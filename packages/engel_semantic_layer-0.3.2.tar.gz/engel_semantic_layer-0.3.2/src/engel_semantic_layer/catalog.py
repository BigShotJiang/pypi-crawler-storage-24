from __future__ import annotations

import json
import tempfile
import webbrowser
from collections import Counter
from html import escape
from pathlib import Path
from typing import Any

from .layer import SemanticLayer
from .loader import load_modules
from .models import CrossModuleMetric, Module, QueryRequest


def _sample_request() -> QueryRequest:
    return QueryRequest(
        from_date="2026-01-01T00:00:00Z",
        to_date="2026-12-31T23:59:59Z",
        time_grain="monthly",
    )


def _build_compile_preview_map(model_path: str | Path) -> dict[str, dict[str, Any]]:
    layer = SemanticLayer.from_path(model_path)
    request = _sample_request()
    previews: dict[str, dict[str, Any]] = {}

    metric_ids = [
        *layer._compiler.by_metric.keys(),
        *layer._compiler.by_cross_metric.keys(),
    ]

    for metric in metric_ids:
        try:
            compiled = layer.compile(metric, request)
            previews[metric] = {
                "ok": True,
                "sql": compiled.sql,
                "moduleId": compiled.module_id,
                "metadata": compiled.metadata,
            }
        except Exception as exc:  # best-effort preview only
            previews[metric] = {
                "ok": False,
                "error": str(exc),
            }

    return previews


def _source_href(source_file: Path, output_path: Path) -> str:
    try:
        return source_file.resolve().as_uri()
    except ValueError:
        return source_file.relative_to(output_path.parent).as_posix()


def _serialize_filter(filter_obj: Any) -> dict[str, Any]:
    payload = {
        "column": filter_obj.column,
        "operator": filter_obj.operator,
        "expression": filter_obj.expression,
    }
    if filter_obj.schema:
        payload["schema"] = filter_obj.schema
    if filter_obj.table:
        payload["table"] = filter_obj.table
    return payload


def _serialize_module(module: Module, output_path: Path) -> dict[str, Any]:
    source_file = module.source_file or output_path
    return {
        "id": module.identifier,
        "label": module.label,
        "description": module.description,
        "schema": module.schema,
        "table": module.table,
        "project": module.project,
        "sourceFile": str(source_file),
        "sourceHref": _source_href(source_file, output_path),
        "dimensionCount": len(module.dimensions),
        "dimensions": [
            {
                "column": dimension.column,
                "type": dimension.type,
                "label": dimension.label,
                "description": dimension.description,
                "targetColumn": dimension.target_column,
            }
            for dimension in module.dimensions
        ],
        "relationships": [
            {
                "name": relationship.name,
                "fromColumn": relationship.from_column,
                "toColumn": relationship.to_column,
                "toModule": relationship.to_module,
                "toTable": relationship.to_table,
                "relationshipType": relationship.relationship_type,
                "joinType": relationship.join_type,
            }
            for relationship in module.relationships
        ],
        "metrics": [metric.identifier for metric in module.metrics],
    }


def _serialize_metric(module: Module, metric: Any, output_path: Path) -> dict[str, Any]:
    source_file = module.source_file or output_path
    return {
        "id": metric.identifier,
        "name": metric.name,
        "description": metric.description,
        "moduleId": module.identifier,
        "moduleLabel": module.label,
        "calculation": metric.calculation,
        "category": metric.category,
        "table": f"{module.schema}.{module.table}",
        "project": module.project,
        "time": metric.time,
        "format": metric.format,
        "targetName": metric.target_name,
        "dimensions": metric.dimensions,
        "dimensionCount": len(metric.dimensions),
        "filters": [_serialize_filter(filter_obj) for filter_obj in metric.filters],
        "slices": [
            {
                "name": slice_obj.name,
                "filter": _serialize_filter(slice_obj.filter),
            }
            for slice_obj in metric.slices
        ],
        "ownerEmails": metric.owner_emails,
        "isPrivate": metric.is_private,
        "isUnlisted": metric.is_unlisted,
        "timeGrains": metric.time_grains,
        "timeResampling": metric.time_resampling,
        "value": metric.value,
        "distinctOn": metric.distinct_on,
        "sqlExpression": metric.sql_expression,
        "numerator": metric.numerator,
        "denominator": metric.denominator,
        "numeratorSql": metric.numerator_sql,
        "denominatorSql": metric.denominator_sql,
        "aiContext": metric.ai_context,
        "sourceFile": str(source_file),
        "sourceHref": _source_href(source_file, output_path),
    }


def _serialize_cross_metric(metric: CrossModuleMetric, output_path: Path) -> dict[str, Any]:
    source_file = metric.source_file or output_path
    return {
        "id": metric.identifier,
        "name": metric.name,
        "description": metric.description,
        "moduleId": "cross_module_metrics",
        "moduleLabel": "Cross-module metrics",
        "calculation": metric.calculation,
        "category": "Cross-module",
        "table": "-",
        "project": None,
        "time": None,
        "format": metric.format,
        "targetName": metric.target_name,
        "dimensions": [],
        "dimensionCount": 0,
        "filters": [],
        "slices": [],
        "ownerEmails": [],
        "isPrivate": False,
        "isUnlisted": False,
        "timeGrains": [],
        "timeResampling": None,
        "value": None,
        "distinctOn": None,
        "sqlExpression": None,
        "numerator": metric.numerator_metric,
        "denominator": metric.denominator_metric,
        "numeratorSql": None,
        "denominatorSql": None,
        "aiContext": None,
        "joinOn": metric.join_on,
        "joinType": metric.join_type,
        "sourceFile": str(source_file),
        "sourceHref": _source_href(source_file, output_path),
    }


def build_catalog_payload(model_path: str | Path, output_path: str | Path) -> dict[str, Any]:
    modules, cross_module_metrics, _ = load_modules(model_path)
    output = Path(output_path)

    compile_preview_map = _build_compile_preview_map(model_path)

    metrics = [_serialize_metric(module, metric, output) for module in modules for metric in module.metrics]
    metrics.extend(_serialize_cross_metric(metric, output) for metric in cross_module_metrics)
    for metric in metrics:
        metric["compilePreview"] = compile_preview_map.get(metric["id"], {"ok": False, "error": "No preview available"})
    metrics.sort(key=lambda item: item["id"])

    module_payload = [_serialize_module(module, output) for module in modules]
    module_payload.sort(key=lambda item: item["id"])

    category_counts = Counter(metric["category"] or "Uncategorized" for metric in metrics)
    calc_counts = Counter(metric["calculation"] for metric in metrics)

    join_edges = []
    by_table = {module.table: module for module in modules}
    for module in modules:
        for relationship in module.relationships:
            target = None
            if relationship.to_module:
                target = next((candidate for candidate in modules if candidate.identifier == relationship.to_module), None)
            if not target and relationship.to_table:
                target = by_table.get(relationship.to_table)
            join_edges.append(
                {
                    "fromModuleId": module.identifier,
                    "toModuleId": target.identifier if target else relationship.to_module or relationship.to_table,
                    "fromColumn": relationship.from_column,
                    "toColumn": relationship.to_column,
                    "joinType": relationship.join_type,
                    "relationshipType": relationship.relationship_type,
                    "resolved": target is not None,
                }
            )

    return {
        "summary": {
            "modelPath": str(model_path),
            "modules": len(modules),
            "metrics": len(metrics),
            "crossModuleMetrics": len(cross_module_metrics),
            "categories": [{"name": name, "count": count} for name, count in sorted(category_counts.items())],
            "calculations": [{"name": name, "count": count} for name, count in sorted(calc_counts.items())],
            "joinEdges": len(join_edges),
        },
        "modules": module_payload,
        "metrics": metrics,
        "joins": join_edges,
    }


def render_catalog_html(payload: dict[str, Any], *, title: str = "Semantic layer catalog") -> str:
    title_text = escape(title)
    payload_json = json.dumps(payload, indent=2, sort_keys=True)
    model_path = escape(str(payload["summary"]["modelPath"]))
    return f"""<!doctype html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    <title>{title_text}</title>
    <style>
      :root {{
        color-scheme: dark;
        --bg: #0d0d0e;
        --bg-2: #131314;
        --panel: rgba(20, 20, 21, 0.9);
        --panel-2: rgba(24, 24, 26, 0.97);
        --panel-3: rgba(30, 30, 32, 0.9);
        --line: rgba(255, 255, 255, 0.08);
        --line-strong: rgba(255, 255, 255, 0.16);
        --text: #f2f2f3;
        --muted: #9b9b9f;
        --accent: #d0d0d4;
        --accent-2: #e6e6e8;
        --accent-3: #b8b8bc;
        --shadow: 0 18px 48px rgba(0, 0, 0, 0.28);
        --radius: 14px;
        --radius-sm: 10px;
        --code-bg: rgba(10, 10, 11, 0.98);
      }}
      * {{ box-sizing: border-box; }}
      html {{ background: linear-gradient(180deg, #111112 0%, #0b0b0c 100%); }}
      body {{
        margin: 0;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        background: transparent;
        color: var(--text);
      }}
      a {{ color: var(--accent-2); text-decoration: none; }}
      a:hover {{ text-decoration: underline; }}
      button, input, select {{ font: inherit; }}
      .page {{ max-width: 1500px; margin: 0 auto; padding: 20px 18px 24px; }}
      .hero {{
        display: grid;
        gap: 14px;
        padding: 18px;
        border: 1px solid var(--line);
        border-radius: 18px;
        background: linear-gradient(180deg, rgba(24, 24, 26, 0.96), rgba(14, 14, 15, 0.94));
        box-shadow: var(--shadow);
      }}
      .eyebrow {{ color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .12em; font-weight: 700; }}
      .hero-top {{ display: flex; justify-content: space-between; gap: 14px; align-items: start; flex-wrap: wrap; }}
      .hero h1 {{ margin: 0; font-size: clamp(24px, 3vw, 34px); line-height: 1.05; }}
      .hero-copy {{ max-width: 880px; }}
      .hero-copy p {{ margin: 6px 0 0; color: var(--muted); font-size: 13px; line-height: 1.45; }}
      .path-pill {{
        margin-top: 10px;
        display: inline-flex;
        max-width: 100%;
        padding: 8px 10px;
        border: 1px solid var(--line);
        border-radius: 999px;
        background: rgba(10, 10, 11, 0.9);
        color: var(--muted);
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 11px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }}
      .stats {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }}
      .stat {{
        border: 1px solid var(--line);
        border-radius: 14px;
        padding: 12px 14px;
        background: linear-gradient(180deg, rgba(28, 28, 30, 0.96), rgba(18, 18, 20, 0.94));
      }}
      .stat-label {{ color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .1em; }}
      .stat-value {{ margin-top: 6px; font-size: 24px; font-weight: 740; }}
      .stat-foot {{ margin-top: 4px; color: var(--muted); font-size: 11px; }}
      .toolbar {{
        margin-top: 12px;
        display: grid;
        gap: 10px;
        padding: 12px;
        border: 1px solid var(--line);
        border-radius: 16px;
        background: rgba(12, 12, 13, 0.84);
      }}
      .toolbar-grid {{ display: grid; grid-template-columns: minmax(0, 1.8fr) repeat(2, minmax(160px, 0.6fr)); gap: 10px; }}
      .field {{ display: grid; gap: 6px; }}
      .field-label {{ color: var(--muted); font-size: 11px; font-weight: 600; }}
      input, select {{
        width: 100%;
        border-radius: 12px;
        border: 1px solid var(--line);
        background: var(--panel-2);
        color: var(--text);
        padding: 10px 12px;
        outline: none;
        transition: border-color .15s ease, box-shadow .15s ease;
      }}
      input:focus, select:focus {{ border-color: var(--line-strong); box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.06); }}
      .category-row {{ display: flex; gap: 8px; flex-wrap: wrap; }}
      .chip-button, .chip {{
        display: inline-flex;
        gap: 6px;
        align-items: center;
        padding: 6px 10px;
        border-radius: 999px;
        border: 1px solid var(--line);
        background: rgba(24, 24, 26, 0.92);
        color: var(--text);
        font-size: 11px;
        line-height: 1;
      }}
      .chip-button {{ cursor: pointer; }}
      .chip-button.active {{ border-color: rgba(255, 255, 255, 0.18); background: rgba(54, 54, 56, 0.92); color: #ffffff; }}
      .chip small, .chip-button small {{ color: var(--muted); font-size: 11px; }}
      .layout {{ margin-top: 12px; display: grid; grid-template-columns: minmax(340px, 430px) minmax(0, 1fr); gap: 12px; align-items: start; }}
      .panel {{
        border: 1px solid var(--line);
        border-radius: 18px;
        background: linear-gradient(180deg, rgba(18, 18, 20, 0.97), rgba(12, 12, 13, 0.95));
        box-shadow: var(--shadow);
        overflow: hidden;
      }}
      .panel-header {{
        padding: 14px 16px 12px;
        border-bottom: 1px solid var(--line);
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: end;
      }}
      .panel-title {{ font-size: 16px; font-weight: 720; }}
      .panel-subtitle {{ color: var(--muted); font-size: 12px; margin-top: 3px; }}
      .metric-list {{ max-height: calc(100vh - 150px); overflow: auto; padding: 8px; }}
      .group-block + .group-block {{ margin-top: 10px; }}
      .group-heading {{ padding: 4px 8px 2px; color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .1em; }}
      .group-heading strong {{ color: var(--text); font-size: 12px; letter-spacing: normal; text-transform: none; margin-right: 6px; }}
      .metric-row {{
        margin-bottom: 8px;
        padding: 12px;
        border: 1px solid transparent;
        border-radius: 14px;
        background: rgba(26, 26, 28, 0.9);
        cursor: pointer;
        transition: transform .12s ease, border-color .12s ease, background .12s ease;
      }}
      .metric-row:hover {{ transform: translateY(-1px); border-color: var(--line-strong); background: rgba(34, 34, 37, 0.96); }}
      .metric-row.active {{ border-color: rgba(255, 255, 255, 0.16); background: linear-gradient(180deg, rgba(42, 42, 45, 0.96), rgba(28, 28, 30, 0.96)); }}
      .metric-title-row {{ display: flex; gap: 12px; justify-content: space-between; align-items: start; }}
      .metric-name {{ font-weight: 700; font-size: 14px; }}
      .metric-id {{ color: var(--muted); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 10px; margin-top: 4px; }}
      .metric-desc {{ color: var(--muted); font-size: 12px; margin-top: 6px; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }}
      .meta-row {{ display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }}
      .meta-pill {{
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 8px;
        border-radius: 999px;
        background: rgba(12, 12, 13, 0.85);
        border: 1px solid var(--line);
        color: var(--muted);
        font-size: 10px;
      }}
      .meta-pill strong {{ color: var(--text); font-size: 11px; }}
      .empty-state {{ padding: 26px 20px 28px; color: var(--muted); text-align: center; }}
      .detail-panel {{ position: sticky; top: 14px; }}
      .detail-header {{ padding: 16px 18px 12px; border-bottom: 1px solid var(--line); }}
      .detail-header-top {{ display: flex; justify-content: space-between; align-items: start; gap: 16px; flex-wrap: wrap; }}
      .detail-name {{ font-size: clamp(20px, 2.5vw, 28px); font-weight: 760; line-height: 1.08; }}
      .detail-subtitle {{ margin-top: 6px; color: var(--muted); font-size: 12px; }}
      .detail-body {{ padding: 16px 18px 18px; max-height: calc(100vh - 120px); overflow: auto; }}
      .section + .section {{ margin-top: 16px; }}
      .section-title {{ font-size: 11px; text-transform: uppercase; letter-spacing: .12em; color: var(--muted); margin-bottom: 8px; }}
      .overview-grid {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }}
      .info-card {{
        padding: 10px 11px;
        border: 1px solid var(--line);
        border-radius: 12px;
        background: rgba(24, 24, 26, 0.9);
      }}
      .info-label {{ color: var(--muted); font-size: 10px; text-transform: uppercase; letter-spacing: .08em; }}
      .info-value {{ margin-top: 5px; font-weight: 620; line-height: 1.35; word-break: break-word; font-size: 12px; }}
      details.preview-block {{ border: 1px solid var(--line); border-radius: 14px; background: rgba(20, 20, 21, 0.92); overflow: hidden; }}
      details.preview-block[open] {{ border-color: var(--line-strong); }}
      .preview-summary {{ list-style: none; cursor: pointer; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; gap: 10px; }}
      .preview-summary::-webkit-details-marker {{ display: none; }}
      .preview-summary-title {{ font-weight: 650; font-size: 13px; }}
      .preview-summary-meta {{ color: var(--muted); font-size: 11px; }}
      .preview-content {{ padding: 0 12px 12px; }}
      .code-block {{
        margin: 0;
        padding: 10px 11px;
        border: 1px solid var(--line);
        border-radius: 12px;
        background: var(--code-bg);
        color: #e4e4e6;
        white-space: pre-wrap;
        word-break: break-word;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 11px;
        line-height: 1.45;
      }}
      .stack {{ display: grid; gap: 8px; }}
      .list-card {{
        padding: 9px 11px;
        border: 1px solid var(--line);
        border-radius: 12px;
        background: rgba(24, 24, 26, 0.82);
      }}
      .list-card-title {{ font-size: 12px; font-weight: 650; margin-bottom: 4px; }}
      .list-card-subtitle {{ color: var(--muted); font-size: 11px; }}
      .tag-grid {{ display: flex; flex-wrap: wrap; gap: 6px; }}
      .detail-columns {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }}
      .muted {{ color: var(--muted); }}
      .small {{ font-size: 12px; }}
      @media (max-width: 1160px) {{
        .stats {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
        .layout {{ grid-template-columns: 1fr; }}
        .detail-panel {{ position: static; }}
        .detail-body {{ max-height: none; }}
        .metric-list {{ max-height: 52vh; }}
      }}
      @media (max-width: 760px) {{
        .page {{ padding: 14px 12px 20px; }}
        .hero {{ padding: 14px; border-radius: 16px; }}
        .toolbar-grid, .overview-grid, .detail-columns {{ grid-template-columns: 1fr; }}
        .stats {{ grid-template-columns: 1fr 1fr; }}
        .panel-header {{ align-items: start; flex-direction: column; }}
      }}
    </style>
  </head>
  <body>
    <div class=\"page\">
      <section class=\"hero\">
        <div class=\"eyebrow\">Generated metrics catalog</div>
        <div class=\"hero-top\">
          <div class=\"hero-copy\">
            <h1>{title_text}</h1>
            <p>Browse the semantic layer like a product surface instead of a YAML wall. Search by metric, filter by module and calculation, inspect slices and baked-in filters, and jump back to the source file when needed.</p>
            <div class=\"path-pill\" title=\"{model_path}\">{model_path}</div>
          </div>
        </div>

        <div class=\"stats\">
          <div class=\"stat\"><div class=\"stat-label\">Metrics</div><div class=\"stat-value\" id=\"stat-metrics\"></div><div class=\"stat-foot\" id=\"stat-metrics-foot\"></div></div>
          <div class=\"stat\"><div class=\"stat-label\">Modules</div><div class=\"stat-value\" id=\"stat-modules\"></div><div class=\"stat-foot\">Semantic model modules</div></div>
          <div class=\"stat\"><div class=\"stat-label\">Cross-module</div><div class=\"stat-value\" id=\"stat-cross\"></div><div class=\"stat-foot\">Derived metrics across modules</div></div>
          <div class=\"stat\"><div class=\"stat-label\">Relationships</div><div class=\"stat-value\" id=\"stat-joins\"></div><div class=\"stat-foot\">Declared module joins</div></div>
        </div>

        <div class=\"toolbar\">
          <div class=\"toolbar-grid\">
            <label class=\"field\">
              <span class=\"field-label\">Search</span>
              <input id=\"search\" type=\"search\" placeholder=\"Try: booking, conversion, country, revenue…\" />
            </label>
            <label class=\"field\">
              <span class=\"field-label\">Module</span>
              <select id=\"module-filter\"></select>
            </label>
            <label class=\"field\">
              <span class=\"field-label\">Calculation</span>
              <select id=\"calculation-filter\"></select>
            </label>
          </div>
          <div>
            <div class=\"field-label\" style=\"margin-bottom:8px\">Category</div>
            <div class=\"category-row\" id=\"category-chips\"></div>
          </div>
        </div>
      </section>

      <div class=\"layout\">
        <section class=\"panel\">
          <div class=\"panel-header\">
            <div>
              <div class=\"panel-title\">Metrics</div>
              <div class=\"panel-subtitle\">The filtered list stays compact; the details live on the right.</div>
            </div>
            <div class=\"chip\"><span id=\"result-count\"></span><small>visible</small></div>
          </div>
          <div class=\"metric-list\" id=\"metric-list\"></div>
        </section>

        <section class=\"panel detail-panel\">
          <div class=\"detail-header\">
            <div class=\"detail-header-top\">
              <div>
                <div class=\"detail-name\" id=\"detail-name\">Select a metric</div>
                <div class=\"detail-subtitle\" id=\"detail-subtitle\">Choose a metric on the left to inspect it.</div>
              </div>
              <div class=\"tag-grid\" id=\"detail-pills\"></div>
            </div>
          </div>
          <div class=\"detail-body\" id=\"detail-body\"></div>
        </section>
      </div>
    </div>

    <script>
      const payload = {payload_json};
      const state = {{
        search: "",
        module: "all",
        calculation: "all",
        category: "all",
        selectedMetricId: payload.metrics[0]?.id ?? null,
      }};

      const els = {{
        search: document.getElementById("search"),
        moduleFilter: document.getElementById("module-filter"),
        calculationFilter: document.getElementById("calculation-filter"),
        categoryChips: document.getElementById("category-chips"),
        metricList: document.getElementById("metric-list"),
        detailName: document.getElementById("detail-name"),
        detailSubtitle: document.getElementById("detail-subtitle"),
        detailPills: document.getElementById("detail-pills"),
        detailBody: document.getElementById("detail-body"),
        resultCount: document.getElementById("result-count"),
        statMetrics: document.getElementById("stat-metrics"),
        statMetricsFoot: document.getElementById("stat-metrics-foot"),
        statModules: document.getElementById("stat-modules"),
        statCross: document.getElementById("stat-cross"),
        statJoins: document.getElementById("stat-joins"),
      }};

      function fmt(value) {{
        if (value === null || value === undefined || value === "") return "—";
        if (Array.isArray(value)) return value.length ? value.join(", ") : "—";
        if (typeof value === "object") return JSON.stringify(value, null, 2);
        return String(value);
      }}

      function escapeHtml(value) {{
        return String(value)
          .replaceAll("&", "&amp;")
          .replaceAll("<", "&lt;")
          .replaceAll(">", "&gt;")
          .replaceAll('"', "&quot;")
          .replaceAll("'", "&#39;");
      }}

      function truncate(value, max = 140) {{
        if (!value) return "";
        return value.length > max ? `${{value.slice(0, max - 1)}}…` : value;
      }}

      function code(text) {{
        return `<code>${{escapeHtml(text)}}</code>`;
      }}

      function joinLines(lines) {{
        return lines.filter(Boolean).join("\\n");
      }}

      function metricById(metricId) {{
        return payload.metrics.find((metric) => metric.id === metricId) || null;
      }}

      function moduleById(moduleId) {{
        return payload.modules.find((module) => module.id === moduleId) || null;
      }}

      function filteredMetrics() {{
        return payload.metrics.filter((metric) => {{
          const haystack = [
            metric.id,
            metric.name,
            metric.description,
            metric.moduleId,
            metric.category,
            metric.table,
            ...(metric.dimensions || []),
            ...(metric.filters || []).map((filter) => `${{filter.column}} ${{filter.operator}} ${{filter.expression}}`),
            ...(metric.slices || []).map((slice) => `${{slice.name}} ${{slice.filter.column}} ${{slice.filter.expression}}`),
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();

          return (
            (state.module === "all" || metric.moduleId === state.module) &&
            (state.calculation === "all" || metric.calculation === state.calculation) &&
            (state.category === "all" || (metric.category || "Uncategorized") === state.category) &&
            haystack.includes(state.search)
          );
        }});
      }}

      function populateFilters() {{
        const modules = ["all", ...new Set(payload.metrics.map((metric) => metric.moduleId))];
        const calculations = ["all", ...new Set(payload.metrics.map((metric) => metric.calculation))];

        els.moduleFilter.innerHTML = modules
          .map((value) => `<option value=\"${{escapeHtml(value)}}\">${{value === "all" ? "All modules" : value}}</option>`)
          .join("");

        els.calculationFilter.innerHTML = calculations
          .map((value) => `<option value=\"${{escapeHtml(value)}}\">${{value === "all" ? "All calculations" : value}}</option>`)
          .join("");

        els.categoryChips.innerHTML = [
          `<button class=\"chip-button\" data-category=\"all\">All <small>${{payload.metrics.length}}</small></button>`,
          ...payload.summary.categories.map(
            (category) => `<button class=\"chip-button\" data-category=\"${{escapeHtml(category.name)}}\">${{escapeHtml(category.name)}} <small>${{category.count}}</small></button>`,
          ),
        ].join("");
      }}

      function renderStats(metrics) {{
        els.statMetrics.textContent = payload.summary.metrics;
        els.statMetricsFoot.textContent = `${{metrics.length}} currently visible`;
        els.statModules.textContent = payload.summary.modules;
        els.statCross.textContent = payload.summary.crossModuleMetrics;
        els.statJoins.textContent = payload.summary.joinEdges;
        els.resultCount.textContent = metrics.length;
      }}

      function renderMetricCard(metric) {{
        return `
          <article class=\"metric-row ${{metric.id === state.selectedMetricId ? "active" : ""}}\" data-metric-id=\"${{escapeHtml(metric.id)}}\">
            <div class=\"metric-title-row\">
              <div>
                <div class=\"metric-name\">${{escapeHtml(metric.name)}}</div>
                <div class=\"metric-id\">${{escapeHtml(metric.id)}}</div>
              </div>
              <span class=\"chip\">${{escapeHtml(metric.calculation)}}</span>
            </div>
            <div class=\"metric-desc\">${{escapeHtml(truncate(metric.description || `${{metric.moduleId}} · ${{metric.table}}`, 150))}}</div>
            <div class=\"meta-row\">
              <span class=\"meta-pill\"><strong>${{escapeHtml(metric.moduleId)}}</strong></span>
              <span class=\"meta-pill\"><strong>${{escapeHtml(metric.category || "Uncategorized")}}</strong></span>
              <span class=\"meta-pill\">${{metric.dimensionCount}} dims</span>
              <span class=\"meta-pill\">${{metric.filters.length}} filters</span>
              ${{metric.slices.length ? `<span class=\"meta-pill\">${{metric.slices.length}} slices</span>` : ""}}
            </div>
          </article>
        `;
      }}

      function groupMetrics(metrics) {{
        const modules = new Map();
        metrics.forEach((metric) => {{
          const moduleKey = metric.moduleId;
          if (!modules.has(moduleKey)) modules.set(moduleKey, {{ moduleId: metric.moduleId, categories: new Map() }});

          const categoryKey = metric.category || "";
          const moduleGroup = modules.get(moduleKey);
          if (!moduleGroup.categories.has(categoryKey)) {{
            moduleGroup.categories.set(categoryKey, {{ category: metric.category || null, metrics: [] }});
          }}
          moduleGroup.categories.get(categoryKey).metrics.push(metric);
        }});

        return [...modules.values()]
          .sort((a, b) => a.moduleId.localeCompare(b.moduleId))
          .map((moduleGroup) => ({{
            moduleId: moduleGroup.moduleId,
            categories: [...moduleGroup.categories.values()]
              .sort((a, b) => (a.category || "").localeCompare(b.category || ""))
              .map((categoryGroup) => ({{
                category: categoryGroup.category,
                metrics: categoryGroup.metrics.sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id)),
              }})),
          }}));
      }}

      function renderMetricList(metrics) {{
        if (!metrics.some((metric) => metric.id === state.selectedMetricId)) {{
          state.selectedMetricId = metrics[0]?.id ?? null;
        }}

        if (!metrics.length) {{
          els.metricList.innerHTML = `<div class=\"empty-state\">No metrics match the current filters. Try broadening the search or switching back to all categories.</div>`;
          return;
        }}

        const groups = groupMetrics(metrics);
        els.metricList.innerHTML = groups
          .map((group) => `
            <section class=\"group-block\">
              <div class=\"group-heading\"><strong>${{escapeHtml(group.moduleId)}}</strong> <span>${{group.categories.reduce((sum, category) => sum + category.metrics.length, 0)}} metrics</span></div>
              ${{group.categories
                .map((categoryGroup) => `
                  <div>
                    ${{categoryGroup.category ? `<div class=\\"group-heading\\" style=\\"padding-top:6px; padding-bottom:4px;\\">${{escapeHtml(categoryGroup.category)}}</div>` : ""}}
                    ${{categoryGroup.metrics.map(renderMetricCard).join("")}}
                  </div>
                `)
                .join("")}}
            </section>
          `)
          .join("");
      }}

      function renderTagList(items, renderItem) {{
        if (!items || !items.length) return `<div class=\"muted small\">None</div>`;
        return `<div class=\"tag-grid\">${{items.map(renderItem).join("")}}</div>`;
      }}

      function renderListCards(items, renderItem) {{
        if (!items || !items.length) return `<div class=\"muted small\">None</div>`;
        return `<div class=\"stack\">${{items.map(renderItem).join("")}}</div>`;
      }}

      function renderDetail() {{
        const metric = metricById(state.selectedMetricId);
        if (!metric) {{
          els.detailName.textContent = "No metric selected";
          els.detailSubtitle.textContent = "Choose a metric on the left to inspect it.";
          els.detailPills.innerHTML = "";
          els.detailBody.innerHTML = `<div class=\"muted\">Nothing to show yet.</div>`;
          return;
        }}

        const module = moduleById(metric.moduleId);
        const relatedJoins = payload.joins.filter((join) => join.fromModuleId === metric.moduleId || join.toModuleId === metric.moduleId);
        const isCrossMetric = metric.moduleId === "cross_module_metrics";

        els.detailName.textContent = metric.name;
        els.detailSubtitle.textContent = `${{metric.id}} · ${{metric.moduleId}} · ${{metric.calculation}}`;
        els.detailPills.innerHTML = [
          `<span class=\"chip\">${{escapeHtml(metric.category || "Uncategorized")}}</span>`,
          `<span class=\"chip\">${{metric.dimensionCount}} dimensions</span>`,
          metric.filters.length ? `<span class=\"chip\">${{metric.filters.length}} filters</span>` : "",
          metric.slices.length ? `<span class=\"chip\">${{metric.slices.length}} slices</span>` : "",
        ].filter(Boolean).join("");

        els.detailBody.innerHTML = `
          <section class=\"section\">
            <div class=\"section-title\">Overview</div>
            <div class=\"overview-grid\">
              <div class=\"info-card\"><div class=\"info-label\">Module</div><div class=\"info-value\">${{escapeHtml(metric.moduleId)}}</div></div>
              <div class=\"info-card\"><div class=\"info-label\">Table</div><div class=\"info-value\">${{escapeHtml(metric.table)}}</div></div>
              <div class=\"info-card\"><div class=\"info-label\">Time field</div><div class=\"info-value\">${{escapeHtml(fmt(metric.time))}}</div></div>
              <div class=\"info-card\"><div class=\"info-label\">Value field</div><div class=\"info-value\">${{escapeHtml(fmt(metric.value))}}</div></div>
              <div class=\"info-card\"><div class=\"info-label\">Distinct on</div><div class=\"info-value\">${{escapeHtml(fmt(metric.distinctOn))}}</div></div>
              <div class=\"info-card\"><div class=\"info-label\">Format / target</div><div class=\"info-value\">${{escapeHtml(joinLines([`Format: ${{fmt(metric.format)}}`, `Target: ${{fmt(metric.targetName)}}`]))}}</div></div>
            </div>
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Sample compiled SQL</div>
            <details class=\"preview-block\">
              <summary class=\"preview-summary\">
                <div>
                  <div class=\"preview-summary-title\">Synthetic monthly compile</div>
                  <div class=\"preview-summary-meta\">from 2026-01-01 to 2026-12-31 · timeGrain=monthly</div>
                </div>
                <span class=\"chip\">${{metric.compilePreview?.ok ? "SQL ready" : "Preview unavailable"}}</span>
              </summary>
              <div class=\"preview-content\">
                ${{metric.compilePreview?.ok
                  ? `<pre class=\\"code-block\\">${{escapeHtml(metric.compilePreview.sql)}}</pre>`
                  : `<pre class=\\"code-block\\">${{escapeHtml(metric.compilePreview?.error || "No preview available")}}</pre>`}}
              </div>
            </details>
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Description</div>
            <pre class=\"code-block\">${{escapeHtml(metric.description || module?.description || "No description provided.")}}</pre>
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Source</div>
            <div class=\"detail-columns\">
              <div class=\"info-card\">
                <div class=\"info-label\">YAML file</div>
                <div class=\"info-value small\">${{escapeHtml(metric.sourceFile)}}</div>
              </div>
              <div class=\"info-card\">
                <div class=\"info-label\">Quick actions</div>
                <div class=\"info-value\"><a href=\"${{escapeHtml(metric.sourceHref)}}\">Open YAML source</a></div>
              </div>
            </div>
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Allowed dimensions</div>
            ${{renderTagList(metric.dimensions, (dimension) => `<span class=\"chip\">${{escapeHtml(dimension)}}</span>`)}}
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Metric filters</div>
            ${{renderListCards(metric.filters, (filter) => `
              <div class=\"list-card\">
                <div class=\"list-card-title\">${{escapeHtml(filter.column)}}</div>
                <div class=\"list-card-subtitle\">${{escapeHtml(filter.operator)}} · ${{escapeHtml(filter.expression)}}</div>
              </div>
            `)}}
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Slices</div>
            ${{renderListCards(metric.slices, (slice) => `
              <div class=\"list-card\">
                <div class=\"list-card-title\">${{escapeHtml(slice.name)}}</div>
                <div class=\"list-card-subtitle\">${{escapeHtml(`${{slice.filter.column}} ${{slice.filter.operator}} ${{slice.filter.expression}}`)}}</div>
              </div>
            `)}}
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Relationships</div>
            ${{renderListCards(relatedJoins, (join) => `
              <div class=\"list-card\">
                <div class=\"list-card-title\">${{escapeHtml(join.fromModuleId)}} → ${{escapeHtml(join.toModuleId || "unresolved")}}</div>
                <div class=\"list-card-subtitle\">${{escapeHtml(`${{join.fromColumn}} = ${{join.toColumn}} · ${{join.joinType}} · ${{join.relationshipType}}`)}}</div>
              </div>
            `)}}
          </section>

          <section class=\"section\">
            <div class=\"section-title\">Expressions and raw fields</div>
            <div class=\"detail-columns\">
              <pre class=\"code-block\">${{escapeHtml(joinLines([
                `Owners: ${{fmt(metric.ownerEmails)}}`,
                `Private: ${{metric.isPrivate ? "yes" : "no"}}`,
                `Unlisted: ${{metric.isUnlisted ? "yes" : "no"}}`,
                `Time grains: ${{fmt(metric.timeGrains)}}`,
                `Time resampling: ${{fmt(metric.timeResampling)}}`,
                isCrossMetric ? `Join on: ${{fmt(metric.joinOn)}}` : "",
                isCrossMetric ? `Join type: ${{fmt(metric.joinType)}}` : "",
              ]))}}</pre>
              <pre class=\"code-block\">${{escapeHtml(joinLines([
                `SQL expression: ${{fmt(metric.sqlExpression)}}`,
                `Numerator: ${{fmt(metric.numerator)}}`,
                `Denominator: ${{fmt(metric.denominator)}}`,
                `Numerator SQL: ${{fmt(metric.numeratorSql)}}`,
                `Denominator SQL: ${{fmt(metric.denominatorSql)}}`,
              ]))}}</pre>
            </div>
          </section>
        `;
      }}

      function attachListeners() {{
        document.querySelectorAll(".metric-row").forEach((row) => {{
          row.addEventListener("click", () => {{
            state.selectedMetricId = row.dataset.metricId;
            render();
          }});
        }});

        document.querySelectorAll("[data-category]").forEach((button) => {{
          button.classList.toggle("active", button.dataset.category === state.category);
          button.addEventListener("click", () => {{
            state.category = button.dataset.category;
            render();
          }});
        }});
      }}

      function render() {{
        const metrics = filteredMetrics();
        renderStats(metrics);
        renderMetricList(metrics);
        renderDetail();
        attachListeners();
      }}

      els.search.addEventListener("input", (event) => {{
        state.search = event.target.value.trim().toLowerCase();
        render();
      }});
      els.moduleFilter.addEventListener("change", (event) => {{
        state.module = event.target.value;
        render();
      }});
      els.calculationFilter.addEventListener("change", (event) => {{
        state.calculation = event.target.value;
        render();
      }});

      populateFilters();
      render();
    </script>
  </body>
</html>
"""


def default_catalog_output_path() -> Path:
    temp_dir = Path(tempfile.gettempdir())
    return temp_dir / "engel-semantic-layer-catalog.html"


def write_catalog_html(model_path: str | Path, output_path: str | Path, *, title: str = "Semantic layer catalog") -> Path:
    output = Path(output_path)
    payload = build_catalog_payload(model_path, output)
    html = render_catalog_html(payload, title=title)
    output.write_text(html, encoding="utf-8")
    return output


def open_catalog_in_browser(path: str | Path) -> None:
    webbrowser.open(Path(path).resolve().as_uri())
