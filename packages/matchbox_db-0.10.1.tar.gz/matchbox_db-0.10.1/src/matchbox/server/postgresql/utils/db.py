"""General utilities for the PostgreSQL backend."""

import base64
import contextlib
import cProfile
import io
import pstats
import uuid
from collections.abc import Generator
from typing import Literal

import pyarrow as pa
from pyarrow import Table as ArrowTable
from sqlalchemy import Column, MetaData, Table, func, select, text
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select
from sqlalchemy.sql.type_api import TypeEngine

from matchbox.common.datatypes import require
from matchbox.common.dtos import (
    BackendResourceType,
    CollectionName,
    GroupName,
    PermissionType,
)
from matchbox.common.exceptions import (
    MatchboxCollectionNotFoundError,
    MatchboxGroupNotFoundError,
)
from matchbox.common.logging import logger
from matchbox.server.base import MatchboxBackends, MatchboxSnapshot
from matchbox.server.postgresql.db import MBDB
from matchbox.server.postgresql.orm import Collections, Groups, Permissions

# Data management


def dump() -> MatchboxSnapshot:
    """Dumps the entire database to a snapshot.

    Returns:
        A MatchboxSnapshot object of type "postgres" with the database's
            current state.
    """
    data = {}

    with MBDB.get_session() as session:
        for table in MBDB.sorted_tables:
            # Query all records from this table
            records = session.execute(select(table)).mappings().all()

            # Convert each record to a dictionary
            table_data = []
            for record in records:
                record_dict = dict(record)
                for k, v in record_dict.items():
                    # Store bytes as nested dictionary with encoding format
                    if isinstance(v, bytes):
                        record_dict[k] = {"base64": base64.b64encode(v).decode("ascii")}

                table_data.append(record_dict)

            data[table.name] = table_data

    return MatchboxSnapshot(backend_type=MatchboxBackends.POSTGRES, data=data)


def restore(snapshot: MatchboxSnapshot, batch_size: int) -> None:
    """Restores the database from a snapshot.

    Args:
        snapshot: A MatchboxSnapshot object of type "postgres" with the
            database's state
        batch_size: The number of records to insert in each batch

    Raises:
        ValueError: If the snapshot is missing data
    """
    with MBDB.get_session() as session:
        # Process tables in order
        for table in MBDB.sorted_tables:
            if table.name not in snapshot.data:
                raise ValueError(f"Invalid: Table {table.name} not found in snapshot.")

            records = snapshot.data[table.name]

            if not records:
                continue

            # Process records for insertion
            processed_records = []
            for record in records:
                processed_record = {}

                for key, value in record.items():
                    # Check if the value is a dictionary with encoding format
                    if isinstance(value, dict) and "base64" in value:
                        processed_record[key] = base64.b64decode(value["base64"])
                    else:
                        processed_record[key] = value

                processed_records.append(processed_record)

            # Insert
            for i in range(0, len(processed_records), batch_size):
                batch = processed_records[i : i + batch_size]
                session.execute(insert(table), batch)
                session.flush()

            # Re-sync primary key sequences
            for pk in table.primary_key:
                lock_stmt = text(
                    f"lock table {table.schema}.{table.name} in exclusive mode;"
                )
                sync_statement = select(
                    func.setval(
                        func.pg_get_serial_sequence(
                            text(f"'{table.schema}.{table.name}'"),
                            text(f"'{pk.name}'"),
                        ),
                        func.coalesce(func.max(text(pk.name)), 0),
                    )
                ).select_from(text(f"{table.schema}.{table.name}"))

                session.execute(lock_stmt)
                session.execute(sync_statement)

        session.commit()


# Permissions


def grant_permission(
    session: Session,
    group_name: GroupName,
    permission: PermissionType,
    resource: Literal[BackendResourceType.SYSTEM] | CollectionName,
) -> None:
    """Grant permission within a session.

    Committing (or otherwise) left to the caller.
    """
    # Get group
    group = session.scalars(
        select(Groups).where(Groups.name == group_name)
    ).one_or_none()
    if group is None:
        raise MatchboxGroupNotFoundError(f"Group '{group_name}' not found")

    if resource == BackendResourceType.SYSTEM:
        stmt = (
            insert(Permissions)
            .values(
                group_id=group.group_id,
                permission=permission,
                is_system=True,
                collection_id=None,
            )
            .on_conflict_do_nothing(constraint="unique_permission_grant")
        )
        session.execute(stmt)
    else:
        # Grant collection permission
        collection = session.scalars(
            select(Collections).where(Collections.name == resource)
        ).one_or_none()
        if collection is None:
            raise MatchboxCollectionNotFoundError(name=resource)

        stmt = (
            insert(Permissions)
            .values(
                group_id=group.group_id,
                permission=permission,
                collection_id=collection.collection_id,
                is_system=None,
            )
            .on_conflict_do_nothing(constraint="unique_permission_grant")
        )
        session.execute(stmt)
    logger.info(
        f"Granted {permission} permission on '{resource}' to group '{group_name}'",
        prefix="Grant permission",
    )


# SQLAlchemy profiling


@contextlib.contextmanager
def sqa_profiled() -> Generator[None, None, None]:
    """SQLAlchemy profiler.

    Taken directly from their docs:
    https://docs.sqlalchemy.org/en/20/faq/performance.html#query-profiling
    """
    pr = cProfile.Profile()
    pr.enable()
    yield
    pr.disable()
    s = io.StringIO()
    ps = pstats.Stats(pr, stream=s).sort_stats("cumulative")
    ps.print_stats()
    # Uncomment this to see who's calling what
    # ps.print_callers()
    print(s.getvalue())


# Misc


def compile_sql(stmt: Select) -> str:
    """Compiles a SQLAlchemy statement into a string.

    Args:
        stmt: The SQLAlchemy statement to compile.

    Returns:
        The compiled SQL statement as a string.
    """
    return str(
        stmt.compile(
            dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True}
        )
    )


@contextlib.contextmanager
def ingest_to_temporary_table(
    table_name: str,
    schema_name: str,
    data: ArrowTable,
    column_types: dict[str, TypeEngine],
    max_chunksize: int | None = None,
) -> Generator[Table, None, None]:
    """Context manager to ingest Arrow data to a temporary table with explicit types.

    Args:
        table_name: Base name for the temporary table
        schema_name: Schema where the temporary table will be created
        data: PyArrow table containing the data to ingest
        column_types: Map of column names to SQLAlchemy type instances
        max_chunksize: Optional maximum chunk size for batches

    Returns:
        A SQLAlchemy Table object representing the temporary table
    """
    temp_table_name = f"{table_name}_tmp_{uuid.uuid4().hex}"

    # Validate that all data columns have type mappings
    missing_columns = set(data.column_names) - set(column_types.keys())
    if missing_columns:
        raise ValueError(f"Missing type mappings for columns: {missing_columns}")

    try:
        # Create SQLAlchemy Table from explicit type mapping
        metadata = MetaData(schema=schema_name)
        columns = [
            Column(column_name, column_type)
            for column_name, column_type in column_types.items()
            if column_name in data.column_names
        ]
        temp_table = Table(temp_table_name, metadata, *columns)

        with MBDB.get_session() as session:
            temp_table.create(require(session.bind))
            session.commit()

        # Ingest data into the temporary table
        with MBDB.get_adbc_connection() as connection:
            batch_reader = pa.RecordBatchReader.from_batches(
                data.schema, data.to_batches(max_chunksize=max_chunksize)
            )

            with connection.cursor() as cursor:
                cursor.adbc_ingest(
                    table_name=temp_table_name,
                    data=batch_reader,
                    mode="append",
                    db_schema_name=schema_name,
                )

            connection.commit()

        MBDB.vacuum_analyze(
            f"{schema_name}.{temp_table_name}",
        )

        yield temp_table

    finally:
        # Step 3: Clean up
        try:
            with MBDB.get_session() as session:
                temp_table.drop(require(session.bind), checkfirst=True)
                session.commit()
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to drop temp table {temp_table_name}: {e}")
