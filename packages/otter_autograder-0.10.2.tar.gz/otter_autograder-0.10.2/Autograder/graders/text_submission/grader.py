"""
Base class for text submission grading.

This module provides the extensible BaseTextSubmissionGrader class that
implements a 3-phase grading approach:
1. Aggregate Analysis - Identify core topics, misconceptions, and student questions
2. Individual Grading - Grade each submission for engagement, relevance, and quality
3. Report Generation - Generate comprehensive insights and recommendations

To create a custom text grader:
1. Subclass BaseTextSubmissionGrader
2. Override prompt methods (_build_*_prompt) for different grading criteria
3. Override hook methods (add_manual_topics_hook, output_report_hook) for customization
4. Optionally customize ScoreCalculator and RubricGenerator via constructor
"""

import logging
import os
import requests
from datetime import datetime
from typing import Any, Dict, List

from Autograder.grader import Grader
from Autograder import config_models
from Autograder.grader_context import GraderContext
from Autograder.ai_orchestrator import (
    ProviderFallbackOrchestrator,
    parse_anthropic_json_payload,
    query_anthropic_text,
    query_anthropic_structured,
    query_openai_structured,
)
from lms_interface.classes import Feedback, Submission, TextSubmission

from .pii import SubmissionPIIRedactor
from .scoring import ScoreCalculator, RubricGenerator
from .prompts import (
    get_aggregate_analysis_prompt,
    get_individual_grading_prompt,
    get_question_consolidation_prompt,
    DEFAULT_MAX_WORDS,
    DEFAULT_MAX_CHARACTERS,
)

log = logging.getLogger(__name__)


class _PromptTemplateContext(dict):
    """Safe formatter context that leaves unknown placeholders unchanged."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


class BaseTextSubmissionGrader(Grader):
    """
    Grader for text-based submissions using a 3-phase approach.

    This is the extensible base class for text submission grading. It provides:
    - 3-phase grading pipeline (aggregate, individual, report)
    - AI provider fallback (Anthropic/OpenAI)
    - PII redaction before AI calls
    - Configurable scoring rubric
    - Slack notifications and file output
    - Multiple hook methods for customization

    Rubric (10 points total, customizable):
    - Engagement (4 pts): Effort to process and explain material
    - Length (2 pts): Meeting 250+ word requirement (calculated locally)
    - Relevance (2 pts): Coverage of class topics
    - Explanation Quality (2 pts): Depth of explanation, not correctness

    To customize for different assignment types, subclass this and override:
    - _build_aggregate_analysis_prompt(): Different aggregate analysis criteria
    - _build_individual_grading_prompt(): Different grading rubric/criteria
    - _build_question_consolidation_prompt(): Different question handling
    - add_manual_topics_hook(): Add/modify topics after AI analysis
    - output_report_hook(): Custom report delivery
    """

    COMPATIBLE_KINDS = {"TextAssignment"}

    @classmethod
    def normalize_settings(cls, settings: Dict, context_label: str) -> Dict:
        """Validate and normalize text submission grader settings."""
        return config_models._normalize_text_submission_grader_settings(
            settings, context_label)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Topic tracking
        self.core_topics = []
        self.related_topics = []
        self.off_topic_indicators = []

        # Results storage
        self.aggregate_results = {}
        self.individual_results = []
        self.support_needed_students = []
        self.consolidated_questions = []

        # Configuration from kwargs
        self.slack_channel = kwargs.get('slack_channel')
        self.records_dir = None
        self.reveal_identity = False
        self.grader_context: GraderContext | None = kwargs.get('grader_context')
        self.prompt_templates: Dict[str, str] = dict(
            kwargs.get('prompt_templates', {}))
        try:
            self.rate_limit_retries = max(
                0, int(kwargs.get('rate_limit_retries', 0)))
        except (TypeError, ValueError):
            self.rate_limit_retries = 0

        rubric_config: Dict[str, Any] = dict(kwargs.get('rubric', {}) or {})

        def _rubric_component(name: str, default_points: int,
                              default_description: str) -> tuple[int, str]:
            component = rubric_config.get(name) or {}
            if not isinstance(component, dict):
                component = {}
            points = component.get("points", default_points)
            description = component.get("description", default_description)
            try:
                points = int(points)
            except (TypeError, ValueError):
                points = default_points
            if points < 0:
                points = default_points
            if not isinstance(description, str) or not description.strip():
                description = default_description
            return points, description

        engagement_points, engagement_description = _rubric_component(
            "engagement", 4, "Effort to process and explain material")
        length_points, length_description = _rubric_component(
            "length", 2, "Meeting word count requirement")
        relevance_points, relevance_description = _rubric_component(
            "relevance", 2, "Coverage of class topics")
        explanation_quality_points, explanation_quality_description = (
            _rubric_component("explanation_quality", 2, "Depth of explanation"))
        try:
            word_threshold = int(rubric_config.get("word_threshold", 250))
        except (TypeError, ValueError):
            word_threshold = 250
        if word_threshold < 1:
            word_threshold = 250

        configured_total = rubric_config.get("total_points")
        if configured_total is None:
            configured_total = (engagement_points + length_points +
                                relevance_points + explanation_quality_points)
        try:
            rubric_total = int(configured_total)
        except (TypeError, ValueError):
            rubric_total = (engagement_points + length_points + relevance_points +
                            explanation_quality_points)
        if rubric_total <= 0:
            rubric_total = (engagement_points + length_points + relevance_points +
                            explanation_quality_points)

        # Scoring and rubric components (can be overridden by subclasses)
        self.score_calculator = ScoreCalculator(word_threshold=word_threshold,
                                                length_points=length_points)
        self.rubric_generator = RubricGenerator(
            engagement_points=engagement_points,
            length_points=length_points,
            relevance_points=relevance_points,
            explanation_quality_points=explanation_quality_points,
            rubric_total=rubric_total,
            word_threshold=word_threshold,
            engagement_description=engagement_description,
            length_description=length_description,
            relevance_description=relevance_description,
            explanation_quality_description=explanation_quality_description)

        # PII redaction
        self.pii_redactor = SubmissionPIIRedactor()
        self.redaction_events: List[Dict] = []

        # Model tier settings for each phase (small, medium, large)
        # Can be configured via grader settings in YAML
        self.phase1_tier = kwargs.get('phase1_tier', 'small')   # Aggregate analysis
        self.phase2_tier = kwargs.get('phase2_tier', 'small')   # Individual grading
        self.phase25_tier = kwargs.get('phase25_tier', 'small')  # Question consolidation

        log.info(
            f"{self.__class__.__name__} initialized with tiers: "
            f"phase1={self.phase1_tier}, phase2={self.phase2_tier}, phase25={self.phase25_tier}"
        )

    # =========================================================================
    # Prompt building methods - Override these for different grading criteria
    # =========================================================================

    def _build_aggregate_analysis_prompt(self, submission_texts: List[str],
                                         assignment_name: str,
                                         course_name: str) -> str:
        """
        Build the prompt for Phase 1 aggregate analysis.

        Override this method to customize how submissions are analyzed
        for identifying topics and patterns.

        Args:
            submission_texts: List of all submission texts
            assignment_name: Name of the assignment
            course_name: Name of the course

        Returns:
            Prompt string for the AI
        """
        rendered_template = self._render_prompt_template(
            "aggregate_analysis", {
                "assignment_name": assignment_name,
                "course_name": course_name,
                "num_submissions": len(submission_texts),
                "submission_texts": submission_texts,
                "submissions_block": "\n\n".join(submission_texts),
            })
        if rendered_template is not None:
            return rendered_template
        return get_aggregate_analysis_prompt(submission_texts, assignment_name,
                                             course_name)

    def _build_individual_grading_prompt(self, submission_text: str,
                                         core_topics: List[str]) -> str:
        """
        Build the prompt for Phase 2 individual grading.

        Override this method to customize the grading rubric and criteria.

        Args:
            submission_text: The student's submission
            core_topics: Core topics from aggregate analysis

        Returns:
            Prompt string for the AI
        """
        rendered_template = self._render_prompt_template(
            "individual_grading", {
                "submission_text": submission_text,
                "core_topics": core_topics,
                "related_topics": self.related_topics,
                "off_topic_indicators": self.off_topic_indicators,
                "core_topics_csv": ", ".join(core_topics),
                "related_topics_csv": ", ".join(self.related_topics),
                "off_topic_indicators_csv": ", ".join(self.off_topic_indicators),
                "engagement_points": self.rubric_generator.engagement_points,
                "length_points": self.rubric_generator.length_points,
                "relevance_points": self.rubric_generator.relevance_points,
                "explanation_quality_points":
                self.rubric_generator.explanation_quality_points,
                "rubric_total": self.rubric_generator.rubric_total,
                "word_threshold": self.score_calculator.word_threshold,
            })
        if rendered_template is not None:
            return rendered_template
        return get_individual_grading_prompt(
            submission_text, core_topics,
            related_topics=self.related_topics,
            off_topic_indicators=self.off_topic_indicators
        )

    def _build_question_consolidation_prompt(self, all_questions: List[str]) -> str:
        """
        Build the prompt for question consolidation.

        Override this method to customize how questions are grouped.

        Args:
            all_questions: List of questions from students

        Returns:
            Prompt string for the AI
        """
        rendered_template = self._render_prompt_template(
            "question_consolidation", {
                "questions": all_questions,
                "questions_list": all_questions,
                "question_count": len(all_questions),
                "questions_block": "\n".join(all_questions),
            })
        if rendered_template is not None:
            return rendered_template
        return get_question_consolidation_prompt(all_questions)

    def _render_prompt_template(self, template_name: str,
                                context: Dict[str, Any]) -> str | None:
        """
        Render a user-configured prompt template, if present.

        Unknown placeholders are preserved to avoid hard failures when
        instructors iterate on custom prompt templates.
        """
        template = self.prompt_templates.get(template_name)
        if not template:
            return None
        try:
            return template.format_map(_PromptTemplateContext(context))
        except Exception as e:
            log.warning(
                f"Failed to render custom prompt template '{template_name}': {e}. "
                "Falling back to built-in prompt.")
            return None

    # =========================================================================
    # PII redaction
    # =========================================================================

    def _redact_submission_text_for_ai(
            self,
            text: str,
            *,
            student_name: str | None = None,
            student_id: int | str | None = None) -> tuple[str, Dict[str, int]]:
        """
        Redact PII from submission text before sending to AI.

        Args:
            text: The submission text
            student_name: Optional student name to redact
            student_id: Optional student ID to redact

        Returns:
            Tuple of (redacted_text, redaction_counts)
        """
        redacted, counts = self.pii_redactor.redact(text,
                                                     student_name=student_name,
                                                     student_id=student_id)
        if counts.get("total_replacements", 0) > 0:
            self.redaction_events.append({
                "student_id": student_id,
                "student_name": student_name,
                "counts": counts,
            })
        return redacted, counts

    # =========================================================================
    # Submission validation and truncation
    # =========================================================================

    def can_grade_submission(self, submission: Submission) -> bool:
        """
        Check if this grader can handle the given submission type.

        Text-based graders can only grade TextSubmission objects.

        Args:
            submission: The submission to check

        Returns:
            True if this is a TextSubmission
        """
        return isinstance(submission, TextSubmission)

    def _truncate_submission_text(
            self,
            text: str,
            max_words: int = DEFAULT_MAX_WORDS,
            max_chars: int = DEFAULT_MAX_CHARACTERS) -> tuple[str, bool]:
        """
        Truncate submission text to max words or max characters.

        Args:
            text: The submission text to truncate
            max_words: Maximum number of words (default: 1000)
            max_chars: Maximum number of characters (default: 7500)

        Returns:
            Tuple of (truncated_text, was_truncated)
        """
        if not text:
            return text, False

        words = text.split()

        # Check word limit
        if len(words) > max_words:
            truncated = ' '.join(words[:max_words])
            return truncated, True

        # Check character limit
        if len(text) > max_chars:
            truncated = text[:max_chars]
            # Try to truncate at word boundary
            last_space = truncated.rfind(' ')
            if last_space > max_chars * 0.9:  # Only if we're not losing too much
                truncated = truncated[:last_space]
            return truncated, True

        return text, False

    # =========================================================================
    # Main grading flow
    # =========================================================================

    def grade_assignment(self, assignment, *args, **kwargs) -> None:
        """
        Override the main grading flow to implement 3-phase approach.

        Args:
            assignment: The assignment to grade
            **kwargs: Additional arguments including:
                - course_name: Name of the course
                - prefer_anthropic: Whether to prefer Anthropic AI
                - records_dir: Directory for saving records
                - reveal_identity: Whether to reveal student identities
        """
        from Autograder.assignment import Assignment_TextAssignment

        if not isinstance(assignment, Assignment_TextAssignment):
            log.error(
                f"TextSubmissionGrader requires Assignment_TextAssignment, got {type(assignment)}"
            )
            return

        runtime_context = kwargs.get('grader_context')
        if runtime_context is None:
            runtime_context = self.grader_context

        # Store assignment and course info for reporting
        default_assignment_name = assignment.lms_assignment.name
        self.assignment_name = getattr(runtime_context, "assignment_name",
                                       None) or default_assignment_name
        self.course_name = (getattr(runtime_context, "course_name", None) or
                            kwargs.get('course_name', 'Unknown Course'))

        # Store provider preference and runtime context
        self.prefer_anthropic = kwargs.get(
            'prefer_anthropic',
            getattr(runtime_context, "prefer_anthropic", False))
        self.records_dir = kwargs.get('records_dir')
        if self.records_dir is None:
            self.records_dir = getattr(runtime_context, "records_dir", None)
        self.reveal_identity = kwargs.get(
            'reveal_identity',
            getattr(runtime_context, "reveal_identity", False))
        self.slack_channel = kwargs.get(
            "slack_channel",
            self.slack_channel or getattr(runtime_context, "slack_channel", None))

        # Initialize token tracking
        self.total_tokens = 0
        self.total_cost = 0.0
        self.usage_details = []

        assignment_name = assignment.lms_assignment.name
        self._run_batch_grading(assignment,
                                assignment_name=assignment_name,
                                course_name=self.course_name)

    def _run_batch_grading(self, assignment, *, assignment_name: str,
                           course_name: str) -> bool:
        """
        Run the complete 3-phase grading pipeline for an assignment.

        Args:
            assignment: Assignment object providing submission data
            assignment_name: Name of the assignment for logging/context
            course_name: Name of the course for context

        Returns:
            True if grading completed successfully, False if no submissions
        """
        submission_data = assignment.get_submission_data()

        if not submission_data:
            log.info(
                f"No submissions to grade for '{assignment_name}' - assignment may be unlocked"
            )
            return False

        truncated_texts, truncation_count, redaction_count = self._truncate_batch_submissions(
            submission_data)

        if truncation_count > 0:
            log.info(
                f"Truncated {truncation_count} submission(s) exceeding {DEFAULT_MAX_WORDS} words or {DEFAULT_MAX_CHARACTERS} characters"
            )
        if redaction_count > 0:
            log.info(
                f"Redacted potential PII in {redaction_count} submission(s) before LLM analysis"
            )

        log.info(
            f"Starting 3-phase grading for '{assignment_name}' with {len(submission_data)} submissions"
        )

        log.info("Phase 1/3: Aggregate analysis")
        self.aggregate_results = self.phase_1_aggregate_analysis(
            truncated_texts, assignment_name, course_name)

        log.info("Phase 2/3: Individual grading")
        self.individual_results = self.phase_2_individual_grading(
            submission_data, self.core_topics)

        self._apply_grades_to_submissions(assignment.submissions,
                                          self.individual_results)

        log.info("Phase 3/3: Report generation")
        self.phase_3_generate_report(self.aggregate_results,
                                     self.individual_results)
        return True

    def _truncate_batch_submissions(self, submission_data: List[Dict]
                                    ) -> tuple[List[str], int, int]:
        """
        Truncate and redact all submissions in a batch.

        Args:
            submission_data: List of submission dictionaries

        Returns:
            Tuple of (prepared_texts, truncation_count, redaction_count)
        """
        prepared_texts = []
        truncation_count = 0
        redaction_count = 0

        for submission_info in submission_data:
            original_text = submission_info.get('text', '')
            truncated, was_truncated = self._truncate_submission_text(original_text)
            prepared_text = truncated
            if was_truncated:
                submission_info['was_truncated'] = True
                truncation_count += 1

            prepared_text, redaction_meta = self._redact_submission_text_for_ai(
                prepared_text,
                student_name=submission_info.get("student_name"),
                student_id=submission_info.get("student_id"))
            if redaction_meta.get("total_replacements", 0) > 0:
                submission_info["was_redacted"] = True
                redaction_count += 1

            submission_info['text'] = prepared_text
            if prepared_text:
                prepared_texts.append(prepared_text)

        return prepared_texts, truncation_count, redaction_count

    # =========================================================================
    # Phase methods
    # =========================================================================

    def phase_1_aggregate_analysis(self, submission_texts: List[str],
                                   assignment_name: str,
                                   course_name: str = "Unknown Course") -> Dict:
        """
        Phase 1: Analyze all submissions to identify core topics and patterns.

        Args:
            submission_texts: List of all submission text content
            assignment_name: Name of the assignment for context
            course_name: Name of the course for context

        Returns:
            Dictionary containing aggregate analysis results
        """
        log.info(
            f"Analyzing {len(submission_texts)} submissions for aggregate insights..."
        )

        if not submission_texts:
            log.warning("No submissions to analyze")
            return {
                "core_topics": [],
                "common_themes": "",
                "key_insights": "",
                "commonly_misunderstood_topics": [],
                "misconception_details": "",
                "teaching_feedback": "",
                "student_questions": []
            }

        prompt = self._build_aggregate_analysis_prompt(submission_texts,
                                                       assignment_name,
                                                       course_name)
        orchestrator = ProviderFallbackOrchestrator(self.prefer_anthropic)

        def _run_anthropic() -> Dict:
            operation = "Phase 1 - Aggregate Analysis (Anthropic)"
            if not self.prefer_anthropic:
                operation = "Phase 1 - Aggregate Analysis (Anthropic fallback)"
            analysis_text, usage = query_anthropic_text(
                prompt,
                tier=self.phase1_tier,
                max_response_tokens=2000,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(usage, operation)

            result = parse_anthropic_json_payload(analysis_text,
                                                  schema_name="aggregate_analysis")
            if result is None:
                result = {
                    "common_themes": analysis_text,
                    "commonly_misunderstood_topics": [],
                    "misconception_details": "",
                    "key_insights": "",
                    "teaching_feedback": "",
                    "core_topics": [],
                    "related_topics": [],
                    "off_topic_indicators": [],
                    "student_questions": []
                }

            self._store_topics_from_result(result)
            provider_label = "Anthropic" if self.prefer_anthropic else "Anthropic fallback"
            log.info(
                f"Aggregate analysis completed ({provider_label}). Identified {len(self.core_topics)} core topics, {len(self.related_topics)} related topics"
            )
            return result

        def _run_openai() -> Dict:
            log.debug(
                f"Attempting aggregate analysis with OpenAI (tier={self.phase1_tier})..."
            )
            result, usage = query_openai_structured(
                prompt,
                schema_name="aggregate_analysis",
                tier=self.phase1_tier,
                max_response_tokens=2000,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(usage,
                                    "Phase 1 - Aggregate Analysis (OpenAI)")
            self._store_topics_from_result(result)
            log.info(
                f"Aggregate analysis completed (OpenAI). Identified {len(self.core_topics)} core topics, {len(self.related_topics)} related topics"
            )
            return result

        def _on_openai_error(error: Exception, is_fallback: bool) -> None:
            log.error(f"OpenAI aggregate analysis failed: {error}")
            if not is_fallback:
                log.info("Falling back to Anthropic...")

        def _on_anthropic_error(error: Exception, is_fallback: bool) -> None:
            if not is_fallback:
                log.error(f"Anthropic aggregate analysis failed: {error}")
                log.info("Falling back to OpenAI...")
            else:
                log.error(f"Anthropic fallback also failed: {error}")

        def _on_both_fail(primary_error: Exception,
                          _secondary_error: Exception) -> Dict:
            if self.prefer_anthropic:
                return {
                    "common_themes": "Error performing analysis",
                    "key_insights": "",
                    "misconception_details": "",
                    "teaching_feedback": "",
                    "core_topics": [],
                    "related_topics": [],
                    "off_topic_indicators": [],
                    "commonly_misunderstood_topics": [],
                    "student_questions": []
                }

            return {
                "common_themes": f"Error performing analysis: {primary_error}",
                "key_insights": "",
                "misconception_details": "",
                "teaching_feedback": "",
                "core_topics": [],
                "related_topics": [],
                "off_topic_indicators": [],
                "commonly_misunderstood_topics": [],
                "student_questions": []
            }

        return orchestrator.run(run_openai=_run_openai,
                                run_anthropic=_run_anthropic,
                                on_openai_error=_on_openai_error,
                                on_anthropic_error=_on_anthropic_error,
                                on_both_fail=_on_both_fail)

    def phase_2_individual_grading(self, submission_data: List[Dict],
                                   core_topics: List[str]) -> List[Dict]:
        """
        Phase 2: Grade each submission individually using core topics.

        Args:
            submission_data: List of submission data dictionaries
            core_topics: Core topics identified from aggregate analysis

        Returns:
            List of individual grading results
        """
        log.info(f"Grading {len(submission_data)} individual submissions...")

        if not core_topics:
            log.warning("No core topics available for individual grading")
            core_topics = ["General class content"]

        individual_results = []
        self.support_needed_students = []

        for i, submission_info in enumerate(submission_data, 1):
            student_id = submission_info.get('student_id')
            student_name = submission_info.get('student_name', 'Unknown')
            submission_text = submission_info.get('text', '')
            word_count = submission_info.get('word_count', 0)
            display_name = student_name
            if self.reveal_identity and student_id is not None and str(
                    student_id) not in str(student_name):
                display_name = f"{student_name} [canvas_user_id={student_id}]"

            log.debug(
                f"   Grading {i}/{len(submission_data)}: {display_name} ({word_count} words)"
            )

            if not submission_text.strip():
                result = {
                    "student_id": student_id,
                    "engagement_score": 0,
                    "relevance_score": 0,
                    "explanation_quality_score": 0,
                    "topics_covered": [],
                    "topics_missing": core_topics,
                    "topics_needing_review": [],
                    "misconception_notes": "",
                    "word_count": 0,
                    "needs_support": True,
                    "support_reason": "No submission content",
                    "feedback": "Please submit your study notes for grading."
                }
            else:
                result = self._grade_individual_submission(
                    submission_text, core_topics, student_id)

            if result.get("grading_failed", False):
                result["student_name"] = student_name
                result["accurate_word_count"] = word_count
                self.support_needed_students.append({
                    "student_id": student_id,
                    "student_name": student_name,
                    "reason":
                    result.get("support_reason", "LLM grading failed")
                })
                individual_results.append(result)
                continue

            result = self.score_calculator.apply_scores(
                result, word_count=word_count, student_name=student_name)

            if self.score_calculator.needs_support(result):
                self.support_needed_students.append({
                    "student_id": student_id,
                    "student_name": student_name,
                    "reason": result.get("support_reason", "Unknown reason")
                })

            individual_results.append(result)

        log.info(
            f"Individual grading completed. {len(self.support_needed_students)} students may need support."
        )

        log.info("Phase 2.5/3: Question consolidation")
        student_questions = self.aggregate_results.get("student_questions", [])
        self.consolidated_questions = self._consolidate_questions(student_questions)

        return individual_results

    def _consolidate_questions(self, all_questions: List[str]) -> List[Dict]:
        """
        Consolidate similar questions from all submissions.

        Args:
            all_questions: List of questions extracted from aggregate analysis

        Returns:
            List of consolidated question dictionaries
        """
        if not all_questions:
            log.info("No questions found to consolidate")
            return []

        log.info(f"Consolidating {len(all_questions)} questions from students...")

        prompt = self._build_question_consolidation_prompt(all_questions)
        orchestrator = ProviderFallbackOrchestrator(self.prefer_anthropic)

        def _run_anthropic() -> List[Dict]:
            operation = "Phase 2.5 - Question Consolidation (Anthropic)"
            if not self.prefer_anthropic:
                operation = "Phase 2.5 - Question Consolidation (Anthropic fallback)"

            result, usage = query_anthropic_structured(
                prompt,
                schema_name="question_consolidation",
                tier=self.phase25_tier,
                max_response_tokens=2000,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(usage, operation)

            consolidated = result.get("consolidated_questions", [])
            log.info(
                f"Consolidated {len(all_questions)} questions into {len(consolidated)} canonical questions"
            )
            return consolidated

        def _run_openai() -> List[Dict]:
            result, usage = query_openai_structured(
                prompt,
                schema_name="question_consolidation",
                tier=self.phase25_tier,
                max_response_tokens=2000,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(
                usage, "Phase 2.5 - Question Consolidation (OpenAI)")
            consolidated = result.get("consolidated_questions", [])
            log.info(
                f"Consolidated {len(all_questions)} questions into {len(consolidated)} canonical questions"
            )
            return consolidated

        def _on_openai_error(error: Exception, is_fallback: bool) -> None:
            log.debug(f"OpenAI question consolidation failed: {error}")
            if not is_fallback:
                log.debug("Trying Anthropic as fallback...")

        def _on_anthropic_error(error: Exception, is_fallback: bool) -> None:
            if not is_fallback:
                log.debug(
                    f"Anthropic question consolidation failed: {error}. Trying OpenAI..."
                )
            else:
                log.debug(f"Anthropic question consolidation failed: {error}")

        def _on_both_fail(_primary_error: Exception,
                          secondary_error: Exception) -> List[Dict]:
            log.error(
                f"Both AI providers failed for question consolidation: {secondary_error}"
            )
            return []

        return orchestrator.run(run_openai=_run_openai,
                                run_anthropic=_run_anthropic,
                                on_openai_error=_on_openai_error,
                                on_anthropic_error=_on_anthropic_error,
                                on_both_fail=_on_both_fail)

    def _grade_individual_submission(self, submission_text: str,
                                     core_topics: List[str],
                                     student_id: str) -> Dict:
        """
        Grade a single submission using AI analysis.

        Args:
            submission_text: The student's submission text
            core_topics: Core topics to check for coverage
            student_id: Student identifier for logging

        Returns:
            Dictionary with grading results
        """
        prompt = self._build_individual_grading_prompt(submission_text, core_topics)
        orchestrator = ProviderFallbackOrchestrator(self.prefer_anthropic)

        def _run_anthropic() -> Dict:
            operation = f"Phase 2 - Individual Grading ({student_id}) - Anthropic"
            if not self.prefer_anthropic:
                operation = f"Phase 2 - Individual Grading ({student_id}) - Anthropic fallback"
            result, usage = query_anthropic_structured(
                prompt,
                schema_name="individual_grading",
                tier=self.phase2_tier,
                max_response_tokens=1000,
                max_retries=3,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(usage, operation)
            result["student_id"] = student_id
            return result

        def _run_openai() -> Dict:
            result, usage = query_openai_structured(
                prompt,
                schema_name="individual_grading",
                tier=self.phase2_tier,
                max_response_tokens=1000,
                max_attempts=3,
                max_rate_limit_retries=self.rate_limit_retries)
            self._track_token_usage(
                usage, f"Phase 2 - Individual Grading ({student_id}) - OpenAI")
            result["student_id"] = student_id
            return result

        def _on_openai_error(error: Exception, is_fallback: bool) -> None:
            if is_fallback and self.prefer_anthropic:
                log.debug(f"OpenAI failed for {student_id}: {error}")
            else:
                log.debug(f"OpenAI failed for {student_id}: {error}")
                if not is_fallback:
                    log.debug("Trying Anthropic...")

        def _on_anthropic_error(error: Exception, is_fallback: bool) -> None:
            if is_fallback and not self.prefer_anthropic:
                log.error(f"Both AI providers failed for {student_id}: {error}")
            elif not is_fallback:
                log.debug(
                    f"Anthropic failed for {student_id}: {error}. Trying OpenAI...")
            else:
                log.debug(f"Anthropic failed for {student_id}: {error}")

        def _on_both_fail(primary_error: Exception,
                          _secondary_error: Exception) -> Dict:
            self._report_individual_grading_failure(
                student_id, f"{type(primary_error).__name__}: {primary_error}")
            return {
                "student_id": student_id,
                "grading_failed": True,
                "needs_support": True,
                "support_reason": "LLM grading failed after retries",
                "feedback":
                "Automatic grading was unavailable for this submission. Instructor review is required."
            }

        return orchestrator.run(run_openai=_run_openai,
                                run_anthropic=_run_anthropic,
                                on_openai_error=_on_openai_error,
                                on_anthropic_error=_on_anthropic_error,
                                on_both_fail=_on_both_fail)

    def phase_3_generate_report(self, aggregate_results: Dict,
                                individual_results: List[Dict]) -> None:
        """
        Phase 3: Generate comprehensive report with insights and recommendations.

        Args:
            aggregate_results: Results from aggregate analysis
            individual_results: Results from individual grading
        """
        log.info("Generating comprehensive class insights report...")

        # Compile report data
        report_data = self._compile_report_data(aggregate_results,
                                                individual_results)

        self._display_aggregate_insights(report_data)
        self._display_grade_summary(report_data)
        self._display_support_recommendations(report_data)

        # Use output hook for custom delivery
        self.output_report_hook(report_data)

        log.info("Report generation completed.")

    def _compile_report_data(self, aggregate_results: Dict,
                             individual_results: List[Dict]) -> Dict:
        """Compile all grading and summary data for report presentation."""
        graded_results = [
            result for result in individual_results
            if not result.get("grading_failed", False) and
            result.get("total_grade") is not None
        ]
        total_grades = [result.get("total_grade", 0) for result in graded_results]
        total_submissions = len(individual_results)
        total_graded = len(graded_results)
        total_ungraded = total_submissions - total_graded

        grade_stats = {
            "total_students":
            total_submissions,
            "graded_students":
            total_graded,
            "ungraded_students":
            total_ungraded,
            "average_grade":
            sum(total_grades) / len(total_grades) if total_grades else 0,
            "grade_distribution":
            self._calculate_grade_distribution(total_grades),
            "students_below_70":
            sum(1 for grade in total_grades if grade < 7),
        }

        topic_coverage = self._analyze_topic_coverage(individual_results)

        support_summary = {
            "students_needing_support": len(self.support_needed_students),
            "support_details": self.support_needed_students
        }
        privacy_summary = {
            "redacted_submission_count": len(self.redaction_events),
            "redaction_events": self.redaction_events,
        }

        return {
            "aggregate_insights": aggregate_results,
            "grade_statistics": grade_stats,
            "topic_coverage": topic_coverage,
            "support_summary": support_summary,
            "privacy_summary": privacy_summary,
            "core_topics": self.core_topics,
            "individual_results": individual_results
        }

    def _calculate_grade_distribution(self, grades: List[float]) -> Dict:
        """Calculate distribution of grades by letter-grade bands."""
        if not grades:
            return {}

        distribution = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
        for grade in grades:
            percentage = (grade / 10) * 100
            if percentage >= 90:
                distribution["A"] += 1
            elif percentage >= 80:
                distribution["B"] += 1
            elif percentage >= 70:
                distribution["C"] += 1
            elif percentage >= 60:
                distribution["D"] += 1
            else:
                distribution["F"] += 1

        return distribution

    def _analyze_topic_coverage(self, individual_results: List[Dict]) -> Dict:
        """Analyze coverage rates for each core topic."""
        if not self.core_topics:
            return {}

        topic_stats = {}
        for topic in self.core_topics:
            covered_count = sum(1 for result in individual_results
                                if topic in result.get("topics_covered", []))
            topic_stats[topic] = {
                "students_covered": covered_count,
                "coverage_percentage": (covered_count / len(individual_results)) * 100
                if individual_results else 0
            }

        return topic_stats

    def _display_aggregate_insights(self, report_data: Dict) -> None:
        """Display aggregate analysis insights."""
        insights = report_data.get("aggregate_insights", {})

        log.debug("\nCLASS-WIDE INSIGHTS")
        log.debug("=" * 60)

        if insights.get("common_themes"):
            log.debug(f"Common themes:\n{insights['common_themes']}")

        if insights.get("key_insights"):
            log.debug(f"\nKey learning insights:\n{insights['key_insights']}")

        misunderstood = insights.get("commonly_misunderstood_topics", [])
        if misunderstood:
            log.debug(f"\nTopics needing review ({len(misunderstood)}):")
            for topic in misunderstood:
                log.debug(f"   - {topic}")
            if insights.get("misconception_details"):
                log.debug(f"   Details: {insights['misconception_details']}")

        if insights.get("teaching_feedback"):
            log.debug(
                f"\nTeaching recommendations:\n{insights['teaching_feedback']}")

        core_topics = report_data.get("core_topics", [])
        if core_topics:
            log.debug(f"\nCore topics identified ({len(core_topics)}):")
            for i, topic in enumerate(core_topics, 1):
                coverage = report_data["topic_coverage"].get(topic, {})
                coverage_pct = coverage.get("coverage_percentage", 0)
                log.debug(f"   {i}. {topic} ({coverage_pct:.1f}% of students)")

    def _display_grade_summary(self, report_data: Dict) -> None:
        """Display grade summary statistics."""
        stats = report_data.get("grade_statistics", {})

        log.debug("\nGRADE SUMMARY")
        log.debug("=" * 60)

        log.debug(f"Total Students: {stats.get('total_students', 0)}")
        log.debug(f"Students Graded: {stats.get('graded_students', 0)}")
        ungraded = stats.get('ungraded_students', 0)
        if ungraded:
            log.debug(f"Ungraded (provider/error): {ungraded}")
        log.debug(
            f"Average Grade: {stats.get('average_grade', 0):.1f}/10 ({stats.get('average_grade', 0)*10:.1f}%)"
        )

        distribution = stats.get("grade_distribution", {})
        if distribution:
            log.debug("\nGrade Distribution:")
            distribution_denominator = max(stats.get('graded_students', 0), 1)
            for letter, count in distribution.items():
                percentage = (count / distribution_denominator) * 100
                log.debug(f"   {letter}: {count} students ({percentage:.1f}%)")

        below_70 = stats.get("students_below_70", 0)
        if below_70 > 0:
            log.debug(f"\n{below_70} students scored below 70%")

    def _display_support_recommendations(self, report_data: Dict) -> None:
        """Display support recommendations for students."""
        support = report_data.get("support_summary", {})
        students_needing_support = support.get("students_needing_support", 0)

        if students_needing_support > 0:
            log.debug("\nSTUDENTS WHO MAY BENEFIT FROM OFFICE HOURS")
            log.debug("=" * 60)

            for student_info in support.get("support_details", []):
                student_id = student_info.get("student_id", "Unknown")
                reason = student_info.get("reason", "No reason provided")
                log.debug(f"- {student_id}: {reason}")
        else:
            log.debug(
                "\nAll students appear to be engaging well with the material.")

    # =========================================================================
    # Grade application
    # =========================================================================

    def _apply_grades_to_submissions(self, submissions: List[Submission],
                                     individual_results: List[Dict]) -> None:
        """
        Apply calculated grades and feedback to Canvas submission objects.

        Args:
            submissions: Original Canvas submission objects
            individual_results: Grading results with scores and feedback
        """
        # Create a mapping from student_id to results for efficient lookup
        results_by_student = {
            result.get('student_id'): result
            for result in individual_results
        }

        for submission in submissions:
            result = results_by_student.get(submission.student.user_id)
            if result and not result.get("grading_failed", False):
                # Use pre-calculated total grade (out of 10) and convert to percentage
                total_grade = result.get('total_grade', 0)
                percentage_score = (total_grade / 10.0) * 100.0

                # Create detailed rubric feedback
                feedback_text = self.rubric_generator.generate(result)
                submission.feedback = Feedback(percentage_score, feedback_text)
            elif result and result.get("grading_failed", False):
                submission.feedback = None
                submission.set_extra({
                    "grading_error": "llm_grading_failed",
                    "grading_error_message": result.get(
                        "support_reason", "LLM grading failed")
                })
            else:
                # Keep ungraded if no result mapping is available.
                submission.feedback = None
                submission.set_extra({
                    "grading_error": "missing_grading_result",
                    "grading_error_message":
                    "Could not map grading result to submission."
                })

    def _generate_rubric_feedback(self, result: Dict) -> str:
        """Backward-compatible wrapper around RubricGenerator."""
        return self.rubric_generator.generate(result)

    # =========================================================================
    # Hook methods for customization - Override these in subclasses
    # =========================================================================

    def _store_topics_from_result(self, result: Dict) -> None:
        """
        Extract and store all topic types from aggregate analysis result.

        Args:
            result: The aggregate analysis result dictionary
        """
        # Store core topics
        self.core_topics = result.get("core_topics", [])
        # Apply topic addition hook
        self.core_topics = self.add_manual_topics_hook(self.core_topics)

        # Store related topics (tangential but valid)
        self.related_topics = result.get("related_topics", [])

        # Store off-topic indicators
        self.off_topic_indicators = result.get("off_topic_indicators", [])

        # Log topic counts
        log.debug(f"Core topics: {self.core_topics}")
        log.debug(f"Related topics: {self.related_topics}")
        if self.off_topic_indicators:
            log.debug(f"Off-topic indicators: {self.off_topic_indicators}")

    def add_manual_topics_hook(self, ai_topics: List[str]) -> List[str]:
        """
        Hook for manually adding or modifying topics after AI analysis.

        Override this method to customize topic selection, for example
        to add course-specific topics that should always be included.

        Args:
            ai_topics: Topics identified by AI analysis

        Returns:
            Final list of topics to use for grading
        """
        return ai_topics

    def output_report_hook(self, report_data: Dict) -> None:
        """
        Hook for customizing report output format.

        Override this method to change how reports are delivered (e.g.,
        to a different notification system, file format, or database).

        Args:
            report_data: Compiled report data
        """
        # Save questions to records directory if configured
        if self.records_dir and self.consolidated_questions:
            self._save_questions_to_records()

        # Send to Slack if configured (includes question file attachment)
        self._send_slack_notification(report_data)

        # Also print to console
        self._print_report_to_console(report_data)

    # =========================================================================
    # File and Slack output
    # =========================================================================

    def _save_questions_to_records(self) -> None:
        """
        Save consolidated questions to records directory as markdown file.

        Filename format: [course_name].[assignment_name].learning-log.md
        """
        if not self.records_dir or not self.consolidated_questions:
            return

        try:
            # Ensure records directory exists
            if not os.path.exists(self.records_dir):
                os.makedirs(self.records_dir)
                log.info(f"Created records directory: {self.records_dir}")

            # Sanitize course and assignment names for filename
            course_safe = self.course_name.replace(' ', '_').replace('/', '-')
            assignment_safe = self.assignment_name.replace(' ', '_').replace('/', '-')
            filename = f"{course_safe}.{assignment_safe}.learning-log.md"
            filepath = os.path.join(self.records_dir, filename)

            # Generate markdown content
            markdown_content = self._generate_questions_markdown()

            # Write to file
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(markdown_content)

            log.info(f"Saved questions to records: {filepath}")

        except Exception as e:
            log.error(f"Failed to save questions to records directory: {e}")

    def _send_slack_notification(self, report_data: Dict) -> None:
        """
        Send summary notification to Slack if configured.

        Includes markdown file attachment if there are student questions.

        Args:
            report_data: Report data to send
        """
        slack_token = os.getenv('SLACK_BOT_TOKEN')
        slack_channel = self.slack_channel

        if not slack_token or not slack_channel:
            log.debug(
                "Slack not configured (missing SLACK_BOT_TOKEN or course slack_channel)"
            )
            return

        try:
            # Create concise summary
            message = self._create_slack_summary(report_data)

            # Send message to Slack
            response = requests.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {slack_token}"},
                json={
                    "channel": slack_channel,
                    "text": message,
                    "mrkdwn": True,
                    "unfurl_links": False,
                    "unfurl_media": False
                },
                timeout=10)

            if not response.json().get('ok'):
                log.warning(
                    f"Slack notification failed: {response.json().get('error')}")
                return

            log.info("Slack notification sent successfully")

            # Upload questions markdown file if there are questions
            if self.consolidated_questions:
                self._upload_questions_to_slack(slack_token, slack_channel)

        except Exception as e:
            log.warning(f"Failed to send Slack notification: {e}")

    def _report_individual_grading_failure(self, student_id: int | str,
                                           reason: str) -> None:
        """
        Send a targeted Slack alert when AI grading fails for a submission.

        Args:
            student_id: Canvas user ID for the affected submission
            reason: Failure reason for operator triage
        """
        slack_token = os.getenv('SLACK_BOT_TOKEN')
        slack_channel = self.slack_channel
        if not slack_token or not slack_channel:
            return

        safe_reason = (reason or "").strip()
        if len(safe_reason) > 500:
            safe_reason = safe_reason[:500] + "... [truncated]"

        message = (
            f":warning: *LLM grading failed for one submission*\n"
            f"*Course:* {self.course_name}\n"
            f"*Assignment:* {self.assignment_name}\n"
            f"*Student ID:* {student_id}\n"
            f"*Reason:* {safe_reason}\n"
            "Submission left ungraded for manual follow-up.")

        try:
            response = requests.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {slack_token}"},
                json={
                    "channel": slack_channel,
                    "text": message,
                    "mrkdwn": True,
                    "unfurl_links": False,
                    "unfurl_media": False
                },
                timeout=10)
            if not response.json().get('ok'):
                log.warning(
                    f"Failed to send per-submission LLM failure alert: {response.json().get('error')}"
                )
        except Exception as e:
            log.warning(f"Failed to send per-submission LLM failure alert: {e}")

    def _upload_questions_to_slack(self, slack_token: str,
                                   slack_channel: str) -> None:
        """
        Upload student questions markdown file to Slack.

        Args:
            slack_token: Slack bot token
            slack_channel: Slack channel ID or name
        """
        try:
            # Generate markdown content
            markdown_content = self._generate_questions_markdown()

            # Generate filename
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            course_safe = self.course_name.replace(' ', '_').replace('/', '-')
            assignment_safe = self.assignment_name.replace(' ', '_').replace('/', '-')
            filename = f"questions_{course_safe}_{assignment_safe}_{timestamp}.md"

            # Upload file to Slack
            response = requests.post(
                "https://slack.com/api/files.upload",
                headers={"Authorization": f"Bearer {slack_token}"},
                data={
                    "channels": slack_channel,
                    "filename": filename,
                    "filetype": "markdown",
                    "initial_comment":
                    f"Student questions from {self.assignment_name} ({len(self.consolidated_questions)} topics)"
                },
                files={"file": (filename, markdown_content, "text/markdown")},
                timeout=30)

            if response.json().get('ok'):
                log.info(f"Questions file uploaded to Slack: {filename}")
            else:
                log.warning(
                    f"Failed to upload questions file: {response.json().get('error')}")

        except Exception as e:
            log.warning(f"Failed to upload questions to Slack: {e}")

    def _generate_questions_markdown(self) -> str:
        """
        Generate markdown content for student questions.

        Returns:
            Markdown-formatted string with all student questions
        """
        if not self.consolidated_questions:
            return ""

        lines = [
            f"# Student Questions: {self.course_name} - {self.assignment_name}",
            f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*",
            "",
            f"Total unique question topics: {len(self.consolidated_questions)}",
            "",
            "---",
            ""
        ]

        # Add each consolidated question group
        for i, q_group in enumerate(self.consolidated_questions, 1):
            canonical = q_group.get("canonical_question", "")
            topic = q_group.get("topic", "General")
            original_questions = q_group.get("original_questions", [])
            student_count = len(original_questions)

            lines.append(f"## {i}. {topic}")
            lines.append("")
            lines.append(f"**Question:** {canonical}")
            lines.append("")
            lines.append(
                f"*Asked by {student_count} student{'s' if student_count > 1 else ''}*"
            )
            lines.append("")

            # Add space for instructor's answer
            lines.append("**Answer:**")
            lines.append("")
            lines.append("<!-- Your answer here -->")
            lines.append("")

            # Show original questions in a collapsible section if there are multiple
            if len(original_questions) > 1:
                lines.append("<details>")
                lines.append(
                    "<summary>Show original questions from students</summary>")
                lines.append("")
                for orig_q in original_questions:
                    lines.append(f"- {orig_q}")
                lines.append("")
                lines.append("</details>")
                lines.append("")

            lines.append("---")
            lines.append("")

        return '\n'.join(lines)

    def _create_slack_summary(self, report_data: Dict) -> str:
        """
        Create concise summary for Slack notification.

        Args:
            report_data: Report data to summarize

        Returns:
            Formatted message string
        """
        stats = report_data.get("grade_statistics", {})
        support = report_data.get("support_summary", {})
        insights = report_data.get("aggregate_insights", {})
        topics = report_data.get("core_topics", [])

        # Get course and assignment info from the grader instance
        course_name = getattr(self, 'course_name', 'Unknown Course')
        assignment_name = getattr(self, 'assignment_name', 'Unknown Assignment')

        # Add cost information if available, with phase breakdown
        cost_text = ""
        phase_breakdown = ""
        if self.total_cost > 0:
            # Calculate cost and model by phase
            phase1_entries = [u for u in self.usage_details if 'Phase 1' in u.get('operation', '')]
            phase2_entries = [u for u in self.usage_details if 'Phase 2 -' in u.get('operation', '')]
            phase25_entries = [u for u in self.usage_details if 'Phase 2.5' in u.get('operation', '')]

            phase1_cost = sum(u.get('cost', 0) for u in phase1_entries)
            phase2_cost = sum(u.get('cost', 0) for u in phase2_entries)
            phase25_cost = sum(u.get('cost', 0) for u in phase25_entries)

            # Get predominant model for each phase
            def get_model(entries):
                if not entries:
                    return "n/a"
                models = [u.get('model', u.get('provider', 'unknown')) for u in entries]
                # Return most common model, with light shortening
                model = max(set(models), key=models.count) if models else "unknown"
                # Shorten model names for display
                if 'claude' in model.lower():
                    for variant in ['haiku', 'sonnet', 'opus']:
                        if variant in model.lower():
                            parts = model.lower().split('-')
                            version_parts = [p for p in parts if p[0].isdigit()] if parts else []
                            if version_parts:
                                return f"{variant}-{version_parts[0]}"
                            return variant
                    return model[:20]
                elif 'gpt' in model.lower():
                    return model.replace('gpt-', '')
                return model[:15]

            phase1_model = get_model(phase1_entries)
            phase2_model = get_model(phase2_entries)

            cost_text = f" (${self.total_cost:.4f} - {self.total_tokens} tokens)"
            phase_breakdown = f"  _Phase 1: ${phase1_cost:.2f} ({phase1_model}) | Phase 2: ${phase2_cost:.2f} ({phase2_model}) | Q&A: ${phase25_cost:.2f}_"

        # Build summary message with header
        lines = [
            f"*{course_name} - {assignment_name}*",
            f"Grading Complete{cost_text}",
        ]
        if phase_breakdown:
            lines.append(phase_breakdown)
        lines.extend([
            "",
            "*Summary:*",
            f"- {stats.get('graded_students', 0)} students graded",
            f"- Average: {stats.get('average_grade', 0):.1f}/10 ({stats.get('average_grade', 0)*10:.1f}%)",
        ])
        ungraded_students = stats.get("ungraded_students", 0)
        if ungraded_students > 0:
            lines.append(f"- Ungraded due to AI/provider failures: {ungraded_students}")

        # Add grade distribution summary
        distribution = stats.get("grade_distribution", {})
        if distribution:
            a_b_count = distribution.get("A", 0) + distribution.get("B", 0)
            c_d_f_count = distribution.get("C", 0) + distribution.get("D", 0) + distribution.get("F", 0)
            lines.append(f"- Grades: {a_b_count} A/B, {c_d_f_count} C/D/F")

        # Add support needs - show ALL students with better formatting
        support_count = support.get("students_needing_support", 0)
        if support_count > 0:
            lines.append(f"\n*Office Hours Recommended ({support_count} students):*")
            for i, student_info in enumerate(support.get("support_details", []), 1):
                student_name = student_info.get("student_name", "Unknown Student")
                reason = student_info.get("reason", "")
                if reason.strip():
                    lines.append(f"{i}. `{student_name}` - {reason}")
                else:
                    lines.append(f"{i}. `{student_name}` - *(No specific reason provided)*")
        else:
            lines.append("\n*Status:* All students engaging well")

        # Add topic insights as a list - show ALL topics
        if topics:
            lines.append(f"\n*Core Topics:*")
            for topic in topics:
                lines.append(f"- {topic}")

        # Add related topics if any
        related = insights.get("related_topics", [])
        if related:
            lines.append(f"\n*Related Topics (also valid):*")
            for topic in related:
                lines.append(f"- {topic}")

        # Add commonly misunderstood topics
        misunderstood = insights.get("commonly_misunderstood_topics", [])
        if misunderstood:
            lines.append(f"\n*Topics Needing Review (common confusion):*")
            for topic in misunderstood:
                lines.append(f"- {topic}")
            misconception_details = insights.get("misconception_details", "").strip()
            if misconception_details:
                lines.append(f"_{misconception_details}_")

        # Add teaching insights as a list
        teaching_feedback = insights.get("teaching_feedback", "").strip()
        if teaching_feedback:
            lines.append(f"\n*Teaching Suggestions:*")
            sentences = [s.strip() for s in teaching_feedback.split('.') if s.strip()]
            for sentence in sentences:
                lines.append(f"- {sentence}")

        # Add consolidated questions section
        if self.consolidated_questions:
            lines.append(
                f"\n*Key Questions from Students ({len(self.consolidated_questions)} topics):*"
            )
            for q_group in self.consolidated_questions:
                canonical = q_group.get("canonical_question", "")
                topic = q_group.get("topic", "")
                original_count = len(q_group.get("original_questions", []))

                if topic:
                    lines.append(
                        f"- *{topic}*: {canonical} ({original_count} student{'s' if original_count > 1 else ''})"
                    )
                else:
                    lines.append(
                        f"- {canonical} ({original_count} student{'s' if original_count > 1 else ''})"
                    )

        return "\n".join(lines)

    # =========================================================================
    # Token usage tracking
    # =========================================================================

    def _track_token_usage(self, usage_info: Dict, operation: str) -> None:
        """
        Track token usage and calculate costs.

        Args:
            usage_info: Usage information from AI provider
            operation: Description of the operation
        """
        provider = usage_info.get("provider", "unknown")
        model = usage_info.get("model", "unknown")
        total_tokens = usage_info.get("total_tokens", 0)
        prompt_tokens = usage_info.get("prompt_tokens", 0)
        completion_tokens = usage_info.get("completion_tokens", 0)

        # Calculate cost based on provider
        cost = self._calculate_cost(usage_info)

        # Track totals
        self.total_tokens += total_tokens
        self.total_cost += cost

        # Store detailed usage
        self.usage_details.append({
            "operation": operation,
            "provider": provider,
            "model": model,
            "total_tokens": total_tokens,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "cost": cost
        })

        log.debug(
            f"{operation}: {total_tokens} tokens (${cost:.4f}) via {provider}/{model}")

    def _calculate_cost(self, usage_info: Dict) -> float:
        """
        Calculate cost based on provider and model pricing.

        Args:
            usage_info: Usage information with provider, model, and token counts

        Returns:
            Estimated cost in USD
        """
        from Autograder.ai_helper import get_model_pricing

        provider = usage_info.get("provider", "unknown")
        model = usage_info.get("model", "unknown")
        prompt_tokens = usage_info.get("prompt_tokens", 0)
        completion_tokens = usage_info.get("completion_tokens", 0)

        # Get pricing from centralized MODEL_CONFIG
        input_price, output_price = get_model_pricing(provider, model)

        # Calculate cost (prices are per million tokens)
        prompt_cost = (prompt_tokens / 1_000_000) * input_price
        completion_cost = (completion_tokens / 1_000_000) * output_price
        return prompt_cost + completion_cost

    def _print_report_to_console(self, report_data: Dict) -> None:
        """
        Default implementation for printing report to console.

        Args:
            report_data: Report data to display
        """
        log.info("Report generation completed (use --debug for full summary).")

    # =========================================================================
    # Abstract method implementations (required by base Grader class)
    # =========================================================================

    def execute_grading(self, *args, **kwargs):
        """Not used in text submission grading - phases handle execution."""
        return None

    def score_grading(self, execution_results, *args, **kwargs) -> Feedback:
        """Not used in text submission grading - phases handle scoring."""
        return Feedback(0.0, "TextSubmissionGrader uses phase-based grading")

    def assignment_needs_preparation(self) -> bool:
        """Text assignments need preparation to fetch submissions."""
        return True


# ---------------------------------------------------------------------------
# Backward-compatibility wrappers
# ---------------------------------------------------------------------------


class BatchProcessor:
    """Backward-compatible wrapper around batch orchestration."""

    def __init__(self, grader):
        self.grader = grader

    def run(self, assignment, *, assignment_name: str, course_name: str) -> bool:
        if hasattr(self.grader, "_run_batch_grading"):
            return self.grader._run_batch_grading(assignment,
                                                  assignment_name=assignment_name,
                                                  course_name=course_name)

        submission_data = assignment.get_submission_data()

        if not submission_data:
            log.info(
                f"No submissions to grade for '{assignment_name}' - assignment may be unlocked"
            )
            return False

        truncated_texts, truncation_count, redaction_count = self._truncate_batch(
            submission_data)

        if truncation_count > 0:
            log.info(
                f"Truncated {truncation_count} submission(s) exceeding {DEFAULT_MAX_WORDS} words or {DEFAULT_MAX_CHARACTERS} characters"
            )
        if redaction_count > 0:
            log.info(
                f"Redacted potential PII in {redaction_count} submission(s) before LLM analysis"
            )

        log.info(
            f"Starting 3-phase grading for '{assignment_name}' with {len(submission_data)} submissions"
        )

        log.info("Phase 1/3: Aggregate analysis")
        self.grader.aggregate_results = self.grader.phase_1_aggregate_analysis(
            truncated_texts, assignment_name, course_name)

        log.info("Phase 2/3: Individual grading")
        self.grader.individual_results = self.grader.phase_2_individual_grading(
            submission_data, self.grader.core_topics)

        self.grader._apply_grades_to_submissions(assignment.submissions,
                                                 self.grader.individual_results)

        log.info("Phase 3/3: Report generation")
        self.grader.phase_3_generate_report(self.grader.aggregate_results,
                                            self.grader.individual_results)
        return True

    def _truncate_batch(self, submission_data: List[Dict]
                        ) -> tuple[List[str], int, int]:
        truncated_texts = []
        truncation_count = 0
        redaction_count = 0

        for submission_info in submission_data:
            original_text = submission_info.get('text', '')
            truncated, was_truncated = self.grader._truncate_submission_text(
                original_text)
            prepared_text = truncated
            if was_truncated:
                submission_info['was_truncated'] = True
                truncation_count += 1

            if hasattr(self.grader, "_redact_submission_text_for_ai"):
                prepared_text, redaction_meta = self.grader._redact_submission_text_for_ai(
                    prepared_text,
                    student_name=submission_info.get("student_name"),
                    student_id=submission_info.get("student_id"))
                if redaction_meta.get("total_replacements", 0) > 0:
                    submission_info["was_redacted"] = True
                    redaction_count += 1
            submission_info['text'] = prepared_text
            if prepared_text:
                truncated_texts.append(prepared_text)

        return truncated_texts, truncation_count, redaction_count


class AggregateAnalyzer:
    """Backward-compatible wrapper around aggregate analysis."""

    def __init__(self, grader):
        self.grader = grader

    def analyze(self, submission_texts: List[str], assignment_name: str,
                course_name: str = "Unknown Course") -> Dict:
        return self.grader.phase_1_aggregate_analysis(submission_texts,
                                                      assignment_name,
                                                      course_name)


class IndividualGradingProcessor:
    """Backward-compatible wrapper around individual grading."""

    def __init__(self, grader):
        self.grader = grader

    def grade_batch(self, submission_data: List[Dict],
                    core_topics: List[str]) -> List[Dict]:
        if hasattr(self.grader, "phase_2_individual_grading"):
            return self.grader.phase_2_individual_grading(submission_data,
                                                          core_topics)

        log.info(f"Grading {len(submission_data)} individual submissions...")

        if not core_topics:
            log.warning("No core topics available for individual grading")
            core_topics = ["General class content"]

        individual_results = []
        self.grader.support_needed_students = []

        for i, submission_info in enumerate(submission_data, 1):
            student_id = submission_info.get('student_id')
            student_name = submission_info.get('student_name', 'Unknown')
            submission_text = submission_info.get('text', '')
            word_count = submission_info.get('word_count', 0)
            display_name = student_name
            if self.grader.reveal_identity and student_id is not None and str(
                    student_id) not in str(student_name):
                display_name = f"{student_name} [canvas_user_id={student_id}]"

            log.debug(
                f"   Grading {i}/{len(submission_data)}: {display_name} ({word_count} words)"
            )

            if not submission_text.strip():
                result = {
                    "student_id": student_id,
                    "engagement_score": 0,
                    "relevance_score": 0,
                    "explanation_quality_score": 0,
                    "topics_covered": [],
                    "topics_missing": core_topics,
                    "topics_needing_review": [],
                    "misconception_notes": "",
                    "word_count": 0,
                    "needs_support": True,
                    "support_reason": "No submission content",
                    "feedback": "Please submit your study notes for grading."
                }
            else:
                result = self.grader._grade_individual_submission(
                    submission_text, core_topics, student_id)

            if result.get("grading_failed", False):
                result["student_name"] = student_name
                result["accurate_word_count"] = word_count
                self.grader.support_needed_students.append({
                    "student_id": student_id,
                    "student_name": student_name,
                    "reason":
                    result.get("support_reason", "LLM grading failed")
                })
                individual_results.append(result)
                continue

            result = self.grader.score_calculator.apply_scores(
                result, word_count=word_count, student_name=student_name)

            if self.grader.score_calculator.needs_support(result):
                self.grader.support_needed_students.append({
                    "student_id": student_id,
                    "student_name": student_name,
                    "reason": result.get("support_reason", "Unknown reason")
                })

            individual_results.append(result)

        log.info(
            f"Individual grading completed. {len(self.grader.support_needed_students)} students may need support."
        )

        log.info("Phase 2.5/3: Question consolidation")
        student_questions = self.grader.aggregate_results.get("student_questions", [])
        self.grader.consolidated_questions = self.grader._consolidate_questions(
            student_questions)

        return individual_results


class QuestionConsolidator:
    """Backward-compatible wrapper around question consolidation."""

    def __init__(self, grader):
        self.grader = grader

    def consolidate(self, all_questions: List[str]) -> List[Dict]:
        return self.grader._consolidate_questions(all_questions)


class IndividualSubmissionAnalyzer:
    """Backward-compatible wrapper around single-submission grading."""

    def __init__(self, grader):
        self.grader = grader

    def analyze(self, submission_text: str, core_topics: List[str],
                student_id: str) -> Dict:
        return self.grader._grade_individual_submission(submission_text,
                                                        core_topics, student_id)


class ReportCompiler:
    """Backward-compatible wrapper around report compilation helpers."""

    def __init__(self, grader):
        self.grader = grader

    def compile(self, aggregate_results: Dict,
                individual_results: List[Dict]) -> Dict:
        return self.grader._compile_report_data(aggregate_results,
                                                individual_results)

    def _calculate_grade_distribution(self, grades: List[float]) -> Dict:
        return self.grader._calculate_grade_distribution(grades)

    def _analyze_topic_coverage(self, individual_results: List[Dict]) -> Dict:
        return self.grader._analyze_topic_coverage(individual_results)


class ReportPresenter:
    """Backward-compatible wrapper around report display helpers."""

    def __init__(self, grader):
        self.grader = grader

    def present(self, report_data: Dict) -> None:
        self.grader._display_aggregate_insights(report_data)
        self.grader._display_grade_summary(report_data)
        self.grader._display_support_recommendations(report_data)

    def display_aggregate_insights(self, report_data: Dict) -> None:
        self.grader._display_aggregate_insights(report_data)

    def display_grade_summary(self, report_data: Dict) -> None:
        self.grader._display_grade_summary(report_data)

    def display_support_recommendations(self, report_data: Dict) -> None:
        self.grader._display_support_recommendations(report_data)
