"""
Docker-based grader implementations.

Contains configurable Docker graders that can run arbitrary grading scripts
in containerized environments.
"""
import contextlib
import os
import pathlib
import re
import shlex
import shutil
import tempfile
import subprocess
import uuid

import yaml
from typing import Any, Dict, Tuple, Optional, List

from Autograder.registry import GraderRegistry
from Autograder import config_models
from lms_interface.classes import Feedback
from Autograder.docker_utils import DockerClient, DockerContainer
import Autograder.exceptions
from Autograder.grader import FileBasedGrader

import logging

log = logging.getLogger(__name__)


def _parse_bool(value, default=False):
  if value is None:
    return default
  if isinstance(value, bool):
    return value
  if isinstance(value, str):
    return value.strip().lower() in {"1", "true", "yes", "on"}
  return bool(value)


class DockerGrader(FileBasedGrader):
  """
  Base class for Docker-based graders.

  Provides common Docker functionality like container management,
  file copying, and command execution using docker_utils.
  """

  def __init__(self, image=None, *args, **kwargs):
    super().__init__(*args, **kwargs)

    env_upload_artifacts = os.getenv("AUTOGRADER_UPLOAD_ERROR_ARTIFACTS")
    upload_error_artifacts = kwargs.get("upload_error_artifacts", False)
    if env_upload_artifacts is not None:
      upload_error_artifacts = _parse_bool(env_upload_artifacts, False)
    self.upload_error_artifacts = _parse_bool(upload_error_artifacts, False)

    # Set up docker client
    try:
      self.docker_client = DockerClient()
    except Autograder.exceptions.DockerError as e:
      log.error(f"Failed to initialize Docker client: {e}")
      raise Autograder.exceptions.ConfigurationError(
        f"Docker client initialization failed: {e}") from e

    # Default to using ubuntu image
    self.base_name_name = image if image is not None else "ubuntu"
    self.image = None  # Only set this when we actually run grading to reduce how often we build
    self.container: Optional[DockerContainer] = None

  # Helper functions below here
  def build_docker_image(self, dockerfile_str: str):
    """
    Build a Docker image from dockerfile content.

    Args:
        dockerfile_str: Dockerfile as a single string

    Returns:
        Built Docker image
    """
    tag = f"grading:{self.__class__.__name__.lower()}"
    return self.docker_client.build_image(dockerfile_str, tag)

  def start_container(self, image=None) -> None:
    """Start a Docker container."""
    image_to_use = image if image is not None else self.image
    self.container = DockerContainer(self.docker_client,
                                     image_to_use,
                                     name_prefix="grader")
    self.container.start()

  def stop_container(self) -> None:
    """Stop the Docker container."""
    if self.container:
      self.container.stop()
      self.container = None

  def add_files_to_docker(self, files_to_copy: List[Tuple] = None) -> None:
    """
    Copy files to the Docker container.

    Args:
        files_to_copy: List of (file_object, target_directory) tuples
    """
    if files_to_copy and self.container:
      self.container.copy_files(files_to_copy)

  def execute_command_in_container(self,
                                   command="",
                                   container=None,
                                   workdir=None) -> Tuple[int, bytes, bytes]:
    """
    Execute a command in the Docker container.

    Args:
        command: Command to execute
        container: Container to use (defaults to self.container)
        workdir: Working directory for command

    Returns:
        Tuple of (return_code, stdout, stderr)
    """
    target_container = container if container is not None else self.container
    if not target_container:
      raise Autograder.exceptions.ContainerError(
        "No container available for command execution. "
        "Call start_container() before execute_command_in_container().")

    return target_container.execute_command(command, workdir)

  def read_file_from_container(self, path_to_file: str) -> Optional[str]:
    """
    Read a file from the Docker container.

    Args:
        path_to_file: Path to file in container

    Returns:
        File contents as string, or None if not found
    """
    if not self.container:
      return None

    return self.container.read_file(path_to_file)

  def _get_slack_config(self) -> dict:
    """
    Get Slack configuration with support for override hierarchy.

    Configuration is checked in order (most specific to least specific):
    1. Assignment-level config (self.slack_webhook, self.slack_channel, self.report_errors)
    2. Course-level config via environment variables (SLACK_WEBHOOK_{COURSE}, etc.)
    3. Global config via environment variables (SLACK_BOT_TOKEN, SLACK_WEBHOOK, etc.)

    Returns:
        dict with keys: webhook, token, channel, enabled
    """
    import os

    # Assignment-level overrides
    webhook = getattr(self, 'slack_webhook', None)
    token = getattr(self, 'slack_token', None)
    channel = getattr(self, 'slack_channel', None)
    enabled = getattr(self, 'report_errors', True)  # Default to enabled

    # Course-level environment variables (if course_name is set)
    course_name = getattr(self, 'course_name',
                          '').upper().replace(' ', '_').replace('-', '_')
    if course_name:
      webhook = webhook or os.getenv(f'SLACK_WEBHOOK_{course_name}')
      token = token or os.getenv(f'SLACK_BOT_TOKEN_{course_name}')
      channel = channel or os.getenv(f'SLACK_CHANNEL_{course_name}')

      # Check for course-specific opt-out
      course_enabled = os.getenv(f'REPORT_ERRORS_{course_name}')
      if course_enabled is not None:
        enabled = course_enabled.lower() not in ('false', '0', 'no')

    # Global environment variables
    webhook = webhook or os.getenv('SLACK_WEBHOOK')
    token = token or os.getenv('SLACK_BOT_TOKEN')
    channel = channel or os.getenv('SLACK_CHANNEL')

    # Global opt-out
    global_enabled = os.getenv('REPORT_ERRORS')
    if global_enabled is not None:
      enabled = enabled and global_enabled.lower() not in ('false', '0', 'no')

    return {
      'webhook': webhook,
      'token': token,
      'channel': channel,
      'enabled': enabled
    }

  def _zip_student_files(self, submission) -> Optional[bytes]:
    """
    Create a zip archive of student submission files.

    Args:
        submission: Submission object with files attribute

    Returns:
        Zip file as bytes, or None if no files
    """
    import io
    import zipfile

    if not submission or not hasattr(submission,
                                     'files') or not submission.files:
      return None

    try:
      zip_buffer = io.BytesIO()
      with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for file_obj in submission.files:
          # Get file name
          filename = getattr(file_obj, 'name', 'unnamed_file')

          # Read file content
          file_obj.seek(0)
          content = file_obj.read()

          # Add to zip
          zip_file.writestr(filename, content)

          # Reset file pointer
          file_obj.seek(0)

      zip_buffer.seek(0)
      return zip_buffer.getvalue()
    except Exception as e:
      log.warning(f"Failed to zip student files: {e}")
      return None

  def _send_error_to_slack(self,
                           error_msg: str,
                           execution_results: Tuple,
                           submission=None) -> None:
    """
    Send error report to Slack with file attachments.

    Args:
        error_msg: Description of the error
        execution_results: Tuple of (rc, stdout, stderr) from execution
        submission: The submission object being graded (if available)
    """
    import io
    from slack_sdk import WebClient
    from slack_sdk.errors import SlackApiError

    slack_config = self._get_slack_config()

    if not slack_config['enabled']:
      log.debug("Error reporting is disabled")
      return

    # Need either webhook or (token + channel)
    webhook = slack_config['webhook']
    token = slack_config['token']
    channel = slack_config['channel']

    if not webhook and not (token and channel):
      log.debug(
        f"Slack not configured for error reporting (webhook={webhook}, token={bool(token)}, channel={channel})"
      )
      return

    rc, stdout, stderr = execution_results

    # Get student info
    student_name = "Unknown"
    if submission and hasattr(submission, 'student') and submission.student:
      student_name = submission.student.name

    # Build initial message
    assignment_name = getattr(self, 'assignment_name', 'Unknown Assignment')
    course_name = getattr(self, 'course_name', 'Unknown Course')

    def _decode_snippet(payload, max_chars=700):
      if payload is None:
        return ""
      if isinstance(payload, bytes):
        text = payload.decode("utf-8", errors="replace")
      else:
        text = str(payload)
      text = text.strip()
      if len(text) > max_chars:
        return text[:max_chars] + "... [truncated]"
      return text

    stdout_snippet = _decode_snippet(stdout)
    stderr_snippet = _decode_snippet(stderr)

    message = (f":warning: *Grading Error Detected*\n"
               f"*Course:* {course_name}\n"
               f"*Assignment:* {assignment_name}\n"
               f"*Student:* {student_name}\n"
               f"*Error:* {error_msg}\n"
               f"*Return Code:* {rc}")
    if not self.upload_error_artifacts:
      message += ("\n*Artifact mode:* disabled (`upload_error_artifacts=false`)\n"
                  "Only summary details are included to reduce PII exposure.")
    else:
      message += ("\n:rotating_light: *Artifact mode enabled* - "
                  "attachments may include PII/student code.")
    if stdout_snippet:
      message += f"\n\n*stdout (truncated):*\n```{stdout_snippet}```"
    if stderr_snippet:
      message += f"\n\n*stderr (truncated):*\n```{stderr_snippet}```"

    try:
      # Handle webhook case (simple message only, no files)
      if webhook:
        import requests
        response = requests.post(webhook, json={"text": message}, timeout=10)
        if response.status_code == 200:
          log.info("Slack error notification sent via webhook (no files)")
        else:
          log.warning(f"Slack webhook failed: {response.status_code}")
        return

      # Use Slack SDK for bot token
      client = WebClient(token=token)
      if not self.upload_error_artifacts:
        client.chat_postMessage(channel=channel,
                                text=message,
                                mrkdwn=True,
                                unfurl_links=False,
                                unfurl_media=False)
        log.info("Slack error report sent successfully (summary mode)")
        return

      # Prepare files to upload
      files_to_upload = []

      # 1. Error details as text file
      error_details = (f"Error: {error_msg}\n"
                       f"Return Code: {rc}\n"
                       f"Student: {student_name}\n"
                       f"Assignment: {assignment_name}\n"
                       f"Course: {course_name}\n")
      files_to_upload.append(('error_details.txt', error_details.encode()))

      # 2. stdout
      if stdout:
        files_to_upload.append(
          ('stdout.txt',
           stdout if isinstance(stdout, bytes) else stdout.encode()))

      # 3. stderr
      if stderr:
        files_to_upload.append(
          ('stderr.txt',
           stderr if isinstance(stderr, bytes) else stderr.encode()))

      # 4. feedback.yaml (if exists)
      feedback_content = self.read_file_from_container("/tmp/feedback.yaml")
      if feedback_content:
        files_to_upload.append(('feedback.yaml', feedback_content.encode()))

      # 5. Student code as zip
      student_zip = self._zip_student_files(submission)
      if student_zip:
        files_to_upload.append(('student_code.zip', student_zip))

      # Upload all files together with the message (not threaded)
      # Note: Slack's files_upload_v2 doesn't support multiple files in one call,
      # so we upload them separately but they'll all appear as attachments
      for filename, content in files_to_upload:
        try:
          client.files_upload_v2(
            channel=channel,
            file=io.BytesIO(content),
            filename=filename,
            title=filename,
            initial_comment=message if filename == files_to_upload[0][0] else
            None  # Only show message with first file
          )
        except SlackApiError as e:
          log.warning(f"Failed to upload {filename}: {e.response['error']}")
        except Exception as e:
          log.warning(f"Failed to upload {filename}: {e}")

      log.info("Slack error report sent successfully with attachments")

    except SlackApiError as e:
      log.warning(f"Slack API error: {e.response['error']}")
    except Exception as e:
      log.warning(f"Failed to send Slack error report: {e}")

  def _report_grading_error(self,
                            error_msg: str,
                            execution_results: Tuple,
                            submission=None) -> None:
    """
    Hook for reporting grading errors (e.g., via Slack, email, etc.).

    Default implementation logs the error and sends to Slack if configured.
    Subclasses can override to add custom behavior or provide additional context.

    Args:
        error_msg: Description of the error
        execution_results: Tuple of (rc, stdout, stderr) from execution
        submission: The submission object being graded (if available)
    """
    log.error(f"Grading error hook called: {error_msg}")
    if submission:
      log.error(
        f"  Submission: {submission.student.name if hasattr(submission, 'student') else 'Unknown'}"
      )
    rc, stdout, stderr = execution_results
    log.error(f"  Return code: {rc}")
    log.error(f"  Stdout (first 500 chars): {stdout[:500] if stdout else ''}")
    log.error(f"  Stderr (first 500 chars): {stderr[:500] if stderr else ''}")

    # Send to Slack if configured
    self._send_error_to_slack(error_msg, execution_results, submission)

  def _get_image(self, *args, **kwargs):
    return "ubuntu"

  def __enter__(self):
    """Context manager entry - ensure image is available."""
    if self.image is None:
      log.debug("Building docker image")
      self.image = self._get_image()
    log.debug(f"Prepared docker image {self.image} context")
    return self

  def __exit__(self, exc_type, exc_val, exc_tb):
    """Context manager exit - clean up docker resources."""
    log.debug("Exiting docker image context")
    self.cleanup()
    if exc_type is not None:
      log.error(f"An exception occurred: {exc_val}")
    return False

  @contextlib.contextmanager
  def _container_context(self):
    """Context manager for per-submission containers."""
    self.start_container()
    try:
      yield
    finally:
      self.stop_container()

  def cleanup(self) -> None:
    """Ensure docker resources are cleaned up on failure or early exit."""
    try:
      self.stop_container()
    except Exception as e:
      log.warning(f"Failed to stop container during cleanup: {e}")

    if self.image is not None and hasattr(self.image, "remove"):
      try:
        self.docker_client.remove_image(self.image, force=True)
      except Exception as e:
        log.warning(f"Failed to remove image during cleanup: {e}")
    self.image = None

  def grade_submission(self,
                       submission,
                       files_to_copy=None,
                       *args,
                       **kwargs) -> Feedback:
    """
    Overrides method to add files to docker and then relies on children to implement two other required files
    :param files_to_copy:
    :param args:
    :param kwargs:
    :return:
    """
    if self.image is None:
      log.debug("Building docker image")
      self.image = self._get_image()

    with self._container_context():
      if files_to_copy is not None:
        self.add_files_to_docker(files_to_copy)
      # input(f"Waiting on container {self.container}")
      return super().grade_submission(submission, *args, **kwargs)


@GraderRegistry.register("template-grader")
class TemplateGrader(DockerGrader):
  """
  Template-based grader that automatically sets up a course template repository
  and runs scripts/grader.py with minimal configuration required.

  Automatically handles:
  - Default Python 3.11 environment
  - Cloning template repository (local or remote)
  - Installing uv and running uv sync
  - Running grader.py with assignment name
  """
  COMPATIBLE_KINDS = {"ProgrammingAssignment"}

  @classmethod
  def normalize_settings(cls, settings: Dict[str, Any],
                         context_label: str) -> Dict[str, Any]:
    """Validate and normalize template grader settings."""
    return config_models._normalize_template_grader_settings(
      settings, context_label)

  def __init__(
      self,
      assignment_name,
      course_name: str = "UnknownCourse",
      base_image_name: str = "python:3.11-slim",  # assume this is based on linux
      source_repo:
    str = "https://github.com/CSUMB-SCD-instructors/course-template",
      additional_repos=None,
      container_repo_path: str = "/repo/programming-assignments",
      student_code_path: str = "",
      extra_installs=None,  # todo: these will be tough, do later
      extra_dockerfile_lines=None,
      file_paths=None,
      grading_script: str | None = None,
      grading_args=None,
      grading_workdir: str | None = None,
      upload_error_artifacts: bool = False,
      *args,
      **kwargs):

    if extra_installs is None:
      extra_installs = []
    if extra_dockerfile_lines is None:
      extra_dockerfile_lines = []
    if file_paths is None:
      file_paths = {}

    self.course_name = course_name
    self.assignment_name = assignment_name
    self.base_image_name = base_image_name
    self.source_repo = source_repo
    self.additional_repos = self._normalize_additional_repos(additional_repos)
    self.container_repo_path = self._normalize_container_repo_path(
      container_repo_path)
    self.student_code_path = student_code_path
    self.extra_installs = extra_installs
    self.extra_dockerfile_lines = extra_dockerfile_lines
    self.file_paths = file_paths
    self.grading_workdir = grading_workdir
    self.grading_script_override = grading_script
    self.grading_args = list(grading_args or [])
    # Potential includes
    self.golden_repo = kwargs.get("golden_repo", None)
    self.files_from_golden = kwargs.get("files_from_golden", [])

    super().__init__(*args,
                     upload_error_artifacts=upload_error_artifacts,
                     **kwargs)

    # todo: these two can likely be removed if we go full template.
    default_workdir = "/repo"
    self.working_dir = (
      self.grading_workdir.strip()
      if isinstance(self.grading_workdir, str) and self.grading_workdir.strip()
      else default_workdir)
    default_script = self._build_default_grading_script(
      assignment_name=self.assignment_name, grading_args=self.grading_args)
    self.grading_script = (
      self.grading_script_override.strip()
      if isinstance(self.grading_script_override, str)
      and self.grading_script_override.strip() else default_script)

    return

  @staticmethod
  def _build_default_grading_script(assignment_name: Any,
                                    grading_args: Optional[List[str]] = None
                                    ) -> str:
    pa_arg = shlex.quote(str(assignment_name))
    normalized_args: List[str] = []
    for arg in grading_args or []:
      normalized_args.append(shlex.quote(str(arg)))

    extra_args = ""
    if normalized_args:
      extra_args = f" {' '.join(normalized_args)}"

    grader_invocation = f"/repo/scripts/grader.py --PA {pa_arg}{extra_args}"
    return (
      "if [ -x /repo/.venv/bin/python ]; then "
      f"/repo/.venv/bin/python {grader_invocation}; "
      "elif command -v python3 >/dev/null 2>&1; then "
      f"python3 {grader_invocation}; "
      "else "
      f"python {grader_invocation}; "
      "fi"
    )

  @staticmethod
  def _normalize_container_repo_path(container_repo_path: str) -> str:
    if not isinstance(container_repo_path, str):
      raise ValueError(
        "container_repo_path must be a string (example: '/repo/programming-assignments')."
      )

    normalized = os.path.normpath(container_repo_path.strip())
    if not normalized.startswith("/"):
      raise ValueError(
        "container_repo_path must be an absolute path under /repo "
        "(example: '/repo/programming-assignments').")
    if normalized != "/repo" and not normalized.startswith("/repo/"):
      raise ValueError(
        f"container_repo_path must be within /repo, got '{container_repo_path}'.")
    return normalized

  def _normalize_additional_repos(self, additional_repos) -> List[dict]:
    if additional_repos is None:
      return []
    if not isinstance(additional_repos, list):
      raise ValueError(
        "additional_repos must be a list of mappings with keys: "
        "source_repo, container_path, optional depth.")

    normalized_repos = []
    for i, repo_config in enumerate(additional_repos):
      if not isinstance(repo_config, dict):
        raise ValueError(
          f"additional_repos[{i}] must be a mapping. "
          "Expected keys: source_repo, container_path, optional depth.")
      unknown_keys = sorted(
        k for k in repo_config.keys() if k not in {"source_repo", "container_path", "depth"})
      if unknown_keys:
        raise ValueError(
          f"additional_repos[{i}] has unsupported key(s): {', '.join(unknown_keys)}")

      source_repo = repo_config.get("source_repo")
      if not isinstance(source_repo, str) or not source_repo.strip():
        raise ValueError(
          f"additional_repos[{i}].source_repo is required and must be a non-empty string."
        )

      container_path = self._normalize_container_repo_path(
        repo_config.get("container_path"))
      if container_path == "/repo":
        raise ValueError(
          "additional_repos cannot target /repo (reserved for source_repo). "
          "Use a subpath such as /repo/tools.")

      depth = repo_config.get("depth", 1)
      if depth is not None and (not isinstance(depth, int) or depth <= 0):
        raise ValueError(
          f"additional_repos[{i}].depth must be an integer >= 1 when provided.")

      normalized_repos.append({
        "source_repo": source_repo,
        "container_path": container_path,
        "depth": depth,
      })

    sorted_paths = sorted(repo["container_path"] for repo in normalized_repos)
    for i, path_i in enumerate(sorted_paths):
      for path_j in sorted_paths[i + 1:]:
        if path_j.startswith(f"{path_i}/") or path_i.startswith(f"{path_j}/"):
          raise ValueError(
            "additional_repos contain overlapping container_path values: "
            f"'{path_i}' and '{path_j}'. Choose disjoint mount targets.")

    return normalized_repos

  def _repo_mounts(self) -> List[dict]:
    mounts = [{
      "container_path": "/repo",
      "context_dir": "repo",
    }]
    for i, repo in enumerate(self.additional_repos):
      mounts.append({
        "container_path": repo["container_path"],
        "context_dir": f"repo_extra_{i}",
      })
    return mounts

  def _container_assignment_root(self) -> str:
    return os.path.join(self.container_repo_path, self.assignment_name)

  @staticmethod
  def _sanitize_image_tag_component(value: Any) -> str:
    raw = str(value).strip().lower()
    normalized = re.sub(r"[^a-z0-9_.-]+", "-", raw)
    normalized = normalized.strip("._-")
    return normalized or "autograder"

  def _build_context_image_tag(self) -> str:
    course = self._sanitize_image_tag_component(self.course_name)
    assignment = self._sanitize_image_tag_component(self.assignment_name)
    return f"template-grader:{course}-{assignment}-{uuid.uuid4().hex}"

  @staticmethod
  def _uv_bootstrap_command() -> str:
    # Some course repos do not use uv projects; skip uv setup in that case.
    # If uv sync fails, retry once after installing common build deps so native
    # wheels (e.g., psycopg2) can compile on slim images.
    return (
      "if [ -f pyproject.toml ]; then "
      "uv sync || ("
      "if command -v apt-get >/dev/null 2>&1; then "
      "apt-get update && "
      "DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "
      "build-essential gcc libpq-dev && "
      "rm -rf /var/lib/apt/lists/*; "
      "elif command -v apk >/dev/null 2>&1; then "
      "apk add --no-cache build-base postgresql-dev; "
      "fi; "
      "uv sync"
      "); "
      "else "
      "echo 'No pyproject.toml found in /repo; skipping uv sync'; "
      "fi"
    )

  @staticmethod
  def _resolve_local_path_for_container_path(temp_build_dir: str,
                                             container_path: str,
                                             repo_mounts: List[dict]) -> str:
    normalized_target = os.path.normpath(container_path)
    for mount in sorted(repo_mounts,
                        key=lambda entry: len(entry["container_path"]),
                        reverse=True):
      mount_path = mount["container_path"]
      if (normalized_target == mount_path
          or normalized_target.startswith(f"{mount_path}/")):
        relative = os.path.relpath(normalized_target, mount_path)
        base = os.path.join(temp_build_dir, mount["context_dir"])
        return base if relative == "." else os.path.join(base, relative)
    raise ValueError(
      f"container path '{container_path}' is not mounted by any configured repository. "
      f"Configured mounts: {', '.join(sorted(m['container_path'] for m in repo_mounts))}"
    )

  @staticmethod
  def _get_repo(repo_path: str, dest="repo", depth=None, deploy_key_path=None):

    dest = pathlib.Path(dest).expanduser().resolve()
    if dest.exists():
      raise FileExistsError(
        f"Destination path '{dest}' already exists while preparing repository "
        f"source '{repo_path}'. Remove the existing path or choose a different target."
      )

    # If it's local, copy it from local
    if pathlib.Path(repo_path).expanduser().exists():
      shutil.copytree(pathlib.Path(repo_path).expanduser(), dest)
      return

    else:  # Get it from the remote location
      env = os.environ.copy()

      # If you need to use an SSH deploy key just for this command:
      # (works for git@host:org/repo.git or ssh://host/...)
      if deploy_key_path:
        ssh_cmd = f"ssh -i {deploy_key_path} -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"
        env["GIT_SSH_COMMAND"] = ssh_cmd

      cmd = ["git", "clone", repo_path, str(dest)]
      if depth:
        cmd[2:2] = ["--depth", str(depth)
                    ]  # insert after "clone" (optional shallow clone)

      run_kwargs = {"check": True, "env": env}
      if not log.isEnabledFor(logging.DEBUG):
        run_kwargs.update({
          "stdout": subprocess.DEVNULL,
          "stderr": subprocess.PIPE,
          "text": True,
        })

      try:
        subprocess.run(cmd, **run_kwargs)
      except subprocess.CalledProcessError as e:
        stderr = (getattr(e, "stderr", None) or "").strip()
        if stderr:
          raise RuntimeError(
            f"git clone failed for '{repo_path}': {stderr}. "
            "Check repository URL/access permissions and network connectivity.") from e
        raise RuntimeError(
          f"git clone failed for '{repo_path}'. "
          "Check repository URL/access permissions and network connectivity.") from e

  def _match_files_to_paths(self,
                            submission) -> Tuple[List[Tuple], Optional[str]]:
    """
    Match submission files to target paths based on regex patterns in file_paths config.

    Args:
        submission: Submission object with files attribute

    Returns:
        Tuple of (files_to_copy, error_message)
        - files_to_copy: List of (file_object, target_path) tuples
        - error_message: Error string if duplicate matches found, None otherwise

    Uses self.file_paths dict where keys are regex patterns and values are dicts with:
        - path: when name is provided, a subdirectory within assignment folder;
                when name is omitted, a full relative target file path.
        - name: optional target filename override
    """
    import re

    files_to_copy = []
    matched_patterns = {}  # Track which patterns have been matched

    # Iterate through submission files
    for file_obj in submission.files:
      # Get the file's name (could include path if uploaded in folder structure)
      file_identifier = getattr(file_obj, 'name', 'unnamed_file')

      log.debug(f"Processing file: {file_identifier}")

      # Try to match against each pattern
      matched_this_file = False
      for pattern, target_config in self.file_paths.items():
        try:
          if re.match(pattern, file_identifier):
            log.debug(f"  Matched pattern: {pattern}")

            # Check if this pattern was already matched by another file
            if pattern in matched_patterns:
              # Multiple files match the same pattern - return error
              previous_file = matched_patterns[pattern]
              error_msg = (
                f"Multiple files match pattern '{pattern}': "
                f"'{previous_file}' and '{file_identifier}'. "
                f"Please ensure file names are unique and match exactly one pattern."
              )
              log.error(error_msg)
              return [], error_msg

            # Record this match
            matched_patterns[pattern] = file_identifier

            # Build target path. Keep backward compatibility:
            # - with name: path is treated as destination directory
            # - without name: path is treated as full destination file path
            configured_path = target_config.get('path', '')
            configured_name = target_config.get('name')
            assignment_root = self._container_assignment_root()

            if configured_name is not None:
              target_directory = os.path.join(assignment_root, configured_path)
              target_file_path = os.path.join(target_directory, configured_name)
            else:
              if not configured_path:
                error_msg = (
                  f"Pattern '{pattern}' has an empty path and no name. "
                  "Provide name, or set path to a full relative target file path."
                )
                log.error(error_msg)
                return [], error_msg
              target_file_path = os.path.join(assignment_root, configured_path)

            files_to_copy.append((file_obj, target_file_path))
            matched_this_file = True
            log.debug(f"  Will copy to: {target_file_path}")
            break  # Only match first pattern

        except re.error as e:
          log.error(f"Invalid regex pattern '{pattern}': {e}")
          return [], f"Invalid regex pattern '{pattern}': {e}"

      if not matched_this_file:
        log.debug(f"  No pattern matched (will be skipped)")

    log.debug(f"Matched {len(files_to_copy)} files using file_paths patterns")
    return files_to_copy, None

  def _get_image(self, **kwargs):
    # What we want to do is to create a docker image that has the repository in it and installs all the required dependencies.
    # In this case that means we need to get the repo from either locally or remotely and then run `uv sync` in the right directory

    with tempfile.TemporaryDirectory() as temp_build_dir:
      log.debug(f"temp_build_dir: {temp_build_dir}")
      repo_mounts = self._repo_mounts()

      # Get the main repo
      self._get_repo(self.source_repo,
                     os.path.join(temp_build_dir, "repo"),
                     depth=1)
      for mount, repo in zip(repo_mounts[1:], self.additional_repos):
        self._get_repo(repo["source_repo"],
                       os.path.join(temp_build_dir, mount["context_dir"]),
                       depth=repo.get("depth"))

      # If we have a golden repo, let's use it to set the extra files
      if self.golden_repo:
        # Download the golden repo, and we'll delete it later
        self._get_repo(self.golden_repo, os.path.join(temp_build_dir,
                                                      "golden"))

        logging.debug(temp_build_dir)
        golden_mounts = [{
          "container_path": "/repo",
          "context_dir": "golden",
        }]
        source_assignment_root = self._resolve_local_path_for_container_path(
          temp_build_dir, self._container_assignment_root(), golden_mounts)
        target_assignment_root = self._resolve_local_path_for_container_path(
          temp_build_dir, self._container_assignment_root(), repo_mounts)

        for f in self.files_from_golden:
          log.debug(f"Copying over golden file: {f}")
          target_file = os.path.join(target_assignment_root, f)
          os.makedirs(os.path.dirname(target_file), exist_ok=True)
          shutil.copy(
            os.path.join(source_assignment_root, f),
            target_file,
          )

        # Remove the golden for now
        shutil.rmtree(os.path.join(temp_build_dir, "golden"))

      # Set up dockerfile
      dockerfile_lines = [
        f"FROM {self.base_image_name}",
        "USER root",
      ]

      # Add any extra Dockerfile lines after FROM but before copying repo
      # This allows for apt installs, user setup, etc.
      if self.extra_dockerfile_lines:
        # Handle both string (single line) and list (multiple lines)
        if isinstance(self.extra_dockerfile_lines, str):
          dockerfile_lines.append(self.extra_dockerfile_lines)
        else:
          dockerfile_lines.extend(self.extra_dockerfile_lines)

      # Continue with the standard setup
      dockerfile_lines.extend([
        "",  # Empty line for readability
        "COPY repo /repo",
      ])
      for mount in repo_mounts[1:]:
        dockerfile_lines.append(
          f"COPY {mount['context_dir']} {mount['container_path']}")
      dockerfile_lines.extend([
        "COPY --from=ghcr.io/astral-sh/uv:0.8.17 /uv /uvx /bin/",
        "WORKDIR /repo",
        "RUN rm -rf .venv",
        "RUN rm -rf uv.lock .venv",
        # "RUN uv lock",
      ])

      # Optional extra install commands from config.
      for install_cmd in self.extra_installs:
        if not isinstance(install_cmd, str):
          continue
        command = install_cmd.strip()
        if not command:
          continue
        if command.upper().startswith("RUN "):
          dockerfile_lines.append(command)
        else:
          dockerfile_lines.append(f"RUN {command}")

      dockerfile_lines.extend([
        f"RUN {self._uv_bootstrap_command()}",
        # "RUN chown -fR dockeruser /repo",
        # "USER dockeruser",
      ])

      # Next, we want to save our dockerfile
      with open(os.path.join(temp_build_dir, "Dockerfile"),
                "w") as dockerfile_fid:
        dockerfile_fid.write('\n'.join(dockerfile_lines) + "\n")
        
      # input(f"Waiting at {temp_build_dir}")

      image = self.docker_client.build_image_from_context(
        context_path=temp_build_dir,
        tag=self._build_context_image_tag(),
        use_cached=True)
    return image

  def grade_submission(self, submission, *args, **kwargs) -> Feedback:
    # Determine which file organization strategy to use
    if self.file_paths:
      # Use new regex-based file matching
      log.debug("Using file_paths regex matching for file organization")
      submission_files, error_msg = self._match_files_to_paths(submission)

      if error_msg:
        # Return error feedback immediately
        log.error(f"File matching error: {error_msg}")
        return Feedback(percentage_score=0.0,
                        comments=f"File naming error: {error_msg}")

      log.debug(
        f"Matched files: {[(f[0].name if hasattr(f[0], 'name') else 'unknown', f[1]) for f in submission_files]}"
      )
    else:
      # Use student_code_path file organization when regex mapping is not configured.
      log.debug("Using student_code_path for file organization")
      assignment_root = self._container_assignment_root()
      student_code_path = self.student_code_path or ""
      normalized_student_code_path = student_code_path.strip()
      looks_like_file_target = (
        bool(normalized_student_code_path)
        and not normalized_student_code_path.endswith("/")
        and bool(
          os.path.splitext(
            os.path.basename(normalized_student_code_path))[1]))

      if looks_like_file_target:
        if len(submission.files) != 1:
          error_msg = (
            "student_code_path appears to be a file target "
            f"('{self.student_code_path}') but this submission has "
            f"{len(submission.files)} files. Use a directory-style "
            "student_code_path or configure file_paths.")
          log.error(error_msg)
          return Feedback(percentage_score=0.0,
                          comments=f"Configuration error: {error_msg}")
        submission_files = [(submission.files[0],
                             os.path.join(assignment_root,
                                          normalized_student_code_path))]
      else:
        submission_files = []
        for f in submission.files:
          # Copy each file into the target directory using its own filename.
          # This avoids accidental overwrite when multiple files are submitted.
          original_name = os.path.basename(
            getattr(f, "name", "submission_file"))
          submission_files.append(
            (f,
             os.path.join(assignment_root, normalized_student_code_path,
                          original_name)))
      log.debug(f"submission.files: {submission.files}")
      log.debug(f"submission_files: {submission_files}")

    # Grade using parent class method
    return super().grade_submission(submission,
                                    files_to_copy=submission_files,
                                    *args,
                                    **kwargs)

  def score_grading(self, execution_results, *args, **kwargs) -> Feedback:
    rc, stdout, stderr = execution_results

    # Try to read the feedback.yaml file (note: different from results.yaml in parent)
    # Expected format:
    #   grade: <percentage 0-100+>  # Percentage score where 100 = full credit
    #   comments: <feedback text>
    #   logs: <optional execution logs>
    feedback_content = self.read_file_from_container("/tmp/feedback.yaml")
    log.debug(f"feedback_content: {feedback_content}")

    if feedback_content:
      try:
        feedback_data = yaml.safe_load(feedback_content)
        if isinstance(feedback_data, dict):
          # Grade should be a percentage (0-100+)
          grade = float(feedback_data.get('grade', 0.0))
          comments = feedback_data.get('comments', 'No comments provided')
          logs = feedback_data.get('logs', '')

          full_feedback = comments
          if logs and logs.strip():
            full_feedback += f"\n\n--- Execution Logs ---\n{logs}"

          return Feedback(percentage_score=grade, comments=full_feedback)
      except Exception as e:
        error_msg = f"Failed to parse feedback YAML: {e}"
        log.error(error_msg)
        self._report_grading_error(error_msg, execution_results,
                                   kwargs.get('submission'))
        return Feedback(
          percentage_score=0.0,
          comments=
          "Error during grading. If this persists, please let your professor know."
        )

    # Fallback: feedback.yaml not found or empty
    error_msg = f"Feedback file not found or empty. RC: {rc}, stdout length: {len(stdout)}, stderr length: {len(stderr)}"
    log.error(error_msg)
    self._report_grading_error(error_msg, execution_results,
                               kwargs.get('submission'))
    return Feedback(
      percentage_score=0.0,
      comments=
      "Error during grading. If this persists, please let your professor know."
    )

  def execute_grading(self, *args, **kwargs) -> Tuple[int, str, str]:
    # Execute the grading script
    rc, stdout, stderr = self.execute_command_in_container(
      command=self.grading_script, workdir=self.working_dir)
    return rc, stdout.decode(), stderr.decode()


# =============================================================================
# Backwards Compatibility Aliases
# =============================================================================
# These aliases preserve backwards compatibility for code that imports the
# old class names with double underscores.
Grader__docker = DockerGrader
Grader__template_grader = TemplateGrader
