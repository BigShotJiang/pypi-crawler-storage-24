#![recursion_limit = "256"]
#![allow(
    clippy::must_use_candidate,
    clippy::return_self_not_must_use,
    clippy::needless_pass_by_value
)]

pub mod conversion_lut;
pub mod graphrecord;
pub mod prelude;
#[cfg(feature = "pyo3-bindings")]
pub mod pyo3_bindings;
