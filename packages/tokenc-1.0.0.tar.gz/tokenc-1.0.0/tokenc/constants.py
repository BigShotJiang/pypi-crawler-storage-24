"""
Constants for The Token Company API
"""

API_BASE_URL = "https://api.thetokencompany.com"
DEFAULT_TIMEOUT = 30
