"""Telegram session store — thin wrapper over generic ChannelSessionStore."""

from pathlib import Path

from fliiq.runtime.channel_store import ChannelSessionStore


class TelegramSessionStore:
    """Backward-compatible wrapper for Telegram sessions."""

    def __init__(self, fliiq_dir: Path):
        self._store = ChannelSessionStore(fliiq_dir, "telegram")

    def log_message(
        self,
        chat_id: int,
        role: str,
        text: str,
        thread_id: int | None = None,
    ) -> None:
        """Append a message to the chat's persistent log."""
        self._store.log_message(str(chat_id), role, text, thread_id)

    def load_recent(
        self,
        chat_id: int,
        thread_id: int | None = None,
        max_messages: int = 20,
        max_age_hours: int = 24,
    ) -> list[dict]:
        """Load recent messages as OpenAI-format message dicts."""
        return self._store.load_recent(
            str(chat_id), thread_id, max_messages, max_age_hours,
        )
