"""Tests for configuration loading."""

from __future__ import annotations

from pathlib import Path

from drasill.config import AppConfig, DbConfig, load_config


def test_load_missing_config_returns_defaults() -> None:
    """Loading a non-existent file returns default config."""
    config = load_config(Path("/nonexistent/config.toml"))
    assert config.server.port == 8400
    assert config.server.host == "0.0.0.0"


def test_load_config_from_toml(tmp_path: Path) -> None:
    """Loading a valid TOML file parses correctly."""
    cfg_file = tmp_path / "test.toml"
    cfg_file.write_text("""\
[server]
host = "127.0.0.1"
port = 9000

[db]
path = "/tmp/test.db"
""")
    config = load_config(cfg_file)
    assert config.server.host == "127.0.0.1"
    assert config.server.port == 9000
    assert config.db.path == "/tmp/test.db"


def test_db_path_expands_tilde() -> None:
    """The ~ in db.path is expanded to the user's home directory."""
    config = AppConfig(db=DbConfig(path="~/data/test.db"))
    assert "~" not in config.db.path
    assert config.db.path.endswith("data/test.db")


def test_env_var_config_path(tmp_path: Path, monkeypatch: object) -> None:
    """Config loads from DRASILL_CONFIG env var."""
    cfg_file = tmp_path / "env.toml"
    cfg_file.write_text("[server]\nport = 7777\n")
    monkeypatch.setenv("DRASILL_CONFIG", str(cfg_file))  # type: ignore[attr-defined]
    config = load_config()
    assert config.server.port == 7777
