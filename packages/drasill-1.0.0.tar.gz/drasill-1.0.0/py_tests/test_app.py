"""Tests for the FastAPI application."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import aiosqlite
import pytest

from drasill.app import create_app
from drasill.config import AppConfig, DbConfig
from drasill.db import init_db
from drasill.mesh.router import mesh_events

if TYPE_CHECKING:
    from fastapi import FastAPI
    from httpx import AsyncClient


async def test_health_endpoint(client: AsyncClient) -> None:
    """Health endpoint returns 200 with status ok."""
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


async def test_index_returns_html(client: AsyncClient) -> None:
    """Index page returns 200 with HTML content."""
    resp = await client.get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert "drasill" in resp.text


async def test_index_has_sidebar_and_panes(client: AsyncClient) -> None:
    """Index page contains sidebar and pane tiling structure."""
    resp = await client.get("/")
    assert "sidebar-agents" in resp.text
    assert "Overview" in resp.text
    assert "/partials/sidebar" in resp.text
    assert "pane-root" in resp.text


async def test_sidebar_partial_empty(client: AsyncClient) -> None:
    """Sidebar partial with no agents shows empty state."""
    resp = await client.get("/partials/sidebar")
    assert resp.status_code == 200
    assert "No agents" in resp.text


async def test_sidebar_partial_with_agents(
    client: AsyncClient,
) -> None:
    """Sidebar partial shows registered agents."""
    await client.post(
        "/mesh/agents",
        json={"name": "sidebar-test"},
    )
    resp = await client.get("/partials/sidebar")
    assert resp.status_code == 200
    assert "sidebar-test" in resp.text

    await client.delete("/mesh/agents/sidebar-test")


async def test_agent_detail_partial_not_found(client: AsyncClient) -> None:
    """Agent detail partial returns 'not found' for unknown agent."""
    resp = await client.get("/partials/agent-detail/ghost")
    assert resp.status_code == 200
    assert "Agent not found" in resp.text


async def test_agent_detail_partial_with_agent(client: AsyncClient) -> None:
    """Agent detail partial renders agent info and messages."""
    await client.post(
        "/mesh/agents",
        json={"name": "detail-test"},
    )
    resp = await client.get("/partials/agent-detail/detail-test")
    assert resp.status_code == 200
    assert "detail-test" in resp.text

    await client.delete("/mesh/agents/detail-test")


async def test_mesh_partial_empty(client: AsyncClient) -> None:
    """Mesh partial with no agents shows empty state."""
    resp = await client.get("/partials/mesh")
    assert resp.status_code == 200
    assert "No agents registered" in resp.text


async def test_mesh_partial_with_agents(client: AsyncClient) -> None:
    """Mesh partial shows registered agents."""
    await client.post("/mesh/agents", json={"name": "mesh-test"})
    resp = await client.get("/partials/mesh")
    assert resp.status_code == 200
    assert "1 idle" in resp.text

    await client.delete("/mesh/agents/mesh-test")


async def test_mesh_partial_with_messages(client: AsyncClient) -> None:
    """Mesh partial shows recent messages."""
    await client.post("/mesh/agents", json={"name": "sender"})
    await client.post("/mesh/agents", json={"name": "receiver"})
    await client.post(
        "/mesh/agents/receiver/inbox",
        json={"from_agent": "sender", "body": "hello mesh"},
    )

    resp = await client.get("/partials/mesh")
    assert resp.status_code == 200
    assert "hello mesh" in resp.text

    await client.delete("/mesh/agents/sender")
    await client.delete("/mesh/agents/receiver")


async def test_sse_mesh_events_integration(app: FastAPI) -> None:
    """SSE /mesh/events endpoint streams real events from the bus."""
    request = MagicMock()
    request.app = app

    response = await mesh_events(request)
    assert response.media_type == "text/event-stream"
    assert response.headers["Cache-Control"] == "no-cache"

    bus = app.state.event_bus
    ait = response.body_iterator.__aiter__()

    async def _push() -> None:
        await asyncio.sleep(0.05)
        bus.publish("refresh")

    task = asyncio.create_task(_push())
    raw = await asyncio.wait_for(ait.__anext__(), timeout=2)
    await task

    chunk = str(raw)
    assert "event: mesh" in chunk
    assert "data: refresh" in chunk


async def test_init_db_locked_probe(tmp_db_path: str) -> None:
    """init_db logs a warning and re-raises when the DB probe detects a lock."""
    real_connect = aiosqlite.connect

    async def _patched_connect(path: str) -> aiosqlite.Connection:
        db = await real_connect(path)
        original_execute = db.execute

        async def _locked_probe(
            sql: str,
            parameters: object = None,
        ) -> object:
            if sql == "SELECT 1":
                msg = "database is locked"
                raise aiosqlite.OperationalError(msg)
            if parameters is not None:
                return await original_execute(sql, parameters)
            return await original_execute(sql)

        db.execute = _locked_probe  # type: ignore[assignment]
        return db

    with (
        patch("drasill.db.aiosqlite.connect", side_effect=_patched_connect),
        pytest.raises(aiosqlite.OperationalError, match="locked"),
    ):
        await init_db(tmp_db_path)


def test_create_app_without_config() -> None:
    """create_app(config=None) loads config from defaults."""
    with patch("drasill.app.load_config") as mock_load:
        mock_load.return_value = AppConfig(
            db=DbConfig(path=":memory:"),
        )
        application = create_app(config=None)
    assert application.title == "drasill"
    mock_load.assert_called_once()
