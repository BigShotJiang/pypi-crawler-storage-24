"""Tests for the agent mesh API."""

from __future__ import annotations

import logging
import sqlite3
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from drasill.mesh.events import MeshEventBus
from drasill.mesh.router import _session_wake

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from fastapi import FastAPI


# --- SSE ---


async def test_event_bus_keepalive() -> None:
    """Event bus yields empty string as keepalive on timeout."""
    bus = MeshEventBus()
    gen = bus.subscribe()
    # Patch wait_for to immediately timeout, triggering keepalive
    with patch("drasill.mesh.events.asyncio.wait_for", side_effect=TimeoutError):
        event = await gen.__anext__()
    assert event == ""


# --- Agent Registry ---


async def test_register_agent(client: AsyncClient) -> None:
    resp = await client.post(
        "/mesh/agents",
        json={"name": "alpha", "pid": 1234},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["name"] == "alpha"
    assert body["status"] == "registered"


async def test_register_duplicate_agent(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post("/mesh/agents", json={"name": "alpha"})
    assert resp.status_code == 409
    assert "already registered" in resp.json()["error"]


async def test_register_invalid_name(client: AsyncClient) -> None:
    resp = await client.post("/mesh/agents", json={"name": "Bad Name!"})
    assert resp.status_code == 422


async def test_register_empty_name(client: AsyncClient) -> None:
    resp = await client.post("/mesh/agents", json={"name": ""})
    assert resp.status_code == 422


async def test_deregister_agent(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "beta"})
    resp = await client.delete("/mesh/agents/beta")
    assert resp.status_code == 200
    assert resp.json()["status"] == "deregistered"

    resp = await client.get("/mesh/agents/beta")
    assert resp.status_code == 404


async def test_deregister_nonexistent(client: AsyncClient) -> None:
    resp = await client.delete("/mesh/agents/ghost")
    assert resp.status_code == 404


async def test_deregister_cleans_pending_messages(
    client: AsyncClient,
) -> None:
    await client.post("/mesh/agents", json={"name": "doomed"})
    await client.post("/mesh/agents", json={"name": "sender"})
    await client.post(
        "/mesh/agents/doomed/inbox",
        json={"from_agent": "sender", "body": "hello"},
    )
    await client.delete("/mesh/agents/doomed")

    # Re-register and check inbox is empty
    await client.post("/mesh/agents", json={"name": "doomed"})
    resp = await client.get("/mesh/agents/doomed/inbox")
    assert resp.json() == {}


async def test_list_agents(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post("/mesh/agents", json={"name": "beta"})
    resp = await client.get("/mesh/agents")
    assert resp.status_code == 200
    agents = resp.json()["agents"]
    names = {a["name"] for a in agents}
    assert names == {"alpha", "beta"}


async def test_list_agents_empty(client: AsyncClient) -> None:
    resp = await client.get("/mesh/agents")
    assert resp.status_code == 200
    assert resp.json()["agents"] == []


async def test_get_agent(client: AsyncClient) -> None:
    await client.post(
        "/mesh/agents",
        json={
            "name": "alpha",
            "pid": 42,
        },
    )
    resp = await client.get("/mesh/agents/alpha")
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "alpha"
    assert body["pid"] == 42
    assert body["status"] == "active"


async def test_get_agent_not_found(client: AsyncClient) -> None:
    resp = await client.get("/mesh/agents/ghost")
    assert resp.status_code == 404


# --- Messaging ---


async def test_send_message(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "run tests"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["status"] == "queued"
    assert "id" in body


async def test_send_message_to_nonexistent(client: AsyncClient) -> None:
    resp = await client.post(
        "/mesh/agents/ghost/inbox",
        json={"from_agent": "human", "body": "hello"},
    )
    assert resp.status_code == 404


async def test_send_empty_body(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": ""},
    )
    assert resp.status_code == 422


async def test_send_invalid_priority(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "test", "priority": "ultra"},
    )
    assert resp.status_code == 422


async def test_check_inbox_empty(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.status_code == 200
    assert resp.json() == {}


async def test_check_inbox_returns_oldest_unread(
    client: AsyncClient,
) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "first"},
    )
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "second"},
    )

    # First check returns oldest message
    resp = await client.get("/mesh/agents/alpha/inbox")
    body = resp.json()
    assert body["from_agent"] == "human"
    assert body["body"] == "first"

    # Second check returns next
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.json()["body"] == "second"

    # Third check — empty
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.json() == {}


async def test_check_inbox_returns_message_fields(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "hello"},
    )

    resp = await client.get("/mesh/agents/alpha/inbox")
    body = resp.json()
    assert body["body"] == "hello"
    assert body["from_agent"] == "human"
    assert body["read_at"] is not None
    assert body.get("attachments", []) == []

    # Won't be returned again
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.json() == {}


async def test_check_inbox_marks_as_read(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "hello"},
    )

    # Reading consumes the message
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.json()["body"] == "hello"

    # Won't be returned again
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.json() == {}


async def test_check_inbox_agent_not_found(client: AsyncClient) -> None:
    resp = await client.get("/mesh/agents/ghost/inbox")
    assert resp.status_code == 404


async def test_urgent_priority(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={
            "from_agent": "human",
            "body": "critical",
            "priority": "urgent",
        },
    )
    resp = await client.get("/mesh/agents/alpha/inbox")
    body = resp.json()
    assert body["priority"] == "urgent"
    assert body["body"] == "critical"
    assert body["from_agent"] == "human"


async def test_check_inbox_with_attachments(
    client: AsyncClient,
    app: FastAPI,
) -> None:
    """Inbox includes attachment metadata."""
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": "see attached"},
    )
    msg_id = resp.json()["id"]

    # Insert a fake attachment linked to the message
    db = app.state.db
    await db.execute(
        "INSERT INTO mesh_attachments "
        "(id, filename, content_type, size, message_id, uploaded_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("abc123", "photo.png", "image/png", 1024, msg_id, "2026-01-01T00:00:00"),
    )
    await db.commit()

    resp = await client.get("/mesh/agents/alpha/inbox")
    body = resp.json()
    assert body["body"] == "see attached"
    assert len(body.get("attachments", [])) == 1
    att = body["attachments"][0]
    assert att["id"] == "abc123"
    assert att["filename"] == "photo.png"
    assert att["content_type"] == "image/png"
    assert att["size"] == 1024
    assert att["url"] == "/mesh/uploads/abc123"


async def test_outbox(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post("/mesh/agents", json={"name": "beta"})
    await client.post(
        "/mesh/agents/beta/inbox",
        json={"from_agent": "alpha", "body": "tests pass"},
    )

    resp = await client.get("/mesh/agents/alpha/outbox")
    assert resp.status_code == 200
    messages = resp.json()["messages"]
    assert len(messages) == 1
    assert messages[0]["body"] == "tests pass"
    assert messages[0]["to_agent"] == "beta"


async def test_outbox_empty(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.get("/mesh/agents/alpha/outbox")
    assert resp.status_code == 200
    assert resp.json()["messages"] == []


async def test_outbox_agent_not_found(client: AsyncClient) -> None:
    resp = await client.get("/mesh/agents/ghost/outbox")
    assert resp.status_code == 404


# --- Localhost Middleware ---


@pytest.fixture
async def remote_client(app: FastAPI) -> AsyncIterator[AsyncClient]:
    """Client that appears to come from a remote IP."""
    transport = ASGITransport(
        app=app,
        client=("203.0.113.1", 12345),
    )
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


async def test_localhost_middleware_allows_local(
    client: AsyncClient,
) -> None:
    resp = await client.get("/mesh/agents")
    assert resp.status_code == 200


async def test_localhost_middleware_blocks_remote(
    remote_client: AsyncClient,
) -> None:
    resp = await remote_client.get("/mesh/agents")
    assert resp.status_code == 403
    assert "localhost-only" in resp.json()["error"]


async def test_localhost_middleware_allows_non_mesh_routes(
    remote_client: AsyncClient,
) -> None:
    resp = await remote_client.get("/health")
    assert resp.status_code == 200


async def test_localhost_middleware_no_client(app: FastAPI) -> None:
    """Middleware blocks when request.client is None."""
    transport = ASGITransport(
        app=app,
        client=None,  # type: ignore[arg-type]  # intentional: testing middleware with no client
    )
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.get("/mesh/agents")
    assert resp.status_code == 403


async def test_send_empty_from_agent(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "", "body": "hello"},
    )
    assert resp.status_code == 422


async def test_send_invalid_from_agent(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "Bad Name!", "body": "hello"},
    )
    assert resp.status_code == 422


async def test_agent_name_max_length(client: AsyncClient) -> None:
    long_name = "a" * 64
    resp = await client.post("/mesh/agents", json={"name": long_name})
    assert resp.status_code == 201

    too_long = "a" * 65
    resp = await client.post("/mesh/agents", json={"name": too_long})
    assert resp.status_code == 422


async def test_message_body_max_length(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "alpha"})
    long_body = "x" * 10000
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": long_body},
    )
    assert resp.status_code == 201

    too_long = "x" * 10001
    resp = await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "human", "body": too_long},
    )
    assert resp.status_code == 422


async def test_deregister_cleans_read_messages(
    client: AsyncClient,
) -> None:
    await client.post("/mesh/agents", json={"name": "target"})
    await client.post("/mesh/agents", json={"name": "src"})
    await client.post(
        "/mesh/agents/target/inbox",
        json={"from_agent": "src", "body": "msg1"},
    )
    # Read the message
    await client.get("/mesh/agents/target/inbox")
    # Deregister and re-register
    await client.delete("/mesh/agents/target")
    await client.post("/mesh/agents", json={"name": "target"})
    # Inbox should be empty (read messages also cleaned)
    resp = await client.get("/mesh/agents/target/inbox")
    assert resp.json() == {}


async def test_fk_enforcement(app: FastAPI) -> None:
    """Foreign key on to_agent prevents inserting messages for nonexistent agents."""
    db = app.state.db
    with pytest.raises(sqlite3.IntegrityError):
        await db.execute(
            "INSERT INTO mesh_messages "
            "(to_agent, from_agent, body, priority, created_at) "
            "VALUES ('ghost', 'human', 'hello', 'normal', '2026-01-01')",
        )


async def test_deregister_cleans_outbox(client: AsyncClient) -> None:
    await client.post("/mesh/agents", json={"name": "sender"})
    await client.post("/mesh/agents", json={"name": "receiver"})
    await client.post(
        "/mesh/agents/receiver/inbox",
        json={"from_agent": "sender", "body": "outgoing"},
    )
    await client.delete("/mesh/agents/sender")

    # Re-register sender — outbox should be empty
    await client.post("/mesh/agents", json={"name": "sender"})
    resp = await client.get("/mesh/agents/sender/outbox")
    assert resp.json()["messages"] == []


# --- Inbox Format ---


async def test_inbox_normal_priority(client: AsyncClient) -> None:
    """Normal priority messages return priority=normal."""
    await client.post("/mesh/agents", json={"name": "alpha"})
    await client.post(
        "/mesh/agents/alpha/inbox",
        json={"from_agent": "beta", "body": "all tests pass"},
    )
    resp = await client.get("/mesh/agents/alpha/inbox")
    body = resp.json()
    assert body["from_agent"] == "beta"
    assert body["body"] == "all tests pass"
    assert body["priority"] == "normal"


async def test_inbox_empty_returns_empty_object(client: AsyncClient) -> None:
    """Empty inbox returns {}."""
    await client.post("/mesh/agents", json={"name": "alpha"})
    resp = await client.get("/mesh/agents/alpha/inbox")
    assert resp.status_code == 200
    body = resp.json()
    assert body == {}


# --- session_id registration and by-session lookup ---


async def test_register_agent_with_session_id(client: AsyncClient) -> None:
    """POST /mesh/agents with session_id persists the field."""
    resp = await client.post(
        "/mesh/agents",
        json={"name": "sess-agent", "session_id": "abc-123"},
    )
    assert resp.status_code == 201

    resp = await client.get("/mesh/agents/sess-agent")
    assert resp.status_code == 200
    assert resp.json()["session_id"] == "abc-123"


async def test_get_agent_by_session_found(client: AsyncClient) -> None:
    """GET /mesh/agents/by-session?id=xxx returns the agent name."""
    await client.post(
        "/mesh/agents",
        json={"name": "sess-agent", "session_id": "my-session-42"},
    )
    resp = await client.get(
        "/mesh/agents/by-session",
        params={"id": "my-session-42"},
    )
    assert resp.status_code == 200
    assert resp.json() == {"name": "sess-agent"}


async def test_get_agent_by_session_not_found(client: AsyncClient) -> None:
    """GET /mesh/agents/by-session?id=missing returns 404."""
    resp = await client.get(
        "/mesh/agents/by-session",
        params={"id": "no-such-session"},
    )
    assert resp.status_code == 404


# --- _session_wake ---


async def test_session_wake_sends_input() -> None:
    """_session_wake calls sup_send_input with encoded text."""
    with patch(
        "drasill.mesh.router.sup_send_input",
        new_callable=AsyncMock,
    ) as mock_send:
        await _session_wake("sess-xyz", "human", "hello")

    mock_send.assert_awaited_once()
    call_args = mock_send.call_args
    assert call_args[0][0] == "sess-xyz"
    # Payload should be bytes containing the message
    payload: bytes = call_args[0][1]
    assert payload == b"[mesh:human] hello\n"


async def test_session_wake_truncates_long_message() -> None:
    """_session_wake truncates bodies longer than 200 characters."""
    long_body = "x" * 300
    with patch(
        "drasill.mesh.router.sup_send_input",
        new_callable=AsyncMock,
    ) as mock_send:
        await _session_wake("sess-xyz", "human", long_body)

    payload: bytes = mock_send.call_args[0][1]
    decoded = payload.decode()
    assert "..." in decoded
    assert len(decoded) < 300


async def test_session_wake_logs_warning_on_oserror(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """_session_wake logs a warning when OSError is raised, does not raise."""
    with (
        patch(
            "drasill.mesh.router.sup_send_input",
            new_callable=AsyncMock,
            side_effect=OSError("connection refused"),
        ),
        caplog.at_level(logging.WARNING),
    ):
        await _session_wake("sess-xyz", "human", "hello")

    assert "sess-xyz" in caplog.text


# --- send_message uses _session_wake when agent has session_id ---


@patch("drasill.mesh.router._session_wake", new_callable=AsyncMock)
async def test_send_message_triggers_session_wake(
    mock_wake: AsyncMock,
    client: AsyncClient,
) -> None:
    """Sending a message to an agent with session_id triggers _session_wake."""
    await client.post(
        "/mesh/agents",
        json={"name": "sess-agent", "session_id": "wake-session"},
    )
    resp = await client.post(
        "/mesh/agents/sess-agent/inbox",
        json={"from_agent": "human", "body": "wake up"},
    )
    assert resp.status_code == 201

    mock_wake.assert_awaited_once_with("wake-session", "human", "wake up")


@patch("drasill.mesh.router._session_wake", new_callable=AsyncMock)
async def test_send_message_without_session_skips_wake(
    mock_session: AsyncMock,
    client: AsyncClient,
) -> None:
    """Sending to an agent without session_id does not trigger wake."""
    await client.post(
        "/mesh/agents",
        json={"name": "no-session-agent"},
    )
    resp = await client.post(
        "/mesh/agents/no-session-agent/inbox",
        json={"from_agent": "human", "body": "hello"},
    )
    assert resp.status_code == 201

    mock_session.assert_not_awaited()
