"""Tests for mesh file upload endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import patch

from drasill.mesh.uploads import (
    ALLOWED_TYPES,
    MAX_FILE_SIZE,
    file_path,
    generate_file_id,
    upload_dir,
)

if TYPE_CHECKING:
    from pathlib import Path

    from fastapi import FastAPI
    from httpx import AsyncClient


async def test_upload_file(client: AsyncClient, tmp_path: Path) -> None:
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path):
        resp = await client.post(
            "/mesh/upload",
            files={"file": ("test.png", b"fakepng", "image/png")},
        )
    assert resp.status_code == 201
    data = resp.json()
    assert data["filename"] == "test.png"
    assert data["content_type"] == "image/png"
    assert data["size"] == 7
    assert "id" in data


async def test_upload_rejects_bad_type(client: AsyncClient) -> None:
    resp = await client.post(
        "/mesh/upload",
        files={"file": ("evil.exe", b"MZ", "application/x-msdownload")},
    )
    assert resp.status_code == 400
    assert "not allowed" in resp.json()["detail"]


async def test_upload_rejects_too_large(client: AsyncClient, tmp_path: Path) -> None:
    with (
        patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path),
        patch("drasill.mesh.router.MAX_FILE_SIZE", 10),
    ):
        resp = await client.post(
            "/mesh/upload",
            files={"file": ("big.txt", b"x" * 20, "text/plain")},
        )
    assert resp.status_code == 400
    assert "too large" in resp.json()["detail"]


async def test_serve_upload(client: AsyncClient, tmp_path: Path) -> None:
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path):
        upload = await client.post(
            "/mesh/upload",
            files={"file": ("hello.txt", b"hello world", "text/plain")},
        )
        fid = upload.json()["id"]
        resp = await client.get(f"/mesh/uploads/{fid}")
    assert resp.status_code == 200
    assert resp.content == b"hello world"


async def test_serve_upload_not_found(client: AsyncClient) -> None:
    resp = await client.get("/mesh/uploads/nonexistent")
    assert resp.status_code == 404


async def test_serve_upload_missing_disk(
    client: AsyncClient,
    app: FastAPI,
) -> None:
    db = app.state.db
    await db.execute(
        "INSERT INTO mesh_attachments "
        "(id, filename, content_type, size, message_id, uploaded_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("gone123", "ghost.txt", "text/plain", 5, None, "2025-01-01"),
    )
    await db.commit()
    resp = await client.get("/mesh/uploads/gone123")
    assert resp.status_code == 404


async def test_link_attachments(
    client: AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    # Register an agent and send a message
    await client.post(
        "/mesh/agents",
        json={"name": "uptest"},
    )
    msg_resp = await client.post(
        "/mesh/agents/uptest/inbox",
        json={"from_agent": "human", "body": "check this file"},
    )
    msg_id = msg_resp.json()["id"]

    # Upload a file
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path):
        up_resp = await client.post(
            "/mesh/upload",
            files={"file": ("doc.pdf", b"%PDF", "application/pdf")},
        )
    fid = up_resp.json()["id"]

    # Link it
    link_resp = await client.post(
        "/mesh/upload/link",
        json={"message_id": msg_id, "attachment_ids": [fid]},
    )
    assert link_resp.status_code == 200
    assert link_resp.json()["count"] == 1

    # Verify linkage in DB
    cursor = await app.state.db.execute(
        "SELECT message_id FROM mesh_attachments WHERE id = ?",
        (fid,),
    )
    row = await cursor.fetchone()
    assert row["message_id"] == msg_id

    # Cleanup
    await client.delete("/mesh/agents/uptest")


async def test_link_missing_params(client: AsyncClient) -> None:
    resp = await client.post(
        "/mesh/upload/link",
        json={"message_id": None, "attachment_ids": []},
    )
    assert resp.status_code == 422


async def test_upload_with_message_id(
    client: AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path):
        resp = await client.post(
            "/mesh/upload?message_id=42",
            files={"file": ("pic.jpg", b"\xff\xd8", "image/jpeg")},
        )
    assert resp.status_code == 201
    cursor = await app.state.db.execute(
        "SELECT message_id FROM mesh_attachments WHERE id = ?",
        (resp.json()["id"],),
    )
    row = await cursor.fetchone()
    assert row["message_id"] == 42


def test_generate_file_id() -> None:
    fid = generate_file_id()
    assert len(fid) == 16
    assert fid.isalnum()


def test_upload_dir_creates(tmp_path: Path) -> None:
    target = tmp_path / "sub" / "uploads"
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", target):
        result = upload_dir()
    assert result == target
    assert target.exists()


def test_file_path_returns_correct(tmp_path: Path) -> None:
    with patch("drasill.mesh.uploads._DEFAULT_UPLOAD_DIR", tmp_path):
        p = file_path("abc123")
    assert p == tmp_path / "abc123"


def test_allowed_types_is_set() -> None:
    assert isinstance(ALLOWED_TYPES, set)
    assert "image/png" in ALLOWED_TYPES


def test_max_file_size() -> None:
    assert MAX_FILE_SIZE == 10 * 1024 * 1024
