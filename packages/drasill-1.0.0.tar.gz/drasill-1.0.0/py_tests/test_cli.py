"""Tests for the drasill CLI."""

from __future__ import annotations

import re
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from drasill.cli import (
    _HM_TARGETS,
    _cloudflared_unit,
    _cloudflared_yml,
    _drasill_bin,
    _systemctl,
    _systemd_unit,
    app,
    main,
)
from drasill.config import AppConfig, DbConfig

runner = CliRunner()


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def test_version_flag() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "drasill 0.1.0" in result.output


def test_help_shows_commands() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "serve" in result.output
    assert "install" in result.output


def test_install_help_shows_subcommands() -> None:
    result = runner.invoke(app, ["install", "--help"])
    assert result.exit_code == 0
    assert "systemd" in result.output
    assert "cloudflared" in result.output


def test_install_systemd_print_only() -> None:
    result = runner.invoke(app, ["install", "systemd", "--print-only"])
    assert result.exit_code == 0
    assert "[Unit]" in result.output
    assert "drasill serve" in result.output
    assert "8400" in result.output


def test_install_systemd_print_only_custom_port() -> None:
    result = runner.invoke(
        app,
        ["install", "systemd", "--print-only", "--port", "9000"],
    )
    assert result.exit_code == 0
    assert "--port 9000" in result.output


def test_install_systemd_print_only_with_config() -> None:
    result = runner.invoke(
        app,
        [
            "install",
            "systemd",
            "--print-only",
            "--config",
            "/etc/drasill.toml",
        ],
    )
    assert result.exit_code == 0
    assert "DRASILL_CONFIG=/etc/drasill.toml" in result.output


def test_install_systemd_writes_file(tmp_path: Path) -> None:
    systemd_dir = tmp_path / ".config" / "systemd" / "user"
    with patch("drasill.cli._SYSTEMD_DIR", systemd_dir):
        result = runner.invoke(app, ["install", "systemd"])
    assert result.exit_code == 0
    unit_path = systemd_dir / "drasill.service"
    assert unit_path.exists()
    content = unit_path.read_text()
    assert "drasill serve" in content
    assert "Wrote" in result.output
    assert "To activate" in result.output


def test_install_systemd_enable(tmp_path: Path) -> None:
    systemd_dir = tmp_path / "systemd"
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch("drasill.cli._systemctl") as mock_ctl,
    ):
        result = runner.invoke(
            app,
            ["install", "systemd", "--enable"],
        )
    assert result.exit_code == 0
    assert "enabled and started" in result.output
    assert mock_ctl.call_count == 2


def test_install_cloudflared_print_only() -> None:
    result = runner.invoke(
        app,
        ["install", "cloudflared", "--print-only"],
    )
    assert result.exit_code == 0
    assert "# cloudflared.service" in result.output
    assert "# cloudflared.yml" in result.output
    assert "<tunnel-id>" in result.output


def test_install_cloudflared_writes_files(tmp_path: Path) -> None:
    systemd_dir = tmp_path / "systemd"
    config_path = tmp_path / "cloudflared.yml"
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch("shutil.which", return_value=None),
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cloudflared",
                "--tunnel-config",
                str(config_path),
            ],
        )
    assert result.exit_code == 0
    assert config_path.exists()
    assert (systemd_dir / "cloudflared.service").exists()
    assert "cloudflared not found" in result.output


def test_install_cloudflared_existing_config(tmp_path: Path) -> None:
    systemd_dir = tmp_path / "systemd"
    config_path = tmp_path / "cloudflared.yml"
    config_path.write_text("existing config")
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch("shutil.which", return_value=None),
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cloudflared",
                "--tunnel-config",
                str(config_path),
            ],
        )
    assert result.exit_code == 0
    assert "Config exists" in result.output
    assert config_path.read_text() == "existing config"


def test_install_cloudflared_enable_placeholders(
    tmp_path: Path,
) -> None:
    systemd_dir = tmp_path / "systemd"
    config_path = tmp_path / "cloudflared.yml"
    config_path.write_text("tunnel: <tunnel-id>")
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch(
            "drasill.cli.shutil.which",
            return_value="/usr/local/bin/cloudflared",
        ),
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cloudflared",
                "--tunnel-config",
                str(config_path),
                "--enable",
            ],
        )
    assert result.exit_code == 0
    assert "placeholders" in result.output


def test_install_cloudflared_enable_ready(tmp_path: Path) -> None:
    systemd_dir = tmp_path / "systemd"
    config_path = tmp_path / "cloudflared.yml"
    config_path.write_text("tunnel: abc123")
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch(
            "drasill.cli.shutil.which",
            return_value="/usr/local/bin/cloudflared",
        ),
        patch("drasill.cli._systemctl") as mock_ctl,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cloudflared",
                "--tunnel-config",
                str(config_path),
                "--enable",
            ],
        )
    assert result.exit_code == 0
    assert "enabled and started" in result.output
    assert mock_ctl.call_count == 2


def test_install_cloudflared_no_enable(tmp_path: Path) -> None:
    systemd_dir = tmp_path / "systemd"
    config_path = tmp_path / "cloudflared.yml"
    config_path.write_text("tunnel: abc123")
    with (
        patch("drasill.cli._SYSTEMD_DIR", systemd_dir),
        patch(
            "drasill.cli.shutil.which",
            return_value="/usr/local/bin/cloudflared",
        ),
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cloudflared",
                "--tunnel-config",
                str(config_path),
            ],
        )
    assert result.exit_code == 0
    assert "To activate" in result.output


def test_serve_help() -> None:
    result = runner.invoke(app, ["serve", "--help"])
    assert result.exit_code == 0
    output = _strip_ansi(result.output)
    assert "--host" in output
    assert "--port" in output
    assert "--reload" in output
    assert "--config" in output


def test_drasill_bin_fallback() -> None:
    with patch("shutil.which", return_value=None):
        result = _drasill_bin()
        assert "drasill" in result


def test_drasill_bin_found() -> None:
    with patch(
        "shutil.which",
        return_value="/usr/local/bin/drasill",
    ):
        assert _drasill_bin() == "/usr/local/bin/drasill"


def test_systemd_unit_contents() -> None:
    unit = _systemd_unit("127.0.0.1", 9000, "/etc/drasill.toml")
    assert "ExecStart=" in unit
    assert "--host 127.0.0.1" in unit
    assert "--port 9000" in unit
    assert "DRASILL_CONFIG=/etc/drasill.toml" in unit


def test_systemd_unit_no_config() -> None:
    unit = _systemd_unit("0.0.0.0", 8400, None)
    assert "DRASILL_CONFIG" not in unit


def test_cloudflared_unit_contents() -> None:
    unit = _cloudflared_unit("/etc/cloudflared.yml")
    assert "cloudflared tunnel" in unit
    assert "/etc/cloudflared.yml" in unit


def test_cloudflared_yml_template() -> None:
    yml = _cloudflared_yml()
    assert "<tunnel-id>" in yml
    assert "<domain>" in yml
    assert "localhost:8400" in yml


def test_check_deps_all_found() -> None:
    def _always_found(name: str) -> str:
        return f"/usr/bin/{name}"

    with patch(
        "drasill.cli.shutil.which",
        side_effect=_always_found,
    ):
        result = runner.invoke(app, ["check-deps"])
    assert result.exit_code == 0
    assert "[ok]" in result.output
    assert "All required dependencies found" in result.output


def test_check_deps_missing_required() -> None:
    def _missing_uv(name: str) -> str | None:
        if name == "uv":
            return None
        return f"/usr/bin/{name}"

    with patch(
        "drasill.cli.shutil.which",
        side_effect=_missing_uv,
    ):
        result = runner.invoke(app, ["check-deps"])
    assert result.exit_code == 1
    assert "MISSING" in result.output
    assert "uv" in result.output


def test_check_deps_missing_optional() -> None:
    def _missing_optional(name: str) -> str | None:
        if name in {"cloudflared", "tailscale"}:
            return None
        return f"/usr/bin/{name}"

    with patch(
        "drasill.cli.shutil.which",
        side_effect=_missing_optional,
    ):
        result = runner.invoke(app, ["check-deps"])
    assert result.exit_code == 0
    assert "----" in result.output
    assert "All required dependencies found" in result.output


def test_main_calls_app() -> None:
    with patch("drasill.cli.app") as mock_app:
        main()
    mock_app.assert_called_once()


def test_serve_calls_uvicorn() -> None:
    with (
        patch("drasill.cli.uvicorn.run") as mock_run,
        patch("drasill.cli.create_app") as mock_create,
        patch("drasill.cli.load_config") as mock_load,
    ):
        mock_load.return_value = "cfg"
        mock_create.return_value = "app"
        result = runner.invoke(app, ["serve"])
    assert result.exit_code == 0
    mock_run.assert_called_once_with(
        "app",
        host="0.0.0.0",
        port=8400,
        reload=False,
    )


def test_serve_with_config(tmp_path: Path) -> None:
    cfg_file = tmp_path / "test.toml"
    cfg_file.write_text("[server]\nport = 9000\n")
    with (
        patch("drasill.cli.uvicorn.run"),
        patch("drasill.cli.create_app"),
        patch("drasill.cli.load_config"),
        patch.dict("os.environ", {}, clear=False),
    ):
        result = runner.invoke(
            app,
            ["serve", "--config", str(cfg_file)],
        )
    assert result.exit_code == 0


def test_systemctl_helper() -> None:
    with patch("drasill.cli.subprocess.run") as mock_run:
        _systemctl("daemon-reload")
    mock_run.assert_called_once_with(
        ["systemctl", "--user", "daemon-reload"],
        check=True,
    )


def test_reset_state_deletes_db(tmp_path: Path) -> None:
    db_file = tmp_path / "dash.db"
    db_file.write_text("fake")
    (tmp_path / "dash.db-wal").write_text("wal")
    (tmp_path / "dash.db-shm").write_text("shm")

    with patch("drasill.cli.load_config") as mock_cfg:
        mock_cfg.return_value = AppConfig(db=DbConfig(path=str(db_file)))
        result = runner.invoke(app, ["reset-state", "--force"])

    assert result.exit_code == 0
    assert not db_file.exists()
    assert not (tmp_path / "dash.db-wal").exists()
    assert not (tmp_path / "dash.db-shm").exists()
    assert "State reset" in result.output


def test_reset_state_no_db(tmp_path: Path) -> None:
    db_file = tmp_path / "nonexistent.db"

    with patch("drasill.cli.load_config") as mock_cfg:
        mock_cfg.return_value = AppConfig(db=DbConfig(path=str(db_file)))
        result = runner.invoke(app, ["reset-state", "--force"])

    assert result.exit_code == 0
    assert "Nothing to reset" in result.output


def test_reset_state_confirms(tmp_path: Path) -> None:
    db_file = tmp_path / "dash.db"
    db_file.write_text("fake")

    with patch("drasill.cli.load_config") as mock_cfg:
        mock_cfg.return_value = AppConfig(db=DbConfig(path=str(db_file)))
        # Decline the prompt
        result = runner.invoke(app, ["reset-state"], input="n\n")

    assert result.exit_code == 1
    assert db_file.exists()


def test_module_entry_point() -> None:
    main_path = Path(__file__).parent.parent / "py_src" / "drasill" / "__main__.py"
    content = main_path.read_text()
    assert "from drasill.cli import main" in content


# ── install hm ───────────────────────────────────────────────────────


def test_install_hm_unsupported_platform() -> None:
    """install hm fails on unsupported platform."""
    with (
        patch("platform.system", return_value="Windows"),
        patch("platform.machine", return_value="AMD64"),
    ):
        result = runner.invoke(app, ["install", "hm"])
    assert result.exit_code == 1
    assert "Unsupported platform" in result.output


def test_install_hm_target_detection() -> None:
    """Correct target string for known platforms."""

    assert _HM_TARGETS[("Linux", "x86_64")] == "x86_64-unknown-linux-gnu"
    assert _HM_TARGETS[("Linux", "aarch64")] == "aarch64-unknown-linux-gnu"
    assert _HM_TARGETS[("Darwin", "x86_64")] == "x86_64-apple-darwin"
    assert _HM_TARGETS[("Darwin", "arm64")] == "aarch64-apple-darwin"
