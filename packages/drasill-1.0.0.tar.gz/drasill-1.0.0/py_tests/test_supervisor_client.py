"""Tests for the heimdall supervisor client."""

from __future__ import annotations

import asyncio
import struct
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from drasill.supervisor_client import (
    EXIT,
    INPUT,
    KILL,
    MODE_BINARY,
    OUTPUT,
    RESIZE,
    STATUS,
    STATUS_RESP,
    SUBSCRIBE,
    _connect,
    _pack_frame,
    _read_frame,
    get_status,
    is_alive,
    list_sessions,
    send_input,
    send_kill,
    send_resize,
    subscribe,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator


# ---------------------------------------------------------------------------
# Helpers — tiny mock supervisor
# ---------------------------------------------------------------------------


async def _mock_supervisor(
    sock_path: Path,
    handler: asyncio.Future[tuple[int, bytes]] | None = None,
    *,
    response_frames: list[tuple[int, bytes]] | None = None,
) -> AsyncIterator[asyncio.Server]:
    """Run a mock supervisor that speaks the heimdall protocol.

    Sends the mode byte on connect, reads one frame, optionally responds.
    """

    async def _on_connect(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        # Send mode byte.
        writer.write(bytes([MODE_BINARY]))
        await writer.drain()

        # Read one frame from the client.
        try:
            header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
        except (asyncio.IncompleteReadError, TimeoutError):
            writer.close()
            return
        msg_type, length = struct.unpack(">BI", header)
        payload = await reader.readexactly(length) if length else b""

        if handler is not None and not handler.done():
            handler.set_result((msg_type, payload))

        # Send response frames if provided.
        if response_frames:
            for resp_type, resp_payload in response_frames:
                writer.write(_pack_frame(resp_type, resp_payload))
            await writer.drain()

        writer.close()
        await writer.wait_closed()

    server = await asyncio.start_unix_server(_on_connect, path=str(sock_path))
    yield server
    server.close()
    await server.wait_closed()


# ---------------------------------------------------------------------------
# Unit tests — frame encoding / decoding
# ---------------------------------------------------------------------------


def test_pack_frame_empty_payload() -> None:
    frame = _pack_frame(0x02)
    assert frame == b"\x02\x00\x00\x00\x00"


def test_pack_frame_with_payload() -> None:
    frame = _pack_frame(0x01, b"hello")
    assert frame == b"\x01\x00\x00\x00\x05hello"


async def test_read_frame_round_trip() -> None:
    frame = _pack_frame(0x81, b"output data")
    reader = asyncio.StreamReader()
    reader.feed_data(frame)
    msg_type, payload = await _read_frame(reader)
    assert msg_type == 0x81
    assert payload == b"output data"


async def test_read_frame_empty_payload() -> None:
    frame = _pack_frame(0x03)
    reader = asyncio.StreamReader()
    reader.feed_data(frame)
    msg_type, payload = await _read_frame(reader)
    assert msg_type == 0x03
    assert payload == b""


async def test_read_frame_incomplete_raises() -> None:
    reader = asyncio.StreamReader()
    reader.feed_data(b"\x01\x00")  # Incomplete header.
    reader.feed_eof()
    with pytest.raises(asyncio.IncompleteReadError):
        await _read_frame(reader)


# ---------------------------------------------------------------------------
# Constants sanity checks
# ---------------------------------------------------------------------------


def test_message_type_constants() -> None:
    """Client types < 0x80, server types >= 0x80."""
    assert INPUT == 0x01
    assert SUBSCRIBE == 0x02
    assert STATUS == 0x03
    assert RESIZE == 0x04
    assert KILL == 0x05
    assert OUTPUT == 0x81
    assert STATUS_RESP == 0x82
    assert EXIT == 0x83


# ---------------------------------------------------------------------------
# Integration tests — mock supervisor
# ---------------------------------------------------------------------------


async def test_connect_reads_mode_byte(tmp_path: Path) -> None:
    sock = tmp_path / "test.sock"
    async for _server in _mock_supervisor(sock):
        _reader, writer = await _connect("test", socket_dir=tmp_path)
        writer.close()
        await writer.wait_closed()
        break


async def test_connect_rejects_bad_mode(tmp_path: Path) -> None:
    sock = tmp_path / "test.sock"

    async def _bad_mode(
        _reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        writer.write(b"\xff")  # Bad mode byte.
        await writer.drain()
        writer.close()

    server = await asyncio.start_unix_server(_bad_mode, path=str(sock))
    try:
        with pytest.raises(ValueError, match="Unsupported protocol mode"):
            await _connect("test", socket_dir=tmp_path)
    finally:
        server.close()
        await server.wait_closed()


async def test_connect_missing_socket(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        await _connect("nonexistent", socket_dir=tmp_path)


async def test_send_input_delivers_frame(tmp_path: Path) -> None:
    sock = tmp_path / "alpha.sock"
    received = asyncio.get_event_loop().create_future()
    async for _server in _mock_supervisor(sock, handler=received):
        await send_input("alpha", b"ls -la\n", socket_dir=tmp_path)
        msg_type, payload = await asyncio.wait_for(received, timeout=2)
        assert msg_type == INPUT
        assert payload == b"ls -la\n"
        break


async def test_get_status_extended_response(tmp_path: Path) -> None:
    sock = tmp_path / "beta.sock"
    # Extended status: pid=42, idle=1500, alive=1, state=active, ms=800
    status_payload = struct.pack(">IIBBI", 42, 1500, 1, 0x04, 800) + b"\x00"
    async for _server in _mock_supervisor(
        sock,
        response_frames=[(STATUS_RESP, status_payload)],
    ):
        result = await get_status("beta", socket_dir=tmp_path)
        assert result["pid"] == 42
        assert result["idle_ms"] == 1500
        assert result["alive"] is True
        assert result["state"] == "active"
        assert result["state_ms"] == 800
        break


async def test_get_status_legacy_9byte(tmp_path: Path) -> None:
    sock = tmp_path / "legacy.sock"
    # Legacy 9-byte: no state fields.
    status_payload = struct.pack(">IIB", 42, 1500, 1)
    async for _server in _mock_supervisor(
        sock,
        response_frames=[(STATUS_RESP, status_payload)],
    ):
        result = await get_status("legacy", socket_dir=tmp_path)
        assert result == {"pid": 42, "idle_ms": 1500, "alive": True}
        assert "state" not in result
        break


async def test_get_status_dead_process(tmp_path: Path) -> None:
    sock = tmp_path / "dead.sock"
    status_payload = struct.pack(">IIBBI", 99, 30000, 0, 0xFF, 0) + b"\x00"
    async for _server in _mock_supervisor(
        sock,
        response_frames=[(STATUS_RESP, status_payload)],
    ):
        result = await get_status("dead", socket_dir=tmp_path)
        assert result["alive"] is False
        assert result["idle_ms"] == 30000
        assert result["state"] == "dead"
        break


async def test_get_status_bad_response(tmp_path: Path) -> None:
    sock = tmp_path / "bad.sock"
    # Wrong type byte.
    async for _server in _mock_supervisor(
        sock,
        response_frames=[(OUTPUT, b"wrong")],
    ):
        with pytest.raises(ValueError, match="Unexpected status response"):
            await get_status("bad", socket_dir=tmp_path)
        break


async def test_get_status_short_payload(tmp_path: Path) -> None:
    sock = tmp_path / "short.sock"
    # Correct type but wrong payload length.
    async for _server in _mock_supervisor(
        sock,
        response_frames=[(STATUS_RESP, b"\x00\x01")],
    ):
        with pytest.raises(ValueError, match="Unexpected status response"):
            await get_status("short", socket_dir=tmp_path)
        break


async def test_subscribe_sends_frame(tmp_path: Path) -> None:
    sock = tmp_path / "sub.sock"
    received = asyncio.get_event_loop().create_future()

    async def _on_connect(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        writer.write(bytes([MODE_BINARY]))
        await writer.drain()
        header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
        msg_type, length = struct.unpack(">BI", header)
        payload = await reader.readexactly(length) if length else b""
        if not received.done():
            received.set_result((msg_type, payload))
        # Send some output then exit.
        writer.write(_pack_frame(OUTPUT, b"hello"))
        writer.write(_pack_frame(EXIT, struct.pack(">i", 0)))
        await writer.drain()
        writer.close()

    server = await asyncio.start_unix_server(_on_connect, path=str(sock))
    try:
        reader, writer = await subscribe("sub", socket_dir=tmp_path)
        msg_type, _ = await asyncio.wait_for(received, timeout=2)
        assert msg_type == SUBSCRIBE

        # Read the output frame.
        out_type, out_payload = await _read_frame(reader)
        assert out_type == OUTPUT
        assert out_payload == b"hello"

        # Read the exit frame.
        exit_type, exit_payload = await _read_frame(reader)
        assert exit_type == EXIT
        assert struct.unpack(">i", exit_payload)[0] == 0

        writer.close()
        await writer.wait_closed()
    finally:
        server.close()
        await server.wait_closed()


async def test_send_resize_frame(tmp_path: Path) -> None:
    sock = tmp_path / "rsz.sock"

    frames_received: list[tuple[int, bytes]] = []

    async def _on_connect(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        writer.write(bytes([MODE_BINARY]))
        await writer.drain()
        # Read subscribe frame.
        header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
        msg_type, length = struct.unpack(">BI", header)
        payload = await reader.readexactly(length) if length else b""
        frames_received.append((msg_type, payload))
        # Read resize frame.
        try:
            header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
            msg_type, length = struct.unpack(">BI", header)
            payload = await reader.readexactly(length) if length else b""
            frames_received.append((msg_type, payload))
        except (asyncio.IncompleteReadError, TimeoutError):
            pass
        writer.close()

    server = await asyncio.start_unix_server(_on_connect, path=str(sock))
    try:
        _reader, writer = await subscribe("rsz", socket_dir=tmp_path)
        await send_resize(writer, 120, 40)
        writer.close()
        await writer.wait_closed()
        # Give the server a moment to process.
        await asyncio.sleep(0.1)
        assert len(frames_received) == 2
        assert frames_received[0][0] == SUBSCRIBE
        assert frames_received[1][0] == RESIZE
        cols, rows = struct.unpack(">HH", frames_received[1][1])
        assert cols == 120
        assert rows == 40
    finally:
        server.close()
        await server.wait_closed()


async def test_send_kill_delivers_frame(tmp_path: Path) -> None:
    sock = tmp_path / "killme.sock"
    received = asyncio.get_event_loop().create_future()
    async for _server in _mock_supervisor(sock, handler=received):
        await send_kill("killme", socket_dir=tmp_path)
        msg_type, payload = await asyncio.wait_for(received, timeout=2)
        assert msg_type == KILL
        assert payload == b""
        break


# ---------------------------------------------------------------------------
# Synchronous helpers
# ---------------------------------------------------------------------------


def test_is_alive_true(tmp_path: Path) -> None:
    (tmp_path / "live.sock").touch()
    assert is_alive("live", socket_dir=tmp_path) is True


def test_is_alive_false(tmp_path: Path) -> None:
    assert is_alive("gone", socket_dir=tmp_path) is False


def test_list_sessions_empty(tmp_path: Path) -> None:
    assert list_sessions(socket_dir=tmp_path) == []


def test_list_sessions_finds_sockets(tmp_path: Path) -> None:
    (tmp_path / "alpha.sock").touch()
    (tmp_path / "beta.sock").touch()
    (tmp_path / "gamma.pid").touch()  # Should be ignored.
    result = list_sessions(socket_dir=tmp_path)
    assert result == ["alpha", "beta"]


def test_list_sessions_missing_dir() -> None:
    result = list_sessions(socket_dir=Path("/nonexistent/dir/xyz"))
    assert result == []
