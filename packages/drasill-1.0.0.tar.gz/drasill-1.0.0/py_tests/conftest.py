"""Shared test fixtures."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from drasill.app import create_app
from drasill.config import AppConfig, DbConfig, ServerConfig

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from fastapi import FastAPI


def _find_hm() -> str | None:
    """Resolve the hm binary path.

    Priority: HM_BIN env var > ./bin/hm > PATH lookup.
    """
    env = os.environ.get("HM_BIN")
    if env:
        return env
    local = Path(__file__).resolve().parent.parent / "bin" / "hm"
    if local.is_file() and os.access(local, os.X_OK):
        return str(local)
    return shutil.which("hm")


@pytest.fixture(scope="session")
def hm_bin() -> str:
    """Path to the hm binary. Skip if not available."""
    path = _find_hm()
    if not path:
        pytest.skip("hm binary not found — run scripts/fetch-hm.sh or set HM_BIN")
    return path


@pytest.fixture
def tmp_db_path(tmp_path: Path) -> str:
    """Return a temporary database path."""
    return str(tmp_path / "test.db")


@pytest.fixture
def test_config(tmp_db_path: str) -> AppConfig:
    """Create an AppConfig pointing at a temp database."""
    return AppConfig(
        server=ServerConfig(host="127.0.0.1", port=8400),
        db=DbConfig(path=tmp_db_path),
    )


@pytest.fixture
async def app(test_config: AppConfig) -> AsyncIterator[FastAPI]:
    """Create a test FastAPI app with lifespan.

    Patches run_monitoring_loop to avoid the background task running
    during tests. Tests for monitoring call monitor_agents directly.
    """
    with patch("drasill.app.run_monitoring_loop", new_callable=AsyncMock):
        application = create_app(config=test_config)
        async with application.router.lifespan_context(application):
            yield application


@pytest.fixture
async def client(app: FastAPI) -> AsyncIterator[AsyncClient]:
    """Create an async HTTP test client."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
