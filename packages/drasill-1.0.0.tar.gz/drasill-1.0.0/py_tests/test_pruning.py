"""Tests for agent monitoring — heimdall probing and dead agent cleanup."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import sqlite3
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, patch

from drasill.config import PruningConfig
from drasill.db import insert_message, peek_next_message
from drasill.mesh.events import MeshEventBus
from drasill.mesh.pruning import (
    ProbeResult,
    _deliver_inbox_on_idle,
    _probe_agent,
    _probe_via_supervisor,
    monitor_agents,
    run_monitoring_loop,
)

if TYPE_CHECKING:
    import aiosqlite
    import pytest
    from fastapi import FastAPI
    from httpx import AsyncClient


def _ago(seconds: int) -> str:
    """Return an ISO timestamp `seconds` in the past."""
    return (datetime.now(tz=UTC) - timedelta(seconds=seconds)).isoformat()


async def _register_agent(  # noqa: PLR0913
    db: aiosqlite.Connection,
    name: str,
    *,
    pid: int | None = None,
    session_id: str | None = None,
    heartbeat_ago: int = 0,
    status: str = "active",
) -> None:
    """Insert an agent directly into the DB."""
    now = datetime.now(tz=UTC)
    hb = (now - timedelta(seconds=heartbeat_ago)).isoformat()
    await db.execute(
        "INSERT INTO mesh_agents "
        "(name, pid, session_id, registered_at, "
        "last_heartbeat, status, idle_timeout) "
        "VALUES (?, ?, ?, ?, ?, ?, 120)",
        (name, pid, session_id, now.isoformat(), hb, status),
    )
    await db.commit()


async def _send_message(
    db: aiosqlite.Connection,
    to_agent: str,
    from_agent: str,
    body: str,
) -> None:
    """Insert a message directly into the DB."""
    await db.execute(
        "INSERT INTO mesh_messages "
        "(to_agent, from_agent, body, priority, created_at) "
        "VALUES (?, ?, ?, 'normal', ?)",
        (to_agent, from_agent, body, datetime.now(tz=UTC).isoformat()),
    )
    await db.commit()


async def _get_status(db: aiosqlite.Connection, name: str) -> str | None:
    """Get agent status, or None if not found."""
    cursor = await db.execute(
        "SELECT status FROM mesh_agents WHERE name = ?",
        (name,),
    )
    row = await cursor.fetchone()
    return row[0] if row else None


async def _agent_exists(db: aiosqlite.Connection, name: str) -> bool:
    cursor = await db.execute(
        "SELECT name FROM mesh_agents WHERE name = ?",
        (name,),
    )
    return await cursor.fetchone() is not None


# --- heimdall session monitoring ---


async def test_dead_session_deregisters(app: FastAPI) -> None:
    """Agent with dead heimdall session is deregistered."""
    db = app.state.db
    await _register_agent(db, "gone", session_id="dead-sess")

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("dead", "dead"),
    ):
        await monitor_agents(db)

    assert not await _agent_exists(db, "gone")


async def test_active_session_stays(app: FastAPI) -> None:
    """Agent with active heimdall session stays registered."""
    db = app.state.db
    await _register_agent(db, "alive", session_id="alive-sess")

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("active", "active", 1500),
    ):
        await monitor_agents(db)

    assert await _agent_exists(db, "alive")


async def test_no_session_id_assumes_active(app: FastAPI) -> None:
    """Agent without session_id stays active (no supervisor to probe)."""
    db = app.state.db
    await _register_agent(db, "noid")

    await monitor_agents(db)

    assert await _get_status(db, "noid") == "active"


async def test_idle_session_marks_idle(app: FastAPI) -> None:
    """Agent whose heimdall session reports idle is marked idle."""
    db = app.state.db
    await _register_agent(
        db,
        "waiting",
        session_id="idle-sess",
        status="active",
    )

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("idle", "idle", 5000),
    ):
        await monitor_agents(db)

    assert await _get_status(db, "waiting") == "idle"


# --- Dead agent removal ---


async def test_dead_agent_removed(app: FastAPI) -> None:
    """Dead agent with old last_heartbeat is removed."""
    db = app.state.db
    await _register_agent(db, "ancient", heartbeat_ago=3700, status="dead")

    await monitor_agents(db)

    assert not await _agent_exists(db, "ancient")


async def test_dead_agent_stays_if_recent(app: FastAPI) -> None:
    """Dead agent with recent last_heartbeat is not removed."""
    db = app.state.db
    await _register_agent(db, "recent-dead", heartbeat_ago=300, status="dead")

    await monitor_agents(db)

    assert await _agent_exists(db, "recent-dead")


# --- Message cleanup ---


async def test_undelivered_messages_logged(
    app: FastAPI,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Unread messages to dead agents are logged before removal."""
    db = app.state.db
    await _register_agent(db, "dead-agent", heartbeat_ago=3700, status="dead")
    await _send_message(db, "dead-agent", "human", "you there?")

    with caplog.at_level(logging.WARNING):
        await monitor_agents(db)

    assert "Undeliverable" in caplog.text
    assert "dead-agent" in caplog.text


async def test_messages_cleaned_on_removal(app: FastAPI) -> None:
    """Messages to/from a removed agent are deleted."""
    db = app.state.db
    await _register_agent(db, "doomed", heartbeat_ago=3700, status="dead")
    await _register_agent(db, "alive-peer", session_id="alive-sess")
    await _send_message(db, "doomed", "alive-peer", "incoming")
    await _send_message(db, "alive-peer", "doomed", "outgoing")

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("active", "active"),
    ):
        await monitor_agents(db)

    cursor = await db.execute(
        "SELECT COUNT(*) FROM mesh_messages "
        "WHERE to_agent = 'doomed' OR from_agent = 'doomed'",
    )
    row = await cursor.fetchone()
    assert row[0] == 0


# --- Empty state ---


async def test_no_agents_no_error(app: FastAPI) -> None:
    """Monitoring with no agents does not error."""
    changed = await monitor_agents(app.state.db)
    assert changed is False


async def test_returns_true_on_change(app: FastAPI) -> None:
    """monitor_agents returns True when agents change state."""
    db = app.state.db
    await _register_agent(db, "stale", session_id="stale-sess")

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("dead", "dead"),
    ):
        changed = await monitor_agents(db)
    assert changed is True


# --- Monitoring loop ---


async def test_monitoring_loop_runs(app: FastAPI) -> None:
    """run_monitoring_loop calls monitor_agents and publishes on change."""
    bus = MeshEventBus()
    db = app.state.db
    fast_config = PruningConfig(interval=0.01)
    await _register_agent(db, "stale", session_id="stale-sess")

    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=ProbeResult("dead", "dead"),
    ):
        task = asyncio.create_task(
            run_monitoring_loop(db, bus, config=fast_config),
        )
        await asyncio.sleep(0.05)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    assert not await _agent_exists(db, "stale")


async def test_monitoring_loop_handles_errors(app: FastAPI) -> None:
    """run_monitoring_loop logs errors but keeps running."""
    bus = MeshEventBus()
    fast_config = PruningConfig(interval=0.01)
    call_count = 0

    async def _bad_monitor(
        _db: object,
        **_kw: object,
    ) -> bool:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            msg = "db error"
            raise RuntimeError(msg)
        return False

    with patch("drasill.mesh.pruning.monitor_agents", side_effect=_bad_monitor):
        task = asyncio.create_task(
            run_monitoring_loop(app.state.db, bus, config=fast_config),
        )
        await asyncio.sleep(0.05)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    assert call_count >= 2


async def test_monitoring_loop_handles_db_locked(app: FastAPI) -> None:
    """run_monitoring_loop logs a warning on DB locked."""
    bus = MeshEventBus()
    fast_config = PruningConfig(interval=0.01)
    call_count = 0

    async def _locked_monitor(
        _db: object,
        **_kw: object,
    ) -> bool:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            msg = "database is locked"
            raise sqlite3.OperationalError(msg)
        return False

    with patch("drasill.mesh.pruning.monitor_agents", side_effect=_locked_monitor):
        task = asyncio.create_task(
            run_monitoring_loop(app.state.db, bus, config=fast_config),
        )
        await asyncio.sleep(0.05)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    assert call_count >= 2


# --- Registration ---


async def test_register_with_custom_timeout(client: AsyncClient) -> None:
    """Registration with idle_timeout persists the value."""
    resp = await client.post(
        "/mesh/agents",
        json={"name": "patient", "idle_timeout": 600},
    )
    assert resp.status_code == 201

    resp = await client.get("/mesh/agents/patient")
    assert resp.json()["idle_timeout"] == 600


async def test_register_default_timeout(client: AsyncClient) -> None:
    """Registration without idle_timeout uses default 120s."""
    await client.post("/mesh/agents", json={"name": "default"})
    resp = await client.get("/mesh/agents/default")
    assert resp.json()["idle_timeout"] == 120


async def test_register_timeout_validation(client: AsyncClient) -> None:
    """idle_timeout below 30 or above 3600 is rejected."""
    resp = await client.post(
        "/mesh/agents",
        json={"name": "too-fast", "idle_timeout": 10},
    )
    assert resp.status_code == 422

    resp = await client.post(
        "/mesh/agents",
        json={"name": "too-slow", "idle_timeout": 7200},
    )
    assert resp.status_code == 422


# --- _probe_via_supervisor ---


async def test_probe_via_supervisor_socket_not_alive() -> None:
    """_probe_via_supervisor returns dead when sup_is_alive returns False."""
    with patch("drasill.mesh.pruning.sup_is_alive", return_value=False):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "dead"


async def test_probe_via_supervisor_get_status_oserror() -> None:
    """_probe_via_supervisor returns dead when get_status raises OSError."""
    with (
        patch("drasill.mesh.pruning.sup_is_alive", return_value=True),
        patch(
            "drasill.mesh.pruning.get_status",
            new_callable=AsyncMock,
            side_effect=OSError("no socket"),
        ),
    ):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "dead"


async def test_probe_via_supervisor_alive_false() -> None:
    """_probe_via_supervisor returns dead when status['alive'] is False."""
    with (
        patch("drasill.mesh.pruning.sup_is_alive", return_value=True),
        patch(
            "drasill.mesh.pruning.get_status",
            new_callable=AsyncMock,
            return_value={"alive": False, "idle_ms": 0, "pid": 123},
        ),
    ):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "dead"


async def test_probe_via_supervisor_with_state() -> None:
    """_probe_via_supervisor returns agent_state from extended status."""
    with (
        patch("drasill.mesh.pruning.sup_is_alive", return_value=True),
        patch(
            "drasill.mesh.pruning.get_status",
            new_callable=AsyncMock,
            return_value={
                "alive": True,
                "idle_ms": 500,
                "pid": 123,
                "state": "active",
                "state_ms": 1200,
            },
        ),
    ):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "active"
    assert result.agent_state == "active"
    assert result.state_ms == 1200


async def test_probe_via_supervisor_idle_state() -> None:
    """_probe_via_supervisor returns idle when heimdall reports idle state."""
    with (
        patch("drasill.mesh.pruning.sup_is_alive", return_value=True),
        patch(
            "drasill.mesh.pruning.get_status",
            new_callable=AsyncMock,
            return_value={
                "alive": True,
                "idle_ms": 5000,
                "pid": 123,
                "state": "idle",
                "state_ms": 5000,
            },
        ),
    ):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "idle"
    assert result.agent_state == "idle"


async def test_probe_via_supervisor_no_state_field() -> None:
    """_probe_via_supervisor treats missing state as active (defensive)."""
    with (
        patch("drasill.mesh.pruning.sup_is_alive", return_value=True),
        patch(
            "drasill.mesh.pruning.get_status",
            new_callable=AsyncMock,
            return_value={"alive": True, "idle_ms": 500, "pid": 123},
        ),
    ):
        result = await _probe_via_supervisor("sess-abc")
    assert result.status == "active"
    assert result.agent_state == "active"  # defensive default


# --- _probe_agent dispatch ---


async def test_probe_agent_uses_supervisor_when_session_id_present() -> None:
    """_probe_agent delegates to _probe_via_supervisor when session_id is set."""
    agent = {"name": "sess-agent", "session_id": "sess-xyz"}
    probe_result = ProbeResult("idle", "idle", 5000)
    with patch(
        "drasill.mesh.pruning._probe_via_supervisor",
        new_callable=AsyncMock,
        return_value=probe_result,
    ) as mock_sup:
        result = await _probe_agent(agent)
    mock_sup.assert_awaited_once_with("sess-xyz")
    assert result.status == "idle"
    assert result.agent_state == "idle"


async def test_probe_agent_returns_active_without_session_id() -> None:
    """_probe_agent returns 'active' when agent has no session_id."""
    agent = {"name": "no-session"}
    result = await _probe_agent(agent)
    assert result.status == "active"


# --- Idle wake (message delivery on active→idle transition) ---


async def test_idle_wake_delivers_message(app: FastAPI) -> None:
    """When agent transitions active→idle, inbox messages are delivered via stdin."""
    db = app.state.db

    await _register_agent(db, "wake-target", session_id="wake-sess")

    # Insert a message into the inbox.

    await insert_message(
        db, to_agent="wake-target", from_agent="peer", body="do the thing"
    )

    agent = {"name": "wake-target", "session_id": "wake-sess", "status": "active"}

    with patch("drasill.mesh.pruning.send_input", new_callable=AsyncMock) as mock_send:
        await _deliver_inbox_on_idle(db, agent)

    mock_send.assert_called_once()
    call_args = mock_send.call_args
    data = call_args.args[1]  # second positional arg is the bytes
    assert b"drasill:message from peer" in data
    assert b"do the thing" in data


async def test_idle_wake_no_message_no_call(app: FastAPI) -> None:
    """No stdin write when inbox is empty."""
    db = app.state.db

    await _register_agent(db, "empty-inbox", session_id="empty-sess")
    agent = {"name": "empty-inbox", "session_id": "empty-sess", "status": "active"}

    with patch("drasill.mesh.pruning.send_input", new_callable=AsyncMock) as mock_send:
        await _deliver_inbox_on_idle(db, agent)

    mock_send.assert_not_called()


async def test_idle_wake_no_session_no_call(app: FastAPI) -> None:
    """No stdin write when agent has no session_id."""
    db = app.state.db

    await _register_agent(db, "no-sess-agent")
    agent = {"name": "no-sess-agent", "session_id": None, "status": "active"}

    with patch("drasill.mesh.pruning.send_input", new_callable=AsyncMock) as mock_send:
        await _deliver_inbox_on_idle(db, agent)

    mock_send.assert_not_called()


async def test_idle_wake_oserror_preserves_message(app: FastAPI) -> None:
    """On delivery failure, message stays in inbox for retry."""
    db = app.state.db

    await _register_agent(db, "unreachable", session_id="dead-sess")
    await insert_message(
        db,
        to_agent="unreachable",
        from_agent="peer",
        body="hello",
    )

    agent = {"name": "unreachable", "session_id": "dead-sess", "status": "active"}

    with patch(
        "drasill.mesh.pruning.send_input",
        new_callable=AsyncMock,
        side_effect=OSError("connection refused"),
    ):
        await _deliver_inbox_on_idle(db, agent)

    # Message should still be in inbox (not consumed).
    msg = await peek_next_message(db, "unreachable")
    assert msg is not None
    assert msg["body"] == "hello"


async def test_idle_wake_valueerror_handled(app: FastAPI) -> None:
    """ValueError from send_input (mode byte mismatch) is caught."""
    db = app.state.db

    await _register_agent(db, "bad-mode", session_id="bad-sess")
    await insert_message(
        db,
        to_agent="bad-mode",
        from_agent="peer",
        body="test",
    )

    agent = {"name": "bad-mode", "session_id": "bad-sess", "status": "active"}

    with patch(
        "drasill.mesh.pruning.send_input",
        new_callable=AsyncMock,
        side_effect=ValueError("unexpected mode byte"),
    ):
        await _deliver_inbox_on_idle(db, agent)

    # Message preserved on failure.
    msg = await peek_next_message(db, "bad-mode")
    assert msg is not None
