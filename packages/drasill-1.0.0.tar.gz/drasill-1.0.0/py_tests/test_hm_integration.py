"""Integration tests using a real heimdall (hm) binary.

These tests require the `hm` binary to be available — either via:
- HM_BIN env var pointing to the binary
- ./bin/hm (downloaded via scripts/fetch-hm.sh)
- hm on PATH

Skipped automatically if hm is not found.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import signal
import struct
import subprocess
import time
from typing import TYPE_CHECKING

import pytest

from drasill.supervisor_client import get_status, is_alive, list_sessions

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    """Temporary directory for session sockets."""
    return tmp_path / "sessions"


def _wait_for_socket(sock_path: Path, timeout: float = 5.0) -> bool:
    """Poll until a socket file appears."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if sock_path.exists():
            return True
        time.sleep(0.05)
    return False


def _read_pid(pid_path: Path) -> int | None:
    """Read the supervisor PID (line 1) from a pid file."""
    try:
        return int(pid_path.read_text().splitlines()[0].strip())
    except (FileNotFoundError, ValueError, IndexError):
        return None


def _kill_session(session_dir: Path, session_id: str) -> None:
    """Kill a session supervisor by PID file."""
    pid = _read_pid(session_dir / f"{session_id}.pid")
    if pid:
        with contextlib.suppress(ProcessLookupError):
            os.kill(pid, signal.SIGTERM)


def _start_session(
    hm_bin: str,
    session_dir: Path,
    sid: str,
    cmd: list[str] | None = None,
) -> subprocess.Popen[bytes]:
    """Start a detached hm session and wait for the socket."""
    session_dir.mkdir(parents=True, exist_ok=True)
    proc = subprocess.Popen(
        [
            hm_bin,
            "run",
            "--detach",
            "--id",
            sid,
            "--socket-dir",
            str(session_dir),
            "--classifier",
            "simple",
            "--",
            *(cmd or ["sleep", "30"]),
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    sock = session_dir / f"{sid}.sock"
    if not _wait_for_socket(sock):
        proc.kill()
        proc.wait()
        msg = f"Socket never appeared: {sock}"
        raise RuntimeError(msg)
    return proc


# ── Basic lifecycle ──────────────────────────────────────────────────


class TestHmLifecycle:
    """Verify hm starts, runs, and stops correctly."""

    def test_detached_session_creates_socket(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """hm run --detach creates a socket file."""
        sid = "lifecycle-sock"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            assert (session_dir / f"{sid}.sock").exists()
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_detached_session_creates_pid_file(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """hm run --detach creates a two-line PID file."""
        sid = "lifecycle-pid"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            pid_path = session_dir / f"{sid}.pid"
            assert pid_path.exists()
            lines = pid_path.read_text().splitlines()
            assert len(lines) >= 1
            sup_pid = int(lines[0].strip())
            assert sup_pid > 0
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_kill_removes_socket(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """hm kill removes the socket file."""
        sid = "lifecycle-kill"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            subprocess.run(
                [hm_bin, "kill", "--socket-dir", str(session_dir), sid],
                check=True,
                timeout=10,
            )
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                if not (session_dir / f"{sid}.sock").exists():
                    break
                time.sleep(0.1)
            assert not (session_dir / f"{sid}.sock").exists()
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)


# ── Status protocol ──────────────────────────────────────────────────


class TestHmStatus:
    """Verify the status protocol over a real socket."""

    def test_status_returns_valid_response(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """Query status over socket and verify response format."""
        sid = "status-proto"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            result = asyncio.run(
                _query_status(session_dir / f"{sid}.sock"),
            )
            assert result["pid"] > 0
            assert result["alive"] == 1  # raw byte, not bool
            assert result["state"] in (0x00, 0x04)  # idle or active
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)


async def _query_status(sock_path: Path) -> dict:
    """Low-level status query over raw socket."""
    reader, writer = await asyncio.open_unix_connection(str(sock_path))
    try:
        mode = await asyncio.wait_for(reader.readexactly(1), timeout=5)
        assert mode == b"\x00"

        writer.write(struct.pack(">BI", 0x03, 0))
        await writer.drain()

        header = await asyncio.wait_for(reader.readexactly(5), timeout=5)
        resp_type = header[0]
        resp_len = struct.unpack(">I", header[1:5])[0]
        assert resp_type == 0x82
        assert resp_len == 15

        payload = await asyncio.wait_for(reader.readexactly(15), timeout=5)
        pid = struct.unpack(">I", payload[0:4])[0]
        alive = payload[8]
        state = payload[9]
        return {"pid": pid, "alive": alive, "state": state}
    finally:
        writer.close()
        await writer.wait_closed()


# ── Supervisor client integration ────────────────────────────────────


class TestSupervisorClient:
    """Test the Python supervisor_client against a real hm session."""

    def test_get_status_real(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """supervisor_client.get_status() works against real hm."""
        sid = "client-status"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            status = asyncio.run(get_status(sid, socket_dir=session_dir))
            assert status["pid"] > 0
            assert status["alive"] is True
            assert status["state"] in ("idle", "active")
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_list_sessions_real(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """supervisor_client.list_sessions() finds real sessions."""
        sid = "client-list"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            sessions = list_sessions(socket_dir=session_dir)
            assert sid in sessions
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_is_alive_real(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """supervisor_client.is_alive() returns True for live session."""
        sid = "client-alive"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            assert is_alive(sid, socket_dir=session_dir)
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

        time.sleep(1)
        assert not is_alive(sid, socket_dir=session_dir)


# ── Subscribe, input, kill ───────────────────────────────────────────


class TestHmRealtimePaths:
    """Test subscribe, input forwarding, and kill via real hm."""

    def test_subscribe_receives_output(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """Subscribe to a session and receive OUTPUT frames."""
        sid = "rt-subscribe"
        proc = _start_session(
            hm_bin,
            session_dir,
            sid,
            cmd=["bash", "-c", "echo SUBSCRIBE_MARKER && sleep 30"],
        )
        try:
            result = asyncio.run(_subscribe_and_read(session_dir / f"{sid}.sock"))
            assert b"SUBSCRIBE_MARKER" in result
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_input_reaches_child(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """Send INPUT frames and verify the child receives them."""
        sid = "rt-input"
        proc = _start_session(hm_bin, session_dir, sid, cmd=["bash"])
        try:
            result = asyncio.run(
                _send_input_and_read(
                    session_dir / f"{sid}.sock",
                    b"echo INPUT_ROUNDTRIP_OK\n",
                ),
            )
            assert b"INPUT_ROUNDTRIP_OK" in result
        finally:
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)

    def test_kill_produces_exit_frame(
        self,
        hm_bin: str,
        session_dir: Path,
    ) -> None:
        """Send KILL frame and receive EXIT frame on subscription."""
        sid = "rt-kill"
        proc = _start_session(hm_bin, session_dir, sid)
        try:
            got_exit = asyncio.run(_kill_and_wait_exit(session_dir / f"{sid}.sock"))
            assert got_exit, "should have received EXIT frame after KILL"
        finally:
            # Session should already be dead, but clean up just in case.
            _kill_session(session_dir, sid)
            proc.wait(timeout=10)


async def _subscribe_and_read(sock_path: Path) -> bytes:
    """Subscribe and collect output until marker or timeout."""
    reader, writer = await asyncio.open_unix_connection(str(sock_path))
    try:
        await asyncio.wait_for(reader.readexactly(1), timeout=5)  # mode byte
        writer.write(struct.pack(">BI", 0x02, 0))
        await writer.drain()
        buf = bytearray()
        for _ in range(100):
            header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
            msg_type = header[0]
            length = struct.unpack(">I", header[1:5])[0]
            if length:
                payload = await asyncio.wait_for(
                    reader.readexactly(length),
                    timeout=2,
                )
            else:
                payload = b""
            if msg_type == 0x81:  # OUTPUT
                buf.extend(payload)
                if b"MARKER" in buf:
                    break
            elif msg_type == 0x83:  # EXIT
                break
        return bytes(buf)
    finally:
        writer.close()
        await writer.wait_closed()


async def _send_input_and_read(sock_path: Path, data: bytes) -> bytes:
    """Subscribe, send input, read output until marker."""
    reader, writer = await asyncio.open_unix_connection(str(sock_path))
    try:
        await asyncio.wait_for(reader.readexactly(1), timeout=5)  # mode byte
        # Subscribe
        writer.write(struct.pack(">BI", 0x02, 0))
        await writer.drain()
        # Drain initial scrollback/output for ~1s
        await asyncio.sleep(1)
        # Send INPUT frame
        writer.write(struct.pack(">BI", 0x01, len(data)) + data)
        await writer.drain()
        # Read output
        buf = bytearray()
        for _ in range(50):
            try:
                header = await asyncio.wait_for(reader.readexactly(5), timeout=2)
            except TimeoutError:
                break
            msg_type = header[0]
            length = struct.unpack(">I", header[1:5])[0]
            if length:
                payload = await asyncio.wait_for(
                    reader.readexactly(length),
                    timeout=2,
                )
            else:
                payload = b""
            if msg_type == 0x81:
                buf.extend(payload)
                if b"ROUNDTRIP" in buf:
                    break
        return bytes(buf)
    finally:
        writer.close()
        await writer.wait_closed()


async def _kill_and_wait_exit(sock_path: Path) -> bool:
    """Subscribe, send KILL, wait for EXIT frame."""
    reader, writer = await asyncio.open_unix_connection(str(sock_path))
    try:
        await asyncio.wait_for(reader.readexactly(1), timeout=5)  # mode byte
        # Subscribe
        writer.write(struct.pack(">BI", 0x02, 0))
        await writer.drain()
        await asyncio.sleep(0.5)
        # Send KILL frame
        writer.write(struct.pack(">BI", 0x05, 0))
        await writer.drain()
        # Wait for EXIT frame
        for _ in range(50):
            try:
                header = await asyncio.wait_for(reader.readexactly(5), timeout=5)
            except (TimeoutError, asyncio.IncompleteReadError):
                return False
            msg_type = header[0]
            length = struct.unpack(">I", header[1:5])[0]
            if length:
                await asyncio.wait_for(reader.readexactly(length), timeout=2)
            if msg_type == 0x83:  # EXIT
                return True
        return False
    finally:
        writer.close()
        await writer.wait_closed()
