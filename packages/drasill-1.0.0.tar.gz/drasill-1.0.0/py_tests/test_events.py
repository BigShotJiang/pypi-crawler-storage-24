"""Tests for the SSE event bus."""

from __future__ import annotations

import asyncio

from drasill.mesh.events import MeshEventBus


async def test_publish_subscribe() -> None:
    """Published events are received by subscribers."""
    bus = MeshEventBus()
    received: list[str] = []

    async def _consumer() -> None:
        async for event in bus.subscribe():
            received.append(event)
            if len(received) == 2:
                break

    task = asyncio.create_task(_consumer())
    await asyncio.sleep(0.01)

    bus.publish("refresh")
    bus.publish("refresh")

    await asyncio.wait_for(task, timeout=1)
    assert received == ["refresh", "refresh"]


async def test_multiple_subscribers() -> None:
    """All subscribers receive every event."""
    bus = MeshEventBus()
    results_a: list[str] = []
    results_b: list[str] = []

    async def _consumer(out: list[str]) -> None:
        async for event in bus.subscribe():
            out.append(event)
            break

    task_a = asyncio.create_task(_consumer(results_a))
    task_b = asyncio.create_task(_consumer(results_b))
    await asyncio.sleep(0.01)

    bus.publish("refresh")

    await asyncio.wait_for(asyncio.gather(task_a, task_b), timeout=1)
    assert results_a == ["refresh"]
    assert results_b == ["refresh"]


async def test_subscriber_count() -> None:
    """subscriber_count tracks active subscribers."""
    bus = MeshEventBus()
    assert bus.subscriber_count == 0

    async def _sub() -> None:
        async for _ in bus.subscribe():
            break

    task = asyncio.create_task(_sub())
    await asyncio.sleep(0.01)
    assert bus.subscriber_count == 1

    bus.publish("done")
    await asyncio.wait_for(task, timeout=1)
    await asyncio.sleep(0.01)
    assert bus.subscriber_count == 0


async def test_publish_no_subscribers() -> None:
    """Publishing with no subscribers does not raise."""
    bus = MeshEventBus()
    bus.publish("refresh")


async def test_full_queue_drops_event() -> None:
    """Events are dropped when subscriber queue is full."""
    bus = MeshEventBus()

    async def _slow_consumer() -> None:
        async for _ in bus.subscribe():
            break

    task = asyncio.create_task(_slow_consumer())
    await asyncio.sleep(0.01)

    # Fill the queue (maxsize=64)
    for _ in range(70):
        bus.publish("refresh")

    # Consumer should still be able to get at least one
    bus.publish("final")
    await asyncio.wait_for(task, timeout=1)
