"""Tests for the Claude Code CLI wrapper."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from drasill.claude import (
    ClaudeError,
    ClaudeOptions,
    ClaudeResponse,
    _build_cmd,
    claude_query,
)


def _mock_process(
    returncode: int = 0,
    stdout: bytes = b"",
    stderr: bytes = b"",
) -> AsyncMock:
    """Create a mock async subprocess."""
    proc = AsyncMock()
    proc.returncode = returncode
    proc.communicate = AsyncMock(return_value=(stdout, stderr))
    proc.kill = AsyncMock()
    return proc


def test_build_cmd_defaults() -> None:
    """Default options produce minimal CLI args."""
    cmd = _build_cmd("hello", ClaudeOptions())
    assert cmd[:3] == ["claude", "-p", "hello"]
    assert "--output-format" in cmd
    assert "--max-turns" in cmd


def test_build_cmd_with_tools() -> None:
    """Allowed tools are joined with commas."""
    opts = ClaudeOptions(allowed_tools=["Read", "Bash"])
    cmd = _build_cmd("x", opts)
    assert "--allowedTools" in cmd
    idx = cmd.index("--allowedTools")
    assert cmd[idx + 1] == "Read,Bash"


def test_build_cmd_with_schema() -> None:
    """JSON schema is serialised into the command."""
    schema = {"type": "object", "properties": {"n": {"type": "string"}}}
    opts = ClaudeOptions(json_schema=schema)
    cmd = _build_cmd("x", opts)
    idx = cmd.index("--json-schema")
    assert json.loads(cmd[idx + 1]) == schema


def test_build_cmd_with_resume() -> None:
    """Resume session ID is passed through."""
    opts = ClaudeOptions(resume_session="sess-1")
    cmd = _build_cmd("x", opts)
    assert "--resume" in cmd
    assert "sess-1" in cmd


async def test_successful_query() -> None:
    """A successful claude invocation returns parsed response."""
    payload = {
        "result": "hello world",
        "session_id": "abc123",
        "usage": {"tokens": 10},
    }
    proc = _mock_process(stdout=json.dumps(payload).encode())

    with patch(
        "drasill.claude.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        resp = await claude_query("test prompt")

    assert isinstance(resp, ClaudeResponse)
    assert resp.result == "hello world"
    assert resp.session_id == "abc123"
    assert resp.usage == {"tokens": 10}


async def test_query_default_opts() -> None:
    """Passing no opts uses defaults."""
    payload = {"result": "ok", "session_id": "", "usage": {}}
    proc = _mock_process(stdout=json.dumps(payload).encode())

    with patch(
        "drasill.claude.asyncio.create_subprocess_exec",
        return_value=proc,
    ) as mock_exec:
        await claude_query("prompt")

    args = mock_exec.call_args[0]
    assert "claude" in args
    assert "--max-turns" in args


async def test_nonzero_exit_raises_claude_error() -> None:
    """A non-zero exit code raises ClaudeError."""
    proc = _mock_process(returncode=1, stderr=b"something broke")

    with (
        patch(
            "drasill.claude.asyncio.create_subprocess_exec",
            return_value=proc,
        ),
        pytest.raises(ClaudeError, match="something broke"),
    ):
        await claude_query("bad prompt")


async def test_timeout_raises() -> None:
    """Exceeding the timeout kills the process and raises TimeoutError."""
    proc = AsyncMock()
    proc.communicate = AsyncMock(side_effect=TimeoutError)
    proc.kill = AsyncMock()

    with (
        patch(
            "drasill.claude.asyncio.create_subprocess_exec",
            return_value=proc,
        ),
        patch(
            "drasill.claude.asyncio.wait_for",
            side_effect=TimeoutError,
        ),
        pytest.raises(TimeoutError),
    ):
        await claude_query(
            "slow prompt",
            ClaudeOptions(timeout_seconds=0.1),
        )
