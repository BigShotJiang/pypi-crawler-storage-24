"""Tests for the terminal WebSocket proxy and session creation."""

from __future__ import annotations

import asyncio
import struct
from io import BytesIO
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import WebSocketDisconnect
from starlette.testclient import TestClient
from starlette.websockets import WebSocketState

from drasill.app import create_app
from drasill.config import AppConfig, DbConfig
from drasill.supervisor_client import EXIT as EXIT_TYPE
from drasill.supervisor_client import OUTPUT as OUTPUT_TYPE
from drasill.supervisor_client import _pack_frame
from drasill.terminal.router import (
    _build_mesh_prompt,
    _git_session_name,
    _relay_input,
    _relay_output,
    _sanitize_session_name,
    _wait_for_socket,
    _ws_via_supervisor,
)

if TYPE_CHECKING:
    from httpx import AsyncClient


# =====================================================================
# WebSocket routing tests
# =====================================================================


async def test_terminal_ws_unknown_agent() -> None:
    config = AppConfig(db=DbConfig(path=":memory:"))
    app = create_app(config)

    with (
        TestClient(app) as tc,
        pytest.raises(Exception),  # noqa: B017, PT011
        tc.websocket_connect("/terminal/nonexistent/ws"),
    ):
        pass


# =====================================================================
# Session name helpers
# =====================================================================


def test_sanitize_session_name() -> None:
    assert _sanitize_session_name("my-project") == "my-project"
    assert _sanitize_session_name("repo:branch") == "repo_branch"
    assert _sanitize_session_name("a.b.c") == "a_b_c"
    assert _sanitize_session_name("hello world!") == "hello_world"
    assert _sanitize_session_name("") == "unnamed"
    assert _sanitize_session_name("///") == "unnamed"
    assert _sanitize_session_name("__test__") == "test"


@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_git_session_name_not_git(mock_exec: AsyncMock) -> None:
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 128
    mock_exec.return_value = mock_proc
    assert await _git_session_name("/tmp") is None


@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_git_session_name_with_remote(mock_exec: AsyncMock) -> None:
    async def _side_effect(*args: object, **_kw: object) -> AsyncMock:
        proc = AsyncMock()
        if "rev-parse" in args and "--is-inside-work-tree" in args:
            proc.communicate.return_value = (b"true\n", b"")
            proc.returncode = 0
        elif "get-url" in args:
            proc.communicate.return_value = (
                b"https://github.com/user/my-repo.git\n",
                b"",
            )
            proc.returncode = 0
        elif "--show-current" in args:
            proc.communicate.return_value = (b"feat/cool\n", b"")
            proc.returncode = 0
        else:
            proc.communicate.return_value = (b"", b"")
            proc.returncode = 0
        return proc

    mock_exec.side_effect = _side_effect
    result = await _git_session_name("/some/dir")
    assert result == "my-repo_feat/cool"


@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_git_session_name_no_remote(mock_exec: AsyncMock) -> None:
    async def _side_effect(*args: object, **_kw: object) -> AsyncMock:
        proc = AsyncMock()
        if "--is-inside-work-tree" in args:
            proc.communicate.return_value = (b"true\n", b"")
            proc.returncode = 0
        elif "get-url" in args:
            proc.communicate.return_value = (b"", b"")
            proc.returncode = 1
        elif "--show-toplevel" in args:
            proc.communicate.return_value = (b"/home/user/myproject\n", b"")
            proc.returncode = 0
        elif "--show-current" in args:
            proc.communicate.return_value = (b"main\n", b"")
            proc.returncode = 0
        else:
            proc.communicate.return_value = (b"", b"")
            proc.returncode = 0
        return proc

    mock_exec.side_effect = _side_effect
    result = await _git_session_name("/home/user/myproject")
    assert result == "myproject_main"


# =====================================================================
# Session creation tests (heimdall)
# =====================================================================


@patch("drasill.terminal.router._wait_for_socket", return_value=True)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value=None)
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_success(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST /terminal/sessions creates a heimdall session and registers agent."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={"name": "test-sess", "directory": "/tmp"},
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["name"] == "test-sess"
    assert data["session_id"] == "test-sess"

    # Verify agent was registered with session_id
    agent_resp = await client.get("/mesh/agents")
    agents = agent_resp.json()["agents"]
    agent = next(a for a in agents if a["name"] == "test-sess")
    assert agent["session_id"] == "test-sess"

    await client.delete("/mesh/agents/test-sess")


@patch("drasill.terminal.router.is_alive", return_value=True)
async def test_create_session_conflict(
    mock_alive: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST /terminal/sessions returns 409 if session already running."""
    resp = await client.post(
        "/terminal/sessions",
        json={"name": "existing", "directory": "/tmp"},
    )
    assert resp.status_code == 409
    assert "already exists" in resp.json()["error"]


async def test_create_session_bad_dir(client: AsyncClient) -> None:
    resp = await client.post(
        "/terminal/sessions",
        json={"name": "bad", "directory": "/nonexistent/path/xyz"},
    )
    assert resp.status_code == 400


@patch("drasill.terminal.router._wait_for_socket", return_value=False)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value=None)
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_supervisor_failure(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST returns 500 when supervisor fails to start."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"supervisor error output")
    mock_proc.returncode = 1
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={"name": "fail-sess", "directory": "/tmp"},
    )
    assert resp.status_code == 500
    assert "Supervisor failed to start" in resp.json()["error"]


@patch("drasill.terminal.router._wait_for_socket", return_value=True)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value=None)
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_auto_name_from_dir(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST without name falls back to directory name."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={"directory": "/tmp"},
    )
    assert resp.status_code == 201
    assert resp.json()["name"] == "tmp"

    await client.delete(f"/mesh/agents/{resp.json()['name']}")


@patch("drasill.terminal.router._wait_for_socket", return_value=True)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value="my-repo_main")
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_auto_name_from_git(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST without name falls back to git-derived name."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={"directory": "/tmp"},
    )
    assert resp.status_code == 201
    assert resp.json()["name"] == "my-repo_main"

    await client.delete(f"/mesh/agents/{resp.json()['name']}")


@patch("drasill.terminal.router._wait_for_socket", return_value=True)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value=None)
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_with_flags(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """POST with continue_session and dangerous_mode flags."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={
            "name": "flag-sess",
            "directory": "/tmp",
            "continue_session": True,
            "dangerous_mode": True,
        },
    )
    assert resp.status_code == 201

    # Verify the heimdall launch included the flags
    heimdall_call = mock_exec.call_args
    args = heimdall_call.args
    assert "--continue" in args
    assert "--dangerously-skip-permissions" in args

    await client.delete("/mesh/agents/flag-sess")


@patch("drasill.terminal.router._wait_for_socket", return_value=True)
@patch("drasill.terminal.router.is_alive", return_value=False)
@patch("drasill.terminal.router._git_session_name", return_value=None)
@patch("drasill.terminal.router.asyncio.create_subprocess_exec")
async def test_create_session_injects_mesh_prompt(
    mock_exec: AsyncMock,
    mock_git: AsyncMock,  # noqa: ARG001
    mock_alive: AsyncMock,  # noqa: ARG001
    mock_wait: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """Session creation injects mesh awareness system prompt."""
    mock_proc = AsyncMock()
    mock_proc.communicate.return_value = (b"", b"")
    mock_proc.returncode = 0
    mock_exec.return_value = mock_proc

    resp = await client.post(
        "/terminal/sessions",
        json={"name": "prompt-test", "directory": "/tmp"},
    )
    assert resp.status_code == 201

    args = mock_exec.call_args.args
    assert "--append-system-prompt" in args
    # The prompt should contain the agent name and mesh API instructions.
    prompt_idx = args.index("--append-system-prompt") + 1
    prompt = args[prompt_idx]
    assert "prompt-test" in prompt
    assert "localhost" in prompt
    assert "/mesh/agents" in prompt
    assert "curl" in prompt

    await client.delete("/mesh/agents/prompt-test")


# =====================================================================
# List sessions
# =====================================================================


@patch(
    "drasill.terminal.router.sup_list_sessions",
    return_value=["alpha", "beta"],
)
async def test_list_sessions(
    mock_sup: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """GET /terminal/sessions returns heimdall sessions."""
    resp = await client.get("/terminal/sessions")
    assert resp.status_code == 200
    assert resp.json()["sessions"] == ["alpha", "beta"]


@patch("drasill.terminal.router.sup_list_sessions", return_value=[])
async def test_list_sessions_empty(
    mock_sup: AsyncMock,  # noqa: ARG001
    client: AsyncClient,
) -> None:
    """GET /terminal/sessions returns empty when no sessions."""
    resp = await client.get("/terminal/sessions")
    assert resp.status_code == 200
    assert resp.json()["sessions"] == []


# =====================================================================
# File drop tests (unchanged)
# =====================================================================


async def test_terminal_drop_upload(client: AsyncClient, tmp_path: object) -> None:
    with patch(
        "drasill.terminal.router._DROP_DIR",
        Path(str(tmp_path)) / "drops",
    ):
        resp = await client.post(
            "/terminal/drop",
            files={"file": ("hello.txt", BytesIO(b"world"), "text/plain")},
        )
    assert resp.status_code == 201
    data = resp.json()
    assert data["path"].endswith("hello.txt")
    result = Path(data["path"]).read_text()  # noqa: ASYNC240
    assert result == "world"


async def test_terminal_drop_dedup(client: AsyncClient, tmp_path: object) -> None:
    drop_dir = Path(str(tmp_path)) / "drops"
    with patch("drasill.terminal.router._DROP_DIR", drop_dir):
        resp1 = await client.post(
            "/terminal/drop",
            files={"file": ("dup.txt", BytesIO(b"a"), "text/plain")},
        )
        resp2 = await client.post(
            "/terminal/drop",
            files={"file": ("dup.txt", BytesIO(b"b"), "text/plain")},
        )
    assert resp1.status_code == 201
    assert resp2.status_code == 201
    assert resp1.json()["path"] != resp2.json()["path"]
    assert "dup-1.txt" in resp2.json()["path"]


async def test_terminal_drop_too_large(client: AsyncClient, tmp_path: object) -> None:
    with (
        patch("drasill.terminal.router._DROP_DIR", Path(str(tmp_path)) / "drops"),
        patch("drasill.terminal.router._DROP_MAX_SIZE", 10),
    ):
        resp = await client.post(
            "/terminal/drop",
            files={
                "file": (
                    "big.bin",
                    BytesIO(b"x" * 100),
                    "application/octet-stream",
                )
            },
        )
    assert resp.status_code == 400
    assert "too large" in resp.json()["detail"].lower()


# =====================================================================
# heimdall relay function tests
# =====================================================================


async def test_relay_output_forwards_output_frames() -> None:
    """_relay_output sends OUTPUT frames as ws.send_bytes."""
    reader = asyncio.StreamReader()
    reader.feed_data(_pack_frame(OUTPUT_TYPE, b"hello"))
    reader.feed_data(_pack_frame(OUTPUT_TYPE, b"world"))
    reader.feed_data(_pack_frame(EXIT_TYPE, struct.pack(">i", 0)))

    ws = MagicMock()
    ws.client_state = WebSocketState.CONNECTED
    ws.send_bytes = AsyncMock()
    ws.close = AsyncMock()

    await _relay_output(ws, reader)

    assert ws.send_bytes.call_count == 2
    ws.send_bytes.assert_any_call(b"hello")
    ws.send_bytes.assert_any_call(b"world")
    ws.close.assert_called_once()


async def test_relay_output_handles_eof() -> None:
    """_relay_output returns cleanly on IncompleteReadError."""
    reader = asyncio.StreamReader()
    reader.feed_eof()

    ws = MagicMock()
    ws.client_state = WebSocketState.CONNECTED
    ws.send_bytes = AsyncMock()

    await _relay_output(ws, reader)
    ws.send_bytes.assert_not_called()


async def test_relay_input_forwards_input() -> None:
    """_relay_input sends INPUT frames from WebSocket to writer."""
    ws = MagicMock()
    ws.receive_text = AsyncMock(
        side_effect=[
            '{"type": "input", "data": "ls\\n"}',
            '{"type": "resize", "cols": 100, "rows": 30}',
            "not json",
            WebSocketDisconnect(),
        ]
    )

    writer = MagicMock()
    writer.write = MagicMock()
    writer.drain = AsyncMock()

    with patch(
        "drasill.terminal.router.send_resize",
        new_callable=AsyncMock,
    ) as mock_resize:
        await _relay_input(ws, writer)

    # INPUT frame was written
    assert writer.write.call_count == 1
    # RESIZE was called
    mock_resize.assert_called_once_with(writer, 100, 30)


async def test_wait_for_socket_found(tmp_path: Path) -> None:
    """_wait_for_socket returns True when socket exists."""
    # Create the socket file
    (tmp_path / "test-ws.sock").touch()

    with patch("drasill.terminal.router.SESSIONS_DIR", tmp_path):
        result = await _wait_for_socket("test-ws")

    assert result is True


async def test_wait_for_socket_timeout(tmp_path: Path) -> None:
    """_wait_for_socket returns False when socket never appears."""
    with (
        patch("drasill.terminal.router.SESSIONS_DIR", tmp_path),
        patch("drasill.terminal.router._SOCKET_WAIT_TIMEOUT", 0.1),
    ):
        result = await _wait_for_socket("never-exists")

    assert result is False


@patch("drasill.terminal.router.subscribe")
async def test_ws_via_supervisor_subscribe_failure(
    mock_subscribe: AsyncMock,
) -> None:
    """_ws_via_supervisor closes WS when subscribe fails."""
    mock_subscribe.side_effect = FileNotFoundError("no socket")

    ws = MagicMock()
    ws.close = AsyncMock()

    await _ws_via_supervisor(ws, "missing-session")

    ws.close.assert_called_once_with(code=4004, reason="Supervisor not available")


# =====================================================================
# Mesh prompt generation
# =====================================================================


def test_build_mesh_prompt_contains_agent_name() -> None:
    """Mesh prompt includes the agent's name."""

    prompt = _build_mesh_prompt("alpha-agent")
    assert "alpha-agent" in prompt


def test_build_mesh_prompt_contains_api_instructions() -> None:
    """Mesh prompt includes curl commands for peers and messaging."""

    prompt = _build_mesh_prompt("test-agent")
    assert "curl" in prompt
    assert "/mesh/agents" in prompt
    # Agent name must appear in the --json payload, not just the intro.
    assert '"from_agent":"test-agent"' in prompt


def test_build_mesh_prompt_uses_configured_port() -> None:
    """Mesh prompt uses the provided port, not a hardcoded default."""

    prompt = _build_mesh_prompt("x", port=9999)
    assert "localhost:9999" in prompt
    assert "8400" not in prompt

    prompt_default = _build_mesh_prompt("x")
    assert "localhost:8400" in prompt_default
