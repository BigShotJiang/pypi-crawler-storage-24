"""E2E tests for the drasill dashboard.

Tests the full UI via Playwright against a real drasill server.
Covers: page load, layout, sidebar, agent mesh, messaging, health deps,
new session dialog, SSE updates.

Every test asserts structural invariants, not just "something exists."
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

import httpx
from playwright.sync_api import expect

if TYPE_CHECKING:
    from playwright.sync_api import Page


# ── Page load and structure ──────────────────────────────────────────


class TestPageLoad:
    """Verify the dashboard loads with correct structure."""

    def test_home_returns_200(self, base_url: str) -> None:
        """GET / returns 200 with HTML content type."""
        resp = httpx.get(f"{base_url}/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]

    def test_home_has_title(self, home: Page) -> None:
        """Page title contains 'drasill'."""
        expect(home).to_have_title(re.compile(r"drasill", re.IGNORECASE))

    def test_sidebar_exists_with_htmx_trigger(self, home: Page) -> None:
        """Sidebar loads via HTMX with SSE trigger."""
        sidebar = home.locator("#sidebar-agents")
        expect(sidebar).to_be_attached()
        # Must have hx-get for loading and sse:mesh for live updates.
        assert sidebar.get_attribute("hx-get") == "/partials/sidebar"
        assert "sse:mesh" in (sidebar.get_attribute("hx-trigger") or "")

    def test_sse_connection_established(self, home: Page) -> None:
        """SSE event source connects to /mesh/events."""
        # The base template has hx-ext="sse" with sse-connect.
        sse_el = home.locator("[sse-connect]").first
        expect(sse_el).to_be_attached()
        assert "/mesh/events" in (sse_el.get_attribute("sse-connect") or "")

    def test_no_js_errors_on_load(self, home: Page) -> None:
        """No JavaScript errors on page load."""
        errors: list[str] = []
        home.on("pageerror", lambda err: errors.append(str(err)))
        home.reload()
        home.wait_for_load_state("domcontentloaded")
        home.wait_for_timeout(1000)
        assert errors == [], f"JS errors: {errors}"

    def test_no_404_resources(self, home: Page) -> None:
        """No 404 errors for any resource on page load."""
        not_found: list[str] = []

        def on_response(response: object) -> None:
            url = getattr(response, "url", "")
            status = getattr(response, "status", 0)
            if status == 404 and not url.endswith("favicon.ico"):
                not_found.append(url)

        home.on("response", on_response)
        home.reload()
        home.wait_for_load_state("domcontentloaded")
        home.wait_for_timeout(500)
        assert not_found == [], f"404s: {not_found}"


# ── Sidebar ──────────────────────────────────────────────────────────


class TestSidebar:
    """Sidebar agent list behavior."""

    def test_sidebar_collapse_expand(self, home: Page) -> None:
        """Sidebar toggle changes width class."""
        aside = home.locator("aside").first
        toggle = aside.locator("button").first
        expect(toggle).to_be_visible()

        # Initially expanded — should have "Agents" text.
        expect(aside).to_contain_text("Agents")

        # Collapse.
        toggle.click()
        home.wait_for_timeout(300)

        # Expand.
        toggle.click()
        home.wait_for_timeout(300)
        expect(aside).to_contain_text("Agents")

    def test_empty_state(self, home: Page) -> None:
        """With no agents, sidebar has zero agent buttons."""
        sidebar = home.locator("#sidebar-agents")
        home.wait_for_timeout(1000)
        agent_buttons = sidebar.locator("[data-open-agent]")
        assert agent_buttons.count() == 0

    def test_agent_registration_updates_sidebar(
        self,
        home: Page,
        base_url: str,
    ) -> None:
        """Registering an agent via API makes it appear in the sidebar."""
        resp = httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "sidebar-test", "idle_timeout": 60},
        )
        assert resp.status_code == 201

        # Trigger HTMX refresh and wait.
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(1500)

        sidebar = home.locator("#sidebar-agents")
        expect(sidebar).to_contain_text("sidebar-test")

        # The agent button should have the correct data attribute.
        btn = sidebar.locator("[data-open-agent='sidebar-test']")
        assert btn.count() == 1

        # Cleanup.
        httpx.delete(f"{base_url}/mesh/agents/sidebar-test")

    def test_agent_deregistration_removes_from_sidebar(
        self,
        home: Page,
        base_url: str,
    ) -> None:
        """Deregistering an agent removes it from the sidebar."""
        httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "sidebar-remove", "idle_timeout": 60},
        )
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(1500)
        expect(home.locator("#sidebar-agents")).to_contain_text("sidebar-remove")

        httpx.delete(f"{base_url}/mesh/agents/sidebar-remove")
        # Trigger refresh twice — SSE can be delayed.
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(2000)
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(1500)

        btn = home.locator("[data-open-agent='sidebar-remove']")
        assert btn.count() == 0


# ── Agent mesh overview ──────────────────────────────────────────────


class TestMeshOverview:
    """Agent mesh overview panel."""

    def test_empty_mesh_shows_no_agents(self, home: Page) -> None:
        """Empty mesh shows 'No agents registered' message."""
        home.wait_for_timeout(1000)
        body = home.inner_text("body")
        assert "no agents" in body.lower()

    def test_mesh_counts_update(
        self,
        home: Page,
        base_url: str,
    ) -> None:
        """Registering agents updates the mesh overview counts."""
        httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "mesh-count-a", "idle_timeout": 60},
        )
        httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "mesh-count-b", "idle_timeout": 60},
        )
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(2000)

        # Overview should show idle count (agents default to idle).
        body = home.inner_text("body")
        assert "idle" in body.lower()

        httpx.delete(f"{base_url}/mesh/agents/mesh-count-a")
        httpx.delete(f"{base_url}/mesh/agents/mesh-count-b")


# ── New session dialog ───────────────────────────────────────────────


class TestNewSessionDialog:
    """New session creation dialog."""

    def test_dialog_opens_and_has_fields(self, home: Page) -> None:
        """Dialog opens on click with name and directory inputs."""
        btn = home.locator("button", has_text="New session").first
        btn.click()
        home.wait_for_timeout(500)

        # Name input.
        name_input = home.locator("input[placeholder*='my-project']").first
        expect(name_input).to_be_visible()
        assert name_input.get_attribute("type") == "text"

        # Directory input.
        dir_input = home.locator("input[placeholder*='dev']").first
        expect(dir_input).to_be_visible()

        # Create button.
        create_btn = home.locator("button", has_text="Create").first
        expect(create_btn).to_be_visible()

    def test_dialog_closes_on_escape(self, home: Page) -> None:
        """Pressing Escape closes the dialog."""
        home.locator("button", has_text="New session").first.click()
        home.wait_for_timeout(300)

        # Dialog should be visible.
        dialog = home.locator("[x-show='showNewSession']").first
        expect(dialog).to_be_visible()

        home.keyboard.press("Escape")
        home.wait_for_timeout(300)
        expect(dialog).to_be_hidden()

    def test_dialog_closes_on_cancel(self, home: Page) -> None:
        """Clicking Cancel closes the dialog."""
        home.locator("button", has_text="New session").first.click()
        home.wait_for_timeout(300)
        home.locator("button", has_text="Cancel").first.click()
        home.wait_for_timeout(300)

        dialog = home.locator("[x-show='showNewSession']").first
        expect(dialog).to_be_hidden()

    def test_dialog_closes_on_backdrop_click(self, home: Page) -> None:
        """Clicking the backdrop closes the dialog."""
        home.locator("button", has_text="New session").first.click()
        home.wait_for_timeout(300)

        # Click the backdrop (the outer overlay div).
        backdrop = home.locator("[x-show='showNewSession']").first
        # Click at the edge of the backdrop, not the inner content.
        backdrop.click(position={"x": 5, "y": 5})
        home.wait_for_timeout(300)
        expect(backdrop).to_be_hidden()


# ── Health deps page ─────────────────────────────────────────────────


class TestHealthDeps:
    """Health dependency check page."""

    def test_page_structure(self, page: Page, base_url: str) -> None:
        """Health page has title, dependency rows, and status indicators."""
        page.goto(f"{base_url}/health/deps")
        page.wait_for_load_state("domcontentloaded")

        expect(page.locator("body")).to_contain_text("System Health")

        # Each required dep should have a row.
        for dep in ("uv", "hm", "claude"):
            row = page.locator(f"text='{dep}'").first
            expect(row).to_be_visible()

        # Should have status dots (green or red circles).
        dots = page.locator(".rounded-full")
        assert dots.count() >= 3, "should have at least 3 status indicators"

    def test_installed_deps_show_path(self, page: Page, base_url: str) -> None:
        """Installed deps show their binary path."""
        page.goto(f"{base_url}/health/deps")
        page.wait_for_load_state("domcontentloaded")
        body = page.inner_text("body")
        # uv should be installed in our test env.
        assert "/uv" in body or "uv" in body

    def test_missing_deps_show_install_link(
        self,
        page: Page,
        base_url: str,
    ) -> None:
        """Missing deps have clickable install links."""
        page.goto(f"{base_url}/health/deps")
        page.wait_for_load_state("domcontentloaded")
        # Install links should be external (https://).
        install_links = page.locator("a[target='_blank']")
        # At least optional deps (cloudflared, tailscale) are likely missing.
        # Even if all are installed, the test should not fail.
        for i in range(install_links.count()):
            href = install_links.nth(i).get_attribute("href")
            assert href is not None
            assert href.startswith("http")


# ── Agent detail view ────────────────────────────────────────────────


class TestAgentDetail:
    """Agent detail panel."""

    def test_agent_click_shows_detail(
        self,
        home: Page,
        base_url: str,
    ) -> None:
        """Clicking an agent in sidebar loads its detail view."""
        httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "detail-click", "idle_timeout": 60},
        )
        home.evaluate("htmx.trigger('#sidebar-agents', 'sse:mesh')")
        home.wait_for_timeout(1500)

        btn = home.locator("[data-open-agent='detail-click']").first
        if btn.count() > 0:
            btn.click()
            home.wait_for_timeout(1500)
            # Detail view should show agent name and status.
            body = home.inner_text("body")
            assert "detail-click" in body
            # Should show a status indicator.
            assert "idle" in body.lower() or "active" in body.lower()

        httpx.delete(f"{base_url}/mesh/agents/detail-click")


# ── Messaging ────────────────────────────────────────────────────────


class TestMessaging:
    """Message sending via mesh overview."""

    def test_message_form_visible_with_agents(
        self,
        home: Page,
        base_url: str,
    ) -> None:
        """Message send form appears in mesh overview when agents exist."""
        httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "msg-form-test", "idle_timeout": 60},
        )
        # The mesh overview loads via HTMX — click on a fresh overview
        # pane to trigger a reload with the new agent.
        home.reload()
        home.wait_for_load_state("domcontentloaded")
        home.wait_for_timeout(2000)

        # The mesh overview should now show the agent and a send form.
        body = home.inner_text("body")
        assert "msg-form-test" in body

        httpx.delete(f"{base_url}/mesh/agents/msg-form-test")


# ── API endpoints ────────────────────────────────────────────────────


class TestAPI:
    """JSON API endpoints work correctly."""

    def test_health_ok(self, base_url: str) -> None:
        """GET /health returns ok."""
        resp = httpx.get(f"{base_url}/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"

    def test_mesh_agents_empty(self, base_url: str) -> None:
        """GET /mesh/agents returns empty list initially."""
        resp = httpx.get(f"{base_url}/mesh/agents")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data["agents"], list)

    def test_agent_lifecycle(self, base_url: str) -> None:
        """Register → get → delete lifecycle via API."""
        # Register.
        resp = httpx.post(
            f"{base_url}/mesh/agents",
            json={"name": "lifecycle-api", "idle_timeout": 60},
        )
        assert resp.status_code == 201

        # Get.
        resp = httpx.get(f"{base_url}/mesh/agents/lifecycle-api")
        assert resp.status_code == 200
        assert resp.json()["name"] == "lifecycle-api"
        assert resp.json()["status"] == "active"

        # Delete.
        resp = httpx.delete(f"{base_url}/mesh/agents/lifecycle-api")
        assert resp.status_code == 200

        # Gone.
        resp = httpx.get(f"{base_url}/mesh/agents/lifecycle-api")
        assert resp.status_code == 404


# ── Static assets ────────────────────────────────────────────────────


class TestStaticAssets:
    """Static asset loading."""

    def test_css_loads_with_correct_type(self, base_url: str) -> None:
        """style.css returns 200 with CSS content type."""
        resp = httpx.get(f"{base_url}/static/style.css")
        assert resp.status_code == 200
        assert "css" in resp.headers.get("content-type", "")
