"""Web terminal — heimdall proxy via WebSocket."""
