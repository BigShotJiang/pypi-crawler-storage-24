"""WebSocket terminal proxy — bridges browser to heimdall sessions.

Uses heimdall Unix socket subscriptions for true async pty streaming.
The browser connects via WebSocket, which relays to/from the heimdall
supervisor process that owns the pty.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path

from fastapi import (
    APIRouter,
    HTTPException,
    Request,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from starlette.websockets import WebSocketState

from drasill.db import (
    get_agent_session_id,
    insert_agent,
)
from drasill.supervisor_client import (
    EXIT,
    OUTPUT,
    SESSIONS_DIR,
    _pack_frame,
    _read_frame,
    is_alive,
    send_resize,
    subscribe,
)
from drasill.supervisor_client import (
    list_sessions as sup_list_sessions,
)

# Terminal file drops are saved here with original filenames.
_DROP_DIR = Path("~/.local/share/drasill/drops").expanduser()

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/terminal")


# =====================================================================
# heimdall WebSocket streaming
# =====================================================================

INPUT_TYPE = 0x01


async def _relay_output(
    ws: WebSocket,
    reader: asyncio.StreamReader,
) -> None:
    """Stream heimdall output frames to the WebSocket client.

    Reads OUTPUT (0x81) and EXIT (0x83) frames from the supervisor and
    forwards raw pty bytes to the browser. xterm.js handles rendering.
    """
    try:
        while True:
            msg_type, payload = await _read_frame(reader)
            if msg_type == OUTPUT:
                if ws.client_state == WebSocketState.CONNECTED:
                    await ws.send_bytes(payload)
            elif msg_type == EXIT:
                if ws.client_state == WebSocketState.CONNECTED:
                    await ws.close(code=1000, reason="session exited")
                return
    except asyncio.IncompleteReadError:
        return
    except WebSocketDisconnect:
        return


async def _relay_input(
    ws: WebSocket,
    writer: asyncio.StreamWriter,
) -> None:
    """Read WebSocket messages and forward input/resize to heimdall.

    Expects JSON messages with ``type: "input"`` or ``type: "resize"``.
    """
    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if msg.get("type") == "input":
                data = msg.get("data", "")
                if data:
                    writer.write(_pack_frame(INPUT_TYPE, data.encode()))
                    await writer.drain()
            elif msg.get("type") == "resize":
                cols = msg.get("cols", 80)
                rows = msg.get("rows", 24)
                await send_resize(writer, cols, rows)
    except WebSocketDisconnect:
        pass


async def _ws_via_supervisor(ws: WebSocket, session_id: str) -> None:
    """Handle WebSocket terminal via heimdall subscription."""
    try:
        reader, writer = await subscribe(session_id)
    except (FileNotFoundError, ConnectionRefusedError, ValueError) as exc:
        logger.warning("Cannot subscribe to session %s: %s", session_id, exc)
        await ws.close(code=4004, reason="Supervisor not available")
        return

    await ws.accept()
    logger.info("Terminal connected (heimdall): %s", session_id)

    output_task = asyncio.create_task(_relay_output(ws, reader))
    input_task = asyncio.create_task(_relay_input(ws, writer))

    try:
        # Wait for either side to finish.
        done, pending = await asyncio.wait(
            {output_task, input_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        # Re-raise any exceptions from completed tasks.
        for task in done:
            task.result()
    except (WebSocketDisconnect, asyncio.CancelledError):
        pass
    finally:
        writer.close()
        await writer.wait_closed()
        output_task.cancel()
        input_task.cancel()
        logger.info("Terminal disconnected (heimdall): %s", session_id)


@router.websocket("/{agent_name}/ws")
async def terminal_ws(websocket: WebSocket, agent_name: str) -> None:
    """WebSocket endpoint for interactive terminal access.

    Connects to the agent's heimdall session via Unix socket subscription.
    """
    db = websocket.app.state.db
    session_id = await get_agent_session_id(db, agent_name)
    if session_id:
        await _ws_via_supervisor(websocket, session_id)
    else:
        await websocket.close(
            code=4004,
            reason="Agent not found or no session",
        )


# =====================================================================
# Session creation
# =====================================================================

_SESSION_NAME_RE = re.compile(r"[^a-zA-Z0-9_-]")

# Heimdall (hm) binary name (can be overridden for testing).
_HM_BIN = "hm"


def _build_mesh_prompt(agent_name: str, port: int = 8400) -> str:
    """Build the mesh awareness system prompt for an agent.

    Injected at launch so the agent knows how to discover peers
    and send messages via the mesh API.
    """
    # agent_name is sanitized to [a-zA-Z0-9_-] by _sanitize_session_name,
    # so it's safe to embed in JSON and shell strings.
    base = f"localhost:{port}"
    return (
        f'You are agent "{agent_name}" in a drasill agent mesh on {base}. '
        "Other agents may be working on related projects. "
        "You can collaborate with them.\n\n"
        "To see who else is in the mesh:\n"
        f"  curl -s {base}/mesh/agents "
        "| jq '.agents[] | {name, status, agent_state}'\n\n"
        "To send a message to another agent:\n"
        f"  curl -s -X POST {base}/mesh/agents/AGENT_NAME/inbox "
        '-H "Content-Type: application/json" '
        f'--json \'{{"from_agent":"{agent_name}","body":"YOUR MESSAGE"}}\'\n\n'
        "When the user asks you to message or coordinate with another agent, "
        "use the commands above. Match agent names approximately — "
        "check the peers list first if unsure."
    )


class SessionCreateRequest(BaseModel):
    """Request body for creating a new supervised Claude session."""

    name: str = Field(default="", max_length=64)
    directory: str = Field(default="")
    continue_session: bool = False
    dangerous_mode: bool = False


_SOCKET_WAIT_TIMEOUT = 2.0


async def _wait_for_socket(session_id: str) -> bool:
    """Wait for the heimdall socket to appear on disk.

    Args:
        session_id: Session ID matching the heimdall --id flag.

    Returns:
        True if socket appeared, False if timed out.

    """
    sock_path = SESSIONS_DIR / f"{session_id}.sock"
    deadline = asyncio.get_running_loop().time() + _SOCKET_WAIT_TIMEOUT
    while asyncio.get_running_loop().time() < deadline:
        if sock_path.exists():
            return True
        await asyncio.sleep(0.05)
    return False


async def _git_session_name(directory: str) -> str | None:
    """Derive session name from git repo+branch, or None."""
    proc = await asyncio.create_subprocess_exec(
        "git",
        "rev-parse",
        "--is-inside-work-tree",
        cwd=directory,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    stdout, _ = await proc.communicate()
    if proc.returncode != 0 or stdout.decode().strip() != "true":
        return None

    # Get repo name from remote or toplevel dir
    proc = await asyncio.create_subprocess_exec(
        "git",
        "remote",
        "get-url",
        "origin",
        cwd=directory,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    stdout, _ = await proc.communicate()
    remote_url = stdout.decode().strip()

    if remote_url:
        repo_name = remote_url.rstrip("/").rsplit("/", 1)[-1]
        repo_name = repo_name.removesuffix(".git")
    else:
        proc = await asyncio.create_subprocess_exec(
            "git",
            "rev-parse",
            "--show-toplevel",
            cwd=directory,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await proc.communicate()
        repo_name = stdout.decode().strip().rsplit("/", 1)[-1]

    # Get branch name
    proc = await asyncio.create_subprocess_exec(
        "git",
        "branch",
        "--show-current",
        cwd=directory,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    stdout, _ = await proc.communicate()
    branch = stdout.decode().strip() or "detached"

    return f"{repo_name}_{branch}"


def _sanitize_session_name(name: str) -> str:
    """Sanitize a session name for compatibility.

    Replaces invalid characters with underscores and strips leading/trailing
    underscores.  Returns ``"unnamed"`` if the result would be empty.
    """
    name = name.replace(":", "_").replace(".", "_")
    name = _SESSION_NAME_RE.sub("_", name).strip("_")
    return name or "unnamed"


@router.post("/sessions")
async def create_session(
    request: Request,
    body: SessionCreateRequest,
) -> JSONResponse:
    """Create a new supervised Claude Code session.

    Launches heimdall as the pty supervisor, waits for the socket to appear,
    and registers the agent in the mesh.

    Args:
        request: FastAPI request.
        body: Session creation parameters.

    Returns:
        JSON with session name, session_id, and directory.

    """
    directory = body.directory or str(Path.home())
    work_dir = Path(directory).expanduser().resolve()  # noqa: ASYNC240
    if not work_dir.is_dir():
        return JSONResponse(
            {"error": f"Directory not found: {directory}"},
            status_code=400,
        )

    # Determine session name
    if body.name:
        session_name = _sanitize_session_name(body.name)
    else:
        git_name = await _git_session_name(str(work_dir))
        if git_name:
            session_name = _sanitize_session_name(git_name)
        else:
            session_name = _sanitize_session_name(work_dir.name)

    # Check for existing supervisor session
    if is_alive(session_name):
        return JSONResponse(
            {"error": f"Session '{session_name}' already exists", "name": session_name},
            status_code=409,
        )

    # Build agent command with mesh awareness prompt.
    server_port = request.app.state.config.server.port
    mesh_prompt = _build_mesh_prompt(session_name, port=server_port)
    claude_args = ["claude", "--append-system-prompt", mesh_prompt]
    if body.continue_session:
        claude_args.append("--continue")
    if body.dangerous_mode:
        claude_args.append("--dangerously-skip-permissions")

    # Ensure socket directory exists.
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

    # Launch heimdall supervisor (detached — drasill manages lifecycle)
    proc = await asyncio.create_subprocess_exec(
        _HM_BIN,
        "run",
        "--detach",
        "--id",
        session_name,
        "--workdir",
        str(work_dir),
        "--socket-dir",
        str(SESSIONS_DIR),
        "--classifier",
        "simple",
        "--session-env-var",
        "DRASILL_SESSION_ID",
        "--",
        *claude_args,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )

    # Wait for socket to appear
    if not await _wait_for_socket(session_name):
        # Supervisor failed to start — try to capture stderr for diagnostics.
        _, stderr_bytes = await asyncio.wait_for(proc.communicate(), timeout=2)
        stderr_text = (
            stderr_bytes.decode(errors="replace").strip() if stderr_bytes else ""
        )
        detail = stderr_text[:200]
        return JSONResponse(
            {"error": f"Supervisor failed to start: {detail}"},
            status_code=500,
        )

    # Register as agent in mesh
    await insert_agent(
        request.app.state.db,
        name=session_name,
        session_id=session_name,
    )
    request.app.state.event_bus.publish("refresh")

    logger.info("Created Claude session: %s in %s (supervisor)", session_name, work_dir)

    return JSONResponse(
        {
            "name": session_name,
            "session_id": session_name,
            "directory": str(work_dir),
        },
        status_code=201,
    )


@router.get("/sessions")
async def list_sessions_endpoint() -> JSONResponse:
    """List all active heimdall sessions."""
    return JSONResponse({"sessions": sorted(sup_list_sessions())})


# Max 10 MiB per dropped file.
_DROP_MAX_SIZE = 10 * 1024 * 1024


@router.post("/drop")
async def terminal_drop(file: UploadFile) -> JSONResponse:
    """Save a dropped file and return the local filesystem path.

    Used by the web terminal to emulate native terminal file drag-and-drop.
    The file is saved with its original name (deduplicated if needed) to a
    local directory so Claude Code can read it directly.
    """
    filename = file.filename or "dropped-file"
    # Sanitize: strip path separators, keep basename only
    filename = Path(filename).name
    if not filename:
        filename = "dropped-file"

    data = await file.read()
    if len(data) > _DROP_MAX_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large (max {_DROP_MAX_SIZE // 1024 // 1024} MiB)",
        )

    _DROP_DIR.mkdir(parents=True, exist_ok=True)

    # Deduplicate: if file exists, add a numeric suffix
    dest = _DROP_DIR / filename
    if dest.exists():
        stem = dest.stem
        suffix = dest.suffix
        counter = 1
        while dest.exists():
            dest = _DROP_DIR / f"{stem}-{counter}{suffix}"
            counter += 1

    dest.write_bytes(data)
    return JSONResponse({"path": str(dest)}, status_code=201)
