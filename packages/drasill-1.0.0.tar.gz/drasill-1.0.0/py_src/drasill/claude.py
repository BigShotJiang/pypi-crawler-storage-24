"""Async wrapper for the Claude Code CLI (``claude -p``)."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ClaudeOptions:
    """Options for a ``claude -p`` invocation.

    Attributes:
        max_turns: Maximum agentic tool-use loops.
        allowed_tools: Tools to auto-approve (e.g. ["Read", "Bash"]).
        json_schema: JSON Schema to enforce structured output.
        resume_session: Session ID to continue a previous conversation.
        timeout_seconds: Subprocess timeout.

    """

    max_turns: int = 1
    allowed_tools: list[str] | None = None
    json_schema: dict[str, Any] | None = None
    resume_session: str | None = None
    timeout_seconds: float = 120.0


@dataclass(frozen=True, slots=True)
class ClaudeResponse:
    """Parsed response from a ``claude -p`` invocation.

    Attributes:
        result: The text content returned by Claude.
        session_id: Session identifier for resuming conversations.
        usage: Token usage metadata.
        raw: The full parsed JSON payload.

    """

    result: str
    session_id: str = ""
    usage: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


class ClaudeError(Exception):
    """Raised when the ``claude`` CLI returns a non-zero exit code."""


def _build_cmd(prompt: str, opts: ClaudeOptions) -> list[str]:
    """Build the CLI command list from prompt and options."""
    cmd: list[str] = [
        "claude",
        "-p",
        prompt,
        "--output-format",
        "json",
        "--max-turns",
        str(opts.max_turns),
    ]

    if opts.allowed_tools:
        cmd.extend(["--allowedTools", ",".join(opts.allowed_tools)])

    if opts.json_schema:
        cmd.extend(["--json-schema", json.dumps(opts.json_schema)])

    if opts.resume_session:
        cmd.extend(["--resume", opts.resume_session])

    return cmd


async def claude_query(
    prompt: str,
    opts: ClaudeOptions | None = None,
) -> ClaudeResponse:
    """Run Claude Code non-interactively and return the parsed response.

    Args:
        prompt: The prompt to send.
        opts: Query options. Uses defaults if not provided.

    Returns:
        Parsed ClaudeResponse.

    Raises:
        ClaudeError: If the CLI exits non-zero.
        TimeoutError: If the subprocess exceeds timeout_seconds.

    """
    if opts is None:
        opts = ClaudeOptions()

    cmd = _build_cmd(prompt, opts)
    logger.debug("Running: %s", " ".join(cmd))

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(),
            timeout=opts.timeout_seconds,
        )
    except TimeoutError:
        proc.kill()
        await proc.communicate()
        msg = f"claude process timed out after {opts.timeout_seconds}s"
        raise TimeoutError(msg) from None

    if proc.returncode != 0:
        msg = f"claude exited with code {proc.returncode}: {stderr.decode().strip()}"
        raise ClaudeError(msg)

    raw = json.loads(stdout)
    return ClaudeResponse(
        result=raw.get("result", ""),
        session_id=raw.get("session_id", ""),
        usage=raw.get("usage", {}),
        raw=raw,
    )
