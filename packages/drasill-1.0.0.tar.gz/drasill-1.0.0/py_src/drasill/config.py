"""Configuration loader — tomllib → Pydantic models."""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

from pydantic import BaseModel, field_validator

_DEFAULT_CONFIG_PATH = Path("config.toml")
_ENV_VAR = "DRASILL_CONFIG"


class ServerConfig(BaseModel):
    """Server bind settings."""

    host: str = "0.0.0.0"  # noqa: S104
    port: int = 8400


class DbConfig(BaseModel):
    """Database settings."""

    path: str = "~/.local/share/drasill/dash.db"

    @field_validator("path")
    @classmethod
    def expand_path(cls, v: str) -> str:
        """Expand ~ in database path."""
        return str(Path(v).expanduser())


class PruningConfig(BaseModel):
    """Agent monitoring and cleanup thresholds."""

    remove_seconds: int = 3600
    interval: float = 5


class AppConfig(BaseModel):
    """Root application configuration."""

    server: ServerConfig = ServerConfig()
    db: DbConfig = DbConfig()
    pruning: PruningConfig = PruningConfig()


def load_config(path: Path | None = None) -> AppConfig:
    """Load configuration from a TOML file.

    Args:
        path: Explicit path to config file. Falls back to DRASILL_CONFIG
              env var, then to config.toml in the current directory.

    Returns:
        Parsed and validated AppConfig.

    """
    if path is None:
        env_path = os.environ.get(_ENV_VAR)
        path = Path(env_path) if env_path else _DEFAULT_CONFIG_PATH

    if not path.exists():
        return AppConfig()

    with path.open("rb") as f:
        raw = tomllib.load(f)

    return AppConfig.model_validate(raw)
