"""Allow running with ``python -m drasill``."""

from drasill.cli import main

main()
