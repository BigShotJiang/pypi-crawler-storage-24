"""FastAPI application factory."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from drasill.config import AppConfig, load_config
from drasill.db import (
    get_agent,
    init_db,
    list_agent_messages,
    list_agents,
    list_agents_with_unread,
    list_recent_messages,
)
from drasill.doctor import check_deps
from drasill.mesh.events import MeshEventBus
from drasill.mesh.middleware import LocalhostOnlyMiddleware
from drasill.mesh.pruning import run_monitoring_loop
from drasill.mesh.router import router as mesh_router
from drasill.terminal.router import router as terminal_router

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

logger = logging.getLogger(__name__)

_BASE_DIR = Path(__file__).resolve().parent
_TEMPLATE_DIR = _BASE_DIR / "templates"
_STATIC_DIR = _BASE_DIR / "static"


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Manage startup and shutdown lifecycle."""
    config: AppConfig = app.state.config
    app.state.db = await init_db(config.db.path)

    event_bus = MeshEventBus()
    app.state.event_bus = event_bus

    prune_task = asyncio.create_task(
        run_monitoring_loop(app.state.db, event_bus, config=config.pruning),
    )
    logger.info("Started")

    yield

    # Notify all connected clients that the server is shutting down
    event_bus.publish("shutdown")
    # Brief pause to let SSE flush to clients
    await asyncio.sleep(0.1)

    prune_task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await prune_task
    await app.state.db.close()
    logger.info("Shutdown complete")


def _register_page_routes(
    app: FastAPI,
    templates: Jinja2Templates,
) -> None:
    """Register HTML page routes."""

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok"})

    @app.get("/health/deps", response_class=HTMLResponse)
    async def health_deps(request: Request) -> HTMLResponse:
        """Dashboard page showing dependency health status."""
        deps = await check_deps()
        all_ok = all(d.found for d in deps if d.required)
        return templates.TemplateResponse(
            request,
            "partials/health_deps.html",
            {"deps": deps, "all_ok": all_ok},
        )

    @app.get("/", response_class=HTMLResponse)
    async def index(request: Request) -> HTMLResponse:
        return templates.TemplateResponse(request, "index.html")

    @app.get("/partials/sidebar", response_class=HTMLResponse)
    async def sidebar_partial(request: Request) -> HTMLResponse:
        """Sidebar agent list partial with unread counts."""
        agents = await list_agents_with_unread(app.state.db)
        return templates.TemplateResponse(
            request,
            "partials/sidebar.html",
            {"agents": agents},
        )

    @app.get("/partials/mesh", response_class=HTMLResponse)
    async def mesh_partial(request: Request) -> HTMLResponse:
        """Agent mesh overview panel."""
        agents = await list_agents(app.state.db)
        messages = await list_recent_messages(app.state.db, limit=20)
        return templates.TemplateResponse(
            request,
            "partials/agent_mesh.html",
            {
                "agents": agents,
                "messages": messages,
                "agent_count": len(agents),
                "active_count": sum(
                    1
                    for a in agents
                    if a.get("agent_state") == "active" and a["status"] != "dead"
                ),
                "idle_count": sum(
                    1
                    for a in agents
                    if a.get("agent_state", "idle") == "idle" and a["status"] != "dead"
                ),
                "dead_count": sum(1 for a in agents if a["status"] == "dead"),
            },
        )


def _register_secondary_routes(
    app: FastAPI,
    templates: Jinja2Templates,
) -> None:
    """Register detail routes."""

    @app.get("/partials/agent-detail/{agent_name}", response_class=HTMLResponse)
    async def agent_detail_partial(
        request: Request,
        agent_name: str,
    ) -> HTMLResponse:
        """Detail view partial for a non-terminal agent tab."""
        agent = await get_agent(app.state.db, agent_name)
        if not agent:
            return HTMLResponse(
                '<p class="text-gray-500 text-sm">Agent not found</p>',
            )
        messages = await list_agent_messages(app.state.db, agent_name)
        return templates.TemplateResponse(
            request,
            "partials/agent_detail.html",
            {"agent": agent, "messages": messages},
        )


def create_app(config: AppConfig | None = None) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        config: Optional pre-loaded config. If None, loads from default path.

    Returns:
        Configured FastAPI application instance.

    """
    if config is None:
        config = load_config()

    app = FastAPI(
        title="drasill",
        version="0.1.0",
        lifespan=_lifespan,
    )
    app.state.config = config

    templates = Jinja2Templates(directory=str(_TEMPLATE_DIR))
    app.state.templates = templates

    if _STATIC_DIR.exists():
        app.mount(
            "/static",
            StaticFiles(directory=str(_STATIC_DIR)),
            name="static",
        )

    _register_page_routes(app, templates)
    _register_secondary_routes(app, templates)

    app.include_router(mesh_router)
    app.include_router(terminal_router)
    app.add_middleware(LocalhostOnlyMiddleware)  # type: ignore[arg-type]  # starlette typing bug with BaseHTTPMiddleware

    return app
