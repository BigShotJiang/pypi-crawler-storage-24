"""SSE event bus for broadcasting mesh state changes."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

logger = logging.getLogger(__name__)


class MeshEventBus:
    """Broadcast mesh events to all connected SSE clients.

    Uses a set of asyncio.Queue instances — one per connected client.
    Publishing fans out to all subscribers.
    """

    def __init__(self) -> None:
        """Initialize with no subscribers."""
        self._subscribers: set[asyncio.Queue[str]] = set()

    def publish(self, event: str) -> None:
        """Send an event string to all connected clients."""
        for queue in self._subscribers:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("SSE subscriber queue full, dropping event")

    async def subscribe(self) -> AsyncIterator[str]:
        """Yield events as they arrive. Cleans up on exit.

        Sends SSE keepalive comments every 30s to detect dead connections.
        Terminates when a ``shutdown`` event is received.
        """
        queue: asyncio.Queue[str] = asyncio.Queue(maxsize=64)
        self._subscribers.add(queue)
        try:
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30)
                    yield event
                    if event == "shutdown":
                        return
                except TimeoutError:
                    # Keepalive — SSE comment to detect dead connections
                    yield ""
        finally:
            self._subscribers.discard(queue)

    @property
    def subscriber_count(self) -> int:
        """Number of active SSE connections."""
        return len(self._subscribers)
