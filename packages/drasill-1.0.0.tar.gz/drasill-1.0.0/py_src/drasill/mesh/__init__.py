"""Agent mesh — registry, messaging, and lifecycle management."""
