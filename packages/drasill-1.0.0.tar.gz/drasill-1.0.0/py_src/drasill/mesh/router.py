"""FastAPI router for the agent mesh API."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from starlette.responses import StreamingResponse

from drasill.db import (
    consume_next_message,
    deregister_agent,
    get_agent,
    get_agent_by_session_id,
    get_attachment,
    get_attachments_for_message,
    insert_agent,
    insert_attachment,
    insert_message,
    link_attachments,
    list_agents,
    list_outbox,
)
from drasill.mesh.models import (
    AgentInfo,
    AgentRegisterRequest,
    LinkAttachmentsRequest,
    MessageInfo,
    MessageSendRequest,
)
from drasill.mesh.uploads import (
    ALLOWED_TYPES,
    MAX_FILE_SIZE,
    file_path,
    generate_file_id,
)
from drasill.supervisor_client import send_input as sup_send_input

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    import aiosqlite

    from drasill.mesh.events import MeshEventBus

logger = logging.getLogger(__name__)

# Strong references to fire-and-forget background tasks (prevents GC).
_background_tasks: set[asyncio.Task[None]] = set()

router = APIRouter(prefix="/mesh")


def _db(request: Request) -> aiosqlite.Connection:
    """Extract the database connection from app state."""
    return request.app.state.db


def _bus(request: Request) -> MeshEventBus:
    """Extract the SSE event bus from app state."""
    return request.app.state.event_bus


def _dict_to_agent(d: dict[str, Any]) -> AgentInfo:
    """Map an agent dict to an AgentInfo model."""
    return AgentInfo(**d)


# --- Shared dependencies ---


async def _require_agent(request: Request, name: str) -> dict[str, Any]:
    """FastAPI dependency: fetch an agent dict or raise 404."""
    agent = await get_agent(_db(request), name)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


RequireAgent = Annotated[dict[str, Any], Depends(_require_agent)]


# --- SSE ---


@router.get("/events")
async def mesh_events(request: Request) -> StreamingResponse:
    """SSE stream of mesh state changes.

    Clients receive a ``data: refresh`` line whenever agents or messages
    change.  HTMX's ``sse`` extension can use this to trigger partial
    reloads without polling.
    """
    bus = _bus(request)

    async def _generate() -> AsyncIterator[str]:
        async for event in bus.subscribe():
            if event:
                yield f"event: mesh\ndata: {event}\n\n"
            else:
                yield ": keepalive\n\n"

    return StreamingResponse(
        _generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# --- Agent Registry ---


@router.post("/agents")
async def register_agent(
    request: Request,
    body: AgentRegisterRequest,
) -> JSONResponse:
    """Register a new agent in the mesh."""
    inserted = await insert_agent(
        _db(request),
        name=body.name,
        pid=body.pid,
        session_id=body.session_id,
        idle_timeout=body.idle_timeout,
    )
    if not inserted:
        return JSONResponse(
            {"error": f"Agent '{body.name}' already registered"},
            status_code=409,
        )
    _bus(request).publish("refresh")
    logger.info("Agent registered: %s", body.name)

    return JSONResponse(
        {"name": body.name, "status": "registered"},
        status_code=201,
    )


@router.delete("/agents/{name}")
async def deregister_agent_endpoint(
    request: Request,
    name: str,
    _agent: RequireAgent,
) -> JSONResponse:
    """Remove an agent from the mesh and clean up pending messages."""
    await deregister_agent(_db(request), name)
    _bus(request).publish("refresh")
    logger.info("Agent deregistered: %s", name)
    return JSONResponse({"name": name, "status": "deregistered"})


@router.get("/agents")
async def list_agents_endpoint(request: Request) -> JSONResponse:
    """List all registered agents."""
    agents = await list_agents(_db(request))
    return JSONResponse(
        {"agents": [_dict_to_agent(a).model_dump() for a in agents]},
    )


@router.get("/agents/by-session")
async def get_agent_by_session(
    request: Request,
    id: str,  # noqa: A002
) -> JSONResponse:
    """Look up an agent name by heimdall session ID."""
    agent = await get_agent_by_session_id(_db(request), id)
    if not agent:
        raise HTTPException(status_code=404, detail="No agent with that session")
    return JSONResponse({"name": agent["name"]})


@router.get("/agents/{name}")
async def get_agent_endpoint(
    name: str,  # noqa: ARG001
    agent: RequireAgent,
) -> JSONResponse:
    """Get details for a single agent."""
    return JSONResponse(_dict_to_agent(agent).model_dump())


# --- Agent wake ---


async def _session_wake(
    session_id: str,
    from_agent: str,
    body: str,
) -> None:
    """Send input to a heimdall session to wake an idle agent.

    Fire-and-forget — failures are logged but never raised.
    """
    max_preview = 200
    preview = body[:max_preview] + "..." if len(body) > max_preview else body
    text = f"[mesh:{from_agent}] {preview}\n"
    try:
        await sup_send_input(session_id, text.encode())
    except OSError:
        logger.warning("Could not wake session %s via heimdall", session_id)


# --- Messaging ---


def _dict_to_message(d: dict[str, Any]) -> MessageInfo:
    """Map a message dict to a MessageInfo model."""
    return MessageInfo(**d)


@router.post("/agents/{name}/inbox")
async def send_message(
    request: Request,
    name: str,
    body: MessageSendRequest,
    agent: RequireAgent,
) -> JSONResponse:
    """Send a message to an agent's inbox."""
    msg_id = await insert_message(
        _db(request),
        to_agent=name,
        from_agent=body.from_agent,
        body=body.body,
        priority=body.priority,
    )
    _bus(request).publish("refresh")

    # Wake the agent via heimdall session
    session_id = agent.get("session_id")
    if session_id:
        task = asyncio.create_task(
            _session_wake(session_id, body.from_agent, body.body),
        )
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

    return JSONResponse(
        {"id": msg_id, "status": "queued"},
        status_code=201,
    )


@router.get("/agents/{name}/inbox")
async def check_inbox(
    request: Request,
    name: str,
    _agent: RequireAgent,
) -> JSONResponse:
    """Check for and consume the oldest unread message.

    This endpoint has side effects: it marks the returned message as read.
    Returns the full message object, or ``{}`` if no messages.
    """
    msg = await consume_next_message(_db(request), name)
    if not msg:
        return JSONResponse({})

    att_rows = await get_attachments_for_message(_db(request), msg["id"])
    attachments = [{**a, "url": f"/mesh/uploads/{a['id']}"} for a in att_rows]
    return JSONResponse({**msg, "attachments": attachments})


@router.get("/agents/{name}/outbox")
async def get_outbox_endpoint(
    request: Request,
    name: str,
    _agent: RequireAgent,
) -> JSONResponse:
    """Get message history sent by this agent."""
    messages = await list_outbox(_db(request), name)
    return JSONResponse(
        {"messages": [_dict_to_message(m).model_dump() for m in messages]},
    )


# --- File Uploads ---


@router.post("/upload")
async def upload_file(
    request: Request,
    file: UploadFile,
    message_id: int | None = None,
) -> JSONResponse:
    """Upload a file attachment.

    Accepts a single multipart file. Optionally links it to an existing
    message via ``message_id`` query parameter.
    """
    content_type = file.content_type or "application/octet-stream"
    if content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"File type '{content_type}' not allowed",
        )

    data = await file.read()
    if len(data) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large (max {MAX_FILE_SIZE // 1024 // 1024} MiB)",
        )

    fid = generate_file_id()
    dest = file_path(fid)
    dest.write_bytes(data)

    await insert_attachment(
        _db(request),
        file_id=fid,
        filename=file.filename or "untitled",
        content_type=content_type,
        size=len(data),
        message_id=message_id,
    )

    return JSONResponse(
        {
            "id": fid,
            "filename": file.filename,
            "content_type": content_type,
            "size": len(data),
        },
        status_code=201,
    )


@router.get("/uploads/{file_id}")
async def serve_upload(
    request: Request,
    file_id: str,
) -> FileResponse:
    """Serve an uploaded file by ID."""
    att = await get_attachment(_db(request), file_id)
    if not att:
        raise HTTPException(status_code=404, detail="File not found")

    path = file_path(file_id)
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found on disk")

    return FileResponse(
        path=str(path),
        media_type=att["content_type"],
        filename=att["filename"],
    )


@router.post("/upload/link")
async def link_attachments_endpoint(
    request: Request,
    body: LinkAttachmentsRequest,
) -> JSONResponse:
    """Link uploaded attachments to a message after creation.

    Body: ``{"message_id": 123, "attachment_ids": ["abc123", "def456"]}``
    """
    await link_attachments(
        _db(request),
        body.message_id,
        body.attachment_ids,
    )
    return JSONResponse(
        {"status": "linked", "count": len(body.attachment_ids)},
    )
