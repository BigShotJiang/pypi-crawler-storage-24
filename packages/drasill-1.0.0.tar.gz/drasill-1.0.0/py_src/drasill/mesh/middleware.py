"""Localhost-only middleware for mesh endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response

_LOCALHOST_ADDRS = frozenset({"127.0.0.1", "::1"})


class LocalhostOnlyMiddleware(BaseHTTPMiddleware):
    """Reject non-localhost requests to /mesh/ endpoints.

    Cloudflare Tunnel (or any reverse proxy) forwards requests with the
    original client IP. This middleware ensures mesh endpoints are only
    accessible from localhost, preventing remote access via the tunnel.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        """Check client host for mesh routes."""
        if request.url.path.startswith("/mesh/"):
            client_host = request.client.host if request.client else None
            if client_host not in _LOCALHOST_ADDRS:
                return JSONResponse(
                    {"error": "Mesh endpoints are localhost-only"},
                    status_code=403,
                )
        return await call_next(request)
