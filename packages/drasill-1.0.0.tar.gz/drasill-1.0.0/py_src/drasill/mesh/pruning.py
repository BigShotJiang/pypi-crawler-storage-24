"""Agent monitoring — status probing via heimdall and dead agent cleanup.

The server monitors agents directly. No external watchdog or heartbeat
endpoint needed. Each cycle:

1. Probe heimdall sessions for ground-truth idle/active/dead status
2. Deregister dead agents immediately
3. Remove agents that have been dead for too long
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from drasill.db import (
    consume_next_message,
    deregister_agent,
    fetch_undelivered_to_dead,
    list_agents,
    peek_next_message,
    remove_dead_agents,
    update_agent_status,
)
from drasill.supervisor_client import get_status, send_input
from drasill.supervisor_client import is_alive as sup_is_alive

if TYPE_CHECKING:
    import aiosqlite

    from drasill.config import PruningConfig
    from drasill.mesh.events import MeshEventBus

logger = logging.getLogger(__name__)

_REMOVE_SECONDS = 3600  # remove dead agents after 1 hour
_PROBE_INTERVAL = 5  # seconds between monitoring cycles


class ProbeResult:
    """Result of probing an agent's status."""

    __slots__ = ("agent_state", "state_ms", "status")

    def __init__(
        self,
        status: str,
        agent_state: str = "idle",
        state_ms: int = 0,
    ) -> None:
        """Initialize probe result with status, agent_state, and state_ms."""
        self.status = status
        self.agent_state = agent_state
        self.state_ms = state_ms


async def _probe_via_supervisor(session_id: str) -> ProbeResult:
    """Probe agent status via heimdall supervisor socket.

    Uses ground-truth state from the pty output classifier.
    """
    if not sup_is_alive(session_id):
        return ProbeResult("dead", "dead")
    try:
        status = await get_status(session_id)
    except (OSError, TimeoutError, ValueError):
        return ProbeResult("dead", "dead")
    if not status["alive"]:
        return ProbeResult("dead", "dead")

    agent_state = status.get("state")
    state_ms = status.get("state_ms", 0)

    if agent_state is None:
        # Heimdall always sends 15-byte STATUS_RESP with state field.
        # If missing, treat as active (defensive).
        agent_state = "active"

    mesh_status = "idle" if agent_state == "idle" else "active"
    return ProbeResult(mesh_status, agent_state, state_ms)


async def _probe_agent(agent: dict) -> ProbeResult:
    """Determine an agent's status via heimdall supervisor.

    Returns a ProbeResult with status, agent_state, and state_ms.
    """
    session_id = agent.get("session_id")
    if not session_id:
        return ProbeResult("active")
    return await _probe_via_supervisor(session_id)


async def _deliver_inbox_on_idle(
    db: aiosqlite.Connection,
    agent: dict,
) -> None:
    """Deliver pending inbox messages to an agent that just went idle.

    Uses peek-then-consume: peek at the oldest unread message, attempt
    delivery via heimdall INPUT frame, and only mark as read if delivery
    succeeds. If delivery fails, the message stays in the inbox for
    the next idle cycle.
    """
    name = agent["name"]
    session_id = agent.get("session_id")
    if not session_id:
        return

    msg = await peek_next_message(db, name)
    if not msg:
        return

    from_agent = msg["from_agent"]
    body = msg["body"][:4096]  # cap length to avoid pty buffer overflow
    wake_text = f"\n[drasill:message from {from_agent}] {body}\n"

    try:
        await send_input(session_id, wake_text.encode())
    except (OSError, TimeoutError, ValueError):
        logger.warning(
            "Failed to deliver message %d to %s — will retry next idle cycle",
            msg["id"],
            name,
        )
        return

    # Delivery succeeded — now consume (mark as read).
    await consume_next_message(db, name)
    logger.info(
        "Delivered inbox message %d to idle agent %s via stdin",
        msg["id"],
        name,
    )


async def run_monitoring_loop(
    db: aiosqlite.Connection,
    event_bus: MeshEventBus,
    *,
    config: PruningConfig | None = None,
) -> None:
    """Monitor agents on a loop until cancelled.

    Each cycle probes all agents concurrently, updates statuses,
    and removes long-dead agents.

    Args:
        db: Database connection.
        event_bus: SSE bus to notify clients of state changes.
        config: Optional thresholds (uses module defaults if None).

    """
    interval = config.interval if config else _PROBE_INTERVAL
    remove_secs = config.remove_seconds if config else _REMOVE_SECONDS
    while True:
        try:
            changed = await monitor_agents(db, remove_seconds=remove_secs)
            if changed:
                event_bus.publish("refresh")
        except asyncio.CancelledError:
            raise
        except sqlite3.OperationalError as exc:
            if "locked" in str(exc).lower():
                logger.warning("Monitoring skipped — database is locked")
            else:
                logger.exception("Monitoring cycle failed")
        except Exception:
            logger.exception("Monitoring cycle failed")
        await asyncio.sleep(interval)


async def monitor_agents(
    db: aiosqlite.Connection,
    *,
    remove_seconds: int = _REMOVE_SECONDS,
) -> bool:
    """Run a single monitoring cycle.

    1. Probe all agents concurrently via heimdall
    2. Dead session → deregister immediately
    3. Active/idle → update status
    4. Long-dead agents → remove

    Args:
        db: Database connection.
        remove_seconds: Seconds after which dead agents are removed.

    Returns:
        True if any agents changed state or were removed.

    """
    all_agents = await list_agents(db)
    if not all_agents:
        return False

    # Split live vs dead — only probe live agents
    live_agents = [a for a in all_agents if a["status"] != "dead"]

    # Probe all live agents concurrently
    tasks = [_probe_agent(a) for a in live_agents]
    statuses = await asyncio.gather(*tasks)

    changed = False

    for agent, result in zip(live_agents, statuses, strict=True):
        name = agent["name"]
        old_status = agent["status"]

        if result.status == "dead":
            await deregister_agent(db, name)
            logger.info(
                "Agent died — deregistered: %s (session=%s)",
                name,
                agent.get("session_id"),
            )
            changed = True
        elif result.status != old_status or result.agent_state != agent.get(
            "agent_state", "idle"
        ):
            await update_agent_status(
                db,
                name,
                result.status,
                agent_state=result.agent_state,
                state_ms=result.state_ms,
            )
            changed = True

            # Idle wake: deliver inbox messages when agent becomes idle.
            if old_status == "active" and result.status == "idle":
                await _deliver_inbox_on_idle(db, agent)

    # Remove long-dead agents (ones that were already dead before this cycle)
    now_ts = int(datetime.now(tz=UTC).timestamp())
    remove_cutoff_ts = now_ts - remove_seconds

    undelivered = await fetch_undelivered_to_dead(db, remove_cutoff_ts)
    for msg in undelivered:
        logger.warning(
            "Undeliverable message id=%d to dead agent %s from %s: %s",
            msg["id"],
            msg["to_agent"],
            msg["from_agent"],
            msg["body"][:100],
        )

    removed = await remove_dead_agents(db, remove_cutoff_ts)
    for name in removed:
        logger.info("Removed dead agent: %s", name)
    if removed:
        changed = True

    if changed:
        await db.commit()
    return changed
