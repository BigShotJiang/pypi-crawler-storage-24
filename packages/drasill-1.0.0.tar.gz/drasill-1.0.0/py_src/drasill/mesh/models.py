"""Pydantic models for mesh API request/response payloads."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class AgentRegisterRequest(BaseModel):
    """Request body for POST /mesh/agents (register)."""

    name: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9_-]+$")
    pid: int | None = None
    session_id: str | None = None
    idle_timeout: int = Field(default=120, ge=30, le=3600)


class AgentInfo(BaseModel):
    """Agent details returned by the API."""

    name: str
    pid: int | None = None
    session_id: str | None = None
    registered_at: str = ""
    last_heartbeat: str = ""
    status: str = "active"
    idle_timeout: int = 120
    agent_state: str = "idle"
    state_ms: int = 0


class MessageSendRequest(BaseModel):
    """Request body for POST /mesh/agents/{name}/inbox."""

    from_agent: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9_-]+$")
    body: str = Field(min_length=1, max_length=10000)
    priority: Literal["normal", "urgent"] = "normal"


class LinkAttachmentsRequest(BaseModel):
    """Request body for POST /mesh/upload/link."""

    message_id: int
    attachment_ids: list[str] = Field(min_length=1)


class MessageInfo(BaseModel):
    """Message returned by inbox/outbox endpoints."""

    id: int
    to_agent: str
    from_agent: str
    body: str
    priority: str = "normal"
    created_at: str
    read_at: str | None = None
