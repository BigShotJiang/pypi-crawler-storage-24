"""File upload storage for mesh attachments."""

from __future__ import annotations

import uuid
from pathlib import Path

_DEFAULT_UPLOAD_DIR = Path("~/.local/share/drasill/uploads").expanduser()

# Allowed MIME types for uploads.
ALLOWED_TYPES: set[str] = {
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
    "image/svg+xml",
    "text/plain",
    "application/json",
    "application/pdf",
    "text/markdown",
    "text/csv",
    "application/octet-stream",
}

# 10 MiB per file.
MAX_FILE_SIZE = 10 * 1024 * 1024


def upload_dir() -> Path:
    """Return the uploads directory, creating it if needed."""
    _DEFAULT_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    return _DEFAULT_UPLOAD_DIR


def generate_file_id() -> str:
    """Generate a unique file ID."""
    return uuid.uuid4().hex[:16]


def file_path(file_id: str) -> Path:
    """Return the on-disk path for a given file ID."""
    return upload_dir() / file_id
