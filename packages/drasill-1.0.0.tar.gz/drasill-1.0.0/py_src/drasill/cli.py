"""CLI entry point for drasill.

Provides ``drasill serve`` and ``drasill install`` commands.
"""

from __future__ import annotations

import asyncio
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile
import textwrap
from pathlib import Path
from typing import Annotated
from urllib.request import urlopen

import typer
import uvicorn

from drasill import __version__
from drasill.app import create_app
from drasill.config import load_config
from drasill.doctor import check_deps

app = typer.Typer(
    name="drasill",
    help="Drasill — personal dashboard server and agent mesh.",
    no_args_is_help=True,
)
install_app = typer.Typer(
    name="install",
    help="Generate and install service files.",
    no_args_is_help=True,
)
app.add_typer(install_app)

_SYSTEMD_DIR = Path.home() / ".config" / "systemd" / "user"

_HostOpt = Annotated[
    str,
    typer.Option(help="Bind address."),
]
_PortOpt = Annotated[
    int,
    typer.Option(help="Bind port."),
]
_ConfigOpt = Annotated[
    str | None,
    typer.Option(help="Path to config.toml."),
]
_EnableOpt = Annotated[
    bool,
    typer.Option(help="Enable and start immediately."),
]


def _version_callback(value: bool) -> None:  # noqa: FBT001
    """Print version and exit."""
    if value:
        typer.echo(f"drasill {__version__}")
        raise typer.Exit


def _drasill_bin() -> str:
    """Return the path to the drasill executable."""
    return shutil.which("drasill") or f"{sys.prefix}/bin/drasill"


def _systemd_unit(
    host: str,
    port: int,
    config_path: str | None,
) -> str:
    """Generate the drasill systemd unit file contents."""
    drasill = _drasill_bin()
    env_line = ""
    if config_path:
        env_line = f"\nEnvironment=DRASILL_CONFIG={config_path}"
    return textwrap.dedent(f"""\
        [Unit]
        Description=drasill — personal dashboard server
        After=network-online.target
        Wants=network-online.target

        [Service]
        Type=simple
        ExecStart={drasill} serve --host {host} --port {port}
        Restart=on-failure
        RestartSec=5{env_line}

        [Install]
        WantedBy=default.target
    """)


def _cloudflared_unit(config_path: str) -> str:
    """Generate the cloudflared systemd unit file contents."""
    return textwrap.dedent(f"""\
        [Unit]
        Description=Cloudflare Tunnel — drasill
        After=network-online.target
        Wants=network-online.target

        [Service]
        Type=simple
        ExecStart=/usr/local/bin/cloudflared tunnel \
--config {config_path} run
        Restart=on-failure
        RestartSec=5

        [Install]
        WantedBy=default.target
    """)


def _cloudflared_yml() -> str:
    """Generate the cloudflared config template."""
    return textwrap.dedent("""\
        # Cloudflare Tunnel config for drasill
        # Replace <tunnel-id> after running:
        #   cloudflared tunnel create drasill
        # Replace <domain> with your actual domain
        #
        # Setup steps:
        #   1. cloudflared tunnel create drasill
        #   2. cloudflared tunnel route dns drasill dash.<domain>
        #   3. Configure Cloudflare Access application policy
        #   4. systemctl --user enable --now cloudflared

        tunnel: <tunnel-id>
        credentials-file: ~/.cloudflared/<tunnel-id>.json

        ingress:
          - hostname: dash.<domain>
            service: http://localhost:8400
          - service: http_status:404
    """)


def _systemctl(*args: str) -> None:
    """Run a systemctl --user command."""
    subprocess.run(
        ["systemctl", "--user", *args],
        check=True,
    )


@app.callback()
def _main(
    _version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Show version and exit.",
        ),
    ] = False,
) -> None:
    """Drasill — personal dashboard server and agent mesh."""


@app.command()
def serve(
    host: _HostOpt = "0.0.0.0",  # noqa: S104
    port: _PortOpt = 8400,
    reload: Annotated[
        bool,
        typer.Option(help="Enable auto-reload (dev mode)."),
    ] = False,
    config: _ConfigOpt = None,
) -> None:
    """Start the drasill server."""
    if config:
        os.environ["DRASILL_CONFIG"] = config

    cfg = load_config()
    application = create_app(cfg)
    uvicorn.run(application, host=host, port=port, reload=reload)


@install_app.command("systemd")
def install_systemd(
    host: _HostOpt = "0.0.0.0",  # noqa: S104
    port: _PortOpt = 8400,
    config: _ConfigOpt = None,
    enable: _EnableOpt = False,
    print_only: Annotated[
        bool,
        typer.Option(
            "--print-only",
            help="Print the unit file only.",
        ),
    ] = False,
) -> None:
    """Install drasill as a systemd user service."""
    unit = _systemd_unit(host, port, config)

    if print_only:
        typer.echo(unit)
        return

    _SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)
    unit_path = _SYSTEMD_DIR / "drasill.service"
    unit_path.write_text(unit)
    typer.echo(f"Wrote {unit_path}")

    if enable:
        _systemctl("daemon-reload")
        _systemctl("enable", "--now", "drasill.service")
        typer.echo("Service enabled and started.")
    else:
        typer.echo("\nTo activate:")
        typer.echo("  systemctl --user daemon-reload")
        typer.echo("  systemctl --user enable --now drasill")

    typer.echo("\nCheck status:")
    typer.echo("  systemctl --user status drasill")
    typer.echo("  journalctl --user -u drasill -f")


@install_app.command("cloudflared")
def install_cloudflared(
    tunnel_config: Annotated[
        str,
        typer.Option(help="Path for cloudflared config."),
    ] = str(
        Path.home() / ".config" / "drasill" / "cloudflared.yml",
    ),
    enable: _EnableOpt = False,
    print_only: Annotated[
        bool,
        typer.Option(
            "--print-only",
            help="Print the unit files only.",
        ),
    ] = False,
) -> None:
    """Install cloudflared tunnel as a systemd user service."""
    tunnel_config_path = Path(tunnel_config)
    unit = _cloudflared_unit(tunnel_config)
    yml = _cloudflared_yml()

    if print_only:
        typer.echo("# cloudflared.service")
        typer.echo(unit)
        typer.echo("# cloudflared.yml")
        typer.echo(yml)
        return

    if not tunnel_config_path.exists():
        tunnel_config_path.parent.mkdir(parents=True, exist_ok=True)
        tunnel_config_path.write_text(yml)
        typer.echo(f"Wrote {tunnel_config_path}")
        typer.echo("  Edit with your tunnel ID and domain.")
    else:
        typer.echo(f"Config exists: {tunnel_config_path}")

    _SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)
    unit_path = _SYSTEMD_DIR / "cloudflared.service"
    unit_path.write_text(unit)
    typer.echo(f"Wrote {unit_path}")

    if not shutil.which("cloudflared"):
        typer.echo(
            "\nWARNING: cloudflared not found in PATH.\n"
            "  https://developers.cloudflare.com/"
            "cloudflare-one/connections/"
            "connect-networks/downloads/",
        )
        return

    if enable:
        content = tunnel_config_path.read_text()
        if "<tunnel-id>" in content:
            typer.echo("\ncloudflared.yml has placeholders.")
            typer.echo("  1. cloudflared tunnel create drasill")
            typer.echo(f"  2. Edit {tunnel_config_path}")
            typer.echo("  3. systemctl --user enable --now cloudflared")
        else:
            _systemctl("daemon-reload")
            _systemctl("enable", "--now", "cloudflared.service")
            typer.echo("Service enabled and started.")
    else:
        typer.echo("\nTo activate:")
        typer.echo("  systemctl --user daemon-reload")
        typer.echo("  systemctl --user enable --now cloudflared")


_HM_REPO = "nazq/heimdall"
_HM_TARGETS = {
    ("Linux", "x86_64"): "x86_64-unknown-linux-gnu",
    ("Linux", "aarch64"): "aarch64-unknown-linux-gnu",
    ("Darwin", "x86_64"): "x86_64-apple-darwin",
    ("Darwin", "arm64"): "aarch64-apple-darwin",
}


@install_app.command("hm")
def install_hm(
    version: Annotated[
        str, typer.Option(help="Version tag (e.g. v1.0.0) or 'latest'.")
    ] = "latest",
    dest: Annotated[
        str, typer.Option(help="Destination directory for the hm binary.")
    ] = str(Path.home() / ".local/bin"),
) -> None:  # pragma: no cover
    """Download and install the heimdall (hm) session supervisor."""
    system = platform.system()
    machine = platform.machine()
    target = _HM_TARGETS.get((system, machine))
    if not target:
        typer.echo(f"Unsupported platform: {system}-{machine}", err=True)
        raise typer.Exit(code=1)

    # Resolve version tag.
    if version == "latest":
        url = f"https://api.github.com/repos/{_HM_REPO}/releases/latest"
        with urlopen(url) as resp:  # noqa: S310
            tag = json.loads(resp.read())["tag_name"]
    else:
        tag = version

    asset = f"heimdall-{target}.tar.gz"
    download_url = f"https://github.com/{_HM_REPO}/releases/download/{tag}/{asset}"
    typer.echo(f"Downloading hm {tag} for {target}...")

    dest_path = Path(dest)
    dest_path.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        archive_path = Path(tmpdir) / asset
        with urlopen(download_url) as resp, archive_path.open("wb") as f:  # noqa: S310
            f.write(resp.read())

        with tarfile.open(archive_path) as tar:
            # Find the hm binary in the archive.
            for member in tar.getmembers():
                if member.name.endswith("/hm") or member.name == "hm":
                    member.name = "hm"  # flatten path
                    tar.extract(member, dest_path, filter="data")
                    break
            else:
                typer.echo("hm binary not found in archive", err=True)
                raise typer.Exit(code=1)

    hm_path = dest_path / "hm"
    hm_path.chmod(0o755)
    typer.echo(f"Installed: {hm_path}")

    result = subprocess.run(
        [str(hm_path), "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        typer.echo(result.stdout.strip())


@app.command("reset-state")
def reset_state(
    config: _ConfigOpt = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt."),
    ] = False,
) -> None:
    """Delete the SQLite database so the next start creates a fresh one."""
    if config:
        os.environ["DRASILL_CONFIG"] = config
    cfg = load_config()
    db_path = Path(cfg.db.path)

    if not db_path.exists():
        typer.echo(f"Nothing to reset — {db_path} does not exist.")
        return

    if not force:
        typer.confirm(f"Delete {db_path}?", abort=True)

    # Also remove WAL/SHM sidecar files
    for suffix in ("", "-wal", "-shm"):
        p = db_path.parent / (db_path.name + suffix)
        if p.exists():
            p.unlink()
            typer.echo(f"Removed {p}")

    typer.echo("State reset. Next `drasill serve` will create a fresh database.")


@app.command("check-deps")
def check_deps_cmd() -> None:
    """Check that required and optional tools are installed."""
    results = asyncio.run(check_deps())
    all_ok = True
    for dep in results:
        if dep.found:
            version = f" ({dep.version})" if dep.version else ""
            typer.echo(f"  [ok] {dep.name} — {dep.path}{version}")
        else:
            marker = "MISSING" if dep.required else "----"
            typer.echo(f"  [{marker}] {dep.name} — {dep.description}")
            typer.echo(f"           {dep.url}")
            if dep.required:
                all_ok = False

    if all_ok:
        typer.echo("\nAll required dependencies found.")
    else:
        typer.echo("\nSome required dependencies are missing.")
        raise typer.Exit(code=1)


def main() -> None:
    """Entry point for ``drasill`` command."""
    app()
