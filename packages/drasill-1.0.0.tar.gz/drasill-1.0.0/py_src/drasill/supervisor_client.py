"""Async client for communicating with heimdall Unix sockets.

Binary framing protocol: each message is [type: u8][len: u32 BE][payload: len bytes].
The supervisor sends a mode byte (0x00 = binary) on connect before any frames.
"""

from __future__ import annotations

import asyncio
import struct
from pathlib import Path
from typing import Any

# Default socket directory — matches heimdall default.
SESSIONS_DIR = Path("~/.local/share/drasill/sessions").expanduser()

# Client -> Supervisor message types.
INPUT = 0x01
SUBSCRIBE = 0x02
STATUS = 0x03
RESIZE = 0x04
KILL = 0x05

# Supervisor -> Client message types.
OUTPUT = 0x81
STATUS_RESP = 0x82
EXIT = 0x83

# Mode byte sent by supervisor on connect.
MODE_BINARY = 0x00

# Status response payload sizes (bytes).
_STATUS_LEGACY_LEN = 9  # pid(4) + idle_ms(4) + alive(1)
_STATUS_EXTENDED_LEN = 15  # legacy + state(1) + state_ms(4) + reserved(1)

# Agent state byte → name mapping (protocol-global, matches heimdall).
_STATE_NAMES: dict[int, str] = {
    0x00: "idle",
    0x01: "thinking",
    0x02: "streaming",
    0x03: "tool_use",
    0x04: "active",
    0xFF: "dead",
}


def _pack_frame(msg_type: int, payload: bytes = b"") -> bytes:
    """Pack a binary frame: [type][len BE][payload]."""
    return struct.pack(">BI", msg_type, len(payload)) + payload


async def _read_frame(reader: asyncio.StreamReader) -> tuple[int, bytes]:
    """Read one binary frame. Returns (type, payload).

    Raises:
        asyncio.IncompleteReadError: If the connection closes mid-frame.

    """
    header = await reader.readexactly(5)
    msg_type, length = struct.unpack(">BI", header)
    payload = await reader.readexactly(length) if length else b""
    return msg_type, payload


async def _connect(
    session_id: str,
    socket_dir: Path | None = None,
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    """Connect to a session socket and consume the mode byte.

    Args:
        session_id: Session identifier (matches heimdall --id).
        socket_dir: Override socket directory (default: SESSIONS_DIR).

    Returns:
        (reader, writer) pair ready for frame I/O.

    Raises:
        FileNotFoundError: If the socket file does not exist.
        ConnectionRefusedError: If the supervisor is not accepting.

    """
    sock_dir = socket_dir or SESSIONS_DIR
    sock_path = sock_dir / f"{session_id}.sock"
    reader, writer = await asyncio.open_unix_connection(sock_path)
    # Consume mode byte (0x00 = binary).
    mode = await reader.readexactly(1)
    if mode[0] != MODE_BINARY:
        writer.close()
        await writer.wait_closed()
        msg = f"Unsupported protocol mode: 0x{mode[0]:02x}"
        raise ValueError(msg)
    return reader, writer


async def send_input(
    session_id: str,
    data: bytes,
    *,
    socket_dir: Path | None = None,
) -> None:
    """Write bytes to a session's pty via heimdall INPUT frame.

    Args:
        session_id: Target session.
        data: Raw bytes to write to the pty.
        socket_dir: Override socket directory.

    """
    _, writer = await _connect(session_id, socket_dir)
    writer.write(_pack_frame(INPUT, data))
    await writer.drain()
    writer.close()
    await writer.wait_closed()


async def get_status(
    session_id: str,
    *,
    socket_dir: Path | None = None,
) -> dict[str, Any]:
    """Query session status via heimdall STATUS protocol.

    Args:
        session_id: Target session.
        socket_dir: Override socket directory.

    Returns:
        Dict with keys: pid (int), idle_ms (int), alive (bool).

    Raises:
        ValueError: If the response is malformed.

    """
    reader, writer = await _connect(session_id, socket_dir)
    writer.write(_pack_frame(STATUS))
    await writer.drain()
    msg_type, payload = await asyncio.wait_for(_read_frame(reader), timeout=2)
    writer.close()
    await writer.wait_closed()
    if msg_type != STATUS_RESP or len(payload) < _STATUS_LEGACY_LEN:
        msg = f"Unexpected status response: type=0x{msg_type:02x}, len={len(payload)}"
        raise ValueError(msg)
    pid, idle_ms, alive = struct.unpack(">IIB", payload[:_STATUS_LEGACY_LEN])
    result: dict[str, Any] = {
        "pid": pid,
        "idle_ms": idle_ms,
        "alive": bool(alive),
    }
    # Extended status: state byte (u8) + state_ms (u32) + reserved (u8).
    ext_fmt = ">BI"
    ext_size = struct.calcsize(ext_fmt)
    if len(payload) >= _STATUS_EXTENDED_LEN:
        state_byte, state_ms = struct.unpack(
            ext_fmt,
            payload[_STATUS_LEGACY_LEN : _STATUS_LEGACY_LEN + ext_size],
        )
        result["state"] = _STATE_NAMES.get(state_byte, "unknown")
        result["state_ms"] = state_ms
    return result


async def subscribe(
    session_id: str,
    *,
    socket_dir: Path | None = None,
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    """Open a persistent subscription for terminal streaming.

    The caller receives (reader, writer). Output frames (0x81) and exit
    frames (0x83) arrive on the reader. The caller can send INPUT and
    RESIZE frames via the writer using ``_pack_frame``.

    Args:
        session_id: Target session.
        socket_dir: Override socket directory.

    Returns:
        (reader, writer) — caller owns the connection lifetime.

    """
    reader, writer = await _connect(session_id, socket_dir)
    writer.write(_pack_frame(SUBSCRIBE))
    await writer.drain()
    return reader, writer


async def send_resize(
    writer: asyncio.StreamWriter,
    cols: int,
    rows: int,
) -> None:
    """Send a resize event to the supervisor.

    Args:
        writer: Writer from a subscribe() connection.
        cols: Terminal width.
        rows: Terminal height.

    """
    payload = struct.pack(">HH", cols, rows)
    writer.write(_pack_frame(RESIZE, payload))
    await writer.drain()


async def send_kill(
    session_id: str,
    *,
    socket_dir: Path | None = None,
) -> None:
    """Send SIGTERM to the supervised child process.

    Args:
        session_id: Target session.
        socket_dir: Override socket directory.

    """
    _, writer = await _connect(session_id, socket_dir)
    writer.write(_pack_frame(KILL))
    await writer.drain()
    writer.close()
    await writer.wait_closed()


def is_alive(session_id: str, *, socket_dir: Path | None = None) -> bool:
    """Check whether the socket file exists on disk.

    Args:
        session_id: Target session.
        socket_dir: Override socket directory.

    Returns:
        True if the socket file exists on disk.

    """
    sock_dir = socket_dir or SESSIONS_DIR
    return (sock_dir / f"{session_id}.sock").exists()


def list_sessions(*, socket_dir: Path | None = None) -> list[str]:
    """Discover active sessions by globbing socket files.

    Args:
        socket_dir: Override socket directory.

    Returns:
        Sorted list of session IDs.

    """
    sock_dir = socket_dir or SESSIONS_DIR
    if not sock_dir.exists():
        return []
    return sorted(p.stem for p in sock_dir.glob("*.sock"))
