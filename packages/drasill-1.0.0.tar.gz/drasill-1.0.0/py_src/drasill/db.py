"""SQLite database setup and data access layer.

All SQL queries live here — callers interact with the database through
these functions and never write SQL directly.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import aiosqlite

logger = logging.getLogger(__name__)

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS mesh_agents (
    name            TEXT PRIMARY KEY,
    pid             INTEGER,
    session_id      TEXT,
    registered_at   TEXT NOT NULL,
    last_heartbeat  TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'active',
    idle_timeout    INTEGER NOT NULL DEFAULT 120,
    agent_state        TEXT NOT NULL DEFAULT 'idle',
    state_ms        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS mesh_messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    to_agent        TEXT NOT NULL,
    from_agent      TEXT NOT NULL,
    body            TEXT NOT NULL,
    priority        TEXT NOT NULL DEFAULT 'normal',
    created_at      TEXT NOT NULL,
    read_at         TEXT,
    acked_at        TEXT,
    FOREIGN KEY (to_agent) REFERENCES mesh_agents(name)
);

CREATE INDEX IF NOT EXISTS idx_mesh_messages_inbox
    ON mesh_messages(to_agent, read_at);

CREATE INDEX IF NOT EXISTS idx_mesh_messages_outbox
    ON mesh_messages(from_agent, created_at DESC);

CREATE TABLE IF NOT EXISTS mesh_attachments (
    id          TEXT PRIMARY KEY,
    filename    TEXT NOT NULL,
    content_type TEXT NOT NULL,
    size        INTEGER NOT NULL,
    message_id  INTEGER,
    uploaded_at TEXT NOT NULL
);
"""


def utc_now() -> str:
    """Return current UTC timestamp as ISO string."""
    return datetime.now(tz=UTC).isoformat()


async def init_db(db_path: str) -> aiosqlite.Connection:
    """Open (or create) the database and ensure schema exists.

    Args:
        db_path: Expanded filesystem path to the SQLite file.

    Returns:
        An open aiosqlite connection.

    """
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    db = await aiosqlite.connect(str(path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode = WAL")
    await db.execute("PRAGMA busy_timeout = 5000")
    await db.execute("PRAGMA foreign_keys = ON")
    await db.execute("PRAGMA synchronous = NORMAL")
    await db.executescript(_SCHEMA)

    # Migrate: add session_id column if missing (existing databases).
    try:
        await db.execute("SELECT session_id FROM mesh_agents LIMIT 0")
    except aiosqlite.OperationalError:
        await db.execute("ALTER TABLE mesh_agents ADD COLUMN session_id TEXT")

    # Migrate: drop tmux_target column (replaced by session_id).
    # SQLite doesn't support DROP COLUMN before 3.35 — just ignore it if present.

    # Migrate: add agent_state and state_ms columns (state machine).
    try:
        await db.execute("SELECT agent_state FROM mesh_agents LIMIT 0")
    except aiosqlite.OperationalError:
        await db.execute(
            "ALTER TABLE mesh_agents"
            " ADD COLUMN agent_state TEXT NOT NULL DEFAULT 'idle'",
        )
        await db.execute(
            "ALTER TABLE mesh_agents ADD COLUMN state_ms INTEGER NOT NULL DEFAULT 0",
        )

    await db.commit()

    # Probe the DB to detect stale locks early (zombie uvicorn workers, etc.)
    try:
        await db.execute("SELECT 1")
    except aiosqlite.OperationalError as exc:
        if "locked" in str(exc).lower():
            logger.warning(
                "Database is locked — a stale process may be holding %s. "
                "Check with: fuser %s",
                path,
                path,
            )
        raise

    return db


# =====================================================================
# Agents
# =====================================================================


async def get_agent(
    db: aiosqlite.Connection,
    name: str,
) -> dict[str, Any] | None:
    """Fetch a single agent by name, or None if not found."""
    cursor = await db.execute(
        "SELECT * FROM mesh_agents WHERE name = ?",
        (name,),
    )
    row = await cursor.fetchone()
    return dict(row) if row else None


async def get_agent_session_id(
    db: aiosqlite.Connection,
    name: str,
) -> str | None:
    """Fetch the session_id for an agent, or None."""
    cursor = await db.execute(
        "SELECT session_id FROM mesh_agents WHERE name = ?",
        (name,),
    )
    row = await cursor.fetchone()
    if not row:
        return None
    return row["session_id"]


async def get_agent_by_session_id(
    db: aiosqlite.Connection,
    session_id: str,
) -> dict[str, Any] | None:
    """Fetch an agent by its session_id, or None."""
    cursor = await db.execute(
        "SELECT name FROM mesh_agents WHERE session_id = ?",
        (session_id,),
    )
    row = await cursor.fetchone()
    return dict(row) if row else None


async def list_agents(db: aiosqlite.Connection) -> list[dict[str, Any]]:
    """Fetch all agents ordered by name."""
    cursor = await db.execute("SELECT * FROM mesh_agents ORDER BY name")
    return [dict(r) for r in await cursor.fetchall()]


async def list_agents_with_unread(
    db: aiosqlite.Connection,
) -> list[dict[str, Any]]:
    """Fetch agents with unread message counts (sidebar query)."""
    cursor = await db.execute(
        "SELECT a.name, a.status, a.session_id, "
        "a.agent_state, a.state_ms, "
        "COALESCE(m.cnt, 0) AS unread "
        "FROM mesh_agents a "
        "LEFT JOIN ("
        "  SELECT to_agent, COUNT(*) AS cnt "
        "  FROM mesh_messages WHERE read_at IS NULL "
        "  GROUP BY to_agent"
        ") m ON a.name = m.to_agent "
        "ORDER BY a.name",
    )
    return [dict(r) for r in await cursor.fetchall()]


async def insert_agent(
    db: aiosqlite.Connection,
    *,
    name: str,
    pid: int | None = None,
    session_id: str | None = None,
    idle_timeout: int = 120,
) -> bool:
    """INSERT OR IGNORE a new agent.

    Returns True if inserted, False if already exists.
    """
    now = utc_now()
    cursor = await db.execute(
        "INSERT OR IGNORE INTO mesh_agents "
        "(name, pid, session_id, "
        "registered_at, last_heartbeat, status, idle_timeout) "
        "VALUES (?, ?, ?, ?, ?, 'active', ?)",
        (name, pid, session_id, now, now, idle_timeout),
    )
    if cursor.rowcount == 0:
        return False
    await db.commit()
    return True


async def update_agent_status(
    db: aiosqlite.Connection,
    name: str,
    status: str,
    *,
    agent_state: str = "idle",
    state_ms: int = 0,
) -> None:
    """Update an agent's status, state, and last_heartbeat timestamp."""
    await db.execute(
        "UPDATE mesh_agents SET last_heartbeat = ?, status = ?, "
        "agent_state = ?, state_ms = ? WHERE name = ?",
        (utc_now(), status, agent_state, state_ms, name),
    )
    await db.commit()


async def deregister_agent(db: aiosqlite.Connection, name: str) -> None:
    """Delete agent + their messages + linked attachments."""
    await db.execute(
        "DELETE FROM mesh_attachments WHERE message_id IN "
        "(SELECT id FROM mesh_messages WHERE to_agent = ? OR from_agent = ?)",
        (name, name),
    )
    await db.execute(
        "DELETE FROM mesh_messages WHERE to_agent = ? OR from_agent = ?",
        (name, name),
    )
    await db.execute("DELETE FROM mesh_agents WHERE name = ?", (name,))
    await db.commit()


# =====================================================================
# Messages
# =====================================================================


async def list_recent_messages(
    db: aiosqlite.Connection,
    *,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Fetch most recent messages globally, with attachments."""
    cursor = await db.execute(
        "SELECT * FROM mesh_messages ORDER BY created_at DESC LIMIT ?",
        (limit,),
    )
    messages = [dict(r) for r in await cursor.fetchall()]
    await attach_file_metadata(db, messages)
    return messages


async def list_agent_messages(
    db: aiosqlite.Connection,
    agent_name: str,
    *,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Fetch messages to/from a specific agent, with attachments."""
    cursor = await db.execute(
        "SELECT * FROM mesh_messages "
        "WHERE to_agent = ? OR from_agent = ? "
        "ORDER BY created_at DESC LIMIT ?",
        (agent_name, agent_name, limit),
    )
    messages = [dict(r) for r in await cursor.fetchall()]
    await attach_file_metadata(db, messages)
    return messages


async def list_outbox(
    db: aiosqlite.Connection,
    from_agent: str,
    *,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Fetch messages sent by an agent."""
    cursor = await db.execute(
        "SELECT * FROM mesh_messages WHERE from_agent = ? "
        "ORDER BY created_at DESC LIMIT ?",
        (from_agent, limit),
    )
    return [dict(r) for r in await cursor.fetchall()]


async def insert_message(
    db: aiosqlite.Connection,
    *,
    to_agent: str,
    from_agent: str,
    body: str,
    priority: str = "normal",
) -> int:
    """Insert a message and return its ID."""
    cursor = await db.execute(
        "INSERT INTO mesh_messages "
        "(to_agent, from_agent, body, priority, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (to_agent, from_agent, body, priority, utc_now()),
    )
    await db.commit()
    return cursor.lastrowid  # type: ignore[return-value]


async def peek_next_message(
    db: aiosqlite.Connection,
    to_agent: str,
) -> dict[str, Any] | None:
    """Return the oldest unread message without marking it as read."""
    cursor = await db.execute(
        "SELECT id, from_agent, body, priority, created_at "
        "FROM mesh_messages "
        "WHERE to_agent = ? AND read_at IS NULL "
        "ORDER BY id ASC LIMIT 1",
        (to_agent,),
    )
    row = await cursor.fetchone()
    return dict(row) if row else None


async def consume_next_message(
    db: aiosqlite.Connection,
    to_agent: str,
) -> dict[str, Any] | None:
    """Mark oldest unread message as read and return it, or None."""
    now = utc_now()
    cursor = await db.execute(
        "UPDATE mesh_messages SET read_at = ? "
        "WHERE id = ("
        "  SELECT id FROM mesh_messages "
        "  WHERE to_agent = ? AND read_at IS NULL "
        "  ORDER BY id ASC LIMIT 1"
        ") RETURNING id, from_agent, body, priority, created_at",
        (now, to_agent),
    )
    row = await cursor.fetchone()
    if not row:
        return None
    await db.commit()
    return {**dict(row), "read_at": now}


# =====================================================================
# Attachments
# =====================================================================


async def attach_file_metadata(
    db: aiosqlite.Connection,
    messages: list[dict[str, Any]],
) -> None:
    """Enrich message dicts in-place with their attachments list."""
    msg_ids = [m["id"] for m in messages if m.get("id")]
    if not msg_ids:
        for m in messages:
            m["attachments"] = []
        return
    ph = ",".join("?" for _ in msg_ids)
    cursor = await db.execute(
        f"SELECT id, filename, content_type, size, message_id "  # noqa: S608
        f"FROM mesh_attachments WHERE message_id IN ({ph})",
        msg_ids,
    )
    att_by_msg: dict[int, list[dict[str, Any]]] = {}
    for a in await cursor.fetchall():
        att_by_msg.setdefault(a["message_id"], []).append(dict(a))
    for m in messages:
        m["attachments"] = att_by_msg.get(m["id"], [])


async def get_attachments_for_message(
    db: aiosqlite.Connection,
    message_id: int,
) -> list[dict[str, Any]]:
    """Fetch attachments for a single message."""
    cursor = await db.execute(
        "SELECT id, filename, content_type, size FROM mesh_attachments "
        "WHERE message_id = ?",
        (message_id,),
    )
    return [dict(a) for a in await cursor.fetchall()]


async def get_attachment(
    db: aiosqlite.Connection,
    file_id: str,
) -> dict[str, Any] | None:
    """Fetch filename + content_type for a single attachment, or None."""
    cursor = await db.execute(
        "SELECT filename, content_type FROM mesh_attachments WHERE id = ?",
        (file_id,),
    )
    row = await cursor.fetchone()
    return dict(row) if row else None


async def insert_attachment(  # noqa: PLR0913
    db: aiosqlite.Connection,
    *,
    file_id: str,
    filename: str,
    content_type: str,
    size: int,
    message_id: int | None = None,
) -> None:
    """Insert an attachment record."""
    await db.execute(
        "INSERT INTO mesh_attachments "
        "(id, filename, content_type, size, message_id, uploaded_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (file_id, filename, content_type, size, message_id, utc_now()),
    )
    await db.commit()


async def link_attachments(
    db: aiosqlite.Connection,
    message_id: int,
    attachment_ids: list[str],
) -> None:
    """Set message_id on attachment rows."""
    ph = ",".join("?" for _ in attachment_ids)
    await db.execute(
        f"UPDATE mesh_attachments SET message_id = ? WHERE id IN ({ph})",  # noqa: S608
        [message_id, *attachment_ids],
    )
    await db.commit()


# =====================================================================
# Pruning (no auto-commit — caller manages the transaction)
# =====================================================================


async def fetch_undelivered_to_dead(
    db: aiosqlite.Connection,
    remove_cutoff_ts: int,
) -> list[dict[str, Any]]:
    """Fetch unread messages to dead agents past the removal threshold."""
    cursor = await db.execute(
        "SELECT m.id, m.to_agent, m.from_agent, m.body "
        "FROM mesh_messages m "
        "JOIN mesh_agents a ON m.to_agent = a.name "
        "WHERE a.status = 'dead' "
        "AND CAST(strftime('%s', a.last_heartbeat) AS INTEGER) < ? "
        "AND m.read_at IS NULL",
        (remove_cutoff_ts,),
    )
    return [dict(r) for r in await cursor.fetchall()]


async def remove_dead_agents(
    db: aiosqlite.Connection,
    remove_cutoff_ts: int,
) -> list[str]:
    """Delete dead agents past threshold + their messages.

    Returns list of removed agent names.
    Does not commit — caller manages the transaction.
    """
    cursor = await db.execute(
        "SELECT name FROM mesh_agents WHERE status = 'dead' "
        "AND CAST(strftime('%s', last_heartbeat) AS INTEGER) < ?",
        (remove_cutoff_ts,),
    )
    to_remove = [r[0] for r in await cursor.fetchall()]
    if to_remove:
        ph = ",".join("?" * len(to_remove))
        await db.execute(
            f"DELETE FROM mesh_messages WHERE to_agent IN ({ph}) "  # noqa: S608
            f"OR from_agent IN ({ph})",
            (*to_remove, *to_remove),
        )
        await db.execute(
            f"DELETE FROM mesh_agents WHERE name IN ({ph})",  # noqa: S608
            to_remove,
        )
    return to_remove
