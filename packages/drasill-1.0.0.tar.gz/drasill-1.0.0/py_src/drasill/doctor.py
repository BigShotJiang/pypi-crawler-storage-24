"""Dependency health checks — shared by CLI and dashboard."""

from __future__ import annotations

import asyncio
import shutil
from dataclasses import dataclass


@dataclass
class DepCheck:
    """Result of checking a single dependency."""

    name: str
    description: str
    url: str
    required: bool
    found: bool
    path: str | None = None
    version: str | None = None


DEPS: list[tuple[str, str, str]] = [
    (
        "uv",
        "Python package manager (required)",
        "https://docs.astral.sh/uv/getting-started/installation/",
    ),
    (
        "hm",
        "Session supervisor — heimdall (required)",
        "https://github.com/nazq/heimdall/releases",
    ),
    (
        "claude",
        "Claude Code CLI (required)",
        "https://docs.anthropic.com/en/docs/claude-code",
    ),
    (
        "cloudflared",
        "Cloudflare Tunnel (optional, remote access)",
        "https://developers.cloudflare.com/"
        "cloudflare-one/connections/"
        "connect-networks/downloads/",
    ),
    (
        "tailscale",
        "WireGuard mesh VPN (optional, remote access)",
        "https://tailscale.com/download",
    ),
]


async def _get_version(binary: str) -> str | None:
    """Try to get version string from a binary."""
    try:
        proc = await asyncio.create_subprocess_exec(
            binary,
            "--version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
        return (
            stdout.decode(errors="replace").strip().splitlines()[0] if stdout else None
        )
    except (TimeoutError, FileNotFoundError, IndexError):
        return None


async def check_deps() -> list[DepCheck]:
    """Check all dependencies and return results."""
    results: list[DepCheck] = []
    for name, description, url in DEPS:
        path = shutil.which(name)
        required = "required" in description
        version = None
        if path and name in ("hm", "claude"):
            version = await _get_version(name)
        results.append(
            DepCheck(
                name=name,
                description=description,
                url=url,
                required=required,
                found=path is not None,
                path=path,
                version=version,
            )
        )
    return results
