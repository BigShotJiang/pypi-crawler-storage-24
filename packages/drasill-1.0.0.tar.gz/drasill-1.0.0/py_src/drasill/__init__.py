"""Drasill — personal dashboard server and agent mesh control plane."""

__version__ = "0.1.0"
