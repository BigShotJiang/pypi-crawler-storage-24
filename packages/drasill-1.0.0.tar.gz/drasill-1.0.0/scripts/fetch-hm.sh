#!/usr/bin/env bash
# Download the heimdall (hm) binary from GitHub releases.
# Usage: scripts/fetch-hm.sh [version] [output-dir]
#
# Defaults: latest release, ./bin/
# Sets: HM_BIN=<output-dir>/hm

set -euo pipefail

VERSION="${1:-latest}"
OUTDIR="${2:-./bin}"
REPO="nazq/heimdall"

# Detect platform
case "$(uname -s)-$(uname -m)" in
    Linux-x86_64)  TARGET="x86_64-unknown-linux-gnu" ;;
    Linux-aarch64) TARGET="aarch64-unknown-linux-gnu" ;;
    Darwin-x86_64) TARGET="x86_64-apple-darwin" ;;
    Darwin-arm64)  TARGET="aarch64-apple-darwin" ;;
    *) echo "Unsupported platform: $(uname -s)-$(uname -m)" >&2; exit 1 ;;
esac

# Resolve version tag
if [ "$VERSION" = "latest" ]; then
    TAG=$(curl -sL "https://api.github.com/repos/$REPO/releases/latest" | grep '"tag_name"' | cut -d'"' -f4)
else
    TAG="$VERSION"
fi

if [ -z "$TAG" ]; then
    echo "Could not resolve release tag" >&2
    exit 1
fi

ASSET="heimdall-${TARGET}.tar.gz"
URL="https://github.com/$REPO/releases/download/$TAG/$ASSET"

mkdir -p "$OUTDIR"
_HM_TMP=$(mktemp -d)
echo "Downloading hm $TAG for $TARGET..."
curl -sL "$URL" | tar xz -C "$_HM_TMP"

# The tarball nests files in a directory — extract the binary.
find "$_HM_TMP" -name "hm" -type f -exec cp {} "$OUTDIR/hm" \;
rm -rf "$_HM_TMP"

if [[ ! -f "$OUTDIR/hm" ]]; then
    echo "hm binary not found in tarball" >&2
    exit 1
fi

chmod +x "$OUTDIR/hm"
echo "Installed: $OUTDIR/hm"
"$OUTDIR/hm" --version
