"""Nox configuration for build and test pipeline."""

import nox

nox.options.default_venv_backend = "uv"


@nox.session(python="3.13")
def lint(session: nox.Session) -> None:
    """Run ruff linting."""
    session.run("ruff", "check", "py_src", "py_tests")


@nox.session(python="3.13")
def format_check(session: nox.Session) -> None:
    """Check code formatting."""
    session.run("ruff", "format", "--check", "py_src", "py_tests")


@nox.session(python="3.13")
def format_fix(session: nox.Session) -> None:
    """Fix code formatting."""
    session.run("ruff", "format", "py_src", "py_tests")


@nox.session(python="3.13")
def type_check(session: nox.Session) -> None:
    """Run ty type checking."""
    session.install(".", "--group", "dev")
    session.run("ty", "check", "--python", session.virtualenv.location)


@nox.session(python="3.13")
def test(session: nox.Session) -> None:
    """Run pytest with coverage."""
    session.run(
        "pytest",
        "-v",
        "--cov=py_src/drasill",
        "--cov-report=term-missing",
        "--cov-report=xml:coverage.xml",
    )


@nox.session(python="3.13")
def all_checks(session: nox.Session) -> None:
    """Run all quality checks."""
    session.notify("lint")
    session.notify("format_check")
    session.notify("type_check")
    session.notify("test")
