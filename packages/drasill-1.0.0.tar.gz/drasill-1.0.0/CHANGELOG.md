# Changelog

## [1.0.0](https://github.com/nazq/Drasill/compare/v0.1.0...v1.0.0) (2026-03-15)


### ⚠ BREAKING CHANGES

* universal agent messaging — no hooks, no plugins, stdin injection ([#10](https://github.com/nazq/Drasill/issues/10))
* replace tmux with heimdall session supervisor

### Features

* add typer CLI, CI pipeline, and boost coverage to 99% ([5c66d16](https://github.com/nazq/Drasill/commit/5c66d166086fb66dc2df8f81e17277a08a21f987))
* comprehensive Playwright E2E tests for dashboard UX ([#9](https://github.com/nazq/Drasill/issues/9)) ([7f34490](https://github.com/nazq/Drasill/commit/7f3449075250df42955c8165f8e715d91a552ad9))
* file attachments with drag-drop, paste, and file picker ([3913ea3](https://github.com/nazq/Drasill/commit/3913ea377f09c54ca8fbce93bea0d7a3a638fc68))
* file attachments with drag-drop, paste, and file picker ([34aaee8](https://github.com/nazq/Drasill/commit/34aaee8fd74dfa00d2fb0b2bb3ccba36d9c34a19))
* file attachments, PWA branding, and operational hardening ([2ec5bc1](https://github.com/nazq/Drasill/commit/2ec5bc167003745242881daa3ca52852dcb9474b))
* ghostty-web terminal + mobile responsive UI ([c37bdb8](https://github.com/nazq/Drasill/commit/c37bdb8d1653931643260fb195e72007b930051f))
* initial commit — agent mesh control plane with web UI ([0fca876](https://github.com/nazq/Drasill/commit/0fca876474207faa5ad9c2d9b7a2952d70b4fd2a))
* PWA branding, graceful shutdown, DB lock handling, role removal, reset-state CLI ([5baa09a](https://github.com/nazq/Drasill/commit/5baa09a1c54d7c4b296df234d5e54225e862bd89))
* PyPI release infrastructure — metadata, install hm, release workflow ([#11](https://github.com/nazq/Drasill/issues/11)) ([199b599](https://github.com/nazq/Drasill/commit/199b599f5470e8910d09c017413dd88ab6a45475))
* replace tmux with heimdall session supervisor ([afe07b7](https://github.com/nazq/Drasill/commit/afe07b77fbd537fd537a078b721993b100e1d45b))
* replace xterm.js with ghostty-web and add mobile responsive UI ([15edcd7](https://github.com/nazq/Drasill/commit/15edcd704cc85cf645d6884d47541be41715bd12))
* terminal config UI, escape buffering, nerd fonts, layout versioning ([4f2a8c0](https://github.com/nazq/Drasill/commit/4f2a8c008fcd41083d25c96abdd42f1288cf3b28))
* terminal config UI, escape buffering, nerd fonts, layout versioning ([ea3613c](https://github.com/nazq/Drasill/commit/ea3613c0fc7b1db913730edf8ae0fa0e43414e52))
* tiling pane manager, settings page, and session creation ([3091335](https://github.com/nazq/Drasill/commit/30913354b178778539f824c7ad8eef0755730d47))
* tiling pane manager, settings, and session creation ([7727d40](https://github.com/nazq/Drasill/commit/7727d40ddd588b23d3298f31565ae29df54d2ce3))
* typer CLI for packaging and deployment ([4b04e8f](https://github.com/nazq/Drasill/commit/4b04e8fe10b048b50373c04cde532c7126216636))
* universal agent messaging — no hooks, no plugins, stdin injection ([#10](https://github.com/nazq/Drasill/issues/10)) ([71ee84a](https://github.com/nazq/Drasill/commit/71ee84a5286876d6aa429a4e96d4e73bddf0efd2))


### Bug Fixes

* add busy_timeout pragma to prevent database locked errors ([7b6ed67](https://github.com/nazq/Drasill/commit/7b6ed674833fee0c5e3d2e9882d04b2b8850848c))
* add contents:read permission to publish job ([7d430a2](https://github.com/nazq/Drasill/commit/7d430a2ec546e76aaaefd8d8042ca5a7df5c772d))
* address codebase audit findings ([b7c53f6](https://github.com/nazq/Drasill/commit/b7c53f635c5a78c01bd546ad686137573040eaa6))
* address PR review nits for terminal enhancements ([ce566be](https://github.com/nazq/Drasill/commit/ce566be148ced3a3e419cb03472de1d8c3efb108))


### Documentation

* add pinchtab browser automation section to CLAUDE.md ([460d542](https://github.com/nazq/Drasill/commit/460d54204f0ec4a941397becf231b8841247dc06))

## 0.1.0 (2026-03-15)


### ⚠ BREAKING CHANGES

* universal agent messaging — no hooks, no plugins, stdin injection ([#10](https://github.com/nazq/Drasill/issues/10))
* replace tmux with heimdall session supervisor

### Features

* add typer CLI, CI pipeline, and boost coverage to 99% ([5c66d16](https://github.com/nazq/Drasill/commit/5c66d166086fb66dc2df8f81e17277a08a21f987))
* comprehensive Playwright E2E tests for dashboard UX ([#9](https://github.com/nazq/Drasill/issues/9)) ([7f34490](https://github.com/nazq/Drasill/commit/7f3449075250df42955c8165f8e715d91a552ad9))
* file attachments with drag-drop, paste, and file picker ([3913ea3](https://github.com/nazq/Drasill/commit/3913ea377f09c54ca8fbce93bea0d7a3a638fc68))
* file attachments with drag-drop, paste, and file picker ([34aaee8](https://github.com/nazq/Drasill/commit/34aaee8fd74dfa00d2fb0b2bb3ccba36d9c34a19))
* file attachments, PWA branding, and operational hardening ([2ec5bc1](https://github.com/nazq/Drasill/commit/2ec5bc167003745242881daa3ca52852dcb9474b))
* ghostty-web terminal + mobile responsive UI ([c37bdb8](https://github.com/nazq/Drasill/commit/c37bdb8d1653931643260fb195e72007b930051f))
* initial commit — agent mesh control plane with web UI ([0fca876](https://github.com/nazq/Drasill/commit/0fca876474207faa5ad9c2d9b7a2952d70b4fd2a))
* PWA branding, graceful shutdown, DB lock handling, role removal, reset-state CLI ([5baa09a](https://github.com/nazq/Drasill/commit/5baa09a1c54d7c4b296df234d5e54225e862bd89))
* PyPI release infrastructure — metadata, install hm, release workflow ([#11](https://github.com/nazq/Drasill/issues/11)) ([199b599](https://github.com/nazq/Drasill/commit/199b599f5470e8910d09c017413dd88ab6a45475))
* replace tmux with heimdall session supervisor ([afe07b7](https://github.com/nazq/Drasill/commit/afe07b77fbd537fd537a078b721993b100e1d45b))
* replace xterm.js with ghostty-web and add mobile responsive UI ([15edcd7](https://github.com/nazq/Drasill/commit/15edcd704cc85cf645d6884d47541be41715bd12))
* terminal config UI, escape buffering, nerd fonts, layout versioning ([4f2a8c0](https://github.com/nazq/Drasill/commit/4f2a8c008fcd41083d25c96abdd42f1288cf3b28))
* terminal config UI, escape buffering, nerd fonts, layout versioning ([ea3613c](https://github.com/nazq/Drasill/commit/ea3613c0fc7b1db913730edf8ae0fa0e43414e52))
* tiling pane manager, settings page, and session creation ([3091335](https://github.com/nazq/Drasill/commit/30913354b178778539f824c7ad8eef0755730d47))
* tiling pane manager, settings, and session creation ([7727d40](https://github.com/nazq/Drasill/commit/7727d40ddd588b23d3298f31565ae29df54d2ce3))
* typer CLI for packaging and deployment ([4b04e8f](https://github.com/nazq/Drasill/commit/4b04e8fe10b048b50373c04cde532c7126216636))
* universal agent messaging — no hooks, no plugins, stdin injection ([#10](https://github.com/nazq/Drasill/issues/10)) ([71ee84a](https://github.com/nazq/Drasill/commit/71ee84a5286876d6aa429a4e96d4e73bddf0efd2))


### Bug Fixes

* add busy_timeout pragma to prevent database locked errors ([7b6ed67](https://github.com/nazq/Drasill/commit/7b6ed674833fee0c5e3d2e9882d04b2b8850848c))
* address codebase audit findings ([b7c53f6](https://github.com/nazq/Drasill/commit/b7c53f635c5a78c01bd546ad686137573040eaa6))
* address PR review nits for terminal enhancements ([ce566be](https://github.com/nazq/Drasill/commit/ce566be148ced3a3e419cb03472de1d8c3efb108))


### Documentation

* add pinchtab browser automation section to CLAUDE.md ([460d542](https://github.com/nazq/Drasill/commit/460d54204f0ec4a941397becf231b8841247dc06))
