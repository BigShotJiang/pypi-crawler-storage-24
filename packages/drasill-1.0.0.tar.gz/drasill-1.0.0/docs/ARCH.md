# Drasill Architecture

Agent mesh control plane and personal dashboard server for coordinating local Claude Code sessions.

## System Overview

```
┌─────────────────────────────────────────────────────┐
│                   Browser (HTMX)                    │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐ │
│  │ Sidebar  │  │  Pane    │  │  Terminal (WS +    │ │
│  │ (agents) │  │  Tiling  │  │  ghostty-web WASM) │ │
│  └────┬─────┘  └────┬─────┘  └─────────┬─────────┘ │
└───────┼──────────────┼──────────────────┼───────────┘
        │ SSE          │ HTTP             │ WebSocket
┌───────┴──────────────┴──────────────────┴───────────┐
│                 FastAPI (uvicorn)                    │
│  ┌────────┐  ┌──────────────────────────────────┐  │
│  │  Mesh  │  │ Terminal Router (heimdall client) │  │
│  │ Router │  └──────────────────────┬───────────┘  │
│  └───┬────┘                         │              │
│  ┌───┴─────────────────────────────────┴─────────┐   │
│  │            SQLite (WAL mode)                 │   │
│  └──────────────────────────────────────────────┘   │
│  ┌──────────────┐  ┌─────────────────────────┐      │
│  │ SSE EventBus │  │ Monitoring Loop (5s)    │      │
│  └──────────────┘  └─────────────────────────┘      │
└─────────────────────────────────────────────────────┘
        │
┌───────┴─────────────────────────────────────────────┐
│        Claude Code Instances (in heimdall)              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │ Agent A │  │ Agent B │  │ Agent C │  ...         │
│  └─────────┘  └─────────┘  └─────────┘              │
└─────────────────────────────────────────────────────┘
```

## Module Map

| Module | Purpose |
|--------|---------|
| `app.py` | FastAPI app factory, lifespan, page/API routes |
| `config.py` | TOML config → Pydantic models (`ServerConfig`, `DbConfig`, `PruningConfig`) |
| `db.py` | SQLite schema, WAL mode, connection factory |
| `claude.py` | Async wrapper for `claude -p` CLI |
| `mesh/` | Agent registry, messaging, SSE, pruning/monitoring |
| `terminal/` | WebSocket heimdall proxy, session creation, mesh prompt injection |
| `supervisor_client.py` | Unix socket client for heimdall IPC |

Detailed docs:

- [Database & Schema](./database.md)
- [Agent Mesh](./mesh.md)
- [Terminal Integration](./terminal.md)
- [Agent Integration](./plugin.md)
- [Frontend & Templates](./frontend.md)
- [Config & Deployment](./deployment.md)

## Data Flow

### Agent Registration

```
Claude Code instance → POST /mesh/agents → SQLite insert → SSE "refresh" → HTMX partial reload
```

### Message Delivery

```
Sender agent (or external channel)
  → POST /mesh/agents/{target}/inbox
    → SQLite insert
    → SSE "refresh" (dashboard update)
    → heimdall INPUT frame (if target has session_id)

Receiver agent
  → Drasill detects active→idle via STATUS polling
    → Writes message to stdin via heimdall INPUT frame
    → Agent sees message at prompt, processes it
```

### Terminal WebSocket

```
Browser
  → WS /terminal/{agent}/ws
    → Lookup agent's session_id in DB
    → Subscribe to heimdall Unix socket (push stream)
    → Input events (JSON) → heimdall INPUT frame
    → heimdall OUTPUT frames → raw binary to browser (xterm.js renders)
```

### Agent Lifecycle

```
active ──(no pty output)──→ idle ──(session gone)──→ deleted immediately
active ──(session gone)──────────────────────────→ deleted immediately
dead   ──(status=dead > 1h)──────────────────────→ removed (row + messages deleted)
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Python 3.13+ |
| Framework | FastAPI + uvicorn |
| Database | SQLite via aiosqlite (WAL mode) |
| Frontend | HTMX + Alpine.js + Tailwind CSS |
| Terminal | ghostty-web (Zig→WASM) + WebSocket |
| Process control | heimdall (Rust pty supervisor) |
| Linting | ruff (ALL rules) |
| Type checking | ty (strict) |
| Testing | pytest + pytest-asyncio, 95% gate |
| Build | hatchling, managed by uv |
| CI | nox (lint, format, types, test) |
