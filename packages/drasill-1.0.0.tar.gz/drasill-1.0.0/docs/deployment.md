# Config & Deployment

## Configuration

### Config File

`config.toml` at project root (or `DRASILL_CONFIG` env var):

```toml
[server]
host = "0.0.0.0"
port = 8400

[db]
path = "~/.local/share/drasill/dash.db"

[pruning]
interval = 5          # seconds between monitoring cycles
remove_seconds = 3600 # remove dead agents after this many seconds
```

### Pydantic Models

| Model | Fields |
|-------|--------|
| `ServerConfig` | `host` (str), `port` (int) |
| `DbConfig` | `path` (str, supports `~` expansion) |
| `PruningConfig` | `interval` (float, default 5s), `remove_seconds` (int, default 3600) |
| `AppConfig` | `server`, `db`, `pruning` |

## Installation

### Via uv (recommended)

```bash
uv tool install drasill          # Install from PyPI (when published)
uv tool install .                # Install from local checkout
drasill --version                # Verify
```

### From source

```bash
git clone https://github.com/nazq/Drasill.git
cd Drasill
uv sync
uv run drasill --version
```

## Running

### CLI

```bash
drasill serve                    # Start with defaults (0.0.0.0:8400)
drasill serve --port 9000        # Custom port
drasill serve --config ~/my.toml # Custom config
drasill serve --reload           # Dev mode with auto-reload
```

Or via module (from source):

```bash
uv run python -m drasill serve
```

## systemd Deployment

The CLI generates systemd unit files with correct paths to your installed `drasill` binary.

```bash
# Preview the unit file
drasill install systemd --print-only

# Write to ~/.config/systemd/user/drasill.service
drasill install systemd

# Write and start immediately
drasill install systemd --enable

# Custom options
drasill install systemd --port 9000 --config /etc/drasill/config.toml --enable
```

Check status:

```bash
systemctl --user status drasill
journalctl --user -u drasill -f
```

## Exposing to the Internet

Drasill binds to localhost by default. To access it from other devices or the internet, you have several options.

### Tailscale (Recommended)

[Tailscale](https://tailscale.com/) creates a WireGuard mesh VPN. Every device on your tailnet gets a stable IP and optional MagicDNS hostname. No port forwarding, no tunnels, no public exposure.

**Setup:**

```bash
# Install (if not already)
curl -fsSL https://tailscale.com/install.sh | sh

# Start and authenticate
sudo tailscale up

# Check your tailnet IP
tailscale ip -4
```

Access Drasill from any device on your tailnet:

```
http://<tailscale-ip>:8400
# or with MagicDNS:
http://<hostname>.tail<tailnet>.ts.net:8400
```

**Advantages:**
- Zero config on the Drasill side — it already binds `0.0.0.0:8400`
- End-to-end encrypted (WireGuard)
- Works behind NAT, firewalls, CGNAT
- No public exposure — only your tailnet devices can connect
- Free for personal use (up to 100 devices)

**Optional — HTTPS with Tailscale Serve:**

```bash
# Serve Drasill over HTTPS on your tailnet
tailscale serve https / http://localhost:8400

# Or expose publicly via Tailscale Funnel
tailscale funnel https / http://localhost:8400
```

### Cloudflare Tunnel

[Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) exposes local services through Cloudflare's network. Requires a Cloudflare account and domain.

**Setup:**

```bash
# Install cloudflared
# https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/

# Create tunnel
cloudflared tunnel create drasill

# Generate service files and config template
drasill install cloudflared

# Edit the config with your tunnel ID and domain
vim ~/.config/drasill/cloudflared.yml

# Enable the service
drasill install cloudflared --enable
```

Preview generated files:

```bash
drasill install cloudflared --print-only
```

**Advantages:**
- Public HTTPS URL with your own domain
- Cloudflare WAF/DDoS protection
- No open ports on your machine
- Free tier available

**Considerations:**
- Drasill's `LocalhostOnlyMiddleware` blocks `/mesh/*` for non-loopback IPs. Cloudflare Tunnel proxies from localhost, so mesh endpoints work. Direct port exposure would not.
- The tunnel adds latency (~20-50ms) vs Tailscale's direct peer connections

### Comparison

| Feature | Tailscale | Cloudflare Tunnel |
|---------|-----------|-------------------|
| Access scope | Your devices only | Public internet |
| Setup | 1 command | Tunnel + DNS config |
| Latency | Direct peer (low) | Via CF edge (~20-50ms) |
| HTTPS | Via `tailscale serve` | Automatic |
| Domain needed | No (MagicDNS) | Yes |
| Cost | Free (personal) | Free tier + domain |

### Why Not Docker?

Drasill manages hm supervisor sessions on the host for agent terminals. A container can't reach the host's Unix sockets without privileged access and socket mounts, which defeats the purpose. Use `uv tool install` + systemd instead.

### Security Note

Regardless of exposure method, `LocalhostOnlyMiddleware` ensures `/mesh/*` endpoints only accept connections from `127.0.0.1` / `::1`. Both Tailscale (direct) and Cloudflare Tunnel (proxy) need the server to bind `0.0.0.0` — which it does by default. The middleware provides the access control layer, not the bind address.
