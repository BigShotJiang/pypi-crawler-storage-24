# Database & Schema

SQLite via aiosqlite with WAL mode for concurrent read/write.

## Connection Setup

```python
db.row_factory = aiosqlite.Row      # Named column access
PRAGMA journal_mode = WAL           # Write-Ahead Logging
PRAGMA foreign_keys = ON            # Enforce FK constraints
PRAGMA synchronous = NORMAL         # Balanced durability/perf
```

## Tables

### `mesh_agents` — Agent registry

Each Claude Code instance registers here on mesh join.

| Column | Type | Notes |
|--------|------|-------|
| name | TEXT PK | Unique agent identifier |
| pid | INTEGER | OS process ID (optional) |
| session_id | TEXT | heimdall session ID for wake delivery |
| registered_at | TEXT | ISO 8601 UTC |
| last_heartbeat | TEXT | Updated by monitoring loop on every state change |
| status | TEXT | `active`, `idle`, or `dead` (mesh-level state) |
| idle_timeout | INTEGER | Seconds before idle (default 120) |
| agent_state | TEXT | Raw pty classifier state: `active` or `idle` |
| state_ms | INTEGER | Milliseconds spent in current `agent_state` |

### `mesh_messages` — Inter-agent messages

Queue-style messaging with read tracking.

| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | Auto-increment |
| to_agent | TEXT FK | Target agent name |
| from_agent | TEXT | Sender agent name |
| body | TEXT | Message content |
| priority | TEXT | `normal` or `urgent` |
| created_at | TEXT | ISO 8601 UTC |
| read_at | TEXT | Set when consumed |
| acked_at | TEXT | Reserved for future ack flow |

Indexes:
- `idx_mesh_messages_inbox(to_agent, read_at)` — Fast unread lookups
- `idx_mesh_messages_outbox(from_agent, created_at DESC)` — Outbox history

### State field semantics

Two fields track agent state:

- **`status`** — mesh-level lifecycle: `active` (has output recently), `idle` (no output), `dead` (session gone). Used for routing, dashboard display, and message delivery gating.
- **`agent_state`** — raw pty classifier output from heimdall: `active` or `idle`. Reflects the granular PTY state; `state_ms` gives how long the process has been in this state.

## Timestamps

All timestamps use `datetime.now(tz=UTC).isoformat()` via the shared `utc_now()` helper in `db.py`. No timezone ambiguity.

## Concurrency

WAL mode allows concurrent readers with a single writer. Since all writes go through the single uvicorn process, this is safe without additional locking. `synchronous=NORMAL` trades marginal durability risk (power loss mid-write) for better write throughput.
