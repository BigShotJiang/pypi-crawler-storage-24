# Terminal Integration

WebSocket-based terminal access to heimdall (pty supervisor) sessions, plus HTTP endpoints for session management.

## WebSocket Protocol

**Endpoint:** `WS /terminal/{agent_name}/ws`

Connection flow:
1. Look up agent's `session_id` in `mesh_agents` table
2. If not found or no `session_id`, reject with code 4004
3. Open a Unix socket subscription to the heimdall session
4. Accept the WebSocket connection
5. Spawn `_relay_output` and `_relay_input` tasks — each running until the other finishes or disconnects

### Client → Server Messages (JSON text frames)

```json
{"type": "input", "data": "ls -la\n"}        // Keystrokes → heimdall INPUT frame
{"type": "resize", "cols": 120, "rows": 40}   // Resize pty
```

### Server → Client Messages (binary frames)

Output is streamed as **raw pty bytes** (binary WebSocket frames). The browser's terminal emulator (ghostty-web / xterm.js) renders them directly. There are no JSON wrappers around pty output.

The supervisor sends two frame types that the server handles:

| Frame type | Byte | Action |
|-----------|------|--------|
| `OUTPUT` (0x81) | content | Forwarded as binary to browser |
| `EXIT` (0x83) | — | WebSocket closed with code 1000 |

## Subscription-Based Streaming

The terminal router subscribes to heimdall's Unix socket for a true async push stream. There is no polling — the supervisor pushes OUTPUT frames whenever the pty produces data. This gives low-latency output delivery without busy-waiting.

## Session Creation

**Endpoint:** `POST /terminal/sessions`

Creates a new heimdall session running Claude Code with mesh awareness injected.

```json
{
  "name": "my-session",         // Optional: auto-derives from git repo+branch
  "directory": "/path/to/project",
  "continue_session": false,    // Adds --continue to claude invocation
  "dangerous_mode": false       // Adds --dangerously-skip-permissions
}
```

Flow:
1. Validate directory exists
2. If no name given, derive from git remote + branch (e.g., `my-repo_feat/cool`); fall back to directory name
3. Check if heimdall session already exists (409 if so)
4. Build mesh-awareness system prompt via `_build_mesh_prompt(session_name, port)` — teaches the agent its identity and how to list peers / send messages via curl
5. Launch heimdall: `hm run --detach --id {name} --workdir {dir} --socket-dir ... --classifier simple -- claude --append-system-prompt {prompt}`
6. Wait up to 2s for the heimdall Unix socket to appear
7. Register the session as an agent in the mesh (`insert_agent`)
8. Return session details with `session_id`

### Mesh Prompt Injection

`_build_mesh_prompt(agent_name, port)` generates a system prompt telling the agent:
- Its name in the mesh
- How to discover peers: `curl localhost:{port}/mesh/agents`
- How to send messages: `curl -X POST localhost:{port}/mesh/agents/{peer}/inbox`

This is passed to `claude` via `--append-system-prompt`. No plugins, hooks, or skills needed.

### Git-Based Session Naming

`_git_session_name(directory)` tries:
1. Get remote URL → extract repo name (e.g., `github.com/user/my-repo.git` → `my-repo`)
2. Get current branch name
3. Combine as `{repo}_{branch}`
4. If no remote, fall back to top-level directory name + branch

Session names are sanitized: dots, colons, spaces, and special chars become underscores.

## Session Listing

**Endpoint:** `GET /terminal/sessions`

Returns active heimdall session names via `hm list`.

## File Drop

**Endpoint:** `POST /terminal/drop`

Saves a file dragged onto the terminal into `~/.local/share/drasill/drops/` with its original filename (deduplicated if a conflict exists). Returns the local filesystem path so Claude Code can read it directly.

## Frontend

The browser renders terminals using **ghostty-web** (Zig→WASM terminal emulator). WASM is lazy-loaded on first terminal open to avoid penalizing page load time. The WebSocket connection includes exponential backoff reconnection.
