# Frontend & Templates

HTMX + Alpine.js + Tailwind CSS. No build step — CDN imports.

## Stack

| Library | Purpose |
|---------|---------|
| HTMX | Partial page updates, SSE, WebSocket |
| htmx-ext-sse | SSE extension for HTMX |
| Alpine.js | Client-side reactivity (pane state, theme) |
| Tailwind CSS | Utility-first styling (CDN) |
| ghostty-web | Terminal emulator (Zig→WASM) |

## Template Structure

```
templates/
├── base.html          # Layout shell, CDN imports, theme, SSE
├── index.html         # Main page: sidebar + pane tiling UI
└── partials/
    ├── sidebar.html       # Agent list with status dots
    ├── agent_mesh.html    # Mesh dashboard panel
    └── agent_detail.html  # Agent info + message history
```

## Pane Tiling

`index.html` implements a resizable split-pane layout via Alpine.js `tileUI()`:

- Left: collapsible sidebar (drawer on mobile)
- Right: split panes with draggable divider
- Each pane can display a terminal (WebSocket), agent detail, or dashboard
- `focusPane()` uses CSS toggle (no DOM rebuild)
- Divider drag uses `requestAnimationFrame` for smooth resizing

## HTMX Patterns

### SSE-Driven Updates

```html
<div hx-ext="sse" sse-connect="/mesh/events">
  <div hx-get="/partials/sidebar"
       hx-trigger="sse:mesh delay:2s"
       hx-swap="innerHTML">
```

The `delay:2s` debounces rapid mutations (e.g., bulk agent registration).

### Partial Swaps

HTMX strips inline event handlers (`onclick`, `onkeydown`) from swapped content. Two solutions used:

1. **Event delegation:** Attach listeners on `document` instead of elements
2. **Alpine re-init:** Call `Alpine.initTree(e.detail.target)` on `htmx:afterSwap`

## Theme

Dark/light mode stored in `localStorage`. Applies `class="dark"` to `<html>`. Tailwind's `dark:` variants handle styling.

## Semantic CSS Classes

`static/style.css` defines reusable classes to DRY common Tailwind combos:

| Class | Purpose |
|-------|---------|
| `.border-theme` | Themed border color |
| `.text-muted` | Secondary text |
| `.text-dimmed` | Tertiary text |
| `.form-input` | Styled input fields |
| `.status-active` | Green status dot |
| `.status-idle` | Yellow status dot |
| `.status-dead` | Gray status dot |

## Terminal (ghostty-web)

WASM is lazy-loaded via `window.loadGhostty()` — only fetched when the first terminal pane opens. WebSocket connections include exponential backoff reconnection on disconnect.

## Mobile

- Sidebar becomes a slide-out drawer (CSS `translate-x` transition)
- Touch targets enlarged via `@media (pointer: coarse)`
- Bottom action toolbar for mobile interactions
- Extra padding to avoid content under the toolbar
