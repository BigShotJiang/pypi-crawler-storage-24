# Agent Integration

Drasill integrates with agents through two mechanisms, both controlled
at session launch. No agent-side plugins, hooks, or skills are needed.

## System Prompt Injection

At session launch, drasill injects mesh awareness into the agent's
system prompt. This gives the agent knowledge of the mesh and the
ability to communicate with peers via the mesh API.

The injected prompt includes:
- The agent's name in the mesh
- How to list peers (`curl GET /mesh/agents`)
- How to send messages (`curl POST /mesh/agents/{peer}/inbox`)

### Per-archetype injection

| Agent | Method |
|-------|--------|
| Claude Code | `--append-system-prompt` CLI flag |
| OpenCode | `--prompt` CLI flag |
| Codex | `AGENTS.md` file written to working directory |
| Other | `.drasill/MESH.md` written to working directory |

## Message Delivery (Two Stages)

Message delivery uses a two-stage approach:

### Stage 1 — Immediate wake notification

When `POST /mesh/agents/{name}/inbox` is called, drasill immediately
sends a short preview to the agent's stdin via heimdall INPUT:

```
[mesh:{from_agent}] {first 200 chars of body}...
```

This fires regardless of agent state — it notifies the agent that a
message is waiting. This is fire-and-forget; failures are logged but
never block the sender.

### Stage 2 — Full delivery on idle transition

The monitoring loop (every 5s) detects when an agent transitions from
`active` to `idle`. On that transition, drasill uses peek-then-consume
to deliver the full message body:

```
[drasill:message from alpha-agent] Fix the login bug on the auth page.
```

If delivery via heimdall INPUT fails (e.g., session unreachable), the
message stays in the inbox and delivery retries on the next idle cycle.
Only after successful delivery is the message marked as read.

The agent sees these as user input at its prompt and processes them
naturally. No special parsing required — the agent's LLM understands
the message format from context.

## What agents can do

With the system prompt and mesh API, agents can:

1. **List peers** — see who else is in the mesh and their status
2. **Send messages** — tell another agent to do something
3. **Receive messages** — get work from peers or external channels

All via `curl` to `localhost:8400/mesh/*`. No SDK or library needed.

## State Monitoring

Drasill monitors all agents via heimdall STATUS polling (every 5s):

- **Idle detection** — triggers message delivery
- **Dead detection** — deregisters the agent
- **State tracking** — updates dashboard in real-time via SSE

No heartbeat hooks or keepalive mechanisms are needed. The supervisor
provides ground-truth state.
