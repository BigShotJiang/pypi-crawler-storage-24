# Agent Mesh

The mesh coordinates AI coding agents running in heimdall (pty supervisor) sessions. Agents register, exchange messages, and are monitored via heimdall STATUS polling.

## API Endpoints

All endpoints are prefixed with `/mesh` and restricted to localhost by `LocalhostOnlyMiddleware`.

### Agent Registry

| Method | Path | Description |
|--------|------|-------------|
| POST | `/agents` | Register agent (name, pid, session_id) |
| DELETE | `/agents/{name}` | Deregister + cleanup messages |
| GET | `/agents` | List all agents |
| GET | `/agents/{name}` | Get single agent details |
| GET | `/agents/by-session` | Look up agent by session ID |

### Messaging

| Method | Path | Description |
|--------|------|-------------|
| POST | `/agents/{name}/inbox` | Send message to agent |
| GET | `/agents/{name}/inbox` | Consume oldest unread (marks as read) |
| GET | `/agents/{name}/outbox` | Sent message history |

The inbox endpoint returns the full message object, or `{}` if no messages.

### SSE

| Method | Path | Description |
|--------|------|-------------|
| GET | `/events` | Server-Sent Events stream |

Publishes `event: mesh\ndata: refresh\n\n` on every mutation (register, deregister, message send). HTMX listens for `sse:mesh` to trigger partial reloads. Keepalive comments every 30s detect dead connections.

## Agent Lifecycle

The monitoring loop runs every 5 seconds (configurable via `[pruning] interval`) and transitions agents through states:

```
active ──(heimdall STATUS: idle)──────→ idle
active ──(heimdall session gone)──────→ deregistered immediately (row deleted)
idle   ──(heimdall session gone)──────→ deregistered immediately (row deleted)
dead   ──(status=dead for > 1 hour)──→ removed (row + messages deleted)
```

State is determined by heimdall STATUS polling, not heartbeats.

When the monitoring loop detects a session is gone (heimdall socket unreachable or `alive=false`), the agent row is deleted immediately. Undelivered messages are logged before deletion. The `dead` status with grace-period removal exists as a safety net for agents marked dead by external means.

## Message Delivery

Messages are delivered in two stages via heimdall stdin injection:

1. **Immediate wake** — on `POST /mesh/agents/{name}/inbox`, if the agent has
   a `session_id`, drasill immediately sends a short preview to stdin:
   `[mesh:{from_agent}] {first 200 chars}...`. Fire-and-forget.

2. **Full delivery on idle** — the monitoring loop (every 5s) detects
   `active → idle` transitions. On that transition, drasill uses
   peek-then-consume: peek at the oldest unread message, attempt delivery
   of the full body via heimdall INPUT frame, then mark as read only if
   delivery succeeds. If delivery fails, the message stays in the inbox
   and retries on the next idle cycle.

No hooks or plugins needed.

## Shared Dependencies

The router uses FastAPI's `Depends()` for common patterns:

```python
RequireAgent = Annotated[dict[str, Any], Depends(_require_agent)]
```

This dependency fetches the agent row or raises 404. All endpoints that operate on a specific agent use it, eliminating duplicated lookup + error handling.

## Event Bus

`MeshEventBus` uses asyncio.Queue fanout — one queue per connected SSE client. Publishing is `put_nowait` with a maxsize of 64 events. Queue-full events are dropped with a warning (prevents slow clients from blocking the server).
