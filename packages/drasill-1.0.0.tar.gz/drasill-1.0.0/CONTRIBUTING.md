# Contributing to Drasill

## Prerequisites

```bash
uv --version        # Python package manager
hm --version        # Heimdall session supervisor
claude --version    # Claude Code CLI (optional, for agent testing)
just --version      # Task runner (optional, for convenience)
```

Install Python dependencies:

```bash
uv sync
```

Download the heimdall binary for integration tests:

```bash
bash scripts/fetch-hm.sh
```

## Development

### Quick commands

```bash
just serve              # start dev server on :8400 (hot reload)
just check              # lint + format + types + tests
just check-all          # above + Playwright E2E tests
just test               # unit tests only
just test-e2e           # Playwright browser tests only
just doctor             # verify all dependencies
```

Or without just:

```bash
uv run drasill serve --reload
uv run nox -s all_checks
uv run pytest
uv run pytest e2e_tests/ --no-cov
uv run drasill check-deps
```

### Project layout

```
py_src/drasill/         # source code
py_tests/               # unit + integration tests
e2e_tests/              # Playwright browser tests
scripts/                # CI helpers (fetch-hm.sh)
docs/                   # architecture and API docs
```

## Code Style

- **Python 3.13+** — modern type syntax (`list[]`, `dict[]`, `X | None`, `collections.abc`)
- **Ruff** — linter + formatter, `select = ["ALL"]` with targeted ignores in `pyproject.toml`
- **ty** — type checker, strict mode, zero errors
- **Google-style docstrings** for all public APIs
- **No raw ANSI escapes** — use library functions

## Testing

- **pytest + pytest-asyncio** — async tests are the default
- **95% coverage gate** — enforced in CI via `--cov-fail-under=95`
- **Playwright** — E2E browser tests in `e2e_tests/` (not counted in coverage)
- **Real hm integration tests** — `py_tests/test_hm_integration.py` runs against a real heimdall binary

### Running specific tests

```bash
uv run pytest py_tests/test_mesh.py -x -q         # one file
uv run pytest -k "test_idle_wake" -x               # by name
HM_BIN=./bin/hm uv run pytest py_tests/test_hm_integration.py --no-cov  # hm integration
```

## Architecture

- **FastAPI** app factory in `app.py`
- **Agent mesh** — `/mesh/*` endpoints for registration, messaging, SSE events
- **Heimdall** — PTY session supervisor, communicated via Unix socket protocol
- **SQLite** via aiosqlite (WAL mode, CREATE IF NOT EXISTS, no migration framework)
- **HTMX + Alpine.js** — live-updating dashboard with SSE
- **No hooks or plugins** — agents get mesh awareness via system prompt injection at launch

### Key files

| File | Purpose |
|------|---------|
| `app.py` | App factory, lifespan, page routes |
| `mesh/router.py` | Mesh API endpoints |
| `mesh/pruning.py` | Agent monitoring + idle-wake message delivery |
| `terminal/router.py` | Session creation, WebSocket relay, mesh prompt |
| `supervisor_client.py` | Async client for heimdall protocol |
| `doctor.py` | Dependency health checks |
| `db.py` | SQLite schema + data access |
| `config.py` | TOML → Pydantic config |

## CI Pipeline

- **nox all_checks** — lint, format check, type check, tests (with coverage)
- **Codecov** — coverage uploaded on every push
- **hm binary** — downloaded from heimdall releases for integration tests
- **Playwright** — E2E tests run separately (not in nox)

## Commit Conventions

- Conventional commits: `feat:`, `fix:`, `refactor:`, `docs:`, `ci:`, `test:`
- Breaking changes: `feat!:` or `fix!:`
- Keep commits focused — one logical change per commit
