"""AIIR — AI Integrity Receipts. Placeholder for name registration."""
__version__ = "0.0.1"
