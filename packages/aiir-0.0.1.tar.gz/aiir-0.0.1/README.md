# AIIR — AI Integrity Receipts

Placeholder for PyPI name registration. Full release coming soon.

https://github.com/invariant-systems-ai/aiir-action
