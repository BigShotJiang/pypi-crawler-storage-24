from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path
from typing import Any

from .api_clients import DstClient, EurostatClient, PxWeb2Client, PxWebClient
from .exceptions import (
    ProviderNotFoundError,
    UnsupportedAPITypeError,
    UnsupportedLanguageError,
)
from .models import Provider

WRAPPER_REGISTRY = {
    "dst": DstClient,
    "eurostat": EurostatClient,
    "pxweb": PxWebClient,
    "pxweb2": PxWeb2Client,
}


def _default_provider_path() -> Path:
    repo_file = Path(__file__).resolve().parent.parent / "PROVIDERS.json"
    if repo_file.exists():
        return repo_file
    return Path(files("statwrapper").joinpath("providers.json"))


def load_providers(path: str | Path | None = None) -> list[Provider]:
    resolved_path = Path(path) if path is not None else _default_provider_path()
    data = json.loads(resolved_path.read_text(encoding="utf-8"))
    return [Provider(**item) for item in data]


def get_provider(
    provider_code: str,
    providers: list[Provider] | None = None,
) -> Provider:
    candidates = providers or load_providers()
    for provider in candidates:
        if provider.provider_code == provider_code:
            return provider
    raise ProviderNotFoundError(provider_code)


def get_wrapper_class(api_type: str) -> type:
    wrapper_cls = WRAPPER_REGISTRY.get(api_type.lower())
    if wrapper_cls is None:
        raise UnsupportedAPITypeError(api_type)
    return wrapper_cls


def create_wrapper(
    provider: Provider,
    *,
    language: str,
    json_request_handler: Any,
    text_request_handler: Any = None,
    bytes_request_handler: Any = None,
    logger: Any = None,
):
    if language not in provider.languages:
        raise UnsupportedLanguageError(provider.provider_code, language)
    wrapper_cls = get_wrapper_class(provider.api_type)
    return wrapper_cls(
        provider,
        language=language,
        json_request_handler=json_request_handler,
        text_request_handler=text_request_handler,
        bytes_request_handler=bytes_request_handler,
        logger=logger,
    )
