from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen


@dataclass
class _HostLimiter:
    interval: float
    lock: asyncio.Lock
    last_request_time: float = 0.0


class RateLimitedSession:
    """Minimal stdlib-backed async HTTP client with per-host spacing."""

    def __init__(
        self,
        *,
        default_rate: float = 1.0,
        host_rates: dict[str, float] | None = None,
        timeout: float = 60.0,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._default_interval = 1.0 / default_rate if default_rate > 0 else 0.0
        self._timeout = timeout
        self._headers = headers or {"User-Agent": "statwrapper/0.1.0"}
        self._limiters: dict[str, _HostLimiter] = {}
        for host, rate in (host_rates or {}).items():
            hostname = urlparse(host).hostname or host
            interval = 1.0 / rate if rate > 0 else 0.0
            self._limiters[hostname] = _HostLimiter(interval=interval, lock=asyncio.Lock())

    async def __aenter__(self) -> RateLimitedSession:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        return None

    def _get_limiter(self, url: str) -> _HostLimiter:
        hostname = urlparse(url).hostname or ""
        limiter = self._limiters.get(hostname)
        if limiter is None:
            limiter = _HostLimiter(
                interval=self._default_interval,
                lock=asyncio.Lock(),
            )
            self._limiters[hostname] = limiter
        return limiter

    async def _wait_for_slot(self, url: str) -> None:
        limiter = self._get_limiter(url)
        async with limiter.lock:
            if limiter.interval > 0:
                now = time.monotonic()
                elapsed = now - limiter.last_request_time
                if elapsed < limiter.interval:
                    await asyncio.sleep(limiter.interval - elapsed)
                limiter.last_request_time = time.monotonic()

    def _build_url(self, url: str, params: dict[str, Any] | None) -> str:
        if not params:
            return url
        encoded = urlencode(
            {
                key: value
                for key, value in params.items()
                if value is not None
            },
            doseq=True,
        )
        separator = "&" if "?" in url else "?"
        return f"{url}{separator}{encoded}"

    async def _read(self, url: str, params: dict[str, Any] | None = None) -> bytes | None:
        await self._wait_for_slot(url)
        request = Request(self._build_url(url, params), headers=self._headers)
        try:
            return await asyncio.to_thread(
                lambda: urlopen(request, timeout=self._timeout).read()
            )
        except Exception:
            return None

    async def get_bytes(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        **_: Any,
    ) -> bytes | None:
        return await self._read(url, params=params)

    async def get_text(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        encoding: str = "utf-8",
        **_: Any,
    ) -> str | None:
        payload = await self._read(url, params=params)
        if payload is None:
            return None
        return payload.decode(encoding, errors="replace")

    async def get_json(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        **_: Any,
    ) -> dict[str, Any] | list[Any] | None:
        payload = await self.get_text(url, params=params)
        if payload is None:
            return None
        try:
            decoded = json.loads(payload)
        except json.JSONDecodeError:
            return None
        return decoded if isinstance(decoded, (dict, list)) else None
