from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

TIME_LABEL_PATTERNS: dict[str, re.Pattern[str]] = {
    "Annual": re.compile(r"^(1[5-9][0-9]{2}|2[0-9]{3}|3000)$"),
    "Quarterly": re.compile(r"^(1[5-9][0-9]{2}|2[0-9]{3}|3000)[QK][1-4]$"),
    "Monthly": re.compile(
        r"^(1[5-9][0-9]{2}|2[0-9]{3}|3000)(M0?[1-9]|M1[0-2]|0?[1-9]|1[0-2])$"
    ),
    "Weekly": re.compile(
        r"^(1[5-9][0-9]{2}|2[0-9]{3}|3000)(W0?[1-9]|W[1-4][0-9]|W5[0-3])$"
    ),
    "Other": re.compile(
        r"^(1[5-9][0-9]{2}|2[0-9]{3}|3000)(W0?[1-9]|W[1-4][0-9]|W5[0-3]|V0?[1-9]|V[1-4][0-9]|V5[0-3])$"
    ),
}

TIME_ALTERNATIVES = {
    "time",
    "tid",
    "year",
    "quarter",
    "month",
    "week",
    "period",
    "time period",
}
GEO_ALTERNATIVES = {
    "geo",
    "region",
    "country",
    "municipality",
    "county",
    "location",
    "area",
}
METRIC_ALTERNATIVES = {
    "unit",
    "contents",
    "measure",
    "metric",
    "value",
    "content",
    "contentscode",
}


def determine_time_unit(first_period: str | None, last_period: str | None) -> str:
    if not first_period or not last_period:
        return "Other"
    for time_format, pattern in TIME_LABEL_PATTERNS.items():
        if pattern.match(first_period) and pattern.match(last_period):
            return time_format
    return "Other"


def detect_role(code: str, label: str, is_time: bool = False) -> str | None:
    if is_time:
        return "time"

    norm_code = code.strip().lower()
    norm_label = label.strip().lower()
    if norm_code == "contentscode" or norm_code in METRIC_ALTERNATIVES:
        return "metric"
    if norm_label in METRIC_ALTERNATIVES:
        return "metric"
    if norm_code in GEO_ALTERNATIVES or norm_label in GEO_ALTERNATIVES:
        return "geo"
    if norm_code in TIME_ALTERNATIVES or norm_label in TIME_ALTERNATIVES:
        return "time"
    return None


def parse_dt(value: str | datetime | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return (
            value.astimezone(timezone.utc)
            if value.tzinfo
            else value.replace(tzinfo=timezone.utc)
        )
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        normalized = raw.replace("Z", "+00:00")
        if re.search(r"[+-]\d{4}$", normalized):
            normalized = f"{normalized[:-5]}{normalized[-5:-2]}:{normalized[-2:]}"
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            return None
        return (
            parsed.astimezone(timezone.utc)
            if parsed.tzinfo
            else parsed.replace(tzinfo=timezone.utc)
        )
    return None


def normalize_note(value: Any) -> list[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        cleaned = value.strip()
        return [cleaned] if cleaned else None
    if isinstance(value, list):
        notes = [str(item).strip() for item in value if str(item).strip()]
        return notes or None
    if isinstance(value, dict):
        text = str(value.get("text") or "").strip()
        return [text] if text else None
    return None


def normalize_contact(raw_contact: Any) -> dict[str, Any] | None:
    if raw_contact is None:
        return None
    if isinstance(raw_contact, dict):
        return raw_contact
    if isinstance(raw_contact, list):
        contacts = [item for item in raw_contact if isinstance(item, dict)]
        if contacts:
            return {"contacts": contacts}
        values = [str(item).strip() for item in raw_contact if str(item).strip()]
        return {"values": values} if values else None
    value = str(raw_contact).strip()
    return {"value": value} if value else None


def ensure_datetime(value: datetime | None, fallback: datetime) -> datetime:
    return value if value is not None else fallback
