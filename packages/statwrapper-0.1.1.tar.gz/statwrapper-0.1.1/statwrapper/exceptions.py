from __future__ import annotations


class StatwrapperError(Exception):
    """Base exception for statwrapper."""


class ProviderNotFoundError(StatwrapperError):
    def __init__(self, provider_code: str) -> None:
        super().__init__(f"Provider not found: {provider_code!r}")


class UnsupportedAPITypeError(StatwrapperError):
    def __init__(self, api_type: str) -> None:
        super().__init__(f"No wrapper registered for api_type={api_type!r}")


class UnsupportedLanguageError(StatwrapperError):
    def __init__(self, provider_code: str, language: str) -> None:
        super().__init__(
            f"Language {language!r} is not supported by provider {provider_code!r}"
        )
