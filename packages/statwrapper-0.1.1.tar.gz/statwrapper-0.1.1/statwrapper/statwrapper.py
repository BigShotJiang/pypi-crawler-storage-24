from __future__ import annotations

import asyncio
import logging
import uuid
from pathlib import Path
from typing import Any

from .http import RateLimitedSession
from .models import DiscoveredDataset, Provider, ResolvedDatasetMetadata
from .provider_registry import create_wrapper, get_provider, load_providers


class StatWrapper:
    def __init__(
        self,
        *,
        providers_path: str | Path | None = None,
        session: RateLimitedSession | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.providers_path = providers_path
        self.providers = load_providers(providers_path)
        self.provider_map = {
            provider.provider_code: provider for provider in self.providers
        }
        self.logger = logger or logging.getLogger(__name__)
        self.session = session or RateLimitedSession(
            default_rate=1.0,
            host_rates={
                provider.base_api_url or provider.provider_code: (
                    1.0 / provider.rate_limit if provider.rate_limit > 0 else 1.0
                )
                for provider in self.providers
            },
        )

    def get_provider(self, provider_code: str) -> Provider:
        return get_provider(provider_code, self.providers)

    def get_wrapper(self, provider_code: str, language: str):
        provider = self.get_provider(provider_code)
        return create_wrapper(
            provider,
            language=language,
            json_request_handler=self.session.get_json,
            text_request_handler=self.session.get_text,
            bytes_request_handler=self.session.get_bytes,
            logger=self.logger,
        )

    async def discover_datasets(
        self,
        provider_code: str,
        language: str,
        *,
        task_id: uuid.UUID | None = None,
    ) -> list[DiscoveredDataset]:
        wrapper = self.get_wrapper(provider_code, language)
        return await wrapper.discover_datasets(task_id or uuid.uuid4())

    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        *,
        task_id: uuid.UUID | None = None,
    ) -> ResolvedDatasetMetadata:
        wrapper = self.get_wrapper(discovered.provider_code, discovered.language)
        return await wrapper.resolve_dataset_metadata(discovered, task_id=task_id)


async def discover_provider_datasets(
    provider_code: str,
    language: str,
    *,
    providers_path: str | Path | None = None,
) -> list[DiscoveredDataset]:
    wrapper = StatWrapper(providers_path=providers_path)
    return await wrapper.discover_datasets(provider_code, language)


async def resolve_dataset_metadata(
    discovered: DiscoveredDataset,
    *,
    providers_path: str | Path | None = None,
) -> ResolvedDatasetMetadata:
    wrapper = StatWrapper(providers_path=providers_path)
    return await wrapper.resolve_dataset_metadata(discovered)


def get_datasets(
    provider_code: str,
    language: str,
    *,
    providers_path: str | Path | None = None,
) -> list[dict[str, Any]]:
    async def _run() -> list[dict[str, Any]]:
        wrapper = StatWrapper(providers_path=providers_path)
        discovered = await wrapper.discover_datasets(provider_code, language)
        resolved = [await wrapper.resolve_dataset_metadata(item) for item in discovered]
        return [item.__dict__ for item in resolved]

    return asyncio.run(_run())
