from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from typing import Any

from .models import DiscoveredDataset, ResolvedDatasetMetadata

JsonResponse = dict[str, Any] | list[Any] | None
JsonRequestHandler = Callable[..., Awaitable[JsonResponse]]
TextRequestHandler = Callable[..., Awaitable[str | None]]
BytesRequestHandler = Callable[..., Awaitable[bytes | None]]


class APIWrapper(ABC):
    """Base class for dependency-free API wrappers."""

    def __init__(
        self,
        provider_code: str,
        label: str,
        language: str,
        json_request_handler: JsonRequestHandler,
        logger: logging.Logger | None = None,
        **kwargs: Any,
    ) -> None:
        self.provider_code = provider_code
        self.label = label
        self.language = language
        self.api_type = "generic"
        self.json_request_handler = json_request_handler
        self.text_request_handler: TextRequestHandler | None = kwargs.pop(
            "text_request_handler",
            None,
        )
        self.bytes_request_handler: BytesRequestHandler | None = kwargs.pop(
            "bytes_request_handler",
            None,
        )
        self.logger = logger or logging.getLogger(__name__)
        self._logger_prefix = f"[{self.provider_code}:{self.language}]"

    def _log_prefix(self, message: str) -> str:
        return f"{self._logger_prefix} {message}"

    async def _get_json(self, url: str, **kwargs: Any) -> JsonResponse:
        return await self.json_request_handler(url, **kwargs)

    async def _get_text(self, url: str, **kwargs: Any) -> str | None:
        if self.text_request_handler is None:
            raise RuntimeError("text_request_handler is not configured")
        return await self.text_request_handler(url, **kwargs)

    async def _get_bytes(self, url: str, **kwargs: Any) -> bytes | None:
        if self.bytes_request_handler is None:
            raise RuntimeError("bytes_request_handler is not configured")
        return await self.bytes_request_handler(url, **kwargs)

    @abstractmethod
    async def health_check(self, dataset_code: str | None = None) -> bool:
        """Return whether the provider is reachable."""

    @abstractmethod
    async def discover_datasets(
        self,
        task_id: Any,
        **kwargs: Any,
    ) -> list[DiscoveredDataset]:
        """Discover datasets from the provider."""

    @abstractmethod
    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        task_id: Any | None = None,
        **kwargs: Any,
    ) -> ResolvedDatasetMetadata:
        """Resolve a discovered dataset into persistence-ready metadata."""
