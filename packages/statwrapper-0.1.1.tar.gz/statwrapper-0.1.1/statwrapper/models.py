from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

_VALID_TIME_UNITS = {"Annual", "Quarterly", "Monthly", "Weekly", "Other"}


def _validate_time_unit(value: str | None) -> None:
    if value is None:
        return
    if value not in _VALID_TIME_UNITS:
        raise ValueError(
            f"Invalid time_unit: {value}. Must be one of {_VALID_TIME_UNITS}."
        )


@dataclass(slots=True)
class Provider:
    provider_code: str
    api_type: str
    default_language: str
    languages: list[str]
    label: str
    country_code: str
    base_api_url: str | None = None
    base_web_url: str | None = None
    rate_limit: float = 1.0
    cell_limit: int = 5000
    variable_limit: int = 1000
    max_concurrency: int | None = None
    data_formats: list[str] = field(default_factory=list)
    extension: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DiscoveredDataset:
    task_id: uuid.UUID
    provider_code: str
    dataset_code: str
    language: str
    updated: datetime
    label: str | None = None
    source: str | None = None
    note: list[str] | None = None
    role: dict[str, list[str]] | None = None
    description: str | None = None
    time_unit: str | None = None
    first_period: str | None = None
    last_period: str | None = None
    discontinued: bool | None = None
    paths: list[list[dict[str, str]]] | None = None
    subject_code: str | None = None
    subject_label: str | None = None
    metadata_url: str | None = None
    data_url: str | None = None
    web_url: str | None = None
    doc_url: str | None = None
    dimension: dict[str, dict[str, Any]] | None = None
    required_dimensions: dict[str, bool | None] | None = None
    official_statistics: bool | None = None
    contact: dict[str, Any] | None = None
    dimension_ids: list[str] | None = None
    extension: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_time_unit(self.time_unit)


@dataclass(slots=True)
class ResolvedDatasetMetadata:
    task_id: uuid.UUID
    provider_code: str
    dataset_code: str
    language: str
    updated: datetime
    label: str
    time_unit: str
    first_period: str
    last_period: str
    paths: list[list[dict[str, str]]]
    role: dict[str, list[str]]
    metadata_url: str
    data_url: str
    dimension: dict[str, dict[str, Any]]
    required_dimensions: dict[str, bool | None]
    note: list[str] | None = None
    source: str | None = None
    description: str | None = None
    discontinued: bool | None = None
    subject_code: str | None = None
    subject_label: str | None = None
    web_url: str | None = None
    doc_url: str | None = None
    official_statistics: bool | None = None
    contact: dict[str, Any] | None = None
    dimension_ids: list[str] | None = None
    extension: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_time_unit(self.time_unit)
