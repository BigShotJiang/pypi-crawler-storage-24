from __future__ import annotations

from typing import Any

from .utils import normalize_contact, normalize_note, parse_dt

_VALID_TIME_UNITS = {"Annual", "Quarterly", "Monthly", "Weekly", "Other"}


def normalize_paths(raw_paths: Any) -> list[list[dict[str, str]]] | None:
    if raw_paths is None:
        return None

    if isinstance(raw_paths, dict) and isinstance(raw_paths.get("paths"), list):
        raw_paths = raw_paths["paths"]
    elif isinstance(raw_paths, dict) and isinstance(raw_paths.get("path"), list):
        raw_paths = [raw_paths]
    elif not isinstance(raw_paths, list):
        raw_paths = [[raw_paths]]

    output: list[list[dict[str, str]]] = []
    for raw_path in raw_paths:
        items = raw_path.get("path") if isinstance(raw_path, dict) else raw_path
        if not isinstance(items, list):
            continue
        normalized_path: list[dict[str, str]] = []
        for index, item in enumerate(items):
            if isinstance(item, dict):
                item_id = str(
                    item.get("id")
                    or item.get("code")
                    or item.get("key")
                    or item.get("value")
                    or index
                ).strip()
                if not item_id:
                    continue
                label = str(
                    item.get("label")
                    or item.get("title")
                    or item.get("name")
                    or item_id
                ).strip()
            else:
                item_id = str(item).strip()
                if not item_id:
                    continue
                label = item_id
            normalized_path.append({"id": item_id, "label": label})
        if normalized_path:
            output.append(normalized_path)
    return output or None


def normalize_role(raw_role: Any) -> dict[str, list[str]] | None:
    if not isinstance(raw_role, dict):
        return None
    output: dict[str, list[str]] = {}
    for key in ("time", "geo", "metric"):
        values = raw_role.get(key)
        if not isinstance(values, list):
            continue
        deduped: list[str] = []
        for value in values:
            text = str(value).strip()
            if text and text not in deduped:
                deduped.append(text)
        if deduped:
            output[key] = deduped
    return output or None


def normalize_dimensions(
    raw_dimensions: Any,
    raw_dimension_ids: Any,
) -> tuple[
    dict[str, dict[str, Any]] | None,
    list[str] | None,
    dict[str, bool | None] | None,
    dict[str, dict[str, Any]] | None,
]:
    if not isinstance(raw_dimensions, dict):
        return None, None, None, None

    if isinstance(raw_dimension_ids, list):
        dimension_ids = [str(item).strip() for item in raw_dimension_ids if str(item).strip()]
    else:
        dimension_ids = [str(key).strip() for key in raw_dimensions if str(key).strip()]

    dimensions: dict[str, dict[str, Any]] = {}
    required_dimensions: dict[str, bool | None] = {}
    dimension_extensions: dict[str, dict[str, Any]] = {}
    for dimension_id in dimension_ids:
        raw_dimension = raw_dimensions.get(dimension_id)
        if not isinstance(raw_dimension, dict):
            continue
        category = raw_dimension.get("category")
        category = category if isinstance(category, dict) else {}

        raw_index = category.get("index")
        if isinstance(raw_index, dict):
            index = {str(key): int(value) for key, value in raw_index.items()}
        elif isinstance(raw_index, list):
            index = {str(value): ordinal for ordinal, value in enumerate(raw_index)}
        else:
            raw_labels = category.get("label")
            index = (
                {str(key): ordinal for ordinal, key in enumerate(raw_labels)}
                if isinstance(raw_labels, dict)
                else {}
            )
        if not index:
            continue

        raw_labels = category.get("label")
        labels = (
            {key: str(raw_labels.get(key, key)) for key in index}
            if isinstance(raw_labels, dict)
            else {key: key for key in index}
        )

        parsed_dimension: dict[str, Any] = {
            "label": str(raw_dimension.get("label") or dimension_id),
            "category": {"index": index, "label": labels},
        }
        note = normalize_note(raw_dimension.get("note"))
        if note:
            parsed_dimension["note"] = note
        dimensions[dimension_id] = parsed_dimension

        elimination = raw_dimension.get("elimination")
        required_dimensions[dimension_id] = (
            None if elimination is None else not bool(elimination)
        )

        extras = {
            key: value
            for key, value in raw_dimension.items()
            if key not in {"label", "category", "note", "elimination"}
        }
        if extras:
            dimension_extensions[dimension_id] = {"extension": extras}

    return (
        dimensions or None,
        dimension_ids or None,
        required_dimensions or None,
        dimension_extensions or None,
    )


def parse_pxweb2_discovery_table(
    table: dict[str, Any],
    *,
    base_api_url: str,
    base_web_url: str | None,
    language: str,
) -> dict[str, Any] | None:
    dataset_code = str(table.get("id") or "").strip()
    if not dataset_code:
        return None

    raw_time_unit = table.get("timeUnit")
    time_unit = (
        raw_time_unit
        if isinstance(raw_time_unit, str) and raw_time_unit in _VALID_TIME_UNITS
        else "Other"
    )

    clean_api = base_api_url.rstrip("/")
    return {
        "dataset_code": dataset_code,
        "label": str(table.get("label") or table.get("title") or dataset_code),
        "updated": parse_dt(table.get("updated")),
        "time_unit": time_unit,
        "first_period": str(table.get("firstPeriod") or "").strip() or None,
        "last_period": str(table.get("lastPeriod") or "").strip() or None,
        "description": str(table.get("description")).strip()
        if table.get("description") is not None
        else None,
        "source": str(table.get("source")).strip()
        if table.get("source") is not None
        else None,
        "note": normalize_note(table.get("note")),
        "subject_code": str(table.get("subjectCode")).strip()
        if table.get("subjectCode") is not None
        else None,
        "paths": normalize_paths(table.get("paths")),
        "discontinued": bool(table.get("discontinued", False)),
        "metadata_url": f"{clean_api}/tables/{dataset_code}/metadata",
        "data_url": f"{clean_api}/tables/{dataset_code}/data?lang={language}",
        "web_url": (
            f"{base_web_url.rstrip('/')}/{language}/table/{dataset_code}"
            if base_web_url
            else None
        ),
        "extension": {
            "links": table.get("links"),
            "variable_names": list(table.get("variableNames", []))
            if isinstance(table.get("variableNames"), list)
            else [],
        },
    }


def parse_pxweb2_metadata_payload(
    payload: dict[str, Any],
    *,
    default_note: list[str] | None,
    default_subject_label: str | None,
    default_official_statistics: bool | None,
    default_contact: dict[str, Any] | None,
    default_extension: dict[str, Any],
) -> dict[str, Any]:
    (
        dimensions,
        dimension_ids,
        required_dimensions,
        dimension_extensions,
    ) = normalize_dimensions(payload.get("dimension"), payload.get("id"))

    extension = dict(default_extension)
    note = normalize_note(payload.get("note")) or default_note
    role = normalize_role(payload.get("role"))
    subject_label = default_subject_label
    official_statistics = default_official_statistics
    contact = default_contact

    raw_extension = payload.get("extension")
    if isinstance(raw_extension, dict):
        extension.update(raw_extension)
        px = raw_extension.get("px")
        if isinstance(px, dict):
            if subject_label is None and px.get("subject-area") is not None:
                subject_label = str(px.get("subject-area")).strip() or None
            if px.get("official-statistics") is not None:
                official_statistics = bool(px.get("official-statistics"))
        normalized_contact = normalize_contact(raw_extension.get("contact"))
        if normalized_contact is not None:
            contact = normalized_contact

    if dimension_extensions is not None:
        merged = {}
        existing = extension.get("dimension_extensions")
        if isinstance(existing, dict):
            merged.update(existing)
        merged.update(dimension_extensions)
        extension["dimension_extensions"] = merged

    return {
        "dimensions": dimensions,
        "dimension_ids": dimension_ids,
        "required_dimensions": required_dimensions,
        "role": role,
        "note": note,
        "subject_label": subject_label,
        "official_statistics": official_statistics,
        "contact": contact,
        "extension": extension,
    }
