from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

from ..base_api_client import APIWrapper
from ..models import DiscoveredDataset, Provider, ResolvedDatasetMetadata
from ..utils import detect_role, determine_time_unit, parse_dt


def _encode_segment(value: str) -> str:
    return quote(value, safe="")


def _normalize_path(path: str) -> str:
    ids = [segment.strip() for segment in path.split("/") if segment.strip()]
    return "/".join(ids)


@dataclass(slots=True)
class _PxWebTableEntry:
    id: str
    title: str
    path: str
    db_id: str
    language: str
    provider_code: str
    base_api_url: str
    base_web_url: str | None
    published: str | None = None
    updated: str | None = None

    @property
    def api_url(self) -> str:
        return (
            f"{self.base_api_url.rstrip('/')}/{self.language}/"
            f"{_encode_segment(self.db_id)}/{_normalize_path(self.path)}/{_encode_segment(self.id)}"
        )

    @property
    def web_url(self) -> str | None:
        if not self.base_web_url:
            return None
        path_segment = _normalize_path(self.path).replace("/", "__")
        return (
            f"{self.base_web_url.rstrip('/')}/{self.language}/"
            f"{_encode_segment(self.db_id)}/{_encode_segment(self.db_id)}__{path_segment}/{_encode_segment(self.id)}/"
        )


class PxWebClient(APIWrapper):
    def __init__(self, provider: Provider, **kwargs: Any) -> None:
        super().__init__(
            provider_code=provider.provider_code,
            label=provider.label,
            language=kwargs.pop("language"),
            json_request_handler=kwargs.pop("json_request_handler"),
            text_request_handler=kwargs.pop("text_request_handler", None),
            bytes_request_handler=kwargs.pop("bytes_request_handler", None),
            logger=kwargs.pop("logger", None),
        )
        self.provider = provider
        self.api_type = provider.api_type
        self.base_api_url = provider.base_api_url
        self.base_web_url = provider.base_web_url
        extension = provider.extension if isinstance(provider.extension, dict) else {}
        dbid = extension.get("dbid", {})
        self.db_ids = set(dbid.keys()) if isinstance(dbid, dict) else set()
        if not self.base_api_url or not self.db_ids:
            raise ValueError("PxWeb provider requires base_api_url and extension.dbid")

    async def health_check(self, dataset_code: str | None = None) -> bool:
        if dataset_code is None:
            db_id = next(iter(self.db_ids))
            url = f"{self.base_api_url.rstrip('/')}/{self.language}/{_encode_segment(db_id)}"
        else:
            url = dataset_code
        payload = await self._get_json(url, params={"filter": "*", "query": "*"})
        return payload is not None

    async def discover_datasets(
        self,
        task_id: uuid.UUID,
        **_: Any,
    ) -> list[DiscoveredDataset]:
        discovered: list[DiscoveredDataset] = []
        for db_id in sorted(self.db_ids):
            url = f"{self.base_api_url.rstrip('/')}/{self.language}/{_encode_segment(db_id)}"
            payload = await self._get_json(url, params={"filter": "*", "query": "*"})
            if not isinstance(payload, list):
                continue
            for entry_data in payload:
                if not isinstance(entry_data, dict):
                    continue
                entry_id = str(entry_data.get("id") or "").strip()
                path = str(entry_data.get("path") or "").strip()
                if not entry_id or not path:
                    continue
                entry = _PxWebTableEntry(
                    id=entry_id,
                    title=str(entry_data.get("title") or entry_id).strip(),
                    path=path,
                    db_id=db_id,
                    language=self.language,
                    provider_code=self.provider_code,
                    base_api_url=self.base_api_url,
                    base_web_url=self.base_web_url,
                    published=str(entry_data.get("published") or "").strip() or None,
                    updated=str(entry_data.get("updated") or "").strip() or None,
                )
                updated = parse_dt(entry.updated) or parse_dt(entry.published)
                if updated is None:
                    continue
                path_items = [
                    {"id": segment, "label": segment}
                    for segment in entry.path.split("/")
                    if segment.strip()
                ]
                discovered.append(
                    DiscoveredDataset(
                        task_id=task_id,
                        provider_code=self.provider_code,
                        dataset_code=entry.id,
                        language=self.language,
                        updated=updated,
                        label=entry.title,
                        metadata_url=entry.api_url,
                        data_url=entry.api_url,
                        web_url=entry.web_url,
                        paths=[path_items] if path_items else None,
                        subject_code=path_items[-1]["id"] if path_items else None,
                        subject_label=path_items[-1]["label"] if path_items else None,
                    )
                )
        return discovered

    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        task_id: uuid.UUID | None = None,
        **_: Any,
    ) -> ResolvedDatasetMetadata:
        metadata_url = discovered.metadata_url
        if metadata_url is None:
            raise ValueError("Discovered dataset is missing metadata_url")
        payload = await self._get_json(metadata_url)
        dimensions: dict[str, dict[str, Any]] = {}
        dimension_ids: list[str] = []
        required_dimensions: dict[str, bool | None] = {}
        role: dict[str, list[str]] = {}
        dimension_extensions: dict[str, dict[str, Any]] = {}
        time_labels: list[str] = []
        title = discovered.label or discovered.dataset_code
        if isinstance(payload, dict):
            payload_title = payload.get("title")
            if isinstance(payload_title, str) and payload_title.strip():
                title = payload_title.strip()
            variables = payload.get("variables")
            if isinstance(variables, list):
                for position, var in enumerate(variables):
                    if not isinstance(var, dict):
                        continue
                    code = str(var.get("code") or "").strip()
                    if not code:
                        continue
                    label = str(var.get("text") or code).strip()
                    values = var.get("values") if isinstance(var.get("values"), list) else []
                    value_texts = (
                        var.get("valueTexts")
                        if isinstance(var.get("valueTexts"), list)
                        else []
                    )
                    index = [str(value) for value in values]
                    labels = {
                        str(value): str(value_texts[idx] if idx < len(value_texts) else value)
                        for idx, value in enumerate(values)
                    }
                    dimensions[code] = {
                        "label": label,
                        "category": {
                            "index": {
                                category_code: ordinal
                                for ordinal, category_code in enumerate(index)
                            },
                            "label": labels,
                        },
                    }
                    dimension_ids.append(code)
                    elimination = var.get("elimination")
                    required_dimensions[code] = (
                        None if elimination is None else not bool(elimination)
                    )
                    inferred_role = detect_role(code, label, bool(var.get("time")))
                    if inferred_role is not None:
                        role.setdefault(inferred_role, []).append(code)
                    if inferred_role == "time":
                        time_labels = [label for label in labels.values() if label.strip()]
                    extras = {
                        key: value
                        for key, value in var.items()
                        if key
                        not in {"code", "text", "values", "valueTexts", "time", "elimination"}
                    }
                    extras["position"] = position
                    if extras:
                        dimension_extensions[code] = {"extension": extras}
        sorted_time_labels = sorted(time_labels)
        first_period = discovered.first_period or (sorted_time_labels[0] if sorted_time_labels else "")
        last_period = discovered.last_period or (sorted_time_labels[-1] if sorted_time_labels else first_period)
        time_unit = discovered.time_unit or determine_time_unit(first_period, last_period)
        extension = dict(discovered.extension)
        if dimension_extensions:
            extension["dimension_extensions"] = dimension_extensions
        return ResolvedDatasetMetadata(
            task_id=task_id or discovered.task_id,
            provider_code=discovered.provider_code,
            dataset_code=discovered.dataset_code,
            language=discovered.language,
            updated=discovered.updated,
            label=title,
            time_unit=time_unit,
            first_period=first_period,
            last_period=last_period,
            paths=discovered.paths or [],
            role=role,
            metadata_url=metadata_url,
            data_url=discovered.data_url or metadata_url,
            dimension=dimensions,
            required_dimensions=required_dimensions,
            note=discovered.note,
            source=discovered.source,
            description=discovered.description,
            discontinued=discovered.discontinued,
            subject_code=discovered.subject_code,
            subject_label=discovered.subject_label,
            web_url=discovered.web_url,
            doc_url=discovered.doc_url,
            official_statistics=discovered.official_statistics,
            contact=discovered.contact,
            dimension_ids=dimension_ids or None,
            extension=extension,
        )
