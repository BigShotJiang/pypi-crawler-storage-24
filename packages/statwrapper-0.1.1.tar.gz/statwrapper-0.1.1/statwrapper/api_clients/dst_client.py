from __future__ import annotations

import uuid
from typing import Any

from ..base_api_client import APIWrapper
from ..models import DiscoveredDataset, Provider, ResolvedDatasetMetadata
from ..utils import (
    detect_role,
    determine_time_unit,
    normalize_contact,
    normalize_note,
    parse_dt,
)


def _collect_tables(subjects_tree: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    tables_by_id: dict[str, dict[str, Any]] = {}

    def visit(node: dict[str, Any]) -> None:
        for table in node.get("tables") or []:
            if not isinstance(table, dict):
                continue
            table_id = str(table.get("id") or "").strip()
            if not table_id:
                continue
            existing = tables_by_id.setdefault(table_id, {"id": table_id})
            for key, value in table.items():
                if existing.get(key) in (None, "", []) and value not in (None, "", []):
                    existing[key] = value
        for child in node.get("subjects") or []:
            if isinstance(child, dict):
                visit(child)

    for root in subjects_tree:
        if isinstance(root, dict):
            visit(root)
    return tables_by_id


def _parse_paths(subjects_tree: list[dict[str, Any]]) -> dict[str, list[list[dict[str, str]]]]:
    code_to_paths: dict[str, list[list[dict[str, str]]]] = {}

    def visit(node: dict[str, Any], path: list[dict[str, str]]) -> None:
        node_id = str(node.get("id") or "").strip()
        node_label = str(node.get("description") or node.get("text") or node_id).strip()
        current_path = path + ([{"id": node_id, "label": node_label}] if node_id else [])
        for table in node.get("tables") or []:
            if not isinstance(table, dict):
                continue
            table_id = str(table.get("id") or "").strip()
            if not table_id:
                continue
            code_to_paths.setdefault(table_id, []).append(
                current_path + [{"id": table_id, "label": str(table.get("text") or table_id).strip()}]
            )
        for child in node.get("subjects") or []:
            if isinstance(child, dict):
                visit(child, current_path)

    for root in subjects_tree:
        if isinstance(root, dict):
            visit(root, [])
    return code_to_paths


class DstClient(APIWrapper):
    def __init__(self, provider: Provider, **kwargs: Any) -> None:
        super().__init__(
            provider_code=provider.provider_code,
            label=provider.label,
            language=kwargs.pop("language"),
            json_request_handler=kwargs.pop("json_request_handler"),
            text_request_handler=kwargs.pop("text_request_handler", None),
            bytes_request_handler=kwargs.pop("bytes_request_handler", None),
            logger=kwargs.pop("logger", None),
        )
        self.provider = provider
        self.api_type = provider.api_type
        self.base_api_url = provider.base_api_url or ""
        self.base_web_url = provider.base_web_url

    def _subjects_url(self) -> str:
        return f"{self.base_api_url.rstrip('/')}/subjects"

    def _tableinfo_url(self, dataset_code: str) -> str:
        return f"{self.base_api_url.rstrip('/')}/tableinfo/{dataset_code}"

    def _data_url(self, dataset_code: str) -> str:
        return f"{self.base_api_url.rstrip('/')}/data/{dataset_code}/JSONSTAT"

    async def health_check(self, dataset_code: str | None = None) -> bool:
        url = self._subjects_url() if dataset_code is None else self._tableinfo_url(dataset_code)
        payload = await self._get_json(url, params={"lang": self.language})
        return payload is not None

    async def discover_datasets(
        self,
        task_id: uuid.UUID,
        **_: Any,
    ) -> list[DiscoveredDataset]:
        payload = await self._get_json(
            self._subjects_url(),
            params={
                "lang": self.language,
                "recursive": "true",
                "omitSubjectsWithoutTables": "true",
                "includeTables": "true",
                "format": "JSON",
            },
        )
        if not isinstance(payload, list):
            return []
        tables_by_id = _collect_tables(payload)
        paths_by_id = _parse_paths(payload)
        output: list[DiscoveredDataset] = []
        for dataset_code, table in sorted(tables_by_id.items()):
            paths = paths_by_id.get(dataset_code, [])
            primary_path = paths[0] if paths else []
            subject = primary_path[0] if primary_path else None
            first_period = str(table.get("firstPeriod") or "").strip() or None
            last_period = str(table.get("latestPeriod") or table.get("lastPeriod") or "").strip() or None
            updated = parse_dt(table.get("updated")) or parse_dt("1970-01-01T00:00:00+00:00")
            if updated is None:
                continue
            output.append(
                DiscoveredDataset(
                    task_id=task_id,
                    provider_code=self.provider_code,
                    dataset_code=dataset_code,
                    language=self.language,
                    updated=updated,
                    label=str(table.get("text") or dataset_code).strip(),
                    description=str(table.get("description")).strip() if table.get("description") is not None else None,
                    source=f"Statistics Denmark - statbank.dk/{dataset_code}",
                    subject_code=subject["id"] if subject else None,
                    subject_label=subject["label"] if subject else None,
                    time_unit=determine_time_unit(first_period, last_period) if first_period and last_period else None,
                    first_period=first_period,
                    last_period=last_period,
                    discontinued=(not bool(table.get("active")) if isinstance(table.get("active"), bool) else False),
                    metadata_url=f"{self._tableinfo_url(dataset_code)}?lang={self.language}",
                    data_url=f"{self._data_url(dataset_code)}?lang={self.language}",
                    web_url=f"{self.base_web_url.rstrip('/')}/{dataset_code}" if self.base_web_url else None,
                    paths=paths or None,
                    extension={"unit": table.get("unit"), "variable_names": table.get("variables")},
                )
            )
        return output

    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        task_id: uuid.UUID | None = None,
        **_: Any,
    ) -> ResolvedDatasetMetadata:
        payload = await self._get_json(
            self._tableinfo_url(discovered.dataset_code),
            params={"lang": self.language},
        )
        dimensions: dict[str, dict[str, Any]] = {}
        dimension_ids: list[str] = []
        required_dimensions: dict[str, bool | None] = {}
        role_map: dict[str, list[str]] = {}
        extension = dict(discovered.extension)
        if isinstance(payload, dict):
            for position, variable in enumerate(payload.get("variables") or []):
                if not isinstance(variable, dict):
                    continue
                dimension_id = str(variable.get("id") or "").strip()
                if not dimension_id:
                    continue
                values = variable.get("values") if isinstance(variable.get("values"), list) else []
                index: dict[str, int] = {}
                labels: dict[str, str] = {}
                for ordinal, item in enumerate(values):
                    if not isinstance(item, dict):
                        continue
                    value_id = str(item.get("id") or "").strip()
                    if not value_id:
                        continue
                    index[value_id] = ordinal
                    labels[value_id] = str(item.get("text") or value_id).strip()
                if not index:
                    continue
                label = str(variable.get("text") or dimension_id).strip()
                dimensions[dimension_id] = {
                    "label": label,
                    "category": {"index": index, "label": labels},
                }
                dimension_ids.append(dimension_id)
                elimination = variable.get("elimination")
                required_dimensions[dimension_id] = None if elimination is None else not bool(elimination)
                role = "geo" if variable.get("map") else detect_role(dimension_id, label, bool(variable.get("time")))
                if role:
                    role_map.setdefault(role, []).append(dimension_id)
                extension.setdefault("dimension_extensions", {})[dimension_id] = {
                    "extension": {"position": position}
                }
        label = (
            str(payload.get("text")).strip()
            if isinstance(payload, dict) and payload.get("text") is not None
            else (discovered.label or discovered.dataset_code)
        )
        description = (
            str(payload.get("description")).strip()
            if isinstance(payload, dict) and payload.get("description") is not None
            else discovered.description
        )
        updated = (
            parse_dt(payload.get("updated"))
            if isinstance(payload, dict)
            else None
        ) or discovered.updated
        return ResolvedDatasetMetadata(
            task_id=task_id or discovered.task_id,
            provider_code=discovered.provider_code,
            dataset_code=discovered.dataset_code,
            language=discovered.language,
            updated=updated,
            label=label,
            time_unit=discovered.time_unit or "Other",
            first_period=discovered.first_period or "",
            last_period=discovered.last_period or discovered.first_period or "",
            paths=discovered.paths or [],
            role=role_map,
            metadata_url=discovered.metadata_url or f"{self._tableinfo_url(discovered.dataset_code)}?lang={self.language}",
            data_url=discovered.data_url or f"{self._data_url(discovered.dataset_code)}?lang={self.language}",
            dimension=dimensions,
            required_dimensions=required_dimensions,
            note=(normalize_note(payload.get("footnote")) if isinstance(payload, dict) else None) or discovered.note,
            source=discovered.source,
            description=description,
            discontinued=not bool(payload.get("active")) if isinstance(payload, dict) and isinstance(payload.get("active"), bool) else discovered.discontinued,
            subject_code=discovered.subject_code,
            subject_label=discovered.subject_label,
            web_url=discovered.web_url,
            doc_url=(
                str(payload.get("documentation", {}).get("url")).strip()
                if isinstance(payload, dict)
                and isinstance(payload.get("documentation"), dict)
                and payload["documentation"].get("url") is not None
                else discovered.doc_url
            ),
            official_statistics=discovered.official_statistics,
            contact=(normalize_contact(payload.get("contacts")) if isinstance(payload, dict) else None) or discovered.contact,
            dimension_ids=dimension_ids or None,
            extension=extension,
        )
