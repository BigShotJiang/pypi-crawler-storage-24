from __future__ import annotations

import asyncio
import csv
import gzip
import io
import re
import uuid
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from ..base_api_client import APIWrapper
from ..models import DiscoveredDataset, Provider, ResolvedDatasetMetadata
from ..utils import parse_dt

DATA_URL_TEMPLATE = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/{dataset_code}"
METADATA_URL_TEMPLATE = (
    "https://ec.europa.eu/eurostat/api/dissemination/sdmx/3.0/data/dataflow/"
    "ESTAT/{dataset_code}/1.0?format=JSON&lang={language}&compress=false&attributes=none&measures=none"
)
WEB_URL_TEMPLATE = "https://ec.europa.eu/eurostat/databrowser/product/page/{dataset_code}"
DOC_URL_TEMPLATE = "https://ec.europa.eu/eurostat/cache/metadata/en/{lowercase_dataset_code}.htm"
TOC_URL_TEMPLATE = "https://ec.europa.eu/eurostat/api/dissemination/catalogue/toc/txt?lang={language}"
DATAFLOWS_URL = (
    "https://ec.europa.eu/eurostat/api/dissemination/sdmx/3.0/structure/dataflow/"
    "ESTAT/all/1.0?format=JSON&compress=false"
)
CODELISTS_URL = "https://ec.europa.eu/eurostat/api/dissemination/sdmx/2.1/codelist/ESTAT/all/latest?format=json"
METABASE_URL = "https://ec.europa.eu/eurostat/api/dissemination/catalogue/metabase.txt.gz"
_GLOBAL_CACHE: dict[
    str,
    tuple[
        dict[str, _Dataflow],
        dict[str, Any],
        dict[str, dict[str, list[str]]],
        dict[str, list[list[dict[str, str]]]],
    ],
] = {}
_GLOBAL_CACHE_LOCK = asyncio.Lock()
_CLEAN_TAGS_PATTERN = re.compile(r"<.*?>")


def _remove_html_tags(text: str) -> str:
    return re.sub(_CLEAN_TAGS_PATTERN, "", text)


def _parse_toc_paths(toc_text: str) -> dict[str, list[list[dict[str, str]]]]:
    reader = csv.reader(io.StringIO(toc_text), delimiter="\t", quotechar='"')
    next(reader, None)
    folder_stack: list[dict[str, str]] = []
    full_stack: list[dict[str, str]] = []
    code_to_paths: dict[str, list[list[dict[str, str]]]] = {}
    for row in reader:
        if len(row) < 3:
            continue
        title, code, item_type = row[0], row[1], row[2]
        if not title.strip() or not code.strip():
            continue
        indent_level = (len(title) - len(title.lstrip())) // 4
        full_stack = full_stack[:indent_level]
        full_stack.append({"id": code, "label": title.strip(), "type": item_type})
        folder_stack = [
            {"id": node["id"], "label": node["label"]}
            for node in full_stack
            if node.get("type") == "folder"
        ]
        if item_type != "folder":
            code_to_paths.setdefault(code.upper(), []).append(list(folder_stack))
    return code_to_paths


def _parse_metabase(gzipped_content: bytes) -> dict[str, dict[str, list[str]]]:
    metabase: dict[str, dict[str, list[str]]] = {}
    with gzip.open(io.BytesIO(gzipped_content), "rt", encoding="utf-8") as handle:
        dataset_dim_values: defaultdict[str, defaultdict[str, list[str]]] = defaultdict(
            lambda: defaultdict(list)
        )
        for line in handle:
            stripped = line.strip()
            if not stripped:
                continue
            parts = stripped.split("\t")
            if len(parts) < 3:
                continue
            dataset_code, dimension, value = parts[:3]
            dataset_dim_values[dataset_code.upper()][dimension].append(value)
    for dataset_code, dimensions in dataset_dim_values.items():
        metabase[dataset_code] = dict(dimensions)
    return metabase


@dataclass(slots=True)
class _Dataflow:
    dataset_code: str
    label: str
    updated: str
    source: str | None
    description: str | None
    first_period: str | None
    last_period: str | None
    extension: dict[str, Any]


class EurostatClient(APIWrapper):
    def __init__(self, provider: Provider, **kwargs: Any) -> None:
        super().__init__(
            provider_code=provider.provider_code,
            label=provider.label,
            language=kwargs.pop("language"),
            json_request_handler=kwargs.pop("json_request_handler"),
            text_request_handler=kwargs.pop("text_request_handler", None),
            bytes_request_handler=kwargs.pop("bytes_request_handler", None),
            logger=kwargs.pop("logger", None),
        )
        self.provider = provider
        self.api_type = provider.api_type

    async def health_check(self, dataset_code: str | None = None) -> bool:
        url = (
            DATAFLOWS_URL
            if dataset_code is None
            else METADATA_URL_TEMPLATE.format(
                dataset_code=dataset_code,
                language=self.language,
            )
        )
        payload = await self._get_json(url)
        return payload is not None

    async def _fetch_global_metadata(
        self,
    ) -> tuple[
        dict[str, _Dataflow],
        dict[str, Any],
        dict[str, dict[str, list[str]]],
        dict[str, list[list[dict[str, str]]]],
    ]:
        cache_key = self.language.lower()
        cached = _GLOBAL_CACHE.get(cache_key)
        if cached is not None:
            return cached
        async with _GLOBAL_CACHE_LOCK:
            cached = _GLOBAL_CACHE.get(cache_key)
            if cached is not None:
                return cached
            toc_text, dataflows_payload, codelists_payload, metabase_payload = (
                await asyncio.gather(
                    self._get_text(TOC_URL_TEMPLATE.format(language=self.language)),
                    self._get_json(DATAFLOWS_URL),
                    self._get_json(CODELISTS_URL),
                    self._get_bytes(METABASE_URL),
                )
            )
            dataflows: dict[str, _Dataflow] = {}
            if isinstance(dataflows_payload, dict):
                items = dataflows_payload.get("link", {}).get("item", [])
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    extension = item.get("extension", {})
                    if not isinstance(extension, dict):
                        extension = {}
                    dataset_code = str(extension.get("id") or "").upper()
                    label = str(item.get("label") or "").strip()
                    if not dataset_code or not label:
                        continue
                    annotation_map: dict[str, Any] = {}
                    for annotation in extension.get("annotation", []):
                        if not isinstance(annotation, dict):
                            continue
                        annotation_type = annotation.get("type")
                        if not annotation_type:
                            continue
                        for key in ("date", "title", "text"):
                            if key in annotation:
                                annotation_map[str(annotation_type)] = annotation[key]
                                break
                    updated = max(
                        str(annotation_map.get("UPDATE_DATA") or ""),
                        str(annotation_map.get("UPDATE_STRUCTURE") or ""),
                    )
                    if not updated:
                        continue
                    description = extension.get("description")
                    dataflows[dataset_code] = _Dataflow(
                        dataset_code=dataset_code,
                        label=label,
                        updated=updated,
                        source=str(annotation_map.get("SOURCE_INSTITUTIONS") or "Eurostat"),
                        description=_remove_html_tags(description)
                        if isinstance(description, str)
                        else None,
                        first_period=str(
                            annotation_map.get("OBS_PERIOD_OVERALL_OLDEST") or ""
                        ).strip()
                        or None,
                        last_period=str(
                            annotation_map.get("OBS_PERIOD_OVERALL_LATEST") or ""
                        ).strip()
                        or None,
                        extension={"dataflow_extension": extension} if extension else {},
                    )
            codelists = codelists_payload if isinstance(codelists_payload, dict) else {}
            metabase = (
                _parse_metabase(metabase_payload)
                if isinstance(metabase_payload, bytes)
                else {}
            )
            toc_paths = _parse_toc_paths(toc_text) if isinstance(toc_text, str) else {}
            _GLOBAL_CACHE[cache_key] = (dataflows, codelists, metabase, toc_paths)
            return _GLOBAL_CACHE[cache_key]

    def _build_dimensions(
        self,
        dataset_code: str,
        codelists: dict[str, Any],
        metabase: dict[str, dict[str, list[str]]],
    ) -> tuple[dict[str, dict[str, Any]], list[str], dict[str, list[str]], str]:
        dimensions: dict[str, dict[str, Any]] = {}
        role: dict[str, list[str]] = {}
        time_unit = "Other"
        items = codelists.get("link", {}).get("item", []) if isinstance(codelists, dict) else []
        for dimension_id, category_ids in metabase.get(dataset_code, {}).items():
            if dimension_id.lower() == "time":
                time_unit = (
                    "Annual"
                    if category_ids and all(len(value) == 4 for value in category_ids[:2])
                    else "Other"
                )
                labels = {value: value for value in category_ids}
                index = {value: ordinal for ordinal, value in enumerate(category_ids)}
                dimensions[dimension_id] = {
                    "label": "Time",
                    "category": {"index": index, "label": labels},
                }
                role.setdefault("time", []).append(dimension_id)
                continue

            dimension_label = dimension_id
            label_map = {value: value for value in category_ids}
            for item in items:
                if not isinstance(item, dict):
                    continue
                extension = item.get("extension", {})
                if not isinstance(extension, dict):
                    continue
                if str(extension.get("id") or "").upper() != dimension_id.upper():
                    continue
                dimension_label = str(item.get("label") or dimension_id)
                labels = item.get("category", {}).get("label", {})
                if isinstance(labels, dict):
                    label_map = {
                        value: str(labels.get(value, value)) for value in category_ids
                    }
                break

            dimensions[dimension_id] = {
                "label": dimension_label,
                "category": {
                    "index": {
                        value: ordinal for ordinal, value in enumerate(category_ids)
                    },
                    "label": label_map,
                },
            }
            if dimension_id.lower() == "geo":
                role.setdefault("geo", []).append(dimension_id)
        return dimensions, list(dimensions.keys()), role, time_unit

    async def discover_datasets(
        self,
        task_id: uuid.UUID,
        **_: Any,
    ) -> list[DiscoveredDataset]:
        dataflows, codelists, metabase, toc_paths = await self._fetch_global_metadata()
        output: list[DiscoveredDataset] = []
        for dataset_code, dataflow in dataflows.items():
            if "$dv_" in dataset_code.lower():
                continue
            dimensions, dimension_ids, role, time_unit = self._build_dimensions(
                dataset_code,
                codelists,
                metabase,
            )
            updated = parse_dt(dataflow.updated)
            if updated is None:
                continue
            paths = toc_paths.get(dataset_code, [])
            subject = paths[0][0] if paths and paths[0] else None
            output.append(
                DiscoveredDataset(
                    task_id=task_id,
                    provider_code=self.provider_code,
                    dataset_code=dataset_code,
                    language=self.language,
                    updated=updated,
                    label=_remove_html_tags(dataflow.label),
                    source=dataflow.source,
                    description=dataflow.description,
                    time_unit=time_unit,
                    first_period=dataflow.first_period,
                    last_period=dataflow.last_period,
                    paths=paths or None,
                    subject_code=subject["id"] if subject else None,
                    subject_label=subject["label"] if subject else None,
                    metadata_url=METADATA_URL_TEMPLATE.format(
                        dataset_code=dataset_code,
                        language=self.language,
                    ),
                    data_url=DATA_URL_TEMPLATE.format(dataset_code=dataset_code),
                    web_url=WEB_URL_TEMPLATE.format(dataset_code=dataset_code),
                    doc_url=DOC_URL_TEMPLATE.format(
                        lowercase_dataset_code=dataset_code.lower()
                    ),
                    dimension=dimensions,
                    required_dimensions=dict.fromkeys(dimension_ids, None),
                    role=role,
                    dimension_ids=dimension_ids,
                    extension=dataflow.extension,
                )
            )
        return output

    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        task_id: uuid.UUID | None = None,
        **_: Any,
    ) -> ResolvedDatasetMetadata:
        return ResolvedDatasetMetadata(
            task_id=task_id or discovered.task_id,
            provider_code=discovered.provider_code,
            dataset_code=discovered.dataset_code,
            language=discovered.language,
            updated=discovered.updated,
            label=discovered.label or discovered.dataset_code,
            time_unit=discovered.time_unit or "Other",
            first_period=discovered.first_period or "",
            last_period=discovered.last_period or discovered.first_period or "",
            paths=discovered.paths or [],
            role=discovered.role or {},
            metadata_url=discovered.metadata_url or "",
            data_url=discovered.data_url or "",
            dimension=discovered.dimension or {},
            required_dimensions=discovered.required_dimensions or {},
            note=discovered.note,
            source=discovered.source or "Eurostat",
            description=discovered.description,
            discontinued=discovered.discontinued,
            subject_code=discovered.subject_code,
            subject_label=discovered.subject_label,
            web_url=discovered.web_url,
            doc_url=discovered.doc_url,
            official_statistics=discovered.official_statistics,
            contact=discovered.contact,
            dimension_ids=discovered.dimension_ids,
            extension=discovered.extension,
        )
