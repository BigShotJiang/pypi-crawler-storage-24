from __future__ import annotations

import uuid
from typing import Any

from ..base_api_client import APIWrapper
from ..models import DiscoveredDataset, Provider, ResolvedDatasetMetadata
from ..parsers import parse_pxweb2_discovery_table, parse_pxweb2_metadata_payload
from ..utils import parse_dt


class PxWeb2Client(APIWrapper):
    def __init__(self, provider: Provider, **kwargs: Any) -> None:
        super().__init__(
            provider_code=provider.provider_code,
            label=provider.label,
            language=kwargs.pop("language"),
            json_request_handler=kwargs.pop("json_request_handler"),
            text_request_handler=kwargs.pop("text_request_handler", None),
            bytes_request_handler=kwargs.pop("bytes_request_handler", None),
            logger=kwargs.pop("logger", None),
        )
        self.provider = provider
        self.api_type = provider.api_type
        self.base_api_url = provider.base_api_url or ""
        self.base_web_url = provider.base_web_url

    def _get_api_url(self, endpoint: str, dataset_code: str | None = None) -> str:
        clean_api = self.base_api_url.rstrip("/")
        if endpoint == "config":
            return f"{clean_api}/config"
        if endpoint == "tables":
            return f"{clean_api}/tables"
        if endpoint == "metadata" and dataset_code:
            return f"{clean_api}/tables/{dataset_code}/metadata"
        if endpoint == "data" and dataset_code:
            return f"{clean_api}/tables/{dataset_code}/data"
        raise ValueError(f"Unsupported endpoint: {endpoint}")

    async def health_check(self, dataset_code: str | None = None) -> bool:
        url = self._get_api_url("metadata" if dataset_code else "config", dataset_code)
        payload = await self._get_json(url, params={"lang": self.language})
        return payload is not None

    async def discover_datasets(
        self,
        task_id: uuid.UUID,
        **_: Any,
    ) -> list[DiscoveredDataset]:
        discovered: list[DiscoveredDataset] = []
        page_number = 1
        total_pages = 1
        while page_number <= total_pages:
            payload = await self._get_json(
                self._get_api_url("tables"),
                params={
                    "lang": self.language,
                    "pageSize": 1000,
                    "pageNumber": page_number,
                    "includeDiscontinued": "true",
                },
            )
            if not isinstance(payload, dict):
                break
            tables = payload.get("tables")
            page_info = payload.get("page", {})
            if not isinstance(tables, list):
                break
            total_pages = int(page_info.get("totalPages", page_number))
            for table in tables:
                if not isinstance(table, dict):
                    continue
                parsed = parse_pxweb2_discovery_table(
                    table,
                    base_api_url=self.base_api_url,
                    base_web_url=self.base_web_url,
                    language=self.language,
                )
                if not parsed:
                    continue
                updated = parsed["updated"] or parse_dt("1970-01-01T00:00:00+00:00")
                if updated is None:
                    continue
                discovered.append(
                    DiscoveredDataset(
                        task_id=task_id,
                        provider_code=self.provider_code,
                        dataset_code=parsed["dataset_code"],
                        language=self.language,
                        updated=updated,
                        label=parsed["label"],
                        source=parsed["source"],
                        note=parsed["note"],
                        description=parsed["description"],
                        time_unit=parsed["time_unit"],
                        first_period=parsed["first_period"],
                        last_period=parsed["last_period"],
                        discontinued=parsed["discontinued"],
                        paths=parsed["paths"],
                        subject_code=parsed["subject_code"],
                        metadata_url=parsed["metadata_url"],
                        data_url=parsed["data_url"],
                        web_url=parsed["web_url"],
                        extension=parsed["extension"],
                    )
                )
            page_number += 1
        return discovered

    async def resolve_dataset_metadata(
        self,
        discovered: DiscoveredDataset,
        task_id: uuid.UUID | None = None,
        **_: Any,
    ) -> ResolvedDatasetMetadata:
        payload = await self._get_json(
            self._get_api_url("metadata", discovered.dataset_code),
            params={"lang": self.language, "outputFormat": "json-stat2"},
        )
        parsed = (
            parse_pxweb2_metadata_payload(
                payload,
                default_note=discovered.note,
                default_subject_label=discovered.subject_label,
                default_official_statistics=discovered.official_statistics,
                default_contact=discovered.contact,
                default_extension=discovered.extension,
            )
            if isinstance(payload, dict)
            else {
                "dimensions": None,
                "dimension_ids": None,
                "required_dimensions": None,
                "role": discovered.role,
                "note": discovered.note,
                "subject_label": discovered.subject_label,
                "official_statistics": discovered.official_statistics,
                "contact": discovered.contact,
                "extension": dict(discovered.extension),
            }
        )
        return ResolvedDatasetMetadata(
            task_id=task_id or discovered.task_id,
            provider_code=discovered.provider_code,
            dataset_code=discovered.dataset_code,
            language=discovered.language,
            updated=discovered.updated,
            label=discovered.label or discovered.dataset_code,
            time_unit=discovered.time_unit or "Other",
            first_period=discovered.first_period or "",
            last_period=discovered.last_period or discovered.first_period or "",
            paths=discovered.paths or [],
            role=parsed["role"] or {},
            metadata_url=discovered.metadata_url
            or self._get_api_url("metadata", discovered.dataset_code),
            data_url=discovered.data_url or self._get_api_url("data", discovered.dataset_code),
            dimension=parsed["dimensions"] or {},
            required_dimensions=parsed["required_dimensions"] or {},
            note=parsed["note"],
            source=discovered.source,
            description=discovered.description,
            discontinued=discovered.discontinued,
            subject_code=discovered.subject_code,
            subject_label=parsed["subject_label"],
            web_url=discovered.web_url,
            official_statistics=parsed["official_statistics"],
            contact=parsed["contact"],
            dimension_ids=parsed["dimension_ids"],
            extension=parsed["extension"],
        )
