import os
from pathlib import Path

import pytest
from jinja2 import Environment, FileSystemLoader
from metapub.exceptions import MetaPubError
from pymultirole_plugins.v1.schema import Document, DocumentList
from starlette.datastructures import Headers, UploadFile

from pyconverters_pubmedfetcher.pubmedfetcher import (
    FakePubMedArticle,
    InputFormat,
    PubmedFetcherConverter,
    PubmedFetcherParameters,
    article_to_document,
    get_article,
    get_fetchers,
)


@pytest.mark.skipif(not os.environ.get("NCBI_API_KEY"), reason="NCBI_API_KEY not set")
@pytest.mark.parametrize(
    "journal",
    [
        "SAGE Open Medical Case Reports",
        "Case Reports in Neurology",
        "Case Reports in Oncology",
        "Case Reports in Pediatrics",
        "Case Reports in Psychiatry",
    ],
)
def test_pubmedfetcher_query(journal):
    testdir = Path(__file__).parent
    tmpldir = testdir / "data"
    env = Environment(loader=FileSystemLoader(tmpldir))
    template = env.get_template("query.txt")
    converter = PubmedFetcherConverter()
    parameters = PubmedFetcherParameters(input_format=InputFormat.Query, retmax=100)
    output_from_parsed_template = template.render(journal=journal)
    source_tmpl = tmpldir / f"query_{journal}.txt"
    with source_tmpl.open("w") as fh:
        fh.write(output_from_parsed_template)

    with source_tmpl.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source_tmpl.name, headers=Headers({"content-type": "text/plain"})), parameters
        )
        sum_file = testdir / tmpldir / f"query_{journal}.json"
        dl = DocumentList(root=docs)
        with sum_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@pytest.mark.skipif(not os.environ.get("NCBI_API_KEY"), reason="NCBI_API_KEY not set")
def test_pubmedfetcher_list():
    model = PubmedFetcherConverter.get_model()
    model_class = model.construct().__class__
    assert model_class == PubmedFetcherParameters
    converter = PubmedFetcherConverter()
    parameters = PubmedFetcherParameters(input_format=InputFormat.ID_List)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/list.txt")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "text/plain"})), parameters
        )
        assert len(docs) == 5
        assert docs[0].identifier == "34239458"
        assert docs[1].identifier == "21886606"
        assert docs[2].identifier == "21886599"
        assert docs[2].metadata["DOI"] == "10.2174/157015911795017263"
        assert docs[3].identifier == "10.18585/inabj.v12i2.1171"
        assert docs[3].metadata["DOI"] == "10.18585/inabj.v12i2.1171"
        assert docs[4].identifier == "21886588"
        assert docs[4].metadata["PMC"] == "3137179"


@pytest.mark.skipif(not os.environ.get("NCBI_API_KEY"), reason="NCBI_API_KEY not set")
def test_pubmedfetcher_allids():
    model = PubmedFetcherConverter.get_model()
    model_class = model.construct().__class__
    assert model_class == PubmedFetcherParameters
    converter = PubmedFetcherConverter()
    parameters = PubmedFetcherParameters(input_format=InputFormat.ID_List)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/DOIs-only.txt")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "text/plain"})), parameters
        )
        assert len(docs) == 153


@pytest.mark.skipif(not os.environ.get("NCBI_API_KEY"), reason="NCBI_API_KEY not set")
def test_pubmedfetcher_xml():
    converter = PubmedFetcherConverter()
    parameters = PubmedFetcherParameters(input_format=InputFormat.XML_PubmedArticleSet, discard_if_no_abstract=False)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/MedLine2021-09-06-19-04-11.xml")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "text/xml"})), parameters
        )
        assert len(docs) == 91
        assert docs[0].identifier == "21886606"


def test_article_to_document_with_abstract_and_title():
    art = FakePubMedArticle(doi="10.1234/test", pmid="12345678", title="Test Title", abstract="Test abstract.")
    doc = article_to_document(art)
    assert doc is not None
    assert doc.identifier == "12345678"
    assert doc.title == "Test Title"
    assert "Test Title" in doc.text
    assert "Test abstract." in doc.text


def test_article_to_document_no_abstract_discarded():
    art = FakePubMedArticle(doi="10.1234/test", pmid="12345678", title="Test Title", abstract=None)
    doc = article_to_document(art, discard_if_no_abstract=True)
    assert doc is None


def test_article_to_document_no_abstract_kept():
    art = FakePubMedArticle(doi="10.1234/test", pmid="12345678", title="Test Title", abstract=None)
    doc = article_to_document(art, discard_if_no_abstract=False)
    assert doc is not None
    assert doc.identifier == "12345678"
    assert doc.text == "Test Title\n\n"


def test_article_to_document_no_title_no_abstract_returns_none():
    art = FakePubMedArticle(doi="10.1234/test", pmid="12345678", title=None, abstract=None)
    doc = article_to_document(art)
    assert doc is None


def test_article_to_document_with_segmentation():
    art = FakePubMedArticle(
        doi="10.1234/test",
        pmid="12345678",
        title="Test Title",
        abstract="First sentence. Second sentence. Third sentence.",
    )
    doc = article_to_document(art, segment=True)
    assert doc is not None
    assert len(doc.sentences) > 0


def test_article_to_document_with_doi_and_pmc():
    art = FakePubMedArticle(
        doi="10.1234/test",
        pmc="PMC1234567",
        pmid="12345678",
        title="Title",
        abstract="Abstract.",
    )
    doc = article_to_document(art)
    assert doc.metadata["DOI"] == "10.1234/test"
    assert doc.metadata["PMC"] == "PMC1234567"


def test_get_article_unknown_identifier():
    pm_fetcher, cr_fetcher = get_fetchers()
    with pytest.raises(MetaPubError):
        get_article(pm_fetcher, cr_fetcher, "not-a-valid-identifier")
