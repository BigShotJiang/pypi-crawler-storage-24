#!/usr/bin/env python3
"""MoMCP-TUI 交互式管理面板 - CLI 入口"""

from InquirerPy import inquirer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
import subprocess
import sys
import platform
import os
from pathlib import Path

console = Console()


class MoMCPManager:
    """MoMCP-TUI 管理器"""
    
    def __init__(self):
        self.package_name = "momcp-tui"
        self.entry_command = "momcp-tui"
        self.self_package_name = "momcp-manager"
        self.self_entry_command = "momcp-manager"
        # 默认参数
        self.default_update_args = "--upgrade"
        self.default_uninstall_args = "-y"
        self.custom_update_args = ""
        self.custom_uninstall_args = ""
        # PyPI 镜像源
        self.pypi_index = "https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple"
        
    def check_python_version(self) -> bool:
        """检查 Python 版本"""
        if sys.version_info < (3, 10):
            return False
        return True
    
    def is_conda_environment(self) -> bool:
        """检查是否在 Conda 环境中"""
        if 'CONDA_PREFIX' in os.environ or 'CONDA_DEFAULT_ENV' in os.environ:
            return True
        
        python_path = sys.executable.lower()
        if 'anaconda' in python_path or 'conda' in python_path:
            return True
        
        return False
    
    def get_conda_env_name(self) -> str:
        """获取当前 Conda 环境名称"""
        return os.environ.get('CONDA_DEFAULT_ENV', 'base')
    
    def get_conda_prefix(self) -> str:
        """获取 Conda 环境路径"""
        return os.environ.get('CONDA_PREFIX', '')
    
    def find_package_location(self, package_name: str) -> str:
        """查找包的安装位置"""
        try:
            cmd_name = 'where' if platform.system() == 'Windows' else 'which'
            result = subprocess.run(
                [cmd_name, f"{package_name}-script.py" if platform.system() == 'Windows' else package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout.strip().split('\n')[0]
        except Exception:
            pass
        return ''
    
    def is_installed_in_conda(self, package_name: str) -> bool:
        """检查包是否安装在 Conda 环境中"""
        location = self.find_package_location(package_name)
        if not location:
            return False
        
        if self.is_conda_environment():
            conda_prefix = self.get_conda_prefix()
            return location.startswith(conda_prefix)
        
        return False
    
    def is_installed(self) -> bool:
        """检查是否已安装"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.package_name],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def get_installed_version(self) -> str:
        """获取已安装版本"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if line.startswith("Version:"):
                        return line.split(":")[1].strip()
        except Exception:
            pass
        return "未知"
    
    def get_latest_version(self) -> str:
        """获取 MoMCP-TUI 最新版本号"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", self.package_name],
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout if result.stdout.strip() else result.stderr
            if output and "Available versions:" in output:
                import re
                match = re.search(r'Available versions: ([\d\.]+)', output)
                if match:
                    return match.group(1)
            return "unknown"
        except Exception:
            return "unknown"
    
    def install(self) -> bool:
        """安装 MoMCP-TUI"""
        console.print("\n")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在安装 MoMCP-TUI...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-i", self.pypi_index, "-U", self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]安装失败：{e}[/]")
                return False
    
    def uninstall(self, custom_args: str = None) -> bool:
        """卸载 MoMCP-TUI"""
        console.print("\n")
        args = custom_args if custom_args else self.default_uninstall_args
        if self.custom_uninstall_args:
            args = f"{args} {self.custom_uninstall_args}"
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"正在卸载 MoMCP-TUI... (参数：{args})", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "uninstall"] + args.split() + [self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]卸载失败：{e}[/]")
                return False
    
    def update(self, custom_args: str = None) -> bool:
        """更新 MoMCP-TUI"""
        console.print("\n")
        args = custom_args if custom_args else self.default_update_args
        if self.custom_update_args:
            args = f"{args} {self.custom_update_args}"
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"正在更新 MoMCP-TUI... (参数：{args})", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-i", self.pypi_index] + args.split() + [self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]更新失败：{e}[/]")
                return False
    
    def is_self_installed(self) -> bool:
        """检查 momcp 自身是否已安装"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.self_package_name],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def get_self_version(self) -> str:
        """获取 momcp 自身已安装版本"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.self_package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if line.startswith("Version:"):
                        return line.split(":")[1].strip()
        except Exception:
            pass
        return "未知"
    
    def get_self_latest_version(self) -> str:
        """获取 momcp 自身最新版本号"""
        try:
            # 方法 1: 尝试使用 pip index
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", self.self_package_name],
                capture_output=True,
                text=True,
                timeout=10
            )
            # 检查 stdout 或 stderr (Windows 可能在 stderr 中)
            output = result.stdout if result.stdout.strip() else result.stderr
            if output and "Available versions:" in output:
                import re
                match = re.search(r'Available versions: ([\d\.]+)', output)
                if match:
                    return match.group(1)
            
            # 方法 2: 直接返回 unknown
            return "unknown"
        except Exception:
            return "unknown"
    
    def update_self(self) -> bool:
        """更新 momcp 自身"""
        console.print("\n")
        
        # 检查是否在 Conda 的非 base 环境中
        if self.is_conda_environment():
            env_name = self.get_conda_env_name()
            if env_name != 'base':
                console.print(f"[yellow]检测到当前在 Conda 环境 [{env_name}] 中[/]")
                console.print("[cyan]将在此环境中执行更新...[/]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在更新 momcp...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-i", self.pypi_index, "--upgrade", self.self_package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]更新失败：{e}[/]")
                return False
    
    def launch(self) -> bool:
        """启动 MoMCP-TUI"""
        try:
            console.print("\n[bold cyan]正在启动 MoMCP-TUI...[/]\n")
            subprocess.run([self.entry_command])
            return True
        except KeyboardInterrupt:
            console.print("\n[yellow]程序已退出[/]")
            return True
        except FileNotFoundError:
            console.print("[red]错误：未找到 momcp-tui 命令，请先安装程序[/]")
            return False
        except Exception as e:
            console.print(f"[red]启动失败：{e}[/]")
            return False


def show_banner():
    """显示欢迎横幅"""
    banner = """
     ▄▄       ▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄       ▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ 
    ▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
    ▐░▌░▌   ▐░▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌░▌   ▐░▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌
    ▐░▌▐░▌ ▐░▌▐░▌▐░▌       ▐░▌▐░▌▐░▌ ▐░▌▐░▌▐░▌          ▐░▌       ▐░▌
    ▐░▌ ▐░▐░▌ ▐░▌▐░▌       ▐░▌▐░▌ ▐░▐░▌ ▐░▌▐░▌          ▐░█▄▄▄▄▄▄▄█░▌
    ▐░▌  ▐░▌  ▐░▌▐░▌       ▐░▌▐░▌  ▐░▌  ▐░▌▐░▌          ▐░░░░░░░░░░░▌
    ▐░▌   ▀   ▐░▌▐░▌       ▐░▌▐░▌   ▀   ▐░▌▐░▌          ▐░█▀▀▀▀▀▀▀▀▀ 
    ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌          ▐░▌          
    ▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░▌          
    ▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌          
     ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀           
                                                                 
    
                  ╔══════════════════════════════════════════╗
                  ║                                          ║
                  ║        Multi-MCP Tool Orchestrator       ║
                  ║                                          ║
                  ╚══════════════════════════════════════════╝
    """
    console.print(Panel(banner, style="bold cyan", border_style="bright_cyan", title="MoMCP", title_align="center"))


def show_system_info(manager: MoMCPManager):
    """显示系统信息"""
    installed = manager.is_installed()
    version = manager.get_installed_version() if installed else "未安装"
    self_installed = manager.is_self_installed()
    self_version = manager.get_self_version() if self_installed else "未安装"
    
    info_lines = [
        f"[bold]系统信息:[/]",
        f"  - Python 版本：{sys.version.split()[0]}",
        f"  - 操作系统：{platform.system()} {platform.release()}",
    ]
    
    # 如果是 Conda 环境，显示环境信息
    if manager.is_conda_environment():
        env_name = manager.get_conda_env_name()
        conda_prefix = manager.get_conda_prefix()
        info_lines.append(f"  - Conda 环境：[cyan]{env_name}[/] ({conda_prefix})")
    
    info_lines.extend([
        f"  - momcp-manager 状态：{'[green]已安装[/]' if self_installed else '[red]未安装[/]'} (版本：[cyan]{self_version}[/])",
        f"  - MoMCP-TUI 状态：{'[green]已安装[/]' if installed else '[red]未安装[/]'} (版本：[cyan]{version}[/])",
    ])
    
    info_panel = Panel(
        "\n".join(info_lines),
        title="状态面板",
        border_style="blue"
    )
    console.print(info_panel)


def main_menu(manager: MoMCPManager):
    """主菜单"""
    while True:
        console.print("\n")
        
        # 获取当前状态
        installed = manager.is_installed()
        version = manager.get_installed_version() if installed else "未安装"
        self_installed = manager.is_self_installed()
        self_version = manager.get_self_version() if self_installed else "未安装"
        
        # 动态生成菜单选项
        choices = []
        
        # momcp 自我更新选项
        if self_installed:
            choices.append({
                "name": f"[F1] 更新 MoMCP-TUI 管理器 (当前：{self_version})",
                "value": "update_self"
            })
        
        # MoMCP-TUI 相关选项
        if not installed:
            choices.append({
                "name": "[F2] 安装 MoMCP-TUI",
                "value": "install"
            })
        else:
            choices.append({
                "name": "[F2] 启动 MoMCP-TUI",
                "value": "launch"
            })
            choices.append({
                "name": "[F3] 更新 MoMCP-TUI",
                "value": "update"
            })
            choices.append({
                "name": "[F4] 卸载 MoMCP-TUI",
                "value": "uninstall"
            })
        
        choices.append({
            "name": "[F5] 查看帮助",
            "value": "help"
        })
        choices.append({
            "name": "[F6] 高级设置",
            "value": "advanced"
        })
        choices.append({
            "name": "[ESC] 退出",
            "value": "exit"
        })
        
        # 显示菜单
        action = inquirer.select(
            message="请选择操作:",
            choices=choices,
            default=choices[0]
        ).execute()
        
        # 处理选择
        if action == "exit":
            confirm = inquirer.confirm(
                message="确定要退出吗？",
                default=True
            ).execute()
            
            if confirm:
                console.print("\n[yellow]再见！[/]\n")
                break
            continue
        
        elif action == "update_self":
            current_version = manager.get_self_version()
            latest_version = manager.get_self_latest_version()
            
            console.print(f"\n当前版本：[yellow]{current_version}[/]")
            if latest_version != "unknown":
                console.print(f"最新版本：[green]{latest_version}[/]")
            else:
                console.print("[yellow]无法检测最新版本，将尝试升级到最新版[/]")
            
            should_update = True
            if current_version != latest_version and latest_version != "unknown":
                confirm = inquirer.confirm(
                    message="发现新版本，是否更新？",
                    default=True
                ).execute()
                
                if not confirm:
                    should_update = False
            elif latest_version == "unknown":
                confirm = inquirer.confirm(
                    message="是否检查并安装最新版本？",
                    default=True
                ).execute()
                
                if not confirm:
                    should_update = False
            else:
                console.print("\n[cyan]✓ 已是最新版本[/]")
                should_update = False
            
            if should_update:
                if manager.update_self():
                    console.print("\n[green]momcp 更新成功！[/]")
                    console.print("[cyan]请重新启动程序以使用新功能[/]")
                else:
                    console.print("\n[red]更新失败[/]")
        
        elif action == "install":
            if manager.install():
                console.print("\n[green]MoMCP-TUI 安装成功！[/]")
                console.print(f"[cyan]运行 `{manager.entry_command}` 启动程序[/]")
            else:
                console.print("\n[red]安装失败[/]")
        
        elif action == "launch":
            manager.launch()
        
        elif action == "update":
            current_version = manager.get_installed_version()
            latest_version = manager.get_latest_version()
            
            console.print(f"\n当前版本：[yellow]{current_version}[/]")
            if latest_version != "unknown":
                console.print(f"最新版本：[green]{latest_version}[/]")
            else:
                console.print("[yellow]无法检测最新版本，将尝试升级到最新版[/]")
            
            should_update = True
            if current_version != latest_version and latest_version != "unknown":
                confirm = inquirer.confirm(
                    message="发现新版本，是否更新？",
                    default=True
                ).execute()
                
                if not confirm:
                    should_update = False
            elif latest_version == "unknown":
                confirm = inquirer.confirm(
                    message="是否检查并安装最新版本？",
                    default=True
                ).execute()
                
                if not confirm:
                    should_update = False
            else:
                console.print("\n[cyan]✓ 已是最新版本[/]")
                should_update = False
            
            if should_update:
                if manager.update():
                    console.print("\n[green]更新成功！[/]")
                else:
                    console.print("\n[red]更新失败[/]")
        
        elif action == "uninstall":
            confirm = inquirer.confirm(
                message="确定要卸载 MoMCP-TUI 吗？",
                default=False
            ).execute()
            
            if confirm:
                second_confirm = inquirer.confirm(
                    message="此操作不可逆，确认继续？",
                    default=False
                ).execute()
                
                if second_confirm:
                    if manager.uninstall():
                        console.print("\n[green]卸载成功！[/]")
                    else:
                        console.print("\n[red]卸载失败[/]")
                else:
                    console.print("\n[yellow]已取消卸载[/]")
            else:
                console.print("\n[yellow]已取消卸载[/]")
        
        elif action == "help":
            show_help()
        
        elif action == "advanced":
            show_advanced_settings(manager)
        
        elif action == "uninstall":
            confirm = inquirer.confirm(
                message="确定要卸载 MoMCP-TUI 吗？",
                default=False
            ).execute()
            
            if confirm:
                second_confirm = inquirer.confirm(
                    message="此操作不可逆，确认继续？",
                    default=False
                ).execute()
                
                if second_confirm:
                    if manager.uninstall():
                        console.print("\n[green]卸载成功！[/]")
                    else:
                        console.print("\n[red]卸载失败[/]")
                else:
                    console.print("\n[yellow]已取消卸载[/]")
            else:
                console.print("\n[yellow]已取消卸载[/]")


def show_advanced_settings(manager: MoMCPManager):
    """显示高级设置菜单"""
    console.print("\n[bold cyan]=== 高级设置 ===[/]\n")
    
    while True:
        choices = [
            {
                "name": f"1. 设置更新参数 (当前：{manager.custom_update_args or '默认'})",
                "value": "set_update"
            },
            {
                "name": f"2. 设置卸载参数 (当前：{manager.custom_uninstall_args or '默认'})",
                "value": "set_uninstall"
            },
            {
                "name": "3. 重置为默认参数",
                "value": "reset"
            },
            {
                "name": "4. 返回主菜单",
                "value": "back"
            }
        ]
        
        action = inquirer.select(
            message="请选择操作:",
            choices=choices
        ).execute()
        
        if action == "back":
            break
        elif action == "set_update":
            update_args = inquirer.text(
                message="请输入 pip install 更新参数 (例如：--force-reinstall):",
                default=manager.custom_update_args
            ).execute()
            manager.custom_update_args = update_args.strip()
            console.print(f"[green]✓ 更新参数已设置为：{update_args}[/]")
        
        elif action == "set_uninstall":
            uninstall_args = inquirer.text(
                message="请输入 pip uninstall 卸载参数 (例如：--purge):",
                default=manager.custom_uninstall_args
            ).execute()
            manager.custom_uninstall_args = uninstall_args.strip()
            console.print(f"[green]✓ 卸载参数已设置为：{uninstall_args}[/]")
        
        elif action == "reset":
            confirm = inquirer.confirm(
                message="确定要重置所有参数为默认值吗？",
                default=True
            ).execute()
            
            if confirm:
                manager.custom_update_args = ""
                manager.custom_uninstall_args = ""
                console.print("[green]✓ 参数已重置为默认值[/]")


def show_help():
    """显示帮助信息"""
    help_text = """
[bold]MoMCP-TUI 使用说明[/]

[bold]快速命令:[/]
  - 安装：pip install momcp-tui
  - 启动：momcp-tui
  - 更新：pip install --upgrade momcp-tui
  - 卸载：pip uninstall momcp-tui

[bold]功能特性:[/]
  - 多模型对话 - OpenAI、DeepSeek、通义千问、Kimi
  - MCP 工具集成 - 文件操作、代码编辑、联网搜索
  - TUI 界面 - 优雅的终端交互体验

[bold]配置文件:[/]
  - 位置：~/.momcp/config.toml

[bold]常用命令:[/]
  - /model list - 查看可用模型
  - /model set NAME - 切换模型
  - /api_key set KEY - 设置 API Key
  - /allow add PATH - 添加文件白名单
  - /help - 显示帮助文档
"""
    console.print(Panel(help_text, title="帮助文档", border_style="green"))


def main():
    """CLI 入口函数"""
    try:
        # 检查 Python 版本
        if not MoMCPManager().check_python_version():
            console.print("[red]错误：需要 Python 3.10 或更高版本[/]")
            sys.exit(1)
        
        # 显示横幅
        show_banner()
        
        # 创建管理器
        manager = MoMCPManager()
        
        # 显示系统信息
        show_system_info(manager)
        
        # 进入主菜单
        main_menu(manager)
        
    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠ 程序被中断[/]\n")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[red]发生错误：{e}[/]\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
