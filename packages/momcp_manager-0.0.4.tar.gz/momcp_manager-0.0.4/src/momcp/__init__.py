"""MoMCP - MoMCP-TUI 交互式管理工具"""

__version__ = "0.0.4"
__author__ = "AndyJin"
__all__ = ["cli"]
