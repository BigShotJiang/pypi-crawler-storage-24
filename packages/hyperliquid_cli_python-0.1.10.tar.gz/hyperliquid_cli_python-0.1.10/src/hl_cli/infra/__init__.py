"""Infrastructure adapters and persistence."""
