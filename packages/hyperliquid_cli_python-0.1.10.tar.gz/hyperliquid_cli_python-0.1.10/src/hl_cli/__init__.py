"""Hyperliquid CLI source package."""
