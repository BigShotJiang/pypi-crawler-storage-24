# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ObsLocation:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'region_name': 'str',
        'bucket_name': 'str',
        'object_key': 'str',
        'sign_method': 'str',
        'sign': 'str'
    }

    attribute_map = {
        'region_name': 'region_name',
        'bucket_name': 'bucket_name',
        'object_key': 'object_key',
        'sign_method': 'sign_method',
        'sign': 'sign'
    }

    def __init__(self, region_name=None, bucket_name=None, object_key=None, sign_method=None, sign=None):
        r"""ObsLocation

        The model defined in huaweicloud sdk

        :param region_name: **参数说明**：OBS所在区域。您可以从[[地区和终端节点](https://developer.huaweicloud.com/endpoint?OBS)](tag:hws)[[地区和终端节点](https://developer.huaweicloud.com/intl/zh-cn/endpoint?OBS)](tag:hws_hk)中查询服务的终端节点。 **取值范围**：长度不超过256，只允许字母、数字、连接符（-）的组合。
        :type region_name: str
        :param bucket_name: **参数说明**：OBS桶名称。 **取值范围**：长度最小为3，最大为63，只允许小写字母、数字、连接符（-）、英文点（.）的组合。
        :type bucket_name: str
        :param object_key: **参数说明**：OBS对象名称(包含文件夹路径)。 **取值范围**：长度不超过1024。
        :type object_key: str
        :param sign_method: **参数说明**： **取值范围**：只支持SHA256,不携带默认为SHA256。
        :type sign_method: str
        :param sign: **参数说明**：SHA256算法计算出的升级包签名值。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该签名给设备。 **取值范围**：长度为64，只允许大小写字母a到f、数字的组合。
        :type sign: str
        """
        
        

        self._region_name = None
        self._bucket_name = None
        self._object_key = None
        self._sign_method = None
        self._sign = None
        self.discriminator = None

        self.region_name = region_name
        self.bucket_name = bucket_name
        self.object_key = object_key
        if sign_method is not None:
            self.sign_method = sign_method
        if sign is not None:
            self.sign = sign

    @property
    def region_name(self):
        r"""Gets the region_name of this ObsLocation.

        **参数说明**：OBS所在区域。您可以从[[地区和终端节点](https://developer.huaweicloud.com/endpoint?OBS)](tag:hws)[[地区和终端节点](https://developer.huaweicloud.com/intl/zh-cn/endpoint?OBS)](tag:hws_hk)中查询服务的终端节点。 **取值范围**：长度不超过256，只允许字母、数字、连接符（-）的组合。

        :return: The region_name of this ObsLocation.
        :rtype: str
        """
        return self._region_name

    @region_name.setter
    def region_name(self, region_name):
        r"""Sets the region_name of this ObsLocation.

        **参数说明**：OBS所在区域。您可以从[[地区和终端节点](https://developer.huaweicloud.com/endpoint?OBS)](tag:hws)[[地区和终端节点](https://developer.huaweicloud.com/intl/zh-cn/endpoint?OBS)](tag:hws_hk)中查询服务的终端节点。 **取值范围**：长度不超过256，只允许字母、数字、连接符（-）的组合。

        :param region_name: The region_name of this ObsLocation.
        :type region_name: str
        """
        self._region_name = region_name

    @property
    def bucket_name(self):
        r"""Gets the bucket_name of this ObsLocation.

        **参数说明**：OBS桶名称。 **取值范围**：长度最小为3，最大为63，只允许小写字母、数字、连接符（-）、英文点（.）的组合。

        :return: The bucket_name of this ObsLocation.
        :rtype: str
        """
        return self._bucket_name

    @bucket_name.setter
    def bucket_name(self, bucket_name):
        r"""Sets the bucket_name of this ObsLocation.

        **参数说明**：OBS桶名称。 **取值范围**：长度最小为3，最大为63，只允许小写字母、数字、连接符（-）、英文点（.）的组合。

        :param bucket_name: The bucket_name of this ObsLocation.
        :type bucket_name: str
        """
        self._bucket_name = bucket_name

    @property
    def object_key(self):
        r"""Gets the object_key of this ObsLocation.

        **参数说明**：OBS对象名称(包含文件夹路径)。 **取值范围**：长度不超过1024。

        :return: The object_key of this ObsLocation.
        :rtype: str
        """
        return self._object_key

    @object_key.setter
    def object_key(self, object_key):
        r"""Sets the object_key of this ObsLocation.

        **参数说明**：OBS对象名称(包含文件夹路径)。 **取值范围**：长度不超过1024。

        :param object_key: The object_key of this ObsLocation.
        :type object_key: str
        """
        self._object_key = object_key

    @property
    def sign_method(self):
        r"""Gets the sign_method of this ObsLocation.

        **参数说明**： **取值范围**：只支持SHA256,不携带默认为SHA256。

        :return: The sign_method of this ObsLocation.
        :rtype: str
        """
        return self._sign_method

    @sign_method.setter
    def sign_method(self, sign_method):
        r"""Sets the sign_method of this ObsLocation.

        **参数说明**： **取值范围**：只支持SHA256,不携带默认为SHA256。

        :param sign_method: The sign_method of this ObsLocation.
        :type sign_method: str
        """
        self._sign_method = sign_method

    @property
    def sign(self):
        r"""Gets the sign of this ObsLocation.

        **参数说明**：SHA256算法计算出的升级包签名值。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该签名给设备。 **取值范围**：长度为64，只允许大小写字母a到f、数字的组合。

        :return: The sign of this ObsLocation.
        :rtype: str
        """
        return self._sign

    @sign.setter
    def sign(self, sign):
        r"""Sets the sign of this ObsLocation.

        **参数说明**：SHA256算法计算出的升级包签名值。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该签名给设备。 **取值范围**：长度为64，只允许大小写字母a到f、数字的组合。

        :param sign: The sign of this ObsLocation.
        :type sign: str
        """
        self._sign = sign

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ObsLocation):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
