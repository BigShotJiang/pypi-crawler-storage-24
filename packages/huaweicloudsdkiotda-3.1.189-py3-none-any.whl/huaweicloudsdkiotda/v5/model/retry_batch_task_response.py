# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RetryBatchTaskResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'targets': 'list[BatchTargetResult]'
    }

    attribute_map = {
        'targets': 'targets'
    }

    def __init__(self, targets=None):
        r"""RetryBatchTaskResponse

        The model defined in huaweicloud sdk

        :param targets: 批量操作目标结果集合
        :type targets: list[:class:`huaweicloudsdkiotda.v5.BatchTargetResult`]
        """
        
        super().__init__()

        self._targets = None
        self.discriminator = None

        if targets is not None:
            self.targets = targets

    @property
    def targets(self):
        r"""Gets the targets of this RetryBatchTaskResponse.

        批量操作目标结果集合

        :return: The targets of this RetryBatchTaskResponse.
        :rtype: list[:class:`huaweicloudsdkiotda.v5.BatchTargetResult`]
        """
        return self._targets

    @targets.setter
    def targets(self, targets):
        r"""Sets the targets of this RetryBatchTaskResponse.

        批量操作目标结果集合

        :param targets: The targets of this RetryBatchTaskResponse.
        :type targets: list[:class:`huaweicloudsdkiotda.v5.BatchTargetResult`]
        """
        self._targets = targets

    def to_dict(self):
        import warnings
        warnings.warn("RetryBatchTaskResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RetryBatchTaskResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
