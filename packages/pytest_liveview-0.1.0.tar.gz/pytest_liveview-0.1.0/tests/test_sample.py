"""Sample tests for pytest-liveview demo."""

import time

import pytest


def test_pass():
    """A simple passing test."""
    assert 1 + 1 == 2


def test_fail():
    """A failing test."""
    assert 1 + 1 == 3


@pytest.mark.skip(reason="Demonstration skip")
def test_skip():
    """A skipped test."""
    assert True


def test_with_output():
    """A test that prints output."""
    print("Hello from test")
    print("More output")
    assert True


def test_fail_with_output():
    """A failing test with output."""
    print("Debug info before fail")
    assert False, "Expected failure"


def test_quick_pass():
    """Fast passing test."""
    assert True


@pytest.mark.parametrize("a", [1, 2, 3])
def test_long_running_success(a):
    """Simulates a slow integration test."""
    print(f"Starting long operation {a}...")
    for i in range(3):
        time.sleep(20)
        print(f"  Progress {a}: {i + 1}/3")
    print(f"Completed successfully {a}")
    assert True


def test_long_running_failure():
    """Slow test that eventually fails."""
    print("Processing data...")
    time.sleep(0.5)
    print("Validating results...")
    time.sleep(0.3)
    assert False, "Validation failed after processing"


@pytest.mark.parametrize("a,b,expected", [(1, 2, 3), (5, 5, 10), (-1, 1, 0)])
def test_addition(a, b, expected):
    """Parametrized addition tests."""
    assert a + b == expected


@pytest.mark.parametrize("value", [1, 2, 3, 4, 5])
def test_parametrized_output(value):
    """Parametrized test with output."""
    print(f"Testing value: {value}")
    time.sleep(0.1)
    assert value > 0
