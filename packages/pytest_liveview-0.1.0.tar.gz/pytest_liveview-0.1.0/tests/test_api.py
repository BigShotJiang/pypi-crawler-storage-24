"""API endpoint tests."""

import time

import pytest


def test_health_check():
    """Test health endpoint."""
    print("GET /health")
    time.sleep(0.1)
    assert True


def test_get_users():
    """Test users list endpoint."""
    print("GET /api/users")
    time.sleep(0.2)
    assert True


def test_create_user():
    """Test user creation."""
    print("POST /api/users")
    time.sleep(0.35)
    assert True


def test_create_user_duplicate_email():
    """Test duplicate email rejection."""
    print("POST /api/users")
    time.sleep(0.1)
    assert False, "Email already exists"


def test_rate_limiting():
    """Test rate limit handling."""
    print("Making requests...")
    for i in range(3):
        time.sleep(0.1)
        print(f"  Request {i + 1}")
    assert True
