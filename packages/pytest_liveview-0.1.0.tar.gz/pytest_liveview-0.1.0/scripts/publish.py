#!/usr/bin/env python3
"""Build and publish pytest-liveview to PyPI.

Usage:
    python scripts/publish.py           # Publish to PyPI
    python scripts/publish.py --test   # Publish to TestPyPI
    python scripts/publish.py --build  # Build only (no upload)

Requires: pip install build twine
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Publish pytest-liveview to PyPI")
    parser.add_argument(
        "--test",
        action="store_true",
        help="Upload to TestPyPI instead of PyPI",
    )
    parser.add_argument(
        "--build",
        action="store_true",
        help="Build only, do not upload",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    dist = root / "dist"

    # Clean dist
    if dist.exists():
        shutil.rmtree(dist)
    dist.mkdir(parents=True)

    # Check build/twine
    if shutil.which("python") is None:
        print("Error: python not found", file=sys.stderr)
        return 1

    # Build
    print("Building package...")
    result = subprocess.run(
        [sys.executable, "-m", "build"],
        cwd=root,
    )
    if result.returncode != 0:
        print("Build failed. Install with: pip install build", file=sys.stderr)
        return 1

    if args.build:
        print("Build complete. Artifacts in dist/")
        return 0

    # Upload
    repo = "testpypi" if args.test else "pypi"
    print(f"Uploading to {repo}...")
    cmd = [sys.executable, "-m", "twine", "upload", "dist/*"]
    if args.test:
        cmd.extend(["--repository", "testpypi"])
    result = subprocess.run(cmd, cwd=root)
    if result.returncode != 0:
        print("Upload failed. Install with: pip install twine", file=sys.stderr)
        return 1

    print("Done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
