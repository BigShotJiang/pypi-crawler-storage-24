# pytest-liveview

A pytest plugin that shows a **real-time test dashboard** in a local web server. Watch your tests run live as they execute.

## Features

- **Real-time updates** via Server-Sent Events
- **Summary counts**: running, passed, failed, skipped
- **Expandable test suites** with per-suite counts
- **Expandable tests** with captured output (stdout, stderr, tracebacks)
- **Text filter** by test/suite name (flexible, space-separated)
- **Status filter**: all, running, passed, failed, skipped, pending
- **Configurable port** (default 8085, tries next if busy)
- **Optional browser launch** via `--liveview-open` flag

## Installation

```bash
pip install pytest-liveview
```

## Usage

Run pytest with the `--liveview` flag:

```bash
pytest --liveview
```

The dashboard URL is printed to stderr and shown in the pytest header, e.g.:

```
liveview: http://127.0.0.1:8085
```

To open the browser automatically:

```bash
pytest --liveview --liveview-open
```

### Options

| Option | Description |
|--------|-------------|
| `--liveview` | Enable the liveview dashboard |
| `--liveview-port PORT` | Use a specific port (default: 8085) |
| `--liveview-open` | Open browser automatically |

## Troubleshooting

- **No output in expanded tests**: Don't use `-s` (which disables capture). Output is captured by default.
- **Dashboard not updating / stats stuck on "running"**: This happens with **pytest-xdist** (`-n 2` or parallel mode). Workers run in separate processes, so updates never reach the dashboard. The plugin auto-disables parallel execution when liveview is enabled. If you use `addopts = -n 2` in config, run without it: `pytest --liveview` (the plugin overrides it).

## License

MIT
