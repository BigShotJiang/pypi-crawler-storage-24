"""Shared state for test results - used by plugin and server."""

import threading
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TestInfo:
    """Info for a single test."""
    nodeid: str
    file: str
    lineno: int | None
    name: str
    suite: str  # e.g. "tests/test_foo.py"
    status: str = "pending"  # pending, running, passed, failed, skipped, xpassed, xfailed, error
    output: str = ""
    duration: float = 0.0


@dataclass
class SuiteInfo:
    """Info for a test suite (file)."""
    name: str
    tests: dict[str, TestInfo] = field(default_factory=dict)
    
    @property
    def running(self) -> int:
        return sum(1 for t in self.tests.values() if t.status == "running")
    
    @property
    def passed(self) -> int:
        return sum(1 for t in self.tests.values() if t.status == "passed")
    
    @property
    def failed(self) -> int:
        return sum(1 for t in self.tests.values() if t.status in ("failed", "error", "xpassed"))
    
    @property
    def skipped(self) -> int:
        return sum(1 for t in self.tests.values() if t.status in ("skipped", "xfailed"))
    
    @property
    def complete(self) -> int:
        return self.passed + self.failed + self.skipped


class TestState:
    """Thread-safe state for all test data."""
    
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.suites: dict[str, SuiteInfo] = {}
        self._sse_listeners: list[Any] = []
    
    def add_sse_listener(self, listener: Any) -> None:
        with self._lock:
            self._sse_listeners.append(listener)
    
    def remove_sse_listener(self, listener: Any) -> None:
        with self._lock:
            if listener in self._sse_listeners:
                self._sse_listeners.remove(listener)
    
    def _notify_listeners(self, event: str, data: dict) -> None:
        import json
        # Use default "message" event so EventSource onmessage fires
        msg = f"data: {json.dumps(data)}\n\n"
        with self._lock:
            dead = []
            for listener in self._sse_listeners:
                try:
                    listener(msg)
                except Exception:
                    dead.append(listener)
            for d in dead:
                self._sse_listeners.remove(d)
    
    def add_test(self, nodeid: str, file: str, lineno: int | None, name: str) -> None:
        """Add a test (from collection)."""
        suite_name = file or "unknown"
        with self._lock:
            if suite_name not in self.suites:
                self.suites[suite_name] = SuiteInfo(name=suite_name)
            suite = self.suites[suite_name]
            if nodeid not in suite.tests:
                suite.tests[nodeid] = TestInfo(
                    nodeid=nodeid, file=file, lineno=lineno, name=name, suite=suite_name
                )
        self._notify_listeners("update", self.to_dict())
    
    def set_test_running(self, nodeid: str) -> None:
        """Mark test as running."""
        with self._lock:
            for suite in self.suites.values():
                if nodeid in suite.tests:
                    suite.tests[nodeid].status = "running"
                    break
        self._notify_listeners("update", self.to_dict())
    
    def set_test_result(
        self,
        nodeid: str,
        status: str,
        output: str = "",
        duration: float = 0.0,
    ) -> None:
        """Update test result."""
        with self._lock:
            for suite in self.suites.values():
                if nodeid in suite.tests:
                    t = suite.tests[nodeid]
                    t.status = status
                    t.output = output
                    t.duration = duration
                    break
        self._notify_listeners("update", self.to_dict())
    
    def update_test_output(self, nodeid: str, output: str) -> None:
        """Update only the output field (for real-time streaming). Does not change status."""
        with self._lock:
            for suite in self.suites.values():
                if nodeid in suite.tests:
                    suite.tests[nodeid].output = output
                    break
        self._notify_listeners("update", self.to_dict())
    
    def to_dict(self) -> dict:
        """Export state as JSON-serializable dict."""
        with self._lock:
            return {
                "suites": {
                    name: {
                        "name": s.name,
                        "running": s.running,
                        "passed": s.passed,
                        "failed": s.failed,
                        "skipped": s.skipped,
                        "complete": s.complete,
                        "total": len(s.tests),
                        "tests": {
                            nid: {
                                "nodeid": t.nodeid,
                                "name": t.name,
                                "suite": t.suite,
                                "status": t.status,
                                "output": t.output,
                                "duration": t.duration,
                            }
                            for nid, t in s.tests.items()
                        },
                    }
                    for name, s in self.suites.items()
                },
                "summary": {
                    "running": sum(s.running for s in self.suites.values()),
                    "passed": sum(s.passed for s in self.suites.values()),
                    "failed": sum(s.failed for s in self.suites.values()),
                    "skipped": sum(s.skipped for s in self.suites.values()),
                    "complete": sum(s.complete for s in self.suites.values()),
                    "total": sum(len(s.tests) for s in self.suites.values()),
                },
            }


# Global state instance
_state: TestState | None = None


def get_state() -> TestState:
    global _state
    if _state is None:
        _state = TestState()
    return _state


def reset_state() -> None:
    global _state
    _state = TestState()
