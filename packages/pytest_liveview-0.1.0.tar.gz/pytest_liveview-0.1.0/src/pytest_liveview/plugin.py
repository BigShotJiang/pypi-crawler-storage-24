"""Pytest plugin for liveview dashboard."""

import os
import sys
import time
import urllib.request
import urllib.error

import pytest

from .server import start_server, stop_server
from .state import get_state, reset_state

# Env var for workers to find the liveview server URL (set by master)
_LIVEVIEW_URL_ENV = "PYTEST_LIVEVIEW_URL"

# Config when liveview is enabled (set in pytest_configure)
_liveview_config: pytest.Config | None = None
_liveview_url: str | None = None
_test_outputs: dict[str, str] = {}
_test_durations: dict[str, float] = {}
_test_outcomes: dict[str, str] = {}

_OUTCOME_PRIORITY = {"error": 4, "failed": 3, "xpassed": 2, "skipped": 1, "xfailed": 1, "passed": 0}


def _get_report_output(report) -> str:
    """Extract output from TestReport (stdout, stderr, longrepr, sections)."""
    parts = []
    # Sections are the canonical source (Captured stdout call, Captured stderr call, etc.)
    try:
        if hasattr(report, "sections"):
            for header, content in report.sections:
                if content and content.strip():
                    parts.append(f"=== {header} ===\n{content.strip()}")
    except Exception:
        pass
    # Fallback to capstdout/capstderr if sections were empty
    if not parts:
        try:
            if hasattr(report, "capstdout") and report.capstdout:
                parts.append("=== Captured stdout ===\n" + report.capstdout)
        except Exception:
            pass
        try:
            if hasattr(report, "capstderr") and report.capstderr:
                parts.append("=== Captured stderr ===\n" + report.capstderr)
        except Exception:
            pass
    try:
        if hasattr(report, "longreprtext") and report.longreprtext:
            parts.append("=== failure/error ===\n" + report.longreprtext)
    except Exception:
        pass
    return "\n".join(parts)


def _is_xdist_worker() -> bool:
    """True if running in a pytest-xdist worker process."""
    return bool(os.environ.get("PYTEST_XDIST_WORKER"))


def _get_liveview_url() -> str | None:
    """Get liveview server URL (from env for workers, from global for master)."""
    return os.environ.get(_LIVEVIEW_URL_ENV) or _liveview_url


def _send_worker_update(nodeid: str, output: str | None = None, status: str | None = None) -> None:
    """Send update from worker to master's liveview server via HTTP."""
    url = _get_liveview_url()
    if not url:
        return
    try:
        import json
        data = {"nodeid": nodeid}
        if output is not None:
            data["output"] = output
        if status is not None:
            data["status"] = status
        req = urllib.request.Request(
            f"{url.rstrip('/')}/api/worker-update",
            data=json.dumps(data).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def _map_outcome(outcome: str) -> str:
    """Map pytest outcome to our status."""
    return {
        "passed": "passed",
        "failed": "failed",
        "skipped": "skipped",
        "xfailed": "xfailed",
        "xpassed": "xpassed",
        "error": "error",
    }.get(outcome, outcome)


@pytest.hookimpl
def pytest_addoption(parser) -> None:
    """Register command-line options."""
    parser.addoption(
        "--liveview",
        action="store_true",
        default=False,
        help="Enable liveview dashboard",
    )
    parser.addoption(
        "--liveview-port",
        action="store",
        type=int,
        default=None,
        help="Port for liveview server (default: 8085, then 8086, ...)",
    )
    parser.addoption(
        "--liveview-open",
        action="store_true",
        default=False,
        help="Open browser automatically when liveview starts",
    )


@pytest.hookimpl(trylast=True)
def pytest_configure(config: pytest.Config) -> None:
    """Start server when liveview is enabled."""
    global _liveview_url
    try:
        config.addinivalue_line(
            "markers",
            "liveview: mark for liveview (no effect, for filtering)",
        )
    except Exception:
        pass
    
    if config.getoption("liveview", default=False):
        global _liveview_config
        _liveview_config = config
        reset_state()

        if _is_xdist_worker():
            # Worker: don't start server, URL comes from env (set by master)
            pass
        else:
            # Master: start server and set env so workers can find it
            port = config.getoption("liveview_port", default=None)
            if port is None:
                try:
                    port = int(config.getini("liveview_port", default="8085"))
                except (ValueError, TypeError, AttributeError):
                    port = 8085
            open_browser = config.getoption("liveview_open", default=False)
            if not open_browser:
                try:
                    open_browser = config.getini("liveview_open", default="false").lower() in ("true", "1", "yes")
                except (AttributeError, Exception):
                    pass
            url = start_server(port=port, open_browser=open_browser)
            if url:
                _liveview_url = url
                os.environ[_LIVEVIEW_URL_ENV] = url
                sys.stderr.write(f"\n  Liveview dashboard: {url}\n")
                sys.stderr.write("  (use --liveview-open to open browser automatically)\n\n")
                sys.stderr.flush()


@pytest.hookimpl
def pytest_report_header(config, start_path=None, startdir=None):
    """Add liveview URL to pytest header so it's always visible."""
    if _liveview_url and config.getoption("liveview", default=False):
        return f"liveview: {_liveview_url}"


@pytest.hookimpl
def pytest_unconfigure(config: pytest.Config) -> None:
    """Stop server when pytest exits."""
    if config.getoption("liveview", default=False):
        stop_server()


def _add_test_from_nodeid(state, nodeid: str) -> None:
    """Add a test to state from nodeid (used when we only have nodeid, e.g. from xdist)."""
    file_path = nodeid.split("::")[0] if "::" in nodeid else nodeid
    name = nodeid.split("::")[-1] if "::" in nodeid else nodeid
    state.add_test(nodeid, file_path, None, name)


@pytest.hookimpl
def pytest_itemcollected(item: pytest.Item) -> None:
    """Add each collected test to state (runs in workers with xdist, master without)."""
    if not item.config.getoption("liveview", default=False):
        return
    state = get_state()
    nodeid = item.nodeid
    file_path = nodeid.split("::")[0] if "::" in nodeid else nodeid
    name = item.name
    lineno = getattr(item, "lineno", None)
    state.add_test(nodeid, file_path, lineno, name)


@pytest.hookimpl(optionalhook=True)
def pytest_xdist_node_collection_finished(node, ids):
    """Populate controller state with collected tests (xdist: controller doesn't run collection)."""
    if _liveview_config is None or not _liveview_config.getoption("liveview", default=False):
        return
    if _is_xdist_worker():
        return  # Only runs in controller
    state = get_state()
    for nodeid in ids:
        _add_test_from_nodeid(state, nodeid)


def _make_live_output_tee(stream, nodeid: str):
    """Create a tee that forwards to stream and pushes updates to liveview state."""
    _buffer: list[str] = []
    _last_notify = [0.0]
    _notify_interval = 0.08  # 80ms - balance between responsiveness and flooding

    def _flush_to_state(force: bool = False):
        now = time.monotonic()
        if not force and now - _last_notify[0] < _notify_interval:
            return
        _last_notify[0] = now
        output = "".join(_buffer)
        if output:
            try:
                if _is_xdist_worker():
                    _send_worker_update(nodeid, output=output)
                else:
                    get_state().update_test_output(nodeid, output)
            except Exception:
                pass

    class LiveTee:
        def write(self, data: str):
            try:
                stream.write(data)
            except Exception:
                pass
            _buffer.append(data)
            _flush_to_state()

        def flush(self):
            try:
                stream.flush()
            except Exception:
                pass
            _flush_to_state(force=True)

        def __getattr__(self, name):
            return getattr(stream, name)

    tee = LiveTee()
    tee._flush_final = lambda: _flush_to_state(force=True)
    return tee


@pytest.hookimpl(hookwrapper=True, trylast=True)
def pytest_runtest_call(item):
    """Wrap the call phase to capture stdout/stderr in real-time.
    Uses trylast to run inside pytest's capture context (after capture plugin).
    """
    if _liveview_config is None or not _liveview_config.getoption("liveview", default=False):
        yield
        return

    nodeid = item.nodeid
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    try:
        sys.stdout = _make_live_output_tee(old_stdout, nodeid)
        sys.stderr = _make_live_output_tee(old_stderr, nodeid)
    except Exception:
        pass

    try:
        yield
    finally:
        try:
            if hasattr(sys.stdout, "_flush_final"):
                sys.stdout._flush_final()
            if hasattr(sys.stderr, "_flush_final"):
                sys.stderr._flush_final()
        except Exception:
            pass
        sys.stdout = old_stdout
        sys.stderr = old_stderr


@pytest.hookimpl
def pytest_runtest_logstart(nodeid: str, location: tuple) -> None:
    """Mark test as running."""
    global _test_outputs, _test_durations, _test_outcomes
    if _liveview_config is None:
        return
    _test_outputs[nodeid] = ""
    _test_durations[nodeid] = 0.0
    _test_outcomes[nodeid] = "passed"
    if _is_xdist_worker():
        _send_worker_update(nodeid, status="running")
    else:
        get_state().set_test_running(nodeid)


@pytest.hookimpl
def pytest_runtest_logreport(report) -> None:
    """Process test report - update status and output."""
    global _test_outputs, _test_durations, _test_outcomes
    if _liveview_config is None:
        return
    if report.when not in ("call", "setup", "teardown"):
        return
    if not _liveview_config.getoption("liveview", default=False):
        return
    
    state = get_state()
    nodeid = report.nodeid
    outcome = _map_outcome(report.outcome)
    output = _get_report_output(report)
    duration = getattr(report, "duration", 0.0) or 0.0
    
    if nodeid not in _test_outputs:
        _test_outputs[nodeid] = ""
    if output:
        _test_outputs[nodeid] = (_test_outputs[nodeid] + "\n" + output).strip()
    _test_durations[nodeid] = _test_durations.get(nodeid, 0) + duration
    
    # Only update to final status (passed/failed/skipped) from the "call" phase.
    # Setup runs before the test body - using setup outcome would mark complete too early.
    # Teardown runs after - we only override if teardown failed.
    if report.when == "call":
        _test_outcomes[nodeid] = outcome
    elif report.when == "teardown" and outcome in ("failed", "error"):
        _test_outcomes[nodeid] = outcome
    elif report.when == "setup" and outcome in ("failed", "error", "skipped"):
        _test_outcomes[nodeid] = outcome  # Setup failed or test skipped in setup
    # For setup+passed: don't update - keep "running" until call completes
    
    final_outcome = _test_outcomes[nodeid]
    if report.when == "setup" and outcome == "passed":
        final_outcome = "running"  # Test body hasn't run yet
    state.set_test_result(
        nodeid,
        final_outcome,
        _test_outputs[nodeid],
        _test_durations[nodeid],
    )


@pytest.hookimpl
def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    """Session finished - ensure final state is sent."""
    if session.config.getoption("liveview", default=False):
        state = get_state()
        state._notify_listeners("done", state.to_dict())
