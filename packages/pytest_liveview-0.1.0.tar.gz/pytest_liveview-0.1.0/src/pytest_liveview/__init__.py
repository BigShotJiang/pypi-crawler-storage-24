"""pytest-liveview: Real-time test dashboard for pytest."""

__version__ = "0.1.0"
