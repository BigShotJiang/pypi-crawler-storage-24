"""HTTP server with SSE for real-time dashboard."""

import json
import queue
import socket
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .state import get_state


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def _find_available_port(start: int = 8085, max_tries: int = 20) -> int | None:
    """Find first available port starting from start."""
    for i in range(max_tries):
        port = start + i
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    return None


def _get_dashboard_html() -> str:
    """Load dashboard HTML from package."""
    p = Path(__file__).parent / "static" / "index.html"
    return p.read_text(encoding="utf-8")


_server: HTTPServer | None = None
_server_thread: threading.Thread | None = None
_server_port: int | None = None


class LiveviewHandler(BaseHTTPRequestHandler):
    """HTTP handler for dashboard and SSE."""
    
    def log_message(self, format: str, *args) -> None:
        pass
    
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path == "/" or path == "/index.html":
            self._serve_dashboard()
        elif path == "/events":
            self._serve_sse()
        elif path == "/api/state":
            self._serve_state()
        else:
            self.send_error(404)
    
    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/worker-update":
            self._handle_worker_update()
        else:
            self.send_error(404)
    
    def _serve_dashboard(self) -> None:
        html = _get_dashboard_html()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode("utf-8"))))
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))
    
    def _handle_worker_update(self) -> None:
        """Receive updates from xdist workers (output, status)."""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length).decode("utf-8")
            data = json.loads(body)
            nodeid = data.get("nodeid")
            if not nodeid:
                self.send_response(400)
                self.end_headers()
                return
            state = get_state()
            if "output" in data:
                state.update_test_output(nodeid, data["output"])
            if "status" in data:
                if data["status"] == "running":
                    state.set_test_running(nodeid)
                else:
                    out = ""
                    with state._lock:
                        for suite in state.suites.values():
                            if nodeid in suite.tests:
                                out = suite.tests[nodeid].output
                                break
                    state.set_test_result(nodeid, data["status"], out)
        except Exception:
            pass
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()
    
    def _serve_state(self) -> None:
        state = get_state().to_dict()
        data = json.dumps(state).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)
    
    def _serve_sse(self) -> None:
        msg_queue: queue.Queue[str | None] = queue.Queue()
        
        def send(msg: str) -> None:
            try:
                self.wfile.write(msg.encode("utf-8"))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
        
        def listener(msg: str) -> None:
            msg_queue.put(msg)
        
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")  # Disable nginx buffering if proxied
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        
        send(f"data: {json.dumps(get_state().to_dict())}\n\n")
        get_state().add_sse_listener(listener)
        try:
            while True:
                try:
                    msg = msg_queue.get(timeout=30)
                    if msg is None:
                        break
                    send(msg)
                except queue.Empty:
                    try:
                        send(": keepalive\n\n")
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
        finally:
            get_state().remove_sse_listener(listener)


def start_server(port: int | None = None, open_browser: bool = False) -> str | None:
    global _server, _server_thread, _server_port
    
    if _server is not None:
        return f"http://127.0.0.1:{_server_port}"
    
    start_port = port if port is not None else 8085
    _server_port = _find_available_port(start_port)
    if _server_port is None:
        return None
    
    _server = ThreadedHTTPServer(("127.0.0.1", _server_port), LiveviewHandler)
    _server_thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _server_thread.start()
    
    url = f"http://127.0.0.1:{_server_port}"
    
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    
    return url


def stop_server() -> None:
    global _server, _server_thread
    if _server is not None:
        _server.shutdown()
        _server = None
    _server_thread = None
