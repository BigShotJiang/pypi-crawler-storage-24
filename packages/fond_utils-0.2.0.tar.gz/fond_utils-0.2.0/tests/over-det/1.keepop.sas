begin_version
3
end_version
begin_metric
0
end_metric
1
begin_variable
var0
-1
2
Atom q()
NegatedAtom q()
end_variable
0
begin_state
1
end_state
begin_goal
1
0 0
end_goal
2
begin_operator
sq_detdup_1 
0
1
0 0 -1 0
1
end_operator
begin_operator
sq_detdup_2 
0
0
1
end_operator
0
