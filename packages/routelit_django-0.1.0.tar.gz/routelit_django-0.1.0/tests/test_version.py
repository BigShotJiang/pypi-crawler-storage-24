from routelit_django import __version__


def test_version():
    assert __version__ is not None
