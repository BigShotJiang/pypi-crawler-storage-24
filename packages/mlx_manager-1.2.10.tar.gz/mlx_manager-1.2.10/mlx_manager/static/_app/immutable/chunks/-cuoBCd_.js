import{b as r,r as o}from"./BZ-ImO5O.js";const t="";function a(...e){return r+t+o(e[0],e[1])}export{a as r};
