# -*- coding: utf-8 -*-
"""
根据配置文件下载测试用例所需数据
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import pandas as pd
import urllib3
from k2magic.k2_dataframe_db import K2DataFrameDB

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_K2ASSETS_CONFIG: Optional[Dict[str, Any]] = None
_OUTPUT_PATH_TEMPLATE: Optional[str] = None

RepoConfig = Dict[str, Any]


_TPL_RE = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")
_WIN_INVALID_PATH_CHARS_RE = re.compile(r'[ <>:"/\\|?*\x00-\x1F]')
_WIN_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
    "COM5",
    "COM6",
    "COM7",
    "COM8",
    "COM9",
    "LPT1",
    "LPT2",
    "LPT3",
    "LPT4",
    "LPT5",
    "LPT6",
    "LPT7",
    "LPT8",
    "LPT9",
}

# 将repo_config里的 {{xxx}} 替换为 case_row[xxx]
def _apply_template(value: Any, case_row: pd.Series) -> Any:
    if isinstance(value, str):
        def _replace(m: re.Match[str]) -> str:
            key = m.group(1).strip()
            if key not in case_row:
                raise KeyError(f"case_config.csv missing column: {key}")
            return str(case_row[key])

        return _TPL_RE.sub(_replace, value)
    return value


def _parse_date_str(change_date_value: Any) -> datetime:
    s = str(change_date_value).strip()
    # 常见输入格式：仅日期 / 日期时间（含空格或T分隔）
    candidates = (
        "%Y%m%d",
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%Y.%m.%d",
        "%Y%m%d %H:%M",
        "%Y%m%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y.%m.%d %H:%M",
        "%Y.%m.%d %H:%M:%S",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%dT%H:%M:%S",
    )
    for fmt in candidates:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    # 兼容 ISO 格式的时区/毫秒，如 2026-03-01T10:30:00.123+08:00
    try:
        return datetime.fromisoformat(s)
    except ValueError as e:
        raise ValueError(f"无法解析 change_date: {change_date_value}") from e


def _sanitize_path_component(part: str) -> str:
    sanitized = _WIN_INVALID_PATH_CHARS_RE.sub("_", part).rstrip(" .")
    if not sanitized:
        return "_"
    if sanitized.upper() in _WIN_RESERVED_NAMES:
        return f"{sanitized}_"
    return sanitized


def _sanitize_output_path(path_value: str) -> str:
    p = Path(path_value)
    anchor = p.anchor
    parts: List[str] = []
    for part in p.parts:
        if part == anchor:
            continue
        parts.append(_sanitize_path_component(part))

    if anchor:
        out = Path(anchor)
        for part in parts:
            out = out / part
        return str(out)
    if not parts:
        return "_"
    return str(Path(*parts))



def _normalize_repo_time_str(value: Any, is_end: bool) -> str:
    raw = str(value).strip()
    dt = _parse_date_str(raw)
    # 仅给“日期”补全天起止；如果输入里已包含时间则保持原样
    has_time = bool(re.search(r"[T\s]\d{1,2}:\d{2}", raw))
    if not has_time:
        if is_end:
            dt = dt.replace(hour=23, minute=59, second=59)
        else:
            dt = dt.replace(hour=0, minute=0, second=0)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _resolve_repo_time_expr(value: Any, is_end: bool) -> str:
    raw = str(value).strip()
    # 先尝试整体解析为时间；若失败再按表达式处理，避免把日期中的 '-' 误判为运算符
    try:
        return _normalize_repo_time_str(raw, is_end=is_end)
    except Exception:
        pass
    # 支持 A+B / A-B，A 为绝对时间，B 为 pandas Timedelta 可解析字符串（如 2D、2H）
    # 按最后一个 + / - 切分（如 2023-04-01+1D）
    plus_idx = raw.rfind("+")
    minus_idx = raw.rfind("-")
    split_idx = max(plus_idx, minus_idx)
    if split_idx <= 0:
        raise ValueError(f"无法解析时间表达式: {value}")
    op = raw[split_idx]
    base_part = raw[:split_idx].strip()
    delta_part = raw[split_idx + 1 :].strip()
    if not delta_part or not re.match(r"^[0-9].*$", delta_part):
        raise ValueError(f"无法解析时间表达式: {value}")

    if not base_part:
        raise ValueError(f"时间表达式缺少基准时间: {value}")
    try:
        base_dt = datetime.strptime(
            _normalize_repo_time_str(base_part, is_end=is_end), "%Y-%m-%d %H:%M:%S"
        )
        delta = pd.Timedelta(delta_part)
    except Exception as e:
        raise ValueError(f"无法解析时间表达式: {value}") from e

    result = base_dt + delta if op == "+" else base_dt - delta
    return result.strftime("%Y-%m-%d %H:%M:%S")


def _save_csv_to_zip(
    df: Optional[pd.DataFrame], output_file: Path, columns=None, compress: bool = True
) -> None:
    output_file = Path(output_file)
    if compress:
        out_s = str(output_file)
        if not out_s.endswith(".csv.zip"):
            output_file = output_file.with_suffix(".csv.zip")
            out_s = str(output_file)
        temp_csv = Path(out_s[:-4]) if out_s.endswith(".zip") else output_file.with_suffix(".csv")
        try:
            if df is not None and not df.empty:
                df.to_csv(temp_csv, index=False, encoding="utf-8-sig")
            else:
                pd.DataFrame(columns=columns if columns else []).to_csv(
                    temp_csv, index=False, encoding="utf-8-sig"
                )
            with zipfile.ZipFile(output_file, "w", zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(temp_csv, temp_csv.name)
            temp_csv.unlink(missing_ok=True)
        except Exception:
            if temp_csv.exists():
                try:
                    temp_csv.unlink()
                except OSError:
                    pass
            raise
    else:
        output_file = output_file.with_suffix(".csv") if output_file.suffix != ".csv" else output_file
        if df is not None and not df.empty:
            df.to_csv(output_file, index=False, encoding="utf-8-sig")
        else:
            pd.DataFrame(columns=columns if columns else []).to_csv(
                output_file, index=False, encoding="utf-8-sig"
            )


def _convert_k_device_to_str(df: Optional[pd.DataFrame]) -> Optional[pd.DataFrame]:
    if df is None or df.empty or "k_device" not in df.columns:
        return df
    col = df["k_device"]
    if pd.api.types.is_string_dtype(col):
        return df

    if pd.api.types.is_float_dtype(col):
        df = df.copy()
        numeric_col = pd.to_numeric(col, errors="coerce")
        df["k_device"] = numeric_col.apply(
            lambda x: str(int(x)) if pd.notna(x) else pd.NA
        ).astype("string")
    return df


def _build_connection_string(repo_name: str) -> str:
    cfg = _K2ASSETS_CONFIG
    if cfg is None:
        raise RuntimeError("未加载 k2assets 配置，请检查 repo_config.json")
    s = f"k2assets+repo://{cfg['username']}:{cfg['password_md5']}@{cfg['host']}"
    if cfg.get("port"):
        s += f":{cfg['port']}"
    s += f"/{repo_name}"
    if cfg.get("tenant"):
        s += f"?tenant={cfg['tenant']}"
    return s


def _split_time_range_by_month(start_time_str: str, end_time_str: str):
    start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S")
    end_time = datetime.strptime(end_time_str, "%Y-%m-%d %H:%M:%S")
    ranges = []
    cur = start_time
    while cur < end_time:
        if cur.month == 12:
            nxt = cur.replace(year=cur.year + 1, month=1, day=1)
        else:
            nxt = cur.replace(month=cur.month + 1, day=1)
        seg_end = nxt.replace(hour=0, minute=0, second=0) - timedelta(seconds=1)
        if seg_end > end_time:
            seg_end = end_time
        ranges.append(
            (cur.strftime("%Y-%m-%d %H:%M:%S"), seg_end.strftime("%Y-%m-%d %H:%M:%S"))
        )
        cur = seg_end + timedelta(seconds=1)
    return ranges


def _apply_keep_latest(df: Optional[pd.DataFrame], keep_latest_rows: Optional[int]):
    if df is None or df.empty or keep_latest_rows is None or keep_latest_rows <= 0:
        return df
    if "k_ts" not in df.columns:
        print("警告: 未找到 k_ts 列，跳过 keep_latest_rows")
        return df
    return (
        df.sort_values("k_ts", ascending=False)
        .head(keep_latest_rows)
        .sort_values("k_ts", ascending=True)
    )


def download_repo_data(
    repo_name: str,
    devices: List[str],
    start_time: str,
    end_time: str,
    columns: List[str],
    output_file: Path,
    value_filter: Optional[str] = None,
    keep_latest_rows: Optional[int] = None,
    compress: bool = True,
    overwrite: bool = False,
) -> None:
    print(f"正在下载 {repo_name}...")
    print(f"设备: {devices}  时间: {start_time} ~ {end_time}  列: {columns}")
    if output_file.exists() and not overwrite:
        print(f"文件已存在，跳过: {output_file}")
        return
    conn_str = _build_connection_string(repo_name)
    db = K2DataFrameDB(conn_str, rest=True)
    start_dt = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
    end_dt = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
    days_diff = (end_dt - start_dt).days

    def _fetch(st: str, et: str) -> Optional[pd.DataFrame]:
        return db.get_repo_data(
            columns=columns,
            start_time=st,
            end_time=et,
            devices=devices,
            desc=False,
            value_filter=value_filter,
        )

    try:
        if days_diff > 30:
            print(f"按月分批下载（{days_diff} 天）…")
            batches = _split_time_range_by_month(start_time, end_time)
            parts: List[pd.DataFrame] = []
            for i, (bs, be) in enumerate(batches, 1):
                print(f"[批次 {i}/{len(batches)}] {bs} ~ {be}")
                try:
                    bdf = _fetch(bs, be)
                    if bdf is not None and not bdf.empty:
                        parts.append(bdf)
                except Exception as e:
                    print(f"批次失败: {e}")
            df = pd.concat(parts, ignore_index=True) if parts else None
            if df is not None and not df.empty:
                n0, n1 = len(df), len(df.drop_duplicates())
                df = df.drop_duplicates()
                if n0 != n1:
                    print(f"合并去重: {n0} -> {n1}")
        else:
            print(f"单次下载（约 {days_diff} 天）…")
            df = _fetch(start_time, end_time)

        if df is not None and not df.empty:
            df = _convert_k_device_to_str(df)
            df = _apply_keep_latest(df, keep_latest_rows)
            _save_csv_to_zip(df, output_file, columns, compress)
            print(f"已保存 {output_file}")
        else:
            print(f"无数据，写空文件 {output_file}")
            _save_csv_to_zip(None, output_file, columns, compress)
    except Exception as e:
        print(f"下载失败: {e}")
        try:
            _save_csv_to_zip(None, output_file, columns, compress)
        except Exception:
            pass
        raise


def download_one_case(
    case_row: pd.Series,
    output_root: Path,
    repo_configs: Sequence[RepoConfig],
    compress: bool = True,
    overwrite: bool = False,
) -> None:
    output_tpl = _OUTPUT_PATH_TEMPLATE
    if not output_tpl:
        raise RuntimeError("repo_config.json 中缺少 output_path 配置")
    out_path_cfg = _apply_template(output_tpl, case_row)
    if not isinstance(out_path_cfg, str) or not out_path_cfg.strip():
        raise RuntimeError("repo_config.json 中 output_path 渲染结果为空")
    sanitized_out_path = _sanitize_output_path(out_path_cfg)
    if sanitized_out_path != out_path_cfg:
        print(f"output_path 包含非法字符，已自动清洗: {out_path_cfg} -> {sanitized_out_path}")
    out_dir = Path(sanitized_out_path)
    if not out_dir.is_absolute():
        out_dir = output_root / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    for cfg in repo_configs:
        repo_name = str(_apply_template(cfg["repo_name"], case_row))
        if cfg.get("start_date") is None:
            raise RuntimeError(f"repo_config.json 配置缺失：{repo_name} / start_date")
        if cfg.get("end_date") is None:
            raise RuntimeError(f"repo_config.json 配置缺失：{repo_name} / end_date")
        st = _resolve_repo_time_expr(_apply_template(cfg["start_date"], case_row), is_end=False)
        et = _resolve_repo_time_expr(_apply_template(cfg["end_date"], case_row), is_end=True)
        cols_cfg = cfg["columns"]
        if not isinstance(cols_cfg, list):
            raise RuntimeError(f"repo_config.json 配置错误：{repo_name} / columns 必须是数组")
        columns: List[str] = [str(_apply_template(c, case_row)) for c in cols_cfg]
        devices_cfg = cfg.get("devices")
        if not isinstance(devices_cfg, list) or not devices_cfg:
            raise RuntimeError(f"repo_config.json 配置错误：{repo_name} / devices 必须是非空数组")
        devices = [str(_apply_template(d, case_row)) for d in devices_cfg]
        vf_cfg = _apply_template(cfg.get("value_filter"), case_row)
        kl = _apply_template(cfg.get("keep_latest_rows"), case_row)
        dest = (
            out_dir / f"{repo_name}.csv.zip"
            if compress
            else out_dir / f"{repo_name}.csv"
        )
        try:
            download_repo_data(
                repo_name, devices, st, et, columns, dest,
                value_filter=vf_cfg, keep_latest_rows=kl, compress=compress, overwrite=overwrite,
            )
        except Exception as e:
            print(f"{repo_name}: {e}")
    print(f"完成 {out_dir.name}")


def download_cases_dataframe(
    df_cases: pd.DataFrame,
    output_root: Path,
    repo_configs: Sequence[RepoConfig],
    compress: bool = True,
    overwrite: bool = False,
) -> None:
    output_root.mkdir(parents=True, exist_ok=True)
    for _, row in df_cases.iterrows():
        download_one_case(row, output_root, repo_configs, compress=compress, overwrite=overwrite)


def _load_repo_configs(path: Path) -> list[RepoConfig]:
    global _K2ASSETS_CONFIG, _OUTPUT_PATH_TEMPLATE
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except OSError as e:
        raise RuntimeError(f"读取 repo 配置失败: {path}: {e}") from e
    except json.JSONDecodeError as e:
        raise RuntimeError(f"repo 配置 JSON 非法: {path}: {e}") from e
    if not isinstance(raw, dict):
        raise RuntimeError(f"repo 配置必须是对象: {path}")
    output_path = raw.get("output_path")
    if not isinstance(output_path, str) or not output_path.strip():
        raise RuntimeError(f"repo 配置中的 output_path 必须是非空字符串: {path}")
    k2assets_cfg = raw.get("k2assets")
    if not isinstance(k2assets_cfg, dict):
        raise RuntimeError(f"repo 配置中的 k2assets 必须是对象: {path}")
    repos = k2assets_cfg.get("repos")
    if not isinstance(repos, list):
        raise RuntimeError(f"repo 配置中的 k2assets.repos 必须是数组: {path}")
    required = ("username", "password_md5", "host")
    missing = [k for k in required if not k2assets_cfg.get(k)]
    if missing:
        raise RuntimeError(f"repo 配置中的 k2assets 缺少字段: {', '.join(missing)}")
    _K2ASSETS_CONFIG = {
        "username": k2assets_cfg["username"],
        "password_md5": k2assets_cfg["password_md5"],
        "host": k2assets_cfg["host"],
        "port": k2assets_cfg.get("port"),
        "tenant": k2assets_cfg.get("tenant"),
    }
    _OUTPUT_PATH_TEMPLATE = output_path
    return repos


def main(argv: Optional[Sequence[str]] = None) -> int:
    def _to_bool(v: str) -> bool:
        s = str(v).strip().lower()
        if s in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "f", "no", "n", "off"}:
            return False
        raise argparse.ArgumentTypeError(f"无效布尔值: {v}")

    p = argparse.ArgumentParser(
        description="按目录读取 repo_config.json + case_config.csv 并下载测试数据"
    )
    p.add_argument("target_dir", help="配置目录（包含 repo_config.json 和 case_config.csv）")
    p.add_argument(
        "--compress",
        type=_to_bool,
        default=True,
        help="是否压缩下载结果（默认: true，可选: true/false/1/0）",
    )
    p.add_argument(
        "--overwrite",
        type=_to_bool,
        default=False,
        help="是否覆盖已存在的同名文件（默认: false，可选: true/false/1/0）",
    )
    args = p.parse_args(argv)

    root = Path(args.target_dir).expanduser().resolve()
    repo_cfg_path = root / "repo_config.json"
    case_cfg_path = root / "case_config.csv"

    if not root.exists() or not root.is_dir():
        raise RuntimeError(f"错误: 目录不存在: {root}")
    if not repo_cfg_path.exists():
        print(f"错误: 找不到 {repo_cfg_path}", file=sys.stderr)
        raise RuntimeError(f"错误: 找不到 {repo_cfg_path}")
    if not case_cfg_path.exists():
        raise RuntimeError(f"错误: 找不到 {case_cfg_path}")

    try:
        repo_configs = _load_repo_configs(repo_cfg_path)
    except RuntimeError as e:
        raise RuntimeError(f"错误: {e}")

    try:
        df_cases = pd.read_csv(case_cfg_path, encoding="utf-8-sig")
    except OSError as e:
        raise RuntimeError(f"错误: 读取用例失败: {case_cfg_path}: {e}")

    try:
        download_cases_dataframe(
            df_cases,
            root,
            repo_configs,
            compress=args.compress,
            overwrite=args.overwrite,
        )
    except Exception as e:
        raise RuntimeError(f"错误: 下载失败: {e}")


if __name__ == "__main__":
    main()