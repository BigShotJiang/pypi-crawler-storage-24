from langchain.schema import Document


def load_from_text_list(texts):

    docs = []

    for t in texts:

        docs.append(Document(page_content=t))

    return docs