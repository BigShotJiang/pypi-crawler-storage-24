import os
import hashlib
import pickle
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from .config import DEFAULT_CONFIG

def get_file_hash(file_path):
    with open(file_path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def load_binary(path):
    if os.path.exists(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    return {}

def save_binary(path, data):
    with open(path, "wb") as f:
        pickle.dump(data, f)

def sync_vector_db(documents_path, index_path, embedding_model=DEFAULT_CONFIG["embedding_model"], chunk_size=DEFAULT_CONFIG["chunk_size"], chunk_overlap=DEFAULT_CONFIG["chunk_overlap"]):
    """
    Update FAISS DB handling new, updated, and deleted documents.
    Uses 'documents.bin' to keep all chunks in memory for rebuilding.
    """
    os.makedirs(index_path, exist_ok=True)

    metadata_file = os.path.join(index_path, "metadata.bin")
    cache_file = os.path.join(index_path, "qa_cache.bin")
    docs_file = os.path.join(index_path, "documents.bin")

    metadata = load_binary(metadata_file)
    qa_cache = load_binary(cache_file)
    all_docs = load_binary(docs_file)  # all existing chunks

    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    embeddings = HuggingFaceEmbeddings(model_name=embedding_model)

    current_files = {f for f in os.listdir(documents_path) if f.lower().endswith(".pdf")}
    rebuild_needed = False

    # -------------------
    # Deleted files
    # -------------------
    removed_files = [f for f in metadata if f not in current_files]
    if removed_files:
        rebuild_needed = True
        all_docs = [d for d in all_docs if d.metadata["source"] not in removed_files]
        # Remove related cache entries
        keys_to_delete = [k for k, v in qa_cache.items() if any(src in removed_files for src in v["sources"])]
        for k in keys_to_delete:
            del qa_cache[k]
        for f in removed_files:
            del metadata[f]
            print(f"[INFO] Document removed: {f}")

    # -------------------
    # Updated / new files
    # -------------------
    updated_files = []
    for f in current_files:
        file_path = os.path.join(documents_path, f)
        new_hash = get_file_hash(file_path)
        if metadata.get(f) != new_hash:
            updated_files.append(f)
            rebuild_needed = True
            metadata[f] = new_hash
            print(f"[INFO] Document updated: {f}")

    # Remove old chunks of updated files
    all_docs = [d for d in all_docs if d.metadata["source"] not in updated_files]

    # Add new chunks
    for f in updated_files:
        file_path = os.path.join(documents_path, f)
        loader = PyPDFLoader(file_path)
        docs = loader.load()
        for d in docs:
            d.metadata["source"] = f
        chunks = splitter.split_documents(docs)
        all_docs.extend(chunks)

    # -------------------
    # Rebuild FAISS if needed
    # -------------------
    if rebuild_needed:
        if all_docs:
            vectordb = FAISS.from_documents(all_docs, embeddings)
            vectordb.save_local(index_path)
            save_binary(docs_file, all_docs)
            save_binary(metadata_file, metadata)
            save_binary(cache_file, qa_cache)
            print("[INFO] Vector DB rebuilt successfully")
        else:
            print("[INFO] No documents left, vector DB cleared")
            for f in ["index.faiss", "index.pkl"]:
                fp = os.path.join(index_path, f)
                if os.path.exists(fp):
                    os.remove(fp)
            save_binary(docs_file, [])
            save_binary(metadata_file, metadata)
            save_binary(cache_file, qa_cache)