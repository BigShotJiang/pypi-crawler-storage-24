# ingestion.py
import os
from langchain_community.document_loaders import PyPDFLoader
from .loader import load_from_text_list

def load_documents(path=None, texts=None):
    """
    Load documents from PDFs or from a list of text strings.

    Args:
        path (str): Folder path containing PDFs.
        texts (List[str]): List of text strings to convert into Documents.

    Returns:
        List[Document]: Loaded documents with metadata.
    """
    documents = []

    if path:
        for file in os.listdir(path):
            if file.endswith(".pdf"):
                file_path = os.path.join(path, file)
                loader = PyPDFLoader(file_path)
                docs = loader.load()
                for d in docs:
                    d.metadata["source"] = file
                documents.extend(docs)

    if texts:
        docs = load_from_text_list(texts)
        documents.extend(docs)

    return documents