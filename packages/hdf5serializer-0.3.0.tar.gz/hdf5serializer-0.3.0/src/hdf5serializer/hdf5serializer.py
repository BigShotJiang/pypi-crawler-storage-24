import h5py
import numpy as np
import importlib
from abc import ABC


class HDF5Serializable(ABC):

    def save_hdf5(self, filename, groupname=None, compression=None):
        with h5py.File(filename, "w") as f:
            grp = f if groupname is None else f.create_group(groupname)
            self._save_to_group(grp, compression=compression)

    @classmethod
    def load_hdf5(cls, filename, groupname=None):
        with h5py.File(filename, "r") as f:
            grp = f if groupname is None else f[groupname]
            return cls._load_from_group(grp)

    @staticmethod
    def load_any(filename, groupname=None):
        with h5py.File(filename, "r") as f:
            grp = f if groupname is None else f[groupname]

            full_classname = grp.attrs["_class"]
            module_name, class_name = full_classname.rsplit(".", 1)

            module = importlib.import_module(module_name)
            cls = getattr(module, class_name)

            return cls._load_from_group(grp)

    # -----------------------
    # SAVE
    # -----------------------

    def _save_to_group(self, group, compression=None):

        group.attrs["_class"] = (
            self.__class__.__module__ + "." + self.__class__.__name__
        )

        for key, value in self.__dict__.items():
            self._save_value(group, key, value, compression)

    def _save_value(self, group, key, value, compression):

        if isinstance(value, np.ndarray):
            group.create_dataset(key, data=value, compression=compression)

        elif isinstance(value, (int, float, str, bool)):
            group.attrs[key] = value

        elif isinstance(value, HDF5Serializable):
            subgrp = group.create_group(key)
            value._save_to_group(subgrp, compression)

        elif isinstance(value, list):
            subgrp = group.create_group(key)
            subgrp.attrs["_type"] = "list"

            for i, item in enumerate(value):
                itemgrp = subgrp.create_group(str(i))
                self._save_list_item(itemgrp, item, compression)

        elif isinstance(value, dict):
            subgrp = group.create_group(key)
            subgrp.attrs["_type"] = "dict"

            for dict_key, item in value.items():
                if not isinstance(dict_key, str):
                    raise TypeError("Only string dict keys are supported")

                itemgrp = subgrp.create_group(dict_key)
                self._save_list_item(itemgrp, item, compression)

        elif value is None:
            subgrp = group.create_group(key)
            subgrp.attrs["_type"] = "none"

        else:
            raise TypeError(f"Unsupported attribute type: {type(value)}")

    def _save_list_item(self, group, item, compression):

        if isinstance(item, HDF5Serializable):
            item._save_to_group(group, compression)

        elif isinstance(item, np.ndarray):
            group.attrs["_type"] = "ndarray"
            group.create_dataset("value", data=item, compression=compression)

        elif isinstance(item, (int, float, str, bool)):
            group.attrs["_type"] = "scalar"
            group.attrs["value"] = item

        elif item is None:
            group.attrs["_type"] = "none"

        else:
            raise TypeError(f"Unsupported container item type: {type(item)}")

    # -----------------------
    # LOAD
    # -----------------------

    @classmethod
    def _load_from_group(cls, group):

        obj = cls.__new__(cls)

        # attributes
        for key, value in group.attrs.items():
            if key != "_class":
                setattr(obj, key, value)

        # datasets / groups
        for key, item in group.items():

            if isinstance(item, h5py.Dataset):
                setattr(obj, key, item[()])

            elif isinstance(item, h5py.Group):

                type_tag = item.attrs.get("_type")

                if type_tag == "none":
                    setattr(obj, key, None)

                elif type_tag == "list":
                    setattr(obj, key, cls._load_list(item))

                elif type_tag == "dict":
                    setattr(obj, key, cls._load_dict(item))

                else:
                    setattr(obj, key, cls._load_dynamic(item))

        return obj

    @classmethod
    def _load_list(cls, group):
        values = []
        for idx in sorted(group.keys(), key=int):
            values.append(cls._load_list_item(group[idx]))
        return values

    @classmethod
    def _load_dict(cls, group):
        result = {}
        for key in group.keys():
            result[key] = cls._load_list_item(group[key])
        return result

    @staticmethod
    def _load_list_item(group):

        type_tag = group.attrs.get("_type")

        if type_tag == "none":
            return None

        elif type_tag == "ndarray":
            return group["value"][()]

        elif type_tag == "scalar":
            return group.attrs["value"]

        else:
            return HDF5Serializable._load_dynamic(group)

    @staticmethod
    def _load_dynamic(group):

        full_classname = group.attrs["_class"]
        module_name, class_name = full_classname.rsplit(".", 1)

        module = importlib.import_module(module_name)
        cls = getattr(module, class_name)

        return cls._load_from_group(group)
