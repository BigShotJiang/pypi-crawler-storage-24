# -*- coding: utf-8 -*-
"""Store default values and keep ScopeSim imports in one place."""

from astar_utils import NestedMapping

import scopesim

Source = scopesim.source.source.Source

create_wcs_from_points = scopesim.optics.image_plane_utils.create_wcs_from_points
load_example_optical_train = scopesim.load_example_optical_train

__config__ = NestedMapping({
    "spectral": {
        "wave_min": 0.3,
        "wave_max": 3.0,
    },
    "random": {
        "seed": 9001,
    },
})
