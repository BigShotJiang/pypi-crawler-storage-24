"""Tests for the validate_prompt_file MCP tool."""

from __future__ import annotations

import re

import pytest

from renderdeck_mcp.tools.validate import run_validate

VALID_PROMPT = """\
# My Presentation

## General

A test deck for validation.

## Global Rules

FORMAT: 16:9

---

## Slide 01 — Introduction

A wide-format opening slide.

---

## Slide 02 — Main Content

Content with data visualisation.

---

## Slide 03 — Closing

Final statement slide.

## Speaker Notes

### Slide 01 — Introduction

**Say:** Welcome everyone.
**Time:** 30 seconds

### Slide 02 — Main Content

**Say:** Here is the data.
**Time:** 2 minutes

### Slide 03 — Closing

**Say:** Thank you.
**Time:** 15 seconds
"""

INVALID_PROMPT_NO_H1 = """\
## Slide 01 — First Slide

Content here.
"""

INVALID_PROMPT_MULTI_ERROR = """\
# Title

## Slide 1 — Bad Number

Not zero-padded.

---

## Slide 01 — First

Content.

---

## Slide 01 — Duplicate

Same number again.
"""


class TestRunValidate:
    """Tests for run_validate."""

    def test_valid_file_returns_valid_true(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert result["valid"] is True
        assert result["slide_count"] == 3
        assert len(result["errors"]) == 0

    def test_valid_file_slides_populated(self) -> None:
        result = run_validate(VALID_PROMPT)
        slides = result["slides"]
        assert len(slides) == 3
        assert slides[0] == {"number": 1, "title": "Introduction", "line_number": 13}
        assert slides[1]["number"] == 2
        assert slides[2]["number"] == 3

    def test_valid_file_slide_dict_keys(self) -> None:
        result = run_validate(VALID_PROMPT)
        slide = result["slides"][0]
        assert set(slide.keys()) == {"number", "title", "line_number"}

    def test_invalid_no_h1_returns_error(self) -> None:
        result = run_validate(INVALID_PROMPT_NO_H1)
        assert result["valid"] is False
        assert len(result["errors"]) >= 1
        assert any("H1" in e["message"] for e in result["errors"])

    def test_error_dict_keys(self) -> None:
        result = run_validate(INVALID_PROMPT_NO_H1)
        error = result["errors"][0]
        assert set(error.keys()) == {"line_number", "message", "slide_number"}

    def test_multiple_errors_all_reported(self) -> None:
        result = run_validate(INVALID_PROMPT_MULTI_ERROR)
        assert result["valid"] is False
        # Should have at least: non-zero-padded slide 1, duplicate slide 01
        assert len(result["errors"]) >= 2

    def test_empty_input_returns_error_not_crash(self) -> None:
        result = run_validate("")
        assert result["valid"] is False
        assert len(result["errors"]) >= 1

    def test_warnings_included(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert isinstance(result["warnings"], list)

    def test_return_type_is_dict(self) -> None:
        result = run_validate(VALID_PROMPT)
        assert isinstance(result, dict)
        assert set(result.keys()) == {
            "valid",
            "slide_count",
            "slides",
            "errors",
            "warnings",
            "prompt_id",
        }


# ---------------------------------------------------------------------------
# Prompt-cache integration: prompt_id in validate response (EXE-1104)
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_prompt_cache_validate() -> object:
    """Clear the module-level prompt_cache singleton after every test in this module."""
    yield
    try:
        from renderdeck_mcp.cache import prompt_cache

        prompt_cache.clear()
    except ImportError:
        pass  # cache module not yet implemented; tests that need it will fail explicitly


class TestValidatePromptId:
    """Tests that run_validate returns a prompt_id field (EXE-1104)."""

    def test_validate_returns_prompt_id_key(self) -> None:
        """The validate response dict must include a 'prompt_id' key."""
        result = run_validate(VALID_PROMPT)
        assert "prompt_id" in result

    def test_validate_prompt_id_is_string(self) -> None:
        """The prompt_id value must be a str."""
        result = run_validate(VALID_PROMPT)
        assert isinstance(result["prompt_id"], str)

    def test_validate_prompt_id_is_64_hex_chars(self) -> None:
        """The prompt_id must be exactly 64 lowercase hexadecimal characters."""
        result = run_validate(VALID_PROMPT)
        prompt_id = result["prompt_id"]
        assert len(prompt_id) == 64
        assert re.fullmatch(r"[0-9a-f]{64}", prompt_id)

    def test_validate_invalid_still_returns_prompt_id(self) -> None:
        """Even when validation fails, the response dict must include prompt_id."""
        result = run_validate(INVALID_PROMPT_NO_H1)
        assert result["valid"] is False
        assert "prompt_id" in result
        assert isinstance(result["prompt_id"], str)
        assert len(result["prompt_id"]) == 64

    def test_validate_same_content_same_id(self) -> None:
        """Calling run_validate twice with identical content returns the same prompt_id."""
        result_a = run_validate(VALID_PROMPT)
        result_b = run_validate(VALID_PROMPT)
        assert result_a["prompt_id"] == result_b["prompt_id"]
