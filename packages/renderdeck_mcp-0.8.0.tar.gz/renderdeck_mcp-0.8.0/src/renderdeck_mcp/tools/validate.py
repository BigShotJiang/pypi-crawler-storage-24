"""MCP tool: validate_prompt_file.

Wraps the parser validator as an MCP tool, returning a structured dict
suitable for JSON serialisation by FastMCP.
"""

from __future__ import annotations

from renderdeck_mcp.cache import prompt_cache


def run_validate(slide_prompt_content: str) -> dict[str, object]:
    """Validate a slide prompt file and return a structured result.

    Returns a dict with keys: valid, slide_count, slides, errors, warnings,
    prompt_id.
    """
    entry = prompt_cache.store(slide_prompt_content)
    result = entry.validation_result

    return {
        "valid": result.valid,
        "slide_count": result.slide_count,
        "slides": [
            {"number": s.number, "title": s.title, "line_number": s.line_number}
            for s in result.slides
        ],
        "errors": [
            {
                "line_number": e.line_number,
                "message": e.message,
                "slide_number": e.slide_number,
            }
            for e in result.errors
        ],
        "warnings": result.warnings,
        "prompt_id": entry.prompt_id,
    }
