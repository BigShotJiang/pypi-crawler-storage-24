# Tasks for Epic-2: MCP Server, Concurrent Image Generation, and .pptx Assembly

[Addresses: G-2, G-3, G-4, G-8, G-9, G-10, G-11]

---

## Task: mcp-server-scaffold

**Type:** Technical Task
**Summary:** Create MCP server with FastMCP, stdio transport, and basic tool registration.
**Risk:** HIC — reversibility: high, consequence: team
**Depends on:** none

### Description

Set up the MCP server entry point using FastMCP 1.x with stdio transport in `src/renderdeck_mcp/server.py` and `src/renderdeck_mcp/__main__.py`. Register a placeholder `generate_deck` tool to verify the server starts and is discoverable by MCP Inspector. Configure `uvx renderdeck-mcp serve` entry point in pyproject.toml.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `python -m renderdeck_mcp serve` starts the MCP server on stdio
- [ ] VERIFY: MCP Inspector connects and lists `generate_deck` tool with correct parameter schema
- [ ] VERIFY: Server responds to MCP `initialize` and `tools/list` requests
- [ ] VERIFY: `pyproject.toml` defines `renderdeck-mcp` console script entry point

#### Boundary Criteria

- [ ] VERIFY: Server exits cleanly on stdin EOF
- [ ] VERIFY: No Google API or Gemini imports at server startup

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/mcp-server-scaffold/design.md`

---

## Task: gemini-client

**Type:** Technical Task
**Summary:** Implement async Gemini API client with retry logic and configurable concurrency.
**Risk:** HIC — reversibility: medium, consequence: isolated
**Depends on:** none

### Description

Create `src/renderdeck_mcp/generation/gemini.py` with an async Gemini API client adapted from `renderdeck.py` (lines 417-575). Supports configurable concurrency (default: 3 simultaneous calls), exponential backoff on 429/503, and text-only fallback on failure. Uses `google-genai` SDK (not deprecated `google-generativeai`).

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `generate_image(prompt, model, aspect_ratio) -> bytes | None` returns PNG bytes or None on failure
- [ ] VERIFY: `generate_images_concurrent(slides, config) -> list[ImageResult]` processes slides with configurable parallelism
- [ ] VERIFY: Retry logic: exponential backoff (2s, 4s, 8s) on 429/503, up to `max_retries` attempts
- [ ] VERIFY: Failed slide after retries → returns None (text-only fallback), does not raise
- [ ] VERIFY: Concurrency limited to `max_concurrent_images` (default: 3)

#### Boundary Criteria

- [ ] VERIFY: API key not logged or included in error messages
- [ ] VERIFY: All Gemini calls use `google-genai`, not deprecated SDK

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests with mocked Gemini API
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/gemini-client/design.md`

---

## Task: cache-manifest

**Type:** Technical Task
**Summary:** Implement cache manifest for per-project content-hash-based image caching.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Create `src/renderdeck_mcp/generation/cache.py` with cache manifest read/write compatible with `renderdeck.py` format. Cache dir: `~/.renderdeck/cache/{project_name}/`. Manifest tracks per-slide content hash and options hash. Reuse images when hashes match.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `load_cache_manifest(project_name) -> CacheManifest | None` reads existing manifest
- [ ] VERIFY: `save_cache_manifest(project_name, manifest)` writes atomically (tmp + rename)
- [ ] VERIFY: `should_regenerate(slide, manifest, options_hash) -> bool` returns True when content or options hash changed
- [ ] VERIFY: Unchanged slide with matching hashes → `should_regenerate` returns False
- [ ] VERIFY: Changed General/Global Rules → all slides have different content hashes → all regenerated

#### Boundary Criteria

- [ ] VERIFY: Missing cache dir → created automatically
- [ ] VERIFY: Corrupted manifest JSON → treated as empty (regenerate all)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover all functional criteria
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green

---

## Task: pptx-builder

**Type:** Technical Task
**Summary:** Implement .pptx assembly with background images and speaker notes via python-pptx.
**Risk:** HIC — reversibility: high, consequence: team
**Depends on:** none

### Description

Create `src/renderdeck_mcp/assembly/pptx_builder.py`. Each slide: full-slide PNG background image + speaker notes on the notes page. Supports 16:9 (WIDE) and 4:3 (STANDARD) aspect ratios. Image compression via Pillow for large PNGs. Slides without images get speaker notes only.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `build_pptx(parsed_deck, images, output_path, aspect_ratio) -> Path` writes a valid .pptx file
- [ ] VERIFY: Each slide has PNG set as full-slide background
- [ ] VERIFY: Speaker notes attached to each slide's notes page
- [ ] VERIFY: Slide without image (empty prompt) → slide with notes only, no background
- [ ] VERIFY: WIDE aspect ratio → 16:9 slide dimensions
- [ ] VERIFY: STANDARD aspect ratio → 4:3 slide dimensions

#### Boundary Criteria

- [ ] VERIFY: .pptx opens in LibreOffice/PowerPoint without errors
- [ ] VERIFY: Large PNG (>5MB) compressed before embedding

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests with sample PNG fixtures
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/pptx-builder/design.md`

---

## Task: generate-deck-tool

**Type:** Technical Task
**Summary:** Wire the full generate_deck pipeline: parse → generate images → cache → assemble .pptx → return result.
**Risk:** HIC — reversibility: medium, consequence: team
**Depends on:** mcp-server-scaffold, gemini-client, cache-manifest, pptx-builder

### Description

Implement the `generate_deck` MCP tool in `src/renderdeck_mcp/tools/generate_deck.py`. Orchestrates: parse prompt file → check cache → generate images (concurrent) → compress → assemble .pptx → update cache manifest → return result with slide count, generated/cached counts, cost estimate, and per-slide status. Includes MCP progress notifications.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `generate_deck(slide_prompt_content, output_path?, image_quality?, project_name?)` returns result JSON with output_path, slide_count, slides_generated, slides_cached, image_results, cost_estimate
- [ ] VERIFY: Default output path: `~/Documents/RenderDeck/{title}_{timestamp}.pptx`
- [ ] VERIFY: `image_quality: "draft"` uses Nano Banana; `"final"` uses Nano Banana Pro
- [ ] VERIFY: Progress notifications emitted per slide (phase, slide number, cached status)
- [ ] VERIFY: Resubmit same content → all slides cached, 0 Gemini calls
- [ ] VERIFY: Change 2 slides → only 2 regenerated, rest cached
- [ ] VERIFY: Image error on one slide → text-only fallback, other slides unaffected, .pptx produced

#### Boundary Criteria

- [ ] VERIFY: Empty prompt file → validation error returned, no .pptx created
- [ ] VERIFY: No Gemini key configured → clear error message with setup instructions

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New integration tests with mocked Gemini API
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/generate-deck-tool/design.md`

---

## Task: reference-image-input

**Type:** Technical Task
**Summary:** Add reference image support (URL/base64) to generate_slide and prompt file parser for multimodal Gemini API input.
**Risk:** HIC — reversibility: high, consequence: team
**Depends on:** generate-deck-tool

### Description

Extend `generate_slide` to accept an optional `reference_images` parameter (list of URL/base64 image objects with role labels). Add a `REFERENCES:` block to the prompt file format per slide. When reference images are provided, include them as multimodal content blocks in the Gemini API request. Graceful fallback to text-only generation when image fetch fails. Maximum 14 reference images per slide (Gemini API limit).

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `generate_slide` accepts optional `reference_images` parameter (list of `{url?, base64?, media_type?, role?}`)
- [ ] VERIFY: Reference images are forwarded to Gemini API as `inline_data` multimodal content blocks
- [ ] VERIFY: Prompt file parser supports `REFERENCES:` block per slide with `url:`, `role:`, `placement:` fields
- [ ] VERIFY: `generate_deck` pipeline passes parsed references through to slide generation
- [ ] VERIFY: Role labels included in text prompt to guide Gemini on image placement
- [ ] VERIFY: URL references are fetched and converted to base64 before API call

#### Boundary Criteria

- [ ] VERIFY: More than 14 reference images per slide → validation error
- [ ] VERIFY: Failed image fetch (network error, 404) → warning logged, slide generated text-only
- [ ] VERIFY: Invalid base64 data → warning logged, that reference skipped
- [ ] VERIFY: Missing `REFERENCES:` block → slide generated normally (backward compatible)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests for reference image parsing and validation
- [ ] New integration tests with mocked Gemini API for multimodal requests
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md`

---

## Task: french-voices

**Type:** Technical Task
**Summary:** Add French voice support (fr-FR, fr-BE, fr-CA) to TTS voice catalogue so users can generate French-narrated video presentations.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Expand the voice catalogue in `src/renderdeck_mcp/voices.py` to include French locales (fr-FR, fr-BE, fr-CA) with short aliases following the existing naming convention. Update `_LOCALE_LABELS` in `src/renderdeck_mcp/tools/voices.py` to include French locale labels. The `list_voices` tool must return French voices alongside English ones, and `generate_video` must accept French voice aliases and produce correctly narrated French audio via edge-tts.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `DEFAULT_VOICES` in `voices.py` includes fr-FR voices (e.g. `fr-FR-DeniseNeural`, `fr-FR-HenriNeural`)
- [ ] VERIFY: `DEFAULT_VOICES` includes fr-BE voices (e.g. `fr-BE-CharlineNeural`, `fr-BE-GerardNeural`)
- [ ] VERIFY: `DEFAULT_VOICES` includes fr-CA voices (e.g. `fr-CA-SylvieNeural`, `fr-CA-AntoineNeural`)
- [ ] VERIFY: French voice aliases follow existing naming convention (lowercase, short first-name)
- [ ] VERIFY: `list_voices` returns French voices alongside English ones
- [ ] VERIFY: `resolve_voice("denise")` returns `"fr-FR-DeniseNeural"`
- [ ] VERIFY: `generate_video` accepts a French voice alias and produces narrated audio

#### Boundary Criteria

- [ ] VERIFY: Existing English voice aliases still resolve correctly (backward compatible)
- [ ] VERIFY: `_LOCALE_LABELS` updated with `fr-FR`, `fr-BE`, `fr-CA` entries

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests for French voice resolution
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy src/`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/french-voices/design.md`

---

## Task: vietnamese-voices

**Type:** Technical Task
**Summary:** Add Vietnamese voice support (vi-VN) to TTS voice catalogue so users can generate Vietnamese-narrated video presentations.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Expand the voice catalogue in `src/renderdeck_mcp/voices.py` to include Vietnamese locale (vi-VN) with short aliases following the existing naming convention. Update `_LOCALE_LABELS` in `src/renderdeck_mcp/tools/voices.py` to include the Vietnamese locale label. The `list_voices` tool must return Vietnamese voices alongside English and French ones, and `generate_video` must accept Vietnamese voice aliases and produce correctly narrated Vietnamese audio via edge-tts.

Vietnamese is a tonal language with six distinct tones. TTS quality is sensitive to correct diacritics in input text. This is a prompt authoring concern — the tool just needs to accept and pass Vietnamese voice identifiers to edge-tts.

This is the same class of change as EXE-1096 (French voice support) — extending the voice registry to a new locale.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `DEFAULT_VOICES` in `voices.py` includes vi-VN voices (`vi-VN-HoaiMyNeural` female, `vi-VN-NamMinhNeural` male)
- [ ] VERIFY: Vietnamese voice aliases follow existing naming convention (lowercase, short first-name)
- [ ] VERIFY: `list_voices` returns Vietnamese voices alongside English and French ones
- [ ] VERIFY: `resolve_voice("hoaimy")` returns `"vi-VN-HoaiMyNeural"`
- [ ] VERIFY: `generate_video` accepts a Vietnamese voice alias and produces narrated audio

#### Boundary Criteria

- [ ] VERIFY: Existing English and French voice aliases still resolve correctly (backward compatible)
- [ ] VERIFY: `_LOCALE_LABELS` updated with `vi-VN` entry

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests for Vietnamese voice resolution
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy src/`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/vietnamese-voices/design.md`

---

## Task: prompt-file-cache

**Type:** Technical Task
**Summary:** Introduce a prompt file cache so that validate_prompt stores the parsed result and returns a unique prompt_id, and all downstream tools reference prompts by ID instead of re-sending full content.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** generate-deck-tool

### Description

Every MCP tool that operates on a presentation (generate_deck, regenerate_slide, assemble_deck, generate_video) currently requires the caller to pass the full prompt file content as a string (`slide_prompt_content`) on every invocation. This creates friction: the MCP client must re-send the entire prompt file for each tool call, the prompt file is re-parsed from scratch every time, and multi-step workflows redundantly process the same content.

Introduce a prompt file cache so that:
1. `validate_prompt` validates the prompt file, stores the parsed result in an in-memory cache, and returns a unique prompt ID (content hash).
2. All downstream tools accept a `prompt_id` referencing a previously validated prompt file instead of `slide_prompt_content`.
3. Slide modifications (e.g., regenerate_slide, modify_slide) re-run validation on the updated content, store the new version under a new prompt ID, and return the updated ID to the caller.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `validate_prompt` returns a `prompt_id` field in its result alongside the existing validation output
- [ ] VERIFY: All tools that currently require `slide_prompt_content` accept `prompt_id` instead
- [ ] VERIFY: The `slide_prompt_content` parameter is removed from all downstream tools — `prompt_id` is the only way to reference a prompt file
- [ ] VERIFY: When `prompt_id` is provided, the tool retrieves the cached parsed prompt file instead of re-parsing
- [ ] VERIFY: When the prompt file content changes (slide edit), re-validation produces a new `prompt_id`
- [ ] VERIFY: Cache entries are scoped per MCP server session (no stale cross-session data)

#### Boundary Criteria

- [ ] VERIFY: Invalid or unknown `prompt_id` → clear error message
- [ ] VERIFY: Server restart clears the cache (no persistent stale data)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests for prompt cache operations
- [ ] New integration tests for prompt_id workflow
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy src/`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-server-generation-assembly/prompt-file-cache/design.md`
