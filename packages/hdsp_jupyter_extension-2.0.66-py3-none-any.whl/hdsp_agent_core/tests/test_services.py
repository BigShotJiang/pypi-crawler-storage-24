"""
HDSP Agent Core - Service Implementation Tests

Tests for Embedded service implementations.
"""

from unittest.mock import AsyncMock, patch

import pytest

from hdsp_agent_core.interfaces import IAgentService, IChatService, IRAGService


class TestEmbeddedAgentService:
    """Tests for EmbeddedAgentService"""

    @pytest.fixture
    def embedded_agent_service(self):
        """Create EmbeddedAgentService instance"""
        from hdsp_agent_core.services.agent_service import EmbeddedAgentService

        return EmbeddedAgentService()

    def test_implements_interface(self, embedded_agent_service):
        """Test EmbeddedAgentService implements IAgentService"""
        assert isinstance(embedded_agent_service, IAgentService)

    @pytest.mark.asyncio
    async def test_generate_plan_with_mock_llm(
        self, embedded_agent_service, sample_plan_request
    ):
        """Test generate_plan calls LLM service"""
        # Mock the LLM service
        with patch.object(
            embedded_agent_service, "_llm_service", create=True
        ) as mock_llm:
            mock_llm.generate_response = AsyncMock(
                return_value='{"steps": [], "plan_id": "test"}'
            )

            # Note: Full integration test would require more mocking
            # This is a placeholder for when LLM integration is complete


class TestEmbeddedChatService:
    """Tests for EmbeddedChatService"""

    @pytest.fixture
    def embedded_chat_service(self):
        """Create EmbeddedChatService instance"""
        from hdsp_agent_core.services.chat_service import EmbeddedChatService

        return EmbeddedChatService()

    def test_implements_interface(self, embedded_chat_service):
        """Test EmbeddedChatService implements IChatService"""
        assert isinstance(embedded_chat_service, IChatService)


class TestEmbeddedRAGService:
    """Tests for EmbeddedRAGService"""

    @pytest.fixture
    def embedded_rag_service(self):
        """Create EmbeddedRAGService instance with mocked RAG manager"""
        from hdsp_agent_core.services.rag_service import EmbeddedRAGService

        service = EmbeddedRAGService()
        return service

    def test_implements_interface(self, embedded_rag_service):
        """Test EmbeddedRAGService implements IRAGService"""
        assert isinstance(embedded_rag_service, IRAGService)

    def test_is_ready_before_init(self, embedded_rag_service):
        """Test is_ready returns False before initialization"""
        assert embedded_rag_service.is_ready() is False

    @pytest.mark.asyncio
    async def test_initialize_sets_ready(self, embedded_rag_service, mock_rag_manager):
        """Test initialize makes service ready when RAGManager is available"""
        # Directly set the internal state to simulate successful initialization
        # since the actual rag_manager module might not be available
        mock_rag_manager.is_ready = True
        embedded_rag_service._rag_manager = mock_rag_manager
        embedded_rag_service._initialized = True

        assert embedded_rag_service.is_ready() is True

    @pytest.mark.asyncio
    async def test_initialize_is_noop(self, embedded_rag_service):
        """Test initialize is a no-op (agent_server dependency removed)"""
        await embedded_rag_service.initialize()

        # Service is not ready because RAG is no longer supported via agent_server
        assert embedded_rag_service.is_ready() is False


class TestServiceInterfaceCompliance:
    """Tests to verify all services implement their interfaces correctly"""

    def test_all_agent_service_methods_exist(self):
        """Verify all IAgentService methods are implemented"""
        from hdsp_agent_core.services.agent_service import EmbeddedAgentService

        required_methods = [
            "generate_plan",
            "refine_code",
            "replan",
            "validate_code",
        ]

        for method in required_methods:
            assert hasattr(EmbeddedAgentService, method), (
                f"EmbeddedAgentService missing {method}"
            )
            assert callable(getattr(EmbeddedAgentService, method))

    def test_all_chat_service_methods_exist(self):
        """Verify all IChatService methods are implemented"""
        from hdsp_agent_core.services.chat_service import EmbeddedChatService

        required_methods = [
            "send_message",
            "send_message_stream",
        ]

        for method in required_methods:
            assert hasattr(EmbeddedChatService, method), (
                f"EmbeddedChatService missing {method}"
            )
            assert callable(getattr(EmbeddedChatService, method))

    def test_all_rag_service_methods_exist(self):
        """Verify all IRAGService methods are implemented"""
        from hdsp_agent_core.services.rag_service import EmbeddedRAGService

        required_methods = [
            "search",
            "get_context_for_query",
            "is_ready",
            "get_index_status",
            "trigger_reindex",
        ]

        for method in required_methods:
            assert hasattr(EmbeddedRAGService, method), (
                f"EmbeddedRAGService missing {method}"
            )
            assert callable(getattr(EmbeddedRAGService, method))
