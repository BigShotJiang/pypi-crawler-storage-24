"""
HDSP Agent Core - ServiceFactory Tests

Tests for ServiceFactory initialization and service creation.
"""

import pytest

from hdsp_agent_core.factory import ServiceFactory, get_service_factory
from hdsp_agent_core.interfaces import IAgentService, IChatService, IRAGService


class TestServiceFactorySingleton:
    """Tests for ServiceFactory singleton pattern"""

    def test_get_instance_returns_same_instance(self, reset_factory):
        """Test get_instance returns the same instance"""
        instance1 = ServiceFactory.get_instance()
        instance2 = ServiceFactory.get_instance()
        assert instance1 is instance2

    def test_reset_instance_clears_singleton(self, reset_factory):
        """Test reset_instance clears the singleton"""
        instance1 = ServiceFactory.get_instance()
        ServiceFactory.reset_instance()
        instance2 = ServiceFactory.get_instance()
        assert instance1 is not instance2

    def test_get_service_factory_convenience_function(self, reset_factory):
        """Test get_service_factory returns singleton"""
        factory1 = get_service_factory()
        factory2 = ServiceFactory.get_instance()
        assert factory1 is factory2


class TestServiceFactoryInitialization:
    """Tests for ServiceFactory initialization"""

    def test_not_initialized_by_default(self, reset_factory):
        """Test factory is not initialized by default"""
        factory = ServiceFactory.get_instance()
        assert factory.is_initialized is False

    @pytest.mark.asyncio
    async def test_initialize(self, reset_factory, mock_env_embedded):
        """Test initialization creates embedded services"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        assert factory.is_initialized is True

    @pytest.mark.asyncio
    async def test_double_initialization_is_noop(
        self, reset_factory, mock_env_embedded
    ):
        """Test calling initialize twice is safe"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        await factory.initialize()  # Should not raise
        assert factory.is_initialized is True

    @pytest.mark.asyncio
    async def test_shutdown_resets_state(self, reset_factory, mock_env_embedded):
        """Test shutdown resets initialization state"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        assert factory.is_initialized is True
        await factory.shutdown()
        assert factory.is_initialized is False


class TestServiceFactoryServiceAccess:
    """Tests for service accessor methods"""

    @pytest.mark.asyncio
    async def test_get_agent_service_after_init(self, reset_factory, mock_env_embedded):
        """Test get_agent_service returns service after init"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        service = factory.get_agent_service()
        assert service is not None
        assert isinstance(service, IAgentService)

    @pytest.mark.asyncio
    async def test_get_chat_service_after_init(self, reset_factory, mock_env_embedded):
        """Test get_chat_service returns service after init"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        service = factory.get_chat_service()
        assert service is not None
        assert isinstance(service, IChatService)

    @pytest.mark.asyncio
    async def test_get_rag_service_after_init(self, reset_factory, mock_env_embedded):
        """Test get_rag_service returns service after init"""
        factory = ServiceFactory.get_instance()
        await factory.initialize()
        service = factory.get_rag_service()
        assert service is not None
        assert isinstance(service, IRAGService)

    def test_get_agent_service_before_init_raises(self, reset_factory):
        """Test get_agent_service raises before initialization"""
        factory = ServiceFactory.get_instance()
        with pytest.raises(RuntimeError, match="not initialized"):
            factory.get_agent_service()

    def test_get_chat_service_before_init_raises(self, reset_factory):
        """Test get_chat_service raises before initialization"""
        factory = ServiceFactory.get_instance()
        with pytest.raises(RuntimeError, match="not initialized"):
            factory.get_chat_service()

    def test_get_rag_service_before_init_raises(self, reset_factory):
        """Test get_rag_service raises before initialization"""
        factory = ServiceFactory.get_instance()
        with pytest.raises(RuntimeError, match="not initialized"):
            factory.get_rag_service()


class TestServiceFactoryServiceTypes:
    """Tests for service type verification"""

    @pytest.mark.asyncio
    async def test_creates_embedded_services(self, reset_factory, mock_env_embedded):
        """Test initialization creates EmbeddedXxxService instances"""
        from hdsp_agent_core.services.agent_service import EmbeddedAgentService
        from hdsp_agent_core.services.chat_service import EmbeddedChatService
        from hdsp_agent_core.services.rag_service import EmbeddedRAGService

        factory = ServiceFactory.get_instance()
        await factory.initialize()

        assert isinstance(factory.get_agent_service(), EmbeddedAgentService)
        assert isinstance(factory.get_chat_service(), EmbeddedChatService)
        assert isinstance(factory.get_rag_service(), EmbeddedRAGService)
