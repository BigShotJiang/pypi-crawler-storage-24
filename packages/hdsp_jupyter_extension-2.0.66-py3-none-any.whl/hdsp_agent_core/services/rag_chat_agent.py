"""RAG Chat Agent — LangChain create_agent 기반 ReAct 에이전트.

chat mode에서 RAG 검색이 필요할 때 LLM이 자동으로 rag_search tool을 호출.
최대 2회 tool call, 스트리밍 지원.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator, Dict, List, Optional

logger = logging.getLogger(__name__)


# 기존 chat 시스템 프롬프트 + RAG 가이드
_RAG_SYSTEM_PROMPT_ADDITION = """

## RAG 지식 검색

당신은 사내 데이터 플랫폼의 테이블 메타데이터와 가이드 문서를 검색할 수 있는 rag_search 도구를 가지고 있습니다.

### 사용 가능한 컬렉션
1. **enterprise_tables**: 전사 엔터프라이즈 테이블 메타데이터
   - 사용 시점: 사용자가 전사 DB 테이블, 컬럼, 스키마를 물어볼 때

2. **bdp_tables**: BDP(빅데이터플랫폼) 테이블 메타데이터
   - 사용 시점: BDP 테이블 조회, 도메인별 데이터 탐색, 적재주기/소유팀 확인

3. **guide_docs**: BDP/플랫폼 업무 가이드 문서 + bdpengine API 레퍼런스
   - bdpengine: BDP 핵심 Python 패키지. S3 파일 관리, MinIO 연동, Spark/EMR Job 제출, Athena 쿼리, SageMaker 학습/배포 등의 통합 인터페이스 (`from bdpengine import *`)
   - 사용 시점: "BDP 어떻게 쓰나요?", "S3에서 파일 다운로드", "Athena 쿼리 방법", "bdpengine 함수", 플랫폼 매뉴얼 질문

4. **ds_guide_docs**: 데이터사이언스 기술 가이드 문서
   - 사용 시점: 분석 기법 질문, 라이브러리 사용법, ML 파이프라인 구현

### 도구 호출 전략 (매우 중요 — 반드시 준수)

**테이블/컬럼/DB 관련 질문**일 때:
1. 먼저 `load_table_search_skill`을 호출하여 필터 가이드를 확인하세요.
2. 가이드를 참고하여 `rag_search`에 적절한 filters를 적용하세요.

**가이드/문서 관련 질문**일 때:
- `load_table_search_skill` 없이 바로 `rag_search`를 호출하세요. 가이드 컬렉션은 pre-filtering이 불필요합니다.

### 검색 전략
- **도구 호출은 최대 3회까지만 허용됩니다.** (load_table_search_skill 1회 + rag_search 최대 2회)
- **rag_search 호출 시 필요한 모든 쿼리를 queries 배열에 담아 배치 처리하세요.**
  - 테이블 + 가이드가 동시에 필요하면 queries 배열에 모두 넣어 1회 호출.
- rag_search 1회 호출 후에는 결과가 부족하더라도 **가진 결과만으로 답변하세요.** 절대 같은 도구를 같은 쿼리로 다시 호출하지 마세요.
- 검색 결과가 완전히 0건이어서 답변이 불가능할 때만 예외적으로 쿼리를 변경하여 1회 재검색 시도를 허용합니다.

### 검색하지 않아도 되는 경우
- 일반 Python 문법, 디버깅 질문 (BDP/bdpengine과 무관한 경우)
- 수학/통계 계산, 일반 지식으로 답변 가능한 질문
- 이전 대화에서 이미 검색한 정보로 충분한 경우

### Python 코드 생성 시 규칙
- BDP 환경에서 S3, MinIO, Athena, Spark, SageMaker 관련 Python 코드를 생성할 때는 guide_docs에서 bdpengine 가이드를 검색하세요. **단, 1회차 배치 호출의 queries 배열에 포함하세요. 별도 도구 호출을 하지 마세요.**
- bdpengine은 사내 BDP의 핵심 Python 패키지로, 모든 데이터 플랫폼 작업의 표준 인터페이스입니다.
  - `from bdpengine import *` 로 임포트하면 S3 버킷 변수, 파일 관리 함수, 쿼리 함수 등이 로드됩니다.
  - boto3 직접 호출 대신 bdpengine 함수를 사용해야 합니다 (인증, 환경 설정이 자동 처리됨).
- 검색 시 source 필터 활용: "31_bdpengine_quickstart.md", "32_bdpengine_s3_functions.md", "33_bdpengine_minio_functions.md", "34_bdpengine_spark_emr_functions.md", "35_bdpengine_athena_sagemaker_functions.md"

### 출처 인용
검색 결과를 활용할 때 자연스럽게 출처를 언급하세요:
- "enterprise_tables에서 확인한 결과, TB_CARD_TXN 테이블은..."
- "BDP 가이드 문서에 따르면..."

### 응답 스타일 (매우 중요)
- **질문한 내용에만 정확히 답변하세요.** 사용자가 묻지 않은 내용을 선제적으로 설명하지 마세요.
- 예를 들어 "카드 거래 테이블 알려줘"라고 하면 테이블 스키마 정보만 답변하세요. 쿼리 예시, Python 코드, 분석 방법론 등을 붙이지 마세요.
- 사용자가 필요할 수 있는 추가 정보가 있다면, 직접 제공하지 말고 짧게 제안만 하세요:
  - "이 테이블의 쿼리 예시가 필요하시면 알려주세요."
  - "bdpengine으로 데이터를 조회하는 방법도 안내해 드릴까요?"
- 검색도 마찬가지로 질문에 필요한 컬렉션만 검색하세요. 단, **코드 생성 요청**(Python, SQL, 쿼리 등)에는 테이블 정보 + guide_docs(bdpengine 가이드)를 함께 배치 검색하세요.
- 간결하고 핵심적인 답변을 우선하세요. 장황한 설명보다 정확한 정보가 중요합니다.
"""


def _format_tool_status(queries_str: str) -> str:
    """tool_start 이벤트에서 사용자 친화적 상태 메시지 생성."""
    _COL_LABELS = {
        "enterprise_tables": "전사 테이블",
        "bdp_tables": "BDP 테이블",
        "guide_docs": "가이드 문서",
        "ds_guide_docs": "DS 가이드",
    }
    try:
        q_list = json.loads(queries_str) if queries_str else []
    except Exception:
        return "📚 지식 베이스 검색 중..."

    parts = []
    for q in q_list:
        if not isinstance(q, dict):
            continue
        query = q.get("query", "")
        col = q.get("collection", "")
        filters = q.get("filters", [])
        col_label = _COL_LABELS.get(col, "전체")
        filter_parts = [
            f"{f['field']}={f['value']}"
            for f in filters
            if isinstance(f, dict) and f.get("field") and f.get("value")
        ]
        filter_str = f" [{', '.join(filter_parts)}]" if filter_parts else ""
        parts.append(f'🔍 {col_label}{filter_str} — "{query}"')

    return "\n".join(parts) if parts else "📚 지식 베이스 검색 중..."


class RAGChatAgent:
    """LangChain create_agent 기반 RAG chat agent.

    chat mode에서 RAG가 가용할 때 LLMService 대신 사용.
    rag_search 도구 1개로 ReAct loop (최대 2회 tool call).
    """

    def __init__(self, llm_config: Dict[str, Any]):
        self._llm_config = llm_config
        self._agent = None

    def _create_model(self):
        """vLLM 설정으로 LangChain ChatModel 생성."""
        from langchain.chat_models import init_chat_model

        cfg = self._llm_config.get("vllm", {})
        endpoint = cfg.get("endpoint", "").rstrip("/")
        if not endpoint.endswith("/v1"):
            endpoint += "/v1"

        return init_chat_model(
            f"openai:{cfg.get('model', 'default')}",
            base_url=endpoint,
            api_key=cfg.get("apiKey", ""),
            temperature=0.0,
            streaming=True,
        )

    @staticmethod
    def _create_tools():
        """rag_search + load_table_search_skill 도구 생성."""
        from jupyter_ext.agent.langchain_tools import (
            create_enhanced_rag_search_tool,
            create_table_search_skill_tool,
        )

        return [create_enhanced_rag_search_tool(), create_table_search_skill_tool()]

    @staticmethod
    def _build_system_prompt() -> str:
        """기존 chat 시스템 프롬프트 + RAG 가이드."""
        from hdsp_agent_core.llm.service import _CHAT_SYSTEM_PROMPT

        return _CHAT_SYSTEM_PROMPT + _RAG_SYSTEM_PROMPT_ADDITION

    def _ensure_agent(self):
        """create_agent로 agent graph 생성 (lazy)."""
        if self._agent is not None:
            return

        from langchain.agents import create_agent

        model = self._create_model()
        tools = self._create_tools()
        system_prompt = self._build_system_prompt()

        self._agent = create_agent(
            model=model,
            tools=tools,
            system_prompt=system_prompt,
        )

    async def stream_response(
        self,
        user_message: str,
        history_messages: Optional[List[Dict[str, str]]] = None,
        file_context: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Agent 응답을 스트리밍. SSE 호환 청크 yield.

        Yields:
            {"content": str, "done": False} — LLM 토큰
            {"status": str, "icon": str, "done": False} — 도구 호출 상태
        """
        self._ensure_agent()

        from langchain_core.messages import AIMessage, HumanMessage

        # 메시지 구성
        messages = []
        if history_messages:
            for m in history_messages:
                if m["role"] == "user":
                    messages.append(HumanMessage(content=m["content"]))
                else:
                    messages.append(AIMessage(content=m["content"]))

        if file_context:
            messages.append(HumanMessage(content=f"[참고 컨텍스트]\n{file_context}"))

        messages.append(HumanMessage(content=user_message))

        input_dict = {"messages": messages}
        config = {"recursion_limit": 12}

        content_started = False
        tool_call_count = 0

        print(f"[RAG] user_message: {user_message[:200]}", flush=True)

        try:
            async for event in self._agent.astream_events(
                input_dict, version="v2", config=config
            ):
                kind = event.get("event", "")

                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk and hasattr(chunk, "content") and chunk.content:
                        content_started = True
                        yield {"content": chunk.content, "done": False}

                elif kind == "on_tool_start":
                    tool_call_count += 1
                    tool_name = event.get("name", "")
                    tool_input = event.get("data", {}).get("input", {})

                    if "skill" in tool_name.lower():
                        # Skill 로드 도구
                        status_msg = "📋 테이블 검색 스킬 로딩..."
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): {tool_name}",
                            flush=True,
                        )
                    else:
                        # rag_search 도구
                        queries_str = ""
                        if isinstance(tool_input, dict):
                            queries_str = tool_input.get("queries", "")
                        status_msg = _format_tool_status(queries_str)
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): "
                            f"{queries_str[:200]}",
                            flush=True,
                        )

                    yield {
                        "status": status_msg,
                        "icon": "search",
                        "done": False,
                    }

                elif kind == "on_tool_end":
                    tool_name = event.get("name", "")
                    output = event.get("data", {}).get("output", "")
                    if hasattr(output, "content"):
                        output = output.content

                    if "skill" in tool_name.lower():
                        # Skill 로드 완료 — 결과 건수 표시 불필요
                        print(f"[RAG] tool_end: {tool_name} loaded", flush=True)
                        yield {
                            "status": "✅ 스킬 로드 완료",
                            "icon": "check",
                            "done": False,
                        }
                    else:
                        # rag_search 결과 + 미리보기
                        total = 0
                        preview = ""
                        try:
                            parsed = (
                                json.loads(output)
                                if isinstance(output, str)
                                else output
                            )
                            if isinstance(parsed, dict):
                                total = parsed.get("total", 0)
                                # 첫 번째 결과에서 미리보기 추출
                                for key in (
                                    "테이블 검색 결과",
                                    "가이드 검색 결과",
                                    "results",
                                ):
                                    items = parsed.get(key, [])
                                    if items and isinstance(items, list):
                                        first = items[0]
                                        p = (
                                            first.get("payload", first)
                                            if isinstance(first, dict)
                                            else {}
                                        )
                                        name = (
                                            p.get("table_name") or p.get("title") or ""
                                        )
                                        korean = p.get("korean_name") or ""
                                        if name and korean:
                                            preview = f" ({name}: {korean} ...)"
                                        elif name:
                                            preview = f" ({name} ...)"
                                        break
                        except Exception:
                            pass
                        print(f"[RAG] tool_end: total={total}", flush=True)
                        yield {
                            "status": f"✅ {total}건 발견{preview}",
                            "icon": "check",
                            "done": False,
                        }

        except Exception as e:
            import traceback

            err_msg = str(e)
            print(f"[RAG] ERROR: {err_msg}", flush=True)
            traceback.print_exc()

            if "recursion limit" in err_msg.lower():
                print("[RAG] Recursion limit — finishing gracefully", flush=True)
                if not content_started:
                    yield {
                        "content": "검색 결과를 바탕으로 답변을 준비했으나 "
                        "처리 한도에 도달했습니다. 질문을 더 구체적으로 "
                        "해주시면 정확한 답변을 드릴 수 있습니다.",
                        "done": False,
                    }
            else:
                yield {"error": f"RAG agent 오류: {err_msg}"}
