"""
HDSP Agent Core - Service Implementations
"""

from .agent_service import EmbeddedAgentService
from .chat_service import EmbeddedChatService
from .rag_service import EmbeddedRAGService

__all__ = [
    "EmbeddedAgentService",
    "EmbeddedChatService",
    "EmbeddedRAGService",
]


# Lazy imports for RAG subsystem (heavy dependencies)
def __getattr__(name):
    if name == "RAGManager":
        from .rag_manager import RAGManager

        return RAGManager
    if name == "get_rag_manager":
        from .rag_manager import get_rag_manager

        return get_rag_manager
    if name == "CodeValidator":
        from hdsp_agent_core.core.code_validator import CodeValidator

        return CodeValidator
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
