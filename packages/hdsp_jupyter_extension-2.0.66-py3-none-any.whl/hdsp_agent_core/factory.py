"""
HDSP Agent Core - 서비스 팩토리

Embedded 서비스 구현을 생성하는 팩토리.
"""

import logging
from typing import Optional

from hdsp_agent_core.interfaces import IAgentService, IChatService, IRAGService

logger = logging.getLogger(__name__)


class ServiceFactory:
    """
    서비스 인스턴스를 생성하는 팩토리.

    싱글톤 패턴으로 애플리케이션 전체에서 일관된 서비스 인스턴스를 보장함.

    사용법:
        factory = ServiceFactory.get_instance()
        await factory.initialize()

        agent_service = factory.get_agent_service()
        chat_service = factory.get_chat_service()
        rag_service = factory.get_rag_service()
    """

    _instance: Optional["ServiceFactory"] = None

    def __init__(self):
        """팩토리 초기화 (get_instance() 사용 권장)"""
        self._initialized = False

        # 서비스 인스턴스 (지연 로딩)
        self._agent_service: Optional[IAgentService] = None
        self._chat_service: Optional[IChatService] = None
        self._rag_service: Optional[IRAGService] = None

        logger.info("ServiceFactory created")

    @classmethod
    def get_instance(cls) -> "ServiceFactory":
        """싱글톤 팩토리 인스턴스 반환"""
        if cls._instance is None:
            cls._instance = ServiceFactory()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """싱글톤 인스턴스 초기화 (테스트용)"""
        cls._instance = None

    @property
    def is_initialized(self) -> bool:
        """팩토리 초기화 여부 확인"""
        return self._initialized

    async def initialize(self) -> None:
        """
        모든 서비스 초기화.

        임베디드 서비스: RAG 매니저 초기화, 지식 베이스 로드
        """
        if self._initialized:
            logger.debug("ServiceFactory already initialized")
            return

        logger.info("Initializing ServiceFactory")

        from hdsp_agent_core.services.agent_service import EmbeddedAgentService
        from hdsp_agent_core.services.chat_service import EmbeddedChatService
        from hdsp_agent_core.services.rag_service import EmbeddedRAGService

        # 서비스 인스턴스 생성
        self._agent_service = EmbeddedAgentService()
        self._chat_service = EmbeddedChatService()
        self._rag_service = EmbeddedRAGService()

        # RAG 서비스 초기화 (비동기 초기화 필요할 수 있음)
        await self._rag_service.initialize()

        self._initialized = True
        logger.info("ServiceFactory initialization complete")

    async def shutdown(self) -> None:
        """모든 서비스 종료 및 리소스 정리"""
        logger.info("Shutting down ServiceFactory")

        # RAG 서비스 정리
        if self._rag_service and hasattr(self._rag_service, "shutdown"):
            await self._rag_service.shutdown()

        # 서비스 인스턴스 초기화
        self._agent_service = None
        self._chat_service = None
        self._rag_service = None
        self._initialized = False

        logger.info("ServiceFactory shutdown complete")

    def get_agent_service(self) -> IAgentService:
        """
        Agent 서비스 인스턴스 반환.

        Returns:
            IAgentService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._agent_service

    def get_chat_service(self) -> IChatService:
        """
        Chat 서비스 인스턴스 반환.

        Returns:
            IChatService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._chat_service

    def get_rag_service(self) -> IRAGService:
        """
        RAG 서비스 인스턴스 반환.

        Returns:
            IRAGService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._rag_service


# 싱글톤 팩토리 편의 함수
def get_service_factory() -> ServiceFactory:
    """싱글톤 ServiceFactory 인스턴스 반환"""
    return ServiceFactory.get_instance()
