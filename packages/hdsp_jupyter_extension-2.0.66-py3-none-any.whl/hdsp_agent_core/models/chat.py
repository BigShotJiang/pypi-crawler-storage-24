"""
채팅 API Pydantic 모델

채팅 메시지 요청 및 응답을 위한 모델.
"""

from typing import Optional

from pydantic import BaseModel, Field

from .common import LLMConfig


class ChatRequest(BaseModel):
    """채팅 메시지 요청 본문"""

    message: str = Field(description="사용자의 채팅 메시지")
    conversationId: Optional[str] = Field(
        default=None, description="컨텍스트 연속성을 위한 대화 ID"
    )
    llmConfig: Optional[LLMConfig] = Field(
        default=None, description="API 키가 포함된 LLM 설정 (클라이언트 제공)"
    )
    maxTokens: Optional[int] = Field(
        default=None,
        description="LLM 최대 출력 토큰 수 (미지정 시 기본값 4096)",
    )


class ChatResponse(BaseModel):
    """채팅 메시지 응답 본문"""

    response: str = Field(description="어시스턴트의 응답")
    conversationId: str = Field(description="이후 메시지를 위한 대화 ID")
    model: Optional[str] = Field(default=None, description="응답에 사용된 모델")


class StreamChunk(BaseModel):
    """스트리밍 응답의 단일 청크"""

    content: str = Field(description="부분 콘텐츠")
    done: bool = Field(default=False, description="스트리밍 완료 여부")
    conversationId: Optional[str] = Field(
        default=None, description="대화 ID (마지막 청크에서 전송)"
    )
