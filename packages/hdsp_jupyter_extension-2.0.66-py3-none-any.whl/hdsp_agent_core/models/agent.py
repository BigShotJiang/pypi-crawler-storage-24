"""
에이전트 API Pydantic 모델

계획 생성, 개선, 재계획, 상태 검증을 위한 모델.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import ErrorInfo, LLMConfig, NotebookContext, ToolCall

# ============ 계획 요청/응답 ============


class PlanStep(BaseModel):
    """실행 계획의 단일 단계"""

    stepNumber: int = Field(description="단계 번호 (1부터 시작)")
    description: str = Field(description="사람이 읽을 수 있는 단계 설명")
    toolCalls: List[ToolCall] = Field(
        default_factory=list, description="이 단계에서 실행할 도구들"
    )
    expectedOutput: Optional[str] = Field(default=None, description="예상 출력 설명")


class ExecutionPlan(BaseModel):
    """에이전트가 생성한 실행 계획"""

    goal: str = Field(description="전체 목표 설명")
    totalSteps: int = Field(description="총 단계 수")
    steps: List[PlanStep] = Field(description="순서대로 정렬된 실행 단계 목록")


class PlanRequest(BaseModel):
    """계획 생성 요청 본문"""

    request: str = Field(description="사용자의 자연어 요청")
    notebookContext: NotebookContext = Field(
        default_factory=NotebookContext, description="현재 노트북 상태"
    )
    llmConfig: Optional[LLMConfig] = Field(
        default=None, description="API 키가 포함된 LLM 설정 (클라이언트 제공)"
    )


class PlanResponse(BaseModel):
    """계획 생성 응답 본문"""

    plan: ExecutionPlan = Field(description="생성된 실행 계획")
    reasoning: str = Field(default="", description="에이전트의 추론 설명")


# ============ 개선 요청/응답 ============


class RefineRequest(BaseModel):
    """코드 개선 요청 본문"""

    step: Dict[str, Any] = Field(description="개선 중인 현재 단계")
    error: ErrorInfo = Field(description="개선을 트리거한 오류")
    attempt: int = Field(default=1, description="현재 시도 횟수")
    previousCode: Optional[str] = Field(default=None, description="이전에 실행한 코드")
    llmConfig: Optional[LLMConfig] = Field(
        default=None, description="API 키가 포함된 LLM 설정 (클라이언트 제공)"
    )


class RefineResponse(BaseModel):
    """코드 개선 응답 본문"""

    toolCalls: List[ToolCall] = Field(description="개선된 도구 호출")
    reasoning: str = Field(default="", description="개선 추론")


# ============ 재계획 요청/응답 ============


class ReplanRequest(BaseModel):
    """재계획 요청 본문"""

    originalPlan: ExecutionPlan = Field(description="원래 실행 계획")
    currentStepIndex: int = Field(description="실패한 단계의 인덱스")
    error: ErrorInfo = Field(description="재계획을 트리거한 오류")
    executionHistory: List[Dict[str, Any]] = Field(
        default_factory=list, description="실행된 단계 이력"
    )
    # LLM 폴백 관련 필드
    previousAttempts: int = Field(
        default=0, description="동일 오류에 대한 이전 시도 횟수"
    )
    previousCodes: List[str] = Field(
        default_factory=list, description="이전에 시도한 코드들"
    )
    useLlmFallback: bool = Field(
        default=True,
        description="패턴 매칭 실패시 LLM 폴백 사용 여부",
    )


class ReplanResponse(BaseModel):
    """재계획 응답 본문"""

    decision: str = Field(
        description="재계획 결정 유형 (refine/insert_steps/replace_step/replan_remaining)"
    )
    analysis: Dict[str, Any] = Field(description="오류 분석 세부사항")
    reasoning: str = Field(default="", description="재계획 추론")
    changes: Dict[str, Any] = Field(default_factory=dict, description="제안된 변경사항")
    usedLlm: bool = Field(
        default=False, description="오류 분석에 LLM 폴백을 사용했는지 여부"
    )
    confidence: float = Field(
        default=1.0,
        description="분석 신뢰도 (패턴 매칭은 1.0, LLM은 0.0-1.0)",
    )


# ============ 반성 요청/응답 ============


class ReflectionEvaluation(BaseModel):
    """반성 평가 결과"""

    checkpoint_passed: bool = Field(description="체크포인트 기준 통과 여부")
    output_matches_expected: bool = Field(
        description="출력이 예상 결과와 일치하는지 여부"
    )
    confidence_score: float = Field(description="신뢰도 점수 (0.0-1.0)")


class ReflectionAnalysis(BaseModel):
    """반성 분석 세부사항"""

    success_factors: List[str] = Field(
        default_factory=list, description="성공에 기여한 요소들"
    )
    failure_factors: List[str] = Field(
        default_factory=list, description="실패를 야기한 요소들"
    )
    unexpected_outcomes: List[str] = Field(
        default_factory=list, description="예상치 못한 결과들"
    )


class ReflectionImpact(BaseModel):
    """나머지 단계에 대한 영향"""

    affected_steps: List[int] = Field(
        default_factory=list, description="영향받는 단계 번호들"
    )
    severity: str = Field(description="영향 심각도: none, minor, major, critical")
    description: str = Field(description="영향 설명")


class ReflectionAdjustment(BaseModel):
    """권장 조정사항"""

    step_number: int = Field(description="조정할 단계 번호")
    change_type: str = Field(
        description="변경 유형: modify_code, add_step, remove_step, change_approach"
    )
    description: str = Field(description="조정 설명")
    new_content: Optional[str] = Field(
        default=None, description="해당되는 경우 새 콘텐츠"
    )


class ReflectionRecommendations(BaseModel):
    """반성 권장사항"""

    action: str = Field(description="권장 작업: continue, adjust, retry, replan")
    adjustments: List[ReflectionAdjustment] = Field(
        default_factory=list, description="구체적인 조정사항들"
    )
    reasoning: str = Field(description="권장사항에 대한 추론")


class ReflectionResult(BaseModel):
    """완전한 반성 결과"""

    evaluation: ReflectionEvaluation = Field(description="평가 결과")
    analysis: ReflectionAnalysis = Field(description="분석 세부사항")
    impact_on_remaining: ReflectionImpact = Field(description="나머지 단계에 대한 영향")
    recommendations: ReflectionRecommendations = Field(description="권장사항")


class ReflectRequest(BaseModel):
    """단계 반성 요청 본문"""

    stepNumber: int = Field(description="반성 대상 단계 번호")
    stepDescription: str = Field(description="단계 설명")
    executedCode: str = Field(description="실행된 코드")
    executionStatus: str = Field(description="실행 상태 (success/error/warning)")
    executionOutput: str = Field(description="실행 출력")
    errorMessage: Optional[str] = Field(
        default=None, description="있는 경우 오류 메시지"
    )
    expectedOutcome: Optional[str] = Field(default=None, description="예상 결과 설명")
    validationCriteria: Optional[List[str]] = Field(
        default=None, description="검증 기준"
    )
    remainingSteps: Optional[List[Dict[str, Any]]] = Field(
        default=None, description="계획의 나머지 단계들"
    )


class ReflectResponse(BaseModel):
    """단계 반성 응답 본문"""

    reflection: ReflectionResult = Field(description="반성 분석 결과")


# ============ 상태 검증 ============


class VerifyStateRequest(BaseModel):
    """상태 검증 요청 본문"""

    stepIndex: int = Field(description="검증할 단계 인덱스")
    expectedChanges: Dict[str, Any] = Field(description="단계에서 예상되는 상태 변경")
    actualOutput: str = Field(description="실행의 실제 출력")
    executionResult: Dict[str, Any] = Field(description="전체 실행 결과")


class VerifyStateResponse(BaseModel):
    """상태 검증 응답 본문"""

    verified: bool = Field(description="상태가 예상과 일치하는지 여부")
    discrepancies: List[str] = Field(
        default_factory=list, description="발견된 불일치 목록"
    )
    confidence: float = Field(default=0.0, description="신뢰도 점수 (0.0-1.0)")


# ============ 실행 보고 ============


class ReportExecutionRequest(BaseModel):
    """도구 실행 결과 보고 요청 본문"""

    stepId: str = Field(description="단계 식별자")
    result: Dict[str, Any] = Field(description="실행 결과 세부사항")


class ReportExecutionResponse(BaseModel):
    """실행 보고 응답 본문"""

    acknowledged: bool = Field(default=True)
    nextAction: Optional[str] = Field(default=None, description="제안된 다음 작업")


# ============ 코드 검증 ============


class ValidationIssue(BaseModel):
    """코드 검증 이슈 (구문, 미정의 이름 등)"""

    severity: str = Field(description="이슈 심각도: error, warning, info")
    category: str = Field(
        description="이슈 카테고리: syntax, undefined_name, unused_import, unused_variable, redefined, import_error, type_error"
    )
    message: str = Field(description="이슈 설명")
    line: Optional[int] = Field(default=None, description="줄 번호")
    column: Optional[int] = Field(default=None, description="열 번호")
    code_snippet: Optional[str] = Field(default=None, description="코드 스니펫")


class DependencyInfo(BaseModel):
    """코드 의존성 정보"""

    imports: List[str] = Field(default_factory=list, description="import 문")
    from_imports: Dict[str, List[str]] = Field(
        default_factory=dict, description="from-import 문"
    )
    defined_names: List[str] = Field(
        default_factory=list, description="정의된 변수/함수 이름"
    )
    used_names: List[str] = Field(
        default_factory=list, description="사용된 변수/함수 이름"
    )
    undefined_names: List[str] = Field(
        default_factory=list, description="미정의 이름 (잠재적 오류)"
    )


class ValidateRequest(BaseModel):
    """코드 검증 요청 본문"""

    code: str = Field(description="검증할 코드")
    notebookContext: Optional[NotebookContext] = Field(
        default=None, description="현재 노트북 컨텍스트 (변수/import 추적용)"
    )


class ValidateResponse(BaseModel):
    """코드 검증 응답 본문"""

    valid: bool = Field(description="코드가 유효한지 여부 (오류 없음)")
    issues: List[ValidationIssue] = Field(default_factory=list, description="검증 이슈")
    dependencies: Optional[DependencyInfo] = Field(
        default=None, description="코드 의존성"
    )
    hasErrors: bool = Field(description="오류가 있는지 여부")
    hasWarnings: bool = Field(description="경고가 있는지 여부")
    summary: str = Field(description="검증 요약")
