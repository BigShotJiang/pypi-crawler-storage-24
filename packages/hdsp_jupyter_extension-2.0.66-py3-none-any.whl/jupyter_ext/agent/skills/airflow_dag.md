---
name: airflow-dag
description: MWAA Airflow DAG 개발 가이드. DAG 구조, Operator, TaskFlow, 테스트, 검증.
---

# Airflow DAG Development Guide

MWAA/Airflow DAG 개발 시 참고하는 가이드입니다.

## DAG 기본 구조 템플릿

```python
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "data-team",
    "depends_on_past": False,
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="example_dag",
    default_args=default_args,
    description="DAG 설명",
    schedule_interval="@daily",  # or cron: "0 9 * * *"
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["example"],
) as dag:

    task_1 = PythonOperator(
        task_id="extract",
        python_callable=extract_function,
    )

    task_2 = PythonOperator(
        task_id="transform",
        python_callable=transform_function,
    )

    task_3 = PythonOperator(
        task_id="load",
        python_callable=load_function,
    )

    task_1 >> task_2 >> task_3
```

## TaskFlow API (@task 데코레이터)

```python
from airflow.decorators import dag, task

@dag(
    schedule_interval="@daily",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["taskflow"],
)
def taskflow_example():

    @task
    def extract():
        return {"data": [1, 2, 3]}

    @task
    def transform(raw: dict):
        return {"transformed": [x * 2 for x in raw["data"]]}

    @task
    def load(transformed: dict):
        print(f"Loaded: {transformed}")

    raw = extract()
    transformed = transform(raw)
    load(transformed)

taskflow_example()
```

## 주요 Operator

| Operator | 용도 | 예시 |
|----------|------|------|
| `PythonOperator` | Python 함수 실행 | `python_callable=func` |
| `BashOperator` | Shell 명령 실행 | `bash_command="echo hello"` |
| `S3KeySensor` | S3 파일 대기 | `bucket_key="s3://bucket/key"` |
| `GlueCrawlerOperator` | Glue Crawler 실행 | `config={"Name": "crawler"}` |
| `AthenaOperator` | Athena 쿼리 실행 | `query="SELECT ..."` |
| `EmrAddStepsOperator` | EMR Step 추가 | `steps=[step_config]` |

## XCom 패턴

```python
# Push (자동 - return 값)
@task
def produce():
    return {"key": "value"}

# Pull (자동 - TaskFlow)
@task
def consume(data):
    print(data["key"])

# Pull (수동 - PythonOperator)
def my_func(**context):
    value = context["ti"].xcom_pull(task_ids="produce")
```

## Connection / Variable 패턴

```python
from airflow.hooks.base import BaseHook
from airflow.models import Variable

# Connection
conn = BaseHook.get_connection("my_conn_id")
host, port = conn.host, conn.port

# Variable
config = Variable.get("my_config", deserialize_json=True)
```

## DAG 검증 명령

```bash
# DAG 파싱 검증 (import 에러 체크)
python -c "
from airflow.models import DagBag
bag = DagBag(dag_folder='.', include_examples=False)
if bag.import_errors:
    for f, err in bag.import_errors.items():
        print(f'ERROR in {f}: {err}')
else:
    print(f'OK: {len(bag.dags)} DAGs loaded')
    for dag_id in bag.dags:
        print(f'  - {dag_id}')
"
```

## pytest 테스트 패턴

```python
import pytest
from airflow.models import DagBag

@pytest.fixture(scope="module")
def dagbag():
    return DagBag(dag_folder="dags/", include_examples=False)

def test_dag_loaded(dagbag):
    assert "my_dag_id" in dagbag.dags
    assert len(dagbag.import_errors) == 0

def test_dag_structure(dagbag):
    dag = dagbag.dags["my_dag_id"]
    assert len(dag.tasks) >= 3
    # task dependency 검증
    extract = dag.get_task("extract")
    transform = dag.get_task("transform")
    assert transform.upstream_task_ids == {"extract"}

def test_task_callable(dagbag):
    dag = dagbag.dags["my_dag_id"]
    task = dag.get_task("extract")
    assert task.python_callable is not None
```

## 안티패턴

| 안티패턴 | 문제 | 올바른 방법 |
|----------|------|------------|
| Top-level DB 쿼리 | DAG 파싱마다 쿼리 실행 | 함수 안에서 쿼리 실행 |
| Heavy import at top | 파싱 시간 증가 | `PythonOperator` 내에서 import |
| `Variable.get()` at top | 매 파싱마다 메타DB 조회 | `template_fields` 또는 함수 내 호출 |
| 하드코딩된 날짜 | 유연성 부족 | `{{ ds }}`, `{{ execution_date }}` 사용 |
| `catchup=True` + 긴 기간 | 대량 백필 발생 | `catchup=False` 또는 제한된 기간 |
