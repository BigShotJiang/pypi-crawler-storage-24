"""Mermaid Fix Middleware — deterministic Mermaid syntax repair on LLM output.

Follows the same pattern as OutputGuardrailMiddleware (awrap_model_call)
and AutoFixMiddleware (awrap_tool_call + request.override).
"""

from __future__ import annotations

import datetime
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from langchain_core.messages import AIMessage

from langchain.agents.middleware.types import (
    AgentMiddleware,
    ModelCallResult,
    ModelRequest,
    ModelResponse,
)
from langgraph.prebuilt.tool_node import ToolCallRequest

from .mermaid_fixer import fix_mermaid_blocks

# ---------------------------------------------------------------------------
# Debug logging (same pattern as guardrail/continuation middlewares)
# ---------------------------------------------------------------------------

_LOGS_DIR = str(Path(__file__).resolve().parents[3] / "logs")
_DEBUG_LOG = str(Path(_LOGS_DIR) / "agent_debug.log")
Path(_LOGS_DIR).mkdir(parents=True, exist_ok=True)

_MERMAID_MARKER = "```mermaid"


def _dbg(msg: str) -> None:
    ts = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
    with open(_DEBUG_LOG, "a") as f:
        f.write(f"[{ts}] MERMAID: {msg}\n")


# ---------------------------------------------------------------------------
# Helper: extract AIMessage from response (same as guardrail_middleware)
# ---------------------------------------------------------------------------


def _extract_ai_message(response: Any) -> AIMessage | None:
    if isinstance(response, AIMessage):
        return response
    if hasattr(response, "message") and isinstance(response.message, AIMessage):
        return response.message
    if hasattr(response, "messages"):
        for msg in reversed(response.messages):
            if isinstance(msg, AIMessage):
                return msg
    return None


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------


class MermaidFixMiddleware(AgentMiddleware):
    """Fix Mermaid syntax errors in LLM text responses and tool calls."""

    # -- Hook 1: LLM text response + tool_calls with mermaid content ---------

    def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> Awaitable[ModelCallResult]:
        return self._impl_model(request, handler)

    async def _impl_model(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        response = await handler(request)
        ai_msg = _extract_ai_message(response)
        if ai_msg is None:
            return response

        # Fix mermaid in text content
        if isinstance(ai_msg.content, str) and _MERMAID_MARKER in ai_msg.content:
            original = ai_msg.content
            ai_msg.content = fix_mermaid_blocks(original)
            if ai_msg.content != original:
                _dbg("fixed mermaid in text content")

        # Fix mermaid in jupyter_markdown tool_calls
        tool_calls = getattr(ai_msg, "tool_calls", None)
        if tool_calls:
            for tc in tool_calls:
                if tc.get("name") != "jupyter_markdown":
                    continue
                args = tc.get("args", {})
                content = args.get("content", "")
                if isinstance(content, str) and _MERMAID_MARKER in content:
                    args["content"] = fix_mermaid_blocks(content)
                    if args["content"] != content:
                        _dbg("fixed mermaid in jupyter_markdown tool_call")

        return response

    # -- Hook 2: jupyter_markdown tool execution -----------------------------

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[Any]],
    ) -> Any:
        tool_name = request.tool_call.get("name", "")
        if tool_name != "jupyter_markdown":
            return await handler(request)

        args = request.tool_call.get("args", {})
        content = args.get("content", "")

        if isinstance(content, str) and _MERMAID_MARKER in content:
            fixed = fix_mermaid_blocks(content)
            if fixed != content:
                modified_call = {
                    **request.tool_call,
                    "args": {**args, "content": fixed},
                }
                request = request.override(tool_call=modified_call)
                _dbg("fixed mermaid in jupyter_markdown tool execution")

        return await handler(request)
