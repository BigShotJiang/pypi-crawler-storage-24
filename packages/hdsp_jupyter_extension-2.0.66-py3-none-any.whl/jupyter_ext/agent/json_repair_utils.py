"""JSON 자동 복구 유틸리티.

LLM이 반환하는 깨진 JSON을 자동으로 수정.
chat-mode-enhancement 브랜치의 repair 로직 포팅.
"""

import json
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


def safe_parse_json(text: str) -> Optional[Any]:
    """JSON 파싱 시도. 실패하면 json-repair로 복구 후 재시도."""
    if not isinstance(text, str) or not text.strip():
        return None
    text = text.strip()
    # 1차: 직접 파싱
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass
    # 2차: json-repair로 복구
    try:
        from json_repair import repair_json

        repaired = repair_json(text, return_objects=True)
        if repaired is not None:
            logger.info("Repaired malformed JSON via json-repair")
            return repaired
    except Exception as e:
        logger.debug("json-repair failed: %s", e)
    return None


def safe_json_dumps(obj: Any, **kwargs) -> str:
    """json.dumps의 안전한 래퍼. ToolMessage 등 직렬화 불가 객체 처리."""
    kwargs.setdefault("ensure_ascii", False)
    kwargs.setdefault("default", str)
    try:
        return json.dumps(obj, **kwargs)
    except (TypeError, ValueError):
        return json.dumps(str(obj))


def ensure_str(value: Any) -> str:
    """ToolMessage 등 비-문자열 값을 안전하게 str로 변환."""
    if isinstance(value, str):
        return value
    if hasattr(value, "content"):
        content = value.content
        return content if isinstance(content, str) else str(content)
    return str(value)
