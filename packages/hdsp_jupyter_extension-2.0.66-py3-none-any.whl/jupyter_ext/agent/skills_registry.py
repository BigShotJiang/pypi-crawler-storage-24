"""DS 스킬 레지스트리.

데이터 사이언스 워크플로우 템플릿 정의.
키워드 매칭으로 관련 스킬이 자동 주입됨.
"""

from __future__ import annotations

from typing import Any

SKILLS_REGISTRY: dict[str, dict[str, Any]] = {
    # -----------------------------------------------------------------------
    # 기존 5개 스킬
    # -----------------------------------------------------------------------
    "comprehensive_eda": {
        "keywords": [
            "eda",
            "탐색적 데이터 분석",
            "exploratory",
            "데이터 탐색",
            "데이터 분석",
        ],
        "template": """## EDA Workflow Template
1. **Data Overview**: `df.shape`, `df.info()`, `df.describe()`, `df.dtypes`
2. **Missing Values**: `df.isnull().sum()`, visualize with `msno.matrix(df)`
3. **Distributions**: Histograms for numerical, value_counts for categorical
4. **Correlations**: `df.corr()` heatmap with `sns.heatmap()`
5. **Outliers**: Box plots, IQR method, z-score analysis
6. **Target Analysis**: Distribution, class balance, relationship with features
""",
    },
    "model_comparison": {
        "keywords": [
            "모델 비교",
            "model comparison",
            "어떤 모델",
            "best model",
            "모델 선택",
        ],
        "template": """## Model Comparison Template
1. **Baseline**: Simple model (DummyClassifier/DummyRegressor)
2. **Candidates**: Train LogisticRegression, RandomForest, GradientBoosting, etc.
3. **Cross-Validation**: `cross_val_score()` with appropriate cv strategy
4. **Metrics Table**: Compare accuracy, F1, precision, recall (or RMSE, MAE, R²)
5. **Statistical Test**: Paired t-test or Wilcoxon on CV scores
6. **Selection**: Best model → hyperparameter tuning with GridSearchCV/Optuna
""",
    },
    "feature_importance_analysis": {
        "keywords": ["feature importance", "특성 중요도", "변수 중요도", "어떤 변수"],
        "template": """## Feature Importance Template
1. **Permutation Importance**: `sklearn.inspection.permutation_importance()`
2. **Tree-based**: `model.feature_importances_` for RF/GBM
3. **SHAP Values**: `shap.TreeExplainer()` → `shap.summary_plot()`
4. **Correlation-based**: Feature-target correlation ranking
5. **Visualization**: Bar plot of top-N features sorted by importance
""",
    },
    "data_cleaning_pipeline": {
        "keywords": [
            "데이터 정제",
            "data cleaning",
            "전처리",
            "preprocessing",
            "결측값",
        ],
        "template": """## Data Cleaning Pipeline Template
1. **Duplicate Removal**: `df.drop_duplicates()`
2. **Missing Values**: Strategy per column (drop/impute mean/median/mode/KNN)
3. **Type Conversion**: Ensure correct dtypes (numeric, datetime, categorical)
4. **Outlier Treatment**: Cap/floor, remove, or transform (log, sqrt)
5. **Encoding**: Label encoding for ordinal, One-hot for nominal
6. **Scaling**: StandardScaler or MinMaxScaler for numerical features
7. **Validation**: `df.info()`, `df.isnull().sum()`, shape check
""",
    },
    "classification_evaluation": {
        "keywords": ["classification", "분류", "confusion matrix", "혼동행렬", "roc"],
        "template": """## Classification Evaluation Template
1. **Confusion Matrix**: `confusion_matrix()` → `ConfusionMatrixDisplay`
2. **Classification Report**: `classification_report()` (precision, recall, F1)
3. **ROC Curve**: `roc_curve()` → `RocCurveDisplay` with AUC score
4. **Precision-Recall Curve**: For imbalanced datasets
5. **Cross-Validation**: Stratified K-Fold to ensure class balance
6. **Error Analysis**: Examine misclassified samples for patterns
""",
    },
    # -----------------------------------------------------------------------
    # 신규 12개 스킬
    # -----------------------------------------------------------------------
    "regression_evaluation": {
        "keywords": [
            "regression",
            "rmse",
            "mae",
            "r2 score",
            "회귀",
            "잔차",
        ],
        "template": """## Regression Evaluation Template
1. **Predictions**: `y_pred = model.predict(X_test)`
2. **Metrics**: RMSE, MAE, R², MAPE — `mean_squared_error()`, `mean_absolute_error()`, `r2_score()`
3. **Residual Plot**: `residuals = y_test - y_pred` → scatter plot vs predicted
4. **Residual Distribution**: Histogram / Q-Q plot for normality check
5. **Actual vs Predicted**: 45-degree line scatter plot
6. **Cross-Validation**: `cross_val_score(scoring='neg_root_mean_squared_error')`
7. **Feature Coefficients**: For linear models, inspect `model.coef_`
""",
    },
    "time_series_analysis": {
        "keywords": [
            "time series",
            "arima",
            "forecast",
            "prophet",
            "시계열",
            "예측 모델",
        ],
        "template": """## Time Series Analysis Template
1. **Visualization**: Line plot with datetime index, check trend & seasonality
2. **Stationarity Test**: ADF test (`adfuller()`), KPSS test
3. **Decomposition**: `seasonal_decompose()` → trend, seasonal, residual
4. **ACF/PACF**: `plot_acf()`, `plot_pacf()` for lag analysis
5. **Modeling**: ARIMA/SARIMA (`pmdarima.auto_arima()`), Prophet, or Exponential Smoothing
6. **Forecast**: Generate future predictions with confidence intervals
7. **Evaluation**: RMSE, MAE, MAPE on hold-out test set
8. **Visualization**: Plot actual vs predicted with forecast horizon
""",
    },
    "clustering_analysis": {
        "keywords": [
            "clustering",
            "k-means",
            "dbscan",
            "silhouette",
            "군집",
            "클러스터링",
        ],
        "template": """## Clustering Analysis Template
1. **Data Scaling**: `StandardScaler()` — critical for distance-based methods
2. **Optimal K**: Elbow method (`inertia_`) + Silhouette score (`silhouette_score()`)
3. **Algorithm Selection**: K-Means, DBSCAN, Hierarchical — based on data shape
4. **Fit & Predict**: `labels = model.fit_predict(X_scaled)`
5. **Evaluation**: Silhouette, Calinski-Harabasz, Davies-Bouldin scores
6. **Visualization**: PCA/t-SNE 2D scatter colored by cluster labels
7. **Cluster Profiling**: Aggregate stats per cluster, identify distinguishing features
""",
    },
    "hypothesis_testing": {
        "keywords": [
            "hypothesis",
            "t-test",
            "anova",
            "p-value",
            "a/b test",
            "가설검정",
        ],
        "template": """## Hypothesis Testing Template
1. **Formulate Hypotheses**: H₀ (null) and H₁ (alternative), significance level α
2. **Check Assumptions**: Normality (Shapiro-Wilk), equal variance (Levene's test)
3. **Select Test**: t-test (2 groups), ANOVA (3+ groups), chi-squared (categorical), Mann-Whitney (non-parametric)
4. **Execute**: `scipy.stats.ttest_ind()`, `f_oneway()`, `chi2_contingency()`
5. **Interpret**: p-value vs α, effect size (Cohen's d), confidence interval
6. **Visualize**: Box plots, violin plots, or bar charts with error bars
7. **Report**: State conclusion in context, mention limitations
""",
    },
    "imbalanced_data_handling": {
        "keywords": [
            "imbalanced",
            "smote",
            "oversampling",
            "undersampling",
            "class weight",
            "불균형",
        ],
        "template": """## Imbalanced Data Handling Template
1. **Diagnose**: `df[target].value_counts(normalize=True)` — check class ratios
2. **Baseline**: Train model without balancing, measure recall for minority class
3. **Resampling**: SMOTE (`imblearn.over_sampling.SMOTE`), RandomUnderSampler, or SMOTEENN
4. **Class Weights**: `model = RandomForestClassifier(class_weight='balanced')`
5. **Threshold Tuning**: Adjust decision threshold using precision-recall curve
6. **Metrics**: Use F1, balanced accuracy, PR-AUC instead of accuracy
7. **Evaluation**: Stratified K-Fold CV to preserve class distribution
""",
    },
    "dimensionality_reduction": {
        "keywords": [
            "dimensionality reduction",
            "pca",
            "t-sne",
            "umap",
            "차원축소",
        ],
        "template": """## Dimensionality Reduction Template
1. **Scaling**: `StandardScaler()` — required before PCA/t-SNE/UMAP
2. **PCA**: `PCA(n_components=0.95)` — retain 95% variance, inspect explained variance ratio
3. **Scree Plot**: Bar chart of explained variance per component
4. **t-SNE**: `TSNE(perplexity=30)` for 2D visualization of high-dim data
5. **UMAP**: `umap.UMAP(n_neighbors=15)` for faster, more scalable alternative
6. **Visualization**: 2D scatter plot colored by target or cluster labels
7. **Feature Loadings**: For PCA, inspect `pca.components_` to understand component meaning
""",
    },
    "anomaly_detection": {
        "keywords": [
            "anomaly detection",
            "isolation forest",
            "outlier detection",
            "이상탐지",
            "이상치 탐지",
        ],
        "template": """## Anomaly Detection Template
1. **EDA**: Distribution plots, box plots to visually identify outliers
2. **Statistical Methods**: Z-score (|z| > 3), IQR (< Q1-1.5*IQR or > Q3+1.5*IQR)
3. **Isolation Forest**: `IsolationForest(contamination=0.05).fit_predict(X)`
4. **Local Outlier Factor**: `LocalOutlierFactor(n_neighbors=20)`
5. **Evaluation**: If labels available — precision, recall; otherwise visual inspection
6. **Visualization**: Scatter plot highlighting anomalies, time-series anomaly overlay
7. **Action**: Remove, cap, or flag anomalies based on domain context
""",
    },
    "hyperparameter_tuning": {
        "keywords": [
            "hyperparameter",
            "optuna",
            "gridsearch",
            "grid search",
            "하이퍼파라미터",
            "튜닝",
        ],
        "template": """## Hyperparameter Tuning Template
1. **Define Search Space**: List hyperparameters and their ranges
2. **GridSearchCV**: `GridSearchCV(estimator, param_grid, cv=5, scoring='f1')`
3. **RandomizedSearchCV**: For large search spaces, `RandomizedSearchCV(n_iter=100)`
4. **Optuna**: `optuna.create_study()` → `study.optimize(objective, n_trials=100)`
5. **Best Params**: `search.best_params_`, `study.best_trial.params`
6. **Retrain**: Fit final model with best params on full training set
7. **Validate**: Evaluate on hold-out test set, compare with baseline
""",
    },
    "model_explainability": {
        "keywords": [
            "shap",
            "lime",
            "explainability",
            "interpretability",
            "모델 해석",
            "설명 가능",
        ],
        "template": """## Model Explainability Template
1. **SHAP Setup**: `explainer = shap.TreeExplainer(model)` or `shap.KernelExplainer`
2. **SHAP Values**: `shap_values = explainer.shap_values(X_test)`
3. **Summary Plot**: `shap.summary_plot(shap_values, X_test)` — global feature impact
4. **Dependence Plot**: `shap.dependence_plot("feature", shap_values, X_test)`
5. **LIME**: `lime.lime_tabular.LimeTabularExplainer` for local instance explanation
6. **Force Plot**: `shap.force_plot()` for single prediction breakdown
7. **Report**: Summarize top drivers, interaction effects, and model behavior
""",
    },
    "text_preprocessing": {
        "keywords": [
            "tokenization",
            "tf-idf",
            "nlp",
            "vectorization",
            "텍스트 전처리",
            "자연어",
        ],
        "template": """## Text Preprocessing Template
1. **Cleaning**: Lowercase, remove HTML/URLs/special chars, strip whitespace
2. **Tokenization**: `nltk.word_tokenize()` or `spacy.load('en')` pipeline
3. **Stopword Removal**: `nltk.corpus.stopwords`, domain-specific additions
4. **Lemmatization/Stemming**: `WordNetLemmatizer()` or `PorterStemmer()`
5. **Vectorization**: `TfidfVectorizer(max_features=5000)` or `CountVectorizer`
6. **Embeddings**: Word2Vec, FastText, or Sentence-BERT for semantic vectors
7. **Validation**: Check vocabulary size, sparsity, sample transformed texts
""",
    },
    "data_quality_report": {
        "keywords": [
            "data quality",
            "profiling",
            "completeness",
            "데이터 품질",
            "프로파일링",
            "데이터 검증",
        ],
        "template": """## Data Quality Report Template
1. **Shape & Types**: `df.shape`, `df.dtypes`, `df.info()`
2. **Missing Values**: Per-column null counts and percentages, missingness patterns
3. **Duplicates**: `df.duplicated().sum()`, identify duplicate columns
4. **Cardinality**: Unique counts per column, detect near-constant features
5. **Value Ranges**: Min/max/mean/std for numerics, frequency tables for categoricals
6. **Consistency Checks**: Data type mismatches, negative values in positive-only fields
7. **Automated Profiling**: `ydata_profiling.ProfileReport(df)` for full HTML report
8. **Summary**: Data readiness score, list of issues requiring action
""",
    },
    "experiment_tracking": {
        "keywords": [
            "mlflow",
            "wandb",
            "experiment tracking",
            "run logging",
            "실험 추적",
            "모델 관리",
        ],
        "template": """## Experiment Tracking Template
1. **Setup**: `mlflow.set_tracking_uri()` / `wandb.init(project='name')`
2. **Log Parameters**: `mlflow.log_params(params)` / `wandb.config.update(params)`
3. **Log Metrics**: `mlflow.log_metric('f1', score)` / `wandb.log({'f1': score})`
4. **Log Artifacts**: Save model, plots, data samples as artifacts
5. **Model Registry**: `mlflow.sklearn.log_model()` for versioned model storage
6. **Compare Runs**: Use UI dashboard to compare experiments side-by-side
7. **Best Run Selection**: Query best run by metric, load for deployment
8. **Reproducibility**: Log git hash, environment, random seeds
""",
    },
    # -----------------------------------------------------------------------
    # 도메인 전문가 스킬 (Airflow, EMR, Lambda, Spring)
    # -----------------------------------------------------------------------
    "airflow_dag_development": {
        "keywords": [
            "airflow",
            "dag",
            "operator",
            "taskflow",
            "에어플로우",
            "mwaa",
            "워크플로우 오케스트레이션",
        ],
        "template": """## Airflow DAG Development Workflow
1. **Structure**: default_args, DAG context, task dependencies
2. **Validate**: python -c "from airflow.models import DagBag; ..."
3. **Test**: pytest with DagBag loading
4. **Deploy**: Copy to $AIRFLOW_HOME/dags/
""",
    },
    "emr_script_development": {
        "keywords": [
            "emr",
            "pyspark",
            "spark-submit",
            "emr step",
            "spark job",
            "spark 스크립트",
        ],
        "template": """## EMR Script Development Workflow
1. **Script**: PySpark with argparse, SparkSession, S3 I/O
2. **Local Test**: spark-submit --master local[*]
3. **Unit Test**: pytest with small local data
""",
    },
    "lambda_function_development": {
        "keywords": [
            "lambda",
            "serverless",
            "sam",
            "handler",
            "api gateway",
            "람다",
        ],
        "template": """## Lambda Development Workflow
1. **Handler**: def handler(event, context)
2. **SAM**: template.yaml with Resources
3. **Local Test**: sam local invoke -e event.json
4. **Unit Test**: pytest with mocked event/context
""",
    },
    "spring_java_development": {
        "keywords": [
            "spring",
            "spring boot",
            "java",
            "maven",
            "gradle",
            "junit",
            "controller",
            "스프링",
            "자바",
            "jdk",
            "jvm",
            "pom.xml",
            "pom",
            "mvn",
            "jar",
            "war",
            "multi-module",
            "멀티모듈",
            "gc",
            "heap",
            "jvm 옵션",
            "jvm option",
            "java record",
            "sealed class",
        ],
        "template": """## Java & Spring Development Workflow
1. **Java**: Records, Sealed Classes, Streams, CompletableFuture
2. **Spring Boot**: Controller -> Service -> Repository -> Entity
3. **Maven**: mvn clean compile / mvn test / profiles / multi-module
4. **JDK/JVM**: -Xmx, GC options, compiler settings
5. **Test**: JUnit 5 + Mockito
""",
    },
}
