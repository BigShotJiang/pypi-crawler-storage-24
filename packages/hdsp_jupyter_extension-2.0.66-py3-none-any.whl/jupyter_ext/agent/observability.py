"""ObservabilityMiddleware — 구조화된 JSONL 이벤트 로깅.

모든 model/tool call을 래핑하여 타이밍 + 메타데이터를
extensions/logs/agent_structured.jsonl에 기록.
"""

from __future__ import annotations

import datetime
import json
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Optional

from hdsp_agent_core.core.exceptions import AgentError

from langchain_core.messages import AIMessage

from langchain.agents.middleware.types import (
    AgentMiddleware,
    ModelCallResult,
    ModelRequest,
    ModelResponse,
)

# 로그 디렉토리: continuation_middleware.py와 동일 위치
_LOGS_DIR = Path(__file__).resolve().parents[3] / "logs"
_STRUCTURED_LOG = _LOGS_DIR / "agent_structured.jsonl"
_LOGS_DIR.mkdir(parents=True, exist_ok=True)


def _write_structured_event(event: dict) -> None:
    """JSON 라인을 agent_structured.jsonl에 기록. ts 자동 추가."""
    event["ts"] = datetime.datetime.now().isoformat(timespec="seconds")
    with open(_STRUCTURED_LOG, "a") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _extract_ai_message(response: Any) -> AIMessage | None:
    """ModelResponse/ModelCallResult에서 AIMessage 추출."""
    if isinstance(response, AIMessage):
        return response
    if hasattr(response, "message") and isinstance(response.message, AIMessage):
        return response.message
    if hasattr(response, "messages"):
        for msg in reversed(response.messages):
            if isinstance(msg, AIMessage):
                return msg
    return None


class ObservabilityMiddleware(AgentMiddleware):
    """model/tool call 타이밍 + 메타데이터를 JSONL로 기록."""

    def __init__(
        self,
        session_id: str = "",
        user_identity: Optional[dict[str, str]] = None,
    ):
        self._session_id = session_id
        self._user_identity = user_identity or {}
        self._model_call_count = 0
        self._tool_call_count = 0

    def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> Awaitable[ModelCallResult]:
        return self._wrap_model(request, handler)

    async def _wrap_model(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        self._model_call_count += 1
        call_num = self._model_call_count
        input_msg_count = len(request.messages) if request.messages else 0

        t0 = time.monotonic()
        status = "ok"
        output_tool_calls = 0
        try:
            response = await handler(request)
            ai_msg = _extract_ai_message(response)
            if ai_msg and hasattr(ai_msg, "tool_calls") and ai_msg.tool_calls:
                output_tool_calls = len(ai_msg.tool_calls)
            return response
        except Exception as exc:
            status = (
                f"error:{exc.error_type}"
                if isinstance(exc, AgentError)
                else f"error:{type(exc).__name__}"
            )
            raise
        finally:
            elapsed_ms = (time.monotonic() - t0) * 1000
            _write_structured_event(
                {
                    "event": "model_call",
                    "session_id": self._session_id,
                    **self._user_identity,
                    "call_num": call_num,
                    "input_msg_count": input_msg_count,
                    "output_tool_calls": output_tool_calls,
                    "elapsed_ms": round(elapsed_ms, 1),
                    "status": status,
                }
            )

    async def awrap_tool_call(self, request, handler):
        self._tool_call_count += 1
        call_num = self._tool_call_count
        tool_name = request.tool_call.get("name", "unknown")

        t0 = time.monotonic()
        status = "ok"
        error_msg = None
        try:
            result = await handler(request)
            return result
        except Exception as exc:
            status = (
                f"error:{exc.error_type}"
                if isinstance(exc, AgentError)
                else f"error:{type(exc).__name__}"
            )
            error_msg = str(exc)[:200]
            raise
        finally:
            elapsed_ms = (time.monotonic() - t0) * 1000
            ev: dict[str, Any] = {
                "event": "tool_call",
                "session_id": self._session_id,
                **self._user_identity,
                "tool_name": tool_name,
                "call_num": call_num,
                "elapsed_ms": round(elapsed_ms, 1),
                "status": status,
            }
            if error_msg:
                ev["error"] = error_msg
            _write_structured_event(ev)

    def get_stats(self) -> dict:
        """현재까지의 model_calls, tool_calls 카운트 반환."""
        return {
            "model_calls": self._model_call_count,
            "tool_calls": self._tool_call_count,
        }
