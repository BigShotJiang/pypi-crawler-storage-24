"""
HDSP Jupyter Extension.

In-process execution via ServiceFactory and WebSocket agent.
Configuration: ~/.jupyter/hdsp_agent_config.json
"""

import asyncio
import os
import sys
import traceback

from ._version import __version__


def _setup_local_imports():
    """Add local hdsp_agent_core to sys.path for direct source imports."""
    from pathlib import Path

    # jupyter_ext/__init__.py → extensions/jupyter/jupyter_ext/
    # hdsp_agent_core source: repo_root/hdsp_agent_core/
    repo_root = Path(__file__).resolve().parent.parent.parent.parent
    core_path = str(repo_root / "hdsp_agent_core")
    if core_path not in sys.path:
        sys.path.insert(0, core_path)


_setup_local_imports()


# SSL certificate setup for macOS
if sys.platform == "darwin":
    try:
        import certifi

        os.environ["SSL_CERT_FILE"] = certifi.where()
        os.environ["REQUESTS_CA_BUNDLE"] = certifi.where()
    except ImportError:
        pass


def _jupyter_labextension_paths():
    """Called by JupyterLab to find extension."""
    return [{"src": "labextension", "dest": "hdsp-agent"}]


def _jupyter_server_extension_points():
    """Called by Jupyter Server to enable extension."""
    return [{"module": "jupyter_ext"}]


def _ensure_config_files():
    """Automatically create necessary configuration files on first run."""
    import json
    import shutil
    from pathlib import Path

    try:
        jupyter_config_dir = Path.home() / ".jupyter"
        jupyter_server_config_d = jupyter_config_dir / "jupyter_server_config.d"

        # 1. Create jupyter_server_config.d directory
        jupyter_server_config_d.mkdir(parents=True, exist_ok=True)

        # 2. Copy hdsp_agent.json (server extension registration)
        dest_server_config = jupyter_server_config_d / "hdsp_jupyter_extension.json"
        if not dest_server_config.exists():
            source_server_config = (
                Path(__file__).parent
                / "etc"
                / "jupyter"
                / "jupyter_server_config.d"
                / "hdsp_jupyter_extension.json"
            )
            if source_server_config.exists():
                shutil.copy(source_server_config, dest_server_config)

        # 3. Create hdsp_agent_config.json (Agent settings - default values)
        config_file = jupyter_config_dir / "hdsp_agent_config.json"
        if not config_file.exists():
            default_config = {
                "provider": "vllm",
                "vllm": {
                    "endpoint": "https://openrouter.ai/api/v1",
                    "apiKey": "",
                    "model": "openai/gpt-4o",
                },
            }
            with open(config_file, "w") as f:
                json.dump(default_config, f, indent=2)

    except Exception:
        # Configuration file creation failure is not fatal, ignore silently
        pass


def _start_embedded_agent_server(server_app, port: int):
    """Start agent server in embedded mode (same process via uvicorn thread)."""
    import threading

    import uvicorn

    # Try to import from installed package first, then fallback to dev path
    try:
        from agent_server.main import app as agent_app
    except ImportError:
        # Development mode: add agent-server to path
        project_root = os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        )
        agent_server_path = os.path.join(project_root, "agent-server")
        if os.path.exists(agent_server_path) and agent_server_path not in sys.path:
            sys.path.insert(0, agent_server_path)
        from agent_server.main import app as agent_app

    def run_uvicorn():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        config = uvicorn.Config(
            agent_app,
            host="127.0.0.1",
            port=port,
            log_level="info",
            access_log=False,
        )
        server = uvicorn.Server(config)
        loop.run_until_complete(server.serve())

    thread = threading.Thread(
        target=run_uvicorn, daemon=True, name="EmbeddedAgentServer"
    )
    thread.start()

    # Wait for agent server to be ready
    import time

    ready = False
    for i in range(50):  # 5 seconds timeout
        try:
            import httpx

            response = httpx.get(f"http://127.0.0.1:{port}/health", timeout=0.2)
            if response.status_code == 200:
                ready = True
                break
        except Exception:
            pass
        time.sleep(0.1)

    if ready:
        server_app.log.info(f"Embedded Agent Server ready on http://127.0.0.1:{port}")
    else:
        server_app.log.warning(
            f"Embedded Agent Server started on http://127.0.0.1:{port} (may still be initializing)"
        )


async def _initialize_service_factory(server_app):
    """Initialize ServiceFactory if hdsp_agent_core is available."""
    try:
        from hdsp_agent_core.factory import get_service_factory

        factory = get_service_factory()
        await factory.initialize()

        server_app.log.info("HDSP Agent ServiceFactory initialized")

        rag_service = factory.get_rag_service()
        rag_ready = rag_service.is_ready()
        server_app.log.info(f"  RAG service ready: {rag_ready}")

    except ImportError:
        # hdsp_agent_core not available, skip ServiceFactory initialization
        pass
    except Exception as e:
        server_app.log.warning(f"ServiceFactory initialization failed: {e}")


def _schedule_initialization(server_app):
    """Schedule async initialization in the event loop."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_initialize_service_factory(server_app))
        else:
            loop.run_until_complete(_initialize_service_factory(server_app))
    except RuntimeError:
        asyncio.run(_initialize_service_factory(server_app))


def load_jupyter_server_extension(server_app):
    """Load the Jupyter Server extension."""
    # [Auto-config] Create config files if they don't exist
    _ensure_config_files()

    try:
        from .http_handlers import setup_handlers

        web_app = server_app.web_app
        setup_handlers(web_app)

        # Expose environment variables to client via PageConfig
        # This allows frontend to access HDSP_ENV, HDSP_PRJ_ID, JUPYTERHUB_USER
        page_config = web_app.settings.setdefault("page_config_data", {})

        # Add HDSP environment variables
        hdsp_env = os.environ.get("HDSP_ENV", "")
        hdsp_prj_id = os.environ.get("HDSP_PRJ_ID", "")
        jupyterhub_user = os.environ.get("JUPYTERHUB_USER", "")
        hdsp_bdp_id = os.environ.get("HDSP_BDP_ID", "")

        if hdsp_env:
            page_config["HDSP_ENV"] = hdsp_env
        if hdsp_prj_id:
            page_config["HDSP_PRJ_ID"] = hdsp_prj_id
        if jupyterhub_user:
            page_config["JUPYTERHUB_USER"] = jupyterhub_user
        if hdsp_bdp_id:
            page_config["HDSP_BDP_ID"] = hdsp_bdp_id

        server_app.log.info(
            f"Exposed HDSP env vars to client: HDSP_ENV={hdsp_env}, HDSP_PRJ_ID={hdsp_prj_id}, JUPYTERHUB_USER={jupyterhub_user}, HDSP_BDP_ID={hdsp_bdp_id}"
        )

        # Keycloak JWT: Extract team claim for access control
        keycloak_token = os.environ.get("KEYCLOAK_ID_TOKEN", "")
        team_claim_name = os.environ.get("HDSP_TEAM_CLAIM_NAME", "hcc_team")
        user_team = ""

        if keycloak_token:
            try:
                import base64
                import json as json_module

                parts = keycloak_token.split(".")
                if len(parts) == 3:
                    payload = parts[1]
                    # Add Base64 padding if needed
                    padding = 4 - len(payload) % 4
                    if padding != 4:
                        payload += "=" * padding
                    decoded = base64.urlsafe_b64decode(payload)
                    claims = json_module.loads(decoded)
                    user_team = claims.get(team_claim_name, "")
                    server_app.log.info(
                        f"Decoded Keycloak JWT: team claim '{team_claim_name}' = '{user_team}'"
                    )
            except Exception as e:
                server_app.log.warning(f"Failed to decode Keycloak token: {e}")

        page_config["HDSP_USER_TEAM"] = user_team
        page_config["HDSP_TEAM_CLAIM_NAME"] = team_claim_name
        page_config["HDSP_EXTENSION_VERSION"] = __version__
        server_app.log.info(f"User team from Keycloak: {user_team or '(not set)'}")

        server_app.log.info("HDSP Jupyter Extension loaded (v%s)", __version__)
        _schedule_initialization(server_app)

        # Start server-side idle monitor
        try:
            from .idle_monitor import ServerIdleMonitor

            idle_monitor = ServerIdleMonitor(server_app)
            idle_monitor.start()
            web_app.settings["hdsp_idle_monitor"] = idle_monitor
        except Exception as idle_err:
            server_app.log.warning(
                f"Server-side idle monitor failed to start: {idle_err}"
            )

    except Exception as e:
        server_app.log.error(f"Failed to load HDSP Jupyter Extension: {e}")
        server_app.log.error(traceback.format_exc())
        raise e
