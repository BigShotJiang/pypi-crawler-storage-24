"""
Configuration for HDSP Jupyter Extension.
"""
