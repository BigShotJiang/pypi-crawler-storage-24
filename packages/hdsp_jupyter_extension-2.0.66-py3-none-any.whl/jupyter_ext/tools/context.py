"""Jupyter 도구를 위한 노트북 컨텍스트 관리."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class CellInfo:
    """노트북 셀 정보."""

    index: int
    cell_type: str  # "code" 또는 "markdown"
    source: str
    outputs: list[dict[str, Any]] = field(default_factory=list)
    execution_count: Optional[int] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class NotebookContext:
    """현재 노트북에 대한 컨텍스트 정보."""

    path: str
    cells: list[CellInfo] = field(default_factory=list)
    kernel_name: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def cell_count(self) -> int:
        """노트북의 셀 수를 가져옵니다."""
        return len(self.cells)

    def get_cell(self, index: int) -> Optional[CellInfo]:
        """인덱스로 셀을 가져옵니다."""
        if 0 <= index < len(self.cells):
            return self.cells[index]
        return None

    def get_code_cells(self) -> list[CellInfo]:
        """모든 코드 셀을 가져옵니다."""
        return [c for c in self.cells if c.cell_type == "code"]

    def get_markdown_cells(self) -> list[CellInfo]:
        """모든 마크다운 셀을 가져옵니다."""
        return [c for c in self.cells if c.cell_type == "markdown"]


class NotebookContextManager:
    """
    노트북 컨텍스트 관리자로 노트북 상태에 대한 접근을 제공합니다.

    이 클래스는 Jupyter 서버의 노트북 모델과 LangChain Agent 도구 사이를
    연결하여 도구가 노트북 상태를 읽고 수정할 수 있게 합니다.
    """

    def __init__(
        self,
        kernel_manager: Any = None,
        contents_manager: Any = None,
    ):
        """
        컨텍스트 관리자를 초기화합니다.

        Args:
            kernel_manager: 코드 실행을 위한 Jupyter 커널 관리자
            contents_manager: 파일 작업을 위한 Jupyter 콘텐츠 관리자
        """
        self._kernel_manager = kernel_manager
        self._contents_manager = contents_manager
        self._current_notebook: Optional[NotebookContext] = None
        self._notebook_model: Optional[dict[str, Any]] = None

    @property
    def current_notebook(self) -> Optional[NotebookContext]:
        """현재 노트북 컨텍스트를 가져옵니다."""
        return self._current_notebook

    @property
    def notebook_model(self) -> Optional[dict[str, Any]]:
        """원시 노트북 모델을 가져옵니다 (직접 조작용)."""
        return self._notebook_model

    @property
    def kernel_manager(self) -> Any:
        """커널 관리자를 가져옵니다."""
        return self._kernel_manager

    @property
    def contents_manager(self) -> Any:
        """콘텐츠 관리자를 가져옵니다."""
        return self._contents_manager

    def set_notebook(self, path: str, model: dict[str, Any]) -> None:
        """
        Jupyter 노트북 모델에서 현재 노트북 컨텍스트를 설정합니다.

        Args:
            path: 노트북 경로
            model: Jupyter 노트북 모델 딕셔너리
        """
        self._notebook_model = model

        # 모델에서 셀 파싱
        content = model.get("content", {})
        raw_cells = content.get("cells", [])
        cells = []

        for i, cell in enumerate(raw_cells):
            cells.append(
                CellInfo(
                    index=i,
                    cell_type=cell.get("cell_type", "code"),
                    source=cell.get("source", ""),
                    outputs=cell.get("outputs", []),
                    execution_count=cell.get("execution_count"),
                    metadata=cell.get("metadata", {}),
                )
            )

        # 노트북 메타데이터 추출
        nb_metadata = content.get("metadata", {})
        kernel_info = nb_metadata.get("kernelspec", {})

        self._current_notebook = NotebookContext(
            path=path,
            cells=cells,
            kernel_name=kernel_info.get("name"),
            metadata=nb_metadata,
        )

    def clear(self) -> None:
        """현재 노트북 컨텍스트를 지웁니다."""
        self._current_notebook = None
        self._notebook_model = None

    def update_cell(self, index: int, source: str) -> bool:
        """
        셀의 소스 코드를 업데이트합니다.

        Args:
            index: 셀 인덱스
            source: 새 소스 코드

        Returns:
            성공하면 True
        """
        if not self._notebook_model or not self._current_notebook:
            return False

        cells = self._notebook_model.get("content", {}).get("cells", [])
        if not 0 <= index < len(cells):
            return False

        cells[index]["source"] = source

        # 컨텍스트 업데이트
        if 0 <= index < len(self._current_notebook.cells):
            self._current_notebook.cells[index].source = source

        return True

    def insert_cell(
        self,
        source: str,
        cell_type: str = "code",
        insert_after: Optional[int] = None,
    ) -> int:
        """
        새 셀을 삽입합니다.

        Args:
            source: 셀 소스 내용
            cell_type: "code" 또는 "markdown"
            insert_after: 이 인덱스 뒤에 삽입 (None = 끝에 추가)

        Returns:
            새 셀의 인덱스
        """
        if not self._notebook_model:
            raise ValueError("노트북 모델이 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])

        new_cell = {
            "cell_type": cell_type,
            "source": source,
            "metadata": {},
        }

        if cell_type == "code":
            new_cell["outputs"] = []
            new_cell["execution_count"] = None

        if insert_after is not None and 0 <= insert_after < len(cells):
            cells.insert(insert_after + 1, new_cell)
            new_index = insert_after + 1
        else:
            cells.append(new_cell)
            new_index = len(cells) - 1

        # 컨텍스트 업데이트
        if self._current_notebook:
            new_cell_info = CellInfo(
                index=new_index,
                cell_type=cell_type,
                source=source,
            )

            if insert_after is not None and 0 <= insert_after < len(
                self._current_notebook.cells
            ):
                self._current_notebook.cells.insert(insert_after + 1, new_cell_info)
                # 이후 셀 인덱스 재설정
                for i in range(insert_after + 2, len(self._current_notebook.cells)):
                    self._current_notebook.cells[i].index = i
            else:
                self._current_notebook.cells.append(new_cell_info)

        return new_index

    def delete_cell(self, index: int) -> bool:
        """
        셀을 삭제합니다.

        Args:
            index: 삭제할 셀 인덱스

        Returns:
            성공하면 True
        """
        if not self._notebook_model or not self._current_notebook:
            return False

        cells = self._notebook_model.get("content", {}).get("cells", [])
        if not 0 <= index < len(cells):
            return False

        del cells[index]

        # 컨텍스트 업데이트
        if 0 <= index < len(self._current_notebook.cells):
            del self._current_notebook.cells[index]
            # 이후 셀 인덱스 재설정
            for i in range(index, len(self._current_notebook.cells)):
                self._current_notebook.cells[i].index = i

        return True

    def get_summary(self) -> dict[str, Any]:
        """
        현재 노트북 상태의 요약을 가져옵니다.

        Returns:
            노트북 요약이 담긴 딕셔너리
        """
        if not self._current_notebook:
            return {"status": "no_notebook"}

        nb = self._current_notebook
        return {
            "path": nb.path,
            "cell_count": nb.cell_count,
            "code_cells": len(nb.get_code_cells()),
            "markdown_cells": len(nb.get_markdown_cells()),
            "kernel": nb.kernel_name,
        }
