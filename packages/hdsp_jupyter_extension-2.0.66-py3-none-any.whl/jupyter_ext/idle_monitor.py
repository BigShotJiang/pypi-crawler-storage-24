"""
Server-side Idle Monitor.

브라우저가 닫혀도 커널/터미널 활동을 감지하여 idle timeout을 서버에서 처리.
Jupyter Server의 커널/터미널 매니저를 통해 마지막 활동 시간을 추적한다.
"""

import asyncio
import json
import logging
import os
import time
from typing import Optional

logger = logging.getLogger("ServerApp")

# 기본 idle timeout: 60분
DEFAULT_IDLE_TIMEOUT_SECONDS = 60 * 60

# 서버 체크 주기: 30초
CHECK_INTERVAL_SECONDS = 30

# SageMaker 메타데이터 경로
SAGEMAKER_METADATA_PATH = "/opt/ml/metadata/resource-metadata.json"


def _is_sagemaker() -> bool:
    """SageMaker 환경인지 판별."""
    return bool(os.environ.get("SAGEMAKER_SPACE_NAME"))


class ServerIdleMonitor:
    """서버 사이드 유휴 상태 모니터."""

    def __init__(self, server_app):
        self.server_app = server_app
        self.last_activity_time = time.time()
        self._task: Optional[asyncio.Task] = None
        self._shutdown_triggered = False
        self._sagemaker = _is_sagemaker()

        # idle timeout 설정 로드
        self.idle_timeout_seconds = self._load_timeout()

        # 환경변수 (shutdown API용)
        self.hdsp_env = os.environ.get("HDSP_ENV")
        self.project_id = os.environ.get("HDSP_PRJ_ID")
        self.user_id = os.environ.get("JUPYTERHUB_USER")

    def _load_timeout(self) -> int:
        """config에서 idle timeout 로드. 최대 1시간."""
        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            cm = get_config_manager()
            config = cm.get_config()
            timeout = config.get("idleTimeout")
            if isinstance(timeout, (int, float)) and timeout > 0:
                return min(int(timeout), DEFAULT_IDLE_TIMEOUT_SECONDS)
        except Exception:
            pass
        return DEFAULT_IDLE_TIMEOUT_SECONDS

    def start(self):
        """모니터링 시작."""
        if self.idle_timeout_seconds <= 0:
            logger.info("[ServerIdleMonitor] Disabled (timeout=0)")
            return

        # SageMaker는 환경변수 없어도 시작 가능
        if not self._sagemaker and not (self.hdsp_env and self.project_id and self.user_id):
            logger.info(
                "[ServerIdleMonitor] Disabled (missing HDSP_ENV/HDSP_PRJ_ID/JUPYTERHUB_USER)"
            )
            return

        self._task = asyncio.ensure_future(self._monitor_loop())
        logger.info(
            "[ServerIdleMonitor] Started (sagemaker=%s, timeout=%ds, interval=%ds)",
            self._sagemaker,
            self.idle_timeout_seconds,
            CHECK_INTERVAL_SECONDS,
        )

    def stop(self):
        """모니터링 중지."""
        if self._task and not self._task.done():
            self._task.cancel()
            logger.info("[ServerIdleMonitor] Stopped")

    def reset(self):
        """활동 감지 시 타이머 리셋 (HTTP 요청 시 호출)."""
        self.last_activity_time = time.time()

    def get_idle_status(self) -> dict:
        """현재 idle 상태 반환 (API 응답용)."""
        kernel_last = self._check_kernel_activity()
        terminal_last = self._check_terminal_activity()
        latest = max(self.last_activity_time, kernel_last, terminal_last)
        idle_seconds = time.time() - latest
        return {
            "idle": idle_seconds >= self.idle_timeout_seconds,
            "idle_seconds": round(idle_seconds),
            "timeout_seconds": self.idle_timeout_seconds,
        }

    def _check_kernel_activity(self) -> float:
        """커널 매니저에서 마지막 활동 시간 조회. epoch 반환."""
        last = 0.0
        try:
            km = self.server_app.kernel_manager
            for kid in km.list_kernel_ids():
                kernel = km.get_kernel(kid)
                # last_activity는 datetime 객체
                if hasattr(kernel, "last_activity") and kernel.last_activity:
                    ts = kernel.last_activity.timestamp()
                    if ts > last:
                        last = ts
                # execution_state로 busy 체크
                if hasattr(kernel, "execution_state") and kernel.execution_state == "busy":
                    return time.time()  # busy면 지금 활동 중
        except Exception as e:
            logger.debug("[ServerIdleMonitor] Kernel check error: %s", e)
        return last

    def _check_terminal_activity(self) -> float:
        """터미널 매니저에서 마지막 활동 시간 조회. 자식 프로세스도 감지."""
        last = 0.0
        try:
            tm = self.server_app.web_app.settings.get("terminal_manager")
            if tm is None:
                return last

            # terminado의 terminals dict에서 직접 순회
            terminals = getattr(tm, "terminals", None)
            if not terminals:
                logger.info("[ServerIdleMonitor] No tm.terminals found (type=%s)", type(tm).__name__)
                return last

            for term_name, term_obj in terminals.items():
                # last_activity 확인 (REST model 대신 직접)
                try:
                    term_model = tm.get(term_name)
                    if isinstance(term_model, dict):
                        la = term_model.get("last_activity")
                        if la and hasattr(la, "timestamp"):
                            ts = la.timestamp()
                            if ts > last:
                                last = ts
                except Exception:
                    pass

                # PTY 자식 프로세스 확인
                if self._terminal_has_running_process(term_obj, term_name):
                    return time.time()

        except Exception as e:
            logger.warning("[ServerIdleMonitor] Terminal check error: %s", e)
        return last

    def _terminal_has_running_process(self, term, term_name: str = "") -> bool:
        """터미널의 쉘에 자식 프로세스가 실행 중인지 확인."""
        try:
            import psutil

            ptyproc = getattr(term, "ptyproc", None)
            if ptyproc is None:
                logger.info("[ServerIdleMonitor] Terminal '%s': no ptyproc attr", term_name)
                return False

            pid = getattr(ptyproc, "pid", None)
            if pid is None:
                logger.info("[ServerIdleMonitor] Terminal '%s': ptyproc has no pid", term_name)
                return False

            if not ptyproc.isalive():
                return False

            proc = psutil.Process(pid)
            children = proc.children(recursive=True)
            if children:
                child_info = [(c.pid, c.name()) for c in children]
                logger.info(
                    "[ServerIdleMonitor] Terminal '%s' (pid=%d) has %d child(ren): %s",
                    term_name, pid, len(children), child_info,
                )
                return True
            return False
        except Exception as e:
            logger.warning("[ServerIdleMonitor] Process check error for '%s': %s", term_name, e)
            return False

    async def _monitor_loop(self):
        """주기적으로 idle 상태를 체크."""
        try:
            while True:
                await asyncio.sleep(CHECK_INTERVAL_SECONDS)

                if self._shutdown_triggered:
                    break

                # 커널/터미널에서 마지막 활동 시간 조회
                now = time.time()
                kernel_last = self._check_kernel_activity()
                terminal_last = self._check_terminal_activity()

                # HTTP 요청 활동, 커널 활동, 터미널 활동 중 가장 최근
                latest_activity = max(
                    self.last_activity_time, kernel_last, terminal_last
                )

                idle_seconds = now - latest_activity

                # 60초마다 상태 로깅
                if int(idle_seconds) % 60 < CHECK_INTERVAL_SECONDS:
                    logger.info(
                        "[ServerIdleMonitor] idle=%.0fs/%.0fs, http=%.0fs ago, kernel=%.0fs ago, terminal=%.0fs ago",
                        idle_seconds, self.idle_timeout_seconds,
                        now - self.last_activity_time,
                        now - kernel_last if kernel_last > 0 else -1,
                        now - terminal_last if terminal_last > 0 else -1,
                    )

                if idle_seconds >= self.idle_timeout_seconds:
                    logger.info(
                        "[ServerIdleMonitor] Idle timeout reached (%.0fs idle). Triggering shutdown.",
                        idle_seconds,
                    )
                    self._shutdown_triggered = True
                    await self._call_shutdown()
                    break

        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("[ServerIdleMonitor] Monitor loop error: %s", e, exc_info=True)

    async def _call_shutdown(self):
        """환경에 따라 적절한 shutdown 호출."""
        if self._sagemaker:
            await self._sagemaker_shutdown()
        else:
            await self._hdsp_shutdown()

    async def _sagemaker_shutdown(self):
        """SageMaker delete_app API로 노트북 종료."""
        try:
            import boto3

            meta = self._load_sagemaker_metadata()
            domain_id = meta.get("DomainId") or os.environ.get("DOMAIN_ID", "")
            space_name = meta.get("SpaceName") or os.environ.get("SAGEMAKER_SPACE_NAME", "")
            app_type = meta.get("AppType", "JupyterLab")
            app_name = meta.get("AppName", "default")

            if not domain_id or not space_name:
                logger.error(
                    "[ServerIdleMonitor] SageMaker shutdown failed: missing DomainId=%s, SpaceName=%s",
                    domain_id, space_name,
                )
                return

            logger.info(
                "[ServerIdleMonitor] SageMaker delete_app: domain=%s, space=%s, app_type=%s, app=%s",
                domain_id, space_name, app_type, app_name,
            )

            client = boto3.client("sagemaker", region_name="ap-northeast-2")
            client.delete_app(
                DomainId=domain_id,
                SpaceName=space_name,
                AppType=app_type,
                AppName=app_name,
            )
            logger.info("[ServerIdleMonitor] SageMaker delete_app success")
        except Exception as e:
            logger.error("[ServerIdleMonitor] SageMaker shutdown error: %s", e)

    def _load_sagemaker_metadata(self) -> dict:
        """SageMaker 리소스 메타데이터 로드."""
        try:
            with open(SAGEMAKER_METADATA_PATH) as f:
                return json.load(f)
        except Exception:
            return {}

    async def _hdsp_shutdown(self):
        """HDSP shutdown API 호출."""
        import httpx

        if self.hdsp_env == "dev":
            api_base = "https://hdsp-api-dev.hyundaicard.com"
        elif self.hdsp_env == "prod":
            api_base = "https://hdsp-api.hyundaicard.com"
        else:
            logger.warning("[ServerIdleMonitor] Unknown HDSP_ENV: %s", self.hdsp_env)
            return

        api_url = f"{api_base}/k8s/jupyter/{self.project_id}/{self.user_id}"
        logger.info("[ServerIdleMonitor] Calling shutdown API: DELETE %s", api_url)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.delete(api_url)

            if response.status_code in (200, 204):
                logger.info("[ServerIdleMonitor] Shutdown API success")
            else:
                logger.error(
                    "[ServerIdleMonitor] Shutdown API failed: %s %s",
                    response.status_code,
                    response.text,
                )
        except Exception as e:
            logger.error("[ServerIdleMonitor] Shutdown API error: %s", e)
