"""Handlers for HDSP Agent."""

try:
    from .websocket import AgentWebSocketHandler
except ImportError:
    AgentWebSocketHandler = None  # type: ignore[assignment,misc]

__all__ = ["AgentWebSocketHandler"]
