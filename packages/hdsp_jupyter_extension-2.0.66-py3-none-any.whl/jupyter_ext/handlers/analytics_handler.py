"""Analytics events handler - append JSONL to file."""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import os
from pathlib import Path
from typing import Optional

from jupyter_server.base.handlers import APIHandler

from .._version import __version__ as _EXT_VERSION
from ..resource_usage import get_integrated_resources

logger = logging.getLogger(__name__)

VALID_EVENT_TYPES = {"impression", "click", "error"}

# Environment-variable sourced identity fields.
# If any is missing, the handler is disabled (silent 204 for every request).
_ENV_TEAM = os.environ.get("HDSP_USER_TEAM", "")
_ENV_PROJECT = os.environ.get("HDSP_PRJ_ID", "")
_ENV_USER = os.environ.get("JUPYTERHUB_USER", "") or os.environ.get("HDSP_BDP_ID", "")
_DISABLED = not ((_ENV_TEAM or _ENV_PROJECT) and _ENV_USER)


def _get_analytics_log_dir() -> Path | None:
    """Return the analytics log directory, or None if unavailable."""
    env = os.environ.get("ANALYTICS_LOG_DIR")
    if env:
        d = Path(env)
    elif Path("/home/sagemaker-user/action_logs").is_dir():
        d = Path("/home/sagemaker-user/action_logs")
    else:
        d = Path(__file__).resolve().parents[3] / "logs"
    try:
        d.mkdir(parents=True, exist_ok=True)
        return d
    except OSError:
        pass
    # Local fallback
    fallback = Path(__file__).resolve().parents[3] / "logs"
    try:
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback
    except OSError:
        logger.warning("Analytics log directory unavailable: %s", d)
        return None


_LOG_DIR = _get_analytics_log_dir()


def _get_analytics_log_path_for_type(event_type: str) -> Optional[Path]:
    """Return today's log file path for a given event type.

    File pattern: ``analytics_{event_type}_{YYYYMMDD}.jsonl``
    """
    if _LOG_DIR is None:
        return None
    today = datetime.date.today().isoformat()
    day_cache = _DAILY_PATH_CACHE.get(today)
    if day_cache is not None:
        cached = day_cache.get(event_type)
        if cached is not None:
            return cached
    else:
        day_cache = {}
        _DAILY_PATH_CACHE[today] = day_cache
    path = _LOG_DIR / f"analytics_{event_type}_{today.replace('-', '')}.jsonl"
    day_cache[event_type] = path
    return path


_DAILY_PATH_CACHE: dict[str, dict[str, Path]] = {}


def _collect_hardware_attrs() -> dict[str, object]:
    try:
        res = get_integrated_resources()
        cpu = res.get("cpu", {})
        mem = res.get("memory", {})
        gpus = res.get("gpus", [])
        return {
            "cpu_cores": cpu.get("cores"),
            "memory_total_gb": mem.get("total_gb"),
            "gpu_name": gpus[0]["name"] if gpus else None,
            "gpu_memory_total_mb": gpus[0]["memory_total_mb"] if gpus else None,
        }
    except Exception:
        return {
            "cpu_cores": None,
            "memory_total_gb": None,
            "gpu_name": None,
            "gpu_memory_total_mb": None,
        }


_HW_ATTRS: dict[str, object] = _collect_hardware_attrs()


def _write_events(path: Path, lines: list[str]) -> None:
    with open(path, "a", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")


class AnalyticsEventsHandler(APIHandler):
    """POST /hdsp-agent/analytics/events"""

    def check_xsrf_cookie(self):
        pass

    async def post(self):
        try:
            if _DISABLED:
                self.set_status(204)
                self.finish()
                return

            body = json.loads(self.request.body.decode("utf-8"))
            if not isinstance(body, list):
                self.set_status(400)
                self.finish()
                return

            lines_by_type: dict[str, list[str]] = {}
            for event in body:
                if not isinstance(event, dict):
                    continue
                if event.get("event_type") not in VALID_EVENT_TYPES:
                    continue
                if not event.get("feature"):
                    continue
                # Server-side injection
                event["datetime"] = datetime.datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                event["team"] = _ENV_TEAM
                event["project"] = _ENV_PROJECT
                event["user_id"] = _ENV_USER
                event["extension_version"] = _EXT_VERSION
                event.update(_HW_ATTRS)
                et = event["event_type"]
                lines_by_type.setdefault(et, []).append(
                    json.dumps(event, ensure_ascii=False)
                )

            for et, lines in lines_by_type.items():
                log_path = _get_analytics_log_path_for_type(et)
                if log_path is not None:
                    await asyncio.to_thread(_write_events, log_path, lines)

            self.set_status(204)
            self.finish()
        except Exception:
            logger.exception("Analytics write failed")
            self.set_status(204)
            self.finish()
