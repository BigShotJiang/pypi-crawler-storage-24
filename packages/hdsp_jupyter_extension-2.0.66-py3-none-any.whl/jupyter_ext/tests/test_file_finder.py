"""Tests for FileIndex fuzzy and prefix search."""

import pytest

from ..tools.file_finder import FileIndex


@pytest.fixture
def sample_tree(tmp_path):
    """Create a sample file tree for testing."""
    # Create directories
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "components").mkdir()
    (tmp_path / "tests").mkdir()
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "node_modules").mkdir()

    # Create files
    (tmp_path / "main.py").touch()
    (tmp_path / "config.yaml").touch()
    (tmp_path / "README.md").touch()
    (tmp_path / "src" / "auth.py").touch()
    (tmp_path / "src" / "auth_utils.py").touch()
    (tmp_path / "src" / "authentication.ts").touch()
    (tmp_path / "src" / "components" / "AuthPanel.tsx").touch()
    (tmp_path / "src" / "components" / "UserPanel.tsx").touch()
    (tmp_path / "tests" / "test_auth.py").touch()
    (tmp_path / "__pycache__" / "main.cpython-311.pyc").touch()
    (tmp_path / "node_modules" / "lodash.js").touch()

    return tmp_path


@pytest.fixture
def index(sample_tree):
    return FileIndex(sample_tree, ttl=0)  # ttl=0 forces rebuild each time


class TestFileIndexBuild:
    def test_excludes_pycache(self, index):
        index._build_index()
        assert not any("__pycache__" in e for e in index._entries)

    def test_excludes_node_modules(self, index):
        index._build_index()
        assert not any("node_modules" in e for e in index._entries)

    def test_includes_regular_files(self, index):
        index._build_index()
        assert "main.py" in index._entries

    def test_includes_directories(self, index):
        index._build_index()
        assert "src/" in index._entries


class TestFuzzySearch:
    def test_exact_match_scores_highest(self, index):
        results = index.fuzzy_search("main.py")
        assert len(results) > 0
        assert results[0]["path"] == "main.py"

    def test_partial_match(self, index):
        results = index.fuzzy_search("auth")
        assert len(results) > 0
        paths = [r["path"] for r in results]
        assert any("auth" in p for p in paths)

    def test_dir_filter_with_slash(self, index):
        results = index.fuzzy_search("src/auth")
        paths = [r["path"] for r in results]
        assert all(p.startswith("src/") or p.startswith("src") for p in paths)

    def test_empty_query_returns_empty(self, index):
        assert index.fuzzy_search("") == []

    def test_max_results_respected(self, index):
        results = index.fuzzy_search("py", max_results=3)
        assert len(results) <= 3

    def test_supported_exts_filter(self, index):
        results = index.fuzzy_search("auth", supported_exts={".py"})
        for r in results:
            if r["type"] == "file":
                assert r["path"].endswith(".py")

    def test_results_have_score(self, index):
        results = index.fuzzy_search("main")
        for r in results:
            assert "score" in r
            assert isinstance(r["score"], float)

    def test_results_have_type(self, index):
        results = index.fuzzy_search("src")
        types = {r["type"] for r in results}
        assert types <= {"file", "directory"}


class TestPrefixSearch:
    def test_root_prefix(self, index):
        results = index.prefix_search("")
        assert len(results) > 0

    def test_dir_prefix(self, index):
        results = index.prefix_search("src/")
        paths = [r["path"] for r in results]
        assert all(p.startswith("src") for p in paths)

    def test_ext_filter(self, index):
        results = index.prefix_search("src/", supported_exts={".py"})
        for r in results:
            if r["type"] == "file":
                assert r["path"].endswith(".py")

    def test_directories_first(self, index):
        results = index.prefix_search("")
        dirs = [i for i, r in enumerate(results) if r["type"] == "directory"]
        files = [i for i, r in enumerate(results) if r["type"] == "file"]
        if dirs and files:
            assert max(dirs) < min(files)


class TestCaching:
    def test_ttl_prevents_rebuild(self, sample_tree):
        idx = FileIndex(sample_tree, ttl=60)
        idx._build_index()
        built_at = idx._built_at
        idx._maybe_rebuild()
        assert idx._built_at == built_at  # no rebuild

    def test_ttl_zero_always_rebuilds(self, sample_tree):
        idx = FileIndex(sample_tree, ttl=0)
        idx._build_index()
        built_at = idx._built_at
        import time

        time.sleep(0.01)
        idx._maybe_rebuild()
        assert idx._built_at > built_at  # rebuilt
