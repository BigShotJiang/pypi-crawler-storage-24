"""A helper to write Muffin Plugins."""

from __future__ import annotations

from abc import ABC
from contextlib import asynccontextmanager
from inspect import iscoroutinefunction
from typing import TYPE_CHECKING, Any, Callable, ClassVar, Mapping

from modconfig import Config

from muffin.errors import MuffinError

if TYPE_CHECKING:
    from muffin.app import Application


class PluginError(MuffinError):
    """Implement any exception in plugins."""


class PluginNotInstalledError(RuntimeError):
    """Raised when a plugin is not installed."""


class BasePlugin(ABC):
    """Base class for Muffin plugins."""

    name: str

    # Plugin options with default values
    defaults: ClassVar[Mapping[str, Any]] = {"disabled": False}

    # Optional middleware method
    middleware: Callable[..., Any] | None = None

    def __init__(self, app: Application | None = None, **options):
        """Save application and create he plugin's configuration."""

        self.cfg = Config(
            config_config={"update_from_env": False},
            **dict({"disabled": False}, **self.defaults),
        )
        self.__app__ = app

        if app is not None:
            self.setup(app, **options)
        else:
            self.cfg.update_from_dict(options, exist_only=True)

    def __repr__(self) -> str:
        """Human readable representation."""
        return f"<muffin.Plugin: {self.name}>"

    async def __aenter__(self):
        if iscoroutinefunction(self.startup):
            await self.startup()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if iscoroutinefunction(self.shutdown):
            await self.shutdown()

    @property
    def app(self) -> Application:
        """Get the application."""
        if self.__app__ is None:
            raise PluginNotInstalledError()

        return self.__app__

    def setup(self, app: Application, *, name: str | None = None, **options) -> Any:
        """Bind app and update the plugin's configuration."""
        # allow to redefine the name for multi plugins with same type
        self.name = name or getattr(self, "name", "")
        if not self.name:
            msg = "Plugin.name is required"
            raise TypeError(msg)

        # Update configuration
        self.cfg.update_from_dict(dict(app.cfg), prefix=f"{self.name}_", exist_only=True)
        self.cfg.update_from_dict(options)
        if self.cfg.disabled:
            app.logger.warning("Plugin %s is disabled", self.name)
            return False

        app.plugins[self.name] = self
        self.__app__ = app

        # Register a middleware
        if callable(self.middleware):
            app.middleware(self.middleware)

        app.on_startup(self.startup)
        app.on_shutdown(self.shutdown)

        return True

    async def startup(self):  # noqa: B027
        """Startup the plugin."""

    async def shutdown(self):  # noqa: B027
        """Shutdown the plugin."""

    async def restart(self):
        """Restart the plugin."""
        await self.shutdown()
        await self.startup()

    @asynccontextmanager
    async def conftest(self):
        """Return a context manager for pytest conftest.py."""
        yield self
