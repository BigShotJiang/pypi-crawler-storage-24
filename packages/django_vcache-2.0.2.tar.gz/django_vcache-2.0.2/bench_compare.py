#!/usr/bin/env python3
"""
Benchmark: django-vcache vs Django's built-in RedisCache.
Uses granian ASGI server. Measures req/s, RSS, and Valkey connection count.

Each request does 6 cache operations (get, get_many, set, set large, incr,
get large) — see sample/views.py bench_mixed() for details.

Run inside Docker:
    docker compose run --rm app python bench_compare.py [--duration 60] [-c 300]
"""

import argparse
import os
import re
import socket
import subprocess
import sys
import time


def get_rss_mb(pid):
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024.0
    except (FileNotFoundError, ProcessLookupError):
        pass
    return 0.0


def find_worker_pid(parent_pid):
    """Find worker process (largest RSS child)."""
    try:
        result = subprocess.run(
            ["ps", "--ppid", str(parent_pid), "-o", "pid=,rss="],
            capture_output=True,
            text=True,
        )
        best_pid, best_rss = None, 0
        for line in result.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) == 2:
                pid, rss = int(parts[0]), int(parts[1])
                if rss > best_rss:
                    best_pid, best_rss = pid, rss
        return best_pid or parent_pid
    except Exception:
        return parent_pid


def get_valkey_connections():
    try:
        import redis

        r = redis.Redis(host="valkey", port=6379, socket_timeout=1)
        count = r.info("clients").get("connected_clients", 0)
        r.close()
        return count
    except Exception:
        return -1


def flush_valkey():
    try:
        import redis

        r = redis.Redis(host="valkey", port=6379, socket_timeout=1)
        r.flushall()
        r.close()
    except Exception:
        pass


def wait_for_server(port, timeout=15):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            s = socket.socket()
            s.settimeout(1)
            s.connect(("127.0.0.1", port))
            s.close()
            return True
        except (ConnectionRefusedError, OSError):
            time.sleep(0.2)
    return False


def run_benchmark(name, settings_module, duration, concurrency, port):
    print(f"\n{'=' * 70}")
    print(f"  {name}")
    print(f"{'=' * 70}")

    flush_valkey()
    time.sleep(0.5)

    env = {
        "DJANGO_SETTINGS_MODULE": settings_module,
        "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
        "PYTHONPATH": "/app",
        "VALKEY_URL": "redis://valkey:6379/1",
    }

    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "granian",
            "sample.asgi:application",
            "--interface",
            "asgi",
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--workers",
            "1",
            "--no-ws",
        ],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    base = f"http://127.0.0.1:{port}"
    if not wait_for_server(port):
        print("  ERROR: server did not start")
        proc.terminate()
        proc.wait()
        return None

    try:
        time.sleep(0.5)
        worker_pid = find_worker_pid(proc.pid)

        # Seed cache
        subprocess.run(
            ["curl", "-sf", f"{base}/bench/seed/"],
            stdout=subprocess.DEVNULL,
            timeout=5,
        )
        time.sleep(0.5)

        initial_rss = get_rss_mb(worker_pid)
        initial_conns = get_valkey_connections()

        print(f"  Worker PID: {worker_pid}, Initial RSS: {initial_rss:.1f} MB")
        print(f"  Duration: {duration}s, Concurrency: {concurrency}")
        print()
        print(f"  {'Time':>6}  {'RSS MB':>8}  {'Conns':>6}")
        print(f"  {'─' * 6}  {'─' * 8}  {'─' * 6}")
        print(f"  {'0s':>6}  {initial_rss:>8.1f}  {initial_conns:>6}")

        # Start load
        hey_proc = subprocess.Popen(
            [
                "hey",
                "-z",
                f"{duration}s",
                "-c",
                str(concurrency),
                "-t",
                "10",
                f"{base}/bench/mixed/",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Sample every 5s
        samples = []
        start = time.monotonic()
        peak_conns = initial_conns
        peak_rss = initial_rss

        while hey_proc.poll() is None:
            now = time.monotonic()
            elapsed = now - start
            if elapsed >= len(samples) * 5 + 5:
                rss = get_rss_mb(worker_pid)
                conns = get_valkey_connections()
                peak_conns = max(peak_conns, conns)
                peak_rss = max(peak_rss, rss)
                samples.append((int(elapsed), rss, conns))
                print(f"  {int(elapsed):>5}s  {rss:>8.1f}  {conns:>6}")
            time.sleep(0.5)

        stdout, _ = hey_proc.communicate()
        final_rss = get_rss_mb(worker_pid)
        final_conns = get_valkey_connections()
        peak_conns = max(peak_conns, final_conns)
        peak_rss = max(peak_rss, final_rss)
        elapsed = int(time.monotonic() - start)

        # Parse hey output
        rps = 0.0
        avg_latency = 0.0
        p99_latency = 0.0
        total_requests = 0
        errors = 0

        m = re.search(r"Requests/sec:\s+([\d.]+)", stdout)
        if m:
            rps = float(m.group(1))

        m = re.search(r"Average:\s+([\d.]+)\s+secs", stdout)
        if m:
            avg_latency = float(m.group(1)) * 1000

        m = re.search(r"99%\s+in\s+([\d.]+)\s+secs", stdout)
        if m:
            p99_latency = float(m.group(1)) * 1000

        for m_line in re.finditer(r"\[(\d+)\]\s+(\d+)\s+responses", stdout):
            code, count = int(m_line.group(1)), int(m_line.group(2))
            total_requests += count
            if code >= 400:
                errors += count

        if not total_requests:
            m = re.search(r"Total:\s+(\d+)", stdout)
            if m:
                total_requests = int(m.group(1))

        print(f"  {elapsed:>5}s  {final_rss:>8.1f}  {final_conns:>6}  (final)")

        result = {
            "name": name,
            "rps": rps,
            "avg_latency_ms": avg_latency,
            "p99_latency_ms": p99_latency,
            "initial_rss": initial_rss,
            "final_rss": final_rss,
            "peak_rss": peak_rss,
            "rss_growth": final_rss - initial_rss,
            "peak_conns": peak_conns,
            "final_conns": final_conns,
            "total_requests": total_requests,
            "errors": errors,
        }

        print(f"\n  Requests/sec:  {rps:,.0f}")
        print(f"  Avg latency:   {avg_latency:.1f} ms")
        print(f"  P99 latency:   {p99_latency:.1f} ms")
        print(
            f"  RSS growth:    {initial_rss:.0f} → {final_rss:.0f} MB "
            f"(peak {peak_rss:.0f} MB)"
        )
        print(f"  Valkey conns:  peak {peak_conns}, final {final_conns}")
        if errors:
            print(f"  Errors:        {errors}")

        return result

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        time.sleep(1)


def main():
    parser = argparse.ArgumentParser(
        description="django-vcache vs Django RedisCache benchmark"
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=60,
        help="Duration per test in seconds (default: 60)",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=300,
        help="Concurrent connections (default: 300)",
    )
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args()

    print("Benchmark: django-vcache vs Django RedisCache")
    print(f"granian ASGI, {args.concurrency} concurrent, {args.duration}s each")

    tests = [
        ("django-vcache", "sample.settings"),
        ("Django RedisCache", "sample.settings_django"),
    ]

    results = []
    for name, settings in tests:
        r = run_benchmark(name, settings, args.duration, args.concurrency, args.port)
        if r:
            results.append(r)

    if len(results) == 2:
        vc, dj = results[0], results[1]

        print(f"\n{'=' * 70}")
        print("  COMPARISON")
        print(f"{'=' * 70}")

        w = 20
        print(f"\n  {'':>{w}}  {'vcache':>12}  {'RedisCache':>12}  {'diff':>10}")
        print(f"  {'─' * w}  {'─' * 12}  {'─' * 12}  {'─' * 10}")

        rps_diff = (vc["rps"] / dj["rps"] - 1) * 100 if dj["rps"] else 0
        print(
            f"  {'Requests/sec':>{w}}  {vc['rps']:>12,.0f}  "
            f"{dj['rps']:>12,.0f}  {rps_diff:>+9.0f}%"
        )

        print(
            f"  {'Avg latency (ms)':>{w}}  {vc['avg_latency_ms']:>12.1f}  "
            f"{dj['avg_latency_ms']:>12.1f}"
        )

        print(
            f"  {'P99 latency (ms)':>{w}}  {vc['p99_latency_ms']:>12.1f}  "
            f"{dj['p99_latency_ms']:>12.1f}"
        )

        print(
            f"  {'Peak RSS (MB)':>{w}}  {vc['peak_rss']:>12.0f}  "
            f"{dj['peak_rss']:>12.0f}  "
            f"{vc['peak_rss'] - dj['peak_rss']:>+9.0f}"
        )

        print(
            f"  {'Peak Valkey conns':>{w}}  {vc['peak_conns']:>12}  "
            f"{dj['peak_conns']:>12}"
        )

        if vc["errors"] or dj["errors"]:
            print(f"  {'Errors':>{w}}  {vc['errors']:>12}  {dj['errors']:>12}")

        print()


if __name__ == "__main__":
    main()
