use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyList, PyString, PyTuple};
use std::sync::OnceLock;
use tokio::runtime::Runtime;
use tokio::sync::oneshot;

static RUNTIME: OnceLock<Runtime> = OnceLock::new();

pub fn get_runtime() -> &'static Runtime {
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("Failed to create tokio runtime")
    })
}

// =========================================================================
// Result types — Rust-native, no GIL needed to construct
// =========================================================================

pub enum RawResult {
    OptBytes(Option<Vec<u8>>),
    Bool(bool),
    Int(i64),
    OptBytesList(Vec<Option<Vec<u8>>>),
    BytesList(Vec<Vec<u8>>),
    StringList(Vec<String>),
    OptKeyAndBytesList(Option<(String, Vec<Vec<u8>>)>),
    Error(String),
}

impl RawResult {
    pub fn into_py(self, py: Python<'_>) -> Result<Py<PyAny>, PyErr> {
        match self {
            RawResult::OptBytes(Some(b)) => Ok(PyBytes::new(py, &b).into_any().unbind()),
            RawResult::OptBytes(None) => Ok(py.None()),
            RawResult::Bool(b) => {
                Ok(b.into_pyobject(py).unwrap().to_owned().into_any().unbind())
            }
            RawResult::Int(n) => Ok(n.into_pyobject(py).unwrap().into_any().unbind()),
            RawResult::OptBytesList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .into_iter()
                    .map(|r| match r {
                        Some(bytes) => PyBytes::new(py, &bytes).into_any().unbind(),
                        None => py.None(),
                    })
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::BytesList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .iter()
                    .map(|b| PyBytes::new(py, b).into_any().unbind())
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::StringList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .iter()
                    .map(|s| PyString::new(py, s).into_any().unbind())
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::OptKeyAndBytesList(Some((key, values))) => {
                let py_values: Vec<Py<PyAny>> = values
                    .iter()
                    .map(|b| PyBytes::new(py, b).into_any().unbind())
                    .collect();
                let py_key = PyString::new(py, &key).into_any().unbind();
                let py_list = PyList::new(py, py_values)?.into_any().unbind();
                Ok(PyTuple::new(py, [py_key, py_list])?.into_any().unbind())
            }
            RawResult::OptKeyAndBytesList(None) => Ok(py.None()),
            RawResult::Error(e) => Err(pyo3::exceptions::PyConnectionError::new_err(e)),
        }
    }
}

// =========================================================================
// RustAwaitable — zero-Future async bridge
//
// Instead of creating an asyncio.Future (which requires GIL acquisition
// on the completion path and forms Task↔Future reference cycles), we
// implement Python's awaitable protocol directly. The tokio task sends
// its result through a oneshot channel; the event loop polls __next__
// via lock-free try_recv() until the result appears.
//
// Tradeoff: we busy-yield (return None to the event loop) instead of
// sleeping until notified. Each poll is a single atomic load — no
// syscall, no GIL. Under high concurrency this scales better than the
// Future approach, which would need GIL acquisition per completion.
// =========================================================================

#[pyclass]
pub struct RustAwaitable {
    rx: Option<oneshot::Receiver<RawResult>>,
}

#[pymethods]
impl RustAwaitable {
    fn __await__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __iter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __next__(&mut self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        let rx = self.rx.as_mut().ok_or_else(|| {
            pyo3::exceptions::PyRuntimeError::new_err("awaitable already consumed")
        })?;
        match rx.try_recv() {
            Ok(result) => {
                self.rx = None;
                let py_val = result.into_py(py)?;
                // Build StopIteration with .value set directly.
                // We can't use PyStopIteration::new_err(py_val) because
                // PyO3 unpacks tuples into *args, and StopIteration.value
                // only returns the first arg when given multiple args.
                let stop = py
                    .get_type::<pyo3::exceptions::PyStopIteration>()
                    .call1((py_val,))?;
                Err(PyErr::from_value(stop.into_any()))
            }
            Err(oneshot::error::TryRecvError::Empty) => {
                // Not ready — yield control back to the event loop.
                Ok(py.None())
            }
            Err(oneshot::error::TryRecvError::Closed) => {
                self.rx = None;
                Err(pyo3::exceptions::PyRuntimeError::new_err(
                    "operation was dropped",
                ))
            }
        }
    }
}

impl RustAwaitable {
    pub fn new() -> (Self, oneshot::Sender<RawResult>) {
        let (tx, rx) = oneshot::channel();
        (RustAwaitable { rx: Some(rx) }, tx)
    }
}
