mod async_bridge;
mod client;
mod connection;

use pyo3::prelude::*;

#[pymodule]
fn _driver(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<client::RustValkeyDriver>()?;
    m.add_class::<async_bridge::RustAwaitable>()?;
    Ok(())
}
