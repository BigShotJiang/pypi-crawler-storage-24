# Benchmarks

Measured on Python 3.14 with granian ASGI server, 300 concurrent connections, 60 seconds per test. Each request performs 6 cache operations (get, get_many, set, set compressed, incr, get compressed). Both backends hitting the same local Valkey instance.

| | django-vcache | Django RedisCache | Change |
|---|---|---|---|
| **Requests/sec** | 1,518 | 113 | **+1,243%** |
| **Peak RSS** | 135 MB | 508 MB | **-73%** |
| **Valkey connections** | 2 | 3,654 | |

## Why the difference?

Django's `RedisCache` wraps every async call in `sync_to_async`, spawning a thread per operation. Under load this creates thousands of connections and unbounded memory growth.

django-vcache uses a single multiplexed connection with native async I/O via a Rust driver. No connection pool to tune, no threads per operation.

## Reproduce

```bash
docker compose run --rm app python bench_compare.py
```
