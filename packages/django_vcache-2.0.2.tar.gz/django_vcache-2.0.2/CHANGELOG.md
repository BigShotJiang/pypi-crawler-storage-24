# Changelog

## 2.0.2

### Bug fixes

- **Fix blmpop with count=1** — Always send the `COUNT` argument to `BLMPOP`. Without it, Redis returns a flat `[key, element]` instead of `[key, [element]]`, which broke response parsing.

## 2.0.1

### Bug fixes

- **Fix blmpop response parsing** — `BLMPOP` returned only the key name instead of `(key, [elements...])`. The redis crate's `FromRedisValue` doesn't handle the nested response format correctly; now parsed manually.
- **Fix StopIteration tuple unpacking** — PyO3's `new_err()` unpacked tuple return values into multiple args, causing `StopIteration.value` to lose all but the first element. Affected any driver method returning a tuple (e.g. `blmpop`).
- **Increase ConnectionManager response timeout** — Default was too aggressive for concurrent workloads with blocking operations. Increased to 30s.

### Other changes

- Switch zstd fallback from `zstd` to `pyzstd` (the library Python 3.14's `compression.zstd` is based on, per PEP 784).

## 2.0.0

Complete rewrite of the I/O layer. Replaces valkey-py with a thin Rust driver (via PyO3) for native async I/O and multiplexed connections.

### What changed

- **Rust I/O driver** — Single multiplexed connection handles all sync and async operations. No connection pool to tune.
- **Native async** — True async I/O instead of `sync_to_async` thread-pool wrappers.
- **TLS support** — `rediss://` and `valkeys://` URLs work out of the box (via rustls, no OpenSSL dependency).
- **Cluster mode** — `CLUSTER_MODE: True` option for Valkey/Redis Cluster (auto-discovers nodes).
- **Sentinel failover** — Automatic re-discovery on failover errors.
- **Atomic incr/decr** — Uses native Redis `INCRBY`/`DECRBY`. Keys created on first use.
- **Pickle serializer option** — `"SERIALIZER": "pickle"` for projects that need to cache arbitrary Python objects.
- **Django 6.0 support** — Tested on Django 5.0–6.0, Python 3.12–3.14.

### Benchmarks

Python 3.14, granian ASGI, 300 concurrent connections, 60 seconds per test.
Each request performs 6 cache operations (get, get_many, set, set compressed, incr, get compressed).

| | django-vcache 2.0 | django-vcache 1.x (valkey-py) | Change |
|---|---|---|---|
| **Requests/sec** | 1,518 | 113 | **+1,243%** |
| **Peak RSS** | 135 MB | 508 MB | **−73%** |
| **Valkey connections** | 2 | 3,654 | |

### Breaking changes

- Requires a Rust toolchain to build from source (pre-built wheels available for common platforms).
- `get_raw_client()` now returns the Rust driver instance, not a valkey-py client.
- Removed valkey-py dependency.

## 1.0.0

Initial stable release. We'll begin to use semantic versioning.

- Use msgpack serialization
