import asyncio
import pickle
import sys
import threading
import time
import uuid
from functools import wraps
from urllib.parse import urlparse

import ormsgpack
from django.core.cache.backends.base import DEFAULT_TIMEOUT, BaseCache

from django_vcache._driver import RustValkeyDriver

if sys.version_info >= (3, 14):
    from compression.zstd import compress as _zstd_compress
    from compression.zstd import decompress as _zstd_decompress
else:
    from pyzstd import compress as _zstd_compress
    from pyzstd import decompress as _zstd_decompress

# Wire format prefixes — first byte identifies serializer + compression.
# Using distinct prefixes means mismatched serializer config won't silently
# corrupt data; it will fall through to the int fallback or return None.
_MSGPACK_RAW = b"m"
_MSGPACK_ZSTD = b"M"
_PICKLE_RAW = b"p"
_PICKLE_ZSTD = b"P"
_MISSING = object()

# Global client registry (one connection per location+mode)
_CLIENTS: dict[str, RustValkeyDriver] = {}
_CLIENTS_LOCK = threading.Lock()


def _default_for(func_name, args, kwargs):
    if func_name in ("get", "aget"):
        if "default" in kwargs:
            return kwargs["default"]
        return args[1] if len(args) > 1 else None
    if func_name in (
        "set",
        "aset",
        "add",
        "aadd",
        "delete",
        "adelete",
        "touch",
        "atouch",
    ):
        return False
    if func_name in ("incr", "aincr", "decr", "adecr"):
        return 0
    if func_name in ("has_key", "ahas_key"):
        return False
    if func_name in ("get_many", "aget_many"):
        return {}
    if func_name in ("set_many", "aset_many"):
        return []
    if func_name in ("delete_many", "adelete_many"):
        return None
    return None


def ignore_connection_errors(func):
    if asyncio.iscoroutinefunction(func):

        @wraps(func)
        async def wrapper(self, *args, **kwargs):
            if not self._ignore_exceptions:
                return await func(self, *args, **kwargs)
            try:
                return await func(self, *args, **kwargs)
            except ConnectionError:
                return _default_for(func.__name__, args, kwargs)

        return wrapper

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if not self._ignore_exceptions:
            return func(self, *args, **kwargs)
        try:
            return func(self, *args, **kwargs)
        except ConnectionError:
            return _default_for(func.__name__, args, kwargs)

    return wrapper


def _parse_sentinel_url(url):
    parts = urlparse(url)
    sentinels = []
    for sentinel_host in parts.netloc.split(","):
        host, port = sentinel_host.split(":")
        sentinels.append(f"redis://{host}:{port}")
    path_parts = parts.path.strip("/").split("/")
    service_name = path_parts[0]
    db = int(path_parts[1]) if len(path_parts) > 1 else 0
    return sentinels, service_name, db


class ValkeyLock:
    """Distributed lock using Rust driver's lock operations."""

    def __init__(
        self,
        driver,
        key,
        timeout=None,
        sleep=0.1,
        blocking=True,
        blocking_timeout=None,
    ):
        self._driver = driver
        self._key = key
        self._timeout = timeout
        self._sleep = sleep
        self._blocking = blocking
        self._blocking_timeout = blocking_timeout
        self._token = str(uuid.uuid4())
        self._owned = False

    def _timeout_ms(self):
        if self._timeout is not None:
            return int(self._timeout * 1000)
        return None

    def acquire(self):
        timeout_ms = self._timeout_ms()
        if not self._blocking:
            self._owned = self._driver.lock_acquire_sync(
                self._key, self._token, timeout_ms
            )
            return self._owned
        deadline = time.monotonic() + (self._blocking_timeout or float("inf"))
        while time.monotonic() < deadline:
            if self._driver.lock_acquire_sync(self._key, self._token, timeout_ms):
                self._owned = True
                return True
            time.sleep(self._sleep)
        return False

    async def aacquire(self):
        timeout_ms = self._timeout_ms()
        if not self._blocking:
            self._owned = await self._driver.lock_acquire(
                self._key, self._token, timeout_ms
            )
            return self._owned
        deadline = time.monotonic() + (self._blocking_timeout or float("inf"))
        while time.monotonic() < deadline:
            acquired = await self._driver.lock_acquire(
                self._key, self._token, timeout_ms
            )
            if acquired:
                self._owned = True
                return True
            await asyncio.sleep(self._sleep)
        return False

    def release(self):
        if self._owned:
            self._driver.lock_release_sync(self._key, self._token)
            self._owned = False

    async def arelease(self):
        if self._owned:
            await self._driver.lock_release(self._key, self._token)
            self._owned = False

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *args):
        self.release()

    async def __aenter__(self):
        return await self.aacquire()

    async def __aexit__(self, *args):
        await self.arelease()


class ValkeyCache(BaseCache):
    def __init__(self, server, params):
        super().__init__(params)
        self._location = server or "redis://127.0.0.1:6379/1"
        options = params.get("OPTIONS", {})
        self._compress_min_len = options.get("COMPRESS_MIN_LEN", 1024)
        self._ignore_exceptions = options.get("IGNORE_EXCEPTIONS", False)
        self._cluster_mode = options.get("CLUSTER_MODE", False)
        self._driver_instance = None

        serializer = options.get("SERIALIZER", "msgpack")
        if serializer == "pickle":
            self._prefix_raw = _PICKLE_RAW
            self._prefix_zstd = _PICKLE_ZSTD
            self._dumps = pickle.dumps
            self._loads = pickle.loads
        elif serializer == "msgpack":
            self._prefix_raw = _MSGPACK_RAW
            self._prefix_zstd = _MSGPACK_ZSTD
            self._dumps = ormsgpack.packb
            self._loads = ormsgpack.unpackb
        else:
            raise ValueError(
                f"Unknown SERIALIZER: {serializer!r}. Use 'msgpack' or 'pickle'."
            )

    @property
    def _driver(self):
        if self._driver_instance is None:
            self._driver_instance = self._get_or_create_driver()
        return self._driver_instance

    @_driver.setter
    def _driver(self, value):
        self._driver_instance = value

    def _get_or_create_driver(self):
        key = str((self._location, self._cluster_mode))
        if key in _CLIENTS:
            return _CLIENTS[key]
        with _CLIENTS_LOCK:
            if key in _CLIENTS:
                return _CLIENTS[key]
            if self._location.startswith("sentinel://"):
                sentinel_urls, service_name, db = _parse_sentinel_url(self._location)
                driver = RustValkeyDriver.connect_via_sentinel(
                    sentinel_urls, service_name, db
                )
            elif self._cluster_mode:
                urls = [u.strip() for u in self._location.split(",") if u.strip()]
                driver = RustValkeyDriver.connect_to_cluster(urls)
            else:
                driver = RustValkeyDriver.connect(self._location)
            _CLIENTS[key] = driver
            return driver

    def get_raw_client(self):
        """Returns the underlying Rust driver instance."""
        return self._driver

    def _encode(self, value):
        # Store integers as raw strings so Redis INCRBY/DECRBY work natively.
        if isinstance(value, int) and not isinstance(value, bool):
            return str(value).encode()
        data = self._dumps(value)
        if self._compress_min_len and len(data) >= self._compress_min_len:
            return self._prefix_zstd + _zstd_compress(data)
        return self._prefix_raw + data

    def _decode(self, raw):
        if raw is None:
            return None
        prefix = raw[:1]
        if prefix in (_MSGPACK_ZSTD, _PICKLE_ZSTD):
            return self._loads(_zstd_decompress(raw[1:]))
        if prefix in (_MSGPACK_RAW, _PICKLE_RAW):
            return self._loads(raw[1:])
        # Raw integer (no wire prefix) — stored for native INCRBY support.
        try:
            return int(raw)
        except (ValueError, TypeError):
            pass
        return None

    def _get_expiration_time(self, timeout):
        if timeout is DEFAULT_TIMEOUT:
            timeout = self.default_timeout
        if timeout is None:
            return None
        if timeout == 0:
            return 0
        return int(timeout)

    # =================================================================
    # Sync methods
    # =================================================================

    @ignore_connection_errors
    def get(self, key, default=None, version=None):
        _key = self.make_key(key, version=version)
        data = self._driver.get_sync(_key)
        if data is None:
            return default
        return self._decode(data)

    @ignore_connection_errors
    def set(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            self._driver.delete_sync(_key)
            return True
        wire = self._encode(value)
        self._driver.set_sync(_key, wire, ttl)
        return True

    @ignore_connection_errors
    def add(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            return False
        wire = self._encode(value)
        return self._driver.set_nx_sync(_key, wire, ttl)

    @ignore_connection_errors
    def delete(self, key, version=None):
        _key = self.make_key(key, version=version)
        return self._driver.delete_sync(_key) > 0

    def close(self, **kwargs):
        pass

    @ignore_connection_errors
    def touch(self, key, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            return self._driver.delete_sync(_key) > 0
        if ttl is None:
            return self._driver.persist_sync(_key)
        return self._driver.expire_sync(_key, ttl)

    @ignore_connection_errors
    def incr(self, key, delta=1, version=None):
        _key = self.make_key(key, version=version)
        try:
            return self._driver.incr_by_sync(_key, delta)
        except ConnectionError as e:
            if "not an integer" in str(e):
                raise ValueError("Key '%s' contains a non-integer value." % key) from e
            raise

    @ignore_connection_errors
    def decr(self, key, delta=1, version=None):
        _key = self.make_key(key, version=version)
        try:
            return self._driver.incr_by_sync(_key, -delta)
        except ConnectionError as e:
            if "not an integer" in str(e):
                raise ValueError("Key '%s' contains a non-integer value." % key) from e
            raise

    @ignore_connection_errors
    def has_key(self, key, version=None):
        _key = self.make_key(key, version=version)
        return self._driver.exists_sync(_key)

    @ignore_connection_errors
    def get_many(self, keys, version=None):
        if not keys:
            return {}
        key_map = {self.make_key(k, version=version): k for k in keys}
        raw_keys = list(key_map.keys())
        raw_values = self._driver.mget_sync(raw_keys)
        result = {}
        for raw_key, raw_val in zip(raw_keys, raw_values):
            if raw_val is not None:
                val = self._decode(raw_val)
                if val is not None:
                    result[key_map[raw_key]] = val
        return result

    @ignore_connection_errors
    def set_many(self, mapping, timeout=DEFAULT_TIMEOUT, version=None):
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            self.delete_many(list(mapping.keys()), version=version)
            return []
        entries = []
        for key, value in mapping.items():
            _key = self.make_key(key, version=version)
            wire = self._encode(value)
            entries.append((_key, wire))
        self._driver.pipeline_set_sync(entries, ttl)
        return list(mapping.keys())

    @ignore_connection_errors
    def delete_many(self, keys, version=None):
        if not keys:
            return
        _keys = [self.make_key(k, version=version) for k in keys]
        self._driver.delete_many_sync(_keys)

    def get_or_set(self, key, default, timeout=DEFAULT_TIMEOUT, version=None):
        val = self.get(key, default=_MISSING, version=version)
        if val is not _MISSING:
            return val
        if callable(default):
            default = default()
        self.add(key, default, timeout=timeout, version=version)
        return self.get(key, default=default, version=version)

    def lock(
        self,
        key,
        version=None,
        timeout=None,
        sleep=0.1,
        blocking=True,
        blocking_timeout=None,
    ):
        if self._cluster_mode:
            raise NotImplementedError("Locking is not supported in cluster mode.")
        _key = self.make_key(key, version=version)
        return ValkeyLock(
            self._driver, _key, timeout, sleep, blocking, blocking_timeout
        )

    @ignore_connection_errors
    def clear(self):
        self._driver.flushdb_sync()

    # =================================================================
    # Async methods
    # =================================================================

    @ignore_connection_errors
    async def aget(self, key, default=None, version=None):
        _key = self.make_key(key, version=version)
        data = await self._driver.get(_key)
        if data is None:
            return default
        return self._decode(data)

    @ignore_connection_errors
    async def aset(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            await self._driver.delete(_key)
            return True
        wire = self._encode(value)
        await self._driver.set(_key, wire, ttl)
        return True

    @ignore_connection_errors
    async def aadd(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            return False
        wire = self._encode(value)
        return await self._driver.set_nx(_key, wire, ttl)

    @ignore_connection_errors
    async def adelete(self, key, version=None):
        _key = self.make_key(key, version=version)
        return (await self._driver.delete(_key)) > 0

    async def aclose(self, **kwargs):
        pass

    @ignore_connection_errors
    async def atouch(self, key, timeout=DEFAULT_TIMEOUT, version=None):
        _key = self.make_key(key, version=version)
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            return (await self._driver.delete(_key)) > 0
        if ttl is None:
            return await self._driver.persist(_key)
        return await self._driver.expire(_key, ttl)

    @ignore_connection_errors
    async def aincr(self, key, delta=1, version=None):
        _key = self.make_key(key, version=version)
        try:
            return await self._driver.incr_by(_key, delta)
        except ConnectionError as e:
            if "not an integer" in str(e):
                raise ValueError("Key '%s' contains a non-integer value." % key) from e
            raise

    @ignore_connection_errors
    async def adecr(self, key, delta=1, version=None):
        _key = self.make_key(key, version=version)
        try:
            return await self._driver.incr_by(_key, -delta)
        except ConnectionError as e:
            if "not an integer" in str(e):
                raise ValueError("Key '%s' contains a non-integer value." % key) from e
            raise

    @ignore_connection_errors
    async def ahas_key(self, key, version=None):
        _key = self.make_key(key, version=version)
        return await self._driver.exists(_key)

    @ignore_connection_errors
    async def aget_many(self, keys, version=None):
        if not keys:
            return {}
        key_map = {self.make_key(k, version=version): k for k in keys}
        raw_keys = list(key_map.keys())
        raw_values = await self._driver.mget(raw_keys)
        result = {}
        for raw_key, raw_val in zip(raw_keys, raw_values):
            if raw_val is not None:
                val = self._decode(raw_val)
                if val is not None:
                    result[key_map[raw_key]] = val
        return result

    @ignore_connection_errors
    async def aset_many(self, mapping, timeout=DEFAULT_TIMEOUT, version=None):
        ttl = self._get_expiration_time(timeout)
        if ttl == 0:
            await self.adelete_many(list(mapping.keys()), version=version)
            return []
        entries = []
        for key, value in mapping.items():
            _key = self.make_key(key, version=version)
            wire = self._encode(value)
            entries.append((_key, wire))
        await self._driver.pipeline_set(entries, ttl)
        return list(mapping.keys())

    @ignore_connection_errors
    async def adelete_many(self, keys, version=None):
        if not keys:
            return
        _keys = [self.make_key(k, version=version) for k in keys]
        await self._driver.delete_many(_keys)

    async def aget_or_set(self, key, default, timeout=DEFAULT_TIMEOUT, version=None):
        val = await self.aget(key, default=_MISSING, version=version)
        if val is not _MISSING:
            return val
        if callable(default):
            default = default()
        await self.aadd(key, default, timeout=timeout, version=version)
        return await self.aget(key, default=default, version=version)

    def alock(
        self,
        key,
        version=None,
        timeout=None,
        sleep=0.1,
        blocking=True,
        blocking_timeout=None,
    ):
        if self._cluster_mode:
            raise NotImplementedError("Locking is not supported in cluster mode.")
        _key = self.make_key(key, version=version)
        return ValkeyLock(
            self._driver, _key, timeout, sleep, blocking, blocking_timeout
        )

    @ignore_connection_errors
    async def aclear(self):
        await self._driver.flushdb()
