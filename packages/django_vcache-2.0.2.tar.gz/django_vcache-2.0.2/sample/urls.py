from django.urls import path

from . import views

urlpatterns = [
    path("set/", views.set_cache, name="set_cache"),
    path("get/", views.get_cache, name="get_cache"),
    path("incr/", views.incr_counter, name="incr_counter"),
    path("async/set/", views.async_set_cache, name="async_set_cache"),
    path("async/get/", views.async_get_cache, name="async_get_cache"),
    path("async/incr/", views.async_incr_counter, name="async_incr_counter"),
    path("bench/seed/", views.bench_seed, name="bench_seed"),
    path("bench/mixed/", views.bench_mixed, name="bench_mixed"),
    path("bench/sync/", views.bench_sync, name="bench_sync"),
    path("bench/mixed-gc/", views.bench_mixed_gc, name="bench_mixed_gc"),
    path("bench/gc/", views.bench_gc, name="bench_gc"),
]
