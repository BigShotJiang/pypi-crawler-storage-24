import gc
import time

from django.core.cache import cache
from django.http import HttpResponse

# Pre-built payloads for benchmark (avoid measuring Python dict creation)
_BENCH_SMALL = {"user": "alice", "role": "admin", "ts": 1709900000}
_BENCH_LARGE = {
    "event": {
        "id": "abc123",
        "message": "NullPointerException in com.example.App",
        "level": "error",
        "platform": "java",
        "tags": {f"tag_{i}": f"value_{i}" for i in range(30)},
        "extra": {f"key_{i}": "x" * 50 for i in range(20)},
    }
}  # ~2.5KB serialized, triggers zstd compression


def set_cache(request):
    """
    Sets a value in the cache.
    """
    key = "my_key"
    value = f"Hello from vcache! The time is {time.time()}"
    cache.set(key, value, 30)
    return HttpResponse(f"Set '{key}' to '{value}' in cache.")


async def async_set_cache(request):
    """
    Sets a value in the cache asynchronously.
    """
    key = "my_key"
    value = f"Hello from vcache! The time is {time.time()}"
    await cache.aset(key, value, 30)
    return HttpResponse(f"Set '{key}' to '{value}' in cache asynchronously.")


def get_cache(request):
    """
    Gets a value from the cache.
    """
    key = "my_key"
    value = cache.get(key)
    if value:
        return HttpResponse(f"Got '{value}' from cache for key '{key}'.")
    else:
        return HttpResponse(f"Key '{key}' not found in cache.")


async def async_get_cache(request):
    """
    Gets a value from the cache asynchronously.
    """
    key = "my_key"
    value = await cache.aget(key)
    if value:
        return HttpResponse(f"Got '{value}' from cache for key '{key}'.")
    else:
        return HttpResponse(f"Key '{key}' not found in cache.")


def incr_counter(request):
    """
    Increments a counter in the cache.
    """
    key = "my_counter"
    try:
        new_value = cache.incr(key)
    except ValueError:
        # If the key doesn't exist, set it to 1
        cache.set(key, 1)
        new_value = 1
    return HttpResponse(f"Counter '{key}' is now {new_value}.")


async def async_incr_counter(request):
    """
    Increments a counter in the cache asynchronously.
    """
    key = "my_counter"
    try:
        new_value = await cache.aincr(key)
    except ValueError:
        # If the key doesn't exist, set it to 1
        await cache.aset(key, 1)
        new_value = 1
    return HttpResponse(f"Counter '{key}' is now {new_value}.")


async def bench_seed(request):
    """Seed cache with data for benchmark reads."""
    await cache.aset("bench:s1", _BENCH_SMALL, 300)
    await cache.aset("bench:s2", _BENCH_SMALL, 300)
    await cache.aset("bench:s3", _BENCH_SMALL, 300)
    await cache.aset("bench:large", _BENCH_LARGE, 300)
    # incr auto-creates, but seed to avoid first-request variance
    await cache.aset("bench:counter", 0, 300)
    return HttpResponse("seeded")


async def bench_gc(request):
    """Force garbage collection and report stats."""
    import resource

    collected = gc.collect()
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return HttpResponse(f"gc collected {collected} objects, maxrss={rss} KB")


def bench_sync(request):
    """Sync-only benchmark (no asyncio futures)."""
    cache.get("bench:s1")
    cache.get("bench:s1")
    cache.get("bench:s2")
    cache.get("bench:s3")
    cache.set("bench:s1", _BENCH_SMALL, 300)
    cache.set("bench:large", _BENCH_LARGE, 300)
    cache.incr("bench:counter")
    cache.get("bench:large")
    return HttpResponse("ok")


_bench_counter = 0


async def bench_mixed_gc(request):
    """bench_mixed + periodic gc.collect() every 100 requests."""
    global _bench_counter
    _bench_counter += 1
    if _bench_counter % 100 == 0:
        gc.collect()
    await cache.aget("bench:s1")
    await cache.aget_many(["bench:s1", "bench:s2", "bench:s3"])
    await cache.aset("bench:s1", _BENCH_SMALL, 300)
    await cache.aset("bench:large", _BENCH_LARGE, 300)
    await cache.aincr("bench:counter")
    await cache.aget("bench:large")
    return HttpResponse("ok")


async def bench_mixed(request):
    """
    Mixed-load benchmark endpoint. Each request does 6 cache operations:
    1. get — small value (session/user lookup)
    2. get_many — 3 small keys (batch read)
    3. set — small value (update session)
    4. set — large value (~2.5KB, triggers zstd compression)
    5. incr — atomic counter (raw integer, no msgpack)
    6. get — large value (read back compressed data)
    """
    # 1. Small get
    await cache.aget("bench:s1")
    # 2. Batch read
    await cache.aget_many(["bench:s1", "bench:s2", "bench:s3"])
    # 3. Small set
    await cache.aset("bench:s1", _BENCH_SMALL, 300)
    # 4. Large set (compressed)
    await cache.aset("bench:large", _BENCH_LARGE, 300)
    # 5. Atomic incr (raw integer, no serialization)
    await cache.aincr("bench:counter")
    # 6. Large get (decompress)
    await cache.aget("bench:large")
    return HttpResponse("ok")
