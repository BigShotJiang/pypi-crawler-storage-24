import os
import unittest
from unittest.mock import MagicMock, patch

from django.core.cache import CacheHandler, cache
from django.test import TestCase, override_settings

from django_vcache import backend as vcache_backend


class LocationTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()

    @override_settings(
        CACHES={
            "custom": {
                "BACKEND": "django_vcache.backend.ValkeyCache",
                "LOCATION": "redis://custom-host:9999/5",
            },
        }
    )
    def test_custom_location_is_respected(self):
        from django.core.cache import caches

        custom_cache = caches["custom"]
        self.assertEqual(custom_cache._location, "redis://custom-host:9999/5")

    @override_settings(
        CACHES={
            "rediss": {
                "BACKEND": "django_vcache.backend.ValkeyCache",
                "LOCATION": "rediss://default:password@secure-server:25061/1",
            },
        }
    )
    def test_rediss_location_with_auth(self):
        from django.core.cache import caches

        rediss_cache = caches["rediss"]
        self.assertEqual(
            rediss_cache._location,
            "rediss://default:password@secure-server:25061/1",
        )


class ValkeyCacheBackendTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    def test_singleton_driver(self):
        caches = CacheHandler()
        cache1 = caches["default"]
        cache2 = caches["default"]
        self.assertIs(cache1.get_raw_client(), cache2.get_raw_client())

    def test_sync_operations(self):
        self.assertTrue(cache.set("key1", "value1", 60))
        self.assertEqual(cache.get("key1"), "value1")
        self.assertEqual(cache.get("non_existent_key"), None)

        self.assertTrue(cache.add("key2", "value2", 60))
        self.assertFalse(cache.add("key2", "new_value2", 60))
        self.assertEqual(cache.get("key2"), "value2")

        self.assertTrue(cache.delete("key1"))
        self.assertIsNone(cache.get("key1"))
        self.assertFalse(cache.delete("non_existent_key"))

        cache.set("num_key", 10)
        self.assertEqual(cache.incr("num_key"), 11)
        self.assertEqual(cache.incr("num_key", 5), 16)
        self.assertEqual(cache.decr("num_key"), 15)
        self.assertEqual(cache.decr("num_key", 3), 12)
        # INCRBY on missing key creates it (Redis native behavior)
        self.assertEqual(cache.incr("non_existent_num_key"), 1)

        self.assertTrue(cache.has_key("num_key"))
        self.assertFalse(cache.has_key("non_existent_key"))

        cache.set("temp_key", "temp_value", 0)
        self.assertIsNone(cache.get("temp_key"))

        cache.add("add_temp_key", "add_temp_value", 0)
        self.assertIsNone(cache.get("add_temp_key"))

        cache.set("touch_key", "touch_value", 1)
        self.assertEqual(cache.get("touch_key"), "touch_value")
        self.assertTrue(cache.touch("touch_key", 100))
        self.assertEqual(cache.get("touch_key"), "touch_value")
        self.assertTrue(cache.touch("touch_key", 0))
        self.assertIsNone(cache.get("touch_key"))
        self.assertFalse(cache.touch("non_existent_touch_key", 100))

    async def test_async_operations(self):
        self.assertTrue(await cache.aset("akey1", "avalue1", 60))
        self.assertEqual(await cache.aget("akey1"), "avalue1")
        self.assertEqual(await cache.aget("non_existent_akey"), None)

        self.assertTrue(await cache.aadd("akey2", "avalue2", 60))
        self.assertFalse(await cache.aadd("akey2", "anew_value2", 60))
        self.assertEqual(await cache.aget("akey2"), "avalue2")

        self.assertTrue(await cache.adelete("akey1"))
        self.assertIsNone(await cache.aget("akey1"))
        self.assertFalse(await cache.adelete("non_existent_akey"))

        await cache.aset("anum_key", 10)
        self.assertEqual(await cache.aincr("anum_key"), 11)
        self.assertEqual(await cache.aincr("anum_key", 5), 16)
        self.assertEqual(await cache.adecr("anum_key"), 15)
        self.assertEqual(await cache.adecr("anum_key", 3), 12)
        # INCRBY on missing key creates it (Redis native behavior)
        self.assertEqual(await cache.aincr("non_existent_anum_key"), 1)

        self.assertTrue(await cache.ahas_key("anum_key"))
        self.assertFalse(await cache.ahas_key("non_existent_akey"))

        await cache.aset("atemp_key", "atemp_value", 0)
        self.assertIsNone(await cache.aget("atemp_key"))

        await cache.aadd("aadd_temp_key", "aadd_temp_value", 0)
        self.assertIsNone(await cache.aget("aadd_temp_key"))

        await cache.aset("atouch_key", "atouch_value", 1)
        self.assertEqual(await cache.aget("atouch_key"), "atouch_value")
        self.assertTrue(await cache.atouch("atouch_key", 100))
        self.assertEqual(await cache.aget("atouch_key"), "atouch_value")
        self.assertTrue(await cache.atouch("atouch_key", 0))
        self.assertIsNone(await cache.aget("atouch_key"))
        self.assertFalse(await cache.atouch("non_existent_atouch_key", 100))

    def test_close_is_noop(self):
        cache.set("before_close", "value")
        cache.close()
        self.assertEqual(cache.get("before_close"), "value")


@override_settings(
    CACHES={
        "default": {
            "BACKEND": "django_vcache.backend.ValkeyCache",
            "LOCATION": "redis://valkey:6379/1",
        },
        "resilient": {
            "BACKEND": "django_vcache.backend.ValkeyCache",
            "LOCATION": "redis://valkey:6379/1",
            "OPTIONS": {
                "IGNORE_EXCEPTIONS": True,
            },
        },
    }
)
class ResilienceTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()

    @patch(
        "django_vcache._driver.RustValkeyDriver",
        new_callable=lambda: type(
            "MockDriver",
            (),
            {
                attr: MagicMock(side_effect=ConnectionError)
                for attr in [
                    "get_sync",
                    "set_sync",
                    "set_nx_sync",
                    "delete_sync",
                    "expire_sync",
                    "persist_sync",
                    "incr_by_sync",
                    "exists_sync",
                    "flushdb_sync",
                ]
            },
        ),
    )
    def test_sync_resilience(self, mock_driver):
        vcache_backend._CLIENTS.clear()
        resilient_cache = cache._connections["resilient"]
        resilient_cache._driver = mock_driver
        self.assertIsNone(resilient_cache.get("key"))
        self.assertFalse(resilient_cache.set("key", "value"))
        self.assertFalse(resilient_cache.add("key", "value"))
        self.assertFalse(resilient_cache.delete("key"))
        self.assertFalse(resilient_cache.touch("key", 10))
        self.assertEqual(resilient_cache.incr("key"), 0)
        self.assertEqual(resilient_cache.decr("key"), 0)
        self.assertFalse(resilient_cache.has_key("key"))


class CompressionTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    @override_settings(
        CACHES={
            "default": {
                "BACKEND": "django_vcache.backend.ValkeyCache",
                "LOCATION": "redis://valkey:6379/1",
                "OPTIONS": {"COMPRESS_MIN_LEN": 128},
            },
        }
    )
    def test_compression_roundtrip(self):
        large_value = "a" * 256
        small_value = "b" * 64

        cache.set("large", large_value)
        cache.set("small", small_value)

        self.assertEqual(cache.get("large"), large_value)
        self.assertEqual(cache.get("small"), small_value)

    @override_settings(
        CACHES={
            "default": {
                "BACKEND": "django_vcache.backend.ValkeyCache",
                "LOCATION": "redis://valkey:6379/1",
                "OPTIONS": {"COMPRESS_MIN_LEN": 128},
            },
        }
    )
    async def test_async_compression_roundtrip(self):
        large_value = "a" * 256
        small_value = "b" * 64

        await cache.aset("large", large_value)
        await cache.aset("small", small_value)

        self.assertEqual(await cache.aget("large"), large_value)
        self.assertEqual(await cache.aget("small"), small_value)


class BatchAndGetOrSetTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    def test_get_many(self):
        cache.set("a", 1)
        cache.set("b", "hello")
        cache.set("c", [1, 2, 3])
        result = cache.get_many(["a", "b", "c", "missing"])
        self.assertEqual(result, {"a": 1, "b": "hello", "c": [1, 2, 3]})

    def test_set_many(self):
        keys = cache.set_many({"x": 10, "y": "foo", "z": [1]})
        self.assertEqual(sorted(keys), ["x", "y", "z"])
        self.assertEqual(cache.get("x"), 10)
        self.assertEqual(cache.get("y"), "foo")
        self.assertEqual(cache.get("z"), [1])

    def test_delete_many(self):
        cache.set("d1", 1)
        cache.set("d2", 2)
        cache.delete_many(["d1", "d2", "d3"])
        self.assertIsNone(cache.get("d1"))
        self.assertIsNone(cache.get("d2"))

    def test_get_or_set(self):
        result = cache.get_or_set("new_key", "default_value", 60)
        self.assertEqual(result, "default_value")
        self.assertEqual(cache.get("new_key"), "default_value")

        result = cache.get_or_set("new_key", "other_value", 60)
        self.assertEqual(result, "default_value")

    def test_get_or_set_callable(self):
        result = cache.get_or_set("callable_key", lambda: 42, 60)
        self.assertEqual(result, 42)

    def test_get_or_set_none(self):
        cache.set("none_key", None)
        result = cache.get_or_set("none_key", "fallback", 60)
        self.assertIsNone(result)

    async def test_aget_many(self):
        await cache.aset("a", 1)
        await cache.aset("b", "hello")
        result = await cache.aget_many(["a", "b", "missing"])
        self.assertEqual(result, {"a": 1, "b": "hello"})

    async def test_aset_many(self):
        keys = await cache.aset_many({"x": 10, "y": "foo"})
        self.assertEqual(sorted(keys), ["x", "y"])
        self.assertEqual(await cache.aget("x"), 10)

    async def test_adelete_many(self):
        await cache.aset("d1", 1)
        await cache.aset("d2", 2)
        await cache.adelete_many(["d1", "d2"])
        self.assertIsNone(await cache.aget("d1"))

    async def test_aget_or_set(self):
        result = await cache.aget_or_set("anew_key", "default_value", 60)
        self.assertEqual(result, "default_value")

        result = await cache.aget_or_set("anew_key", "other_value", 60)
        self.assertEqual(result, "default_value")

    async def test_aget_or_set_none(self):
        await cache.aset("anone_key", None)
        result = await cache.aget_or_set("anone_key", "fallback", 60)
        self.assertIsNone(result)

    def test_clear(self):
        cache.set("c1", 1)
        cache.set("c2", 2)
        cache.clear()
        self.assertIsNone(cache.get("c1"))
        self.assertIsNone(cache.get("c2"))

    async def test_aclear(self):
        await cache.aset("ac1", 1)
        await cache.aset("ac2", 2)
        await cache.aclear()
        self.assertIsNone(await cache.aget("ac1"))
        self.assertIsNone(await cache.aget("ac2"))


@override_settings(
    CACHES={
        "default": {
            "BACKEND": "django_vcache.backend.ValkeyCache",
            "LOCATION": "redis://valkey:6379/1",
            "OPTIONS": {"SERIALIZER": "pickle"},
        },
    }
)
class PickleSerializerTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    def test_pickle_roundtrip(self):
        cache.set("pk1", {"key": "value", "nested": [1, 2, 3]}, 60)
        self.assertEqual(cache.get("pk1"), {"key": "value", "nested": [1, 2, 3]})

    def test_pickle_incr(self):
        cache.set("pk_num", 10)
        self.assertEqual(cache.incr("pk_num"), 11)

    async def test_pickle_async_roundtrip(self):
        await cache.aset("apk1", "hello", 60)
        self.assertEqual(await cache.aget("apk1"), "hello")

    def test_pickle_compression(self):
        large_value = "x" * 2048
        cache.set("pk_large", large_value, 60)
        self.assertEqual(cache.get("pk_large"), large_value)


class EvalTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    def test_eval_sync_returns_int(self):
        driver = cache.get_raw_client()
        result = driver.eval_sync("return 42", [], [])
        self.assertEqual(result, 42)

    def test_eval_sync_with_keys(self):
        driver = cache.get_raw_client()
        driver.set_sync("eval_key", b"hello", None)
        result = driver.eval_sync('return redis.call("get", KEYS[1])', ["eval_key"], [])
        self.assertEqual(result, b"hello")

    async def test_eval_async(self):
        driver = cache.get_raw_client()
        result = await driver.eval("return 42", [], [])
        self.assertEqual(result, 42)

    @unittest.skipIf(
        os.environ.get("VALKEY_CLUSTER_MODE") == "true",
        "Multi-key Lua scripts require keys in the same hash slot.",
    )
    def test_eval_sync_atomic_pipeline(self):
        """Simulate vtasks fail-task: lpush DLQ + ltrim + lrem atomically."""
        driver = cache.get_raw_client()
        task_data = b"task-payload"
        driver.lpush_sync("processing", [task_data])

        script = """
        redis.call("lpush", KEYS[1], ARGV[1])
        redis.call("ltrim", KEYS[1], 0, ARGV[2])
        redis.call("lrem", KEYS[2], 1, ARGV[1])
        return 1
        """
        result = driver.eval_sync(
            script,
            ["dlq", "processing"],
            [task_data, b"99"],
        )
        self.assertEqual(result, 1)
        self.assertEqual(driver.llen_sync("dlq"), 1)
        self.assertEqual(driver.llen_sync("processing"), 0)


class LockingTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()
        cache.clear()

    @unittest.skipIf(
        os.environ.get("VALKEY_CLUSTER_MODE") == "true",
        "Locking is not supported in cluster mode.",
    )
    def test_sync_lock(self):
        lock_name = "my-lock"
        with cache.lock(lock_name, blocking=False) as lock:
            self.assertTrue(lock)
            self.assertFalse(cache.lock(lock_name, blocking=False).acquire())

        self.assertTrue(cache.lock(lock_name, blocking=False).acquire())

    @unittest.skipIf(
        os.environ.get("VALKEY_CLUSTER_MODE") == "true",
        "Locking is not supported in cluster mode.",
    )
    async def test_async_lock(self):
        lock_name = "my-async-lock"
        async with cache.alock(lock_name, blocking=False) as lock:
            self.assertTrue(lock)
            self.assertFalse(await cache.alock(lock_name, blocking=False).aacquire())

        self.assertTrue(await cache.alock(lock_name, blocking=False).aacquire())


@override_settings(
    CACHES={
        "default": {
            "BACKEND": "django_vcache.backend.ValkeyCache",
            "LOCATION": "redis://valkey:6379/1",
            "OPTIONS": {
                "CLUSTER_MODE": True,
            },
        },
    }
)
class ClusterModeTests(TestCase):
    def setUp(self):
        vcache_backend._CLIENTS.clear()

    def test_lock_raises_not_implemented(self):
        with self.assertRaises(NotImplementedError):
            cache.lock("some-lock")

    def test_alock_raises_not_implemented(self):
        with self.assertRaises(NotImplementedError):
            cache.alock("some-lock")
