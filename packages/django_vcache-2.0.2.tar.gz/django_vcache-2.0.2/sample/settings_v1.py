"""Settings that use the v1 (valkey-py) backend for A/B benchmarking."""

from sample.settings import *  # noqa: F401, F403

CACHES = {
    "default": {
        "BACKEND": "vcache_v1.backend.ValkeyCache",
        "LOCATION": os.environ.get("VALKEY_URL", "redis://valkey:6379/1"),  # noqa: F405
        "OPTIONS": {
            "max_connections": 100,
            "connection_pool_timeout": 5,
        },
    },
}
