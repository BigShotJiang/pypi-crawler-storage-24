"""Gateway-owned planning for supported assistant proposal families."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse
from obra.gateway.workflow_studio.starter_catalog import (
    choose_recommended_starters,
    normalize_starter_domain_id,
)
from obra.llm.output_parser import OutputParser

SUPPORTED_INTENT_IDS = {
    "advice_only",
    "recommend_starters",
    "draft_workflow_from_thread",
    "generate_documentation",
    "launch_run",
    "approve_operator_review",
    "resolve_escalation",
    "tighten_stage_review_instructions",
    "insert_stage",
    "remove_stage",
    "reorder_stages",
    "connect_stages",
    "disconnect_stages",
}
SUPPORTED_CONFIDENCE = {"low", "medium", "high"}
WORKFLOW_MUTATION_INTENT_IDS = {
    "tighten_stage_review_instructions",
    "insert_stage",
    "remove_stage",
    "reorder_stages",
    "connect_stages",
    "disconnect_stages",
}
ACTION_ID_TO_INTENT_ID = {
    "recommend_starters": "recommend_starters",
    "generate_documentation": "generate_documentation",
    "execute_launch_run": "launch_run",
    "execute_approve_operator_review": "approve_operator_review",
    "execute_resolve_escalation": "resolve_escalation",
    "execute_template_edit": "tighten_stage_review_instructions",
    "execute_stage_insert": "insert_stage",
    "execute_stage_remove": "remove_stage",
    "execute_stage_reorder": "reorder_stages",
    "execute_connection_add": "connect_stages",
    "execute_connection_remove": "disconnect_stages",
    "execute_draft_workflow_from_thread": "draft_workflow_from_thread",
}


@dataclass(frozen=True)
class AssistantGuidedDecision:
    """Structured guided-turn contract returned by the provider."""

    message: str
    intent_id: str = "advice_only"
    confidence: str = "low"
    intent_args: dict[str, Any] = field(default_factory=dict)


def _normalize_request_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _record_action_id(record: dict[str, Any]) -> str:
    return str(record.get("action_id") or record.get("action_type") or "").strip()


def _record_intent_id(record: dict[str, Any]) -> str | None:
    action_id = _record_action_id(record)
    if action_id in ACTION_ID_TO_INTENT_ID:
        return ACTION_ID_TO_INTENT_ID[action_id]
    if action_id.startswith("propose_"):
        return action_id.removeprefix("propose_")
    return None


def _string_field(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _request_keywords(lower_message: str, *keywords: str) -> bool:
    return any(keyword in lower_message for keyword in keywords)


def _looks_like_stage_insert_request(lower_message: str) -> bool:
    return _request_keywords(lower_message, "add stage", "add step", "insert stage", "insert step") or (
        "stage" in lower_message and _request_keywords(lower_message, "add ", "insert ")
    )


def _conversation_text(resolved_context: dict[str, Any] | None) -> str:
    turns = (resolved_context or {}).get("all_turns") or []
    return "\n".join(
        str(turn.get("message") or "")
        for turn in turns
        if isinstance(turn, dict) and turn.get("role") == "user"
    ).lower()


def _ui_context(resolved_context: dict[str, Any] | None) -> dict[str, Any]:
    ui_context = (resolved_context or {}).get("ui_context") or {}
    return ui_context if isinstance(ui_context, dict) else {}


def _infer_domain_id(resolved_context: dict[str, Any] | None) -> str:
    explicit_domain = normalize_starter_domain_id((resolved_context or {}).get("domain_id"))
    if explicit_domain:
        return explicit_domain
    ui_domain = normalize_starter_domain_id(_ui_context(resolved_context).get("domain_id"))
    if ui_domain:
        return ui_domain
    workflow = (resolved_context or {}).get("workflow") or {}
    if isinstance(workflow, dict):
        workflow_domain = normalize_starter_domain_id(
            workflow.get("domain_id") or workflow.get("domain")
        )
        if workflow_domain:
            return workflow_domain
    conversation_text = _conversation_text(resolved_context)
    if any(
        keyword in conversation_text
        for keyword in ("code", "test", "bug", "frontend", "backend", "api")
    ):
        return "software"
    return "business"


def _compose_request_text(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    return f"{_conversation_text(resolved_context)}\n{user_message}".strip().lower()


def _recommend_starter_payload(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    domain_id = _infer_domain_id(resolved_context)
    ranked = choose_recommended_starters(
        domain_id=domain_id,
        request_text=_compose_request_text(user_message, resolved_context),
        limit=3,
    )
    if not ranked:
        return None, []

    def _shape(starter: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": str(starter.get("id") or ""),
            "domain_id": normalize_starter_domain_id(starter.get("domain_id") or domain_id),
            "title": str(starter.get("title") or ""),
            "description": str(starter.get("description") or ""),
            "intended_use_cases": starter.get("intended_use_cases") or [],
            "stages": starter.get("stages") or [],
        }

    return _shape(ranked[0]), [_shape(starter) for starter in ranked[1:]]


def _stage_binding(stage_id: str, path_hint: str) -> dict[str, Any]:
    return {
        "binding_role": "primary_stage_instruction",
        "binding_scope": "stage",
        "stage_id": stage_id,
        "target_artifact_type": "stage_asset",
        "target_artifact_id": path_hint,
        "target_version_selector": "v1",
        "relationship_type": "binds_to",
        "path_hint": path_hint,
        "content_format": "markdown",
        "adoption_state": "approved_for_execution",
        "adoption_metadata": {},
        "materialization_metadata": {"path": path_hint},
    }


def _quality_loop(checkpoint: str) -> dict[str, Any]:
    return {
        "entry": {"when": "after_stage_runner"},
        "routing": {
            "on_pass": "continue",
            "on_advisory_pass": "continue_with_findings",
            "on_revise_required": "revise_same_stage",
            "on_block": "block_stage",
            "on_escalate": "escalate",
            "on_pending_manual": "wait_for_manual_action",
            "on_manual_resume": "resume_stage",
        },
        "evaluators": [
            {
                "runner": "quality.sense_check",
                "subject": "current_stage_output",
                "required": True,
            }
        ],
        "aggregation": {"strategy": "all_required_pass"},
        "thresholds": {"max_total_findings": 3},
        "pending_manual": {
            "required_action": "approve_revision",
            "resume": {"checkpoint": checkpoint, "strategy": "resume_stage"},
        },
    }


def _default_scaffold_title(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    """Infer a draft title from the first user request in the thread."""
    title = "Assistant Drafted Workflow"
    turns = (resolved_context or {}).get("all_turns") or []
    first_user = next(
        (
            str(turn.get("message") or "")[:80]
            for turn in turns
            if isinstance(turn, dict) and turn.get("role") == "user"
        ),
        user_message[:80],
    )
    if len(first_user) > 60:
        first_user = first_user[:60].rsplit(" ", 1)[0]
    if first_user:
        title = first_user
    return title


def _first_user_request(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    turns = (resolved_context or {}).get("all_turns") or []
    first_user = next(
        (
            str(turn.get("message") or "").strip()
            for turn in turns
            if isinstance(turn, dict) and turn.get("role") == "user" and str(turn.get("message") or "").strip()
        ),
        "",
    )
    return first_user or str(user_message or "").strip()


def _titleize_stage_phrase(phrase: str) -> str:
    words = [word for word in re.split(r"\s+", phrase.strip()) if word]
    titled: list[str] = []
    for word in words:
        if word.upper() in {"IT", "HR", "QA", "PRD", "API"}:
            titled.append(word.upper())
        else:
            titled.append(word.capitalize())
    return " ".join(titled)


def _normalize_stage_phrase(phrase: str) -> str:
    normalized = re.sub(r"\([^)]*\)", "", phrase).strip(" .,:;")
    normalized = re.sub(
        r"^(?:it\s+should|should|then|and|also|plus|with|including|include|includes)\s+",
        "",
        normalized,
        flags=re.IGNORECASE,
    )
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def _extract_list_stage_phrases(request_text: str) -> list[str]:
    lowered = request_text.lower()
    segments: list[str] = []
    for marker in (" should ", " with ", " including ", " include ", " includes "):
        marker_index = lowered.find(marker)
        if marker_index >= 0:
            segments.append(request_text[marker_index + len(marker):].strip())
    if not segments:
        return []

    candidate = max(segments, key=len)
    candidate = re.split(r"[.?!]\s", candidate, maxsplit=1)[0]
    candidate = candidate.strip(" .")
    if not candidate:
        return []

    raw_parts = re.split(r",| and | then | plus ", candidate, flags=re.IGNORECASE)
    phrases: list[str] = []
    for raw_part in raw_parts:
        phrase = _normalize_stage_phrase(raw_part)
        if not phrase:
            continue
        if len(phrase.split()) < 2 and phrase.lower() not in {"orientation", "approval", "review"}:
            continue
        phrases.append(phrase)
    return phrases


def _stage_purpose_from_phrase(phrase: str, request_text: str) -> str:
    lowered = phrase.lower()
    if "document" in lowered:
        return "Collect and validate the employee paperwork required to start onboarding."
    if "background" in lowered:
        return "Run employment eligibility and background screening checks before provisioning access."
    if "it account" in lowered or "account" in lowered or "access" in lowered:
        return "Provision the systems, identity, and device access the assignee needs to begin work."
    if "orientation" in lowered:
        return "Schedule orientation and share the agenda, logistics, and readiness checklist with the new hire."
    if "fraud" in lowered:
        return "Run anomaly checks against vendor history, duplicate billing signals, and approval thresholds."
    if "invoice" in lowered and ("extract" in lowered or "data" in lowered):
        return "Extract the structured invoice fields needed for downstream checks and approval routing."
    if "approval" in lowered or "approve" in lowered:
        return "Review the compiled evidence and record the final approval decision for the request."
    if "review" in lowered or "check" in lowered:
        return "Review the prior stage output for completeness, policy compliance, and quality before the next handoff."
    if "test case" in lowered:
        return "Generate executable test cases that trace directly back to the requirement and risk analysis."
    if "risk" in lowered or "coverage" in lowered:
        return "Assess the request for risk areas and map the required coverage strategy before generating deliverables."
    if "requirements" in lowered or "prd" in lowered:
        return "Analyze the source requirements and capture the scope, constraints, and acceptance criteria for the workflow."
    return f"Complete {phrase} for the workflow request and produce a clear handoff for the next stage."


def _fallback_stage_phrases(request_text: str) -> list[str]:
    lowered = request_text.lower()
    if any(keyword in lowered for keyword in ("onboarding", "new employee", "new hire")):
        return [
            "collect documents",
            "run background checks",
            "set up IT accounts",
            "schedule orientation",
        ]
    if "invoice" in lowered:
        stages = ["intake invoices", "extract invoice data"]
        if "fraud" in lowered:
            stages.append("run fraud detection")
        stages.append("approval review")
        return stages
    if any(keyword in lowered for keyword in ("test plan", "test cases", "requirements document", "prd")):
        return [
            "analyze requirements",
            "design risk coverage",
            "generate test cases",
            "review test plan",
        ]
    return []


def _infer_structured_scaffold_definition(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> dict[str, Any] | None:
    request_text = _first_user_request(user_message, resolved_context)
    title = _default_scaffold_title(user_message, resolved_context)
    domain_id = _infer_domain_id(resolved_context)
    phrases = _extract_list_stage_phrases(request_text) or _fallback_stage_phrases(request_text)
    if not phrases:
        return None

    stages: list[dict[str, Any]] = []
    prior_stage_id: str | None = None
    seen_ids: set[str] = set()
    for phrase in phrases:
        title_text = _titleize_stage_phrase(phrase)
        stage_id = _slugify_stage_id(phrase)
        if stage_id in seen_ids:
            suffix = 2
            while f"{stage_id}-{suffix}" in seen_ids:
                suffix += 1
            stage_id = f"{stage_id}-{suffix}"
        seen_ids.add(stage_id)
        stages.append(
            {
                "id": stage_id,
                "title": title_text,
                "purpose": _stage_purpose_from_phrase(phrase, request_text),
                "depends_on": [prior_stage_id] if prior_stage_id else [],
            }
        )
        prior_stage_id = stage_id

    if len(stages) < 2:
        return None

    return {
        "title": title,
        "domain_id": domain_id,
        "description": f"Workflow designed from assistant conversation: {title}",
        "stages": stages,
    }


def _default_workflow_top_level(
    *,
    title: str,
    domain_id: str,
    description: str,
) -> dict[str, Any]:
    return {
        "title": title,
        "domain_id": domain_id,
        "description": description,
        "compile_ready": True,
        "quality_dimensions": ["docs_analysis"] if domain_id == "business" else ["code_quality"],
        "lifecycle_capabilities": ["derive", "review", "execute", "wait_resume"],
    }


def _default_stage_category(index: int, total: int) -> str:
    if index == 0:
        return "intake"
    if index == total - 1:
        return "delivery"
    return "automation"


def _default_stage_type(title: str, index: int) -> str:
    if index == 0:
        return "analysis"
    lowered = title.lower()
    if any(keyword in lowered for keyword in ("review", "approve", "approval", "qa", "quality", "check")):
        return "review"
    return "analysis"


def _default_stage_outputs(stage_id: str, title: str) -> list[str]:
    lowered = title.lower()
    if "review" in lowered:
        return ["review-decision"]
    if "approve" in lowered:
        return ["approval-decision"]
    return [f"{stage_id}-output"]


def _default_stage_inputs(stage_id: str, depends_on: list[str], index: int) -> list[str]:
    if index == 0:
        return ["source-request"]
    return [f"{dependency}-output" for dependency in depends_on] or [f"{stage_id}-input"]


def _default_stage_verification(title: str, purpose: str) -> list[str]:
    return [f"{title} output satisfies the stage purpose: {purpose}"]


def _default_stage_diagram(index: int, total: int) -> dict[str, Any]:
    category = _default_stage_category(index, total)
    return {
        "lane_id": category,
        "category": category,
    }


def _normalize_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _enrich_scaffold_stage(
    stage: dict[str, Any],
    *,
    index: int,
    total: int,
    domain_id: str,
) -> dict[str, Any]:
    stage_id = str(stage.get("id") or "").strip()
    title = str(stage.get("title") or stage_id).strip()
    purpose = str(stage.get("purpose") or "").strip()
    depends_on = _normalize_string_list(stage.get("depends_on"))
    default_outputs = _default_stage_outputs(stage_id, title)
    enriched = dict(stage)
    enriched["id"] = stage_id
    enriched["title"] = title
    enriched["purpose"] = purpose
    enriched["depends_on"] = depends_on
    enriched["stage_type"] = str(enriched.get("stage_type") or _default_stage_type(title, index)).strip()
    enriched["inputs"] = _normalize_string_list(enriched.get("inputs")) or _default_stage_inputs(
        stage_id,
        depends_on,
        index,
    )
    enriched["outputs"] = _normalize_string_list(enriched.get("outputs")) or default_outputs
    enriched["rules"] = _normalize_string_list(enriched.get("rules")) or ["workflow-safety"]
    enriched["quality_gates"] = _normalize_string_list(enriched.get("quality_gates")) or (
        ["docs_analysis"] if domain_id == "business" else ["code_quality"]
    )
    template_path = f"templates/{domain_id}/{stage_id}.md"
    bindings = enriched.get("template_asset_bindings")
    enriched["template_asset_bindings"] = (
        [binding for binding in bindings if isinstance(binding, dict)]
        if isinstance(bindings, list) and bindings
        else [_stage_binding(stage_id, template_path)]
    )
    enriched["verification"] = _normalize_string_list(enriched.get("verification")) or _default_stage_verification(
        title,
        purpose,
    )
    runner = enriched.get("runner")
    enriched["runner"] = dict(runner) if isinstance(runner, dict) and runner else {"runner_id": "docs"}
    quality_loop = enriched.get("quality_loop")
    enriched["quality_loop"] = (
        dict(quality_loop)
        if isinstance(quality_loop, dict) and quality_loop
        else _quality_loop(f"{stage_id}-loop")
    )
    diagram = enriched.get("diagram")
    if isinstance(diagram, dict):
        category = str(diagram.get("category") or "").strip()
        lane_id = str(diagram.get("lane_id") or "").strip()
        if category and lane_id:
            enriched["diagram"] = dict(diagram)
        else:
            enriched["diagram"] = {
                **_default_stage_diagram(index, total),
                **dict(diagram),
            }
    else:
        enriched["diagram"] = _default_stage_diagram(index, total)
    return enriched


def _validate_scaffold_definition(scaffold: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    title = str(scaffold.get("title") or "").strip()
    if not title:
        errors.append("top-level title must be a non-empty string")

    stages = scaffold.get("stages")
    if not isinstance(stages, list) or not stages:
        errors.append("stages must be a non-empty list")
        return False, errors

    for index, stage in enumerate(stages, start=1):
        if not isinstance(stage, dict):
            errors.append(f"stage {index} must be an object")
            continue
        stage_id = str(stage.get("id") or "").strip()
        if not stage_id:
            errors.append(f"stage {index} is missing id")
        elif not re.fullmatch(r"^[a-z0-9][a-z0-9-]*$", stage_id):
            errors.append(f"stage {index} id '{stage_id}' must be slug-formatted")
        if not str(stage.get("title") or "").strip():
            errors.append(f"stage {index} is missing title")
        if not str(stage.get("purpose") or "").strip():
            errors.append(f"stage {index} is missing purpose")
        depends_on = stage.get("depends_on")
        if not isinstance(depends_on, list):
            errors.append(f"stage {index} depends_on must be a list")
    return not errors, errors


def _format_scaffold_fallback_notice(reason: str, errors: list[str] | None = None) -> str:
    error_suffix = ""
    if errors:
        error_suffix = f" ({'; '.join(errors[:3])})"
    return (
        "I couldn't use a structured scaffold from the guided draft request, "
        f"so I prepared a generic fallback workflow instead{error_suffix}."
    )


def _build_generic_scaffold(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return the deterministic generic fallback scaffold."""
    domain_id = _infer_domain_id(resolved_context)
    conversation_text = _compose_request_text(user_message, resolved_context)
    title = _default_scaffold_title(user_message, resolved_context)
    is_invoice = "invoice" in conversation_text
    resolved_title = "Invoice Approval Workflow" if is_invoice else title
    description = (
        "Process invoice attachments from intake through extraction, review, and approval."
        if is_invoice
        else f"Assistant-generated workflow scaffold: {resolved_title}"
    )
    stages = [
        {
            "id": "intake",
            "title": "Intake",
            "purpose": "Collect the incoming request and normalize the source material.",
            "depends_on": [],
        },
        {
            "id": "process",
            "title": "Process",
            "purpose": "Process the intake material and produce the primary deliverable.",
            "depends_on": ["intake"],
        },
        {
            "id": "review",
            "title": "Review",
            "purpose": "Review the output for quality and completeness.",
            "depends_on": ["process"],
        },
    ]
    return {
        **_default_workflow_top_level(
            title=resolved_title,
            domain_id=domain_id,
            description=description,
        ),
        "stages": [
            _enrich_scaffold_stage(stage, index=index, total=len(stages), domain_id=domain_id)
            for index, stage in enumerate(stages)
        ],
    }


def _resolve_scaffold_from_decision(
    decision: AssistantGuidedDecision,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> tuple[dict[str, Any], str | None]:
    """Resolve a scaffold from guided intent_args, heuristic inference, or generic fallback."""
    scaffold_definition = decision.intent_args.get("scaffold_definition")

    # Try LLM-provided scaffold first
    if isinstance(scaffold_definition, dict):
        is_valid, errors = _validate_scaffold_definition(scaffold_definition)
        if is_valid:
            pass  # Use it below
        else:
            scaffold_definition = None  # Fall through to heuristic

    # Try heuristic inference from conversation when LLM didn't provide a valid scaffold
    if not isinstance(scaffold_definition, dict):
        inferred = _infer_structured_scaffold_definition(user_message, resolved_context)
        if inferred is not None:
            is_valid, errors = _validate_scaffold_definition(inferred)
            if is_valid:
                scaffold_definition = inferred

    # Final fallback to generic
    if not isinstance(scaffold_definition, dict):
        return (
            _build_generic_scaffold(user_message, resolved_context),
            _format_scaffold_fallback_notice("no valid scaffold available"),
        )

    domain_id = normalize_starter_domain_id(scaffold_definition.get("domain_id")) or _infer_domain_id(
        resolved_context
    )
    title = str(scaffold_definition.get("title") or "").strip() or _default_scaffold_title(
        user_message,
        resolved_context,
    )
    description = str(scaffold_definition.get("description") or "").strip() or (
        f"Workflow designed from assistant conversation: {title}"
    )
    stages = [
        _enrich_scaffold_stage(
            dict(stage),
            index=index,
            total=len(scaffold_definition.get("stages") or []),
            domain_id=domain_id,
        )
        for index, stage in enumerate(scaffold_definition.get("stages") or [])
        if isinstance(stage, dict)
    ]
    resolved_scaffold = dict(scaffold_definition)
    resolved_scaffold.update(
        _default_workflow_top_level(
            title=title,
            domain_id=domain_id,
            description=description,
        )
    )
    resolved_scaffold["stages"] = stages
    return resolved_scaffold, None


def _resolve_workflow_ref(resolved_context: dict[str, Any] | None) -> tuple[str | None, str | None]:
    resolved_context = resolved_context or {}
    ui_context = resolved_context.get("ui_context") or {}
    projection = ui_context.get("semantic_projection") if isinstance(ui_context, dict) else {}
    if isinstance(projection, dict):
        workflow_id = str(projection.get("workflow_id") or "").strip() or None
        revision_id = str(projection.get("expected_revision_id") or "").strip() or None
        if workflow_id or revision_id:
            return workflow_id, revision_id
    direct_workflow_id = str(resolved_context.get("workflow_id") or "").strip() or None
    direct_revision_id = str(resolved_context.get("revision_id") or "").strip() or None
    if direct_workflow_id or direct_revision_id:
        return direct_workflow_id, direct_revision_id
    workflow = resolved_context.get("workflow") or {}
    if isinstance(workflow, dict):
        return (
            str(workflow.get("workflow_id") or "") or None,
            str(workflow.get("latest_revision_id") or workflow.get("revision_id") or "") or None,
        )
    return None, None


def _workflow_stages(resolved_context: dict[str, Any] | None) -> list[dict[str, Any]]:
    workflow = (resolved_context or {}).get("workflow") or {}
    if not isinstance(workflow, dict):
        return []
    stages = workflow.get("workflow_definition", {}).get("stages") or workflow.get("stages") or []
    return [stage for stage in stages if isinstance(stage, dict)]


def _stage_identifier(stage: dict[str, Any]) -> str:
    return str(stage.get("stage_id") or stage.get("id") or "").strip()


def _stage_title(stage: dict[str, Any]) -> str:
    return str(stage.get("title") or stage.get("name") or _stage_identifier(stage)).strip()


def _selected_stage_id(resolved_context: dict[str, Any] | None) -> str | None:
    ui_context = _ui_context(resolved_context)
    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        detail = projection.get("selected_stage_detail")
        if isinstance(detail, dict):
            stage_id = str(detail.get("stage_id") or "").strip()
            if stage_id:
                return stage_id
    selected_nodes = ui_context.get("selected_nodes") or []
    if isinstance(selected_nodes, list) and selected_nodes:
        stage_id = str(selected_nodes[0]).strip()
        if stage_id:
            return stage_id
    return None


def _stage_lookup(resolved_context: dict[str, Any] | None) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for stage in _workflow_stages(resolved_context):
        stage_id = _stage_identifier(stage)
        if not stage_id:
            continue
        lookup[stage_id.lower()] = stage_id
        lookup[_stage_title(stage).lower()] = stage_id
    selected_stage_id = _selected_stage_id(resolved_context)
    if selected_stage_id:
        lookup["selected"] = selected_stage_id
        lookup["selected stage"] = selected_stage_id
        lookup["this stage"] = selected_stage_id
        lookup["current stage"] = selected_stage_id
    return lookup


def _resolve_stage_id(value: Any, resolved_context: dict[str, Any] | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    lookup = _stage_lookup(resolved_context)
    return lookup.get(text.lower()) or text


def _slugify_stage_id(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "new-stage"


def _workflow_mutation_boundary_message(resolved_context: dict[str, Any] | None) -> str | None:
    ui_context = _ui_context(resolved_context)
    if ui_context.get("has_conflict"):
        return (
            "The visible workflow draft is in conflict with a newer saved revision. Reload or "
            "reapply your draft before I prepare an executable workflow mutation."
        )
    if ui_context.get("dirty"):
        return (
            "The visible workflow draft has unsaved local changes. Save, discard, or reload the "
            "draft before I prepare an executable workflow mutation against the persisted workflow."
        )
    return None


def _intent_requires_clean_draft(intent_id: str) -> bool:
    return intent_id in WORKFLOW_MUTATION_INTENT_IDS


def _extract_requested_stage_title(lower_message: str) -> str:
    if "approval" in lower_message or "approve" in lower_message:
        return "Approval"
    if "extract" in lower_message:
        return "Extract"
    if "review" in lower_message:
        return "Review"
    if "validate" in lower_message:
        return "Validation"
    if "publish" in lower_message:
        return "Publish"
    return "New Stage"


def _find_named_stage_ids(
    lower_message: str,
    resolved_context: dict[str, Any] | None,
) -> list[str]:
    stage_ids: list[str] = []
    for stage in _workflow_stages(resolved_context):
        stage_id = _stage_identifier(stage)
        stage_title = _stage_title(stage).lower()
        if not stage_id:
            continue
        if stage_id.lower() in lower_message or stage_title in lower_message:
            stage_ids.append(stage_id)
    selected_stage_id = _selected_stage_id(resolved_context)
    if selected_stage_id and selected_stage_id not in stage_ids:
        stage_ids.insert(0, selected_stage_id)
    return stage_ids


def _default_template_after_content(
    *,
    subject: str,
    instruction_focus: str,
) -> str:
    focus_text = f" Focus especially on {instruction_focus}." if instruction_focus else ""
    return (
        "Review the current output against explicit acceptance criteria, explain any quality gaps "
        f"grounded in {subject}, and state the correction or escalation path before moving on.{focus_text}"
    )


def _record_target_metadata(record: dict[str, Any]) -> dict[str, Any]:
    action_inputs = record.get("action_inputs")
    action_inputs = action_inputs if isinstance(action_inputs, dict) else {}
    metadata: dict[str, Any] = {}

    for key in (
        "workflow_id",
        "stage_id",
        "starter_id",
        "domain_id",
        "template_role",
        "source_stage_id",
        "target_stage_id",
        "run_id",
        "escalation_id",
        "choice",
        "output_review_finding_id",
    ):
        value = _string_field(record.get(key) or action_inputs.get(key))
        if value is not None:
            metadata[key] = value

    ordered_stage_ids = record.get("ordered_stage_ids") or action_inputs.get("ordered_stage_ids")
    if isinstance(ordered_stage_ids, list):
        metadata["ordered_stage_ids"] = [str(item) for item in ordered_stage_ids if str(item).strip()]

    proposed_stage = record.get("proposed_stage") or action_inputs.get("stage_definition")
    if isinstance(proposed_stage, dict):
        title = _string_field(proposed_stage.get("title"))
        if title is not None:
            metadata["proposed_stage_title"] = title
        stage_id = _string_field(proposed_stage.get("stage_id") or proposed_stage.get("id"))
        if stage_id is not None:
            metadata["proposed_stage_id"] = stage_id

    removed_stage = record.get("removed_stage")
    if isinstance(removed_stage, dict):
        title = _string_field(removed_stage.get("title"))
        if title is not None:
            metadata["removed_stage_title"] = title

    starter = record.get("starter")
    if isinstance(starter, dict):
        title = _string_field(starter.get("title"))
        if title is not None:
            metadata["starter_title"] = title

    return metadata


def _target_summary(intent_id: str, metadata: dict[str, Any]) -> str | None:
    if intent_id == "insert_stage":
        title = metadata.get("proposed_stage_title") or metadata.get("proposed_stage_id")
        workflow_id = metadata.get("workflow_id")
        if title and workflow_id:
            return f"insert stage '{title}' in workflow {workflow_id}"
    if intent_id == "remove_stage":
        title = metadata.get("removed_stage_title") or metadata.get("stage_id")
        workflow_id = metadata.get("workflow_id")
        if title and workflow_id:
            return f"remove stage '{title}' from workflow {workflow_id}"
    if intent_id in {"connect_stages", "disconnect_stages"}:
        source = metadata.get("source_stage_id")
        target = metadata.get("target_stage_id")
        if source and target:
            verb = "connect" if intent_id == "connect_stages" else "disconnect"
            return f"{verb} {source} -> {target}"
    if intent_id == "reorder_stages":
        ordered = metadata.get("ordered_stage_ids") or []
        if ordered:
            return f"reorder stages to {' -> '.join(str(item) for item in ordered)}"
    if intent_id == "tighten_stage_review_instructions":
        stage_id = metadata.get("stage_id")
        template_role = metadata.get("template_role")
        if stage_id:
            return f"tighten {template_role or 'stage'} instructions for {stage_id}"
    if intent_id == "recommend_starters":
        title = metadata.get("starter_title") or metadata.get("starter_id")
        domain_id = metadata.get("domain_id")
        if title and domain_id:
            return f"recommend starter '{title}' for {domain_id}"
    if intent_id == "generate_documentation":
        workflow_id = metadata.get("workflow_id")
        if workflow_id:
            return f"generate documentation for workflow {workflow_id}"
    if intent_id == "draft_workflow_from_thread":
        return "draft a new workflow from the current thread"
    if intent_id == "launch_run":
        workflow_id = metadata.get("workflow_id")
        if workflow_id:
            return f"launch a run for workflow {workflow_id}"
    return None


def _record_status(
    turn: dict[str, Any],
    record: dict[str, Any],
    *,
    has_any_accepted: bool,
) -> str:
    if bool(record.get("reverted")):
        return "reverted"
    record_status = _normalize_request_text(record.get("status"))
    if record_status in {"accepted", "applied"}:
        return "accepted"
    if record_status == "reverted":
        return "reverted"
    if record_status == "rejected":
        return "rejected"
    if record_status == "conflict":
        return "conflict"
    if record_status == "superseded":
        return "superseded"

    turn_outcome = _normalize_request_text(turn.get("outcome"))
    if turn_outcome == "applied":
        return "superseded" if has_any_accepted else "accepted"
    if turn_outcome == "reverted":
        return "reverted"
    if turn_outcome == "rejected":
        return "rejected"
    if turn_outcome == "conflict":
        return "conflict"
    return "pending"


def build_recent_guided_decision_context(
    all_turns: list[dict[str, Any]] | None,
    *,
    limit: int = 10,
) -> list[dict[str, Any]]:
    """Build structured recent guided decision context from prior thread turns."""
    if not all_turns:
        return []

    recent: list[dict[str, Any]] = []
    last_user_message = ""
    for turn in all_turns:
        if not isinstance(turn, dict):
            continue
        role = str(turn.get("role") or "").strip()
        if role == "user":
            last_user_message = str(turn.get("message") or "")
            continue
        if role != "assistant":
            continue
        raw_records = turn.get("action_records")
        if not isinstance(raw_records, list) or not raw_records:
            continue
        proposal_records = [
            record
            for record in raw_records
            if isinstance(record, dict) and _record_intent_id(record) is not None
        ]
        if not proposal_records:
            continue
        accepted_ids = {
            id(record)
            for record in proposal_records
            if _normalize_request_text(record.get("status")) in {"accepted", "applied"}
        }
        for record in proposal_records:
            intent_id = _record_intent_id(record)
            if intent_id is None:
                continue
            metadata = _record_target_metadata(record)
            recent.append(
                {
                    "intent_id": intent_id,
                    "request_text": _normalize_request_text(last_user_message),
                    "status": _record_status(
                        turn,
                        record,
                        has_any_accepted=bool(accepted_ids) and id(record) not in accepted_ids,
                    ),
                    "target_summary": _target_summary(intent_id, metadata),
                    "target_metadata": metadata,
                    "turn_id": str(turn.get("turn_id") or ""),
                    "created_at": str(turn.get("created_at") or ""),
                }
            )
    return recent[-limit:]


def _recent_guided_decisions(resolved_context: dict[str, Any] | None) -> list[dict[str, Any]]:
    decisions = (resolved_context or {}).get("recent_guided_decisions")
    if isinstance(decisions, list):
        return [item for item in decisions if isinstance(item, dict)]
    all_turns = (resolved_context or {}).get("all_turns")
    if isinstance(all_turns, list):
        return build_recent_guided_decision_context(all_turns)
    return []


def _current_request_target_metadata(
    decision: AssistantGuidedDecision,
    resolved_context: dict[str, Any] | None,
) -> dict[str, Any]:
    workflow_id, _ = _resolve_workflow_ref(resolved_context)
    metadata: dict[str, Any] = {}
    if workflow_id:
        metadata["workflow_id"] = workflow_id
    for key, value in decision.intent_args.items():
        if isinstance(value, (str, list)):
            metadata[key] = value
    if decision.intent_id == "remove_stage" and "stage_id" not in metadata:
        selected = _selected_stage_id(resolved_context)
        if selected:
            metadata["stage_id"] = selected
    if decision.intent_id in {"connect_stages", "disconnect_stages"} and "source_stage_id" not in metadata:
        selected = _selected_stage_id(resolved_context)
        if selected:
            metadata["source_stage_id"] = selected
    return metadata


def _same_target(
    decision: AssistantGuidedDecision,
    entry: dict[str, Any],
    resolved_context: dict[str, Any] | None,
    user_message: str,
) -> bool:
    entry_request = _normalize_request_text(entry.get("request_text"))
    current_request = _normalize_request_text(user_message)
    if entry_request and current_request and entry_request == current_request:
        return True

    current_metadata = _current_request_target_metadata(decision, resolved_context)
    entry_metadata = entry.get("target_metadata")
    if not isinstance(entry_metadata, dict):
        return False

    comparable_keys = {
        "workflow_id",
        "stage_id",
        "source_stage_id",
        "target_stage_id",
        "template_role",
        "ordered_stage_ids",
    }
    shared = comparable_keys & current_metadata.keys() & entry_metadata.keys()
    return bool(shared) and all(current_metadata[key] == entry_metadata[key] for key in shared)


def _repeat_guidance_message(
    status: str,
    *,
    target_summary: str | None,
) -> str:
    summary = target_summary or "that change"
    if status == "rejected":
        return (
            f"I already proposed {summary} in this thread and it was rejected. "
            "Tell me what should be different or ask me to revisit it with a narrower change."
        )
    if status == "accepted":
        return (
            f"I already prepared and applied {summary}. "
            "Work from the updated state or ask for a refinement on the current revision."
        )
    if status == "reverted":
        return (
            f"I previously applied {summary} and it was reverted. "
            "If you want it again, ask me to re-propose it with the new constraints called out."
        )
    if status in {"conflict", "superseded"}:
        return (
            f"The last proposal for {summary} no longer matches the latest revision. "
            "Reload the current workflow state or ask me to re-propose it against the latest context."
        )
    return ""


def _repeat_guidance_decision(
    decision: AssistantGuidedDecision,
    *,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantGuidedDecision | None:
    for entry in reversed(_recent_guided_decisions(resolved_context)):
        if str(entry.get("intent_id") or "") != decision.intent_id:
            continue
        status = str(entry.get("status") or "").strip()
        if status not in {"accepted", "rejected", "reverted", "conflict", "superseded"}:
            continue
        if not _same_target(decision, entry, resolved_context, user_message):
            continue
        return AssistantGuidedDecision(
            message=_repeat_guidance_message(
                status,
                target_summary=_string_field(entry.get("target_summary")),
            ),
            intent_id="advice_only",
            confidence="low",
            intent_args={},
        )
    return None


def _build_stage_definition(
    intent_args: dict[str, Any],
    resolved_context: dict[str, Any] | None,
) -> tuple[dict[str, Any], str | None]:
    title = str(intent_args.get("title") or "").strip() or "New Stage"
    stage_id = str(intent_args.get("stage_id") or "").strip() or _slugify_stage_id(title)
    after_stage_id = _resolve_stage_id(intent_args.get("after_stage_id"), resolved_context)

    depends_on_raw = intent_args.get("depends_on")
    depends_on: list[str] = []
    if isinstance(depends_on_raw, list):
        depends_on = [
            resolved
            for item in depends_on_raw
            if (resolved := _resolve_stage_id(item, resolved_context)) is not None
        ]
    elif after_stage_id:
        depends_on = [after_stage_id]

    stage_type = str(intent_args.get("stage_type") or intent_args.get("category") or "analysis").strip()
    category = str(intent_args.get("category") or stage_type).strip()
    lane_id = str(intent_args.get("lane_id") or "").strip()

    stage_definition: dict[str, Any] = {
        "stage_id": stage_id,
        "id": stage_id,
        "title": title,
        "purpose": str(intent_args.get("purpose") or "").strip(),
        "stage_type": stage_type,
        "category": category,
        "depends_on": depends_on,
    }
    if lane_id or category:
        stage_definition["diagram"] = {
            **({"lane_id": lane_id} if lane_id else {}),
            **({"category": category} if category else {}),
        }
    return stage_definition, after_stage_id


def _build_insert_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_definition: dict[str, Any],
    after_stage_id: str | None,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    insertion_index = 0
    if after_stage_id:
        for index, stage in enumerate(stages):
            if _stage_identifier(stage) == after_stage_id:
                insertion_index = index + 1
                break
    previous_stage = stages[insertion_index - 1] if insertion_index > 0 and insertion_index - 1 < len(stages) else None
    next_stage = stages[insertion_index] if insertion_index < len(stages) else None
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_insert",
                action_type="propose_stage_insert",
                action_inputs={
                    "workflow_id": workflow_id,
                    "after_stage_id": after_stage_id,
                    "stage_definition": stage_definition,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="scaffold",
                workflow_id=workflow_id,
                proposed_stage=stage_definition,
                insertion_index=insertion_index,
                surrounding_stages={
                    "previous": _stage_title(previous_stage) if isinstance(previous_stage, dict) else None,
                    "next": _stage_title(next_stage) if isinstance(next_stage, dict) else None,
                },
            )
        ],
    )


def _build_remove_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    target = next((stage for stage in stages if _stage_identifier(stage) == stage_id), None)
    affected_connections = []
    for stage in stages:
        if stage_id in (stage.get("depends_on") or []):
            affected_connections.append(
                {
                    "stage_id": _stage_identifier(stage),
                    "title": _stage_title(stage),
                    "relationship": "depends_on_removed",
                }
            )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_remove",
                action_type="propose_stage_remove",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                removed_stage={
                    "stage_id": stage_id,
                    "title": _stage_title(target) if isinstance(target, dict) else stage_id,
                },
                affected_connections=affected_connections,
            )
        ],
    )


def _build_reorder_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    ordered_stage_ids: list[str],
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    stage_map = {_stage_identifier(stage): stage for stage in stages}
    before_order = [
        {"stage_id": _stage_identifier(stage), "title": _stage_title(stage)}
        for stage in stages
        if _stage_identifier(stage)
    ]
    after_order = [
        {"stage_id": stage_id, "title": _stage_title(stage_map.get(stage_id, {"stage_id": stage_id}))}
        for stage_id in ordered_stage_ids
    ]
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_reorder",
                action_type="propose_stage_reorder",
                action_inputs={
                    "workflow_id": workflow_id,
                    "ordered_stage_ids": ordered_stage_ids,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                before_order=before_order,
                after_order=after_order,
            )
        ],
    )


def _build_connection_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    source_stage_id: str,
    target_stage_id: str,
    action: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stage_map = {_stage_identifier(stage): stage for stage in _workflow_stages(resolved_context)}
    edge = {
        "source_stage_id": source_stage_id,
        "source_title": _stage_title(stage_map.get(source_stage_id, {"stage_id": source_stage_id})),
        "target_stage_id": target_stage_id,
        "target_title": _stage_title(stage_map.get(target_stage_id, {"stage_id": target_stage_id})),
    }
    action_id = "execute_connection_add" if action == "add" else "execute_connection_remove"
    action_type = "propose_connection_add" if action == "add" else "propose_connection_remove"
    payload_field = "edge_added" if action == "add" else "edge_removed"
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id=action_id,
                action_type=action_type,
                action_inputs={
                    "workflow_id": workflow_id,
                    "source_stage_id": source_stage_id,
                    "target_stage_id": target_stage_id,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                **{payload_field: edge},
            )
        ],
    )


def _build_template_edit_response(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str | None,
    template_role: str,
    before_content: str,
    after_content: str,
    explanation: str,
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_template_edit",
                action_type="propose_template_edit",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "template_role": template_role,
                    "proposed_content": after_content,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                before_content=before_content,
                after_content=after_content,
                workflow_id=workflow_id,
                stage_id=stage_id,
                template_role=template_role,
            )
        ],
    )


def _build_starter_recommendation_record(
    *,
    user_message: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    workflow_id, revision_id = _resolve_workflow_ref(resolved_context)
    starter, alternates = _recommend_starter_payload(user_message, resolved_context)
    if starter is None:
        return AssistantLlmResponse(
            message=(
                "I couldn't find a starter that matches the current domain and request. "
                "Set a domain or describe the workflow outcome more specifically."
            )
        )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="recommend_starters",
                action_type="propose_starter_recommendation",
                action_inputs={
                    "starter_id": starter["id"],
                    "domain_id": starter["domain_id"],
                    "workflow_id": workflow_id or "",
                    "expected_revision_id": revision_id or "",
                },
                preview_type="starter_recommendation",
                workflow_id=workflow_id,
                expected_revision_id=revision_id or "",
                domain_id=starter["domain_id"],
                starter=starter,
                alternate_starters=alternates,
            )
        ],
    )


def _build_generate_documentation_record(
    *,
    workflow_id: str,
    explanation: str,
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="generate_documentation",
                action_type="propose_generate_documentation",
                action_inputs={"workflow_id": workflow_id},
                preview_type="documentation",
                workflow_id=workflow_id,
            )
        ],
    )


def _output_review_context(resolved_context: dict[str, Any] | None) -> dict[str, Any]:
    output_review = (resolved_context or {}).get("output_review") or {}
    return output_review if isinstance(output_review, dict) else {}


def _looks_like_output_review_request(
    lower_message: str,
    resolved_context: dict[str, Any] | None,
) -> bool:
    if not _output_review_context(resolved_context):
        return False
    return any(
        keyword in lower_message
        for keyword in (
            "review this output",
            "review these outputs",
            "review this run",
            "review this artifact",
            "review output",
            "review outputs",
            "workflow fix",
            "fix this workflow",
            "suggest a fix",
            "improve this output",
            "quality issue",
            "why is this weak",
        )
    )


def _stage_output_entry(
    output_review: dict[str, Any],
    stage_name: str,
) -> dict[str, Any] | None:
    for entry in output_review.get("intermediate_outputs") or []:
        if not isinstance(entry, dict):
            continue
        if str(entry.get("stage_name") or "").strip() == stage_name:
            return entry
    return None


def _content_text(entry: dict[str, Any] | None) -> str:
    if not isinstance(entry, dict):
        return ""
    return str(entry.get("content_text") or entry.get("content_preview") or "").strip()


def _stage_id_for_output_review(
    output_review: dict[str, Any],
    resolved_context: dict[str, Any] | None,
    stage_name: str,
) -> str | None:
    entry = _stage_output_entry(output_review, stage_name)
    if isinstance(entry, dict):
        stage_id = str(entry.get("stage_id") or "").strip()
        if stage_id:
            return stage_id
    return _resolve_stage_id(stage_name, resolved_context)


def _current_stage_before_content(
    resolved_context: dict[str, Any] | None,
    stage_id: str | None,
    template_role: str,
) -> str:
    if stage_id is None:
        return ""
    for stage in _workflow_stages(resolved_context):
        if _stage_identifier(stage) != stage_id:
            continue
        if template_role == "purpose":
            return str(stage.get("purpose") or stage.get("description") or "").strip()
        return str(stage.get(template_role) or "").strip()
    return ""


def _snippet(text: str, limit: int = 180) -> str:
    normalized = " ".join(str(text).split())
    return normalized[:limit]


def _build_output_review_findings(
    *,
    resolved_context: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    output_review = _output_review_context(resolved_context)
    if not output_review:
        return []

    gather_text = _content_text(_stage_output_entry(output_review, "gather-sources"))
    analyze_text = _content_text(_stage_output_entry(output_review, "analyze-metrics"))
    narrative_text = _content_text(_stage_output_entry(output_review, "draft-narrative"))
    chart_text = _content_text(_stage_output_entry(output_review, "create-charts"))
    final_text = _content_text(output_review.get("selected_output")) or _content_text(
        (output_review.get("final_outputs") or [None])[-1]
        if isinstance(output_review.get("final_outputs"), list)
        else None
    )

    findings: list[dict[str, Any]] = []

    if any(
        keyword in chart_text.lower()
        for keyword in ("low resolution", "labels overlap", "not accessible", "reduced quality", "colorblind", "y-axis scale starts")
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "create-charts")
        findings.append(
            {
                "id": "chart-quality-guardrails",
                "priority": "P0",
                "title": "Chart stage allows presentation-quality defects through",
                "summary": "The chart output reports accessibility and rendering problems that should block or revise the stage before distribution.",
                "evidence": _snippet(chart_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(resolved_context, stage_id, "purpose"),
                "after_content": (
                    "Generate stakeholder-ready charts only. Validate label readability, color accessibility, "
                    "and axis integrity before completing the stage. If any chart uses reduced-quality rendering, "
                    "overlapping labels, inaccessible colors, or misleading scales, revise the chart package and "
                    "summarize the correction before handing off downstream."
                ),
                "proposal_label": "Tighten chart quality checks",
            }
        )

    if any(
        phrase in narrative_text.lower() or phrase in final_text.lower()
        for phrase in (
            "performed well this quarter",
            "plans to continue growing",
            "marketing campaigns were run",
            "costs were managed",
            "continue current trajectory",
        )
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "draft-narrative")
        findings.append(
            {
                "id": "narrative-specificity",
                "priority": "P1",
                "title": "Narrative stage permits generic, weakly evidenced summary language",
                "summary": "The report narrative uses vague claims instead of translating the metric analysis into quantified stakeholder-facing conclusions.",
                "evidence": _snippet(narrative_text or final_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(resolved_context, stage_id, "purpose"),
                "after_content": (
                    "Draft a data-backed narrative for non-technical stakeholders. Every summary claim must cite "
                    "the underlying metrics or trend comparison, name the business driver, and avoid vague phrases "
                    "such as 'performed well' or 'continue current trajectory' unless the evidence is explicitly stated."
                ),
                "proposal_label": "Make the narrative evidence-backed",
            }
        )

    if any(
        keyword in gather_text.lower() or keyword in analyze_text.lower()
        for keyword in ("not available", "partial", "estimates", "pending final reconciliation", "unavailable")
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "gather-sources")
        findings.append(
            {
                "id": "source-completeness",
                "priority": "P1",
                "title": "Source collection stage does not gate incomplete or provisional inputs",
                "summary": "The run continued despite missing or estimated source data, which weakens every downstream artifact.",
                "evidence": _snippet(gather_text or analyze_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(resolved_context, stage_id, "purpose"),
                "after_content": (
                    "Collect every required quarterly source before completing the stage. Detect missing departments, "
                    "partial spreadsheets, reconciliation gaps, or estimated figures and return a structured deficiency "
                    "report instead of passing partial data to downstream analysis."
                ),
                "proposal_label": "Gate incomplete source inputs",
            }
        )

    if findings:
        return findings

    selected_output = output_review.get("selected_output")
    selected_stage_id = (
        str(selected_output.get("stage_id") or "").strip()
        if isinstance(selected_output, dict)
        else ""
    )
    fallback_stage_id = (
        selected_stage_id
        or _selected_stage_id(resolved_context)
        or _stage_identifier(_workflow_stages(resolved_context)[0])
        if _workflow_stages(resolved_context)
        else None
    )
    fallback_stage_name = (
        str(selected_output.get("stage_title") or selected_output.get("stage_name") or "selected stage")
        if isinstance(selected_output, dict)
        else "selected stage"
    )
    return [
        {
            "id": "output-review-tightening",
            "priority": "P1",
            "title": "Selected output needs stronger acceptance criteria",
            "summary": "The current evidence does not show the stage is checking the output against explicit completeness and quality expectations.",
            "evidence": _snippet(_content_text(selected_output)),
            "stage_id": fallback_stage_id,
            "template_role": "purpose",
            "before_content": _current_stage_before_content(resolved_context, fallback_stage_id, "purpose"),
            "after_content": (
                f"Review the {fallback_stage_name} output against explicit acceptance criteria before completing "
                "the stage. Call out missing evidence, quality gaps, and downstream risks, then either revise the "
                "output or return a structured issue summary."
            ),
            "proposal_label": "Tighten output review criteria",
        }
    ]


def _build_output_review_response(
    *,
    workflow_id: str,
    revision_id: str | None,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    output_review = _output_review_context(resolved_context)
    findings = _build_output_review_findings(resolved_context=resolved_context)
    if not findings:
        return AssistantLlmResponse(message=explanation)

    action_records: list[dict[str, Any]] = [
        {
            "action_id": "output_review_findings",
            "action_type": "output_review_findings",
            "preview_type": "output_review_findings",
            "route": output_review.get("route"),
            "run_id": output_review.get("run_id"),
            "selected_artifact_id": output_review.get("selected_artifact_id"),
            "selected_output": output_review.get("selected_output"),
            "findings": [
                {
                    "id": finding["id"],
                    "priority": finding["priority"],
                    "title": finding["title"],
                    "summary": finding["summary"],
                    "evidence": finding["evidence"],
                }
                for finding in findings
            ],
        }
    ]
    for finding in findings:
        action_records.append(
            build_proposal_record(
                action_id="execute_template_edit",
                action_type="propose_template_edit",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": finding["stage_id"],
                    "template_role": finding["template_role"],
                    "proposed_content": finding["after_content"],
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                stage_id=finding["stage_id"],
                template_role=finding["template_role"],
                before_content=finding["before_content"],
                after_content=finding["after_content"],
                output_review_finding_id=finding["id"],
                output_review_priority=finding["priority"],
                output_review_title=finding["title"],
                output_review_summary=finding["summary"],
                proposal_label=finding["proposal_label"],
            )
        )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=action_records,
    )


def infer_guided_decision(
    user_message: str,
    *,
    resolved_context: dict[str, Any] | None,
) -> AssistantGuidedDecision:
    """Infer a guided decision from obvious request/context signals."""
    resolved_context = resolved_context or {}
    lower_message = user_message.lower()
    workflow = resolved_context.get("workflow")
    selected_run = resolved_context.get("selected_run") or resolved_context.get("latest_run")
    selected_artifact = resolved_context.get("selected_artifact")
    workflow_id, _ = _resolve_workflow_ref(resolved_context)
    selected_stage_id = _selected_stage_id(resolved_context)
    mutation_boundary = _workflow_mutation_boundary_message(resolved_context)
    named_stage_ids = _find_named_stage_ids(lower_message, resolved_context)

    if workflow_id and mutation_boundary and _looks_like_output_review_request(lower_message, resolved_context):
        return AssistantGuidedDecision(message=mutation_boundary)

    if workflow_id and _looks_like_output_review_request(lower_message, resolved_context):
        return AssistantGuidedDecision(
            message=(
                "I reviewed the selected evidence and prepared concrete workflow fixes you can choose from."
            ),
            intent_id="tighten_stage_review_instructions",
            confidence="high",
        )

    if workflow is None and _request_keywords(
        lower_message,
        "starter",
        "starting point",
        "workflow template",
        "starter flow",
        "recommend a starter",
        "starter recommendation",
    ):
        return AssistantGuidedDecision(
            message=(
                "I picked a starter that fits the domain and the workflow outcome you described."
            ),
            intent_id="recommend_starters",
            confidence="high",
        )

    if workflow is None and _request_keywords(
        lower_message,
        "draft",
        "create",
        "build",
        "scaffold",
        "turn this into",
    ):
        scaffold_definition = _infer_structured_scaffold_definition(user_message, resolved_context)
        return AssistantGuidedDecision(
            message=(
                "I drafted a workflow scaffold from your request so you can review the stages before applying it."
            ),
            intent_id="draft_workflow_from_thread",
            confidence="high",
            intent_args={"scaffold_definition": scaffold_definition} if scaffold_definition else {},
        )

    if workflow_id and mutation_boundary and _request_keywords(
        lower_message,
        "add",
        "insert",
        "remove",
        "delete",
        "connect",
        "disconnect",
        "reorder",
        "move",
        "edit",
        "fix",
        "update",
        "improve",
    ):
        return AssistantGuidedDecision(message=mutation_boundary)

    if workflow_id and _request_keywords(
        lower_message,
        "documentation",
        "document this workflow",
        "workflow docs",
        "markdown",
        "export docs",
        "write docs",
    ):
        return AssistantGuidedDecision(
            message=(
                "I prepared stakeholder-ready workflow documentation for the active workflow."
            ),
            intent_id="generate_documentation",
            confidence="high",
        )

    if workflow_id and _request_keywords(lower_message, "launch run", "start run", "run this", "execute run"):
        return AssistantGuidedDecision(
            message="I prepared a run launch using the active workflow context.",
            intent_id="launch_run",
            confidence="high",
        )

    if isinstance(selected_run, dict):
        run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
        escalation_id = str(
            selected_run.get("escalation_id")
            or selected_run.get("correlation", {}).get("escalation_id")
            or ""
        ).strip()
        if (
            run_id
            and _request_keywords(lower_message, "approve", "continue", "unblock")
            and str(selected_run.get("status") or "") == "awaiting_operator"
        ):
            return AssistantGuidedDecision(
                message="I prepared the operator approval action for the selected run.",
                intent_id="approve_operator_review",
                confidence="high",
            )
        if run_id and escalation_id and _request_keywords(
            lower_message, "resolve escalation", "force complete", "abandon"
        ):
            return AssistantGuidedDecision(
                message="I prepared an escalation resolution for the selected run.",
                intent_id="resolve_escalation",
                confidence="high",
                intent_args={
                    "choice": "abandon" if "abandon" in lower_message else "force_complete",
                },
            )

    if workflow_id and selected_stage_id and _request_keywords(
        lower_message, "remove this stage", "delete this stage", "remove the selected stage"
    ):
        return AssistantGuidedDecision(
            message="I prepared the selected stage for removal.",
            intent_id="remove_stage",
            confidence="high",
        )

    if workflow_id and _looks_like_stage_insert_request(lower_message):
        stage_title = _extract_requested_stage_title(lower_message)
        return AssistantGuidedDecision(
            message="I prepared the requested stage so you can review it before applying the workflow change.",
            intent_id="insert_stage",
            confidence="high",
            intent_args={
                "title": stage_title,
                "purpose": f"{stage_title} the workflow output before the next handoff.",
                "after_stage_id": selected_stage_id,
            },
        )

    if workflow_id and _request_keywords(lower_message, "reorder", "move this stage", "move stage", "change the order"):
        if len(named_stage_ids) >= 2:
            return AssistantGuidedDecision(
                message="I prepared the requested stage order update for review.",
                intent_id="reorder_stages",
                confidence="high",
                intent_args={"ordered_stage_ids": named_stage_ids},
            )

    if workflow_id and _request_keywords(lower_message, "connect", "disconnect", "remove connection"):
        if len(named_stage_ids) >= 2:
            source_stage_id = named_stage_ids[0]
            target_stage_id = named_stage_ids[1]
            return AssistantGuidedDecision(
                message="I prepared the requested stage connection change for review.",
                intent_id="disconnect_stages"
                if _request_keywords(lower_message, "disconnect", "remove connection")
                else "connect_stages",
                confidence="high",
                intent_args={
                    "source_stage_id": source_stage_id,
                    "target_stage_id": target_stage_id,
                },
            )

    if workflow_id and _request_keywords(
        lower_message,
        "improve",
        "update",
        "edit",
        "fix",
        "review output",
        "quality",
    ):
        target_stage_id = selected_stage_id or (named_stage_ids[0] if named_stage_ids else None)
        subject = "selected evidence" if selected_artifact else "current workflow context"
        return AssistantGuidedDecision(
            message="I prepared a targeted stage-instruction update you can review before applying.",
            intent_id="tighten_stage_review_instructions",
            confidence="high",
            intent_args={
                **({"stage_id": target_stage_id} if target_stage_id else {}),
                "template_role": "purpose",
                "instruction_focus": subject,
            },
        )

    return AssistantGuidedDecision(
        message=_actionable_advice_message("", user_message=user_message, resolved_context=resolved_context),
    )


def _actionable_advice_message(
    message: str,
    *,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    existing = str(message or "").strip()
    lower_message = user_message.lower()
    workflow_id, _ = _resolve_workflow_ref(resolved_context)
    has_output_review = bool(_output_review_context(resolved_context))
    if existing and any(
        phrase in existing.lower()
        for phrase in ("save", "reload", "select", "open", "describe", "tell me", "ask me", "point me")
    ):
        return existing

    if _request_keywords(lower_message, "documentation", "workflow docs", "markdown") and not workflow_id:
        guidance = "Open the workflow you want documented, then ask me to generate documentation for it."
    elif _looks_like_output_review_request(lower_message, resolved_context) and not has_output_review:
        guidance = "Open the run or artifact output you want reviewed, then ask me to review that evidence."
    elif _request_keywords(
        lower_message,
        "add stage",
        "insert stage",
        "remove stage",
        "connect",
        "disconnect",
        "reorder",
        "move stage",
    ) and not workflow_id:
        guidance = "Open the workflow revision you want to change and select or name the stage before asking again."
    elif _request_keywords(lower_message, "starter", "draft", "workflow") and workflow_id is None:
        guidance = "Describe the workflow outcome, inputs, and review step you need so I can prepare a starter or draft."
    else:
        guidance = "Point me at a workflow, stage, run, or artifact and tell me what change or review you want."

    if existing:
        return f"{existing} Next step: {guidance}"
    return f"I need a little more context before I can turn this into a safe proposal. Next step: {guidance}"


def reconcile_guided_decision(
    decision: AssistantGuidedDecision,
    *,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantGuidedDecision:
    """Upgrade obvious proposal cases and suppress narrow exact repeats."""
    inferred = infer_guided_decision(user_message, resolved_context=resolved_context)
    chosen = decision
    if decision.intent_id == "advice_only" or decision.confidence != "high":
        if inferred.intent_id != "advice_only" and inferred.confidence == "high":
            chosen = inferred
        else:
            return AssistantGuidedDecision(
                message=_actionable_advice_message(
                    decision.message or inferred.message,
                    user_message=user_message,
                    resolved_context=resolved_context,
                ),
                intent_id="advice_only",
                confidence="low",
                intent_args={},
            )

    # When both LLM and heuristic agree on draft_workflow_from_thread but the
    # LLM omitted scaffold_definition, merge the heuristic's structured scaffold
    # so the resolver has something to work with.
    if (
        chosen.intent_id == "draft_workflow_from_thread"
        and not chosen.intent_args.get("scaffold_definition")
        and inferred.intent_id == "draft_workflow_from_thread"
        and inferred.intent_args.get("scaffold_definition")
    ):
        merged_args = {**chosen.intent_args, "scaffold_definition": inferred.intent_args["scaffold_definition"]}
        chosen = AssistantGuidedDecision(
            message=chosen.message,
            intent_id=chosen.intent_id,
            confidence=chosen.confidence,
            intent_args=merged_args,
        )

    repeat_guidance = _repeat_guidance_decision(
        chosen,
        user_message=user_message,
        resolved_context=resolved_context,
    )
    if repeat_guidance is not None:
        return repeat_guidance

    if chosen.intent_id == "advice_only":
        return AssistantGuidedDecision(
            message=_actionable_advice_message(
                chosen.message,
                user_message=user_message,
                resolved_context=resolved_context,
            ),
            intent_id="advice_only",
            confidence="low",
            intent_args={},
        )

    return chosen


def build_guided_stub_response(
    user_message: str,
    resolved_context: dict[str, Any] | None = None,
) -> AssistantLlmResponse:
    """Deterministic fallback used when the real provider bootstrap is unavailable."""
    decision = reconcile_guided_decision(
        infer_guided_decision(user_message, resolved_context=resolved_context),
        user_message=user_message,
        resolved_context=resolved_context,
    )
    return plan_guided_response(
        decision,
        user_message=user_message,
        resolved_context=resolved_context,
    )


def _extract_embedded_json(text: str) -> dict[str, Any] | None:
    """Extract the first JSON object containing a 'message' key from mixed text.

    LLMs sometimes prepend chain-of-thought reasoning before the JSON
    contract.  This helper finds the first ``{...}`` block that parses as
    valid JSON and contains the expected ``message`` field.
    """
    import json as _json

    # Find all potential JSON object start positions
    for match in re.finditer(r'\{', text):
        start = match.start()
        # Walk forward to find balanced braces
        depth = 0
        for i in range(start, len(text)):
            if text[i] == '{':
                depth += 1
            elif text[i] == '}':
                depth -= 1
                if depth == 0:
                    candidate = text[start:i + 1]
                    try:
                        data = _json.loads(candidate)
                        if isinstance(data, dict) and "message" in data:
                            return data
                    except (ValueError, _json.JSONDecodeError):
                        pass
                    break
    return None


def normalize_guided_decision(payload: Any) -> AssistantGuidedDecision:
    """Parse or normalize provider output into the guided-turn contract."""
    if isinstance(payload, AssistantGuidedDecision):
        return payload

    data: dict[str, Any] | None = None
    if isinstance(payload, dict):
        data = payload
    elif hasattr(payload, "content") and isinstance(getattr(payload, "content", None), str):
        raw = str(payload.content)
        parser = OutputParser()
        parsed = parser.parse(raw, expected_format="json")
        if parsed.success and isinstance(parsed.data, dict):
            data = parsed.data
        else:
            # Fallback: extract embedded JSON from mixed reasoning + JSON text
            data = _extract_embedded_json(raw)
            if data is None:
                return AssistantGuidedDecision(message=raw.strip())
    elif isinstance(payload, str):
        parser = OutputParser()
        parsed = parser.parse(payload, expected_format="json")
        if parsed.success and isinstance(parsed.data, dict):
            data = parsed.data
        else:
            # Fallback: extract embedded JSON from mixed reasoning + JSON text
            data = _extract_embedded_json(payload)
            if data is None:
                return AssistantGuidedDecision(message=payload.strip())

    if not isinstance(data, dict):
        return AssistantGuidedDecision(message=str(payload).strip())

    intent_id = str(data.get("intent_id") or "advice_only").strip() or "advice_only"
    if intent_id not in SUPPORTED_INTENT_IDS:
        intent_id = "advice_only"

    confidence = str(data.get("confidence") or "low").strip().lower() or "low"
    if confidence not in SUPPORTED_CONFIDENCE:
        confidence = "low"

    intent_args = data.get("intent_args")
    return AssistantGuidedDecision(
        message=str(data.get("message") or "").strip(),
        intent_id=intent_id,
        confidence=confidence,
        intent_args=intent_args if isinstance(intent_args, dict) else {},
    )


def plan_guided_response(
    decision: AssistantGuidedDecision,
    *,
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    """Convert the guided-turn contract into a deterministic assistant response."""
    decision = reconcile_guided_decision(
        decision,
        user_message=user_message,
        resolved_context=resolved_context,
    )
    if decision.intent_id == "advice_only" or decision.confidence != "high":
        return AssistantLlmResponse(
            message=_actionable_advice_message(
                decision.message,
                user_message=user_message,
                resolved_context=resolved_context,
            )
        )

    resolved_context = resolved_context or {}
    workflow_id, revision_id = _resolve_workflow_ref(resolved_context)
    selected_run = resolved_context.get("selected_run") or resolved_context.get("latest_run")
    selected_artifact = resolved_context.get("selected_artifact")
    project_id = str(resolved_context.get("project_id") or "").strip()
    working_dir = resolved_context.get("working_dir")
    mutation_boundary = _workflow_mutation_boundary_message(resolved_context)
    output_review = _output_review_context(resolved_context)

    if (
        workflow_id
        and _intent_requires_clean_draft(decision.intent_id)
        and mutation_boundary is not None
    ):
        return AssistantLlmResponse(message=mutation_boundary)

    if decision.intent_id == "draft_workflow_from_thread":
        scaffold_definition, fallback_notice = _resolve_scaffold_from_decision(
            decision,
            user_message,
            resolved_context,
        )
        message = decision.message or (
            "I drafted a workflow scaffold from your request so you can review the stages before applying it."
        )
        if fallback_notice:
            message = f"{message}\n\n{fallback_notice}"
        return AssistantLlmResponse(
            message=message,
            outcome="proposal",
            action_records=[
                build_proposal_record(
                    action_id="execute_draft_workflow_from_thread",
                    action_type="draft_workflow_from_thread",
                    action_inputs={
                        "scaffold_definition": scaffold_definition,
                        "domain_id": scaffold_definition.get("domain_id", "business"),
                    },
                    preview_type="scaffold",
                    scaffold_definition=scaffold_definition,
                    stage_count=len(scaffold_definition.get("stages", [])),
                )
            ],
        )

    if decision.intent_id == "recommend_starters":
        return _build_starter_recommendation_record(
            user_message=user_message,
            explanation=decision.message
            or "I picked a starter that fits the domain and the workflow outcome you described.",
            resolved_context=resolved_context,
        )

    if decision.intent_id == "generate_documentation" and workflow_id:
        return _build_generate_documentation_record(
            workflow_id=workflow_id,
            explanation=decision.message
            or "I prepared stakeholder-ready workflow documentation for the active workflow.",
        )

    if decision.intent_id == "launch_run" and workflow_id:
        objective = str(decision.intent_args.get("objective") or f"Assistant launch for {workflow_id}")
        return AssistantLlmResponse(
            message=decision.message
            or "I prepared a workflow run launch using the active workflow context.",
            outcome="proposal",
            action_records=[
                build_proposal_record(
                    action_id="execute_launch_run",
                    action_type="propose_launch_run",
                    action_inputs={
                        "objective": objective,
                        "project_id": project_id,
                        "working_dir": working_dir,
                        "workflow_id": workflow_id,
                        "revision_id": revision_id,
                        "domain_id": _infer_domain_id(resolved_context),
                    },
                    preview_type="run_action",
                    run_action_kind="launch_run",
                    workflow_id=workflow_id,
                    revision_id=revision_id,
                    objective=objective,
                )
            ],
        )

    if decision.intent_id == "approve_operator_review" and isinstance(selected_run, dict):
        run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
        if run_id and str(selected_run.get("status") or "") == "awaiting_operator":
            blocking_summary = selected_run.get("blocking_summary", {})
            return AssistantLlmResponse(
                message=decision.message or "I prepared the operator approval action for the selected run.",
                outcome="proposal",
                action_records=[
                    build_proposal_record(
                        action_id="execute_approve_operator_review",
                        action_type="propose_approve_operator_review",
                        action_inputs={"run_id": run_id},
                        preview_type="run_action",
                        run_action_kind="approve_operator_review",
                        run_id=run_id,
                        required_action=str(
                            blocking_summary.get("required_action") or "approve_operator_review"
                        ),
                    )
                ],
            )

    if decision.intent_id == "resolve_escalation" and isinstance(selected_run, dict):
        run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
        escalation_id = str(
            selected_run.get("escalation_id")
            or selected_run.get("correlation", {}).get("escalation_id")
            or ""
        ).strip()
        choice = str(decision.intent_args.get("choice") or "force_complete").strip()
        if run_id and escalation_id and choice in {"force_complete", "abandon"}:
            return AssistantLlmResponse(
                message=decision.message or "I prepared an escalation resolution for the selected run.",
                outcome="proposal",
                action_records=[
                    build_proposal_record(
                        action_id="execute_resolve_escalation",
                        action_type="propose_resolve_escalation",
                        action_inputs={
                            "run_id": run_id,
                            "escalation_id": escalation_id,
                            "choice": choice,
                        },
                        preview_type="run_action",
                        run_action_kind="resolve_escalation",
                        run_id=run_id,
                        escalation_id=escalation_id,
                        choice=choice,
                    )
                ],
            )

    if decision.intent_id == "tighten_stage_review_instructions" and workflow_id:
        if output_review:
            return _build_output_review_response(
                workflow_id=workflow_id,
                revision_id=revision_id,
                explanation=decision.message
                or (
                    "I reviewed the selected evidence and prepared concrete workflow fixes you can choose from."
                ),
                resolved_context=resolved_context,
            )
        target_stage_id = _resolve_stage_id(decision.intent_args.get("stage_id"), resolved_context)
        if target_stage_id is None:
            target_stage_id = _selected_stage_id(resolved_context)
        if target_stage_id is None and isinstance(selected_run, dict):
            target_stage_id = str(
                selected_run.get("failure_stage_id")
                or selected_run.get("current_stage", {}).get("stage_id")
                or ""
            ) or None
        template_role = str(decision.intent_args.get("template_role") or "purpose").strip() or "purpose"
        instruction_focus = str(decision.intent_args.get("instruction_focus") or "").strip()
        subject = "the selected output evidence" if selected_artifact else "the workflow context"
        return _build_template_edit_response(
            workflow_id=workflow_id,
            revision_id=revision_id,
            stage_id=target_stage_id,
            template_role=template_role,
            before_content="Review the current output and produce a final result.",
            after_content=_default_template_after_content(
                subject=subject,
                instruction_focus=instruction_focus,
            ),
            explanation=decision.message
            or (
                "I prepared a targeted stage-instruction update you can review before applying."
            ),
        )

    if decision.intent_id == "insert_stage" and workflow_id:
        stage_definition, after_stage_id = _build_stage_definition(
            decision.intent_args,
            resolved_context,
        )
        return _build_insert_stage_record(
            workflow_id=workflow_id,
            revision_id=revision_id,
            stage_definition=stage_definition,
            after_stage_id=after_stage_id,
            explanation=decision.message
            or "I prepared the requested workflow stage for insertion.",
            resolved_context=resolved_context,
        )

    if decision.intent_id == "remove_stage" and workflow_id:
        stage_id = _resolve_stage_id(decision.intent_args.get("stage_id"), resolved_context)
        if stage_id is None:
            stage_id = _selected_stage_id(resolved_context)
        if stage_id:
            return _build_remove_stage_record(
                workflow_id=workflow_id,
                revision_id=revision_id,
                stage_id=stage_id,
                explanation=decision.message or "I prepared the requested stage removal.",
                resolved_context=resolved_context,
            )

    if decision.intent_id == "reorder_stages" and workflow_id:
        ordered_raw = decision.intent_args.get("ordered_stage_ids")
        ordered_stage_ids = []
        if isinstance(ordered_raw, list):
            ordered_stage_ids = [
                resolved
                for item in ordered_raw
                if (resolved := _resolve_stage_id(item, resolved_context)) is not None
            ]
        if ordered_stage_ids:
            return _build_reorder_stage_record(
                workflow_id=workflow_id,
                revision_id=revision_id,
                ordered_stage_ids=ordered_stage_ids,
                explanation=decision.message or "I prepared the requested workflow reorder.",
                resolved_context=resolved_context,
            )

    if decision.intent_id in {"connect_stages", "disconnect_stages"} and workflow_id:
        source_stage_id = _resolve_stage_id(decision.intent_args.get("source_stage_id"), resolved_context)
        target_stage_id = _resolve_stage_id(decision.intent_args.get("target_stage_id"), resolved_context)
        if source_stage_id is None:
            source_stage_id = _selected_stage_id(resolved_context)
        if source_stage_id and target_stage_id:
            return _build_connection_record(
                workflow_id=workflow_id,
                revision_id=revision_id,
                source_stage_id=source_stage_id,
                target_stage_id=target_stage_id,
                action="add" if decision.intent_id == "connect_stages" else "remove",
                explanation=decision.message
                or (
                    "I prepared the requested stage connection change."
                    if decision.intent_id == "connect_stages"
                    else "I prepared the requested stage disconnection."
                ),
                resolved_context=resolved_context,
            )

    return AssistantLlmResponse(
        message=_actionable_advice_message(
            decision.message
            or "I could not map this request to a supported proposal with high confidence.",
            user_message=user_message,
            resolved_context=resolved_context,
        )
    )
