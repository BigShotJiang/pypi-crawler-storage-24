"""Gateway config getter owners."""

from __future__ import annotations

import os

from obra.gateway.automation.profile import (
    GATEWAY_PROFILE_STANDARD,
    OBRA_GATEWAY_AUTH_TOKEN_ENV,
    OBRA_GATEWAY_PROFILE_ENV,
)

from .. import _core, _defaults

__all__ = [
    "get_gateway_assistant_config",
    "get_gateway_config",
    "get_gateway_transcription_config",
]


def get_gateway_config() -> dict:
    """Get gateway server configuration.

    Returns dict with host, port, max_sessions, auth_token, escalation_timeout_s,
    enable_cors, cors_origins, allowed_working_dir_base, max_event_queue_size,
    session_eviction_ttl_seconds, max_objective_length, max_project_id_length,
    max_working_dir_length, cors_allow_credentials, allow_public_bind,
    public_bind_tls_terminated, trusted_proxy_cidrs, ws_auth_timeout_s,
    max_ws_connections_total, max_ws_connections_per_ip, ws_max_message_bytes,
    enable_app_rate_limit, rest_rate_limit_per_minute, rest_rate_limit_burst,
    ws_rate_limit_per_minute, ws_rate_limit_burst, logs_session_cookie_name,
    logs_session_ttl_s, logs_session_cookie_secure, studio_session_cookie_name,
    studio_session_ttl_s, studio_session_cookie_secure, studio_launch_token_ttl_s,
    logs_stream_max_clients_total, logs_stream_max_clients_per_ip,
    logs_stream_idle_timeout_s, logs_expose_absolute_paths from gateway section.
    """
    config, _, _ = _core.load_layered_config()
    try:
        gw = config["gateway"]
        return {
            "profile": str(
                gw.get("profile")
                or os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD)
            ),
            "host": gw["host"],
            "port": gw["port"],
            "max_sessions": gw["max_sessions"],
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV, gw.get("auth_token")),
            "escalation_timeout_s": float(gw["escalation_timeout_s"]),
            "enable_cors": gw["enable_cors"],
            "cors_origins": gw["cors_origins"],
            "allowed_working_dir_base": gw.get("allowed_working_dir_base", "~/obra-projects"),
            "max_event_queue_size": int(gw.get("max_event_queue_size", 1000)),
            "session_eviction_ttl_seconds": int(gw.get("session_eviction_ttl_seconds", 3600)),
            "max_objective_length": int(gw.get("max_objective_length", 10000)),
            "max_project_id_length": int(gw.get("max_project_id_length", 256)),
            "max_working_dir_length": int(gw.get("max_working_dir_length", 4096)),
            "cors_allow_credentials": gw.get("cors_allow_credentials", True),
            "allow_public_bind": gw.get("allow_public_bind", False),
            "public_bind_tls_terminated": gw.get("public_bind_tls_terminated", False),
            "trusted_proxy_cidrs": list(gw.get("trusted_proxy_cidrs", [])),
            "ws_auth_timeout_s": float(gw.get("ws_auth_timeout_s", 5)),
            "max_ws_connections_total": int(gw.get("max_ws_connections_total", 200)),
            "max_ws_connections_per_ip": int(gw.get("max_ws_connections_per_ip", 20)),
            "ws_max_message_bytes": int(gw.get("ws_max_message_bytes", 1_048_576)),
            "enable_app_rate_limit": gw.get("enable_app_rate_limit", True),
            "rest_rate_limit_per_minute": int(gw.get("rest_rate_limit_per_minute", 120)),
            "rest_rate_limit_burst": int(gw.get("rest_rate_limit_burst", 60)),
            "ws_rate_limit_per_minute": int(gw.get("ws_rate_limit_per_minute", 240)),
            "ws_rate_limit_burst": int(gw.get("ws_rate_limit_burst", 120)),
            "logs_session_cookie_name": gw["logs_session_cookie_name"],
            "logs_session_ttl_s": int(gw["logs_session_ttl_s"]),
            "logs_session_cookie_secure": bool(gw["logs_session_cookie_secure"]),
            "studio_session_cookie_name": str(
                gw.get("studio_session_cookie_name", "obra_studio_session")
            ),
            "studio_session_ttl_s": int(gw.get("studio_session_ttl_s", 43_200)),
            "studio_session_cookie_secure": bool(
                gw.get("studio_session_cookie_secure", False)
            ),
            "studio_launch_token_ttl_s": int(gw.get("studio_launch_token_ttl_s", 120)),
            "logs_stream_max_clients_total": int(gw["logs_stream_max_clients_total"]),
            "logs_stream_max_clients_per_ip": int(gw["logs_stream_max_clients_per_ip"]),
            "logs_stream_idle_timeout_s": float(gw["logs_stream_idle_timeout_s"]),
            "logs_expose_absolute_paths": bool(gw["logs_expose_absolute_paths"]),
        }
    except (KeyError, TypeError):
        return {
            "profile": os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD),
            "host": _defaults.DEFAULT_GATEWAY_HOST,
            "port": _defaults.DEFAULT_GATEWAY_PORT,
            "max_sessions": _defaults.DEFAULT_GATEWAY_MAX_SESSIONS,
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV),
            "escalation_timeout_s": _defaults.DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S,
            "enable_cors": _defaults.DEFAULT_GATEWAY_ENABLE_CORS,
            "cors_origins": _defaults.DEFAULT_GATEWAY_CORS_ORIGINS,
            "allowed_working_dir_base": "~/obra-projects",
            "max_event_queue_size": 1000,
            "session_eviction_ttl_seconds": 3600,
            "max_objective_length": 10000,
            "max_project_id_length": 256,
            "max_working_dir_length": 4096,
            "cors_allow_credentials": True,
            "allow_public_bind": False,
            "public_bind_tls_terminated": False,
            "trusted_proxy_cidrs": [],
            "ws_auth_timeout_s": 5.0,
            "max_ws_connections_total": 200,
            "max_ws_connections_per_ip": 20,
            "ws_max_message_bytes": 1_048_576,
            "enable_app_rate_limit": True,
            "rest_rate_limit_per_minute": 120,
            "rest_rate_limit_burst": 60,
            "ws_rate_limit_per_minute": 240,
            "ws_rate_limit_burst": 120,
            "logs_session_cookie_name": "obra_logs_session",
            "logs_session_ttl_s": 900,
            "logs_session_cookie_secure": False,
            "studio_session_cookie_name": "obra_studio_session",
            "studio_session_ttl_s": 43_200,
            "studio_session_cookie_secure": False,
            "studio_launch_token_ttl_s": 120,
            "logs_stream_max_clients_total": 100,
            "logs_stream_max_clients_per_ip": 20,
            "logs_stream_idle_timeout_s": 900.0,
            "logs_expose_absolute_paths": False,
        }


def get_gateway_assistant_config() -> dict:
    """Get gateway assistant context pipeline configuration.

    Returns a flat dict with all assistant operational parameters from
    gateway.assistant config section plus orchestration.content.chars_per_token.
    """
    config, _, _ = _core.load_layered_config()
    try:
        assistant = config["gateway"]["assistant"]
    except (KeyError, TypeError):
        assistant = {}

    # Also pull chars_per_token from orchestration.content for token estimation
    try:
        chars_per_token = int(config["orchestration"]["content"]["chars_per_token"])
    except (KeyError, TypeError, ValueError):
        chars_per_token = 4

    section_priorities = assistant.get("section_priorities", {})
    conv_history = assistant.get("conversation_history", {})
    memory = assistant.get("memory", {})
    persistence = assistant.get("persistence", {})
    retention = assistant.get("retention", {})
    strategy = assistant.get("strategy", {})
    revision_history = assistant.get("revision_history", {})
    knowledge = assistant.get("knowledge", {})
    screenshot = assistant.get("screenshot", {})
    run_timeline = assistant.get("run_timeline", {})
    stage_detail = assistant.get("stage_detail", {})
    model = assistant.get("model", {})
    logging_section = assistant.get("logging", {})

    return {
        "prompt_budget_tokens": int(assistant.get("prompt_budget_tokens", 8000)),
        "chars_per_token": chars_per_token,
        "section_priorities": {
            "preamble": int(section_priorities.get("preamble", 1)),
            "selected_stage": int(section_priorities.get("selected_stage", 2)),
            "workflow_definition": int(section_priorities.get("workflow_definition", 3)),
            "knowledge_docs": int(section_priorities.get("knowledge_docs", 4)),
            "recent_transcript": int(section_priorities.get("recent_transcript", 4)),
            "thread_summary": int(section_priorities.get("thread_summary", 4)),
            "carry_forward_context": int(section_priorities.get("carry_forward_context", 4)),
            "conversation_history": int(section_priorities.get("conversation_history", 5)),
            "latest_run": int(section_priorities.get("latest_run", 6)),
            "ui_state": int(section_priorities.get("ui_state", 7)),
            "graph_structure": int(section_priorities.get("graph_structure", 7)),
            "proactive_guidance": int(section_priorities.get("proactive_guidance", 7)),
            "recent_changes": int(section_priorities.get("recent_changes", 8)),
            "interaction_log": int(section_priorities.get("interaction_log", 9)),
            "revision_history": int(section_priorities.get("revision_history", 10)),
        },
        "conversation_history_max_proposal_turns": int(
            conv_history.get("max_proposal_turns", 10)
        ),
        "conversation_history_message_preview_chars": int(
            conv_history.get("message_preview_chars", 80)
        ),
        "memory_recent_turns": int(memory.get("recent_turns", 6)),
        "memory_summary_turns": int(memory.get("summary_turns", 12)),
        "memory_summary_message_chars": int(memory.get("summary_message_chars", 160)),
        "memory_mode_event_limit": int(memory.get("mode_event_limit", 6)),
        "persistence_storage_path": str(
            persistence.get("storage_path", "assistant/threads.json")
        ),
        "retention": {
            "max_active_threads": int(retention.get("max_active_threads", 20)),
            "archive_after_days": int(retention.get("archive_after_days", 30)),
            "delete_after_days": int(retention.get("delete_after_days", 180)),
        },
        "strategy_design_guidance_max_stages": int(
            strategy.get("design_guidance_max_stages", 3)
        ),
        "revision_history_max_revisions": int(
            revision_history.get("max_revisions", 5)
        ),
        "knowledge_max_document_bytes": int(
            knowledge.get("max_document_bytes", 102400)
        ),
        "knowledge_max_total_bytes": int(
            knowledge.get("max_total_bytes", 2097152)
        ),
        "knowledge_token_budget": int(knowledge.get("token_budget", 2000)),
        "screenshot_max_bytes": int(screenshot.get("max_bytes", 204800)),
        "screenshot_initial_scale": float(screenshot.get("initial_scale", 0.5)),
        "screenshot_jpeg_quality": float(screenshot.get("jpeg_quality", 0.7)),
        "screenshot_fallback_scale": float(screenshot.get("fallback_scale", 0.3)),
        "screenshot_fallback_quality": float(screenshot.get("fallback_quality", 0.5)),
        "run_timeline_max_events": int(run_timeline.get("max_events", 10)),
        "stage_detail_max_dependency_chain_stages": int(
            stage_detail.get("max_dependency_chain_stages", 20)
        ),
        "model_default_model": str(model.get("default_model", "sonnet")),
        "model_default_provider": str(model.get("default_provider", "anthropic")),
        "model_health_check_on_startup": bool(
            model.get("health_check_on_startup", True)
        ),
        "model_health_check_cache_ttl_s": int(
            model.get("health_check_cache_ttl_s", 300)
        ),
        "auth_method": str(model.get("auth_method", "oauth")),
        "allow_stub_fallback": bool(
            os.environ.get("OBRA_GATEWAY_ASSISTANT_STUB_FALLBACK", "").strip().lower()
            in ("1", "true", "yes")
            or assistant.get("allow_stub_fallback", False)
        ),
        "logging": dict(logging_section),
    }


def get_gateway_transcription_config() -> dict:
    """Get gateway transcription configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    transcription = config["gateway"]["transcription"]
    return {
        "provider": str(transcription["provider"]),
        "model_size": str(transcription["model_size"]),
        "max_audio_bytes": int(transcription["max_audio_bytes"]),
    }
