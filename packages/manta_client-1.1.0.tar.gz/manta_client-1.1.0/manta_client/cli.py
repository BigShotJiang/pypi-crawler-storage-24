"""Manta client CLI main entry point.

Usage:
    manta-client [OPTIONS] COMMAND [ARGS]...

Commands:
    config          Configuration management
    auth            Authentication management
    job             Job management
    skill           Skill management
    schedule        Schedule management
    secret          Secret management
"""

from __future__ import annotations

import typer

from manta_client import __version__
from manta_client.commands import auth, config, self_cmd
from manta_client.commands import dashboard as dashboard_cmd
from manta_client.commands import doctor as doctor_cmd
from manta_client.commands.agent import assistant as assistant_cmd
from manta_client.commands.agent import cluster as cluster_cmd
from manta_client.commands.agent import job as job_cmd
from manta_client.commands.agent import resource as resource_cmd
from manta_client.commands.agent import schedule as schedule_cmd
from manta_client.commands.agent import secret as secret_cmd
from manta_client.commands.agent import skill as skill_cmd
from manta_client.commands.agent import workspace as workspace_cmd

# Create main app
app = typer.Typer(
    name="manta-client",
    help="Manta AI Agent client CLI",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Add command groups to main app
app.add_typer(config.app, name="config")
app.add_typer(auth.app, name="auth")
app.add_typer(assistant_cmd.app, name="assistant")
app.add_typer(job_cmd.app, name="job")
app.add_typer(skill_cmd.app, name="skill")
app.add_typer(schedule_cmd.app, name="schedule")
app.add_typer(secret_cmd.app, name="secret")
app.add_typer(cluster_cmd.app, name="cluster")
app.add_typer(workspace_cmd.app, name="workspace")
app.add_typer(resource_cmd.app, name="resource")
app.add_typer(self_cmd.app, name="self")
app.add_typer(doctor_cmd.app, name="doctor")
app.add_typer(dashboard_cmd.app, name="dashboard")


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        typer.echo(f"manta-client version {__version__}")
        raise typer.Exit()


def quiet_callback(value: bool) -> None:
    """Enable quiet mode for machine-friendly output."""
    if value:
        from manta_client.output import set_quiet

        set_quiet(True)


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        callback=quiet_callback,
        is_eager=True,
        help="Quiet mode: minimal output for scripting and AI agents",
    ),
) -> None:
    """Manta AI Agent client CLI.

    A command-line interface for interacting with the Manta API.
    Manage jobs, environments, skills, and more.

    [bold]Getting Started:[/bold]

    1. Configure API URL:
       $ manta-client config set api_url http://your-server:8000

    2. Login via OAuth2:
       $ manta-client auth login

    3. Create a job:
       $ manta-client job create -m "Analyze this codebase"

    [bold]Quiet Mode (-q):[/bold]

    Use --quiet for machine-friendly output (scripts, AI agents):
       $ manta-client -q job create -m "task"    # prints only job_id
       $ manta-client -q job list                 # prints one job_id per line
    """
    pass


if __name__ == "__main__":
    app()
