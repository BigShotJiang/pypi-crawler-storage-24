"""Manta Dashboard - lightweight web dashboard served locally."""
