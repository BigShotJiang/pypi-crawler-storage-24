"""Standardized exit codes for manta-client CLI.

These exit codes allow callers (scripts, Claude Code, CI) to
programmatically determine what went wrong without parsing stderr.
"""

# Success
SUCCESS = 0

# General / unknown error
ERROR = 1

# Authentication failure (401, token expired)
AUTH_FAILURE = 2

# Resource not found (404)
NOT_FOUND = 3

# Client-side validation / argument error
VALIDATION_ERROR = 4

# Job terminal states (used by `job wait`)
JOB_FAILED = 10
JOB_CANCELLED = 11
JOB_TIMEOUT = 12


def exit_code_for_api_error(code: int) -> int:
    """Map an HTTP/API error code to a CLI exit code."""
    if code == 401:
        return AUTH_FAILURE
    if code == 404:
        return NOT_FOUND
    if code in (400, 409, 422):
        return VALIDATION_ERROR
    return ERROR
