"""Manta client CLI package."""

try:
    from manta_client._version import __version__
except ModuleNotFoundError:
    __version__ = "0.0.0.dev0"
