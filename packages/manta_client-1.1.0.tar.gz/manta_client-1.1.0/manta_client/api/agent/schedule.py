"""Schedule API client."""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class ScheduleAPI:
    """Schedule API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def list_schedules(self, skip: int = 0, limit: int = 100) -> dict[str, Any]:
        """List schedules."""
        return await self.client.get("/api/v1/schedules", params={"skip": skip, "limit": limit})

    async def get_schedule(self, pk: int) -> dict[str, Any]:
        """Get schedule by ID."""
        return await self.client.get(f"/api/v1/schedules/{pk}")

    async def create_schedule(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create schedule."""
        return await self.client.post("/api/v1/schedules", data=data)

    async def delete_schedule(self, pk: int) -> dict[str, Any]:
        """Delete schedule."""
        return await self.client.delete(f"/api/v1/schedules/{pk}")


_schedule_api: ScheduleAPI | None = None


def get_schedule_api() -> ScheduleAPI:
    """Get or create the global Schedule API instance."""
    global _schedule_api
    if _schedule_api is None:
        _schedule_api = ScheduleAPI()
    return _schedule_api
