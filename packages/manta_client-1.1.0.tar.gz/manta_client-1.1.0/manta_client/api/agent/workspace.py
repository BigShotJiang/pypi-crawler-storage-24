"""Workspace API client."""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class WorkspaceAPI:
    """Workspace API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def list_workspaces(self) -> dict[str, Any]:
        """List user's workspaces."""
        return await self.client.get("/api/v1/workspaces")

    async def get_workspace(self, workspace_id: int) -> dict[str, Any]:
        """Get workspace by ID."""
        return await self.client.get(f"/api/v1/workspaces/{workspace_id}")

    async def get_workspace_by_name(self, name: str) -> dict[str, Any]:
        """Get workspace by name."""
        return await self.client.get(f"/api/v1/workspaces/by-name/{name}")

    async def create_workspace(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create workspace."""
        return await self.client.post("/api/v1/workspaces", data=data)

    async def update_workspace(self, workspace_id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update workspace."""
        return await self.client.put(f"/api/v1/workspaces/{workspace_id}", data=data)

    async def delete_workspace(self, workspace_id: int) -> dict[str, Any]:
        """Delete workspace."""
        return await self.client.delete(f"/api/v1/workspaces/{workspace_id}")

    async def sync_workspace(self, workspace_id: int) -> dict[str, Any]:
        """Trigger workspace repo sync."""
        return await self.client.post(f"/api/v1/workspaces/{workspace_id}/sync")


_workspace_api: WorkspaceAPI | None = None


def get_workspace_api() -> WorkspaceAPI:
    """Get or create the global Workspace API instance."""
    global _workspace_api
    if _workspace_api is None:
        _workspace_api = WorkspaceAPI()
    return _workspace_api
