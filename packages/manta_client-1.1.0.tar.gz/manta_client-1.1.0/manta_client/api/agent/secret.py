"""Secret API client.

Endpoints:
- POST /api/v1/secrets - Create secret
- GET /api/v1/secrets - List secrets
- GET /api/v1/secrets/{id} - Get secret info
- PUT /api/v1/secrets/{id} - Update secret
- DELETE /api/v1/secrets/{id} - Delete secret
"""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class SecretAPI:
    """Secret API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def create_secret(
        self,
        name: str,
        value: str,
        description: str | None = None,
        scope: str = "user",
    ) -> dict[str, Any]:
        """Create a new secret (always user-scoped via CLI).

        Args:
            name: Unique secret name
            value: Secret value (plaintext, will be encrypted server-side)
            description: Secret description
            scope: Scope (default: user)

        Returns:
            SecretInfo dict
        """
        data: dict[str, Any] = {"name": name, "value": value, "scope": scope}
        if description:
            data["description"] = description
        return await self.client.post("/api/v1/secrets", data=data)

    async def list_secrets(
        self,
        scope: str | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> dict[str, Any]:
        """List secrets (values are never returned).

        Args:
            scope: Filter by scope
            skip: Offset for pagination
            limit: Maximum number of results

        Returns:
            {items: list[SecretInfo], total: int}
        """
        params: dict[str, Any] = {"skip": skip, "limit": limit}
        if scope:
            params["scope"] = scope
        return await self.client.get("/api/v1/secrets", params=params)

    async def get_secret(self, pk: int) -> dict[str, Any]:
        """Get secret by ID (value is never returned).

        Args:
            pk: Secret ID

        Returns:
            SecretInfo dict
        """
        return await self.client.get(f"/api/v1/secrets/{pk}")

    async def update_secret(
        self,
        pk: int,
        value: str | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Update a secret.

        Args:
            pk: Secret ID
            value: New secret value
            description: New description

        Returns:
            SecretInfo dict
        """
        data: dict[str, Any] = {}
        if value is not None:
            data["value"] = value
        if description is not None:
            data["description"] = description
        return await self.client.put(f"/api/v1/secrets/{pk}", data=data)

    async def delete_secret(self, pk: int) -> Any:
        """Delete a secret.

        Args:
            pk: Secret ID

        Returns:
            Success response
        """
        return await self.client.delete(f"/api/v1/secrets/{pk}")


# Singleton API instance
_secret_api: SecretAPI | None = None


def get_secret_api() -> SecretAPI:
    """Get or create the global Secret API instance."""
    global _secret_api
    if _secret_api is None:
        _secret_api = SecretAPI()
    return _secret_api
