"""Resource API client.

Endpoints:
- GET /api/v1/resources - List managed resources
- GET /api/v1/resources/{id} - Get resource details
- POST /api/v1/resources/{id}/renew - Renew resource lease
- POST /api/v1/resources/{id}/cleanup - Manually clean up resource
- POST /api/v1/resources/{id}/protect - Protect resource (admin)
- DELETE /api/v1/resources/{id}/protect - Unprotect resource (admin)
"""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class ResourceAPI:
    """Resource API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def list_resources(
        self,
        status: str | None = None,
        skip: int = 0,
        limit: int = 100,
        refresh: bool = False,
    ) -> dict[str, Any]:
        """List managed resources.

        Args:
            status: Filter by status (active, expiring, protected, etc.)
            skip: Offset for pagination
            limit: Maximum number of results
            refresh: Scan K8s namespaces before listing to discover new resources

        Returns:
            {items: list[ResourceInfo], total: int}
        """
        params: dict[str, Any] = {"skip": skip, "limit": limit}
        if status:
            params["status"] = status
        if refresh:
            params["refresh"] = True
        return await self.client.get("/api/v1/resources", params=params)

    async def get_resource(self, pk: int) -> dict[str, Any]:
        """Get resource details by ID.

        Args:
            pk: Resource ID

        Returns:
            ResourceInfo dict
        """
        return await self.client.get(f"/api/v1/resources/{pk}")

    async def renew_resource(self, pk: int, hours: int = 24) -> dict[str, Any]:
        """Renew resource lease.

        Args:
            pk: Resource ID
            hours: Hours to extend the lease

        Returns:
            ResourceInfo dict
        """
        return await self.client.post(f"/api/v1/resources/{pk}/renew", data={"hours": hours})

    async def cleanup_resource(self, pk: int) -> dict[str, Any]:
        """Manually clean up a resource (delete from K8s).

        Args:
            pk: Resource ID

        Returns:
            ResourceInfo dict
        """
        return await self.client.post(f"/api/v1/resources/{pk}/cleanup")

    async def protect_resource(self, pk: int) -> dict[str, Any]:
        """Mark resource as permanently protected (admin only).

        Args:
            pk: Resource ID

        Returns:
            ResourceInfo dict
        """
        return await self.client.post(f"/api/v1/resources/{pk}/protect")

    async def unprotect_resource(self, pk: int) -> dict[str, Any]:
        """Remove protection from resource (admin only).

        Args:
            pk: Resource ID

        Returns:
            ResourceInfo dict
        """
        return await self.client.delete(f"/api/v1/resources/{pk}/protect")


# Singleton API instance
_resource_api: ResourceAPI | None = None


def get_resource_api() -> ResourceAPI:
    """Get or create the global Resource API instance."""
    global _resource_api
    if _resource_api is None:
        _resource_api = ResourceAPI()
    return _resource_api
