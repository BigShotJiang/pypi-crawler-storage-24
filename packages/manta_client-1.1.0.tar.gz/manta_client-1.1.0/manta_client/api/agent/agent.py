"""Agent API client.

Endpoints:
- GET /api/v1/agents - List all agents
- GET /api/v1/agents/{name} - Get agent info
- POST /api/v1/agents/{name}/execute - Execute agent
"""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class AgentAPI:
    """Agent API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def list_agents(self) -> dict[str, Any]:
        """List all available agents.

        Returns:
            {agents: list[AgentInfo], total: int}
        """
        return await self.client.get("/api/v1/agents")

    async def get_agent(self, name: str) -> dict[str, Any]:
        """Get agent information by name.

        Args:
            name: Agent name

        Returns:
            AgentInfo dict
        """
        return await self.client.get(f"/api/v1/agents/{name}")

    async def execute_agent(
        self,
        name: str,
        input_data: dict[str, Any] | None = None,
        timeout: float = 300.0,
    ) -> dict[str, Any]:
        """Execute an agent synchronously.

        Args:
            name: Agent name
            input_data: Agent input parameters
            timeout: Request timeout in seconds (default 5 minutes for long-running agents)

        Returns:
            AgentExecuteResponse dict
        """
        data = {
            "input_data": input_data or {},
        }

        return await self.client.post(f"/api/v1/agents/{name}/execute", data=data, timeout=timeout)


# Singleton API instance
_agent_api: AgentAPI | None = None


def get_agent_api() -> AgentAPI:
    """Get or create the global Agent API instance."""
    global _agent_api
    if _agent_api is None:
        _agent_api = AgentAPI()
    return _agent_api
