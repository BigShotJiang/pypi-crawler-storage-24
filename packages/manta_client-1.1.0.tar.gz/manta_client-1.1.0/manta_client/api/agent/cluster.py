"""Cluster API client."""

from __future__ import annotations

from typing import Any

from manta_client.api.client import MantaClient, get_client


class ClusterAPI:
    """Cluster API client."""

    def __init__(self, client: MantaClient | None = None):
        self.client = client or get_client()

    async def list_clusters(self) -> dict[str, Any]:
        """List all clusters."""
        return await self.client.get("/api/v1/clusters")

    async def get_cluster(self, cluster_id: int) -> dict[str, Any]:
        """Get cluster by ID."""
        return await self.client.get(f"/api/v1/clusters/{cluster_id}")

    async def get_cluster_by_name(self, name: str) -> dict[str, Any]:
        """Get cluster by name."""
        return await self.client.get(f"/api/v1/clusters/by-name/{name}")

    async def create_cluster(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create a new cluster (admin only)."""
        return await self.client.post("/api/v1/clusters", data=data)

    async def update_cluster(self, cluster_id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update a cluster (admin only)."""
        return await self.client.put(f"/api/v1/clusters/{cluster_id}", data=data)

    async def delete_cluster(self, cluster_id: int) -> dict[str, Any]:
        """Delete a cluster (admin only)."""
        return await self.client.delete(f"/api/v1/clusters/{cluster_id}")

    async def download_kubeconfig(self, name: str) -> dict[str, Any]:
        """Download kubeconfig for a cluster."""
        return await self.client.get(f"/api/v1/clusters/by-name/{name}/kubeconfig")


_cluster_api: ClusterAPI | None = None


def get_cluster_api() -> ClusterAPI:
    """Get or create the global Cluster API instance."""
    global _cluster_api
    if _cluster_api is None:
        _cluster_api = ClusterAPI()
    return _cluster_api
