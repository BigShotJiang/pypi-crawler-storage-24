// ═══════════════════════════════════════════════════════
//  CVC Dashboard — TypeScript Type Definitions
// ═══════════════════════════════════════════════════════

// ── Service Status ──────────────────────────────────
export type ServiceStatus = 'running' | 'stopped' | 'unknown' | 'error';

export interface ServiceInfo {
  name: string;
  status: ServiceStatus;
  port?: number;
  pid?: number | null;
  uptime?: string | null;
  url?: string;
}

export interface ServicesResponse {
  services: Record<string, ServiceInfo>;
  gateway_uptime: string;
}

// ── Analytics / Stats ───────────────────────────────
export interface AnalyticsResponse {
  commits: { total: number; by_type: Record<string, number>; by_branch: Record<string, number> };
  branches: Array<{ name: string; head: string; status: string }>;
  tokens: { total: number; estimated_cost_usd: number };
  recent_activity: unknown[];
}

export interface StatsResponse {
  total_commits: number;
  total_branches: number;
  total_agents: number;
  commits_by_type: Record<string, number>;
  total_tokens: number;
  estimated_cost_usd: number;
  database_size_bytes: number;
  blob_count: number;
  head?: string | null;
}

// ── Commits / Timeline ─────────────────────────────
export interface CommitEntry {
  hash: string;
  message: string;
  timestamp: string;
  commit_type?: string;
  branch?: string;
  parent_hash?: string | null;
  content?: string;
  metadata?: Record<string, unknown>;
}

export interface TimelineEntry {
  hash: string;
  message: string;
  timestamp: string;
  commit_type?: string;
  branch?: string;
}

// ── Operations ──────────────────────────────────────
export interface CommitRequest {
  message: string;
  content?: string;
  commit_type?: string;
  metadata?: Record<string, unknown>;
}

export interface BranchRequest {
  name: string;
}

export interface MergeRequest {
  source_branch: string;
  strategy?: string;
}

export interface RestoreRequest {
  commit_hash: string;
}

export interface OperationResult {
  status: string;
  hash?: string;
  branch?: string;
  message?: string;
  error?: string;
  [key: string]: unknown;
}

export interface RecallResult {
  results: Array<{
    hash: string;
    message: string;
    score: number;
    content?: string;
  }>;
}

export interface DiffResult {
  commit_a: string;
  commit_b: string;
  diff: string | Record<string, unknown>;
}

// ── Memory / Context ────────────────────────────────
export interface ContextEntry {
  role: string;
  content: string;
  timestamp?: string;
}

export interface MemoryContextResponse {
  context: ContextEntry[];
  token_count?: number;
}

export interface BlobEntry {
  hash: string;
  size: number;
  type?: string;
}

export interface MemoryBlobsResponse {
  blobs: BlobEntry[];
  total: number;
}

export interface MemoryStatsResponse {
  database_size_bytes: number;
  blob_count: number;
  blob_total_bytes: number;
  cvc_root: string;
}

// ── Models ──────────────────────────────────────────
export interface ModelInfo {
  id: string;
  name: string;
  provider: string;
  context_window?: number;
  max_output?: number;
  description?: string;
}

export interface ModelCatalog {
  providers: Record<string, ModelInfo[]>;
}

export interface CurrentModel {
  provider: string;
  model: string;
  api_key_set: boolean;
}

// ── MCP ─────────────────────────────────────────────
export interface MCPTool {
  name: string;
  description: string;
  parameters?: Record<string, unknown>;
}

export interface MCPStatus {
  available: boolean;
  transport: string;
  tool_count: number;
}

// ── Chat ────────────────────────────────────────────
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatRequest {
  messages: ChatMessage[];
  model?: string;
  stream?: boolean;
}

// ── Hive Mind / SDK ─────────────────────────────────
export interface HiveMindAgent {
  agent_id: string;
  name?: string;
  role?: string;
  rank?: string;
  squad?: string;
  registered_at?: string;
}

export interface RegisterAgentRequest {
  agent_id: string;
  name?: string;
  role?: string;
  rank?: string;
  squad?: string;
}

// ── Connections ─────────────────────────────────────
export interface ConnectionInfo {
  name: string;
  description: string;
  icon: string;
  base_url: string;
  api_key: string;
  instructions: string;
}

// ── VCS ─────────────────────────────────────────────
export interface VCSStatus {
  provider: string;
  repo_root?: string;
  current_branch?: string;
  has_repo: boolean;
}

// ── Audit ───────────────────────────────────────────
export interface AuditEntry {
  timestamp: string;
  action: string;
  details?: string;
}

// ── WebSocket ───────────────────────────────────────
export interface WSMessage {
  type: string;
  data: unknown;
  timestamp?: string;
}

// ── Config ──────────────────────────────────────────
export interface GatewayConfig {
  proxy_port: number;
  gateway_port: number;
  db_path?: string;
  provider?: string;
  model?: string;
  [key: string]: unknown;
}

// ── Settings ────────────────────────────────────────
export interface SettingsFieldOption {
  value: string;
  label: string;
  desc?: string;
}

export interface SettingsField {
  key: string;
  type: 'text' | 'number' | 'password' | 'select' | 'toggle' | 'radio' | 'slider'
    | 'tag_list' | 'key_value' | 'hook_editor' | 'plugin_toggles' | 'model_select';
  label: string;
  description?: string;
  placeholder?: string;
  options?: string[] | SettingsFieldOption[];
  depends_on?: string;
  level: 'global' | 'project' | 'local';
  min?: number;
  max?: number;
  step?: number;
  visible_when?: Record<string, string>;
  hook_events?: string[];
}

export interface SettingsSection {
  id: string;
  title: string;
  icon: string;
  fields: SettingsField[];
}

export interface SettingsSchema {
  sections: SettingsSection[];
}

export interface SettingsGlobal {
  provider: string;
  model: string;
  agent_id: string;
  api_keys: Record<string, string>;
}

export interface SettingsProject {
  permissions: { allow: string[]; deny: string[]; ask: string[] };
  env: Record<string, string>;
  hooks: Record<string, unknown[]>;
  outputStyle: string;
  autoMemoryEnabled: boolean;
  alwaysThinkingEnabled: boolean;
  autoCompactThreshold: number;
  enabledPlugins: Record<string, boolean>;
  trust_mode: string;
  plan_display: string;
  trusted_commands: string[];
  blocked_commands: string[];
  [key: string]: unknown;
}

export interface SettingsResponse {
  global: SettingsGlobal;
  project: SettingsProject;
  schema: SettingsSchema;
}

// ── Agent Templates ─────────────────────────────────
export interface AgentTemplate {
  id: string;
  name: string;
  description: string;
  system_prompt: string;
  tools_allow: string[];
  tools_deny: string[];
  tool_tier: string;
  model_override: string;
  provider_override: string;
  max_turns: number;
  rank: string;
  squad: string;
  capabilities: string[];
  skills: string[];
  auto_respond: boolean;
  auto_share_to_hive: boolean;
  created_at: number;
  updated_at: number;
  created_by: string;
  is_builtin: boolean;
  source?: string;
}

export interface AgentsListResponse {
  registered: Record<string, unknown>[];
  templates: AgentTemplate[];
  builtins: AgentTemplate[];
  total: number;
}

export interface AgentFromPromptResponse {
  status: string;
  template: AgentTemplate;
  raw_description: string;
}

// ── Hive Memory ─────────────────────────────────────
export interface HiveMemoryEntry {
  id: string;
  agent_id: string;
  content: string;
  category: string;
  tags: string[];
  timestamp: number;
  commit_hash: string;
  message: string;
}

export interface HiveMemoryResponse {
  entries: HiveMemoryEntry[];
  total: number;
}

export interface HiveMemoryStats {
  total_entries: number;
  categories: Record<string, number>;
  contributing_agents: string[];
  agent_count: number;
}

export interface SquadInfo {
  name: string;
  branch: string;
  agents: Record<string, unknown>[];
  agent_count: number;
}
