"""DDD-friendly agent template package."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ddd-agent")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
