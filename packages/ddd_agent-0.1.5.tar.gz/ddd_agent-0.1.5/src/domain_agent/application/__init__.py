"""Application layer package with ports, DTOs, and use cases."""
