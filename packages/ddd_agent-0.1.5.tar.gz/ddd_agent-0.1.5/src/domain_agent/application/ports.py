"""Application ports for the generic agent workflow."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Protocol

from domain_agent.application.dto import AgentWorkResult
from domain_agent.domain import (
    AgentPlan,
    PlannedAction,
    Request,
)


class RequestRepository(Protocol):
    """Persistence boundary for workflow requests."""

    def get(self, request_id: str) -> Request | None:
        """Load a request by id."""

    def save(self, request: Request) -> None:
        """Persist the current request state."""


class ContextProvider(Protocol):
    """External source for request context."""

    def get_context(self, request: Request) -> dict[str, object]:
        """Return context relevant to the request."""


class AgentEngine(Protocol):
    """Boundary for preparing agent analysis, plan, and proposal output."""

    def prepare(
        self,
        request: Request,
        context: Mapping[str, object],
    ) -> AgentWorkResult:
        """Create structured agent output for the request."""


class ActionExecutor(Protocol):
    """Boundary for executing the reviewed action."""

    def execute(self, request: Request, agent_plan: AgentPlan | None = None) -> str:
        """Execute the request and return execution notes."""


class Tool(Protocol):
    """Executable tool used by a planned action."""

    name: str

    def execute(self, request: Request, action: PlannedAction) -> str:
        """Execute a planned action for the request."""


class ToolRegistry(Protocol):
    """Lookup boundary for executable tools."""

    def get(self, tool_name: str) -> Tool:
        """Return the registered tool for the given name."""


@dataclass(frozen=True)
class WorkflowDependencies:
    """Dependencies required by the workflow graph."""

    context_provider: ContextProvider
    agent_engine: AgentEngine
    action_executor: ActionExecutor
    requires_human_review: bool = True
    auto_reviewer_id: str = "workflow-system"
