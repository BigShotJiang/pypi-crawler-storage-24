"""LangChain-based adapters for agent preparation."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool

from domain_agent.application.dto import AgentWorkResult, AnalysisResult, Observation
from domain_agent.application.ports import AgentEngine
from domain_agent.domain import AgentPlan, PlannedAction, Proposal, Request, RiskLevel


def _default_prompt() -> ChatPromptTemplate:
    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You prepare structured agent work for a request. "
                    "Return JSON only.\n{format_instructions}"
                ),
            ),
            (
                "human",
                (
                    "Request summary: {request_summary}\n"
                    "Request details: {request_details}\n"
                    "Risk level: {risk_level}\n"
                    "Context: {context}\n"
                    "Available tools: {tool_catalog}\n"
                    "Prepare analysis, proposal, and optional actions."
                ),
            ),
        ]
    )


@dataclass(frozen=True)
class LangChainAgentEngine(AgentEngine):
    """Use LangChain LCEL primitives to prepare structured agent work."""

    model: Runnable[object, object]
    tools: Sequence[BaseTool] = ()
    prepared_by: str = "langchain-agent-engine"
    prompt: ChatPromptTemplate = field(default_factory=_default_prompt)

    def prepare(
        self,
        request: Request,
        context: Mapping[str, object],
    ) -> AgentWorkResult:
        parser = JsonOutputParser()
        chain = self.prompt | self.model | parser
        payload = chain.invoke(
            {
                "format_instructions": parser.get_format_instructions(),
                "request_summary": request.summary,
                "request_details": request.details,
                "risk_level": request.risk_level.value,
                "context": dict(context),
                "tool_catalog": self._tool_catalog(),
            }
        )
        if not isinstance(payload, Mapping):
            raise TypeError("LangChain agent engine must return a mapping payload.")

        return self._build_work_result(request, payload)

    def _tool_catalog(self) -> tuple[dict[str, str], ...]:
        return tuple(
            {
                "name": tool.name,
                "description": getattr(tool, "description", ""),
            }
            for tool in self.tools
        )

    def _build_work_result(
        self,
        request: Request,
        payload: Mapping[str, object],
    ) -> AgentWorkResult:
        analysis_summary = self._require_str(payload, "analysis_summary")
        analysis_rationale = self._require_str(payload, "analysis_rationale")
        proposal_summary = self._require_str(payload, "proposal_summary")
        expected_outcome = self._optional_str(payload, "expected_outcome")
        execution_steps = self._tuple_of_strings(payload.get("execution_steps", ()))
        risk_level = RiskLevel(self._require_str(payload, "risk_level"))
        actions = self._build_actions(request, payload.get("actions", ()))
        observations = self._build_observations(payload.get("observations", ()))

        analysis = AnalysisResult(
            summary=analysis_summary,
            rationale=analysis_rationale,
            execution_steps=execution_steps,
            risk_level=risk_level,
        )
        agent_plan = None
        if actions:
            agent_plan = AgentPlan(
                summary=proposal_summary,
                rationale=analysis_rationale,
                actions=actions,
                expected_outcome=expected_outcome or proposal_summary,
                risk_level=risk_level,
            )
        proposal = Proposal(
            summary=proposal_summary,
            rationale=analysis_rationale,
            execution_steps=execution_steps,
            risk_level=risk_level,
            prepared_by=self.prepared_by,
            agent_plan=agent_plan,
        )
        return AgentWorkResult(
            analysis=analysis,
            proposal=proposal,
            agent_plan=agent_plan,
            observations=observations,
        )

    def _build_actions(
        self,
        request: Request,
        actions_payload: object,
    ) -> tuple[PlannedAction, ...]:
        if not isinstance(actions_payload, Sequence) or isinstance(actions_payload, (str, bytes)):
            raise TypeError("Agent actions must be provided as a sequence.")

        available_tools = {tool.name for tool in self.tools}
        actions: list[PlannedAction] = []
        for index, action_payload in enumerate(actions_payload, start=1):
            if not isinstance(action_payload, Mapping):
                raise TypeError("Each agent action must be a mapping.")

            tool_name = self._require_str(action_payload, "tool_name")
            if available_tools and tool_name not in available_tools:
                raise ValueError(f"Tool '{tool_name}' is not registered in the LangChain adapter.")

            action_id = self._optional_str(action_payload, "action_id") or (
                f"{request.request_id}-action-{index}"
            )
            description = self._require_str(action_payload, "description")
            arguments = action_payload.get("arguments", {})
            if not isinstance(arguments, Mapping):
                raise TypeError("Agent action arguments must be a mapping.")

            actions.append(
                PlannedAction(
                    action_id=action_id,
                    tool_name=tool_name,
                    description=description,
                    arguments=dict(arguments),
                )
            )
        return tuple(actions)

    def _build_observations(self, observations_payload: object) -> tuple[Observation, ...]:
        if not isinstance(observations_payload, Sequence) or isinstance(
            observations_payload,
            (str, bytes),
        ):
            raise TypeError("Agent observations must be provided as a sequence.")

        observations: list[Observation] = []
        for observation_payload in observations_payload:
            if not isinstance(observation_payload, Mapping):
                raise TypeError("Each observation must be a mapping.")
            observations.append(
                Observation(
                    source=self._require_str(observation_payload, "source"),
                    summary=self._require_str(observation_payload, "summary"),
                    details=self._optional_str(observation_payload, "details") or "",
                )
            )

        return tuple(observations)

    @staticmethod
    def _require_str(payload: Mapping[str, object], key: str) -> str:
        value = payload.get(key)
        if not isinstance(value, str) or not value:
            raise ValueError(f"Payload field '{key}' must be a non-empty string.")
        return value

    @staticmethod
    def _optional_str(payload: Mapping[str, object], key: str) -> str | None:
        value = payload.get(key)
        if value is None:
            return None
        if not isinstance(value, str):
            raise TypeError(f"Payload field '{key}' must be a string when provided.")
        return value

    @staticmethod
    def _tuple_of_strings(value: object) -> tuple[str, ...]:
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            raise TypeError("Execution steps must be provided as a sequence.")
        result: list[str] = []
        for item in value:
            if not isinstance(item, str) or not item:
                raise ValueError("Execution steps must contain non-empty strings.")
            result.append(item)
        return tuple(result)
