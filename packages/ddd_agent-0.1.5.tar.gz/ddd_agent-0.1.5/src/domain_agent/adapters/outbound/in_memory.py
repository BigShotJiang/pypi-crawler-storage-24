"""In-memory adapters for development and test scenarios."""

from __future__ import annotations

import datetime as dt
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field

from domain_agent.application.dto import AgentWorkResult, AnalysisResult, ReviewPacket
from domain_agent.application.ports import (
    ActionExecutor,
    AgentEngine,
    ContextProvider,
    RequestRepository,
    Tool,
    ToolRegistry,
)
from domain_agent.domain import (
    ActionReviewDecision,
    AgentPlan,
    PlannedAction,
    PlanReviewResult,
    Proposal,
    Request,
    ReviewDecision,
)


@dataclass
class InMemoryRequestRepository(RequestRepository):
    """Store requests in memory by id."""

    items: dict[str, Request] = field(default_factory=dict)

    def get(self, request_id: str) -> Request | None:
        return self.items.get(request_id)

    def save(self, request: Request) -> None:
        self.items[request.request_id] = request


@dataclass(frozen=True)
class StaticContextProvider(ContextProvider):
    """Return fixed context merged with request metadata."""

    context: Mapping[str, object] = field(default_factory=dict)

    def get_context(self, request: Request) -> dict[str, object]:
        return {
            "request_id": request.request_id,
            **self.context,
        }


@dataclass(frozen=True)
class StaticAgentEngine(AgentEngine):
    """Generate predictable analysis, plan, and proposal data."""

    prepared_by: str = "workflow-agent"
    default_tool_name: str = "approved_action"

    def prepare(
        self,
        request: Request,
        context: Mapping[str, object],
    ) -> AgentWorkResult:
        analysis = AnalysisResult(
            summary=f"Analyze request {request.request_id}",
            rationale=f"Available context keys: {', '.join(sorted(str(key) for key in context))}",
            execution_steps=("collect inputs", "perform approved action"),
            risk_level=request.risk_level,
        )
        agent_plan = AgentPlan(
            summary=f"Plan for {request.request_id}",
            rationale=analysis.rationale,
            actions=(
                PlannedAction(
                    action_id=f"{request.request_id}-action-1",
                    tool_name=self.default_tool_name,
                    description=analysis.execution_steps[0],
                    arguments={"request_id": request.request_id},
                ),
            ),
            expected_outcome=f"Approved actions for {request.request_id} are completed.",
            risk_level=analysis.risk_level,
        )
        proposal = Proposal(
            summary=analysis.summary,
            rationale=analysis.rationale,
            execution_steps=analysis.execution_steps,
            risk_level=analysis.risk_level,
            prepared_by=self.prepared_by,
            agent_plan=agent_plan,
        )
        return AgentWorkResult(
            analysis=analysis,
            proposal=proposal,
            agent_plan=agent_plan,
        )


def build_static_review_handler(
    *,
    approved: bool,
    decided_by: str = "human-reviewer",
    comment: str = "Request rejected during human review.",
) -> Callable[[ReviewPacket], PlanReviewResult]:
    """Return a predictable review handler for tests and demos."""

    def handle_review(review_packet: ReviewPacket) -> PlanReviewResult:
        action_decisions = tuple(
            ActionReviewDecision(
                action_id=planned_action.action_id,
                approved=approved,
                comment="" if approved else comment,
            )
            for planned_action in review_packet.planned_actions
        )
        return PlanReviewResult(
            decision=ReviewDecision(
                approved=approved,
                decided_by=decided_by,
                decided_at=dt.datetime.now(tz=dt.UTC),
                comment="" if approved else comment,
            ),
            action_decisions=action_decisions,
        )

    return handle_review


@dataclass
class RecordingActionExecutor(ActionExecutor):
    """Record execution attempts and return a predictable result."""

    calls: int = 0

    def execute(self, request: Request, agent_plan: AgentPlan | None = None) -> str:
        del agent_plan
        self.calls += 1
        return f"Executed {request.request_id}"


@dataclass(frozen=True)
class InMemoryTool(Tool):
    """A simple in-memory tool implementation for tests and demos."""

    name: str
    result_prefix: str = "Executed"

    def execute(self, request: Request, action: PlannedAction) -> str:
        return f"{self.result_prefix} {action.tool_name} for {request.request_id}"


@dataclass
class InMemoryToolRegistry(ToolRegistry):
    """Store tools in memory by name."""

    tools: dict[str, Tool] = field(default_factory=dict)

    def get(self, tool_name: str) -> Tool:
        try:
            return self.tools[tool_name]
        except KeyError as error:
            raise LookupError(f"Tool '{tool_name}' is not registered.") from error

    def register(self, tool: Tool) -> None:
        self.tools[tool.name] = tool


@dataclass
class ToolDispatchingActionExecutor(ActionExecutor):
    """Execute an agent plan by dispatching each action to a registered tool."""

    tool_registry: ToolRegistry
    executed_actions: list[str] = field(default_factory=list)

    def execute(self, request: Request, agent_plan: AgentPlan | None = None) -> str:
        if agent_plan is None:
            raise ValueError("Tool-dispatching execution requires an agent plan.")

        approved_action_ids = set(request.approved_action_ids())
        results: list[str] = []
        for action in agent_plan.actions:
            if approved_action_ids and action.action_id not in approved_action_ids:
                continue
            tool = self.tool_registry.get(action.tool_name)
            result = tool.execute(request, action)
            self.executed_actions.append(action.tool_name)
            results.append(result)

        return " | ".join(results)
