"""CLI helpers for exporting the generic workflow graph."""

from __future__ import annotations

import argparse
from pathlib import Path

from domain_agent.orchestration.langgraph.export import (
    export_workflow_mermaid,
    write_workflow_mermaid,
)


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI parser for graph export."""
    parser = argparse.ArgumentParser(
        description="Export the agent workflow graph.",
    )
    parser.add_argument(
        "--format",
        choices=("mermaid",),
        default="mermaid",
        help="Output format.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional file path to write the exported graph.",
    )
    return parser


def main() -> int:
    """Run the graph export CLI."""
    parser = build_parser()
    args = parser.parse_args()

    if args.format != "mermaid":
        parser.error(f"Unsupported format: {args.format}")

    if args.output is None:
        print(export_workflow_mermaid())
        return 0

    write_workflow_mermaid(args.output)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
