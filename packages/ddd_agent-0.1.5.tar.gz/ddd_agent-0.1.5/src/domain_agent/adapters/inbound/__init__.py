"""Inbound adapters such as CLI or HTTP entry points."""

from domain_agent.adapters.inbound.cli_demo import main as run_cli_demo
from domain_agent.adapters.inbound.cli_review import CLIReviewCollector

__all__ = ["CLIReviewCollector", "run_cli_demo"]
