"""Ports-and-adapters package for delivery and infrastructure concerns."""

