"""LangGraph orchestration assembly for the generic agent template."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from langgraph.graph import END, START, StateGraph

from domain_agent.application.ports import WorkflowDependencies
from domain_agent.orchestration.langgraph.nodes import (
    DeterministicNodes,
    LLMNodes,
    route_after_review,
)
from domain_agent.orchestration.langgraph.state import WorkflowState


@dataclass(frozen=True)
class WorkflowShape:
    """Feature-level configuration for assembling the workflow graph."""

    include_collect_context: bool = True
    include_execute_action: bool = True


DEFAULT_WORKFLOW_SHAPE = WorkflowShape()


def build_workflow(
    dependencies: WorkflowDependencies,
    *,
    workflow_shape: WorkflowShape = DEFAULT_WORKFLOW_SHAPE,
    checkpointer: Any | None = None,
) -> Any:
    """Build the default agent workflow graph."""
    deterministic_nodes = DeterministicNodes(dependencies)
    llm_nodes = LLMNodes(dependencies)

    graph = StateGraph(WorkflowState)
    graph.add_node("validate_request", deterministic_nodes.validate_request)
    if workflow_shape.include_collect_context:
        graph.add_node("collect_context", deterministic_nodes.collect_context)
    graph.add_node("prepare_agent_work", llm_nodes.prepare_agent_work)
    graph.add_node("resolve_review", deterministic_nodes.resolve_review)
    if workflow_shape.include_execute_action:
        graph.add_node("execute_action", deterministic_nodes.execute_action)
    graph.add_node("close_request", deterministic_nodes.close_request)

    graph.add_edge(START, "validate_request")
    if workflow_shape.include_collect_context:
        graph.add_edge("validate_request", "collect_context")
        graph.add_edge("collect_context", "prepare_agent_work")
    else:
        graph.add_edge("validate_request", "prepare_agent_work")
    graph.add_edge("prepare_agent_work", "resolve_review")
    graph.add_conditional_edges(
        "resolve_review",
        route_after_review
        if workflow_shape.include_execute_action
        else lambda _state: "close_request",
        (
            {
                "execute_action": "execute_action",
                "close_request": "close_request",
            }
            if workflow_shape.include_execute_action
            else {
                "close_request": "close_request",
            }
        ),
    )
    if workflow_shape.include_execute_action:
        graph.add_edge("execute_action", "close_request")
    graph.add_edge("close_request", END)

    return graph.compile(checkpointer=checkpointer)
