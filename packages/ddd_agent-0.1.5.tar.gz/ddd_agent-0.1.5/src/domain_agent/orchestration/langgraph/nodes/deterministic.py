"""Deterministic workflow nodes and routing logic."""

from __future__ import annotations

import datetime as dt

from langgraph.types import interrupt

from domain_agent.application.dto import ReviewPacket, build_review_packet
from domain_agent.application.ports import WorkflowDependencies
from domain_agent.domain import (
    ActionReviewDecision,
    PlanReviewResult,
    RequestStatus,
    ReviewDecision,
)
from domain_agent.orchestration.langgraph.errors import WorkflowValidationError
from domain_agent.orchestration.langgraph.state import WorkflowState


def _append_step(state: WorkflowState, step_name: str) -> tuple[str, ...]:
    return tuple(state.get("completed_steps", ())) + (step_name,)


class DeterministicNodes:
    """Deterministic nodes that do not depend on LLM behavior."""

    def __init__(self, dependencies: WorkflowDependencies) -> None:
        self._dependencies = dependencies

    def validate_request(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        if request.status is not RequestStatus.DRAFT:
            raise WorkflowValidationError("Workflow expects a draft request as input.")
        if request.proposal is not None:
            raise WorkflowValidationError(
                "Workflow input request must not already contain a proposal."
            )
        if request.review_decision is not None:
            raise WorkflowValidationError(
                "Workflow input request must not already contain a review decision."
            )

        request.start_review()
        return {
            "request": request,
            "validation_passed": True,
            "completed_steps": _append_step(state, "validate_request"),
        }

    def collect_context(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        context = self._dependencies.context_provider.get_context(request)
        return {
            "context": context,
            "completed_steps": _append_step(state, "collect_context"),
        }

    def resolve_review(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        proposal = state["proposal"]
        observations = state.get("observations", ())
        review_packet = build_review_packet(request, proposal, observations=observations)

        if self._dependencies.requires_human_review:
            review_result = interrupt(review_packet)
            if not isinstance(review_result, PlanReviewResult):
                raise TypeError("Review interrupt must resume with a PlanReviewResult.")
        else:
            review_result = self._build_auto_review_result(review_packet)

        request.request_review()
        request.record_review_result(review_result)

        return {
            "request": request,
            "review_packet": ReviewPacket(
                request_id=review_packet.request_id,
                requester_id=review_packet.requester_id,
                request_summary=review_packet.request_summary,
                proposal_summary=review_packet.proposal_summary,
                rationale=review_packet.rationale,
                risk_level=review_packet.risk_level,
                execution_steps=review_packet.execution_steps,
                planned_actions=review_packet.planned_actions,
                observations=review_packet.observations,
                action_decisions=review_result.action_decisions,
            ),
            "plan_review_result": review_result,
            "review_decision": review_result.decision,
            "completed_steps": _append_step(state, "resolve_review"),
        }

    def _build_auto_review_result(self, review_packet: ReviewPacket) -> PlanReviewResult:
        action_decisions = tuple(
            ActionReviewDecision(
                action_id=planned_action.action_id,
                approved=True,
                comment="",
            )
            for planned_action in review_packet.planned_actions
        )
        return PlanReviewResult(
            decision=ReviewDecision(
                approved=True,
                decided_by=self._dependencies.auto_reviewer_id,
                decided_at=dt.datetime.now(tz=dt.UTC),
                comment="",
            ),
            action_decisions=action_decisions,
        )

    def execute_action(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        execution_result = self._dependencies.action_executor.execute(
            request,
            state.get("agent_plan"),
        )
        request.execute(execution_result)
        return {
            "request": request,
            "execution_result": execution_result,
            "completed_steps": _append_step(state, "execute_action"),
        }

    def close_request(self, state: WorkflowState) -> WorkflowState:
        request = state["request"]
        return {
            "outcome": request.status.value,
            "closed": True,
            "completed_steps": _append_step(state, "close_request"),
        }


def route_after_review(state: WorkflowState) -> str:
    """Route to execution only when the request has a positive review result."""
    request = state["request"]
    if request.status is RequestStatus.APPROVED:
        return "execute_action"
    return "close_request"
