"""Workflow-specific errors."""


class WorkflowValidationError(ValueError):
    """Raised when a request cannot enter the workflow."""
