"""Typed state for the default agent workflow graph."""

from __future__ import annotations

from typing import TypedDict

from domain_agent.application.dto import AnalysisResult, Observation, ReviewPacket
from domain_agent.domain import AgentPlan, PlanReviewResult, Proposal, Request, ReviewDecision


class WorkflowState(TypedDict, total=False):
    """State carried across the LangGraph workflow."""

    request: Request
    context: dict[str, object]
    analysis: AnalysisResult
    observations: tuple[Observation, ...]
    agent_plan: AgentPlan | None
    proposal: Proposal
    review_packet: ReviewPacket
    plan_review_result: PlanReviewResult
    review_decision: ReviewDecision
    validation_passed: bool
    execution_result: str
    outcome: str
    closed: bool
    completed_steps: tuple[str, ...]


def initial_workflow_state(request: Request) -> WorkflowState:
    """Create the initial state for a workflow run."""
    return {
        "request": request,
        "context": {},
        "validation_passed": False,
        "closed": False,
        "completed_steps": (),
    }
