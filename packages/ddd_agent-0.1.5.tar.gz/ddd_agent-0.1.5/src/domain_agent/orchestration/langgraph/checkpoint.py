"""Checkpoint helpers for LangGraph orchestration."""

from __future__ import annotations

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

_ALLOWED_MSGPACK_TYPES = (
    ("domain_agent.domain.models", "ActionReviewDecision"),
    ("domain_agent.domain.models", "AgentPlan"),
    ("domain_agent.domain.models", "PlannedAction"),
    ("domain_agent.domain.models", "PlanReviewResult"),
    ("domain_agent.domain.models", "Proposal"),
    ("domain_agent.domain.models", "Request"),
    ("domain_agent.domain.models", "RequestStatus"),
    ("domain_agent.domain.models", "ReviewDecision"),
    ("domain_agent.domain.models", "RiskLevel"),
    ("domain_agent.application.dto", "AnalysisResult"),
    ("domain_agent.application.dto", "Observation"),
    ("domain_agent.application.dto", "ReviewPacket"),
)


def build_in_memory_checkpointer() -> InMemorySaver:
    """Create an in-memory checkpointer with registered custom message-pack types."""
    return InMemorySaver(
        serde=JsonPlusSerializer(
            allowed_msgpack_modules=_ALLOWED_MSGPACK_TYPES,
        )
    )
