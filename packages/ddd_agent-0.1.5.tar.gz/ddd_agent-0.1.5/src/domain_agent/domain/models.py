"""Core domain model for a generic agent workflow."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from enum import StrEnum


class DomainError(ValueError):
    """Base error for invalid domain operations."""


class InvalidStatusTransitionError(DomainError):
    """Raised when a request attempts an invalid lifecycle transition."""


class ReviewRequiredError(DomainError):
    """Raised when execution is attempted before a required review outcome."""


class RequestStatus(StrEnum):
    """Lifecycle states for a reviewable request."""

    DRAFT = "draft"
    UNDER_REVIEW = "under_review"
    PROPOSED = "proposed"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXECUTED = "executed"

    def can_transition_to(self, target: RequestStatus) -> bool:
        """Return whether this status can move directly to the target status."""
        allowed_transitions: dict[RequestStatus, set[RequestStatus]] = {
            RequestStatus.DRAFT: {RequestStatus.UNDER_REVIEW},
            RequestStatus.UNDER_REVIEW: {RequestStatus.PROPOSED},
            RequestStatus.PROPOSED: {RequestStatus.AWAITING_APPROVAL},
            RequestStatus.AWAITING_APPROVAL: {
                RequestStatus.APPROVED,
                RequestStatus.REJECTED,
            },
            RequestStatus.APPROVED: {RequestStatus.EXECUTED},
            RequestStatus.REJECTED: set(),
            RequestStatus.EXECUTED: set(),
        }
        return target in allowed_transitions[self]


class RiskLevel(StrEnum):
    """Generic risk classification for a request or proposal."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass(frozen=True)
class PlannedAction:
    """A single tool-backed action planned by the agent."""

    action_id: str
    tool_name: str
    description: str
    arguments: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.action_id.strip():
            raise DomainError("Planned action action_id must not be empty.")
        if not self.tool_name.strip():
            raise DomainError("Planned action tool_name must not be empty.")
        if not self.description.strip():
            raise DomainError("Planned action description must not be empty.")

        object.__setattr__(self, "arguments", dict(self.arguments))


@dataclass(frozen=True)
class AgentPlan:
    """A structured plan of executable actions prepared by the agent."""

    summary: str
    rationale: str
    actions: tuple[PlannedAction, ...]
    expected_outcome: str
    risk_level: RiskLevel

    def __post_init__(self) -> None:
        if not self.summary.strip():
            raise DomainError("Agent plan summary must not be empty.")
        if not self.rationale.strip():
            raise DomainError("Agent plan rationale must not be empty.")
        if not self.expected_outcome.strip():
            raise DomainError("Agent plan expected_outcome must not be empty.")
        if not self.actions:
            raise DomainError("Agent plan must include at least one planned action.")


@dataclass(frozen=True)
class Proposal:
    """A human-reviewable plan prepared before execution."""

    summary: str
    rationale: str
    execution_steps: tuple[str, ...]
    risk_level: RiskLevel
    prepared_by: str
    agent_plan: AgentPlan | None = None

    def __post_init__(self) -> None:
        if not self.summary.strip():
            raise DomainError("Proposal summary must not be empty.")
        if not self.rationale.strip():
            raise DomainError("Proposal rationale must not be empty.")
        if not self.prepared_by.strip():
            raise DomainError("Proposal prepared_by must not be empty.")
        if not self.execution_steps:
            raise DomainError("Proposal must include at least one execution step.")
        if any(not step.strip() for step in self.execution_steps):
            raise DomainError("Proposal execution steps must not be empty.")


@dataclass(frozen=True)
class ReviewDecision:
    """A human decision recorded against a proposed request."""

    approved: bool
    decided_by: str
    decided_at: dt.datetime
    comment: str = ""

    def __post_init__(self) -> None:
        if not self.decided_by.strip():
            raise DomainError("Review decision decided_by must not be empty.")
        if self.decided_at.tzinfo is None:
            raise DomainError("Review decision decided_at must be timezone-aware.")
        if not self.approved and not self.comment.strip():
            raise DomainError("Rejected decisions must include a comment.")


@dataclass(frozen=True)
class ActionReviewDecision:
    """A human decision recorded for a single planned action."""

    action_id: str
    approved: bool
    comment: str = ""

    def __post_init__(self) -> None:
        if not self.action_id.strip():
            raise DomainError("Action review action_id must not be empty.")
        if not self.approved and not self.comment.strip():
            raise DomainError("Rejected action reviews must include a comment.")


@dataclass(frozen=True)
class PlanReviewResult:
    """Structured review outcome for a full plan review."""

    decision: ReviewDecision
    action_decisions: tuple[ActionReviewDecision, ...]

    def __post_init__(self) -> None:
        if not self.action_decisions:
            raise DomainError("Plan review result must include action decisions.")
        approved_actions = tuple(
            action_decision for action_decision in self.action_decisions if action_decision.approved
        )
        if self.decision.approved and not approved_actions:
            raise DomainError("A positive plan review requires at least one approved action.")
        if not self.decision.approved and approved_actions:
            raise DomainError("Rejected plans cannot contain approved actions.")


@dataclass
class Request:
    """Aggregate root for a reviewable request."""

    request_id: str
    requester_id: str
    summary: str
    risk_level: RiskLevel
    details: str = ""
    status: RequestStatus = RequestStatus.DRAFT
    proposal: Proposal | None = None
    review_decision: ReviewDecision | None = None
    action_review_decisions: tuple[ActionReviewDecision, ...] = ()
    execution_notes: str | None = None
    _executed: bool = field(init=False, default=False, repr=False)

    def __post_init__(self) -> None:
        if not self.request_id.strip():
            raise DomainError("Request request_id must not be empty.")
        if not self.requester_id.strip():
            raise DomainError("Request requester_id must not be empty.")
        if not self.summary.strip():
            raise DomainError("Request summary must not be empty.")

        if self.status in {
            RequestStatus.PROPOSED,
            RequestStatus.AWAITING_APPROVAL,
            RequestStatus.APPROVED,
            RequestStatus.REJECTED,
            RequestStatus.EXECUTED,
        } and self.proposal is None:
            raise DomainError(f"Request in status {self.status.value} requires a proposal.")

        if self.status in {
            RequestStatus.APPROVED,
            RequestStatus.REJECTED,
            RequestStatus.EXECUTED,
        } and self.review_decision is None:
            raise DomainError(
                f"Request in status {self.status.value} requires a review decision."
            )

        if self.status is RequestStatus.REJECTED and self.review_decision is not None:
            if self.review_decision.approved:
                raise DomainError("Rejected request cannot carry an approving decision.")

        if (
            self.status in {RequestStatus.APPROVED, RequestStatus.EXECUTED}
            and self.review_decision is not None
        ):
            if not self.review_decision.approved:
                raise DomainError("Approved or executed request requires an approving decision.")

        if self.action_review_decisions:
            if self.proposal is None:
                raise DomainError("Action reviews require a proposal.")
            planned_action_ids = self._expected_action_ids()
            decision_action_ids = {
                action_decision.action_id for action_decision in self.action_review_decisions
            }
            if planned_action_ids != decision_action_ids:
                raise DomainError("Action reviews must cover each planned action exactly once.")
        elif (
            self.status in {RequestStatus.APPROVED, RequestStatus.REJECTED, RequestStatus.EXECUTED}
            and self.proposal is not None
        ):
            raise DomainError("Approved, rejected, or executed requests require action reviews.")

        self._executed = self.status is RequestStatus.EXECUTED

    def start_review(self) -> None:
        """Move a draft request into review."""
        self._transition_to(RequestStatus.UNDER_REVIEW)

    def attach_proposal(self, proposal: Proposal) -> None:
        """Attach a proposal after analysis has completed."""
        if self.status is not RequestStatus.UNDER_REVIEW:
            raise InvalidStatusTransitionError(
                "Proposal can only be attached while the request is under review."
            )
        self.proposal = proposal
        self._transition_to(RequestStatus.PROPOSED)

    def request_review(self) -> None:
        """Expose the prepared proposal for human review."""
        if self.status is not RequestStatus.PROPOSED:
            raise InvalidStatusTransitionError(
                "Review can only be requested after a proposal has been prepared."
            )
        if self.proposal is None:
            raise DomainError("Review cannot be requested without a proposal.")
        self._transition_to(RequestStatus.AWAITING_APPROVAL)

    def record_review_result(self, review_result: PlanReviewResult) -> None:
        """Record the human plan review result and update the request state."""
        if self.status is not RequestStatus.AWAITING_APPROVAL:
            raise InvalidStatusTransitionError(
                "Review decisions can only be recorded while awaiting review."
            )
        if self.proposal is None:
            raise DomainError("Action-level review requires a proposal.")

        planned_action_ids = self._expected_action_ids()
        decision_action_ids = {
            action_decision.action_id for action_decision in review_result.action_decisions
        }
        if planned_action_ids != decision_action_ids:
            raise DomainError("Review result must include a decision for every planned action.")

        self.review_decision = review_result.decision
        self.action_review_decisions = review_result.action_decisions
        target_status = (
            RequestStatus.APPROVED if review_result.decision.approved else RequestStatus.REJECTED
        )
        self._transition_to(target_status)

    def approved_action_ids(self) -> tuple[str, ...]:
        """Return the action ids positively reviewed for execution."""
        return tuple(
            action_decision.action_id
            for action_decision in self.action_review_decisions
            if action_decision.approved
        )

    def _expected_action_ids(self) -> set[str]:
        if self.proposal is None:
            raise DomainError("Expected action ids require a proposal.")
        if self.proposal.agent_plan is None:
            return {"plan-review"}
        return {planned_action.action_id for planned_action in self.proposal.agent_plan.actions}

    def execute(self, execution_notes: str | None = None) -> None:
        """Mark the reviewed request as executed."""
        if self.status is RequestStatus.REJECTED:
            raise ReviewRequiredError("Rejected requests cannot be executed.")
        if self.status is not RequestStatus.APPROVED:
            raise ReviewRequiredError("Review is required before execution.")
        if self.review_decision is None or not self.review_decision.approved:
            raise ReviewRequiredError("A positive review decision is required before execution.")

        self.execution_notes = execution_notes
        self._transition_to(RequestStatus.EXECUTED)
        self._executed = True

    def _transition_to(self, target_status: RequestStatus) -> None:
        if not self.status.can_transition_to(target_status):
            raise InvalidStatusTransitionError(
                f"Cannot transition request from {self.status.value} to {target_status.value}."
            )
        self.status = target_status
