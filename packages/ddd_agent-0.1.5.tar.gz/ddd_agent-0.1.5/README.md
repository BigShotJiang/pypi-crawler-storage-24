# ddd-agent

LangGraph와 LangChain을 적용하기 쉬운 DDD-friendly Python agent 템플릿입니다.

이 저장소는 "LangGraph를 쓰는 샘플"이 아니라, 다음을 분리해서 유지하는 reusable core를 목표로 합니다.

- 도메인 규칙
- application ports와 use cases
- inbound / outbound adapters
- review packet과 review result 같은 사람 개입 모델
- `AgentEngine` 포트를 통한 agent reasoning 결과 생성
- LangGraph orchestration
- LangChain LCEL 기반 `AgentEngine` adapter
- CLI 기반 human review 데모
- 외부 example app

## 핵심 포인트

- 패키지 이름: `ddd-agent`
- import 패키지: `domain_agent`
- Python: `3.11+`
- 패키징: `uv`
- workflow orchestration: `LangGraph`
- 현재 사람 개입 흐름: `optional human review`
- 포함된 CLI:
  - `domain-agent-demo`
  - `domain-agent-graph`

## 빠른 실행

```bash
uv sync
uv run domain-agent-demo
```

workflow graph 확인:

```bash
uv run domain-agent-graph --format mermaid
```

Streamlit GUI:

```bash
cd examples/streamlit_review_demo
uv sync
uv run streamlit run streamlit_review_demo/app.py
```

패키지 빌드:

```bash
uv build
```

PyPI 배포:

- GitHub Release를 `published` 상태로 만들면 `.github/workflows/release.yml`이 실행됩니다.
- workflow는 `uv build` 후 Trusted Publishing으로 `ddd-agent`를 PyPI에 업로드합니다.
- PyPI 쪽 publisher 설정의 project name은 반드시 `ddd-agent`여야 합니다.
- 패키지 버전은 `pyproject.toml`에 고정하지 않고 Git tag에서 계산합니다.
- release tag는 `v0.1.1` 같은 SemVer 형식을 권장합니다.

## 문서

현재 구조를 이해할 때는 아래 문서를 먼저 보는 편이 좋습니다.

- [Overview](docs/index.md)
- [Quickstart](docs/quickstart.md)
- [Usage Recipes](docs/usage-recipes.md)
- [Architecture](docs/architecture.md)
- [Domain Model](docs/domain-model.md)
- [API Reference](docs/api-reference.md)
- [Example Guide](docs/example-guide.md)
- [Package Map](docs/package-map.md)
- [Runtime Flow](docs/runtime-flow.md)
- [Extension Guide](docs/extension-guide.md)

온라인 문서:
- `https://seungbaeji.github.io/domain-agent-template/`

읽기 순서 추천:

1. `src/domain_agent/domain/models.py`
2. `docs/domain-model.md`
3. `src/domain_agent/application/dto.py`
4. `src/domain_agent/application/ports.py`
5. `src/domain_agent/orchestration/langgraph/graph.py`
6. `src/domain_agent/orchestration/langgraph/nodes/deterministic.py`
7. `src/domain_agent/application/use_cases.py`
8. `src/domain_agent/adapters/inbound/cli_demo.py`

새 도메인을 직접 붙여보려면 [Quickstart](docs/quickstart.md)부터 보는 편이 가장 빠릅니다.
LangGraph/LangChain을 어디에 붙여야 하는지 보려면 [Usage Recipes](docs/usage-recipes.md)가 가장 직접적입니다.

## 현재 구조 요약

generic core:
- `src/domain_agent`

example apps:
- `examples/autonomous_digest`
- `examples/langchain_digest`
- `examples/langchain_repo_triage`
- `examples/github_repo_review`
- `examples/operational_change`
- `examples/mock_api`
- `examples/streamlit_review_demo`

현재 human-in-the-loop 메커니즘은 LangGraph interrupt/resume에 위임되어 있습니다.  
기본 workflow는 human review를 켜거나 끌 수 있고, review가 필요한 경우에만 `ReviewPacket`으로 pause합니다. review를 끄면 같은 lifecycle을 자동 review result로 통과합니다.

현재 core workflow는 아래 단계를 가집니다.

- `validate_request`
- `collect_context`
- `prepare_agent_work`
- `resolve_review`
- `execute_action`
- `close_request`

## 도메인 모델

현재 도메인 모델의 중심은 `Request` aggregate입니다.

핵심 타입:

- `Request`
- `RequestStatus`
- `RiskLevel`
- `Proposal`
- `AgentPlan`
- `PlannedAction`
- `ReviewDecision`
- `ActionReviewDecision`
- `PlanReviewResult`

의미:

- `Request`는 lifecycle과 review 결과를 소유하는 aggregate root입니다.
- `Proposal`은 review 대상인 human-readable summary입니다.
- `AgentPlan`은 실행 가능한 action plan입니다.
- `PlanReviewResult`는 plan-level 결과와 action-level 결과를 함께 묶습니다.

주요 invariants:

- `PROPOSED` 이후 상태는 반드시 `Proposal`이 있어야 함
- `APPROVED`, `REJECTED`, `EXECUTED`는 반드시 `ReviewDecision`이 있어야 함
- action review는 planned action 전체를 정확히 덮어야 함
- reject된 request는 실행할 수 없음
- execute는 positive review 이후에만 가능

상세 설명은 [Domain Model](docs/domain-model.md) 문서를 참고하면 됩니다.

## 테스트

generic package:

```bash
uv run pytest -q tests
```

example apps:

```bash
uv run pytest -q examples/autonomous_digest/tests
uv run pytest -q examples/langchain_digest/tests
uv run pytest -q examples/langchain_repo_triage/tests
uv run pytest -q examples/github_repo_review/tests
uv run pytest -q examples/operational_change/tests
uv run pytest -q examples/mock_api/tests
uv run pytest -q examples/streamlit_review_demo/tests
```

## Example Variants

| Example | Human review | Purpose |
| --- | --- | --- |
| `examples/autonomous_digest` | disabled | show the same core in autonomous mode |
| `examples/langchain_digest` | disabled | show a LangChain-backed `AgentEngine` in autonomous mode |
| `examples/langchain_repo_triage` | enabled | show LangChain reasoning plus external API observations |
| `examples/github_repo_review` | enabled | show a real HTTP API-backed review flow |
| `examples/operational_change` | enabled | show a review-heavy operational workflow |
| `examples/mock_api` | enabled | show a reviewable flow with a fake external API |
| `examples/streamlit_review_demo` | optional | visualize the same workflow in a browser UI |

정적 검사:

```bash
uv run ruff check src tests examples/operational_change examples/mock_api
uv run mypy src
```

## 문서 사이트

Python 생태계 쪽 도구를 그대로 쓰기 위해 `MkDocs + mkdocstrings` 구성을 추가했습니다.

설치:

```bash
make docs-sync
```

실행:

```bash
make docs
```

Streamlit demo 의존성:

```bash
cd examples/streamlit_review_demo
uv sync
```

정적 빌드:

```bash
make docs-build
```

설정 파일:
- `mkdocs.yml`

## 배포 자동화

PyPI 배포 workflow:
- `.github/workflows/release.yml`

문서 배포 workflow:
- `.github/workflows/docs.yml`

동작 방식:

1. `v0.1.1` 같은 Git tag로 Release publish
2. `actions/checkout`이 전체 tag history를 fetch
3. `.python-version` 기준 Python setup 후 `uv build`
4. `hatch-vcs`가 Git tag에서 package version을 계산
5. `pypa/gh-action-pypi-publish`로 PyPI 업로드

문서 배포 방식:

1. `main` push
2. `.python-version` 기준 Python setup
3. `uv run --group docs mkdocs build --strict`
4. GitHub Pages 배포

전제 조건:

- PyPI Trusted Publisher 등록
- project name: `ddd-agent`
- repository: `seungbaeji/domain-agent-template`
- workflow filename: `release.yml`
- release tag convention: `v<semver>` 예: `v0.1.1`

## Versioning Policy

이 저장소는 package version을 `pyproject.toml`에 수동으로 고정하지 않습니다.

원칙:

- 버전은 Git tag에서 계산
- release tag는 `v<semver>` 형식 사용
- 예:
  - `v0.1.1`
  - `v0.2.0`
  - `v1.0.0`

의미:

- `main`에서 평소 개발 중인 빌드는 dev version으로 계산될 수 있음
- GitHub Release를 publish할 때만 PyPI에 release version이 업로드됨
- release workflow는 default branch HEAD가 아니라 release에 연결된 Git tag ref를 checkout해서 빌드함

## Release Process

권장 release 절차는 아래와 같습니다.

1. 변경 사항을 PR로 `main`에 merge
2. 로컬 `main`을 최신으로 업데이트
3. release 대상 커밋에 `v<semver>` tag 생성
4. 해당 tag로 GitHub Release publish
5. release workflow가 PyPI에 package 업로드
6. 문서는 별도로 `main` push 기준으로 GitHub Pages에 반영

즉:

- `main` merge -> docs 배포
- `release publish` -> PyPI 배포

release workflow는 다음을 보장합니다.

- release에 연결된 tag ref를 checkout해서 build
- build 결과의 artifact version이 release tag와 일치하는지 검증
- tag와 build version이 다르면 배포를 실패시켜 잘못된 dev/post release 업로드를 막음

예시:

```bash
git switch main
git pull --ff-only origin main
git tag v0.1.1
git push origin v0.1.1
```

그 다음 GitHub에서 `v0.1.1` release를 publish하면 됩니다.
