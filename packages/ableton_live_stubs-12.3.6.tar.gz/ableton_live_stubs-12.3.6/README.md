# ableton-live-stubs

PEP 561 type stubs for Ableton Live 12.3.6's Python API.

## Installation

```
pip install ableton-live-stubs==12.3.6
```

## Usage

Once installed, type checkers (pyright, mypy) automatically discover the `Live` module stubs.
No configuration needed.

```python
from Live.Application import Application
from Live.Song import Song
```

## Manual setup (without pip)

Download the zip from the
[GitHub release](https://github.com/PhotonicVelocity/LiveAPI/releases/tag/v12.3.6)
and add the extracted `Live/` directory to your type checker's search path:

```json
// pyrightconfig.json
{
  "extraPaths": ["path/to/Live-stubs"]
}
```

## Source

Generated from runtime introspection of Ableton Live 12.3.6.
See [LiveAPI](https://github.com/PhotonicVelocity/LiveAPI) for details.
