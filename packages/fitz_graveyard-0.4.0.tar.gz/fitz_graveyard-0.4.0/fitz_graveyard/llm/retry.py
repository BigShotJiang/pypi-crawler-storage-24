# fitz_graveyard/llm/retry.py
"""Retry logic for Ollama API calls with exponential backoff."""

import logging

from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)


def is_retryable(exception: BaseException) -> bool:
    """
    Returns True if the exception should be retried.

    Retryable conditions:
    - ConnectionError (server unavailable)
    - ResponseError with status in (408, 429, 500, 502, 503, 504)
      BUT NOT status 500 with "requires more system memory" (that's OOM, handled by fallback)
    """
    if isinstance(exception, ConnectionError):
        return True

    try:
        from ollama import ResponseError
    except ImportError:
        return False

    if isinstance(exception, ResponseError):
        status = exception.status_code
        # Retryable HTTP status codes (transient errors)
        retryable_statuses = {408, 429, 500, 502, 503, 504}

        if status not in retryable_statuses:
            return False

        # Special case: 500 with OOM message should NOT be retried (fallback handles it)
        if status == 500:
            error_msg = str(exception).lower()
            if "requires more system memory" in error_msg:
                return False

        return True

    return False


# Tenacity retry decorator for Ollama API calls
ollama_retry = retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=60),
    retry=retry_if_exception(is_retryable),
    before_sleep=before_sleep_log(logger, logging.WARNING),
)


def is_lm_studio_retryable(exception: BaseException) -> bool:
    """
    Returns True if the LM Studio exception should be retried.

    Retryable conditions:
    - ConnectionError (server unavailable)
    - httpx transport errors (connection refused, timeout)
    - openai APIConnectionError / APITimeoutError (model loading, server restart)
    """
    if isinstance(exception, ConnectionError):
        return True

    # httpx transport-level errors
    try:
        import httpx
        if isinstance(exception, (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout)):
            return True
    except ImportError:
        pass

    # openai SDK errors
    try:
        from openai import APIConnectionError, APITimeoutError, APIStatusError
        if isinstance(exception, (APIConnectionError, APITimeoutError)):
            return True
        if isinstance(exception, APIStatusError):
            return exception.status_code in {408, 429, 502, 503, 504}
    except ImportError:
        pass

    return False


# Tenacity retry decorator for LM Studio API calls
lm_studio_retry = retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=5, max=60),
    retry=retry_if_exception(is_lm_studio_retryable),
    before_sleep=before_sleep_log(logger, logging.WARNING),
)


def is_llama_cpp_retryable(exception: BaseException) -> bool:
    """
    Returns True if the llama.cpp exception should be retried.

    Same as LM Studio retryable conditions, plus 503 (model loading/swapping)
    and RuntimeError from server crashes (auto-restart may have failed).
    """
    # Reuse LM Studio logic for shared error types
    if is_lm_studio_retryable(exception):
        return True

    # Additionally handle 500 from llama-server during model loading
    try:
        from openai import APIStatusError
        if isinstance(exception, APIStatusError) and exception.status_code == 500:
            return True
    except ImportError:
        pass

    # Server crash/restart failures
    if isinstance(exception, RuntimeError):
        msg = str(exception).lower()
        if "llama-server" in msg or "crashed" in msg or "exited" in msg:
            return True

    return False


# Tenacity retry decorator for llama.cpp API calls
# More attempts + shorter waits to handle model swap latency
llama_cpp_retry = retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=2, max=30),
    retry=retry_if_exception(is_llama_cpp_retryable),
    before_sleep=before_sleep_log(logger, logging.WARNING),
)
