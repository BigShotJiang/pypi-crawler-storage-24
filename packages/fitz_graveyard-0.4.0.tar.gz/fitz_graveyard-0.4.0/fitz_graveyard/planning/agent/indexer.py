# fitz_graveyard/planning/agent/indexer.py
"""
Structural index builder for codebase context gathering.

Extracts structural information (classes, functions, imports) from source
files using language-appropriate methods:
  - Python: ast module (classes with bases, functions with signatures, imports)
  - Config (YAML/JSON/TOML): safe parsers for top-level keys
  - Markdown/RST: regex heading extraction
  - Generic code (JS/TS/Go/Rust/Java/C/C++/Ruby): regex patterns
  - Fallback: no structural info line

The index gives the LLM architectural visibility into the entire codebase
without reading full file contents, breaking the circular retrieval problem.
"""

import ast
import json
import logging
import re
from pathlib import Path, PurePosixPath
from typing import Any

logger = logging.getLogger(__name__)

# Maximum total index size in characters before truncation.
# At ~4 chars/token this is ~30K tokens — fits comfortably in 32K+ context
# windows while leaving room for the rest of the prompt.
_MAX_INDEX_CHARS = 120_000

# Extension → extractor mapping.
# INDEXABLE_EXTENSIONS is the union — used by the tree walker to skip files
# that the indexer can't extract anything useful from.
_PYTHON_EXTS = {".py"}
_CONFIG_EXTS = {".yaml", ".yml", ".json", ".toml"}
_MARKDOWN_EXTS = {".md", ".rst"}
_GENERIC_CODE_EXTS = {
    ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    ".go",
    ".rs",
    ".java", ".kt", ".scala",
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cxx",
    ".rb",
    ".cs",
    ".swift",
    ".php",
    ".lua",
    ".zig",
    ".ex", ".exs",
    ".erl", ".hrl",
    ".hs",
    ".ml", ".mli",
    ".sh", ".bash", ".zsh",
}

# All extensions the indexer can extract structure from.
# Files without these extensions are invisible to the agent.
INDEXABLE_EXTENSIONS = _PYTHON_EXTS | _CONFIG_EXTS | _MARKDOWN_EXTS | _GENERIC_CODE_EXTS

# Decorators worth showing in the structural index (architectural cues).
_KEY_DECORATORS = frozenset({
    "dataclass", "abstractmethod", "property", "staticmethod",
    "classmethod", "override",
})


def build_structural_index(
    source_dir: str,
    file_list: list[str],
    max_file_bytes: int = 50_000,
    connection_counts: dict[str, int] | None = None,
) -> str:
    """
    Build a compact structural index of all files in the codebase.

    Args:
        source_dir: Absolute path to source directory root.
        file_list: List of relative file paths (posix-style) to index.
        max_file_bytes: Maximum bytes to read per file.
        connection_counts: Optional mapping of file path to import
            connection count. Used to prioritize truncation — files
            with fewer connections lose detail first.

    Returns:
        Multi-line text index with structural info per file.
    """
    root = Path(source_dir).resolve()
    entries: list[tuple[str, str]] = []  # (rel_path, index_text)

    for rel_path in file_list:
        full_path = root / rel_path
        if not full_path.is_file():
            continue

        try:
            raw = full_path.read_bytes()[:max_file_bytes]
            content = raw.decode("utf-8", errors="replace")
        except OSError:
            continue

        if not content.strip():
            continue

        suffix = PurePosixPath(rel_path).suffix.lower()
        info = _extract_structure(suffix, content, rel_path)
        if info:
            entries.append((rel_path, info))
        else:
            entries.append((rel_path, "(no structural info)"))

    # Format and apply size budget
    return _format_index(entries, connection_counts)


def _extract_structure(suffix: str, content: str, rel_path: str) -> str:
    """Dispatch to the appropriate extractor based on file extension."""
    if suffix in _PYTHON_EXTS:
        return _extract_python(content)
    if suffix in _CONFIG_EXTS:
        return _extract_config(suffix, content)
    if suffix in _MARKDOWN_EXTS:
        return _extract_markdown(content)
    if suffix in _GENERIC_CODE_EXTS:
        return _extract_generic_code(content)
    return ""


def _extract_python(content: str) -> str:
    """Extract structure from Python files using AST.

    Falls back to regex if AST parsing fails (syntax errors).
    """
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return _extract_python_regex(content)

    lines: list[str] = []

    # Module docstring (first line only)
    module_doc = ast.get_docstring(tree)
    if module_doc:
        first_line = module_doc.strip().splitlines()[0]
        lines.append(f'doc: "{first_line}"')

    # Classes with bases, decorators, and method names + return types
    classes = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            bases = []
            for base in node.bases:
                bases.append(_ast_name(base))
            methods = []
            for n in ast.iter_child_nodes(node):
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    m_str = n.name
                    if n.returns:
                        try:
                            ret = ast.unparse(n.returns)
                        except Exception:
                            ret = _ast_name(n.returns)
                        m_str += f" -> {ret}"
                    methods.append(m_str)
            cls_str = node.name
            if bases:
                cls_str += f"({', '.join(bases)})"
            decs = _extract_key_decorators(node.decorator_list)
            if decs:
                cls_str += f" [{', '.join(f'@{d}' for d in decs)}]"
            if methods:
                cls_str += f" [{', '.join(methods)}]"
            classes.append(cls_str)
    if classes:
        lines.append(f"classes: {'; '.join(classes)}")

    # Top-level functions with parameter names, return types, decorators
    functions = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            params = [arg.arg for arg in node.args.args if arg.arg != "self"]
            func_str = f"{node.name}({', '.join(params)})"
            if node.returns:
                try:
                    ret = ast.unparse(node.returns)
                except Exception:
                    ret = _ast_name(node.returns)
                func_str += f" -> {ret}"
            decs = _extract_key_decorators(node.decorator_list)
            if decs:
                func_str += f" [{', '.join(f'@{d}' for d in decs)}]"
            functions.append(func_str)
    if functions:
        lines.append(f"functions: {', '.join(functions)}")

    # Imports — walk full tree to catch TYPE_CHECKING and conditional imports.
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                if "." in node.module:
                    imports.add(node.module)
                else:
                    imports.add(node.module)
    if imports:
        lines.append(f"imports: {', '.join(sorted(imports))}")

    # __all__ exports
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, (ast.List, ast.Tuple)):
                        names = [
                            elt.value for elt in node.value.elts
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                        ]
                        if names:
                            lines.append(f"exports: {', '.join(names)}")

    return "\n".join(lines)


def _ast_name(node: ast.expr) -> str:
    """Get a human-readable name from an AST node."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        value = _ast_name(node.value)
        return f"{value}.{node.attr}" if value else node.attr
    if isinstance(node, ast.Subscript):
        return _ast_name(node.value)
    return "?"


def _extract_key_decorators(decorator_list: list[ast.expr]) -> list[str]:
    """Extract recognized decorator names from an AST decorator list."""
    result = []
    for dec in decorator_list:
        name = None
        if isinstance(dec, ast.Name):
            name = dec.id
        elif isinstance(dec, ast.Attribute):
            name = dec.attr
        elif isinstance(dec, ast.Call):
            func = dec.func
            if isinstance(func, ast.Name):
                name = func.id
            elif isinstance(func, ast.Attribute):
                name = func.attr
        if name and name in _KEY_DECORATORS:
            result.append(name)
    return result


def _extract_python_regex(content: str) -> str:
    """Fallback Python extraction using regex when AST fails."""
    lines: list[str] = []

    classes = re.findall(r'^class\s+(\w+)(?:\(([^)]*)\))?:', content, re.MULTILINE)
    if classes:
        cls_strs = []
        for name, bases in classes:
            cls_strs.append(f"{name}({bases})" if bases else name)
        lines.append(f"classes: {'; '.join(cls_strs)}")

    functions = re.findall(r'^(?:async\s+)?def\s+(\w+)\(([^)]*)\)', content, re.MULTILINE)
    if functions:
        func_strs = [f"{name}({params})" for name, params in functions]
        lines.append(f"functions: {', '.join(func_strs)}")

    imports = set()
    for m in re.finditer(r'^(?:from\s+(\S+)\s+)?import\s+(\S+)', content, re.MULTILINE):
        mod = m.group(1) or m.group(2)
        imports.add(mod.split(".")[0])
    if imports:
        lines.append(f"imports: {', '.join(sorted(imports))}")

    return "\n".join(lines)


def _extract_config(suffix: str, content: str) -> str:
    """Extract top-level keys from config files."""
    try:
        if suffix in (".yaml", ".yml"):
            # Only import yaml if needed — it's optional
            import yaml
            data = yaml.safe_load(content)
        elif suffix == ".json":
            data = json.loads(content)
        elif suffix == ".toml":
            import tomllib
            data = tomllib.loads(content)
        else:
            return ""
    except Exception:
        return ""

    if isinstance(data, dict):
        keys = list(data.keys())[:20]  # Cap at 20 keys
        return f"keys: {', '.join(str(k) for k in keys)}"
    return ""


def _extract_markdown(content: str) -> str:
    """Extract headings from markdown/RST files."""
    # Markdown headings
    headings = re.findall(r'^(#{1,3})\s+(.+)', content, re.MULTILINE)
    if headings:
        items = [f"{'#' * len(h[0])} {h[1].strip()}" for h in headings[:15]]
        return f"headings: {'; '.join(items)}"

    # RST headings (line of = or - under text)
    rst_headings = re.findall(r'^(.+)\n[=\-~^]+$', content, re.MULTILINE)
    if rst_headings:
        items = [h.strip() for h in rst_headings[:15]]
        return f"headings: {'; '.join(items)}"

    return ""


def _extract_generic_code(content: str) -> str:
    """Extract structure from non-Python code using regex patterns.

    Covers: JS/TS, Go, Rust, Java/Kotlin, C/C++, Ruby, C#, Swift, PHP, etc.
    """
    lines: list[str] = []

    # Classes / structs / interfaces / traits / enums
    type_defs = re.findall(
        r'^(?:export\s+)?(?:pub\s+)?(?:public\s+|private\s+|protected\s+|abstract\s+|sealed\s+)?'
        r'(?:class|struct|interface|trait|enum|type)\s+'
        r'(\w+)',
        content, re.MULTILINE,
    )
    if type_defs:
        lines.append(f"types: {', '.join(dict.fromkeys(type_defs))}")

    # Functions / methods (various languages)
    func_patterns = [
        # Go: func Name(
        r'^func\s+(?:\([^)]*\)\s+)?(\w+)\s*\(',
        # Rust: fn name(  / pub fn name(
        r'^(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*[<(]',
        # JS/TS: function name( / export function name(
        r'^(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*[<(]',
        # JS/TS: const name = (...) => / const name = function
        r'^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)\s*=>|function)',
        # Java/C#/Kotlin: public void name( / fun name(
        r'^\s+(?:public|private|protected|static|override|virtual|abstract|final|\s)*'
        r'(?:fun|void|int|string|bool|float|double|var|val|Task|async)\s+(\w+)\s*[<(]',
        # Ruby: def name
        r'^(?:\s+)?def\s+(\w+)',
        # C/C++: type name( at start of line (heuristic)
        r'^(?:static\s+)?(?:inline\s+)?(?:const\s+)?\w[\w:*&<> ]*\s+(\w+)\s*\([^;]*$',
    ]
    functions: list[str] = []
    for pat in func_patterns:
        for m in re.finditer(pat, content, re.MULTILINE):
            name = m.group(1)
            if name not in functions and name not in ("if", "for", "while", "switch", "return", "main"):
                functions.append(name)
    if functions:
        lines.append(f"functions: {', '.join(functions[:20])}")

    # Imports / requires / use statements
    imports: set[str] = set()
    import_patterns = [
        r'^import\s+["\']([^"\']+)["\']',           # JS/TS import "x"
        r'^import\s+.*\s+from\s+["\']([^"\']+)["\']', # JS/TS import x from "y"
        r'^(?:const|let|var)\s+.*=\s*require\(["\']([^"\']+)["\']\)',  # Node require
        r'^import\s+"([^"]+)"',                       # Go import
        r'^use\s+([\w:]+)',                            # Rust use
        r'^import\s+([\w.]+)',                         # Java/Kotlin
        r'^using\s+([\w.]+)',                          # C#
        r'^require\s+["\']([^"\']+)["\']',             # Ruby
        r'^#include\s+[<"]([^>"]+)[>"]',               # C/C++
    ]
    for pat in import_patterns:
        for m in re.finditer(pat, content, re.MULTILINE):
            mod = m.group(1).split("/")[0].split("::")[0].split(".")[0]
            if mod:
                imports.add(mod)
    if imports:
        lines.append(f"imports: {', '.join(sorted(imports))}")

    return "\n".join(lines)


def _format_index(
    entries: list[tuple[str, str]],
    connection_counts: dict[str, int] | None = None,
) -> str:
    """Format entries into the final index text, truncating if over budget.

    Strategy: never drop files entirely.  If over budget, progressively
    reduce detail — first strip imports, then strip function lists — from
    the *least connected* files first.  Files with more import connections
    are architecturally central and keep their structural info.
    Falls back to depth-based ordering when connection data is unavailable.
    """
    parts: list[str] = []
    for rel_path, info in entries:
        parts.append(f"## {rel_path}\n{info}")

    full = "\n\n".join(parts)

    if len(full) <= _MAX_INDEX_CHARS:
        return full

    # Over budget — strip detail from least-connected files first.
    # Files with more imports to/from other files are architecturally
    # central and should keep their structural info.
    mutable = list(entries)  # preserve original order for output
    conns = connection_counts or {}
    by_priority = sorted(
        range(len(mutable)),
        key=lambda i: conns.get(mutable[i][0], 0),
    )

    # Pass 1: strip imports lines from least-connected files first
    for idx in by_priority:
        rel_path, info = mutable[idx]
        lines = [ln for ln in info.splitlines() if not ln.startswith("imports:")]
        mutable[idx] = (rel_path, "\n".join(lines))
        if _estimate_size(mutable) <= _MAX_INDEX_CHARS:
            break

    # Pass 2: strip functions lines from least-connected files first
    if _estimate_size(mutable) > _MAX_INDEX_CHARS:
        for idx in by_priority:
            rel_path, info = mutable[idx]
            lines = [ln for ln in info.splitlines() if not ln.startswith("functions:")]
            mutable[idx] = (rel_path, "\n".join(lines))
            if _estimate_size(mutable) <= _MAX_INDEX_CHARS:
                break

    # Pass 3: last resort — reduce to path-only for least-connected files
    if _estimate_size(mutable) > _MAX_INDEX_CHARS:
        for idx in by_priority:
            mutable[idx] = (mutable[idx][0], "")
            if _estimate_size(mutable) <= _MAX_INDEX_CHARS:
                break

    result_parts = []
    for rel_path, info in mutable:
        if info.strip():
            result_parts.append(f"## {rel_path}\n{info}")
        else:
            result_parts.append(f"## {rel_path}")

    return "\n\n".join(result_parts)


def _estimate_size(entries: list[tuple[str, str]]) -> int:
    """Estimate formatted index size without building the full string."""
    total = 0
    for rel_path, info in entries:
        total += 3 + len(rel_path) + 1 + len(info) + 2  # "## " + path + "\n" + info + "\n\n"
    return total


# ---------------------------------------------------------------------------
# Full import graph (for reverse-import caller expansion)
# ---------------------------------------------------------------------------


def _extract_full_imports(content: str) -> set[str]:
    """Extract full dotted import paths from Python source (AST, regex fallback)."""
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return _extract_full_imports_regex(content)

    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module)
    return imports


def _extract_full_imports_regex(content: str) -> set[str]:
    """Regex fallback for full import paths.

    Unlike the structural index regex (top-level only), this matches
    indented imports too — critical for lazy imports inside functions.
    """
    imports: set[str] = set()
    for m in re.finditer(r'^\s*from\s+(\S+)\s+import', content, re.MULTILINE):
        imports.add(m.group(1))
    for m in re.finditer(r'^\s*import\s+(\S+)', content, re.MULTILINE):
        imports.add(m.group(1).split(",")[0].strip())
    return imports


def _build_module_file_lookup(file_list: list[str]) -> dict[str, str]:
    """Build module_dotted_path -> relative_file_path lookup.

    E.g.: "fitz_ai.governance.governor" -> "fitz_ai/governance/governor.py"
    Also maps package inits: "fitz_ai.governance" -> "fitz_ai/governance/__init__.py"
    """
    lookup: dict[str, str] = {}
    for rel_path in file_list:
        if not rel_path.endswith(".py"):
            continue
        module = rel_path[:-3].replace("/", ".")
        if module.endswith(".__init__"):
            lookup[module] = rel_path
            lookup[module[:-9]] = rel_path  # strip ".__init__"
        else:
            lookup[module] = rel_path
    return lookup


def build_import_graph(
    source_dir: str,
    file_list: list[str],
    max_file_bytes: int = 50_000,
) -> tuple[dict[str, set[str]], dict[str, str]]:
    """Build forward import map and module lookup.

    Returns:
        (forward_map, module_lookup) where:
        - forward_map: {file_path: {resolved_file_path, ...}} — only intra-project imports
        - module_lookup: {dotted.module: file_path}
    """
    root = Path(source_dir).resolve()
    module_lookup = _build_module_file_lookup(file_list)
    forward: dict[str, set[str]] = {}

    for rel_path in file_list:
        if not rel_path.endswith(".py"):
            continue
        full_path = root / rel_path
        if not full_path.is_file():
            continue
        try:
            raw = full_path.read_bytes()[:max_file_bytes]
            content = raw.decode("utf-8", errors="replace")
        except OSError:
            continue

        full_imports = _extract_full_imports(content)
        resolved = set()
        for imp in full_imports:
            target = module_lookup.get(imp)
            if target and target != rel_path:
                resolved.add(target)

        if resolved:
            forward[rel_path] = resolved

    return forward, module_lookup


# ---------------------------------------------------------------------------
# Interface signature extraction (compact cheat sheet for planning context)
# ---------------------------------------------------------------------------

_MAX_SIGNATURES_CHARS = 8000


def _format_annotation(node: ast.expr | None) -> str:
    """Format a type annotation AST node to readable string."""
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return "?"


def _format_param(arg: ast.arg) -> str:
    """Format a function parameter with optional type annotation."""
    ann = _format_annotation(arg.annotation)
    if ann:
        return f"{arg.arg}: {ann}"
    return arg.arg


def _extract_signatures_from_python(content: str) -> str:
    """Extract class/function signatures with type annotations from Python source.

    Produces a compact representation showing:
    - Classes with base classes and method signatures (params + return types)
    - Top-level functions with params + return types
    """
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return ""

    lines: list[str] = []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            bases = [_ast_name(b) for b in node.bases]
            base_str = f"({', '.join(bases)})" if bases else ""
            lines.append(f"class {node.name}{base_str}:")

            for child in ast.iter_child_nodes(node):
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    params = [
                        _format_param(a)
                        for a in child.args.args
                        if a.arg != "self"
                    ]
                    ret = _format_annotation(child.returns)
                    ret_str = f" -> {ret}" if ret else ""
                    async_prefix = "async " if isinstance(child, ast.AsyncFunctionDef) else ""
                    lines.append(f"  {async_prefix}{child.name}({', '.join(params)}){ret_str}")

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            params = [
                _format_param(a)
                for a in node.args.args
                if a.arg != "self"
            ]
            ret = _format_annotation(node.returns)
            ret_str = f" -> {ret}" if ret else ""
            async_prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
            lines.append(f"{async_prefix}{node.name}({', '.join(params)}){ret_str}")

    return "\n".join(lines)


def extract_interface_signatures(
    source_dir: str,
    file_paths: list[str],
    max_file_bytes: int = 50_000,
) -> str:
    """Extract compact interface signatures from Python files for planning context.

    Produces a cheat sheet of class hierarchies, method signatures, and return
    types that the LLM can reference without reading full source. Placed at the
    top of the planning context so it's never truncated.

    Args:
        source_dir: Absolute path to source directory root.
        file_paths: Relative posix-style paths to extract from.
        max_file_bytes: Maximum bytes to read per file.

    Returns:
        Formatted signature block, or empty string if no signatures found.
    """
    root = Path(source_dir).resolve()
    blocks: list[str] = []
    used = 0

    for rel_path in file_paths:
        if not rel_path.endswith(".py"):
            continue

        full_path = root / rel_path
        if not full_path.is_file():
            continue

        try:
            raw = full_path.read_bytes()[:max_file_bytes]
            content = raw.decode("utf-8", errors="replace")
        except OSError:
            continue

        sigs = _extract_signatures_from_python(content)
        if not sigs:
            continue

        block = f"## {rel_path}\n{sigs}"
        if used + len(block) > _MAX_SIGNATURES_CHARS:
            break

        blocks.append(block)
        used += len(block)

    return "\n\n".join(blocks)


_MAX_LIBRARY_CHARS = 4000
_MAX_LIBRARY_PACKAGES = 10


def extract_library_signatures(
    source_dir: str,
    included_files: list[str],
    file_list: list[str],
    max_file_bytes: int = 50_000,
) -> str:
    """Extract public API signatures from third-party packages used by included files.

    Collects imports from included files, filters out intra-project imports,
    then uses importlib + inspect to extract class/method signatures from
    installed packages. Gives the LLM ground truth for library APIs so it
    doesn't hallucinate non-existent methods like ``ContextVar.update()``.

    Args:
        source_dir: Absolute path to source directory root.
        included_files: Files included in the planning context.
        file_list: All file paths in the codebase (for intra-project filtering).
        max_file_bytes: Maximum bytes to read per file.

    Returns:
        Formatted library reference block, or empty string if nothing found.
    """
    import importlib
    import inspect

    root = Path(source_dir).resolve()
    module_lookup = _build_module_file_lookup(file_list)

    # Collect all imports from included files
    all_imports: set[str] = set()
    for rel_path in included_files:
        if not rel_path.endswith(".py"):
            continue
        full_path = root / rel_path
        if not full_path.is_file():
            continue
        try:
            raw = full_path.read_bytes()[:max_file_bytes]
            content = raw.decode("utf-8", errors="replace")
        except OSError:
            continue
        all_imports.update(_extract_full_imports(content))

    # Filter out intra-project imports
    third_party: set[str] = set()
    for imp in all_imports:
        top_level = imp.split(".")[0]
        if top_level in module_lookup or imp in module_lookup:
            continue
        # Skip stdlib modules we can't usefully introspect
        if top_level in {"__future__", "typing", "typing_extensions", "collections"}:
            continue
        third_party.add(top_level)

    if not third_party:
        return ""

    blocks: list[str] = []
    used = 0

    for pkg_name in sorted(third_party)[:_MAX_LIBRARY_PACKAGES]:
        try:
            mod = importlib.import_module(pkg_name)
        except Exception:
            continue

        lines: list[str] = []
        try:
            members = inspect.getmembers(mod)
        except Exception:
            members = [(name, getattr(mod, name, None)) for name in dir(mod)]

        for name, obj in members:
            if name.startswith("_"):
                continue
            try:
                if inspect.isclass(obj):
                    methods = _extract_class_public_methods(obj)
                    if methods:
                        lines.append(f"class {name}: {', '.join(methods)}")
                    else:
                        lines.append(f"class {name}")
                elif inspect.isfunction(obj) or inspect.isbuiltin(obj):
                    sig = _safe_signature(obj)
                    lines.append(f"{name}{sig}")
            except Exception:
                continue

        if not lines:
            continue

        block = f"## {pkg_name}\n" + "\n".join(lines[:20])  # Cap lines per package
        if used + len(block) > _MAX_LIBRARY_CHARS:
            break

        blocks.append(block)
        used += len(block)

    if not blocks:
        return ""

    logger.info(
        f"Library signatures: extracted {len(blocks)} packages ({used} chars)"
    )
    return "\n\n".join(blocks)


def _extract_class_public_methods(cls: type) -> list[str]:
    """Extract public method names + signatures from a class."""
    import inspect

    methods: list[str] = []
    for name in sorted(dir(cls)):
        if name.startswith("_"):
            continue
        try:
            attr = getattr(cls, name)
        except Exception:
            continue
        if callable(attr) or isinstance(attr, property):
            sig = _safe_signature(attr) if callable(attr) else " (property)"
            methods.append(f"{name}{sig}")
    return methods[:15]  # Cap methods per class


def _safe_signature(obj: object) -> str:
    """Get inspect.signature() as string, or empty on failure."""
    import inspect

    try:
        sig = inspect.signature(obj)
        return str(sig)
    except (ValueError, TypeError):
        return "()"


# ---------------------------------------------------------------------------
# Investigation question generation (customized from AST data)
# ---------------------------------------------------------------------------

_MAX_CUSTOM_QUESTIONS = 3


def generate_investigation_questions(
    signatures: str,
    forward_map: dict[str, set[str]],
    reverse_count: dict[str, int],
) -> list[str]:
    """Generate codebase-specific investigation questions from structural data.

    Analyzes interface signatures and import graph to produce targeted
    questions that guide the LLM toward architectural insights it would
    otherwise miss.

    Args:
        signatures: Output of extract_interface_signatures().
        forward_map: {file: {imported_files}} from build_import_graph().
        reverse_count: {file: number_of_importers} from import graph.

    Returns:
        List of 0-3 customized question strings.
    """
    questions: list[str] = []

    # Parse signatures to find class hierarchies and method signatures
    hierarchies = _parse_class_hierarchies(signatures)
    methods_with_simple_returns = _parse_simple_return_methods(signatures)

    # 1. Class hierarchy: base class with ≥2 implementations
    for base, impls in hierarchies.items():
        if len(impls) >= 2 and len(questions) < _MAX_CUSTOM_QUESTIONS:
            impl_list = ", ".join(impls[:5])
            questions.append(
                f"Class '{base}' has {len(impls)} implementations: {impl_list}. "
                f"For each implementation, what does its key method actually do internally? "
                f"Do all implementations handle data the same way, or do some discard "
                f"information that others preserve? What data is available inside each "
                f"implementation that is NOT available to outside callers?"
            )

    # 2. Hub file: imported by many files (architecturally central)
    hub_threshold = 5
    hubs = sorted(
        ((f, c) for f, c in reverse_count.items() if c >= hub_threshold),
        key=lambda x: x[1],
        reverse=True,
    )
    for hub_file, count in hubs[:1]:  # Only ask about the top hub
        if len(questions) < _MAX_CUSTOM_QUESTIONS:
            questions.append(
                f"File '{hub_file}' is imported by {count} other files, making it "
                f"architecturally central. What interfaces does it define? What are "
                f"the exact method signatures and return types? If this file's "
                f"contracts change, what would break?"
            )

    # 3. Simple return type on complex method (data loss signal)
    for file_path, method_name, return_type, param_count in methods_with_simple_returns:
        if len(questions) < _MAX_CUSTOM_QUESTIONS:
            questions.append(
                f"Method '{method_name}' in '{file_path}' takes {param_count} "
                f"parameters but returns only '{return_type}'. What richer data "
                f"is available inside this method before the return value is "
                f"constructed? What information is discarded during the conversion "
                f"to {return_type}?"
            )

    return questions


def _parse_class_hierarchies(signatures: str) -> dict[str, list[str]]:
    """Extract {base_class: [impl1, impl2, ...]} from signatures text.

    Parses lines like:
      class OpenAIChat(ChatProvider):
      class OllamaChat(ChatProvider):
    into {"ChatProvider": ["OpenAIChat", "OllamaChat"]}
    """
    hierarchies: dict[str, list[str]] = {}
    for match in re.finditer(r"class\s+(\w+)\(([^)]+)\):", signatures):
        cls_name = match.group(1)
        bases = [b.strip() for b in match.group(2).split(",")]
        for base in bases:
            if base and base not in ("object", "ABC", "BaseModel", "Protocol"):
                hierarchies.setdefault(base, []).append(cls_name)
    return hierarchies


def _parse_simple_return_methods(
    signatures: str,
) -> list[tuple[str, str, str, int]]:
    """Find methods with simple return types that suggest data loss.

    Returns list of (file_path, method_name, return_type, param_count).
    Only includes methods returning str/bool with ≥3 parameters.
    """
    results: list[tuple[str, str, str, int]] = []
    current_file = ""
    simple_types = {"str", "bool", "int", "float", "None"}

    for line in signatures.splitlines():
        if line.startswith("## "):
            current_file = line[3:].strip()
            continue

        # Match method lines like: "  chat(prompt: str, model: str) -> str"
        # or top-level: "process(data: list, config: dict) -> bool"
        match = re.match(
            r"\s*(?:async\s+)?(\w+)\(([^)]*)\)\s*->\s*(\w+)", line,
        )
        if not match:
            continue

        method_name = match.group(1)
        params_str = match.group(2)
        return_type = match.group(3)

        if return_type not in simple_types:
            continue
        if method_name.startswith("_"):
            continue

        # Count parameters (split by comma, filter empty)
        params = [p.strip() for p in params_str.split(",") if p.strip()]
        if len(params) >= 3:
            results.append((current_file, method_name, return_type, len(params)))

    return results


# ---------------------------------------------------------------------------
# Two-tier directory clustering (for large codebases, ≥100 files)
# ---------------------------------------------------------------------------

_CLUSTERING_THRESHOLD = 100


def _group_by_directory(
    file_list: list[str], max_depth: int = 2,
) -> dict[str, list[str]]:
    """Group file paths by their directory prefix up to *max_depth* levels.

    Root-level files (no directory) are grouped under ``"(root)"``.

    Args:
        file_list: Relative posix-style paths.
        max_depth: Maximum directory depth for grouping (default 2).

    Returns:
        Mapping of directory prefix → list of file paths in that group.
    """
    groups: dict[str, list[str]] = {}
    for rel_path in file_list:
        parts = PurePosixPath(rel_path).parts
        if len(parts) <= 1:
            key = "(root)"
        else:
            key = "/".join(parts[: min(max_depth, len(parts) - 1)]) + "/"
        groups.setdefault(key, []).append(rel_path)
    return groups


def build_directory_clusters(
    source_dir: str,
    file_list: list[str],
    max_depth: int = 2,
    max_file_bytes: int = 50_000,
) -> tuple[str, dict[str, list[str]]]:
    """Build aggregated directory-level summaries for LLM directory selection.

    For each directory cluster, aggregates class names, function names, and
    imports from the files it contains (reusing ``_extract_structure``).

    Args:
        source_dir:     Absolute path to source root.
        file_list:      Relative posix-style paths.
        max_depth:      Directory grouping depth (default 2).
        max_file_bytes: Max bytes per file for extraction.

    Returns:
        Tuple of (formatted_text, groups_dict).
        *formatted_text* is the prompt-ready cluster summary.
        *groups_dict* maps dir prefix → list of file paths.
    """
    root = Path(source_dir).resolve()
    groups = _group_by_directory(file_list, max_depth)

    lines: list[str] = []
    for dir_prefix in sorted(groups):
        files = groups[dir_prefix]
        all_classes: list[str] = []
        all_functions: list[str] = []
        all_imports: set[str] = set()

        for rel_path in files:
            full_path = root / rel_path
            if not full_path.is_file():
                continue
            try:
                raw = full_path.read_bytes()[:max_file_bytes]
                content = raw.decode("utf-8", errors="replace")
            except OSError:
                continue
            if not content.strip():
                continue

            suffix = PurePosixPath(rel_path).suffix.lower()
            info = _extract_structure(suffix, content, rel_path)
            if not info:
                continue

            for line in info.splitlines():
                if line.startswith("classes:"):
                    all_classes.extend(
                        c.strip() for c in line[len("classes:"):].split(";") if c.strip()
                    )
                elif line.startswith("functions:"):
                    all_functions.extend(
                        f.strip() for f in line[len("functions:"):].split(",") if f.strip()
                    )
                elif line.startswith("imports:"):
                    all_imports.update(
                        i.strip() for i in line[len("imports:"):].split(",") if i.strip()
                    )

        entry = f"## {dir_prefix}  ({len(files)} files)"
        detail_lines: list[str] = []
        if all_classes:
            detail_lines.append(f"classes: {'; '.join(all_classes[:15])}")
        if all_functions:
            detail_lines.append(f"functions: {', '.join(all_functions[:15])}")
        if all_imports:
            detail_lines.append(f"imports: {', '.join(sorted(all_imports)[:10])}")

        if detail_lines:
            entry += "\n" + "\n".join(detail_lines)
        lines.append(entry)

    text = "\n\n".join(lines)
    logger.info(
        f"Clustered {len(file_list)} files into {len(groups)} directories "
        f"({len(text)} chars)"
    )
    return text, groups
