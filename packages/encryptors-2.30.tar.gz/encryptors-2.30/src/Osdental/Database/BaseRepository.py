from typing import Any
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from Osdental.Exception.ControlledException import DatabaseException
from Osdental.Shared.Utils.DataNormalizer import normalize

class BaseRepository:

    def __init__(self, async_session: AsyncSession):
        self.async_session = async_session
    
    def _get_status_value(self, rows: dict, *possible_keys: str):
        for key in possible_keys:
            if key in rows:
                return rows[key]
        return None

    async def _execute_query(
        self,
        query: str,
        params: dict | None = None,
        *,
        many: bool = False,
        as_dict: bool = False
    ) -> Any:
        result = await self.async_session.execute(
            text(query),
            params or {}
        )
        
        data = (
            result.mappings().all()
            if many
            else result.mappings().first()
        )

        if not as_dict or data is None:
            return data

        if many:
            return normalize(data)

        return normalize(data)

    async def _execute_command(
        self,
        query: str,
        params: dict | None = None,
        *,
        validate: bool = True,
        success_codes: str | int | tuple[str | int, ...] | None = None
    ):
        result = await self.async_session.execute(
            text(query),
            params or {}
        )

        row = result.mappings().first()

        if not validate or not row:
            return row

        status_code = self._get_status_value(
            row,
            "statusCode",
            "STATUS_CODE",
            "status_code"
        )

        status_message = self._get_status_value(
            row,
            "statusMessage",
            "STATUS_MESSAGE",
            "status_message"
        )

        # Si no se define success_codes, solo valida que no sea None
        if success_codes is None:
            if status_code is None:
                raise DatabaseException(
                    message="Status code missing",
                    error="Status code missing",
                    status_code=500
                )
            return row

        # Normalizamos a tupla
        if not isinstance(success_codes, tuple):
            success_codes = (success_codes,)

        if status_code not in success_codes:
            raise DatabaseException(
                message=status_message,
                error=status_message,
                status_code=status_code
            )

        return row