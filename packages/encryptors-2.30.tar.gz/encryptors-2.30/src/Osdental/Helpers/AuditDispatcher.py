import asyncio
import logging
from Osdental.Models.AuditConfig import AuditConfig
from Osdental.Messaging import IMessageQueue
from Osdental.Graphql._Helpers._AuditHelper import AuditHelper

class AuditDispatcher:

    def __init__(self, messaging: IMessageQueue, audit_config: AuditConfig, max_queue_size: int = 5000):
        self._messaging = messaging
        self._audit_config = audit_config
        self._queue = asyncio.Queue(maxsize=max_queue_size)
        self._worker_task = None

    # Se llama en startup
    def start(self):
        self._worker_task = asyncio.create_task(self._worker())

    # Se llama en shutdown
    async def stop(self):
        # Esperar a que la cola se vacíe
        await self._queue.join()

        # Enviar sentinel para cerrar worker
        await self._queue.put(None)

        # Esperar a que el worker termine
        if self._worker_task:
            await self._worker_task

    # Ultra rápido, no bloquea
    def dispatch(self, request, request_payload, result, errors = None):
        try:
            payload = {
                "request": request,
                "request_payload": request_payload,
                "result": result,
                "errors": errors
            }

            self._queue.put_nowait(payload)

        except asyncio.QueueFull:
            logging.error("Audit queue full. Dropping message.")

    # Worker real
    async def _worker(self):        
        while True:
            payload = await self._queue.get()
            # Sentinel detectado → salir limpio
            if payload is None:
                self._queue.task_done()
                break

            try:
                await self._process(payload)
            except Exception:
                logging.exception("Audit processing failed")
            finally:
                self._queue.task_done()

    # Logica
    async def _process(self, payload):
        request = payload["request"]
        request_payload = payload["request_payload"]
        result = payload["result"]

        operation_name = request_payload.get("operation_name")
        if operation_name == 'UnknownOperation':
            logging.info("Skipping audit: no data in GraphQL response")
            return
        
        request_audit_payload = await AuditHelper.build_request_payload(
            request=request,
            audit_config=self._audit_config,
            operation_name=operation_name,
            full_name=request_payload.get("user"),
            payload=request_payload.get("variables")
        )

        status = result.get("status")
        message = result.get("message")
        data = result.get("data")
        
        ERROR_PREFIXES = ("DB_ERROR", "DB_WARNING")
        if status.upper().startswith(ERROR_PREFIXES):
            payload = AuditHelper.build_final_payload(
                type="ERROR",
                status_code=status,
                error=message
            )

            audit_message = request_audit_payload | payload

        else:
            payload = AuditHelper.build_final_payload(
                type="RESPONSE",
                status_code="200",
                result=data
            )

            audit_message = request_audit_payload | payload
        
        await self._messaging.enqueue(audit_message)
