import json
import asyncio
from typing import List, Dict, Any
from functools import wraps
from Osdental.InternalHttp.Request import CustomRequest
from Osdental.InternalHttp.Response import CustomResponse
from Osdental.Encryptor.Rsa import RSAEncryptor
from Osdental.Exception.ControlledException import OSDException, RSAEncryptException, AESEncryptException
from Osdental.Encryptor.Aes import AES
from Osdental.Shared.Utils.TextProcessor import TextProcessor
from Osdental.Shared.Logger import logger as custom_logger
from Osdental.Models.Legacy import Legacy
from Osdental.Grpc.Client.PortalClient import PortalClient
from Osdental.Shared.Enums.Code import Code

portal_client = PortalClient()
aes = AES()



def try_decrypt_or_return_raw(data: str, private_key_rsa: str, aes_key: str) -> str:
    try:
        return RSAEncryptor.decrypt(data, private_key_rsa, silent=True)
    except RSAEncryptException:
        try:
            return aes.decrypt(aes_key, data, silent=True)
        except AESEncryptException:
            return data

def enqueue_response(data: Any, headers: Dict[str,str], msg_info: str = None):
    content = json.dumps(data) if isinstance(data, dict) else msg_info
    custom_response = CustomResponse(content=content, headers=headers)
    _ = asyncio.create_task(custom_response.send_to_service_bus())


def handle_audit_and_exception():
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            headers = {}

            
            # Extract request and operation name before opening the span
            try:
                _, info = args[:2] 
                request = info.context.get('request')
                headers = info.context.get('headers') or {}
                
                if request:
                    # Send audit of the request to Service Bus
                    custom_request = CustomRequest(request)
                    _ = asyncio.create_task(custom_request.send_to_service_bus())

            except Exception as ex:
                logger.warning(f"Failed to extract operationName: {ex}")

            try:
                # Get legacy
                res = await portal_client.get_legacy()
                data = json.loads(res.data)
                legacy = Legacy.from_db(data) if res.status == Code.PROCESS_SUCCESS_CODE else None
                # Run the resolver
                response = await func(*args, **kwargs)
                # Prepare data and message
                msg_info = TextProcessor.concatenate(response.get('status'), '-', response.get('message'))
                raw_data = response.get('data')
                data_to_enqueue = None
                if raw_data:
                    data_to_enqueue = try_decrypt_or_return_raw(raw_data, legacy.private_key2, legacy.aes_key_auth)
                # Enqueue response
                enqueue_response(data_to_enqueue, headers, msg_info)
                return response
            except OSDException as ex:
                # Controlled log
                custom_logger.error(f'Controlled error: {str(ex)}')      
                ex.headers = headers
                _ = asyncio.create_task(ex.send_to_service_bus())
                return ex.get_response()
            except Exception as e:
                # Unhandled exception log and span
                custom_logger.error(f'Unexpected error: {str(e)}')      
                ex = OSDException(error=str(e), headers=headers)
                _ = asyncio.create_task(ex.send_to_service_bus())
                return ex.get_response()

        return wrapper
    return decorator