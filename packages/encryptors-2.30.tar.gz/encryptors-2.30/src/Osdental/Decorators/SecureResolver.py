import inspect
import asyncio
from functools import wraps
from typing import Callable, Dict, Any
from graphql import GraphQLResolveInfo
from Osdental.Models.Token import AuthToken
from Osdental.Models.Response import Response
from Osdental.Shared.Enums.Profile import Profile
from Osdental.Exception.ControlledException import OSDException
from Osdental.Encryptor.Aes import AES


aes = AES()
def secure_resolver(action = None):
    def decorator(func: Callable):

        signature = inspect.signature(func)
        accepts_data = "data" in signature.parameters

        @wraps(func)
        async def wrapper(obj: Any, info: GraphQLResolveInfo, **kwargs: Dict):
            try:
                token: AuthToken = info.context.token
                payload = getattr(info.context, "decrypted_payload", None)
                aes_key = getattr(info.context, "aes_key", None)

                if action:
                    if Profile(token.abbreviation) not in action.allowed_roles:
                        raise OSDException("DB_ERROR_AUTH", "You are not authorized to perform this action.")

                if accepts_data and payload:
                    kwargs["data"] = payload

                result: Response = await func(obj, info, **kwargs)

                if result.data is not None:
                    result.data = aes.encrypt(aes_key, result.data)

                return result

                # await info.context.audit_dispatcher.dispatch(
                #     security=security,
                #     result=result
                # )

                if result.data is not None:
                    result.data = aes.encrypt(security.encryptor.aes_auth, result.data)
                    

                return result

            except (Exception, OSDException) as e:
                result = {
                    "status": getattr(e, "status_code", "DB_ERROR_UNEXPECTED"),
                    "message": getattr(e, "message", "Could not process request."),
                    "error": getattr(e, "error", type(e).__name__),
                    "data": None
                }

                # _ = asyncio.create_task(
                #     info.context.audit_dispatcher.dispatch(
                #         security=security,
                #         result=result
                #     )
                # )

                return result

        return wrapper
    return decorator