from typing import Dict, Any
from datetime import datetime, timedelta, timezone
from azure.identity.aio import DefaultAzureCredential
from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import (
    generate_blob_sas, 
    BlobSasPermissions
)
from Osdental.Storage import IStorageService

class AzureBlobStorage(IStorageService):

    def __init__(self, account_url: str, container_name: str = "uploads"):
        """
        account_url: ej. "https://tunombre.blob.core.windows.net"
        """
        self._account_url = account_url
        self._container = container_name
        # Inyectamos la credencial por defecto (Managed Identity en Prod, Azure CLI en Dev)
        self._credential = DefaultAzureCredential()
        self._client = BlobServiceClient(self._account_url, credential=self._credential)
        self._container_client = self._client.get_container_client(self._container)

    async def upload(self, blob_name: str, data: bytes | str) -> str | bool:
        """ Uploads a blob. Returns the blob URL. """
        try:
            blob_client = self._container_client.get_blob_client(blob_name)

            if isinstance(data, str):
                data = data.encode("utf-8")

            await blob_client.upload_blob(data, overwrite=True)
            return blob_client.url
        
        except Exception:
            return False

    async def download(self, blob_name: str) -> bytes | None:
        """ Download a blob. """
        try:
            blob_client = self._container_client.get_blob_client(blob_name)
            stream = await blob_client.download_blob()
            return await stream.readall()
        
        except Exception:
            return None

    async def delete(self, blob_name: str) -> bool:
        """ Deletes a blob. """
        try:
            blob_client = self.container_client.get_blob_client(blob_name)
            await blob_client.delete_blob()
            return True
        
        except Exception:
            return False

    async def generate_upload_url(self, filename: str) -> Dict[str, Any]:
        # 1. Obtener una User Delegation Key (válida por máximo 7 días)
        start_time = datetime.now(timezone.utc)
        expiry_time = start_time + timedelta(hours=2)

        user_delegation_key = await self._client.get_user_delegation_key(
            key_start_time=start_time,
            key_expiry_time=expiry_time
        )

        # 2. Generar el SAS usando la clave de delegación
        sas_token = generate_blob_sas(
            account_name=self._client.account_name,
            container_name=self._container,
            blob_name=filename,
            user_delegation_key=user_delegation_key,
            permission=BlobSasPermissions(write=True, create=True),
            expiry=expiry_time
        )

        url = f"{self._account_url}/{self._container}/{filename}?{sas_token}"

        return {
            "uploadUrl": url,
            "blobName": filename
        }