from typing import Optional
from pydantic import BaseModel, Field
from Osdental.Models.Legacy import Legacy

class AuthToken(BaseModel):
    
    id_token: str = Field(alias="idToken")
    id_user: str = Field(alias="idUser")
    id_external_enterprise: str = Field(alias="idExternalEnterprise")
    id_profile: str = Field(alias="idProfile")
    id_legacy: str = Field(alias="idLegacy")
    id_authorization: str = Field(default=None, alias="idAuthorization")
    id_item_report: str = Field(alias="idItemReport")
    id_enterprise: str = Field(alias="idEnterprise")
    user_full_name: str = Field(alias="userFullName")
    abbreviation: str = Field(alias="abbreviation")
    aes_key_auth: str = Field(alias="aesKeyAuth")
    access_token: Optional[str] = Field(default=None, alias="accessToken")
    base_id_external_enterprise: Optional[str] = Field(default=None, alias="baseIdExternalEnterprise")
    mk_id_external_enterprise: Optional[str] = Field(default=None, alias="mkIdExternalEnterprise")
    jwt_user_key: Optional[str] = Field(default=None, alias="jwtUserKey")
    legacy: Optional[Legacy] = Field(default=None, alias="legacy")

    class ConfigDict:
        populate_by_name = True