from Osdental.Encryptor.Aes import AES
from Osdental.Encryptor.Jwt import JWT
from Osdental.Models.Token import AuthToken

class TokenService:

    def __init__(self, jwt_user_key: str, auth_validator):
        self.jwt_user_key = jwt_user_key
        self.auth_validator = auth_validator
        self.aes = AES()

    async def authenticate(self, request):
        authorization = request.headers.get("authorization")
        if not authorization or not authorization.startswith("Bearer "):
            raise ValueError("Missing Bearer token")

        encrypted_token = authorization.split(" ")[1]

        aes_user = request.app.state.aes_user

        user_token = self.aes.decrypt(aes_user, encrypted_token)
        payload = JWT.extract_payload(user_token, self.jwt_user_key)
        token = AuthToken(**payload)

        # Validate via RPC
        request = {
            'idToken': token.id_token,
            'idUser': token.id_user
        }
        is_valid = await self.auth_validator.validate_auth_token(request)
        if not is_valid:
            raise ValueError("You are not authorized to access this portal.")

        return token