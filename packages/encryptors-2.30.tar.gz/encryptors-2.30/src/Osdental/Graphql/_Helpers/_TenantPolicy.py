from Osdental.Encryptor.Aes import AES
from uuid import UUID
from graphql import OperationType

class TenantPolicy:

    @staticmethod
    def resolve(token, headers, decrypted_payload, operation_type: str):
        aes = AES()
        # Solo aplicamos cambios si es QUERY
        if operation_type != OperationType.QUERY.value:
            return token  # devolver token tal cual

        # SUPER ADMIN / OSDEL ADMIN -> UUID 0
        if token.abbreviation.startswith(("SPAU", "OSDA")):
            token.id_external_enterprise = str(UUID(int=0))
            return token

        # Marketing -> tomar dynamicClientId del header
        if token.abbreviation.startswith("OSDMK"):
            dynamic_client_id = headers.get("dynamicClientId")
            if dynamic_client_id:
                decrypted_mk_id = aes.decrypt(token.aes_key_auth, dynamic_client_id)
                token.id_external_enterprise = decrypted_mk_id
                token.mk_id_external_enterprise = decrypted_mk_id
                return token

        # If it comes by request, it is taken as priority
        external_enterprise_req = decrypted_payload.get('idExternalEnterprise')
        if external_enterprise_req and token:
            token.id_external_enterprise = external_enterprise_req

        return token