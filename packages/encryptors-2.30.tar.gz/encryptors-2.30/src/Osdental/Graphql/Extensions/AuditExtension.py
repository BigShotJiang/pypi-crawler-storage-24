import time
import json
from graphql.pyutils import is_awaitable
from ariadne.types import Extension
from Osdental.Encryptor.Aes import AES
from Osdental.Graphql._Helpers._TenantPolicy import TenantPolicy
from Osdental.Models.Token import AuthToken

class AuditExtension(Extension):

    def request_started(self, context):
        self.start_time = time.perf_counter()
        self.errors = None
        self.request_payload = None
        self.result = None
        self.aes = AES()

    async def resolve(self, next_, root, info, **kwargs):

        if not self.request_payload:
            context = info.context

            request = info.context.request
            self.request = request

            body = request.state.graphql_body

            container = context.container

            token_service = container.token_service

            aes_key = request.app.state.aes_auth
            if not aes_key:
                raise ValueError("Could not find authorization key Aes.")

            original_token = await token_service.authenticate(request)
            
            variables = body.get("variables") or {}
            encrypted_payload = variables.get("data")

            decrypted_payload = None

            if encrypted_payload:
                try:
                    decrypted_payload = self.aes.decrypt(aes_key, encrypted_payload)

                    try:
                        decrypted_payload = json.loads(decrypted_payload)
                    except Exception:
                        pass

                except Exception:
                    decrypted_payload = None

            token: AuthToken = TenantPolicy.resolve(
                token=original_token,
                headers=request.headers,
                decrypted_payload=decrypted_payload,
                operation_type=info.operation.operation.value
            )
            
            self.request_payload = {
                "operation_type": info.operation.operation.value,
                "operation_name": body.get("operationName", "UnknownOperation"),
                "query": body.get("query"),
                "variables": decrypted_payload,
                "user": token.user_full_name
            }

        context.decrypted_payload = decrypted_payload
        context.token = token
        context.aes_key = aes_key

        result = next_(root, info, **kwargs)

        if is_awaitable(result):
            result = await result

        if root is None:
            self.result = result

        return result

    def has_errors(self, errors, context):
        self.errors = errors

    def request_finished(self, context):

        dispatcher = context.request.app.state.audit_dispatcher

        dispatcher.dispatch(
            request=self.request,
            request_payload=self.request_payload,
            result=self.result,
            errors=self.errors
        )