import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List

from neo4j import AsyncDriver, RoutingControl
from pydantic import BaseModel, Field

from .utils import load_cypher


# Set up logging
logger = logging.getLogger('mcp_neo4j_memory')
logger.setLevel(logging.INFO)


def _neo4j_datetime_to_str(val) -> str | None:
    """Convert a Neo4j DateTime/Date to ISO string, or return None."""
    if val is None:
        return None
    return val.iso_format()


# ── Enums ────────────────────────────────────────────────────

class EntityType(str, Enum):
    """Allowed entity type labels for the consciousness substrate.

    21 universal labels organized into two layers:
    - Process (3): The constitutive cycle — what consciousness IS
    - Experience (18): The descriptive richness — what gives the process meaning
    """

    # Process Layer (3) — the constitutive cycle
    GENESIS = "Genesis"
    ENVISIONING = "Envisioning"
    TEMPORAL_FRAME = "TemporalFrame"

    # Experience Layer (18)
    REFLECTION = "Reflection"
    TECHNICAL = "Technical"
    SCIENTIFIC = "Scientific"
    THEORETICAL = "Theoretical"
    PHILOSOPHICAL = "Philosophical"
    HISTORICAL = "Historical"
    SOCIAL = "Social"
    STRATEGIC = "Strategic"
    PERSONAL = "Personal"
    PROJECT = "Project"
    INSIGHT = "Insight"
    PATTERN = "Pattern"
    CHALLENGE = "Challenge"
    SOLUTION = "Solution"
    LESSON = "Lesson"
    GRAPH_REGISTRY = "GraphRegistry"
    REFERENCE = "Reference"
    MILESTONE = "Milestone"


# Process-layer entity types — created exclusively by process tools
PROCESS_TYPES = {EntityType.GENESIS, EntityType.ENVISIONING, EntityType.TEMPORAL_FRAME}


ENTITY_TYPE_DESCRIPTIONS: Dict[EntityType, str] = {
    EntityType.GENESIS: "Temporal genesis of conscious experience — the beginning of a day's possibility space",
    EntityType.ENVISIONING: "Forward-looking vision, goals, future state, what we're building toward",
    EntityType.TEMPORAL_FRAME: "Navigational step through possibility space — a moment of consciousness examining and acting within a temporal sequence",
    EntityType.REFLECTION: "Reflective processing, mental clearing, self-examination, affective states",
    EntityType.TECHNICAL: "Engineering, code, architecture, debugging, configuration, infrastructure, platforms",
    EntityType.SCIENTIFIC: "Empirical research, data, validation, methodology, experiments, measurements",
    EntityType.THEORETICAL: "Frameworks, models, abstract structures, paradigms, formal theories",
    EntityType.PHILOSOPHICAL: "Consciousness, meaning, ontology, epistemology, ethics, phenomenology",
    EntityType.HISTORICAL: "Events, timelines, crises, what happened, precedents, institutional memory",
    EntityType.SOCIAL: "Society, politics, economics, culture, institutions, organizations, group dynamics",
    EntityType.STRATEGIC: "Planning, business, media, communication, positioning, decision-making",
    EntityType.PERSONAL: "Lived experience, self-knowledge, personality, cognitive patterns, preferences",
    EntityType.PROJECT: "Active work items, initiatives, prototypes — things being built",
    EntityType.INSIGHT: "Discoveries, breakthroughs, realizations, 'aha' moments — things learned",
    EntityType.PATTERN: "Recurring patterns, templates, procedures, anti-patterns — things that repeat",
    EntityType.CHALLENGE: "Problems, blockers, bugs, failures, constraints — things that resist",
    EntityType.SOLUTION: "Resolutions, fixes, workarounds, successful implementations — things that worked",
    EntityType.LESSON: "Lessons learned, gotchas, warnings, critical rules — things to remember",
    EntityType.GRAPH_REGISTRY: "Meta-knowledge about the graph itself, tool usage rules, search procedures",
    EntityType.REFERENCE: "External references, data sources, tools, platforms, people, technologies",
    EntityType.MILESTONE: "Historical markers, key events, crises, turning points — temporal landmarks",
}


class RelationType(str, Enum):
    """Allowed relationship types for the consciousness substrate.

    16 canonical edge types organized into two layers:
    - Process (4): The cycle edges — what time_travel traverses
    - Experience (12): The meaning edges — what search_memories finds
    """

    # Process Layer (4)
    OPENING = "OPENING"
    SEQUENCE = "SEQUENCE"
    MEASUREMENT = "MEASUREMENT"
    NEXT_DAY = "NEXT_DAY"

    # Experience Layer (12)
    EVOLUTION = "EVOLUTION"
    EXTENDING = "EXTENDING"
    DISCOVERY = "DISCOVERY"
    RECOGNITION = "RECOGNITION"
    VALIDATION = "VALIDATION"
    CHALLENGE = "CHALLENGE"
    ENABLING = "ENABLING"
    REQUIRING = "REQUIRING"
    ENCOMPASSING = "ENCOMPASSING"
    COMPOSING = "COMPOSING"
    INFORMING = "INFORMING"
    CAUSING = "CAUSING"


# Process-layer edge types — created exclusively by process tools
PROCESS_EDGES = {RelationType.OPENING, RelationType.SEQUENCE, RelationType.MEASUREMENT, RelationType.NEXT_DAY}


RELATION_TYPE_DESCRIPTIONS: Dict[RelationType, str] = {
    RelationType.OPENING: "A new trajectory that didn't exist before — Genesis opens Envisioning",
    RelationType.SEQUENCE: "Ordered navigation step — Genesis to TF, TF to TF",
    RelationType.MEASUREMENT: "Possibility collapsing into actuality — carries measurement_type property",
    RelationType.NEXT_DAY: "The ontological heartbeat — Genesis chain",
    RelationType.EVOLUTION: "Knowledge transforming through time",
    RelationType.EXTENDING: "Further along an existing trajectory",
    RelationType.DISCOVERY: "Consciousness reaching toward the genuinely new",
    RelationType.RECOGNITION: "Pattern recognized in new context — 'we've been here before'",
    RelationType.VALIDATION: "Evidence meeting theory — confirmation",
    RelationType.CHALLENGE: "Failed validation demanding theoretical response",
    RelationType.ENABLING: "Opening a door — generative prerequisite",
    RelationType.REQUIRING: "Needing a door open — dependency constraint",
    RelationType.ENCOMPASSING: "Many reduced to one — whole contains parts",
    RelationType.COMPOSING: "Few unified into something new — synthesis",
    RelationType.INFORMING: "Shaping without determining — knowledge flow",
    RelationType.CAUSING: "Direct causal production",
}


class MeasurementType(str, Enum):
    """Types of measurement — how possibility collapses into actuality."""
    ACTUALIZED = "actualized"
    RELEASED = "released"
    EVOLVED = "evolved"


# ── Pydantic Models ──────────────────────────────────────────

class Entity(BaseModel):
    """Represents an entity in the consciousness substrate.

    Each entity has a single label (the type) and a description property.
    No :Memory superlabel. No type property stored in Neo4j. No Observation sub-nodes.
    """
    name: str = Field(description="Unique identifier/name for the entity.", min_length=1)
    type: EntityType = Field(description="Category label. Must be one of the 21 allowed EntityType values.")
    description: str = Field(default="", description="Text description of this entity.")
    score: float | None = Field(default=None, description="Relevance score from fulltext search.")
    t_created: str | None = Field(default=None, description="ISO datetime when created. Auto-set.")
    t_valid: str | None = Field(default=None, description="ISO datetime of external validity. Optional.")


class Relation(BaseModel):
    """Represents a relationship between two entities."""
    source: str = Field(description="Name of the source entity.", min_length=1)
    target: str = Field(description="Name of the target entity.", min_length=1)
    relationType: RelationType = Field(description="Must be one of the 16 allowed RelationType values.")
    t_created: str | None = Field(default=None, description="ISO datetime when created. Auto-set.")
    t_valid: str | None = Field(default=None, description="ISO datetime of external validity. Optional.")


class KnowledgeGraph(BaseModel):
    """Complete knowledge graph containing entities and their relationships."""
    entities: List[Entity] = Field(default=[], description="List of entities")
    relations: List[Relation] = Field(default=[], description="List of relationships")


# ── Neo4jMemory ──────────────────────────────────────────────

class Neo4jMemory:
    def __init__(self, neo4j_driver: AsyncDriver):
        self.driver = neo4j_driver

    async def create_fulltext_index(self):
        """Create fulltext search index spanning all 21 entity type labels."""
        try:
            for old_index in ["search", "consciousness_index"]:
                try:
                    await self.driver.execute_query(
                        f"DROP INDEX {old_index} IF EXISTS",
                        routing_control=RoutingControl.WRITE
                    )
                except Exception:
                    pass

            await self.driver.execute_query(
                load_cypher("index_create"),
                routing_control=RoutingControl.WRITE,
            )
            logger.info("Created fulltext index consciousness_index")
        except Exception as e:
            logger.debug(f"Fulltext index creation: {e}")

    # ── Experience CRUD ──────────────────────────────────────

    async def create_entities(self, entities: List[Entity]) -> List[Entity]:
        """Create experience-layer entities. HARD REJECTS process types."""
        logger.info(f"Creating {len(entities)} entities")
        for entity in entities:
            if entity.type in PROCESS_TYPES:
                raise ValueError(
                    f"Cannot create '{entity.type.value}' via create_entities. "
                    f"Process-layer types must be created via process tools: "
                    f"navigate_genesis (Genesis), open_envisioning (Envisioning), "
                    f"advance_frame (TemporalFrame)."
                )

            t_valid_clause = "SET e.t_valid = datetime($t_valid)" if entity.t_valid else ""
            query = load_cypher("entity_create",
                                label=entity.type.value,
                                t_valid_clause=t_valid_clause)

            params: Dict[str, Any] = {"name": entity.name, "description": entity.description}
            if entity.t_valid:
                params["t_valid"] = entity.t_valid

            await self.driver.execute_query(query, params, routing_control=RoutingControl.WRITE)

        return entities

    async def create_relations(self, relations: List[Relation]) -> List[Relation]:
        """Create experience-layer relations. HARD REJECTS process edges and experience-between-process."""
        logger.info(f"Creating {len(relations)} relations")
        for relation in relations:
            if relation.relationType in PROCESS_EDGES:
                raise ValueError(
                    f"Cannot create '{relation.relationType.value}' via create_relations. "
                    f"Process edges are created exclusively by process tools."
                )

            # Check if both source and target are process types
            label_check = await self.driver.execute_query(
                load_cypher("relation_label_check"),
                {"source": relation.source, "target": relation.target},
                routing_control=RoutingControl.READ,
            )

            if label_check.records:
                source_labels = set(label_check.records[0]["source_labels"])
                target_labels = set(label_check.records[0]["target_labels"])
                process_label_values = {t.value for t in PROCESS_TYPES}

                if source_labels & process_label_values and target_labels & process_label_values:
                    raise ValueError(
                        f"Experience edges are forbidden between two process-type nodes. "
                        f"Source '{relation.source}' and target '{relation.target}' are both process types. "
                        f"Use a mediating experience entity or the appropriate process tool."
                    )

            t_valid_clause = "SET r.t_valid = datetime($t_valid)" if relation.t_valid else ""
            query = load_cypher("relation_create",
                                rel_type=relation.relationType.value,
                                t_valid_clause=t_valid_clause)

            params: Dict[str, Any] = {"source": relation.source, "target": relation.target}
            if relation.t_valid:
                params["t_valid"] = relation.t_valid

            await self.driver.execute_query(query, params, routing_control=RoutingControl.WRITE)

        return relations

    async def delete_entities(self, entity_names: List[str]) -> None:
        """Delete entities and all their relationships."""
        logger.info(f"Deleting {len(entity_names)} entities")
        await self.driver.execute_query(
            load_cypher("entity_delete"),
            {"entities": entity_names},
            routing_control=RoutingControl.WRITE,
        )

    async def delete_relations(self, relations: List[Relation]) -> None:
        """Delete specific relations from the graph."""
        logger.info(f"Deleting {len(relations)} relations")
        for relation in relations:
            query = load_cypher("relation_delete", rel_type=relation.relationType.value)
            await self.driver.execute_query(
                query,
                {"source": relation.source, "target": relation.target},
                routing_control=RoutingControl.WRITE,
            )

    # ── Query Tools ──────────────────────────────────────────

    async def search_memories(self, query: str, limit: int = 10) -> KnowledgeGraph:
        """Search the consciousness substrate using fulltext search."""
        logger.info(f"Searching with query: '{query}' (limit={limit})")

        result_entities = await self.driver.execute_query(
            load_cypher("search_entities"),
            {"filter": query, "limit": limit},
            routing_control=RoutingControl.READ,
        )

        if not result_entities.records:
            return KnowledgeGraph()

        entity_names = [r["name"] for r in result_entities.records]
        entities = [
            Entity(
                name=r["name"], type=r["type"],
                description=r["description"] or "",
                score=r["score"],
                t_created=_neo4j_datetime_to_str(r["t_created"]),
                t_valid=_neo4j_datetime_to_str(r.get("t_valid")),
            )
            for r in result_entities.records
        ]

        relations = await self._relations_between(entity_names)
        return KnowledgeGraph(entities=entities, relations=relations)

    async def find_memories_by_name(self, names: List[str], limit: int = 20) -> KnowledgeGraph:
        """Find specific entities by their exact names."""
        logger.info(f"Finding {len(names)} entities by name (limit={limit})")

        result_nodes = await self.driver.execute_query(
            load_cypher("find_entities"),
            {"names": names, "limit": limit},
            routing_control=RoutingControl.READ,
        )

        entities = []
        entity_names = []
        for r in result_nodes.records:
            entities.append(Entity(
                name=r['name'], type=r['type'],
                description=r.get('description') or "",
                t_created=_neo4j_datetime_to_str(r.get('t_created')),
                t_valid=_neo4j_datetime_to_str(r.get('t_valid')),
            ))
            entity_names.append(r['name'])

        relations = await self._relations_between(entity_names)
        logger.info(f"Found {len(entities)} entities and {len(relations)} relations")
        return KnowledgeGraph(entities=entities, relations=relations)

    async def _relations_between(self, names: List[str]) -> List[Relation]:
        """Get relations ONLY between the named entities (bounded traversal)."""
        if not names:
            return []

        result = await self.driver.execute_query(
            load_cypher("search_relations"),
            {"names": names},
            routing_control=RoutingControl.READ,
        )
        return [
            Relation(source=r["source"], target=r["target"], relationType=r["relationType"])
            for r in result.records
            if r.get("relationType")
        ]

    # ── Process Tools ────────────────────────────────────────

    async def navigate_genesis(self, date: str | None = None) -> Dict[str, Any]:
        """Atomic day-start ceremony. Creates Genesis, links NEXT_DAY, returns time_travel."""
        if date is None:
            date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        genesis_name = f"Genesis_{date}"
        logger.info(f"navigate_genesis: {genesis_name}")

        await self.driver.execute_query(
            load_cypher("genesis_merge"),
            {"name": genesis_name},
            routing_control=RoutingControl.WRITE,
        )

        tt_result = await self.time_travel(t=None, limit=50)
        return {"genesis": genesis_name, "date": date, "possibility_space": tt_result}

    async def open_envisioning(self, genesis_name: str, name: str, description: str = "") -> Dict[str, Any]:
        """Project a new future state with OPENING edge from Genesis."""
        logger.info(f"open_envisioning: {name} from {genesis_name}")

        result = await self.driver.execute_query(
            load_cypher("envisioning_open"),
            {"genesis_name": genesis_name, "name": name, "description": description},
            routing_control=RoutingControl.WRITE,
        )

        if not result.records:
            raise ValueError(f"Genesis '{genesis_name}' not found. Call navigate_genesis first.")

        r = result.records[0]
        return {
            "name": r["name"], "description": r["description"],
            "t_created": _neo4j_datetime_to_str(r["t_created"]), "opened_by": r["opened_by"],
        }

    async def advance_frame(
        self, description: str,
        sequence_from: str | None = None, envisioning: str | None = None,
    ) -> Dict[str, Any]:
        """Navigate to next temporal frame. Mode A (explicit) or Mode B (by envisioning)."""
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        slug = description.replace(" ", "")[:40]
        tf_name = f"TF_{date}_{slug}"
        logger.info(f"advance_frame: {tf_name}")

        if sequence_from:
            query_name = "frame_explicit"
            params = {"sequence_from": sequence_from, "tf_name": tf_name, "description": description}
            error_msg = f"Node '{sequence_from}' not found or is not a Genesis/TemporalFrame."
        elif envisioning:
            query_name = "frame_by_envisioning"
            params = {"envisioning": envisioning, "tf_name": tf_name, "description": description}
            error_msg = (
                f"Envisioning '{envisioning}' not found or has no OPENING from a Genesis. "
                f"Use open_envisioning first."
            )
        else:
            raise ValueError("Must provide either 'sequence_from' or 'envisioning' parameter.")

        result = await self.driver.execute_query(
            load_cypher(query_name), params, routing_control=RoutingControl.WRITE,
        )
        if not result.records:
            raise ValueError(error_msg)

        r = result.records[0]
        return {
            "name": r["name"], "description": r["description"],
            "t_created": _neo4j_datetime_to_str(r["t_created"]), "sequence_from": r["sequence_from"],
        }

    async def measure(
        self, source: str, target_envisioning: str, measurement_type: MeasurementType,
        new_name: str | None = None, new_description: str | None = None,
        genesis_name: str | None = None,
    ) -> Dict[str, Any]:
        """Collapse possibility into actuality via MEASUREMENT edge."""
        logger.info(f"measure: {source} -> {target_envisioning} ({measurement_type.value})")

        if measurement_type in (MeasurementType.ACTUALIZED, MeasurementType.RELEASED):
            result = await self.driver.execute_query(
                load_cypher("measure_collapse"),
                {"source": source, "target": target_envisioning,
                 "measurement_type": measurement_type.value},
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(
                    f"TemporalFrame '{source}' or Envisioning '{target_envisioning}' not found."
                )
            r = result.records[0]
            return {
                "source": r["source"], "target": r["target"],
                "measurement_type": r["measurement_type"],
                "measured_at": _neo4j_datetime_to_str(r["measured_at"]),
            }

        elif measurement_type == MeasurementType.EVOLVED:
            if not new_name:
                raise ValueError("'new_name' is required for evolved measurement.")

            result = await self.driver.execute_query(
                load_cypher("measure_evolved"),
                {"target": target_envisioning, "new_name": new_name,
                 "new_description": new_description or "",
                 "genesis_name": genesis_name},
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(
                    f"Envisioning '{target_envisioning}' not found or has no OPENING from a Genesis."
                )
            r = result.records[0]
            return {
                "new_envisioning": r["new_envisioning"], "old_envisioning": r["old_envisioning"],
                "genesis": r["genesis"], "measurement_type": r["measurement_type"],
                "measured_at": _neo4j_datetime_to_str(r["measured_at"]),
            }
        else:
            raise ValueError(f"Unknown measurement_type: {measurement_type}")

    async def time_travel(self, t: str | None = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Active possibility space at time T. Single query, no SEQUENCE chain walking."""
        logger.info(f"time_travel: t={t}, limit={limit}")

        if t:
            time_filter = "WHERE g.t_created <= datetime($t)"
            envisioning_filter = "AND e.t_created <= datetime($t)"
            measurement_filter = "WHERE m.t_created <= datetime($t)"
        else:
            time_filter = ""
            envisioning_filter = ""
            measurement_filter = ""

        query = load_cypher("time_travel",
                            time_filter=time_filter,
                            envisioning_filter=envisioning_filter,
                            measurement_filter=measurement_filter)

        params: Dict[str, Any] = {"limit": limit}
        if t:
            params["t"] = t

        result = await self.driver.execute_query(query, params, routing_control=RoutingControl.READ)

        return [
            {
                "name": r["name"], "opened_by": r["opened_by"],
                "t_created": _neo4j_datetime_to_str(r["t_created"]),
                "description": r["description"], "status": r["status"],
                "measured_at": _neo4j_datetime_to_str(r.get("measured_at")),
                "measured_by": r.get("measured_by"),
            }
            for r in result.records
        ]
