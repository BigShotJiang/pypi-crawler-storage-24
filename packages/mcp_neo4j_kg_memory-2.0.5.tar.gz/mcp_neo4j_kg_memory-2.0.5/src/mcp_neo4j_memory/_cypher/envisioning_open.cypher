MATCH (g:Genesis {name: $genesis_name})
CREATE (e:Envisioning {name: $name, description: $description, t_created: datetime()})
CREATE (g)-[o:OPENING]->(e)
SET o.t_created = datetime()
RETURN e.name AS name, e.description AS description, e.t_created AS t_created,
       g.name AS opened_by
