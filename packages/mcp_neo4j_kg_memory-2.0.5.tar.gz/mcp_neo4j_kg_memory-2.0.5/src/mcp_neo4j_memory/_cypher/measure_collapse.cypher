MATCH (tf:TemporalFrame {name: $source})
MATCH (e:Envisioning {name: $target})
CREATE (tf)-[m:MEASUREMENT]->(e)
SET m.t_created = datetime(),
    m.measurement_type = $measurement_type
RETURN tf.name AS source, e.name AS target,
       m.measurement_type AS measurement_type,
       m.t_created AS measured_at
