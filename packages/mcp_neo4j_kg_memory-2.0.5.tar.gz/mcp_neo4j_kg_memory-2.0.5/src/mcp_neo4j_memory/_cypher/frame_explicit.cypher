MATCH (prev {name: $sequence_from})
WHERE prev:Genesis OR prev:TemporalFrame
CREATE (tf:TemporalFrame {name: $tf_name, description: $description, t_created: datetime()})
CREATE (prev)-[s:SEQUENCE]->(tf)
SET s.t_created = datetime()
RETURN tf.name AS name, tf.description AS description, tf.t_created AS t_created,
       prev.name AS sequence_from
