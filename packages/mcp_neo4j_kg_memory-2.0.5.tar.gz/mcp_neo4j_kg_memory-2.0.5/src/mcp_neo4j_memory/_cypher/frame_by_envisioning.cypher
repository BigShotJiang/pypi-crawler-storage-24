MATCH (e:Envisioning {name: $envisioning})
MATCH (g:Genesis)-[:OPENING]->(e)
OPTIONAL MATCH (g)-[:SEQUENCE*]->(tf:TemporalFrame)
WITH e, g, tf
ORDER BY COALESCE(tf.t_created, g.t_created) DESC
LIMIT 1
WITH e, COALESCE(tf, g) AS prev
CREATE (new_tf:TemporalFrame {name: $tf_name, description: $description, t_created: datetime()})
CREATE (prev)-[s:SEQUENCE]->(new_tf)
SET s.t_created = datetime()
RETURN new_tf.name AS name, new_tf.description AS description,
       new_tf.t_created AS t_created, prev.name AS sequence_from
