import pytest
from unittest.mock import Mock, AsyncMock
from pydantic import ValidationError

from mcp_neo4j_memory.server import format_namespace, create_mcp_server
from mcp_neo4j_memory.neo4j_memory import (
    Neo4jMemory, KnowledgeGraph, Entity, EntityType, PROCESS_TYPES,
    Relation, RelationType, PROCESS_EDGES, MeasurementType,
)


class TestFormatNamespace:
    """Test the format_namespace function behavior."""

    def testformat_namespace_empty_string(self):
        """Test format_namespace with empty string returns empty string."""
        assert format_namespace("") == ""

    def testformat_namespace_no_hyphen(self):
        """Test format_namespace adds hyphen when not present."""
        assert format_namespace("myapp") == "myapp-"

    def testformat_namespace_with_hyphen(self):
        """Test format_namespace returns string as-is when hyphen already present."""
        assert format_namespace("myapp-") == "myapp-"

    def testformat_namespace_complex_name(self):
        """Test format_namespace with complex namespace names."""
        assert format_namespace("company.product") == "company.product-"
        assert format_namespace("app_v2") == "app_v2-"


class TestNamespacing:
    """Test namespacing functionality."""

    @pytest.fixture
    def mock_memory(self):
        """Create a mock Neo4jMemory for testing."""
        memory = Mock(spec=Neo4jMemory)
        knowledge_graph = KnowledgeGraph(entities=[], relations=[])
        memory.create_entities = AsyncMock(return_value=[])
        memory.create_relations = AsyncMock(return_value=[])
        memory.delete_entities = AsyncMock(return_value=None)
        memory.delete_relations = AsyncMock(return_value=None)
        memory.search_memories = AsyncMock(return_value=knowledge_graph)
        memory.find_memories_by_name = AsyncMock(return_value=knowledge_graph)
        memory.navigate_genesis = AsyncMock(return_value={"genesis": "Genesis_2026-03-06", "date": "2026-03-06", "possibility_space": []})
        memory.open_envisioning = AsyncMock(return_value={"name": "Test", "description": "", "t_created": None, "opened_by": "Genesis_2026-03-06"})
        memory.advance_frame = AsyncMock(return_value={"name": "TF_2026-03-06_Test", "description": "Test", "t_created": None, "sequence_from": "Genesis_2026-03-06"})
        memory.measure = AsyncMock(return_value={"source": "TF", "target": "E", "measurement_type": "actualized", "measured_at": None})
        memory.time_travel = AsyncMock(return_value=[])
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_namespace_tool_prefixes(self, mock_memory):
        """Test that tools are correctly prefixed with namespace."""
        # Test with namespace
        namespaced_server = create_mcp_server(mock_memory, namespace="test-ns")
        tools = await namespaced_server.get_tools()

        expected_tools = [
            # Process tools
            "test-ns-navigate_genesis",
            "test-ns-open_envisioning",
            "test-ns-advance_frame",
            "test-ns-measure",
            "test-ns-time_travel",
            # Experience tools
            "test-ns-create_entities",
            "test-ns-create_relations",
            "test-ns-delete_entities",
            "test-ns-delete_relations",
            # Query tools
            "test-ns-search_memories",
            "test-ns-find_memories_by_name",
            # Taxonomy tools
            "test-ns-list_allowed_types",
            "test-ns-list_allowed_relation_types",
            # Infrastructure tools
            "test-ns-get_neo4j_schema",
            "test-ns-read_neo4j_cypher",
            "test-ns-gds_create_projection",
            "test-ns-gds_drop_projection",
            "test-ns-gds_pagerank",
            "test-ns-gds_louvain",
            "test-ns-gds_wcc",
        ]

        for expected_tool in expected_tools:
            assert expected_tool in tools.keys(), f"Tool {expected_tool} not found in tools"

        # Test without namespace (default tools)
        default_server = create_mcp_server(mock_memory)
        default_tools = await default_server.get_tools()

        expected_default_tools = [
            "navigate_genesis",
            "open_envisioning",
            "advance_frame",
            "measure",
            "time_travel",
            "create_entities",
            "create_relations",
            "delete_entities",
            "delete_relations",
            "search_memories",
            "find_memories_by_name",
            "list_allowed_types",
            "list_allowed_relation_types",
            "get_neo4j_schema",
            "read_neo4j_cypher",
            "gds_create_projection",
            "gds_drop_projection",
            "gds_pagerank",
            "gds_louvain",
            "gds_wcc",
        ]

        for expected_tool in expected_default_tools:
            assert expected_tool in default_tools.keys(), f"Default tool {expected_tool} not found"

    @pytest.mark.asyncio
    async def test_namespace_tool_functionality(self, mock_memory):
        """Test that namespaced tools function correctly."""
        namespaced_server = create_mcp_server(mock_memory, namespace="test")
        tools = await namespaced_server.get_tools()

        # Test that a namespaced tool exists and works
        search_tool = tools.get("test-search_memories")
        assert search_tool is not None

        # Call the tool function and verify it works
        result = await search_tool.fn(query="test", limit=10)
        mock_memory.search_memories.assert_called_once()

    @pytest.mark.asyncio
    async def test_multiple_namespace_isolation(self, mock_memory):
        """Test that different namespaces create isolated tool sets."""
        server_a = create_mcp_server(mock_memory, namespace="app-a")
        server_b = create_mcp_server(mock_memory, namespace="app-b")

        tools_a = await server_a.get_tools()
        tools_b = await server_b.get_tools()

        assert "app-a-search_memories" in tools_a.keys()
        assert "app-a-search_memories" not in tools_b.keys()

        assert "app-b-search_memories" in tools_b.keys()
        assert "app-b-search_memories" not in tools_a.keys()

        assert len(tools_a) == len(tools_b)

    @pytest.mark.asyncio
    async def test_namespace_hyphen_handling(self, mock_memory):
        """Test namespace hyphen handling edge cases."""
        server_with_hyphen = create_mcp_server(mock_memory, namespace="myapp-")
        tools_with_hyphen = await server_with_hyphen.get_tools()
        assert "myapp-search_memories" in tools_with_hyphen.keys()

        server_without_hyphen = create_mcp_server(mock_memory, namespace="myapp")
        tools_without_hyphen = await server_without_hyphen.get_tools()
        assert "myapp-search_memories" in tools_without_hyphen.keys()

        assert set(tools_with_hyphen.keys()) == set(tools_without_hyphen.keys())

    @pytest.mark.asyncio
    async def test_complex_namespace_names(self, mock_memory):
        """Test complex namespace naming scenarios."""
        complex_namespaces = [
            "company.product",
            "app_v2",
            "client-123",
            "test.env.staging"
        ]

        for namespace in complex_namespaces:
            server = create_mcp_server(mock_memory, namespace=namespace)
            tools = await server.get_tools()

            expected_tool = f"{namespace}-search_memories"
            assert expected_tool in tools.keys(), f"Tool {expected_tool} not found for namespace '{namespace}'"

    @pytest.mark.asyncio
    async def test_namespace_tool_count_consistency(self, mock_memory):
        """Test that namespaced and default servers have the same number of tools."""
        default_server = create_mcp_server(mock_memory)
        namespaced_server = create_mcp_server(mock_memory, namespace="test")

        default_tools = await default_server.get_tools()
        namespaced_tools = await namespaced_server.get_tools()

        assert len(default_tools) == len(namespaced_tools)

        # 20 tools: 5 process + 4 experience + 2 query + 2 taxonomy + 7 infrastructure
        assert len(default_tools) == 20
        assert len(namespaced_tools) == 20


class TestEntityTypeValidation:
    """Test that the EntityType enum properly constrains entity types."""

    def test_valid_entity_type_accepted(self):
        """Test that a valid EntityType value is accepted by Entity model."""
        entity = Entity(
            name="Test Entity",
            type="Technical",
            description="This is a test",
        )
        assert entity.type == EntityType.TECHNICAL
        assert entity.type.value == "Technical"

    def test_invalid_entity_type_rejected(self):
        """Test that an invalid type string is rejected by Entity model."""
        with pytest.raises(ValidationError) as exc_info:
            Entity(
                name="Bad Entity",
                type="Consciousness_Theory",
                description="Should fail",
            )
        assert "type" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        """Test that every EntityType enum value is accepted."""
        for entity_type in EntityType:
            entity = Entity(
                name=f"Test {entity_type.value}",
                type=entity_type.value,
                description="Testing",
            )
            assert entity.type == entity_type

    def test_entity_type_enum_has_21_members(self):
        """Test that the EntityType enum has exactly 21 members."""
        assert len(EntityType) == 21

    def test_case_sensitive_rejection(self):
        """Test that type matching is case-sensitive (lowercase 'technical' rejected)."""
        with pytest.raises(ValidationError):
            Entity(
                name="Case Test",
                type="technical",
                description="Should fail",
            )

    def test_entity_description_field(self):
        """Test that Entity uses description instead of observations."""
        entity = Entity(
            name="Test",
            type="Insight",
            description="An important insight about consciousness",
        )
        assert entity.description == "An important insight about consciousness"
        assert not hasattr(entity, 'observations') or 'observations' not in entity.model_fields

    def test_entity_description_defaults_empty(self):
        """Test that description defaults to empty string."""
        entity = Entity(name="Test", type="Technical")
        assert entity.description == ""


class TestProcessTypeGuards:
    """Test that process types are properly guarded."""

    def test_process_types_set(self):
        """Test PROCESS_TYPES contains exactly the 3 process types."""
        assert PROCESS_TYPES == {EntityType.GENESIS, EntityType.ENVISIONING, EntityType.TEMPORAL_FRAME}
        assert len(PROCESS_TYPES) == 3

    def test_process_edges_set(self):
        """Test PROCESS_EDGES contains exactly the 4 process edges."""
        assert PROCESS_EDGES == {RelationType.OPENING, RelationType.SEQUENCE, RelationType.MEASUREMENT, RelationType.NEXT_DAY}
        assert len(PROCESS_EDGES) == 4

    def test_create_entities_rejects_process_types(self):
        """Test that Entity model accepts process types at model level (rejection is in Neo4jMemory.create_entities)."""
        # The Entity model itself accepts all types — the guard is in the data layer
        for process_type in PROCESS_TYPES:
            entity = Entity(name=f"Test {process_type.value}", type=process_type.value)
            assert entity.type == process_type

    def test_create_relations_rejects_process_edges(self):
        """Test that Relation model accepts process edges at model level (rejection is in Neo4jMemory.create_relations)."""
        for process_edge in PROCESS_EDGES:
            relation = Relation(source="A", target="B", relationType=process_edge.value)
            assert relation.relationType == process_edge


class TestMeasurementType:
    """Test the MeasurementType enum."""

    def test_measurement_type_values(self):
        """Test MeasurementType has exactly 3 values."""
        assert len(MeasurementType) == 3
        assert MeasurementType.ACTUALIZED.value == "actualized"
        assert MeasurementType.RELEASED.value == "released"
        assert MeasurementType.EVOLVED.value == "evolved"

    def test_measurement_type_from_string(self):
        """Test MeasurementType can be created from string."""
        assert MeasurementType("actualized") == MeasurementType.ACTUALIZED
        assert MeasurementType("released") == MeasurementType.RELEASED
        assert MeasurementType("evolved") == MeasurementType.EVOLVED

    def test_invalid_measurement_type_rejected(self):
        """Test that invalid measurement type strings are rejected."""
        with pytest.raises(ValueError):
            MeasurementType("completed")


class TestListAllowedTypes:
    """Test the list_allowed_types tool."""

    @pytest.fixture
    def mock_memory(self):
        memory = Mock(spec=Neo4jMemory)
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_list_allowed_types_returns_all_types(self, mock_memory):
        """Test that list_allowed_types returns all 21 types."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")
        assert tool is not None

        result = await tool.fn()
        import json
        text = result.content[0].text
        data = json.loads(text)

        assert data["total_types"] == 21

        # Collect all types across categories
        all_types = set()
        for category in data["categories"].values():
            all_types.update(category["types"].keys())

        assert len(all_types) == 21

        for entity_type in EntityType:
            assert entity_type.value in all_types, f"{entity_type.value} missing from list_allowed_types"

    @pytest.mark.asyncio
    async def test_list_allowed_types_has_descriptions(self, mock_memory):
        """Test that every type has a non-empty description."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        for category in data["categories"].values():
            for type_name, description in category["types"].items():
                assert isinstance(description, str) and len(description) > 0, \
                    f"Type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_allowed_types_categories(self, mock_memory):
        """Test that types are organized into Process/Experience layers."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        expected_categories = {"process", "experience"}
        assert set(data["categories"].keys()) == expected_categories

        # Process: 3, Experience: 18
        assert len(data["categories"]["process"]["types"]) == 3
        assert len(data["categories"]["experience"]["types"]) == 18


class TestRelationTypeValidation:
    """Test that the RelationType enum properly constrains relation types."""

    def test_valid_relation_type_accepted(self):
        """Test that a valid RelationType value is accepted by Relation model."""
        relation = Relation(
            source="Node A",
            target="Node B",
            relationType="INFORMING",
        )
        assert relation.relationType == RelationType.INFORMING
        assert relation.relationType.value == "INFORMING"

    def test_invalid_relation_type_rejected(self):
        """Test that an invalid type string is rejected by Relation model."""
        with pytest.raises(ValidationError) as exc_info:
            Relation(
                source="Node A",
                target="Node B",
                relationType="WORKS_AT",
            )
        assert "relationType" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        """Test that every RelationType enum value is accepted."""
        for rel_type in RelationType:
            relation = Relation(
                source=f"Source {rel_type.value}",
                target=f"Target {rel_type.value}",
                relationType=rel_type.value,
            )
            assert relation.relationType == rel_type

    def test_relation_type_enum_has_16_members(self):
        """Test that the RelationType enum has exactly 16 members."""
        assert len(RelationType) == 16

    def test_case_sensitive_rejection(self):
        """Test that type matching is case-sensitive (lowercase 'informing' rejected)."""
        with pytest.raises(ValidationError):
            Relation(
                source="Node A",
                target="Node B",
                relationType="informing",
            )


class TestListAllowedRelationTypes:
    """Test the list_allowed_relation_types tool."""

    @pytest.fixture
    def mock_memory(self):
        memory = Mock(spec=Neo4jMemory)
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_returns_all_types(self, mock_memory):
        """Test that list_allowed_relation_types returns all 16 types."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")
        assert tool is not None

        result = await tool.fn()
        import json
        text = result.content[0].text
        data = json.loads(text)

        assert data["total_types"] == 16

        # Collect all types across layers
        all_types = set()
        # Process types
        all_types.update(data["layers"]["process"]["types"].keys())
        # Experience types from subcategories
        for subcat in data["layers"]["experience"]["subcategories"].values():
            all_types.update(subcat["types"].keys())

        assert len(all_types) == 16

        for rel_type in RelationType:
            assert rel_type.value in all_types, f"{rel_type.value} missing from list_allowed_relation_types"

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_has_descriptions(self, mock_memory):
        """Test that every type has a non-empty description."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        # Check process types
        for type_name, description in data["layers"]["process"]["types"].items():
            assert isinstance(description, str) and len(description) > 0, \
                f"Relation type {type_name} has empty or missing description"

        # Check experience types
        for subcat in data["layers"]["experience"]["subcategories"].values():
            for type_name, description in subcat["types"].items():
                assert isinstance(description, str) and len(description) > 0, \
                    f"Relation type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_layers(self, mock_memory):
        """Test that types are organized into Process/Experience layers."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        expected_layers = {"process", "experience"}
        assert set(data["layers"].keys()) == expected_layers

        # Process: 4 types
        assert len(data["layers"]["process"]["types"]) == 4
        # Experience: 6 subcategories with 2 types each = 12
        assert len(data["layers"]["experience"]["subcategories"]) == 6


class TestTemporalFields:
    """Test that bi-temporal metadata fields work correctly on models."""

    def test_entity_accepts_temporal_fields(self):
        """Test Entity model accepts t_created and t_valid as optional strings."""
        entity = Entity(
            name="Test Entity",
            type="Technical",
            description="A fact",
            t_created="2026-03-04T10:00:00Z",
            t_valid="2026-03-01T00:00:00Z",
        )
        assert entity.t_created == "2026-03-04T10:00:00Z"
        assert entity.t_valid == "2026-03-01T00:00:00Z"

    def test_entity_temporal_fields_default_none(self):
        """Test Entity model works without temporal fields (backward compat)."""
        entity = Entity(
            name="Old Entity",
            type="Personal",
            description="Still works",
        )
        assert entity.t_created is None
        assert entity.t_valid is None

    def test_entity_partial_temporal_fields(self):
        """Test Entity with only t_valid provided (no t_created)."""
        entity = Entity(
            name="Partial",
            type="Insight",
            description="Some insight",
            t_valid="2026-01-15T12:00:00Z",
        )
        assert entity.t_created is None
        assert entity.t_valid == "2026-01-15T12:00:00Z"

    def test_relation_accepts_temporal_fields(self):
        """Test Relation model accepts t_created and t_valid."""
        relation = Relation(
            source="A",
            target="B",
            relationType="INFORMING",
            t_created="2026-03-04T10:00:00Z",
            t_valid="2026-03-01T00:00:00Z",
        )
        assert relation.t_created == "2026-03-04T10:00:00Z"
        assert relation.t_valid == "2026-03-01T00:00:00Z"

    def test_relation_temporal_fields_default_none(self):
        """Test Relation model works without temporal fields (backward compat)."""
        relation = Relation(
            source="A",
            target="B",
            relationType="ENABLING",
        )
        assert relation.t_created is None
        assert relation.t_valid is None

    def test_relation_no_expired_or_invalid_fields(self):
        """Test Relation model does NOT have t_expired/t_invalid.

        Consciousness doesn't invalidate relationships — understanding shifts
        are captured by EVOLUTION edges, not invalidation timestamps.
        """
        relation = Relation(
            source="A",
            target="B",
            relationType="ENABLING",
        )
        assert not hasattr(relation, 't_expired') or 't_expired' not in relation.model_fields
        assert not hasattr(relation, 't_invalid') or 't_invalid' not in relation.model_fields
