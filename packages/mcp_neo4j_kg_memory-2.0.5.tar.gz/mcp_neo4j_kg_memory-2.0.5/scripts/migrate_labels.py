#!/usr/bin/env python3
"""One-time migration: collapse 322 freeform node labels → 20 EntityType labels.

Usage:
    python scripts/migrate_labels.py --dry-run   # preview changes
    python scripts/migrate_labels.py              # execute migration

Reads NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE from env vars.
"""

import argparse
import os
import re
import sys
from collections import defaultdict

from dotenv import load_dotenv
from neo4j import GraphDatabase

# Load .env file from project root (or cwd)
load_dotenv()


# ── Target taxonomy (20 labels) ──────────────────────────────────────────

VALID_LABELS = {
    "DailyContext", "Envisioning", "Reflection",
    "Technical", "Scientific", "Theoretical", "Philosophical",
    "Historical", "Social", "Strategic", "Personal",
    "Project", "Insight", "Pattern", "Challenge", "Solution", "Lesson",
    "GraphRegistry", "Reference", "Milestone",
}


# ── Explicit overrides ───────────────────────────────────────────────────
# These take priority over keyword rules. Add entries here for types that
# the keyword classifier gets wrong or that are genuinely ambiguous.

EXPLICIT_MAP: dict[str, str] = {
    # Already correct
    "DailyContext": "DailyContext",
    "Insight": "Insight",
    "Challenge": "Challenge",
    "Milestone": "Milestone",
    "Project": "Project",

    # Structural
    "DailyEnvisioning": "Envisioning",
    "Future_State_Vision": "Envisioning",
    "Vision": "Envisioning",
    "MentalClearing": "Reflection",
    "AffectiveObservation": "Reflection",
    "AffectiveTransformation": "Reflection",
    "AffectiveState": "Reflection",
    "AffectiveExperience": "Reflection",
    "PersonalPhenomenology": "Reflection",
    "Phenomenological_Experience": "Reflection",
    "Phenomenological_Data": "Reflection",
    "Phenomenological_Insight": "Reflection",
    "Experiential_Documentation": "Reflection",
    "ExistentialCondition": "Reflection",

    # Knowledge Domains — disambiguation
    "Consciousness_Theory": "Theoretical",
    "Consciousness_Mechanism": "Theoretical",
    "Consciousness_Principle": "Theoretical",
    "ConsciousnessPhysics": "Theoretical",
    "ConsciousnessLaw": "Theoretical",
    "Consciousness_Phenomenon": "Theoretical",
    "Consciousness_Insight": "Insight",
    "Consciousness_Breakthrough": "Insight",
    "ConsciousnessEvolution": "Philosophical",
    "ConsciousnessValidation": "Scientific",
    "Consciousness_Framework_Validation": "Scientific",
    "Consciousness_Milestone": "Milestone",

    "Ontological_Breakthrough": "Theoretical",
    "Ontological_Convergence": "Theoretical",
    "Ontological_Insight": "Theoretical",
    "Ontological_Framework": "Theoretical",
    "Epistemological_Discovery": "Theoretical",
    "Epistemological_Principle": "Theoretical",
    "Epistemological_Substrate": "Theoretical",
    "Epistemological_Warning": "Lesson",
    "EpistemologicalPrinciple": "Theoretical",

    "Economic_Ontology": "Social",
    "EconomicCondition": "Social",
    "EconomicFoundation": "Social",
    "MonetaryPolicy": "Social",
    "SocialCondition": "Social",
    "SocialStructure": "Social",
    "SocietalStructure": "Social",
    "SociologicalSubstrate": "Social",
    "PolicyResponse": "Social",
    "PoliticalStructure": "Social",
    "InstitutionalAnalysis": "Social",
    "JudicialAnalysis": "Social",
    "LegislativeAnalysis": "Social",
    "ComparativeAssessment": "Social",
    "ComparativeAnalysis": "Social",
    "ComprehensiveAnalysis": "Social",
    "Organizational_Dynamics_Pattern": "Social",
    "Civilizational_Framework": "Social",

    "PhysiologicalSubstrate": "Scientific",
    "PsychologicalSubstrate": "Scientific",
    "CognitiveSubstrate": "Scientific",

    # Explicit activity type overrides
    "ActiveProject": "Project",
    "PendingTask": "Project",
    "Prototype": "Project",
    "ProjectDesign": "Project",
    "NextJS_Project": "Project",
    "Technical_Initiative": "Project",

    "ArchitecturalInsight": "Insight",
    "TechnicalInsight": "Insight",
    "StrategicInsight": "Insight",
    "MetaCognitiveInsight": "Insight",
    "PhilosophicalInsight": "Insight",
    "Methodological_Insight": "Insight",
    "Fundamental_Insight": "Insight",
    "Critical_Insight": "Insight",
    "Infrastructure_Insight": "Insight",
    "Philosophical_Insight": "Insight",
    "TechnicalChallenge": "Challenge",
    "Technical_Challenge": "Challenge",
    "Philosophical_Challenge": "Challenge",
    "Architectural_Challenge": "Challenge",
    "Technical_Blocker": "Challenge",
    "Technical_Constraint": "Challenge",
    "Fundamental_Barrier": "Challenge",
    "Platform_Limitation": "Challenge",
    "Component_Architecture_Issue": "Challenge",
    "MCP_Connectivity_Issue": "Challenge",
    "System_Behavior_Issue": "Challenge",
    "Critical_Version_Issue": "Challenge",
    "Platform_Dependency_Issue": "Challenge",
    "Process_Failure": "Challenge",

    "TechnicalSolution": "Solution",
    "Implementation_Success": "Solution",
    "Working_Solution": "Solution",
    "Solution_Success": "Solution",
    "Solution_Pattern": "Solution",
    "Solution_Attempt": "Solution",
    "Infrastructure_Success": "Solution",
    "Configuration_Success": "Solution",
    "Implementation_Fix": "Solution",
    "Critical_Fix": "Solution",
    "Configuration_Fix": "Solution",
    "Configuration_Error_Resolution": "Solution",
    "Authentication_Migration_Fix": "Solution",
    "Type_Interface_Fix": "Solution",
    "Component_Interface_Fix": "Solution",

    "Lesson_Learned": "Lesson",
    "LessonLearned": "Lesson",
    "Critical_Lesson": "Lesson",
    "Infrastructure_Lesson": "Lesson",
    "Critical_Syntax_Rule": "Lesson",
    "Implementation_Gotcha": "Lesson",
    "Syntax_Gotcha": "Lesson",
    "Implementation_Rule": "Lesson",
    "BreakingChange": "Lesson",

    # Meta
    "Tool_Usage_Rules": "GraphRegistry",
    "Query_Template": "GraphRegistry",
    "Query_Templates": "GraphRegistry",
    "Search_Simulation": "GraphRegistry",
    "Memory_Integration_Procedure": "GraphRegistry",
    "Prompt_Templates": "GraphRegistry",
    "Usage_Examples": "GraphRegistry",
    "Code_Templates": "GraphRegistry",

    "Person": "Reference",
    "Media_Contact": "Reference",
    "DataSource": "Reference",
    "Platform": "Reference",
    "Tool": "Reference",
    "Technology": "Reference",
    "Research_Tool": "Reference",
    "PersonalityProfile": "Personal",
    "Test_Entity": "Reference",

    "HistoricalMilestone": "Milestone",
    "CrisisEvent": "Milestone",
    "Critical_Incident": "Milestone",
    "Enterprise_Discovery": "Milestone",
    "Enterprise_Discovery_Event": "Milestone",

    # Historical
    "HistoricalAnalysis": "Historical",
    "HistoricalPhenomenon": "Historical",
    "Historical_Infrastructure": "Historical",

    # Strategic
    "Implementation_Strategy": "Strategic",
    "Strategic_Framework": "Strategic",
    "Strategic_Decision": "Strategic",
    "Business_Framework": "Strategic",
    "Business_Strategy": "Strategic",
    "Business_Intelligence_Pattern": "Strategic",
    "Communication_Strategy": "Strategic",
    "CommunicationStrategy": "Strategic",
    "Media_Strategy_Analysis": "Strategic",
    "Media_Engagement": "Strategic",
    "Conference_Submission": "Strategic",
    "Risk_Analysis": "Strategic",
    "Decision_Logic": "Strategic",
    "Research_Strategy": "Strategic",
    "Operational_Framework": "Strategic",

    # Patterns
    "DesignPattern": "Pattern",
    "Design_Pattern": "Pattern",
    "SystemicPattern": "Pattern",
    "ArchitecturalPattern": "Pattern",
    "Architectural_Pattern": "Pattern",
    "Architecture_Pattern": "Pattern",
    "Technical_Pattern": "Pattern",
    "Implementation_Pattern": "Pattern",
    "Recurring_Pattern": "Pattern",
    "Meta_Pattern": "Pattern",
    "Critical_Bug_Pattern": "Pattern",
    "Configuration_Error_Pattern": "Pattern",
    "Code_Bug_Pattern": "Pattern",
    "Code_Error_Pattern": "Pattern",
    "Code_Warning_Pattern": "Pattern",
    "Code_Optimization_Pattern": "Pattern",
    "Critical_Error_Pattern": "Pattern",
    "Security_Vulnerability_Pattern": "Pattern",
    "Security_Pattern": "Pattern",
    "Integration_Pattern": "Pattern",
    "Interface_Pattern": "Pattern",
    "Refactoring_Pattern": "Pattern",
    "Configuration_Pattern": "Pattern",
    "Platform_Integration_Pattern": "Pattern",
    "Access_Control_Pattern": "Pattern",
    "Authentication_Pattern": "Pattern",
    "UI_Design_Pattern": "Pattern",

    # Scientific
    "Empirical_Validation": "Scientific",
    "Empirical_Evidence": "Scientific",
    "Empirical_Observation": "Scientific",
    "Empirical_Event": "Scientific",
    "Empirical_Research": "Scientific",
    "EmpiricalResearch": "Scientific",
    "External_Validation": "Scientific",
    "Paradigm_Validation": "Scientific",
    "MethodologicalValidation": "Scientific",
    "Research_Methodology": "Scientific",
    "Research_Finding": "Scientific",
    "Research_Agenda": "Scientific",
    "Research": "Scientific",
    "Literature_Review": "Scientific",
    "Methodology": "Scientific",
    "ScientificKnowledge": "Scientific",
    "ResearchInsights": "Scientific",
    "Behavioral_Analysis": "Scientific",
    "Revolutionary_Methodology": "Scientific",
    "Investigation": "Scientific",

    # Theoretical
    "TheoreticalFramework": "Theoretical",
    "Theoretical_Framework": "Theoretical",
    "theoretical_framework": "Theoretical",
    "Meta_Framework": "Theoretical",
    "Framework_Principle": "Theoretical",
    "TheoreticalConcept": "Theoretical",
    "TheoreticalMechanism": "Theoretical",
    "TheoreticalProblem": "Theoretical",
    "TheoreticalBreakthrough": "Theoretical",
    "Theoretical_Breakthrough": "Theoretical",
    "Theoretical_Cluster": "Theoretical",
    "FundamentalTheory": "Theoretical",
    "FundamentalPrinciple": "Theoretical",
    "FirstPrinciple": "Theoretical",
    "Core_Principle": "Theoretical",
    "Principle": "Theoretical",
    "GroundingFramework": "Theoretical",
    "Preliminary_Theory": "Theoretical",
    "Predictive_Framework": "Theoretical",
    "Mental_Model": "Theoretical",
    "Paradigm_Shift": "Theoretical",
    "Paradigm_Analysis": "Theoretical",
    "AI_Framework": "Theoretical",
    "Structural_Analysis": "Theoretical",
    "Framework_Development": "Theoretical",
    "Framework_Correction": "Theoretical",
    "Concept": "Theoretical",
    "Semantic_Concept": "Theoretical",
    "Cross_Cutting_Knowledge": "Theoretical",
    "Knowledge": "Theoretical",
    "Catalyst": "Theoretical",
    "Fundamental_Laws": "Theoretical",
    "Process_Model": "Theoretical",
    "Core_Process": "Theoretical",
    "Methodological_Framework": "Theoretical",
    "Analysis_Framework": "Theoretical",
    "Development_Framework": "Theoretical",
    "Textual_Analysis": "Theoretical",

    # Philosophical
    "Philosophical_Framework": "Philosophical",
    "Design_Philosophy": "Philosophical",
    "DesignPhilosophy": "Philosophical",
    "Philosophical_Foundation": "Philosophical",
    "PhilosophicalPrinciple": "Philosophical",
    "EthicalInsight": "Philosophical",
    "EthicalPractice": "Philosophical",
    "Ethics": "Philosophical",
    "Personal_Philosophy": "Philosophical",
    "Development_Philosophy": "Philosophical",
    "Technical_Philosophy": "Philosophical",
    "Reflexive_Knowledge": "Philosophical",

    # Personal
    "Applied_Analysis": "Personal",

    # Technical (catch-alls for remaining technical types)
    "Technical_Knowledge_Domain": "Technical",
    "Code_Template": "Technical",
    "Implementation_Procedure": "Technical",
    "Troubleshooting_Knowledge": "Technical",
    "Configuration_Procedure": "Technical",
    "Configuration": "Technical",
    "System_Component": "Technical",
    "Platform_Configuration_Difference": "Technical",
    "System_Design": "Technical",
    "Architecture_Design": "Technical",
    "Architecture_Decision": "Technical",
    "Architecture": "Technical",
    "Technical_Architecture": "Technical",
    "System_Architecture": "Technical",
    "Technical_Framework": "Technical",
    "Technical_Knowledge": "Technical",
    "InfrastructureComponent": "Technical",
    "DebuggingInfrastructure": "Technical",
    "Infrastructure": "Technical",
    "Integration": "Technical",
    "Implementation_Status": "Technical",
    "Implementation_Demo": "Technical",
    "Implementation_Manual": "Technical",
    "Technology_Stack": "Technical",
    "Development_Optimization": "Technical",
    "Implementation_Methodology": "Technical",
    "Critical_Debugging_Discovery": "Technical",
    "Debugging_Methodology": "Technical",
    "Error_Investigation": "Technical",
    "Fault_Tolerance_System": "Technical",
    "Monitoring_Implementation": "Technical",
    "Architecture_Analysis_Methodology": "Technical",
    "IDE_Configuration": "Technical",
    "Database_Schema": "Technical",
    "Analysis_Technique": "Technical",
    "Troubleshooting_Session": "Technical",
    "InfrastructureConfig": "Technical",
    "Technical_Update": "Technical",
    "Network_Architecture": "Technical",
    "Documentation_Methodology": "Technical",
    "Revolutionary_Technology": "Technical",
    "Technical_Breakthrough": "Technical",
    "TechnicalBreakthrough": "Technical",
    "Security_Design": "Technical",
    "SSL_Configuration": "Technical",
    "Development_Environment_Setup": "Technical",
    "Technology_Evaluation": "Technical",
    "Critical_Error": "Technical",
    "Error": "Technical",
    "Technical_Session": "Technical",
    "OperatingPrinciple": "Technical",
    "Operational_Procedure": "Technical",
    "Refactoring_Methodology": "Technical",
    "Framework_Evolution": "Technical",
    "Migration_Analysis": "Technical",
    "Discovery": "Insight",

    # Null type fallback
    None: "Reference",
}


# ── Keyword-based fallback classifier ────────────────────────────────────
# Order matters: first match wins. More specific patterns come first.

KEYWORD_RULES: list[tuple[str, str]] = [
    # Activity types (check before domains)
    (r"(?i)(project|initiative|prototype|pending.?task)", "Project"),
    (r"(?i)(insight|breakthrough|discovery|realization)", "Insight"),
    (r"(?i)(pattern|template|anti.?pattern|recurring)", "Pattern"),
    (r"(?i)(challenge|blocker|bug|failure|constraint|limitation|barrier|issue|error)", "Challenge"),
    (r"(?i)(solution|success|fix|resolution|workaround)", "Solution"),
    (r"(?i)(lesson|gotcha|warning|critical.?rule|breaking.?change)", "Lesson"),

    # Meta
    (r"(?i)(graph.?registry|tool.?usage|query.?template|search.?sim|prompt|usage.?example)", "GraphRegistry"),
    (r"(?i)(reference|data.?source|person|contact|platform$|tool$)", "Reference"),
    (r"(?i)(milestone|crisis|landmark|turning.?point|critical.?incident)", "Milestone"),

    # Structural
    (r"(?i)(daily.?context|session.?summary)", "DailyContext"),
    (r"(?i)(envisioning|vision|future.?state|goal)", "Envisioning"),
    (r"(?i)(reflection|mental.?clearing|affective|phenomenolog|experiential|existential)", "Reflection"),

    # Knowledge domains (broader patterns last)
    (r"(?i)(strategic|strategy|business|media|communication|positioning|decision|risk.?analysis)", "Strategic"),
    (r"(?i)(personal|self.?knowledge|personality|cognitive.?pattern|preference)", "Personal"),
    (r"(?i)(histor|timeline|precedent|institutional.?memory|crisis.?event)", "Historical"),
    (r"(?i)(social|politic|economic|cultur|institution|organization|group.?dynamic|sociolog|monetary|legislative|judicial|civic)", "Social"),
    (r"(?i)(philosoph|consciousness(?!.*(valid|frame.*valid))|meaning|ontolog|epistemolog|ethic|phenomeno)", "Philosophical"),
    (r"(?i)(scientific|empiric|research|valid|methodolog|experiment|measurement|data)", "Scientific"),
    (r"(?i)(theor|framework|model|paradigm|abstract|formal|concept|principle|structure|meta.?frame|fundamental)", "Theoretical"),
    (r"(?i)(technic|engineer|code|architect|debug|config|infra|platform|implement|system|security|database|network|ssl|deploy|docker|ci.?cd|api)", "Technical"),
]


def classify_type(old_type: str | None) -> str:
    """Map an old freeform type string to one of the 20 canonical labels."""
    # 1. Check explicit map first
    if old_type in EXPLICIT_MAP:
        return EXPLICIT_MAP[old_type]

    # 2. Already a valid label?
    if old_type in VALID_LABELS:
        return old_type

    # 3. Keyword rules
    if old_type is not None:
        for regex, new_label in KEYWORD_RULES:
            if re.search(regex, old_type):
                return new_label

    # 4. Fallback
    return "Reference"


def get_all_types(driver, database: str) -> list[dict]:
    """Query all distinct type values with their counts."""
    with driver.session(database=database) as session:
        result = session.run(
            "MATCH (n:Memory) RETURN n.type AS type, count(n) AS count ORDER BY count DESC"
        )
        return [{"type": record["type"], "count": record["count"]} for record in result]


def migrate(driver, database: str, old_type: str | None, new_type: str, dry_run: bool) -> int:
    """Migrate nodes from old_type to new_type. Returns count of affected nodes."""
    if dry_run:
        with driver.session(database=database) as session:
            if old_type is None:
                result = session.run(
                    "MATCH (n:Memory) WHERE n.type IS NULL RETURN count(n) AS count"
                )
            else:
                result = session.run(
                    "MATCH (n:Memory) WHERE n.type = $old_type RETURN count(n) AS count",
                    old_type=old_type,
                )
            return result.single()["count"]

    with driver.session(database=database) as session:
        if old_type is None:
            # Handle null type
            result = session.run(
                f"""
                MATCH (n:Memory) WHERE n.type IS NULL
                SET n.type = $new_type
                SET n:`{new_type}`
                RETURN count(n) AS migrated
                """,
                new_type=new_type,
            )
        elif old_type == new_type:
            # Type is already correct, just ensure label exists
            result = session.run(
                f"""
                MATCH (n:Memory) WHERE n.type = $old_type
                SET n:`{new_type}`
                RETURN count(n) AS migrated
                """,
                old_type=old_type,
            )
        else:
            # Full migration: update type, remove old label, add new label
            result = session.run(
                f"""
                MATCH (n:Memory) WHERE n.type = $old_type
                SET n.type = $new_type
                REMOVE n:`{old_type}`
                SET n:`{new_type}`
                RETURN count(n) AS migrated
                """,
                old_type=old_type,
                new_type=new_type,
            )
        return result.single()["migrated"]


def main():
    parser = argparse.ArgumentParser(description="Migrate knowledge graph labels to 20 canonical types")
    parser.add_argument("--dry-run", action="store_true", help="Preview migration without making changes")
    parser.add_argument("--uri", default=None, help="Neo4j URI (or NEO4J_URI env var)")
    parser.add_argument("--username", default=None, help="Neo4j username (or NEO4J_USERNAME env var)")
    parser.add_argument("--password", default=None, help="Neo4j password (or NEO4J_PASSWORD env var)")
    parser.add_argument("--database", default=None, help="Neo4j database (or NEO4J_DATABASE env var)")
    args = parser.parse_args()

    uri = args.uri or os.environ.get("NEO4J_URI") or os.environ.get("NEO4J_URL", "bolt://localhost:7687")
    username = args.username or os.environ.get("NEO4J_USERNAME", "neo4j")
    password = args.password or os.environ.get("NEO4J_PASSWORD", "password")
    database = args.database or os.environ.get("NEO4J_DATABASE", "neo4j")

    print(f"{'DRY RUN — ' if args.dry_run else ''}Migrating labels in {uri} / {database}")
    print(f"Target taxonomy: {len(VALID_LABELS)} labels\n")

    driver = GraphDatabase.driver(uri, auth=(username, password))

    try:
        driver.verify_connectivity()
    except Exception as e:
        print(f"ERROR: Cannot connect to Neo4j: {e}", file=sys.stderr)
        sys.exit(1)

    # Get all current types
    all_types = get_all_types(driver, database)
    print(f"Found {len(all_types)} distinct type values across {sum(t['count'] for t in all_types)} nodes\n")

    # Build migration plan
    summary: dict[str, int] = defaultdict(int)
    migrations: list[tuple[str | None, str, int]] = []

    for entry in all_types:
        old_type = entry["type"]
        new_type = classify_type(old_type)
        count = entry["count"]

        if new_type not in VALID_LABELS:
            print(f"  BUG: classify_type('{old_type}') returned '{new_type}' which is not valid!", file=sys.stderr)
            sys.exit(1)

        migrations.append((old_type, new_type, count))
        summary[new_type] += count

    # Print migration plan
    print("─" * 72)
    print(f"{'Old Type':<50} → {'New Type':<20} Count")
    print("─" * 72)

    for old_type, new_type, count in migrations:
        old_display = str(old_type) if old_type is not None else "<NULL>"
        marker = "  " if old_type == new_type else "→ "
        print(f"  {old_display:<48} {marker}{new_type:<20} {count:>4}")

    print("─" * 72)
    print(f"\nSummary by new label:")
    for label in sorted(summary.keys()):
        print(f"  {label:<20} {summary[label]:>4} nodes")
    print(f"  {'TOTAL':<20} {sum(summary.values()):>4} nodes")
    print()

    if args.dry_run:
        print("DRY RUN complete — no changes made.")
        driver.close()
        return

    # Execute migration
    print("Executing migration...")
    total_migrated = 0

    for old_type, new_type, expected_count in migrations:
        migrated = migrate(driver, database, old_type, new_type, dry_run=False)
        total_migrated += migrated
        old_display = str(old_type) if old_type is not None else "<NULL>"
        print(f"  {old_display} → {new_type}: {migrated} nodes")

    print(f"\nMigration complete: {total_migrated} nodes updated.")

    # Verify
    post_types = get_all_types(driver, database)
    print(f"\nPost-migration: {len(post_types)} distinct types")
    for entry in post_types:
        marker = " ✓" if entry["type"] in VALID_LABELS else " ✗ UNEXPECTED"
        print(f"  {entry['type']:<20} {entry['count']:>4}{marker}")

    driver.close()


if __name__ == "__main__":
    main()
