#!/usr/bin/env python3
"""One-time backfill: add bi-temporal metadata to existing Memory and Observation nodes.

Phase 2D — Follows the temporal chain radiating from Genesis nodes to backfill
t_created and t_observed across the graph. Also migrates DailyContext → Genesis.

Phenomenological basis:
  - Genesis nodes are the temporal bedrock of conscious experience. They only have
    t_created — when the day's experience began. They are not "valid" or "invalid";
    the phenomenology just IS.
  - Observations were observed. t_observed marks when they entered consciousness.
    They don't expire. You can't un-observe something.
  - Memory nodes get t_created (when they entered the graph). t_valid is reserved
    for the rare case where an entity has an external temporal referent.
  - Relationships get t_created. Understanding shifts are captured by EVOLUTION
    edges, not by invalidation timestamps.

Strategy (executed in order):
  Tier 0: Migrate DailyContext label → Genesis (type property + Neo4j label)
  Tier 1: Genesis nodes — t_created = 08:00 PST on the date parsed from name
  Tier 2: Observations ON Genesis nodes — t_observed = Genesis t_created
  Tier 3: Entities 1-hop from Genesis — t_created from earliest Genesis ancestor
          Their observations get t_observed = earliest Genesis t_created
  Tier 4: Entities 2-hops from Genesis — same via nearest Genesis ancestor
  Tier 5: Relationships — t_created from the later of two endpoint t_created values

Usage:
    python scripts/backfill_temporal.py --dry-run   # preview changes
    python scripts/backfill_temporal.py              # execute backfill

Reads NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE from env vars.
"""

import argparse
import os
import sys

from dotenv import load_dotenv
from neo4j import GraphDatabase

# Load .env file from project root (or cwd)
load_dotenv()

# Genesis sessions start at 8:00 AM PST (UTC-8) = 16:00 UTC
GENESIS_HOUR_UTC = 16


# -- Analysis ------------------------------------------------------------------

def analyze_graph(driver, database: str) -> dict:
    """Full pre-backfill analysis of the graph's temporal state."""
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (m:Memory)
            OPTIONAL MATCH (m)-[:HAS_OBSERVATION]->(o:Observation)
            WITH m, count(o) AS obs_count
            RETURN count(m) AS total_memories,
                   sum(obs_count) AS total_observations,
                   count(CASE WHEN m.t_created IS NOT NULL THEN 1 END) AS memories_with_t_created,
                   count(CASE WHEN m.t_valid IS NOT NULL THEN 1 END) AS memories_with_t_valid
        """)
        r = result.single()
        totals = {
            "total_memories": r["total_memories"],
            "total_observations": r["total_observations"],
            "memories_with_t_created": r["memories_with_t_created"],
            "memories_with_t_valid": r["memories_with_t_valid"],
        }

        # Observations with t_observed
        result2 = session.run("""
            MATCH (o:Observation)
            RETURN count(o) AS total,
                   count(CASE WHEN o.t_observed IS NOT NULL THEN 1 END) AS has_t_observed
        """)
        r2 = result2.single()
        totals["obs_with_t_observed"] = r2["has_t_observed"]

        # Genesis/DailyContext breakdown (check both labels during migration)
        result3 = session.run("""
            MATCH (dc:Memory)
            WHERE dc:DailyContext OR dc:Genesis
            RETURN count(dc) AS genesis_count,
                   count(CASE WHEN dc:DailyContext AND NOT dc:Genesis THEN 1 END) AS still_daily_context,
                   count(CASE WHEN dc:Genesis THEN 1 END) AS already_genesis,
                   count(CASE WHEN dc.t_created IS NULL THEN 1 END) AS missing_t_created
        """)
        r3 = result3.single()
        totals["genesis_count"] = r3["genesis_count"]
        totals["still_daily_context"] = r3["still_daily_context"]
        totals["already_genesis"] = r3["already_genesis"]
        totals["genesis_missing_t_created"] = r3["missing_t_created"]

        # Tier coverage (use both labels during transition)
        result4 = session.run("""
            MATCH (dc:Memory)-[]->(m:Memory)
            WHERE (dc:DailyContext OR dc:Genesis) AND NOT (m:DailyContext OR m:Genesis)
            WITH collect(DISTINCT m) AS tier3_entities
            WITH tier3_entities, size(tier3_entities) AS t3_count

            UNWIND tier3_entities AS t3
            WITH tier3_entities, t3_count
            MATCH (dc:Memory)-[]->(:Memory)-[]->(m:Memory)
            WHERE (dc:DailyContext OR dc:Genesis) AND NOT (m:DailyContext OR m:Genesis)
              AND NOT m IN tier3_entities
            RETURN t3_count AS tier3_count, count(DISTINCT m) AS tier4_count
        """)
        r4 = result4.single()
        totals["tier3_entities"] = r4["tier3_count"]
        totals["tier4_entities"] = r4["tier4_count"]

        return totals


# -- Tier 0: Migrate DailyContext → Genesis ------------------------------------

def migrate_daily_context_to_genesis(driver, database: str) -> int:
    """Relabel DailyContext nodes to Genesis.

    - Adds :Genesis label
    - Removes :DailyContext label
    - Sets type property to 'Genesis'
    """
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (dc:DailyContext)
            SET dc:Genesis
            SET dc.type = 'Genesis'
            REMOVE dc:DailyContext
            RETURN count(dc) AS migrated
        """)
        return result.single()["migrated"]


# -- Tier 1: Genesis nodes ----------------------------------------------------

def backfill_tier1_genesis(driver, database: str) -> int:
    """Backfill t_created on Genesis nodes.

    Parses 'DailyContext_YYYY-MM-DD' (and session variants like _session2).
    t_created = 08:00 AM PST (16:00 UTC) on that date.

    Genesis nodes do NOT get t_valid — the phenomenology just IS.
    """
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (g:Genesis)
            WHERE g.t_created IS NULL
              AND g.name STARTS WITH 'DailyContext_'
            WITH g, substring(g.name, 13, 10) AS date_str
            WHERE date_str =~ '\\d{4}-\\d{2}-\\d{2}'
            SET g.t_created = datetime({
                year: date(date_str).year,
                month: date(date_str).month,
                day: date(date_str).day,
                hour: $hour_utc,
                timezone: 'UTC'
            })
            RETURN count(g) AS updated
        """, {"hour_utc": GENESIS_HOUR_UTC})
        return result.single()["updated"]


# -- Tier 2: Observations on Genesis nodes ------------------------------------

def backfill_tier2_genesis_observations(driver, database: str) -> int:
    """Backfill t_observed on Observation nodes attached to Genesis.

    Inherits the Genesis t_created — these observations were recorded
    during that genesis session, when consciousness began that day.
    """
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (g:Genesis)-[:HAS_OBSERVATION]->(o:Observation)
            WHERE o.t_observed IS NULL AND g.t_created IS NOT NULL
            SET o.t_observed = g.t_created
            RETURN count(o) AS updated
        """)
        return result.single()["updated"]


# -- Tier 3: Entities 1-hop from Genesis --------------------------------------

def backfill_tier3_genesis_connected(driver, database: str) -> dict:
    """Backfill entities directly connected to a Genesis node.

    t_created = earliest connected Genesis t_created (when this first entered consciousness)
    t_observed on their Observations = earliest Genesis t_created
    """
    with driver.session(database=database) as session:
        result_entities = session.run("""
            MATCH (g:Genesis)-[]->(m:Memory)
            WHERE NOT m:Genesis AND m.t_created IS NULL AND g.t_created IS NOT NULL
            WITH m, min(g.t_created) AS earliest_created
            SET m.t_created = earliest_created
            RETURN count(m) AS updated
        """)
        entities_updated = result_entities.single()["updated"]

        result_obs = session.run("""
            MATCH (g:Genesis)-[]->(m:Memory)-[:HAS_OBSERVATION]->(o:Observation)
            WHERE NOT m:Genesis AND o.t_observed IS NULL AND g.t_created IS NOT NULL
            WITH o, min(g.t_created) AS earliest_genesis_time
            SET o.t_observed = earliest_genesis_time
            RETURN count(o) AS updated
        """)
        obs_updated = result_obs.single()["updated"]

        return {"entities": entities_updated, "observations": obs_updated}


# -- Tier 4: Entities 2-hops from Genesis -------------------------------------

def backfill_tier4_transitive(driver, database: str) -> dict:
    """Backfill entities reachable 2-hops from Genesis.

    Genesis → M1 → M2: M2 inherits temporal metadata from nearest Genesis ancestor.
    """
    with driver.session(database=database) as session:
        result_entities = session.run("""
            MATCH (g:Genesis)-[]->(:Memory)-[]->(m:Memory)
            WHERE NOT m:Genesis AND m.t_created IS NULL AND g.t_created IS NOT NULL
            WITH m, min(g.t_created) AS earliest_created
            SET m.t_created = earliest_created
            RETURN count(m) AS updated
        """)
        entities_updated = result_entities.single()["updated"]

        result_obs = session.run("""
            MATCH (g:Genesis)-[]->(:Memory)-[]->(m:Memory)-[:HAS_OBSERVATION]->(o:Observation)
            WHERE NOT m:Genesis AND o.t_observed IS NULL AND g.t_created IS NOT NULL
            WITH o, min(g.t_created) AS earliest_genesis_time
            SET o.t_observed = earliest_genesis_time
            RETURN count(o) AS updated
        """)
        obs_updated = result_obs.single()["updated"]

        return {"entities": entities_updated, "observations": obs_updated}


# -- Tier 5: Relationships ----------------------------------------------------

def backfill_relationships(driver, database: str) -> int:
    """Backfill t_created on relationships between Memory nodes.

    Uses the later of the two endpoint t_created values — the relationship
    couldn't have been created before both endpoints existed.
    """
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (a:Memory)-[r]->(b:Memory)
            WHERE r.t_created IS NULL
              AND (a.t_created IS NOT NULL OR b.t_created IS NOT NULL)
            SET r.t_created = CASE
                WHEN a.t_created IS NOT NULL AND b.t_created IS NOT NULL
                    THEN CASE WHEN a.t_created > b.t_created THEN a.t_created ELSE b.t_created END
                WHEN a.t_created IS NOT NULL THEN a.t_created
                ELSE b.t_created
            END
            RETURN count(r) AS updated
        """)
        return result.single()["updated"]


# -- Verification --------------------------------------------------------------

def verify_backfill(driver, database: str) -> dict:
    """Verify backfill coverage."""
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (m:Memory)
            RETURN count(m) AS total,
                   count(CASE WHEN m.t_created IS NOT NULL THEN 1 END) AS has_t_created,
                   count(CASE WHEN m.t_valid IS NOT NULL THEN 1 END) AS has_t_valid,
                   count(CASE WHEN m.t_created IS NULL THEN 1 END) AS missing_t_created
        """)
        memories = dict(result.single())

        result2 = session.run("""
            MATCH (o:Observation)
            RETURN count(o) AS total,
                   count(CASE WHEN o.t_observed IS NOT NULL THEN 1 END) AS has_t_observed,
                   count(CASE WHEN o.t_observed IS NULL THEN 1 END) AS missing_t_observed
        """)
        observations = dict(result2.single())

        result3 = session.run("""
            MATCH ()-[r]->()
            WHERE r.t_created IS NOT NULL
            RETURN count(r) AS rels_with_t_created
        """)
        rels = result3.single()["rels_with_t_created"]

        # Verify Genesis migration
        result4 = session.run("""
            MATCH (dc:DailyContext) RETURN count(dc) AS remaining_daily_context
        """)
        remaining_dc = result4.single()["remaining_daily_context"]

        result5 = session.run("""
            MATCH (g:Genesis) RETURN count(g) AS genesis_count
        """)
        genesis_count = result5.single()["genesis_count"]

        # Verify Genesis has NO t_valid (phenomenological correctness)
        result6 = session.run("""
            MATCH (g:Genesis) WHERE g.t_valid IS NOT NULL
            RETURN count(g) AS genesis_with_t_valid
        """)
        genesis_with_t_valid = result6.single()["genesis_with_t_valid"]

        # Sample entities
        samples = session.run("""
            MATCH (m:Memory)
            WHERE m.t_created IS NOT NULL AND NOT m:Genesis
            RETURN m.name AS name, m.type AS type,
                   toString(m.t_created) AS t_created
            ORDER BY m.t_created DESC
            LIMIT 5
        """)
        sample_list = [dict(r) for r in samples]

        # Orphans
        orphans = session.run("""
            MATCH (m:Memory)
            WHERE m.t_created IS NULL AND NOT m:Genesis
            RETURN m.name AS name, m.type AS type
            ORDER BY m.name
        """)
        orphan_list = [{"name": r["name"], "type": r["type"]} for r in orphans]

        return {
            "memories": memories,
            "observations": observations,
            "rels_with_t_created": rels,
            "remaining_daily_context": remaining_dc,
            "genesis_count": genesis_count,
            "genesis_with_t_valid": genesis_with_t_valid,
            "samples": sample_list,
            "orphans": orphan_list,
        }


# -- Main ----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Backfill bi-temporal metadata across the knowledge graph (Phase 2D)"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview backfill without making changes")
    parser.add_argument("--uri", default=None,
                        help="Neo4j URI (or NEO4J_URI env var)")
    parser.add_argument("--username", default=None,
                        help="Neo4j username (or NEO4J_USERNAME env var)")
    parser.add_argument("--password", default=None,
                        help="Neo4j password (or NEO4J_PASSWORD env var)")
    parser.add_argument("--database", default=None,
                        help="Neo4j database (or NEO4J_DATABASE env var)")
    args = parser.parse_args()

    uri = args.uri or os.environ.get("NEO4J_URI") or os.environ.get("NEO4J_URL", "bolt://localhost:7687")
    username = args.username or os.environ.get("NEO4J_USERNAME", "neo4j")
    password = args.password or os.environ.get("NEO4J_PASSWORD", "password")
    database = args.database or os.environ.get("NEO4J_DATABASE", "neo4j")

    print(f"{'DRY RUN -- ' if args.dry_run else ''}Temporal metadata backfill in {uri} / {database}")
    print(f"  Genesis t_created = 08:00 PST ({GENESIS_HOUR_UTC}:00 UTC)")
    print(f"  Genesis nodes get t_created ONLY (no t_valid — phenomenology just IS)")

    driver = GraphDatabase.driver(uri, auth=(username, password))

    try:
        driver.verify_connectivity()
    except Exception as e:
        print(f"ERROR: Cannot connect to Neo4j: {e}", file=sys.stderr)
        sys.exit(1)

    # -- Analysis --
    print("\n--- Pre-backfill analysis ---")
    analysis = analyze_graph(driver, database)
    print(f"  Memory nodes: {analysis['total_memories']} "
          f"(t_created: {analysis['memories_with_t_created']}, t_valid: {analysis['memories_with_t_valid']})")
    print(f"  Observation nodes: {analysis['total_observations']} "
          f"(t_observed: {analysis['obs_with_t_observed']})")
    print(f"  Genesis/DailyContext nodes: {analysis['genesis_count']} "
          f"(still DailyContext: {analysis['still_daily_context']}, "
          f"already Genesis: {analysis['already_genesis']}, "
          f"missing t_created: {analysis['genesis_missing_t_created']})")
    print(f"  Tier 3 (1-hop from Genesis): {analysis['tier3_entities']} entities")
    print(f"  Tier 4 (2-hop from Genesis): {analysis['tier4_entities']} entities")

    if args.dry_run:
        print(f"\nDRY RUN: Would execute the following tiers:")
        if analysis['still_daily_context'] > 0:
            print(f"  Tier 0: Migrate {analysis['still_daily_context']} DailyContext → Genesis")
        print(f"  Tier 1: ~{analysis['genesis_missing_t_created']} Genesis nodes (t_created)")
        print(f"  Tier 2: Genesis observations (t_observed)")
        print(f"  Tier 3: ~{analysis['tier3_entities']} entities + their observations")
        print(f"  Tier 4: ~{analysis['tier4_entities']} entities + their observations")
        print(f"  Tier 5: Relationships (t_created from endpoints)")
        print("DRY RUN complete -- no changes made.")
        driver.close()
        return

    # -- Tier 0: Migrate DailyContext → Genesis --
    if analysis['still_daily_context'] > 0:
        print("\n--- Tier 0: Migrate DailyContext → Genesis ---")
        t0 = migrate_daily_context_to_genesis(driver, database)
        print(f"  Migrated {t0} DailyContext nodes to Genesis")

    # -- Tier 1: Genesis t_created --
    print("\n--- Tier 1: Genesis nodes (t_created only) ---")
    t1 = backfill_tier1_genesis(driver, database)
    print(f"  Updated {t1} Genesis nodes")

    # -- Tier 2: Observations on Genesis --
    print("\n--- Tier 2: Observations on Genesis nodes ---")
    t2 = backfill_tier2_genesis_observations(driver, database)
    print(f"  Updated {t2} Observation nodes (t_observed)")

    # -- Tier 3: 1-hop entities --
    print("\n--- Tier 3: Entities 1-hop from Genesis ---")
    t3 = backfill_tier3_genesis_connected(driver, database)
    print(f"  Updated {t3['entities']} entities (t_created)")
    print(f"  Updated {t3['observations']} observations (t_observed)")

    # -- Tier 4: 2-hop entities --
    print("\n--- Tier 4: Entities 2-hops from Genesis ---")
    t4 = backfill_tier4_transitive(driver, database)
    print(f"  Updated {t4['entities']} entities (t_created)")
    print(f"  Updated {t4['observations']} observations (t_observed)")

    # -- Tier 5: Relationships --
    print("\n--- Tier 5: Relationships ---")
    t5 = backfill_relationships(driver, database)
    print(f"  Updated {t5} relationships (t_created)")

    # -- Verification --
    print("\n--- Post-backfill verification ---")
    v = verify_backfill(driver, database)
    m = v["memories"]
    o = v["observations"]
    print(f"  Memories: {m['has_t_created']}/{m['total']} have t_created")
    print(f"  Observations: {o['has_t_observed']}/{o['total']} have t_observed")
    print(f"  Relationships with t_created: {v['rels_with_t_created']}")
    print(f"  Genesis nodes: {v['genesis_count']} (remaining DailyContext: {v['remaining_daily_context']})")

    if v['genesis_with_t_valid'] > 0:
        print(f"\n  WARNING: {v['genesis_with_t_valid']} Genesis nodes have t_valid "
              f"(should be 0 — Genesis is phenomenological bedrock)")

    if v["samples"]:
        print("\n  Sample backfilled entities:")
        for s in v["samples"]:
            print(f"    {s['name']} ({s['type']}): t_created={s['t_created']}")

    if v["orphans"]:
        print(f"\n  Orphaned entities (no Genesis chain, {len(v['orphans'])} total):")
        for orph in v["orphans"][:10]:
            print(f"    {orph['name']} ({orph['type']})")

    coverage_pct = (o['has_t_observed'] / o['total'] * 100) if o['total'] > 0 else 0
    print(f"\n  Observation coverage: {coverage_pct:.1f}%")

    if m['missing_t_created'] == 0 and o['missing_t_observed'] == 0:
        print("  Backfill complete: 100% coverage.")
    else:
        print(f"  {m['missing_t_created']} memories and {o['missing_t_observed']} observations "
              f"still missing temporal metadata (orphaned from Genesis chain).")

    driver.close()


if __name__ == "__main__":
    main()
