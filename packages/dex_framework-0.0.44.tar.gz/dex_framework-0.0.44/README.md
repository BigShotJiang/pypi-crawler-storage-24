# DEx-Framework

> **Material Design 3 component library for Python + Flet**  
> Python 3.10+ · Flet 0.28.3+ · 20 components · 21 token families · 5 themes

> **Copyright © 2026 Almir J Gomes. Todos os direitos reservados.**  
> Autor: Almir J Gomes · almir.jg@hotmail.com · Criado em: 03/2026

---

## Installation

```bash
pip install DEx-Framework
```

## Quick Start

```python
import flet as ft
from DEx_Framework.foundations.components import DS_AppShell, DS_KPICard, DS_Button, SidebarItem
from DEx_Framework.foundations.tokens import TK_AppShellTokens, TK_KPICardTokens, TK_ButtonTokens

def main(page: ft.Page):
    shell = DS_AppShell(
        title="Data Platform",
        subtitle="Pipeline Monitor",
        icon=ft.Icons.STORAGE,
        token=TK_AppShellTokens.default,
        items=[
            SidebarItem(label="Dashboard", icon=ft.Icons.DASHBOARD),
            SidebarItem(label="Pipelines", icon=ft.Icons.SYNC_ALT),
        ],
        content=ft.Column([
            DS_KPICard(
                title="Active Pipelines",
                value="248",
                variation=12.5,
                trend="up",
                icon=ft.Icons.SYNC_ALT,
                token=TK_KPICardTokens.default,
            ),
            DS_Button(
                label="Run Pipeline",
                icon=ft.Icons.PLAY_ARROW,
                token=TK_ButtonTokens.filled,
            ),
        ]),
    )
    page.add(shell)

ft.app(target=main)
```

## Components

### Visual Foundations (Funda??es Visuais) ? 1 componente(s)
- `DS_Text`

### Layout & Structure (Layout e Estrutura) ? 6 componente(s)
- `DS_AppShell`
- `DS_Header`
- `DS_Sidebar`
- `DS_Menu_NR`
- `DS_Container`
- `DS_Card`

### Data Input Controls (Controles de Entrada de Dados) ? 6 componente(s)
- `DS_TextField`
- `DS_Dropdown`
- `DS_Checkbox`
- `DS_RadioGroup`
- `DS_Search`
- `DS_FilePicker`

### Actions & Commands (A??es e Comandos) ? 2 componente(s)
- `DS_Button`
- `DS_TextLink`

### Navigation Components (Componentes de Navega??o) ? 3 componente(s)
- `DS_Tabs`
- `DS_Stepper`
- `DS_Timeline`

### Data Display & Visualization (Exibi??o e Visualiza??o de Dados) ? 4 componente(s)
- `DS_Table`
- `DS_KPICard`
- `DS_LineChart`
- `DS_ProgressBar`

### Feedback & Status (Feedback e Status) ? 3 componente(s)
- `DS_Alert`
- `DS_StatusChip`
- `DS_Toast`

### Authentication & Session (Autentica??o e Sess?o) ? 2 componente(s)
- `DS_Login`
- `DS_Login_Modal`

### Overlays & Dialogs (Sobreposi??es e Di?logos) ? 1 componente(s)
- `DS_Modal`

### Theming & Styling (Temas e Estiliza??o) ? 2 componente(s)
- `DS_ThemeManager`
- `DS_ThemeList`
## Themes

```python
from DEx_Framework.foundations.components import DS_ThemeManager

tm = DS_ThemeManager.get()
tm.apply(page, "dark")      # default | light | dark | demi_dark | system
tm.cycle(page)              # cycle through all themes
```

## Token System

Every visual property is controlled by an immutable `@dataclass(frozen=True)` token.

```python
from DEx_Framework.foundations.components import DS_Button
from DEx_Framework.foundations.tokens import TK_ButtonTokens

DS_Button(label="Save", token=TK_ButtonTokens.filled)
DS_Button(label="Delete", token=TK_ButtonTokens.danger)
```

## Documentation

See [Docs/design_system.md](Docs/design_system.md) for the full technical reference.

Component groups: [Docs/MD/Components_Groups.md](Docs/MD/Components_Groups.md)

## License

MIT — Copyright © 2026 Almir J Gomes · almir.jg@hotmail.com
