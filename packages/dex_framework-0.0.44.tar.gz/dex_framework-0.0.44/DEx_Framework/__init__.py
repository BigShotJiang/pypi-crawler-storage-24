from __future__ import annotations

from DEx_Framework import foundations as _foundations
from DEx_Framework.foundations import *  # noqa: F401,F403

__version__ = "0.0.44"

__all__ = [
    *_foundations.__all__,
    "__version__",
]
