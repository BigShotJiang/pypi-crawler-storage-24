from __future__ import annotations
from typing import Callable, Optional, Sequence

import flet as ft

from DEx_Framework.foundations.components.layout_structure.ds_app_shell import DS_AppShell
from DEx_Framework.foundations.components.layout_structure.ds_header import HeaderAction
from DEx_Framework.foundations.components.layout_structure.ds_version_bar import DS_VersionBar
from DEx_Framework.foundations.components.layout_structure.ds_sidebar import SidebarAction, SidebarItem
from DEx_Framework.foundations.components.authentication_session.ds_login_modal import DS_Login_Modal
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_app_shell import TK_AppShellToken, TK_AppShellTokens


ContentBuilder = Callable[[int], ft.Control]


class DS_Menu_NR(ft.Column):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,

        # Geral
        # -----
        items: Sequence[SidebarItem],
        subtitle: str = "",

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,
        contents: Optional[Sequence[ft.Control]] = None,
        content_builder: Optional[ContentBuilder] = None,

        # Tokens e tema
        # -------------
        token: TK_AppShellToken = TK_AppShellTokens.default,
        sidebar_mode: str = "expanded",
        selected_index: int = 0,
        bottom_actions: Optional[Sequence[SidebarAction]] = None,
        header_actions: Optional[Sequence[HeaderAction]] = None,
        dynamic_sidebar_title: bool = True,
        sidebar_header_title: Optional[str] = None,
        show_search: bool = False,

        # Callbacks
        # ---------
        on_item_click: Optional[Callable[[int], None]] = None,
        page: Optional[ft.Page] = None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,
        auto_apply_page_theme: bool = True,
        theme_name: Optional[str] = None,
        enable_theme_action: bool = True,
        enable_login_action: bool = False,
        login_modal: Optional[DS_Login_Modal] = None,
        login_action_icon: str = ft.Icons.LOGIN,
        login_action_tooltip: str = "Login",
        theme_action_icon: str = ft.Icons.PALETTE,
        theme_action_tooltip: str = "Tema",
        show_version_bar: bool = True,
        version_bar: Optional[DS_VersionBar] = None,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._page = page
        self._items = list(items)
        self._contents = list(contents) if contents is not None else None
        self._content_builder = content_builder
        self._selected_index = selected_index
        self._on_item_click = on_item_click
        self._dynamic_sidebar_title = dynamic_sidebar_title
        self._sidebar_header_title = sidebar_header_title

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        if self._theme_manager is not None:
            if self._page is not None and auto_apply_theme:
                should_apply = False
                if theme_name:
                    should_apply = True
                elif auto_apply_page_theme:
                    page_theme = getattr(self._page, "theme", None)
                    page_bgcolor = getattr(self._page, "bgcolor", None)
                    should_apply = page_theme is None and page_bgcolor is None
                if should_apply:
                    self._theme_manager.apply(self._page, theme_name or self._theme_manager.current_name)
            if auto_apply_theme:
                token = self._theme_manager.theme.app_shell

        self._login_modal = login_modal
        if enable_login_action and self._login_modal is None:
            self._login_modal = DS_Login_Modal()

        self._version_bar = version_bar
        if show_version_bar and self._version_bar is None:
            self._version_bar = DS_VersionBar(theme_manager=self._theme_manager)

        merged_header_actions: Optional[list[HeaderAction]] = None
        if header_actions is not None:
            merged_header_actions = list(header_actions)
            if enable_theme_action:
                merged_header_actions.append(
                    HeaderAction(
                        icon=theme_action_icon,
                        tooltip=theme_action_tooltip,
                        on_click=self._handle_cycle_theme,
                    )
                )
            if enable_login_action:
                merged_header_actions.append(
                    HeaderAction(
                        icon=login_action_icon,
                        tooltip=login_action_tooltip,
                        on_click=self._handle_open_login,
                    )
                )

        self._shell = DS_AppShell(
            title=title,
            subtitle=subtitle,
            icon=icon,
            items=self._items,
            token=token,
            sidebar_mode=sidebar_mode,
            selected_index=selected_index,
            content=self._resolve_content(selected_index),
            bottom_actions=list(bottom_actions) if bottom_actions else [],
            header_actions=merged_header_actions,
            show_search=show_search,
            header_extra=self._version_bar,
            dynamic_sidebar_title=self._dynamic_sidebar_title,
            sidebar_header_title=self._sidebar_header_title,
            on_item_click=self._handle_item_click,
            auto_apply_theme=auto_apply_theme,
            theme_manager=self._theme_manager,
            page=self._page,
            login_modal=self._login_modal,
            enable_theme_action=enable_theme_action,
            enable_login_action=enable_login_action,
        )

        kwargs.pop("expand", None)
        super().__init__(
            expand=True,
            spacing=0,
            controls=[self._shell],
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    def _handle_item_click(self, idx: int):
        self._selected_index = idx
        if self._contents is not None or self._content_builder is not None:
            self._shell.set_content(self._resolve_content(idx))
            self._shell.set_selected(idx)
        if self._on_item_click:
            self._on_item_click(idx)

    def _handle_cycle_theme(self, e: ft.ControlEvent):
        if self._theme_manager is None or self._page is None:
            return
        self._theme_manager.cycle(self._page)

    def _handle_open_login(self, e: ft.ControlEvent):
        if self._login_modal is None or self._page is None:
            return
        self._login_modal.open_modal(self._page)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_content(self, idx: int) -> ft.Control:
        if self._content_builder is not None:
            return self._content_builder(idx)
        if self._contents is not None and 0 <= idx < len(self._contents):
            return self._contents[idx]
        return ft.Container(expand=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------


    @property
    def title(self) -> str:
        return self._shell.title

    @title.setter
    def title(self, value: str):
        self._shell.title = value

    @property
    def subtitle(self) -> str:
        return self._shell.subtitle

    @subtitle.setter
    def subtitle(self, value: str):
        self._shell.subtitle = value

    @property
    def shell(self) -> DS_AppShell:
        return self._shell

    @property
    def login_modal(self) -> Optional[DS_Login_Modal]:
        return self._login_modal

    def set_content(self, content: ft.Control):
        self._shell.set_content(content)

    def set_selected(self, index: int):
        self._selected_index = index
        self._shell.set_selected(index)

    def set_sidebar_mode(self, mode: str):
        self._shell.set_sidebar_mode(mode)

    def apply_theme(self, theme_name: str):
        if self._theme_manager is None or self._page is None:
            return
        self._theme_manager.apply(self._page, theme_name)

    def cycle_theme(self):
        if self._theme_manager is None or self._page is None:
            return
        self._theme_manager.cycle(self._page)

    def open_login(self):
        if self._login_modal is None or self._page is None:
            return
        self._login_modal.open_modal(self._page)

    def close_login(self):
        if self._login_modal is None or self._page is None:
            return
        self._login_modal.close_modal(self._page)
