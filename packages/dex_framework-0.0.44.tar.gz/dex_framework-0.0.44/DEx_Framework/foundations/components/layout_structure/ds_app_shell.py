from __future__ import annotations
from dataclasses import replace
from typing import Callable, Optional
import flet as ft
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_sidebar import TK_SidebarToken

from DEx_Framework.foundations.tokens.tk_app_shell import TK_AppShellToken, TK_AppShellTokens
from DEx_Framework.foundations.components.layout_structure.ds_header  import DS_Header, HeaderAction
from DEx_Framework.foundations.components.layout_structure.ds_sidebar import DS_Sidebar, SidebarItem, SidebarAction
from DEx_Framework.foundations.components.authentication_session.ds_login_modal import DS_Login_Modal
from DEx_Framework.foundations.components.actions_commands.ds_theme_action import DS_Theme_Action


DEFAULT_NESTING_LIGHTEN = 0.06


class DS_AppShell(ft.Column):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,

        # Geral
        # -----
        items: list,
        subtitle: str = "",

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,
        logo_path: Optional[str] = None,
        content: Optional[ft.Control] = None,

        # Tokens e tema
        # -------------
        token: TK_AppShellToken = TK_AppShellTokens.default,
        sidebar_mode: str = "expanded",
        selected_index: int = 0,
        bottom_actions: Optional[list] = None,
        header_actions: Optional[list] = None,
        dynamic_sidebar_title: bool = True,
        sidebar_header_title: Optional[str] = None,
        header_extra: Optional[ft.Control] = None,
        show_search: bool = False,

        # Callbacks
        # ---------
        on_item_click: Optional[Callable] = None,
        on_mode_change: Optional[Callable] = None,
        nesting_level: int = 0,
        nesting_lighten: float = DEFAULT_NESTING_LIGHTEN,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,
        page: Optional[ft.Page] = None,
        login_modal: Optional[DS_Login_Modal] = None,
        enable_theme_action: bool = True,
        enable_login_action: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._on_item_click  = on_item_click
        self._nesting_level  = max(0, int(nesting_level))
        self._nesting_lighten = max(0.0, min(1.0, float(nesting_lighten)))
        self._title          = title
        self._subtitle       = subtitle
        self._icon           = icon
        self._logo_path      = logo_path
        self._header_actions = header_actions
        self._default_header_actions = header_actions is None
        self._dynamic_sidebar_title = dynamic_sidebar_title
        self._sidebar_header_title = sidebar_header_title
        self._header_extra = header_extra
        self._show_search    = show_search
        self._page = page
        self._theme_manager  = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        if self._theme_manager is not None:
            token = self._theme_manager.theme.app_shell
        self._token          = self._tone_app_shell_token(token, self._nesting_level)
        self._login_modal = login_modal
        if enable_login_action and self._login_modal is None:
            self._login_modal = DS_Login_Modal()

        self._content_area = ft.Container(
            expand=True,
            bgcolor=self._token.bgcolor,
            content=content or ft.Container(),
        )

        sidebar_token = self._token.sidebar_token

        self._sidebar = DS_Sidebar(
            items=items,
            header_title=self._sidebar_header_title or title,
            dynamic_header_title=self._dynamic_sidebar_title,
            token=sidebar_token,
            bottom_actions=bottom_actions or [],
            mode=sidebar_mode,
            selected_index=selected_index,
            on_item_click=self._handle_item_click,
            on_mode_change=on_mode_change,
        )

        self._apply_sidebar_corner()

        header_token = self._tone_header_token(self._token.header_token, self._nesting_level)
        self._theme_action = None
        if self._header_actions is None:
            theme_action = DS_Theme_Action(
                page=self._page,
                theme_manager=self._theme_manager,
                auto_apply_theme=auto_apply_theme,
                tooltip=self._theme_tooltip(),
            )
            self._header_actions = [
                HeaderAction(
                    icon=ft.Icons.SEARCH,
                    tooltip="Pesquisar",
                    on_click=self._handle_search,
                    visible=True,
                ),
                HeaderAction(
                    icon=ft.Icons.NOTIFICATIONS,
                    tooltip="Notificações",
                    on_click=self._handle_notifications,
                    visible=True,
                ),
                HeaderAction(
                    icon=ft.Icons.SETTINGS,
                    tooltip="Configurações",
                    on_click=self._handle_settings,
                    visible=True,
                ),
                HeaderAction(
                    icon=ft.Icons.HELP_OUTLINE,
                    tooltip="Help-Auxilio ao usuário",
                    on_click=self._handle_help,
                    visible=True,
                ),
                theme_action,
                HeaderAction(
                    icon=ft.Icons.PERSON,
                    tooltip="Portfolio do usuário",
                    on_click=self._handle_open_login if enable_login_action else None,
                    visible=True,
                ),
                HeaderAction(
                    icon=ft.Icons.LOGOUT,
                    tooltip="Sair do sistema",
                    on_click=self._handle_exit,
                    visible=True,
                ),
            ]
            self._theme_action = theme_action

        self._header = DS_Header(
            title=title,
            subtitle=subtitle,
            icon=icon,
            logo_path=logo_path,
            token=header_token,
            actions=self._header_actions,
            show_search=show_search,
            right_extra=self._header_extra,
            page=self._page,
            theme_manager=self._theme_manager,
        )

        self._body = ft.Row(
            expand=True,
            spacing=0,
            controls=[
                self._sidebar,
                self._content_area,
            ],
        )

        self._root = ft.Container(
            expand=True,
            bgcolor=token.bgcolor,
            content=ft.Column(
                expand=True,
                spacing=0,
                controls=[self._header, self._body],
            ),
        )

        kwargs.pop("expand", None)
        super().__init__(
            expand=True,
            spacing=0,
            controls=[self._root],
            **kwargs,
        )

        self._apply_nesting_to_content(content)

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _handle_cycle_theme(self, e):
        if self._theme_manager is None or self._page is None:
            return
        self._theme_manager.cycle(self._page)

    def _handle_open_login(self, e):
        if self._login_modal is None or self._page is None:
            return
        self._login_modal.open_modal(self._page)

    def _show_info(self, message: str):
        if self._page is None:
            return
        try:
            self._page.snack_bar = ft.SnackBar(content=ft.Text(message))
            self._page.snack_bar.open = True
            self._page.update()
        except Exception:
            pass

    def _handle_search(self, e):
        self._show_info("Pesquisar (ação padrão)")

    def _handle_settings(self, e):
        self._show_info("Configurações (ação padrão)")

    def _handle_notifications(self, e):
        self._show_info("Notificações (ação padrão)")

    def _handle_help(self, e):
        self._show_info("Ajuda (ação padrão)")

    def _handle_exit(self, e):
        if self._page is None:
            return
        try:
            self._page.window_close()
        except Exception:
            try:
                self._page.window_destroy()
            except Exception:
                pass

    def _theme_tooltip(self) -> str:
        if self._theme_manager is None:
            return "Tema"
        return f"Tema: {self._theme_manager.current_name}"

    def _apply_nesting_to_content(self, content: Optional[ft.Control]):
        self._propagate_nesting(content, self._nesting_level + 1)

    def _on_theme_change(self, theme):
        self._apply_theme(theme)

    def _apply_theme(self, theme):
        self._token = self._tone_app_shell_token(theme.app_shell, self._nesting_level)
        if self._default_header_actions and self._theme_action is not None:
            try:
                self._theme_action.tooltip = self._theme_tooltip()
            except Exception:
                pass

        # 1. cores de fundo
        self._content_area.bgcolor = self._token.bgcolor
        if hasattr(self, "_root") and self._root is not None:
            self._root.bgcolor = self._token.bgcolor

        # 2. sidebar
        self._sidebar.set_token(self._token.sidebar_token)
        self._apply_sidebar_corner()

        # 3. header â€” recria e injeta na Column interna
        header_token = self._tone_header_token(self._token.header_token, self._nesting_level)
        self._header = DS_Header(
            title=self._title,
            subtitle=self._subtitle,
            icon=self._icon,
            logo_path=self._logo_path,
            token=header_token,
            actions=self._header_actions,
            show_search=self._show_search,
            right_extra=self._header_extra,
            page=self._page,
            theme_manager=self._theme_manager,
        )
        if hasattr(self, "_root") and self._root is not None:
            self._root.content.controls[0] = self._header

        # 4. propaga para sub-shell no content (se existir)
        content_ctrl = self._content_area.content
        if isinstance(content_ctrl, DS_AppShell):
            content_ctrl._apply_theme(theme)

        # 5. forÃ§a refresh nos controles corretos
        for ctrl in (self._content_area, self._root):
            try:
                ctrl.update()
            except Exception:
                pass
        try:
            self._root.content.update()
        except Exception:
            pass

    def _propagate_nesting(self, control: Optional[ft.Control], level: int):
        if control is None:
            return
        if isinstance(control, DS_AppShell):
            control.set_nesting_level(level)
            return
        if hasattr(control, "content") and isinstance(getattr(control, "content"), ft.Control):
            self._propagate_nesting(control.content, level)
        if hasattr(control, "controls") and isinstance(getattr(control, "controls"), list):
            for child in control.controls:
                self._propagate_nesting(child, level)

    def _apply_sidebar_corner(self):
        if self._nesting_level == 0:
            self._sidebar.set_border_radius(
                ft.border_radius.only(top_right=12)
            )
        else:
            self._sidebar.set_border_radius(ft.border_radius.all(0))

    def set_nesting_level(self, level: int):
        level = max(0, int(level))
        if level == self._nesting_level:
            return
        self._nesting_level = level
        self._token = self._tone_app_shell_token(self._token, level)
        self._sidebar.set_token(self._token.sidebar_token)
        self._apply_sidebar_corner()
        self._content_area.bgcolor = self._token.bgcolor
        if hasattr(self, "_root") and self._root is not None:
            self._root.bgcolor = self._token.bgcolor
        header_token = self._tone_header_token(self._token.header_token, self._nesting_level)
        self._header = DS_Header(
            title=self._title,
            subtitle=self._subtitle,
            icon=self._icon,
            logo_path=self._logo_path,
            token=header_token,
            actions=self._header_actions,
            show_search=self._show_search,
            right_extra=self._header_extra,
        )
        if hasattr(self, "_root") and self._root is not None:
            self._root.content.controls[0] = self._header
        self._apply_nesting_to_content(self._content_area.content)

    
    
    def _tone_header_token(self, token, level: int):
        if level <= 0:
            return token
        factor = min(self._nesting_lighten * level, 0.9)
        return replace(
            token,
            bgcolor=self._tone_color(token.bgcolor, factor),
            divider_color=self._tone_color(token.divider_color, factor),
            action_btn_bgcolor=self._tone_color(token.action_btn_bgcolor, factor),
            action_btn_hover_color=self._tone_color(token.action_btn_hover_color, factor),
            search_bgcolor=self._tone_color(token.search_bgcolor, factor),
            search_border_color=self._tone_color(token.search_border_color, factor),
        )

    def _tone_app_shell_token(self, token: TK_AppShellToken, level: int) -> TK_AppShellToken:
        if level <= 0:
            return token
        factor = min(self._nesting_lighten * level, 0.9)
        return replace(
            token,
            bgcolor=self._tone_color(token.bgcolor, factor),
            header_token=self._tone_header_token(token.header_token, level),
            sidebar_token=self._tone_sidebar_token(token.sidebar_token, level),
        )

    def _tone_sidebar_token(self, token: TK_SidebarToken, level: int) -> TK_SidebarToken:
        if level <= 0:
            return token
        factor = min(self._nesting_lighten * level, 0.9)
        return replace(
            token,
            bgcolor=self._tone_color(token.bgcolor, factor),
            header_bgcolor=self._tone_color(token.header_bgcolor, factor),
            action_area_bgcolor=self._tone_color(token.action_area_bgcolor, factor),
            item_bgcolor_hover=self._tone_color(token.item_bgcolor_hover, factor),
            item_bgcolor_selected=self._tone_color(token.item_bgcolor_selected, factor),
            toggle_hover_color=self._tone_color(token.toggle_hover_color, factor),
        )

    @staticmethod
    def _tone_color(color: str, factor: float) -> str:
        if not isinstance(color, str):
            return color
        if not color.startswith("#") or len(color) != 7:
            return color
        try:
            r = int(color[1:3], 16)
            g = int(color[3:5], 16)
            b = int(color[5:7], 16)
        except ValueError:
            return color
        factor = max(0.0, min(1.0, factor))
        r = int(r + (255 - r) * factor)
        g = int(g + (255 - g) * factor)
        b = int(b + (255 - b) * factor)
        return f"#{r:02X}{g:02X}{b:02X}"

    def _handle_item_click(self, idx: int):
        if self._on_item_click:
            self._on_item_click(idx)

    def set_content(self, control: ft.Control):
        self._content_area.content = control
        self._apply_nesting_to_content(control)
        try:
            self._content_area.update()
        except AssertionError:
            pass

    def set_selected(self, index: int):
        self._sidebar.set_selected(index)

    def set_sidebar_mode(self, mode: str):
        self._sidebar.set_mode(mode)


    @property
    def title(self) -> str:
        return self._title

    @title.setter
    def title(self, value: str):
        self._title = value
        # atualiza header e sidebar
        self._header = DS_Header(
            title=self._title,
            subtitle=self._subtitle,
            icon=self._icon,
            logo_path=self._logo_path,
            token=self._tone_header_token(self._token.header_token, self._nesting_level),
            actions=self._header_actions,
            show_search=self._show_search,
            right_extra=self._header_extra,
            page=self._page,
            theme_manager=self._theme_manager,
        )
        if hasattr(self, "_root") and self._root is not None:
            self._root.content.controls[0] = self._header
            try:
                self._root.content.update()
            except Exception:
                pass
        try:
            self._sidebar._header_title = value
            self._sidebar._refresh()
        except Exception:
            pass

    @property
    def subtitle(self) -> str:
        return self._subtitle

    @subtitle.setter
    def subtitle(self, value: str):
        self._subtitle = value
        self._header = DS_Header(
            title=self._title,
            subtitle=self._subtitle,
            icon=self._icon,
            logo_path=self._logo_path,
            token=self._tone_header_token(self._token.header_token, self._nesting_level),
            actions=self._header_actions,
            show_search=self._show_search,
            right_extra=self._header_extra,
            page=self._page,
            theme_manager=self._theme_manager,
        )
        if hasattr(self, "_root") and self._root is not None:
            self._root.content.controls[0] = self._header
            try:
                self._root.content.update()
            except Exception:
                pass

    @property
    def sidebar(self) -> DS_Sidebar:
        return self._sidebar

    @property
    def content_area(self) -> ft.Container:
        return self._content_area
