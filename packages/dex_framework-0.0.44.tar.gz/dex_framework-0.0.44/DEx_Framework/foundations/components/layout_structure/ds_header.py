from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.components.actions_commands.ds_theme_action import DS_Theme_Action
from DEx_Framework.foundations.components.actions_commands.ds_user_login_action import DS_User_Login_Action
from DEx_Framework.foundations.tokens.tk_header import TK_HeaderToken as HeaderToken, TK_HeaderTokens as HeaderTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

@dataclass
class HeaderAction:
    icon: str
    tooltip: str = ""
    on_click: Optional[object] = None
    visible: bool = True


class DS_Header(ft.Column):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,
        subtitle: Optional[str] = None,

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,
        logo_path: Optional[str] = None,

        # Tokens e tema
        # -------------
        token: HeaderToken = HeaderTokens.primary,

        # Geral
        # -----
        bgcolor: Optional[str] = None,
        title_size: Optional[float] = None,
        title_weight: Optional[str] = None,
        subtitle_size: Optional[float] = None,
        subtitle_weight: Optional[str] = None,
        show_search: bool = False,
        search_hint: str = "Pesquisar...",

        # Callbacks
        # ---------
        on_search_change=None,
        actions: Optional[list] = None,
        right_extra: Optional[ft.Control] = None,
        page: Optional[ft.Page] = None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._title = title
        self._subtitle = subtitle
        self._icon = icon
        self._logo_path = logo_path
        self._bgcolor_override = bgcolor
        self._title_size_override = title_size
        self._title_weight_override = title_weight
        self._subtitle_size_override = subtitle_size
        self._subtitle_weight_override = subtitle_weight
        self._show_search = show_search
        self._search_hint = search_hint
        self._on_search_change = on_search_change
        self._page = page
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        if actions is None:
            actions = [
                HeaderAction(icon=ft.Icons.SEARCH, tooltip="Pesquisar"),
                HeaderAction(icon=ft.Icons.NOTIFICATIONS, tooltip="Notificações"),
                HeaderAction(icon=ft.Icons.SETTINGS, tooltip="Configurações"),
                HeaderAction(icon=ft.Icons.HELP_OUTLINE, tooltip="Ajuda – auxílio ao usuário"),
                DS_Theme_Action(
                    page=self._page,
                    icon=ft.Icons.PALETTE,
                    theme_manager=self._theme_manager,
                    auto_apply_theme=auto_apply_theme,
                    use_header_style=True,
                    tooltip="Tema",
                ),
                DS_User_Login_Action(
                    page=self._page,
                    # logo=True,
                    logo_src=self._logo_path,
                    theme_manager=self._theme_manager,
                    auto_apply_theme=auto_apply_theme,
                    icon=ft.Icons.PERSON,
                    tooltip="Usuário",
                    use_header_style=True,
                    origin="header",
                ),
                HeaderAction(icon=ft.Icons.LOGOUT, tooltip="Sair do sistema"),
            ]
        self._actions = actions
        self._right_extra = right_extra
        self._use_theme_token = token is HeaderTokens.primary and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.app_shell.header_token
        self._token = token

        resolved_bgcolor = bgcolor if bgcolor is not None else token.bgcolor

        left = self._build_title_block(
            title=title,
            subtitle=subtitle,
            icon=icon,
            logo_path=logo_path,
            token=token,
            title_size=title_size or token.title_size,
            title_weight=title_weight or token.title_weight,
            subtitle_size=subtitle_size or token.subtitle_size,
            subtitle_weight=subtitle_weight or token.subtitle_weight,
        )

        right_controls = []

        if show_search:
            right_controls.append(self._build_search(token, search_hint, on_search_change))

        if actions:
            for action in actions:
                if isinstance(action, HeaderAction):
                    if action.visible:
                        right_controls.append(self._build_action_button(action, token))
                else:
                    # Se o controle tiver atributo "visible", respeita
                    if getattr(action, "visible", True):
                        right_controls.append(action)

        right_top = ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=right_controls)
        right_block: ft.Control = right_top
        if right_extra is not None:
            right_block = ft.Column(
                spacing=2,
                horizontal_alignment=ft.CrossAxisAlignment.END,
                controls=[
                    right_top,
                    ft.Container(
                        margin=ft.margin.only(bottom=1),
                        content=ft.Row(
                            spacing=0,
                            alignment=ft.MainAxisAlignment.END,
                            controls=[right_extra],
                        ),
                    ),
                ],
            )

        header_row = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                left,
                right_block,
            ],
        )

        left_pad = max(0, token.padding_horizontal - 8)
        controls = [
            ft.Container(
                bgcolor=resolved_bgcolor,
                padding=ft.padding.only(
                    left=left_pad,
                    right=token.padding_horizontal,
                    top=token.padding_vertical,
                    bottom=token.padding_vertical,
                ),
                content=header_row,
            ),
        ]

        super().__init__(controls=controls, spacing=0, **kwargs)

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _build_title_block(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        logo_path: Optional[str],
        token: HeaderToken,
        title_size: float,
        title_weight: str,
        subtitle_size: float,
        subtitle_weight: str,
    ) -> ft.Control:
        title_text = ft.Text(value=title, size=title_size, weight=title_weight, color=token.title_color)

        if icon:
            title_row = ft.Row(
                spacing=token.spacing,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            text_block = ft.Column(
                spacing=2,
                controls=[
                    title_row,
                    ft.Text(value=subtitle, size=subtitle_size, weight=subtitle_weight, color=token.subtitle_color),
                ],
            )
        else:
            text_block = title_row

        if logo_path:
            logo_size = 80
            logo = ft.Container(
                width=logo_size,
                height=logo_size,
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                border_radius=ft.border_radius.all(logo_size / 2),
                content=ft.Image(
                    src=logo_path,
                    fit=ft.ImageFit.COVER,
                ),
            )
            return ft.Row(
                spacing=token.spacing,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[logo, text_block],
            )

        return text_block

    @staticmethod
    def _build_search(token: HeaderToken, hint: str, on_change) -> ft.TextField:
        return ft.TextField(
            hint_text=hint,
            hint_style=ft.TextStyle(color=token.search_hint_color),
            text_style=ft.TextStyle(color=token.search_text_color),
            prefix_icon=ft.Icon(name=ft.Icons.SEARCH, color=token.search_hint_color),
            border_color=token.search_border_color,
            focused_border_color=token.search_focused_border_color,
            focused_border_width=2,
            border_width=1,
            border_radius=24,
            bgcolor=token.search_bgcolor,
            content_padding=ft.padding.symmetric(horizontal=16, vertical=8),
            text_size=14,
            cursor_color=token.search_focused_border_color,
            width=220,
            height=40,
            on_change=on_change,
        )

    @staticmethod
    def _build_action_button(action: HeaderAction, token: HeaderToken) -> ft.IconButton:
        handler = action.on_click
        if handler is None:
            name = action.tooltip or action.icon
            handler = lambda e, _name=name: print(f"Acao: {_name}")
        return ft.IconButton(
            icon=action.icon,
            icon_color=token.action_btn_icon_color,
            icon_size=token.action_btn_icon_size,
            tooltip=action.tooltip,
            on_click=handler,
            style=ft.ButtonStyle(
                bgcolor=token.action_btn_bgcolor,
                overlay_color=token.action_btn_hover_color,
                shape=ft.CircleBorder(),
                padding=ft.padding.all(8),
            ),
            width=token.action_btn_size,
            height=token.action_btn_size,
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.app_shell.header_token
        token = self._token
        resolved_bgcolor = self._bgcolor_override if self._bgcolor_override is not None else token.bgcolor

        left = self._build_title_block(
            title=self._title,
            subtitle=self._subtitle,
            icon=self._icon,
            logo_path=self._logo_path,
            token=token,
            title_size=self._title_size_override or token.title_size,
            title_weight=self._title_weight_override or token.title_weight,
            subtitle_size=self._subtitle_size_override or token.subtitle_size,
            subtitle_weight=self._subtitle_weight_override or token.subtitle_weight,
        )

        right_controls = []
        if self._show_search:
            right_controls.append(self._build_search(token, self._search_hint, self._on_search_change))
        if self._actions:
            for action in self._actions:
                if isinstance(action, HeaderAction):
                    if action.visible:
                        right_controls.append(self._build_action_button(action, token))
                else:
                    if getattr(action, "visible", True):
                        right_controls.append(action)

        header_row = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                left,
                ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=right_controls),
            ],
        )

        left_pad = max(0, token.padding_horizontal - 8)
        self.controls = [
            ft.Container(
                bgcolor=resolved_bgcolor,
                padding=ft.padding.only(
                    left=left_pad,
                    right=token.padding_horizontal,
                    top=token.padding_vertical,
                    bottom=token.padding_vertical,
                ),
                content=header_row,
            ),
        ]
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
