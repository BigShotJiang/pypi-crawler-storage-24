# =============================================================================
# DEx-Framework
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
# =============================================================================
from __future__ import annotations
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_Container(ft.Container):

    def __init__(
        self,

        # Geral
        # -----
        content: ft.Control | None = None,

        # Dimensões e layout
        # ------------------
        width: float | None = None,
        height: float | None = None,
        expand: bool | None = None,
        padding: int | ft.Padding | None = None,
        margin: int | ft.Margin | None = None,
        bgcolor: str | None = None,
        border_radius: int | float | None = None,
        border: ft.Border | None = None,
        alignment: ft.Alignment | None = None,
        visible: bool = True,

        # Tokens e tema
        # -------------
        theme_manager: DS_ThemeManager | None = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._bgcolor_override = bgcolor
        self._border_override = border
        self._border_radius_override = border_radius
        self._padding_override = padding

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme = self._theme_manager is not None

        bg, br, bd, pad = self._resolve_defaults(self._theme_manager.theme if self._use_theme else None)

        super().__init__(
            content=content,
            width=width,
            height=height,
            expand=expand,
            padding=pad,
            margin=margin,
            bgcolor=bg,
            border_radius=br,
            border=bd,
            alignment=alignment,
            visible=visible,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _resolve_defaults(self, theme: TK_Theme | None):
        if theme is None:
            bgcolor = self._bgcolor_override if self._bgcolor_override is not None else self._DEFAULT_BGCOLOR
            border_radius = self._border_radius_override if self._border_radius_override is not None else self._DEFAULT_BORDER_RADIUS
            border = self._border_override if self._border_override is not None else ft.border.all(
                self._DEFAULT_BORDER_WIDTH, self._DEFAULT_BORDER_COLOR
            )
            padding = self._padding_override if self._padding_override is not None else self._DEFAULT_PADDING
            return bgcolor, border_radius, border, padding

        card = theme.card
        bgcolor = self._bgcolor_override if self._bgcolor_override is not None else card.bgcolor
        border_radius = self._border_radius_override if self._border_radius_override is not None else card.border_radius
        if self._border_override is not None:
            border = self._border_override
        else:
            border_color = card.border_color or self._DEFAULT_BORDER_COLOR
            border = ft.border.all(card.border_width, border_color)
        padding = self._padding_override if self._padding_override is not None else card.padding
        return bgcolor, border_radius, border, padding

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme:
            return
        bgcolor, border_radius, border, padding = self._resolve_defaults(theme)
        self.bgcolor = bgcolor
        self.border_radius = border_radius
        self.border = border
        self.padding = padding
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
