from __future__ import annotations
from typing import Optional
from pathlib import Path

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.components.layout_structure.ds_container import DS_Container
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme




def _tone_color(color: str, factor: float) -> str:
    if not isinstance(color, str):
        return color
    if not color.startswith("#") or len(color) != 7:
        return color
    try:
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
    except ValueError:
        return color
    factor = max(0.0, min(1.0, factor))
    r = int(r + (255 - r) * factor)
    g = int(g + (255 - g) * factor)
    b = int(b + (255 - b) * factor)
    return f"#{r:02X}{g:02X}{b:02X}"


def _is_dark(color: str) -> bool:
    if not isinstance(color, str) or not color.startswith("#") or len(color) != 7:
        return False
    try:
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
    except ValueError:
        return False
    luminance = (0.299 * r + 0.587 * g + 0.114 * b)
    return luminance < 140

class DS_VersionBar(ft.Container):

    def __init__(
        self,

        # Geral
        # -----
        app_name: str = "Aplicacao",
        show_labels: bool = True,

        # Textos e rótulos
        # ----------------
        ds_label: str = "Design System",
        app_label: str = "Aplicacao",

        # Tokens e tema
        # -------------
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._app_name = app_name
        self._show_labels = show_labels
        self._ds_label = ds_label
        self._app_label = app_label

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._ds_version = self._resolve_ds_version()
        self._app_version = self._resolve_app_version()

        token_theme = self._theme_manager.theme if self._theme_manager is not None else None

        kwargs.pop("content", None)
        super().__init__(
            padding=ft.padding.symmetric(horizontal=0, vertical=0),
            bgcolor="transparent",
            border=None,
            border_radius=0,
            content=self._build_content(token_theme),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    # ------------------------------------------------------------------
    # Resolucao de versoes
    # ------------------------------------------------------------------

    @staticmethod
    def _read_pyproject_version(pyproject: Path) -> Optional[str]:
        try:
            lines = pyproject.read_text(encoding="utf-8").splitlines()
        except Exception:
            return None

        in_project = False
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("[") and line.endswith("]"):
                in_project = line == "[project]"
                continue
            if in_project and line.startswith("version"):
                parts = line.split("=", 1)
                if len(parts) != 2:
                    continue
                value = parts[1].strip().strip("\"'")
                if value:
                    return value
        return None

    @staticmethod
    def _find_pyproject(start: Path) -> Optional[Path]:
        for p in [start] + list(start.parents):
            candidate = p / "pyproject.toml"
            if candidate.exists():
                return candidate
        return None

    def _resolve_ds_version(self) -> str:
        # 1) tenta metadata do pacote instalado
        try:
            import importlib.metadata as importlib_metadata
            return importlib_metadata.version("DEx-Framework")
        except Exception:
            pass

        # 2) tenta pyproject.toml do proprio repo
        try:
            here = Path(__file__).resolve()
            pyproject = self._find_pyproject(here)
            if pyproject:
                v = self._read_pyproject_version(pyproject)
                if v:
                    return v
        except Exception:
            pass

        return "0.0.0"

    def _resolve_app_version(self) -> str:
        try:
            pyproject = self._find_pyproject(Path.cwd())
            if pyproject:
                v = self._read_pyproject_version(pyproject)
                if v:
                    return v
        except Exception:
            pass
        return "0.0.0"

    # ------------------------------------------------------------------
    # Renderizacao
    # ------------------------------------------------------------------

    def _build_content(self, theme: Optional[TK_Theme]) -> ft.Control:
        base = theme.text_accent if theme is not None else "#000000"
        ds_bg = _tone_color(base, 0.18)
        app_bg = _tone_color(base, 0.28)

        ds_text = "#FFFFFF" if _is_dark(ds_bg) else "#000000"
        app_text = "#FFFFFF" if _is_dark(app_bg) else "#000000"

        ds_box = DS_Container(
            margin=0,
            padding=2,
            border_radius=4,
            bgcolor=ds_bg,
            border=ft.border.all(1, base),
            tooltip="Versao Design System",
            content=ft.Text(f"DS v{self._ds_version}", size=10, color=ds_text),
        )

        app_box = DS_Container(
            margin=0,
            padding=2,
            border_radius=4,
            bgcolor=app_bg,
            border=ft.border.all(1, base),
            tooltip="Versao Aplicacao",
            content=ft.Text(f"App v{self._app_version}", size=10, color=app_text),
        )

        return ft.Row(
            spacing=0,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[ds_box, app_box],
        )

    def refresh(self):
        self._ds_version = self._resolve_ds_version()
        self._app_version = self._resolve_app_version()
        theme = self._theme_manager.theme if self._theme_manager is not None else None
        self.content = self._build_content(theme)
        try:
            self.update()
        except Exception:
            pass

    def _apply_theme(self, theme: TK_Theme):
        self.content = self._build_content(theme)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
