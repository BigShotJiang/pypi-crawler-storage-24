from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_card import TK_CardToken as CardToken, TK_CardTokens as CardTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_Card(ft.Container):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,
        subtitle: Optional[str] = None,

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,

        # Geral
        # -----
        content: Optional[ft.Control] = None,
        footer: Optional[ft.Control] = None,

        # Tokens e tema
        # -------------
        token: CardToken = CardTokens.elevated,
        bgcolor: Optional[str] = None,

        # Dimensões e layout
        # ------------------
        width: Optional[float] = None,
        height: Optional[float] = None,

        # Callbacks
        # ---------
        on_click=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._title = title
        self._subtitle = subtitle
        self._icon = icon
        self._content = content
        self._footer = footer
        self._bgcolor_override = bgcolor
        self._width = width
        self._height = height
        self._on_click = on_click

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token in (
            CardTokens.elevated,
            CardTokens.outlined,
            CardTokens.dark,
            CardTokens.filled,
        ) and self._theme_manager is not None

        if self._use_theme_token:
            token = self._theme_manager.theme.card
        self._token = token

        super().__init__(
            bgcolor=bgcolor if bgcolor is not None else token.bgcolor,
            border_radius=token.border_radius,
            padding=token.padding,
            border=self._build_border(token),
            shadow=self._build_shadow(token),
            width=width,
            height=height,
            on_click=on_click,
            ink=on_click is not None,
            content=self._build_content(token),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _build_border(token: CardToken) -> Optional[ft.Border]:
        if token.border_color:
            return ft.border.all(width=token.border_width, color=token.border_color)
        return None

    @staticmethod
    def _build_shadow(token: CardToken) -> Optional[list]:
        if token.shadow_blur > 0:
            return [
                ft.BoxShadow(
                    blur_radius=token.shadow_blur,
                    offset=ft.Offset(0, token.shadow_offset_y),
                    color=token.shadow_color,
                    spread_radius=0,
                )
            ]
        return None

    def _build_content(self, token: CardToken) -> ft.Control:
        header = self._build_header(self._title, self._subtitle, self._icon, token)

        body_controls = [header]

        if self._content is not None:
            body_controls.append(ft.Divider(height=1, color=token.border_color or "#00000022"))
            body_controls.append(self._content)

        if self._footer is not None:
            body_controls.append(ft.Divider(height=1, color=token.border_color or "#00000022"))
            body_controls.append(self._footer)

        return ft.Column(
            spacing=token.spacing,
            controls=body_controls,
        )

    @staticmethod
    def _build_header(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        token: CardToken,
    ) -> ft.Control:
        title_text = ft.Text(
            value=title,
            size=token.title_size,
            weight=token.title_weight,
            color=token.title_color,
        )

        if icon:
            title_row = ft.Row(
                spacing=token.spacing,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            return ft.Column(
                spacing=2,
                controls=[
                    title_row,
                    ft.Text(
                        value=subtitle,
                        size=token.subtitle_size,
                        weight=token.subtitle_weight,
                        color=token.subtitle_color,
                    ),
                ],
            )

        return title_row

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.card
        token = self._token
        self.border = self._build_border(token)
        self.shadow = self._build_shadow(token)
        self.border_radius = token.border_radius
        self.padding = token.padding
        self.bgcolor = self._bgcolor_override if self._bgcolor_override is not None else token.bgcolor
        self.content = self._build_content(token)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
