from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Literal, Optional

import flet as ft
import threading

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_sidebar import TK_SidebarToken, TK_SidebarTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

SidebarMode = Literal["expanded", "icons_only", "hidden"]


@dataclass
class SidebarItem:
    label: str
    icon: str
    selected_icon: Optional[str] = None
    on_click: Optional[Callable] = None
    badge: Optional[str] = None


@dataclass
class SidebarAction:
    icon: str
    tooltip: str = ""
    on_click: Optional[Callable] = None


class DS_Sidebar(ft.Container):
    """
    DS_Sidebar
    
    Finalidade:
    - Componente DS_Sidebar.
    
    Detalhes:
    - Classe: DS_Sidebar.
    - Base: ft.Container.
    
    Parâmetros:
    
    Segmento: Geral
    ---
    - items (list): Parâmetro items.
    
    Segmento: Tokens e tema
    ---
    - token (TK_SidebarToken): Token usado para estilização.
    - header_title (str): Parâmetro header_title.
    - dynamic_header_title (bool): Parâmetro dynamic_header_title.
    - bottom_actions (Optional[list]): Parâmetro bottom_actions.
    - mode (SidebarMode): Parâmetro mode.
    - selected_index (int): Parâmetro selected_index.
    
    Segmento: Callbacks
    ---
    - on_mode_change (Optional[Callable]): Callback executado quando mode change.
    - on_item_click (Optional[Callable]): Callback executado quando item click.
    - auto_minimize (bool): Parâmetro auto_minimize.
    - auto_minimize_delay_ms (int): Parâmetro auto_minimize_delay_ms.
    - theme_manager (Optional[DS_ThemeManager]): Gerenciador de tema.
    
    Segmento: Parâmetros do botão
    ---
    - auto_apply_theme (bool): Parâmetro auto_apply_theme.
    
    Segmento: Outros
    ---
    - **kwargs: Parâmetros adicionais.
    """

    def __init__(
        self,

        # Geral
        # -----
        items: list,

        # Tokens e tema
        # -------------
        token: TK_SidebarToken = TK_SidebarTokens.default,
        header_title: str = "Menu",
        dynamic_header_title: bool = True,
        bottom_actions: Optional[list] = None,
        mode: SidebarMode = "expanded",
        selected_index: int = 0,

        # Callbacks
        # ---------
        on_mode_change: Optional[Callable] = None,
        on_item_click: Optional[Callable] = None,
        auto_minimize: bool = True,
        auto_minimize_delay_ms: int = 5000,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_SidebarTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.app_shell.sidebar_token

        self._items = items
        self._header_title = header_title
        self._dynamic_header_title = dynamic_header_title
        self._token = token
        self._bottom_actions = bottom_actions or []
        self._mode = mode
        self._selected = selected_index
        self._update_header_title()
        self._on_mode_change = on_mode_change
        self._on_item_click = on_item_click
        self._auto_minimize = auto_minimize
        self._auto_minimize_delay_ms = int(auto_minimize_delay_ms)
        self._auto_timer = None

        kwargs.pop("expand", None)
        super().__init__(
            width=self._resolve_width(),
            expand=False,
            bgcolor=token.bgcolor,
            border_radius=ft.border_radius.all(0),
            animate=ft.Animation(280, ft.AnimationCurve.EASE_IN_OUT),
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            on_hover=lambda e: self._handle_hover(e),
            content=self._build_content(),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _calc_expanded_width(self) -> float:
        token = self._token
        labels = [item.label for item in self._items] + ["Menu"]
        max_label_len = max((len(str(l)) for l in labels), default=0)
        text_w = self._estimate_text_width(max_label_len, token.item_text_size)
        badge_w = 0
        for item in self._items:
            if item.badge:
                badge_w = max(badge_w, self._estimate_badge_width(len(str(item.badge))))
        base = (
            token.item_padding_horizontal * 2
            + token.item_icon_size
            + 12
            + text_w
            + (badge_w + 8 if badge_w > 0 else 0)
            + 8
        )
        min_width = max(
            token.width_collapsed,
            token.item_icon_size + token.item_padding_horizontal * 2 + 24,
            base,
        )
        max_width = 300
        return min(max_width, min_width)

    @staticmethod
    def _estimate_text_width(char_count: int, font_size: float) -> float:
        return char_count * (font_size * 0.75)

    @staticmethod
    def _estimate_badge_width(char_count: int) -> float:
        return char_count * 6 + 12

    def _resolve_width(self) -> float:
        if self._mode == "expanded":
            return self._calc_expanded_width()
        if self._mode == "icons_only":
            return self._token.width_collapsed
        return 0

    
    
    
    
    
    def _toggle_pin(self, e: ft.ControlEvent):
        # alterna auto-minimize
        self._auto_minimize = not self._auto_minimize
        if not self._auto_minimize:
            try:
                if self._auto_timer is not None:
                    self._auto_timer.cancel()
            except Exception:
                pass
        else:
            self._restart_auto_minimize()

    def _handle_hover(self, e: ft.ControlEvent):
        if e.data == "true":
            if self._mode == "icons_only":
                self._mode = "expanded"
                # mantendo auto_minimize ativo
                self._refresh()
            self._restart_auto_minimize()

    def _start_auto_timer(self):
        if not self._auto_minimize:
            return
        if self._auto_timer is not None:
            try:
                self._auto_timer.cancel()
            except Exception:
                pass
        delay = max(0.1, float(self._auto_minimize_delay_ms) / 1000.0)
        self._auto_timer = threading.Timer(delay, lambda: self._handle_auto_minimize(None))
        try:
            self._auto_timer.daemon = True
        except Exception:
            pass
        try:
            self._auto_timer.start()
        except Exception:
            pass

    def _restart_auto_minimize(self):
        if self._auto_timer is None or not self._auto_minimize:
            return
        try:
            self._auto_timer.cancel()
        except Exception:
            pass
        self._start_auto_timer()

    def _handle_auto_minimize(self, e: ft.ControlEvent):
        if self._mode == "expanded":
            self._mode = "icons_only"
            self._refresh()
        if self._auto_timer is not None:
            try:
                self._auto_timer.cancel()
            except Exception:
                pass

    def _cycle_mode(self, e):
        self._mode = "icons_only" if self._mode == "expanded" else "expanded"
        self._refresh()
        if self._on_mode_change:
            self._on_mode_change(self._mode)


    def _update_header_title(self):
        if not self._dynamic_header_title:
            return
        try:
            if self._items and 0 <= self._selected < len(self._items):
                self._header_title = self._items[self._selected].label
        except Exception:
            pass

    def _handle_item_click(self, idx: int, item_callback: Optional[Callable]):
        self._selected = idx
        self._update_header_title()
        self._refresh()
        if item_callback:
            item_callback(idx)
        if self._on_item_click:
            self._on_item_click(idx)
        self._restart_auto_minimize()

    def set_mode(self, mode: SidebarMode):
        self._mode = mode
        self._refresh()

    def set_selected(self, index: int):
        self._selected = index
        self._update_header_title()
        self._refresh()

    def set_token(self, token: TK_SidebarToken):
        self._token = token
        self.bgcolor = token.bgcolor
        self._refresh()

    def set_border_radius(self, radius: ft.BorderRadius):
        self.border_radius = radius
        try:
            self.update()
        except AssertionError:
            pass

    def _refresh(self):
        self.width = self._resolve_width()
        self.content = self._build_content()
        try:
            self.update()
        except AssertionError:
            pass

    def _build_content(self) -> ft.Column:
        token = self._token
        expanded = self._mode == "expanded"

        toggle_icon = (
            ft.Icons.MENU_OPEN if expanded else
            ft.Icons.MENU
        )

        header = ft.Container(
            bgcolor=token.header_bgcolor,
            height=token.header_height,
            padding=ft.padding.symmetric(horizontal=token.item_padding_horizontal),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                          if expanded else ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        visible=expanded,
                        tooltip="Fixar sidebar",
                        ink=True,
                        on_click=self._toggle_pin,
                        content=ft.Text(
                            value=self._header_title,
                            size=18,
                            weight="w700",
                            color=token.item_text_color,
                        ),
                    ),
                    ft.IconButton(
                        icon=toggle_icon,
                        icon_color=token.toggle_icon_color,
                        icon_size=token.toggle_icon_size,
                        tooltip="Expandir" if not expanded else "Recolher",
                        on_click=self._cycle_mode,
                        style=ft.ButtonStyle(
                            bgcolor=token.toggle_bgcolor,
                            overlay_color=token.toggle_hover_color,
                            shape=ft.CircleBorder(),
                        ),
                    ),
                ],
            ),
        )

        self._start_auto_timer()

        items_controls = [
            self._build_item(idx, item)
            for idx, item in enumerate(self._items)
        ]

        items_area = ft.Container(
            expand=True,
            padding=ft.padding.symmetric(horizontal=8, vertical=8),
            content=ft.Column(
                spacing=token.item_spacing,
                scroll=ft.ScrollMode.AUTO,
                controls=items_controls,
            ),
        )

        bottom_area = self._build_bottom_actions()

        controls = [header, items_area, bottom_area]

        return ft.Column(
            spacing=0,
            expand=True,
            controls=controls,
        )

    def _build_item(self, idx: int, item: SidebarItem) -> ft.Container:
        token = self._token
        is_selected = idx == self._selected
        expanded = self._mode == "expanded"
        icon_name = (item.selected_icon or item.icon) if is_selected else item.icon

        icon_ctrl = ft.Icon(
            name=icon_name,
            size=token.item_icon_size,
            color=token.item_icon_selected_color if is_selected else token.item_icon_color,
        )

        row_controls: list = [icon_ctrl]

        if expanded:
            row_controls.append(
                ft.Text(
                    value=item.label,
                    size=token.item_text_size,
                    weight=token.item_text_weight,
                    color=token.item_text_selected_color if is_selected else token.item_text_color,
                    expand=True,
                    no_wrap=True,
                    overflow=ft.TextOverflow.ELLIPSIS,
                )
            )
            if item.badge:
                row_controls.append(self._build_badge(item.badge, token))

        container = ft.Container(
            height=token.item_height,
            border_radius=token.item_border_radius,
            bgcolor=token.item_bgcolor_selected if is_selected else "transparent",
            padding=ft.padding.symmetric(horizontal=token.item_padding_horizontal),
            tooltip=item.label if not expanded else None,
            ink=True,
            on_click=lambda e, i=idx, cb=item.on_click: self._handle_item_click(i, cb),
            content=ft.Row(
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=row_controls,
            ),
        )

        def on_hover(e, c=container, sel=is_selected):
            if e.data == "true":
                self._restart_auto_minimize()
            if not sel:
                c.bgcolor = (
                    token.item_bgcolor_hover if e.data == "true" else "transparent"
                )
                c.update()

        container.on_hover = on_hover
        return container

    @staticmethod
    def _build_badge(text: str, token: TK_SidebarToken) -> ft.Container:
        return ft.Container(
            content=ft.Text(
                value=str(text),
                size=10,
                weight="w600",
                color=token.badge_text_color,
            ),
            bgcolor=token.badge_bgcolor,
            border_radius=10,
            padding=ft.padding.symmetric(horizontal=6, vertical=2),
        )

    def _build_bottom_actions(self) -> ft.Container:
        token = self._token
        expanded = self._mode == "expanded"

        if not self._bottom_actions:
            return ft.Container(height=0)

        btns = [
            ft.IconButton(
                icon=action.icon,
                icon_color=token.action_icon_color,
                icon_size=token.action_icon_size,
                tooltip=action.tooltip,
                on_click=action.on_click,
                style=ft.ButtonStyle(
                    bgcolor=token.action_bgcolor,
                    overlay_color=token.action_hover_color,
                    shape=ft.CircleBorder(),
                ),
            )
            for action in self._bottom_actions
        ]

        return ft.Container(
            bgcolor=token.action_area_bgcolor,
            padding=ft.padding.symmetric(horizontal=8, vertical=10),
            content=ft.Row(
                controls=btns,
                alignment=ft.MainAxisAlignment.CENTER
                          if not expanded else ft.MainAxisAlignment.START,
                spacing=4,
            ),
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.app_shell.sidebar_token
        self.bgcolor = self._token.bgcolor
        self._refresh()

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
