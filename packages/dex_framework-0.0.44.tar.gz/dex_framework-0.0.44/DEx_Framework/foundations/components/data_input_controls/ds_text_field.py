from __future__ import annotations
from typing import Literal, Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_input import TK_TextFieldToken as TextFieldToken, TK_InputTokens as InputTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

FieldState = Literal["normal", "readonly", "required"]


class DS_TextField(ft.TextField):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",

        # Tokens e tema
        # -------------
        token: TextFieldToken = InputTokens.outlined,

        # Textos e rótulos
        # ----------------
        hint_text: Optional[str] = None,

        # Geral
        # -----
        state: FieldState = "normal",
        multiline: bool = False,
        min_lines: Optional[int] = None,
        max_lines: Optional[int] = None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._state = state
        self._use_theme_token = token is InputTokens.outlined and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.input
        self._token = token

        bgcolor, border_color, label_color, read_only = self._resolve_state(token, state)

        super().__init__(
            label=label,
            hint_text=hint_text,
            text_size=token.text_size,
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_radius=token.border_radius,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            label_style=ft.TextStyle(color=label_color),
            cursor_color=token.cursor_color,
            bgcolor=bgcolor,
            content_padding=token.content_padding,
            read_only=read_only,
            multiline=multiline,
            min_lines=min_lines if multiline else None,
            max_lines=max_lines if multiline else None,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _resolve_state(token: TextFieldToken, state: FieldState):
        if state == "readonly":
            return (
                token.bgcolor_readonly,
                token.border_color_readonly,
                token.label_color,
                True,
            )
        if state == "required":
            return (
                token.bgcolor_required,
                token.border_color_required,
                token.label_color_required,
                False,
            )
        return token.bgcolor, token.border_color, token.label_color, False

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.input
        token = self._token
        bgcolor, border_color, label_color, read_only = self._resolve_state(token, self._state)
        self.text_size = token.text_size
        self.border_color = border_color
        self.focused_border_color = token.focused_border_color
        self.border_radius = token.border_radius
        self.border_width = token.border_width
        self.focused_border_width = token.focused_border_width
        self.label_style = ft.TextStyle(color=label_color)
        self.cursor_color = token.cursor_color
        self.bgcolor = bgcolor
        self.content_padding = token.content_padding
        self.read_only = read_only
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
