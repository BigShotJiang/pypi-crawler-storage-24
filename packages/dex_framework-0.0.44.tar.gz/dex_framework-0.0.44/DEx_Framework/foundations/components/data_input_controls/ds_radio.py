from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_radio import TK_RadioToken as RadioToken, TK_RadioTokens as RadioTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


@dataclass
class RadioOption:
    label: str
    value: str


class DS_RadioGroup(ft.RadioGroup):

    def __init__(
        self,

        # Geral
        # -----
        options: list,

        # Tokens e tema
        # -------------
        token: RadioToken = RadioTokens.primary,
        value: Optional[str] = None,

        # Parâmetros do botão
        # -------------------
        disabled: bool = False,

        # Callbacks
        # ---------
        on_change=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._options = options
        self._value = value
        self._disabled = disabled
        self._on_change = on_change

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is RadioTokens.primary and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.radio
        self._token = token

        super().__init__(
            value=value,
            on_change=on_change,
            content=self._build_radios(token),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build_radios(self, token: RadioToken) -> ft.Column:
        radios = [
            ft.Radio(
                label=opt.label,
                value=opt.value,
                fill_color=token.disabled_color if self._disabled else token.active_color,
                label_style=ft.TextStyle(
                    size=token.label_size,
                    color=token.disabled_color if self._disabled else token.label_color,
                ),
                splash_radius=token.splash_radius,
            )
            for opt in self._options
        ]

        return ft.Column(
            controls=radios,
            spacing=4,
            disabled=self._disabled,
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.radio
        self.content = self._build_radios(self._token)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
