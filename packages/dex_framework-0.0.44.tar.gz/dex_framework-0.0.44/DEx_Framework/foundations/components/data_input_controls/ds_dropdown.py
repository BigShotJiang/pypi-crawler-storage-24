from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_dropdown import TK_DropdownToken as DropdownToken, TK_DropdownTokens as DropdownTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

FieldState = Literal["normal", "readonly", "required"]


@dataclass
class DropdownOption:
    label: str
    value: str
    icon: Optional[str] = None


class DS_Dropdown(ft.Dropdown):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",

        # Geral
        # -----
        options: Optional[list] = None,

        # Tokens e tema
        # -------------
        token: DropdownToken = DropdownTokens.outlined,
        state: FieldState = "normal",
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._state = state
        self._use_theme_token = token is DropdownTokens.outlined and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.dropdown
        self._token = token

        bgcolor, border_color, label_color, disabled = self._resolve_state(token, state)

        built_options = self._build_options(options or [], token)

        super().__init__(
            label=label,
            options=built_options,
            text_size=token.text_size,
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_radius=token.border_radius,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            label_style=ft.TextStyle(color=label_color),
            bgcolor=bgcolor,
            content_padding=token.content_padding,
            disabled=disabled,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _resolve_state(token: DropdownToken, state: FieldState):
        if state == "readonly":
            return token.bgcolor_readonly, token.border_color_readonly, token.label_color, True
        if state == "required":
            return token.bgcolor_required, token.border_color_required, token.label_color_required, False
        return token.bgcolor, token.border_color, token.label_color, False

    @staticmethod
    def _build_options(options: list, token: DropdownToken) -> list:
        result = []
        for opt in options:
            result.append(
                ft.dropdown.Option(
                    key=opt.value,
                    text=opt.label,
                    leading_icon=ft.Icon(
                        name=opt.icon,
                        size=token.icon_size,
                        color=token.icon_color,
                    ) if opt.icon else None,
                )
            )
        return result

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.dropdown
        token = self._token
        bgcolor, border_color, label_color, disabled = self._resolve_state(token, self._state)
        self.text_size = token.text_size
        self.border_color = border_color
        self.focused_border_color = token.focused_border_color
        self.border_radius = token.border_radius
        self.border_width = token.border_width
        self.focused_border_width = token.focused_border_width
        self.label_style = ft.TextStyle(color=label_color)
        self.bgcolor = bgcolor
        self.content_padding = token.content_padding
        self.disabled = disabled
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
