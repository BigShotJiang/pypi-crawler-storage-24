from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_search import TK_SearchToken as SearchToken, TK_SearchTokens as SearchTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_Search(ft.TextField):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        hint_text: str = "Pesquisar...",

        # Tokens e tema
        # -------------
        token: SearchToken = SearchTokens.outlined,

        # Dimensões e layout
        # ------------------
        width: Optional[float] = None,

        # Parâmetros do botão
        # -------------------
        disabled: bool = False,

        # Callbacks
        # ---------
        on_change=None,
        on_submit=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._disabled = disabled
        self._use_theme_token = token in (SearchTokens.outlined, SearchTokens.dark, SearchTokens.filled) and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.search
        self._token = token
        self._width_override = width

        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        border_color = token.border_color_disabled if disabled else token.border_color

        super().__init__(
            hint_text=hint_text,
            hint_style=ft.TextStyle(color=token.hint_color),
            text_style=ft.TextStyle(color=token.text_color),
            prefix_icon=ft.Icon(name=ft.Icons.SEARCH, size=token.icon_size, color=token.icon_color),
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            border_radius=token.border_radius,
            bgcolor=bgcolor,
            content_padding=ft.padding.symmetric(
                horizontal=token.content_padding_horizontal,
                vertical=token.content_padding_vertical,
            ),
            text_size=token.text_size,
            cursor_color=token.focused_border_color,
            height=token.height,
            width=width if width is not None else token.width,
            disabled=disabled,
            on_change=on_change,
            on_submit=on_submit,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.search
        token = self._token
        disabled = self._disabled
        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        border_color = token.border_color_disabled if disabled else token.border_color
        self.hint_style = ft.TextStyle(color=token.hint_color)
        self.text_style = ft.TextStyle(color=token.text_color)
        self.prefix_icon = ft.Icon(name=ft.Icons.SEARCH, size=token.icon_size, color=token.icon_color)
        self.border_color = border_color
        self.focused_border_color = token.focused_border_color
        self.border_width = token.border_width
        self.focused_border_width = token.focused_border_width
        self.border_radius = token.border_radius
        self.bgcolor = bgcolor
        self.content_padding = ft.padding.symmetric(
            horizontal=token.content_padding_horizontal,
            vertical=token.content_padding_vertical,
        )
        self.text_size = token.text_size
        self.cursor_color = token.focused_border_color
        self.height = token.height
        self.width = self._width_override if self._width_override is not None else token.width
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
