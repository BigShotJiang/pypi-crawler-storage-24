from __future__ import annotations
from typing import Callable, Optional, Sequence

import flet as ft

from DEx_Framework.foundations.components.actions_commands.ds_button import DS_Button
from DEx_Framework.foundations.components.overlays_dialogs.ds_modal import DS_Modal, ModalAction
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_button import TK_ButtonTokens as ButtonTokens
from DEx_Framework.foundations.tokens.tk_modal import TK_ModalToken as ModalToken, TK_ModalTokens as ModalTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_FilePicker:

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str = "Selecionar arquivos",
        subtitle: Optional[str] = "Escolha os arquivos para upload",

        # Tokens e tema
        # -------------
        token: ModalToken = ModalTokens.default,

        # Dimensões e layout
        # ------------------
        width: int = 500,
        height: int = 400,

        # Geral
        # -----
        allow_multiple: bool = True,
        file_type: ft.FilePickerFileType = ft.FilePickerFileType.ANY,
        allowed_extensions: Optional[Sequence[str]] = None,
        pick_button_label: str = "Escolher arquivos",
        clear_button_label: str = "Limpar",
        pick_button_radius: Optional[float] = None,
        clear_button_radius: Optional[float] = None,
        cancel_label: str = "Cancelar",
        confirm_label: str = "Confirmar",

        # Callbacks
        # ---------
        on_pick: Optional[Callable[[list], None]] = None,
        on_confirm: Optional[Callable[[list], None]] = None,
        on_cancel: Optional[Callable[[], None]] = None,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._page: Optional[ft.Page] = None
        self._on_pick = on_pick
        self._on_confirm = on_confirm
        self._on_cancel = on_cancel
        self._files: list = []
        self._width = width
        self._height = height

        self.allow_multiple = allow_multiple
        self.file_type = file_type
        self.allowed_extensions = allowed_extensions

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._theme: Optional[TK_Theme] = self._theme_manager.theme if self._theme_manager is not None else None
        self._use_theme_token = token is ModalTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme.modal
        self._token = token

        self._count_text = ft.Text("0 arquivo(s)", size=12, color="#6750A4")
        self._files_list = ft.Column(spacing=6, height=height - 160, scroll=ft.ScrollMode.AUTO)

        self._info_title = ft.Text("Selecao de arquivos", size=14, weight="w600", color="#1C1B1F")
        self._info_desc = ft.Text(
            "Use o botao abaixo para abrir o seletor do sistema.",
            size=12,
            color="#49454F",
        )

        self._pick_button = DS_Button(
            label=pick_button_label,
            icon=ft.Icons.FOLDER_OPEN,
            token=ButtonTokens.filled,
            radius=pick_button_radius,
            on_click=self._open_picker,
            theme_manager=self._theme_manager,
            auto_apply_theme=auto_apply_theme,
        )
        self._clear_button = DS_Button(
            label=clear_button_label,
            icon=ft.Icons.CLEAR,
            token=ButtonTokens.outlined,
            radius=clear_button_radius,
            on_click=self._clear_selection,
            theme_manager=self._theme_manager,
            auto_apply_theme=auto_apply_theme,
        )

        left_column = ft.Column(
            spacing=12,
            width=190,
            controls=[
                self._info_title,
                self._info_desc,
                self._pick_button,
                self._clear_button,
                ft.Container(height=8),
                self._count_text,
            ],
        )

        self._files_box = ft.Container(
            expand=True,
            padding=12,
            border=ft.border.all(1, "#D0C4D6"),
            border_radius=10,
            bgcolor="#FFFFFF",
            content=self._files_list,
        )

        content = ft.Container(
            width=width,
            height=height,
            padding=ft.padding.all(12),
            content=ft.Row(
                spacing=16,
                vertical_alignment=ft.CrossAxisAlignment.START,
                controls=[left_column, self._files_box],
            ),
        )

        self._file_picker = ft.FilePicker(on_result=self._on_result)

        self._modal = DS_Modal(
            title=title,
            subtitle=subtitle,
            icon=ft.Icons.FILE_OPEN,
            token=token,
            content=content,
            actions=[
                ModalAction(label=cancel_label, on_click=self._handle_cancel),
                ModalAction(label=confirm_label, primary=True, on_click=self._handle_confirm),
            ],
            theme_manager=self._theme_manager,
            auto_apply_theme=auto_apply_theme,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

        self._render_files()
        self._apply_theme(self._theme)

    def _apply_theme(self, theme: Optional[TK_Theme]):
        if theme is None:
            return
        self._theme = theme
        self._count_text.color = theme.text_accent
        self._info_title.color = theme.text_primary
        self._info_desc.color = theme.text_secondary
        self._files_box.bgcolor = theme.card.bgcolor
        self._files_box.border = ft.border.all(1, theme.card.border_color or "#D0C4D6")
        self._files_box.border_radius = theme.card.border_radius
        self._render_files()
        try:
            self._files_box.update()
        except Exception:
            pass

    def _render_files(self):
        t = self._theme
        text_primary = t.text_primary if t is not None else "#1C1B1F"
        text_secondary = t.text_secondary if t is not None else "#49454F"
        accent = t.text_accent if t is not None else "#6750A4"

        self._files_list.controls = []
        if not self._files:
            self._files_list.controls.append(
                ft.Text("Nenhum arquivo selecionado", size=12, color=text_secondary)
            )
        else:
            for item in self._files:
                name = getattr(item, "name", None) or str(item)
                self._files_list.controls.append(
                    ft.Row(
                        spacing=6,
                        controls=[
                            ft.Icon(ft.Icons.INSERT_DRIVE_FILE, size=16, color=accent),
                            ft.Text(name, size=12, color=text_primary),
                        ],
                    )
                )
        self._count_text.value = f"{len(self._files)} arquivo(s)"

    def _open_picker(self, e):
        if not self._page:
            return
        self._file_picker.pick_files(
            allow_multiple=self.allow_multiple,
            file_type=self.file_type,
            allowed_extensions=self.allowed_extensions,
        )

    def _clear_selection(self, e):
        self._files = []
        self._render_files()
        if self._page:
            self._page.update()

    def _on_result(self, e: ft.FilePickerResultEvent):
        files = e.files or []
        if files:
            self._files = list(files)
        else:
            self._files = [e.path] if e.path else []

        self._render_files()
        if self._on_pick:
            self._on_pick(self._files)
        if self._page:
            self._page.update()

    def _handle_confirm(self, e):
        if self._on_confirm:
            self._on_confirm(self._files)
        if self._page:
            self.close_modal(self._page)

    def _handle_cancel(self, e):
        if self._on_cancel:
            self._on_cancel()
        if self._page:
            self.close_modal(self._page)

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    def open_modal(self, page: ft.Page):
        self._page = page
        if self._file_picker not in page.overlay:
            page.overlay.append(self._file_picker)
        self._modal.open_modal(page)

    def close_modal(self, page: ft.Page):
        self._modal.close_modal(page)
