from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_checkbox import TK_CheckboxToken as CheckboxToken, TK_CheckboxTokens as CheckboxTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_Checkbox(ft.Checkbox):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",

        # Tokens e tema
        # -------------
        token: CheckboxToken = CheckboxTokens.primary,

        # Geral
        # -----
        value: bool = False,
        disabled: bool = False,

        # Callbacks
        # ---------
        on_change=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._disabled = disabled
        self._use_theme_token = token is CheckboxTokens.primary and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.checkbox
        self._token = token

        super().__init__(
            label=label,
            value=value,
            disabled=disabled,
            on_change=on_change,
            active_color=token.active_color if not disabled else token.disabled_color,
            check_color=token.check_color,
            border_side=ft.BorderSide(
                width=2,
                color=token.disabled_color if disabled else token.border_color,
            ),
            label_style=ft.TextStyle(
                size=token.label_size,
                color=token.disabled_color if disabled else token.label_color,
            ),
            splash_radius=token.splash_radius,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        token = theme.checkbox
        self._token = token
        disabled = self._disabled
        self.active_color = token.active_color if not disabled else token.disabled_color
        self.check_color = token.check_color
        self.border_side = ft.BorderSide(
            width=2,
            color=token.disabled_color if disabled else token.border_color,
        )
        self.label_style = ft.TextStyle(
            size=token.label_size,
            color=token.disabled_color if disabled else token.label_color,
        )
        self.splash_radius = token.splash_radius
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
