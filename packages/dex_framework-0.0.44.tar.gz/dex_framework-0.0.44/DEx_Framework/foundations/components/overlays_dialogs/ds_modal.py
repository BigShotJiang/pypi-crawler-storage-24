from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_modal import TK_ModalToken as ModalToken, TK_ModalTokens as ModalTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


@dataclass
class ModalAction:
    label: str
    on_click: Optional[object] = None
    icon: Optional[str] = None
    primary: bool = False


class DS_Modal(ft.AlertDialog):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,
        subtitle: Optional[str] = None,

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,

        # Geral
        # -----
        content: Optional[ft.Control] = None,
        actions: Optional[list] = None,

        # Tokens e tema
        # -------------
        token: ModalToken = ModalTokens.default,

        # Comportamento do modal
        # ----------------------
        modal: bool = True,

        # Callbacks
        # ---------
        on_dismiss=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._title = title
        self._subtitle = subtitle
        self._icon = icon
        self._content_ctrl = content
        self._actions = actions or []

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token in (ModalTokens.default, ModalTokens.dark) and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.modal
        self._token = token

        built_title = self._build_title(title, subtitle, icon, token)
        built_actions = self._build_actions(self._actions, token)

        super().__init__(
            modal=modal,
            title=built_title,
            content=ft.Container(
                content=content,
                padding=ft.padding.symmetric(vertical=4),
            ) if content else None,
            actions=built_actions if built_actions else None,
            actions_alignment=ft.MainAxisAlignment.END,
            on_dismiss=on_dismiss,
            shape=ft.RoundedRectangleBorder(
                radius=token.border_radius
            ),
            bgcolor=token.bgcolor,
            shadow_color=token.shadow_color,
            title_padding=ft.padding.all(token.padding),
            content_padding=ft.padding.symmetric(horizontal=token.padding, vertical=0),
            actions_padding=ft.padding.only(
                left=token.padding,
                right=token.padding,
                bottom=token.padding,
                top=8,
            ),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _build_title(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        token: ModalToken,
    ) -> ft.Control:
        title_text = ft.Text(
            value=title,
            size=token.title_size,
            weight=token.title_weight,
            color=token.title_color,
        )

        if icon:
            title_row = ft.Row(
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            return ft.Column(
                spacing=4,
                tight=True,
                controls=[
                    title_row,
                    ft.Text(
                        value=subtitle,
                        size=token.subtitle_size,
                        weight=token.subtitle_weight,
                        color=token.subtitle_color,
                    ),
                    ft.Divider(height=token.spacing, thickness=token.divider_thickness, color=token.divider_color),
                ],
            )

        return ft.Column(
            spacing=4,
            tight=True,
            controls=[
                title_row,
                ft.Divider(height=token.spacing, thickness=token.divider_thickness, color=token.divider_color),
            ],
        )

    @staticmethod
    def _build_actions(actions: list, token: ModalToken) -> list:
        accent = token.icon_color
        result = []
        for action in actions:
            if action.primary:
                btn = ft.ElevatedButton(
                    text=action.label,
                    icon=action.icon,
                    on_click=action.on_click,
                    style=ft.ButtonStyle(
                        bgcolor=accent,
                        color="#FFFFFF",
                        shape=ft.RoundedRectangleBorder(radius=20),
                        padding=ft.padding.symmetric(horizontal=24, vertical=10),
                    ),
                )
            else:
                btn = ft.TextButton(
                    text=action.label,
                    icon=action.icon,
                    on_click=action.on_click,
                    style=ft.ButtonStyle(
                        color=accent,
                        shape=ft.RoundedRectangleBorder(radius=20),
                        padding=ft.padding.symmetric(horizontal=16, vertical=10),
                    ),
                )
            result.append(btn)
        return result

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.modal
        token = self._token
        self.title = self._build_title(self._title, self._subtitle, self._icon, token)
        self.actions = self._build_actions(self._actions, token) if self._actions else None
        self.shape = ft.RoundedRectangleBorder(
            radius=token.border_radius
        )
        self.bgcolor = token.bgcolor
        self.shadow_color = token.shadow_color
        self.title_padding = ft.padding.all(token.padding)
        self.content_padding = ft.padding.symmetric(horizontal=token.padding, vertical=0)
        self.actions_padding = ft.padding.only(
            left=token.padding,
            right=token.padding,
            bottom=token.padding,
            top=8,
        )
        if self._content_ctrl is not None:
            self.content = ft.Container(
                content=self._content_ctrl,
                padding=ft.padding.symmetric(vertical=4),
            )
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    def open_modal(self, page: ft.Page):
        self.open = True
        page.overlay.append(self)
        page.update()

    def close_modal(self, page: ft.Page):
        self.open = False
        page.update()
