# =============================================================================
# DEx-Framework
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
# =============================================================================
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Callable, List

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_line_chart import TK_LineChartToken, TK_LineChartTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class LineChartPoint:
    x: float
    y: float
    tooltip: Optional[str] = None


@dataclass
class LineChartSeries:
    name: str
    points: List[LineChartPoint]
    color: Optional[str] = None
    stroke_width: Optional[float] = None
    curved: bool = True
    show_dots: bool = True
    dashed: bool = False


# ---------------------------------------------------------------------------
# Component
# ---------------------------------------------------------------------------

class DS_LineChart(ft.Container):
    """
    DS_LineChart
    
    Finalidade:
    - Componente DS_LineChart.
    
    Detalhes:
    - Classe: DS_LineChart.
    - Base: ft.Container.
    
    Parâmetros:
    
    Segmento: Geral
    ---
    - series (List[LineChartSeries]): Parâmetro series.
    - x_labels (Optional[List[str]]): Parâmetro x_labels.
    
    Segmento: Textos e rótulos
    ---
    - title (str): Parâmetro title.
    - show_title (bool): Define se show title.
    - show_legend (bool): Define se show legend.
    - show_grid (bool): Define se show grid.
    - show_dots (bool): Define se show dots.
    
    Segmento: Dimensões e layout
    ---
    - width (Optional[float]): Valor de width.
    - height (Optional[float]): Valor de height.
    
    Segmento: Tokens e tema
    ---
    - token (Optional[TK_LineChartToken]): Token usado para estilização.
    
    Segmento: Callbacks
    ---
    - on_point_hover (Optional[Callable]): Callback executado quando point hover.
    - theme_manager (Optional[DS_ThemeManager]): Gerenciador de tema.
    
    Segmento: Parâmetros do botão
    ---
    - auto_apply_theme (bool): Parâmetro auto_apply_theme.
    
    Segmento: Outros
    ---
    - **kwargs: Parâmetros adicionais.
    """

    def __init__(
        self,

        # Geral
        # -----
        series: List[LineChartSeries],
        x_labels: Optional[List[str]] = None,

        # Textos e rótulos
        # ----------------
        title: str = "",
        show_title: bool = True,
        show_legend: bool = True,
        show_grid: bool = True,
        show_dots: bool = True,

        # Dimensões e layout
        # ------------------
        width: Optional[float] = None,
        height: Optional[float] = None,

        # Tokens e tema
        # -------------
        token: Optional[TK_LineChartToken] = None,

        # Callbacks
        # ---------
        on_point_hover: Optional[Callable] = None,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        super().__init__(**kwargs)
        self._series = series
        self._x_labels = x_labels or []
        self._title = title
        self._show_title = show_title
        self._show_legend = show_legend
        self._show_grid = show_grid
        self._show_dots = show_dots
        self._chart_width = width
        self._chart_height_override = height
        self._on_point_hover = on_point_hover

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = (token is None or token is TK_LineChartTokens.default) and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.line_chart
        self._token = token or TK_LineChartTokens.default
        self._chart_height = height or self._token.height

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

        self._rebuild()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _color(self, index: int, override: Optional[str] = None) -> str:
        if override:
            return override
        palette = self._token.series_colors
        return palette[index % len(palette)]

    def _y_bounds(self):
        all_y = [p.y for s in self._series for p in s.points]
        if not all_y:
            return 0.0, 100.0
        mn, mx = min(all_y), max(all_y)
        rng = mx - mn
        pad = rng * 0.15 if rng > 0 else (abs(mx) * 0.15 or 10)
        return mn - pad, mx + pad

    # ------------------------------------------------------------------
    # Internal builders
    # ------------------------------------------------------------------

    def _build_chart(self) -> ft.LineChart:
        t = self._token
        data_series = []

        for i, s in enumerate(self._series):
            color = self._color(i, s.color)
            stroke = s.stroke_width or t.stroke_width

            dot = ft.ChartCirclePoint(
                radius=t.dot_size,
                color=color,
                stroke_color=color,
                stroke_width=1.5,
            )
            no_dot = ft.ChartCirclePoint(radius=0)

            points = []
            for p in s.points:
                label = p.tooltip or str(round(p.y, 2))
                points.append(
                    ft.LineChartDataPoint(
                        x=p.x,
                        y=p.y,
                        tooltip=label,
                        point=dot if (self._show_dots and s.show_dots) else no_dot,
                        selected_point=ft.ChartCirclePoint(
                            radius=t.dot_size + 2,
                            color=color,
                            stroke_color="#FFFFFF",
                            stroke_width=2,
                        ),
                    )
                )

            series_kwargs = dict(
                data_points=points,
                stroke_width=stroke,
                color=color,
                curved=s.curved,
                stroke_cap_round=True,
            )
            if s.dashed:
                series_kwargs["dash_pattern"] = [5, 4]

            data_series.append(ft.LineChartData(**series_kwargs))

        x_axis_labels = [
            ft.ChartAxisLabel(
                value=i,
                label=ft.Container(
                    content=ft.Text(
                        lbl,
                        size=t.label_size,
                        color=t.label_color,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    width=48,
                ),
            )
            for i, lbl in enumerate(self._x_labels)
        ]

        min_y, max_y = self._y_bounds()

        grid_lines = ft.ChartGridLines(
            color=t.grid_color, width=1, dash_pattern=[3, 3]
        )

        return ft.LineChart(
            data_series=data_series,
            border=ft.border.all(t.border_width, t.border_color),
            horizontal_grid_lines=grid_lines if self._show_grid else ft.ChartGridLines(width=0),
            vertical_grid_lines=ft.ChartGridLines(width=0),
            left_axis=ft.ChartAxis(labels_size=45, show_labels=True),
            bottom_axis=ft.ChartAxis(
                labels=x_axis_labels,
                labels_size=36,
                show_labels=bool(x_axis_labels),
            ),
            tooltip_bgcolor=t.tooltip_bgcolor,
            min_y=min_y,
            max_y=max_y,
            expand=True,
            on_chart_event=self._on_point_hover,
        )

    def _build_legend(self) -> ft.Container:
        t = self._token
        items = []
        for i, s in enumerate(self._series):
            color = self._color(i, s.color)
            if s.dashed:
                line_ctrl = ft.Row(
                    spacing=2, tight=True,
                    controls=[
                        ft.Container(width=6, height=3, bgcolor=color, border_radius=1),
                        ft.Container(width=3, height=3, bgcolor=color, border_radius=1, opacity=0.35),
                        ft.Container(width=5, height=3, bgcolor=color, border_radius=1),
                    ],
                )
            else:
                line_ctrl = ft.Container(width=18, height=3, bgcolor=color, border_radius=2)

            items.append(
                ft.Row(
                    spacing=6, tight=True,
                    controls=[
                        line_ctrl,
                        ft.Text(s.name, size=11, color=t.label_color),
                    ],
                )
            )

        border = (
            ft.border.all(1, t.legend_border_color)
            if t.legend_border_color != "transparent"
            else None
        )
        return ft.Container(
            content=ft.Row(spacing=16, wrap=True, controls=items),
            bgcolor=t.legend_bgcolor,
            border=border,
            border_radius=t.legend_border_radius,
            padding=ft.padding.symmetric(horizontal=12, vertical=6),
        )

    def _rebuild(self):
        t = self._token
        col: List[ft.Control] = []

        if self._show_title and self._title:
            col.append(
                ft.Text(
                    self._title,
                    size=t.title_size,
                    weight=t.title_weight,
                    color=t.title_color,
                )
            )

        col.append(
            ft.Container(
                content=self._build_chart(),
                height=self._chart_height,
                expand=self._chart_width is None,
            )
        )

        if self._show_legend and self._series:
            col.append(self._build_legend())

        # Apply to self (ft.Container)
        self.content = ft.Column(spacing=10, controls=col, tight=True)
        self.bgcolor = t.bgcolor
        self.border = (
            ft.border.all(t.border_width, t.border_color)
            if t.border_width > 0 else None
        )
        self.border_radius = t.border_radius
        self.padding = t.padding
        self.width = self._chart_width

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.line_chart
        self._chart_height = self._chart_height_override or self._token.height
        self._rebuild()
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def toggle_legend(self):
        """Exibe/oculta a legenda."""
        self._show_legend = not self._show_legend
        self._rebuild()
        self.update()

    def toggle_title(self):
        """Exibe/oculta o titulo."""
        self._show_title = not self._show_title
        self._rebuild()
        self.update()

    def toggle_grid(self):
        """Exibe/oculta as linhas de grade."""
        self._show_grid = not self._show_grid
        self._rebuild()
        self.update()

    def toggle_dots(self):
        """Exibe/oculta os pontos nas series."""
        self._show_dots = not self._show_dots
        self._rebuild()
        self.update()

    def set_title(self, title: str):
        """Atualiza o titulo do grafico."""
        self._title = title
        self._rebuild()
        self.update()

    def set_series(self, series: List[LineChartSeries]):
        """Substitui todas as series."""
        self._series = series
        self._rebuild()
        self.update()

    def add_point(self, series_index: int, point: LineChartPoint):
        """Adiciona um ponto a uma serie existente (live update)."""
        if 0 <= series_index < len(self._series):
            self._series[series_index].points.append(point)
            self._rebuild()
            self.update()

    def set_x_labels(self, labels: List[str]):
        """Substitui os rotulos do eixo X."""
        self._x_labels = labels
        self._rebuild()
        self.update()
