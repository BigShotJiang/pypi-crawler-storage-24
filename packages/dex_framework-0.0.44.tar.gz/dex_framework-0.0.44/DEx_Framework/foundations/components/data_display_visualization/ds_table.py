from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_table import TK_TableToken as TableToken, TK_TableTokens as TableTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


@dataclass
class TableColumn:
    label: str
    key: str
    width: Optional[float] = None
    sortable: bool = False
    render: Optional[Callable] = None


@dataclass
class TableRow:
    data: dict
    on_click: Optional[Callable] = None


class DS_Table(ft.Column):
    """
    DS_Table
    
    Finalidade:
    - Componente DS_Table.
    
    Detalhes:
    - Classe: DS_Table.
    - Base: ft.Column.
    
    Parâmetros:
    
    Segmento: Geral
    ---
    - columns (list): Parâmetro columns.
    - rows (list): Parâmetro rows.
    
    Segmento: Tokens e tema
    ---
    - token (TableToken): Token usado para estilização.
    - selectable (bool): Parâmetro selectable.
    - alternating_rows (bool): Parâmetro alternating_rows.
    - sort_column (Optional[str]): Parâmetro sort_column.
    - sort_ascending (bool): Parâmetro sort_ascending.
    
    Segmento: Callbacks
    ---
    - on_sort (Optional[Callable]): Callback executado quando sort.
    
    Segmento: Dimensões e layout
    ---
    - width (Optional[float]): Valor de width.
    - theme_manager (Optional[DS_ThemeManager]): Gerenciador de tema.
    
    Segmento: Parâmetros do botão
    ---
    - auto_apply_theme (bool): Parâmetro auto_apply_theme.
    
    Segmento: Outros
    ---
    - **kwargs: Parâmetros adicionais.
    """

    def __init__(
        self,

        # Geral
        # -----
        columns: list,
        rows: list,

        # Tokens e tema
        # -------------
        token: TableToken = TableTokens.default,
        selectable: bool = False,
        alternating_rows: bool = True,
        sort_column: Optional[str] = None,
        sort_ascending: bool = True,

        # Callbacks
        # ---------
        on_sort: Optional[Callable] = None,

        # Dimensões e layout
        # ------------------
        width: Optional[float] = None,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token in (TableTokens.default, TableTokens.minimal, TableTokens.dark) and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.table
        self._token = token
        self._columns = columns
        self._rows = rows
        self._selectable = selectable
        self._alternating = alternating_rows
        self._sort_col = sort_column
        self._sort_asc = sort_ascending
        self._on_sort = on_sort
        self._selected: set = set()
        self._width = width

        self._container = ft.Container(
            content=self._build_table(),
            border=ft.border.all(token.border_width, token.border_color),
            border_radius=token.border_radius,
            bgcolor=token.bgcolor,
            width=width,
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        )

        super().__init__(controls=[self._container], spacing=0, **kwargs)

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build_table(self) -> ft.DataTable:
        token = self._token

        columns = []

        if self._selectable:
            columns.append(ft.DataColumn(label=ft.Text("")))

        for col in self._columns:
            label_controls = [
                ft.Text(
                    value=col.label,
                    size=token.header_text_size,
                    weight=token.header_text_weight,
                    color=token.header_text_color,
                ),
            ]
            if col.sortable and self._sort_col == col.key:
                label_controls.append(
                    ft.Icon(
                        name=ft.Icons.ARROW_UPWARD if self._sort_asc else ft.Icons.ARROW_DOWNWARD,
                        size=14,
                        color=token.icon_color,
                    )
                )

            columns.append(
                ft.DataColumn(
                    label=ft.Row(
                        spacing=4,
                        tight=True,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=label_controls,
                    ),
                    numeric=False,
                    on_sort=(
                        (lambda k: lambda e: self._handle_sort(k))(col.key)
                    ) if col.sortable else None,
                )
            )

        rows = []
        for idx, row in enumerate(self._rows):
            bg = (
                token.row_selected_color if idx in self._selected
                else (token.row_alt_bgcolor if self._alternating and idx % 2 != 0 else token.row_bgcolor)
            )

            cells = []

            if self._selectable:
                cells.append(
                    ft.DataCell(
                        ft.Checkbox(
                            value=idx in self._selected,
                            active_color=token.checkbox_color,
                            on_change=(lambda i: lambda e: self._toggle_select(i))(idx),
                        )
                    )
                )

            for col in self._columns:
                value = row.data.get(col.key, "")
                cell_content = col.render(value) if col.render else ft.Text(
                    value=str(value),
                    size=token.cell_text_size,
                    color=token.cell_text_color,
                )
                cells.append(ft.DataCell(cell_content))

            rows.append(
                ft.DataRow(
                    cells=cells,
                    color=bg,
                    on_select_changed=row.on_click,
                )
            )

        return ft.DataTable(
            columns=columns,
            rows=rows,
            border=ft.border.only(bottom=ft.BorderSide(token.divider_thickness, token.divider_color)),
            horizontal_lines=ft.BorderSide(token.divider_thickness, token.divider_color),
            heading_row_color=token.header_bgcolor,
            heading_row_height=48,
            data_row_min_height=token.cell_padding_vertical * 2 + 20,
            data_row_max_height=token.cell_padding_vertical * 2 + 40,
            column_spacing=token.cell_padding_horizontal,
            horizontal_margin=token.cell_padding_horizontal,
            bgcolor=token.bgcolor,
            show_checkbox_column=False,
        )

    def _handle_sort(self, key: str):
        if self._sort_col == key:
            self._sort_asc = not self._sort_asc
        else:
            self._sort_col = key
            self._sort_asc = True
        if self._on_sort:
            self._on_sort(self._sort_col, self._sort_asc)
        self._refresh()

    def _toggle_select(self, idx: int):
        if idx in self._selected:
            self._selected.discard(idx)
        else:
            self._selected.add(idx)
        self._refresh()

    def _refresh(self):
        self._container.content = self._build_table()
        try:
            self.update()
        except Exception:
            pass

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.table
        token = self._token
        self._container.border = ft.border.all(token.border_width, token.border_color)
        self._container.border_radius = token.border_radius
        self._container.bgcolor = token.bgcolor
        self._container.width = self._width
        self._refresh()

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
