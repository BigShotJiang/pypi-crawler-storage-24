# =============================================================================
# DEx-Framework
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
# =============================================================================
from __future__ import annotations
from typing import Optional
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_progressbar import TK_ProgressBarToken, TK_ProgressBarTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_ProgressBar(ft.Container):

    def __init__(
        self,

        # Geral
        # -----
        value: float = 0.0,

        # Dimensões e layout
        # ------------------
        width: float | None = None,
        height: float = 8,
        bgcolor: str | None = None,
        progress_color: str | None = None,
        border_radius: int | float = 999,

        # Textos e rótulos
        # ----------------
        show_label: bool = False,
        label_color: str | None = None,
        label_size: int = 12,
        animate: bool = False,
        tooltip: str | None = None,

        # Tokens e tema
        # -------------
        token: TK_ProgressBarToken = TK_ProgressBarTokens.default,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        super().__init__(**kwargs)

        self._value = self._normalize(value)
        self._bar_height = height
        self._border_radius = border_radius
        self._show_label = show_label
        self._label_size = label_size
        self._animate = animate

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_ProgressBarTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.progressbar
        self._token = token

        self._bgcolor_override = bgcolor
        self._progress_color_override = progress_color
        self._label_color_override = label_color

        self.width = width
        self.tooltip = tooltip
        self.expand = width is None

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

        self._rebuild()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize(v: float) -> float:
        return max(0.0, min(1.0, v))

    def _current_colors(self):
        t = self._token
        bgcolor = self._bgcolor_override if self._bgcolor_override is not None else t.track_bgcolor
        progress_color = self._progress_color_override if self._progress_color_override is not None else t.progress_color
        label_color = self._label_color_override if self._label_color_override is not None else t.label_color
        return bgcolor, progress_color, label_color

    def _build_label(self) -> ft.Text:
        _, _, label_color = self._current_colors()
        return ft.Text(
            f"{int(self._value * 100)}%",
            size=self._label_size,
            color=label_color,
            weight=ft.FontWeight.W_500,
            text_align=ft.TextAlign.CENTER,
        )

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def _rebuild(self):
        bgcolor, progress_color, _ = self._current_colors()
        radius = ft.border_radius.all(self._border_radius)

        bar = ft.Stack(
            height=self._bar_height,
            expand=True,
            controls=[
                ft.Container(
                    bgcolor=bgcolor,
                    border_radius=radius,
                    height=self._bar_height,
                    expand=True,
                ),
                ft.Container(
                    content=ft.ProgressBar(
                        value=self._value,
                        bgcolor=ft.Colors.TRANSPARENT,
                        color=progress_color,
                        border_radius=radius,
                        height=self._bar_height,
                    ),
                    expand=True,
                    height=self._bar_height,
                    animate=ft.Animation(300, ft.AnimationCurve.EASE_IN_OUT)
                    if self._animate else None,
                ),
            ],
        )

        col_controls: list[ft.Control] = []

        if self._show_label:
            col_controls.append(self._build_label())

        col_controls.append(bar)

        self.content = ft.Column(
            spacing=4,
            tight=True,
            controls=col_controls,
        )
        self.expand = self.width is None

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.progressbar
        self._rebuild()
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_value(self, value: float):
        self._value = self._normalize(value)
        self._rebuild()
        self.update()
