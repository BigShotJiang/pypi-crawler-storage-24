from __future__ import annotations
from typing import Optional
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_kpi_card import TK_KPICardToken, TK_KPICardTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_KPICard(ft.Container):

    def __init__(
        self,

        # Textos e rótulos
        # ----------------
        title: str,

        # Geral
        # -----
        value: str,
        variation: Optional[float] = None,
        variation_label: str = "",

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,
        trend: str = "neutral",

        # Tokens e tema
        # -------------
        token: TK_KPICardToken = TK_KPICardTokens.default,

        # Dimensões e layout
        # ------------------
        width: Optional[float] = 220,

        # Callbacks
        # ---------
        on_click=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._title = title
        self._value = value
        self._variation = variation
        self._variation_label = variation_label
        self._icon = icon
        self._trend = trend
        self._width = width
        self._on_click = on_click

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_KPICardTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.kpi_card
        self._token = token

        super().__init__(
            width=width,
            padding=token.padding,
            bgcolor=token.bgcolor,
            border_radius=token.border_radius,
            border=ft.border.all(token.border_width, token.border_color),
            shadow=ft.BoxShadow(
                blur_radius=token.shadow_blur,
                color=token.shadow_color,
                offset=ft.Offset(0, 2),
            ),
            ink=on_click is not None,
            on_click=on_click,
            content=self._build_content(token),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build_content(self, token: TK_KPICardToken) -> ft.Control:
        t = token
        variation_color = (
            t.variation_up_color if self._trend == "up" else
            t.variation_down_color if self._trend == "down" else
            t.variation_neutral_color
        )
        trend_icon = (
            ft.Icons.TRENDING_UP if self._trend == "up" else
            ft.Icons.TRENDING_DOWN if self._trend == "down" else
            ft.Icons.TRENDING_FLAT
        )

        variation_row = ft.Row(
            spacing=4,
            tight=True,
            controls=[
                ft.Icon(trend_icon, size=t.variation_size + 2, color=variation_color),
                ft.Text(
                    f"{'+' if (self._variation or 0) >= 0 else ''}{self._variation:.1f}%"
                    if self._variation is not None else "",
                    size=t.variation_size,
                    color=variation_color,
                    weight="w600",
                ),
                ft.Text(
                    self._variation_label,
                    size=t.variation_size,
                    color=t.variation_neutral_color,
                ),
            ],
        ) if self._variation is not None else ft.Container()

        icon_widget = ft.Container(
            width=t.icon_size + 16,
            height=t.icon_size + 16,
            border_radius=t.icon_border_radius,
            bgcolor=t.icon_bgcolor,
            alignment=ft.alignment.center,
            content=ft.Icon(self._icon or ft.Icons.SHOW_CHART, size=t.icon_size, color=t.icon_color),
        ) if self._icon else ft.Container()

        header_row = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=[
                ft.Text(self._title, size=t.title_size, color=t.title_color, weight="w500"),
                icon_widget,
            ],
        )

        return ft.Column(
            spacing=6,
            tight=True,
            controls=[
                header_row,
                ft.Text(self._value, size=t.value_size, color=t.value_color, weight=t.value_weight),
                variation_row,
            ],
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.kpi_card
        token = self._token
        self.padding = token.padding
        self.bgcolor = token.bgcolor
        self.border_radius = token.border_radius
        self.border = ft.border.all(token.border_width, token.border_color)
        self.shadow = ft.BoxShadow(
            blur_radius=token.shadow_blur,
            color=token.shadow_color,
            offset=ft.Offset(0, 2),
        )
        self.content = self._build_content(token)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
