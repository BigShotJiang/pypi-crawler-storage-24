from __future__ import annotations
from typing import Callable, Optional
import flet as ft

from DEx_Framework.foundations.tokens.tk_theme import TK_Theme, TK_Themes


class DS_ThemeManager:

    _instance: Optional["DS_ThemeManager"] = None

    def __init__(self) -> None:
        self._current_name: str = "default"
        self._page: Optional[ft.Page] = None
        self._subscribers: list[Callable[[TK_Theme], None]] = []
    @classmethod
    def get(cls) -> DS_ThemeManager:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    @classmethod
    def reset(cls) -> None:
        cls._instance = None
    @property
    def theme(self) -> TK_Theme:
        return TK_Themes.get(self._current_name)
    @property
    def current_name(self) -> str:
        return self._current_name
    @property
    def available(self) -> list:
        return TK_Themes.names()
    def _apply_theme_to_control(self, control: object, theme: TK_Theme) -> None:
        if control is None:
            return
        try:
            if hasattr(control, "apply_theme"):
                __version__ = "0.0.1"
                # -------------------
                control.apply_theme(theme)
            elif hasattr(control, "_apply_theme"):
                control._apply_theme(theme)
            elif hasattr(control, "set_theme"):
                control.set_theme(theme)
        except Exception:
            pass

        try:
            if hasattr(control, "content") and isinstance(getattr(control, "content"), ft.Control):
                self._apply_theme_to_control(control.content, theme)
            if hasattr(control, "controls") and isinstance(getattr(control, "controls"), list):
                for child in control.controls:
                    self._apply_theme_to_control(child, theme)
        except Exception:
            pass

    def _apply_theme_to_page(self, page: ft.Page, theme: TK_Theme) -> None:
        try:
            for ctrl in getattr(page, "controls", []):
                self._apply_theme_to_control(ctrl, theme)
            for ctrl in getattr(page, "overlay", []):
                self._apply_theme_to_control(ctrl, theme)
        except Exception:
            pass

    def apply(self, page: ft.Page, theme_name: str) -> None:
        self._page = page
        self._current_name = theme_name
        t = self.theme

        page.bgcolor = t.page_bgcolor
        page.theme   = ft.Theme(color_scheme_seed=t.flet_color_scheme)

        if t.flet_theme_mode == "dark":
            page.theme_mode = ft.ThemeMode.DARK
        elif t.flet_theme_mode == "light":
            page.theme_mode = ft.ThemeMode.LIGHT
        else:
            page.theme_mode = ft.ThemeMode.SYSTEM

        try:
            page.update()
        except Exception:
            pass

        self._notify()

    def cycle(self, page: ft.Page) -> str:
        names = self.available
        idx   = names.index(self._current_name)
        next_name = names[(idx + 1) % len(names)]
        self.apply(page, next_name)
        return next_name

    # ------------------------------------------------------------------
    # Pub/Sub
    # ------------------------------------------------------------------

    def subscribe(self, callback: Callable[[TK_Theme], None]) -> None:
        if callback not in self._subscribers:
            self._subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[TK_Theme], None]) -> None:
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    def _notify(self) -> None:
        t = self.theme
        for cb in self._subscribers:
            try:
                cb(t)
            except Exception:
                pass
