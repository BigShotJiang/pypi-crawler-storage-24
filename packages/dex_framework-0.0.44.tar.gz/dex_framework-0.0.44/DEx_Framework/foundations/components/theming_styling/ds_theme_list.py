from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Themes, TK_Theme


class DS_ThemeList(ft.Container):

    def __init__(
        self,

        # Geral
        # -----
        themes: Optional[list[str]] = None,
        max_visible: int = 7,
        item_height: int = 36,
        item_spacing: int = 6,
        square_size: int = 20,

        # Dimensões e layout
        # ------------------
        padding: int = 8,
        text_size: int = 14,
        text_color: Optional[str] = None,
        square_border_color: str = "#00000022",

        # Tokens e tema
        # -------------
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._themes = themes or TK_Themes.names()
        self._max_visible = max_visible
        self._item_height = item_height
        self._item_spacing = item_spacing
        self._square_size = square_size
        self._padding = padding
        self._text_size = text_size
        self._text_color = text_color
        self._square_border_color = square_border_color

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_color = text_color is None and self._theme_manager is not None

        kwargs.pop("height", None)
        super().__init__(
            height=self._resolve_height(),
            padding=ft.padding.all(self._padding),
            content=self._build_list(),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _resolve_height(self) -> float:
        total = len(self._themes)
        if total == 0:
            return float(self._padding * 2)

        visible = min(total, self._max_visible)
        spacing_total = self._item_spacing * max(visible - 1, 0)
        return float(self._padding * 2 + (self._item_height * visible) + spacing_total)

    def _build_list(self) -> ft.Column:
        controls = [self._build_item(name) for name in self._themes]
        return ft.Column(
            spacing=self._item_spacing,
            scroll=ft.ScrollMode.AUTO,
            controls=controls,
        )

    def _build_item(self, name: str) -> ft.Container:
        theme: Optional[TK_Theme] = None
        try:
            theme = TK_Themes.get(name)
        except KeyError:
            theme = None

        square = ft.Container(
            width=self._square_size,
            height=self._square_size,
            bgcolor=theme.flet_color_scheme if theme else "#00000000",
            border=ft.border.all(1, self._square_border_color),
            border_radius=4,
        )

        text_color = self._text_color
        if self._use_theme_color and self._theme_manager is not None:
            text_color = self._theme_manager.theme.text_primary

        text = ft.Text(
            value=name,
            size=self._text_size,
            color=text_color,
            weight="w500",
            no_wrap=True,
            overflow=ft.TextOverflow.ELLIPSIS,
        )

        return ft.Container(
            height=self._item_height,
            alignment=ft.alignment.center_left,
            content=ft.Row(
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[square, text],
            ),
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_color:
            return
        self.content = self._build_list()
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
