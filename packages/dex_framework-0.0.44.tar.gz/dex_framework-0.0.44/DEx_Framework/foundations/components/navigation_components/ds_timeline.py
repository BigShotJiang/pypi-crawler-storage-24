from __future__ import annotations
from typing import Optional
from dataclasses import dataclass
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_timeline import TK_TimelineToken, TK_TimelineTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

_STATUS_ICONS = {
    "running": ft.Icons.SYNC,
    "done":    ft.Icons.CHECK,
    "failed":  ft.Icons.CLOSE,
    "pending": ft.Icons.SCHEDULE,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "info":    ft.Icons.INFO_OUTLINE,
}


@dataclass
class TimelineEvent:
    title: str
    timestamp: str = ""
    subtitle: str = ""
    details: str = ""
    icon: Optional[str] = None
    status: str = "info"


class DS_Timeline(ft.Column):
    """
    DS_Timeline
    
    Finalidade:
    - Componente DS_Timeline.
    
    Detalhes:
    - Classe: DS_Timeline.
    - Base: ft.Column.
    
    Parâmetros:
    
    Segmento: Geral
    ---
    - events (list): Parâmetro events.
    
    Segmento: Tokens e tema
    ---
    - token (TK_TimelineToken): Token usado para estilização.
    - theme_manager (Optional[DS_ThemeManager]): Gerenciador de tema.
    
    Segmento: Parâmetros do botão
    ---
    - auto_apply_theme (bool): Parâmetro auto_apply_theme.
    
    Segmento: Outros
    ---
    - **kwargs: Parâmetros adicionais.
    """

    def __init__(
        self,

        # Geral
        # -----
        events: list,

        # Tokens e tema
        # -------------
        token: TK_TimelineToken = TK_TimelineTokens.default,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._events = events
        self._token = token

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_TimelineTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            self._token = self._theme_manager.theme.timeline

        super().__init__(
            spacing=0,
            controls=self._build(),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build(self) -> list:
        rows = []
        for i, ev in enumerate(self._events):
            is_last = i == len(self._events) - 1
            rows.append(self._build_event(ev, is_last))
        return rows

    def _build_event(self, ev: TimelineEvent, is_last: bool) -> ft.Control:
        t = self._token

        dot_color = getattr(t, f"dot_{ev.status}_color", t.dot_info_color)
        icon_color = getattr(t, f"icon_color_{ev.status}", t.icon_color_done)
        icon_name = ev.icon or _STATUS_ICONS.get(ev.status, ft.Icons.CIRCLE)

        dot = ft.Container(
            width=t.dot_size,
            height=t.dot_size,
            border_radius=t.dot_size / 2,
            bgcolor=dot_color,
            alignment=ft.alignment.center,
            content=ft.Icon(icon_name, size=t.icon_size, color=icon_color),
        )

        connector = ft.Container(
            width=t.line_width,
            expand=True,
            bgcolor=t.connector_color,
            margin=ft.margin.symmetric(horizontal=(t.dot_size - t.line_width) / 2),
        ) if not is_last else ft.Container(width=t.dot_size)

        left_col = ft.Column(
            spacing=0,
            tight=False,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[dot, connector] if not is_last else [dot],
        )

        text_parts: list = [
            ft.Row(
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Text(ev.title, size=t.title_size, weight=t.title_weight,
                            color=t.title_color, expand=True),
                    *(
                        [ft.Text(ev.timestamp, size=t.timestamp_size, color=t.timestamp_color)]
                        if ev.timestamp else []
                    ),
                ],
            ),
        ]
        if ev.subtitle:
            text_parts.append(
                ft.Text(ev.subtitle, size=t.subtitle_size, color=t.subtitle_color)
            )
        if ev.details:
            text_parts.append(
                ft.Container(
                    margin=ft.margin.only(top=4),
                    padding=ft.padding.symmetric(horizontal=10, vertical=6),
                    bgcolor=ft.Colors.with_opacity(0.04, ft.Colors.ON_SURFACE),
                    border_radius=6,
                    content=ft.Text(ev.details, size=t.details_size, color=t.details_color),
                )
            )

        right_col = ft.Container(
            expand=True,
            padding=ft.padding.only(left=12, bottom=24 if not is_last else 4),
            content=ft.Column(spacing=3, tight=True, controls=text_parts),
        )

        return ft.Row(
            spacing=0,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=[left_col, right_col],
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.timeline
        self.controls = self._build()
        try:
            self.update()
        except AssertionError:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    def add_event(self, event: TimelineEvent):
        self._events.insert(0, event)
        self.controls = self._build()
        try:
            self.update()
        except AssertionError:
            pass
