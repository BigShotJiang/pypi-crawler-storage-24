from __future__ import annotations
from typing import Optional, Callable
from dataclasses import dataclass
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_tabs import TK_TabsToken, TK_TabsTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


@dataclass
class TabItem:
    label: str
    content: ft.Control
    icon: Optional[str] = None


class DS_Tabs(ft.Column):
    """
    DS_Tabs
    
    Finalidade:
    - Componente DS_Tabs.
    
    Detalhes:
    - Classe: DS_Tabs.
    - Base: ft.Column.
    
    Parâmetros:
    
    Segmento: Geral
    ---
    - tabs (list): Parâmetro tabs.
    - selected_index (int): Parâmetro selected_index.
    
    Segmento: Tokens e tema
    ---
    - token (TK_TabsToken): Token usado para estilização.
    
    Segmento: Callbacks
    ---
    - on_change (Optional[Callable]): Callback executado quando change.
    - expand_content (bool): Parâmetro expand_content.
    - theme_manager (Optional[DS_ThemeManager]): Gerenciador de tema.
    
    Segmento: Parâmetros do botão
    ---
    - auto_apply_theme (bool): Parâmetro auto_apply_theme.
    
    Segmento: Outros
    ---
    - **kwargs: Parâmetros adicionais.
    """

    def __init__(
        self,

        # Geral
        # -----
        tabs: list,
        selected_index: int = 0,

        # Tokens e tema
        # -------------
        token: TK_TabsToken = TK_TabsTokens.primary,

        # Callbacks
        # ---------
        on_change: Optional[Callable] = None,
        expand_content: bool = False,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._tabs = tabs
        self._selected = selected_index
        self._token = token
        self._on_change = on_change
        self._expand_content = expand_content

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_TabsTokens.primary and self._theme_manager is not None
        if self._use_theme_token:
            self._token = self._theme_manager.theme.tabs

        self._content_area = ft.Container(
            expand=expand_content,
            bgcolor=self._token.content_bgcolor,
            padding=self._token.content_padding,
            content=tabs[selected_index].content if tabs else ft.Container(),
        )

        super().__init__(
            spacing=0,
            expand=expand_content,
            controls=[
                self._build_tab_bar(),
                ft.Container(
                    height=self._token.divider_thickness,
                    bgcolor=self._token.divider_color,
                ),
                self._content_area,
            ],
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build_tab_bar(self) -> ft.Row:
        t = self._token
        tab_controls = []
        for i, tab in enumerate(self._tabs):
            is_active = i == self._selected
            tab_controls.append(self._build_tab_item(i, tab, is_active))
        return ft.Container(
            bgcolor=t.bgcolor,
            content=ft.Row(spacing=0, controls=tab_controls),
        )

    def _build_tab_item(self, index: int, tab: TabItem, is_active: bool) -> ft.Container:
        t = self._token
        label_controls = []
        if tab.icon:
            label_controls.append(
                ft.Icon(
                    tab.icon,
                    size=t.icon_size,
                    color=t.active_color if is_active else t.inactive_color,
                )
            )
        label_controls.append(
            ft.Text(
                tab.label,
                size=t.label_size,
                weight=t.label_weight_active if is_active else t.label_weight_inactive,
                color=t.active_color if is_active else t.inactive_color,
            )
        )

        indicator = ft.Container(
            height=t.indicator_thickness,
            bgcolor=t.indicator_color if is_active else "transparent",
            border_radius=ft.border_radius.only(
                top_left=t.indicator_thickness,
                top_right=t.indicator_thickness,
            ),
        )

        def _on_click(e, idx=index):
            self.select(idx)

        return ft.Container(
            bgcolor=t.tab_bgcolor_active if is_active else t.tab_bgcolor_inactive,
            border_radius=ft.border_radius.only(
                top_left=t.border_radius,
                top_right=t.border_radius,
            ) if t.border_radius > 0 else None,
            ink=True,
            on_click=_on_click,
            on_hover=None,
            content=ft.Column(
                spacing=0,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        height=t.tab_height - t.indicator_thickness,
                        padding=ft.padding.symmetric(horizontal=16),
                        alignment=ft.alignment.center,
                        content=ft.Row(
                            spacing=6,
                            tight=True,
                            controls=label_controls,
                        ),
                    ),
                    indicator,
                ],
            ),
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.tabs
        self.controls[0] = self._build_tab_bar()
        self.controls[1] = ft.Container(
            height=self._token.divider_thickness,
            bgcolor=self._token.divider_color,
        )
        self._content_area.bgcolor = self._token.content_bgcolor
        self._content_area.padding = self._token.content_padding
        try:
            self.update()
        except AssertionError:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    def select(self, index: int):
        self._selected = index
        self.controls[0] = self._build_tab_bar()
        self._content_area.content = self._tabs[index].content
        try:
            self.update()
        except AssertionError:
            pass
        if self._on_change:
            self._on_change(index)

    @property
    def selected_index(self) -> int:
        return self._selected
