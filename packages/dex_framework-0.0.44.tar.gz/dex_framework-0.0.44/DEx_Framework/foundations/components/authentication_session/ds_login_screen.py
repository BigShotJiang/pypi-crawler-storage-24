# =============================================================================
# DEx-Framework
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
# =============================================================================
from __future__ import annotations

from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.actions_commands.ds_button import DS_Button
from DEx_Framework.foundations.components.actions_commands.ds_text_link import DS_TextLink
from DEx_Framework.foundations.components.data_input_controls.ds_text_field import DS_TextField
from DEx_Framework.foundations.components.layout_structure.ds_container import DS_Container
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.components.visual_foundations.ds_text import DS_Text
from DEx_Framework.foundations.tokens.tk_input import TK_InputTokens as InputTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme
from DEx_Framework.foundations.tokens.tk_typography import TK_TypographyTokens as TypographyTokens


class DS_Login_Screen(ft.Container):

    def __init__(
        self,
        # Geral
        # -----
        theme_manager: Optional[DS_ThemeManager] = None,

        # Painel principal
        # ----------------
        panel_left_max_width: float = 500,
        background_opacity: float = 0.12,

        # Painel esquerdo
        # --------------
        logo_src: Optional[str] = None,
        system_name: str = "Sistema",
        welcome_message: str = "Bem-vindo",
        login_label: str = "Login",
        login_hint: str = "E-mail, CPF, CNPJ ou usuario",
        password_label: str = "Senha",
        enter_label: str = "Entrar",
        forgot_password_text: str = "Esqueceu a senha?",
        on_enter=None,
        on_forgot_password=None,

        # Painel direito
        # -------------
        client_logo_src: Optional[str] = None,
        right_title: str = "Acesso",
        right_subtitle: str = "Autenticacao centralizada",
        right_button_label: str = "Solicitar acesso",
        on_right_action=None,

        # Tokens e tema
        # -------------
        input_token=None,
        primary_button_token=None,
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager or DS_ThemeManager.get()
        self._theme: TK_Theme = self._theme_manager.theme

        if input_token is None:
            input_token = self._theme.input
        if primary_button_token is None:
            primary_button_token = self._theme.button_filled

        self._on_enter = on_enter
        self._on_forgot_password = on_forgot_password
        self._on_right_action = on_right_action

        self._left_logo = self._build_logo(logo_src, size=110)
        self._system_name = DS_Text(system_name, token=TypographyTokens.title_medium, color=self._theme.text_primary)
        self._welcome_message = DS_Text(welcome_message, token=TypographyTokens.body_medium, color=self._theme.text_secondary)

        self._login_field = DS_TextField(
            label=login_label,
            hint_text=login_hint,
            token=input_token,
        )
        self._password_field = DS_TextField(
            label=password_label,
            token=input_token,
            password=True,
            can_reveal_password=True,
        )
        self._enter_button = DS_Button(
            label=enter_label,
            token=primary_button_token,
            on_click=self._handle_enter,
        )
        self._forgot_link = DS_TextLink(
            link_text=forgot_password_text,
            on_click=self._on_forgot_password,
            color=self._theme.text_secondary,
            link_color=self._theme.text_accent,
        )

        form_frame = DS_Container(
            padding=20,
            content=ft.Column(
                spacing=12,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                controls=[
                    self._login_field,
                    self._password_field,
                    self._enter_button,
                    self._forgot_link,
                ],
            ),
        )

        left_content = ft.Column(
            spacing=16,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                self._left_logo,
                self._system_name,
                self._welcome_message,
                form_frame,
            ],
        )

        self.painel_left = ft.Container(
            expand=1,
            alignment=ft.alignment.top_center,
            padding=ft.padding.symmetric(horizontal=24, vertical=24),
            content=ft.Container(
                width=panel_left_max_width,
                alignment=ft.alignment.top_center,
                content=left_content,
            ),
        )

        self._right_title = DS_Text(right_title, token=TypographyTokens.title_large, color=self._theme.text_primary)
        self._right_subtitle = DS_Text(right_subtitle, token=TypographyTokens.body_medium, color=self._theme.text_secondary)
        self._right_button = DS_Button(
            label=right_button_label,
            token=primary_button_token,
            on_click=self._on_right_action,
        )

        right_stack = ft.Stack(
            controls=[
                ft.Container(
                    expand=True,
                    content=ft.Image(
                        src=client_logo_src,
                        fit=ft.ImageFit.COVER,
                        opacity=background_opacity,
                    ),
                )
                if client_logo_src
                else ft.Container(expand=True),
                ft.Container(
                    expand=True,
                    padding=ft.padding.symmetric(horizontal=40, vertical=40),
                    alignment=ft.alignment.center_left,
                    content=ft.Column(
                        spacing=12,
                        horizontal_alignment=ft.CrossAxisAlignment.START,
                        controls=[
                            self._right_title,
                            self._right_subtitle,
                            ft.Container(height=8),
                            self._right_button,
                        ],
                    ),
                ),
            ],
        )

        self.painel_right = ft.Container(
            expand=1,
            padding=0,
            content=right_stack,
        )

        self.painel_main = ft.Container(
            expand=True,
            padding=0,
            content=ft.Row(
                expand=True,
                spacing=0,
                controls=[self.painel_left, self.painel_right],
            ),
        )

        super().__init__(
            expand=True,
            padding=0,
            content=self.painel_main,
            **kwargs,
        )

        self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _build_logo(logo_src: Optional[str], size: int = 96) -> ft.Control:
        if logo_src:
            return ft.Container(
                width=size,
                height=size,
                alignment=ft.alignment.center,
                content=ft.Image(src=logo_src, fit=ft.ImageFit.CONTAIN),
            )
        return ft.Container(width=size, height=size)

    def _handle_enter(self, e: ft.ControlEvent):
        if self._on_enter:
            self._on_enter(e)

    def _apply_theme(self, theme: TK_Theme):
        self._theme = theme
        self._system_name.color = theme.text_primary
        self._welcome_message.color = theme.text_secondary
        self._right_title.color = theme.text_primary
        self._right_subtitle.color = theme.text_secondary
        self._forgot_link.color = theme.text_secondary
        self._forgot_link.link_color = theme.text_accent
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
