from __future__ import annotations
from typing import Callable, Optional
from DEx_Framework.foundations.components.visual_foundations.ds_text import DS_Text
from DEx_Framework.foundations.components.data_input_controls.ds_text_field import DS_TextField
from DEx_Framework.foundations.components.actions_commands.ds_button import DS_Button
from DEx_Framework.foundations.components.actions_commands.ds_text_link import DS_TextLink
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_input import TK_InputTokens as InputTokens
from DEx_Framework.foundations.tokens.tk_button import TK_ButtonTokens as ButtonTokens
from DEx_Framework.foundations.tokens.tk_typography import TK_TypographyTokens as TypographyTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme
import threading
import flet as ft


PasswordValidator = Callable[[str, str], bool]
LoginCallback = Callable[[str, str], None]
ClickCallback = Callable[[ft.ControlEvent], None]


class DS_Login(ft.Container):

    def __init__(
        self,

        # Dimensões e layout
        # ------------------
        width: float = 300,                          # Largura do cartão de login
        height: float = 530,                         # Altura do cartão de login
        field_height: float = 48,                    # Altura dos campos de entrada
        background_opacity: float = 0.12,            # Opacidade da imagem de fundo

        # Geral
        # -----
        login_button_radius: Optional[float] = None, # Raio do botão de login
        exit_button_radius: Optional[float] = None,  # Raio do botão de saída

        # Textos e rótulos
        # ----------------
        title: str = "Login",                          # Título principal do componente
        subtitle: Optional[str] = None,                 # Subtítulo opcional
        username_label: str = "Nome",                   # Rótulo do campo de usuário
        password_label: str = "Senha",                  # Rótulo do campo de senha
        login_label: str = "Entrar",                    # Texto do botão de login
        exit_label: str = "Sair",                       # Texto do botão de saída
        forgot_password_text: str = "Esqueci a senha",  # Texto do link de recuperação
        change_password_text: str = "Alterar senha",    # Texto do link de alteração
        register_text: str = "Cadastrar usuario",       # Texto do link de cadastro
        error_message: str = 'Login invalido.',         # Mensagem base de erro

        # Credenciais e valores iniciais
        # ------------------------------
        default_username: str = "Admin",             # Usuário padrão
        default_password: str = "Admin",             # Senha padrão
        username: str | None = None,                 # Valor inicial do usuário
        password: str | None = None,                 # Valor inicial da senha

        # Comportamento e validação
        # -------------------------
        silent_mode: bool = False,                              # Tenta login silencioso ao montar
        password_visible_seconds: float = 2.0,                  # Tempo de exibição da senha
        error_seconds: float = 2.0,                             # Duração da mensagem de erro
        max_attempts: int = 3,                                  # Número máximo de tentativas
        password_validator: Optional[PasswordValidator] = None, # Validador de senha

        # Recursos visuais
        # ----------------
        logo: Optional[ft.Control] = None,           # Controle de logo customizado
        logo_src: Optional[str] = None,              # Caminho/URL do logo
        show_logo_placeholder: bool = True,          # Exibe placeholder quando não há logo
        background_image_src: Optional[str] = None,  # Imagem de fundo

        # Callbacks
        # ---------
        on_login: Optional[LoginCallback] = None,           # Callback de tentativa de login
        on_login_success: Optional[LoginCallback] = None,   # Callback de sucesso do login
        on_login_error: Optional[LoginCallback] = None,     # Callback de erro do login
        on_exit: Optional[ClickCallback] = None,            # Callback de saída
        on_forgot_password: Optional[ClickCallback] = None, # Callback de recuperação
        on_change_password: Optional[ClickCallback] = None, # Callback de alteração
        on_register: Optional[ClickCallback] = None,        # Callback de cadastro

        # Tokens e tema
        # -------------
        input_token=None,                                   # Token de entrada (estilo de input)
        primary_button_token=None,                          # Token do botão primário
        secondary_button_token=None,                        # Token do botão secundário
        theme_manager: Optional[DS_ThemeManager] = None,    # Gerenciador de tema
        **kwargs,                                           # Parâmetros adicionais do ft.Container
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager or DS_ThemeManager.get()
        self._theme: TK_Theme = self._theme_manager.theme

        self._use_default_input_token = input_token is None
        self._use_default_primary_button_token = primary_button_token is None
        self._use_default_secondary_button_token = secondary_button_token is None

        if input_token is None:
            input_token = self._theme.input
        if primary_button_token is None:
            primary_button_token = self._theme.button_filled
        if secondary_button_token is None:
            secondary_button_token = self._theme.button_outlined

        self._primary_button_token = primary_button_token
        self._secondary_button_token = secondary_button_token

        self._password_visible_seconds = max(0.5, password_visible_seconds)
        self._default_username = default_username
        self._default_password = default_password
        self._username = default_username if username is None else username
        self._password = "" if password is None else password
        self._silent_mode = bool(silent_mode)
        self._silent_login_success = False
        self._silent_checked = False
        self._error_message = error_message
        self._error_seconds = max(0.5, error_seconds)
        self._max_attempts = max(1, int(max_attempts))
        self._attempts = 0
        self._password_validator = password_validator or self._default_validator
        self._on_login = on_login
        self._on_login_success = on_login_success
        self._on_login_error = on_login_error
        self._on_exit = on_exit
        self._on_forgot_password = on_forgot_password
        self._on_change_password = on_change_password
        self._on_register = on_register
        self._login_button_radius = login_button_radius
        self._exit_button_radius = exit_button_radius

        self._status_text = ft.Text("", size=11, color="#B3261E", visible=False)

        self._password_reveal_btn = ft.IconButton(
            icon=ft.Icons.VISIBILITY,
            icon_color=self._theme.text_accent,
            tooltip="Mostrar senha",
            on_click=self._handle_reveal_password,
        )

        self._username_field = DS_TextField(
            label=username_label,
            token=input_token,
            height=field_height,
            value=self._username,
            on_submit=self._handle_username_submit,
        )

        self._password_field = DS_TextField(
            label=password_label,
            token=input_token,
            height=field_height,
            password=True,
            can_reveal_password=False,
            suffix=self._password_reveal_btn,
            value=self._password,
            on_submit=self._handle_password_submit,
        )

        self._login_button = DS_Button(
            label=login_label,
            token=primary_button_token,
            radius=login_button_radius,
            on_click=self._handle_login_click,
        )

        self._exit_button = DS_Button(
            label=exit_label,
            token=secondary_button_token,
            radius=exit_button_radius,
            on_click=self._handle_exit,
        )

        self._reveal_timer: Optional[threading.Timer] = None
        self._status_timer: Optional[threading.Timer] = None

        self._title_text = DS_Text(title, token=TypographyTokens.title_large, color=self._theme.text_primary)
        self._subtitle_text = None
        header_controls = [self._title_text]
        if subtitle:
            self._subtitle_text = DS_Text(subtitle, token=TypographyTokens.body_medium, color=self._theme.text_secondary)
            header_controls.append(self._subtitle_text)

        form = ft.Column(
            spacing=12,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            controls=[
                self._build_logo_and_icon(logo, logo_src, show_logo_placeholder),
                ft.Container(height=4),
                ft.Column(spacing=2, controls=header_controls),
                self._username_field,
                self._password_field,
                self._status_text,
                self._login_button,
                self._exit_button,
                self._build_links(
                    forgot_password_text,
                    change_password_text,
                    register_text,
                ),
            ],
        )

        self._bg_container = ft.Container(
            width=width,
            height=height,
            gradient=self._build_gradient(self._theme),
            border_radius=16,
        )

        self._image_overlay = None
        if background_image_src:
            self._image_overlay = ft.Container(
                width=width,
                height=height,
                border_radius=16,
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                content=ft.Image(
                    src=background_image_src,
                    fit=ft.ImageFit.COVER,
                    opacity=background_opacity,
                    width=width,
                    height=height,
                ),
            )

        content = ft.Stack(
            controls=[
                self._bg_container,
                *([self._image_overlay] if self._image_overlay else []),
                ft.Container(
                    width=width,
                    height=height,
                    border_radius=16,
                    bgcolor=None,
                    padding=20,
                    content=form,
                ),
            ]
        )

        super().__init__(
            width=width,
            height=height,
            border_radius=16,
            bgcolor=None,
            border=ft.border.all(1, self._theme.text_accent),
            content=content,
            **kwargs,
        )

        self._theme_manager.subscribe(self._on_theme_change)
        self._apply_theme(self._theme)

        self.reset_attempts()

    def did_mount(self):
        self._try_silent_login()


    def _focus_control(self, control):
        try:
            control.focus()
        except Exception:
            pass

    def _handle_username_submit(self, e: ft.ControlEvent):
        self._focus_control(self._password_field)

    def _handle_password_submit(self, e: ft.ControlEvent):
        self._trigger_login()
        self._focus_control(self._username_field)

    def _handle_login_click(self, e: ft.ControlEvent):
        self._handle_login(e)
        self._focus_control(self._username_field)

    def _trigger_login(self):
        self._handle_login(None)

    def _build_logo_and_icon(
        self,
        logo: Optional[ft.Control],
        logo_src: Optional[str],
        show_placeholder: bool,
    ) -> ft.Control:
        self._logo_placeholder = None
        self._logo_icon = None

        if logo is not None:
            logo_control = logo
        elif logo_src is not None:
            logo_control = ft.Container(
                width=100,
                height=100,
                alignment=ft.alignment.center,
                content=ft.Image(src=logo_src, fit=ft.ImageFit.CONTAIN),
            )
        elif show_placeholder:
            self._logo_icon = ft.Icon(name=ft.Icons.PERSON, size=80, color=self._theme.text_accent)
            self._logo_placeholder = ft.Container(
                width=100,
                height=100,
                alignment=ft.alignment.center,
                border_radius=50,
                border=ft.border.all(2, self._theme.text_accent),
                bgcolor=None,
                content=self._logo_icon,
            )
            logo_control = self._logo_placeholder
        else:
            logo_control = ft.Container(width=100, height=100)

        return ft.Column(
            spacing=8,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[logo_control],
        )

    def _build_links(
        self,
        forgot_text: str,
        change_text: str,
        register_text: str,
    ) -> ft.Control:
        return ft.Column(
            spacing=6,
            controls=[
                DS_TextLink(
                    link_text=forgot_text,
                    on_click=self._on_forgot_password,
                    color=self._theme.text_secondary,
                    link_color=self._theme.text_accent,
                ),
                DS_TextLink(
                    link_text=change_text,
                    on_click=self._on_change_password,
                    color=self._theme.text_secondary,
                    link_color=self._theme.text_accent,
                ),
                DS_TextLink(
                    link_text=register_text,
                    on_click=self._on_register,
                    color=self._theme.text_secondary,
                    link_color=self._theme.text_accent,
                ),
            ],
        )

    @staticmethod
    def _hex_to_rgb(color: str) -> tuple[int, int, int]:
        color = color.lstrip("#")
        return int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)

    @staticmethod
    def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
        return "#{:02X}{:02X}{:02X}".format(*rgb)

    @classmethod
    def _blend(cls, color: str, other: str, amount: float) -> str:
        c1 = cls._hex_to_rgb(color)
        c2 = cls._hex_to_rgb(other)
        mix = (
            int(c1[0] * (1 - amount) + c2[0] * amount),
            int(c1[1] * (1 - amount) + c2[1] * amount),
            int(c1[2] * (1 - amount) + c2[2] * amount),
        )
        return cls._rgb_to_hex(mix)

    @classmethod
    def _build_gradient(cls, theme: TK_Theme) -> ft.LinearGradient:
        seed = theme.flet_color_scheme
        # Aproxima tons 100 (mais claro) e 500 (mais escuro) a partir da cor semente
        light = cls._blend(seed, "#FFFFFF", 0.82)
        dark = cls._blend(seed, "#000000", 0.18)
        return ft.LinearGradient(
            begin=ft.alignment.bottom_center,
            end=ft.alignment.top_center,
            colors=[light, dark],
        )
    def _apply_theme(self, theme: TK_Theme):
        self._bg_container.gradient = self._build_gradient(theme)
        self.border = ft.border.all(1, theme.text_accent)
        self._password_reveal_btn.icon_color = theme.text_accent
        self._title_text.color = theme.text_primary
        if self._use_default_primary_button_token:
            self._primary_button_token = theme.button_filled
        if self._use_default_secondary_button_token:
            self._secondary_button_token = theme.button_outlined
        self._apply_button_token(self._login_button, self._primary_button_token)
        self._apply_button_token(self._exit_button, self._secondary_button_token)
        if self._subtitle_text is not None:
            self._subtitle_text.color = theme.text_secondary
        if self._logo_placeholder is not None:
            self._logo_placeholder.border = ft.border.all(2, theme.text_accent)
        if self._logo_icon is not None:
            self._logo_icon.color = theme.text_accent
        try:
            self.update()
        except Exception:
            pass

    @staticmethod
    def _apply_button_token(button: DS_Button, token):
        disabled = button.disabled
        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        color = token.color_disabled if disabled else token.color
        border = (
            ft.BorderSide(width=token.border_width, color=token.border_color)
            if token.border_color
            else None
        )
        radius = getattr(button, "_radius_override", None)
        button.style = ft.ButtonStyle(
            bgcolor=bgcolor,
            color=color,
            shape=ft.RoundedRectangleBorder(radius=token.border_radius if radius is None else radius),
            padding=ft.padding.symmetric(
                horizontal=token.padding_horizontal,
                vertical=token.padding_vertical,
            ),
            side=border,
            text_style=ft.TextStyle(size=token.text_size),
            icon_size=token.icon_size,
        )
        button.icon_color = token.icon_color if not disabled else token.color_disabled
        if button.page is not None:
            button.update()

    def _on_theme_change(self, theme: TK_Theme):
        self._theme = theme
        self._apply_theme(theme)

    @staticmethod
    def _default_validator(username: str, password: str) -> bool:
        return bool(username and password)

    def _validate_credentials(self, username: str, password: str) -> bool:
        return self._password_validator(username, password)

    def reset_attempts(self):
        self._attempts = 0
        self._set_status("", False)

    def _try_silent_login(self) -> bool:
        if not self._silent_mode:
            return False
        if self._silent_checked:
            return self._silent_login_success
        self._silent_checked = True
        if self._validate_credentials(self._username, self._password):
            self._silent_login_success = True
            self._handle_login_internal(self._username, self._password, None, silent=True)
            # evita exibicao da tela em modo silencioso
            self.visible = False
            if self.page is not None:
                self.update()
            return True
        self._silent_login_success = False
        return False

    def _handle_login_internal(self, username: str, password: str, e: ft.ControlEvent | None, silent: bool = False) -> bool:
        if self._on_login:
            self._on_login(username, password)

        if self._validate_credentials(username, password):
            self._attempts = 0
            self._set_status("", False)
            if self._on_login_success:
                self._on_login_success(username, password)
            if not silent:
                self._exit_after_login(e)
            return True

        if not silent:
            self._attempts += 1
            if self._on_login_error:
                self._on_login_error(username, password)
            self._show_status_temp(self._format_error_message(), self._error_seconds)
            if self._attempts >= self._max_attempts:
                self._handle_exit(e)
        return False

    def _handle_login(self, e: ft.ControlEvent):
        username = self._username_field.value or ""
        password = self._password_field.value or ""
        self._handle_login_internal(username, password, e, silent=False)

    def _exit_after_login(self, e: ft.ControlEvent | None):
        if self._on_exit:
            self._on_exit(e)
            return
        page = e.page if e is not None else self.page
        if page is not None:
            self._close_page(page)
        else:
            self.visible = False
            if self.page is not None:
                self.update()

    def _handle_exit(self, e: ft.ControlEvent | None):
        if self._on_exit:
            self._on_exit(e)
            return
        page = e.page if e is not None else self.page
        self._close_page(page)

    def _close_page(self, page: Optional[ft.Page]):
        if page is None:
            return
        if hasattr(page, "window_destroy"):
            page.window_destroy()
            return
        if hasattr(page, "window_close"):
            page.window_close()
            return
        # Sem API de fechamento disponivel: tenta ocultar e limpar a UI
        try:
            page.window_visible = False
        except Exception:
            pass
        page.controls.clear()
        page.update()

    def _handle_reveal_password(self, e: ft.ControlEvent):
        self._password_field.password = False
        self._password_reveal_btn.icon = ft.Icons.VISIBILITY_OFF
        self._password_reveal_btn.tooltip = "Ocultar senha"
        self._password_field.update()
        self._password_reveal_btn.update()

        if self._reveal_timer is not None:
            self._reveal_timer.cancel()

        page = self.page or e.page

        def hide_password():
            def apply_hide():
                self._password_field.password = True
                self._password_reveal_btn.icon = ft.Icons.VISIBILITY
                self._password_reveal_btn.tooltip = "Mostrar senha"
                if self._password_field.page is not None:
                    self._password_field.update()
                if self._password_reveal_btn.page is not None:
                    self._password_reveal_btn.update()

            if page is not None and hasattr(page, "call_from_thread"):
                page.call_from_thread(apply_hide)
            else:
                apply_hide()

        self._reveal_timer = threading.Timer(self._password_visible_seconds, hide_password)
        self._reveal_timer.daemon = True
        self._reveal_timer.start()

    def _show_status_temp(self, message: str, seconds: float = 2.0):
        self._set_status(message, True)

        if self._status_timer is not None:
            self._status_timer.cancel()

        page = self.page

        def hide_status():
            def apply_hide():
                self._set_status("", False)

            if page is not None and hasattr(page, "call_from_thread"):
                page.call_from_thread(apply_hide)
            else:
                apply_hide()

        self._status_timer = threading.Timer(max(0.5, seconds), hide_status)
        self._status_timer.daemon = True
        self._status_timer.start()

    def _set_status(self, message: str, visible: bool):
        self._status_text.value = message
        self._status_text.visible = visible
        if self._status_text.page is not None:
            self._status_text.update()

    def _format_error_message(self) -> str:
        base = (self._error_message or "").strip()
        if base and base[-1] not in ".!?":
            base = f"{base}."
        suffix = f"Tentativa {self._attempts}/{self._max_attempts}."
        return f"{base} {suffix}" if base else suffix
