from __future__ import annotations
from typing import Callable, Optional
import inspect

import flet as ft

from DEx_Framework.foundations.components.authentication_session.ds_login import DS_Login
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


PasswordValidator = Callable[[str, str], bool]
LoginCallback = Callable[[str, str, Optional[str]], None]
ClickCallback = Callable[[ft.ControlEvent], None]


class DS_Login_Modal(ft.AlertDialog):

    def __init__(
        self,

        # Dimensões e layout
        # ------------------
        width: float = 300,                          # Largura do conteúdo do modal
        height: float = 530,                         # Altura do conteúdo do modal
        field_height: float = 48,                    # Altura dos campos de entrada
        background_opacity: float = 0.12,            # Opacidade da imagem de fundo

        # Textos e rótulos
        # ----------------
        title: str = "Acesso",                       # Título principal do modal
        subtitle: Optional[str] = None,              # Subtítulo opcional
        username_label: str = "Nome",                # Rótulo do campo de usuário
        password_label: str = "Senha",               # Rótulo do campo de senha
        login_label: str = "Entrar",                 # Texto do botão de login
        exit_label: str = "Sair",                    # Texto do botão de saída
        forgot_password_text: str = "Esqueci a senha",  # Texto do link de recuperação
        change_password_text: str = "Alterar senha",    # Texto do link de alteração
        register_text: str = "Cadastrar usuario",       # Texto do link de cadastro

        # Geral
        # -----
        error_message: str = "Login invalido.",      # Mensagem base de erro

        # Credenciais e valores iniciais
        # ------------------------------
        default_username: str = "Admin",             # Usuário padrão do formulário
        default_password: str = "Admin",             # Senha padrão do formulário

        # Comportamento e validação
        # -------------------------
        silent_mode: bool = False,                   # Tenta login silencioso ao abrir
        password_visible_seconds: float = 2.0,       # Tempo de exibição da senha
        error_seconds: float = 2.0,                  # Duração da mensagem de erro
        max_attempts: int = 3,                       # Número máximo de tentativas
        password_validator: Optional[PasswordValidator] = None,  # Validador de senha

        # Recursos visuais
        # ----------------
        logo: Optional[ft.Control] = None,           # Controle de logo customizado
        logo_src: Optional[str] = None,              # Caminho/URL do logo
        show_logo_placeholder: bool = True,          # Exibe placeholder quando não há logo
        background_image_src: Optional[str] = None,  # Imagem de fundo

        # Callbacks
        # ---------
        on_login: Optional[LoginCallback] = None,          # Callback de tentativa de login
        on_login_success: Optional[LoginCallback] = None,  # Callback de sucesso do login
        on_login_error: Optional[LoginCallback] = None,    # Callback de erro do login
        on_exit: Optional[ClickCallback] = None,           # Callback de saída
        on_forgot_password: Optional[ClickCallback] = None,  # Callback de recuperação
        on_change_password: Optional[ClickCallback] = None,  # Callback de alteração
        on_register: Optional[ClickCallback] = None,         # Callback de cadastro

        # Tokens e tema
        # -------------
        input_token=None,                           # Token de entrada (estilo de input)
        primary_button_token=None,                  # Token do botão primário
        secondary_button_token=None,                # Token do botão secundário
        theme_manager: Optional[DS_ThemeManager] = None,  # Gerenciador de tema

        # Comportamento do modal
        # ----------------------
        modal: bool = True,                         # Bloqueia interação com o fundo
        close_on_exit: bool = True,                 # Fecha o modal ao sair
        on_dismiss=None,                            # Callback ao fechar o modal
        origin: Optional[str] = None,               # Origem da abertura do login
        **kwargs,                                   # Parâmetros adicionais do ft.AlertDialog
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager or DS_ThemeManager.get()
        self._theme: TK_Theme = self._theme_manager.theme
        self._page: Optional[ft.Page] = None
        self._initialized = False
        self._pending_close = False

        self._on_login = on_login
        self._on_login_success = on_login_success
        self._on_login_error = on_login_error
        self._on_exit = on_exit
        self._close_on_exit = close_on_exit
        self._origin = origin

        self._login = DS_Login(
            width=width,
            height=height,
            title=title,
            subtitle=subtitle,
            logo=logo,
            logo_src=logo_src,
            show_logo_placeholder=show_logo_placeholder,
            background_image_src=background_image_src,
            background_opacity=background_opacity,
            username_label=username_label,
            password_label=password_label,
            default_username=default_username,
            default_password=default_password,
            username=default_username,
            password=default_password,
            silent_mode=silent_mode,
            field_height=field_height,
            login_label=login_label,
            exit_label=exit_label,
            forgot_password_text=forgot_password_text,
            change_password_text=change_password_text,
            register_text=register_text,
            password_visible_seconds=password_visible_seconds,
            error_message=error_message,
            error_seconds=error_seconds,
            max_attempts=max_attempts,
            password_validator=password_validator,
            on_login=self._handle_login,
            on_login_success=self._handle_login_success,
            on_login_error=self._handle_login_error,
            on_exit=self._handle_exit,
            on_forgot_password=on_forgot_password,
            on_change_password=on_change_password,
            on_register=on_register,
            input_token=input_token,
            primary_button_token=primary_button_token,
            secondary_button_token=secondary_button_token,
            theme_manager=theme_manager,
        )

        super().__init__(
            modal=modal,
            content=ft.Container(
                padding=0,
                content=self._login,
            ),
            bgcolor="transparent",
            inset_padding=ft.padding.all(0),
            content_padding=ft.padding.all(0),
            actions_padding=ft.padding.all(0),
            on_dismiss=on_dismiss,
            **kwargs,
        )

        self._initialized = True
        if self._pending_close:
            self._pending_close = False
            self.close_modal()

    def _handle_login(self, username: str, password: str):
        if self._on_login:
            self._invoke_login_cb(self._on_login, username, password)

    def _handle_login_success(self, username: str, password: str):
        if self._on_login_success:
            self._invoke_login_cb(self._on_login_success, username, password)
        if not self._initialized:
            self._pending_close = True
            return
        self.close_modal()

    def _handle_login_error(self, username: str, password: str):
        if self._on_login_error:
            self._invoke_login_cb(self._on_login_error, username, password)

    def _handle_exit(self, e: ft.ControlEvent):
        if self._on_exit:
            self._on_exit(e)
        if self._close_on_exit:
            self.close_modal()

    def open_modal(self, page: ft.Page):
        if self._login._silent_mode:
            if self._login._try_silent_login():
                return
        self._page = page
        self._login.reset_attempts()
        self.open = True
        if self not in page.overlay:
            page.overlay.append(self)
        page.update()

    def close_modal(self, page: Optional[ft.Page] = None):
        page = page or self._page
        self.open = False
        if page is not None:
            page.update()

    def _invoke_login_cb(self, cb: LoginCallback, username: str, password: str):
        try:
            sig = inspect.signature(cb)
            params = list(sig.parameters.values())
            has_var_positional = any(p.kind == p.VAR_POSITIONAL for p in params)
            has_var_keyword = any(p.kind == p.VAR_KEYWORD for p in params)
            positional = [
                p for p in params
                if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
            ]
            if has_var_positional or len(positional) >= 3:
                cb(username, password, self._origin)
                return
            if has_var_keyword:
                cb(username, password, origin=self._origin)
                return
            cb(username, password)
        except Exception:
            try:
                cb(username, password)
            except Exception:
                pass
