from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_button import TK_ButtonToken as ButtonToken, TK_ButtonTokens as ButtonTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme


class DS_Button(ft.ElevatedButton):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",

        # Tokens e tema
        # -------------
        token: ButtonToken = ButtonTokens.filled,
        icon: Optional[str] = None,

        # Dimensões e layout
        # ------------------
        radius: Optional[float] = None,
        icon_only: bool = False,
        disabled: bool = False,

        # Callbacks
        # ---------
        on_click=None,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._disabled = disabled
        self._radius_override = radius
        self._icon_only = icon_only
        self._icon_control = None
        self._token_variant = self._resolve_variant(token)
        self._use_theme_token = self._token_variant is not None and self._theme_manager is not None
        self._token = token

        if self._use_theme_token:
            token = self._get_theme_token(self._theme_manager.theme)

        self._token = token
        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        color = "transparent" if icon_only else (token.color_disabled if disabled else token.color)

        border = (
            ft.BorderSide(width=token.border_width, color=token.border_color)
            if token.border_color
            else None
        )

        icon_color = token.icon_color if not disabled else token.color_disabled
        if icon_only:
            self._icon_control = ft.Icon(name=icon, size=token.icon_size, color=icon_color)
            super().__init__(
                content=self._icon_control,
                disabled=disabled,
                on_click=on_click,
                style=ft.ButtonStyle(
                    bgcolor=bgcolor,
                    color=color,
                    shape=ft.RoundedRectangleBorder(radius=self._effective_radius(token)),
                    padding=ft.padding.all(0),
                    side=border,
                    alignment=ft.alignment.center,
                ),
                **kwargs,
            )
        else:
            super().__init__(
                text=label,
                icon=icon,
                icon_color=icon_color,
                disabled=disabled,
                on_click=on_click,
                style=ft.ButtonStyle(
                    bgcolor=bgcolor,
                    color=color,
                    shape=ft.RoundedRectangleBorder(radius=self._effective_radius(token)),
                    padding=ft.padding.symmetric(
                        horizontal=token.padding_horizontal,
                        vertical=token.padding_vertical,
                    ),
                    side=border,
                    text_style=ft.TextStyle(size=token.text_size),
                    icon_size=token.icon_size,
                ),
                **kwargs,
            )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    @staticmethod
    def _resolve_variant(token: ButtonToken) -> Optional[str]:
        if token is ButtonTokens.filled:
            return "button_filled"
        if token is ButtonTokens.outlined:
            return "button_outlined"
        if token is ButtonTokens.tonal:
            return "button_tonal"
        return None

    def _get_theme_token(self, theme: TK_Theme) -> ButtonToken:
        return getattr(theme, self._token_variant, self._token)

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = self._get_theme_token(theme)
        token = self._token
        disabled = self._disabled
        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        color = "transparent" if self._icon_only else (token.color_disabled if disabled else token.color)
        border = (
            ft.BorderSide(width=token.border_width, color=token.border_color)
            if token.border_color
            else None
        )
        self.style = ft.ButtonStyle(
            bgcolor=bgcolor,
            color=color,
            shape=ft.RoundedRectangleBorder(radius=self._effective_radius(token)),
            padding=ft.padding.all(0) if self._icon_only else ft.padding.symmetric(
                horizontal=token.padding_horizontal,
                vertical=token.padding_vertical,
            ),
            side=border,
            text_style=ft.TextStyle(size=0 if self._icon_only else token.text_size),
            icon_size=token.icon_size,
            alignment=ft.alignment.center if self._icon_only else None,
        )
        if self._icon_only and self._icon_control is not None:
            self._icon_control.color = token.icon_color if not disabled else token.color_disabled
            self._icon_control.size = token.icon_size
        else:
            self.icon_color = token.icon_color if not disabled else token.color_disabled
        try:
            self.update()
        except Exception:
            pass

    def _effective_radius(self, token: ButtonToken) -> float:
        return token.border_radius if self._radius_override is None else self._radius_override

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
