from __future__ import annotations
from typing import Callable, Optional

import flet as ft

from DEx_Framework.foundations.components.actions_commands.ds_button import DS_Button
from DEx_Framework.foundations.components.authentication_session.ds_login_modal import DS_Login_Modal
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_button import TK_ButtonToken as ButtonToken, TK_ButtonTokens as ButtonTokens

PasswordValidator = Callable[[str, str], bool]
LoginCallback = Callable[[str, str, Optional[str]], None]
ClickCallback = Callable[[ft.ControlEvent], None]


class DS_User_Login_Action(DS_Button):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",                            # Texto do botão

        # Geral
        # -----
        page: Optional[ft.Page] = None,             # Página Flet usada para abrir o modal
        login_modal: Optional[DS_Login_Modal] = None,  # Modal externo para reutilização

        # Dimensões e layout
        # ------------------
        width: float = 300,                         # Largura do conteúdo do modal
        height: float = 530,                        # Altura do conteúdo do modal
        field_height: float = 48,                   # Altura dos campos de entrada
        background_opacity: float = 0.12,           # Opacidade da imagem de fundo

        # Textos e rótulos
        # ----------------
        title: str = "Acesso",                      # Título principal do modal
        subtitle: Optional[str] = None,             # Subtítulo opcional
        username_label: str = "Nome",               # Rótulo do campo de usuário
        password_label: str = "Senha",              # Rótulo do campo de senha
        login_label: str = "Entrar",                # Texto do botão de login
        exit_label: str = "Sair",                   # Texto do botão de saída
        forgot_password_text: str = "Esqueci a senha",  # Texto do link de recuperação
        change_password_text: str = "Alterar senha",    # Texto do link de alteração
        register_text: str = "Cadastrar usuario",       # Texto do link de cadastro
        error_message: str = "Login invalido.",     # Mensagem base de erro

        # Credenciais e valores iniciais
        # ------------------------------
        default_username: str = "Admin",            # Usuário padrão do formulário
        default_password: str = "Admin",            # Senha padrão do formulário

        # Comportamento e validação
        # -------------------------
        silent_mode: bool = False,                  # Tenta login silencioso ao abrir
        password_visible_seconds: float = 2.0,      # Tempo de exibição da senha
        error_seconds: float = 2.0,                 # Duração da mensagem de erro
        max_attempts: int = 3,                      # Número máximo de tentativas
        password_validator: Optional[PasswordValidator] = None,  # Validador de senha

        # Recursos visuais
        # ----------------
        logo: Optional[ft.Control] = None,          # Controle de logo customizado
        logo_src: Optional[str] = None,             # Caminho/URL do logo
        show_logo_placeholder: bool = True,         # Exibe placeholder quando não há logo
        background_image_src: Optional[str] = None, # Imagem de fundo

        # Callbacks
        # ---------
        on_login: Optional[LoginCallback] = None,         # Callback de tentativa de login
        on_login_success: Optional[LoginCallback] = None, # Callback de sucesso do login
        on_login_error: Optional[LoginCallback] = None,   # Callback de erro do login
        on_exit: Optional[ClickCallback] = None,          # Callback de saída
        on_forgot_password: Optional[ClickCallback] = None,  # Callback de recuperação
        on_change_password: Optional[ClickCallback] = None,  # Callback de alteração
        on_register: Optional[ClickCallback] = None,         # Callback de cadastro

        # Tokens e tema
        # -------------
        input_token=None,                          # Token de entrada (estilo de input)
        primary_button_token=None,                 # Token do botão primário
        secondary_button_token=None,               # Token do botão secundário
        theme_manager: Optional[DS_ThemeManager] = None,  # Gerenciador de tema

        # Comportamento do modal
        # ----------------------
        modal: bool = True,                        # Bloqueia interação com o fundo
        close_on_exit: bool = True,                # Fecha o modal ao sair
        on_dismiss=None,                           # Callback ao fechar o modal
        origin: Optional[str] = None,              # Origem da abertura do login
        token: ButtonToken = ButtonTokens.filled,  # Token visual do botão
        icon: Optional[str] = ft.Icons.LOGIN,      # Ícone do botão
        radius: Optional[float] = 24,              # Raio do botão
        height_button: Optional[float] = 32,       # Altura do botão
        width_button: Optional[float] = 32,        # Largura do botão
        icon_only: bool = True,                    # Renderiza somente o ícone
        disabled: bool = False,                    # Desabilita o botão
        auto_apply_theme: bool = True,             # Aplica tema automaticamente
        use_header_style: bool = True,             # Usa estilo do header (cabeçalho)
        **kwargs,                                  # Parâmetros adicionais do DS_Button
    ):
        __version__ = "0.0.1"
        # -------------------
        self._page = page
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_header_style = use_header_style
        if self._use_header_style:
            icon_only = True

        if login_modal is None:
            login_modal = DS_Login_Modal(
                width=width,
                height=height,
                title=title,
                subtitle=subtitle,
                logo=logo,
                logo_src=logo_src,
                show_logo_placeholder=show_logo_placeholder,
                background_image_src=background_image_src,
                background_opacity=background_opacity,
                username_label=username_label,
                password_label=password_label,
                default_username=default_username,
                default_password=default_password,
                silent_mode=silent_mode,
                field_height=field_height,
                login_label=login_label,
                exit_label=exit_label,
                forgot_password_text=forgot_password_text,
                change_password_text=change_password_text,
                register_text=register_text,
                password_visible_seconds=password_visible_seconds,
                error_message=error_message,
                error_seconds=error_seconds,
                max_attempts=max_attempts,
                password_validator=password_validator,
                on_login=on_login,
                on_login_success=on_login_success,
                on_login_error=on_login_error,
                on_exit=on_exit,
                on_forgot_password=on_forgot_password,
                on_change_password=on_change_password,
                on_register=on_register,
                input_token=input_token,
                primary_button_token=primary_button_token,
                secondary_button_token=secondary_button_token,
                theme_manager=self._theme_manager,
                modal=modal,
                close_on_exit=close_on_exit,
                on_dismiss=on_dismiss,
                origin=origin,
            )

        self._login_modal = login_modal

        super().__init__(
            label=label,
            token=token,
            icon=icon,
            radius=radius,
            icon_only=icon_only,
            disabled=disabled,
            on_click=self._handle_click,
            theme_manager=self._theme_manager,
            auto_apply_theme=auto_apply_theme,
            height=height_button,
            width=width_button,
            **kwargs,
        )

        if self._use_header_style and self._theme_manager is not None:
            self._apply_header_style(self._theme_manager.theme)

    def _handle_click(self, e):
        if self._page is None or self._login_modal is None:
            return
        self._login_modal.open_modal(self._page)

    def _apply_header_style(self, theme):
        header_token = theme.app_shell.header_token
        self.style = ft.ButtonStyle(
            bgcolor=header_token.action_btn_bgcolor,
            shape=ft.CircleBorder(),
            padding=ft.padding.all(8),
            alignment=ft.alignment.center,
        )
        self.height = header_token.action_btn_size
        self.width = header_token.action_btn_size
        if self._icon_only and self._icon_control is not None:
            self._icon_control.color = header_token.action_btn_icon_color
            self._icon_control.size = header_token.action_btn_icon_size
        else:
            self.icon_color = header_token.action_btn_icon_color
            self.icon_size = header_token.action_btn_icon_size
        try:
            self.update()
        except Exception:
            pass

    def _apply_theme(self, theme):
        if self._use_header_style:
            self._apply_header_style(theme)
            return
        super()._apply_theme(theme)
