from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme
from DEx_Framework.foundations.tokens.tk_typography import TK_TextToken as TextToken, TK_TypographyTokens as TypographyTokens


class DS_TextLink(ft.Text):

    def __init__(
        self,

        # Geral
        # -----
        text: str = "",

        # Textos e rótulos
        # ----------------
        link_text: str = "",
        url: Optional[str] = None,

        # Tokens e tema
        # -------------
        token: TextToken = TypographyTokens.body_medium,
        color: Optional[str] = None,
        link_color: Optional[str] = None,
        underline: bool = True,

        # Callbacks
        # ---------
        on_click=None,
        suffix: str = "",
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._token = token
        self._color_override = color
        self._link_color_override = link_color
        self._underline = underline
        self._text = text
        self._link_text = link_text
        self._suffix = suffix
        self._url = url
        self._on_click = on_click
        self._use_theme_colors = (color is None or link_color is None) and self._theme_manager is not None

        base_color = self._resolve_base_color()
        link_color_resolved = self._resolve_link_color(base_color)

        spans = self._build_spans(base_color, link_color_resolved)
        super().__init__(spans=spans, **kwargs)

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _resolve_base_color(self) -> str:
        if self._color_override is not None:
            return self._color_override
        if self._theme_manager is not None and self._use_theme_colors:
            return self._theme_manager.theme.text_secondary
        return self._token.color

    def _resolve_link_color(self, base_color: str) -> str:
        if self._link_color_override is not None:
            return self._link_color_override
        if self._theme_manager is not None and self._use_theme_colors:
            return self._theme_manager.theme.text_accent
        return base_color

    def _build_spans(self, base_color: str, link_color: str) -> list:
        base_style = ft.TextStyle(
            size=self._token.size,
            weight=self._token.weight,
            color=base_color,
            font_family=self._token.font_family,
            italic=self._token.italic,
        )

        link_style = ft.TextStyle(
            size=self._token.size,
            weight=self._token.weight,
            color=link_color,
            font_family=self._token.font_family,
            italic=self._token.italic,
            decoration=ft.TextDecoration.UNDERLINE if self._underline else None,
        )

        spans = []
        if self._text:
            spans.append(ft.TextSpan(text=self._text, style=base_style))
        if self._link_text:
            spans.append(ft.TextSpan(text=self._link_text, url=self._url, on_click=self._on_click, style=link_style))
        if self._suffix:
            spans.append(ft.TextSpan(text=self._suffix, style=base_style))
        return spans

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_colors:
            return
        base_color = self._resolve_base_color()
        link_color = self._resolve_link_color(base_color)
        self.spans = self._build_spans(base_color, link_color)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
