from __future__ import annotations
from dataclasses import replace
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.actions_commands.ds_button import DS_Button
from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_button import TK_ButtonToken as ButtonToken, TK_ButtonTokens as ButtonTokens


class DS_Theme_Action(DS_Button):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str = "",

        # Geral
        # -----
        page: Optional[ft.Page] = None,

        # Tokens e tema
        # -------------
        token: ButtonToken = ButtonTokens.filled,
        icon: Optional[str] = ft.Icons.PALETTE,
        shape: str = "rounded",

        # Dimensões e layout
        # ------------------
        radius: Optional[float] = 24,
        height: Optional[float] = 32,
        width: Optional[float] = 32,
        icon_only: bool = True,
        disabled: bool = False,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,
        use_header_style: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._page = page
        self._shape = shape
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_header_style = use_header_style
        if self._use_header_style:
            icon_only = True
        if self._shape == "square":
            radius = 0

        super().__init__(
            label=label,
            token=token,
            icon=icon,
            radius=radius,
            icon_only=icon_only,
            disabled=disabled,
            on_click=self._handle_click,
            theme_manager=self._theme_manager,
            auto_apply_theme=auto_apply_theme,
            height=height,
            width=width,
            **kwargs,
        )

        if self._use_header_style and self._theme_manager is not None:
            self._apply_header_style(self._theme_manager.theme)

    def _handle_click(self, e):
        if self._theme_manager is None or self._page is None:
            return
        self._theme_manager.cycle(self._page)

    def _apply_header_style(self, theme):
        header_token = theme.app_shell.header_token
        self.style = ft.ButtonStyle(
            bgcolor=header_token.action_btn_bgcolor,
            shape=ft.CircleBorder(),
            padding=ft.padding.all(8),
            alignment=ft.alignment.center,
        )
        self.height = header_token.action_btn_size
        self.width = header_token.action_btn_size
        if self._icon_only and self._icon_control is not None:
            self._icon_control.color = header_token.action_btn_icon_color
            self._icon_control.size = header_token.action_btn_icon_size
        else:
            self.icon_color = header_token.action_btn_icon_color
            self.icon_size = header_token.action_btn_icon_size
        try:
            self.update()
        except Exception:
            pass

    def _apply_theme(self, theme):
        if self._use_header_style:
            self._apply_header_style(theme)
            return
        super()._apply_theme(theme)

    def _apply_shape(self, token: ButtonToken) -> ButtonToken:
        if self._shape == "square":
            return replace(token, border_radius=0)
        return token

    def _get_theme_token(self, theme):
        token = super()._get_theme_token(theme)
        return self._apply_shape(token)
