from __future__ import annotations
from typing import Optional

import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme
from DEx_Framework.foundations.tokens.tk_typography import TK_TextToken as TextToken, TK_TypographyTokens as TypographyTokens


class DS_Text(ft.Text):

    def __init__(
        self,

        # Geral
        # -----
        value: str = "",

        # Tokens e tema
        # -------------
        token: TextToken = TypographyTokens.body_medium,
        color: Optional[str] = None,
        theme_manager: Optional[DS_ThemeManager] = None,

        # Parâmetros do botão
        # -------------------
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._token = token
        self._color_override = color
        self._use_theme_color = color is None and self._theme_manager is not None

        resolved_color = color if color is not None else (self._theme_manager.theme.text_primary if self._use_theme_color else token.color)

        super().__init__(
            value=value,
            size=token.size,
            weight=token.weight,
            color=resolved_color,
            font_family=token.font_family,
            italic=token.italic,
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_color:
            return
        self.color = theme.text_primary
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
