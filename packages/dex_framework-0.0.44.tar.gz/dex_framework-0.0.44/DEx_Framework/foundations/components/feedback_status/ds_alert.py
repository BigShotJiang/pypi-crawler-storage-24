from __future__ import annotations
from typing import Optional, Callable
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_alert import TK_AlertToken, TK_AlertTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

_ICONS = {
    "info":    ft.Icons.INFO_OUTLINE,
    "success": ft.Icons.CHECK_CIRCLE_OUTLINE,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "error":   ft.Icons.ERROR_OUTLINE,
}


class DS_Alert(ft.Container):

    def __init__(
        self,

        # Geral
        # -----
        message: str,
        alert_type: str = "info",

        # Textos e rótulos
        # ----------------
        title: Optional[str] = None,

        # Parâmetros do botão
        # -------------------
        icon: Optional[str] = None,
        dismissible: bool = False,

        # Callbacks
        # ---------
        on_dismiss: Optional[Callable] = None,

        # Tokens e tema
        # -------------
        token: TK_AlertToken = TK_AlertTokens.default,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._message = message
        self._alert_type = alert_type
        self._title = title
        self._icon = icon
        self._dismissible = dismissible
        self._on_dismiss = on_dismiss

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_AlertTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.alert
        self._token = token

        self._wrapper = self._build_wrapper(token)

        kwargs.pop("content", None)
        super().__init__(content=self._wrapper, **kwargs)

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _build_wrapper(self, token: TK_AlertToken) -> ft.Container:
        t = token
        tp = self._alert_type

        bgcolor = getattr(t, f"{tp}_bgcolor")
        border_color = getattr(t, f"{tp}_border_color")
        icon_color = getattr(t, f"{tp}_icon_color")
        title_color = getattr(t, f"{tp}_title_color")
        text_color = getattr(t, f"{tp}_text_color")

        icon_widget = ft.Icon(
            self._icon or _ICONS.get(tp, ft.Icons.INFO_OUTLINE),
            size=t.icon_size,
            color=icon_color,
        )

        text_col = ft.Column(
            spacing=2,
            tight=True,
            expand=True,
            controls=[
                *(
                    [ft.Text(self._title, size=t.title_size, weight=t.title_weight, color=title_color)]
                    if self._title else []
                ),
                ft.Text(self._message, size=t.message_size, color=text_color),
            ],
        )

        row_controls: list = [icon_widget, text_col]

        if self._dismissible:
            row_controls.append(
                ft.IconButton(
                    icon=ft.Icons.CLOSE,
                    icon_size=14,
                    icon_color=icon_color,
                    tooltip="Fechar",
                    on_click=self._handle_dismiss,
                    padding=ft.padding.all(0),
                )
            )

        row = ft.Row(
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=row_controls,
        )

        return ft.Container(
            padding=ft.padding.only(
                left=t.border_left_width + t.padding_horizontal,
                right=t.padding_horizontal,
                top=t.padding_vertical,
                bottom=t.padding_vertical,
            ),
            bgcolor=bgcolor,
            border_radius=t.border_radius,
            border=ft.border.only(left=ft.BorderSide(t.border_left_width, border_color)),
            content=row,
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.alert
        self._wrapper = self._build_wrapper(self._token)
        self.content = self._wrapper
        try:
            self.update()
        except AssertionError:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)

    def _handle_dismiss(self, e):
        self.visible = False
        try:
            self.update()
        except AssertionError:
            pass
        if self._on_dismiss:
            self._on_dismiss(e)
