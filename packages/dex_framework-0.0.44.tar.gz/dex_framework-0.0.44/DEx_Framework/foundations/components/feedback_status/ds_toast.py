from __future__ import annotations
from typing import Optional
import threading
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme
from DEx_Framework.foundations.tokens.tk_toast import TK_ToastToken, TK_ToastTokens

_ICONS = {
    "info": ft.Icons.INFO_OUTLINE,
    "success": ft.Icons.CHECK_CIRCLE_OUTLINE,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "error": ft.Icons.ERROR_OUTLINE,
}


class DS_Toast:

    @staticmethod
    def show(
            page: ft.Page,
            message: str,
            toast_type: str = "info",
            title: Optional[str] = None,
            duration: int = 4000,
            position: str = "bottom_right",
            token: TK_ToastToken = TK_ToastTokens.default,
            dismissible: bool = True,
            theme_manager: Optional[DS_ThemeManager] = None,
            auto_apply_theme: bool = True,
    ) -> ft.Container:
        tm = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        if token is TK_ToastTokens.default and tm is not None:
            token = tm.theme.toast

        t = token
        tp = toast_type

        bgcolor = getattr(t, f"{tp}_bgcolor")
        border_color = getattr(t, f"{tp}_border_color")
        icon_color = getattr(t, f"{tp}_icon_color")
        title_color = getattr(t, f"{tp}_title_color")
        text_color = getattr(t, f"{tp}_text_color")

        toast_ref: list = []

        def dismiss(e=None):
            if toast_ref and toast_ref[0] in page.overlay:
                page.overlay.remove(toast_ref[0])
                try:
                    page.update()
                except Exception:
                    pass

        text_col = ft.Column(
            spacing=2,
            tight=True,
            expand=True,
            controls=[
                *(
                    [ft.Text(title, size=t.title_size, weight=t.title_weight, color=title_color)]
                    if title else []
                ),
                ft.Text(message, size=t.message_size, color=text_color),
            ],
        )

        row_controls = [
            ft.Icon(_ICONS.get(tp, ft.Icons.INFO_OUTLINE), size=t.icon_size, color=icon_color),
            text_col,
        ]
        if dismissible:
            row_controls.append(
                ft.IconButton(
                    icon=ft.Icons.CLOSE,
                    icon_size=t.close_icon_size,
                    icon_color=icon_color,
                    tooltip="Fechar",
                    on_click=dismiss,
                    padding=ft.padding.all(0),
                )
            )

        align_map = {
            "top_right": ft.alignment.top_right,
            "top_left": ft.alignment.top_left,
            "bottom_right": ft.alignment.bottom_right,
            "bottom_left": ft.alignment.bottom_left,
            "top_center": ft.alignment.top_center,
            "bottom_center": ft.alignment.bottom_center,
        }

        toast = ft.Container(
            content=ft.Container(
                content=ft.Row(
                    spacing=t.spacing,
                    vertical_alignment=ft.CrossAxisAlignment.START,
                    controls=row_controls,
                ),
                bgcolor=bgcolor,
                border_radius=t.border_radius,
                border=ft.border.all(1, border_color),
                padding=ft.padding.symmetric(
                    horizontal=t.padding_horizontal,
                    vertical=t.padding_vertical,
                ),
                shadow=ft.BoxShadow(
                    blur_radius=t.shadow_blur,
                    color=t.shadow_color,
                    offset=ft.Offset(0, 4),
                ),
                width=max(t.min_width, 280),
            ),
            alignment=align_map.get(position, ft.alignment.bottom_right),
            expand=True,
            margin=ft.margin.all(16),
        )

        toast_ref.append(toast)
        page.overlay.append(toast)
        try:
            page.update()
        except Exception:
            pass

        if duration > 0:
            def _auto_dismiss():
                dismiss()

            timer = threading.Timer(duration / 1000, _auto_dismiss)
            timer.daemon = True
            timer.start()

        return toast
