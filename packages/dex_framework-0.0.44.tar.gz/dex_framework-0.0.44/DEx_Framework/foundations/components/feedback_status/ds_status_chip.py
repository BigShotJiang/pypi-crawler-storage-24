from __future__ import annotations
from typing import Optional
import flet as ft

from DEx_Framework.foundations.components.theming_styling.ds_theme_manager import DS_ThemeManager
from DEx_Framework.foundations.tokens.tk_status_chip import TK_StatusChipToken, TK_StatusChipTokens
from DEx_Framework.foundations.tokens.tk_theme import TK_Theme

_STATUS_ICONS = {
    "running": ft.Icons.SYNC,
    "done":    ft.Icons.CHECK_CIRCLE_OUTLINE,
    "failed":  ft.Icons.ERROR_OUTLINE,
    "pending": ft.Icons.HOURGLASS_EMPTY,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "info":    ft.Icons.INFO_OUTLINE,
}

_STATUS_USE_DOT = {"running"}


class DS_StatusChip(ft.Container):

    def __init__(
        self,

        # Parâmetros do botão
        # -------------------
        label: str,

        # Geral
        # -----
        status: str = "pending",
        icon: Optional[str] = None,

        # Dimensões e layout
        # ------------------
        size: str = "medium",

        # Tokens e tema
        # -------------
        token: TK_StatusChipToken = TK_StatusChipTokens.default,
        theme_manager: Optional[DS_ThemeManager] = None,
        auto_apply_theme: bool = True,

        # Outros
        # ------
        **kwargs,
    ):
        __version__ = "0.0.1"
        # -------------------
        self._label = label
        self._status = status
        self._icon = icon
        self._size = size

        self._theme_manager = theme_manager if theme_manager is not None else (DS_ThemeManager.get() if auto_apply_theme else None)
        self._use_theme_token = token is TK_StatusChipTokens.default and self._theme_manager is not None
        if self._use_theme_token:
            token = self._theme_manager.theme.status_chip
        self._token = token
        bgcolor, padding = self._resolve_style(token)

        super().__init__(
            bgcolor=bgcolor,
            border_radius=token.border_radius,
            padding=padding,
            content=self._build_content(token),
            **kwargs,
        )

        if self._theme_manager is not None:
            self._theme_manager.subscribe(self._on_theme_change)

    def _resolve_style(self, token: TK_StatusChipToken):
        t = token
        status = self._status
        bgcolor = getattr(t, f"{status}_bgcolor", t.pending_bgcolor)
        pad_h = getattr(t, f"padding_horizontal_{self._size}", t.padding_horizontal_md)
        pad_v = getattr(t, f"padding_vertical_{self._size}", t.padding_vertical_md)
        padding = ft.padding.symmetric(horizontal=pad_h, vertical=pad_v)
        return bgcolor, padding

    def _build_content(self, token: TK_StatusChipToken) -> ft.Control:
        t = token
        status = self._status

        text_color = getattr(t, f"{status}_text_color", t.pending_text_color)

        tsize = getattr(t, f"text_size_{self._size}", t.text_size_md)
        isize = getattr(t, f"icon_size_{self._size}", t.icon_size_md)

        use_dot = status in _STATUS_USE_DOT and self._icon is None
        icon_name = self._icon or _STATUS_ICONS.get(status)

        if use_dot:
            dot_color = getattr(t, f"{status}_dot_color", text_color)
            indicator = ft.Container(
                width=t.dot_size,
                height=t.dot_size,
                border_radius=t.dot_size / 2,
                bgcolor=dot_color,
            )
        else:
            icon_color = getattr(t, f"{status}_icon_color", text_color)
            indicator = ft.Icon(icon_name, size=isize, color=icon_color)

        controls = [indicator, ft.Text(self._label, size=tsize, color=text_color, weight="w500")]

        return ft.Row(
            spacing=t.spacing,
            tight=True,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=controls,
        )

    def _apply_theme(self, theme: TK_Theme):
        if not self._use_theme_token:
            return
        self._token = theme.status_chip
        bgcolor, padding = self._resolve_style(self._token)
        self.bgcolor = bgcolor
        self.padding = padding
        self.content = self._build_content(self._token)
        try:
            self.update()
        except Exception:
            pass

    def _on_theme_change(self, theme: TK_Theme):
        self._apply_theme(theme)
