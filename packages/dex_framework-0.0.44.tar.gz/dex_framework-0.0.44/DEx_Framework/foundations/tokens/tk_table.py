from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_TableToken:
    bgcolor: str
    border_radius: float
    border_color: str
    border_width: float
    header_bgcolor: str
    header_text_color: str
    header_text_size: float
    header_text_weight: str
    row_bgcolor: str
    row_alt_bgcolor: str
    row_hover_color: str
    row_selected_color: str
    cell_text_color: str
    cell_text_size: float
    cell_padding_horizontal: float
    cell_padding_vertical: float
    divider_color: str
    divider_thickness: float
    icon_color: str
    icon_size: float
    checkbox_color: str


class TK_TableTokens:
    default = TK_TableToken(
        bgcolor="#FFFBFE",
        border_radius=12,
        border_color="#CAC4D0",
        border_width=1,
        header_bgcolor="#F7F2FA",
        header_text_color="#1C1B1F",
        header_text_size=13,
        header_text_weight="w600",
        row_bgcolor="#FFFBFE",
        row_alt_bgcolor="#F4EFF4",
        row_hover_color="#E8DEF8",
        row_selected_color="#D0BCFF",
        cell_text_color="#1C1B1F",
        cell_text_size=13,
        cell_padding_horizontal=16,
        cell_padding_vertical=12,
        divider_color="#E7E0EC",
        divider_thickness=1,
        icon_color="#6750A4",
        icon_size=18,
        checkbox_color="#6750A4",
    )

    dark = TK_TableToken(
        bgcolor="#1C1B1F",
        border_radius=12,
        border_color="#49454F",
        border_width=1,
        header_bgcolor="#2B2930",
        header_text_color="#E6E1E5",
        header_text_size=13,
        header_text_weight="w600",
        row_bgcolor="#1C1B1F",
        row_alt_bgcolor="#25232A",
        row_hover_color="#49454F",
        row_selected_color="#4A4458",
        cell_text_color="#CAC4D0",
        cell_text_size=13,
        cell_padding_horizontal=16,
        cell_padding_vertical=12,
        divider_color="#49454F",
        divider_thickness=1,
        icon_color="#D0BCFF",
        icon_size=18,
        checkbox_color="#D0BCFF",
    )

    minimal = TK_TableToken(
        bgcolor="#FFFFFF",
        border_radius=0,
        border_color="#E0E0E0",
        border_width=1,
        header_bgcolor="#FFFFFF",
        header_text_color="#49454F",
        header_text_size=12,
        header_text_weight="w600",
        row_bgcolor="#FFFFFF",
        row_alt_bgcolor="#FAFAFA",
        row_hover_color="#F5F5F5",
        row_selected_color="#E8DEF8",
        cell_text_color="#1C1B1F",
        cell_text_size=13,
        cell_padding_horizontal=16,
        cell_padding_vertical=10,
        divider_color="#E0E0E0",
        divider_thickness=1,
        icon_color="#6750A4",
        icon_size=18,
        checkbox_color="#6750A4",
    )
