from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_TabsToken:
    bgcolor: str
    active_color: str
    inactive_color: str
    indicator_color: str
    indicator_thickness: float
    tab_bgcolor_active: str
    tab_bgcolor_inactive: str
    tab_bgcolor_hover: str
    tab_height: float
    label_size: float
    label_weight_active: str
    label_weight_inactive: str
    icon_size: float
    border_radius: float
    divider_color: str
    divider_thickness: float
    content_bgcolor: str
    content_padding: float


class TK_TabsTokens:
    primary = TK_TabsToken(
        bgcolor="#F7F2FA",
        active_color="#6750A4",
        inactive_color="#49454F",
        indicator_color="#6750A4",
        indicator_thickness=3,
        tab_bgcolor_active="transparent",
        tab_bgcolor_inactive="transparent",
        tab_bgcolor_hover="#E8DEF8",
        tab_height=48,
        label_size=13,
        label_weight_active="w600",
        label_weight_inactive="w400",
        icon_size=18,
        border_radius=0,
        divider_color="#CAC4D0",
        divider_thickness=1,
        content_bgcolor="#FFFFFF",
        content_padding=16,
    )

    surface = TK_TabsToken(
        bgcolor="#FFFFFF",
        active_color="#6750A4",
        inactive_color="#79747E",
        indicator_color="#6750A4",
        indicator_thickness=3,
        tab_bgcolor_active="#E8DEF8",
        tab_bgcolor_inactive="transparent",
        tab_bgcolor_hover="#F3EDF7",
        tab_height=48,
        label_size=13,
        label_weight_active="w600",
        label_weight_inactive="w400",
        icon_size=18,
        border_radius=24,
        divider_color="#CAC4D0",
        divider_thickness=1,
        content_bgcolor="#FFFFFF",
        content_padding=16,
    )

    dark = TK_TabsToken(
        bgcolor="#1C1B1F",
        active_color="#D0BCFF",
        inactive_color="#938F99",
        indicator_color="#D0BCFF",
        indicator_thickness=3,
        tab_bgcolor_active="#4A4458",
        tab_bgcolor_inactive="transparent",
        tab_bgcolor_hover="#2B2930",
        tab_height=48,
        label_size=13,
        label_weight_active="w600",
        label_weight_inactive="w400",
        icon_size=18,
        border_radius=24,
        divider_color="#49454F",
        divider_thickness=1,
        content_bgcolor="#141218",
        content_padding=16,
    )
