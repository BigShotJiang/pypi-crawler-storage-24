from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_StepperToken:
    active_color: str
    completed_color: str
    pending_color: str
    error_color: str
    connector_color: str
    connector_active_color: str
    connector_thickness: float
    step_size: float
    step_text_color_active: str
    step_text_color_completed: str
    step_text_color_pending: str
    step_number_size: float
    label_color_active: str
    label_color_completed: str
    label_color_pending: str
    label_color_error: str
    label_size: float
    label_weight_active: str
    label_weight_default: str
    sublabel_color: str
    sublabel_size: float
    bgcolor: str


class TK_StepperTokens:
    default = TK_StepperToken(
        active_color="#6750A4",
        completed_color="#386A20",
        pending_color="#CAC4D0",
        error_color="#B3261E",
        connector_color="#CAC4D0",
        connector_active_color="#6750A4",
        connector_thickness=2,
        step_size=32,
        step_text_color_active="#FFFFFF",
        step_text_color_completed="#FFFFFF",
        step_text_color_pending="#79747E",
        step_number_size=13,
        label_color_active="#6750A4",
        label_color_completed="#386A20",
        label_color_pending="#49454F",
        label_color_error="#B3261E",
        label_size=13,
        label_weight_active="w600",
        label_weight_default="w400",
        sublabel_color="#79747E",
        sublabel_size=11,
        bgcolor="transparent",
    )

    dark = TK_StepperToken(
        active_color="#D0BCFF",
        completed_color="#6DD58C",
        pending_color="#49454F",
        error_color="#F2B8B5",
        connector_color="#49454F",
        connector_active_color="#D0BCFF",
        connector_thickness=2,
        step_size=32,
        step_text_color_active="#381E72",
        step_text_color_completed="#0D3B1E",
        step_text_color_pending="#938F99",
        step_number_size=13,
        label_color_active="#D0BCFF",
        label_color_completed="#6DD58C",
        label_color_pending="#CAC4D0",
        label_color_error="#F2B8B5",
        label_size=13,
        label_weight_active="w600",
        label_weight_default="w400",
        sublabel_color="#938F99",
        sublabel_size=11,
        bgcolor="transparent",
    )
