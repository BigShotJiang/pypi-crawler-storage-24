from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_RadioToken:
    active_color: str
    border_color: str
    disabled_color: str
    label_color: str
    label_size: float
    splash_radius: float


class TK_RadioTokens:
    primary = TK_RadioToken(
        active_color="#6750A4",
        border_color="#79747E",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )

    error = TK_RadioToken(
        active_color="#B3261E",
        border_color="#B3261E",
        disabled_color="#1C1B1F61",
        label_color="#B3261E",
        label_size=14,
        splash_radius=20,
    )

    success = TK_RadioToken(
        active_color="#386A20",
        border_color="#386A20",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )
