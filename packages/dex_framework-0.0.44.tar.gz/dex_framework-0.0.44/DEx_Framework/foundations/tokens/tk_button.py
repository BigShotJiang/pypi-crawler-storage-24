from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class TK_ButtonToken:
    bgcolor: str
    color: str
    border_radius: float
    text_size: float
    padding_horizontal: float
    padding_vertical: float
    icon_size: float
    icon_color: str
    bgcolor_disabled: str
    color_disabled: str
    border_color: Optional[str]
    border_width: float


class TK_ButtonTokens:
    filled = TK_ButtonToken(
        bgcolor="#6750A4",
        color="#FFFFFF",
        border_radius=20,
        text_size=14,
        padding_horizontal=24,
        padding_vertical=10,
        icon_size=18,
        icon_color="#FFFFFF",
        bgcolor_disabled="#1C1B1F1F",
        color_disabled="#1C1B1F61",
        border_color=None,
        border_width=0,
    )

    outlined = TK_ButtonToken(
        bgcolor="transparent",
        color="#6750A4",
        border_radius=20,
        text_size=14,
        padding_horizontal=24,
        padding_vertical=10,
        icon_size=18,
        icon_color="#6750A4",
        bgcolor_disabled="transparent",
        color_disabled="#1C1B1F61",
        border_color="#79747E",
        border_width=1,
    )

    text = TK_ButtonToken(
        bgcolor="transparent",
        color="#6750A4",
        border_radius=20,
        text_size=14,
        padding_horizontal=12,
        padding_vertical=10,
        icon_size=18,
        icon_color="#6750A4",
        bgcolor_disabled="transparent",
        color_disabled="#1C1B1F61",
        border_color=None,
        border_width=0,
    )

    tonal = TK_ButtonToken(
        bgcolor="#E8DEF8",
        color="#21005D",
        border_radius=20,
        text_size=14,
        padding_horizontal=24,
        padding_vertical=10,
        icon_size=18,
        icon_color="#21005D",
        bgcolor_disabled="#1C1B1F1F",
        color_disabled="#1C1B1F61",
        border_color=None,
        border_width=0,
    )

    danger = TK_ButtonToken(
        bgcolor="#B3261E",
        color="#FFFFFF",
        border_radius=20,
        text_size=14,
        padding_horizontal=24,
        padding_vertical=10,
        icon_size=18,
        icon_color="#FFFFFF",
        bgcolor_disabled="#1C1B1F1F",
        color_disabled="#1C1B1F61",
        border_color=None,
        border_width=0,
    )
