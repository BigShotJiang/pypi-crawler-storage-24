from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_CheckboxToken:
    active_color: str
    check_color: str
    border_color: str
    disabled_color: str
    label_color: str
    label_size: float
    splash_radius: float


class TK_CheckboxTokens:
    primary = TK_CheckboxToken(
        active_color="#6750A4",
        check_color="#FFFFFF",
        border_color="#79747E",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )

    error = TK_CheckboxToken(
        active_color="#B3261E",
        check_color="#FFFFFF",
        border_color="#B3261E",
        disabled_color="#1C1B1F61",
        label_color="#B3261E",
        label_size=14,
        splash_radius=20,
    )

    success = TK_CheckboxToken(
        active_color="#386A20",
        check_color="#FFFFFF",
        border_color="#386A20",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )
