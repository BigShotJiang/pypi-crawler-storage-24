# =============================================================================
# DEx-Framework
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
# =============================================================================
from __future__ import annotations
from dataclasses import dataclass
import flet as ft


@dataclass(frozen=True)
class TK_LineChartToken:
    bgcolor:              str
    border_color:         str
    border_width:         float
    border_radius:        float
    grid_color:           str
    label_color:          str
    label_size:           float
    title_color:          str
    title_size:           float
    title_weight:         ft.FontWeight
    legend_bgcolor:       str
    legend_border_color:  str
    legend_border_radius: float
    tooltip_bgcolor:      str
    tooltip_text_color:   str
    series_colors:        tuple
    padding:              float
    height:               float
    dot_size:             float
    stroke_width:         float


class TK_LineChartTokens:
    default = TK_LineChartToken(
        bgcolor              = "#FFFFFF",
        border_color         = "#CAC4D0",
        border_width         = 1.0,
        border_radius        = 12.0,
        grid_color           = "#E8E0F0",
        label_color          = "#49454F",
        label_size           = 11.0,
        title_color          = "#1C1B1F",
        title_size           = 14.0,
        title_weight         = ft.FontWeight.W_600,
        legend_bgcolor       = "#F7F2FA",
        legend_border_color  = "#CAC4D0",
        legend_border_radius = 8.0,
        tooltip_bgcolor      = "#2B2930",
        tooltip_text_color   = "#E6E1E5",
        series_colors        = ("#6750A4", "#386A20", "#B3261E", "#006874", "#625B71", "#7D5260"),
        padding              = 16.0,
        height               = 280.0,
        dot_size             = 4.0,
        stroke_width         = 2.5,
    )

    dark = TK_LineChartToken(
        bgcolor              = "#1C1B1F",
        border_color         = "#49454F",
        border_width         = 1.0,
        border_radius        = 12.0,
        grid_color           = "#2B2930",
        label_color          = "#CAC4D0",
        label_size           = 11.0,
        title_color          = "#E6E1E5",
        title_size           = 14.0,
        title_weight         = ft.FontWeight.W_600,
        legend_bgcolor       = "#2B2930",
        legend_border_color  = "#49454F",
        legend_border_radius = 8.0,
        tooltip_bgcolor      = "#E8DEF8",
        tooltip_text_color   = "#1C1B1F",
        series_colors        = ("#D0BCFF", "#B5CCAE", "#F2B8B5", "#A3D5DB", "#CCC2DC", "#EFB8C8"),
        padding              = 16.0,
        height               = 280.0,
        dot_size             = 4.0,
        stroke_width         = 2.5,
    )

    minimal = TK_LineChartToken(
        bgcolor              = "transparent",
        border_color         = "transparent",
        border_width         = 0.0,
        border_radius        = 0.0,
        grid_color           = "#F3EDF7",
        label_color          = "#79747E",
        label_size           = 10.0,
        title_color          = "#1C1B1F",
        title_size           = 13.0,
        title_weight         = ft.FontWeight.W_500,
        legend_bgcolor       = "transparent",
        legend_border_color  = "transparent",
        legend_border_radius = 0.0,
        tooltip_bgcolor      = "#2B2930",
        tooltip_text_color   = "#E6E1E5",
        series_colors        = ("#6750A4", "#386A20", "#B3261E", "#006874", "#625B71", "#7D5260"),
        padding              = 8.0,
        height               = 240.0,
        dot_size             = 3.0,
        stroke_width         = 2.0,
    )
