from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_SidebarToken:
    bgcolor: str
    border_right_color: str
    border_right_width: float

    width_expanded: float
    width_collapsed: float

    header_bgcolor: str
    header_height: float

    toggle_icon_color: str
    toggle_icon_size: float
    toggle_bgcolor: str
    toggle_hover_color: str

    item_height: float
    item_border_radius: float
    item_padding_horizontal: float
    item_spacing: float
    item_bgcolor_hover: str
    item_bgcolor_selected: str
    item_icon_color: str
    item_icon_selected_color: str
    item_icon_size: float
    item_text_color: str
    item_text_selected_color: str
    item_text_size: float
    item_text_weight: str

    badge_bgcolor: str
    badge_text_color: str

    divider_color: str
    divider_thickness: float

    action_icon_color: str
    action_icon_size: float
    action_bgcolor: str
    action_hover_color: str
    action_area_bgcolor: str


class TK_SidebarTokens:
    default = TK_SidebarToken(
        bgcolor="#FFFBFE",
        border_right_color="#CAC4D0",
        border_right_width=1,
        width_expanded=300,
        width_collapsed=64,
        header_bgcolor="#F7F2FA",
        header_height=64,
        toggle_icon_color="#6750A4",
        toggle_icon_size=22,
        toggle_bgcolor="transparent",
        toggle_hover_color="#E8DEF8",
        item_height=48,
        item_border_radius=28,
        item_padding_horizontal=12,
        item_spacing=4,
        item_bgcolor_hover="#E8DEF8",
        item_bgcolor_selected="#E8DEF8",
        item_icon_color="#49454F",
        item_icon_selected_color="#6750A4",
        item_icon_size=24,
        item_text_color="#1C1B1F",
        item_text_selected_color="#6750A4",
        item_text_size=14,
        item_text_weight="w500",
        badge_bgcolor="#B3261E",
        badge_text_color="#FFFFFF",
        divider_color="#CAC4D0",
        divider_thickness=1,
        action_icon_color="#49454F",
        action_icon_size=22,
        action_bgcolor="transparent",
        action_hover_color="#E8DEF8",
        action_area_bgcolor="#F7F2FA",
    )

    dark = TK_SidebarToken(
        bgcolor="#1C1B1F",
        border_right_color="#49454F",
        border_right_width=1,
        width_expanded=300,
        width_collapsed=64,
        header_bgcolor="#2B2930",
        header_height=64,
        toggle_icon_color="#D0BCFF",
        toggle_icon_size=22,
        toggle_bgcolor="transparent",
        toggle_hover_color="#4A4458",
        item_height=48,
        item_border_radius=28,
        item_padding_horizontal=12,
        item_spacing=4,
        item_bgcolor_hover="#4A4458",
        item_bgcolor_selected="#4A4458",
        item_icon_color="#CAC4D0",
        item_icon_selected_color="#D0BCFF",
        item_icon_size=24,
        item_text_color="#E6E1E5",
        item_text_selected_color="#D0BCFF",
        item_text_size=14,
        item_text_weight="w500",
        badge_bgcolor="#B3261E",
        badge_text_color="#FFFFFF",
        divider_color="#49454F",
        divider_thickness=1,
        action_icon_color="#CAC4D0",
        action_icon_size=22,
        action_bgcolor="transparent",
        action_hover_color="#4A4458",
        action_area_bgcolor="#2B2930",
    )

    demi_dark = TK_SidebarToken(
        bgcolor="#1E1B2E",
        border_right_color="#524F63",
        border_right_width=1,
        width_expanded=300,
        width_collapsed=64,
        header_bgcolor="#2D2A3E",
        header_height=64,
        toggle_icon_color="#CDB4FF",
        toggle_icon_size=22,
        toggle_bgcolor="transparent",
        toggle_hover_color="#4F4B60",
        item_height=48,
        item_border_radius=28,
        item_padding_horizontal=12,
        item_spacing=4,
        item_bgcolor_hover="#38354A",
        item_bgcolor_selected="#4F378B",
        item_icon_color="#C4BDD6",
        item_icon_selected_color="#CDB4FF",
        item_icon_size=24,
        item_text_color="#E2DDED",
        item_text_selected_color="#CDB4FF",
        item_text_size=14,
        item_text_weight="w500",
        badge_bgcolor="#B3261E",
        badge_text_color="#FFFFFF",
        divider_color="#524F63",
        divider_thickness=1,
        action_icon_color="#C4BDD6",
        action_icon_size=22,
        action_bgcolor="transparent",
        action_hover_color="#38354A",
        action_area_bgcolor="#2D2A3E",
    )

    minimal = TK_SidebarToken(
        bgcolor="#FFFFFF",
        border_right_color="#E0E0E0",
        border_right_width=1,
        width_expanded=300,
        width_collapsed=56,
        header_bgcolor="#FFFFFF",
        header_height=56,
        toggle_icon_color="#49454F",
        toggle_icon_size=20,
        toggle_bgcolor="transparent",
        toggle_hover_color="#F5F5F5",
        item_height=44,
        item_border_radius=8,
        item_padding_horizontal=12,
        item_spacing=2,
        item_bgcolor_hover="#F5F5F5",
        item_bgcolor_selected="#E8DEF8",
        item_icon_color="#616161",
        item_icon_selected_color="#6750A4",
        item_icon_size=22,
        item_text_color="#212121",
        item_text_selected_color="#6750A4",
        item_text_size=13,
        item_text_weight="w500",
        badge_bgcolor="#B3261E",
        badge_text_color="#FFFFFF",
        divider_color="#E0E0E0",
        divider_thickness=1,
        action_icon_color="#616161",
        action_icon_size=20,
        action_bgcolor="transparent",
        action_hover_color="#F5F5F5",
        action_area_bgcolor="#FAFAFA",
    )
