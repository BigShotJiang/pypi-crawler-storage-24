from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_ModalToken:
    bgcolor: str
    border_radius: float
    padding: float
    title_size: float
    title_weight: str
    title_color: str
    subtitle_size: float
    subtitle_weight: str
    subtitle_color: str
    icon_color: str
    icon_size: float
    divider_color: str
    divider_thickness: float
    shadow_color: str
    shadow_blur: float
    spacing: float
    min_width: float


class TK_ModalTokens:
    default = TK_ModalToken(
        bgcolor="#FFFBFE",
        border_radius=28,
        padding=24,
        title_size=20,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=28,
        divider_color="#CAC4D0",
        divider_thickness=1,
        shadow_color="#00000040",
        shadow_blur=16,
        spacing=16,
        min_width=280,
    )

    danger = TK_ModalToken(
        bgcolor="#FFFBFE",
        border_radius=28,
        padding=24,
        title_size=20,
        title_weight="w600",
        title_color="#B3261E",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#B3261E",
        icon_size=28,
        divider_color="#F2B8B5",
        divider_thickness=1,
        shadow_color="#00000040",
        shadow_blur=16,
        spacing=16,
        min_width=280,
    )

    dark = TK_ModalToken(
        bgcolor="#2B2930",
        border_radius=28,
        padding=24,
        title_size=20,
        title_weight="w600",
        title_color="#E6E1E5",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#CAC4D0",
        icon_color="#D0BCFF",
        icon_size=28,
        divider_color="#49454F",
        divider_thickness=1,
        shadow_color="#00000066",
        shadow_blur=20,
        spacing=16,
        min_width=280,
    )
