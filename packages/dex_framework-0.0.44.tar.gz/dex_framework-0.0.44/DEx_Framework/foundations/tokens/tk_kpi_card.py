from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_KPICardToken:
    bgcolor: str
    border_radius: float
    padding: float
    border_color: str
    border_width: float
    shadow_color: str
    shadow_blur: float
    title_color: str
    title_size: float
    value_color: str
    value_size: float
    value_weight: str
    variation_up_color: str
    variation_down_color: str
    variation_neutral_color: str
    variation_size: float
    icon_bgcolor: str
    icon_color: str
    icon_size: float
    icon_border_radius: float


class TK_KPICardTokens:
    default = TK_KPICardToken(
        bgcolor="#FFFFFF",
        border_radius=16,
        padding=20,
        border_color="#E8DEF8",
        border_width=1,
        shadow_color="#0000001A",
        shadow_blur=8,
        title_color="#49454F",
        title_size=13,
        value_color="#1C1B1F",
        value_size=32,
        value_weight="w700",
        variation_up_color="#386A20",
        variation_down_color="#B3261E",
        variation_neutral_color="#79747E",
        variation_size=12,
        icon_bgcolor="#E8DEF8",
        icon_color="#6750A4",
        icon_size=24,
        icon_border_radius=12,
    )

    success = TK_KPICardToken(
        bgcolor="#F6FBF4",
        border_radius=16,
        padding=20,
        border_color="#C2E7CE",
        border_width=1,
        shadow_color="#0000001A",
        shadow_blur=6,
        title_color="#386A20",
        title_size=13,
        value_color="#1C1B1F",
        value_size=32,
        value_weight="w700",
        variation_up_color="#386A20",
        variation_down_color="#B3261E",
        variation_neutral_color="#79747E",
        variation_size=12,
        icon_bgcolor="#C2E7CE",
        icon_color="#386A20",
        icon_size=24,
        icon_border_radius=12,
    )

    danger = TK_KPICardToken(
        bgcolor="#FFF8F7",
        border_radius=16,
        padding=20,
        border_color="#F2B8B5",
        border_width=1,
        shadow_color="#0000001A",
        shadow_blur=6,
        title_color="#B3261E",
        title_size=13,
        value_color="#1C1B1F",
        value_size=32,
        value_weight="w700",
        variation_up_color="#386A20",
        variation_down_color="#B3261E",
        variation_neutral_color="#79747E",
        variation_size=12,
        icon_bgcolor="#F2B8B5",
        icon_color="#B3261E",
        icon_size=24,
        icon_border_radius=12,
    )

    dark = TK_KPICardToken(
        bgcolor="#2B2930",
        border_radius=16,
        padding=20,
        border_color="#49454F",
        border_width=1,
        shadow_color="#00000033",
        shadow_blur=10,
        title_color="#CAC4D0",
        title_size=13,
        value_color="#E6E1E5",
        value_size=32,
        value_weight="w700",
        variation_up_color="#6DD58C",
        variation_down_color="#F2B8B5",
        variation_neutral_color="#938F99",
        variation_size=12,
        icon_bgcolor="#4A4458",
        icon_color="#D0BCFF",
        icon_size=24,
        icon_border_radius=12,
    )
