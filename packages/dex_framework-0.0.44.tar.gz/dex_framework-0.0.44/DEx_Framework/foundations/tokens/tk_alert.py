from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_AlertToken:
    border_radius: float
    border_left_width: float
    padding_horizontal: float
    padding_vertical: float
    title_size: float
    title_weight: str
    message_size: float
    icon_size: float
    info_bgcolor: str
    info_border_color: str
    info_icon_color: str
    info_title_color: str
    info_text_color: str
    success_bgcolor: str
    success_border_color: str
    success_icon_color: str
    success_title_color: str
    success_text_color: str
    warning_bgcolor: str
    warning_border_color: str
    warning_icon_color: str
    warning_title_color: str
    warning_text_color: str
    error_bgcolor: str
    error_border_color: str
    error_icon_color: str
    error_title_color: str
    error_text_color: str


class TK_AlertTokens:
    default = TK_AlertToken(
        border_radius=8,
        border_left_width=4,
        padding_horizontal=16,
        padding_vertical=14,
        title_size=14,
        title_weight="w600",
        message_size=13,
        icon_size=20,
        info_bgcolor="#E3F2FD",
        info_border_color="#1565C0",
        info_icon_color="#1565C0",
        info_title_color="#0D47A1",
        info_text_color="#1C1B1F",
        success_bgcolor="#F6FBF4",
        success_border_color="#386A20",
        success_icon_color="#386A20",
        success_title_color="#2D5518",
        success_text_color="#1C1B1F",
        warning_bgcolor="#FFF8E1",
        warning_border_color="#7D5700",
        warning_icon_color="#7D5700",
        warning_title_color="#5D4000",
        warning_text_color="#1C1B1F",
        error_bgcolor="#FFF8F7",
        error_border_color="#B3261E",
        error_icon_color="#B3261E",
        error_title_color="#8C1D18",
        error_text_color="#1C1B1F",
    )

    dark = TK_AlertToken(
        border_radius=8,
        border_left_width=4,
        padding_horizontal=16,
        padding_vertical=14,
        title_size=14,
        title_weight="w600",
        message_size=13,
        icon_size=20,
        info_bgcolor="#0D2137",
        info_border_color="#64B5F6",
        info_icon_color="#64B5F6",
        info_title_color="#90CAF9",
        info_text_color="#CAC4D0",
        success_bgcolor="#0D2016",
        success_border_color="#6DD58C",
        success_icon_color="#6DD58C",
        success_title_color="#A8D5B5",
        success_text_color="#CAC4D0",
        warning_bgcolor="#1E1600",
        warning_border_color="#FFD54F",
        warning_icon_color="#FFD54F",
        warning_title_color="#FFE082",
        warning_text_color="#CAC4D0",
        error_bgcolor="#2D0F0D",
        error_border_color="#F2B8B5",
        error_icon_color="#F2B8B5",
        error_title_color="#F2B8B5",
        error_text_color="#CAC4D0",
    )
