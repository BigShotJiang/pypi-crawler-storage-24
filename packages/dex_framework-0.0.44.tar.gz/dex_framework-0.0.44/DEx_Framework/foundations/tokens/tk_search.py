from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class TK_SearchToken:
    bgcolor: str
    border_color: str
    focused_border_color: str
    border_radius: float
    border_width: float
    focused_border_width: float
    text_color: str
    hint_color: str
    icon_color: str
    icon_size: float
    text_size: float
    height: float
    width: Optional[float]
    content_padding_horizontal: float
    content_padding_vertical: float
    bgcolor_disabled: str
    border_color_disabled: str


class TK_SearchTokens:
    outlined = TK_SearchToken(
        bgcolor="transparent",
        border_color="#79747E",
        focused_border_color="#6750A4",
        border_radius=24,
        border_width=1,
        focused_border_width=2,
        text_color="#1C1B1F",
        hint_color="#79747E",
        icon_color="#49454F",
        icon_size=20,
        text_size=14,
        height=44,
        width=None,
        content_padding_horizontal=16,
        content_padding_vertical=10,
        bgcolor_disabled="#F4EFF4",
        border_color_disabled="#CAC4D0",
    )

    filled = TK_SearchToken(
        bgcolor="#E7E0EC",
        border_color="#E7E0EC",
        focused_border_color="#6750A4",
        border_radius=24,
        border_width=0,
        focused_border_width=2,
        text_color="#1C1B1F",
        hint_color="#79747E",
        icon_color="#49454F",
        icon_size=20,
        text_size=14,
        height=44,
        width=None,
        content_padding_horizontal=16,
        content_padding_vertical=10,
        bgcolor_disabled="#D9D3DE",
        border_color_disabled="#CAC4D0",
    )

    dark = TK_SearchToken(
        bgcolor="#2B2930",
        border_color="#49454F",
        focused_border_color="#D0BCFF",
        border_radius=24,
        border_width=1,
        focused_border_width=2,
        text_color="#E6E1E5",
        hint_color="#938F99",
        icon_color="#CAC4D0",
        icon_size=20,
        text_size=14,
        height=44,
        width=None,
        content_padding_horizontal=16,
        content_padding_vertical=10,
        bgcolor_disabled="#1C1B1F",
        border_color_disabled="#49454F",
    )
