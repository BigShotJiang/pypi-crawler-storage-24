﻿from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_ProgressBarToken:
    track_bgcolor: str
    progress_color: str
    label_color: str


class TK_ProgressBarTokens:
    default = TK_ProgressBarToken(
        track_bgcolor="#E8E0F0",
        progress_color="#6750A4",
        label_color="#1C1B1F",
    )

    dark = TK_ProgressBarToken(
        track_bgcolor="#4A4458",
        progress_color="#D0BCFF",
        label_color="#E6E1E5",
    )

    demi_dark = TK_ProgressBarToken(
        track_bgcolor="#524F63",
        progress_color="#CDB4FF",
        label_color="#E2DDED",
    )
