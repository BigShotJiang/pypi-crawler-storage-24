﻿from __future__ import annotations
from dataclasses import dataclass

from DEx_Framework.foundations.tokens.tk_app_shell import TK_AppShellToken, TK_AppShellTokens
from DEx_Framework.foundations.tokens.tk_header    import TK_HeaderToken, TK_HeaderTokens
from DEx_Framework.foundations.tokens.tk_sidebar   import TK_SidebarToken, TK_SidebarTokens
from DEx_Framework.foundations.tokens.tk_button    import TK_ButtonToken,   TK_ButtonTokens
from DEx_Framework.foundations.tokens.tk_card      import TK_CardToken,     TK_CardTokens
from DEx_Framework.foundations.tokens.tk_input     import TK_TextFieldToken, TK_InputTokens
from DEx_Framework.foundations.tokens.tk_modal     import TK_ModalToken,    TK_ModalTokens
from DEx_Framework.foundations.tokens.tk_table     import TK_TableToken,    TK_TableTokens
from DEx_Framework.foundations.tokens.tk_search    import TK_SearchToken,   TK_SearchTokens
from DEx_Framework.foundations.tokens.tk_alert     import TK_AlertToken,    TK_AlertTokens
from DEx_Framework.foundations.tokens.tk_checkbox  import TK_CheckboxToken, TK_CheckboxTokens
from DEx_Framework.foundations.tokens.tk_dropdown  import TK_DropdownToken, TK_DropdownTokens
from DEx_Framework.foundations.tokens.tk_kpi_card  import TK_KPICardToken,  TK_KPICardTokens
from DEx_Framework.foundations.tokens.tk_line_chart import TK_LineChartToken, TK_LineChartTokens
from DEx_Framework.foundations.tokens.tk_progressbar import TK_ProgressBarToken, TK_ProgressBarTokens
from DEx_Framework.foundations.tokens.tk_radio     import TK_RadioToken,    TK_RadioTokens
from DEx_Framework.foundations.tokens.tk_status_chip import TK_StatusChipToken, TK_StatusChipTokens
from DEx_Framework.foundations.tokens.tk_stepper   import TK_StepperToken,  TK_StepperTokens
from DEx_Framework.foundations.tokens.tk_tabs      import TK_TabsToken,     TK_TabsTokens
from DEx_Framework.foundations.tokens.tk_timeline  import TK_TimelineToken, TK_TimelineTokens
from DEx_Framework.foundations.tokens.tk_toast     import TK_ToastToken,    TK_ToastTokens


@dataclass(frozen=True)
class TK_Theme:
    """
    Agrupa todos os tokens de componentes para um tema visual completo.

    Campos
    ------
    name                 : Identificador do tema
    page_bgcolor         : Cor de fundo da pÃ¡gina
    flet_theme_mode      : "light" | "dark" | "system"
    flet_color_scheme    : Cor semente para o ft.Theme do Flet

    app_shell            : Layout header + sidebar
    button_filled        : BotÃ£o primÃ¡rio preenchido
    button_outlined      : BotÃ£o com borda
    button_tonal         : BotÃ£o tonal (surface variant)
    card                 : Card elevado
    input                : Campo de texto outlined
    modal                : DiÃ¡logo/modal padrÃ£o
    table                : Tabela de dados
    search               : Campo de busca

    text_primary         : Cor principal de texto
    text_secondary       : Cor secundÃ¡ria de texto
    text_accent          : Cor de destaque (links, Ã­cones ativos)
    """
    name: str
    page_bgcolor: str
    flet_theme_mode: str
    flet_color_scheme: str

    app_shell: TK_AppShellToken
    button_filled: TK_ButtonToken
    button_outlined: TK_ButtonToken
    button_tonal: TK_ButtonToken
    card: TK_CardToken
    input: TK_TextFieldToken
    modal: TK_ModalToken
    table: TK_TableToken
    search: TK_SearchToken

    alert: TK_AlertToken
    checkbox: TK_CheckboxToken
    dropdown: TK_DropdownToken
    kpi_card: TK_KPICardToken
    line_chart: TK_LineChartToken
    progressbar: TK_ProgressBarToken
    radio: TK_RadioToken
    status_chip: TK_StatusChipToken
    stepper: TK_StepperToken
    tabs: TK_TabsToken
    timeline: TK_TimelineToken
    toast: TK_ToastToken

    text_primary: str
    text_secondary: str
    text_accent: str


# ---------------------------------------------------------------------------
# Variantes de tokens adicionais usadas pelos temas dark / demi-dark / light
# (definidas inline para nÃ£o poluir os arquivos de token individuais)
# ---------------------------------------------------------------------------

_BUTTON_FILLED_DARK = TK_ButtonToken(
    bgcolor="#D0BCFF", color="#381E72",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#381E72",
    bgcolor_disabled="#E6E1E533", color_disabled="#E6E1E561",
    border_color=None, border_width=0,
)
_BUTTON_OUTLINED_DARK = TK_ButtonToken(
    bgcolor="transparent", color="#D0BCFF",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#D0BCFF",
    bgcolor_disabled="transparent", color_disabled="#E6E1E561",
    border_color="#938F99", border_width=1,
)
_BUTTON_TONAL_DARK = TK_ButtonToken(
    bgcolor="#4A4458", color="#E8DEF8",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#E8DEF8",
    bgcolor_disabled="#E6E1E533", color_disabled="#E6E1E561",
    border_color=None, border_width=0,
)

_BUTTON_FILLED_DEMI = TK_ButtonToken(
    bgcolor="#CDB4FF", color="#2D0070",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#2D0070",
    bgcolor_disabled="#E2DDED33", color_disabled="#E2DDED61",
    border_color=None, border_width=0,
)
_BUTTON_OUTLINED_DEMI = TK_ButtonToken(
    bgcolor="transparent", color="#CDB4FF",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#CDB4FF",
    bgcolor_disabled="transparent", color_disabled="#E2DDED61",
    border_color="#9C98A8", border_width=1,
)
_BUTTON_TONAL_DEMI = TK_ButtonToken(
    bgcolor="#4F378B", color="#E2DDED",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#E2DDED",
    bgcolor_disabled="#E2DDED33", color_disabled="#E2DDED61",
    border_color=None, border_width=0,
)

_INPUT_DARK = TK_TextFieldToken(
    border_color="#938F99", focused_border_color="#D0BCFF",
    border_radius=4, border_width=1, focused_border_width=2,
    text_size=16, label_color="#CAC4D0", cursor_color="#D0BCFF",
    bgcolor="transparent", content_padding=16,
    bgcolor_readonly="#2B2930", bgcolor_required="#370B09",
    border_color_readonly="#49454F", border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
)
_INPUT_DEMI = TK_TextFieldToken(
    border_color="#9C98A8", focused_border_color="#CDB4FF",
    border_radius=4, border_width=1, focused_border_width=2,
    text_size=16, label_color="#C4BDD6", cursor_color="#CDB4FF",
    bgcolor="transparent", content_padding=16,
    bgcolor_readonly="#2D2A3E", bgcolor_required="#3A1414",
    border_color_readonly="#524F63", border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
)

_MODAL_DEMI = TK_ModalToken(
    bgcolor="#2D2A3E", border_radius=28, padding=24,
    title_size=20, title_weight="w600", title_color="#E2DDED",
    subtitle_size=14, subtitle_weight="w400", subtitle_color="#C4BDD6",
    icon_color="#CDB4FF", icon_size=28,
    divider_color="#524F63", divider_thickness=1,
    shadow_color="#00000066", shadow_blur=20,
    spacing=16, min_width=280,
)

_TABLE_DEMI = TK_TableToken(
    bgcolor="#1E1B2E", border_radius=12,
    border_color="#524F63", border_width=1,
    header_bgcolor="#2D2A3E",
    header_text_color="#E2DDED", header_text_size=13, header_text_weight="w600",
    row_bgcolor="#1E1B2E", row_alt_bgcolor="#26233A",
    row_hover_color="#38354A", row_selected_color="#4F378B",
    cell_text_color="#C4BDD6", cell_text_size=13,
    cell_padding_horizontal=16, cell_padding_vertical=12,
    divider_color="#524F63", divider_thickness=1,
    icon_color="#CDB4FF", icon_size=18, checkbox_color="#CDB4FF",
)

_SEARCH_DEMI = TK_SearchToken(
    bgcolor="#2D2A3E", border_color="#524F63",
    focused_border_color="#CDB4FF",
    border_radius=24, border_width=1, focused_border_width=2,
    text_color="#E2DDED", hint_color="#9C98A8",
    icon_color="#C4BDD6", icon_size=20, text_size=14,
    height=44, width=None,
    content_padding_horizontal=16, content_padding_vertical=10,
    bgcolor_disabled="#1E1B2E", border_color_disabled="#524F63",
)


_CHECKBOX_DARK = TK_CheckboxToken(
    active_color="#D0BCFF",
    check_color="#381E72",
    border_color="#938F99",
    disabled_color="#E6E1E561",
    label_color="#E6E1E5",
    label_size=14,
    splash_radius=20,
)
_CHECKBOX_DEMI = TK_CheckboxToken(
    active_color="#CDB4FF",
    check_color="#2D0070",
    border_color="#9C98A8",
    disabled_color="#E2DDED61",
    label_color="#E2DDED",
    label_size=14,
    splash_radius=20,
)

_RADIO_DARK = TK_RadioToken(
    active_color="#D0BCFF",
    border_color="#938F99",
    disabled_color="#E6E1E561",
    label_color="#E6E1E5",
    label_size=14,
    splash_radius=20,
)
_RADIO_DEMI = TK_RadioToken(
    active_color="#CDB4FF",
    border_color="#9C98A8",
    disabled_color="#E2DDED61",
    label_color="#E2DDED",
    label_size=14,
    splash_radius=20,
)

_DROPDOWN_DARK = TK_DropdownToken(
    border_color="#938F99",
    focused_border_color="#D0BCFF",
    border_radius=4,
    border_width=1,
    focused_border_width=2,
    text_size=16,
    label_color="#CAC4D0",
    bgcolor="transparent",
    content_padding=16,
    bgcolor_readonly="#2B2930",
    bgcolor_required="#370B09",
    border_color_readonly="#49454F",
    border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
    icon_color="#CAC4D0",
    icon_size=20,
)
_DROPDOWN_DEMI = TK_DropdownToken(
    border_color="#9C98A8",
    focused_border_color="#CDB4FF",
    border_radius=4,
    border_width=1,
    focused_border_width=2,
    text_size=16,
    label_color="#C4BDD6",
    bgcolor="transparent",
    content_padding=16,
    bgcolor_readonly="#2D2A3E",
    bgcolor_required="#3A1414",
    border_color_readonly="#524F63",
    border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
    icon_color="#C4BDD6",
    icon_size=20,
)


# ---------------------------------------------------------------------------
# TK_Themes â€” catÃ¡logo de temas
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Cores semente (MD3) para temas adicionais
# ---------------------------------------------------------------------------

_SEED_BLUE       = "#2196F3"
_SEED_INDIGO     = "#3F51B5"
_SEED_TEAL       = "#009688"
_SEED_LIGHT_BLUE = "#03A9F4"
_SEED_CYAN       = "#00BCD4"
_SEED_LIME       = "#CDDC39"
_SEED_AMBER      = "#FFC107"
_SEED_BROWN      = "#795548"
_SEED_BLUE_GREY  = "#607D8B"


# ---------------------------------------------------------------------------
# Helpers de cor e tokens din?micos para temas com seed
# ---------------------------------------------------------------------------

def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    hex_color = hex_color.lstrip("#")
    return int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def _mix(c1: str, c2: str, t: float) -> str:
    r1, g1, b1 = _hex_to_rgb(c1)
    r2, g2, b2 = _hex_to_rgb(c2)
    r = int(r1 + (r2 - r1) * t)
    g = int(g1 + (g2 - g1) * t)
    b = int(b1 + (b2 - b1) * t)
    return _rgb_to_hex((r, g, b))


def _lighten(color: str, amount: float) -> str:
    return _mix(color, "#FFFFFF", amount)


def _darken(color: str, amount: float) -> str:
    return _mix(color, "#000000", amount)


def _header_from_seed(seed: str) -> TK_HeaderToken:
    base = TK_HeaderTokens.primary
    return TK_HeaderToken(
        bgcolor=seed,
        title_size=base.title_size,
        title_weight=base.title_weight,
        title_color="#FFFFFF",
        subtitle_size=base.subtitle_size,
        subtitle_weight=base.subtitle_weight,
        subtitle_color=_lighten(seed, 0.70),
        icon_color="#FFFFFF",
        icon_size=base.icon_size,
        divider_color=_lighten(seed, 0.45),
        divider_thickness=base.divider_thickness,
        padding_horizontal=base.padding_horizontal,
        padding_vertical=base.padding_vertical,
        spacing=base.spacing,
        search_bgcolor=_darken(seed, 0.12),
        search_border_color=_lighten(seed, 0.35),
        search_focused_border_color="#FFFFFF",
        search_text_color="#FFFFFF",
        search_hint_color=_lighten(seed, 0.60),
        action_btn_bgcolor=_darken(seed, 0.08),
        action_btn_icon_color="#FFFFFF",
        action_btn_hover_color=_lighten(seed, 0.25),
        action_btn_size=base.action_btn_size,
        action_btn_icon_size=base.action_btn_icon_size,
    )


def _button_filled_from_seed(seed: str) -> TK_ButtonToken:
    base = TK_ButtonTokens.filled
    return TK_ButtonToken(
        bgcolor=seed,
        color="#FFFFFF",
        border_radius=base.border_radius,
        text_size=base.text_size,
        padding_horizontal=base.padding_horizontal,
        padding_vertical=base.padding_vertical,
        icon_size=base.icon_size,
        icon_color="#FFFFFF",
        bgcolor_disabled=base.bgcolor_disabled,
        color_disabled=base.color_disabled,
        border_color=None,
        border_width=0,
    )


def _button_outlined_from_seed(seed: str) -> TK_ButtonToken:
    base = TK_ButtonTokens.outlined
    return TK_ButtonToken(
        bgcolor="transparent",
        color=seed,
        border_radius=base.border_radius,
        text_size=base.text_size,
        padding_horizontal=base.padding_horizontal,
        padding_vertical=base.padding_vertical,
        icon_size=base.icon_size,
        icon_color=seed,
        bgcolor_disabled=base.bgcolor_disabled,
        color_disabled=base.color_disabled,
        border_color=_darken(seed, 0.25),
        border_width=base.border_width,
    )


def _button_tonal_from_seed(seed: str) -> TK_ButtonToken:
    base = TK_ButtonTokens.tonal
    return TK_ButtonToken(
        bgcolor=_lighten(seed, 0.80),
        color=_darken(seed, 0.45),
        border_radius=base.border_radius,
        text_size=base.text_size,
        padding_horizontal=base.padding_horizontal,
        padding_vertical=base.padding_vertical,
        icon_size=base.icon_size,
        icon_color=_darken(seed, 0.45),
        bgcolor_disabled=base.bgcolor_disabled,
        color_disabled=base.color_disabled,
        border_color=None,
        border_width=0,
    )


def _sidebar_from_seed(seed: str) -> TK_SidebarToken:
    base = TK_SidebarTokens.default
    return TK_SidebarToken(
        bgcolor=_lighten(seed, 0.96),
        border_right_color=base.border_right_color,
        border_right_width=base.border_right_width,
        width_expanded=base.width_expanded,
        width_collapsed=base.width_collapsed,
        header_bgcolor=_lighten(seed, 0.85),
        header_height=base.header_height,
        toggle_icon_color=seed,
        toggle_icon_size=base.toggle_icon_size,
        toggle_bgcolor=base.toggle_bgcolor,
        toggle_hover_color=_lighten(seed, 0.65),
        item_height=base.item_height,
        item_border_radius=base.item_border_radius,
        item_padding_horizontal=base.item_padding_horizontal,
        item_spacing=base.item_spacing,
        item_bgcolor_hover=_lighten(seed, 0.65),
        item_bgcolor_selected=_lighten(seed, 0.55),
        item_icon_color=base.item_icon_color,
        item_icon_selected_color=seed,
        item_icon_size=base.item_icon_size,
        item_text_color=base.item_text_color,
        item_text_selected_color=seed,
        item_text_size=base.item_text_size,
        item_text_weight=base.item_text_weight,
        badge_bgcolor=base.badge_bgcolor,
        badge_text_color=base.badge_text_color,
        divider_color=base.divider_color,
        divider_thickness=base.divider_thickness,
        action_icon_color=seed,
        action_icon_size=base.action_icon_size,
        action_bgcolor=base.action_bgcolor,
        action_hover_color=_lighten(seed, 0.65),
        action_area_bgcolor=_lighten(seed, 0.90),
    )


def _app_shell_from_seed(seed: str) -> TK_AppShellToken:
    return TK_AppShellToken(
        bgcolor=_lighten(seed, 0.94),
        header_token=_header_from_seed(seed),
        sidebar_token=_sidebar_from_seed(seed),
    )


class TK_Themes:
    """
    CatÃ¡logo de temas prontos para uso.

    Variantes
    ---------
    default   : MD3 purple â€” tema padrÃ£o claro com acento roxo
    light     : Branco limpo â€” mÃ¡ximo de claridade, contrastes sutis
    dark      : Escuro profundo â€” superfÃ­cie quase preta (#141218)
    demi_dark : Semi-escuro â€” slate-purple (#1E1B2E), mais suave que o dark total
    system    : Segue a preferÃªncia do SO (light tokens, modo=system no Flet)
    blue      : Tema claro com seed azul
    indigo    : Tema claro com seed ?ndigo
    teal      : Tema claro com seed teal
    light_blue: Tema claro com seed azul-claro
    cyan      : Tema claro com seed ciano
    lime      : Tema claro com seed lima
    amber     : Tema claro com seed ?mbar
    brown     : Tema claro com seed marrom
    blue_grey : Tema claro com seed azul-acinzentado
    """

    default = TK_Theme(
        name="default",
        page_bgcolor="#F7F2FA",
        flet_theme_mode="light",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.default,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    light = TK_Theme(
        name="light",
        page_bgcolor="#FFFFFF",
        flet_theme_mode="light",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.light,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.outlined,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.minimal,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    dark = TK_Theme(
        name="dark",
        page_bgcolor="#141218",
        flet_theme_mode="dark",
        flet_color_scheme="#D0BCFF",
        app_shell=TK_AppShellTokens.dark,
        button_filled=_BUTTON_FILLED_DARK,
        button_outlined=_BUTTON_OUTLINED_DARK,
        button_tonal=_BUTTON_TONAL_DARK,
        card=TK_CardTokens.dark,
        input=_INPUT_DARK,
        modal=TK_ModalTokens.dark,
        table=TK_TableTokens.dark,
        search=TK_SearchTokens.dark,
        alert=TK_AlertTokens.dark,
        checkbox=_CHECKBOX_DARK,
        dropdown=_DROPDOWN_DARK,
        kpi_card=TK_KPICardTokens.dark,
        line_chart=TK_LineChartTokens.dark,
        progressbar=TK_ProgressBarTokens.dark,
        radio=_RADIO_DARK,
        status_chip=TK_StatusChipTokens.dark,
        stepper=TK_StepperTokens.dark,
        tabs=TK_TabsTokens.dark,
        timeline=TK_TimelineTokens.dark,
        toast=TK_ToastTokens.dark,
        text_primary="#E6E1E5",
        text_secondary="#CAC4D0",
        text_accent="#D0BCFF",
    )

    demi_dark = TK_Theme(
        name="demi_dark",
        page_bgcolor="#1E1B2E",
        flet_theme_mode="dark",
        flet_color_scheme="#CDB4FF",
        app_shell=TK_AppShellTokens.demi_dark,
        button_filled=_BUTTON_FILLED_DEMI,
        button_outlined=_BUTTON_OUTLINED_DEMI,
        button_tonal=_BUTTON_TONAL_DEMI,
        card=_TABLE_DEMI,
        input=_INPUT_DEMI,
        modal=_MODAL_DEMI,
        table=_TABLE_DEMI,
        search=_SEARCH_DEMI,
        alert=TK_AlertTokens.dark,
        checkbox=_CHECKBOX_DEMI,
        dropdown=_DROPDOWN_DEMI,
        kpi_card=TK_KPICardTokens.dark,
        line_chart=TK_LineChartTokens.dark,
        progressbar=TK_ProgressBarTokens.demi_dark,
        radio=_RADIO_DEMI,
        status_chip=TK_StatusChipTokens.dark,
        stepper=TK_StepperTokens.dark,
        tabs=TK_TabsTokens.dark,
        timeline=TK_TimelineTokens.dark,
        toast=TK_ToastTokens.dark,
        text_primary="#E2DDED",
        text_secondary="#C4BDD6",
        text_accent="#CDB4FF",
    )

    system = TK_Theme(
        name="system",
        page_bgcolor="#F7F2FA",
        flet_theme_mode="system",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.default,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    blue = TK_Theme(
        name="blue",
        page_bgcolor=_lighten(_SEED_BLUE, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_BLUE,
        app_shell=_app_shell_from_seed(_SEED_BLUE),
        button_filled=_button_filled_from_seed(_SEED_BLUE),
        button_outlined=_button_outlined_from_seed(_SEED_BLUE),
        button_tonal=_button_tonal_from_seed(_SEED_BLUE),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_BLUE,
    )

    indigo = TK_Theme(
        name="indigo",
        page_bgcolor=_lighten(_SEED_INDIGO, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_INDIGO,
        app_shell=_app_shell_from_seed(_SEED_INDIGO),
        button_filled=_button_filled_from_seed(_SEED_INDIGO),
        button_outlined=_button_outlined_from_seed(_SEED_INDIGO),
        button_tonal=_button_tonal_from_seed(_SEED_INDIGO),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_INDIGO,
    )

    teal = TK_Theme(
        name="teal",
        page_bgcolor=_lighten(_SEED_TEAL, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_TEAL,
        app_shell=_app_shell_from_seed(_SEED_TEAL),
        button_filled=_button_filled_from_seed(_SEED_TEAL),
        button_outlined=_button_outlined_from_seed(_SEED_TEAL),
        button_tonal=_button_tonal_from_seed(_SEED_TEAL),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_TEAL,
    )

    light_blue = TK_Theme(
        name="light_blue",
        page_bgcolor=_lighten(_SEED_LIGHT_BLUE, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_LIGHT_BLUE,
        app_shell=_app_shell_from_seed(_SEED_LIGHT_BLUE),
        button_filled=_button_filled_from_seed(_SEED_LIGHT_BLUE),
        button_outlined=_button_outlined_from_seed(_SEED_LIGHT_BLUE),
        button_tonal=_button_tonal_from_seed(_SEED_LIGHT_BLUE),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_LIGHT_BLUE,
    )

    cyan = TK_Theme(
        name="cyan",
        page_bgcolor=_lighten(_SEED_CYAN, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_CYAN,
        app_shell=_app_shell_from_seed(_SEED_CYAN),
        button_filled=_button_filled_from_seed(_SEED_CYAN),
        button_outlined=_button_outlined_from_seed(_SEED_CYAN),
        button_tonal=_button_tonal_from_seed(_SEED_CYAN),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_CYAN,
    )

    lime = TK_Theme(
        name="lime",
        page_bgcolor=_lighten(_SEED_LIME, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_LIME,
        app_shell=_app_shell_from_seed(_SEED_LIME),
        button_filled=_button_filled_from_seed(_SEED_LIME),
        button_outlined=_button_outlined_from_seed(_SEED_LIME),
        button_tonal=_button_tonal_from_seed(_SEED_LIME),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_LIME,
    )

    amber = TK_Theme(
        name="amber",
        page_bgcolor=_lighten(_SEED_AMBER, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_AMBER,
        app_shell=_app_shell_from_seed(_SEED_AMBER),
        button_filled=_button_filled_from_seed(_SEED_AMBER),
        button_outlined=_button_outlined_from_seed(_SEED_AMBER),
        button_tonal=_button_tonal_from_seed(_SEED_AMBER),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_AMBER,
    )

    brown = TK_Theme(
        name="brown",
        page_bgcolor=_lighten(_SEED_BROWN, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_BROWN,
        app_shell=_app_shell_from_seed(_SEED_BROWN),
        button_filled=_button_filled_from_seed(_SEED_BROWN),
        button_outlined=_button_outlined_from_seed(_SEED_BROWN),
        button_tonal=_button_tonal_from_seed(_SEED_BROWN),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_BROWN,
    )

    blue_grey = TK_Theme(
        name="blue_grey",
        page_bgcolor=_lighten(_SEED_BLUE_GREY, 0.96),
        flet_theme_mode="light",
        flet_color_scheme=_SEED_BLUE_GREY,
        app_shell=_app_shell_from_seed(_SEED_BLUE_GREY),
        button_filled=_button_filled_from_seed(_SEED_BLUE_GREY),
        button_outlined=_button_outlined_from_seed(_SEED_BLUE_GREY),
        button_tonal=_button_tonal_from_seed(_SEED_BLUE_GREY),
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        alert=TK_AlertTokens.default,
        checkbox=TK_CheckboxTokens.primary,
        dropdown=TK_DropdownTokens.outlined,
        kpi_card=TK_KPICardTokens.default,
        line_chart=TK_LineChartTokens.default,
        progressbar=TK_ProgressBarTokens.default,
        radio=TK_RadioTokens.primary,
        status_chip=TK_StatusChipTokens.default,
        stepper=TK_StepperTokens.default,
        tabs=TK_TabsTokens.primary,
        timeline=TK_TimelineTokens.default,
        toast=TK_ToastTokens.default,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent=_SEED_BLUE_GREY,
    )

    _ALL: dict = {}

    @classmethod
    def _ensure_all(cls) -> None:
        if cls._ALL:
            return
        cls._ALL = {
            name: value
            for name, value in cls.__dict__.items()
            if isinstance(value, TK_Theme)
        }

    @classmethod
    def get(cls, name: str) -> TK_Theme:
        """Retorna o tema pelo nome. Lan?a KeyError se n?o encontrado."""
        cls._ensure_all()
        if name not in cls._ALL:
            raise KeyError(f"Tema '{name}' n?o encontrado. Op??es: {list(cls._ALL)}")
        return cls._ALL[name]

    @classmethod
    def names(cls) -> list:
        """Retorna a lista de nomes de temas dispon?veis."""
        cls._ensure_all()
        return list(cls._ALL.keys())


