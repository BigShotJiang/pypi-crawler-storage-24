from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_TimelineToken:
    bgcolor: str
    line_color: str
    line_width: float
    dot_size: float
    dot_border_width: float
    dot_running_color: str
    dot_done_color: str
    dot_failed_color: str
    dot_pending_color: str
    dot_warning_color: str
    dot_info_color: str
    icon_size: float
    icon_color_running: str
    icon_color_done: str
    icon_color_failed: str
    icon_color_pending: str
    title_color: str
    title_size: float
    title_weight: str
    subtitle_color: str
    subtitle_size: float
    timestamp_color: str
    timestamp_size: float
    details_color: str
    details_size: float
    item_spacing: float
    connector_color: str


class TK_TimelineTokens:
    default = TK_TimelineToken(
        bgcolor="transparent",
        line_color="#E8DEF8",
        line_width=2,
        dot_size=36,
        dot_border_width=2,
        dot_running_color="#1565C0",
        dot_done_color="#386A20",
        dot_failed_color="#B3261E",
        dot_pending_color="#79747E",
        dot_warning_color="#7D5700",
        dot_info_color="#6750A4",
        icon_size=18,
        icon_color_running="#FFFFFF",
        icon_color_done="#FFFFFF",
        icon_color_failed="#FFFFFF",
        icon_color_pending="#FFFFFF",
        title_color="#1C1B1F",
        title_size=14,
        title_weight="w600",
        subtitle_color="#49454F",
        subtitle_size=13,
        timestamp_color="#79747E",
        timestamp_size=11,
        details_color="#49454F",
        details_size=12,
        item_spacing=0,
        connector_color="#CAC4D0",
    )

    dark = TK_TimelineToken(
        bgcolor="transparent",
        line_color="#4A4458",
        line_width=2,
        dot_size=36,
        dot_border_width=2,
        dot_running_color="#64B5F6",
        dot_done_color="#6DD58C",
        dot_failed_color="#F2B8B5",
        dot_pending_color="#49454F",
        dot_warning_color="#FFD54F",
        dot_info_color="#D0BCFF",
        icon_size=18,
        icon_color_running="#0D2137",
        icon_color_done="#0D2016",
        icon_color_failed="#2D1210",
        icon_color_pending="#141218",
        title_color="#E6E1E5",
        title_size=14,
        title_weight="w600",
        subtitle_color="#CAC4D0",
        subtitle_size=13,
        timestamp_color="#938F99",
        timestamp_size=11,
        details_color="#CAC4D0",
        details_size=12,
        item_spacing=0,
        connector_color="#49454F",
    )
