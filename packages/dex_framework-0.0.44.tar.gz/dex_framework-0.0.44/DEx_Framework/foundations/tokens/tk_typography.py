from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class TK_TextToken:
    size: float
    weight: str
    color: str
    font_family: Optional[str] = None
    italic: bool = False


class TK_TypographyTokens:
    display_large   = TK_TextToken(size=57, weight="w400", color="#1C1B1F")
    display_medium  = TK_TextToken(size=45, weight="w400", color="#1C1B1F")
    display_small   = TK_TextToken(size=36, weight="w400", color="#1C1B1F")

    headline_large  = TK_TextToken(size=32, weight="w400", color="#1C1B1F")
    headline_medium = TK_TextToken(size=28, weight="w400", color="#1C1B1F")
    headline_small  = TK_TextToken(size=24, weight="w400", color="#1C1B1F")

    title_large     = TK_TextToken(size=22, weight="w500", color="#1C1B1F")
    title_medium    = TK_TextToken(size=16, weight="w500", color="#1C1B1F")
    title_small     = TK_TextToken(size=14, weight="w500", color="#1C1B1F")

    body_large      = TK_TextToken(size=16, weight="w400", color="#1C1B1F")
    body_medium     = TK_TextToken(size=14, weight="w400", color="#1C1B1F")
    body_small      = TK_TextToken(size=12, weight="w400", color="#1C1B1F")

    label_large     = TK_TextToken(size=14, weight="w500", color="#1C1B1F")
    label_medium    = TK_TextToken(size=12, weight="w500", color="#1C1B1F")
    label_small     = TK_TextToken(size=11, weight="w500", color="#1C1B1F")
