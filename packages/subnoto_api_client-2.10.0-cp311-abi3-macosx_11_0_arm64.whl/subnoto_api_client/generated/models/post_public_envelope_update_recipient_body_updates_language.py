from enum import Enum

class PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage(str, Enum):
    EN = "en"
    ES = "es"
    FI = "fi"
    FR = "fr"
    IT = "it"

    def __str__(self) -> str:
        return str(self.value)
