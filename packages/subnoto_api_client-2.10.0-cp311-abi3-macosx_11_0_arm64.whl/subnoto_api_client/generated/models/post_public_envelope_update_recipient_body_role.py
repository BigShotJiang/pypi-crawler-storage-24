from enum import Enum

class PostPublicEnvelopeUpdateRecipientBodyRole(str, Enum):
    APPROVER = "approver"
    SIGNER = "signer"
    VIEWER = "viewer"

    def __str__(self) -> str:
        return str(self.value)
