from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_update_recipient_body_updates_language import PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage
from ..models.post_public_envelope_update_recipient_body_updates_role import PostPublicEnvelopeUpdateRecipientBodyUpdatesRole
from ..models.post_public_envelope_update_recipient_body_updates_verification_type import PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType
from ..types import UNSET, Unset






T = TypeVar("T", bound="PostPublicEnvelopeUpdateRecipientBodyUpdates")



@_attrs_define
class PostPublicEnvelopeUpdateRecipientBodyUpdates:
    """ 
        Attributes:
            firstname (str | Unset):
            lastname (str | Unset):
            phone (str | Unset):
            job_title (str | Unset):
            company (str | Unset):
            address_line_1 (str | Unset):
            address_line_2 (str | Unset):
            zip_code (str | Unset):
            city (str | Unset):
            country (str | Unset):
            role (PostPublicEnvelopeUpdateRecipientBodyUpdatesRole | Unset):
            order (float | Unset):
            language (PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage | Unset):
            verification_type (PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType | Unset):
     """

    firstname: str | Unset = UNSET
    lastname: str | Unset = UNSET
    phone: str | Unset = UNSET
    job_title: str | Unset = UNSET
    company: str | Unset = UNSET
    address_line_1: str | Unset = UNSET
    address_line_2: str | Unset = UNSET
    zip_code: str | Unset = UNSET
    city: str | Unset = UNSET
    country: str | Unset = UNSET
    role: PostPublicEnvelopeUpdateRecipientBodyUpdatesRole | Unset = UNSET
    order: float | Unset = UNSET
    language: PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage | Unset = UNSET
    verification_type: PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        firstname = self.firstname

        lastname = self.lastname

        phone = self.phone

        job_title = self.job_title

        company = self.company

        address_line_1 = self.address_line_1

        address_line_2 = self.address_line_2

        zip_code = self.zip_code

        city = self.city

        country = self.country

        role: str | Unset = UNSET
        if not isinstance(self.role, Unset):
            role = self.role.value


        order = self.order

        language: str | Unset = UNSET
        if not isinstance(self.language, Unset):
            language = self.language.value


        verification_type: str | Unset = UNSET
        if not isinstance(self.verification_type, Unset):
            verification_type = self.verification_type.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if firstname is not UNSET:
            field_dict["firstname"] = firstname
        if lastname is not UNSET:
            field_dict["lastname"] = lastname
        if phone is not UNSET:
            field_dict["phone"] = phone
        if job_title is not UNSET:
            field_dict["jobTitle"] = job_title
        if company is not UNSET:
            field_dict["company"] = company
        if address_line_1 is not UNSET:
            field_dict["addressLine1"] = address_line_1
        if address_line_2 is not UNSET:
            field_dict["addressLine2"] = address_line_2
        if zip_code is not UNSET:
            field_dict["zipCode"] = zip_code
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country
        if role is not UNSET:
            field_dict["role"] = role
        if order is not UNSET:
            field_dict["order"] = order
        if language is not UNSET:
            field_dict["language"] = language
        if verification_type is not UNSET:
            field_dict["verificationType"] = verification_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        firstname = d.pop("firstname", UNSET)

        lastname = d.pop("lastname", UNSET)

        phone = d.pop("phone", UNSET)

        job_title = d.pop("jobTitle", UNSET)

        company = d.pop("company", UNSET)

        address_line_1 = d.pop("addressLine1", UNSET)

        address_line_2 = d.pop("addressLine2", UNSET)

        zip_code = d.pop("zipCode", UNSET)

        city = d.pop("city", UNSET)

        country = d.pop("country", UNSET)

        _role = d.pop("role", UNSET)
        role: PostPublicEnvelopeUpdateRecipientBodyUpdatesRole | Unset
        if isinstance(_role,  Unset):
            role = UNSET
        else:
            role = PostPublicEnvelopeUpdateRecipientBodyUpdatesRole(_role)




        order = d.pop("order", UNSET)

        _language = d.pop("language", UNSET)
        language: PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage | Unset
        if isinstance(_language,  Unset):
            language = UNSET
        else:
            language = PostPublicEnvelopeUpdateRecipientBodyUpdatesLanguage(_language)




        _verification_type = d.pop("verificationType", UNSET)
        verification_type: PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType | Unset
        if isinstance(_verification_type,  Unset):
            verification_type = UNSET
        else:
            verification_type = PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType(_verification_type)




        post_public_envelope_update_recipient_body_updates = cls(
            firstname=firstname,
            lastname=lastname,
            phone=phone,
            job_title=job_title,
            company=company,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            zip_code=zip_code,
            city=city,
            country=country,
            role=role,
            order=order,
            language=language,
            verification_type=verification_type,
        )


        post_public_envelope_update_recipient_body_updates.additional_properties = d
        return post_public_envelope_update_recipient_body_updates

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
