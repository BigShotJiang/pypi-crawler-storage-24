from enum import Enum

class PostPublicEnvelopeUpdateRecipientBodyUpdatesVerificationType(str, Enum):
    EMAIL = "email"
    NONE = "none"
    SMS = "sms"

    def __str__(self) -> str:
        return str(self.value)
