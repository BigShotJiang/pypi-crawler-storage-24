from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_update_recipient_response_200_recipient_language import PostPublicEnvelopeUpdateRecipientResponse200RecipientLanguage
from ..models.post_public_envelope_update_recipient_response_200_recipient_role import PostPublicEnvelopeUpdateRecipientResponse200RecipientRole
from ..models.post_public_envelope_update_recipient_response_200_recipient_status import PostPublicEnvelopeUpdateRecipientResponse200RecipientStatus
from ..models.post_public_envelope_update_recipient_response_200_recipient_verification_type import PostPublicEnvelopeUpdateRecipientResponse200RecipientVerificationType
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PostPublicEnvelopeUpdateRecipientResponse200Recipient")



@_attrs_define
class PostPublicEnvelopeUpdateRecipientResponse200Recipient:
    """ 
        Attributes:
            email (str):
            firstname (str):
            lastname (str):
            phone (None | str):
            role (PostPublicEnvelopeUpdateRecipientResponse200RecipientRole):
            order (float):
            associated_contact (bool):
            status (PostPublicEnvelopeUpdateRecipientResponse200RecipientStatus):
            language (PostPublicEnvelopeUpdateRecipientResponse200RecipientLanguage):
            verification_type (PostPublicEnvelopeUpdateRecipientResponse200RecipientVerificationType):
            color_variant (str):
            job_title (str | Unset):
            company (str | Unset):
            address_line_1 (str | Unset):
            address_line_2 (str | Unset):
            zip_code (str | Unset):
            city (str | Unset):
            country (str | Unset):
     """

    email: str
    firstname: str
    lastname: str
    phone: None | str
    role: PostPublicEnvelopeUpdateRecipientResponse200RecipientRole
    order: float
    associated_contact: bool
    status: PostPublicEnvelopeUpdateRecipientResponse200RecipientStatus
    language: PostPublicEnvelopeUpdateRecipientResponse200RecipientLanguage
    verification_type: PostPublicEnvelopeUpdateRecipientResponse200RecipientVerificationType
    color_variant: str
    job_title: str | Unset = UNSET
    company: str | Unset = UNSET
    address_line_1: str | Unset = UNSET
    address_line_2: str | Unset = UNSET
    zip_code: str | Unset = UNSET
    city: str | Unset = UNSET
    country: str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        firstname = self.firstname

        lastname = self.lastname

        phone: None | str
        phone = self.phone

        role = self.role.value

        order = self.order

        associated_contact = self.associated_contact

        status = self.status.value

        language = self.language.value

        verification_type = self.verification_type.value

        color_variant = self.color_variant

        job_title = self.job_title

        company = self.company

        address_line_1 = self.address_line_1

        address_line_2 = self.address_line_2

        zip_code = self.zip_code

        city = self.city

        country = self.country


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "firstname": firstname,
            "lastname": lastname,
            "phone": phone,
            "role": role,
            "order": order,
            "associatedContact": associated_contact,
            "status": status,
            "language": language,
            "verificationType": verification_type,
            "colorVariant": color_variant,
        })
        if job_title is not UNSET:
            field_dict["jobTitle"] = job_title
        if company is not UNSET:
            field_dict["company"] = company
        if address_line_1 is not UNSET:
            field_dict["addressLine1"] = address_line_1
        if address_line_2 is not UNSET:
            field_dict["addressLine2"] = address_line_2
        if zip_code is not UNSET:
            field_dict["zipCode"] = zip_code
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        firstname = d.pop("firstname")

        lastname = d.pop("lastname")

        def _parse_phone(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        phone = _parse_phone(d.pop("phone"))


        role = PostPublicEnvelopeUpdateRecipientResponse200RecipientRole(d.pop("role"))




        order = d.pop("order")

        associated_contact = d.pop("associatedContact")

        status = PostPublicEnvelopeUpdateRecipientResponse200RecipientStatus(d.pop("status"))




        language = PostPublicEnvelopeUpdateRecipientResponse200RecipientLanguage(d.pop("language"))




        verification_type = PostPublicEnvelopeUpdateRecipientResponse200RecipientVerificationType(d.pop("verificationType"))




        color_variant = d.pop("colorVariant")

        job_title = d.pop("jobTitle", UNSET)

        company = d.pop("company", UNSET)

        address_line_1 = d.pop("addressLine1", UNSET)

        address_line_2 = d.pop("addressLine2", UNSET)

        zip_code = d.pop("zipCode", UNSET)

        city = d.pop("city", UNSET)

        country = d.pop("country", UNSET)

        post_public_envelope_update_recipient_response_200_recipient = cls(
            email=email,
            firstname=firstname,
            lastname=lastname,
            phone=phone,
            role=role,
            order=order,
            associated_contact=associated_contact,
            status=status,
            language=language,
            verification_type=verification_type,
            color_variant=color_variant,
            job_title=job_title,
            company=company,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            zip_code=zip_code,
            city=city,
            country=country,
        )

        return post_public_envelope_update_recipient_response_200_recipient

