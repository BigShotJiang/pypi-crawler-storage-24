from enum import Enum

class PostPublicEnvelopeUpdateRecipientBodyUpdatesRole(str, Enum):
    APPROVER = "approver"
    SIGNER = "signer"
    VIEWER = "viewer"

    def __str__(self) -> str:
        return str(self.value)
