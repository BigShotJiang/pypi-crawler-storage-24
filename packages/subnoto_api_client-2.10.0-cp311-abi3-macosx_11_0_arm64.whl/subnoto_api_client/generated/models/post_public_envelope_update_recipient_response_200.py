from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_update_recipient_response_200_recipient import PostPublicEnvelopeUpdateRecipientResponse200Recipient





T = TypeVar("T", bound="PostPublicEnvelopeUpdateRecipientResponse200")



@_attrs_define
class PostPublicEnvelopeUpdateRecipientResponse200:
    """ 
        Attributes:
            recipient (PostPublicEnvelopeUpdateRecipientResponse200Recipient):
     """

    recipient: PostPublicEnvelopeUpdateRecipientResponse200Recipient





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_update_recipient_response_200_recipient import PostPublicEnvelopeUpdateRecipientResponse200Recipient
        recipient = self.recipient.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "recipient": recipient,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_update_recipient_response_200_recipient import PostPublicEnvelopeUpdateRecipientResponse200Recipient
        d = dict(src_dict)
        recipient = PostPublicEnvelopeUpdateRecipientResponse200Recipient.from_dict(d.pop("recipient"))




        post_public_envelope_update_recipient_response_200 = cls(
            recipient=recipient,
        )

        return post_public_envelope_update_recipient_response_200

