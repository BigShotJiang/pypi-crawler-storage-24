from enum import Enum

class PostPublicEnvelopeUpdateRecipientResponse200RecipientRole(str, Enum):
    APPROVER = "approver"
    SIGNER = "signer"
    VIEWER = "viewer"

    def __str__(self) -> str:
        return str(self.value)
