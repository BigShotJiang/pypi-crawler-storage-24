from enum import Enum

class PostPublicEnvelopeUpdateRecipientResponse200RecipientStatus(str, Enum):
    APPROVED = "approved"
    CANCELED = "canceled"
    DECLINED = "declined"
    PENDING = "pending"
    SIGNED = "signed"

    def __str__(self) -> str:
        return str(self.value)
