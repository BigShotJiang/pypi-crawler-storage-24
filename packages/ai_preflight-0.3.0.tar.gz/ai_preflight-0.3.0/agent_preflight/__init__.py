"""agent-preflight — safe, budget-aware multi-model agent experiments.

Quickstart::

    from agent_preflight import preflight, provision_key, BudgetTracker

    # 1. Validate prerequisites
    preflight(
        admin_key="sk-or-admin-...",
        or_key="sk-or-...",
        models=["meta-llama/llama-3.3-70b-instruct"],
        budget_per_model=0.25,
    )

    # 2. Provision a capped sub-key
    key = provision_key(admin_key, label="my-run-llama", limit_usd=0.25)

    # 3. Track spend
    tracker = BudgetTracker(api_key=key, limit_usd=0.25, mode="detailed")
    status = tracker.poll()
    print(status)  # Budget: $0.25 remaining of $0.25 (100% left)

    # 4. Or run a full multi-model Docker experiment
    from agent_preflight import run_multi
    results = run_multi(
        models=[("meta-llama/llama-3.3-70b-instruct", "llama"), ...],
        image_name="my-agent:latest",
        admin_key="sk-or-admin-...",
        or_key="sk-or-...",
        budget_usd=0.25,
    )
"""

from .budget import BudgetTracker
from .caching import (
    ANTHROPIC_MIN_CACHE_TOKENS,
    CacheMetrics,
    PromptBuilder,
    detect_provider,
    format_cache_report,
    min_cache_tokens,
    stable_system_prompt,
)
from .docker import build_image, image_exists, remove_container, run_container
from .eject import (
    BudgetExceededEject,
    BudgetFractionEject,
    CompositeEject,
    EjectPolicy,
    IdleTimeoutEject,
    default_eject_policies,
)
from .events import EventLogger
from .health import InfraCheck, docker_health, env_vars, git_version, http_health
from .models import BudgetStatus, CacheStats, EjectDecision, InfraResult, RunResult
from .preflight import PreflightError, preflight
from .provision import (
    delete_key,
    get_account_balance,
    get_available_models,
    get_available_models_or_empty,
    get_usage,
    provision_key,
    provision_key_full,
)
from .runner import run_multi, run_single
from .status import latest_run, main as status_main, print_status_table, summarise_model
from .utils import render_prompt, summarize_run

__all__ = [
    # Preflight
    "preflight",
    "PreflightError",
    # Infrastructure health checks
    "InfraCheck",
    "InfraResult",
    "http_health",
    "env_vars",
    "docker_health",
    "git_version",
    # Provisioning
    "provision_key",
    "provision_key_full",
    "delete_key",
    "get_usage",
    "get_account_balance",
    "get_available_models",
    "get_available_models_or_empty",
    # Budget tracking
    "BudgetTracker",
    "BudgetStatus",
    # Prompt caching
    "PromptBuilder",
    "CacheMetrics",
    "CacheStats",
    "ANTHROPIC_MIN_CACHE_TOKENS",
    "min_cache_tokens",
    "detect_provider",
    "format_cache_report",
    "stable_system_prompt",
    # Eject policies
    "EjectPolicy",
    "EjectDecision",
    "BudgetExceededEject",
    "IdleTimeoutEject",
    "BudgetFractionEject",
    "CompositeEject",
    "default_eject_policies",
    # Docker
    "run_container",
    "run_multi",
    "run_single",
    "build_image",
    "image_exists",
    "remove_container",
    # Events
    "EventLogger",
    # Models
    "RunResult",
    # Status
    "status_main",
    "print_status_table",
    "summarise_model",
    "latest_run",
    # Utilities
    "render_prompt",
    "summarize_run",
]
