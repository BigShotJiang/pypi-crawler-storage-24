"""Helpers for resolving package-level patch points at runtime."""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


def resolve_public(name: str, fallback: T, *, original: T | None = None) -> T:
    """Resolve a callable from ``agent_preflight`` if it has been patched.

    This lets tests and downstream users monkeypatch ``agent_preflight.foo``
    consistently, while internal modules retain local fallbacks and avoid
    import-time cycles.
    """
    try:
        import agent_preflight as package
    except Exception:
        return fallback

    value = getattr(package, name, fallback)
    if not isinstance(value, Callable):
        return fallback

    if original is not None and value is original and fallback is not original:
        return fallback

    return value
