"""Unit tests for budget tracker helpers."""

from __future__ import annotations

import agent_preflight as package

from agent_preflight.budget import BudgetTracker


class TestBudgetTracker:
    def test_package_level_get_usage_patch_is_used(self, monkeypatch):
        monkeypatch.setattr(package, "get_usage", lambda _key: 0.123)

        tracker = BudgetTracker(api_key="sk-or-test", limit_usd=1.0, poll_interval_s=0)
        status = tracker.poll(force=True)

        assert status.used == 0.123
