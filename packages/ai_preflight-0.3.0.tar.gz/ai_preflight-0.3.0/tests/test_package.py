"""Package metadata tests."""

from __future__ import annotations

from importlib.resources import files


def test_py_typed_marker_present():
    assert files("agent_preflight").joinpath("py.typed").is_file()
