"""Crypto Addresses resource."""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..pagination import PaginatedResponse, async_paginate, paginate


class CryptoAddressesResource:
    """Sync crypto address operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._client.post("/api/v1/crypto-addresses", json=params)

    def list(self, **params: Any) -> PaginatedResponse:
        return self._client.get_paginated("/api/v1/crypto-addresses", params=params)

    def list_auto_paginate(self, **params: Any):
        return paginate(lambda p: self._client.get_paginated("/api/v1/crypto-addresses", params=p), params)

    def get(self, address_id: str) -> Dict[str, Any]:
        return self._client.get(f"/api/v1/crypto-addresses/{address_id}")

    def update(self, address_id: str, **params: Any) -> Dict[str, Any]:
        return self._client.patch(f"/api/v1/crypto-addresses/{address_id}", json=params)

    def delete(self, address_id: str) -> Dict[str, Any]:
        return self._client.delete(f"/api/v1/crypto-addresses/{address_id}")

    def validate(self, **params: Any) -> Dict[str, Any]:
        return self._client.get("/api/v1/crypto-addresses/validate", params=params)


class AsyncCryptoAddressesResource:
    """Async crypto address operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    async def create(self, **params: Any) -> Dict[str, Any]:
        return await self._client.post("/api/v1/crypto-addresses", json=params)

    async def list(self, **params: Any) -> PaginatedResponse:
        return await self._client.get_paginated("/api/v1/crypto-addresses", params=params)

    def list_auto_paginate(self, **params: Any):
        return async_paginate(lambda p: self._client.get_paginated("/api/v1/crypto-addresses", params=p), params)

    async def get(self, address_id: str) -> Dict[str, Any]:
        return await self._client.get(f"/api/v1/crypto-addresses/{address_id}")

    async def update(self, address_id: str, **params: Any) -> Dict[str, Any]:
        return await self._client.patch(f"/api/v1/crypto-addresses/{address_id}", json=params)

    async def delete(self, address_id: str) -> Dict[str, Any]:
        return await self._client.delete(f"/api/v1/crypto-addresses/{address_id}")

    async def validate(self, **params: Any) -> Dict[str, Any]:
        return await self._client.get("/api/v1/crypto-addresses/validate", params=params)
