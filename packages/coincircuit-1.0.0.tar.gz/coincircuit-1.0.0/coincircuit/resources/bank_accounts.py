"""Bank Accounts resource."""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..pagination import PaginatedResponse, async_paginate, paginate


class BankAccountsResource:
    """Sync bank account operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._client.post("/api/v1/bank-accounts", json=params)

    def list(self, **params: Any) -> PaginatedResponse:
        return self._client.get_paginated("/api/v1/bank-accounts", params=params)

    def list_auto_paginate(self, **params: Any):
        return paginate(lambda p: self._client.get_paginated("/api/v1/bank-accounts", params=p), params)

    def get(self, account_id: str) -> Dict[str, Any]:
        return self._client.get(f"/api/v1/bank-accounts/{account_id}")

    def update(self, account_id: str, **params: Any) -> Dict[str, Any]:
        return self._client.patch(f"/api/v1/bank-accounts/{account_id}", json=params)

    def delete(self, account_id: str) -> Dict[str, Any]:
        return self._client.delete(f"/api/v1/bank-accounts/{account_id}")

    def banks(self) -> Any:
        return self._client.get("/api/v1/bank-accounts/banks")


class AsyncBankAccountsResource:
    """Async bank account operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    async def create(self, **params: Any) -> Dict[str, Any]:
        return await self._client.post("/api/v1/bank-accounts", json=params)

    async def list(self, **params: Any) -> PaginatedResponse:
        return await self._client.get_paginated("/api/v1/bank-accounts", params=params)

    def list_auto_paginate(self, **params: Any):
        return async_paginate(lambda p: self._client.get_paginated("/api/v1/bank-accounts", params=p), params)

    async def get(self, account_id: str) -> Dict[str, Any]:
        return await self._client.get(f"/api/v1/bank-accounts/{account_id}")

    async def update(self, account_id: str, **params: Any) -> Dict[str, Any]:
        return await self._client.patch(f"/api/v1/bank-accounts/{account_id}", json=params)

    async def delete(self, account_id: str) -> Dict[str, Any]:
        return await self._client.delete(f"/api/v1/bank-accounts/{account_id}")

    async def banks(self) -> Any:
        return await self._client.get("/api/v1/bank-accounts/banks")
