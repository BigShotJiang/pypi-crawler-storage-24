"""Blockchain resource."""

from typing import Any, Dict

from ..client import AsyncHttpClient, HttpClient

BASE_PATH = "/api/v1/blockchain"


class BlockchainResource:
    """Synchronous blockchain resource.

    Wraps endpoints under ``/api/v1/blockchain``.
    """

    def __init__(self, client: HttpClient) -> None:
        self._client = client

    def get_supported_assets(self) -> Dict[str, Any]:
        """Get all supported blockchain assets and networks.

        Returns a dict keyed by chain name (e.g. "ethereum", "solana"),
        where each value is a list of asset objects with metadata and
        optional contract info.

        Returns:
            Dict mapping chain names to lists of supported asset objects.
        """
        return self._client.request("GET", f"{BASE_PATH}/assets")

    def get_confirmations(self) -> Dict[str, Any]:
        """Get confirmation requirements for each blockchain.

        Returns:
            Dict with confirmation requirements per chain.
        """
        return self._client.request("GET", f"{BASE_PATH}/confirmations")

    def get_gas_fees(self) -> Dict[str, Any]:
        """Get current gas fees for each blockchain.

        Returns:
            Dict with gas fee data per chain.
        """
        return self._client.request("GET", f"{BASE_PATH}/gas-fees")


class AsyncBlockchainResource:
    """Asynchronous blockchain resource."""

    def __init__(self, client: AsyncHttpClient) -> None:
        self._client = client

    async def get_supported_assets(self) -> Dict[str, Any]:
        """Get all supported blockchain assets and networks (async)."""
        return await self._client.request("GET", f"{BASE_PATH}/assets")

    async def get_confirmations(self) -> Dict[str, Any]:
        """Get confirmation requirements for each blockchain (async)."""
        return await self._client.request("GET", f"{BASE_PATH}/confirmations")

    async def get_gas_fees(self) -> Dict[str, Any]:
        """Get current gas fees for each blockchain (async)."""
        return await self._client.request("GET", f"{BASE_PATH}/gas-fees")
