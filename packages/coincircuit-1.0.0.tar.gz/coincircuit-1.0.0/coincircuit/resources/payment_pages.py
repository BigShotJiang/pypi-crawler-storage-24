"""Payment Pages resource."""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..pagination import PaginatedResponse, async_paginate, paginate


class PaymentPagesResource:
    """Sync payment pages operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._client.post("/api/v1/payments/pages", json=params)

    def list(self, **params: Any) -> PaginatedResponse:
        return self._client.get_paginated("/api/v1/payments/pages", params=params)

    def list_auto_paginate(self, **params: Any):
        return paginate(lambda p: self._client.get_paginated("/api/v1/payments/pages", params=p), params)

    def update(self, page_id: str, **params: Any) -> Dict[str, Any]:
        return self._client.patch(f"/api/v1/payments/pages/{page_id}", json=params)

    def delete(self, page_id: str) -> Dict[str, Any]:
        return self._client.delete(f"/api/v1/payments/pages/{page_id}")

    def sessions(self, reference: str, **params: Any) -> PaginatedResponse:
        return self._client.get_paginated(f"/api/v1/payments/pages/{reference}/sessions", params=params)


class AsyncPaymentPagesResource:
    """Async payment pages operations."""

    def __init__(self, client: Any) -> None:
        self._client = client

    async def create(self, **params: Any) -> Dict[str, Any]:
        return await self._client.post("/api/v1/payments/pages", json=params)

    async def list(self, **params: Any) -> PaginatedResponse:
        return await self._client.get_paginated("/api/v1/payments/pages", params=params)

    def list_auto_paginate(self, **params: Any):
        return async_paginate(lambda p: self._client.get_paginated("/api/v1/payments/pages", params=p), params)

    async def update(self, page_id: str, **params: Any) -> Dict[str, Any]:
        return await self._client.patch(f"/api/v1/payments/pages/{page_id}", json=params)

    async def delete(self, page_id: str) -> Dict[str, Any]:
        return await self._client.delete(f"/api/v1/payments/pages/{page_id}")

    async def sessions(self, reference: str, **params: Any) -> PaginatedResponse:
        return await self._client.get_paginated(f"/api/v1/payments/pages/{reference}/sessions", params=params)
