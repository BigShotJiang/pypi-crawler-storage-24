"""Balance resource."""

from typing import Any, Dict, Optional

from ..client import AsyncHttpClient, HttpClient
from ..types import BalanceDto

BASE_PATH = "/api/v1/balance"


class BalanceResource:
    """Synchronous balance resource.

    Wraps endpoints under ``/api/v1/balance``.
    """

    def __init__(self, client: HttpClient) -> None:
        self._client = client

    def get(self, *, currency: Optional[str] = None) -> BalanceDto:
        """Get the merchant balance.

        Args:
            currency: Filter by currency (e.g. "NGN", "USDT"). Optional.

        Returns:
            The balance object with total, available, and pending amounts.
        """
        params: Dict[str, Any] = {
            "currency": currency,
        }
        return self._client.request("GET", BASE_PATH, params=params)


class AsyncBalanceResource:
    """Asynchronous balance resource."""

    def __init__(self, client: AsyncHttpClient) -> None:
        self._client = client

    async def get(self, *, currency: Optional[str] = None) -> BalanceDto:
        """Get the merchant balance (async)."""
        params: Dict[str, Any] = {
            "currency": currency,
        }
        return await self._client.request("GET", BASE_PATH, params=params)
