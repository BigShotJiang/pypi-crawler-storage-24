"""Exchange rates resource."""

from typing import Any, Dict, Optional

from ..client import AsyncHttpClient, HttpClient

BASE_PATH = "/api/v1/rates"


class RatesResource:
    """Synchronous exchange rates resource.

    Wraps endpoints under ``/api/v1/rates``.
    """

    def __init__(self, client: HttpClient) -> None:
        self._client = client

    def convert(self, *, from_currency: str, to_currency: str) -> Dict[str, Any]:
        """Get the conversion rate between two currencies.

        Args:
            from_currency: Source currency (e.g. "USD", "NGN", "USDT").
            to_currency: Target currency (e.g. "USDT", "NGN", "USD").

        Returns:
            Conversion rate data.
        """
        params: Dict[str, Any] = {
            "from": from_currency,
            "to": to_currency,
        }
        return self._client.request("GET", f"{BASE_PATH}/convert", params=params)

    def list(self) -> Dict[str, Any]:
        """Get all available conversion rates.

        Returns:
            Dict of all conversion rates.
        """
        return self._client.request("GET", BASE_PATH)


class AsyncRatesResource:
    """Asynchronous exchange rates resource."""

    def __init__(self, client: AsyncHttpClient) -> None:
        self._client = client

    async def convert(self, *, from_currency: str, to_currency: str) -> Dict[str, Any]:
        """Get the conversion rate between two currencies (async)."""
        params: Dict[str, Any] = {
            "from": from_currency,
            "to": to_currency,
        }
        return await self._client.request("GET", f"{BASE_PATH}/convert", params=params)

    async def list(self) -> Dict[str, Any]:
        """Get all available conversion rates (async)."""
        return await self._client.request("GET", BASE_PATH)
