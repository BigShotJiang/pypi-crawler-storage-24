"""Transactions resource."""

from typing import Any, AsyncIterator, Dict, Iterator, Optional

from ..client import AsyncHttpClient, HttpClient
from ..pagination import PaginatedResponse, async_paginate, paginate
from ..types import TransactionDto

BASE_PATH = "/api/v1/transactions"


class TransactionsResource:
    """Synchronous transactions resource.

    Wraps endpoints under ``/api/v1/transactions``.
    """

    def __init__(self, client: HttpClient) -> None:
        self._client = client

    def list(
        self,
        *,
        page: int = 1,
        size: int = 10,
        search: Optional[str] = None,
        status: Optional[str] = None,
        chain: Optional[str] = None,
        asset: Optional[str] = None,
        session_reference: Optional[str] = None,
        customer_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> PaginatedResponse:
        """List transactions with pagination.

        Returns:
            A PaginatedResponse containing TransactionDto items.
        """
        params: Dict[str, Any] = {
            "page": page,
            "size": size,
            "search": search,
            "status": status,
            "chain": chain,
            "asset": asset,
            "sessionReference": session_reference,
            "customerId": customer_id,
            "startDate": start_date,
            "endDate": end_date,
        }
        return self._client.request_paginated("GET", BASE_PATH, params=params)

    def list_auto_paginate(self, **kwargs: Any) -> Iterator[TransactionDto]:
        """Iterate over all transactions across all pages."""
        return paginate(self.list, params=kwargs)

    def get(self, tx_hash: str) -> TransactionDto:
        """Get a transaction by its blockchain hash.

        Args:
            tx_hash: The blockchain transaction hash.

        Returns:
            The transaction object.
        """
        return self._client.request("GET", f"{BASE_PATH}/{tx_hash}")


class AsyncTransactionsResource:
    """Asynchronous transactions resource."""

    def __init__(self, client: AsyncHttpClient) -> None:
        self._client = client

    async def list(
        self,
        *,
        page: int = 1,
        size: int = 10,
        search: Optional[str] = None,
        status: Optional[str] = None,
        chain: Optional[str] = None,
        asset: Optional[str] = None,
        session_reference: Optional[str] = None,
        customer_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> PaginatedResponse:
        """List transactions with pagination (async)."""
        params: Dict[str, Any] = {
            "page": page,
            "size": size,
            "search": search,
            "status": status,
            "chain": chain,
            "asset": asset,
            "sessionReference": session_reference,
            "customerId": customer_id,
            "startDate": start_date,
            "endDate": end_date,
        }
        return await self._client.request_paginated("GET", BASE_PATH, params=params)

    def list_auto_paginate(self, **kwargs: Any) -> AsyncIterator[TransactionDto]:
        """Iterate over all transactions across all pages (async)."""
        return async_paginate(self.list, params=kwargs)

    async def get(self, tx_hash: str) -> TransactionDto:
        """Get a transaction by its blockchain hash (async)."""
        return await self._client.request("GET", f"{BASE_PATH}/{tx_hash}")
