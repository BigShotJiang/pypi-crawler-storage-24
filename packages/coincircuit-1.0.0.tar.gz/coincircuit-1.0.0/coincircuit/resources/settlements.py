"""Settlements resource."""

from typing import Any, AsyncIterator, Dict, Iterator, Optional

from ..client import AsyncHttpClient, HttpClient
from ..pagination import PaginatedResponse, async_paginate, paginate
from ..types import SettlementResponseDto

BASE_PATH = "/api/v1/settlements"


class SettlementsResource:
    """Synchronous settlements resource.

    Wraps endpoints under ``/api/v1/settlements``.
    """

    def __init__(self, client: HttpClient) -> None:
        self._client = client

    def list(
        self,
        *,
        page: int = 1,
        size: int = 10,
        entity: Optional[str] = None,
        currency: Optional[str] = None,
    ) -> PaginatedResponse:
        """List settlements with pagination.

        Args:
            page: Page number (1-based).
            size: Items per page.
            entity: Filter by entity type ("session" or "invoice"). Optional.
            currency: Filter by settlement currency. Optional.

        Returns:
            A PaginatedResponse containing SettlementResponseDto items.
        """
        params: Dict[str, Any] = {
            "page": page,
            "size": size,
            "entity": entity,
            "currency": currency,
        }
        return self._client.request_paginated("GET", BASE_PATH, params=params)

    def list_auto_paginate(self, **kwargs: Any) -> Iterator[SettlementResponseDto]:
        """Iterate over all settlements across all pages."""
        return paginate(self.list, params=kwargs)

    def get(
        self,
        reference: str,
        *,
        entity: Optional[str] = None,
    ) -> SettlementResponseDto:
        """Get a settlement by reference.

        Args:
            reference: The session or invoice reference.
            entity: Entity type ("session" or "invoice"). Optional.

        Returns:
            The settlement object.
        """
        params: Dict[str, Any] = {
            "entity": entity,
        }
        return self._client.request(
            "GET",
            f"{BASE_PATH}/{reference}",
            params=params,
        )


class AsyncSettlementsResource:
    """Asynchronous settlements resource."""

    def __init__(self, client: AsyncHttpClient) -> None:
        self._client = client

    async def list(
        self,
        *,
        page: int = 1,
        size: int = 10,
        entity: Optional[str] = None,
        currency: Optional[str] = None,
    ) -> PaginatedResponse:
        """List settlements with pagination (async)."""
        params: Dict[str, Any] = {
            "page": page,
            "size": size,
            "entity": entity,
            "currency": currency,
        }
        return await self._client.request_paginated("GET", BASE_PATH, params=params)

    def list_auto_paginate(self, **kwargs: Any) -> AsyncIterator[SettlementResponseDto]:
        """Iterate over all settlements across all pages (async)."""
        return async_paginate(self.list, params=kwargs)

    async def get(
        self,
        reference: str,
        *,
        entity: Optional[str] = None,
    ) -> SettlementResponseDto:
        """Get a settlement by reference (async)."""
        params: Dict[str, Any] = {
            "entity": entity,
        }
        return await self._client.request(
            "GET",
            f"{BASE_PATH}/{reference}",
            params=params,
        )
