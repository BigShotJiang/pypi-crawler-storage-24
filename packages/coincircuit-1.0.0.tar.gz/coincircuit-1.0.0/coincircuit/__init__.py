"""CoinCircuit Python SDK.

Usage (synchronous)::

    from coincircuit import CoinCircuit

    cc = CoinCircuit(api_key="sk_live_...")
    session = cc.payments.create(
        title="Order #123",
        description="Widget purchase",
        amount="10.00",
        currency="USD",
        customer={"email": "buyer@example.com"},
        asset="USDC",
        chain="base",
    )

Usage (asynchronous)::

    from coincircuit import AsyncCoinCircuit

    async_cc = AsyncCoinCircuit(api_key="sk_live_...")
    session = await async_cc.payments.create(...)
"""

from .client import AsyncHttpClient, HttpClient
from .errors import CoinCircuitApiError, CoinCircuitAuthError, CoinCircuitError
from .pagination import PaginatedResponse
from .resources.balance import AsyncBalanceResource, BalanceResource
from .resources.blockchain import AsyncBlockchainResource, BlockchainResource
from .resources.customers import AsyncCustomersResource, CustomersResource
from .resources.invoices import AsyncInvoicesResource, InvoicesResource
from .resources.payments import AsyncPaymentsResource, PaymentsResource
from .resources.payouts import AsyncPayoutsResource, PayoutsResource
from .resources.rates import AsyncRatesResource, RatesResource
from .resources.refunds import AsyncRefundsResource, RefundsResource
from .resources.settlements import AsyncSettlementsResource, SettlementsResource
from .resources.transactions import AsyncTransactionsResource, TransactionsResource
from .resources.x402 import AsyncX402Resource, X402Resource
from .resources.payment_pages import AsyncPaymentPagesResource, PaymentPagesResource
from .resources.bank_accounts import AsyncBankAccountsResource, BankAccountsResource
from .resources.crypto_addresses import AsyncCryptoAddressesResource, CryptoAddressesResource

__version__ = "1.0.0"

__all__ = [
    # Main clients
    "CoinCircuit",
    "AsyncCoinCircuit",
    # Errors
    "CoinCircuitError",
    "CoinCircuitApiError",
    "CoinCircuitAuthError",
    # Pagination
    "PaginatedResponse",
    # Version
    "__version__",
]


class CoinCircuit:
    """Synchronous CoinCircuit API client.

    Provides access to all CoinCircuit API resources through
    namespace attributes (e.g. ``cc.payments``, ``cc.invoices``).

    Args:
        api_key: Your CoinCircuit API key (e.g. "sk_live_...").
        base_url: API base URL. Defaults to https://api.coincircuit.io.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Max retry attempts for transient errors. Defaults to 2.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.coincircuit.io",
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._client = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        # Resource namespaces
        self.payments = PaymentsResource(self._client)
        self.x402 = X402Resource(self._client)
        self.invoices = InvoicesResource(self._client)
        self.transactions = TransactionsResource(self._client)
        self.payouts = PayoutsResource(self._client)
        self.balance = BalanceResource(self._client)
        self.blockchain = BlockchainResource(self._client)
        self.customers = CustomersResource(self._client)
        self.refunds = RefundsResource(self._client)
        self.settlements = SettlementsResource(self._client)
        self.rates = RatesResource(self._client)
        self.payment_pages = PaymentPagesResource(self._client)
        self.bank_accounts = BankAccountsResource(self._client)
        self.crypto_addresses = CryptoAddressesResource(self._client)

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._client.close()

    def __enter__(self) -> "CoinCircuit":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncCoinCircuit:
    """Asynchronous CoinCircuit API client.

    Provides the same resource namespaces as ``CoinCircuit`` but all
    methods are coroutines.

    Args:
        api_key: Your CoinCircuit API key (e.g. "sk_live_...").
        base_url: API base URL. Defaults to https://api.coincircuit.io.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Max retry attempts for transient errors. Defaults to 2.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.coincircuit.io",
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._client = AsyncHttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        # Resource namespaces
        self.payments = AsyncPaymentsResource(self._client)
        self.x402 = AsyncX402Resource(self._client)
        self.invoices = AsyncInvoicesResource(self._client)
        self.transactions = AsyncTransactionsResource(self._client)
        self.payouts = AsyncPayoutsResource(self._client)
        self.balance = AsyncBalanceResource(self._client)
        self.blockchain = AsyncBlockchainResource(self._client)
        self.customers = AsyncCustomersResource(self._client)
        self.refunds = AsyncRefundsResource(self._client)
        self.settlements = AsyncSettlementsResource(self._client)
        self.rates = AsyncRatesResource(self._client)
        self.payment_pages = AsyncPaymentPagesResource(self._client)
        self.bank_accounts = AsyncBankAccountsResource(self._client)
        self.crypto_addresses = AsyncCryptoAddressesResource(self._client)

    async def close(self) -> None:
        """Close the underlying async HTTP client and release resources."""
        await self._client.close()

    async def __aenter__(self) -> "AsyncCoinCircuit":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
