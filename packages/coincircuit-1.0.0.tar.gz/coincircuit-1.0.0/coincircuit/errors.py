"""CoinCircuit SDK error classes."""

from typing import Any, Dict, Optional


class CoinCircuitError(Exception):
    """Base error for all CoinCircuit SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)


class CoinCircuitApiError(CoinCircuitError):
    """Raised when the CoinCircuit API returns a non-success response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        body: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.status_code = status_code
        self.body = body or {}
        super().__init__(message)

    def __str__(self) -> str:
        return f"CoinCircuitApiError({self.status_code}): {self.message}"

    def __repr__(self) -> str:
        return (
            f"CoinCircuitApiError(message={self.message!r}, "
            f"status_code={self.status_code!r})"
        )


class CoinCircuitAuthError(CoinCircuitApiError):
    """Raised when the API returns 401 Unauthorized or 403 Forbidden."""

    def __str__(self) -> str:
        return f"CoinCircuitAuthError({self.status_code}): {self.message}"

    def __repr__(self) -> str:
        return (
            f"CoinCircuitAuthError(message={self.message!r}, "
            f"status_code={self.status_code!r})"
        )
