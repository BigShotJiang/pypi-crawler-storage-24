/*
 * MIT License
 *
 * Copyright (c) 2025 Andy Park <andypark.purdue@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <nanobind/eigen/dense.h>
#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>
#include <nanobind/stl/vector.h>

#include <embodik/ik_baseline.hpp>
#include <embodik/types.hpp>
#include <pinocchio/spatial/se3.hpp>

namespace nb = nanobind;
namespace eik = embodik;

// Forward declarations for sub-module bindings
void bind_robot_model(nb::module_ &m);
void bind_tasks(nb::module_ &m);
void bind_kinematics_solver(nb::module_ &m);
void bind_pose_metrics(nb::module_ &m);

NB_MODULE(_embodik_impl, m) {
  m.doc() = "embodiK: High-performance inverse kinematics with Pinocchio";
  using nb::literals::operator""_a;

  // Enums
  nb::enum_<eik::SolverStatus>(m, "SolverStatus",
                               "Status codes for embodiK baseline")
      .value("SUCCESS", eik::SolverStatus::kSuccess)
      .value("INVALID_INPUT", eik::SolverStatus::kInvalidInput)
      .value("NUMERICAL_ERROR", eik::SolverStatus::kNumericalError)
      .value("SHAPE_MISMATCH", eik::SolverStatus::kShapeMismatch)
      .value("EMPTY_PROBLEM", eik::SolverStatus::kEmptyProblem)
      .value("CONSTRAINT_BOUNDS_MISMATCH",
             eik::SolverStatus::kConstraintBoundsMismatch)
      .value("NON_FINITE_INPUT", eik::SolverStatus::kNonFiniteInput)
      .value("INFEASIBLE", eik::SolverStatus::kInfeasible);

  // Types
  nb::class_<eik::BasicSolverConfig>(m, "BasicSolverConfig",
                                     "Basic configuration for solver")
      .def(nb::init<>())
      .def_rw("epsilon", &eik::BasicSolverConfig::epsilon)
      .def_rw("iteration_limit", &eik::BasicSolverConfig::iteration_limit)
      .def_rw("regularization", &eik::BasicSolverConfig::regularization);

  // (Intentionally do not bind VelocitySolverConfig/RegularizedInverseConfig
  // yet to avoid import-time issues.)

  nb::class_<eik::JointConfiguration>(m, "JointConfiguration",
                                      "Joint positions container")
      .def(nb::init<>())
      .def_rw("positions", &eik::JointConfiguration::positions);

  nb::class_<eik::SolverResult>(m, "SolverResult", "Result from IK solve step")
      .def_ro("solution", &eik::SolverResult::solution)
      .def_ro("status", &eik::SolverResult::status)
      .def_ro("computation_time_ms", &eik::SolverResult::computation_time_ms)
      .def_ro("iterations", &eik::SolverResult::iterations)
      .def_ro("final_error", &eik::SolverResult::final_error)
      .def_ro("task_scales", &eik::SolverResult::task_scales)
      .def_ro("task_errors", &eik::SolverResult::task_errors)
      .def_ro("task_modes_effective", &eik::SolverResult::task_modes_effective)
      .def_ro("task_used_fallback", &eik::SolverResult::task_used_fallback)
      .def_ro("status_message", &eik::SolverResult::status_message);

  nb::class_<eik::VelocitySolverResult, eik::SolverResult>(
      m, "VelocitySolverResult", "Extended result for velocity-level solving")
      .def_ro("saturated_joints", &eik::VelocitySolverResult::saturated_joints)
      .def_ro("limits_applied", &eik::VelocitySolverResult::limits_applied)
      .def_prop_ro(
          "joint_velocities",
          [](const eik::VelocitySolverResult &r) { return r.joint_velocities; })
      .def_ro("pinocchio_kinematics_time_ms",
              &eik::VelocitySolverResult::pinocchio_kinematics_time_ms,
              "Time spent in Pinocchio forward kinematics (ms)")
      .def_ro("collision_constraint_time_ms",
              &eik::VelocitySolverResult::collision_constraint_time_ms,
              "Time spent evaluating collision distances/constraints (ms)")
      .def_ro("task_update_time_ms",
              &eik::VelocitySolverResult::task_update_time_ms,
              "Time spent updating tasks (Jacobian computation) (ms)")
      .def_ro("solver_computation_time_ms",
              &eik::VelocitySolverResult::solver_computation_time_ms,
              "Time spent in core solver computation (ms)")
      .def_ro("constraint_setup_time_ms",
              &eik::VelocitySolverResult::constraint_setup_time_ms,
              "Time spent setting up constraint matrices (ms)");

  nb::class_<eik::PositionIKOptions>(m, "PositionIKOptions",
                                     "Options for position-level IK solving")
      .def(nb::init<>())
      .def_rw("position_tolerance", &eik::PositionIKOptions::position_tolerance)
      .def_rw("orientation_tolerance",
              &eik::PositionIKOptions::orientation_tolerance)
      .def_rw("max_iterations", &eik::PositionIKOptions::max_iterations)
      .def_rw("dt", &eik::PositionIKOptions::dt)
      .def_rw("stagnation_tolerance",
              &eik::PositionIKOptions::stagnation_tolerance,
              "Minimum improvement required per iteration to avoid early "
              "termination")
      .def_rw("stagnation_iterations",
              &eik::PositionIKOptions::stagnation_iterations,
              "Number of consecutive stagnant iterations before aborting")
      .def_prop_rw(
          "nullspace_bias",
          [](const eik::PositionIKOptions &opt) -> nb::object {
            if (opt.nullspace_bias.has_value()) {
              return nb::cast(opt.nullspace_bias.value());
            }
            return nb::none();
          },
          [](eik::PositionIKOptions &opt, nb::object obj) {
            if (!obj.is_none()) {
              opt.nullspace_bias = nb::cast<Eigen::VectorXd>(obj);
            } else {
              opt.nullspace_bias.reset();
            }
          },
          "Target configuration for nullspace control (optional)")
      .def_rw("nullspace_gain", &eik::PositionIKOptions::nullspace_gain,
              "Nullspace task gain/weight")
      .def_rw(
          "nullspace_active_joints",
          &eik::PositionIKOptions::nullspace_active_joints,
          "List of joint indices for nullspace control (empty = all joints)")
      .def_rw("excluded_joint_indices",
              &eik::PositionIKOptions::excluded_joint_indices,
              "Nv-indices excluded from the temporary frame and nullspace "
              "posture tasks in solve_position (same convention as "
              "Task.set_excluded_joint_indices and "
              "PositionStepOptions.excluded_joint_indices)")
      .def_rw("max_linear_step", &eik::PositionIKOptions::max_linear_step,
              "Maximum linear step per iteration (meters)")
      .def_rw("max_angular_step", &eik::PositionIKOptions::max_angular_step,
              "Maximum angular step per iteration (radians)")
      .def_rw("position_gain", &eik::PositionIKOptions::position_gain,
              "Linear error gain used by position IK")
      .def_rw("orientation_gain", &eik::PositionIKOptions::orientation_gain,
              "Angular error gain used by position IK")
      .def_rw("primary_solve_mode", &eik::PositionIKOptions::primary_solve_mode,
              "Primary end-effector solve mode used by position IK")
      .def_rw("primary_allow_min_error_fallback",
              &eik::PositionIKOptions::primary_allow_min_error_fallback,
              "Allow SCALE primary task to fall back to MIN_ERROR in position IK");

  nb::class_<eik::PositionStepOptions>(
      m, "PositionStepOptions",
      "Options for solve_position_step(): gains, timestep, and optional joint "
      "controls. Field names match PositionIKOptions where applicable "
      "(excluded_joint_indices uses the same nv convention as "
      "PositionIKOptions and Task.set_excluded_joint_indices).")
      .def(nb::init<>())
      .def_rw("position_gain", &eik::PositionStepOptions::position_gain,
              "Multiplier on the linear pose error (default 1.0)")
      .def_rw("orientation_gain", &eik::PositionStepOptions::orientation_gain,
              "Multiplier on the angular pose error (default 1.0)")
      .def_rw("max_steps", &eik::PositionStepOptions::max_steps,
              "Number of velocity-IK iterations per call (default 1)")
      .def_rw("dt", &eik::PositionStepOptions::dt,
              "Integration timestep per step; <=0 uses solver.dt (default -1)")
      .def_rw("max_linear_speed", &eik::PositionStepOptions::max_linear_speed,
              "Maximum linear speed magnitude in solve_position_step (m/s); <=0 means unlimited")
      .def_rw("max_angular_speed", &eik::PositionStepOptions::max_angular_speed,
              "Maximum angular speed magnitude in solve_position_step (rad/s); <=0 means unlimited")
      .def_rw("excluded_joint_indices",
              &eik::PositionStepOptions::excluded_joint_indices,
              "Same role as PositionIKOptions.excluded_joint_indices: merged "
              "into exclusions on the driven pose task(s) and all PostureTasks "
              "for each inner solve_velocity (restored after the step).")
      .def_rw("locked_joint_indices",
              &eik::PositionStepOptions::locked_joint_indices,
              "Nv-indices forced to v=0 inside the velocity QP (bounds + "
              "zeroed Jacobian columns). Preferred for consistent diagnostics. "
              "Out-of-range → InvalidInput.")
      .def_rw("integration_zero_velocity_indices",
              &eik::PositionStepOptions::integration_zero_velocity_indices,
              "Nv-indices zeroed on joint_velocities after each inner "
              "solve_velocity and before integrate (legacy post-QP mask). "
              "Out-of-range → InvalidInput.");

  nb::class_<eik::TaskTarget>(
      m, "TaskTarget",
      "Per-task target and gains for multi-task solve_position_step()")
      .def(nb::init<>())
      .def(nb::init<const std::string &, const Eigen::Matrix4d &, double, double>(),
           nb::arg("task_name"), nb::arg("target_pose"),
           nb::arg("position_gain") = 1.0, nb::arg("orientation_gain") = 1.0)
      .def_static(
          "from_se3",
          [](const std::string &task_name, const pinocchio::SE3 &target_pose,
             double position_gain, double orientation_gain) {
            eik::TaskTarget t;
            t.task_name = task_name;
            t.target_pose = target_pose.toHomogeneousMatrix();
            t.position_gain = position_gain;
            t.orientation_gain = orientation_gain;
            return t;
          },
          nb::arg("task_name"), nb::arg("target_pose"),
          nb::arg("position_gain") = 1.0, nb::arg("orientation_gain") = 1.0)
      .def_rw("task_name", &eik::TaskTarget::task_name)
      .def_rw("target_pose", &eik::TaskTarget::target_pose)
      .def_rw("position_gain", &eik::TaskTarget::position_gain)
      .def_rw("orientation_gain", &eik::TaskTarget::orientation_gain);

  nb::class_<eik::PositionIKResult, eik::VelocitySolverResult>(
      m, "PositionIKResult", "Result from position-level IK solving")
      .def_ro("q_solution", &eik::PositionIKResult::q_solution)
      .def_prop_ro(
          "achieved_pose",
          [](const eik::PositionIKResult &r) { return r.achieved_pose; })
      .def_ro("position_error", &eik::PositionIKResult::position_error)
      .def_ro("orientation_error", &eik::PositionIKResult::orientation_error)
      .def_ro("iterations_used", &eik::PositionIKResult::iterations_used)
      .def_ro("position_error_trace",
              &eik::PositionIKResult::position_error_trace)
      .def_ro("orientation_error_trace",
              &eik::PositionIKResult::orientation_error_trace);

  m.def("pose_error_norm", &eik::calculateConfigurationDistance, "current"_a,
        "target"_a,
        R"pbdoc(
          Compute L2 norm between two pose vectors.
          Returns inf for invalid inputs.
          )pbdoc");

  // No additional velocity IK bindings defined

  // Eigen-first overloads (preferred)
  m.def(
      "computeMultiObjectiveVelocitySolutionEigen",
      [](const std::vector<Eigen::VectorXd> &goals,
         const std::vector<Eigen::MatrixXd> &jacobians,
         const Eigen::MatrixXd &C, const Eigen::VectorXd &lower_limits,
         const Eigen::VectorXd &upper_limits, double solver_tolerance,
         double solver_tight_tolerance, unsigned int max_iters,
         double norm_threshold, unsigned int max_zero_scale_iters,
         double sr_tolerance, double sr_damping) {
        eik::VelocitySolverConfig p;
        p.epsilon = solver_tolerance;
        p.precision_threshold = solver_tight_tolerance;
        p.iteration_limit = max_iters;
        p.magnitude_limit = norm_threshold;
        p.stall_detection_count = max_zero_scale_iters;
        p.regularization_config.epsilon = sr_tolerance;
        p.regularization_config.regularization_factor = sr_damping;
        return eik::computeMultiObjectiveVelocitySolutionEigen(
            goals, jacobians, C, lower_limits, upper_limits, p);
      },
      "goals"_a, "jacobians"_a, "C"_a, "lower_limits"_a, "upper_limits"_a,
      "solver_tolerance"_a = 1e-6, "solver_tight_tolerance"_a = 1e-10,
      "max_iters"_a = 20, "norm_threshold"_a = 1e10,
      "max_zero_scale_iters"_a = 2, "sr_tolerance"_a = 1e-6,
      "sr_damping"_a = 1e-1,
      R"pbdoc(
          Full multi-task velocity IK using Eigen types. Preferred API.
          )pbdoc");

  // Module metadata
  m.attr("__version__") = "0.2.0";
  m.attr("DEFAULT_REGULARIZATION") = eik::BasicSolverConfig{}.regularization;

  // Bind robot model with Pinocchio integration
  bind_robot_model(m);

  // Bind task framework
  bind_tasks(m);

  // Bind high-level kinematics solver
  bind_kinematics_solver(m);

  // Bind pose metrics free functions
  bind_pose_metrics(m);
}
