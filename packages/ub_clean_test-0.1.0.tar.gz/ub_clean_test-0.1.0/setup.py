from setuptools import setup, find_packages

setup(
    name="ub-clean-test",
    version="0.1.0",
    author="pengyeqin",
    description="测试包",
    packages=find_packages(),
)