from setuptools import setup, find_packages

setup(
    name="ToGos",
    version="1.1.8",
    author="Kerem",
    description="ToGos paketi",
    long_description="Detayli aciklama",
    long_description_content_type="text/plain",
    
    # Kodun klasörsüz direkt ana dizindeyse bunu kullan:
    py_modules=['main'], 
    
    # Eğer kodun bir klasörün içindeyse bunu aktif et:
    # packages=find_packages(), 
    
    install_requires=[],
    
    entry_points={
        'console_scripts': [
            'togos-calistir=main:main',
        ],
    },
)