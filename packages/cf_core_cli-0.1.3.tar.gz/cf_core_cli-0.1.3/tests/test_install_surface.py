from __future__ import annotations

from importlib import metadata
from pathlib import Path
import subprocess
import sys

import cf_cli


def _cf_script_path() -> Path:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    for scripts_dir in candidate_dirs:
        for candidate in ("cf.exe", "cf.cmd", "cf-script.py", "cf"):
            path = scripts_dir / candidate
            if path.is_file():
                return path
    raise FileNotFoundError(
        f"cf console script not found near interpreter {Path(sys.executable).resolve()}"
    )


def test_distribution_metadata_matches_module_version() -> None:
    assert metadata.version("cf-core-cli") == cf_cli.__version__


def test_installed_cf_console_script_help_surface() -> None:
    result = subprocess.run(
        [str(_cf_script_path()), "--help"],
        check=False,
        capture_output=True,
        text=True,
    )

    combined_output = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined_output
    assert "Cogniflow unified CLI" in combined_output
