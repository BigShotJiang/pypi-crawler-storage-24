from __future__ import annotations

import argparse
import importlib
import sys

from . import registry


DEFAULT_MODULES = [
    "cf_ontology.cf_cli",
    "cf_web.cli",
    "cf_pipeline_cert.cli",
    "cf_pipeline_report.cli",
    "cf_pipeline_report.cli_plugin",
    "cf_opcua_server.cli",
]


def _load_modules() -> None:
    for module_name in DEFAULT_MODULES:
        try:
            importlib.import_module(module_name)
        except Exception:
            continue


def build_parser() -> argparse.ArgumentParser:
    _load_modules()
    parser = argparse.ArgumentParser(prog="cf", description="Cogniflow unified CLI")
    root_subparsers = parser.add_subparsers(dest="group", required=True)

    for group in registry.iter_groups():
        group_parser = root_subparsers.add_parser(
            group.name,
            help=group.help or f"{group.name} commands",
        )
        group_subparsers = group_parser.add_subparsers(dest=f"{group.name}_cmd", required=True)
        for cmd in group.commands:
            cmd.add_parser(group_subparsers)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    handler = getattr(args, "_cf_handler", None)
    if not handler:
        parser.print_help()
        return 2
    try:
        return int(handler(args))
    except SystemExit as exc:
        return int(exc.code or 0)
    except Exception as exc:
        print(f"CLI error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
