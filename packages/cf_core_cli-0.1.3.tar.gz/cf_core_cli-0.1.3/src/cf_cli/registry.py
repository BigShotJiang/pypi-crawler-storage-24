from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional
import argparse


@dataclass
class CommandSpec:
    name: str
    add_parser: Callable[[argparse._SubParsersAction], argparse.ArgumentParser]
    help: Optional[str] = None


@dataclass
class GroupSpec:
    name: str
    help: Optional[str] = None
    commands: List[CommandSpec] = field(default_factory=list)


_GROUPS: Dict[str, GroupSpec] = {}


def register_command(
    group: str,
    name: str,
    add_parser: Callable[[argparse._SubParsersAction], argparse.ArgumentParser],
    *,
    group_help: Optional[str] = None,
    command_help: Optional[str] = None,
) -> None:
    group_spec = _GROUPS.get(group)
    if group_spec is None:
        group_spec = GroupSpec(name=group, help=group_help)
        _GROUPS[group] = group_spec
    elif group_help and not group_spec.help:
        group_spec.help = group_help
    group_spec.commands.append(CommandSpec(name=name, add_parser=add_parser, help=command_help))


def iter_groups() -> Iterable[GroupSpec]:
    return _GROUPS.values()
