"""CLI package for OPIE."""
