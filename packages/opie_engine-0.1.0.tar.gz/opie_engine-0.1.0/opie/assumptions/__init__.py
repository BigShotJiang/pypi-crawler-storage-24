"""Assumption models and loaders."""
