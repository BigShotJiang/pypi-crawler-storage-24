"""FastAPI application for OPIE."""
