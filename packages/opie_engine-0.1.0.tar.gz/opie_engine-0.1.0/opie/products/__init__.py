"""Product hook implementations."""
