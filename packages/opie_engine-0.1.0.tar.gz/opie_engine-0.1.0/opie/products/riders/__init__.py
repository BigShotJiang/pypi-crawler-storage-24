"""Rider hooks and registry."""
