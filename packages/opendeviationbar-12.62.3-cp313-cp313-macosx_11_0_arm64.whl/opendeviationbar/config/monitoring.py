"""Monitoring configuration for notifications and gap-backfill checks.

Issue #110: Unified configuration via pydantic-settings.

All values load from environment variables (OPENDEVIATIONBAR_ prefix) with automatic
overlay: CLI > env > TOML > defaults via pydantic-settings.
"""

from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MonitoringConfig(BaseSettings):
    """Configuration for monitoring, notifications, and gap-backfill checks.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_TELEGRAM_TOKEN : str | None
        Telegram bot token (default: None)
    OPENDEVIATIONBAR_TELEGRAM_CHAT_ID : str
        Telegram chat ID (default: "")
    OPENDEVIATIONBAR_GAP_FRESH_THRESHOLD_MIN : int
        Minutes before data is considered stale (default: 30)
    OPENDEVIATIONBAR_GAP_STALE_THRESHOLD_MIN : int
        Minutes before data is considered stale (default: 120)
    OPENDEVIATIONBAR_GAP_CRITICAL_THRESHOLD_MIN : int
        Minutes before data is critical (default: 1440)
    OPENDEVIATIONBAR_ENV : str
        Environment name (default: "development")
    OPENDEVIATIONBAR_GIT_SHA : str
        Git commit SHA (default: "unknown")
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_",
        case_sensitive=False,
    )

    telegram_token: str | None = None
    telegram_chat_id: str = ""
    gap_fresh_threshold_min: int = Field(
        30,
        validation_alias=AliasChoices(
            "OPENDEVIATIONBAR_GAP_FRESH_THRESHOLD_MIN",
            "OPENDEVIATIONBAR_RECENCY_FRESH_THRESHOLD_MIN",
        ),
    )
    gap_stale_threshold_min: int = Field(
        120,
        validation_alias=AliasChoices(
            "OPENDEVIATIONBAR_GAP_STALE_THRESHOLD_MIN",
            "OPENDEVIATIONBAR_RECENCY_STALE_THRESHOLD_MIN",
        ),
    )
    gap_critical_threshold_min: int = Field(
        1440,
        validation_alias=AliasChoices(
            "OPENDEVIATIONBAR_GAP_CRITICAL_THRESHOLD_MIN",
            "OPENDEVIATIONBAR_RECENCY_CRITICAL_THRESHOLD_MIN",
        ),
    )
    # Env var is OPENDEVIATIONBAR_ENV, not OPENDEVIATIONBAR_ENVIRONMENT (historical)
    environment: str = Field(
        "development",
        validation_alias=AliasChoices(
            "OPENDEVIATIONBAR_ENV", "OPENDEVIATIONBAR_ENVIRONMENT"
        ),
    )
    git_sha: str = "unknown"
