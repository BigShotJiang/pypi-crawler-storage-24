"""主对话与子 Agent 的「无用户输入」定时唤醒文案（TUI 心跳 / 子任务协调）。"""

from __future__ import annotations

# 与 TUI 侧识别一致：勿改前缀，否则 _chat_pump_loop 无法标记系统行
MAIN_IDLE_PULSE_PREFIX = "（Aicd·主对话·定时心跳）"
MAIN_LIFECYCLE_WAKEUP_PREFIX = "（Aicd·主对话·子任务终态）"

# TUI / Tk GUI 在注入接续回合前写入聊天的同一行提示
MAIN_LIFECYCLE_UI_LOG_LINE = (
    "[系统] 顶层子任务已结束，主对话接续处理主收件箱…"
)


def is_main_idle_pulse(user_text: str) -> bool:
    return user_text.lstrip().startswith(MAIN_IDLE_PULSE_PREFIX)


def is_main_lifecycle_wakeup(user_text: str) -> bool:
    return user_text.lstrip().startswith(MAIN_LIFECYCLE_WAKEUP_PREFIX)


def main_idle_pulse_user_text() -> str:
    return (
        MAIN_IDLE_PULSE_PREFIX
        + " 当前无新的真人输入。请先 **task_main_inbox**（或依赖运行时已注入的【主收件箱】）与 **task_session_children_digest** "
        "查看本会话顶层子任务是否有 **lifecycle** 完成/失败/取消或其它上行消息；再用 **task_list**、**task_result**、**task_thread_stats** "
        "核对 **running** / **failed** / **pending** 与 **timeline** / **sub_agent_trace**。"
        "若有失败、长期停滞或需要用户决策，用中文在聊天区**简短**说明并视情况 **task_cancel** 或对仍运行的子任务 **task_message_send**（**directive** / **question**）。"
        "检查周期由 **`agent.idleHeartbeatSec`**（TUI **`/agent heartbeat <秒>`**）或 **`agent_settings_update`** 自主设置。"
        "若一切正常、无需打扰用户，可只回复：**·**（中间点）。"
    )


def main_lifecycle_wakeup_user_text() -> str:
    """顶层 task_ai/task_shell 结束后由 TUI 注入，驱动主对话读主收件箱并接续。"""
    return (
        MAIN_LIFECYCLE_WAKEUP_PREFIX
        + " 刚有**顶层**后台任务结束，**lifecycle** 已写入主会话收件箱。"
        " 运行时会自动注入 **【主收件箱】**；请结合 **task_list** / **task_result** / **task_session_children_digest** "
        "确认是否仍有 **running** 任务，并按用户既定目标**接续**编写/汇总/收尾。"
        " 若已全部完成且无需新动作，可只回复 **·**。"
    )


def sub_agent_idle_pulse_user_text() -> str:
    return (
        "（Aicd·子 Agent·定时心跳）收件箱暂无新 **task_message**，但你仍有 **running** 或 **pending** 的子任务（**task_list** 里 **parent_id** 等于你当前 **task_id** 的行）。"
        "请用 **task_result** 查看子任务；需要上级同步时，先 **task_result**（**task_id**=你自己）读 **parent_id**：若非空则 **task_message_send** 的 **to_task_id**=该 **parent_id**，**kind** 用 **status** / **question** / **alert**；"
        "若为顶层子任务（**parent_id** 为空），主对话会通过定时心跳、子任务终态注入与用户输入查看 **task_list**，你应继续用 **task_progress** 保持可见。"
        "失败子任务可考虑 **task_cancel** 或拆成更小的 **task_ai**。无事可回复 **·**。"
    )
