"""HOME 目录下可热加载的插件：manifest、加载器、注册表、备份。"""

from __future__ import annotations

from aicd.plugins.registry import PluginRegistry

__all__ = ["PluginRegistry"]
