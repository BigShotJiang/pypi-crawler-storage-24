"""Slash 命令补全候选。"""

from __future__ import annotations

from aicd.ui.slash_suggester import pick_slash_completion


def test_pick_slash_minimal_extension() -> None:
    assert pick_slash_completion("/") == "/?"
    assert pick_slash_completion("/t") == "/task "
    assert pick_slash_completion("/task") == "/task "
    assert pick_slash_completion("/task ") == "/task stop"
    assert pick_slash_completion("/hi") == "/history "


def test_pick_non_slash() -> None:
    assert pick_slash_completion("hello") is None


def test_pick_case_insensitive() -> None:
    assert pick_slash_completion("/TASK") == "/task "


def test_pick_chat_completion() -> None:
    assert pick_slash_completion("/chat") == "/chat "
    assert pick_slash_completion("/chat ") == "/chat stop"
