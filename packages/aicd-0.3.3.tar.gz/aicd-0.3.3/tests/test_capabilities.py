from __future__ import annotations

from aicd.capabilities import (
    CAPABILITIES_SCHEMA,
    build_capabilities_payload,
    format_capabilities_prompt_chunk,
)
from aicd.invocation import InvocationContext


def test_capabilities_v2_has_merged_tools_and_self_model() -> None:
    inv = InvocationContext(0, "user", None, None, None, "")
    p = build_capabilities_payload(
        plugin_registry=None,
        invocation=inv,
        plugins_boot_loaded=False,
    )
    assert p["schema"] == CAPABILITIES_SCHEMA == "aicd.capabilities.v2"
    assert "openai_tools_merged" in p
    assert isinstance(p["openai_tools_merged"], list)
    assert len(p["openai_tools_merged"]) == p["tools"]["merged_count"]
    assert p["tools"]["core_only_count"] <= p["tools"]["merged_count"]
    assert "self_model_for_ai_and_plugins" in p
    sm = p["self_model_for_ai_and_plugins"]
    assert "runtime_role" in sm
    assert "plugin_naming" in sm
    assert "host_ipc" in p
    methods = [m.get("method") for m in p["host_ipc"]["methods"]]
    assert "main_chat" in methods
    assert "main_chat_workspace" in methods
    assert "main_chat_workspace_batch" in methods
    assert "main_chat_session_attach" in methods
    assert "main_inbox_continue" in methods
    assert "workspace_set" in methods
    assert "http_serve" in p
    chunk = format_capabilities_prompt_chunk(p)
    assert "capability self-model" in chunk.lower()
    assert "openai_tools_merged" in chunk
