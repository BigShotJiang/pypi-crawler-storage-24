"""主会话 attach：切换 SQLite session_id 并 hydrate。"""

from __future__ import annotations

import asyncio
import uuid


def test_attach_chat_session_id_rehydrates(tmp_path) -> None:
    from aicd.runtime import build_runtime

    async def _go() -> None:
        ctx = await build_runtime(home=tmp_path / "h", skip_first_setup=True)
        try:
            sid_a = ctx.router._chat_session_id
            assert sid_a
            other = str(uuid.uuid4())
            await ctx.store.append_chat_message(
                ctx.conn, session_id=sid_a, role="user", content="in_a"
            )
            await ctx.store.append_chat_message(
                ctx.conn, session_id=other, role="user", content="in_b"
            )
            await ctx.agent.attach_chat_session_id(other)
            assert ctx.agent._session_id == other
            assert ctx.router._chat_session_id == other
            texts = [
                m.get("content") for m in ctx.agent._messages if m.get("role") == "user"
            ]
            assert "in_b" in texts
            assert "in_a" not in texts
        finally:
            await ctx.shutdown_graceful()

    asyncio.run(_go())
