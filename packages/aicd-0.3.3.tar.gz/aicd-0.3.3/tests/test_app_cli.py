"""CLI 行为烟测（不启动 TUI / 不调 LLM）。"""

from typer.testing import CliRunner

from aicd.app import app


def test_tui_noui_requires_ai() -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["tui", "--noui"])
    assert r.exit_code == 2
    assert "--ai" in (r.stdout or "") + (r.stderr or "")


def test_root_noui_requires_ai() -> None:
    """顶层 aicd --noui 与 aicd tui --noui 相同校验。"""
    runner = CliRunner()
    r = runner.invoke(app, ["--noui"])
    assert r.exit_code == 2
    assert "--ai" in (r.stdout or "") + (r.stderr or "")


def test_help_lists_root_ai_shortcut() -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["--help"])
    assert r.exit_code == 0
    out = (r.stdout or "") + (r.stderr or "")
    assert "--ai" in out
    assert "aicd tui --ai" in out or "tui --ai" in out


def test_noui_and_console_mutually_exclusive() -> None:
    runner = CliRunner()
    for args in (
        ["tui", "--noui", "--console", "--ai", "x"],
        ["--noui", "--console", "--ai", "x"],
    ):
        r = runner.invoke(app, args)
        assert r.exit_code == 2
        out = (r.stdout or "") + (r.stderr or "")
        assert "不能同时" in out


def test_gui_help() -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["gui", "--help"])
    assert r.exit_code == 0
    out = (r.stdout or "") + (r.stderr or "")
    assert "gui" in out.lower() or "Tk" in out


def test_chat_once_help() -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["chat-once", "--help"])
    assert r.exit_code == 0
    out = (r.stdout or "") + (r.stderr or "")
    assert "--work" in out
    assert "--output-json" in out


def test_chat_once_message_xor_file() -> None:
    runner = CliRunner()
    r = runner.invoke(
        app,
        ["chat-once", "--work", ".", "--message", "a", "--message-file", "nope"],
    )
    assert r.exit_code == 2


def test_gui_mutually_exclusive_with_console_and_noui() -> None:
    runner = CliRunner()
    for args in (
        ["--gui", "--console"],
        ["--gui", "--noui", "--ai", "x"],
    ):
        r = runner.invoke(app, args)
        assert r.exit_code == 2
        assert "不能同时" in ((r.stdout or "") + (r.stderr or ""))
