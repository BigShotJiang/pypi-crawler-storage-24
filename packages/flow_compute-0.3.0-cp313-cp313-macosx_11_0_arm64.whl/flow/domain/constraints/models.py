"""Constraint models for GPU cluster selection.

Defines user-facing constraints (what you need) and provider-side capabilities
(what clusters offer). Both are immutable value objects used by the constraint
solver to filter and rank candidates.

Capabilities use nullable fields to distinguish "unknown" (None) from "verified
absent" (empty/zero). The solver handles unknowns explicitly: fail-closed for
safety-critical constraints (compliance, topology), pessimistic defaults for
performance constraints (startup, bandwidth).
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Any

from pydantic import Field, field_validator

from flow.domain.ir.base import FrozenModel


class Topology(enum.Enum):
    """GPU network topology preference.

    CONTIGUOUS: all GPUs under same switch fabric (InfiniBand/NVSwitch).
        Equivalent to SLURM --switches=1 or Ray STRICT_PACK.
    SPREAD: distribute across fault domains for resilience.
    ANY: no topology preference (default).
    """

    CONTIGUOUS = "contiguous"
    SPREAD = "spread"
    ANY = "any"


class Constraints(FrozenModel):
    """User-facing constraints for cluster selection.

    Constraints are additive: each non-None field narrows the candidate set.
    When all fields are at defaults, every cluster passes (backward-compatible).

    Examples:
        >>> Constraints(topology="contiguous", regions=["eu-*"])
        >>> Constraints(max_startup_minutes=5.0, min_reliability=0.99)
    """

    topology: Topology = Field(
        default=Topology.ANY,
        description="GPU network topology requirement.",
    )
    regions: list[str] | None = Field(
        default=None,
        description="Glob patterns for allowed regions, e.g. ['eu-*'].",
    )
    exclude_regions: list[str] | None = Field(
        default=None,
        description="Glob patterns for excluded regions.",
    )
    compliance: list[str] | None = Field(
        default=None,
        description="Required compliance certifications, e.g. ['gdpr', 'soc2']. All must match.",
    )
    min_interconnect_gbps: float | None = Field(
        default=None,
        gt=0,
        description="Minimum inter-node interconnect bandwidth in Gbps.",
    )
    min_egress_gbps: float | None = Field(
        default=None,
        gt=0,
        description="Minimum egress bandwidth in Gbps.",
    )
    min_ingress_gbps: float | None = Field(
        default=None,
        gt=0,
        description="Minimum ingress bandwidth in Gbps.",
    )
    max_startup_minutes: float | None = Field(
        default=None,
        gt=0,
        description="Maximum acceptable startup latency (p50) in minutes.",
    )
    min_reliability: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Minimum uptime score (0.0-1.0).",
    )
    max_price_per_hour: float | None = Field(
        default=None,
        gt=0,
        description="Maximum hourly price ceiling in USD.",
    )

    @field_validator("topology", mode="before")
    @classmethod
    def _coerce_topology(cls, v: Any) -> Topology:
        if isinstance(v, str):
            return Topology(v.lower())
        return v

    @field_validator("regions", "exclude_regions", mode="before")
    @classmethod
    def _normalize_regions(cls, v: Any) -> list[str] | None:
        if v is None:
            return None
        return [r.lower() for r in v]

    @field_validator("compliance", mode="before")
    @classmethod
    def _normalize_compliance(cls, v: Any) -> list[str] | None:
        if v is None:
            return None
        return [c.lower() for c in v]


@dataclass(frozen=True, slots=True)
class ClusterCapabilities:
    """Provider-side metadata describing what a cluster offers.

    Nullable fields distinguish "unknown" from "verified absent":
      - compliance_certifications=None  -> compliance status unknown
      - compliance_certifications=frozenset()  -> verified: no certifications
      - topology=None  -> topology unknown
      - topology="contiguous"  -> verified contiguous

    The constraint solver uses this distinction to fail closed on safety-critical
    unknowns and apply pessimistic scoring on performance unknowns.
    """

    # Always known (from auction API)
    cluster_id: str
    region: str
    gpu_type: str
    gpu_count: int
    price_per_hour: float
    available_quantity: int = 0
    instance_type_id: str | None = None
    auction_id: str | None = None

    # Known from API when available, None when unknown
    internode_interconnect: str | None = None
    intranode_interconnect: str | None = None

    # Capabilities metadata -- None means unknown, not absent
    interconnect_bandwidth_gbps: float | None = None
    topology: str | None = None  # "contiguous", "distributed", or None (unknown)
    startup_latency_p50_minutes: float | None = None
    reliability_score: float | None = None  # 0.0-1.0, or None (unmeasured)
    egress_gbps: float | None = None
    ingress_gbps: float | None = None
    compliance_certifications: frozenset[str] | None = None  # None = unknown


@dataclass(frozen=True, slots=True)
class ScoredCandidate:
    """A cluster candidate with composite score and breakdown.

    Score is in [0, 1] where higher is better.
    """

    candidate: ClusterCapabilities
    score: float
    price_score: float = 0.0
    capacity_score: float = 0.0
    startup_score: float = 0.0
    reliability_score: float = 0.0
    region_preference_score: float = 0.0
