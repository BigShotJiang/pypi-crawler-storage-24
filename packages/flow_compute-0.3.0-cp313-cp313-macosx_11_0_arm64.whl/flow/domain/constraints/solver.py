"""Constraint solver for GPU cluster selection.

Pure domain logic: filters candidates by hard constraints, then scores
survivors with a fixed-weight composite score. No I/O, no side effects.

Uncertainty handling:
  - Safety-critical constraints (compliance, topology): fail closed when
    capability is unknown (None). A cluster that can't prove GDPR compliance
    is rejected, not silently passed.
  - Performance constraints (startup, bandwidth, reliability): reject when
    capability is unknown and the constraint is set. We don't guess.
  - Scoring: unknown capabilities get pessimistic defaults (score 0.0).

Scoring weights (v1, not user-tunable):
    - Price:       50%  (cheaper is better)
    - Capacity:    20%  (more available GPUs is better)
    - Startup:     15%  (faster startup is better)
    - Reliability: 10%  (higher uptime is better)
    - Region pref:  5%  (preferred region bonus)
"""

from __future__ import annotations

import fnmatch

from flow.domain.constraints.models import (
    ClusterCapabilities,
    Constraints,
    ScoredCandidate,
    Topology,
)

# Scoring weights
_W_PRICE = 0.50
_W_CAPACITY = 0.20
_W_STARTUP = 0.15
_W_RELIABILITY = 0.10
_W_REGION_PREF = 0.05

# Normalization constants
_PRICE_CEILING = 50.0  # $50/h maps to score 0.0
_CAPACITY_CEILING = 64  # 64+ GPUs maps to score 1.0
_STARTUP_CEILING = 30.0  # 30+ minutes maps to score 0.0


class ConstraintSolver:
    """Filter and rank cluster candidates against user constraints.

    Usage:
        results = ConstraintSolver.select(constraints, candidates, preferred_region="us-east-1")
        best = results[0].candidate  # highest-scored survivor
    """

    @staticmethod
    def select(
        constraints: Constraints,
        candidates: list[ClusterCapabilities],
        preferred_region: str | None = None,
    ) -> list[ScoredCandidate]:
        """Filter candidates by hard constraints, then score and rank survivors.

        Args:
            constraints: User-specified requirements.
            candidates: Available cluster capabilities from the provider.
            preferred_region: Optional region preference for scoring bonus.

        Returns:
            Scored candidates sorted by composite score (descending),
            then price (ascending) as tiebreaker. Empty list if all
            candidates are filtered out.
        """
        survivors = [c for c in candidates if _passes_all_filters(constraints, c)]

        scored = [_score_candidate(c, preferred_region) for c in survivors]

        scored.sort(key=lambda s: (-s.score, s.candidate.price_per_hour))
        return scored


def _passes_all_filters(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    """Return True if the candidate passes every hard constraint."""
    return (
        _check_topology(constraints, cap)
        and _check_regions(constraints, cap)
        and _check_exclude_regions(constraints, cap)
        and _check_compliance(constraints, cap)
        and _check_interconnect(constraints, cap)
        and _check_egress(constraints, cap)
        and _check_ingress(constraints, cap)
        and _check_startup(constraints, cap)
        and _check_reliability(constraints, cap)
        and _check_price(constraints, cap)
    )


# ==================== Safety-critical filters (fail closed on unknown) ====================


def _check_topology(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    """Fail closed: unknown topology rejects when contiguous/spread required."""
    if constraints.topology == Topology.ANY:
        return True
    if cap.topology is None:
        return False  # Unknown topology cannot satisfy a specific requirement
    return cap.topology == constraints.topology.value


def _check_compliance(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    """Fail closed: unknown compliance rejects when certifications required."""
    if not constraints.compliance:
        return True
    if cap.compliance_certifications is None:
        return False  # Unknown compliance cannot satisfy certification requirements
    required = set(constraints.compliance)
    return required.issubset(cap.compliance_certifications)


# ==================== Region filters (always known) ====================


def _check_regions(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if not constraints.regions:
        return True
    region_lower = cap.region.lower()
    return any(fnmatch.fnmatch(region_lower, pattern) for pattern in constraints.regions)


def _check_exclude_regions(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if not constraints.exclude_regions:
        return True
    region_lower = cap.region.lower()
    return not any(
        fnmatch.fnmatch(region_lower, pattern) for pattern in constraints.exclude_regions
    )


# ==================== Performance filters (reject on unknown when constrained) ====================


def _check_interconnect(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if constraints.min_interconnect_gbps is None:
        return True
    if cap.interconnect_bandwidth_gbps is None:
        return False  # Can't verify bandwidth requirement
    return cap.interconnect_bandwidth_gbps >= constraints.min_interconnect_gbps


def _check_egress(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if constraints.min_egress_gbps is None:
        return True
    if cap.egress_gbps is None:
        return False
    return cap.egress_gbps >= constraints.min_egress_gbps


def _check_ingress(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if constraints.min_ingress_gbps is None:
        return True
    if cap.ingress_gbps is None:
        return False
    return cap.ingress_gbps >= constraints.min_ingress_gbps


def _check_startup(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if constraints.max_startup_minutes is None:
        return True
    if cap.startup_latency_p50_minutes is None:
        return False  # Can't verify startup latency
    return cap.startup_latency_p50_minutes <= constraints.max_startup_minutes


def _check_reliability(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    if constraints.min_reliability is None:
        return True
    if cap.reliability_score is None:
        return False  # Can't verify reliability
    return cap.reliability_score >= constraints.min_reliability


def _check_price(constraints: Constraints, cap: ClusterCapabilities) -> bool:
    """Price is always known from the auction API."""
    if constraints.max_price_per_hour is None:
        return True
    return cap.price_per_hour <= constraints.max_price_per_hour


# ==================== Scoring (pessimistic on unknown) ====================


def _score_candidate(
    cap: ClusterCapabilities,
    preferred_region: str | None,
) -> ScoredCandidate:
    """Compute composite score for a candidate that passed all filters.

    Unknown capabilities score 0.0 (pessimistic). This naturally ranks
    clusters with verified metadata higher than those without.
    """
    price_score = max(0.0, 1.0 - cap.price_per_hour / _PRICE_CEILING)
    capacity_score = (
        min(1.0, cap.available_quantity / _CAPACITY_CEILING) if cap.available_quantity else 0.0
    )

    # Pessimistic: unknown startup = worst score
    if cap.startup_latency_p50_minutes is not None:
        startup_score = max(0.0, 1.0 - cap.startup_latency_p50_minutes / _STARTUP_CEILING)
    else:
        startup_score = 0.0

    # Pessimistic: unknown reliability = worst score
    reliability = cap.reliability_score if cap.reliability_score is not None else 0.0

    region_pref = _region_preference_score(cap.region, preferred_region)

    composite = (
        _W_PRICE * price_score
        + _W_CAPACITY * capacity_score
        + _W_STARTUP * startup_score
        + _W_RELIABILITY * reliability
        + _W_REGION_PREF * region_pref
    )

    return ScoredCandidate(
        candidate=cap,
        score=composite,
        price_score=price_score,
        capacity_score=capacity_score,
        startup_score=startup_score,
        reliability_score=reliability,
        region_preference_score=region_pref,
    )


def _region_preference_score(region: str, preferred: str | None) -> float:
    """Score region preference: 1.0 if exact match, 0.5 if no preference, 0.0 otherwise."""
    if preferred is None:
        return 0.5
    if region.lower() == preferred.lower():
        return 1.0
    return 0.0
