"""Constraint-based cluster selection for GPU workloads.

Provides a two-layer system:
  - ``Constraints``: user-facing requirements (topology, regions, compliance, etc.)
  - ``ClusterCapabilities``: provider-side metadata (bandwidth, latency, reliability)
  - ``ConstraintSolver``: pure domain logic connecting the two layers

Usage:
    from flow.domain.constraints import Constraints, ConstraintSolver

    constraints = Constraints(topology="contiguous", regions=["eu-*"])
    results = ConstraintSolver.select(constraints, candidates)
"""

from flow.domain.constraints.models import (
    ClusterCapabilities,
    Constraints,
    ScoredCandidate,
    Topology,
)
from flow.domain.constraints.solver import ConstraintSolver

__all__ = [
    "ClusterCapabilities",
    "ConstraintSolver",
    "Constraints",
    "ScoredCandidate",
    "Topology",
]
