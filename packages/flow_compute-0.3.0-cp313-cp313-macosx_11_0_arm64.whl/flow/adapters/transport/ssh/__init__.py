"""SSH transport (stable facade).

Re-exports core SSH primitives and transport-specific tunnel utilities.
"""

from __future__ import annotations

from flow.core.ssh import (
    SSHConnectionInfo,
    build_ssh_command,
    find_fallback_private_key,
    has_ssh_banner,
    is_endpoint_responsive,
    is_ssh_ready,
    ssh_command_string,
    tcp_port_open,
    wait_for_ssh_ready,
)

from .client import (
    ExponentialBackoffSSHWaiter,
    ISSHWaiter,
)
from .tunnel import (
    SSHTunnel,
    SSHTunnelManager,
)


class SshStack:
    """Backward-compat namespace. Prefer importing from flow.core.ssh directly."""

    build_ssh_command = staticmethod(build_ssh_command)
    tcp_port_open = staticmethod(tcp_port_open)
    has_ssh_banner = staticmethod(has_ssh_banner)
    is_ssh_ready = staticmethod(is_ssh_ready)
    is_endpoint_responsive = staticmethod(is_endpoint_responsive)
    find_fallback_private_key = staticmethod(find_fallback_private_key)


__all__ = [
    "ExponentialBackoffSSHWaiter",
    "ISSHWaiter",
    "SSHConnectionInfo",
    "SSHTunnel",
    "SSHTunnelManager",
    "SshStack",
    "build_ssh_command",
    "find_fallback_private_key",
    "has_ssh_banner",
    "is_endpoint_responsive",
    "is_ssh_ready",
    "ssh_command_string",
    "tcp_port_open",
    "wait_for_ssh_ready",
]
