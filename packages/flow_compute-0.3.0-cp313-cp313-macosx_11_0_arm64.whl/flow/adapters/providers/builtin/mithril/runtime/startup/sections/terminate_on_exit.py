"""Terminate-on-exit lifecycle section.

Monitors the main workload and cancels the task via the Mithril API when it
exits. Supports both Docker containers (via `docker wait`) and host-mode
processes (via PID file monitoring).
"""

from __future__ import annotations

import textwrap

from flow.adapters.providers.builtin.mithril.runtime.startup.sections.base import (
    ScriptContext,
    ScriptSection,
)
from flow.adapters.providers.builtin.mithril.runtime.startup.sections.cancel_helpers import (
    build_cancel_script,
    build_runtime_config,
)
from flow.adapters.providers.builtin.mithril.runtime.startup.utils import (
    ensure_curl_available,
)
from flow.utils.paths import HOST_PID_FILE


class TerminateOnExitSection(ScriptSection):
    @property
    def name(self) -> str:
        return "terminate_on_exit"

    @property
    def priority(self) -> int:
        return 88

    def should_include(self, context: ScriptContext) -> bool:
        return context.terminate_on_exit

    def generate(self, context: ScriptContext) -> str:
        if not self.should_include(context):
            return ""

        config_block = self._build_config_block(context)
        cancel_script = build_cancel_script()
        ensure_curl = ensure_curl_available()

        if context.docker_image:
            watcher_script = self._docker_watcher_script()
            after_dep = "After=network-online.target docker.service"
        else:
            watcher_script = self._host_watcher_script()
            after_dep = "After=network-online.target"

        return textwrap.dedent(
            f"""
            # Terminate-on-exit: cancel task when main workload exits
            mkdir -p /var/log/flow
            {config_block}
            {ensure_curl}
            # Install cancel helper if missing (shared with runtime monitor)
            if [ ! -x /usr/local/bin/flow-runtime-cancel.sh ]; then
              cat > /usr/local/bin/flow-runtime-cancel.sh << 'CANCEL_EOF'
{cancel_script}
CANCEL_EOF
              chmod +x /usr/local/bin/flow-runtime-cancel.sh
            fi
            # Install watcher service
            cat > /usr/local/sbin/flow-terminate-on-exit.sh <<'WATCH_EOF'
{watcher_script}
WATCH_EOF
            chmod +x /usr/local/sbin/flow-terminate-on-exit.sh

            cat > /etc/systemd/system/flow-terminate-on-exit.service <<SERVICE_EOF
[Unit]
Description=Flow Terminate On Exit
{after_dep}
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/sbin/flow-terminate-on-exit.sh
Restart=no

[Install]
WantedBy=multi-user.target
SERVICE_EOF
            if command -v systemctl >/dev/null 2>&1; then
              systemctl daemon-reload
              systemctl enable flow-terminate-on-exit.service
              systemctl restart flow-terminate-on-exit.service || systemctl start flow-terminate-on-exit.service
            else
              nohup /usr/local/sbin/flow-terminate-on-exit.sh >/var/log/flow/terminate-on-exit.log 2>&1 &
            fi
            """
        ).strip()

    def _docker_watcher_script(self) -> str:
        """Watcher that monitors Docker container exit."""
        return textwrap.dedent("""\
            #!/bin/bash
            set -euo pipefail
            CN="main"
            if ! command -v docker >/dev/null 2>&1; then exit 0; fi
            # Wait until container exists
            for i in $(seq 1 900); do
              if docker ps -a --format '{{.Names}}' | grep -q "^$CN$"; then break; fi
              sleep 1
            done
            # Wait for container exit; then cancel the task
            docker wait "$CN" >/dev/null 2>&1 || true
            /usr/local/bin/flow-runtime-cancel.sh || true""")

    def _host_watcher_script(self) -> str:
        """Watcher that monitors host PID file for process exit."""
        return textwrap.dedent(f"""\
            #!/bin/bash
            set -euo pipefail
            PID_FILE="{HOST_PID_FILE}"
            # Wait until PID file appears
            for i in $(seq 1 900); do
              if [ -f "$PID_FILE" ]; then break; fi
              sleep 1
            done
            if [ ! -f "$PID_FILE" ]; then
              echo "[terminate-on-exit] PID file not found after 900s; exiting"
              exit 0
            fi
            PID=$(cat "$PID_FILE")
            # Wait for process exit
            while kill -0 "$PID" 2>/dev/null; do sleep 2; done
            echo "[terminate-on-exit] Workload PID $PID exited"
            /usr/local/bin/flow-runtime-cancel.sh || true""")

    def _build_config_block(self, context: ScriptContext) -> str:
        """Write runtime config so the cancel helper has credentials."""
        api_key = context.environment.get("MITHRIL_API_KEY", "")
        api_url = context.environment.get("MITHRIL_API_URL", "https://api.mithril.ai")
        project = context.environment.get("MITHRIL_PROJECT", "")

        if not api_key or not project:
            return "# No provider credentials available for terminate_on_exit"

        return build_runtime_config(
            task_name=context.task_name or "unknown",
            api_key=api_key,
            api_url=api_url,
            project=project,
        )


__all__ = ["TerminateOnExitSection"]
