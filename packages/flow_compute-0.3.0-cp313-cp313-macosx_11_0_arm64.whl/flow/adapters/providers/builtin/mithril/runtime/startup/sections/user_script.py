"""User script section for host-mode (non-Docker) execution.

Runs the user command directly on the host VM. Provides:
- Log file routing via tee to /var/log/flow/user-workload.log
- PID file for lifecycle management
- Working directory setup
- User command marker for log parsing
"""

from __future__ import annotations

import base64
import shlex
import textwrap

from flow.adapters.providers.builtin.mithril.runtime.startup.sections.base import (
    ScriptContext,
    ScriptSection,
)
from flow.utils.paths import (
    CONTAINER_USER_COMMAND_MARKER,
    HOST_LOG_DIR,
    HOST_LOG_FILE,
    HOST_PID_FILE,
    WORKSPACE_DIR,
)


class UserScriptSection(ScriptSection):
    @property
    def name(self) -> str:
        return "user_script"

    @property
    def priority(self) -> int:
        return 90

    def should_include(self, context: ScriptContext) -> bool:
        return bool(context.user_script and context.user_script.strip())

    def generate(self, context: ScriptContext) -> str:
        if not context.user_script or not context.user_script.strip():
            return ""

        script_content = context.user_script.strip()
        if not script_content.startswith("#!"):
            script_content = "#!/bin/bash\n" + script_content

        workdir = getattr(context, "working_directory", None) or WORKSPACE_DIR
        safe_workdir = shlex.quote(workdir)

        # Base64-encode the script to avoid heredoc marker injection
        encoded = base64.b64encode(script_content.encode()).decode()

        return textwrap.dedent(f"""\
            # Host execution: run user script directly on the VM
            mkdir -p {HOST_LOG_DIR}
            mkdir -p {safe_workdir}
            chmod 777 {safe_workdir} 2>/dev/null || true

            echo '{encoded}' | base64 -d > /tmp/user_startup.sh
            chmod +x /tmp/user_startup.sh

            echo "{CONTAINER_USER_COMMAND_MARKER}"
            echo "Executing user startup script (host mode)"

            # Run user script with output tee'd to log file for `flow logs` retrieval.
            # The script runs in a subshell so we can capture its PID for lifecycle mgmt.
            cd {safe_workdir}
            /tmp/user_startup.sh > >(tee -a {HOST_LOG_FILE}) 2>&1 &
            FLOW_USER_PID=$!
            echo "$FLOW_USER_PID" > {HOST_PID_FILE}
            echo "User workload started (PID $FLOW_USER_PID)"
            wait "$FLOW_USER_PID"
            FLOW_USER_RC=$?
            echo "[flow] User workload exited with code $FLOW_USER_RC" | tee -a {HOST_LOG_FILE}""")


__all__ = ["UserScriptSection"]
