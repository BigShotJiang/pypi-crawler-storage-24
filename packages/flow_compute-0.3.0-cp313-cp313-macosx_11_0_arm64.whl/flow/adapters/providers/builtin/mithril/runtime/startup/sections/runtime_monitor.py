"""Runtime monitor lifecycle section.

Enforces max_run_time_hours by installing a systemd timer that fires
shortly before the deadline. When triggered, the timer stops the workload
gracefully and cancels the task via the Mithril API.

Supports both Docker containers (docker stop) and host-mode processes
(kill via PID file).
"""

from __future__ import annotations

import shlex
import textwrap

from flow.adapters.providers.builtin.mithril.runtime.startup.sections.base import (
    ScriptContext,
    ScriptSection,
)
from flow.adapters.providers.builtin.mithril.runtime.startup.sections.cancel_helpers import (
    build_cancel_script,
    build_runtime_config,
)
from flow.adapters.providers.builtin.mithril.runtime.startup.utils import (
    ensure_curl_available,
)
from flow.utils.paths import HOST_PID_FILE


class RuntimeMonitorSection(ScriptSection):
    @property
    def name(self) -> str:
        return "runtime_monitor"

    @property
    def priority(self) -> int:
        return 90

    def should_include(self, context: ScriptContext) -> bool:
        return bool(context.max_run_time_hours)

    def generate(self, context: ScriptContext) -> str:
        if not context.max_run_time_hours:
            return ""

        max_runtime_seconds = int(context.max_run_time_hours * 3600)
        api_key = context.environment.get("MITHRIL_API_KEY", "")
        api_url = context.environment.get("MITHRIL_API_URL", "https://api.mithril.ai")
        project = context.environment.get("MITHRIL_PROJECT", "")

        if not api_key or not project:
            return ""

        config_block = self._build_config_block(
            context, api_key, api_url, project, max_runtime_seconds
        )
        cancel_script = build_cancel_script()
        ensure_curl = ensure_curl_available()

        if context.docker_image:
            runtime_limit_script = self._docker_limit_script()
        else:
            runtime_limit_script = self._host_limit_script()

        timer_unit = self._build_timer_unit()
        service_unit = self._build_service_unit()

        return textwrap.dedent(
            f"""
            {config_block}
            {ensure_curl}
            if [ ! -x /usr/local/bin/flow-runtime-cancel.sh ]; then
              cat > /usr/local/bin/flow-runtime-cancel.sh << 'CANCEL_EOF'
{cancel_script}
CANCEL_EOF
              chmod +x /usr/local/bin/flow-runtime-cancel.sh
            fi
            cat > /usr/local/bin/flow-runtime-limit.sh << 'LIMIT_EOF'
{runtime_limit_script}
LIMIT_EOF
            chmod +x /usr/local/bin/flow-runtime-limit.sh
            cat > /etc/systemd/system/flow-runtime-limit.timer << TIMER_EOF
{timer_unit}
TIMER_EOF
            cat > /etc/systemd/system/flow-runtime-limit.service << 'SERVICE_EOF'
{service_unit}
SERVICE_EOF
            if command -v systemctl >/dev/null 2>&1; then
              systemctl daemon-reload
              systemctl enable flow-runtime-limit.timer
              systemctl restart flow-runtime-limit.timer || systemctl start flow-runtime-limit.timer
            else
              echo "[runtime_monitor] systemd not available; using background fallback" >&2
              nohup sh -c "sleep ${{TIMER_SECONDS}}; /usr/local/bin/flow-runtime-limit.sh" >/var/log/flow/runtime-limit-oneshot.log 2>&1 &
            fi
            """
        ).strip()

    def _docker_limit_script(self) -> str:
        """Graceful shutdown for Docker workloads."""
        return textwrap.dedent("""\
            #!/bin/bash
            set -euo pipefail
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] [runtime_limit] Max runtime reached; initiating graceful shutdown"
            docker stop -t 30 main 2>/dev/null || true
            sleep 10
            /usr/local/bin/flow-runtime-cancel.sh || true""")

    def _host_limit_script(self) -> str:
        """Graceful shutdown for host-mode workloads."""
        return textwrap.dedent(f"""\
            #!/bin/bash
            set -euo pipefail
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] [runtime_limit] Max runtime reached; initiating graceful shutdown"
            PID_FILE="{HOST_PID_FILE}"
            if [ -f "$PID_FILE" ]; then
              PID=$(cat "$PID_FILE")
              if kill -0 "$PID" 2>/dev/null; then
                kill -TERM "$PID" 2>/dev/null || true
                # Grace period: wait up to 30s for clean exit
                for i in $(seq 1 30); do
                  kill -0 "$PID" 2>/dev/null || break
                  sleep 1
                done
                # Force kill if still running
                kill -9 "$PID" 2>/dev/null || true
              fi
            fi
            sleep 5
            /usr/local/bin/flow-runtime-cancel.sh || true""")

    def _build_config_block(
        self,
        context: ScriptContext,
        api_key: str,
        api_url: str,
        project: str,
        max_runtime_seconds: int,
    ) -> str:
        """Write runtime config with deadline tracking."""
        safe_hours = shlex.quote(str(context.max_run_time_hours))

        # Reuse shared config writer for credentials
        base_config = build_runtime_config(
            task_name=context.task_name or "unknown",
            api_key=api_key,
            api_url=api_url,
            project=project,
        )

        # Append deadline tracking (runtime monitor specific)
        return textwrap.dedent(
            f"""
            mkdir -p /var/lib/flow /var/log/flow
            {base_config}

            CONFIG_PATH="/var/lib/flow/task-runtime.conf"
            echo "MAX_RUNTIME_HOURS={safe_hours}" >> "$CONFIG_PATH"
            NOW=$(date +%s)
            if ! grep -q '^DEADLINE_EPOCH=' "$CONFIG_PATH" 2>/dev/null; then
              echo "DEADLINE_EPOCH=$((NOW + {max_runtime_seconds}))" >> "$CONFIG_PATH"
            fi
            source "$CONFIG_PATH"
            NOW=$(date +%s)
            REMAINING=$((DEADLINE_EPOCH - NOW))
            if [ "$REMAINING" -le 0 ]; then REMAINING=60; fi
            TIMER_SECONDS=$((REMAINING - 120))
            if [ "$TIMER_SECONDS" -lt 60 ]; then TIMER_SECONDS=60; fi
            """
        ).strip()

    def _build_timer_unit(self) -> str:
        return textwrap.dedent("""\
            [Unit]
            Description=Flow Runtime Limit Timer
            [Timer]
            OnBootSec=${TIMER_SECONDS}s
            AccuracySec=1min
            Persistent=true
            [Install]
            WantedBy=timers.target""")

    def _build_service_unit(self) -> str:
        return textwrap.dedent("""\
            [Unit]
            Description=Flow Runtime Limit Enforcement
            [Service]
            Type=oneshot
            ExecStart=/usr/local/bin/flow-runtime-limit.sh
            Restart=no""")


__all__ = ["RuntimeMonitorSection"]
