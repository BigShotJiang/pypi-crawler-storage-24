"""Adapter between Mithril and domain models.

This module handles all the impedance mismatch between Mithril's API
and our domain models, keeping both layers clean.
"""

import logging

from flow.adapters.providers.builtin.mithril.adapters.storage import MithrilStorageMapper
from flow.adapters.providers.builtin.mithril.domain.models import (
    MithrilBid,
    MithrilInstance,
    MithrilVolume,
)
from flow.sdk.models import Instance, InstanceStatus, Volume

logger = logging.getLogger(__name__)


class MithrilAdapter:
    """Convert between Mithril models and domain models.

    This adapter handles all the messy conversions so that:
    1. The provider can work with Mithril-native models internally
    2. The public API can provide stable domain models
    3. Changes to either side don't affect the other
    """

    # Instance status mapping from Mithril to domain
    INSTANCE_STATUS_MAP = {
        "provisioning": InstanceStatus.PENDING,
        "starting": InstanceStatus.PENDING,
        "running": InstanceStatus.RUNNING,
        "stopping": InstanceStatus.STOPPED,
        "stopped": InstanceStatus.STOPPED,
        "terminating": InstanceStatus.TERMINATED,
        "terminated": InstanceStatus.TERMINATED,
    }

    @classmethod
    def mithril_instance_to_instance(
        cls, mithril_instance: MithrilInstance, bid: MithrilBid
    ) -> Instance:
        """Convert Mithril instance to domain Instance model.

        Args:
            mithril_instance: Mithril instance model
            bid: Parent bid for context (SSH keys, etc.)

        Returns:
            Domain Instance model with connection details
        """
        # Determine SSH host
        ssh_host = mithril_instance.ssh_host or mithril_instance.public_ip

        # Map instance status
        instance_status = cls.INSTANCE_STATUS_MAP.get(
            mithril_instance.status.lower(), InstanceStatus.PENDING
        )

        return Instance(
            instance_id=mithril_instance.fid,
            task_id=bid.fid,
            status=instance_status,
            ssh_host=ssh_host,
            private_ip=mithril_instance.private_ip,
            created_at=mithril_instance.created_at,
            terminated_at=mithril_instance.terminated_at,
        )

    @classmethod
    def mithril_volume_to_volume(cls, mithril_volume: MithrilVolume) -> Volume:
        """Convert Mithril volume to domain Volume model.

        Args:
            mithril_volume: Mithril volume model

        Returns:
            Domain Volume model
        """
        # Determine storage interface from Mithril data
        interface = MithrilStorageMapper.determine_interface(
            mount_path=mithril_volume.mount_path,
            # Prefer explicit disk interface from API if available
            device_type=None,
            volume_type=None,
            mithril_metadata={"disk_interface": getattr(mithril_volume, "disk_interface", None)},
        )

        # Volume model allows extra fields; include bid/reservation relationships when present
        return Volume(
            volume_id=mithril_volume.fid,
            name=mithril_volume.name,
            size_gb=mithril_volume.size_gb,
            region=mithril_volume.region,
            interface=interface,
            created_at=mithril_volume.created_at,
            attached_to=mithril_volume.attached_to,
            bids=getattr(mithril_volume, "bids", []),
            reservations=getattr(mithril_volume, "reservations", []),
            attachments_supported=getattr(mithril_volume, "attachments_supported", None),
        )
