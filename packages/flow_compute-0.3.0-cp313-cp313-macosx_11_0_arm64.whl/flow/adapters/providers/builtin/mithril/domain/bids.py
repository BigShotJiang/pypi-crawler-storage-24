"""Bid submission and selection facade.

Unifies region selection, instance type resolution, and bid submission behind a
single service used by the provider facade.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient
from flow.adapters.providers.builtin.mithril.bidding.builder import BidBuilder
from flow.adapters.providers.builtin.mithril.core.errors import MithrilAPIError
from flow.adapters.providers.builtin.mithril.domain.capabilities import (
    auction_to_capabilities,
)
from flow.adapters.providers.builtin.mithril.domain.catalog import CatalogService, Offering
from flow.adapters.providers.builtin.mithril.domain.pricing import PricingService
from flow.domain.constraints import Constraints, ConstraintSolver, Topology
from flow.errors import FlowError, ResourceNotAvailableError
from flow.protocols.selection import PlacementDecision
from flow.sdk.models import TaskConfig

logger = logging.getLogger(__name__)


class BidsService:
    def __init__(
        self,
        api: MithrilApiClient,
        catalog: CatalogService,
        pricing: PricingService,
        get_project_id: callable,
    ) -> None:
        self._api = api
        self._catalog = catalog
        self._pricing = pricing
        self._get_project_id = get_project_id

    def select_region_and_instance(
        self, config: TaskConfig, instance_type: str
    ) -> PlacementDecision:
        """Select region and instance type from catalog offerings."""
        try:
            candidate_type_ids = self._catalog.candidate_ids(instance_type)
        except (FlowError, AttributeError, TypeError) as exc:
            raise ResourceNotAvailableError(
                f"Unsupported or unknown instance type: {instance_type}",
                suggestions=[
                    "Use 'flow catalog' to list available instance types",
                    "Try a specific size like '8xh100' or '4xa100'",
                ],
            ) from exc

        if not candidate_type_ids:
            raise ResourceNotAvailableError(
                f"Unsupported or unknown instance type: {instance_type}",
                suggestions=[
                    "Use 'flow catalog' to list available instance types",
                    "Try a specific size like '8xh100' or '4xa100'",
                ],
            )

        # Collect offerings across all candidates from the catalog snapshot
        best_offering: dict[str, Offering] = {}
        type_for_region: dict[str, str] = {}
        regions_seen: set[str] = set()
        all_offering_data: list[tuple[str, str, Offering]] = []

        for fid in candidate_type_ids:
            offerings_by_region = self._catalog.offerings_by_region(fid)
            for region, offering in offerings_by_region.items():
                regions_seen.add(region)
                all_offering_data.append((region, fid, offering))

                existing = best_offering.get(region)
                if existing is None or offering.price_per_hour < existing.price_per_hour:
                    best_offering[region] = offering
                    type_for_region[region] = fid

        # Constraint-aware selection when constraints are present
        constraints = getattr(config, "constraints", None)
        if constraints is None:
            constraints = _maybe_synthesize_constraints(config)

        if constraints is not None:
            candidates = [
                auction_to_capabilities(_offering_to_dict(offering), region, fid)
                for region, fid, offering in all_offering_data
            ]
            results = ConstraintSolver.select(
                constraints, candidates, preferred_region=config.region
            )
            if not results:
                regions_checked = sorted(regions_seen)
                raise ResourceNotAvailableError(
                    f"No clusters match constraints for instance type {instance_type}",
                    suggestions=[
                        f"Checked regions: {', '.join(regions_checked) if regions_checked else 'none'}",
                        "Relax constraint requirements (topology, compliance, price)",
                        "Try a different instance type",
                    ],
                )
            best = results[0].candidate
            sel_offering = best_offering.get(best.region)
            return PlacementDecision(
                region=best.region,
                instance_type_fid=best.instance_type_id,
                price_per_hour=sel_offering.price_per_hour if sel_offering else 0.0,
                available_quantity=sel_offering.available_quantity if sel_offering else 0,
                candidate_regions=sorted(regions_seen),
            )

        # Default path: select best region by capacity then price
        selected_region = _select_best_offering_region(best_offering, config.region)
        if not selected_region:
            regions_checked = sorted(regions_seen)
            raise ResourceNotAvailableError(
                f"No available regions for instance type {instance_type}",
                suggestions=[
                    f"Checked regions: {', '.join(regions_checked) if regions_checked else 'none'}",
                    "Try a different instance type",
                    "Increase your max price limit",
                    "Check back later for availability",
                ],
            )

        offering = best_offering[selected_region]
        instance_type_id = type_for_region.get(selected_region, candidate_type_ids[0])
        return PlacementDecision(
            region=selected_region,
            instance_type_fid=instance_type_id,
            price_per_hour=offering.price_per_hour,
            available_quantity=offering.available_quantity,
            candidate_regions=sorted(regions_seen),
        )

    def submit_bid(
        self,
        config: TaskConfig,
        *,
        region: str,
        instance_type_id: str,
        k8s_cluster_id: str | None = None,
        project_id: str | None = None,
        ssh_keys: list[str] | None = None,
        startup_script: str | None = None,
        volume_attachments: list[dict[str, Any]] | None = None,
    ) -> Any:
        bid_spec = BidBuilder.build_specification(
            config=config,
            project_id=project_id or self._get_project_id(),
            region=region,
            instance_type_id=instance_type_id,
            k8s_cluster_id=k8s_cluster_id,
            ssh_keys=ssh_keys or [],
            startup_script=startup_script,
            volume_attachments=volume_attachments or [],
        )
        return self._api.create_bid(bid_spec.to_api_payload())

    @staticmethod
    def extract_bid_id(response: Any) -> str:
        """Extract bid ID from API response."""
        from flow.adapters.providers.builtin.mithril.core.errors import MithrilBidError

        if isinstance(response, dict):
            bid_id = response.get("fid") or response.get("bid_id")
            if not bid_id and isinstance(response.get("bid"), dict):
                bid_id = response["bid"].get("fid") or response["bid"].get("bid_id")
            if bid_id:
                return bid_id
            raise MithrilBidError(f"No bid ID in response: {response}")

        bid_id = str(response)
        if not bid_id:
            raise MithrilBidError(f"Invalid bid response: {response}")
        return bid_id

    # ================= Bid State Transitions =================
    def pause_bid(self, bid_id: str) -> None:
        """Pause a bid (idempotent operation)."""
        try:
            self._api.patch_bid(bid_id, {"paused": True})
            logger.debug(f"Bid {bid_id} pause request succeeded (paused=True)")
        except (MithrilAPIError, OSError, ValueError) as e:
            try:
                self._api.patch_bid(bid_id, {"status": "paused"})
                logger.debug(f"Bid {bid_id} pause request succeeded (status=paused)")
            except (MithrilAPIError, OSError, ValueError) as e2:
                if any(
                    k in str(e).lower() or k in str(e2).lower()
                    for k in ("already paused", "already_paused", "is paused")
                ):
                    logger.debug(f"Bid {bid_id} already paused")
                    return
                raise MithrilAPIError(f"Failed to pause bid: {e2}") from e2

        time.sleep(1.0)

    def unpause_bid(self, bid_id: str) -> None:
        """Unpause a bid (idempotent operation)."""
        try:
            self._api.patch_bid(bid_id, {"paused": False})
            logger.debug(f"Bid {bid_id} unpause request succeeded (paused=False)")
        except (MithrilAPIError, OSError, ValueError) as e:
            try:
                self._api.patch_bid(bid_id, {"status": "running"})
                logger.debug(f"Bid {bid_id} unpause request succeeded (status=running)")
            except (MithrilAPIError, OSError, ValueError) as e2:
                msg = (str(e) + " " + str(e2)).lower()
                if any(k in msg for k in ("not paused", "already running", "is running")):
                    logger.debug(f"Bid {bid_id} already unpaused")
                    return
                raise MithrilAPIError(f"Failed to unpause bid: {e2}") from e2

    def safe_unpause_bid(self, bid_id: str) -> None:
        """Attempt to unpause a bid and swallow errors for best-effort recovery."""
        try:
            self.unpause_bid(bid_id)
        except (MithrilAPIError, OSError, ValueError):
            logger.warning(f"Failed to unpause bid {bid_id} during error recovery")

    def update_bid_volumes(self, bid_id: str, volumes: list[str]) -> None:
        """Update the volumes attached to a bid."""
        try:
            self._api.patch_bid(bid_id, {"launch_specification": {"volumes": volumes}})
        except (MithrilAPIError, OSError, ValueError) as first_err:
            try:
                self._api.patch_bid(bid_id, {"volumes": volumes})
            except (MithrilAPIError, OSError, ValueError):
                raise first_err

    def update_bid_launch_spec(self, bid_id: str, launch_spec: dict[str, Any]) -> None:
        """Update the full launch_specification for a bid."""
        try:
            self._api.patch_bid(bid_id, {"launch_specification": launch_spec})
        except Exception as first_err:
            raise MithrilAPIError(
                f"Failed to update launch_specification: {first_err}"
            ) from first_err


def _select_best_offering_region(
    offerings: dict[str, Offering],
    preferred_region: str | None = None,
) -> str | None:
    """Choose a region given offerings and an optional preferred region.

    Policy: honor preferred region if available, otherwise pick highest
    capacity then lowest price.
    """
    if not offerings:
        return None
    if preferred_region and preferred_region in offerings:
        return preferred_region

    best_region: str | None = None
    best_score: tuple[int, float] = (-1, float("inf"))
    for region, offering in offerings.items():
        capacity = offering.capacity
        price = offering.price_per_hour
        if capacity > best_score[0] or (capacity == best_score[0] and price < best_score[1]):
            best_score = (capacity, price)
            best_region = region
    return best_region


def _offering_to_dict(offering: Offering) -> dict[str, Any]:
    """Convert Offering to dict for auction_to_capabilities compatibility."""
    return {
        "last_instance_price": f"${offering.price_per_hour:.2f}",
        "capacity": offering.capacity,
        "internode_interconnect": offering.internode_interconnect,
        "intranode_interconnect": offering.intranode_interconnect,
    }


# Bandwidth mappings for legacy internode_interconnect strings
_INTERCONNECT_BANDWIDTH: dict[str, float] = {
    "ib_3200": 3200.0,
    "ib_1600": 1600.0,
    "ib_800": 800.0,
    "ib_400": 400.0,
    "ib_200": 200.0,
}


def _maybe_synthesize_constraints(config: TaskConfig) -> Constraints | None:
    """Synthesize Constraints from legacy TaskConfig fields when appropriate."""
    internode = getattr(config, "internode_interconnect", None)
    max_price = getattr(config, "max_price_per_hour", None)

    if not internode and not max_price:
        return None

    kwargs: dict[str, Any] = {}

    if internode:
        lower = internode.lower()
        if "infiniband" in lower or lower.startswith("ib"):
            kwargs["topology"] = Topology.CONTIGUOUS
        bandwidth = _INTERCONNECT_BANDWIDTH.get(lower)
        if bandwidth:
            kwargs["min_interconnect_gbps"] = bandwidth

    if max_price is not None:
        kwargs["max_price_per_hour"] = float(max_price)

    if not kwargs:
        return None

    return Constraints(**kwargs)
