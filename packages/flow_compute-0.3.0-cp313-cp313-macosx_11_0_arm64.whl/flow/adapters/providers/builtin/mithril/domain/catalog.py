"""Unified catalog service for instance types and spot availability."""

from __future__ import annotations

import logging
import re
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

from flow.adapters.providers.builtin.mithril.core.constants import VALID_REGIONS
from flow.domain.parsers.instance_parser import InstanceParser
from flow.errors import FlowError
from flow.protocols.instance_types import InstanceTypeResolverProtocol

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient

logger = logging.getLogger(__name__)

# Seed data for instance type display names. These are used as a bootstrap
# before the API is queried, and as a fallback when the API is unavailable.
# New instance types are discovered dynamically via /v2/instance-types.
SEED_INSTANCE_TYPES: dict[str, str] = {
    "it_RrgkIZz6c9BZu5gi": "a100-80gb.sxm.1x",
    "it_TiAPxzKNi4xO0IAr": "a100-80gb.sxm.2x",
    "it_4TugeYWOov5FllEf": "a100-80gb.sxm.4x",
    "it_Sg1nDx1I8NFep60J": "a100-80gb.sxm.8x",
    "it_5ECSoHQjLBzrp5YM": "h100-80gb.sxm.8x",
    "it_XqgKWbhZ5gznAYsG": "h100-80gb.sxm.8x",
    "it_7RHoQUztab9lU9Ne": "h200.8x",
    "it_q0o0UtmD4bgy36kb": "neb-b200.sxm.8x",
    "it_nFEHySv5IMnHKbKi": "b200-192gb.8x",
    "it_tcjiKnwIK0jX21t3": "b200-192gb.1x",
    "it_WCJ0NkfuADQ7yexV": "b200-192gb.2x",
    "it_OS38SJAdsS1l6QFU": "b200-192gb.4x",
}


@dataclass(frozen=True, slots=True)
class InstanceTypeInfo:
    """Metadata for a single instance type SKU."""

    fid: str
    name: str
    gpu_type: str
    gpu_count: int
    gpu_memory_gb: int
    aliases: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Offering:
    """A live spot market offering for a specific instance type in a region."""

    auction_id: str
    instance_type_fid: str
    region: str
    price_per_hour: float
    capacity: int
    available_quantity: int
    internode_interconnect: str | None = None
    intranode_interconnect: str | None = None


@dataclass(frozen=True, slots=True)
class CatalogSnapshot:
    """Immutable point-in-time snapshot of the instance catalog and market."""

    instance_types: dict[str, InstanceTypeInfo]
    offerings: list[Offering]
    fetched_at: float


class CatalogService(InstanceTypeResolverProtocol):
    """Unified service for instance type resolution and availability queries.

    Makes exactly two API calls per refresh cycle (instance types + availability).
    Thread safety: snapshot is an immutable frozen dataclass swapped atomically.
    """

    def __init__(self, api: MithrilApiClient, *, ttl: float = 300.0) -> None:
        self._api = api
        self._ttl = float(ttl)
        self._regions: tuple[str, ...] = tuple(VALID_REGIONS)
        if not self._regions:
            raise ValueError("CatalogService requires at least one valid region")

        # alias -> instance_fid (unambiguous mappings only)
        self._map: dict[str, str] = {}
        # bare gpu name -> list of (alias_with_count, fid) for ambiguous names
        self._ambiguous: dict[str, list[tuple[str, str]]] = {}
        # instance_fid -> display_name
        self._names: dict[str, str] = dict(SEED_INSTANCE_TYPES)
        # instance_fid -> gpu count
        self._gpu_counts: dict[str, int] = self._bootstrap_gpu_counts(self._names)
        # gpu family -> list of instance_fids
        self._family_ids: dict[str, list[str]] = self._build_family_index(self._names)
        self._snapshot: CatalogSnapshot | None = None
        self._last_refresh: float | None = None

    # ---- InstanceTypeResolverProtocol ----

    def resolve(self, user_spec: str) -> str:
        """Resolve user-friendly spec to a Mithril instance type ID."""
        if not user_spec:
            raise FlowError("Instance type specification is required")

        normalized_spec = user_spec.lower().strip()

        # Direct ID passthrough does not need hydration.
        if normalized_spec.startswith("it_"):
            return user_spec.strip()

        self._ensure_hydrated()

        for key in self._iter_lookup_keys(normalized_spec):
            mapped = self._map.get(key)
            if mapped:
                return mapped

            variants = self._ambiguous.get(key)
            if variants:
                if len(variants) == 1:
                    suggested = variants[0][0]
                    raise FlowError(
                        f'"{user_spec}" requires a count prefix. Use: {suggested}',
                    )
                lines = [f"  - {alias}  ({self._names.get(fid, fid)})" for alias, fid in variants]
                raise FlowError(
                    f'"{user_spec}" is ambiguous. Specify the GPU count:\n' + "\n".join(lines),
                )

        available_display = self._friendly_available_types()
        raise FlowError(
            f"Unknown instance type: {user_spec}",
            suggestions=[
                f"Available: {', '.join(available_display[:8])}",
                "Use 'flow pricing --list' to see all available instance types",
                "Examples: '1xa100', '4xa100', '8xh100'",
            ],
        )

    def resolve_simple(self, spec: str) -> str:
        """Simple exact resolution using the static mapping."""
        normalized = spec.lower().strip()
        if normalized.startswith("it_"):
            return spec.strip()
        self._ensure_hydrated()
        if normalized in self._map:
            return self._map[normalized]
        available = self._friendly_available_types()
        raise ValueError(f"Unknown instance type: {spec}. Available: {', '.join(available)}")

    def candidate_ids(self, user_spec: str) -> list[str]:
        """Return candidate instance type IDs for region fallback.

        Resolves the primary ID, then expands to same-GPU-count family members.
        GPU count is a hard constraint: an 8-GPU request never falls back to 1-GPU.
        """
        primary = self.resolve(user_spec)
        candidates = [primary]
        primary_count = self._gpu_counts.get(primary)

        family = self._detect_family(user_spec)
        if family:
            primary_prefix = self._vendor_prefix(self._names.get(primary, ""), family)
            for alt_id in self._family_ids.get(family, []):
                if alt_id in candidates:
                    continue
                alt_count = self._gpu_counts.get(alt_id)
                if primary_count is None or alt_count is None:
                    continue
                if alt_count != primary_count:
                    continue
                alt_prefix = self._vendor_prefix(self._names.get(alt_id, ""), family)
                if alt_prefix != primary_prefix and primary_prefix != "":
                    continue
                candidates.append(alt_id)

        return candidates

    # ---- Catalog queries ----

    def get_snapshot(self) -> CatalogSnapshot:
        """Return the current catalog snapshot, refreshing if stale."""
        self._ensure_hydrated()
        if self._snapshot is None:
            return CatalogSnapshot(instance_types={}, offerings=[], fetched_at=time.monotonic())
        return self._snapshot

    def offerings_for(self, instance_fid: str) -> list[Offering]:
        """Return all offerings for a specific instance type."""
        snapshot = self.get_snapshot()
        return [o for o in snapshot.offerings if o.instance_type_fid == instance_fid]

    def offerings_by_region(self, instance_fid: str) -> dict[str, Offering]:
        """Return cheapest offering per region for a specific instance type."""
        result: dict[str, Offering] = {}
        for offering in self.offerings_for(instance_fid):
            existing = result.get(offering.region)
            if existing is None or offering.price_per_hour < existing.price_per_hour:
                result[offering.region] = offering
        return result

    def get_display_name(self, instance_fid: str) -> str | None:
        """Return the human-readable display name for an instance type ID."""
        self._ensure_hydrated()
        return self._names.get(instance_fid)

    def get_instance_type_info(self, instance_fid: str) -> InstanceTypeInfo | None:
        """Return rich metadata for an instance type ID.

        Checks the hydrated snapshot first, then builds from seed/name data.
        Returns None if the ID is completely unknown.
        """
        self._ensure_hydrated()

        # Check snapshot (populated after API hydration)
        if self._snapshot and instance_fid in self._snapshot.instance_types:
            return self._snapshot.instance_types[instance_fid]

        # Build from name data (seed dict or previously discovered)
        name = self._names.get(instance_fid)
        if not name:
            return None

        gpu_count = self._gpu_counts.get(instance_fid, 1)
        gpu_type = self._extract_gpu_type(name)
        gpu_memory_gb = self._extract_gpu_memory(name)
        aliases = tuple(sorted(self._derive_aliases(name)))
        return InstanceTypeInfo(
            fid=instance_fid,
            name=name,
            gpu_type=gpu_type,
            gpu_count=gpu_count,
            gpu_memory_gb=gpu_memory_gb,
            aliases=aliases,
        )

    # ---- Internal refresh ----

    def _ensure_hydrated(self) -> None:
        """Hydrate mappings from the API if stale."""
        now = time.monotonic()
        if self._last_refresh is not None and (now - self._last_refresh) < self._ttl:
            return
        self._refresh()

    def _refresh(self) -> CatalogSnapshot:
        """Execute exactly 2 API calls to build a fresh snapshot."""
        # 1. GET /v2/instance-types -> build type map
        self._hydrate_from_instance_types()
        # 2. GET /v2/spot/availability -> build offerings + discover extra types
        offerings = self._hydrate_from_availability()

        instance_types: dict[str, InstanceTypeInfo] = {}
        for fid, name in self._names.items():
            gpu_count = self._gpu_counts.get(fid, 1)
            gpu_type, gpu_memory_gb = self._extract_gpu_info(name)
            aliases = tuple(sorted(self._derive_aliases(name)))
            instance_types[fid] = InstanceTypeInfo(
                fid=fid,
                name=name,
                gpu_type=gpu_type,
                gpu_count=gpu_count,
                gpu_memory_gb=gpu_memory_gb,
                aliases=aliases,
            )

        self._snapshot = CatalogSnapshot(
            instance_types=instance_types,
            offerings=offerings,
            fetched_at=time.monotonic(),
        )
        self._last_refresh = time.monotonic()
        return self._snapshot

    def _hydrate_from_instance_types(self) -> None:
        """Fetch instance types from API to discover SKUs dynamically."""
        response = self._api.list_instance_types({})

        if isinstance(response, dict) and "data" in response:
            instance_types = response["data"]
        elif isinstance(response, list):
            instance_types = response
        else:
            return

        if not isinstance(instance_types, list):
            return

        for item in instance_types:
            fid = item.get("fid")
            name = item.get("name")
            num_gpus = item.get("num_gpus")
            gpu_type = item.get("gpu_type")

            # Handle legacy "gpus" array format
            if not num_gpus or not gpu_type:
                gpus = item.get("gpus")
                if isinstance(gpus, list) and gpus:
                    first_gpu = gpus[0]
                    if isinstance(first_gpu, dict):
                        gpu_type = gpu_type or first_gpu.get("name")
                        num_gpus = num_gpus or first_gpu.get("count")

            if not fid or not name:
                continue

            if isinstance(num_gpus, int) and num_gpus > 0:
                self._gpu_counts[fid] = num_gpus

            display_name = self._qualify_name(name, num_gpus)
            self._names[fid] = display_name
            aliases = self._derive_aliases(display_name)

            bare_gpu: str | None = None
            if num_gpus and gpu_type:
                gpu_lower = gpu_type.lower()
                name_head = display_name.split(".")[0].lower()
                name_head_clean = re.sub(r"-\d+gb$", "", name_head)
                is_vendor_prefixed = name_head_clean != gpu_lower and name_head_clean.endswith(
                    gpu_lower
                )
                canonical = name_head_clean if is_vendor_prefixed else gpu_lower
                count_alias = f"{num_gpus}x{canonical}"
                aliases.add(count_alias)
                bare_gpu = canonical
                aliases.add(bare_gpu)

            family = self._detect_family(name) or self._detect_family(gpu_type)
            if family:
                self._record_family_member(family, fid)

            for alias in sorted(aliases, key=lambda a: (a == bare_gpu, a)):
                if not alias:
                    continue
                is_bare_gpu = alias == bare_gpu
                self._record_alias(alias, fid, is_bare_gpu=is_bare_gpu)

    def _hydrate_from_availability(self) -> list[Offering]:
        """Fetch availability and build Offering list."""
        response = self._api.list_spot_availability({})

        if isinstance(response, dict):
            for key in ("auctions", "data", "availability"):
                if key in response and isinstance(response[key], list):
                    response = response[key]
                    break
            else:
                return []

        if not isinstance(response, Sequence):
            return []

        offerings: list[Offering] = []
        for payload in response:
            if not isinstance(payload, Mapping):
                continue

            instance_fid = payload.get("instance_type")
            if not isinstance(instance_fid, str) or not instance_fid.startswith("it_"):
                continue

            region = payload.get("region")
            if not isinstance(region, str) or not region:
                continue

            display_name = self._names.get(instance_fid) or SEED_INSTANCE_TYPES.get(instance_fid)
            if not display_name:
                continue

            self._names[instance_fid] = display_name

            # Fallback GPU count from display name for FIDs not seen in instance types API.
            if instance_fid not in self._gpu_counts:
                from flow.utils.instance_spec import parse as _parse_spec

                try:
                    spec = _parse_spec(display_name)
                    if spec.gpu_count is not None:
                        self._gpu_counts[instance_fid] = spec.gpu_count
                except Exception:  # noqa: BLE001
                    pass

            family = self._detect_family(display_name)
            if family:
                self._record_family_member(family, instance_fid)

            aliases = self._derive_aliases(display_name)
            for alias in aliases:
                key = alias.lower()
                if not key:
                    continue
                self._record_alias(key, instance_fid, is_bare_gpu=False)

            price_per_hour = _parse_price_str(
                payload.get("last_instance_price") or payload.get("price")
            )

            # The API "capacity" field is already in instance count (server computes
            # sum of resource_gpus // instance_gpus). No further division needed.
            capacity = int(payload.get("capacity") or payload.get("available_gpus") or 0)

            offering = Offering(
                auction_id=(
                    payload.get("fid")
                    or payload.get("id")
                    or payload.get("auction_id")
                    or "auction-unknown"
                ),
                instance_type_fid=instance_fid,
                region=region,
                price_per_hour=price_per_hour,
                capacity=capacity,
                available_quantity=capacity,
                internode_interconnect=payload.get("internode_interconnect"),
                intranode_interconnect=payload.get("intranode_interconnect"),
            )
            offerings.append(offering)

        return offerings

    # ---- Alias management ----

    def _record_alias(self, alias: str, fid: str, *, is_bare_gpu: bool) -> None:
        """Record an alias -> fid mapping.

        Bare GPU names (e.g. "a100") always go to _ambiguous so users must
        specify a count prefix (e.g. "1xa100").
        """
        if is_bare_gpu:
            if alias in self._ambiguous:
                variants = self._ambiguous[alias]
                if not any(v_fid == fid for _, v_fid in variants):
                    count_alias = self._find_count_alias_for_fid(fid)
                    variants.append((count_alias or alias, fid))
                return

            if alias in self._map:
                existing = self._map.pop(alias)
                if existing == fid:
                    count_alias = self._find_count_alias_for_fid(fid)
                    self._ambiguous[alias] = [(count_alias or alias, fid)]
                else:
                    existing_count_alias = self._find_count_alias_for_fid(existing)
                    new_count_alias = self._find_count_alias_for_fid(fid)
                    self._ambiguous[alias] = [
                        (existing_count_alias or alias, existing),
                        (new_count_alias or alias, fid),
                    ]
            else:
                count_alias = self._find_count_alias_for_fid(fid)
                self._ambiguous[alias] = [(count_alias or alias, fid)]
            return

        if alias in self._ambiguous:
            return

        existing = self._map.get(alias)
        if existing == fid:
            return

        self._map[alias] = fid

    def _find_count_alias_for_fid(self, fid: str) -> str | None:
        """Find a count-qualified alias (e.g., '8xh100') that maps to this fid."""
        for alias, mapped_fid in self._map.items():
            if mapped_fid == fid and "x" in alias:
                return alias
        return None

    def _iter_lookup_keys(self, normalized_spec: str) -> list[str]:
        keys = [normalized_spec]
        parsed = self._parse_key(normalized_spec)
        if parsed and parsed not in keys:
            keys.append(parsed)
        return keys

    def _friendly_available_types(self) -> list[str]:
        """Return deduplicated, shortest alias per unique fid."""
        fid_to_shortest: dict[str, str] = {}
        for alias, fid in sorted(self._map.items(), key=lambda x: len(x[0])):
            if fid not in fid_to_shortest:
                fid_to_shortest[fid] = alias
        return sorted(fid_to_shortest.values())

    def _record_family_member(self, family: str, instance_fid: str) -> None:
        members = self._family_ids.setdefault(family, [])
        if instance_fid not in members:
            members.append(instance_fid)

    # ---- Static helpers ----

    @staticmethod
    def _vendor_prefix(display_name: str, family: str) -> str:
        """Extract vendor prefix from a display name relative to a GPU family."""
        head = display_name.split(".")[0].lower()
        idx = head.find(family)
        if idx <= 0:
            return ""
        return head[:idx]

    @staticmethod
    def _parse_key(user_spec: str) -> str:
        """Normalize user spec into a lookup key."""
        s = (user_spec or "").strip().lower()
        if not s:
            return s
        if "." in s and any(tok in s for tok in ("sxm", "pcie")):
            return s
        if "x" in s:
            left, right = s.split("x", 1)
            try:
                _ = int(left)
                return f"{left}x{right}"
            except ValueError:
                return s
        return s

    @staticmethod
    def _derive_aliases(display_name: str) -> set[str]:
        aliases: set[str] = set()
        if not display_name:
            return aliases

        name = display_name.strip()
        if not name:
            return aliases

        lowered = name.lower()
        aliases.add(lowered)

        try:
            components = InstanceParser.parse(lowered)
        except (FlowError, ValueError, TypeError):
            components = None

        if components:
            if components.gpu_count > 1:
                aliases.add(f"{components.gpu_count}x{components.gpu_type}")
            aliases.add(components.gpu_type)

        return {alias for alias in aliases if alias}

    @staticmethod
    def _qualify_name(raw_name: str, num_gpus: int | None) -> str:
        """Ensure an instance type name includes the GPU count."""
        if not num_gpus or num_gpus < 1:
            return raw_name

        from flow.utils.instance_spec import parse as _parse_spec

        try:
            spec = _parse_spec(raw_name)
            if spec.gpu_count is not None and spec.gpu_count == num_gpus:
                return raw_name
        except Exception:  # noqa: BLE001
            pass

        return f"{raw_name}.{num_gpus}x"

    @staticmethod
    def _detect_family(value: str | None) -> str | None:
        if not value:
            return None
        lowered = value.lower()
        for family in ("b200", "h200", "h100", "a100"):
            if family in lowered:
                return family
        return None

    @staticmethod
    def _build_family_index(names: Mapping[str, str]) -> dict[str, list[str]]:
        index: dict[str, list[str]] = {}
        for instance_fid, display_name in names.items():
            family = CatalogService._detect_family(display_name)
            if not family:
                continue
            members = index.setdefault(family, [])
            if instance_fid not in members:
                members.append(instance_fid)
        return index

    @staticmethod
    def _bootstrap_gpu_counts(names: Mapping[str, str]) -> dict[str, int]:
        """Extract GPU counts from seed display names."""
        from flow.utils.instance_spec import parse as _parse_spec

        counts: dict[str, int] = {}
        for fid, display_name in names.items():
            try:
                spec = _parse_spec(display_name)
                if spec.gpu_count is not None:
                    counts[fid] = spec.gpu_count
            except Exception:  # noqa: BLE001
                pass
        return counts

    @staticmethod
    def _extract_gpu_info(display_name: str) -> tuple[str, int]:
        """Extract (gpu_type, memory_gb) from a display name via canonical parser."""
        from flow.domain.parsers.gpu_display import parse_gpu_display

        info = parse_gpu_display(display_name)
        gpu_type = info.model.lower() if info.model else display_name.split(".")[0].lower()
        memory_gb = int(info.memory_label.rstrip("G")) if info.memory_label else 0
        return gpu_type, memory_gb


def _parse_price_str(price_str: str | None) -> float:
    """Parse a price string like '$10.00' to float. Returns 0.0 on failure."""
    if price_str is None:
        return 0.0
    s = str(price_str).strip()
    if s.startswith("$"):
        s = s[1:]
    s = s.replace(",", "")
    try:
        return float(s)
    except (ValueError, TypeError):
        return 0.0
