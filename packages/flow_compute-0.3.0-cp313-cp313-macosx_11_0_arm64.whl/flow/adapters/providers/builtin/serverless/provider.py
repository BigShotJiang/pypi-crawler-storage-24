"""Serverless provider implementing ProviderAdapter for Temporal + K8s backend.

Routes function invocations to Temporal workflows which manage K8s Deployments
with KEDA autoscaling. Implements the same interface as Mithril/Local/Mock
providers so the SDK layer is backend-agnostic.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from flow.adapters.providers.adapter import ProviderAdapter
from flow.adapters.providers.base import ProviderCapabilities
from flow.adapters.providers.builtin.serverless.context import ServerlessContext
from flow.application.config.config import Config
from flow.sdk.image import Image
from flow.sdk.models import (
    AvailableInstance,
    Task,
    TaskConfig,
    TaskStatus,
    Volume,
)

logger = logging.getLogger(__name__)


class ServerlessProvider(ProviderAdapter):
    """Serverless execution backend using Temporal + Kubernetes + KEDA.

    Each .remote() call starts a Temporal FunctionInvocationWorkflow.
    The workflow ensures a K8s Deployment exists, waits for a ready pod,
    then dispatches the serialized function call to the container over HTTP.
    """

    NAME = "serverless"

    def __init__(self, ctx: ServerlessContext) -> None:
        super().__init__(
            name="serverless",
            capabilities=ProviderCapabilities(
                supports_multi_node=False,
                supports_reservations=False,
                supports_spot_instances=False,
                supports_custom_images=True,
                supports_gpu_passthrough=True,
                requires_ssh_keys=False,
            ),
        )
        self._ctx = ctx
        self._tasks: dict[str, Task] = {}
        self._lock = threading.Lock()

    @classmethod
    def from_config(cls, config: Config) -> ServerlessProvider:
        """Create a provider from a Config object.

        This is the factory method used by the provider registry and
        the FlowApp backend selection.
        """
        provider_config: dict[str, Any] = config.provider_config

        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Inside an async context we cannot call run_until_complete.
            # Build a minimal context; Temporal/K8s connect lazily on first use.
            ctx = ServerlessContext(
                config=provider_config,
                temporal_client=None,
                k8s_client=provider_config.get("k8s_client"),
                image_registry=provider_config.get("image_registry", ""),
                namespace=provider_config.get("k8s_namespace", "flow-serverless"),
                project_id=provider_config.get("project_id", "default"),
                task_queue=provider_config.get("task_queue", "flow-serverless"),
            )
        else:
            ctx = asyncio.get_event_loop().run_until_complete(
                ServerlessContext.build(provider_config)
            )
        return cls(ctx)

    # -- Task lifecycle -------------------------------------------------------

    def submit_task(
        self,
        instance_type: str,
        config: TaskConfig,
        volume_ids: list[str] | None = None,
        allow_partial_fulfillment: bool = False,
        chunk_size: int | None = None,
    ) -> Task:
        """Submit a function invocation via Temporal workflow."""
        workflow_id = f"invoke-{config.name}-{uuid4().hex[:8]}"

        task = Task(
            task_id=workflow_id,
            name=config.name,
            status=TaskStatus.PENDING,
            instance_type=instance_type,
            num_instances=1,
            region=self._ctx.namespace,
            cost_per_hour="0.00",
            created_at=datetime.now(tz=timezone.utc),
            config=config,
            provider_metadata={
                "backend": "serverless",
                "workflow_id": workflow_id,
                "task_queue": self._ctx.task_queue,
            },
        )
        with self._lock:
            self._tasks[workflow_id] = task

        # Start Temporal workflow if client is available
        if self._ctx.temporal_client is not None:
            self._start_invocation_workflow(workflow_id, config, instance_type, volume_ids)

        self.log_operation(
            "submit_task",
            workflow_id=workflow_id,
            function=config.name,
            gpu=instance_type,
        )
        return task

    def _start_invocation_workflow(
        self,
        workflow_id: str,
        config: TaskConfig,
        instance_type: str,
        volume_ids: list[str] | None,
    ) -> None:
        """Start a FunctionInvocationWorkflow on Temporal (fire-and-forget)."""
        import asyncio

        from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
            FunctionInvocationInput,
            FunctionInvocationWorkflow,
        )

        input_data = FunctionInvocationInput(
            function_name=config.name,
            image_spec=_serialize_image(config.image),
            instance_type=instance_type,
            args_serialized=config.env.get("_FLOW_ARGS", "").encode(),
            volume_ids=volume_ids or [],
        )

        async def _start() -> None:
            await self._ctx.temporal_client.start_workflow(
                FunctionInvocationWorkflow.run,
                input_data,
                id=workflow_id,
                task_queue=self._ctx.task_queue,
            )

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            self._pending_workflow = loop.create_task(_start())
        else:
            asyncio.get_event_loop().run_until_complete(_start())

    def get_task(self, task_id: str) -> Task:
        """Get task details by workflow ID."""
        with self._lock:
            if task_id in self._tasks:
                return self._tasks[task_id]
        raise KeyError(f"Task not found: {task_id}")

    def get_task_status(self, task_id: str) -> TaskStatus:
        """Get current task status from Temporal."""
        task = self.get_task(task_id)
        return task.status

    def list_tasks(
        self,
        status: str | None = None,
        limit: int = 100,
        force_refresh: bool = False,
    ) -> list[Task]:
        """List tasks with optional status filtering."""
        with self._lock:
            tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status.value == status]
        return tasks[:limit]

    def stop_task(self, task_id: str) -> bool:
        """Stop a running task by cancelling its Temporal workflow."""
        with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id].status = TaskStatus.CANCELLED
                return True
        return False

    def cancel_task(self, task_id: str) -> None:
        """Cancel a task."""
        self.stop_task(task_id)

    def pause_task(self, task_id: str) -> bool:
        """Pause not supported for serverless functions."""
        return False

    def unpause_task(self, task_id: str) -> bool:
        """Unpause not supported for serverless functions."""
        return False

    def get_task_logs(self, task_id: str, tail: int = 100, log_type: str = "stdout") -> str:
        """Get task logs from the container."""
        return ""

    def stream_task_logs(
        self,
        task_id: str,
        log_type: str = "stdout",
        follow: bool = True,
        tail: int = 10,
    ) -> Iterable[str]:
        """Stream task logs (not yet implemented for serverless)."""
        return iter([])

    # -- Instance discovery (not applicable for serverless) -------------------

    def find_instances(
        self, requirements: dict[str, Any], limit: int = 10
    ) -> list[AvailableInstance]:
        """Serverless backend does not expose raw instances."""
        return []

    # -- Volume management (delegated to K8s PVCs) ---------------------------

    def create_volume(
        self,
        size_gb: int,
        name: str | None = None,
        interface: str = "block",
        region: str | None = None,
    ) -> Volume:
        """Create a K8s PersistentVolumeClaim."""
        raise NotImplementedError("Volume management for serverless backend is not yet implemented")

    def delete_volume(self, volume_id: str) -> bool:
        """Delete a K8s PersistentVolumeClaim."""
        raise NotImplementedError("Volume management for serverless backend is not yet implemented")

    def list_volumes(self, limit: int = 100) -> list[Volume]:
        """List K8s PersistentVolumeClaims."""
        return []


def _serialize_image(image: str | Image | None) -> dict[str, str]:
    """Serialize an Image object or string to a dict for workflow input."""
    if image is None:
        return {"kind": "registry", "reference": "python:3.11"}
    if isinstance(image, str):
        return {"kind": "registry", "reference": image}
    # Image object with build steps
    return {
        "kind": "build",
        "base_image": image.base_image or "python:3.11",
        "dockerfile": image.to_dockerfile(),
    }
