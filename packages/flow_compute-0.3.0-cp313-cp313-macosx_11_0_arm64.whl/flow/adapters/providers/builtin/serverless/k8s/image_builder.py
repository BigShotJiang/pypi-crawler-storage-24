"""Container image building from Image specs.

Generates Dockerfiles from Image build steps and delegates actual
builds to kaniko (in-cluster) or buildkit.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def generate_dockerfile(image_spec: dict[str, Any]) -> str:
    """Generate a Dockerfile string from a serialized image spec.

    If the spec contains a pre-built Dockerfile, returns it directly.
    Otherwise, constructs a Dockerfile from the base image and build steps.

    Args:
        image_spec: Serialized Image specification dict.

    Returns:
        Dockerfile contents as a string.
    """
    kind = image_spec.get("kind", "registry")

    if kind == "registry":
        return f"FROM {image_spec['reference']}\n"

    if kind == "build":
        dockerfile = image_spec.get("dockerfile")
        if dockerfile:
            return dockerfile
        # Fallback: just FROM the base image
        base = image_spec.get("base_image", "python:3.11-slim")
        return f"FROM {base}\n"

    return "FROM python:3.11-slim\n"
