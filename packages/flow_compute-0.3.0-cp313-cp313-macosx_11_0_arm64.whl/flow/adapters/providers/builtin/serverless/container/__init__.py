"""Container runtime for serverless function execution.

The runtime module runs inside the user's container and provides an HTTP
server that receives function invocations and returns results.
"""
