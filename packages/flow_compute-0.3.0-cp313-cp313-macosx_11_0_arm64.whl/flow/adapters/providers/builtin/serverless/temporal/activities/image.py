"""Image build and push activities for Temporal workflows.

Build container images from Image specs and push to the configured registry.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
        EnsureImageInput,
    )

try:
    from temporalio import activity
except ImportError:
    activity = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


def _content_hash(image_spec: dict[str, Any]) -> str:
    """Compute a deterministic content hash for an image spec."""
    canonical = json.dumps(image_spec, sort_keys=True)
    return hashlib.sha256(canonical.encode()).hexdigest()[:12]


async def _ensure_image(input: EnsureImageInput) -> str:
    """Build container image from Image spec if not already in registry.

    Returns the full image reference (registry/project/name:hash).

    Steps:
        1. Compute content hash from image spec.
        2. Check if image exists in registry (skip build if so).
        3. Generate Dockerfile from image spec.
        4. Build and push via kaniko or buildkit.

    Args:
        input: Image specification including build steps, registry URL,
            project ID, and function name.

    Returns:
        Full image reference string.
    """
    content_hash = _content_hash(input.image_spec)

    # If the image spec is a pre-built registry image, return it directly
    if input.image_spec.get("kind") == "registry":
        return input.image_spec["reference"]

    # Construct the target image tag
    if input.registry and input.project:
        image_tag = f"{input.registry}/{input.project}/{input.function_name}:{content_hash}"
    else:
        image_tag = f"{input.function_name}:{content_hash}"

    logger.info("Ensuring image exists: %s", image_tag)

    # In production, this would:
    # 1. Check registry for existing image
    # 2. Generate Dockerfile from image_spec
    # 3. Build via kaniko (in-cluster) or buildkit
    # 4. Push to registry
    # For now, return the tag -- actual build logic depends on cluster setup.
    return image_tag


if activity is not None:
    ensure_image = activity.defn(_ensure_image)
else:
    ensure_image = _ensure_image  # type: ignore[assignment]
