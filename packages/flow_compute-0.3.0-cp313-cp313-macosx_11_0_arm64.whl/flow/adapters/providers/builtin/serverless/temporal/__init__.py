"""Temporal integration for the serverless execution backend.

Contains workflow definitions, activity implementations, client factory,
and schedule management.
"""
