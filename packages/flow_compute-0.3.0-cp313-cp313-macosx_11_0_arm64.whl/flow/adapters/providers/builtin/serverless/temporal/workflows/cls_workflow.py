"""ClassMethodWorkflow -- handles @app.cls() lifecycle: enter -> method -> exit.

The container stays warm across the entire lifecycle. Exit methods run
even if the target method fails (finally semantics).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta

try:
    from temporalio import workflow

    with workflow.unsafe.imports_passed_through():
        from flow.adapters.providers.builtin.serverless.temporal.activities.container import (
            ensure_container_ready,
        )
        from flow.adapters.providers.builtin.serverless.temporal.activities.dispatch import (
            dispatch_request,
        )
        from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
            DispatchInput,
            EnsureContainerInput,
        )
except ImportError:
    workflow = None  # type: ignore[assignment]


@dataclass(frozen=True)
class ClassMethodInput:
    """Input to ClassMethodWorkflow.

    Attributes:
        function_name: Class name for deployment lookup.
        image_ref: Container image reference.
        gpu: GPU type.
        enter_methods: Methods to call on container startup (in order).
        target_method: The method being invoked by the user.
        exit_methods: Methods to call on teardown (always, even on failure).
        args_serialized: Serialized (args, kwargs) for target_method.
        timeout_seconds: Max time for target_method execution.
        namespace: K8s namespace.
    """

    function_name: str
    image_ref: str
    gpu: str
    enter_methods: list[str]
    target_method: str
    exit_methods: list[str]
    args_serialized: bytes = b""
    timeout_seconds: int = 3600
    namespace: str = "flow-serverless"
    volume_ids: list[str] = field(default_factory=list)


if workflow is not None:

    @workflow.defn
    class ClassMethodWorkflow:
        """Workflow for class-based function invocation with lifecycle hooks.

        Sequence: ensure container -> enter methods -> target method -> exit methods.
        Exit methods run in a finally block.
        """

        @workflow.run
        async def run(self, input: ClassMethodInput) -> bytes:
            # Ensure container is ready
            endpoint = await workflow.execute_activity(
                ensure_container_ready,
                EnsureContainerInput(
                    function_name=input.function_name,
                    image_ref=input.image_ref,
                    gpu=input.gpu,
                    namespace=input.namespace,
                    volume_ids=input.volume_ids,
                ),
                start_to_close_timeout=timedelta(minutes=10),
            )

            # Call @enter methods in order
            for enter_method in input.enter_methods:
                await workflow.execute_activity(
                    dispatch_request,
                    DispatchInput(
                        endpoint=endpoint,
                        function_name=input.function_name,
                        args_serialized=b"",
                        method=enter_method,
                    ),
                    start_to_close_timeout=timedelta(minutes=30),
                )

            # Call target @method, then always call @exit methods
            try:
                result = await workflow.execute_activity(
                    dispatch_request,
                    DispatchInput(
                        endpoint=endpoint,
                        function_name=input.function_name,
                        args_serialized=input.args_serialized,
                        method=input.target_method,
                        timeout_seconds=input.timeout_seconds,
                    ),
                    start_to_close_timeout=timedelta(seconds=input.timeout_seconds),
                )
            finally:
                for exit_method in input.exit_methods:
                    await workflow.execute_activity(
                        dispatch_request,
                        DispatchInput(
                            endpoint=endpoint,
                            function_name=input.function_name,
                            args_serialized=b"",
                            method=exit_method,
                        ),
                        start_to_close_timeout=timedelta(minutes=5),
                    )

            return result

else:

    class ClassMethodWorkflow:  # type: ignore[no-redef]
        """Stub when temporalio is not installed."""

        async def run(self, input: ClassMethodInput) -> bytes:
            raise ImportError("temporalio is required for serverless backend")
