"""Temporal activity implementations for serverless function execution.

Activities:
    container: K8s deployment lifecycle (ensure_container_ready, scale, delete).
    dispatch: HTTP request dispatch to function containers.
    image: Container image build and push.
    k8s: Low-level K8s CRUD operations.
"""
