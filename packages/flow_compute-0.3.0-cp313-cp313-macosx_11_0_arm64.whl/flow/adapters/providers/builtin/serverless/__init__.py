"""Serverless execution backend using Temporal (control plane) and Kubernetes + KEDA (data plane).

This provider supports container autoscaling, scale-to-zero, concurrency control,
dynamic batching, web endpoints, and scheduled execution. The DX layer
(@app.function, @app.cls) is backend-agnostic -- the same decorators work on
both VM and serverless backends.
"""

from flow.adapters.providers.builtin.serverless.provider import ServerlessProvider

__all__ = ["ServerlessProvider"]
