"""Jupyter notebook support for SkyPilot clusters.

Provides functionality to start Jupyter on SkyPilot clusters with
automatic SSH tunneling and browser opening.
"""

from __future__ import annotations

import logging
import secrets
import subprocess
import webbrowser
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.bridge import SkyBridge

logger = logging.getLogger(__name__)


@dataclass
class JupyterSession:
    """Active Jupyter session info.

    Attributes:
        cluster_name: SkyPilot cluster name
        remote_port: Port Jupyter is running on in the cluster
        local_port: Local port for SSH tunnel
        token: Authentication token for Jupyter access
        tunnel_pid: PID of SSH tunnel process (if managed)
    """

    cluster_name: str
    remote_port: int
    local_port: int
    token: str
    tunnel_pid: int | None = None

    @property
    def url(self) -> str:
        """Local URL to access Jupyter (includes authentication token)."""
        return f"http://localhost:{self.local_port}/?token={self.token}"


# Script to start Jupyter on cluster
JUPYTER_START_SCRIPT = """#!/bin/bash
set -e

# Install Jupyter if not present
if ! command -v jupyter &>/dev/null; then
    echo "Installing JupyterLab..."
    pip install -q jupyterlab
fi

# Kill any existing Jupyter processes
pkill -f 'jupyter-lab' 2>/dev/null || true

# Start Jupyter (no browser, token-authenticated)
nohup jupyter lab \
    --ip=0.0.0.0 \
    --port={port} \
    --no-browser \
    --NotebookApp.token='{token}' \
    --NotebookApp.password='' \
    --ServerApp.token='{token}' \
    --ServerApp.password='' \
    > /tmp/jupyter.log 2>&1 &

echo "Jupyter started on port {port}"
echo "Logs at /tmp/jupyter.log"
"""


class JupyterManager:
    """Manages Jupyter sessions on SkyPilot clusters.

    Provides functionality to:
    - Start Jupyter on a cluster
    - Create SSH tunnels for port forwarding
    - Open browser automatically
    - Stop Jupyter sessions
    """

    def __init__(self, bridge: SkyBridge) -> None:
        """Initialize the Jupyter manager.

        Args:
            bridge: SkyBridge for SkyPilot operations
        """
        self._bridge = bridge
        self._sessions: dict[str, JupyterSession] = {}

    def start_jupyter(
        self,
        cluster_name: str,
        local_port: int = 8888,
        remote_port: int = 8888,
        open_browser: bool = True,
    ) -> JupyterSession:
        """Start Jupyter on cluster and create SSH tunnel.

        Args:
            cluster_name: SkyPilot cluster name
            local_port: Local port for tunnel
            remote_port: Remote Jupyter port
            open_browser: Whether to open browser

        Returns:
            JupyterSession with connection info

        Raises:
            ValueError: If cluster not found or not running
        """
        # 1. Check cluster exists and is running
        info = self._bridge.get_dev_cluster_info(cluster_name)
        if info is None:
            raise ValueError(f"Cluster '{cluster_name}' not found")
        if info.status != "running":
            raise ValueError(f"Cluster '{cluster_name}' is not running (status: {info.status})")
        if info.ip_address is None:
            raise ValueError(f"Cluster '{cluster_name}' has no IP address")

        # 2. Generate authentication token
        token = secrets.token_hex(32)

        # 3. Start Jupyter on cluster
        script = JUPYTER_START_SCRIPT.format(port=remote_port, token=token)
        logger.info("Starting Jupyter on %s:%d", cluster_name, remote_port)
        self._bridge.exec_on_dev_cluster(
            cluster_name=cluster_name,
            command=script,
            stream_logs=False,
        )

        # 4. Create SSH tunnel
        ssh_user = info.ssh_user or "ubuntu"
        tunnel_pid = self._create_ssh_tunnel(
            ip_address=info.ip_address,
            ssh_user=ssh_user,
            local_port=local_port,
            remote_port=remote_port,
        )

        session = JupyterSession(
            cluster_name=cluster_name,
            remote_port=remote_port,
            local_port=local_port,
            token=token,
            tunnel_pid=tunnel_pid,
        )
        self._sessions[cluster_name] = session

        # 5. Open browser
        if open_browser:
            logger.info("Opening Jupyter at %s", session.url)
            webbrowser.open(session.url)

        return session

    def stop_jupyter(self, cluster_name: str) -> bool:
        """Stop Jupyter session and close tunnel.

        Args:
            cluster_name: SkyPilot cluster name

        Returns:
            True if session was stopped, False if not found
        """
        session = self._sessions.get(cluster_name)
        if not session:
            return False

        # Kill SSH tunnel
        if session.tunnel_pid:
            try:
                import os
                import signal

                os.kill(session.tunnel_pid, signal.SIGTERM)
                logger.info("Terminated SSH tunnel (PID: %d)", session.tunnel_pid)
            except ProcessLookupError:
                pass
            except OSError as e:
                logger.warning("Failed to kill tunnel process: %s", e)

        # Kill Jupyter process on cluster
        try:
            self._bridge.exec_on_dev_cluster(
                cluster_name=cluster_name,
                command="pkill -f 'jupyter-lab' || true",
                stream_logs=False,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("Failed to stop Jupyter on cluster: %s", e)

        del self._sessions[cluster_name]
        return True

    def get_session(self, cluster_name: str) -> JupyterSession | None:
        """Get active Jupyter session for a cluster.

        Args:
            cluster_name: SkyPilot cluster name

        Returns:
            JupyterSession if active, None otherwise
        """
        return self._sessions.get(cluster_name)

    def list_sessions(self) -> list[JupyterSession]:
        """List all active Jupyter sessions.

        Returns:
            List of active JupyterSession objects
        """
        return list(self._sessions.values())

    def _create_ssh_tunnel(
        self,
        ip_address: str,
        ssh_user: str,
        local_port: int,
        remote_port: int,
    ) -> int | None:
        """Create SSH tunnel to cluster.

        Args:
            ip_address: Cluster IP address
            ssh_user: SSH username for the cluster (e.g. "ubuntu", "root")
            local_port: Local port for tunnel
            remote_port: Remote port to forward

        Returns:
            PID of tunnel process, or None if failed
        """
        try:
            # Create SSH tunnel in background
            cmd = [
                "ssh",
                "-N",  # Don't execute remote command
                "-L",
                f"{local_port}:localhost:{remote_port}",
                "-o",
                "StrictHostKeyChecking=no",
                "-o",
                "UserKnownHostsFile=/dev/null",
                "-o",
                "LogLevel=ERROR",
                f"{ssh_user}@{ip_address}",
            ]

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            logger.info(
                "Created SSH tunnel: localhost:%d -> %s@%s:%d",
                local_port,
                ssh_user,
                ip_address,
                remote_port,
            )
            return process.pid

        except (OSError, subprocess.SubprocessError) as e:
            logger.warning("Failed to create SSH tunnel: %s", e)
            return None
