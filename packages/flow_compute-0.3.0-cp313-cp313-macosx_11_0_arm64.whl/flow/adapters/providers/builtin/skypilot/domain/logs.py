"""Log streaming utilities for SkyPilot clusters.

Provides functions for retrieving and streaming logs from SkyPilot clusters,
with proper formatting and filtering options.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.bridge.sky_bridge import SkyBridge

logger = logging.getLogger(__name__)


@dataclass
class LogOptions:
    """Options for log retrieval.

    Attributes:
        tail: Number of lines to return from the end.
        follow: Whether to follow logs in real-time.
        log_type: Type of logs ("stdout", "stderr", "all").
        since: Return logs since this timestamp (seconds).
        timestamps: Whether to include timestamps in output.
    """

    tail: int = 100
    follow: bool = False
    log_type: str = "stdout"
    since: float | None = None
    timestamps: bool = False


def get_cluster_logs(
    bridge: SkyBridge,
    cluster_name: str,
    options: LogOptions | None = None,
) -> str:
    """Retrieve logs from a SkyPilot cluster.

    Args:
        bridge: SkyBridge instance for cluster communication.
        cluster_name: Name of the cluster to get logs from.
        options: Log retrieval options.

    Returns:
        Log content as a string.
    """
    if options is None:
        options = LogOptions()

    logs = bridge.get_logs(cluster_name)

    # Apply tail if specified
    if options.tail and options.tail > 0:
        lines = logs.splitlines()
        logs = "\n".join(lines[-options.tail :])

    return logs


def stream_cluster_logs(
    bridge: SkyBridge,
    cluster_name: str,
    options: LogOptions | None = None,
) -> Iterator[str]:
    """Stream logs from a SkyPilot cluster.

    Args:
        bridge: SkyBridge instance for cluster communication.
        cluster_name: Name of the cluster to stream logs from.
        options: Log streaming options.

    Yields:
        Log lines as they become available.
    """
    if options is None:
        options = LogOptions(follow=True)

    yield from bridge.stream_logs(cluster_name)


def format_log_line(
    line: str,
    show_timestamp: bool = False,
    prefix: str | None = None,
) -> str:
    """Format a log line with optional timestamp and prefix.

    Args:
        line: Raw log line.
        show_timestamp: Whether to prepend timestamp.
        prefix: Optional prefix (e.g., node identifier).

    Returns:
        Formatted log line.
    """
    parts = []

    if prefix:
        parts.append(f"[{prefix}]")

    parts.append(line)

    return " ".join(parts)


def parse_job_logs(
    raw_output: str,
    job_id: int | None = None,
) -> str:
    """Parse and clean SkyPilot job output.

    SkyPilot job output may contain setup information, progress bars,
    and other noise. This function extracts the actual job output.

    Args:
        raw_output: Raw output from SkyPilot.
        job_id: Optional job ID to filter for.

    Returns:
        Cleaned job output.
    """
    lines = raw_output.splitlines()
    cleaned_lines: list[str] = []

    # Skip SkyPilot preamble and progress indicators
    in_job_output = False

    for line in lines:
        # Detect start of actual job output
        if "Job started" in line or (job_id and f"Job {job_id}" in line):
            in_job_output = True
            continue

        # Skip progress bars and setup lines
        if any(
            pattern in line
            for pattern in [
                "Setting up",
                "Installing",
                "Downloading",
                "\x1b[",  # ANSI escape sequences
                "━",  # Progress bar
                "100%|",  # tqdm progress
            ]
        ):
            continue

        if in_job_output:
            cleaned_lines.append(line)

    # If we never found job output marker, return all non-progress lines
    if not cleaned_lines:
        return "\n".join(
            line
            for line in lines
            if not any(pattern in line for pattern in ["━", "100%|", "\x1b["])
        )

    return "\n".join(cleaned_lines)


class LogManager:
    """Manages log retrieval and streaming for SkyPilot clusters."""

    def __init__(self, bridge: SkyBridge) -> None:
        """Initialize LogManager.

        Args:
            bridge: SkyBridge instance for cluster communication.
        """
        self._bridge = bridge

    def get_logs(
        self,
        cluster_name: str,
        tail: int = 100,
        log_type: str = "stdout",
    ) -> str:
        """Get logs from cluster.

        Args:
            cluster_name: Cluster name.
            tail: Lines to return.
            log_type: Log type.

        Returns:
            Log content.
        """
        options = LogOptions(tail=tail, log_type=log_type)
        return get_cluster_logs(self._bridge, cluster_name, options)

    def stream_logs(
        self,
        cluster_name: str,
        follow: bool = True,
    ) -> Iterator[str]:
        """Stream logs from cluster.

        Args:
            cluster_name: Cluster name.
            follow: Whether to follow.

        Yields:
            Log lines.
        """
        options = LogOptions(follow=follow)
        yield from stream_cluster_logs(self._bridge, cluster_name, options)
