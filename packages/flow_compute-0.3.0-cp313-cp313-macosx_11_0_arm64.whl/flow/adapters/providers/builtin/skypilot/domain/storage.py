"""Storage management for SkyPilot using sky.Storage.

Provides the StorageManager class for creating, deleting, and managing
persistent cloud storage (GCS, S3, Azure Blob) through SkyPilot's Storage API.

Cloud storage in SkyPilot differs from block volumes:
- Uses object storage buckets (not block devices)
- Persists independently of clusters
- Can be mounted to multiple clusters
- Syncs data bidirectionally with local paths
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from flow.adapters.providers.builtin.skypilot.domain.state_store import VolumeRecord
from flow.adapters.providers.builtin.skypilot.exceptions import StorageNotFoundError
from flow.sdk.models import Volume

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.bridge.sky_bridge import SkyBridge
    from flow.adapters.providers.builtin.skypilot.domain.state_store import StateStore

logger = logging.getLogger(__name__)

# Prefix for Flow-managed storage
STORAGE_PREFIX = "flow-vol-"


def generate_volume_name(name: str | None = None) -> str:
    """Generate a unique volume name.

    Args:
        name: Optional user-provided name.

    Returns:
        Unique volume name with flow prefix.
    """
    if name:
        # Ensure name has prefix
        if not name.startswith(STORAGE_PREFIX):
            return f"{STORAGE_PREFIX}{name}"
        return name

    # Generate unique name
    suffix = uuid.uuid4().hex[:8]
    return f"{STORAGE_PREFIX}{suffix}"


def storage_info_to_volume(
    name: str,
    store_type: str,
    size_gb: int = 0,
    region: str | None = None,
) -> Volume:
    """Convert storage info to Flow Volume object.

    Args:
        name: Storage name.
        store_type: Storage backend type.
        size_gb: Size in GB (informational for cloud storage).
        region: Region where storage resides.

    Returns:
        Volume object.
    """
    return Volume(
        volume_id=f"sky-vol-{name}",
        name=name,
        size_gb=size_gb,
        region=region or "auto",
    )


class StorageManager:
    """Manages cloud storage for SkyPilot clusters.

    This class provides a Volume-compatible interface for SkyPilot's cloud
    storage, allowing `flow volume` commands to work with GCS/S3/Azure buckets.

    Key differences from block volumes:
    - Size is not fixed (cloud storage scales automatically)
    - Storage persists after cluster termination
    - Can be mounted to any cluster via storage_mounts
    """

    def __init__(self, bridge: SkyBridge, state_store: StateStore | None = None) -> None:
        """Initialize StorageManager.

        Args:
            bridge: SkyBridge instance for storage operations.
            state_store: Optional state store for persisting volume metadata.
                If None, falls back to in-memory tracking only.
        """
        self._bridge = bridge
        self._state_store = state_store

    def create_volume(
        self,
        size_gb: int,
        name: str | None = None,
        region: str | None = None,
    ) -> Volume:
        """Create a new cloud storage volume.

        Args:
            size_gb: Requested size in GB (informational for cloud storage).
            name: Optional volume name.
            region: Target region (used for bucket location).

        Returns:
            Volume object with storage details.
        """
        volume_name = generate_volume_name(name)

        logger.info("Creating cloud storage: %s", volume_name)

        # Create storage via bridge
        storage_info = self._bridge.create_storage(
            name=volume_name,
            source=None,  # No initial sync
            store_type=None,  # Auto-detect based on cloud config
            region=region,
        )

        # Persist volume metadata so size_gb survives process restarts
        if self._state_store is not None:
            self._state_store.put_volume(
                VolumeRecord(
                    name=volume_name,
                    size_gb=size_gb,
                    store_type=storage_info.store_type,
                    created_at=datetime.now(timezone.utc).isoformat(),
                    region=storage_info.region or region,
                )
            )

        return storage_info_to_volume(
            name=storage_info.name,
            store_type=storage_info.store_type,
            size_gb=size_gb,
            region=storage_info.region or region,
        )

    def delete_volume(self, volume_id: str) -> bool:
        """Delete a cloud storage volume.

        Args:
            volume_id: Volume identifier (sky-vol-* or flow-vol-* format).

        Returns:
            True if deleted successfully.

        Raises:
            StorageNotFoundError: If the volume does not exist.
        """
        # Extract storage name from volume_id
        if volume_id.startswith("sky-vol-"):
            storage_name = volume_id[8:]  # Remove "sky-vol-" prefix
        else:
            storage_name = volume_id

        # Verify volume exists before attempting deletion
        storage_info = self._bridge.get_storage(storage_name)
        if storage_info is None:
            raise StorageNotFoundError(storage_name)

        logger.info("Deleting cloud storage: %s", storage_name)

        self._bridge.delete_storage(storage_name)  # Raises on failure

        if self._state_store is not None:
            self._state_store.remove_volume(storage_name)

        return True

    def list_volumes(
        self,
        limit: int = 100,
        project_id: str | None = None,
        region: str | None = None,
    ) -> list[Volume]:
        """List all cloud storage volumes.

        Args:
            limit: Maximum volumes to return.
            project_id: Optional project filter (not used for SkyPilot).
            region: Optional region filter.

        Returns:
            List of Volume objects.
        """
        storage_list = self._bridge.list_storage()

        volumes = []
        for storage in storage_list:
            # Only include Flow-managed storage
            if not storage.name.startswith(STORAGE_PREFIX):
                continue

            persisted = self._state_store.get_volume(storage.name) if self._state_store else None
            storage_region = storage.region or (persisted.region if persisted else None)

            # Apply region filter if specified
            if region and storage_region and storage_region != region:
                continue

            size_gb = (
                persisted.size_gb
                if persisted is not None
                else self._get_persisted_size(storage.name)
            )
            volumes.append(
                storage_info_to_volume(
                    name=storage.name,
                    store_type=storage.store_type,
                    size_gb=size_gb,
                    region=storage_region,
                )
            )

        # Sort by name for consistent ordering
        volumes.sort(key=lambda v: v.name or "")

        return volumes[:limit]

    def get_volume(self, volume_id: str) -> Volume | None:
        """Get a volume by ID.

        Args:
            volume_id: Volume identifier.

        Returns:
            Volume object or None if not found.
        """
        # Extract storage name from volume_id
        if volume_id.startswith("sky-vol-"):
            storage_name = volume_id[8:]
        else:
            storage_name = volume_id

        storage_info = self._bridge.get_storage(storage_name)
        if storage_info is None:
            return None

        persisted = self._state_store.get_volume(storage_name) if self._state_store else None
        size_gb = (
            persisted.size_gb if persisted is not None else self._get_persisted_size(storage_name)
        )
        return storage_info_to_volume(
            name=storage_info.name,
            store_type=storage_info.store_type,
            size_gb=size_gb,
            region=storage_info.region or (persisted.region if persisted else None),
        )

    def _get_persisted_size(self, volume_name: str) -> int:
        """Look up persisted size_gb for a volume, returning 0 if unknown."""
        if self._state_store is not None:
            record = self._state_store.get_volume(volume_name)
            if record is not None:
                return record.size_gb
        return 0

    def is_volume_id(self, identifier: str) -> bool:
        """Check if identifier is a volume ID.

        Args:
            identifier: String to check.

        Returns:
            True if it's a volume ID.
        """
        return identifier.startswith("sky-vol-") or identifier.startswith(STORAGE_PREFIX)
