"""SkyPilot provider for Flow.

This provider uses SkyPilot to orchestrate GPU workloads across cloud providers
(GCP, AWS, Azure) with automatic pricing optimization and failover.
"""

from flow.adapters.providers.builtin.skypilot.provider import SkyPilotProvider

__all__ = ["SkyPilotProvider"]
