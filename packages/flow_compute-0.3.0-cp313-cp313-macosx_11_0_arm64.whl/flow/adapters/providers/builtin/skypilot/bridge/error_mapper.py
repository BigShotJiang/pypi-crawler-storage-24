"""Maps SkyPilot exceptions to Flow exceptions.

This ensures sky exceptions NEVER escape the bridge.
All sky.* exceptions are caught and converted to Flow exceptions.

Strategy:
1. Check isinstance against sky.exceptions types (fast, reliable).
2. Fall back to string pattern matching (handles unknown/wrapped errors).
"""

from __future__ import annotations

import logging
import re
from typing import Any

from flow.adapters.providers.builtin.skypilot.exceptions import (
    CloudCredentialsError,
    ClusterNotFoundError,
    NoPricingOptionsError,
    QuotaExceededError,
    SkyPilotProviderError,
)

logger = logging.getLogger(__name__)


def map_sky_error(error: Exception) -> Exception:
    """Map a SkyPilot exception to a Flow exception.

    NEVER re-raise the original sky exception - always wrap it.

    Args:
        error: Original exception from SkyPilot.

    Returns:
        Flow exception that wraps the original error.
    """
    sky_exceptions = _get_sky_exceptions()
    if sky_exceptions is not None:
        mapped = _map_by_type(error, sky_exceptions)
        if mapped is not None:
            return mapped

    return _map_by_string(error)


def _get_sky_exceptions() -> Any | None:
    """Lazily import sky.exceptions.

    SkyPilot's import path can trigger unrelated initialization side effects
    (for example cache/database setup) before we ever reach ``sky.exceptions``.
    Error mapping must remain available even when that environment setup fails,
    so we fall back to string-based classification after logging the reason.
    """
    try:
        import sky.exceptions

        return sky.exceptions
    except (ImportError, ModuleNotFoundError):
        return None
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "Could not import sky.exceptions for type-based error mapping: %s",
            exc,
        )
        return None


def _map_by_type(error: Exception, sky_exc: Any) -> Exception | None:
    """Map exception using isinstance checks against sky.exceptions."""
    error_str = str(error)

    if hasattr(sky_exc, "ClusterDoesNotExist") and isinstance(error, sky_exc.ClusterDoesNotExist):
        cluster_name = _extract_cluster_name(error_str) or "unknown"
        return ClusterNotFoundError(cluster_name)

    if hasattr(sky_exc, "ResourcesUnavailableError") and isinstance(
        error, sky_exc.ResourcesUnavailableError
    ):
        gpu_type, gpu_count = _extract_resource_info(str(error))
        return NoPricingOptionsError(
            gpu_type=gpu_type, gpu_count=gpu_count, max_price=None, detail=str(error)
        )

    if hasattr(sky_exc, "NoCloudAccessError") and isinstance(error, sky_exc.NoCloudAccessError):
        cloud = _extract_cloud_from_error(str(error).lower())
        return CloudCredentialsError(cloud, str(error))

    if hasattr(sky_exc, "CloudUserIdentityError") and isinstance(
        error, sky_exc.CloudUserIdentityError
    ):
        cloud = _extract_cloud_from_error(str(error).lower())
        return CloudCredentialsError(cloud, str(error))

    if hasattr(sky_exc, "CommandError") and isinstance(error, sky_exc.CommandError):
        return SkyPilotProviderError(f"Remote command failed: {error}")

    return None  # Not matched by type


def _map_by_string(error: Exception) -> Exception:
    """Map exception by string pattern matching (fallback)."""
    error_str = str(error).lower()
    error_type = type(error).__name__

    logger.debug("Mapping sky error by string: %s: %s", error_type, error)

    if "credential" in error_str or "authentication" in error_str:
        cloud = _extract_cloud_from_error(error_str)
        return CloudCredentialsError(cloud, str(error))

    if "quota" in error_str or "limit exceeded" in error_str:
        cloud = _extract_cloud_from_error(error_str)
        return QuotaExceededError(cloud, "GPU", str(error))

    if "no resources" in error_str or "no launchable" in error_str:
        gpu_type, gpu_count = _extract_resource_info(str(error))
        return NoPricingOptionsError(
            gpu_type=gpu_type, gpu_count=gpu_count, max_price=None, detail=str(error)
        )

    if "permission" in error_str or "forbidden" in error_str:
        cloud = _extract_cloud_from_error(error_str)
        return CloudCredentialsError(cloud, f"Permission denied: {error}")

    if "cluster" in error_str and ("not found" in error_str or "does not exist" in error_str):
        cluster_name = _extract_cluster_name(str(error)) or "unknown"
        return ClusterNotFoundError(cluster_name)

    return SkyPilotProviderError(f"SkyPilot error: {error}")


def _extract_cloud_from_error(error_str: str) -> str:
    """Extract cloud name from error message.

    Args:
        error_str: Lowercased error message.

    Returns:
        Cloud name or "unknown".
    """
    clouds = ["gcp", "aws", "azure", "lambda", "runpod", "kubernetes"]
    for cloud in clouds:
        if cloud in error_str:
            return cloud
    return "unknown"


def _extract_resource_info(error_str: str) -> tuple[str | None, int]:
    """Extract GPU type and count from a SkyPilot error message.

    Parses common SkyPilot resource patterns like "T4:1", "A100:4",
    "H100:8". Returns (None, 0) when no resource info is found.

    Args:
        error_str: Original error message.

    Returns:
        Tuple of (gpu_type, gpu_count). gpu_type is None if not found.
    """
    # Pattern: "T4:1", "A100:4", "H100:8", "V100:2"
    match = re.search(r"\b([A-Za-z]\w*\d+):(\d+)\b", error_str)
    if match:
        return match.group(1), int(match.group(2))

    # Pattern: "1x T4", "4x A100"
    match = re.search(r"\b(\d+)\s*x\s*([A-Za-z]\w*\d+)\b", error_str)
    if match:
        return match.group(2), int(match.group(1))

    return None, 0


def _extract_cluster_name(error_str: str) -> str | None:
    """Extract cluster name from error message. Best-effort.

    Args:
        error_str: Error message (original case).

    Returns:
        Cluster name if found, None otherwise.
    """
    for marker in ["cluster '", 'cluster "', "cluster "]:
        idx = error_str.lower().find(marker)
        if idx != -1:
            start = idx + len(marker)
            end = error_str.find("'", start)
            if end == -1:
                end = error_str.find('"', start)
            if end == -1:
                end = error_str.find(" ", start)
            if end != -1:
                return error_str[start:end]
    return None
