"""SkyPilot provider configuration.

Parses Flow config into SkyPilot-specific settings.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

SUPPORTED_CLOUDS = ("gcp", "aws", "azure")


@dataclass
class SkyPilotConfig:
    """Configuration for SkyPilot provider."""

    # Enabled clouds (empty = all available)
    clouds: list[str] = field(default_factory=lambda: ["gcp", "aws", "azure"])

    # Disabled clouds
    disabled_clouds: list[str] = field(default_factory=list)

    # Default preferences
    use_spot: bool = True
    default_region: dict[str, str] = field(default_factory=dict)
    disk_size_gb: int = 256

    # API server settings
    api_server_auto_start: bool = True
    api_server_port: int = 8265
    api_server_timeout: int = 300

    # Cluster naming
    cluster_prefix: str = "flow"
    idle_timeout_minutes: int = 0  # Auto-down after task

    # GCP Dynamic Workload Scheduler
    dws_run_duration_seconds: int | None = None  # Flex-start duration (max 604800 = 7 days)
    dws_provision_timeout_seconds: int | None = None  # Max wait for DWS provisioning

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SkyPilotConfig:
        """Create config from dictionary.

        Args:
            data: Configuration dictionary, typically from .flow/config.yaml

        Returns:
            SkyPilotConfig instance
        """
        skypilot_data = data.get("skypilot", {})
        defaults = skypilot_data.get("defaults", {})
        api_server = skypilot_data.get("api_server", {})
        cluster = skypilot_data.get("cluster", {})
        dws = skypilot_data.get("dws", {})

        return cls(
            clouds=skypilot_data.get("clouds", ["gcp", "aws", "azure"]),
            disabled_clouds=skypilot_data.get("disabled_clouds", []),
            use_spot=defaults.get("use_spot", True),
            default_region=defaults.get("regions", {}),
            disk_size_gb=defaults.get("disk_size_gb", 256),
            api_server_auto_start=api_server.get("auto_start", True),
            api_server_port=api_server.get("port", 8265),
            api_server_timeout=api_server.get("timeout", 300),
            cluster_prefix=cluster.get("name_prefix", "flow"),
            idle_timeout_minutes=cluster.get("idle_timeout_minutes", 0),
            dws_run_duration_seconds=dws.get("run_duration_seconds"),
            dws_provision_timeout_seconds=dws.get("provision_timeout_seconds"),
        )

    def get_enabled_clouds(self) -> list[str]:
        """Get list of enabled clouds.

        Returns:
            List of cloud names that are enabled and not disabled
        """
        configured = self._normalize_clouds(
            self.clouds or list(SUPPORTED_CLOUDS),
            field_name="clouds",
        )
        disabled = set(self._normalize_clouds(self.disabled_clouds, field_name="disabled_clouds"))
        return [cloud for cloud in configured if cloud not in disabled]

    def get_default_region_for_cloud(self, cloud: str) -> str | None:
        """Get default region for a specific cloud.

        Args:
            cloud: Cloud name (gcp, aws, azure)

        Returns:
            Default region string or None
        """
        return self.default_region.get(cloud.lower())

    def _normalize_clouds(self, clouds: list[str], *, field_name: str) -> list[str]:
        """Normalize configured cloud names and reject unsupported values."""
        normalized: list[str] = []
        seen: set[str] = set()

        for raw_cloud in clouds:
            cloud = raw_cloud.strip().lower()
            if cloud not in SUPPORTED_CLOUDS:
                supported = ", ".join(SUPPORTED_CLOUDS)
                raise ValueError(
                    f"Unsupported SkyPilot cloud '{raw_cloud}' in {field_name}. "
                    f"Supported clouds: {supported}."
                )
            if cloud not in seen:
                normalized.append(cloud)
                seen.add(cloud)

        return normalized
