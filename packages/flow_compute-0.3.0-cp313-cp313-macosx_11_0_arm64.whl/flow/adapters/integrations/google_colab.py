"""Google Colab integration for Flow SDK.

Provides Google Colab integration through the local runtime connection protocol.
Launches a localhost-bound Jupyter server on a Flow GPU instance and connects
via SSH port forwarding.
"""

from __future__ import annotations

import logging
import re
import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timezone

from flow.core.ssh.probe import tcp_port_open
from flow.errors import FlowError, TaskNotFoundError, ValidationError
from flow.sdk.client import Flow, TaskConfig
from flow.sdk.models import Task, TaskStatus, VolumeSpec

logger = logging.getLogger(__name__)


def auto_select_region(flow_client: Flow, instance_type: str) -> str | None:
    """Select the best region for an instance type based on availability and price.

    Returns:
        Region string, or None if auto-selection fails.
    """
    try:
        instances = flow_client.find_instances({"instance_type": instance_type}, limit=20)
        if not instances:
            return None

        def _avail(i):
            return i.available_quantity if i.available_quantity is not None else 0

        instances.sort(key=lambda i: (-_avail(i), i.price_per_hour))
        return instances[0].region
    except Exception:  # noqa: BLE001
        return None


@dataclass
class ColabConnection:
    """Connection details for Google Colab to connect to Flow GPU instance."""

    connection_url: str
    ssh_command: str
    instance_ip: str
    instance_type: str
    task_id: str
    session_id: str
    created_at: datetime
    jupyter_token: str
    remote_port: int = 8888

    def to_dict(self) -> dict[str, str]:
        return {
            "connection_url": self.connection_url,
            "ssh_command": self.ssh_command,
            "instance_ip": self.instance_ip,
            "instance_type": self.instance_type,
            "task_id": self.task_id,
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "jupyter_token": self.jupyter_token,
            "remote_port": str(self.remote_port),
        }

    def connection_url_for_localport(self, local_port: int) -> str:
        return f"http://localhost:{local_port}/?token={self.jupyter_token}"

    def get_token(self) -> str:
        return self.jupyter_token


class GoogleColabIntegration:
    """Google Colab integration using local runtime connection."""

    JUPYTER_STARTUP_SCRIPT = """#!/bin/bash
set -euo pipefail

# Ensure notebook 7+ is installed (quiet to minimize output).
# --break-system-packages is required on Ubuntu 23.04+ (PEP 668).
python3 -c "import notebook" 2>/dev/null || \
  python3 -m pip install -q --no-warn-script-location --disable-pip-version-check \
    --break-system-packages 'notebook>=7,<8'

# Token and config
export JUPYTER_TOKEN=$(python3 - <<'PY'
import secrets; print(secrets.token_urlsafe(32))
PY
)
mkdir -p ~/.jupyter
cat > ~/.jupyter/jupyter_notebook_config.py << EOF
c.ServerApp.allow_origin = 'https://colab.research.google.com'
c.ServerApp.token = '$JUPYTER_TOKEN'
c.ServerApp.port_retries = 0
EOF

# Select a free localhost port
REMOTE_PORT=$(python3 - <<'PY'
import socket
s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1]); s.close()
PY
)
echo "$REMOTE_PORT" > ~/.jupyter/colab_port

# Start Jupyter bound to localhost via python3 -m notebook (pip may not
# install the 'jupyter-notebook' entry point on externally-managed envs).
echo "Starting Jupyter for Colab on port $REMOTE_PORT (localhost bind)" >&2 || true
nohup python3 -m notebook \
  --ServerApp.allow_origin='https://colab.research.google.com' \
  --ServerApp.token=$JUPYTER_TOKEN \
  --ServerApp.port_retries=0 \
  --port=$REMOTE_PORT \
  --no-browser \
  --ip=127.0.0.1 \
  >/dev/null 2>&1 &

echo "JUPYTER_STARTED=true" || true

# Keep main process alive so the task stays running.
# If Jupyter dies, the loop exits and the task will fail.
while kill -0 $! 2>/dev/null; do
    sleep 30
done
"""

    def __init__(self, flow_client: Flow):
        self.flow = flow_client
        self._active_connections: dict[str, ColabConnection] = {}

    def sanitize_volume_name(self, desired_name: str | None) -> str:
        name = (desired_name or "colab-ws").strip().lower()
        name = re.sub(r"[^a-z0-9-]+", "-", name)
        name = re.sub(r"-{2,}", "-", name).strip("-")
        if len(name) < 3:
            name = (name + "000")[:3]
        if len(name) > 64:
            name = name[:64].rstrip("-")
        if not re.match(r"^[a-z0-9]", name or ""):
            name = f"a{name}"
        if not re.search(r"[a-z0-9]$", name or ""):
            name = f"{name}0"
        if len(name) < 3:
            name = (name + "000")[:3]
        return name

    def connect(
        self,
        instance_type: str,
        hours: float | None = None,
        auto_tunnel: bool = False,
        name: str | None = None,
        attach_workspace: bool = True,
        workspace_size_gb: int = 50,
        workspace_name: str | None = None,
        *,
        quiet: bool = False,
    ) -> ColabConnection:
        if hours is not None and hours != 0 and (hours < 0.1 or hours > 168):
            raise ValidationError("Hours must be between 0.1 and 168, or 0/unset for no limit")
        if hours == 0:
            hours = None
        session_id = f"colab-{secrets.token_hex(6)}"
        config = TaskConfig(
            name=name or f"colab-{instance_type}",
            unique_name=False,
            instance_type=instance_type,
            command=["bash", "-c", self.JUPYTER_STARTUP_SCRIPT],
            upload_code=False,
            upload_strategy="none",
            image="",
            env={"FLOW_HEALTH_MONITORING": "false"},
            max_run_time_hours=hours,
            priority="high",
        )
        if not getattr(config, "region", None):
            config.region = auto_select_region(self.flow, instance_type)
        if attach_workspace and workspace_size_gb > 0:
            vol_name = self.sanitize_volume_name(workspace_name or f"colab-ws-{session_id}")
            config.volumes = [
                VolumeSpec(name=vol_name, size_gb=workspace_size_gb, mount_path="/workspace")
            ]
        if not quiet:
            if hours is None:
                logger.info(f"Launching {instance_type}...")
            else:
                logger.info(f"Launching {instance_type} for {hours} hours...")
            logger.info("Provisioning can take several minutes.")
        task = self.flow.run(config)
        connection = self.wait_for_instance_ready(task, session_id, quiet=quiet)
        self._active_connections[session_id] = connection
        if auto_tunnel:
            self._establish_ssh_tunnel(connection)
        return connection

    def wait_for_instance_ready(
        self,
        task: Task,
        session_id: str,
        timeout: int = 900,
        *,
        quiet: bool = False,
    ) -> ColabConnection:
        start_time = time.time()
        last_status = None
        jupyter_token = None
        instance_ip = None
        remote_port_val: int | None = None
        has_remote_ops = True
        while time.time() - start_time < timeout:
            try:
                task = self.flow.get_task(task.task_id)
                status = task.status
            except Exception as e:  # noqa: BLE001
                logger.error(f"Failed to get task status: {e}")
                status = TaskStatus.FAILED
            if status != last_status:
                if status == TaskStatus.PENDING:
                    if last_status is None and not quiet:
                        logger.info("Instance allocation started...")
                elif status == TaskStatus.RUNNING:
                    if not quiet:
                        logger.info("Instance running; preparing Jupyter environment...")
                elif status == TaskStatus.FAILED:
                    if not quiet:
                        logger.error("Instance failed to start")
                    raise FlowError(f"Task {task.task_id} failed: {task.message}")
                last_status = status
            if status == TaskStatus.RUNNING:
                if not instance_ip and task.ssh_host:
                    instance_ip = task.ssh_host

                # Resolve remote_ops once per iteration
                remote_ops = None
                if has_remote_ops:
                    try:
                        remote_ops = self.flow.get_remote_operations()
                    except (AttributeError, NotImplementedError):
                        has_remote_ops = False

                if not jupyter_token and instance_ip and remote_ops is not None:
                    try:
                        cmd = "awk -F\"'\" '/^c.ServerApp.token/ {print $2}' ~/.jupyter/jupyter_notebook_config.py"
                        token_output = remote_ops.execute_command(task.task_id, cmd)
                        candidate = (token_output or "").strip()
                        if candidate:
                            jupyter_token = candidate
                    except Exception:  # noqa: BLE001
                        pass
                if instance_ip and remote_port_val is None and remote_ops is not None:
                    try:
                        port_output = remote_ops.execute_command(
                            task.task_id, "cat ~/.jupyter/colab_port || true"
                        )
                        port_str = (port_output or "").strip()
                        if port_str.isdigit():
                            remote_port_val = int(port_str)
                    except Exception:  # noqa: BLE001
                        pass
                jupyter_http_ok = False
                if instance_ip and (remote_port_val is not None) and jupyter_token:
                    if remote_ops is not None:
                        try:
                            check_cmd = (
                                f"python3 - <<'PY'\n"
                                f"import urllib.request, urllib.error\n"
                                f'url = "http://127.0.0.1:{remote_port_val}/api/status?token={jupyter_token}"\n'
                                f"try:\n"
                                f"    urllib.request.urlopen(url, timeout=2)\n"
                                f'    print("OK")\n'
                                f"except Exception as e:\n"
                                f"    pass\n"
                                f"PY"
                            )
                            http_out = (
                                remote_ops.execute_command(task.task_id, check_cmd) or ""
                            ).strip()
                            if "OK" in http_out:
                                jupyter_http_ok = True
                        except Exception:  # noqa: BLE001
                            pass
                    else:
                        # Without remote ops, skip HTTP health check
                        jupyter_http_ok = True

                # For providers without remote ops, fall back to SSH-only readiness
                # with default port if we can't query it remotely
                if (
                    not has_remote_ops
                    and instance_ip
                    and tcp_port_open(instance_ip, 22, timeout_sec=5.0)
                ):
                    if remote_port_val is None:
                        remote_port_val = 8888
                    if not jupyter_token:
                        jupyter_token = ""
                    jupyter_http_ok = True

                if (
                    instance_ip
                    and jupyter_token
                    and (remote_port_val is not None)
                    and jupyter_http_ok
                    and tcp_port_open(instance_ip, 22, timeout_sec=5.0)
                ):
                    if not quiet:
                        logger.info("SSH access confirmed")
                    return ColabConnection(
                        connection_url=f"http://localhost:{remote_port_val}/?token={jupyter_token}",
                        ssh_command=f"ssh -N -o ExitOnForwardFailure=yes -o ServerAliveInterval=60 -o ServerAliveCountMax=2 -L 8888:localhost:{remote_port_val} {task.ssh_user}@{instance_ip}",
                        instance_ip=instance_ip,
                        instance_type=task.instance_type,
                        task_id=task.task_id,
                        session_id=session_id,
                        created_at=datetime.now(timezone.utc),
                        jupyter_token=jupyter_token,
                        remote_port=remote_port_val,
                    )
            time.sleep(5)
        raise FlowError(f"Instance not ready after {timeout // 60} minutes")

    def _establish_ssh_tunnel(self, connection: ColabConnection) -> None:
        logger.info(f"Auto-tunnel requested for {connection.task_id}")

    def disconnect(self, session_id: str) -> None:
        if session_id not in self._active_connections:
            raise ValueError(f"Session {session_id} not found")
        connection = self._active_connections[session_id]
        try:
            self.flow.stop(connection.task_id)
            logger.info(f"Disconnected session {session_id}")
        except Exception as e:  # noqa: BLE001
            logger.error(f"Failed to stop task {connection.task_id}: {e}")
            raise FlowError(f"Failed to disconnect session: {e!s}")
        finally:
            del self._active_connections[session_id]

    def list_sessions(self) -> list[dict[str, str]]:
        sessions = []
        for session_id, connection in self._active_connections.items():
            try:
                task = self.flow.get_task(connection.task_id)
                status = task.status.value
            except TaskNotFoundError:
                status = "terminated"
            except Exception:  # noqa: BLE001
                status = "unknown"
            sessions.append(
                {
                    "session_id": session_id,
                    "instance_type": connection.instance_type,
                    "status": status,
                    "created_at": connection.created_at.isoformat(),
                    "connection_url": connection.connection_url,
                    "ssh_command": connection.ssh_command,
                }
            )
        return sessions

    def get_startup_progress(self, task_id: str) -> str:
        try:
            logs = self.flow.logs(task_id, tail=50)
            if "JUPYTER_STARTED=true" in logs:
                return "Jupyter server ready!"
            elif re.search(r"Starting Jupyter server on port \d+", logs):
                return "Starting Jupyter server..."
            elif "Installing dependencies" in logs or "pip install" in logs:
                return "Installing dependencies..."
            elif "Starting Jupyter server for Google Colab" in logs:
                return "Initializing Jupyter environment..."
            else:
                return "Instance initializing..."
        except Exception:  # noqa: BLE001
            return "Waiting for instance..."
