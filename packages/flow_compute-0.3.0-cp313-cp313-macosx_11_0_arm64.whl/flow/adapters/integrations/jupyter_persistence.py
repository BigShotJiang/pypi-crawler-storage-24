"""Persistence utilities for Flow-Colab integration.

Handles state checkpointing and restoration for notebook sessions.
"""

import os

from flow.errors import FlowError
from flow.sdk.client import Flow


class PersistenceManager:
    """Manages persistent state for Colab notebooks."""

    def __init__(self, flow_client: Flow | None = None):
        """Initialize persistence manager.

        Args:
            flow_client: Flow client for volume management
        """
        self.flow = flow_client
        try:
            from flow.application.config.runtime import settings as _settings  # local import

            colab_cfg = _settings.colab or {}
            self._enabled = bool(colab_cfg.get("persistence", True))
        except Exception:  # noqa: BLE001
            self._enabled = os.environ.get("FLOW_COLAB_PERSISTENCE", "true").lower() == "true"

    def is_enabled(self) -> bool:
        """Check if persistence is enabled."""
        return self._enabled

    def ensure_volume(self, region: str, session_id: str, size_gb: int = 1) -> str:
        """Ensure a persistence volume exists for the session.

        Args:
            region: Region to create volume in (colocated with GPU)
            session_id: Session identifier
            size_gb: Volume size in GB

        Returns:
            Volume ID
        """
        if not self.flow:
            raise FlowError("Flow client required for volume management")

        from flow.adapters.resilience.retry import ExponentialBackoffPolicy, with_retry
        from flow.errors import NetworkError

        volume_name = f"colab-persist-{session_id}"

        # Check for existing volume with retry
        _list_policy = ExponentialBackoffPolicy(max_attempts=3, initial_delay=1.0)

        @with_retry(
            policy=_list_policy,
            retryable_exceptions=(NetworkError, ConnectionError),
        )
        def list_volumes():
            return self.flow.list_volumes()

        volumes = list_volumes()
        for vol in volumes:
            if vol.name == volume_name:
                return vol.volume_id

        # Create new volume with retry
        _create_policy = ExponentialBackoffPolicy(max_attempts=3, initial_delay=1.0)

        @with_retry(
            policy=_create_policy,
            retryable_exceptions=(NetworkError, ConnectionError),
        )
        def create_volume():
            return self.flow.create_volume(name=volume_name, size_gb=size_gb)

        volume = create_volume()
        return volume.volume_id
