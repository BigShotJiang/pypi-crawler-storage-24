"""Configuration dataclasses for health monitoring.

This module provides centralized configuration for the health monitoring
subsystem, including GPUd client settings, scoring thresholds, streaming
configuration, and storage options.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class GPUdConfig:
    """Configuration for GPUd client connections."""

    base_url: str = "https://localhost:15132"
    port: int = 15132
    version: str = "v0.5.1"
    bind_address: str = "127.0.0.1"
    timeout_seconds: float = 10.0
    health_endpoints: tuple[str, ...] = ("/healthz",)
    verify_ssl: bool = False  # GPUd v0.8.0+ uses self-signed certs


@dataclass(frozen=True)
class ScoringConfig:
    """Configuration for health score calculation.

    Thresholds and weights used to compute overall health scores
    from component metrics.
    """

    # Temperature thresholds (Celsius)
    temperature_warning_c: int = 75
    temperature_critical_c: int = 85

    # GPU memory utilization thresholds (percent)
    gpu_memory_warning_pct: int = 85
    gpu_memory_critical_pct: int = 95

    # Host resource thresholds (percent)
    host_cpu_critical_pct: int = 95
    host_memory_critical_pct: int = 90
    host_disk_critical_pct: int = 95

    # Event time decay (hours)
    event_decay_tau_hours: float = 24.0

    # Health status thresholds
    threshold_healthy: float = 0.8
    threshold_degraded: float = 0.5

    # Component weights for overall score
    weights: dict[str, float] = field(
        default_factory=lambda: {
            "gpu": 0.35,
            "memory": 0.20,
            "interconnect": 0.20,
            "host": 0.15,
            "software": 0.10,
        }
    )


@dataclass(frozen=True)
class StreamingConfig:
    """Configuration for metrics streaming."""

    endpoint: str | None = None  # Remote endpoint for streaming metrics
    interval_seconds: int = 30
    batch_size: int = 10
    auth_token: str | None = None
    log_dir: Path = field(default_factory=lambda: Path.home() / ".flow" / "metrics")


@dataclass(frozen=True)
class StorageConfig:
    """Configuration for local metrics storage."""

    base_path: Path = field(default_factory=lambda: Path.home() / ".flow" / "metrics")
    retention_days: int = 7
    compress_after_days: int = 1


@dataclass(frozen=True)
class HealthConfig:
    """Main configuration for the health monitoring subsystem.

    Combines all sub-configurations into a single immutable object.
    """

    gpud: GPUdConfig = field(default_factory=GPUdConfig)
    scoring: ScoringConfig = field(default_factory=ScoringConfig)
    streaming: StreamingConfig = field(default_factory=StreamingConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)


# Default configuration instance
DEFAULT_CONFIG = HealthConfig()

# Convenience constants derived from default config
DEFAULT_GPUD_PORT: int = DEFAULT_CONFIG.gpud.port
DEFAULT_GPUD_VERSION: str = DEFAULT_CONFIG.gpud.version
DEFAULT_GPUD_BIND: str = DEFAULT_CONFIG.gpud.bind_address
DEFAULT_HEALTH_ENDPOINTS: tuple[str, ...] = DEFAULT_CONFIG.gpud.health_endpoints
DEFAULT_TIMEOUT: float = DEFAULT_CONFIG.gpud.timeout_seconds


__all__ = [
    "DEFAULT_CONFIG",
    "DEFAULT_GPUD_BIND",
    "DEFAULT_GPUD_PORT",
    "DEFAULT_GPUD_VERSION",
    "DEFAULT_HEALTH_ENDPOINTS",
    "DEFAULT_TIMEOUT",
    "GPUdConfig",
    "HealthConfig",
    "ScoringConfig",
    "StorageConfig",
    "StreamingConfig",
]
