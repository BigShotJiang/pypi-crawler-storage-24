"""SSH and GPUd connectivity probes for health monitoring.

Measures node reachability and latency using the existing SSH transport stack.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


@dataclass
class ConnectivityResult:
    """Result of a connectivity probe."""

    ssh_reachable: bool
    ssh_latency_ms: float | None
    gpud_reachable: bool
    gpud_latency_ms: float | None
    timestamp: datetime


class ConnectivityProbe:
    """Probes node connectivity using the existing SSH transport stack."""

    def probe(
        self,
        host: str,
        port: int = 22,
        gpud_port: int = 15132,
    ) -> ConnectivityResult:
        """Probe SSH and GPUd reachability for a host.

        Args:
            host: Hostname or IP to probe.
            port: SSH port.
            gpud_port: GPUd HTTPS port.

        Returns:
            ConnectivityResult with reachability and latency data.
        """
        from flow.core.ssh import tcp_port_open

        ssh_reachable = False
        ssh_latency_ms = None
        gpud_reachable = False
        gpud_latency_ms = None

        # Probe SSH
        start = time.monotonic()
        try:
            ssh_reachable = tcp_port_open(host, port, timeout_sec=5.0)
            elapsed = time.monotonic() - start
            if ssh_reachable:
                ssh_latency_ms = elapsed * 1000.0
        except Exception as e:  # noqa: BLE001
            logger.debug(f"SSH probe to {host}:{port} failed: {e}")

        # Probe GPUd endpoint
        start = time.monotonic()
        try:
            gpud_reachable = tcp_port_open(host, gpud_port, timeout_sec=5.0)
            elapsed = time.monotonic() - start
            if gpud_reachable:
                gpud_latency_ms = elapsed * 1000.0
        except Exception as e:  # noqa: BLE001
            logger.debug(f"GPUd probe to {host}:{gpud_port} failed: {e}")

        return ConnectivityResult(
            ssh_reachable=ssh_reachable,
            ssh_latency_ms=ssh_latency_ms,
            gpud_reachable=gpud_reachable,
            gpud_latency_ms=gpud_latency_ms,
            timestamp=datetime.now(timezone.utc),
        )


__all__ = ["ConnectivityProbe", "ConnectivityResult"]
