"""Handles command execution on the dev VM (direct and containerized)."""

from __future__ import annotations

import json
import logging
import os
import shlex
from typing import TYPE_CHECKING, Any, Protocol

from flow.application.dev.models import ContainerInfo, ContainerStatus
from flow.core.docker import DockerConfig

if TYPE_CHECKING:
    from flow.sdk.models import Task

logger = logging.getLogger(__name__)


def sanitize_env_name(name: str | None) -> str:
    """Normalize a container environment name for safe path usage.

    Strips whitespace, slashes, and rejects shell metacharacters to prevent
    injection when the name is interpolated into shell commands.
    """
    raw = (name or "").strip()
    if raw.lower() == "default":
        return "default"
    cleaned = raw.strip("/").strip()
    if not cleaned:
        return "env"
    # Reject shell metacharacters to prevent injection in shell commands.
    _UNSAFE_CHARS = set(";|&$`\\!#(){}[]<>?*~'\"\n\r\t")
    if _UNSAFE_CHARS.intersection(cleaned):
        safe = "".join(c for c in cleaned if c not in _UNSAFE_CHARS)
        if not safe:
            return "env"
        cleaned = safe
    return cleaned


class OutputSink(Protocol):
    """Interface for output display (Rich console, logger, etc.)."""

    def print(self, *args: Any, **kwargs: Any) -> None: ...


class _LoggerSink:
    """Fallback sink that logs output instead of printing to console."""

    def print(self, *args: Any, **kwargs: Any) -> None:
        msg = " ".join(str(a) for a in args)
        logger.info(msg)


class DevContainerExecutor:
    """Executes commands in containers on the dev VM."""

    def __init__(self, flow_client: Any, vm_task: Task, console: OutputSink | None = None):
        """Initialize container executor.

        Args:
            flow_client: Flow SDK client
            vm_task: The dev VM task object
            console: Output sink for user-facing messages. Defaults to logger.
        """
        self.flow_client = flow_client
        self.vm_task = vm_task
        self.container_prefix = "flow-dev-exec"
        self._console: OutputSink = console or _LoggerSink()

    def execute_command(
        self,
        command: str,
        image: str | None = None,
        interactive: bool = False,
        env_name: str = "default",
    ) -> int:
        """Execute command on the dev VM.

        Default environment runs directly on VM (no containers).
        Named environments use containers for isolation.

        Args:
            command: Command to execute
            image: Docker image to use (forces container for default env)
            interactive: Whether to run interactively
            env_name: Named environment (default: "default")

        Returns:
            Exit code of the command
        """
        try:
            remote_ops = self.flow_client.get_remote_operations()
        except (AttributeError, NotImplementedError):
            self._console.print("[error]Error: Provider doesn't support remote operations[/error]")
            return 1

        if env_name == "default" and not image:
            return self._execute_direct(command, interactive, remote_ops)
        return self._execute_containerized(command, image, interactive, env_name, remote_ops)

    def _execute_direct(self, command: str, interactive: bool, remote_ops: Any) -> int:
        logger.info(f"Executing directly on VM: {command[:50]}...")

        if interactive:
            try:
                remote_ops.open_shell(self.vm_task.task_id, command=command)
                return 0
            except Exception as e:  # noqa: BLE001
                self._console.print(f"[error]Error: {e}[/error]")
                return 1
        else:
            try:
                from flow.errors import RemoteExecutionError

                output = remote_ops.execute_command(self.vm_task.task_id, command)
                if output:
                    self._console.print(output, end="")
                return 0
            except RemoteExecutionError as e:
                self._console.print(f"[error]Command failed: {e}[/error]")
                return 1
            except Exception as e:  # noqa: BLE001
                self._console.print(f"[error]Error: {e}[/error]")
                return 1

    def _execute_containerized(
        self, command: str, image: str | None, interactive: bool, env_name: str, remote_ops: Any
    ) -> int:
        import posixpath as _pp

        from flow.utils.paths import DEV_ENVS_ROOT, DEV_HOME_DIR, WORKSPACE_DIR

        container_name = f"{self.container_prefix}-{os.urandom(3).hex()}"

        if not image:
            image = os.environ.get("FLOW_DEV_CONTAINER_IMAGE", "ubuntu:22.04")

        validation_error = DockerConfig.validate_image_reference(image)
        if validation_error:
            self._console.print(f"[error]Error: {validation_error}[/error]")
            return 1

        env = sanitize_env_name(env_name)
        env_dir = _pp.join(DEV_ENVS_ROOT, env)
        setup_env_cmd = f"mkdir -p {env_dir}"
        try:
            remote_ops.execute_command(self.vm_task.task_id, setup_env_cmd)
        except Exception as e:  # noqa: BLE001
            if env_name != "default":
                self._console.print(
                    f"[error]Failed to create environment directory '{env_dir}': {e}[/error]"
                )
                return 1
            logger.warning("Failed to create env directory (default): %s", e)

        docker_args: list[str] = [
            "docker",
            "run",
            "--rm",
            "--name",
            container_name,
            "-v",
            f"{env_dir}:{WORKSPACE_DIR}",
            "-v",
            f"{DEV_HOME_DIR}:/shared:ro",
            "-w",
            WORKSPACE_DIR,
            "-e",
            f"HOME={WORKSPACE_DIR}",
            "--pull",
            "missing",
        ]

        docker_args.extend(
            [
                "-e",
                "FLOW_DEV_CONTAINER=true",
                "-e",
                f"FLOW_DEV_USER={os.environ.get('USER', 'default')}",
            ]
        )

        # Add GPU support if NVIDIA runtime is available
        try:
            gpu_runtime_check = "docker info --format '{{json .Runtimes}}' | grep -q nvidia"
            remote_ops.execute_command(self.vm_task.task_id, gpu_runtime_check)
            docker_args.extend(["--gpus", "all"])
        except Exception:  # noqa: BLE001
            pass

        if interactive:
            docker_args.extend(["-it"])

        docker_args.append(image)
        docker_args.extend(["bash", "-lc", command])

        docker_cmd = " ".join(shlex.quote(arg) for arg in docker_args)

        if interactive:
            try:
                remote_ops.open_shell(self.vm_task.task_id, command=docker_cmd)
                return 0
            except Exception as e:  # noqa: BLE001
                self._console.print(f"[error]Error: {e}[/error]")
                return 1
        else:
            try:
                from flow.errors import RemoteExecutionError

                # Ensure image availability
                logger.debug(f"Checking Docker image availability: {image}")
                try:
                    pull_output = remote_ops.execute_command(
                        self.vm_task.task_id,
                        f"docker image inspect {image} >/dev/null 2>&1 || docker pull {image}",
                    )
                    if pull_output and "Pulling from" in pull_output:
                        self._console.print(f"Pulling Docker image: {image}")
                        logger.info(f"Pulling Docker image: {image}")
                except RemoteExecutionError as e:
                    logger.debug(f"Image pull failed (may use cache): {e}")

                logger.info(f"Executing container command: {command[:50]}...")
                output = remote_ops.execute_command(self.vm_task.task_id, docker_cmd)
                if output:
                    self._console.print(output, end="")
                logger.debug("Command executed successfully")
                return 0
            except RemoteExecutionError as e:
                error_msg = str(e)
                if "unable to find image" in error_msg.lower():
                    self._console.print(
                        f"[error]Docker image '{image}' not found and could not be pulled[/error]"
                    )
                    self._console.print(
                        "[warning]Tip: Check image name or ensure internet connectivity on the dev VM[/warning]"
                    )
                elif "docker: command not found" in error_msg.lower():
                    self._console.print("[error]Docker is not installed on the dev VM[/error]")
                    self._console.print(
                        "[warning]Tip: SSH into the VM and install Docker first[/warning]"
                    )
                else:
                    self._console.print(f"[error]Command failed: {e}[/error]")
                return 1
            except Exception as e:  # noqa: BLE001
                self._console.print(f"[error]Error: {e}[/error]")
                return 1

    def reset_containers(self) -> None:
        try:
            remote_ops = self.flow_client.get_remote_operations()
        except (AttributeError, NotImplementedError):
            self._console.print("[error]Error: Provider doesn't support remote operations[/error]")
            return

        cleanup_commands = [
            f"docker ps -q -f name={self.container_prefix} | xargs -r docker stop",
            f"docker ps -a -q -f name={self.container_prefix} | xargs -r docker rm -f",
        ]

        for cmd in cleanup_commands:
            try:
                from flow.errors import RemoteExecutionError

                remote_ops.execute_command(self.vm_task.task_id, cmd)
            except RemoteExecutionError as e:
                if "requires at least 1 argument" not in str(e):
                    self._console.print(f"[warning]Warning during cleanup: {e}[/warning]")
            except Exception as e:  # noqa: BLE001
                self._console.print(f"[warning]Warning during cleanup: {e}[/warning]")

    def get_container_status(self) -> ContainerStatus:
        try:
            remote_ops = self.flow_client.get_remote_operations()
        except (AttributeError, NotImplementedError):
            return {"active_containers": 0, "containers": []}

        list_cmd = f"docker ps -f name={self.container_prefix} --format '{{{{json .}}}}'"

        try:
            from flow.errors import RemoteExecutionError

            output = remote_ops.execute_command(self.vm_task.task_id, list_cmd)

            containers: list[ContainerInfo] = []
            if output:
                for line in output.strip().split("\n"):
                    if line:
                        try:
                            containers.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass

            return {"active_containers": len(containers), "containers": containers}
        except RemoteExecutionError:
            return {"active_containers": 0, "containers": []}
        except Exception:  # noqa: BLE001
            return {"active_containers": 0, "containers": []}
