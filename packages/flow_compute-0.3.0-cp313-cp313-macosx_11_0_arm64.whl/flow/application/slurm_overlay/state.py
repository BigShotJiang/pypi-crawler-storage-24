"""Local state persistence for Slurm overlay clusters.

Stores cluster state in ~/.flow/slurm_clusters.json so clusters survive
terminal restarts. This is the simplest reliable approach until provider
metadata API support is available.

Includes file locking to prevent concurrent access issues when multiple
processes modify cluster state simultaneously.
"""

from __future__ import annotations

import fcntl
import json
import logging
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Literal

from flow.sdk.models.slurm_overlay import SlurmOverlayState

logger = logging.getLogger(__name__)

# Valid cluster status values
VALID_STATUSES: set[Literal["creating", "ready", "degraded", "dissolving"]] = {
    "creating",
    "ready",
    "degraded",
    "dissolving",
}

# Lock timeout in seconds
LOCK_TIMEOUT = 30


class LockTimeoutError(Exception):
    """Timeout while waiting for file lock."""

    pass


class ClusterStateStore:
    """Persistent storage for Slurm overlay cluster state.

    Stores cluster state in a local JSON file. Thread-safe via file locking
    and atomic writes.
    """

    DEFAULT_PATH = Path.home() / ".flow" / "slurm_clusters.json"

    def __init__(self, path: Path | None = None, lock_timeout: int = LOCK_TIMEOUT):
        """Initialize the state store.

        Args:
            path: Custom path for state file. Defaults to ~/.flow/slurm_clusters.json
            lock_timeout: Timeout in seconds for acquiring file lock.
        """
        self._path = path or self.DEFAULT_PATH
        self._lock_path = self._path.with_suffix(".lock")
        self._lock_timeout = lock_timeout
        self._ensure_directory()

    def _ensure_directory(self) -> None:
        """Create parent directory if it doesn't exist."""
        self._path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def _file_lock(self, exclusive: bool = True) -> Iterator[None]:
        """Acquire file lock for safe concurrent access.

        Args:
            exclusive: If True, acquire exclusive lock (for writes).
                      If False, acquire shared lock (for reads).

        Yields:
            None when lock is acquired.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        lock_mode = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
        start_time = time.monotonic()

        # Create lock file if it doesn't exist
        self._lock_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self._lock_path, "a") as lock_file:
            while True:
                try:
                    # Try non-blocking lock first
                    fcntl.flock(lock_file.fileno(), lock_mode | fcntl.LOCK_NB)
                    try:
                        yield
                    finally:
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                    return
                except BlockingIOError:
                    # Lock is held by another process
                    elapsed = time.monotonic() - start_time
                    if elapsed >= self._lock_timeout:
                        raise LockTimeoutError(
                            f"Could not acquire lock on {self._lock_path} "
                            f"within {self._lock_timeout}s"
                        )
                    # Wait a bit before retrying
                    time.sleep(0.1)

    def _load_raw(self) -> dict[str, Any]:
        """Load raw state from disk (caller should hold lock)."""
        if not self._path.exists():
            return {"clusters": {}, "version": 1}
        try:
            return json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load state file, starting fresh: {e}")
            return {"clusters": {}, "version": 1}

    def _save_raw(self, data: dict[str, Any]) -> None:
        """Save raw state to disk atomically (caller should hold lock)."""
        # Write to temp file then rename for atomicity
        temp_path = self._path.with_suffix(".tmp")
        temp_path.write_text(json.dumps(data, indent=2, default=str))
        temp_path.rename(self._path)

    def save(self, state: SlurmOverlayState) -> None:
        """Save or update cluster state.

        Args:
            state: Cluster state to persist.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=True):
            data = self._load_raw()
            data["clusters"][state.name] = state.model_dump(mode="json")
            self._save_raw(data)
        logger.debug(f"Saved cluster state: {state.name}")

    def get(self, name: str) -> SlurmOverlayState | None:
        """Get cluster state by name.

        Args:
            name: Cluster name.

        Returns:
            Cluster state, or None if not found.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=False):
            data = self._load_raw()
            cluster_data = data.get("clusters", {}).get(name)
            if cluster_data:
                return SlurmOverlayState(**cluster_data)
            return None

    def delete(self, name: str) -> bool:
        """Delete cluster state.

        Args:
            name: Cluster name to delete.

        Returns:
            True if deleted, False if not found.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=True):
            data = self._load_raw()
            if name in data.get("clusters", {}):
                del data["clusters"][name]
                self._save_raw(data)
                logger.debug(f"Deleted cluster state: {name}")
                return True
            return False

    def list_all(self) -> list[SlurmOverlayState]:
        """List all stored cluster states.

        Returns:
            List of cluster states.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=False):
            data = self._load_raw()
            clusters = []
            for name, cluster_data in data.get("clusters", {}).items():
                try:
                    clusters.append(SlurmOverlayState(**cluster_data))
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Failed to load cluster {name}: {e}")
            return clusters

    def update_status(self, name: str, status: str) -> SlurmOverlayState | None:
        """Update cluster status.

        Args:
            name: Cluster name.
            status: New status value. Must be one of: creating, ready, degraded, dissolving.

        Returns:
            Updated state, or None if cluster not found.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
            ValueError: If status is not a valid value.
        """
        if status not in VALID_STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_STATUSES))}"
            )

        with self._file_lock(exclusive=True):
            data = self._load_raw()
            cluster_data = data.get("clusters", {}).get(name)
            if cluster_data:
                cluster_data["status"] = status
                self._save_raw(data)
                return SlurmOverlayState(**cluster_data)
            return None

    def add_worker(
        self,
        name: str,
        worker_fid: str,
        worker_ip: str,
    ) -> SlurmOverlayState | None:
        """Add a worker to cluster state.

        Args:
            name: Cluster name.
            worker_fid: Worker instance FID.
            worker_ip: Worker private IP.

        Returns:
            Updated state, or None if cluster not found.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=True):
            data = self._load_raw()
            cluster_data = data.get("clusters", {}).get(name)
            if cluster_data:
                worker_fids = cluster_data.get("worker_fids", [])
                if worker_fid not in worker_fids:
                    worker_fids.append(worker_fid)
                    cluster_data["worker_fids"] = worker_fids
                worker_ips = cluster_data.get("worker_ips", {})
                worker_ips[worker_fid] = worker_ip
                cluster_data["worker_ips"] = worker_ips
                self._save_raw(data)
                return SlurmOverlayState(**cluster_data)
            return None

    def remove_worker(self, name: str, worker_fid: str) -> SlurmOverlayState | None:
        """Remove a worker from cluster state.

        Args:
            name: Cluster name.
            worker_fid: Worker instance FID to remove.

        Returns:
            Updated state, or None if cluster not found.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=True):
            data = self._load_raw()
            cluster_data = data.get("clusters", {}).get(name)
            if cluster_data:
                worker_fids = cluster_data.get("worker_fids", [])
                if worker_fid in worker_fids:
                    worker_fids.remove(worker_fid)
                    cluster_data["worker_fids"] = worker_fids
                worker_ips = cluster_data.get("worker_ips", {})
                if worker_fid in worker_ips:
                    del worker_ips[worker_fid]
                    cluster_data["worker_ips"] = worker_ips
                self._save_raw(data)
                return SlurmOverlayState(**cluster_data)
            return None

    def exists(self, name: str) -> bool:
        """Check if cluster exists in state store.

        Args:
            name: Cluster name.

        Returns:
            True if cluster exists.

        Raises:
            LockTimeoutError: If lock cannot be acquired within timeout.
        """
        with self._file_lock(exclusive=False):
            data = self._load_raw()
            return name in data.get("clusters", {})


# Thread-safe singleton management
_singleton_lock = threading.Lock()
_default_store: ClusterStateStore | None = None


def get_state_store() -> ClusterStateStore:
    """Get the default state store instance (thread-safe singleton)."""
    global _default_store
    if _default_store is None:
        with _singleton_lock:
            # Double-check after acquiring lock
            if _default_store is None:
                _default_store = ClusterStateStore()
    return _default_store
