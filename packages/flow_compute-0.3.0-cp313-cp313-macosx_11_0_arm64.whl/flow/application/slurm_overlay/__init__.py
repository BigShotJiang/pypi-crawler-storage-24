"""Slurm overlay cluster orchestration.

This module provides the core logic for creating, managing, and dissolving
Slurm overlay clusters on existing Flow instances.
"""

from flow.application.slurm_overlay.exceptions import (
    ClusterExistsError,
    InstanceNotFoundError,
    InstanceNotReadyError,
    RegionMismatchError,
    SlurmOverlayError,
    SSHExecutionError,
)
from flow.application.slurm_overlay.hardware import GPUInfo
from flow.application.slurm_overlay.health import ClusterHealthReport, NodeHealth
from flow.application.slurm_overlay.orchestrator import SlurmOverlayOrchestrator
from flow.application.slurm_overlay.ssh_ops import ResolvedInstance

__all__ = [
    "ClusterExistsError",
    "ClusterHealthReport",
    "GPUInfo",
    "InstanceNotFoundError",
    "InstanceNotReadyError",
    "NodeHealth",
    "RegionMismatchError",
    "ResolvedInstance",
    "SSHExecutionError",
    "SlurmOverlayError",
    "SlurmOverlayOrchestrator",
]
