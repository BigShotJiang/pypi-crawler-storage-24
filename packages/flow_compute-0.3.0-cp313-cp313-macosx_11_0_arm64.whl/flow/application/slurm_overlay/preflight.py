"""Preflight validation for Slurm overlay cluster operations.

Validates that instances are ready for overlay cluster membership before
attempting any setup. This catches common issues early and provides
actionable error messages.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from flow.application.slurm_overlay.ssh_ops import ResolvedInstance


class SSHRunner(Protocol):
    """Protocol for SSH command execution on instances."""

    def __call__(
        self,
        instance: ResolvedInstance,
        command: str,
        timeout: int = 300,
    ) -> str:
        """Execute command on instance via SSH.

        Args:
            instance: Target instance with SSH credentials.
            command: Shell command to execute.
            timeout: Maximum execution time in seconds.

        Returns:
            Command stdout.

        Raises:
            SSHExecutionError: If command fails or times out.
        """
        ...


logger = logging.getLogger(__name__)


@dataclass
class PreflightCheck:
    """Result of a single preflight check."""

    name: str
    passed: bool
    message: str
    instance: str = ""
    details: str = ""


@dataclass
class PreflightResult:
    """Aggregated preflight validation results."""

    checks: list[PreflightCheck] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """True if all checks passed."""
        return all(c.passed for c in self.checks)

    @property
    def failed_checks(self) -> list[PreflightCheck]:
        """List of failed checks."""
        return [c for c in self.checks if not c.passed]

    def add(self, check: PreflightCheck) -> None:
        """Add a check result."""
        self.checks.append(check)

    def summary(self) -> str:
        """Human-readable summary of results."""
        passed = sum(1 for c in self.checks if c.passed)
        total = len(self.checks)
        status = "PASSED" if self.passed else "FAILED"

        lines = [f"Preflight validation {status} ({passed}/{total} checks)"]

        if not self.passed:
            lines.append("\nFailed checks:")
            for check in self.failed_checks:
                lines.append(f"  ✗ [{check.instance}] {check.name}: {check.message}")
                if check.details:
                    lines.append(f"    {check.details}")

        return "\n".join(lines)


class PreflightValidationError(Exception):
    """Preflight validation failed."""

    def __init__(self, result: PreflightResult):
        self.result = result
        super().__init__(result.summary())


class PreflightValidator:
    """Validates instances are ready for Slurm overlay operations.

    Performs a series of checks before cluster creation:
    1. SSH connectivity - can we connect?
    2. Root access - does sudo work?
    3. Network reachability - can controller reach workers?
    4. GPU availability - is nvidia-smi working?
    """

    def __init__(self, ssh_runner: SSHRunner):
        """Initialize with an SSH command runner.

        Args:
            ssh_runner: Callable that runs SSH commands on instances.
        """
        self._run_ssh = ssh_runner

    def validate_for_create(
        self,
        controller: ResolvedInstance,
        workers: list[ResolvedInstance],
    ) -> PreflightResult:
        """Validate all instances for cluster creation.

        Args:
            controller: Resolved controller instance.
            workers: List of resolved worker instances.

        Returns:
            PreflightResult with all check results.

        Raises:
            PreflightValidationError: If any critical check fails.
        """
        result = PreflightResult()

        # Check controller first
        self._validate_instance(controller, result, is_controller=True)

        # Check all workers
        for worker in workers:
            self._validate_instance(worker, result, is_controller=False)

        # Check network connectivity from controller to workers
        if workers:
            self._validate_network_connectivity(controller, workers, result)

        if not result.passed:
            raise PreflightValidationError(result)

        return result

    def _validate_instance(
        self,
        instance: ResolvedInstance,
        result: PreflightResult,
        is_controller: bool,
    ) -> None:
        """Validate a single instance."""
        role = "controller" if is_controller else "worker"
        logger.info(f"Validating {role} {instance.name}...")

        # Check SSH connectivity
        result.add(self._check_ssh_connectivity(instance))

        # Check root access (required for package installation)
        result.add(self._check_root_access(instance))

        # Check GPU availability
        result.add(self._check_gpu_availability(instance))

    def _check_ssh_connectivity(self, instance: ResolvedInstance) -> PreflightCheck:
        """Check SSH connectivity to instance."""
        try:
            output = self._run_ssh(instance, "echo 'ssh-ok'", timeout=30)
            if "ssh-ok" in output:
                return PreflightCheck(
                    name="SSH connectivity",
                    passed=True,
                    message="SSH connection successful",
                    instance=instance.name,
                )
            return PreflightCheck(
                name="SSH connectivity",
                passed=False,
                message="SSH connected but output unexpected",
                instance=instance.name,
                details=f"Expected 'ssh-ok', got: {output[:100]}",
            )
        except Exception as e:  # noqa: BLE001
            return PreflightCheck(
                name="SSH connectivity",
                passed=False,
                message="SSH connection failed",
                instance=instance.name,
                details=str(e),
            )

    def _check_root_access(self, instance: ResolvedInstance) -> PreflightCheck:
        """Check sudo access works without password."""
        try:
            output = self._run_ssh(instance, "sudo -n echo 'sudo-ok'", timeout=30)
            if "sudo-ok" in output:
                return PreflightCheck(
                    name="Root access",
                    passed=True,
                    message="sudo works without password",
                    instance=instance.name,
                )
            return PreflightCheck(
                name="Root access",
                passed=False,
                message="sudo command failed",
                instance=instance.name,
                details=f"Output: {output[:100]}",
            )
        except Exception as e:  # noqa: BLE001
            return PreflightCheck(
                name="Root access",
                passed=False,
                message="sudo access check failed",
                instance=instance.name,
                details=str(e),
            )

    def _check_gpu_availability(self, instance: ResolvedInstance) -> PreflightCheck:
        """Check nvidia-smi is available and working."""
        try:
            output = self._run_ssh(
                instance,
                "nvidia-smi --query-gpu=count --format=csv,noheader 2>/dev/null || echo 'no-gpu'",
                timeout=30,
            )
            if "no-gpu" in output or not output.strip():
                return PreflightCheck(
                    name="GPU availability",
                    passed=True,  # Not having GPUs is OK (CPU-only node)
                    message="No GPUs detected (CPU-only instance)",
                    instance=instance.name,
                )

            # Got a count, verify it's reasonable
            try:
                # nvidia-smi returns one line per GPU, count them
                gpu_count = len(output.strip().split("\n"))
                return PreflightCheck(
                    name="GPU availability",
                    passed=True,
                    message=f"{gpu_count} GPU(s) detected",
                    instance=instance.name,
                )
            except (ValueError, IndexError):
                return PreflightCheck(
                    name="GPU availability",
                    passed=True,
                    message="nvidia-smi responded (count unclear)",
                    instance=instance.name,
                    details=f"Output: {output[:100]}",
                )
        except Exception as e:  # noqa: BLE001
            return PreflightCheck(
                name="GPU availability",
                passed=False,
                message="nvidia-smi check failed",
                instance=instance.name,
                details=str(e),
            )

    def _validate_network_connectivity(
        self,
        controller: ResolvedInstance,
        workers: list[ResolvedInstance],
        result: PreflightResult,
    ) -> None:
        """Validate controller can reach all workers via private IP."""
        worker_ips = [w.private_ip for w in workers]
        worker_names = {w.private_ip: w.name for w in workers}

        for ip in worker_ips:
            check = self._check_network_reachability(controller, ip, worker_names[ip])
            result.add(check)

    def _check_network_reachability(
        self,
        source: ResolvedInstance,
        target_ip: str,
        target_name: str,
    ) -> PreflightCheck:
        """Check source can reach target via private IP."""
        try:
            # Use timeout to avoid hanging on unreachable IPs
            output = self._run_ssh(
                source,
                f"timeout 5 bash -c 'echo > /dev/tcp/{target_ip}/22' 2>&1 && echo 'reachable' || echo 'unreachable'",
                timeout=30,
            )
            status = output.strip().splitlines()[-1].strip() if output.strip() else ""
            if status == "reachable":
                return PreflightCheck(
                    name="Network reachability",
                    passed=True,
                    message=f"Can reach {target_name} ({target_ip})",
                    instance=source.name,
                )
            return PreflightCheck(
                name="Network reachability",
                passed=False,
                message=f"Cannot reach {target_name} ({target_ip})",
                instance=source.name,
                details=(
                    "Instances may be in different regions/networks. "
                    f"Probe result: {status or output.strip() or 'no output'}"
                ),
            )
        except Exception as e:  # noqa: BLE001
            return PreflightCheck(
                name="Network reachability",
                passed=False,
                message=f"Network check to {target_name} failed",
                instance=source.name,
                details=str(e),
            )
