"""Exception classes for Slurm overlay cluster operations."""

from __future__ import annotations


class SlurmOverlayError(Exception):
    """Base exception for Slurm overlay operations."""

    pass


class InstanceNotFoundError(SlurmOverlayError):
    """Instance could not be found or resolved."""

    pass


class InstanceNotReadyError(SlurmOverlayError):
    """Instance is not in a ready state for overlay operations."""

    pass


class ClusterExistsError(SlurmOverlayError):
    """Instance is already part of a cluster."""

    pass


class RegionMismatchError(SlurmOverlayError):
    """Instances are in different regions and cannot communicate."""

    def __init__(self, regions_by_instance: dict[str, str]):
        self.regions_by_instance = regions_by_instance
        regions = set(regions_by_instance.values())
        message = (
            f"Instances are in {len(regions)} different regions and cannot form a cluster.\n"
            f"Multi-node Slurm clusters require all instances to be in the same region.\n\n"
            f"Instances by region:\n"
        )
        by_region: dict[str, list[str]] = {}
        for name, region in regions_by_instance.items():
            by_region.setdefault(region, []).append(name)
        for region, names in sorted(by_region.items()):
            message += f"  {region}: {', '.join(names)}\n"
        message += "\nUse instances from the same region to create a multi-node cluster."
        super().__init__(message)


class SSHExecutionError(SlurmOverlayError):
    """SSH command execution failed."""

    def __init__(self, message: str, returncode: int, stderr: str):
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr
