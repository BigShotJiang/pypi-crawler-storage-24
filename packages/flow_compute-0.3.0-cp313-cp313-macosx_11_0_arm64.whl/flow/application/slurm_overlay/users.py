"""User identity management for Slurm overlay clusters."""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from flow.sdk.models.slurm_overlay import ClusterUser


def derive_slurm_username(user_info: dict[str, Any]) -> str:
    """Derive a valid Linux username from Flow user info.

    Priority: user_name -> email prefix -> user_id prefix.
    Linux rules: max 32 chars, lowercase alphanumeric + underscore, starts with letter.
    """
    user_name = user_info.get("user_name") or user_info.get("username")
    if user_name:
        username = re.sub(r"[^a-z0-9_]", "", str(user_name).lower())
        if username and username[0].isalpha():
            return username[:32]

    email = user_info.get("email") or user_info.get("primary_email")
    if email and "@" in str(email):
        username = re.sub(r"[^a-z0-9_]", "", str(email).split("@")[0].lower())
        if username and username[0].isalpha():
            return username[:32]

    user_id = user_info.get("fid") or user_info.get("id") or user_info.get("user_id") or "flowuser"
    username = re.sub(r"[^a-z0-9_]", "", str(user_id).lower().replace("user_", "u"))
    if not username or not username[0].isalpha():
        username = "u" + username
    return username[:32]


def ensure_unique_username(username: str, existing: set[str]) -> str:
    """Ensure username is unique by appending _N suffix if needed."""
    if username not in existing:
        return username
    for i in range(2, 100):
        candidate = f"{username[:29]}_{i}"
        if candidate not in existing:
            return candidate
    raise ValueError(f"Could not generate unique username for {username}")


def create_cluster_user(user_info: dict[str, Any], existing_usernames: set[str]) -> ClusterUser:
    """Create a ClusterUser from Flow user info with unique username."""
    username = ensure_unique_username(derive_slurm_username(user_info), existing_usernames)
    return ClusterUser(
        flow_user_id=user_info.get("fid") or user_info.get("id") or user_info.get("user_id") or "",
        flow_email=user_info.get("email") or user_info.get("primary_email"),
        linux_username=username,
        provisioned_at=datetime.now(UTC),
    )


def extract_teammates_from_response(response: Any) -> list[dict[str, Any]]:
    """Extract teammate list from API response, handling various envelope formats."""
    if isinstance(response, list):
        return response

    if isinstance(response, dict):
        for key in ("data", "teammates", "users", "members", "results", "items"):
            val = response.get(key)
            if isinstance(val, list):
                return val
            if isinstance(val, dict) and isinstance(val.get("items"), list):
                return val["items"]

    return []
