"""Health monitoring and analysis for Slurm overlay clusters.

Provides cluster health checking, node state inspection, and repair
suggestion generation as free functions and dataclasses.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Literal

from flow.application.slurm_overlay.exceptions import (
    InstanceNotFoundError,
    SSHExecutionError,
)
from flow.application.slurm_overlay.ssh_ops import (
    ResolvedInstance,
    check_service_running,
    check_ssh_reachable,
    run_ssh_command,
)
from flow.sdk.models.slurm_overlay import SlurmOverlayState

logger = logging.getLogger(__name__)


@dataclass
class NodeHealth:
    """Health status of a single node."""

    fid: str
    name: str
    role: Literal["controller", "worker"]
    ssh_reachable: bool
    slurm_running: bool
    slurm_state: str = ""  # From sinfo: idle, alloc, down, drain, etc.
    error: str = ""


@dataclass
class ClusterHealthReport:
    """Comprehensive cluster health status."""

    cluster_name: str
    overall_status: Literal["healthy", "degraded", "critical", "unknown"]

    # Node health
    controller: NodeHealth | None = None
    workers: list[NodeHealth] = field(default_factory=list)

    # Slurm status from controller
    sinfo_output: str = ""
    squeue_output: str = ""
    partition: str = ""
    nodes_total: int = 0
    nodes_available: int = 0

    # Issues and suggestions
    issues: list[str] = field(default_factory=list)
    suggested_actions: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """Human-readable summary of cluster health."""
        lines = [
            f"Cluster: {self.cluster_name}",
            f"Status: {self.overall_status.upper()}",
            "",
        ]

        if self.controller:
            ctrl_status = "reachable" if self.controller.ssh_reachable else "unreachable"
            slurm_status = "running" if self.controller.slurm_running else "stopped"
            lines.append(
                f"Controller: {self.controller.name} ({ctrl_status}, slurm {slurm_status})"
            )

        if self.workers:
            lines.append(f"Workers: {len(self.workers)}")
            for w in self.workers:
                w_status = "reachable" if w.ssh_reachable else "unreachable"
                slurm_status = "running" if w.slurm_running else "stopped"
                state = f", state={w.slurm_state}" if w.slurm_state else ""
                lines.append(f"  - {w.name}: {w_status}, slurm {slurm_status}{state}")

        if self.partition:
            lines.append(f"\nPartition: {self.partition}")
            lines.append(f"Nodes: {self.nodes_available}/{self.nodes_total} available")

        if self.issues:
            lines.append("\nIssues:")
            for issue in self.issues:
                lines.append(f"  - {issue}")

        if self.suggested_actions:
            lines.append("\nSuggested actions:")
            for action in self.suggested_actions:
                lines.append(f"  - {action}")

        return "\n".join(lines)


def get_cluster_info(controller: ResolvedInstance) -> dict[str, str]:
    """Get Slurm cluster information from the controller.

    Args:
        controller: Resolved controller instance.

    Returns:
        Dictionary with sinfo and squeue output.
    """
    sinfo = run_ssh_command(controller, "sinfo --noheader 2>/dev/null || echo 'No nodes'")
    squeue = run_ssh_command(controller, "squeue --noheader 2>/dev/null || echo 'No jobs'")

    return {
        "sinfo": sinfo.strip(),
        "squeue": squeue.strip(),
    }


def get_cluster_health(
    cluster_state: SlurmOverlayState,
    resolve_fn: Callable[[str], ResolvedInstance],
) -> ClusterHealthReport:
    """Perform comprehensive health check on a cluster.

    Args:
        cluster_state: Cluster state with configuration.
        resolve_fn: Callable to resolve instance FIDs to ResolvedInstance.

    Returns:
        ClusterHealthReport with detailed health status.
    """
    cluster_name = cluster_state.name
    partition = cluster_state.partition
    controller_fid = cluster_state.controller_fid
    worker_fids: list[str] = cluster_state.worker_fids

    report = ClusterHealthReport(
        cluster_name=cluster_name,
        overall_status="unknown",
        partition=partition,
    )

    # Check controller
    try:
        controller = resolve_fn(controller_fid)
        ctrl_reachable = check_ssh_reachable(controller)
        ctrl_slurm_running = False
        ctrl_error = ""

        if ctrl_reachable:
            ctrl_slurm_running = check_service_running(controller, "slurmctld")
            if ctrl_slurm_running:
                try:
                    report.sinfo_output = run_ssh_command(
                        controller, "sinfo 2>/dev/null", timeout=30
                    )
                    report.squeue_output = run_ssh_command(
                        controller, "squeue 2>/dev/null", timeout=30
                    )
                    parse_sinfo(report)
                except SSHExecutionError as e:
                    ctrl_error = f"Failed to get Slurm status: {e}"
        else:
            ctrl_error = "SSH connection failed"

        report.controller = NodeHealth(
            fid=controller_fid,
            name=controller.name,
            role="controller",
            ssh_reachable=ctrl_reachable,
            slurm_running=ctrl_slurm_running,
            error=ctrl_error,
        )

        if not ctrl_reachable:
            report.issues.append(f"Controller {controller.name} is unreachable")
        elif not ctrl_slurm_running:
            report.issues.append(f"slurmctld is not running on {controller.name}")

    except InstanceNotFoundError as e:
        report.issues.append(f"Controller instance not found: {e}")

    # Check workers
    for worker_fid in worker_fids:
        try:
            worker = resolve_fn(worker_fid)
            w_reachable = check_ssh_reachable(worker)
            w_slurm_running = False
            w_error = ""
            w_state = ""

            if w_reachable:
                w_slurm_running = check_service_running(worker, "slurmd")
                if report.controller and report.controller.slurm_running:
                    w_state = get_node_slurm_state(
                        resolve_fn(controller_fid),
                        worker.name,
                    )
            else:
                w_error = "SSH connection failed"

            worker_health = NodeHealth(
                fid=worker_fid,
                name=worker.name,
                role="worker",
                ssh_reachable=w_reachable,
                slurm_running=w_slurm_running,
                slurm_state=w_state,
                error=w_error,
            )
            report.workers.append(worker_health)

            if not w_reachable:
                report.issues.append(f"Worker {worker.name} is unreachable")
            elif not w_slurm_running:
                report.issues.append(f"slurmd is not running on {worker.name}")
            elif w_state and "down" in w_state.lower():
                report.issues.append(f"Worker {worker.name} is in DOWN state")

        except InstanceNotFoundError as e:
            report.issues.append(f"Worker instance {worker_fid} not found: {e}")

    report.overall_status = determine_health_status(report)
    generate_health_suggestions(report)

    return report


def get_node_slurm_state(controller: ResolvedInstance, node_name: str) -> str:
    """Get a node's state from Slurm."""
    try:
        short_name = node_name.split(".")[0]
        output = run_ssh_command(
            controller,
            f"sinfo -n {short_name} -o '%T' --noheader 2>/dev/null || echo unknown",
            timeout=10,
        )
        return output.strip()
    except (SSHExecutionError, Exception):
        return "unknown"


def parse_sinfo(report: ClusterHealthReport) -> None:
    """Parse sinfo output to extract node counts."""
    if not report.sinfo_output:
        return

    lines = report.sinfo_output.strip().split("\n")
    total = 0
    available = 0

    for line in lines:
        if not line.strip() or line.startswith("PARTITION"):
            continue
        parts = line.split()
        if len(parts) >= 4:
            try:
                nodes = int(parts[3])
                total += nodes
                state = parts[4].lower() if len(parts) > 4 else ""
                if state in ("idle", "mix", "alloc", "allocated"):
                    available += nodes
            except (ValueError, IndexError):
                pass

    report.nodes_total = total
    report.nodes_available = available


def determine_health_status(
    report: ClusterHealthReport,
) -> Literal["healthy", "degraded", "critical", "unknown"]:
    """Determine overall cluster health status."""
    if not report.controller:
        return "critical"
    if not report.controller.ssh_reachable:
        return "critical"
    if not report.controller.slurm_running:
        return "critical"

    if report.workers:
        all_workers_down = all(not w.ssh_reachable for w in report.workers)
        if all_workers_down:
            return "critical"

        some_workers_down = any(
            not w.ssh_reachable or not w.slurm_running or "down" in w.slurm_state.lower()
            for w in report.workers
        )
        if some_workers_down:
            return "degraded"

    return "healthy"


def generate_health_suggestions(report: ClusterHealthReport) -> None:
    """Generate suggested actions based on health issues."""
    if not report.controller or not report.controller.ssh_reachable:
        report.suggested_actions.append("Check if the controller instance is running: flow status")
        return

    if not report.controller.slurm_running:
        report.suggested_actions.append(
            f"Restart Slurm services: flow ssh {report.controller.name} "
            "'sudo systemctl restart munge slurmctld slurmd'"
        )

    for worker in report.workers:
        if not worker.ssh_reachable:
            report.suggested_actions.append(
                f"Check if worker {worker.name} is running, or remove it: "
                f"flow cluster remove {report.cluster_name} {worker.name}"
            )
        elif not worker.slurm_running:
            report.suggested_actions.append(
                f"Restart slurmd on {worker.name}: flow ssh {worker.name} "
                "'sudo systemctl restart munge slurmd'"
            )
        elif "down" in worker.slurm_state.lower():
            report.suggested_actions.append(
                f"Resume worker {worker.name}: flow ssh {report.controller.name if report.controller else 'controller'} "
                f"'sudo scontrol update NodeName={worker.name} State=RESUME'"
            )
