"""Bundled Claude Code skills and project guidance for flow-compute.

These files are installed into the user's project by `flow setup claude`.
"""

from __future__ import annotations

from importlib import resources
from pathlib import Path


def get_data_dir() -> Path:
    """Return the path to the bundled claude data directory."""
    return Path(str(resources.files("flow.data.claude")))
