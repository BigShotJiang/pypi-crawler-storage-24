---
name: flow
description: Complete reference for the Flow GPU compute SDK, CLI, and Mithril platform. Auto-loads when code uses `import flow`, `flow.run()`, `FlowApp`, or the `flow` CLI. Covers task submission, spot auction mechanics, preemption handling, volumes, ports, SSH, distributed training, and the full decorator API.
user-invocable: false
---

# Flow SDK, CLI, and Mithril Platform Reference

Flow (`pip install flow-compute`) is a CLI and Python SDK for running GPU workloads on the Mithril compute platform.

## Mithril Platform

Mithril is a self-serve GPU cloud. Two provisioning models:

**Spot instances** (default): Blind second-price auction evaluated every 2 minutes. You submit a limit price (max $/GPU-hr). All winners pay the highest losing bid, not their own bid. Multi-instance bids are all-or-nothing. Ties broken by bid age.

**Reservations**: Guaranteed capacity for 3 hours to 2 weeks. Full cost charged upfront. Pause credit earned for idle instances (minimum 1-hour pause). Partial return credit available (non-reversible). Paused instances restart within ~7 minutes.

### Preemption

When spot price exceeds your limit price, you get a **5-minute grace period**. The instance file `/opt/mithril/MITHRIL_SIGNAL.yml` updates with `instance_status: STATUS_PREEMPTING` and an `end_time`. The bid may be re-allocated during the grace period if market price drops (signal file is removed).

**Strategy**: Save checkpoints to persistent storage without terminating the workload. Use systemd services in startup scripts for automatic job resumption after preemption. Boot disks are preserved until bid is terminated.

### Storage on Mithril

| Type | Mount point | Preemption | Multi-attach | Max size |
|------|-------------|------------|--------------|----------|
| Ephemeral | `/mnt/local` (NVMe SSD) | Wiped on host restart, retained on VM restart | No | Instance-dependent |
| File share | `/mnt/<name>` (virtiofs) | Preserved | Yes | 32 TB |
| Block | Manual mount | Preserved | No (single-writer, corruption risk) | 32 TB |

File shares: preformatted, auto-mounted on creation, best for most use cases. Available in us-central1-b and us-central2-a (H100). Performance on 8xH100: ~5600 MB/s seq read, ~2250 MB/s seq write.

Block storage: requires quota approval (contact support@mithril.ai). Raw disk, user formats with mkfs. Cannot resize after creation.

Storage pricing: $0.08/GB/month. No charge for network ingress/egress/bandwidth.

### Ports

Open ports on instances using `foundrypf` (high ports only, >=1024):
```bash
sudo nohup foundrypf <port> >/dev/null 2>&1 &   # open
sudo foundrypf -d <port>                          # close
```
For persistence across reboots, create a systemd service with `ExecStart=/usr/local/bin/foundrypf <port>` and `Restart=always`.

### Instance Types

| Instance | GPU | VRAM | GPUs | CPUs | RAM (GB) | Ephemeral (GB) |
|----------|-----|------|------|------|----------|----------------|
| 1x A100 80GB SXM | A100 SXM | 80 GB | 1 | 26 | 190 | 1,750 |
| 2x A100 80GB SXM | A100 SXM | 80 GB | 2 | 52 | 380 | 3,500 |
| 4x A100 80GB SXM | A100 SXM | 80 GB | 4 | 102 | 760 | 7,000 |
| 8x A100 80GB SXM | A100 SXM | 80 GB | 8 | 204 | 1,520 | 14,000 |
| 8x H100 80GB SXM | H100 SXM | 80 GB | 8 | 104+ | 1,800+ | 6,400+ |
| 8x B200 192GB SXM | B200 SXM | 192 GB | 8 | 232 | 3,584 | 2,800 |

Instance naming formats: `a100`, `8xh100`, `h100-80gb.sxm.8x`, `a100-80gb.pcie.4x`. GPU types: A100, H100, L40S, B200.

### Quotas

Reservation quotas: max forward-looking reserved instance-hours per instance type. Spot quotas: max concurrent allocated instances per type. View in dashboard under Instances > Quotas. Increase via support@mithril.ai.

### Billing

Spot: billed per running hour at market rate (millisecond precision). Not billed during paused/preempted states. Reservations: full cost upfront. PAYG is default ($100 spend threshold, auto-raises). Card payments: 2.9% processing fee.

## SDK Entry Points

### One-liner
```python
import flow
task = flow.run("python train.py", gpu="H100", gpu_count=8)
task = flow.run("python train.py", instance_type="8xh100", max_price_per_hour=3.50)
```

### Client
```python
from flow import Flow, TaskConfig
with Flow() as f:
    task = f.submit(command="python train.py", gpu="H100")
    tasks = f.list_tasks(status="running")
    logs = f.logs(task.task_id, follow=True)
    f.cancel(task.task_id)
```
Sub-clients: `f.tasks`, `f.volumes`, `f.reservations`, `f.ssh`, `f.identity`, `f.instances`, `f.dev`.

### Decorator API
```python
app = flow.FlowApp()

@app.function(gpu="H100", gpu_count=8, image="pytorch/pytorch:2.2.2-cuda12.1-cudnn8-runtime")
def train(lr: float = 0.001) -> dict:
    return {"loss": 0.01}

result = train.remote(lr=0.001)                    # sync, returns result
task = train.spawn(lr=0.001)                       # async, returns Task
results = list(train.map([0.1, 0.01, 0.001]))     # parallel fan-out
results = list(train.starmap([(0.1, 32), (0.01, 64)]))  # multi-arg fan-out
```

### Class-based
```python
@app.cls(gpu="A100")
class Predictor:
    @flow.enter()       # runs once on container start
    def setup(self): self.model = load_model()
    @flow.exit()        # runs on shutdown
    def teardown(self): cleanup()
    @flow.method()      # remotely callable
    def predict(self, text: str) -> dict: return self.model(text)
```

### Image builder
```python
image = (flow.Image.debian_slim("3.11")
    .pip_install("torch", "transformers")
    .apt_install("git")
    .run_commands("echo hello")
    .env({"CUDA_VISIBLE_DEVICES": "0,1"})
    .add_local_file("weights.pt", "/model/weights.pt"))
# Also: Image.from_registry("nvcr.io/nvidia/pytorch:24.01-py3")
# Also: Image.from_dockerfile("./Dockerfile")
```

## TaskConfig Fields

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `command` | `str` | required | |
| `instance_type` | `str \| list[str]` | None | Fallback list tries each in order |
| `gpu` | `str` | None | `"H100"`, `"A100"` |
| `gpu_count` | `int` | None | |
| `min_gpu_memory_gb` | `int` | None | Capability-based selection (1-640) |
| `image` | `str \| Image` | PyTorch default | |
| `name` | `str` | `"flow-task"` | Pattern: `[a-zA-Z0-9][a-zA-Z0-9._-]*` |
| `env` | `dict[str,str]` | `{}` | |
| `volumes` | `list[VolumeSpec]` | `[]` | See Volume section |
| `ports` | `list[int]` | `[]` | High ports only (>=1024) |
| `num_instances` | `int` | `1` | Multi-node (1-100) |
| `max_price_per_hour` | `float` | None | Spot bid limit price |
| `max_run_time_hours` | `float` | None | 0 disables limit |
| `allocation_mode` | `"spot"\|"reserved"\|"auto"` | `"spot"` | |
| `region` | `str` | None | |
| `upload_code` | `bool` | `True` | |
| `terminate_on_exit` | `bool` | `False` | |
| `priority` | `"low"\|"med"\|"high"` | `"med"` | |
| `secrets` | `list[Secret]` | None | |
| `schedule` | `Cron\|Period` | None | |
| `constraints` | `Constraints` | None | Topology, region filters, interconnect |
| `distributed_mode` | `"auto"\|"manual"` | None | For num_instances > 1 |
| `internode_interconnect` | `str` | None | `"InfiniBand"`, `"IB_3200"` |
| `preemptible_ok` | `bool` | `True` | |
| `reservation_id` | `str` | None | Run on specific reservation |
| `ssh_keys` | `list[str]` | `[]` | |

## Volumes

### VolumeSpec
```python
VolumeSpec(name="data", size_gb=100, interface="block"|"file",
           mount_path="/data", create_if_missing=True,
           iops=None, throughput_mb_s=None)
```

### SDK operations
```python
vol = f.create_volume(size_gb=100, name="data", interface="block", region="us-central1-b")
f.mount_volume(vol.volume_id, task.task_id, mount_point="/data")
vols = f.list_volumes()
f.delete_volume(vol.volume_id)
```

### CLI
```bash
flow volume create --size 100 --name data --interface file
flow volume list
flow volume info <volume-id>
flow volume delete <volume-id>
flow mount <volume> <task>
```

**Key rules**: Block volumes are single-writer (cannot attach to multi-node tasks). File shares support multi-attach. Both must be in the same region as the instance. Persistent storage survives preemption and pause. Always use persistent storage for checkpoints on spot instances.

## CLI Commands

### Submission & lifecycle
```bash
flow submit train.py -i h100 --gpu-count 8 -n my-job
flow submit config.yaml
flow status                           # list tasks
flow status <task> --json             # detail
flow status --watch                   # live refresh
flow logs <task> -f                   # stream logs
flow logs <task> -n 50                # tail N lines
flow logs <task> --source startup     # startup logs (also: setup, cloud-init, host)
flow logs <task> --stream stderr      # stderr only
flow logs <task> --node 1             # multi-node: specific node
flow cancel <task>
flow cancel --all
```

### Interactive GPU access
```bash
flow grab 8 h100 --hours 4           # grab GPUs (sleep infinity + SSH)
flow grab 2 8xa100 --max-price 2.50  # 2 nodes of 8xA100, price cap
flow release <task>                   # release grabbed resources
flow ssh <task>                       # SSH into instance
flow ssh <task> -- nvidia-smi         # run remote command
flow ssh <task> --node 2              # SSH to specific node (multi-node)
flow dev                              # persistent dev VM
flow dev --gpu H100 --sync .          # dev VM with code sync
```

### Remote operations
```bash
flow upload-code <task>               # sync code to running task
flow jupyter <task>                   # Jupyter with SSH tunnel
flow colab up h100 --hours 4          # Colab-ready instance
flow ports open <task> --port 8080    # open port
flow ports list <task>
flow ports close <task> --port 8080
```

### Market & monitoring
```bash
flow pricing --gpu h100               # GPU pricing
flow pricing --json                   # machine-readable
flow availability --gpu h100          # availability by region
flow availability --json
flow health                           # system health
flow health <task>                    # GPU health for task
flow ask "cheapest 8 H100s"           # AI-powered search
```

### Infrastructure
```bash
flow volume create --size 100 --name data
flow volume list
flow ssh-key list / sync / create / delete
flow k8s list
flow reserve list / info <id>
```

### Slurm clusters
```bash
flow cluster create training -c controller-instance -w worker-1,worker-2
flow cluster list                     # list overlay clusters
flow cluster info training            # health, nodes, jobs
flow cluster ssh training             # SSH to controller
flow cluster ssh training -- squeue   # run Slurm command
flow cluster jobs training            # list recent jobs
flow cluster logs training -j 12345   # view job logs
flow cluster add training new-worker  # add worker
flow cluster remove training old-worker  # remove worker (drains jobs first)
flow cluster dissolve training        # remove Slurm, keep instances
flow cluster repair training          # auto-fix cluster issues
```

### Setup
```bash
flow setup                            # interactive credentials
flow setup --claude-code              # install Claude Code skills only
flow init                             # generate task config YAML
flow tutorial                         # guided onboarding
flow update                           # update flow-compute
```

## Task Object

Returned by `flow.run()`, `f.submit()`, `fn.spawn()`:
- Identity: `task.task_id`, `task.name`, `task.status` (TaskStatus enum)
- Actions: `task.logs()`, `task.log_stream()`, `task.wait()`, `task.cancel()`, `task.shell("cmd")`
- State: `task.is_running`, `task.is_terminal`, `task.has_ssh_access`
- Cost: `task.cost_per_hour`, `task.total_cost`
- Network: `task.ssh_host`, `task.ssh_port`, `task.public_ip`, `task.region`
- Decorator API: `task.result()` to get return value

TaskStatus: PENDING, PROVISIONING, RUNNING, PAUSED, PREEMPTING, COMPLETED, FAILED, CANCELLED.

## Multi-Node Distributed Training

```python
task = flow.run(
    "torchrun --nproc_per_node=8 train.py",
    instance_type="8xh100",
    num_instances=4,          # 4 nodes x 8 GPUs = 32 GPUs
    internode_interconnect="InfiniBand",
    constraints=Constraints(topology=Topology.CONTIGUOUS),
)
# Auto-set env vars: FLOW_RANK, FLOW_WORLD_SIZE, FLOW_MASTER_ADDR, FLOW_MASTER_PORT
```

Block storage volumes cannot attach to multi-node tasks. Use file shares or data_mounts.

## Scheduling & Secrets

```python
@app.function(gpu="A100", schedule=flow.Cron("0 9 * * 1-5"))
def daily_train(): ...

@app.function(gpu="A100", schedule=flow.Period(hours=6))
def periodic_eval(): ...

hf = flow.Secret.from_name("huggingface-token")   # env var auto-derived: HF_TOKEN
wb = flow.Secret.from_env("WANDB_API_KEY")         # pass through from local env
custom = flow.Secret.from_dict({"KEY": "val"})

@app.function(gpu="H100", secrets=[hf, wb])
def train(): ...
```

## Serverless / Web Endpoints

```python
@app.function(gpu="A100", min_containers=1, max_containers=10)
@flow.web_endpoint(method="POST")
@flow.concurrent(max_inputs=8)
async def predict(text: str) -> dict:
    return model(text)
# Deploy: flow deploy app.py
```

## Constraints

```python
Constraints(
    topology=Topology.CONTIGUOUS,        # CONTIGUOUS | SPREAD | ANY
    regions=["us-*"],                     # glob patterns
    exclude_regions=["eu-*"],
    min_interconnect_gbps=200.0,
    max_price_per_hour=3.50,
    compliance=["soc2"],
)
```

## Errors

All inherit from `FlowError`: `AuthenticationError`, `ResourceNotFoundError`, `TaskNotFoundError`, `ValidationError`, `ResourceNotAvailableError`, `QuotaExceededError`, `InsufficientBidPriceError`, `SSHNotReadyError`, `FlowTimeoutError`.

## Configuration

```bash
~/.flow/config.yaml           # config file
MITHRIL_API_KEY=...            # API key (from console.mithril.ai)
FLOW_PROVIDER=mithril          # provider selection
flow setup                     # interactive setup
```

## Installation

```bash
pip install flow-compute
pip install flow-compute[skypilot]      # multi-cloud via SkyPilot
pip install flow-compute[serverless]    # Temporal serverless
pip install flow-compute[jupyter]       # Jupyter support
```

## Live Market Intelligence

When advising users on GPU selection, bid pricing, cost estimation, or budget planning, fetch live market data first:

```bash
flow pricing --gpu <type> --json    # current prices, 7d history, win rate estimates, planning
flow availability --gpu <type> --json   # current capacity
```

The `flow pricing --json` response includes (keyed by `gpu:region`):
- `trends.<gpu:region>.trend_pct`: negative = prices declining (good time to bid)
- `uptime_estimates.<gpu:region>[]`: win rate %, estimated runtime (24h/48h/72h), and cost at various limit prices
- `planning.<gpu:region>.market_summary.confidence`: "stable" / "moderate" / "volatile"
- `planning.<gpu:region>.budget_scenarios[]`: for budgets of $250/$500/$1000/$2500, the optimal limit price and expected runtime
- `planning.<gpu:region>.runtime_scenarios[]`: for 24/48/72h runtime targets, the cheapest limit price and expected cost

Win rate estimates are based on price eligibility (% of time market price was below the limit). Actual allocation also depends on capacity and bid competition, so treat these as directional guidance, not guarantees.

When recommending limit prices, explain that users pay the clearing price (second-price auction), not their limit price. A higher limit increases win rate, not cost per hour.
