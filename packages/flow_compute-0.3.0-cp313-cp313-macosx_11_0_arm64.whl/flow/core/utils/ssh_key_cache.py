"""SSH key resolution cache for instant connections (core utility).

Caches SSH key paths for tasks to avoid repeated lookups and filesystem
searches. Follows the same ephemeral caching pattern as task indices.
"""

from __future__ import annotations

import json
import time
from pathlib import Path


class SSHKeyCache:
    """Manages cached SSH key resolutions and endpoint data.

    Stores mappings from task IDs to resolved SSH key paths and SSH
    endpoints (host/port), avoiding expensive repeated lookups.

    Key paths expire after 5 minutes. Endpoints use a longer 30-minute
    TTL because a running instance's SSH endpoint is stable until
    termination or preemption. Successful connections refresh the
    endpoint TTL.
    """

    CACHE_TTL_SECONDS = 300  # 5 minutes (key paths)
    ENDPOINT_TTL_SECONDS = 1800  # 30 minutes (SSH endpoints)

    def __init__(self, cache_dir: Path | None = None):
        """Initialize cache with optional custom directory.

        Args:
            cache_dir: Directory for cache file (defaults to ~/.flow)
        """
        self.cache_dir = cache_dir or Path.home() / ".flow"
        self.cache_file = self.cache_dir / "ssh_keys.json"

    def save_key_path(
        self,
        task_id: str,
        key_path: str,
        *,
        platform_key_ids: list[str] | None = None,
        public_key_fingerprint: str | None = None,
    ) -> None:
        """Cache a resolved SSH key path.

        Args:
            task_id: Task ID
            key_path: Resolved SSH private key path
            platform_key_ids: Platform SSH key IDs associated with the task (for validation)
            public_key_fingerprint: Optional normalized public key fingerprint
        """
        # Create directory if needed
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Load existing cache
        cache_data = self._load_cache() or {"keys": {}}

        # Update with new key
        entry = {"path": key_path, "timestamp": time.time()}
        if platform_key_ids:
            entry["platform_keys"] = platform_key_ids
        if public_key_fingerprint:
            entry["fingerprint"] = public_key_fingerprint
        cache_data["keys"][task_id] = entry

        # Clean expired entries
        self._clean_expired(cache_data)

        self._atomic_write(cache_data)

    def get_key_path(
        self,
        task_id: str,
        *,
        validate_with_platform_keys: list[str] | None = None,
        expected_fingerprint: str | None = None,
    ) -> str | None:
        """Get cached SSH key path if available.

        Args:
            task_id: Task ID to look up
            validate_with_platform_keys: If provided, ensure cached entry matches these IDs
            expected_fingerprint: If provided, ensure cached entry matches this fingerprint

        Returns:
            SSH key path or None if not cached/expired
        """
        cache_data = self._load_cache()
        if not cache_data:
            return None

        key_info = cache_data.get("keys", {}).get(task_id)
        if not key_info:
            return None

        # Check if expired
        age = time.time() - key_info.get("timestamp", 0)
        if age > self.CACHE_TTL_SECONDS:
            return None

        # Optional validation against platform keys
        if validate_with_platform_keys is not None:
            cached_platform_keys = key_info.get("platform_keys") or []
            if cached_platform_keys and not any(
                k in cached_platform_keys for k in validate_with_platform_keys
            ):
                return None

        # Optional validation against fingerprint
        if expected_fingerprint is not None:
            cached_fp = key_info.get("fingerprint")
            if cached_fp and cached_fp != expected_fingerprint:
                return None

        key_path = key_info.get("path")
        if key_path and Path(key_path).exists():
            return key_path

        return None

    def save_endpoint(self, task_id: str, host: str, port: int = 22) -> None:
        """Cache a resolved SSH endpoint for a task.

        Creates the cache entry if it doesn't exist, or updates the endpoint
        fields on an existing entry without disturbing key path data.

        Args:
            task_id: Task ID.
            host: Resolved SSH host (IP address or hostname).
            port: Resolved SSH port.
        """
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        cache_data = self._load_cache() or {"keys": {}}
        entry = cache_data["keys"].setdefault(task_id, {})
        entry["ssh_host"] = host
        entry["ssh_port"] = port
        entry["endpoint_at"] = time.time()
        self._clean_expired(cache_data)
        self._atomic_write(cache_data)

    def get_endpoint(self, task_id: str) -> tuple[str, int] | None:
        """Get cached SSH endpoint if fresh.

        Endpoint freshness is determined by the more recent of
        ``endpoint_at`` and ``last_success_at``, giving successful
        connections an implicit TTL extension.

        Args:
            task_id: Task ID to look up.

        Returns:
            ``(host, port)`` tuple or ``None`` if not cached / expired.
        """
        cache_data = self._load_cache()
        if not cache_data:
            return None
        entry = cache_data.get("keys", {}).get(task_id)
        if not entry:
            return None
        host = entry.get("ssh_host")
        port = entry.get("ssh_port")
        if not host:
            return None
        # Use the more recent of endpoint_at and last_success_at
        endpoint_at = entry.get("endpoint_at", 0)
        last_success = entry.get("last_success_at", 0)
        freshest = max(endpoint_at, last_success)
        if time.time() - freshest > self.ENDPOINT_TTL_SECONDS:
            return None
        return str(host), int(port or 22)

    def invalidate_endpoint(self, task_id: str) -> None:
        """Remove cached endpoint data for a task.

        Clears only endpoint fields (ssh_host, ssh_port, endpoint_at);
        leaves key path data intact so re-resolution only needs the
        endpoint, not the key.

        Args:
            task_id: Task ID whose endpoint should be invalidated.
        """
        cache_data = self._load_cache()
        if not cache_data:
            return
        entry = cache_data.get("keys", {}).get(task_id)
        if not entry:
            return
        for field in ("ssh_host", "ssh_port", "endpoint_at"):
            entry.pop(field, None)
        self._atomic_write(cache_data)

    def _load_cache(self) -> dict | None:
        """Load cache data if valid.

        Returns:
            Cache data dict or None if not found/invalid
        """
        if not self.cache_file.exists():
            return None

        try:
            return json.loads(self.cache_file.read_text())
        except (json.JSONDecodeError, KeyError):
            # Invalid cache file
            return None

    def _atomic_write(self, cache_data: dict) -> None:
        """Write cache data atomically via temp-file rename."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        temp_file = self.cache_file.with_suffix(".tmp")
        try:
            temp_file.write_text(json.dumps(cache_data, indent=2))
            temp_file.replace(self.cache_file)
        except BaseException:
            temp_file.unlink(missing_ok=True)
            raise

    def _clean_expired(self, cache_data: dict) -> None:
        """Remove entries where both key and endpoint data are expired.

        Args:
            cache_data: Cache data to clean (modified in place)
        """
        now = time.time()
        keys_to_remove = []

        for task_id, entry in cache_data.get("keys", {}).items():
            key_expired = (now - entry.get("timestamp", 0)) > self.CACHE_TTL_SECONDS
            endpoint_freshest = max(entry.get("endpoint_at", 0), entry.get("last_success_at", 0))
            endpoint_expired = (now - endpoint_freshest) > self.ENDPOINT_TTL_SECONDS
            # Only evict when both concerns are stale
            if key_expired and endpoint_expired:
                keys_to_remove.append(task_id)

        for task_id in keys_to_remove:
            cache_data["keys"].pop(task_id, None)

    def clear(self) -> None:
        """Clear the SSH key cache."""
        if self.cache_file.exists():
            self.cache_file.unlink()

    def mark_connection_success(self, task_id: str) -> None:
        """Record successful SSH connection for fast-path optimization.

        Updates ``last_success_at`` timestamp so subsequent connections can
        skip readiness probes when the connection was recently successful.
        This also implicitly extends the endpoint TTL since ``get_endpoint``
        uses ``max(endpoint_at, last_success_at)`` for freshness.
        """
        cache_data = self._load_cache()
        if not cache_data:
            return

        entry = cache_data.get("keys", {}).get(task_id)
        if not entry:
            return

        entry["last_success_at"] = time.time()

        self._atomic_write(cache_data)

    def was_recently_successful(self, task_id: str, ttl_seconds: float = 60.0) -> bool:
        """Check if SSH connection was successful within TTL.

        Used by fast-path to skip readiness probes when we connected recently.

        Args:
            task_id: Task ID to check
            ttl_seconds: How recent the success must be (default 60s)

        Returns:
            True if connected successfully within TTL, False otherwise
        """
        cache_data = self._load_cache()
        if not cache_data:
            return False

        key_info = cache_data.get("keys", {}).get(task_id)
        if not key_info:
            return False

        last_success = key_info.get("last_success_at")
        if last_success is None:
            return False

        age = time.time() - last_success
        return age < ttl_seconds
