"""Disk-backed pricing cache for spot market prices.

Caches spot pricing data to avoid repeated API calls across CLI invocations.
Follows the same pattern as SSHKeyCache: atomic writes, TTL-based expiration,
and fail-open semantics (cache corruption never blocks the caller).
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_CACHE_VERSION = 1


class PricingCache:
    """Manages cached spot pricing data on disk.

    Stores pricing entries keyed by ``instance_type|region`` with a 5-minute
    TTL. Each entry holds raw pricing data (cents integers) from the API.

    Cache file: ``~/.flow/pricing_cache.json``
    """

    PRICE_TTL_SECONDS = 300  # 5 minutes

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir or Path.home() / ".flow"
        self.cache_file = self.cache_dir / "pricing_cache.json"

    def get(self, instance_type: str, region: str) -> dict[str, Any] | None:
        """Look up cached pricing for an instance type and region.

        Args:
            instance_type: Provider instance type ID.
            region: Region identifier.

        Returns:
            Raw pricing dict (e.g. ``{"spot_price_cents": 2500}``) or None
            if not cached or expired.
        """
        cache_data = self._load()
        if cache_data is None:
            return None

        key = f"{instance_type}|{region}"
        entry = cache_data.get("prices", {}).get(key)
        if not entry:
            return None

        age = time.time() - entry.get("saved_at", 0)
        if age > self.PRICE_TTL_SECONDS:
            return None

        return {k: v for k, v in entry.items() if k != "saved_at"}

    def save(self, instance_type: str, region: str, data: dict[str, Any]) -> None:
        """Cache pricing data for an instance type and region.

        Args:
            instance_type: Provider instance type ID.
            region: Region identifier.
            data: Pricing dict to cache (e.g. ``{"spot_price_cents": 2500}``).
        """
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

            cache_data = self._load() or {
                "version": _CACHE_VERSION,
                "prices": {},
            }
            cache_data.setdefault("prices", {})

            key = f"{instance_type}|{region}"
            cache_data["prices"][key] = {**data, "saved_at": time.time()}

            self._clean_expired(cache_data)
            self._atomic_write(cache_data)
        except OSError:
            logger.debug("Failed to write pricing cache", exc_info=True)

    def clear(self) -> None:
        """Remove the pricing cache file."""
        try:
            if self.cache_file.exists():
                self.cache_file.unlink()
        except OSError:
            pass

    def _load(self) -> dict[str, Any] | None:
        """Load cache data from disk. Returns None on any failure."""
        if not self.cache_file.exists():
            return None
        try:
            data = json.loads(self.cache_file.read_text())
            if not isinstance(data, dict):
                return None
            if data.get("version") != _CACHE_VERSION:
                return None
            return data
        except (json.JSONDecodeError, OSError):
            return None

    def _atomic_write(self, cache_data: dict[str, Any]) -> None:
        """Write cache data atomically via temp-file rename."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        temp_file = self.cache_file.with_suffix(".tmp")
        try:
            temp_file.write_text(json.dumps(cache_data, indent=2))
            temp_file.replace(self.cache_file)
        except BaseException:
            temp_file.unlink(missing_ok=True)
            raise

    def _clean_expired(self, cache_data: dict[str, Any]) -> None:
        """Remove expired entries from cache data (modified in place)."""
        now = time.time()
        expired_keys = [
            key
            for key, entry in cache_data.get("prices", {}).items()
            if (now - entry.get("saved_at", 0)) > self.PRICE_TTL_SECONDS
        ]
        for key in expired_keys:
            cache_data["prices"].pop(key, None)
