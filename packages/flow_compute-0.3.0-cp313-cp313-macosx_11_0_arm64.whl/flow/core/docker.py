"""Centralized Docker configuration and utilities."""

import logging
import re
from enum import Enum

logger = logging.getLogger(__name__)


class DockerSystemPath(Enum):
    """Well-known Docker system paths with semantic meaning."""

    STORAGE = "/var/lib/docker"  # Docker's layer storage
    SOCKET = "/var/run/docker.sock"  # Docker daemon socket
    CONFIG = "/etc/docker"  # Docker configuration


_VALID_IMAGE_REF = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._/:@-]*$")


class DockerConfig:
    """Docker-specific configuration and validation.

    This class provides centralized Docker knowledge to prevent
    duplication and ensure consistent behavior across providers.
    """

    # Docker system paths that shouldn't be mounted inside containers
    RESTRICTED_MOUNT_PATHS: set[str] = {path.value for path in DockerSystemPath}

    @classmethod
    def is_restricted_mount(cls, path: str) -> bool:
        """Check if a path should not be mounted inside containers.

        These paths would conflict with the container's own Docker daemon
        or expose sensitive host configuration.

        Args:
            path: The mount path to check

        Returns:
            True if the path is restricted and shouldn't be mounted
        """
        return path in cls.RESTRICTED_MOUNT_PATHS

    @classmethod
    def should_mount_in_container(cls, mount_path: str) -> bool:
        """Determine if a volume should be mounted inside the container.

        This is the inverse of is_restricted_mount, provided for clearer
        intent at the call site.

        Args:
            mount_path: The path to potentially mount

        Returns:
            True if the path should be mounted in the container
        """
        return not cls.is_restricted_mount(mount_path)

    @staticmethod
    def validate_image_reference(image: str) -> str | None:
        """Validate a Docker image reference.

        Returns None if the reference is valid, or an error message string
        describing the problem.

        Rejects:
            - Empty strings
            - References starting with ``-`` (flag injection)
            - References containing shell metacharacters

        Args:
            image: Docker image reference to validate

        Returns:
            None if valid, error message string if invalid
        """
        if not image:
            return "Docker image reference must not be empty"
        if image.startswith("-"):
            return f"Docker image reference must not start with '-': {image}"
        if not _VALID_IMAGE_REF.match(image):
            return f"Docker image reference contains invalid characters: {image}"
        return None
