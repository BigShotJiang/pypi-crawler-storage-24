"""Generate and manage SSH config for known Flow tasks.

Writes ~/.flow/ssh/config with Host stanzas for running tasks,
enabling ``ssh flow-<task-name>`` at native SSH speed.
"""

from __future__ import annotations

import fcntl
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from flow.core.ssh.command import ssh_control_dir

logger = logging.getLogger(__name__)

FLOW_SSH_DIR = Path.home() / ".flow" / "ssh"
FLOW_SSH_CONFIG = FLOW_SSH_DIR / "config"

_MARKER_BEGIN = "# --- BEGIN flow-managed hosts ---"
_MARKER_END = "# --- END flow-managed hosts ---"

# Characters that are safe in SSH Host alias (alphanumeric, dash, dot, underscore)
_ALIAS_SAFE = re.compile(r"[^a-zA-Z0-9._-]")


def _sanitize_alias(name: str) -> str:
    """Convert a task name to an SSH-safe Host alias."""
    return _ALIAS_SAFE.sub("-", name).strip("-") or "task"


@dataclass(frozen=True)
class SSHHostEntry:
    """One Host stanza for an SSH config file."""

    alias: str
    hostname: str
    port: int
    user: str
    identity_file: Path
    proxyjump: str | None = None


@dataclass
class SSHConfigManager:
    """Lifecycle management for ~/.flow/ssh/config."""

    config_path: Path = field(default_factory=lambda: FLOW_SSH_CONFIG)

    def write_config(self, entries: list[SSHHostEntry]) -> None:
        """Write (overwrite) the flow-managed SSH config with given entries."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        lines: list[str] = [_MARKER_BEGIN]
        for entry in entries:
            lines.append(f"Host {entry.alias}")
            lines.append(f"    HostName {entry.hostname}")
            lines.append(f"    Port {entry.port}")
            lines.append(f"    User {entry.user}")
            lines.append(f"    IdentityFile {entry.identity_file}")
            lines.append("    IdentitiesOnly yes")
            lines.append("    StrictHostKeyChecking accept-new")
            lines.append("    ControlMaster auto")
            lines.append("    ControlPersist 60")
            lines.append(f"    ControlPath {ssh_control_dir()}/%r@%h:%p")
            if entry.proxyjump:
                lines.append(f"    ProxyJump {entry.proxyjump}")
            lines.append("")
        lines.append(_MARKER_END)

        content = "\n".join(lines) + "\n"

        with open(self.config_path, "w") as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                f.write(content)
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)

    def remove_host(self, alias: str) -> None:
        """Remove a single host stanza from the config file."""
        if not self.config_path.exists():
            return

        try:
            text = self.config_path.read_text()
        except OSError:
            return

        # Parse existing entries and filter out the target alias
        entries = self._parse_entries(text)
        entries = [e for e in entries if e.alias != alias]
        self.write_config(entries)

    def add_or_update_host(self, entry: SSHHostEntry) -> None:
        """Add or update a single host stanza, preserving others."""
        existing = []
        if self.config_path.exists():
            try:
                existing = self._parse_entries(self.config_path.read_text())
            except OSError:
                pass

        # Replace existing entry with same alias, or append
        updated = [e for e in existing if e.alias != entry.alias]
        updated.append(entry)
        self.write_config(updated)

    def ensure_include_directive(self) -> bool:
        """Add 'Include ~/.flow/ssh/config' to ~/.ssh/config if not present.

        Returns True if added, False if already present or ~/.ssh/config
        does not exist.
        """
        ssh_config = Path.home() / ".ssh" / "config"
        if not ssh_config.exists():
            return False

        include_line = f"Include {self.config_path}"
        try:
            text = ssh_config.read_text()
        except OSError:
            return False

        if include_line in text:
            return False

        # Prepend the Include directive (SSH processes Include top-down)
        new_text = f"{include_line}\n\n{text}"
        try:
            with open(ssh_config, "w") as f:
                fcntl.flock(f, fcntl.LOCK_EX)
                try:
                    f.write(new_text)
                finally:
                    fcntl.flock(f, fcntl.LOCK_UN)
        except OSError:
            return False
        return True

    def _parse_entries(self, text: str) -> list[SSHHostEntry]:
        """Parse SSHHostEntry objects from the flow-managed section."""
        entries: list[SSHHostEntry] = []

        # Extract content between markers
        begin_idx = text.find(_MARKER_BEGIN)
        end_idx = text.find(_MARKER_END)
        if begin_idx == -1 or end_idx == -1:
            return entries

        managed = text[begin_idx + len(_MARKER_BEGIN) : end_idx]

        current_alias: str | None = None
        props: dict[str, str] = {}

        for line in managed.splitlines():
            stripped = line.strip()
            if stripped.startswith("Host "):
                if current_alias and "HostName" in props:
                    entries.append(self._props_to_entry(current_alias, props))
                current_alias = stripped.split(None, 1)[1]
                props = {}
            elif current_alias and " " in stripped:
                key, _, value = stripped.partition(" ")
                props[key.strip()] = value.strip()

        # Flush last entry
        if current_alias and "HostName" in props:
            entries.append(self._props_to_entry(current_alias, props))

        return entries

    @staticmethod
    def _props_to_entry(alias: str, props: dict[str, str]) -> SSHHostEntry:
        """Convert parsed properties to an SSHHostEntry."""
        return SSHHostEntry(
            alias=alias,
            hostname=props.get("HostName", ""),
            port=int(props.get("Port", "22")),
            user=props.get("User", "ubuntu"),
            identity_file=Path(props.get("IdentityFile", "")),
            proxyjump=props.get("ProxyJump"),
        )
