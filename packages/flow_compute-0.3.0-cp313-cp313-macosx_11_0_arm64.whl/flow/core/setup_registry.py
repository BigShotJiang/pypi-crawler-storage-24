"""Registry for provider setup implementations.

Manages the mapping between provider names and their setup adapters.
"""

import os

from flow.core.setup_adapters import ProviderSetupAdapter


class SetupRegistry:
    """Registry for provider setup adapters."""

    _adapter_registry: dict[str, type[ProviderSetupAdapter]] = {}

    @classmethod
    def register_adapter(cls, provider_name: str, adapter_class: type[ProviderSetupAdapter]):
        """Register a provider setup adapter.

        Args:
            provider_name: Name of the provider
            adapter_class: Setup adapter implementation class
        """
        cls._adapter_registry[provider_name.lower()] = adapter_class

    @classmethod
    def get_adapter(cls, provider_name: str) -> ProviderSetupAdapter | None:
        """Get setup adapter for a provider.

        Args:
            provider_name: Name of the provider

        Returns:
            Setup adapter instance or None if not found
        """
        adapter_class = cls._adapter_registry.get(provider_name.lower())
        if adapter_class:
            return adapter_class()
        return None

    @classmethod
    def list_adapters(cls) -> list[str]:
        """List all providers that have registered setup adapters.

        Returns:
            List of provider names with adapters
        """
        return list(cls._adapter_registry.keys())


def register_providers():
    """Register all available provider setups."""
    import importlib

    try:
        _mod = importlib.import_module("flow.adapters.providers.builtin.mithril.setup.adapter")
        MithrilSetupAdapter = _mod.MithrilSetupAdapter
    except Exception:  # pragma: no cover - optional provider availability  # noqa: BLE001
        MithrilSetupAdapter = None  # type: ignore[assignment]

    if str(os.environ.get("FLOW_ENABLE_DEMO_ADAPTER", "")).strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }:
        try:
            from flow.core.mock_setup_adapter import MockSetupAdapter

            SetupRegistry.register_adapter("mock", MockSetupAdapter)
        except Exception:  # noqa: BLE001
            pass

    if MithrilSetupAdapter is not None:
        SetupRegistry.register_adapter("mithril", MithrilSetupAdapter)
