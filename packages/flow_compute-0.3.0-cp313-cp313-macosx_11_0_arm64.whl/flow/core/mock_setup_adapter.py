"""Mock provider setup adapter for demo and testing purposes.

Presents realistic fields so users can practice configuring projects,
regions, SSH keys, and a demo API key without touching real infrastructure.
Enabled only via FLOW_ENABLE_DEMO_ADAPTER environment variable.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from flow.core.setup_adapters import (
    ConfigField,
    FieldType,
    ProviderSetupAdapter,
    ValidationResult,
)

_DEMO_PROJECTS = [
    "post-training-team",
    "reasoning-research",
    "inference-optimization",
    "pretraining",
]

_DEMO_REGIONS = [
    "us-demo-1",
    "eu-demo-1",
    "apac-demo-1",
]


class MockSetupAdapter(ProviderSetupAdapter):
    """Demo/mock provider setup adapter with full wizard experience."""

    def get_provider_name(self) -> str:
        return "mock"

    def get_configuration_fields(self) -> list[ConfigField]:
        return [
            ConfigField(
                name="demo_api_key",
                field_type=FieldType.PASSWORD,
                required=True,
                mask_display=True,
                display_name="Demo API Key",
                help_text=(
                    "Enter any value to simulate authentication. This is NOT used "
                    "against real services. Tip: use DEMO-XXXX for tutorials."
                ),
            ),
            ConfigField(
                name="project",
                field_type=FieldType.CHOICE,
                required=True,
                display_name="Demo Project",
                help_text="Select a sample project for pre-populated examples.",
                dynamic_choices=True,
            ),
            ConfigField(
                name="region",
                field_type=FieldType.CHOICE,
                required=True,
                display_name="Default Demo Region",
                help_text="Pick a demo region for simulated capacity.",
                choices=_DEMO_REGIONS,
                dynamic_choices=False,
            ),
            ConfigField(
                name="default_ssh_key",
                field_type=FieldType.CHOICE,
                required=False,
                display_name="Default SSH Key",
                help_text=(
                    "Choose how SSH should behave in demos. Generate on Mithril "
                    "(recommended) saves the private key locally; or pick a local public key."
                ),
                dynamic_choices=True,
            ),
        ]

    def detect_existing_config(self) -> dict[str, Any]:
        try:
            from flow.application.config.manager import ConfigManager

            sources = ConfigManager().load_sources()
            cfg = sources.config_file if isinstance(sources.config_file, dict) else {}
            if (cfg.get("provider") or "").lower() == "mock":
                demo = cfg.get("demo", {}) or {}
                return {
                    "provider": "mock",
                    "project": cfg.get("project", _DEMO_PROJECTS[0]),
                    "region": cfg.get("region", _DEMO_REGIONS[0]),
                    "default_ssh_key": cfg.get("default_ssh_key", "_auto_"),
                    "demo_api_key": demo.get("api_key"),
                }
        except Exception:  # noqa: BLE001
            pass
        return {
            "provider": "mock",
            "project": _DEMO_PROJECTS[0],
            "region": _DEMO_REGIONS[0],
            "default_ssh_key": "_auto_",
        }

    def get_dynamic_choices(self, field_name: str, context: dict[str, Any]) -> list[str]:
        if field_name == "project":
            return list(_DEMO_PROJECTS)
        if field_name == "default_ssh_key":
            choices = [
                "GENERATE_SERVER|Generate on Mithril (recommended; saves key locally)",
            ]
            try:
                ssh_dir = Path.home() / ".ssh"
                if ssh_dir.exists():
                    for pub in sorted(ssh_dir.glob("*.pub")):
                        choices.append(f"local:{pub}|Local: {pub.name}")
            except Exception:  # noqa: BLE001
                pass
            return choices
        return []

    def validate_field(
        self, field_name: str, value: str, context: dict[str, Any] | None = None
    ) -> ValidationResult:
        if field_name == "project":
            ok = value in _DEMO_PROJECTS
            return ValidationResult(
                is_valid=ok,
                display_value=value,
                message=None if ok else "Unknown project",
            )
        if field_name == "region":
            ok = value in _DEMO_REGIONS
            return ValidationResult(
                is_valid=ok,
                display_value=value,
                message=None if ok else "Unknown region",
            )
        if field_name == "default_ssh_key":
            if value.startswith("local:"):
                key_path = value.split(":", 1)[1]
                p = Path(key_path).expanduser()
                if p.exists() and p.is_file():
                    return ValidationResult(
                        is_valid=True,
                        display_value=f"Local key: {p.name}",
                        processed_value=str(p),
                    )
                return ValidationResult(
                    is_valid=False,
                    display_value=None,
                    message="Local key not found",
                )
            return ValidationResult(
                is_valid=False, display_value=None, message="Unsupported key selection"
            )
        if field_name == "demo_api_key":
            if not value or not value.strip():
                return ValidationResult(
                    is_valid=False,
                    display_value=None,
                    message="Demo API key is required",
                )
            try:
                from flow.sdk.helpers.masking import mask_strict_last4

                display = mask_strict_last4(value)
            except Exception:  # noqa: BLE001
                display = "****"
            return ValidationResult(is_valid=True, display_value=display)
        return ValidationResult(is_valid=True, display_value=value)

    def save_configuration(self, config: dict[str, Any]) -> bool:
        from flow.application.config.manager import ConfigManager

        payload: dict[str, Any] = {"provider": "mock"}
        if config.get("project"):
            payload["project"] = config["project"]
        if config.get("region"):
            payload["region"] = config["region"]
        if config.get("default_ssh_key"):
            payload["default_ssh_key"] = config["default_ssh_key"]
        if config.get("demo_api_key"):
            payload["demo"] = {"api_key": config["demo_api_key"]}

        manager = ConfigManager()
        manager.save(payload)
        return True

    def verify_configuration(self, config: dict[str, Any]) -> tuple[bool, str | None]:
        return True, None
