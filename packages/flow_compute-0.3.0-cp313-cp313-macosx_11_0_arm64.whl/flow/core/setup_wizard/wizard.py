"""Orchestration for the Generic Setup Wizard.

This class coordinates rendering, input, validation, and field configuration
using the modular helpers in this package.

The wizard uses a linear flow (Step 1 of N, Step 2 of N, ...) for first-time
setup, and a summary + menu for reconfiguration of already-configured systems.
"""

from __future__ import annotations

import os
import signal
import sys
from typing import Any

from rich.console import Console

from flow.cli.utils.theme_manager import theme_manager
from flow.core.setup_adapters import FieldType, ProviderSetupAdapter
from flow.core.setup_wizard.field_configurator import configure_field
from flow.core.setup_wizard.menu_selector import interactive_menu_select
from flow.core.setup_wizard.ui_renderer import UIRenderer


class GenericSetupWizard:
    """Generic setup wizard that works with any provider adapter."""

    @staticmethod
    def _coerce_to_type(field, value):
        if field.field_type == FieldType.BOOLEAN:
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                return value.lower() in ("true", "yes", "1", "on")
            return bool(value)
        return value

    def __init__(self, console: Console, adapter: ProviderSetupAdapter):
        self.console = console
        self.adapter = adapter
        self.ui = UIRenderer(console)
        self.config: dict[str, Any] = {}
        self._config_dirty = False
        # Cache validation results to avoid re-validating unchanged values.
        # Key: (field_name, value, dependency_values_tuple)
        self._validation_cache: dict[tuple, Any] = {}

    def run(self) -> bool:
        """Run the setup wizard flow."""

        # Keyboard interrupt handler
        def keyboard_interrupt_handler(signum, frame):
            self.console.print("\n\n[warning]Setup cancelled[/warning]")
            try:
                os.system("stty sane 2>/dev/null || true")
            except Exception:  # noqa: BLE001
                pass
            sys.exit(0)

        old_handler = signal.signal(signal.SIGINT, keyboard_interrupt_handler)
        try:
            self.ui.render_welcome(self.adapter)
            self.config = self.adapter.detect_existing_config()

            if self._is_fully_configured():
                proceed = self._handle_fully_configured()
                if not proceed:
                    return False
                try:
                    if self._config_dirty and not self.adapter.save_configuration(self.config):
                        self.console.print("\n[error]Failed to save configuration[/error]")
                        return False
                    return True
                except Exception:  # noqa: BLE001
                    return True
            else:
                if not self._run_linear_flow():
                    return False

                if not self.adapter.save_configuration(self.config):
                    self.console.print("\n[error]Failed to save configuration[/error]")
                    return False
                if self._verify_configuration(self.config):
                    self.ui.render_completion(self.adapter, self.config)
                    return True
                else:
                    self.console.print(
                        "\n[warning]Setup completed but verification failed."
                        " Check your settings.[/warning]"
                    )
                    return False
        finally:
            signal.signal(signal.SIGINT, old_handler)

    # --- Linear flow (first-time setup) ---

    def _run_linear_flow(self) -> bool:
        """Walk through required fields sequentially: Step 1 of N, Step 2 of N, etc.

        ESC on any step goes back to the previous step. Auto-skips fields that
        are already configured or have a single available choice.
        """
        fields = self.adapter.get_configuration_fields()
        required_fields = [f for f in fields if f.required]
        total_steps = len(required_fields)
        self._shown_empty_choice_hint: set[str] = set()

        step_num = 0
        last_rendered_step = -1
        while step_num < len(required_fields):
            field = required_fields[step_num]

            # Auto-configure CHOICE fields with a single option (except SSH keys)
            if (
                field.field_type == FieldType.CHOICE
                and field.dynamic_choices
                and not self.config.get(field.name)
                and field.name != "default_ssh_key"
            ):
                depends_on = field.depends_on or []
                missing_deps = [d for d in depends_on if not self.config.get(d)]
                if not missing_deps:
                    choices = self.adapter.get_dynamic_choices(field.name, self.config)
                    if len(choices) == 1:
                        single_choice = choices[0]
                        choice_id = (
                            single_choice.split("|")[0] if "|" in single_choice else single_choice
                        )
                        validation_result = self.adapter.validate_field(
                            field.name, choice_id, self.config
                        )
                        if validation_result.is_valid:
                            coerced = self._coerce_to_type(field, choice_id)
                            if self.config.get(field.name) != coerced:
                                self.config[field.name] = coerced
                                self._config_dirty = True
                                fields_to_clear = [
                                    f.name
                                    for f in fields
                                    if f.depends_on and field.name in f.depends_on
                                ]
                                for f_name in fields_to_clear:
                                    self.config.pop(f_name, None)
                                self._invalidate_validation_cache_for_fields(
                                    [field.name] + fields_to_clear
                                )

            # Skip already-configured fields (show a brief confirmation)
            if self._is_field_effectively_configured(field):
                display_name = field.display_name or field.name.replace("_", " ").title()
                success = theme_manager.get_color("success")
                muted = theme_manager.get_color("muted")
                self.console.print(
                    f"[{success}]✓[/{success}] [{muted}]{display_name} already configured[/{muted}]"
                )
                step_num += 1
                continue

            # Skip fields with unmet dependencies
            if field.depends_on:
                missing_deps = [d for d in field.depends_on if not self.config.get(d)]
                if missing_deps:
                    step_num += 1
                    continue

            # Only render the step header once per step (avoid reprinting on retry)
            if step_num != last_rendered_step:
                display_name = field.display_name or field.name.replace("_", " ").title()
                self._render_step_header(step_num + 1, total_steps, display_name)
                last_rendered_step = step_num

            result = configure_field(
                console=self.console,
                adapter=self.adapter,
                field_name=field.name,
                context=self.config,
                current_config=self.config,
                coerce_fn=self._coerce_to_type,
                shown_empty_choice_hint=self._shown_empty_choice_hint,
                inline=True,
            )

            if result is None:
                # ESC pressed -- go back to previous configurable step
                if step_num > 0:
                    prev_field = required_fields[step_num - 1]
                    self.config.pop(prev_field.name, None)
                    self._invalidate_validation_cache_for_fields([prev_field.name])
                    step_num -= 1
                    last_rendered_step = -1  # Force re-render of the previous step
                continue

            # Only treat as a mutation when the value actually changed.
            if self.config.get(field.name) != result.value:
                self.config[field.name] = result.value
                self._config_dirty = True

                # Clear dependent fields when a field changes.
                fields_to_clear = [
                    f.name for f in fields if f.depends_on and field.name in f.depends_on
                ]
                for f_name in fields_to_clear:
                    self.config.pop(f_name, None)
                self._invalidate_validation_cache_for_fields([field.name] + fields_to_clear)

            step_num += 1

        return True

    def _render_step_header(self, step: int, total: int, name: str) -> None:
        """Render step progress with visual bar."""
        from flow.cli.utils.animations import progress_bar

        progress = step / total
        bar = progress_bar(progress, width=30, style="smooth")
        muted = theme_manager.get_color("muted")
        accent = theme_manager.get_color("accent")

        self.console.print()
        self.console.print(
            "  ",
            bar,
            f" [{muted}]Step {step} of {total}[/{muted}]",
            f"[{accent}]{name}[/{accent}]",
        )

    # --- Reconfiguration path (already-configured systems) ---

    def _handle_fully_configured(self) -> bool:
        """Show summary and offer verify/change/exit for already-configured systems.

        Uses a loop instead of recursion to avoid printing the summary multiple times.
        """
        from flow.cli.ui.presentation.visual_constants import get_status_display

        while True:
            # Clear stale content from previous iterations. InteractiveSelector
            # uses an alternate screen buffer; when it exits, the terminal restores
            # the main screen (including the previously-printed summary). Without
            # clearing, the old summary + new summary appear as visible duplicates.
            self.console.clear()
            self.console.print(
                f"\n{get_status_display('configured', 'All required components are configured', icon_style='check')}"
            )

            # Show current config summary
            fields = self.adapter.get_configuration_fields()
            success_color = theme_manager.get_color("success")
            for field in fields:
                if not field.required:
                    continue
                display_name = field.display_name or field.name.replace("_", " ").title()
                value = self.config.get(field.name)
                validation = self._get_validation_result(field.name, str(value or ""), self.config)
                if validation.is_valid and validation.display_value:
                    self.console.print(
                        f"  [{success_color}]✓[/{success_color}] {display_name}: "
                        f"{validation.display_value}"
                    )

            menu_options = [
                ("verify", "Verify and finish (recommended)", ""),
                ("reconfig", "Change a setting", ""),
                ("exit", "Exit now (skip verification)", ""),
            ]
            self.console.print()
            action = interactive_menu_select(
                options=menu_options,
                title="What would you like to do?",
                default_index=0,
                extra_header_html=None,
                breadcrumbs=["Flow Setup", "Complete"],
            )
            if action is None:
                action = "verify"

            if action == "verify":
                success, error = self.adapter.verify_configuration(self.config)
                if success:
                    self.console.print(
                        f"\n[{success_color}]✓ Configuration verified"
                        f" successfully![/{success_color}]"
                    )
                    return True
                self.console.print(f"\n[warning]Verification failed: {error}[/warning]")
                # Fall through to show summary again with menu

            elif action == "reconfig":
                self._reconfigure_single_field()
                # Loop back to show updated summary

            elif action == "exit":
                self.console.print("\n[dim]Exiting without verification.[/dim]")
                return True

            else:
                return True

    def _reconfigure_single_field(self) -> None:
        """Let user pick a single field to change."""
        fields = self.adapter.get_configuration_fields()
        required_fields = [f for f in fields if f.required]
        self._shown_empty_choice_hint: set[str] = set()

        field_options = []
        for field in required_fields:
            display_name = field.display_name or field.name.replace("_", " ").title()
            field_options.append((field.name, display_name, ""))
        field_options.append(("done", "Done", ""))

        choice = interactive_menu_select(
            options=field_options,
            title="Which setting would you like to change?",
            default_index=0,
            breadcrumbs=["Flow Setup", "Reconfigure"],
        )
        if choice is None or choice == "done":
            return

        result = configure_field(
            console=self.console,
            adapter=self.adapter,
            field_name=choice,
            context=self.config,
            current_config=self.config,
            coerce_fn=self._coerce_to_type,
            shown_empty_choice_hint=self._shown_empty_choice_hint,
        )
        changed = False
        if result and self.config.get(choice) != result.value:
            changed = True
            self.config[choice] = result.value
            self._config_dirty = True

            # Only clear dependent fields whose values are now invalid.
            # This prevents unnecessary re-prompts (e.g., SSH key stays valid
            # when project changes because SSH keys are account-scoped).
            dependent_fields = [f for f in fields if f.depends_on and choice in f.depends_on]
            actually_cleared: list[str] = []
            for dep_field in dependent_fields:
                old_value = self.config.get(dep_field.name)
                if old_value is None:
                    continue
                validation = self.adapter.validate_field(
                    dep_field.name, str(old_value), self.config
                )
                if not validation.is_valid:
                    self.config.pop(dep_field.name, None)
                    actually_cleared.append(dep_field.name)
            self._invalidate_validation_cache_for_fields([choice] + actually_cleared)

        if not changed:
            return

        # If clearing invalidated dependents left gaps, configure them inline
        # without step headers (which would be confusing in reconfigure context).
        for field in required_fields:
            if self._is_field_effectively_configured(field):
                continue
            if field.depends_on:
                missing_deps = [d for d in field.depends_on if not self.config.get(d)]
                if missing_deps:
                    continue
            gap_result = configure_field(
                console=self.console,
                adapter=self.adapter,
                field_name=field.name,
                context=self.config,
                current_config=self.config,
                coerce_fn=self._coerce_to_type,
                shown_empty_choice_hint=self._shown_empty_choice_hint,
                inline=True,
            )
            if gap_result is not None:
                self.config[field.name] = gap_result.value
                self._config_dirty = True

    # --- Shared helpers ---

    def _is_fully_configured(self) -> bool:
        fields = self.adapter.get_configuration_fields()
        required_fields = [f for f in fields if f.required]
        return all(self._is_field_effectively_configured(f) for f in required_fields)

    def _is_field_effectively_configured(self, field) -> bool:
        value = self.config.get(field.name)

        if field.field_type == FieldType.LINK:
            # Check dependencies first
            if field.depends_on:
                for dep in field.depends_on:
                    if not self.config.get(dep):
                        return False
            # LINK fields are validated via adapter even if there's no stored value
            validation_result = self.adapter.validate_field(
                field.name, str(value or ""), self.config
            )
            return validation_result.is_valid

        return self.adapter.is_field_configured(field.name, value)

    def _verify_configuration(self, config: dict[str, Any]) -> bool:
        from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
        from flow.cli.ui.presentation.visual_constants import format_text

        self.console.print(f"\n{format_text('title', 'Verifying Configuration')}")

        with AnimatedEllipsisProgress(self.console, "Verifying configuration", transient=True):
            try:
                success, error = self.adapter.verify_configuration(config)
            except Exception as e:  # noqa: BLE001
                success, error = False, str(e)

        if success:
            success_color = theme_manager.get_color("success")
            self.console.print(f"[{success_color}]✓ Configuration verified[/{success_color}]")
            return True
        else:
            self.console.print("[error]✗ Verification failed[/error]")
            self.console.print(f"\n[error]Error:[/error] {error}")
            return False

    def _get_validation_result(self, field_name: str, value: str, context: dict[str, Any]):
        """Return cached validation result if value and dependencies haven't changed.

        The cache key includes the values of any declared dependencies for the field
        (e.g., api_key for billing), so changing a dependency triggers re-validation.
        """
        fields_by_name = {f.name: f for f in self.adapter.get_configuration_fields()}
        field = fields_by_name.get(field_name)
        depends_on = field.depends_on if field and field.depends_on else []
        dep_items = tuple(sorted((dep, str(context.get(dep, ""))) for dep in depends_on))
        cache_key = (field_name, value, dep_items)

        if cache_key in self._validation_cache:
            return self._validation_cache[cache_key]
        result = self.adapter.validate_field(field_name, value, context)
        self._validation_cache[cache_key] = result
        return result

    def _invalidate_validation_cache_for_fields(self, field_names: list[str]) -> None:
        """Remove cached validation entries for the given fields."""
        field_names_set = set(field_names)
        keys_to_delete = [k for k in self._validation_cache if k[0] in field_names_set]
        for k in keys_to_delete:
            del self._validation_cache[k]
