"""UI rendering helpers for the setup wizard.

This module focuses on presentation (Rich Panels/Tables) and avoids any API calls.
"""

from __future__ import annotations

import os
import sys
import time
from typing import Any

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from flow.cli.ui.presentation.visual_constants import (
    SPACING,
    format_text,
    get_colors,
    get_panel_styles,
)
from flow.cli.utils.theme_manager import theme_manager
from flow.core.setup_adapters import ProviderSetupAdapter

# Block-letter "FLOW" wordmark using Unicode box-drawing characters.
# Each line is a separate string for typewriter animation.
_WORDMARK_LINES = [
    "   ███████╗██╗      ██████╗ ██╗    ██╗",
    "   ██╔════╝██║     ██╔═══██╗██║    ██║",
    "   █████╗  ██║     ██║   ██║██║ █╗ ██║",
    "   ██╔══╝  ██║     ██║   ██║██║███╗██║",
    "   ██║     ███████╗╚██████╔╝╚███╔███╔╝",
    "   ╚═╝     ╚══════╝ ╚═════╝  ╚══╝╚══╝ ",
]

# Simplified ASCII fallback for FLOW_ASCII=1 or narrow terminals.
_WORDMARK_ASCII = [
    "   FLOW",
]

# Box frame width (must accommodate the longest wordmark line + padding).
_FRAME_WIDTH = 48


def _get_version() -> str:
    """Fetch the current Flow version string."""
    try:
        from flow._version import get_version

        return get_version()
    except Exception:  # noqa: BLE001
        return "0.0.0"


def _should_skip_animation() -> bool:
    """Return True if animations should be suppressed."""
    if os.environ.get("FLOW_NO_ANIMATION"):
        return True
    if os.environ.get("FLOW_ASCII") == "1":
        return True
    if os.environ.get("CI"):
        return True
    return bool(not sys.stdout.isatty())


def _use_ascii() -> bool:
    """Return True if only ASCII characters should be used."""
    return os.environ.get("FLOW_ASCII") == "1"


def _build_framed_wordmark(version: str) -> list[str]:
    """Build the full wordmark frame as a list of lines.

    Returns the box-drawn frame with the wordmark, tagline, and version.
    """
    if _use_ascii():
        inner_w = _FRAME_WIDTH - 4  # account for "| " and " |"
        lines = [
            "+" + "=" * (_FRAME_WIDTH - 2) + "+",
            "|" + " " * (inner_w + 2) + "|",
        ]
        for wl in _WORDMARK_ASCII:
            lines.append("|" + wl.ljust(inner_w + 2) + "|")
        lines.append("|" + " " * (inner_w + 2) + "|")
        tagline = "   GPU Cloud Platform"
        ver_str = f"v{version}"
        spacer = inner_w + 2 - len(tagline) - len(ver_str)
        if spacer < 1:
            spacer = 1
        lines.append("|" + tagline + " " * spacer + ver_str + "|")
        lines.append("|" + " " * (inner_w + 2) + "|")
        lines.append("+" + "=" * (_FRAME_WIDTH - 2) + "+")
        return lines

    inner_w = _FRAME_WIDTH - 4  # account for "║ " and " ║"
    lines = [
        "  ╔" + "═" * (inner_w + 2) + "╗",
        "  ║" + " " * (inner_w + 2) + "║",
    ]
    for wl in _WORDMARK_LINES:
        padded = wl.ljust(inner_w + 2)
        lines.append(f"  ║{padded}║")
    lines.append("  ║" + " " * (inner_w + 2) + "║")

    tagline = "   GPU Cloud Platform"
    ver_str = f"v{version}"
    spacer = inner_w + 2 - len(tagline) - len(ver_str)
    if spacer < 1:
        spacer = 1
    lines.append(f"  ║{tagline}{' ' * spacer}{ver_str}║")
    lines.append("  ║" + " " * (inner_w + 2) + "║")
    lines.append("  ╚" + "═" * (inner_w + 2) + "╝")
    return lines


class UIRenderer:
    """Handles rendering of UI components for the setup wizard."""

    def __init__(self, console: Console):
        self.console = console

    def render_welcome(self, adapter: ProviderSetupAdapter) -> None:
        """Render the animated welcome screen with ASCII wordmark."""
        version = _get_version()
        frame_lines = _build_framed_wordmark(version)

        # Check terminal width for narrow-terminal fallback
        try:
            width = self.console.width or 80
        except Exception:  # noqa: BLE001
            width = 80

        if width < 50:
            # Narrow terminal: simple text fallback
            self.console.print(f"\n  [bold]Flow[/bold] v{version}")
            self.console.print("  [dim]GPU Cloud Platform[/dim]\n")
        else:
            self._animate_welcome(frame_lines)

        # Subtitle
        muted = theme_manager.get_color("muted")
        self.console.print(
            f"  [{muted}]Configure your GPU compute environment in under 60 seconds.[/{muted}]"
        )
        self.console.print()

        # Demo mode panel for mock provider
        try:
            if str(adapter.get_provider_name()).lower() == "mock":
                panel = self._create_demo_mode_panel()
                self.console.print(panel)
                self.console.print()
        except Exception:  # noqa: BLE001
            pass

    def render_completion(
        self,
        adapter: ProviderSetupAdapter,
        config: dict[str, Any],
    ) -> None:
        """Render the completion screen with a summary of configured values.

        Args:
            adapter: The provider adapter (used to get field metadata).
            config: The final configuration dictionary.
        """
        self.console.print("\n" + "─" * 50)
        self.console.print()

        success_color = theme_manager.get_color("success")
        muted = theme_manager.get_color("muted")
        accent = theme_manager.get_color("accent")

        self.console.print(f"  [{success_color}]✓ Setup complete[/{success_color}]")
        self.console.print()

        # Show configured fields as key-value summary
        fields = adapter.get_configuration_fields()
        required_fields = [f for f in fields if f.required]

        # Compute label width dynamically so all values align
        label_width = 2 + max(
            (len(f.display_name or f.name.replace("_", " ").title()) for f in required_fields),
            default=14,
        )

        for field in required_fields:
            display_name = field.display_name or field.name.replace("_", " ").title()
            value = config.get(field.name)
            if value:
                # Try to get a display-friendly value from validation
                validation = adapter.validate_field(field.name, str(value), config)
                display_value = validation.display_value if validation.display_value else str(value)
                self.console.print(
                    f"    [{muted}]{display_name:<{label_width}}[/{muted}]"
                    f"[{accent}]{display_value}[/{accent}]"
                )

        # Billing reminder if applicable
        if hasattr(adapter, "billing_not_configured") and adapter.billing_not_configured:
            link_color = theme_manager.get_color("link")
            from flow.utils.links import WebLinks

            billing_link = WebLinks.billing_settings()
            self.console.print()
            self.console.print(
                "  [warning]Remember to configure billing to use GPU resources:[/warning]"
            )
            self.console.print(f"  [{link_color}]{billing_link}[/{link_color}]")

        self.console.print()

    def _animate_welcome(self, lines: list[str]) -> None:
        """Reveal wordmark lines with typewriter animation.

        Falls back to static rendering when animations are disabled.
        """
        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")

        if _should_skip_animation():
            self.console.print()
            for line in lines:
                # Frame characters in muted, wordmark content in accent
                styled = self._style_frame_line(line, accent, muted)
                self.console.print(styled)
            self.console.print()
            return

        self.console.print()
        frame_delay = 0.04

        try:
            with Live(
                Text(""),
                console=self.console,
                transient=False,
                refresh_per_second=30,
            ) as live:
                rendered_lines: list[Text] = []
                for line in lines:
                    styled = self._style_frame_line(line, accent, muted)
                    rendered_lines.append(styled)
                    # Build combined display
                    display = Text("\n").join(rendered_lines)
                    live.update(display)
                    time.sleep(frame_delay)

                # Shimmer pass across the wordmark
                self._shimmer_pass(live, rendered_lines, lines)

        except Exception:  # noqa: BLE001
            # Fallback: just print statically if Live fails
            for line in lines:
                styled = self._style_frame_line(line, accent, muted)
                self.console.print(styled)

        self.console.print()

    def _style_frame_line(self, line: str, accent: str, muted: str) -> Text:
        """Apply styling to a single frame line.

        Frame borders get muted color, wordmark content gets accent color,
        and tagline/version text uses the default color.
        """
        result = Text()
        if not line:
            return result

        # Simple heuristic: border is the first/last few characters on interior lines
        # For top/bottom border lines (start with ╔ or ╚ or +), color the entire line muted
        stripped = line.lstrip()
        if stripped and stripped[0] in "╔╚+":
            result.append(line, style=muted)
            return result

        # For interior lines starting with ║ or |
        if stripped and stripped[0] in "║|":
            # Find the frame characters at start and end
            # Leading whitespace + frame char
            lead_ws = len(line) - len(stripped)
            result.append(line[: lead_ws + 1], style=muted)  # leading whitespace + ║

            # Content between first and last frame char
            inner = line[lead_ws + 1 : -1]

            if "█" in inner or "╗" in inner or "╝" in inner or "╔" in inner:
                # Wordmark line -- accent color
                result.append(inner, style=accent)
            else:
                # Tagline/version/blank -- default
                result.append(inner)

            result.append(line[-1], style=muted)  # trailing ║
            return result

        # Default: plain
        result.append(line)
        return result

    def _shimmer_pass(
        self,
        live: Live,
        rendered_lines: list[Text],
        raw_lines: list[str],
    ) -> None:
        """Apply a brief shimmer sweep across the wordmark text."""
        from flow.cli.utils.animations import shimmer_effect

        theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")

        # Identify which lines are wordmark lines (contain block chars)
        wordmark_indices = [i for i, line in enumerate(raw_lines) if "█" in line]
        if not wordmark_indices:
            return

        shimmer_steps = 15
        shimmer_duration = 0.04

        for step in range(shimmer_steps):
            phase = step / shimmer_steps
            new_lines: list[Text] = []
            for i, (styled, raw) in enumerate(zip(rendered_lines, raw_lines, strict=False)):
                if i in wordmark_indices:
                    # Extract the inner content and apply shimmer
                    stripped = raw.lstrip()
                    lead_ws = len(raw) - len(stripped)
                    inner = raw[lead_ws + 1 : -1]
                    shimmer_text = shimmer_effect(inner, phase, intensity=0.8)

                    result = Text()
                    result.append(raw[: lead_ws + 1], style=muted)
                    result.append_text(shimmer_text)
                    result.append(raw[-1], style=muted)
                    new_lines.append(result)
                else:
                    new_lines.append(styled)
            display = Text("\n").join(new_lines)
            live.update(display)
            time.sleep(shimmer_duration)

        # Restore original styled lines after shimmer
        display = Text("\n").join(rendered_lines)
        live.update(display)

    def _create_demo_mode_panel(self) -> Panel:
        from flow.utils.links import WebLinks

        colors = get_colors()
        panel_styles = get_panel_styles()
        bullet = f"[{colors['primary']}]•[/{colors['primary']}]"
        body_lines = [
            f"{bullet} [bold]Sandbox only — no real resources are created.[/bold]",
            f"{bullet} Provider: [accent]mock[/accent]",
            f"{bullet} Switch to real: [accent]flow setup --provider mithril[/accent] or [accent]flow demo stop[/accent]",
            f"{bullet} SSH access: Your [bold]default SSH key[/bold] lets you securely log in",
            f"{bullet} Manage keys: [link]{WebLinks.ssh_keys()}[/link]",
        ]
        return Panel(
            "\n".join(body_lines),
            title=f"{format_text('subtitle', 'DEMO MODE')}",
            title_align=panel_styles["info"]["title_align"],
            border_style=theme_manager.get_color("warning"),
            padding=panel_styles["info"]["padding"],
            width=SPACING["panel_width"],
        )
