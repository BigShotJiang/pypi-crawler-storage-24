"""Core runtime: setup, and internal utilities.

Houses provider setup/orchestration, filesystem/layout constants, and
low-level runtime helpers (e.g., mounts, packaging, Docker).

Import directly from submodules for the symbols you need:
    from flow.core.paths import WORKSPACE_DIR
"""

__all__ = [
    "DATA_ROOT",
    "DEV_ENVS_ROOT",
    "DEV_HOME_DIR",
    "EPHEMERAL_NVME_DIR",
    "RESULT_FILE",
    "S3FS_CACHE_DIR",
    "S3FS_PASSWD_FILE",
    "STARTUP_SCRIPT_PREFIX",
    "VOLUMES_ROOT",
    # Paths/constants (lightweight; safe to expose)
    "WORKSPACE_DIR",
    # Provider setup
    "ResourceTracker",
    "SetupRegistry",
    "auto_target_for_source",
    # Helpers
    "default_volume_mount_path",
    "register_providers",
]
