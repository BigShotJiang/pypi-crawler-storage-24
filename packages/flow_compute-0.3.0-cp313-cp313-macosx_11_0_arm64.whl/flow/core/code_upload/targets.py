from __future__ import annotations

import posixpath as _pp
from dataclasses import dataclass
from pathlib import Path

"""Centralized logic for deciding upload destinations across CLI and provider.

This keeps 'where code lands' consistent between `flow submit` and `flow dev`.

Conventions:
- Run (containerized): upload nested at ~/<project> by default. Mithril resolves ~
  to /home/ubuntu. Docker bind-mounts the same absolute path inside the container.
- Dev default env (host): nested by default at '~/<project>' unless flat is requested
- Dev named env (containerized): nested at '/envs/<env>/<project>' and appears at
  '/workspace/<project>' inside the container
"""


DEFAULT_WORKDIR = "/workspace"


@dataclass(frozen=True)
class UploadTargetPlan:
    """Planned upload destinations.

    remote_parent: where to create/upload on the VM
    remote_target: the concrete directory to pass to the transfer
    container_workdir: where the code will appear inside a container (if applicable)
    mode: 'flat' or 'nested'
    """

    remote_parent: str
    remote_target: str
    container_workdir: str | None
    mode: str


@dataclass(frozen=True)
class UploadTargetError(RuntimeError):
    """Error during upload target validation or creation."""

    code: str
    message: str
    remediation: str | None = None

    def __post_init__(self) -> None:
        super().__init__(self.message)


def _project_name(source_dir: Path | None) -> str:
    """Extract project name from source directory, falling back to 'project'."""
    name = (source_dir.name if isinstance(source_dir, Path) else None) or ""
    return name or "project"


def plan_for_run(
    source_dir: Path | None = None,
    working_dir: str | None = None,
    *,
    home_dir: str = "~",
) -> UploadTargetPlan:
    """Plan upload target for flow submit.

    When working_dir is explicitly set, returns a flat plan at that path.
    Otherwise, computes a nested plan at home_dir/<project>.
    """
    if working_dir is not None:
        return UploadTargetPlan(
            remote_parent=working_dir,
            remote_target=working_dir,
            container_workdir=working_dir,
            mode="flat",
        )
    project = _project_name(source_dir)
    target = _pp.join(home_dir, project)
    return UploadTargetPlan(
        remote_parent=home_dir,
        remote_target=target,
        container_workdir=target,
        mode="nested",
    )


def plan_for_dev(
    source_dir: Path,
    env_name: str = "default",
    *,
    upload_mode: str = "nested",
    parent_override: str | None = None,
) -> UploadTargetPlan:
    """Plan upload target for flow dev.

    - default env (host): '~/<project>' when nested; '~' when flat
    - named env (containerized): '/envs/<env>/<project>' when nested; '/envs/<env>' when flat
      and appears at '/workspace' or '/workspace/<project>' inside the container
    """
    # Normalize inputs
    mode = "flat" if upload_mode == "flat" else "nested"
    project_name = _project_name(source_dir)

    if env_name == "default":
        parent = parent_override or "~"
        target = _pp.join(parent, project_name) if mode == "nested" else parent
        return UploadTargetPlan(
            remote_parent=parent,
            remote_target=target,
            container_workdir=None,
            mode=mode,
        )

    # Named environment
    env_root = _pp.join("/envs", env_name)
    target = _pp.join(env_root, project_name) if mode == "nested" else env_root
    # In the container, env_root is bind-mounted at /workspace
    container_dir = _pp.join(DEFAULT_WORKDIR, project_name) if mode == "nested" else DEFAULT_WORKDIR
    return UploadTargetPlan(
        remote_parent=env_root,
        remote_target=target,
        container_workdir=container_dir,
        mode=mode,
    )


__all__ = [
    "DEFAULT_WORKDIR",
    "UploadTargetError",
    "UploadTargetPlan",
    "plan_for_dev",
    "plan_for_run",
]
