"""SSH command builder -- single source of truth.

One function to build SSH command argv lists with consistent security
posture and options. No settings imports; runtime tunables via env vars
or explicit parameters only.
"""

from __future__ import annotations

import os
from collections.abc import Iterable
from pathlib import Path
from shlex import join as shlex_join


def ssh_control_dir() -> str:
    """Return SSH control socket directory with restricted permissions.

    Uses ``~/.flow/ssh-ctl/`` with 0700 permissions to prevent symlink
    attacks that are possible with predictable ``/tmp`` paths on
    multi-user systems.
    """
    d = Path.home() / ".flow" / "ssh-ctl"
    d.mkdir(parents=True, exist_ok=True)
    d.chmod(0o700)
    return str(d)


# Canonical options for ephemeral cloud instances.
_BASE_OPTIONS: list[str] = [
    "-o",
    "StrictHostKeyChecking=no",
    "-o",
    "UserKnownHostsFile=/dev/null",
    "-o",
    "PasswordAuthentication=no",
    "-o",
    "ConnectTimeout=10",
    "-o",
    "ServerAliveInterval=10",
    "-o",
    "ServerAliveCountMax=3",
]


def build_ssh_command(
    *,
    user: str,
    host: str,
    port: int = 22,
    key_path: Path | str | None = None,
    prefix_args: Iterable[str] | None = None,
    remote_command: str | list[str] | None = None,
    use_mux: bool = True,
    known_hosts_path: str | None = None,
) -> list[str]:
    """Build a canonical SSH command argv list.

    Args:
        user: SSH username.
        host: Target hostname or IP.
        port: SSH port (default 22).
        key_path: Private key path, if any.
        prefix_args: Extra args preceding destination (e.g., ``-N -L ...``
            for tunnels, ``-J bastion`` for ProxyJump).
        remote_command: Command to execute remotely. A string is appended
            as a single shell token; a list is appended as separate tokens.
        use_mux: Enable SSH connection multiplexing (default True).
            Callers that need to disable mux for probes should pass False.
        known_hosts_path: Custom UserKnownHostsFile path. When set,
            overrides the default ``/dev/null``.
    """
    cmd: list[str] = ["ssh"]

    if prefix_args:
        cmd.extend(list(prefix_args))

    cmd.extend(["-p", str(port)])

    if key_path:
        cmd.extend(["-i", str(Path(key_path).expanduser())])
        cmd.extend(["-o", "IdentitiesOnly=yes"])

    cmd.extend(_BASE_OPTIONS)

    if known_hosts_path:
        # Override the /dev/null default already in _BASE_OPTIONS
        cmd.extend(["-o", f"UserKnownHostsFile={known_hosts_path}"])

    # Prefer publickey auth; disable slow GSSAPI negotiation
    cmd.extend(
        [
            "-o",
            "PreferredAuthentications=publickey",
            "-o",
            "GSSAPIAuthentication=no",
        ]
    )

    # Connection multiplexing for fast subsequent connects
    if use_mux:
        env_val = os.environ.get("FLOW_SSH_MUX", "").strip().lower()
        if env_val in ("0", "false", "no", "off"):
            pass  # env override disables mux
        else:
            cmd.extend(
                [
                    "-o",
                    "ControlMaster=auto",
                    "-o",
                    "ControlPersist=60s",
                    "-o",
                    f"ControlPath={ssh_control_dir()}/%r@%h:%p",
                    "-o",
                    "StreamLocalBindUnlink=yes",
                ]
            )

    cmd.extend(["-o", "Compression=yes"])

    cmd.append(f"{user}@{host}")

    if remote_command:
        # Non-interactive: disable pseudo-tty, enable batch mode
        cmd.insert(1, "-T")
        cmd.insert(1, "-o")
        cmd.insert(2, "BatchMode=yes")
        if isinstance(remote_command, str):
            cmd.append(remote_command)
        else:
            cmd.extend(remote_command)

    if os.environ.get("FLOW_SSH_DEBUG") == "1":
        import logging

        logging.getLogger(__name__).debug("SSH command argv: %s", " ".join(cmd))

    return cmd


def ssh_command_string(argv: list[str]) -> str:
    """Return a shell-quoted command string (for logging/JSON display)."""
    return shlex_join(argv)
