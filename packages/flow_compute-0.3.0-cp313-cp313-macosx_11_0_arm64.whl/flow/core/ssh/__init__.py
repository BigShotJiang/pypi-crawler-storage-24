"""Core SSH primitives -- single source of truth.

All SSH command building, readiness probing, and connection types live
here. Higher layers (adapters, SDK, CLI) import from this package.
"""

from flow.core.ssh.command import build_ssh_command, ssh_command_string, ssh_control_dir
from flow.core.ssh.connection import SSHConnectionInfo
from flow.core.ssh.probe import (
    find_fallback_private_key,
    has_ssh_banner,
    is_endpoint_responsive,
    is_ssh_ready,
    resolve_proxyjump,
    tcp_port_open,
    wait_for_ssh_ready,
)

__all__ = [
    "SSHConnectionInfo",
    "build_ssh_command",
    "find_fallback_private_key",
    "has_ssh_banner",
    "is_endpoint_responsive",
    "is_ssh_ready",
    "resolve_proxyjump",
    "ssh_command_string",
    "ssh_control_dir",
    "tcp_port_open",
    "wait_for_ssh_ready",
]
