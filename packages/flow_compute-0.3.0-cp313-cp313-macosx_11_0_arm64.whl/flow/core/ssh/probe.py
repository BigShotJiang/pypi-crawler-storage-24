"""SSH readiness primitives -- single source of truth.

Provides low-level TCP probes, SSH banner detection, authenticated
readiness checks, and a consolidated wait loop. No settings imports;
runtime tunables via env vars or explicit parameters only.
"""

from __future__ import annotations

import logging
import os
import socket
import subprocess
import time as _t
from collections.abc import Callable
from pathlib import Path

from flow.errors.ssh import SshAuthenticationError

logger = logging.getLogger(__name__)

# Lightweight TTL cache for port responsiveness probes.
_PROBE_CACHE: dict[tuple[str, int], tuple[float, bool]] = {}


def tcp_port_open(host: str, port: int, timeout_sec: float = 2.0) -> bool:
    """Lightweight TCP connect check before a full SSH handshake."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout_sec)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except OSError:
        return False


def has_ssh_banner(host: str, port: int, timeout_sec: float = 1.5) -> bool:
    """Return True if the endpoint responds with an SSH-2.0 banner.

    Avoids false-positives on generic TCP listeners (load balancers,
    bastions) that keep port 22 open but aren't running sshd for the
    target instance.
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout_sec)
        sock.connect((host, port))
        data = sock.recv(256)
        sock.close()
        line = (data or b"").decode("ascii", errors="ignore").strip()
        return line.startswith("SSH-")
    except OSError:
        return False


def is_endpoint_responsive(
    host: str,
    port: int,
    ttl_seconds: float | None = None,
) -> bool:
    """Return True if TCP port is open, with a tiny TTL cache.

    Keeps probes snappy during status rendering when multiple tasks
    share the same endpoint.
    """
    if ttl_seconds is None:
        try:
            ttl_seconds = float(os.environ.get("FLOW_SSH_PROBE_TTL", "15"))
        except (ValueError, TypeError):
            ttl_seconds = 15.0

    key = (str(host), int(port))
    now = _t.time()

    cached = _PROBE_CACHE.get(key)
    if cached:
        ts, ok = cached
        if now - ts < ttl_seconds:
            return ok

    ok = has_ssh_banner(host, port) or tcp_port_open(host, port)

    # Bound cache size to prevent unbounded memory growth
    if len(_PROBE_CACHE) > 512:
        _PROBE_CACHE.clear()
    _PROBE_CACHE[key] = (now, ok)
    return ok


def is_ssh_ready(
    *,
    user: str,
    host: str,
    port: int,
    key_path: Path,
    prefix_args: list[str] | None = None,
    timeout: float = 4.0,
) -> bool:
    """Return True if SSH responds to a BatchMode probe.

    Raises:
        SshAuthenticationError: On permanent auth failure (wrong key,
            permission denied) to allow callers to fail fast.
    """
    debug = os.environ.get("FLOW_SSH_DEBUG") == "1"

    if not tcp_port_open(host, port):
        if debug:
            logger.debug("SSH tcp_port_open(%s:%s) -> closed", host, port)
        return False
    elif debug:
        logger.debug("SSH tcp_port_open(%s:%s) -> open", host, port)

    # Build probe with BatchMode so it doesn't hang on prompts
    from flow.core.ssh.command import build_ssh_command

    probe_prefix: list[str] = []
    if prefix_args:
        probe_prefix.extend(list(prefix_args))
    probe_prefix.extend(
        [
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=4",
            "-o",
            "ConnectionAttempts=1",
        ]
    )

    test_cmd = build_ssh_command(
        user=user,
        host=host,
        port=port,
        key_path=key_path,
        use_mux=False,
        prefix_args=probe_prefix,
        remote_command="echo SSH_OK",
    )

    try:
        result = subprocess.run(
            test_cmd,
            capture_output=True,
            text=True,
            timeout=int(timeout),
        )
        if debug:
            logger.debug(
                "SSH probe exit=%s stdout=%r stderr=%r",
                result.returncode,
                result.stdout,
                result.stderr,
            )
        if result.returncode == 255:
            stderr = (result.stderr or "").lower()
            if (
                "connection reset by peer" in stderr
                or "kex_exchange_identification" in stderr
                or "connection closed" in stderr
            ):
                return False
            # Authentication errors are permanent -- raise to fail fast
            logger.debug(
                "SSH authentication failed for %s@%s:%s with key %s: %s",
                user,
                host,
                port,
                key_path,
                result.stderr,
            )
            raise SshAuthenticationError(
                f"SSH authentication failed: {result.stderr.strip()}",
                key_path=key_path,
                stderr=result.stderr,
            )
        return result.returncode == 0 and "SSH_OK" in (result.stdout or "")
    except subprocess.TimeoutExpired:
        return False
    except SshAuthenticationError:
        raise
    except OSError:
        return False


def wait_for_ssh_ready(
    *,
    user: str,
    host: str,
    port: int,
    key_path: Path,
    proxyjump: str | None = None,
    timeout: float = 600,
    initial_interval: float = 1.0,
    max_backoff: float = 8.0,
    progress_callback: Callable[[str], None] | None = None,
) -> None:
    """Wait until SSH is ready or timeout expires.

    Consolidates the 4+ separate wait loops that existed in the old code.

    Raises:
        TimeoutError: If SSH doesn't become ready within timeout.
        SshAuthenticationError: On permanent auth failure.
    """
    prefix_args = ["-J", proxyjump] if proxyjump else None
    start = _t.time()
    interval = max(0.5, initial_interval)

    while True:
        elapsed = _t.time() - start
        if elapsed >= timeout:
            raise TimeoutError(
                f"SSH connection timeout after {int(elapsed)}s for {user}@{host}:{port}"
            )

        if progress_callback:
            mins, secs = divmod(int(elapsed), 60)
            progress_callback(f"Waiting for SSH ({mins}m {secs}s elapsed)")

        if is_ssh_ready(
            user=user,
            host=host,
            port=port,
            key_path=key_path,
            prefix_args=prefix_args,
        ):
            return

        _t.sleep(min(interval, max_backoff))
        interval = min(max_backoff, interval * 1.5)


def resolve_proxyjump(
    host: str,
    port: int,
    user: str,
    private_ip: str | None = None,
) -> tuple[str, int, str | None]:
    """Determine if ProxyJump is needed and return connection parameters.

    If ``private_ip`` is provided and is a non-global IP different from
    ``host``, returns ``(private_ip, 22, "{user}@{host}:{port}")`` for
    ProxyJump routing. Otherwise returns ``(host, port, None)``.
    """
    if not private_ip or str(private_ip) == str(host):
        return host, port, None

    from ipaddress import ip_address

    try:
        is_private = not ip_address(str(private_ip)).is_global
    except (ValueError, TypeError):
        return host, port, None

    if is_private:
        proxyjump = f"{user}@{host}:{port}"
        return str(private_ip), 22, proxyjump

    return host, port, None


def find_fallback_private_key() -> Path | None:
    """Return a fallback private key path if explicitly configured or found.

    Precedence:
        1. ``MITHRIL_SSH_KEY`` env var
        2. ``FLOW_SSH_KEY_PATH`` env var (legacy)
        3. Standard ``~/.ssh`` key names (ed25519, rsa, ecdsa)
    """
    from flow.core.keys.resolution import resolve_env_key_path

    p = resolve_env_key_path(("MITHRIL_SSH_KEY", "Mithril_SSH_KEY", "FLOW_SSH_KEY_PATH"))
    if p is not None:
        return p

    # Common defaults (flow_key is generated by ``flow setup``)
    ssh_dir = Path.home() / ".ssh"
    for name in ("flow_key", "id_ed25519", "id_rsa", "id_ecdsa"):
        p = ssh_dir / name
        if p.exists():
            return p
    return None
