"""Unified SSH connection info type.

Single source of truth for SSH connection parameters across the codebase.
Replaces both ``ConnectionDetails`` (connection_manager.py) and the old
``SSHConnectionInfo`` (client.py).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class SSHConnectionInfo:
    """SSH connection parameters for a remote host."""

    host: str
    port: int
    user: str
    key_path: Path
    proxyjump: str | None = None
    task_id: str | None = None

    @property
    def destination(self) -> str:
        return f"{self.user}@{self.host}"
