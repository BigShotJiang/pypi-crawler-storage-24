"""Icon utilities for Flow CLI.

Provides a single source of truth for the Flow brand icon and helpers to
prefix help strings consistently across the CLI.
"""

from __future__ import annotations

import os


def flow_icon() -> str:
    """Return the Flow icon character.

    Uses FLOW_ICON env override if set, otherwise the Unicode star U+274A.
    """
    override = os.environ.get("FLOW_ICON", "").strip()
    return override if override else "❊"


def prefix_with_flow_icon(text: str | None, muted: bool = False) -> str:
    """Prefix provided text with the Flow icon, if not already present.

    Args:
        text: Text to prefix with icon
        muted: If True, apply muted styling to the entire text
    """
    icon = flow_icon()
    base = text or ""
    stripped = base.lstrip()
    if stripped.startswith(icon) or stripped.startswith("\u274a"):
        result = base
    else:
        result = f"{icon} {base}".rstrip()

    if muted:
        # Apply Rich markup for muted styling
        return f"[muted]{result}[/muted]"
    return result
