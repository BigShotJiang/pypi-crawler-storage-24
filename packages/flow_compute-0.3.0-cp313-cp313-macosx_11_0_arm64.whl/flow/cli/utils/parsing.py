"""CLI parsing utilities."""

from __future__ import annotations


def parse_price(value: str | float | int | None) -> float:
    """Parse a price string like "$1.50" to a float 1.5.

    Returns 0.0 for None (no price specified).
    Raises ValueError for unparsable non-None input.
    """
    if value is None:
        return 0.0
    if isinstance(value, int | float):
        return float(value)
    s = str(value).strip()
    if s.startswith("$"):
        s = s[1:]
    try:
        return float(s)
    except ValueError:
        raise ValueError(
            f"Invalid price format: '{value}'. Expected a number like '1.50' or '$1.50'."
        ) from None
