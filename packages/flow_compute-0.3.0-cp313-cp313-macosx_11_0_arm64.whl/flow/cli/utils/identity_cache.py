"""Disk-backed identity cache for owner resolution.

Caches /v2/me identity and teammates map with independent TTLs to avoid
redundant API calls on repeated ``flow status`` invocations.

Cache file: ``~/.flow/identity_cache.json``
"""

from __future__ import annotations

import json
import logging
import tempfile
import time
from pathlib import Path

logger = logging.getLogger(__name__)

_CACHE_VERSION = 1


class IdentityCache:
    """Dual-TTL identity cache scoped by provider context.

    Identity (``me``) is cached for 24 hours; teammates for 4 hours.
    Context switching (different provider/project) invalidates teammates
    since they belong to the previous org scope.
    """

    ME_TTL_SECONDS = 86400  # 24 hours
    TEAMMATES_TTL_SECONDS = 14400  # 4 hours

    def __init__(self, cache_dir: Path | None = None) -> None:
        self._cache_dir = cache_dir or Path.home() / ".flow"
        self._cache_file = self._cache_dir / "identity_cache.json"

    def get_me(self, context: str | None = None) -> dict[str, str | None] | None:
        """Return cached identity if fresh and context matches."""
        data = self._load()
        if data is None:
            return None
        if not self._context_matches(data, context):
            return None
        me = data.get("me")
        if not isinstance(me, dict):
            return None
        saved_at = me.get("saved_at")
        if not isinstance(saved_at, int | float):
            return None
        if time.time() - saved_at > self.ME_TTL_SECONDS:
            return None
        user_id = me.get("user_id")
        if not user_id:
            return None
        return {
            "user_id": me.get("user_id"),
            "username": me.get("username"),
            "email": me.get("email"),
        }

    def save_me(
        self,
        user_id: str,
        username: str | None,
        email: str | None,
        context: str | None = None,
    ) -> None:
        """Persist identity. Clears teammates if context changed."""
        try:
            data = self._load() or {}
            old_context = data.get("context")
            context_changed = (
                old_context is not None and context is not None and old_context != context
            )
            if context_changed:
                data.pop("teammates", None)
            data["version"] = _CACHE_VERSION
            if context is not None:
                data["context"] = context
            data["me"] = {
                "user_id": user_id,
                "username": username,
                "email": email,
                "saved_at": time.time(),
            }
            self._atomic_write(data)
        except Exception:  # noqa: BLE001
            logger.debug("identity_cache: failed to save me", exc_info=True)

    def get_teammates(self, context: str | None = None) -> dict[str, str] | None:
        """Return cached teammates map if fresh and context matches."""
        data = self._load()
        if data is None:
            return None
        if not self._context_matches(data, context):
            return None
        teammates = data.get("teammates")
        if not isinstance(teammates, dict):
            return None
        saved_at = teammates.get("saved_at")
        if not isinstance(saved_at, int | float):
            return None
        if time.time() - saved_at > self.TEAMMATES_TTL_SECONDS:
            return None
        mapping = teammates.get("map")
        if not isinstance(mapping, dict):
            return None
        return mapping

    def save_teammates(
        self,
        teammates: dict[str, str],
        context: str | None = None,
    ) -> None:
        """Persist teammates map. Preserves existing identity data."""
        try:
            data = self._load() or {}
            data["version"] = _CACHE_VERSION
            if context is not None:
                data["context"] = context
            data["teammates"] = {
                "saved_at": time.time(),
                "map": teammates,
            }
            self._atomic_write(data)
        except Exception:  # noqa: BLE001
            logger.debug("identity_cache: failed to save teammates", exc_info=True)

    def clear(self) -> None:
        """Remove the cache file."""
        try:
            if self._cache_file.exists():
                self._cache_file.unlink()
        except Exception:  # noqa: BLE001
            pass

    # -- Private helpers --

    @staticmethod
    def _context_matches(data: dict, context: str | None) -> bool:
        """Return True if stored context matches the requested context."""
        stored = data.get("context")
        if stored is None or context is None:
            return True
        return stored == context

    def _load(self) -> dict | None:
        """Load and validate cache file. Returns None on any error."""
        if not self._cache_file.exists():
            return None
        try:
            data = json.loads(self._cache_file.read_text())
        except (json.JSONDecodeError, OSError):
            return None
        if not isinstance(data, dict):
            return None
        if data.get("version") != _CACHE_VERSION:
            return None
        return data

    def _atomic_write(self, data: dict) -> None:
        """Write cache data atomically via temp-file rename."""
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            dir=self._cache_dir, suffix=".tmp", prefix="identity_cache_"
        )
        try:
            with open(fd, "w") as f:
                json.dump(data, f, indent=2)
            Path(tmp_path).replace(self._cache_file)
        except Exception:
            # Clean up temp file on failure
            try:
                Path(tmp_path).unlink(missing_ok=True)
            except Exception:  # noqa: BLE001
                pass
            raise
