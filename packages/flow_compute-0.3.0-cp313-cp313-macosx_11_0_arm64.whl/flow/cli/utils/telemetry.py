"""Opt-in telemetry for Flow CLI.

Writes JSONL events to ~/.flow/metrics.jsonl when telemetry is enabled.
Never raises; best-effort only.

When enabled and an Amplitude key is set, events are also mirrored to
Amplitude via ``flow.utils.analytics``.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _utcnow_iso() -> str:
    """Return current UTC time as an ISO 8601 string with Z suffix."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _safe_dict(obj: dict[str, Any] | None) -> dict[str, Any]:
    """Coerce a dict to be JSON-serializable, converting bad values to str."""
    try:
        if not obj:
            return {}
        result: dict[str, Any] = {}
        for k, v in obj.items():
            try:
                json.dumps({k: v})
                result[k] = v
            except Exception:  # noqa: BLE001
                result[k] = str(v)
        return result
    except Exception:  # noqa: BLE001
        return {}


@dataclass
class CommandMetric:
    command: str
    duration: float
    success: bool
    error_type: str | None = None
    timestamp: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = _utcnow_iso()


@dataclass
class EventMetric:
    event: str
    properties: dict[str, Any]
    timestamp: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = _utcnow_iso()


class CommandTracker:
    """Context manager that records a CLI command execution as a metric."""

    def __init__(self, telemetry: Telemetry, command: str) -> None:
        self.telemetry = telemetry
        self.command = command
        self.start_time: float | None = None

    def __enter__(self) -> CommandTracker:
        self.start_time = time.time()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        if not self.telemetry.enabled:
            return
        try:
            duration = time.time() - self.start_time if self.start_time else 0.0

            success, err_name = _classify_exit(exc_type, exc_val)
            full_name = _resolve_command_name(self.command)

            metric = CommandMetric(
                command=full_name,
                duration=duration,
                success=success,
                error_type=err_name,
            )
            self.telemetry._append_jsonl(asdict(metric))

            # Amplitude sink (best-effort)
            try:
                from flow.utils import analytics as _analytics

                _analytics.track(
                    "cli_command",
                    {
                        "command": full_name,
                        "success": success,
                        "error_type": err_name or "",
                        "duration_ms": int(duration * 1000),
                        "origin": "cli",
                    },
                )
            except Exception:  # noqa: BLE001
                logger.debug("Failed to send command metric to Amplitude", exc_info=True)
        except Exception:  # noqa: BLE001
            logger.debug("Failed to record command metric", exc_info=True)


def _classify_exit(
    exc_type: type[BaseException] | None,
    exc_val: BaseException | None,
) -> tuple[bool, str | None]:
    """Determine success/failure and error name from exception info.

    Returns:
        (success, error_type) tuple.
    """
    if exc_type is None:
        return True, None
    try:
        import click as _click

        if exc_type is _click.exceptions.Exit:
            code = getattr(exc_val, "exit_code", 1)
            if code == 0:
                return True, None
            return False, "Exit"
    except Exception:  # noqa: BLE001
        pass
    return False, exc_type.__name__


def _resolve_command_name(fallback: str) -> str:
    """Get the full Click command path, falling back to the provided name."""
    try:
        import click as _click

        ctx = _click.get_current_context(silent=True)
        if ctx and getattr(ctx, "command_path", None):
            return ctx.command_path
    except Exception:  # noqa: BLE001
        pass
    return fallback


class Telemetry:
    """Best-effort CLI telemetry that writes to local JSONL, Amplitude, and server."""

    def __init__(self) -> None:
        try:
            from flow.utils import analytics as _analytics

            self.enabled = bool(_analytics.telemetry_enabled())
        except Exception:  # noqa: BLE001
            self.enabled = os.environ.get("FLOW_TELEMETRY", "0") == "1"
        self.metrics_file = Path.home() / ".flow" / "metrics.jsonl"
        self._lock = threading.Lock()

    def track_command(self, command: str) -> CommandTracker:
        """Return a context manager that records command execution metrics."""
        return CommandTracker(self, command)

    @contextmanager
    def track_invocation(self, raw_tokens: list[str]) -> Iterator[None]:
        """Context manager combining track_command and log_invocation.

        Records both the command-level metric (JSONL + Amplitude) and the
        invocation-level metric (server sync + intent analysis) in a single
        context manager. Use this from the CLI entry point.

        Args:
            raw_tokens: sys.argv[1:] tokens.
        """
        command = raw_tokens[0] if raw_tokens else "help"
        start_time = time.time()
        outcome = "success"
        error_type = None
        error_message = None

        try:
            with self.track_command(command):
                yield
        except Exception as exc:
            outcome = _classify_invocation_outcome(exc)
            error_type = type(exc).__name__
            error_message = str(exc)[:100]
            raise
        finally:
            if self.enabled:
                duration_ms = int((time.time() - start_time) * 1000)
                resolved = _resolve_command_name(command)
                self.log_invocation(
                    raw_tokens=raw_tokens,
                    outcome=outcome,
                    resolved_command=resolved if resolved != command else None,
                    error_type=error_type,
                    error_message=error_message,
                    duration_ms=duration_ms,
                )

    def log_event(self, event: str, properties: dict[str, Any] | None = None) -> None:
        """Write an arbitrary event to the JSONL and Amplitude sinks."""
        if not self.enabled:
            return
        try:
            safe_props = _safe_dict(properties)
            payload = asdict(EventMetric(event=event, properties=safe_props))
            self._append_jsonl(payload)
            try:
                from flow.utils import analytics as _analytics

                _analytics.track(event, safe_props)
            except Exception:  # noqa: BLE001
                logger.debug("Failed to send event to Amplitude", exc_info=True)
        except Exception:  # noqa: BLE001
            logger.debug("Failed to log event '%s'", event, exc_info=True)

    def log_invocation(
        self,
        raw_tokens: list[str],
        outcome: str,
        resolved_command: str | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        """Log a CLI invocation with full context for intent analysis.

        Args:
            raw_tokens: Command tokens from sys.argv[1:] (sanitized to first 2).
            outcome: One of "success", "error", "help".
            resolved_command: The command Click resolved (e.g., "instance create").
            error_type: Exception class name if outcome is "error".
            error_message: Truncated error message (first 100 chars).
            duration_ms: Execution time in milliseconds.
        """
        if not self.enabled:
            return
        try:
            raw_cmd = raw_tokens[0] if raw_tokens else ""
            raw_subcmd = raw_tokens[1] if len(raw_tokens) > 1 else None
            if raw_subcmd and (raw_subcmd.startswith("-") or "=" in raw_subcmd):
                raw_subcmd = None

            help_requested = any(t in ("-h", "--help", "help") for t in raw_tokens)
            inferred_intent = infer_intent(raw_cmd) if outcome == "error" else None

            props: dict[str, Any] = {
                "raw_command": raw_cmd[:50] if raw_cmd else "",
                "outcome": outcome,
                "help_requested": help_requested,
            }
            if raw_subcmd:
                props["raw_subcommand"] = raw_subcmd[:50]
            if resolved_command:
                props["resolved_command"] = resolved_command
            if error_type:
                props["error_type"] = error_type
            if error_message:
                props["error_message"] = error_message[:100]
            if inferred_intent:
                props["inferred_intent"] = inferred_intent
            if duration_ms is not None:
                props["duration_ms"] = duration_ms

            self.log_event("cli_invocation", props)

            self._send_to_server(
                [
                    {
                        "event": "cli_invocation",
                        "timestamp": _utcnow_iso(),
                        "properties": props,
                    }
                ]
            )
        except Exception:  # noqa: BLE001
            logger.debug("Failed to log invocation", exc_info=True)

    # -- internal helpers --

    def _append_jsonl(self, payload: dict[str, Any]) -> None:
        """Append a JSON line to the local metrics file (best effort)."""
        with self._lock:
            try:
                self.metrics_file.parent.mkdir(parents=True, exist_ok=True)
                created = not self.metrics_file.exists()
                with open(self.metrics_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(payload) + "\n")
                if created and os.name == "posix":
                    try:
                        os.chmod(self.metrics_file, 0o600)
                    except OSError:
                        pass
            except OSError:
                logger.debug("Failed to write to metrics file", exc_info=True)

    def _send_to_server(self, events: list[dict[str, Any]]) -> None:
        """Best-effort POST events to Mithril API telemetry endpoint.

        Runs in a daemon thread to avoid blocking CLI execution.
        """
        if not self.enabled or not events:
            return

        def _send() -> None:
            try:
                from flow.application.config.config import Config

                config = Config.from_env(require_auth=False)
                if not config.api_key or not config.api_url:
                    return

                import httpx

                server_events = []
                for e in events:
                    props = e.get("properties", {})
                    server_events.append(
                        {
                            "event_name": e.get("event", "unknown"),
                            "occurred_at": e.get("timestamp", _utcnow_iso()),
                            "raw_command": props.get("raw_command"),
                            "resolved_command": props.get("resolved_command"),
                            "outcome": props.get("outcome"),
                            "error_type": props.get("error_type"),
                            "inferred_intent": props.get("inferred_intent"),
                            "duration_ms": props.get("duration_ms"),
                            "client_version": self._get_version(),
                            "source": "cli",
                            "properties": props,
                        }
                    )

                httpx.post(
                    f"{config.api_url}/v2/flow/telemetry/events",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                    json={"events": server_events},
                    timeout=2.0,
                )
            except Exception:  # noqa: BLE001
                logger.debug("Failed to send telemetry to server", exc_info=True)

        try:
            t = threading.Thread(target=_send, daemon=True)
            t.start()
        except Exception:  # noqa: BLE001
            logger.debug("Failed to start server telemetry thread", exc_info=True)

    def _get_version(self) -> str:
        """Get Flow CLI version for telemetry context."""
        try:
            from flow._version import get_version

            return get_version()
        except Exception:  # noqa: BLE001
            return "unknown"


def _classify_invocation_outcome(exc: BaseException) -> str:
    """Map an exception to an invocation outcome string."""
    try:
        import click as _click

        if isinstance(exc, _click.exceptions.UsageError):
            return "error"
        if isinstance(exc, _click.exceptions.Exit):
            code = getattr(exc, "exit_code", 0)
            return "help" if code == 0 else "error"
    except Exception:  # noqa: BLE001
        pass
    return "error"


# Common command mistakes and their likely intended commands.
INTENT_MAP: dict[str, str] = {
    # Deletion variants
    "remove": "cancel",
    "rm": "cancel",
    "delete": "cancel",
    "kill": "cancel",
    "stop": "cancel",
    "terminate": "cancel",
    # Execution variants
    "run": "submit",
    "exec": "submit",
    "execute": "submit",
    "start": "submit",
    "launch": "instance create",
    # Listing variants
    "ls": "status",
    "list": "status",
    "ps": "status",
    "jobs": "status",
    "tasks": "status",
    # Info variants
    "info": "status",
    "show": "status",
    "get": "status",
    "describe": "status",
    # Instance variants
    "instances": "instance",
    "vm": "instance",
    "vms": "instance",
    "server": "instance",
    "servers": "instance",
    "node": "instance",
    "nodes": "instance",
    "gpu": "instance",
    "gpus": "instance",
    # Volume variants
    "disk": "volume",
    "disks": "volumes",
    "storage": "volumes",
    # Other common mistakes
    "connect": "ssh",
    "shell": "ssh",
    "login": "ssh",
    "attach": "ssh",
    "config": "setup",
    "configure": "setup",
    "init": "setup",
    "auth": "setup",
    "price": "pricing",
    "prices": "pricing",
    "cost": "pricing",
    "costs": "pricing",
    "log": "logs",
    "tail": "logs",
    "output": "logs",
}


def infer_intent(raw_command: str) -> str | None:
    """Map a mistyped command to its likely intended command."""
    if not raw_command:
        return None
    normalized = raw_command.lower().strip()
    return INTENT_MAP.get(normalized)
