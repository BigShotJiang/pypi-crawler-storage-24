"""Shared utilities for Jupyter functionality."""

import signal
import subprocess
import sys
import time
import webbrowser
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from flow.cli.commands.base import console


def wait_for_jupyter_ready(url: str, timeout: int = 60) -> bool:
    """Poll the Jupyter URL until it responds or timeout is reached.

    Args:
        url: The Jupyter server URL to check
        timeout: Maximum time to wait in seconds (default: 60)

    Returns:
        True if server responds within timeout, False otherwise
    """
    start_time = time.time()
    console.print("Waiting for Jupyter server to respond...")

    while time.time() - start_time < timeout:
        try:
            # Try to connect to the server
            request = Request(url)
            with urlopen(request, timeout=2) as response:
                if response.status == 200:
                    elapsed = time.time() - start_time
                    console.print(
                        f"[success]✓ Jupyter server ready (took {elapsed:.2f}s)[/success]"
                    )
                    return True
        except (URLError, OSError):
            # Server not ready yet, continue polling
            pass

        time.sleep(1.0)

    return False


def create_jupyter_tunnel(
    task: Any,
    host: str,
    ssh_key_path: str,
    username: str,
    local_port: int,
    jupyter_port: int,
    token: str | None,
    no_open: bool,
    raise_on_timeout: bool = False,
    ssh_port: int = 22,
) -> None:
    """Create SSH tunnel and optionally open browser.

    Args:
        task: The task object
        host: SSH host
        ssh_key_path: Path to SSH key
        username: SSH username
        local_port: Local port for tunnel
        jupyter_port: Remote Jupyter port
        token: Jupyter authentication token
        no_open: Whether to skip opening browser
        raise_on_timeout: Whether to raise RuntimeError on timeout (vs return)
        ssh_port: SSH port on the remote host (default: 22)
    """
    # Build the URL
    url = f"http://localhost:{local_port}"
    if token:
        url += f"/?token={token}"

    console.print("Creating SSH tunnel...")

    # SSH tunnel command via core SSH module
    from pathlib import Path

    from flow.core.ssh import build_ssh_command

    tunnel_cmd = build_ssh_command(
        user=username,
        host=host,
        port=ssh_port,
        key_path=Path(ssh_key_path),
        prefix_args=[
            "-N",
            "-L",
            f"{local_port}:localhost:{jupyter_port}",
            "-o",
            "LogLevel=ERROR",
        ],
        use_mux=False,
    )

    try:
        # Start the tunnel in background
        tunnel_process = subprocess.Popen(tunnel_cmd, stderr=subprocess.DEVNULL)

        console.print("[success]✓ SSH tunnel established[/success]")

        # Wait for Jupyter to be accessible through the tunnel
        if not wait_for_jupyter_ready(url, timeout=60):
            console.print("[warning]Jupyter server did not respond within 60 seconds[/warning]")
            console.print(
                "[warning]The tunnel is still active; the server may still be starting[/warning]"
            )
            console.print(f"[blue]You can try opening manually: {url}[/blue]")
            if raise_on_timeout:
                tunnel_process.terminate()
                raise RuntimeError("Jupyter server did not respond within 60 seconds")
            # Keep tunnel alive -- don't terminate on timeout (Fix #3)

        # Open browser if requested
        if not no_open:
            try:
                webbrowser.open(url)
                console.print("[success]✓ Opened Jupyter in browser[/success]")
            except Exception:  # noqa: BLE001
                console.print("[warning]Could not open browser automatically[/warning]")
                console.print(f"[blue]Please open: {url}[/blue]")
        else:
            console.print(f"[blue]Copy and open this URL: {url}[/blue]")

        # Clean status display
        console.print("\n" + "─" * 60)
        console.print("[bold success]Jupyter Notebook is running[/bold success]")
        console.print(f"[dim]Task: {task.task_id}[/dim]")
        console.print(f"[dim]Local URL: {url}[/dim]")
        console.print("─" * 60)
        console.print("\n[bold]Press Ctrl+C to stop the tunnel and exit[/bold]")

        # Set up signal handler for clean shutdown
        def signal_handler(signum, frame):
            console.print("\n[warning]Shutting down tunnel...[/warning]")
            tunnel_process.terminate()
            try:
                tunnel_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                tunnel_process.kill()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        # Wait for the tunnel process
        tunnel_process.wait()

    except KeyboardInterrupt:
        console.print("\n[warning]Tunnel stopped by user[/warning]")
    except Exception as e:  # noqa: BLE001
        console.print(f"[error]Error with SSH tunnel: {e}[/error]")
