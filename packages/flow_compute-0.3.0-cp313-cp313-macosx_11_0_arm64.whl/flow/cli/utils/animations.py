"""Animation primitives for Flow CLI.

Provides spinner frames, text effects, and progress bar rendering.
All timing uses monotonic clocks to avoid jumps from NTP adjustments.
"""

import math
import os
import time

from rich.style import Style
from rich.text import Text

# Monotonic anchor for all animation phases
_START_TIME = time.monotonic()

# Spinner frame sequences
SPINNERS: dict[str, list[str]] = {
    "dots": ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
    "line": ["-", "\\", "|", "/"],
}


def get_phase(duration: float, delay: float = 0.0) -> float:
    """Current animation phase as a value in [0.0, 1.0).

    Args:
        duration: Cycle length in seconds.
        delay: Phase offset in seconds.
    """
    elapsed = time.monotonic() - _START_TIME + delay
    return (elapsed % duration) / duration


def get_spinner_frame(pattern: list[str], phase: float) -> str:
    """Select a spinner character from *pattern* at the given *phase*."""
    return pattern[int(phase * len(pattern)) % len(pattern)]


def wave_pattern(text: str, phase: float, intensity: float = 1.0) -> Text:
    """Per-character sine-wave brightness animation."""
    result = Text()
    n = len(text)
    for i, char in enumerate(text):
        brightness = 0.5 + 0.5 * math.sin(((phase + i / n) % 1.0) * 2 * math.pi) * intensity
        if brightness > 0.75:
            style = Style(color="bright_white", bold=True)
        elif brightness > 0.5:
            style = Style(color="white")
        elif brightness > 0.25:
            style = Style(color="bright_black")
        else:
            style = Style(color="black")
        result.append(char, style=style)
    return result


def pulse_effect(text: str, phase: float, intensity: float = 1.0) -> Text:
    """Uniform brightness pulse on the entire string."""
    brightness = 0.5 + 0.5 * math.sin(phase * 2 * math.pi) * intensity
    if brightness > 0.75:
        style = Style(color="bright_white", bold=True)
    elif brightness > 0.5:
        style = Style(color="white")
    elif brightness > 0.25:
        style = Style(color="bright_black")
    else:
        style = Style(dim=True)
    return Text(text, style=style)


def shimmer_effect(text: str, phase: float, intensity: float = 1.0) -> Text:
    """Traveling highlight band across the string."""
    result = Text()
    n = len(text)
    shimmer_width = 0.2
    for i, char in enumerate(text):
        distance = abs(i / n - phase)
        if distance > 0.5:
            distance = 1.0 - distance
        if distance < shimmer_width:
            brightness = (1.0 - distance / shimmer_width) * intensity
            style = (
                Style(color="bright_white", bold=True) if brightness > 0.5 else Style(color="white")
            )
        else:
            style = Style()
        result.append(char, style=style)
    return result


def progress_bar(
    progress: float,
    width: int = 20,
    animated: bool = True,
    style: str = "gradient",
    color: str | None = None,
) -> Text:
    """Render an animated progress bar as Rich Text.

    Args:
        progress: Value in [0.0, 1.0].
        width: Bar width in characters.
        animated: Whether to animate the leading edge.
        style: Visual style ("gradient", "smooth", "blocks", or "default").
        color: Explicit accent color; falls back to theme accent.
    """
    ascii_only = os.getenv("FLOW_ASCII") == "1"

    if (style in {"smooth", "rounded"}) and not ascii_only:
        chars = " ▏▎▍▌▋▊▉█"
        filled = int(progress * width * 8)
        full_blocks = filled // 8
        partial_block = filled % 8
        bar = "█" * full_blocks
        if partial_block > 0 and full_blocks < width:
            bar += chars[partial_block]
        bar += " " * (width - len(bar))
    elif style == "gradient" and not ascii_only:
        full_blocks = int(progress * width)
        if full_blocks <= 0:
            bar = "░" * width
        elif full_blocks >= width:
            bar = "█" * width
        else:
            bar = "█" * full_blocks + "▓" + "░" * (width - full_blocks - 1)
        filled = full_blocks
    elif style == "blocks":
        filled = int(progress * width)
        bar = "■" * filled + "□" * (width - filled)
    else:
        filled = int(progress * width)
        bar = "=" * filled + "-" * (width - filled)

    left_cap = "(" if style == "rounded" else "["
    right_cap = ")" if style == "rounded" else "]"
    result = Text(f"{left_cap}{bar}{right_cap}")

    # Resolve accent color
    try:
        if color is None:
            from flow.cli.utils.theme_manager import theme_manager as _tm

            accent = _tm.get_color("aep.accent") or _tm.get_color("accent")
        else:
            accent = color
    except Exception:  # noqa: BLE001
        accent = "cyan"

    # Colorize the filled region
    try:
        if style in {"smooth", "rounded"} and not ascii_only:
            filled8 = int(progress * width * 8)
            fb = filled8 // 8
            partial = filled8 % 8
            start, end = 1, 1 + fb + (1 if (partial > 0 and fb < width) else 0)
        elif style == "gradient" and not ascii_only:
            fb = int(progress * width)
            edge = 1 if (progress > 0 and fb < width) else 0
            start, end = 1, 1 + fb + edge
        else:
            start, end = 1, 1 + int(progress * width)
        if end > start:
            result.stylize(accent, start, end)
    except Exception:  # noqa: BLE001
        pass

    if animated and progress < 1.0:
        phase = get_phase(1.0)
        if filled > 0 and filled < width:
            edge_pos = filled - 1
            if phase > 0.5:
                result.stylize(Style(bold=True), edge_pos + 1, edge_pos + 2)

    return result


# Backward-compatible singleton facade so existing code that imports
# ``animation_engine.method(...)`` keeps working without changes.
class _AnimationEngine:
    """Thin wrapper exposing module-level functions as methods."""

    SPINNERS = SPINNERS

    @staticmethod
    def get_phase(duration: float, delay: float = 0.0) -> float:
        return get_phase(duration, delay)

    @staticmethod
    def get_spinner_frame(pattern: list[str], phase: float) -> str:
        return get_spinner_frame(pattern, phase)

    @staticmethod
    def wave_pattern(text: str, phase: float, intensity: float = 1.0) -> Text:
        return wave_pattern(text, phase, intensity)

    @staticmethod
    def pulse_effect(text: str, phase: float, intensity: float = 1.0) -> Text:
        return pulse_effect(text, phase, intensity)

    @staticmethod
    def shimmer_effect(text: str, phase: float, intensity: float = 1.0) -> Text:
        return shimmer_effect(text, phase, intensity)

    @staticmethod
    def progress_bar(
        progress: float,
        width: int = 20,
        animated: bool = True,
        style: str = "gradient",
        color: str | None = None,
    ) -> Text:
        return progress_bar(progress, width, animated, style, color)


animation_engine = _AnimationEngine()
