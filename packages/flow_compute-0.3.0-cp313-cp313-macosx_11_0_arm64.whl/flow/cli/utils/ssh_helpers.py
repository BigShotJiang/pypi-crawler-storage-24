"""CLI SSH helpers.

Thin shims over ``flow.core.ssh`` for backward compatibility.
"""

from __future__ import annotations

from pathlib import Path

from flow.core.ssh import build_ssh_command, ssh_command_string

__all__ = ["build_ssh_argv", "ssh_command_string"]


def build_ssh_argv(
    user: str,
    host: str,
    port: int,
    key_path: str | None,
    extra_ssh_args: list[str] | None = None,
    remote_command: list[str] | None = None,
    known_hosts_path: str | None = None,
) -> list[str]:
    """Build an ssh argv list with safe ordering and defaults.

    Delegates to ``flow.core.ssh.build_ssh_command`` for the base
    command, then appends extra args and remote command tokens.
    """
    return build_ssh_command(
        user=user,
        host=host,
        port=port,
        key_path=Path(key_path) if key_path else None,
        prefix_args=extra_ssh_args,
        remote_command=remote_command,
        known_hosts_path=known_hosts_path,
    )
