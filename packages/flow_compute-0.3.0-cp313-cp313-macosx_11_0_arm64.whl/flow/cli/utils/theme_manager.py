"""Theme management system for Flow CLI.

Provides automatic terminal theme detection, theme loading, and theme-aware
console creation for consistent visual presentation across different terminal
environments.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

import yaml
from rich.console import Console
from rich.theme import Theme as RichTheme


@dataclass
class FlowTheme:
    """Flow theme definition."""

    name: str
    colors: dict[str, str]
    is_dark: bool = True

    def to_rich_theme(self) -> RichTheme:
        """Convert Flow theme to Rich theme."""
        return RichTheme(self.colors)


class ThemeManager:
    """Manages theme detection, loading, and application for Flow CLI."""

    # Built-in themes
    THEMES = {
        "modern": FlowTheme(
            name="modern",
            is_dark=True,
            colors={
                # Base colors
                "default": "#D1D5DB",  # soft light gray text
                "muted": "#9CA3AF",  # muted gray
                "border": "#4B5563",  # slate/gray border
                # Bright blue accent tuned for dark backgrounds (blue-300)
                "accent": "#93C5FD",
                # Map named colors to semantic palette
                "cyan": "#93C5FD",
                "blue": "#93C5FD",
                "green": "#6EE7B7",  # emerald-300
                "yellow": "#FCD34D",  # amber-300
                "red": "#FCA5A5",  # red-300
                "magenta": "#93C5FD",
                # Repr/link highlighting
                "repr.url": "underline #93C5FD",
                "repr.path": "#93C5FD",
                "repr.filename": "#93C5FD",
                "link": "underline #93C5FD",
                "selected": "#334155",
                "selected_arrow": "#93C5FD",
                "selected_bg": "bright_black",
                "selected_fg": "white",
                "selected_muted_fg": "bright_white",
                "shortcut_key": "#93C5FD",
                # Status colors — high luminance for dark backgrounds
                "success": "#6EE7B7",  # emerald-300
                "warning": "#FCD34D",  # amber-300
                "error": "#FCA5A5",  # red-300
                "info": "#93C5FD",  # blue-300
                # Task status colors
                "status.pending": "#FCD34D",
                "status.starting": "#93C5FD",
                "status.preparing": "#93C5FD",
                "status.running": "#6EE7B7",
                "status.paused": "#A5F3FC",  # cyan-200
                "status.preempting": "#FCD34D",
                "status.completed": "#6EE7B7",
                "status.failed": "#FCA5A5",
                "status.cancelled": "#9CA3AF",
                # Table elements
                "table.header": "bold #93C5FD",
                "table.border": "#4B5563",
                "table.row": "#D1D5DB",
                "table.row.dim": "#9CA3AF",
                # Semantic elements
                "task.name": "#F3F4F6",  # gray-100: bright, readable name
                "task.id": "#93C5FD",
                "task.gpu": "#93C5FD",  # accent: GPU pops as key info
                "task.ip": "#93C5FD",
                "task.time": "#6B7280",  # gray-500: recede further
                "task.duration": "#6B7280",
            },
        ),
        "modern_light": FlowTheme(
            name="modern_light",
            is_dark=False,
            colors={
                # Base colors
                "default": "#0F172A",  # primary ink
                "muted": "#64748B",  # captions / muted
                "border": "#D1D5DB",  # subtle dividers
                # Accent tuned for legibility on light backgrounds
                "accent": "#2563EB",
                "cyan": "#2563EB",
                "blue": "#2563EB",
                "green": "#059669",  # emerald-600
                "yellow": "#D97706",  # amber-600
                "red": "#DC2626",  # red-600
                "magenta": "#2563EB",
                # Repr/link highlighting
                "repr.url": "underline #2563EB",
                "repr.path": "#2563EB",
                "repr.filename": "#2563EB",
                "link": "underline #2563EB",
                "selected": "#2563EB",
                "selected_arrow": "#2563EB",
                "selected_bg": "#EFF6FF",
                "selected_fg": "#0F172A",
                "selected_muted_fg": "#475569",
                "shortcut_key": "#2563EB",
                # Status colors — darker shades for light backgrounds
                "success": "#059669",  # emerald-600
                "warning": "#D97706",  # amber-600
                "error": "#DC2626",  # red-600
                "info": "#2563EB",
                # Task status colors
                "status.pending": "#D97706",
                "status.starting": "#2563EB",
                "status.preparing": "#2563EB",
                "status.running": "#059669",
                "status.paused": "#0E7490",
                "status.preempting": "#D97706",
                "status.completed": "#059669",
                "status.failed": "#DC2626",
                "status.cancelled": "#64748B",
                # Table elements
                "table.header": "bold #2563EB",
                "table.border": "#D1D5DB",
                "table.row": "#0F172A",
                "table.row.dim": "#64748B",
                # Semantic elements
                "task.name": "#0F172A",
                "task.id": "#2563EB",
                "task.gpu": "#0F172A",
                "task.ip": "#2563EB",
                "task.time": "#64748B",
                "task.duration": "#64748B",
            },
        ),
    }

    def __init__(self):
        """Initialize theme manager."""
        self.current_theme_name = None
        self.current_theme = None
        self.custom_themes_dir = Path.home() / ".flow" / "themes"
        self._console_cache = {}

    def detect_terminal_theme(self) -> str:
        """Auto-detect terminal theme.

        Returns:
            "modern_light" when a light background is detected; otherwise "modern".
        """
        # Check environment variables first
        if os.environ.get("FLOW_THEME"):
            return os.environ["FLOW_THEME"]

        # Check persisted config (~/.flow/config.yaml)
        try:
            config_path = Path.home() / ".flow" / "config.yaml"
            if config_path.exists():
                with open(config_path) as f:
                    cfg = yaml.safe_load(f) or {}
                    if isinstance(cfg, dict) and cfg.get("theme"):
                        return str(cfg.get("theme"))
        except Exception:  # noqa: BLE001
            # Ignore config errors and fall back to detection
            pass

        # Check common terminal theme indicators
        if os.environ.get("COLORFGBG"):
            # Format: "foreground;background"
            colors = os.environ["COLORFGBG"].split(";")
            if len(colors) >= 2:
                try:
                    bg = int(colors[1])
                    # Common light backgrounds: 7 (white), 15 (bright white)
                    if bg in [7, 15]:
                        return "modern_light"
                except ValueError:
                    pass

        # Check terminal-specific environment variables
        if os.environ.get("ITERM_PROFILE"):
            # iTerm2 specific
            profile = os.environ["ITERM_PROFILE"].lower()
            if any(light in profile for light in ["light", "solarized-light", "papercolor"]):
                return "modern_light"

        # Check if running in light mode terminals
        if os.environ.get("TERMINAL_EMULATOR") == "JetBrains-JediTerm":
            # IntelliJ IDEA terminal often uses light themes
            return "modern_light"

        # Default to modern (dark) theme
        return "modern"

    def load_theme(self, theme_name: str | None = None) -> FlowTheme:
        """Load theme by name or auto-detect.

        Args:
            theme_name: Theme name to load, or None to auto-detect

        Returns:
            Loaded theme
        """
        if theme_name is None:
            theme_name = self.detect_terminal_theme()

        # Check built-in themes first
        if theme_name in self.THEMES:
            self.current_theme_name = theme_name
            self.current_theme = self.THEMES[theme_name]
            return self.current_theme

        # Try to load custom theme
        custom_theme = self._load_custom_theme(theme_name)
        if custom_theme:
            self.current_theme_name = theme_name
            self.current_theme = custom_theme
            return custom_theme

        # Fallback to default (modern)
        self.current_theme_name = "modern"
        self.current_theme = self.THEMES["modern"]
        return self.current_theme

    def _load_custom_theme(self, theme_name: str) -> FlowTheme | None:
        """Load custom theme from file.

        Args:
            theme_name: Name of custom theme

        Returns:
            Loaded theme or None if not found
        """
        if not self.custom_themes_dir.exists():
            return None

        # Try YAML first, then JSON
        for ext in [".yaml", ".yml", ".json"]:
            theme_file = self.custom_themes_dir / f"{theme_name}{ext}"
            if theme_file.exists():
                try:
                    with open(theme_file) as f:
                        if ext == ".json":
                            data = json.load(f)
                        else:
                            data = yaml.safe_load(f)

                    return FlowTheme(
                        name=data.get("name", theme_name),
                        colors=data.get("colors", {}),
                        is_dark=data.get("is_dark", True),
                    )
                except Exception:  # noqa: BLE001
                    # Invalid theme file
                    pass

        return None

    def create_console(
        self, force_color: bool | None = None, no_color: bool | None = None, **kwargs
    ) -> Console:
        """Create theme-aware Rich Console instance.

        Args:
            force_color: Force color output
            no_color: Disable color output
            **kwargs: Additional arguments for Console

        Returns:
            Configured Console instance
        """
        # Load theme if not already loaded
        if self.current_theme is None:
            self.load_theme()

        # Handle color forcing via args and environment
        flow_color = (os.environ.get("FLOW_COLOR") or "").lower().strip()
        if flow_color not in {"auto", "always", "never", ""}:
            flow_color = "auto"

        if no_color or os.environ.get("NO_COLOR") or flow_color == "never":
            kwargs["no_color"] = True
        elif force_color or flow_color == "always":
            kwargs["force_terminal"] = True

        # Basic color-system detection with graceful degradation
        if "color_system" not in kwargs:
            colorterm = (os.environ.get("COLORTERM") or "").lower()
            term = (os.environ.get("TERM") or "").lower()
            if any(k in colorterm for k in ("truecolor", "24bit")):
                kwargs["color_system"] = "truecolor"
            elif "256color" in term:
                kwargs["color_system"] = "256"

        # Apply theme
        kwargs["theme"] = self.current_theme.to_rich_theme()

        # Create console
        console = Console(**kwargs)

        return console

    def is_color_enabled(self) -> bool:
        """Return True if color output should be enabled based on env and defaults."""
        flow_color = (os.environ.get("FLOW_COLOR") or "").lower().strip()
        if os.environ.get("NO_COLOR") or flow_color == "never":  # noqa: SIM103
            return False
        # If explicitly requested always, or auto/default, consider enabled
        return True

    def get_color(self, color_key: str) -> str:
        """Get color value for a given key.

        Args:
            color_key: Color key (e.g., "status.running")

        Returns:
            Color value or default
        """
        if self.current_theme is None:
            self.load_theme()

        # Special-case: provide a theme-aware default for AEP accent without
        # requiring every theme to define it explicitly.
        if color_key == "aep.accent":
            # Use explicit theme value when provided; otherwise a dark/light default
            if "aep.accent" in self.current_theme.colors:
                return self.current_theme.colors["aep.accent"]
            return "#a8d7e8" if getattr(self.current_theme, "is_dark", True) else "#003366"

        return self.current_theme.colors.get(color_key, "default")

    def list_themes(self) -> list[str]:
        """List all available themes.

        Returns:
            List of theme names
        """
        themes = list(self.THEMES.keys())

        # Add custom themes
        if self.custom_themes_dir.exists():
            for theme_file in self.custom_themes_dir.glob("*.{yaml,yml,json}"):
                theme_name = theme_file.stem
                if theme_name not in themes:
                    themes.append(theme_name)

        return sorted(themes)


# Global theme manager instance
theme_manager = ThemeManager()
