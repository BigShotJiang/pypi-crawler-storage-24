"""Shared hint builders for consistent Ctrl+C/resume copy."""

from __future__ import annotations

from rich.text import Text

from flow.cli.utils.theme_manager import theme_manager


def build_wait_hints(
    subject: str,
    resume_command: str,
    *,
    extra_action: tuple[str, str] | None = None,
) -> Text:
    """Build a concise hint line for long waits.

    Args:
        subject: Noun describing what continues (e.g., "VM", "job", "instance").
        resume_command: Command users should run to resume.
        extra_action: Optional tuple (label, command) appended after a separator.

    Returns:
        Rich Text object with styles applied.
    """
    try:
        accent = theme_manager.get_color("accent")
    except Exception:  # noqa: BLE001
        accent = "cyan"

    hint = Text()
    hint.append("  ")
    hint.append("Ctrl+C", style=accent)
    hint.append(f" to detach — {subject} continues. Resume: ")
    hint.append(resume_command, style=accent)

    if extra_action and isinstance(extra_action, tuple) and len(extra_action) == 2:
        label, command = extra_action
        hint.append("  |  ")
        hint.append(label)
        hint.append(command, style=accent)

    return hint


def build_provisioning_hint(
    subject: str,
    resume_command: str,
    *,
    extra_action: tuple[str, str] | None = None,
) -> Text:
    """Build a standardized provisioning hint with timing expectation.

    Args:
        subject: Noun describing what continues (e.g., "VM", "job", "instance").
        resume_command: Command users should run to resume.
        extra_action: Optional tuple (label, command) appended on line 1.

    Returns:
        Rich Text object with styles applied.
    """
    hint = build_wait_hints(
        subject,
        resume_command,
        extra_action=extra_action,
    )
    try:
        hint.append("\n")
        hint.append("  Provisioning typically takes 2-5 min", style="dim")
    except Exception:  # noqa: BLE001
        pass
    return hint


def build_allocation_hint(
    resume_command: str,
    *,
    subject: str = "allocation",
    extra_action: tuple[str, str] | None = None,
) -> Text:
    """Build a standardized allocation hint block.

    Args:
        resume_command: Command to resume/monitor after exiting.
        subject: Noun for what continues (default: "allocation").
        extra_action: Optional tuple (label, command) appended on line 1.
    """
    return build_wait_hints(
        subject,
        resume_command,
        extra_action=extra_action,
    )


def build_sync_check_hint() -> Text:
    """Two-line hint shown while preflighting code sync.

    Line 1: Checking working directory for changes
    Line 2: Only changed files will be uploaded (respects .flowignore)
    """
    try:
        accent = theme_manager.get_color("accent")
    except Exception:  # noqa: BLE001
        accent = "cyan"

    t = Text()
    t.append("  Checking working directory for changes\n")
    t.append("  Only changed files will be uploaded (respects ")
    t.append(".flowignore", style=accent)
    t.append(")")
    return t
