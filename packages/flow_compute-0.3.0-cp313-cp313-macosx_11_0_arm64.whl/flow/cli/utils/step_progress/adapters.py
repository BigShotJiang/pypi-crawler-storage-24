"""Progress adapters for allocation, SSH wait, and upload tracking."""

from __future__ import annotations

import time

from flow.cli.utils.step_progress.timeline import StepTimeline


class AllocationProgressAdapter:
    """Adapter to update the timeline during instance allocation."""

    def __init__(self, timeline: StepTimeline, step_index: int, estimated_seconds: int = 120):
        self.timeline = timeline
        self.step_index = step_index
        self.estimated_seconds = estimated_seconds
        self._start = None

    def __enter__(self):
        self.timeline.start_step(self.step_index)
        self._start = time.monotonic()
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc is None:
            self.timeline.complete_step()
        else:
            self.timeline.fail_step(str(exc))
        # Return False to propagate any exception
        return False

    def tick(self):
        if self._start is None:
            return
        elapsed = time.monotonic() - self._start
        pct = min(elapsed / self.estimated_seconds, 0.95)
        self.timeline.update_active(percent=pct)


class SSHWaitProgressAdapter:
    """Adapter to update the timeline during SSH readiness wait."""

    def __init__(
        self,
        timeline: StepTimeline,
        step_index: int,
        estimated_seconds: int,
        baseline_elapsed_seconds: int | None = None,
    ):
        self.timeline = timeline
        self.step_index = step_index
        self.estimated_seconds = estimated_seconds
        self.baseline_elapsed_seconds = baseline_elapsed_seconds
        self._start = None

    def __enter__(self):
        self.timeline.start_step(self.step_index)
        # If provided, seed this step with a baseline elapsed so the bar resumes correctly
        try:
            step = self.timeline.steps[self.step_index]
            step.baseline_elapsed_seconds = self.baseline_elapsed_seconds
        except Exception:  # noqa: BLE001
            pass
        self._start = time.monotonic()
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc is None:
            self.timeline.complete_step()
        else:
            self.timeline.fail_step(str(exc))
        # Return False to propagate any exception
        return False

    def update_eta(self, eta: str | None = None):
        if self._start is None:
            return
        base = self.baseline_elapsed_seconds or 0
        elapsed = time.monotonic() - self._start
        # Mirror bar logic for consistency, though provisioning steps now hide the bar.
        if base > (self.estimated_seconds or 0) * 2:
            pct = min(elapsed / self.estimated_seconds, 0.95)
        else:
            pct = min((base + elapsed) / self.estimated_seconds, 0.95)
        self.timeline.update_active(percent=pct, eta=eta)

        # Keep any hint set by the caller (e.g., Ctrl+C guidance + concise context).


class UploadProgressReporter:
    """Bridge reporter that maps code transfer progress to the timeline."""

    def __init__(self, timeline: StepTimeline, step_index: int, on_start: callable | None = None):
        self.timeline = timeline
        self.step_index = step_index
        self._entered = False
        # Optional callback fired when transfer starts (after step becomes active)
        self._on_start = on_start
        # Ensure on_start is invoked at most once even if multiple phases call it
        self._on_start_fired = False

    def invoke_on_start(self) -> None:
        if self._on_start_fired:
            return
        if callable(self._on_start):
            try:
                self._on_start()
                self._on_start_fired = True
            except Exception:  # noqa: BLE001
                # Never fail UX due to a rendering callback
                self._on_start_fired = True
                pass

    def ensure_started(self) -> None:
        """Public API used by context helpers to start timeline step once."""
        if not self._entered:
            self.timeline.start_step(self.step_index)
            self._entered = True

    # Matches IProgressReporter, but we deliberately avoid importing it to prevent tight coupling
    def ssh_wait_progress(self, message: str):
        class _Ctx:
            def __init__(self, outer: UploadProgressReporter):
                self.outer = outer

            def __enter__(self):
                # Start the current step (e.g., "Checking for changes").
                # Do NOT flip to "Uploading code" during SSH wait; that happens
                # when real transfer begins.
                self.outer.ensure_started()
                # Clarify the UX: this phase is actually blocking on SSH reachability.
                try:
                    from rich.text import (
                        Text as _Text,  # local import to avoid heavy top-level deps
                    )

                    # Override any pre-set hint (like "Checking working directory for changes")
                    # so users see the true state.
                    self.outer.timeline.set_active_hint_text(_Text(str(message)))
                except Exception:  # noqa: BLE001
                    # Best-effort; never fail rendering
                    pass
                return self.outer

            def __exit__(self, exc_type, exc, tb):
                # Do not complete here; let transfer_progress complete
                return False

        return _Ctx(self)

    def transfer_progress(self, message: str):
        class _Ctx:
            def __init__(self, outer: UploadProgressReporter):
                self.outer = outer

            def __enter__(self):
                # Flip from preflight (e.g., checking/scanning) to the actual
                # upload step right as the transfer phase begins.
                self.outer.ensure_started()
                self.outer.invoke_on_start()
                return self.outer

            def __exit__(self, exc_type, exc, tb):
                if exc is None:
                    self.outer.timeline.complete_step()
                else:
                    self.outer.timeline.fail_step(str(exc))
                return False

        return _Ctx(self)

    def update_status(self, message: str) -> None:
        # Map to a subtle note; avoid excessive churn
        try:
            # If we're in the SSH wait phase, keep the hint in sync so it doesn't
            # conflict with the earlier "Checking for changes" hint.
            low = str(message).lower()
            if "waiting for ssh" in low:
                from rich.text import Text as _Text

                self.timeline.set_active_hint_text(_Text(str(message)))
            else:
                self.timeline.update_active(message=message)
        except Exception:  # noqa: BLE001
            # Fall back to simple note update
            self.timeline.update_active(message=message)

    def update_transfer(
        self,
        percentage: float | None,
        speed: str | None,
        eta: str | None,
        current_file: str | None,
    ) -> None:
        """Update timeline with transfer progress from rsync."""
        step = self.timeline.steps[self.step_index]
        note = f"Uploading: {current_file}" if current_file else None

        # Update estimated duration based on progress data
        if step.started_mono is not None:
            elapsed = time.monotonic() - step.started_mono
            new_total = self._estimate_total_duration(elapsed, percentage, eta)

            if new_total is not None:
                # Smooth transition to preserve visual continuity
                if step.estimated_seconds:
                    base = step.baseline_elapsed_seconds or 0
                    current_pct = min((base + elapsed) / step.estimated_seconds, 0.95)
                else:
                    current_pct = min(elapsed / new_total, 0.95)
                step.baseline_elapsed_seconds = int(max(0.0, current_pct * new_total - elapsed))
                step.estimated_seconds = int(new_total)

        self.timeline.update_active(
            percent=(percentage / 100.0) if percentage is not None else None,
            speed=speed,
            eta=eta,
            message=note,
        )

    def _estimate_total_duration(
        self, elapsed: float, percentage: float | None, eta: str | None
    ) -> float | None:
        """Estimate total transfer duration from percentage or ETA string."""
        if percentage is not None and percentage > 0:
            frac = max(0.001, percentage / 100.0)
            return max(elapsed / frac, elapsed + 1.0)

        if eta:
            eta_secs = self._parse_eta_string(eta)
            if eta_secs > 0:
                return elapsed + eta_secs

        return None

    @staticmethod
    def _parse_eta_string(eta: str) -> int:
        """Parse rsync ETA string (e.g., '0:01:30' or '1:30') to seconds."""
        try:
            parts = eta.split(":")
            if len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
            elif len(parts) == 2:
                return int(parts[0]) * 60 + int(parts[1])
            return int(parts[0])
        except ValueError:
            return 0

    # New: allow callers to annotate the completed step with a short note
    def set_completion_note(self, note: str) -> None:
        try:
            step = self.timeline.steps[self.step_index]
            step.note = note
            # Re-render so the note appears under the completed step
            self.timeline.refresh()
        except Exception:  # noqa: BLE001
            # Best-effort; never fail UX for note rendering
            pass

    # Provide a way for strategies to seed a realistic ETA before progress lines start
    def seed_estimated_seconds(self, seconds: int) -> None:
        try:
            step = self.timeline.steps[self.step_index]
            if not seconds or seconds <= 0:
                return
            # Smooth the transition: preserve current visual percentage if possible
            import time as _time

            if step.started_mono is not None and step.estimated_seconds:
                elapsed = max(0.0, float(_time.monotonic() - step.started_mono))
                base = float(step.baseline_elapsed_seconds or 0)
                current_pct = min((base + elapsed) / float(step.estimated_seconds), 0.95)
                new_base = max(0.0, current_pct * float(seconds) - elapsed)
                step.baseline_elapsed_seconds = int(new_base)
            step.estimated_seconds = int(seconds)
            self.timeline.refresh()
        except Exception:  # noqa: BLE001
            pass


class ProgressAdapter:
    """Unified timeline adapter factory for allocation, SSH wait, and upload."""

    @classmethod
    def allocation(
        cls, timeline: StepTimeline, step_index: int, estimated_seconds: int = 120
    ) -> AllocationProgressAdapter:
        """Create an adapter for allocation progress tracking."""
        return AllocationProgressAdapter(timeline, step_index, estimated_seconds)

    @classmethod
    def ssh_wait(
        cls,
        timeline: StepTimeline,
        step_index: int,
        estimated_seconds: int,
        *,
        baseline_elapsed_seconds: int | None = None,
    ) -> SSHWaitProgressAdapter:
        """Create an adapter for SSH wait progress tracking."""
        return SSHWaitProgressAdapter(
            timeline, step_index, estimated_seconds, baseline_elapsed_seconds
        )

    @classmethod
    def upload(
        cls,
        timeline: StepTimeline,
        step_index: int,
        *,
        on_start: callable | None = None,
    ) -> UploadProgressReporter:
        """Create an adapter for upload progress tracking."""
        return UploadProgressReporter(timeline, step_index, on_start)


class NullConsole:
    """Console that discards prints to avoid duplicate provider messages."""

    def print(self, *_args, **_kwargs):
        return None
