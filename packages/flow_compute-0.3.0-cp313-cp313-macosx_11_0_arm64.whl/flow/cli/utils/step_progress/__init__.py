"""Unified step timeline progress UI for CLI commands.

Provides a single, coherent live region that renders a compact list of steps,
with one active step at a time. Each step can optionally display a progress
bar when an estimated duration is available. Finished steps show a checkmark
and duration; failures show a cross and a short message.

This component is intentionally lightweight and self-contained so it can be
owned by one caller (e.g., `flow dev`) without conflicting with other Live
displays.
"""

from flow.cli.utils.step_progress.adapters import (
    AllocationProgressAdapter,
    NullConsole,
    ProgressAdapter,
    SSHWaitProgressAdapter,
    UploadProgressReporter,
)
from flow.cli.utils.step_progress.hints import (
    build_allocation_hint,
    build_provisioning_hint,
    build_sync_check_hint,
    build_wait_hints,
)
from flow.cli.utils.step_progress.timeline import StepTimeline

__all__ = [
    "AllocationProgressAdapter",
    "NullConsole",
    "ProgressAdapter",
    "SSHWaitProgressAdapter",
    "StepTimeline",
    "UploadProgressReporter",
    "build_allocation_hint",
    "build_provisioning_hint",
    "build_sync_check_hint",
    "build_wait_hints",
]
