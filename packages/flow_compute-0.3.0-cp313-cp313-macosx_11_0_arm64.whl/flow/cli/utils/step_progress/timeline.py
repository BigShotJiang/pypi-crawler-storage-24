"""Step timeline core: StepTimeline, _Step, and logging suppression."""

from __future__ import annotations

import logging
import os
import random
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass

from rich.console import Console
from rich.live import Live
from rich.text import Text

from flow.cli.utils.animations import animation_engine
from flow.cli.utils.theme_manager import theme_manager


def _fmt_duration(secs: int) -> str:
    """Format seconds as a compact human-readable duration string."""
    if secs < 90:
        return f"{secs}s"
    mins = secs // 60
    rem_secs = secs % 60
    if mins < 60:
        return f"{mins}m{rem_secs}s" if rem_secs > 0 else f"{mins}m"
    hours = mins // 60
    rem_m = mins % 60
    return f"{hours}h {rem_m}m"


@contextmanager
def _suppress_console_logging():
    """Temporarily suppress console logging to avoid interference with Rich Live displays.

    This prevents log messages from breaking the Live rendering and causing
    the timeline to reprint its title multiple times.

    Only suppresses if the current log level is WARNING or higher - respects
    DEBUG/INFO levels when explicitly set for debugging.
    """
    flow_logger = logging.getLogger("flow")
    original_levels = {}

    # Check if user has explicitly enabled verbose logging (DEBUG or INFO)
    # If so, don't suppress - they want to see logs for debugging
    current_level = flow_logger.getEffectiveLevel()
    should_suppress = current_level >= logging.WARNING

    try:
        if should_suppress:
            for handler in flow_logger.handlers:
                if isinstance(handler, logging.StreamHandler):
                    original_levels[id(handler)] = handler.level
                    # Temporarily set to ERROR to suppress WARNING logs during Live display
                    handler.setLevel(logging.ERROR)
        yield
    finally:
        # Restore original levels
        if should_suppress:
            for handler in flow_logger.handlers:
                if isinstance(handler, logging.StreamHandler):
                    original_level = original_levels.get(id(handler))
                    if original_level is not None:
                        handler.setLevel(original_level)


@dataclass
class _Step:
    label: str
    show_bar: bool = False
    estimated_seconds: int | None = None
    show_estimate: bool = True
    status: str = "pending"  # pending | active | done | failed
    note: str = ""
    note_text: Text | None = None
    started_mono: float | None = None
    finished_mono: float | None = None
    last_percent: float | None = None
    last_speed: str | None = None
    last_eta: str | None = None
    # When resuming a wait step (e.g., SSH provisioning), seed the bar with prior elapsed seconds
    baseline_elapsed_seconds: int | None = None


class StepTimeline:
    """Render and control a multi-step timeline with minimal, tasteful UI.

    Adds tasteful animations for active labels and optional animated title using
    the centralized animation engine. Runs a lightweight render loop so that
    animations move even when no explicit progress updates are flowing.
    """

    def __init__(
        self,
        console: Console,
        title: str | None = None,
        *,
        enable_animations: bool = True,
        title_animation: str | None = None,  # "wave" | "pulse" | "shimmer" | None
        active_label_animation: str | None = "pulse",  # None to disable
    ):
        self.console = console
        self.title = title or ""
        self.steps: list[_Step] = []
        self._live: Live | None = None
        self._active_index: int | None = None
        # Animation options
        self._enable_animations = enable_animations
        self._title_animation = title_animation
        self._active_label_animation = active_label_animation
        # Logging suppressor context manager
        self._logging_suppressor = None
        # Global environment overrides
        # Resolve UI preferences with precedence: env > YAML config > defaults
        try:
            from flow.application.config.runtime import settings as _settings

            ui_cfg = dict(_settings.ui or {})
            anim_block = ui_cfg.get("animations", {}) if isinstance(ui_cfg, dict) else {}
            yaml_mode = (anim_block or {}).get("mode") if isinstance(anim_block, dict) else None
            yaml_simple = (
                bool(ui_cfg.get("simple_output", False)) if isinstance(ui_cfg, dict) else False
            )
        except Exception:  # noqa: BLE001
            yaml_mode = None
            yaml_simple = False

        env_mode = os.getenv("FLOW_ANIMATIONS", "").strip().lower() or (
            str(yaml_mode).lower() if yaml_mode else ""
        )
        # Respect simple output preference globally (calmer, non-animated)
        simple_env = os.getenv("FLOW_SIMPLE_OUTPUT", "").strip().lower()
        if (simple_env in {"1", "true", "yes"}) or yaml_simple:
            self._enable_animations = False
        if os.getenv("NO_COLOR"):
            self._enable_animations = False
        if env_mode in {"off", "0", "false", "disabled"}:
            self._enable_animations = False
        elif env_mode == "minimal":
            self._enable_animations = True
            # Keep spinner only; disable label/title animations
            self._title_animation = None
            self._active_label_animation = None
            # Slightly reduce cadence
            self._frame_interval = 0.1
        elif env_mode == "full":
            # Encourage richer animations if caller didn't explicitly set
            if self._title_animation is None:
                self._title_animation = "shimmer"
            if self._active_label_animation is None:
                self._active_label_animation = "wave"
        elif env_mode == "auto" or env_mode == "":
            # If caller didn't set explicit mode, enable auto
            if self._title_animation is None:
                self._title_animation = "auto"
            if self._active_label_animation is None:
                self._active_label_animation = "auto"
        # Animation cadence
        self._frame_interval = 0.08
        # When animations are disabled we still want time-based bars to tick,
        # but at a low cadence to keep CPU/IO minimal.
        if not self._enable_animations:
            self._frame_interval = 1.0

        # Background render loop
        self._render_thread: threading.Thread | None = None
        self._stop_event: threading.Event | None = None
        # Prevent concurrent Live.update() from multiple threads
        self._render_lock: threading.Lock = threading.Lock()

    def add_step(
        self,
        label: str,
        *,
        show_bar: bool = False,
        estimated_seconds: int | None = None,
        show_estimate: bool = True,
        baseline_elapsed_seconds: int | None = None,
    ) -> int:
        self.steps.append(
            _Step(
                label=label,
                show_bar=show_bar,
                estimated_seconds=estimated_seconds,
                show_estimate=show_estimate,
                baseline_elapsed_seconds=baseline_elapsed_seconds,
            )
        )
        self.start()
        return len(self.steps) - 1

    def start(self) -> None:
        if self._live is not None:
            return
        # Suppress console logging during Live display to prevent interference
        self._logging_suppressor = _suppress_console_logging()
        self._logging_suppressor.__enter__()

        self._live = Live(Text(""), console=self.console, refresh_per_second=20, transient=True)
        self._live.__enter__()
        self._render()
        # Start lightweight render loop in terminals (even when animations are off)
        # so time-based progress bars keep ticking smoothly.
        if getattr(self.console, "is_terminal", True) and not os.getenv("CI"):
            self._stop_event = threading.Event()
            self._render_thread = threading.Thread(target=self._render_loop, daemon=True)
            self._render_thread.start()

    def _render_loop(self) -> None:
        # Keep refreshing while live is active; only minimal work
        while self._live is not None and self._stop_event and not self._stop_event.is_set():
            has_active = self._active_index is not None
            if has_active or self._title_animation:
                # Re-render to advance spinner/animated text phases
                self._render()
            # Keep cadence light to avoid CPU burn
            time.sleep(self._frame_interval)

    def _format_bar(self, step: _Step) -> Text:
        if step.estimated_seconds and step.started_mono and step.status == "active":
            # Include baseline elapsed so bar resumes realistically, unless the baseline
            # dwarfs the estimate (e.g., very old instance age). In that case, anchor the
            # bar to the local session elapsed so the visual matches the displayed text.
            baseline = step.baseline_elapsed_seconds or 0
            elapsed = time.monotonic() - step.started_mono
            if baseline > (step.estimated_seconds or 0) * 2:
                pct = min(elapsed / step.estimated_seconds, 0.95)
            else:
                pct = min((baseline + elapsed) / step.estimated_seconds, 0.95)
        else:
            pct = step.last_percent if step.last_percent is not None else 0.0
        # Use gradient style with theme accent; add a subtle shimmer edge
        width = 28
        bar = animation_engine.progress_bar(pct, width=width, style="gradient", animated=True)
        # Ensure filled region uses theme accent (blue-ish) for clarity
        try:
            bar_color = (
                theme_manager.get_color("aep.accent") or theme_manager.get_color("accent") or "cyan"
            )
            # Compute filled region including the gradient edge block
            filled8 = int(pct * width * 8)
            full_blocks = filled8 // 8
            partial = filled8 % 8
            start = 1  # inside the leading '['
            end = 1 + full_blocks + (1 if (partial > 0 and full_blocks < width) else 0)
            if end > start:
                bar.stylize(bar_color, start, end)
        except Exception:  # noqa: BLE001
            pass
        # Compose status line pieces
        extra = []
        if step.estimated_seconds and step.started_mono:
            baseline = step.baseline_elapsed_seconds or 0
            wall = baseline + int(time.monotonic() - step.started_mono)

            # When baseline (instance age) is very large, avoid showing inflated elapsed.
            if wall > step.estimated_seconds * 2:
                local_only = int(time.monotonic() - step.started_mono)
                if step.show_estimate:
                    extra.append(
                        f"{_fmt_duration(local_only)} elapsed  ~{_fmt_duration(int(step.estimated_seconds))}"
                    )
                else:
                    extra.append(f"{_fmt_duration(local_only)} elapsed")
            else:
                shown_elapsed = min(wall, step.estimated_seconds)
                plus = "+" if wall > step.estimated_seconds else ""
                if step.show_estimate:
                    extra.append(
                        f"{_fmt_duration(int(shown_elapsed))}{plus}/{_fmt_duration(int(step.estimated_seconds))}"
                    )
                else:
                    extra.append(f"{_fmt_duration(int(shown_elapsed))}{plus}")
        if step.last_speed:
            extra.append(step.last_speed)
        if step.last_eta:
            extra.append(f"ETA {step.last_eta}")
        extra_text = ("  " + "  ".join(extra)) if extra else ""
        return Text.assemble("  ", bar, extra_text)

    def _format_line(self, idx: int, step: _Step) -> list[Text]:
        indent = "  "
        lines: list[Text] = []

        if step.status == "pending":
            lines.append(Text(f"{indent}  {step.label}", style="dim"))
        elif step.status == "active":
            # ASCII-safe spinner selection
            ascii_only = False
            try:
                enc = getattr(self.console, "encoding", None)
                if not enc or "UTF" not in str(enc).upper() or os.getenv("FLOW_ASCII") == "1":
                    ascii_only = True
            except Exception:  # noqa: BLE001
                ascii_only = False
            spinner_frames = (
                animation_engine.SPINNERS["line"]
                if ascii_only
                else animation_engine.SPINNERS["dots"]
            )
            spinner_phase = animation_engine.get_phase(0.8)
            spinner = animation_engine.get_spinner_frame(spinner_frames, spinner_phase)

            # Animated active label (subtle)
            label_text = Text(step.label)
            chosen = self._select_active_label_animation(step)
            if chosen:
                phase = animation_engine.get_phase(1.6)
                if chosen == "wave":
                    label_text = animation_engine.wave_pattern(step.label, phase, intensity=0.6)
                elif chosen == "pulse":
                    label_text = animation_engine.pulse_effect(step.label, phase, intensity=0.7)
                elif chosen == "shimmer":
                    label_text = animation_engine.shimmer_effect(step.label, phase, intensity=0.5)

            accent = theme_manager.get_color("accent")
            header = Text(indent) + Text(spinner, style=accent) + Text(" ") + label_text
            lines.append(header)
            if step.show_bar:
                lines.append(self._format_bar(step))
            if step.note_text is not None:
                lines.append(step.note_text)
        elif step.status == "done":
            # Duration display (human-friendly)
            dur = ""
            if step.started_mono and step.finished_mono:
                local_delta = int(step.finished_mono - step.started_mono)
                dur_secs = local_delta

                dur = f" ({_fmt_duration(int(dur_secs))})"
            note = f" – {step.note}" if step.note else ""
            try:
                check_color = (
                    theme_manager.get_color("success")
                    or theme_manager.get_color("default")
                    or "white"
                )
            except Exception:  # noqa: BLE001
                check_color = "white"
            line = Text(indent) + Text("✓ ", style=check_color) + Text(f"{step.label}{dur}{note}")
            lines.append(line)
        else:  # failed
            note = f" – {step.note}" if step.note else ""
            from flow.cli.utils.theme_manager import theme_manager as _tm

            line = (
                Text(indent)
                + Text("✗ ", style=_tm.get_color("error"))
                + Text(f"{step.label}{note}")
            )
            lines.append(line)

        return lines

    def _render(self) -> None:
        parts: list[Text] = []
        if self.title:
            chosen_title_anim = None
            if self._title_animation and self._enable_animations:
                if self._title_animation == "auto":
                    # Titles default to subtle shimmer for tasteful motion
                    chosen_title_anim = "shimmer"
                elif self._title_animation == "random":
                    # Avoid playful bounce for headers
                    chosen_title_anim = random.choice(["wave", "pulse", "shimmer"])
                else:
                    chosen_title_anim = self._title_animation
            if chosen_title_anim:
                phase = animation_engine.get_phase(2.4)
                if chosen_title_anim == "wave":
                    parts.append(animation_engine.wave_pattern(self.title, phase, intensity=0.5))
                elif chosen_title_anim == "pulse":
                    parts.append(animation_engine.pulse_effect(self.title, phase, intensity=0.6))
                elif chosen_title_anim == "shimmer":
                    parts.append(animation_engine.shimmer_effect(self.title, phase, intensity=0.5))
                else:
                    parts.append(Text(self.title))
            else:
                parts.append(Text(self.title))
        for i, step in enumerate(self.steps):
            for line in self._format_line(i, step):
                parts.append(line)
        display = Text("\n").join(parts) if parts else Text("")
        if self._live:
            # Guard Live.update from concurrent access by the background loop
            with self._render_lock:
                self._live.update(display)

    # Public refresh method to avoid reaching into private internals
    def refresh(self) -> None:
        self._render()

    def start_step(self, index: int) -> None:
        self._active_index = index
        step = self.steps[index]
        step.status = "active"
        step.started_mono = time.monotonic()
        self._render()

    def update_active(
        self,
        *,
        percent: float | None = None,
        speed: str | None = None,
        eta: str | None = None,
        message: str | None = None,
    ) -> None:
        if self._active_index is None:
            return
        step = self.steps[self._active_index]
        if percent is not None:
            # Keep within [0, 0.99] to avoid looking finished prematurely
            clamped = max(0.0, min(percent, 0.99))
            step.last_percent = clamped
        if speed is not None:
            step.last_speed = speed
        if eta is not None:
            step.last_eta = eta
        if message:
            # Augment label temporarily for extra context
            step.note = message
        self._render()

    def set_active_hint_text(self, text: Text) -> None:
        """Set a rich hint Text under the active step."""
        if self._active_index is None:
            return
        step = self.steps[self._active_index]
        step.note_text = text
        self._render()

    def complete_step(self, note: str | None = None) -> None:
        if self._active_index is None:
            return
        idx = self._active_index
        step = self.steps[idx]
        step.status = "done"
        step.finished_mono = time.monotonic()
        if note:
            step.note = note
        self._active_index = None
        self._render()

    def fail_step(self, message: str) -> None:
        if self._active_index is None:
            return
        step = self.steps[self._active_index]
        step.status = "failed"
        step.note = message
        self._active_index = None
        self._render()

    def finish(self) -> None:
        if self._live is None:
            return
        # Ensure no step remains marked active
        self._active_index = None
        # Final render without spinners/bars
        self._render()
        # Stop render loop first
        if self._stop_event is not None:
            self._stop_event.set()
        if self._render_thread is not None:
            try:
                self._render_thread.join(timeout=1.0)
                # If thread is still alive, try a short extra wait once more to ensure cleanup
                if self._render_thread.is_alive():
                    self._render_thread.join(timeout=0.5)
            except Exception:  # noqa: BLE001
                pass
        self._live.__exit__(None, None, None)
        self._live = None

        # Restore logging
        if self._logging_suppressor is not None:
            try:
                self._logging_suppressor.__exit__(None, None, None)
                self._logging_suppressor = None
            except Exception:  # noqa: BLE001
                pass

    # Convenience to update title dynamically
    def set_title(self, title: str, *, animation: str | None = None) -> None:
        self.title = title
        if animation is not None:
            self._title_animation = animation
        self._render()

    # Heuristic selection for active label animation
    def _select_active_label_animation(self, step: _Step) -> str | None:
        if not self._enable_animations:
            return None
        choice = self._active_label_animation
        if choice is None:
            return None
        if choice == "auto":
            # For long-running steps with a bar, prefer pulse; for short ones skip
            if step.show_bar and step.estimated_seconds:
                if step.estimated_seconds >= 120:
                    return "pulse"
                if step.estimated_seconds >= 30:
                    return "wave"
                return None
            # Non-bar steps are usually brief (e.g., Connecting); mild pulse
            return "pulse"
        if choice == "random":
            # Pick from subtle set to avoid playful bounce on labels
            return random.choice(["pulse", "wave", "shimmer"])
        return choice
