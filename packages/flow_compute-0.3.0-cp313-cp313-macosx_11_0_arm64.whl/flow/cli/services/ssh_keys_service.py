"""SSH key business logic: data fetching, enrichment, aggregation, resolution.

Extracted from cli/commands/ssh_keys.py to separate business logic from
CLI rendering and Click command definitions.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, TypedDict

from flow.adapters.providers.builtin.mithril.domain.models import PlatformSSHKey
from flow.core.keys.identity import (
    _load_all as load_all_key_metadata,
)
from flow.core.keys.identity import (
    get_local_key_private_path as _id_get_local,
)
from flow.core.utils.ssh_key import (
    LocalSSHKey,
    discover_local_ssh_keys,
    match_local_key_to_platform,
)
from flow.domain.ssh.resolver import SmartSSHKeyResolver

logger = logging.getLogger(__name__)

# Constants shared with the CLI command module
AUTO_KEY_PREFIX = "flow-auto-"
FLOW_PREFIX = "flow:"
PLATFORM_ID_PREFIX = "sshkey_"
AUTO_SENTINEL = "_auto_"


class EnrichedKeyMapping(TypedDict):
    """Result of enriching and mapping local SSH keys with platform data.

    Attributes:
        user_keys: List of (name, path) tuples for user-provided keys.
        auto_keys: List of (name, path) tuples for auto-generated keys.
        key_tuple_to_platform: Maps (key_name, path_str) tuples to platform_id strings.
    """

    user_keys: list[tuple[str, Path]]
    auto_keys: list[tuple[str, Path]]
    key_tuple_to_platform: dict[tuple[str, str], str]


class KeyLookupResult(TypedDict):
    """Result of looking up a key across all sources."""

    platform_key: PlatformSSHKey | None  # Key object if exists on platform
    platform_id: str | None  # Platform ID (from metadata, config, or platform)
    local_path: Path | None  # Local private key path
    display_name: str  # Name to show in UI
    is_configured: bool  # In config.yaml
    in_metadata: bool  # Has entry in metadata.json


def fetch_ssh_key_data(flow) -> tuple[list, list[LocalSSHKey], list[PlatformSSHKey]]:
    """Fetch SSH key data from config, local system, and platform.

    Returns:
        tuple: (configured_keys, local_keys, platform_keys)
    """
    configured_keys = flow.config.provider_config.get("ssh_keys", [])
    local_keys = discover_local_ssh_keys()

    # Get platform keys via provider
    raw_keys = flow.list_platform_ssh_keys()
    platform_keys = [PlatformSSHKey.from_api(rk) for rk in raw_keys]

    return configured_keys, local_keys, platform_keys


def enrich_and_map_keys(
    local_keys: list[LocalSSHKey],
    platform_keys: list[PlatformSSHKey],
    metadata: dict[str, Any],
) -> EnrichedKeyMapping:
    """Enrich local keys with platform data and create mappings.

    This consolidates key enrichment and platform mapping into a single pass:
    1. Starts with raw filesystem scan (e.g., "id_ed25519")
    2. Uses metadata to enrich with platform names and build platform_id mappings
    3. Does cryptographic matching (pubkey/fingerprint) for any unmapped keys
    4. Categorizes into user_keys vs auto_keys for display

    Args:
        local_keys: List of LocalSSHKey objects from discover_local_ssh_keys().
        platform_keys: List of PlatformSSHKey objects from platform API.
        metadata: Metadata dict from ~/.flow/ identity store.

    Returns:
        EnrichedKeyMapping with user_keys, auto_keys, and key_tuple_to_platform.
    """
    user_keys = []
    auto_keys = []
    key_tuple_to_platform = {}

    # Phase 1: Enrich keys using metadata (authoritative source)
    metadata_processed_paths = set()

    scanned_user_keys = []
    scanned_auto_keys = []
    for key_pair in local_keys:
        if key_pair.name.startswith(AUTO_KEY_PREFIX):
            scanned_auto_keys.append((key_pair.name, key_pair.private_key_path))
        else:
            scanned_user_keys.append((key_pair.name, key_pair.private_key_path))

    platform_key_ids = {k.fid for k in platform_keys}

    for platform_id, info in metadata.items():
        if not isinstance(info, dict) or "private_key_path" not in info:
            continue

        private_path = Path(info["private_key_path"])
        file_exists = private_path.exists()

        if file_exists:
            private_path = private_path.resolve()

        path_str = str(private_path)
        key_name = info.get("key_name", private_path.stem)
        is_auto = info.get("auto_generated", False) or key_name.startswith(AUTO_KEY_PREFIX)

        if file_exists and path_str not in metadata_processed_paths:
            scanned_user_keys = [(n, p) for n, p in scanned_user_keys if str(p) != path_str]
            scanned_auto_keys = [(n, p) for n, p in scanned_auto_keys if str(p) != path_str]
            metadata_processed_paths.add(path_str)

        if is_auto:
            display_name = (
                f"{FLOW_PREFIX}{key_name}" if not key_name.startswith(FLOW_PREFIX) else key_name
            )
            auto_keys.append((display_name, private_path))
        else:
            user_keys.append((key_name, private_path))

        if platform_id in platform_key_ids:
            key_tuple_to_platform[(key_name, str(private_path))] = platform_id
        else:
            logger.debug(
                f"Key {key_name} has stale metadata (platform_id={platform_id} not on platform)"
            )

    # Phase 2: Cryptographic matching for unmapped keys
    for key_pair in local_keys:
        path_resolved = str(key_pair.private_key_path.resolve())
        if (key_pair.name, path_resolved) in key_tuple_to_platform:
            continue

        platform_id = match_local_key_to_platform(
            key_pair.private_key_path, platform_keys, match_by_name=True
        )

        if platform_id:
            key_tuple_to_platform[(key_pair.name, path_resolved)] = platform_id

            if key_pair.name.startswith(AUTO_KEY_PREFIX):
                display_name = (
                    f"{FLOW_PREFIX}{key_pair.name}"
                    if not key_pair.name.startswith(FLOW_PREFIX)
                    else key_pair.name
                )
                auto_keys.append((display_name, key_pair.private_key_path))
            else:
                user_keys.append((key_pair.name, key_pair.private_key_path))

    return {
        "user_keys": user_keys,
        "auto_keys": auto_keys,
        "key_tuple_to_platform": key_tuple_to_platform,
    }


def aggregate_all_keys(
    configured_keys,
    user_keys,
    auto_keys,
    platform_keys,
    key_tuple_to_platform,
    metadata,
    show_auto,
) -> list[dict]:
    """Aggregate all keys from all sources into a unified list with computed properties.

    Returns a list of dicts with keys: key_id, name, path, platform_id, has_local,
    on_platform, is_default, is_auto, is_required.
    """
    platform_keys_by_id = {pkey.fid: pkey for pkey in platform_keys}
    required_key_ids = {pkey.fid for pkey in platform_keys if getattr(pkey, "required", False)}

    configured_platform_ids = {
        ck for ck in configured_keys if isinstance(ck, str) and ck.startswith(PLATFORM_ID_PREFIX)
    }

    all_keys = {}

    for name, path in user_keys:
        platform_id = key_tuple_to_platform.get((name, str(path)), "")
        is_auto = name.startswith(FLOW_PREFIX) or name.startswith(AUTO_KEY_PREFIX)

        if is_auto and not show_auto:
            continue

        key_id = platform_id if platform_id else str(path)

        if key_id not in all_keys:
            all_keys[key_id] = {
                "name": name,
                "path": path,
                "platform_id": platform_id,
                "is_auto": is_auto,
            }

    if show_auto:
        for name, path in auto_keys:
            platform_id = key_tuple_to_platform.get((name, str(path)), "")
            key_id = platform_id if platform_id else str(path)

            if key_id not in all_keys:
                all_keys[key_id] = {
                    "name": name,
                    "path": path,
                    "platform_id": platform_id,
                    "is_auto": True,
                }

    for pkey in platform_keys:
        is_auto = getattr(pkey, "name", "").startswith(AUTO_KEY_PREFIX)

        if is_auto and not show_auto:
            continue

        if pkey.fid not in all_keys:
            all_keys[pkey.fid] = {
                "name": getattr(pkey, "name", pkey.fid),
                "path": None,
                "platform_id": pkey.fid,
                "is_auto": is_auto,
            }

    for ck in configured_keys:
        if isinstance(ck, str) and ck.startswith(PLATFORM_ID_PREFIX) and ck not in all_keys:
            metadata_info = metadata.get(ck, {})
            local_path = None
            key_name = ck

            if metadata_info and "private_key_path" in metadata_info:
                local_path = Path(metadata_info["private_key_path"])
                key_name = metadata_info.get("key_name", ck)

                path_key = str(local_path)
                if path_key in all_keys:
                    all_keys[path_key]["platform_id"] = ck
                    continue

            all_keys[ck] = {
                "name": key_name,
                "path": local_path,
                "platform_id": ck,
                "is_auto": False,
            }

    rows = []
    for key_id, key_info in all_keys.items():
        has_local = False
        if key_info["path"]:
            path_obj = (
                key_info["path"]
                if isinstance(key_info["path"], Path)
                else Path(str(key_info["path"]))
            )
            has_local = path_obj.exists()

        on_platform = (
            key_info["platform_id"] in platform_keys_by_id if key_info["platform_id"] else False
        )
        is_default = (
            key_info["platform_id"] in configured_platform_ids if key_info["platform_id"] else False
        )

        if on_platform:
            platform_key = platform_keys_by_id[key_info["platform_id"]]
            display_name = getattr(platform_key, "name", key_info["name"])
        else:
            display_name = key_info["name"]

        if key_info["is_auto"]:
            display_name = display_name.replace(FLOW_PREFIX, "")

        is_required = (
            key_info["platform_id"] in required_key_ids if key_info["platform_id"] else False
        )

        rows.append(
            {
                "key_id": key_id,
                "name": display_name,
                "path": key_info["path"],
                "platform_id": key_info["platform_id"],
                "has_local": has_local,
                "on_platform": on_platform,
                "is_default": is_default,
                "is_auto": key_info["is_auto"],
                "is_required": is_required,
            }
        )

    rows.sort(key=lambda r: (not r["is_default"], not r["has_local"], r["name"].lower()))
    return rows


def compute_statistics(
    configured_keys, user_keys, platform_keys, key_tuple_to_platform
) -> tuple[int, int]:
    """Compute statistics about local-only and platform-only keys.

    Returns:
        tuple: (local_only_count, platform_only_count)
    """
    local_platform_ids = set(key_tuple_to_platform.values())
    local_only_count = 0
    for key_reference in configured_keys:
        if not isinstance(key_reference, str) or key_reference.startswith(PLATFORM_ID_PREFIX):
            continue

        p = Path(key_reference).expanduser().resolve()
        has_platform = any(
            pid for (name, path), pid in key_tuple_to_platform.items() if path == str(p)
        )
        if p.exists() and not has_platform:
            local_only_count += 1

    for name, path in user_keys:
        if not key_tuple_to_platform.get((name, str(path)), ""):
            local_only_count += 1

    platform_only_count = sum(1 for pkey in platform_keys if pkey.fid not in local_platform_ids)

    return local_only_count, platform_only_count


def sync_keys_to_platform(console, user_keys, key_tuple_to_platform, ssh_key_manager) -> int:
    """Sync local user keys to platform.

    Args:
        console: Rich console for output.
        user_keys: List of (name, path) tuples.
        key_tuple_to_platform: Existing mappings.
        ssh_key_manager: Provider SSH key manager.

    Returns:
        Number of keys synced.
    """
    from rich.text import Text

    from flow.cli.utils.step_progress import StepTimeline
    from flow.cli.utils.theme_manager import theme_manager as _tm

    synced_count = 0
    timeline = None

    try:
        timeline = StepTimeline(console, title="flow ssh-key", title_animation="auto")
        timeline.start()
        idx_sync = timeline.add_step("Uploading SSH keys", show_bar=True)
        timeline.start_step(idx_sync)

        accent = _tm.get_color("accent")
        hint = Text()
        hint.append("  Press ")
        hint.append("Ctrl+C", style=accent)
        hint.append(" to stop syncing. Keys already uploaded remain on platform.")
        timeline.set_active_hint_text(hint)
    except Exception:  # noqa: BLE001
        logger.debug("Failed to initialize timeline", exc_info=True)
        timeline = None

    try:
        for name, path in user_keys:
            pub_path = path.with_suffix(".pub")
            if not pub_path.exists():
                continue

            if (name, str(path)) in key_tuple_to_platform:
                console.print(f"  - {name} already synced")
                continue

            try:
                result = ssh_key_manager.get_or_create_key_if_file_path([str(path)])
                if result:
                    console.print(f"  ✓ Uploaded {name}")
                    synced_count += 1
            except Exception as e:  # noqa: BLE001
                from rich.markup import escape

                console.print(f"  ✗ Failed to upload {name}: {escape(str(e))}")
                logger.debug(f"Upload failed for {name}", exc_info=True)
    finally:
        if timeline is not None:
            timeline.complete_step()
            timeline.finish()

    return synced_count


def resolve_key_lookup(key_id: str, flow, ssh_key_manager, console) -> KeyLookupResult | None:
    """Resolve user input and fetch all relevant key data.

    Returns None if index resolution fails (early exit with error shown).
    """
    from flow.cli.ui.presentation.next_steps import render_next_steps_panel
    from flow.cli.utils.ssh_key_index_cache import SSHKeyIndexCache

    # Step 1: Handle index lookup
    resolved_id = key_id
    local_path_hint = None

    if key_id.isdigit() or key_id.startswith(":"):
        ref, err = SSHKeyIndexCache().resolve_index(key_id)
        if err:
            console.print(f"\n[error]{err}[/error]")
            try:
                render_next_steps_panel(
                    console,
                    [
                        "flow ssh-key list  [muted]— refresh indices[/muted]",
                        "Use index shortcuts: [accent]:N[/accent] or [accent]N[/accent]",
                    ],
                    title="Tips",
                )
            except Exception:  # noqa: BLE001
                console.print("[dim]Tip: Re-run 'flow ssh-key list' to refresh indices[/dim]")
            return None

        if ref:
            rtype = ref.get("type")
            rval = ref.get("ref", "")
            if rtype == "platform_id" or (isinstance(rval, str) and rval.startswith("sshkey_")):
                resolved_id = rval
            elif rtype == "local":
                lp = Path(rval).expanduser().resolve()
                if lp.exists():
                    local_path_hint = lp
                    resolved_id = lp.stem

    # Step 2: Fetch platform keys
    platform_keys = []
    try:
        raw = flow.list_platform_ssh_keys()
        platform_keys = [PlatformSSHKey.from_api(rk) for rk in raw]
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Failed to fetch platform keys: {e}")
        if ssh_key_manager:
            platform_keys = ssh_key_manager.list_keys()

    platform_keys_by_id = {k.fid: k for k in platform_keys}

    # Step 3: Load metadata and config
    metadata = load_all_key_metadata()
    configured_keys = flow.config.provider_config.get("ssh_keys", [])

    # Step 4: Find the key
    platform_key = None
    platform_id = None
    local_path = local_path_hint
    display_name = resolved_id

    # Try direct platform ID match
    if resolved_id.startswith("sshkey_"):
        platform_key = platform_keys_by_id.get(resolved_id)
        platform_id = resolved_id
        if platform_key:
            display_name = getattr(platform_key, "name", resolved_id)

    # Try metadata lookup (by name or ID)
    if not platform_key:
        for pid, meta in metadata.items():
            if meta.get("key_name") == resolved_id or pid == resolved_id:
                platform_id = pid
                display_name = meta.get("key_name", resolved_id)
                platform_key = platform_keys_by_id.get(pid)
                if "private_key_path" in meta:
                    p = Path(meta["private_key_path"])
                    if p.exists():
                        local_path = p
                break

    # Try platform name match
    if not platform_key:
        matches = [k for k in platform_keys if getattr(k, "name", "") == resolved_id]
        if len(matches) == 1:
            platform_key = matches[0]
            platform_id = platform_key.fid
            display_name = platform_key.name
        elif len(matches) > 1:
            console.print(f"\n[warning]Multiple keys found with name '{resolved_id}':[/warning]")
            for m in matches[:10]:
                console.print(f"  • {m.name} ({m.fid})")
            console.print("\n[dim]Please use the platform ID (sshkey_xxx)[/dim]")
            return None

    # Try local key resolution
    if not platform_key and ssh_key_manager:
        local_resolver = SmartSSHKeyResolver(ssh_key_manager)
        resolved_path = local_resolver.resolve_ssh_key(resolved_id)
        if resolved_path and resolved_path.exists():
            local_path = resolved_path
            display_name = resolved_path.stem
            if local_path:
                pub_path = local_path.with_suffix(".pub")
                if pub_path.exists():
                    for pk in platform_keys:
                        matched_id = match_local_key_to_platform(
                            local_path, [pk], match_by_name=True
                        )
                        if matched_id:
                            platform_key = pk
                            platform_id = pk.fid
                            break

    # Step 5: Try to find local path if we have platform key but no path yet
    if platform_key and not local_path:
        mapped = _id_get_local(platform_key.fid)
        if mapped and mapped.exists():
            local_path = mapped
        else:
            local_keys = discover_local_ssh_keys()
            for lk in local_keys:
                matched_id = match_local_key_to_platform(
                    lk.private_key_path, [platform_key], match_by_name=True
                )
                if matched_id:
                    local_path = lk.private_key_path
                    break

    # Step 6: Check if configured
    is_configured = False
    if platform_id:
        is_configured = platform_id in configured_keys
    elif local_path:
        is_configured = str(local_path) in configured_keys or display_name in configured_keys

    return {
        "platform_key": platform_key,
        "platform_id": platform_id,
        "local_path": local_path,
        "display_name": display_name,
        "is_configured": is_configured,
        "in_metadata": platform_id in metadata if platform_id else False,
    }
