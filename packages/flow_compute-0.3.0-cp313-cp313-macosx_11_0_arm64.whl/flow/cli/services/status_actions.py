"""High-level status actions extracted from the status command.

These helpers encapsulate fetching, filtering, and presentation for the
snapshot view and the single-task resolution flow, keeping the command slim.
"""

from __future__ import annotations

import logging
import os as _os
import sys as _sys

import flow.sdk.factory as sdk_factory

logger = logging.getLogger(__name__)


def _make_client():
    if _os.environ.get("PYTEST_CURRENT_TEST"):
        try:
            from flow.sdk.client import Flow as _Flow

            return _Flow()
        except (ImportError, ValueError):
            pass
    return sdk_factory.create_client(auto_init=True)


def _print_error(console, message: str) -> None:
    from flow.cli.utils.theme_manager import theme_manager as _tm

    color = _tm.get_color("error")
    console.print(f"[{color}]{message}[/{color}]")


def present_single_or_interactive(
    console,
    task_identifier: str,
    *,
    state: str | None,
    interactive: bool | None,
    flow_client=None,
) -> bool:
    """Present a single task, with interactive fallback on ambiguous matches.

    Resolves task and owner context concurrently to save 200-400ms.

    Returns True when handled (rendered), False to allow caller fallback.
    """
    from concurrent.futures import ThreadPoolExecutor

    from flow.cli.utils.task_resolver import resolve_task_identifier as _resolve

    try:
        from flow.cli.ui.presentation.animated_progress import (
            AnimatedEllipsisProgress as _AEP,
        )
    except ImportError:
        _AEP = None  # type: ignore

    def _resolve_task(client):
        return _resolve(client, task_identifier)

    def _resolve_owners(client):
        from flow.cli.ui.runtime.owner_resolver import OwnerResolver

        resolver = OwnerResolver(client)
        me = resolver.get_me()
        teammates = resolver.get_teammates_map(me=me)
        return me, teammates

    def _do_concurrent_resolve(client):
        with ThreadPoolExecutor(max_workers=2) as pool:
            task_future = pool.submit(_resolve_task, client)
            owner_future = pool.submit(_resolve_owners, client)
            task_result = task_future.result()
            try:
                owner_result = owner_future.result()
            except Exception:  # noqa: BLE001
                owner_result = (None, None)
        return task_result, owner_result

    if _AEP:
        with _AEP(console, "Looking up task", start_immediately=True):
            if flow_client is None:
                flow_client = _make_client()
            (task, error), (me, owner_map) = _do_concurrent_resolve(flow_client)
    else:
        flow_client = flow_client or _make_client()
        (task, error), (me, owner_map) = _do_concurrent_resolve(flow_client)

    if error and error.strip().lower().startswith("multiple tasks match"):
        return _handle_ambiguous_match(
            console, error, task_identifier, state, interactive, flow_client
        )

    if error:
        _print_error(console, error)
        return True

    from flow.cli.ui.facade.views import TaskDetailRenderer

    TaskDetailRenderer(console).render_task_details(task, me=me, owner_map=owner_map)  # type: ignore[arg-type]
    return True


def _handle_ambiguous_match(
    console,
    error: str,
    task_identifier: str,
    state: str | None,
    interactive: bool | None,
    flow_client,
) -> bool:
    """Handle ambiguous task resolution with interactive selection."""
    allow_interactive = interactive is True or (interactive is None and _sys.stdin.isatty())

    if not allow_interactive:
        _print_error(console, error)
        return True

    from flow.cli.ui.components import select_task
    from flow.cli.utils.task_fetcher import TaskFetcher as _Fetcher

    try:
        from flow.sdk.models import TaskStatus as _TS

        state_enum = _TS(state) if state else None
    except (ValueError, KeyError):
        state_enum = None

    fetcher = _Fetcher(flow_client)
    candidates = fetcher.fetch_for_resolution(limit=1000)
    if state_enum is not None:
        candidates = [t for t in candidates if getattr(t, "status", None) == state_enum]

    ident = task_identifier
    candidates = [
        t
        for t in candidates
        if getattr(t, "task_id", "").startswith(ident)
        or (getattr(t, "name", None) or "").startswith(ident)
    ]

    if not candidates:
        console.print(error)
        return True

    selected = select_task(candidates, title="Multiple matches \u2013 select a task")
    if not selected:
        return True

    from flow.cli.ui.facade.views import TaskPresenter

    TaskPresenter(console, flow_client=flow_client).present_single_task(
        getattr(selected, "task_id", task_identifier)
    )
    return True
