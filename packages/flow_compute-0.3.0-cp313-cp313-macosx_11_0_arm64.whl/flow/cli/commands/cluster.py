"""Manage Slurm overlay clusters on Flow instances.

Promotes the overlay cluster commands to a top-level ``flow cluster`` surface.
The same commands remain available under ``flow slurm overlay`` for backward
compatibility.
"""

from __future__ import annotations

import click

from flow.cli.app import OrderedDYMGroup
from flow.cli.commands.base import BaseCommand


class ClusterCommand(BaseCommand):
    """Manage Slurm overlay clusters on Flow instances."""

    @property
    def name(self) -> str:
        return "cluster"

    @property
    def help(self) -> str:
        return "Manage Slurm overlay clusters on instances"

    def get_command(self) -> click.Group:
        from flow.cli.commands.slurm_overlay import overlay_group

        @click.group(
            name="cluster",
            cls=OrderedDYMGroup,
            help=(
                "Manage Slurm overlay clusters on existing Flow instances.\n\n"
                "Overlay clusters organize running instances into Slurm clusters\n"
                "for batch job submission. They can be dissolved without terminating\n"
                "the underlying instances.\n\n"
                "\b\n"
                "Examples:\n"
                "  flow cluster create training -c my-gpu -w worker-1,worker-2\n"
                "  flow cluster ssh training\n"
                "  flow cluster jobs training\n"
                "  flow cluster dissolve training"
            ),
        )
        def cluster_group():
            pass

        # Copy subcommands from overlay_group without mutating the original
        for cmd_name in list(overlay_group.list_commands(None)):  # type: ignore[arg-type]
            cmd = overlay_group.get_command(None, cmd_name)  # type: ignore[arg-type]
            if cmd:
                cluster_group.add_command(cmd, name=cmd_name)

        return cluster_group


command = ClusterCommand()
