"""Visual feedback utilities for CLI commands.

Abstractions for success/error messages and visual feedback built on Rich.
"""

from __future__ import annotations

import os

from rich.console import Console
from rich.text import Text

from flow.cli.utils.theme_manager import theme_manager


class FeedbackStyle:
    """Configurable styles for feedback messages."""

    # Success styles (semantic: readable ink for text, bright icon for symbol)
    SUCCESS_COLOR = theme_manager.get_color("success")
    SUCCESS_ICON = "✓"
    SUCCESS_BORDER = theme_manager.get_color("success.border") or theme_manager.get_color("success")

    # Error styles
    ERROR_COLOR = theme_manager.get_color("error")
    ERROR_ICON = "✗"
    ERROR_BORDER = theme_manager.get_color("error.border") or theme_manager.get_color("error")

    # Info styles
    INFO_COLOR = theme_manager.get_color("info")
    INFO_ICON = "ℹ"
    INFO_BORDER = theme_manager.get_color("info.border") or theme_manager.get_color("info")


class Feedback:
    """Provides visual feedback for CLI operations."""

    def __init__(self, console: Console | None = None):
        """Initialize feedback with optional console override."""
        self.console = console or theme_manager.create_console()
        self.style = FeedbackStyle()
        self.simple_mode = os.environ.get("FLOW_SIMPLE_OUTPUT", "").lower() in ("1", "true", "yes")

    def success(
        self,
        message: str,
        title: str | None = None,
        subtitle: str | None = None,
    ) -> None:
        """Display a success message with visual styling."""
        self._display_feedback(
            message=message,
            title=title or "Success",
            subtitle=subtitle,
            icon=self.style.SUCCESS_ICON,
            color=self.style.SUCCESS_COLOR,
        )

    def error(
        self,
        message: str,
        title: str | None = None,
        subtitle: str | None = None,
    ) -> None:
        """Display an error message with visual styling."""
        self._display_feedback(
            message=message,
            title=title or "Error",
            subtitle=subtitle,
            icon=self.style.ERROR_ICON,
            color=self.style.ERROR_COLOR,
        )

    def info(
        self,
        message: str,
        title: str | None = None,
        subtitle: str | None = None,
        *,
        neutral_body: bool = False,
        title_color: str | None = None,
    ) -> None:
        """Display an informational message with visual styling."""
        self._display_feedback(
            message=message,
            title=title or "Info",
            subtitle=subtitle,
            icon=self.style.INFO_ICON,
            color=self.style.INFO_COLOR,
            title_color=title_color,
            neutral_body=neutral_body,
        )

    def _display_feedback(
        self,
        message: str,
        title: str,
        icon: str,
        color: str,
        subtitle: str | None = None,
        *,
        title_color: str | None = None,
        neutral_body: bool = False,
    ) -> None:
        """Display formatted feedback: icon + title headline, indented body below."""
        if self.simple_mode:
            self.console.print(f"{icon} {title}: {message}", style=color)
            return

        _title_color = title_color or color

        # Headline
        self.console.print()
        self.console.print(
            Text.assemble(
                (f"{icon} ", f"bold {_title_color}"),
                (title, f"bold {_title_color}"),
            )
        )

        # Body — preserve Rich markup by printing through console.print
        content = Text.from_markup(message)
        if not content.spans and not neutral_body:
            content.stylize(color)

        for segment in content.split("\n"):
            if segment.plain.strip():
                indented = Text("  ")
                indented.append_text(segment)
                self.console.print(indented)

        if subtitle:
            self.console.print(f"  [muted]{subtitle}[/muted]")
        self.console.print()


# Global feedback instance for convenience
feedback = Feedback()
