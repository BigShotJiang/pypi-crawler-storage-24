"""Deploy command -- deploy serverless functions with schedules and web endpoints.

Parses a user script to discover ``@app.function()`` and ``@app.cls()``
declarations that have ``schedule`` or ``@flow.web_endpoint()`` decorators,
then creates the corresponding K8s + Temporal resources via the serverless
backend's DeployWorkflow.
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

import click

from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.error_handling import cli_error_guard

logger = logging.getLogger(__name__)


def _discover_functions(module: Any) -> list[dict[str, Any]]:
    """Walk module attributes and collect deployable function descriptors.

    A function is deployable if it has a ``schedule`` or a
    ``__flow_web_endpoint__`` attribute (set by ``@flow.web_endpoint()``).

    Returns:
        List of dicts with keys: name, schedule, web_endpoint, image, gpu.
    """
    from flow.sdk.decorators import RemoteFunction

    results: list[dict[str, Any]] = []
    for attr_name in dir(module):
        obj = getattr(module, attr_name)

        # RemoteFunction instances (from @app.function())
        if isinstance(obj, RemoteFunction):
            schedule = obj.schedule
            web_ep = getattr(obj.func, "__flow_web_endpoint__", None)
            if schedule is not None or web_ep is not None:
                results.append(
                    {
                        "name": obj.func_name,
                        "schedule": schedule,
                        "web_endpoint": web_ep,
                        "image": obj.image,
                        "gpu": obj.gpu,
                    }
                )

        # WrappedClass instances (from @app.cls()) -- check for web endpoint methods
        if hasattr(obj, "__wrapped__"):
            user_cls = obj.__wrapped__
            for method_name in dir(user_cls):
                method = getattr(user_cls, method_name)
                web_ep = getattr(method, "__flow_web_endpoint__", None)
                if web_ep is not None:
                    results.append(
                        {
                            "name": f"{user_cls.__name__}.{method_name}",
                            "schedule": None,
                            "web_endpoint": web_ep,
                            "image": None,
                            "gpu": None,
                        }
                    )

    return results


def _import_script(script_path: str) -> Any:
    """Import a Python script as a module.

    Args:
        script_path: Path to the .py file.

    Returns:
        Imported module object.

    Raises:
        click.ClickException: If the script cannot be loaded.
    """
    path = Path(script_path).resolve()
    if not path.exists():
        raise click.ClickException(f"Script not found: {script_path}")
    if not path.suffix == ".py":
        raise click.ClickException(f"Expected a .py file, got: {path.name}")

    module_name = path.stem

    # Add script's parent to sys.path so local imports work
    parent = str(path.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise click.ClickException(f"Cannot load module from: {script_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


class DeployCommand(BaseCommand):
    """Deploy serverless functions with schedules and web endpoints."""

    @property
    def name(self) -> str:
        return "deploy"

    @property
    def help(self) -> str:
        return "Deploy functions to serverless backend"

    def get_command(self) -> click.Command:
        @click.command(name=self.name)
        @click.argument("script_path")
        @click.option(
            "--dry-run",
            "-d",
            is_flag=True,
            help="Show what would be deployed without making changes",
        )
        @click.option("--json", "output_json", is_flag=True, help="Output JSON")
        @click.pass_context
        @cli_error_guard(self)
        def deploy(ctx: click.Context, script_path: str, dry_run: bool, output_json: bool) -> None:
            """Deploy functions with schedules or web endpoints.

            \b
            Examples:
              flow deploy app.py              # Deploy all scheduled/web functions
              flow deploy app.py --dry-run    # Preview without deploying
            """
            self._execute(script_path, dry_run=dry_run, output_json=output_json)

        return deploy

    def _execute(self, script_path: str, *, dry_run: bool, output_json: bool) -> None:
        # Import the user script
        console.print(f"Loading [accent]{script_path}[/accent]...")
        module = _import_script(script_path)

        # Discover deployable functions
        functions = _discover_functions(module)
        if not functions:
            console.print(
                "[warning]No deployable functions found.[/warning] "
                "Functions must have a schedule or @flow.web_endpoint() decorator."
            )
            return

        if output_json:
            from flow.cli.utils.json_output import print_json

            print_json(
                {
                    "functions": functions,
                    "dry_run": dry_run,
                }
            )
            return

        # Display discovered functions
        console.print(f"\nDiscovered {len(functions)} deployable function(s):\n")
        for fn in functions:
            label = fn["name"]
            parts: list[str] = []
            if fn.get("schedule"):
                sched = fn["schedule"]
                expr = getattr(sched, "expression", None) or str(sched)
                parts.append(f"schedule={expr}")
            if fn.get("web_endpoint"):
                method = fn["web_endpoint"].get("method", "POST")
                parts.append(f"web_endpoint({method})")
            if fn.get("gpu"):
                parts.append(f"gpu={fn['gpu']}")
            detail = ", ".join(parts)
            console.print(f"  [accent]{label}[/accent]  {detail}")

        if dry_run:
            console.print("\n[dim]Dry run -- no resources created.[/dim]")
            return

        # Deploy via the serverless provider's DeployWorkflow
        self._deploy_functions(functions)

    def _deploy_functions(self, functions: list[dict[str, Any]]) -> None:
        """Start a DeployWorkflow for the given functions."""
        import flow.sdk.factory as sdk_factory

        client = sdk_factory.create_client(auto_init=True)
        provider = client.provider

        # Check that we're using the serverless provider
        if provider.name != "serverless":
            console.print(
                "[warning]Deploy requires the serverless backend.[/warning]\n"
                "Set FLOW_PROVIDER=serverless in your environment or "
                "use FlowApp(backend='serverless') in your script."
            )
            return

        console.print("\nDeploying functions...")

        from flow.sdk.models import TaskConfig

        for fn in functions:
            name = fn["name"]
            config = TaskConfig(
                name=f"deploy-{name}",
                command=["echo", "deployed"],
                image=fn["image"],
                schedule=fn["schedule"],
                web_endpoint=bool(fn["web_endpoint"]),
            )

            task = provider.submit_task(
                instance_type=fn["gpu"] or "cpu",
                config=config,
            )
            console.print(f"  [success]Deployed[/success] {name}  (workflow={task.task_id})")

        console.print("\nDone.")


# Export command instance
command = DeployCommand()
