"""Init command -- generate a task config file.

Creates a clean, scannable YAML task config with sensible defaults.
Seed values via flags; SSH keys are auto-detected from the local environment.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Sequence
from pathlib import Path

import click

from flow.application.config.config import Config
from flow.cli.commands.base import BaseCommand, console
from flow.cli.commands.input_types import PortsExpr, merge_ports_expr
from flow.sdk.models.task_config import TaskConfig


def _default_name() -> str:
    """Derive a task name from the current directory.

    Sanitizes to match TaskConfig name pattern: ^[a-zA-Z0-9][a-zA-Z0-9._-]*$
    Falls back to "my-task" if the directory name is unusable.
    """
    try:
        dir_name = Path.cwd().name
    except Exception:  # noqa: BLE001
        return "my-task"
    # Replace invalid characters with hyphens
    sanitized = re.sub(r"[^a-zA-Z0-9._-]", "-", dir_name)
    # Strip leading non-alphanumeric characters
    sanitized = re.sub(r"^[^a-zA-Z0-9]+", "", sanitized)
    # Strip trailing hyphens
    sanitized = sanitized.rstrip("-")
    if not sanitized:
        return "my-task"
    return sanitized


def _expand_env_items(items: Iterable[str]) -> list[str]:
    """Expand comma-separated env items.

    If a single --env value contains commas AND every comma-separated
    piece contains '=', treat them as separate KEY=VALUE pairs.
    Otherwise treat the whole string as one item (safe for values
    like HOSTS=a,b,c).
    """
    expanded: list[str] = []
    for item in items:
        if "," in item:
            parts = item.split(",")
            if all("=" in p for p in parts):
                expanded.extend(parts)
                continue
        expanded.append(item)
    return expanded


def _parse_env(items: Iterable[str]) -> dict[str, str]:
    env: dict[str, str] = {}
    for it in _expand_env_items(items):
        if "=" not in it:
            continue
        k, v = it.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k:
            env[k] = v
    return env


def _write_output(text: str, output: str | None, force: bool) -> None:
    if output:
        path = Path(output)
        if path.exists() and not force:
            raise click.ClickException(
                f"Output file already exists: {path}. Use --force to overwrite."
            )
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        console.print(f"[success]✓[/success] Wrote config to [repr.path]{path}[/repr.path]")
    else:
        click.echo(text, nl=False)


def _detect_ssh_keys() -> list[str] | None:
    """Auto-detect SSH keys from config or local filesystem."""
    try:
        cfg = Config.from_env(require_auth=False)
        keys_val = (
            cfg.provider_config.get("ssh_keys") if isinstance(cfg.provider_config, dict) else None
        )
        if isinstance(keys_val, list) and keys_val:
            return [str(k).strip() for k in keys_val if str(k).strip()]
    except Exception:  # noqa: BLE001
        pass

    candidates = [
        Path.home() / ".ssh" / "id_ed25519",
        Path.home() / ".ssh" / "id_rsa",
        Path.home() / ".flow" / "keys" / "id_ed25519",
        Path.home() / ".flow" / "keys" / "id_rsa",
    ]
    for p in candidates:
        try:
            if p.exists() and p.is_file():
                return [str(p)]
        except Exception:  # noqa: BLE001
            continue
    return None


def _generate_task_yaml(
    name: str | None,
    unique_name: bool,
    instance_type: str | None,
    min_gpu_memory_gb: int | None,
    command: str | None,
    image: str | None,
    env_items: Iterable[str],
    ports: list[int],
    priority: str | None,
    max_price_per_hour: float | None,
    ssh_keys: list[str] | None = None,
) -> str:
    """Build a clean, scannable task YAML config string.

    Required fields are uncommented at the top; optional fields are
    commented out with short inline docs. Validates all seeded values
    through TaskConfig before emitting.
    """
    resolved_name = name or _default_name()

    # Build data dict for validation
    data: dict[str, object] = {}
    data["name"] = resolved_name
    data["unique_name"] = False  # deterministic output; set real value in YAML

    if instance_type and min_gpu_memory_gb:
        min_gpu_memory_gb = None
    if instance_type:
        data["instance_type"] = instance_type
    elif min_gpu_memory_gb:
        data["min_gpu_memory_gb"] = int(min_gpu_memory_gb)
    else:
        data["instance_type"] = "8xb200"

    if image:
        data["image"] = image
    data["command"] = command or 'echo "Hello from Flow!"\nnvidia-smi'

    env_map = _parse_env(env_items)
    if env_map:
        data["env"] = env_map
    if ports:
        data["ports"] = ports
    if priority:
        data["priority"] = priority
    if max_price_per_hour is not None:
        data["max_price_per_hour"] = float(max_price_per_hour)
    if ssh_keys:
        keys = [str(k).strip() for k in ssh_keys if str(k).strip()]
        if keys:
            data["ssh_keys"] = keys

    # Validate through TaskConfig
    TaskConfig(**data)

    # Build YAML output as a progressively-disclosed template.
    # Top: essentials a new user needs. Bottom: advanced capabilities.
    # Section headers make the template scannable during demos.
    COL = 42  # column where inline comments start

    def _commented(field: str, hint: str) -> str:
        """Format a commented field with aligned inline hint."""
        left = f"# {field}"
        return f"{left:<{COL}}{hint}"

    lines: list[str] = []
    lines.append("# Flow task config -- submit with: flow submit task.yaml")
    lines.append("# Fields left unspecified are intelligently inferred by Flow.")
    lines.append("# Uncomment and customize any section below as needed.")

    # ── Essentials ────────────────────────────────────────────────────
    lines.append("")
    lines.append(f"name: {resolved_name}")

    if min_gpu_memory_gb:
        lines.append(f"min_gpu_memory_gb: {int(min_gpu_memory_gb)}")
        lines.append(_commented("instance_type: 8xb200", "# alternative: b200 | 8xb200 | h100"))
    else:
        it_val = instance_type or "8xb200"
        lines.append(f"instance_type: {it_val}")
        lines.append(_commented("min_gpu_memory_gb: 40", "# alternative: any GPU with >= N GB"))

    if image:
        lines.append(f"image: {image}")
    else:
        lines.append(
            _commented("image: nvidia/cuda:12.1.0-runtime-ubuntu22.04", "# optional: Docker image")
        )

    cmd_val = command or 'echo "Hello from Flow!"\nnvidia-smi'
    lines.append("")
    lines.append("command: |")
    for cmd_line in cmd_val.splitlines():
        lines.append(f"  {cmd_line}")

    # ── Environment ───────────────────────────────────────────────────
    lines.append("")
    if env_map:
        lines.append("env:")
        for k, v in env_map.items():
            lines.append(f'  {k}: "{v}"')
    else:
        lines.append("# env:")
        lines.append('#   WANDB_API_KEY: "..."')
        lines.append("#   DATASET: imagenet")

    # ── Storage ───────────────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Storage --")
    lines.append("#")
    lines.append("# volumes:")
    lines.append("#   - name: training-data")
    lines.append("#     size_gb: 100")
    lines.append("#     mount_path: /data")
    lines.append("#")
    lines.append(_commented("data_mounts:", "# cloud storage (S3, GCS)"))
    lines.append("#   - source: s3://bucket/dataset")
    lines.append("#     target: /data/dataset")

    # ── Networking ────────────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Networking --")
    lines.append("#")
    if ports:
        items = ", ".join(str(p) for p in ports)
        lines.append(f"ports: [{items}]")
    else:
        lines.append(_commented("ports: [8888, 6006]", "# Jupyter, TensorBoard"))
    if ssh_keys:
        keys = [str(k).strip() for k in ssh_keys if str(k).strip()]
        if keys:
            lines.append("ssh_keys:")
            for k in keys:
                lines.append(f"  - {k}")
    else:
        lines.append("# ssh_keys:")
        lines.append("#   - ~/.ssh/id_ed25519")

    # ── Cost control ──────────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Cost control --")
    lines.append("#")
    if priority:
        lines.append(f"priority: {priority}")
    else:
        lines.append(_commented("priority: med", "# low | med | high"))
    if max_price_per_hour is not None:
        lines.append(f"max_price_per_hour: {float(max_price_per_hour)}")
    else:
        lines.append(_commented("max_price_per_hour: 12.50", "# USD hourly cap"))
    lines.append(_commented("allocation_mode: spot", "# spot | reserved | auto"))
    lines.append(_commented("reservation_id: res-abc123", "# target reserved capacity"))

    # ── Lifecycle ─────────────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Lifecycle --")
    lines.append("#")
    lines.append("# max_run_time_hours: 24")
    lines.append(_commented("terminate_on_exit: true", "# cancel when command finishes"))
    lines.append("# retries:")
    lines.append("#   max_retries: 3")
    lines.append("#   backoff_seconds: 60")

    # ── Code upload ───────────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Code upload --")
    lines.append("#")
    lines.append(_commented("upload_code: true", "# sync current directory to instance"))
    lines.append("# working_dir: /workspace")
    lines.append(_commented("upload_strategy: auto", "# auto | embedded | scp | none"))

    # ── Multi-node scaling ────────────────────────────────────────────
    lines.append("")
    lines.append("# -- Multi-node scaling --")
    lines.append("#")
    lines.append(_commented("num_instances: 1", "# multi-node: 2, 4, 8"))
    lines.append(_commented("distributed_mode: auto", "# auto | manual (torchrun rendezvous)"))
    lines.append(_commented("internode_interconnect: IB_3200", "# InfiniBand for multi-node"))

    # ── Region and placement ──────────────────────────────────────────
    lines.append("")
    lines.append("# -- Region and placement --")
    lines.append("#")
    lines.append(_commented("region: us-central1-a", "# auto-selected if omitted"))
    lines.append(_commented("k8s: my-cluster", "# target a Kubernetes cluster"))

    lines.append("")
    return "\n".join(lines)


class InitCommand(BaseCommand):
    """Create a task config file."""

    @property
    def name(self) -> str:
        return "init"

    @property
    def help(self) -> str:
        return "Create a task config file"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option("-o", "--output", type=click.Path(dir_okay=False), help="Write to file")
        @click.option("--force", is_flag=True, help="Overwrite existing output file")
        @click.option("--name", type=str, help="Seed task name")
        @click.option("--no-unique", is_flag=True, help="Set unique_name: false", hidden=True)
        @click.option(
            "--instance", "-i", type=str, help="Seed instance_type (e.g., 1xh100, 8xh100)"
        )
        @click.option(
            "--min-gpu-mem",
            type=int,
            help="Seed min_gpu_memory_gb (mutually exclusive with --instance)",
        )
        @click.option("--command", "-c", type=str, help="Seed command")
        @click.option("--image", type=str, help="Seed image")
        @click.option(
            "--env",
            "env_items",
            multiple=True,
            help="Seed env vars: KEY=VALUE (repeatable, comma-separated)",
        )
        @click.option(
            "--port",
            "port_exprs",
            type=PortsExpr(),
            multiple=True,
            help="Seed ports: 8888,6006 or 3000-3002 (repeatable)",
        )
        @click.option(
            "--priority",
            type=click.Choice(["low", "med", "high"], case_sensitive=False),
            help="Seed priority",
        )
        @click.option("--max-price-per-hour", type=float, help="Seed max_price_per_hour (USD)")
        def init(
            output: str | None,
            force: bool,
            name: str | None,
            no_unique: bool,
            instance: str | None,
            min_gpu_mem: int | None,
            command: str | None,
            image: str | None,
            env_items: tuple[str, ...],
            port_exprs: tuple[Sequence[int], ...],
            priority: str | None,
            max_price_per_hour: float | None,
        ) -> None:
            """Create a task config file.

            Examples:
                flow init > task.yaml
                flow init -o task.yaml
                flow init -i 1xh100 --name my-train -c 'python train.py'
                flow init --port 8888,6006 --env WANDB_KEY=abc,LR=0.001
            """
            if instance and min_gpu_mem:
                raise click.ClickException("--instance and --min-gpu-mem are mutually exclusive")

            ssh_keys = _detect_ssh_keys()
            ports = merge_ports_expr(port_exprs)

            text = _generate_task_yaml(
                name,
                not no_unique,
                instance,
                min_gpu_mem,
                command,
                image,
                env_items,
                ports,
                priority,
                max_price_per_hour,
                ssh_keys=ssh_keys,
            )

            _write_output(text, output, force)

        return init


command = InitCommand()
