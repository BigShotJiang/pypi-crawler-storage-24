"""Grafana + Prometheus orchestration for GPU health dashboards.

Deploys a Docker Compose stack on the remote GPU instance that scrapes
GPUd metrics locally. The user's machine only needs an SSH tunnel to
access the Grafana UI -- zero local Docker dependency.
"""

from __future__ import annotations

import base64
import json
import logging
import subprocess
import textwrap

logger = logging.getLogger(__name__)

REMOTE_GRAFANA_HOST_PORT = 13000
GPUD_PORT = 15132
PROMETHEUS_PORT = 9090
REMOTE_WORKDIR = "/tmp/flow-dashboard"

# ---------------------------------------------------------------------------
# Config templates
# ---------------------------------------------------------------------------


def _prometheus_config() -> str:
    """Prometheus scrape config targeting GPUd on the same host."""
    return f"""\
global:
  scrape_interval: 5s
  evaluation_interval: 5s

scrape_configs:
  - job_name: gpud
    scheme: https
    tls_config:
      insecure_skip_verify: true
    static_configs:
      - targets: ["host.docker.internal:{GPUD_PORT}"]
"""


def _grafana_datasource() -> str:
    return f"""\
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    uid: PBFA97CFB590B2093
    access: proxy
    url: http://prometheus:{PROMETHEUS_PORT}
    isDefault: true
    editable: false
"""


def _grafana_dashboard_provider() -> str:
    return """\
apiVersion: 1
providers:
  - name: default
    orgId: 1
    folder: ''
    type: file
    disableDeletion: true
    updateIntervalSeconds: 30
    options:
      path: /var/lib/grafana/dashboards
      foldersFromFilesStructure: false
"""


def _docker_compose(grafana_host_port: int = REMOTE_GRAFANA_HOST_PORT) -> str:
    """Docker Compose file for Prometheus + Grafana on the remote instance."""
    return f"""\
services:
  prometheus:
    image: prom/prometheus:latest
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml:ro
    extra_hosts:
      - "host.docker.internal:host-gateway"
    restart: "no"

  grafana:
    image: grafana/grafana-oss:latest
    ports:
      - "{grafana_host_port}:3000"
    environment:
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
      - GF_AUTH_DISABLE_LOGIN_FORM=true
      - GF_DASHBOARDS_DEFAULT_HOME_DASHBOARD_PATH=/var/lib/grafana/dashboards/gpu-health.json
    volumes:
      - ./grafana/provisioning/datasources:/etc/grafana/provisioning/datasources:ro
      - ./grafana/provisioning/dashboards:/etc/grafana/provisioning/dashboards:ro
      - ./grafana/dashboards:/var/lib/grafana/dashboards:ro
    depends_on:
      - prometheus
    restart: "no"
"""


# ---------------------------------------------------------------------------
# Grafana dashboard JSON
# ---------------------------------------------------------------------------


def _gpu_dashboard_json(task_name: str) -> str:
    """Pre-built Grafana dashboard for GPUd metrics."""
    dashboard = {
        "uid": "gpu-health",
        "title": f"GPU Health — {task_name}",
        "tags": ["gpu", "flow", "health"],
        "timezone": "browser",
        "refresh": "5s",
        "time": {"from": "now-15m", "to": "now"},
        "panels": [
            # Row: Overview
            _row_panel(0, "Overview", 0),
            _stat_panel(
                1, "GPUs", "count(accelerator_nvidia_temperature_current_celsius)", 0, 1, 4, 3
            ),
            _stat_panel(
                2,
                "Avg Temperature",
                "avg(accelerator_nvidia_temperature_current_celsius)",
                4,
                1,
                4,
                3,
                unit="celsius",
                thresholds=[0, 65, 80],
            ),
            _stat_panel(
                3,
                "Avg Utilization",
                "avg(accelerator_nvidia_utilization_gpu_util_percent)",
                8,
                1,
                4,
                3,
                unit="percent",
                thresholds=[0, 50, 90],
            ),
            _stat_panel(
                4,
                "Avg Power",
                "avg(accelerator_nvidia_power_used_percent)",
                12,
                1,
                4,
                3,
                unit="percent",
                thresholds=[0, 70, 90],
            ),
            _stat_panel(
                5,
                "ECC Errors",
                "sum(accelerator_nvidia_ecc_aggregate_total_uncorrected)",
                16,
                1,
                4,
                3,
                thresholds=[0, 1, 10],
            ),
            _stat_panel(
                6,
                "HW Slowdown",
                "sum(accelerator_nvidia_clock_hw_slowdown)",
                20,
                1,
                4,
                3,
                thresholds=[0, 1],
            ),
            # Row: Temperature
            _row_panel(10, "Temperature", 4),
            _timeseries_panel(
                11,
                "GPU Core Temperature",
                "accelerator_nvidia_temperature_current_celsius",
                "{{uuid}}",
                0,
                5,
                12,
                8,
                unit="celsius",
                thresholds=[{"value": 65, "color": "yellow"}, {"value": 80, "color": "red"}],
            ),
            _timeseries_panel(
                12,
                "HBM Temperature",
                "accelerator_nvidia_temperature_current_hbm_celsius",
                "{{uuid}}",
                12,
                5,
                12,
                8,
                unit="celsius",
            ),
            # Row: Utilization
            _row_panel(20, "Utilization", 13),
            _timeseries_panel(
                21,
                "GPU Utilization",
                "accelerator_nvidia_utilization_gpu_util_percent",
                "{{uuid}}",
                0,
                14,
                12,
                8,
                unit="percent",
                y_max=100,
            ),
            _timeseries_panel(
                22,
                "Memory Utilization",
                "accelerator_nvidia_utilization_memory_util_percent",
                "{{uuid}}",
                12,
                14,
                12,
                8,
                unit="percent",
                y_max=100,
            ),
            # Row: Memory
            _row_panel(30, "Memory", 22),
            _timeseries_panel(
                31,
                "GPU Memory Used",
                "accelerator_nvidia_memory_used_bytes / 1024 / 1024 / 1024",
                "{{uuid}}",
                0,
                23,
                12,
                8,
                unit="decgbytes",
            ),
            _timeseries_panel(
                32,
                "GPU Memory Free",
                "accelerator_nvidia_memory_free_bytes / 1024 / 1024 / 1024",
                "{{uuid}}",
                12,
                23,
                12,
                8,
                unit="decgbytes",
            ),
            # Row: Power
            _row_panel(40, "Power", 31),
            _timeseries_panel(
                41,
                "Power Draw",
                "accelerator_nvidia_power_current_usage_milli_watts / 1000",
                "{{uuid}}",
                0,
                32,
                12,
                8,
                unit="watt",
            ),
            _timeseries_panel(
                42,
                "Power Usage %",
                "accelerator_nvidia_power_used_percent",
                "{{uuid}}",
                12,
                32,
                12,
                8,
                unit="percent",
                y_max=100,
            ),
            # Row: Clock & NVLink
            _row_panel(50, "Clock Speed & NVLink", 40),
            _timeseries_panel(
                51,
                "GPU Clock Speed",
                "accelerator_nvidia_clock_speed_graphics_mhz",
                "{{uuid}}",
                0,
                41,
                12,
                8,
                unit="rotmhz",
            ),
            _timeseries_panel(
                52,
                "NVLink CRC Errors",
                "accelerator_nvidia_nvlink_crc_errors",
                "{{uuid}}",
                12,
                41,
                12,
                8,
            ),
            # Row: System
            _row_panel(60, "System", 49),
            _timeseries_panel(
                61,
                "CPU Usage",
                "cpu_used_percent",
                "cpu",
                0,
                50,
                8,
                6,
                unit="percent",
                y_max=100,
            ),
            _timeseries_panel(
                62,
                "System Memory Used",
                "memory_used_bytes / 1024 / 1024 / 1024",
                "memory",
                8,
                50,
                8,
                6,
                unit="decgbytes",
            ),
            _timeseries_panel(
                63,
                "Disk Used",
                "disk_used_bytes / 1024 / 1024 / 1024",
                "{{device}}",
                16,
                50,
                8,
                6,
                unit="decgbytes",
            ),
        ],
        "schemaVersion": 39,
        "version": 1,
    }
    return json.dumps(dashboard, indent=2)


def _row_panel(panel_id: int, title: str, y: int) -> dict:
    return {
        "id": panel_id,
        "type": "row",
        "title": title,
        "gridPos": {"h": 1, "w": 24, "x": 0, "y": y},
        "collapsed": False,
    }


def _stat_panel(
    panel_id: int,
    title: str,
    expr: str,
    x: int,
    y: int,
    w: int,
    h: int,
    unit: str = "short",
    thresholds: list | None = None,
) -> dict:
    steps = [{"color": "green", "value": None}]
    if thresholds:
        colors = ["green", "yellow", "red", "dark-red"]
        for i, v in enumerate(thresholds):
            steps.append({"color": colors[min(i + 1, len(colors) - 1)], "value": v})
    return {
        "id": panel_id,
        "type": "stat",
        "title": title,
        "gridPos": {"h": h, "w": w, "x": x, "y": y},
        "targets": [{"expr": expr, "refId": "A"}],
        "fieldConfig": {
            "defaults": {
                "unit": unit,
                "thresholds": {"mode": "absolute", "steps": steps},
            },
            "overrides": [],
        },
        "datasource": {"type": "prometheus", "uid": "PBFA97CFB590B2093"},
    }


def _timeseries_panel(
    panel_id: int,
    title: str,
    expr: str,
    legend: str,
    x: int,
    y: int,
    w: int,
    h: int,
    unit: str = "short",
    y_max: float | None = None,
    thresholds: list[dict] | None = None,
) -> dict:
    panel = {
        "id": panel_id,
        "type": "timeseries",
        "title": title,
        "gridPos": {"h": h, "w": w, "x": x, "y": y},
        "targets": [{"expr": expr, "legendFormat": legend, "refId": "A"}],
        "fieldConfig": {
            "defaults": {
                "unit": unit,
                "custom": {
                    "drawStyle": "line",
                    "lineInterpolation": "smooth",
                    "fillOpacity": 15,
                    "pointSize": 5,
                    "showPoints": "auto",
                },
            },
            "overrides": [],
        },
        "datasource": {"type": "prometheus", "uid": "PBFA97CFB590B2093"},
    }
    if y_max is not None:
        panel["fieldConfig"]["defaults"]["max"] = y_max
    if thresholds:
        panel["fieldConfig"]["defaults"]["custom"]["thresholdsStyle"] = {"mode": "line"}
        panel["fieldConfig"]["defaults"]["thresholds"] = {
            "mode": "absolute",
            "steps": [{"color": "transparent", "value": None}] + thresholds,
        }
    return panel


# ---------------------------------------------------------------------------
# Remote deploy script
# ---------------------------------------------------------------------------


def _deploy_script(task_name: str, grafana_host_port: int = REMOTE_GRAFANA_HOST_PORT) -> str:
    """Self-contained bash script that provisions the dashboard on a remote instance.

    Executed via ``ssh user@host 'sudo bash -s'`` with the script piped to stdin.
    Emits ``FLOW_OK`` on success or ``FLOW_ERROR:<message>`` on failure for the
    CLI to parse.
    """
    prometheus_yml_b64 = base64.b64encode(_prometheus_config().encode()).decode()
    datasource_yml_b64 = base64.b64encode(_grafana_datasource().encode()).decode()
    dashboard_provider_b64 = base64.b64encode(_grafana_dashboard_provider().encode()).decode()
    compose_yml_b64 = base64.b64encode(_docker_compose(grafana_host_port).encode()).decode()
    dashboard_json_b64 = base64.b64encode(_gpu_dashboard_json(task_name).encode()).decode()

    return textwrap.dedent(f"""\
        #!/usr/bin/env bash
        set -euo pipefail

        CURRENT_STEP="init"
        trap 'echo "FLOW_ERROR:failed during step [$CURRENT_STEP] (line $LINENO)"' ERR

        CURRENT_STEP="docker"
        echo "FLOW_STEP:docker"

        # --- Ensure Docker is available ---
        if ! command -v docker >/dev/null 2>&1; then
            echo "Docker not found, installing..."
            export DEBIAN_FRONTEND=noninteractive

            INSTALLED=0
            if command -v apt-get >/dev/null 2>&1; then
                apt-get update -qq || true
                apt-get install -y docker.io || true
                if command -v docker >/dev/null 2>&1; then INSTALLED=1; fi
            elif command -v dnf >/dev/null 2>&1; then
                dnf -y install docker || true
                if command -v docker >/dev/null 2>&1; then INSTALLED=1; fi
            elif command -v yum >/dev/null 2>&1; then
                yum -y install docker || true
                if command -v docker >/dev/null 2>&1; then INSTALLED=1; fi
            fi

            if [ "$INSTALLED" -ne 1 ]; then
                if command -v curl >/dev/null 2>&1; then
                    MAX_RETRIES=3
                    RETRY_COUNT=0
                    while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
                        if curl -fsSL https://get.docker.com -o /tmp/get-docker.sh && sh /tmp/get-docker.sh; then
                            rm -f /tmp/get-docker.sh
                            INSTALLED=1
                            break
                        else
                            RETRY_COUNT=$((RETRY_COUNT + 1))
                            sleep 5
                        fi
                    done
                fi
            fi

            if [ "$INSTALLED" -ne 1 ]; then
                echo "FLOW_ERROR:Docker installation failed"
                exit 1
            fi
        fi

        # Ensure Docker daemon is running
        if command -v systemctl >/dev/null 2>&1; then
            systemctl enable docker 2>/dev/null || true
            systemctl start docker 2>/dev/null || true
        elif command -v service >/dev/null 2>&1; then
            service docker start 2>/dev/null || true
        fi

        DOCKER_READY=false
        for i in $(seq 1 30); do
            if docker info >/dev/null 2>&1; then
                DOCKER_READY=true
                break
            fi
            sleep 1
        done
        if [ "$DOCKER_READY" = "false" ]; then
            echo "FLOW_ERROR:Docker daemon did not become ready"
            exit 1
        fi

        # Ensure docker compose is available
        if ! docker compose version >/dev/null 2>&1; then
            echo "FLOW_ERROR:docker compose plugin not available"
            exit 1
        fi

        CURRENT_STEP="config"
        echo "FLOW_STEP:config"

        # --- Deploy config files ---
        WORKDIR="{REMOTE_WORKDIR}"
        mkdir -p "$WORKDIR/grafana/provisioning/datasources"
        mkdir -p "$WORKDIR/grafana/provisioning/dashboards"
        mkdir -p "$WORKDIR/grafana/dashboards"

        echo "{prometheus_yml_b64}" | base64 -d > "$WORKDIR/prometheus.yml"
        echo "{datasource_yml_b64}" | base64 -d > "$WORKDIR/grafana/provisioning/datasources/prometheus.yml"
        echo "{dashboard_provider_b64}" | base64 -d > "$WORKDIR/grafana/provisioning/dashboards/dashboard.yml"
        echo "{compose_yml_b64}" | base64 -d > "$WORKDIR/docker-compose.yml"
        echo "{dashboard_json_b64}" | base64 -d > "$WORKDIR/grafana/dashboards/gpu-health.json"

        CURRENT_STEP="containers"
        echo "FLOW_STEP:containers"

        # --- Start containers (idempotent: tear down first) ---
        cd "$WORKDIR"
        docker compose down -v 2>/dev/null || true
        docker compose up -d --quiet-pull

        CURRENT_STEP="readiness"
        echo "FLOW_STEP:readiness"

        # --- Wait for Grafana ---
        GRAFANA_READY=false
        for i in $(seq 1 60); do
            if curl -sf "http://localhost:{grafana_host_port}/api/health" >/dev/null 2>&1; then
                GRAFANA_READY=true
                break
            fi
            sleep 1
        done

        if [ "$GRAFANA_READY" = "false" ]; then
            echo "FLOW_ERROR:Grafana did not become ready within 60s"
            exit 1
        fi

        echo "FLOW_OK"
    """)


def _teardown_command() -> str:
    """Shell command to tear down the dashboard stack on the remote instance."""
    return f"cd {REMOTE_WORKDIR} && docker compose down -v 2>/dev/null; rm -rf {REMOTE_WORKDIR}"


def _extract_error(stdout: str) -> str | None:
    """Extract the most specific FLOW_ERROR message from deploy script output."""
    for line in reversed(stdout.splitlines()):
        if line.startswith("FLOW_ERROR:"):
            return line.split(":", 1)[1]
    return None


# ---------------------------------------------------------------------------
# Remote lifecycle
# ---------------------------------------------------------------------------


class RemoteGrafanaDashboard:
    """Manages the lifecycle of a Grafana + Prometheus stack on a remote GPU instance."""

    def __init__(
        self,
        ssh_prefix: list[str],
        task_name: str,
        grafana_host_port: int = REMOTE_GRAFANA_HOST_PORT,
    ) -> None:
        self.ssh_prefix = ssh_prefix
        self.task_name = task_name
        self.grafana_host_port = grafana_host_port

    def deploy(self, timeout: int = 180) -> str | None:
        """Deploy the dashboard stack on the remote instance.

        Pipes the deploy script into ``ssh ... 'sudo bash -s'``.
        Returns None on success, or an error message string on failure.
        """
        script = _deploy_script(self.task_name, self.grafana_host_port)
        cmd = self.ssh_prefix + ["sudo bash -s"]

        try:
            result = subprocess.run(
                cmd,
                input=script,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            logger.warning("Deploy script timed out after %ds", timeout)
            return "Deploy timed out (instance may be slow or unresponsive)"

        logger.debug("Deploy stdout: %s", result.stdout)
        if result.stderr:
            logger.debug("Deploy stderr: %s", result.stderr)

        # Extract the most specific error from the output
        error_detail = _extract_error(result.stdout)

        if result.returncode != 0:
            return error_detail or f"Deploy script exited with code {result.returncode}"

        if error_detail:
            return error_detail

        if "FLOW_OK" not in result.stdout:
            return "Deploy script completed but did not report success"

        return None

    def teardown(self, timeout: int = 30) -> None:
        """Tear down the dashboard stack on the remote instance."""
        cmd = self.ssh_prefix + [_teardown_command()]
        try:
            subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except Exception:  # noqa: BLE001
            logger.debug("Failed to tear down remote dashboard", exc_info=True)
