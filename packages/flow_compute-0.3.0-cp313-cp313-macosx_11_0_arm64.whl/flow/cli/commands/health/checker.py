"""Core HealthChecker class for Flow health diagnostics.

Coordinates basic health checks (connectivity, auth, SSH keys, state sync)
and delegates GPU health, SSH diagnostics, and scoring to focused modules.
"""

from __future__ import annotations

import logging
import re
import socket
import subprocess
import threading
import time
from contextlib import suppress
from datetime import datetime, timezone
from typing import Any

import httpx
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel

from flow.adapters.integrations.health.config import (
    DEFAULT_GPUD_BIND,
    DEFAULT_GPUD_PORT,
    DEFAULT_GPUD_VERSION,
)
from flow.cli.commands.health import demo_factory, scoring, ssh_diagnosis
from flow.cli.ui.facade.views import HealthRenderer
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.errors import FlowError
from flow.sdk.client import Flow
from flow.sdk.health import (
    GPUdStatus,
    GPUdStatusDiagnoser,
    GPUInstanceDetector,
    HealthCheckMessageHandler,
    MetricsStore,
    NodeHealthSnapshotFactory,
    SSHConnectionHandler,
    TaskAgeCalculator,
)
from flow.sdk.health_models import (
    FleetHealthSummary,
    HealthStatus,
    NodeHealthSnapshot,
)
from flow.sdk.models import TaskStatus

logger = logging.getLogger(__name__)

# Regex to strip Rich console markup tags for plain-text logging.
_RICH_MARKUP_RE = re.compile(r"\[/?[a-z_ ]+\]")


class HealthChecker:
    """Performs comprehensive health checks on Flow setup."""

    def __init__(self, flow_client: Flow, *, json_mode: bool = False):
        self.flow_client = flow_client
        self.json_mode = json_mode
        self._lists_lock = threading.Lock()
        self.issues: list[dict] = []
        self.warnings: list[dict] = []
        self.successes: list[dict] = []
        self.renderer = HealthRenderer()
        self.metrics_store = MetricsStore()
        self.gpud_diagnoser = GPUdStatusDiagnoser()
        self.snapshot_factory = NodeHealthSnapshotFactory()
        self.message_handler = HealthCheckMessageHandler(self.issues, self.warnings, self.successes)
        self.gpu_detector = GPUInstanceDetector()
        self.age_calculator = TaskAgeCalculator()
        self._http = httpx.Client(
            headers={"User-Agent": "flow-compute-health/1.0"},
            verify=False,  # GPUd uses self-signed TLS certs
        )
        self._ssh_key_cache: dict[str, str | None] = {}

        # Configurable health settings
        cfg = getattr(flow_client, "config", None)
        hc = getattr(cfg, "health_config", {}) or {}
        self.health_endpoints: list[str] = list(
            hc.get("endpoints", ["/healthz", "/readyz", "/livez", "/health"])
        )
        self.gpud_health_timeout: int = int(hc.get("gpud_health_timeout", 2))
        self.gpud_http_timeout: int = int(hc.get("gpud_http_timeout", 5))
        self.ssh_curl_timeout: int = int(hc.get("ssh_curl_timeout", 5))
        self.tunnel_timeout_seconds: int = int(hc.get("tunnel_timeout", 10))
        self.gpud_port: int = int(hc.get("gpud_port", DEFAULT_GPUD_PORT))
        self.gpud_version: str = str(hc.get("gpud_version", DEFAULT_GPUD_VERSION))
        self.gpud_bind: str = str(hc.get("gpud_bind", DEFAULT_GPUD_BIND))
        thresholds = hc.get("thresholds", {})
        self.thresholds: dict[str, Any] = dict(thresholds) if isinstance(thresholds, dict) else {}

    def close(self) -> None:
        """Release resources (httpx client)."""
        self._http.close()

    def __enter__(self) -> HealthChecker:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Message helpers
    # ------------------------------------------------------------------

    def add_issue(self, category: str, message: str, suggestion: str | None = None):
        """Add a critical issue."""
        self.issues.append({"category": category, "message": message, "suggestion": suggestion})

    def add_warning(self, category: str, message: str, suggestion: str | None = None):
        """Add a warning."""
        self.warnings.append({"category": category, "message": message, "suggestion": suggestion})

    def add_success(self, category: str, message: str):
        """Add a success."""
        self.successes.append({"category": category, "message": message})

    # ------------------------------------------------------------------
    # Basic checks
    # ------------------------------------------------------------------

    def check_connectivity(self) -> bool:
        """Check API connectivity."""
        try:
            if getattr(self.flow_client.config, "provider", "") == "mock":
                self.add_success("Connectivity", "Demo mode (mock): connectivity OK")
                return True
            self.flow_client.tasks.list(limit=1)
            self.add_success("Connectivity", "Successfully connected to Flow API")
            return True
        except FlowError as e:
            self.add_issue(
                "Connectivity",
                f"Cannot connect to Flow API: {e!s}",
                "Check your internet connection and API endpoint configuration",
            )
            return False

    def check_authentication(self) -> bool:
        """Check authentication status."""
        try:
            if getattr(self.flow_client.config, "provider", "") == "mock":
                cfg = getattr(self.flow_client, "config", None)
                demo_cfg = {}
                project = None
                region = None
                if cfg and isinstance(getattr(cfg, "provider_config", None), dict):
                    project = cfg.provider_config.get("project")
                    region = cfg.provider_config.get("region")
                    demo_cfg = cfg.provider_config.get("demo", {}) or {}
                has_demo_key = bool(demo_cfg.get("api_key"))
                if has_demo_key:
                    self.add_success(
                        "Authentication",
                        f"Demo mode (mock): demo API key configured • project='{project or 'demo'}' region='{region or 'demo-region-1'}'",
                    )
                else:
                    self.add_success(
                        "Authentication",
                        "Demo mode (mock): no authentication required (demo API key optional)",
                    )
                return True
            config = self.flow_client.config
            if config and config.provider_config:
                project = config.provider_config.get("project", "unknown")
                region = config.provider_config.get("region", "unknown")
                if project != "unknown":
                    self.add_success(
                        "Authentication",
                        f"Authenticated to project '{project}' in region '{region}'",
                    )
                    return True
                else:
                    self.add_issue(
                        "Authentication",
                        "No project configured",
                        "Run 'flow setup' to configure project",
                    )
                    return False
            else:
                self.add_issue(
                    "Authentication",
                    "No authentication configured",
                    "Run 'flow setup' to configure authentication",
                )
                return False
        except Exception as e:  # noqa: BLE001
            self.add_issue(
                "Authentication",
                f"Authentication error: {e!s}",
                "Run 'flow setup' to reconfigure authentication",
            )
            return False

    def check_ssh_keys(self) -> bool:
        """Check SSH key configuration."""
        from pathlib import Path

        import yaml

        try:
            if getattr(self.flow_client.config, "provider", "") == "mock":
                self.add_success("SSH Keys", "Demo mode (mock): SSH keys not required")
                return True
            config_path = Path.home() / ".flow" / "config.yaml"
            if not config_path.exists():
                self.add_issue(
                    "SSH Keys",
                    "Flow configuration file not found",
                    "Run 'flow setup' to set up Flow",
                )
                return False

            with open(config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            ssh_key_path = config.get("ssh_key_path")
            if not ssh_key_path:
                self.add_warning(
                    "SSH Keys",
                    "No SSH key path configured",
                    "SSH keys will be auto-generated when needed",
                )
            else:
                key_path = Path(ssh_key_path).expanduser()
                if key_path.exists():
                    self.add_success("SSH Keys", f"SSH key found at {key_path}")
                else:
                    self.add_issue(
                        "SSH Keys",
                        f"SSH key not found at {key_path}",
                        "Generate a new SSH key or update the path in ~/.flow/config.yaml",
                    )
                    return False

            return True
        except Exception as e:  # noqa: BLE001
            self.add_warning(
                "SSH Keys",
                f"Could not check SSH keys: {e!s}",
                "SSH functionality may be limited",
            )
            return True

    def check_cloud_credentials(self) -> bool:
        """Check cloud credential configuration for SkyPilot provider.

        Verifies that credential files exist for each cloud enabled in the
        SkyPilot configuration. Skips silently for non-SkyPilot providers.
        """
        provider = getattr(self.flow_client.config, "provider", "")
        if provider != "skypilot":
            return True

        try:
            from flow.core.cloud_detection import detect_all_clouds

            sky_cfg = (self.flow_client.config.provider_config or {}).get("skypilot", {})
            enabled = sky_cfg.get("clouds", [])
            if not enabled:
                self.add_issue(
                    "Cloud Credentials",
                    "No clouds enabled in SkyPilot configuration",
                    "Run 'flow setup' to configure cloud providers",
                )
                return False

            all_ok = True
            for cloud in detect_all_clouds():
                if cloud.key not in enabled:
                    continue
                if cloud.is_configured:
                    self.add_success(
                        "Cloud Credentials",
                        f"{cloud.name}: {cloud.credential_source}",
                    )
                else:
                    steps = " -> ".join(cmd for _, cmd in cloud.setup_instructions)
                    self.add_issue(
                        "Cloud Credentials",
                        f"{cloud.name} credentials not found",
                        steps,
                    )
                    all_ok = False
            return all_ok
        except Exception as e:  # noqa: BLE001
            self.add_warning(
                "Cloud Credentials",
                f"Could not check cloud credentials: {e!s}",
                "Run 'flow health' again after verifying your cloud setup",
            )
            return True

    def check_instance_sync(self) -> dict[str, list[dict]]:
        """Check for state synchronization issues between Flow and provider."""
        from flow.cli.utils.task_fetcher import TaskFetcher

        fetcher = TaskFetcher(self.flow_client)
        active_tasks = [
            task
            for task in fetcher.fetch_all_tasks(limit=100, prioritize_active=True)
            if task.status in [TaskStatus.RUNNING, TaskStatus.PENDING]
        ]

        if not active_tasks:
            self.add_success("State Sync", "No active tasks to synchronize")
            return {"flow_tasks": [], "provider_instances": [], "orphaned": [], "missing": []}

        flow_task_map = {
            task.task_id: {
                "id": task.task_id,
                "name": task.name,
                "status": task.status.value if hasattr(task.status, "value") else str(task.status),
            }
            for task in active_tasks
        }

        provider_task_ids = self._get_provider_task_ids()
        if provider_task_ids is None:
            return {
                "flow_tasks": list(flow_task_map.values()),
                "provider_instances": [],
                "orphaned": [],
                "missing": [],
            }

        missing = [
            task_data
            for task_id, task_data in flow_task_map.items()
            if task_id not in provider_task_ids
        ]

        if missing:
            self.add_issue(
                "State Sync",
                f"Found {len(missing)} tasks missing from provider",
                "These tasks are tracked by Flow but don't exist in the provider. Try 'flow status --force-refresh'.",
            )
        else:
            self.add_success("State Sync", "All tasks are synchronized with provider")

        return {
            "flow_tasks": list(flow_task_map.values()),
            "provider_instances": list(provider_task_ids) if provider_task_ids else [],
            "orphaned": [],
            "missing": missing,
        }

    def _get_provider_task_ids(self) -> set[str] | None:
        """Get task IDs from provider, returns None if provider unreachable."""
        try:
            task_ids: set[str] = set()
            for status in [TaskStatus.RUNNING, TaskStatus.PENDING]:
                try:
                    tasks = self.flow_client.list_tasks(status=status, limit=100)
                    task_ids.update(task.task_id for task in tasks)
                except Exception as e:  # noqa: BLE001
                    self.add_warning(
                        "State Sync",
                        f"Could not list {status.value} tasks from provider: {e!s}",
                    )

            if not task_ids:
                self.add_issue(
                    "State Sync",
                    "Could not retrieve any tasks from provider",
                    "Provider may be unreachable or authentication may have failed.",
                )
                return None

            return task_ids

        except Exception as e:  # noqa: BLE001
            self.add_issue(
                "State Sync",
                f"Failed to connect to provider: {e!s}",
                "Check your provider configuration and network connectivity.",
            )
            return None

    # ------------------------------------------------------------------
    # SSH key resolution
    # ------------------------------------------------------------------

    def _resolve_task_ssh_key(self, task_id: str) -> str | None:
        """Resolve the SSH private key path for a task via the provider.

        Results are cached per task_id to avoid redundant provider API
        calls and file-system probes when multiple health checks run
        against the same task.

        Falls back to ``find_fallback_private_key`` when the provider
        does not return a key (e.g. mock provider).
        """
        if task_id in self._ssh_key_cache:
            return self._ssh_key_cache[task_id]

        from flow.core.ssh import find_fallback_private_key

        key_path = self.flow_client.get_task_ssh_connection_info(task_id)
        if key_path is not None:
            resolved = str(key_path)
        else:
            fallback = find_fallback_private_key()
            resolved = str(fallback) if fallback else None

        self._ssh_key_cache[task_id] = resolved
        return resolved

    # ------------------------------------------------------------------
    # Instance health
    # ------------------------------------------------------------------

    def check_instance_health(self, task_id: str) -> dict[str, Any]:
        """Check health of a specific instance."""
        health: dict[str, Any] = {
            "task_id": task_id,
            "reachable": False,
            "ssh_ready": False,
            "age_hours": None,
            "issues": [],
        }

        try:
            task = self.flow_client.get_task(task_id)

            if task.created_at:
                now = datetime.now(timezone.utc)
                if task.created_at.tzinfo is None:
                    created_at = task.created_at.replace(tzinfo=timezone.utc)
                else:
                    created_at = task.created_at
                age = now - created_at
                health["age_hours"] = age.total_seconds() / 3600

            if not task.ssh_host:
                health["issues"].append("No SSH host assigned")
                return health

            try:
                ssh_port = int(getattr(task, "ssh_port", 22) or 22)
                with socket.create_connection((task.ssh_host, ssh_port), timeout=3):
                    health["reachable"] = True
            except OSError:
                health["reachable"] = False
                health["issues"].append("SSH port unreachable (network/firewall)")

            if health["reachable"]:
                try:
                    key_path = self._resolve_task_ssh_key(task_id)
                    ssh_prefix = ssh_diagnosis.build_ssh_command_prefix(task, key_path=key_path)
                    ssh_test = subprocess.run(
                        ssh_prefix + ["echo", "OK"],
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )

                    if ssh_test.returncode == 0:
                        health["ssh_ready"] = True
                    else:
                        stderr = ssh_test.stderr.lower()
                        if "connection reset" in stderr or "kex_exchange" in stderr:
                            health["issues"].append("SSH service is still starting up")
                        elif "connection refused" in stderr:
                            health["issues"].append("SSH port is closed")
                        elif "permission denied" in stderr:
                            health["issues"].append("SSH authentication failed")
                        else:
                            health["issues"].append(f"SSH test failed: {ssh_test.stderr.strip()}")
                except subprocess.TimeoutExpired:
                    health["issues"].append("SSH connection timed out")
                except Exception as e:  # noqa: BLE001
                    health["issues"].append(f"SSH test error: {e!s}")

        except FlowError as e:
            health["issues"].append(f"Could not fetch task details: {e!s}")

        return health

    # ------------------------------------------------------------------
    # GPU health (delegates to extracted modules)
    # ------------------------------------------------------------------

    def _emit_diagnosis_snapshot(
        self,
        diagnosis: Any,
        task: Any,
        task_id: str,
    ) -> NodeHealthSnapshot:
        """Emit a diagnosis warning and return the corresponding snapshot.

        Centralizes the handle_diagnosis + snapshot-factory pattern used
        for FAILED, STARTING, and unknown GPUd statuses.
        """
        self.message_handler.handle_diagnosis(diagnosis, task_id)
        if diagnosis.status == GPUdStatus.NOT_INSTALLED:
            return self.snapshot_factory.create_not_installed_snapshot(task)
        if diagnosis.status == GPUdStatus.FAILED:
            return self.snapshot_factory.create_failed_snapshot(task, diagnosis.reason)
        if diagnosis.status == GPUdStatus.STARTING:
            return self.snapshot_factory.create_starting_snapshot(task)
        return self.snapshot_factory.create_failed_snapshot(task, "Unknown GPUd status")

    def check_gpu_health(
        self,
        task_id: str,
        _demo_scenario: str | None = None,
        *,
        auto_install: bool = True,
    ) -> NodeHealthSnapshot | None:
        """Check GPU health for a specific task using GPUd API."""
        try:
            task = self.flow_client.get_task(task_id)

            # Demo mode
            try:
                if getattr(self.flow_client.config, "provider", "") == "mock":
                    return demo_factory.create_demo_snapshot(
                        task, self.thresholds, scenario_override=_demo_scenario
                    )
            except Exception:  # noqa: BLE001
                pass

            if not self.gpu_detector.is_gpu_instance(task.instance_type):
                self.add_warning("GPU Health", f"Task {task_id} is not using a GPU instance type")
                return None

            task_age_hours = self.age_calculator.get_age_hours(task.created_at)
            gpud_port = self.gpud_port
            key_path = self._resolve_task_ssh_key(task_id)

            try:
                # Marker check
                marker_status = None
                try:
                    ssh_prefix = ssh_diagnosis.build_ssh_command_prefix(task, key_path=key_path)
                    marker_status = self.gpud_diagnoser.check_gpud_marker(ssh_prefix)
                except Exception:  # noqa: BLE001
                    pass

                tunnel_timeout = threading.Event()

                def timeout_handler():
                    tunnel_timeout.set()

                timer = threading.Timer(float(self.tunnel_timeout_seconds), timeout_handler)
                timer.start()

                diagnosis = None
                snapshot_result: NodeHealthSnapshot | None = None

                try:
                    try:
                        ssh_tunnel_manager = self.flow_client.get_ssh_tunnel_manager()
                        use_tunnel_manager = True
                    except Exception:  # noqa: BLE001
                        ssh_tunnel_manager = None
                        use_tunnel_manager = False

                    tunnel = None
                    api_url = None

                    if use_tunnel_manager:
                        with ssh_tunnel_manager.tunnel_context(
                            task=task,
                            remote_port=gpud_port,
                            local_port=0,
                            key_path=key_path,
                        ) as tunnel:
                            timer.cancel()
                            if tunnel_timeout.is_set():
                                raise TimeoutError("SSH tunnel creation timed out")

                            api_url = f"https://localhost:{tunnel.local_port}"

                            diagnosis = ssh_diagnosis.diagnose_with_marker(
                                api_url,
                                task_age_hours,
                                marker_status,
                                self._http,
                                self.health_endpoints,
                                self.gpud_health_timeout,
                            )

                            if diagnosis and diagnosis.status == GPUdStatus.HEALTHY:
                                snapshot, issues, warnings = ssh_diagnosis.query_gpud_api(
                                    api_url,
                                    task,
                                    self._http,
                                    self.health_endpoints,
                                    self.gpud_http_timeout,
                                    self.thresholds,
                                )
                                with self._lists_lock:
                                    self.issues.extend(issues)
                                    self.warnings.extend(warnings)
                                if snapshot:
                                    self.metrics_store.write_snapshot(snapshot)
                                    self._apply_gpu_analysis(snapshot)
                                snapshot_result = snapshot
                    else:
                        timer.cancel()
                        diagnosis = ssh_diagnosis.check_gpud_via_ssh(
                            task,
                            task_age_hours,
                            marker_status,
                            self.health_endpoints,
                            self.ssh_curl_timeout,
                            self.gpud_port,
                            key_path=key_path,
                        )
                finally:
                    timer.cancel()

                if snapshot_result is not None:
                    return snapshot_result

                if diagnosis:
                    if diagnosis.status == GPUdStatus.NOT_INSTALLED:
                        if auto_install:
                            installed = self._try_install_gpud(task, key_path=key_path)
                            if installed:
                                return self.check_gpu_health(
                                    task_id,
                                    auto_install=False,
                                )
                            fallback = self._nvidia_smi_fallback(task, key_path=key_path)
                            if fallback:
                                self._apply_gpu_analysis(fallback)
                                return fallback
                        return self._emit_diagnosis_snapshot(diagnosis, task, task_id)
                    elif diagnosis.status == GPUdStatus.HEALTHY:
                        snapshot = ssh_diagnosis.query_gpud_api_via_ssh(
                            task,
                            self.ssh_curl_timeout,
                            self.gpud_port,
                            self.thresholds,
                            key_path=key_path,
                        )
                        if snapshot:
                            self.metrics_store.write_snapshot(snapshot)
                            self._apply_gpu_analysis(snapshot)
                            return snapshot
                        return self.snapshot_factory.create_failed_snapshot(
                            task, "GPUd healthy but metrics fetch failed"
                        )
                    else:
                        return self._emit_diagnosis_snapshot(diagnosis, task, task_id)

                return self.snapshot_factory.create_unreachable_snapshot(
                    task, "SSH tunnel creation failed"
                )

            except TimeoutError:
                self.add_warning(
                    "GPU Health",
                    f"SSH connection to {task_id} timed out",
                    "Node may be unreachable or under heavy load",
                )
                return self.snapshot_factory.create_unreachable_snapshot(
                    task, "SSH connection timeout"
                )
            except Exception as e:  # noqa: BLE001
                ssh_diag = SSHConnectionHandler.analyze_ssh_error(e, task_age_hours)

                if ssh_diag.status == GPUdStatus.NOT_INSTALLED:
                    if auto_install:
                        installed = self._try_install_gpud(task, key_path=key_path)
                        if installed:
                            return self.check_gpu_health(
                                task_id,
                                auto_install=False,
                            )
                        fallback = self._nvidia_smi_fallback(task, key_path=key_path)
                        if fallback:
                            self._apply_gpu_analysis(fallback)
                            return fallback
                    return self._emit_diagnosis_snapshot(ssh_diag, task, task_id)
                else:
                    self.message_handler.handle_diagnosis(ssh_diag, task_id)
                    return self.snapshot_factory.create_unreachable_snapshot(task, ssh_diag.reason)

        except Exception as e:  # noqa: BLE001
            self.add_issue("GPU Health", f"Failed to check GPU health: {e!s}")
            return None

    def _try_install_gpud(self, task: Any, *, key_path: str | None = None) -> bool:
        """Install GPUd on a remote instance via SSH.

        Uses the same install script as provisioning. Idempotent and safe
        to run on instances with existing GPUd installations.

        Returns:
            True if GPUd was installed and is responding on the health endpoint.
        """
        from flow.cli.utils.theme_manager import theme_manager

        console = theme_manager.create_console()

        def _emit(msg: str) -> None:
            if self.json_mode:
                logger.info(_RICH_MARKUP_RE.sub("", msg))
            else:
                console.print(msg)

        try:
            _emit("[warning]Installing GPU monitoring daemon (GPUd)...[/warning]")
            ssh_prefix = ssh_diagnosis.build_ssh_command_prefix(task, key_path=key_path)

            # Install GPUd
            install_cmd = ssh_prefix + [
                f"curl -fsSL https://pkg.gpud.dev/install.sh | bash -s -- {self.gpud_version}"
            ]
            result = subprocess.run(
                install_cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                err = result.stderr.strip() if result.stderr else "unknown error"
                logger.debug("GPUd install failed: %s", err)
                _emit(f"[warning]GPUd install failed: {err}[/warning]")
                return False

            # Start daemon
            start_cmd = ssh_prefix + [
                f"sudo gpud up --web-address={self.gpud_bind}:{self.gpud_port}"
            ]
            start_result = subprocess.run(
                start_cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if start_result.returncode != 0:
                err = start_result.stderr.strip() if start_result.stderr else "unknown error"
                logger.debug("GPUd start failed: %s", err)
                _emit(f"[warning]GPUd start failed: {err}[/warning]")
                return False

            # Write marker file
            marker_cmd = ssh_prefix + ["echo 'running' | sudo tee /var/run/flow-gpud-status"]
            subprocess.run(
                marker_cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            # Poll health endpoint for up to 30 seconds
            health_cmd = ssh_prefix + [f"curl -skf https://localhost:{self.gpud_port}/healthz"]
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                poll = subprocess.run(
                    health_cmd,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if poll.returncode == 0:
                    _emit("[success]GPUd installed and running.[/success]")
                    return True
                time.sleep(2)

            _emit(
                "[warning]GPUd installed but health endpoint not responding "
                f"after 30s on port {self.gpud_port}[/warning]"
            )
            return False
        except Exception as e:  # noqa: BLE001
            _emit(f"[warning]GPUd install error: {e}[/warning]")
            return False

    def _nvidia_smi_fallback(
        self,
        task: Any,
        *,
        key_path: str | None = None,
    ) -> NodeHealthSnapshot | None:
        """Collect basic GPU metrics via nvidia-smi when GPUd is unavailable."""
        try:
            ssh_prefix = ssh_diagnosis.build_ssh_command_prefix(task, key_path=key_path)
            smi_cmd = ssh_prefix + [
                "nvidia-smi --query-gpu=index,name,temperature.gpu,"
                "utilization.gpu,memory.used,memory.total,power.draw,"
                "power.limit --format=csv,noheader,nounits"
            ]
            result = subprocess.run(
                smi_cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode != 0:
                return None

            from flow.sdk.health_models import GPUMetric

            gpu_metrics: list[GPUMetric] = []
            for line in result.stdout.strip().splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 8:
                    continue
                try:
                    gpu_metrics.append(
                        GPUMetric(
                            gpu_index=int(parts[0]),
                            uuid="",
                            name=parts[1],
                            temperature_c=float(parts[2]),
                            power_draw_w=float(parts[6]),
                            power_limit_w=float(parts[7]),
                            memory_used_mb=int(float(parts[4])),
                            memory_total_mb=int(float(parts[5])),
                            gpu_utilization_pct=float(parts[3]),
                            sm_occupancy_pct=0.0,
                            clock_mhz=0,
                            max_clock_mhz=0,
                        )
                    )
                except (ValueError, IndexError):
                    continue

            if not gpu_metrics:
                return None

            return self.snapshot_factory.create_nvidia_smi_snapshot(task, gpu_metrics)
        except Exception:  # noqa: BLE001
            return None

    def _apply_gpu_analysis(self, snapshot: NodeHealthSnapshot) -> None:
        """Score the snapshot and merge findings into checker state."""
        score = scoring.calculate_health_score(snapshot, self.thresholds)
        snapshot.health_score = score
        snapshot.health_status = scoring.determine_health_status(score)
        issues, warnings, successes = scoring.analyze_gpu_health(snapshot)
        with self._lists_lock:
            self.issues.extend(issues)
            self.warnings.extend(warnings)
            self.successes.extend(successes)

    # ------------------------------------------------------------------
    # Fleet GPU health
    # ------------------------------------------------------------------

    def check_fleet_gpu_health(
        self,
        show_all: bool = False,
        json_mode: bool = False,
        name_filter: str | None = None,
        limit: int | None = None,
        watch_interval: int | None = None,
    ) -> FleetHealthSummary:
        """Check GPU health across all running tasks."""
        from flow.cli.utils.theme_manager import theme_manager

        console = theme_manager.create_console()

        tasks = self.flow_client.tasks.list(status=TaskStatus.RUNNING, limit=100)
        if not tasks:
            try:
                recent = self.flow_client.tasks.list(status=None, limit=200)

                def score(t: Any) -> int:
                    try:
                        return int(getattr(t, "num_instances", 1) or 1)
                    except Exception:  # noqa: BLE001
                        return 1

                recent_sorted = sorted(recent, key=score, reverse=True)
                tasks = [t for t in recent_sorted if score(t) > 1][:5]
            except Exception:  # noqa: BLE001
                pass

        if not show_all:
            tasks = [t for t in tasks if self.gpu_detector.is_gpu_instance(t.instance_type)]

        if name_filter:
            try:
                nf = name_filter.lower()
                tasks = [
                    t
                    for t in tasks
                    if (t.name and nf in str(t.name).lower())
                    or (t.task_id and nf in str(t.task_id).lower())
                ]
            except Exception:  # noqa: BLE001
                pass

        if limit is not None and isinstance(limit, int) and limit > 0:
            tasks = tasks[:limit]

        if not tasks:
            if not json_mode:
                console.print("[warning]No GPU tasks are currently running[/warning]")
            self.add_warning("GPU Health", "No GPU tasks are currently running")
            return FleetHealthSummary(
                timestamp=datetime.now(timezone.utc),
                total_nodes=0,
                healthy_nodes=0,
                degraded_nodes=0,
                critical_nodes=0,
                total_gpus=0,
                healthy_gpus=0,
                avg_gpu_temperature=0,
                avg_gpu_utilization=0,
                avg_gpu_memory_utilization=0,
            )

        snapshots: list[NodeHealthSnapshot] = []
        if json_mode:
            for task in tasks:
                snapshot = self.check_gpu_health(task.task_id, auto_install=False)
                if snapshot:
                    snapshots.append(snapshot)
                time.sleep(0.1)
        else:
            console.print()
            with AnimatedEllipsisProgress(
                console,
                f"🔍 Discovering {len(tasks)} GPU nodes",
                animation_style="shimmer",
                start_immediately=True,
            ) as init_progress:
                time.sleep(0.6)
                init_progress.update_message(f"📡 Connecting to {len(tasks)} nodes")
                time.sleep(0.6)
            console.print()

            from concurrent.futures import ThreadPoolExecutor, as_completed

            animation_frame = 0
            current_checking_node = None
            check_complete = threading.Event()

            def run_checks_parallel():
                nonlocal current_checking_node
                max_workers = min(8, max(1, len(tasks)))
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    is_demo = False
                    with suppress(Exception):
                        is_demo = getattr(self.flow_client.config, "provider", "") == "mock"

                    nonhealthy_idx = 0 if not is_demo else (len(tasks) // 2)

                    future_to_task = {}
                    for idx, t in enumerate(tasks):
                        if is_demo:
                            scenario = "healthy" if idx != nonhealthy_idx else "degraded"
                            future = executor.submit(
                                self.check_gpu_health,
                                t.task_id,
                                scenario,
                                auto_install=False,
                            )
                        else:
                            future = executor.submit(
                                self.check_gpu_health,
                                t.task_id,
                                auto_install=False,
                            )
                        future_to_task[future] = t
                    for future in as_completed(future_to_task):
                        t = future_to_task[future]
                        current_checking_node = t.name or t.task_id[:12]
                        try:
                            snapshot = future.result()
                            if snapshot:
                                snapshots.append(snapshot)
                        except Exception:  # noqa: BLE001
                            pass
                        time.sleep(0.05)
                current_checking_node = None
                check_complete.set()

            checker_thread = threading.Thread(target=run_checks_parallel, daemon=True)
            checker_thread.start()

            with Live(console=console, refresh_per_second=20, vertical_overflow="crop") as live:
                while not check_complete.is_set() or animation_frame < 10:
                    layout = Layout()
                    layout.split_column(
                        Layout(
                            self.renderer.render_scan_progress_panel(
                                total_tasks=len(tasks),
                                checked_snapshots=snapshots,
                                current_node_label=current_checking_node,
                                animation_frame=animation_frame,
                            ),
                            size=13,
                        ),
                        Layout(self.renderer.render_live_table(tasks, snapshots)),
                    )
                    live.update(layout)
                    animation_frame += 1
                    time.sleep(0.05)

                checker_thread.join(timeout=1.0)

        summary = self._calculate_fleet_summary(snapshots)

        if snapshots and not json_mode:
            unmonitored = [s for s in snapshots if s.health_status == HealthStatus.UNKNOWN]
            if unmonitored:
                install_url = "https://pkg.gpud.dev/install.sh"
                info_content = f"""[warning]{len(unmonitored)} of {len(snapshots)} nodes lack GPU monitoring[/warning]

[bold]To enable monitoring:[/bold]
• Future tasks: Use [accent]flow submit[/accent] (includes GPUd)
• Current tasks: SSH and run:
  [accent]curl -fsSL {install_url} | bash[/accent]

[bold]Quick action:[/bold] [link]{install_url}[/link]
"""
                info_panel = Panel(
                    info_content,
                    title="[bold warning]⚠ Action Needed[/bold warning]",
                    border_style=theme_manager.get_color("warning"),
                    padding=(1, 1),
                    expand=False,
                )
                console.print("\n")
                console.print(info_panel)

        return summary

    def _calculate_fleet_summary(self, snapshots: list[NodeHealthSnapshot]) -> FleetHealthSummary:
        """Calculate fleet-wide health summary from snapshots."""
        monitored = [s for s in snapshots if s.health_status != HealthStatus.UNKNOWN]
        unmonitored = [s for s in snapshots if s.health_status == HealthStatus.UNKNOWN]

        legacy_snapshots = [
            s for s in unmonitored if "legacy" in (s.machine_info or {}).get("note", "").lower()
        ]
        not_installed = [
            s
            for s in unmonitored
            if "not installed" in (s.machine_info or {}).get("note", "").lower()
        ]

        total_nodes = len(monitored)
        healthy_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.HEALTHY)
        degraded_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.DEGRADED)
        critical_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.CRITICAL)

        total_gpus = 0
        healthy_gpus = 0
        sum_temp = 0.0
        sum_util = 0.0
        sum_mem = 0.0
        for s in monitored:
            try:
                nodes = int((s.machine_info or {}).get("nodes", 1) or 1)
            except Exception:  # noqa: BLE001
                nodes = 1
            gpn = len(s.gpu_metrics)
            if gpn == 0:
                gpn = int((s.machine_info or {}).get("gpus_per_node", 0) or 0)
            measured_gpus = len(s.gpu_metrics)
            total_gpus += measured_gpus if measured_gpus > 0 else nodes * gpn
            for g in s.gpu_metrics:
                if g.temperature_c < 75 and not g.is_throttling:
                    healthy_gpus += 1
                sum_temp += g.temperature_c
                sum_util += g.gpu_utilization_pct
                sum_mem += g.memory_utilization_pct

        if total_gpus > 0:
            avg_temp = sum_temp / total_gpus
            avg_util = sum_util / total_gpus
            avg_mem = sum_mem / total_gpus
        else:
            avg_temp = avg_util = avg_mem = 0

        critical_issues: list[dict] = []
        fleet_warnings: list[dict] = []

        for snapshot in snapshots:
            if snapshot.health_status == HealthStatus.CRITICAL:
                for issue in self.issues:
                    if issue["category"] == "GPU Health":
                        critical_issues.append(
                            {
                                "task_name": snapshot.task_name,
                                "component": "GPU",
                                "message": issue["message"],
                            }
                        )

            for gpu in snapshot.gpu_metrics:
                if gpu.temperature_c >= 85:
                    critical_issues.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"Critical temperature: {gpu.temperature_c}°C",
                        }
                    )
                elif gpu.temperature_c >= 75:
                    fleet_warnings.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"High temperature: {gpu.temperature_c}°C",
                        }
                    )

        if legacy_snapshots:
            fleet_warnings.append(
                {
                    "task_name": "Legacy Tasks",
                    "component": "GPU Monitoring",
                    "message": f"{len(legacy_snapshots)} task(s) started before GPU monitoring was available",
                }
            )

        if not_installed:
            fleet_warnings.insert(
                0,
                {
                    "task_name": "Manual Tasks",
                    "component": "GPU Monitoring",
                    "message": f"{len(not_installed)} task(s) without GPU monitoring (started manually or via console)",
                },
            )

        return FleetHealthSummary(
            timestamp=datetime.now(timezone.utc),
            total_nodes=total_nodes,
            healthy_nodes=healthy_nodes,
            degraded_nodes=degraded_nodes,
            critical_nodes=critical_nodes,
            total_gpus=total_gpus,
            healthy_gpus=healthy_gpus,
            avg_gpu_temperature=avg_temp,
            avg_gpu_utilization=avg_util,
            avg_gpu_memory_utilization=avg_mem,
            critical_issues=critical_issues[:10],
            warnings=fleet_warnings[:10],
            legacy_nodes=len(legacy_snapshots),
        )

    # ------------------------------------------------------------------
    # Report generation
    # ------------------------------------------------------------------

    def generate_report(self) -> dict[str, Any]:
        """Generate comprehensive health report."""
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "summary": {
                "issues": len(self.issues),
                "warnings": len(self.warnings),
                "successes": len(self.successes),
            },
            "details": {
                "issues": self.issues,
                "warnings": self.warnings,
                "successes": self.successes,
            },
        }
