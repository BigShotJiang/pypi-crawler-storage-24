"""Shell completion support for the Flow CLI."""

from flow.cli.completion.callbacks import (
    complete_instance_types,
    complete_ssh_key_identifiers,
    complete_task_ids,
    complete_volume_ids,
    complete_yaml_files,
)

__all__ = [
    "complete_instance_types",
    "complete_ssh_key_identifiers",
    "complete_task_ids",
    "complete_volume_ids",
    "complete_yaml_files",
]
