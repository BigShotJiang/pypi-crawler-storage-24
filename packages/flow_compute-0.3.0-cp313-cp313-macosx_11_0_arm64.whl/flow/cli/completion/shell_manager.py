"""Shell completion installation and script generation.

Manages install/uninstall of shell completion scripts for Bash, Zsh, and Fish.
Generates completion scripts via Click's ``_FLOW_COMPLETE`` mechanism with
static fallbacks when the binary is unavailable.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from rich.panel import Panel

from flow.cli.utils.theme_manager import theme_manager
from flow.errors import FlowError

console = theme_manager.create_console()


def _print_status_panel(body_lines: list[str]) -> None:
    """Render a Shell Completion status panel to the console."""
    panel = Panel(
        "\n".join(body_lines),
        title="[accent][bold]Shell Completion[/bold][/accent]",
        border_style=theme_manager.get_color("table.border"),
        expand=False,
    )
    console.print("")
    console.print(panel)


class ShellCompletionManager:
    """Manage shell completion install/uninstall and script generation.

    Attributes:
      SUPPORTED_SHELLS: Shells explicitly supported by this implementation.
      SHELL_CONFIGS: Mapping of shell to its rc file and completion directory.
    """

    SUPPORTED_SHELLS = ["bash", "zsh", "fish"]
    SHELL_CONFIGS = {
        "bash": {"rc_file": "~/.bashrc", "completion_dir": "~/.bash_completion.d"},
        "zsh": {"rc_file": "~/.zshrc", "completion_dir": "~/.zsh/completions"},
        "fish": {
            "rc_file": "~/.config/fish/config.fish",
            "completion_dir": "~/.config/fish/completions",
        },
    }

    def render_script(self, shell: str) -> str:
        """Render a shell completion script for the given shell.

        Attempts to ask Click (via the Flow entrypoint) to emit a shell-specific
        script. When unavailable, falls back to a bundled, known-good template.

        Args:
          shell: Target shell name. One of ``"bash"``, ``"zsh"``, or ``"fish"``.

        Returns:
          The full shell completion script text.

        Raises:
          FlowError: If the requested shell is not supported.
        """
        flow_cmd = shutil.which("flow")
        cmd = [flow_cmd] if flow_cmd else [sys.executable, "-m", "flow.cli"]
        result = subprocess.run(
            cmd,
            env={**os.environ, "_FLOW_COMPLETE": f"{shell}_source"},
            capture_output=True,
            text=True,
        )
        if result.stdout and not result.stdout.startswith("Usage:"):
            return result.stdout

        if shell == "bash":
            return """_flow_completion() {
    local IFS=$'\\n'
    local response

    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD _FLOW_COMPLETE=bash_complete flow)

    for completion in $response; do
        IFS=',' read type value <<< "$completion"

        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done

    return 0
}

complete -o nosort -F _flow_completion flow"""
        if shell == "zsh":
            return """#compdef flow

_flow_completion() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[flow] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) _FLOW_COMPLETE=zsh_complete flow)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
            return
        elif [[ "$type" == "file" ]]; then
            _path_files
            return
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -t commands completion completions_with_descriptions
    fi

    if [ -n "$completions" ]; then
        compadd -U -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    _flow_completion "$@"
else
    compdef _flow_completion flow
fi"""
        if shell == "fish":
            return '''function _flow_completion
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) _FLOW_COMPLETE=fish_complete flow)

    for completion in $response
        set -l metadata (string split "," $completion)

        if test $metadata[1] = "dir"
            __fish_complete_directories
        else if test $metadata[1] = "file"
            __fish_complete_path
        else if test $metadata[1] = "plain"
            echo $metadata[2]
        end
    end
end

complete -c flow -f -a "(_flow_completion)"'''
        raise FlowError(f"Unsupported shell: {shell}")

    def get_completion_path(self, shell: str) -> Path:
        """Return the standard completion file path for a shell.

        Args:
          shell: Shell name. One of ``"bash"``, ``"zsh"``, or ``"fish"``.

        Returns:
          Path to the completion script location for the shell.

        Raises:
          FlowError: If the shell is unsupported.
        """
        if shell == "bash":
            return Path(os.path.expanduser("~/.bash_completion.d/flow"))
        if shell == "zsh":
            return Path(os.path.expanduser("~/.zsh/completions/_flow"))
        if shell == "fish":
            return Path(os.path.expanduser("~/.config/fish/completions/flow.fish"))
        raise FlowError(f"Unsupported shell: {shell}")

    def is_installed(self, shell: str, rc_content: str) -> bool:
        """Check whether completion activation is already present in rc content.

        Args:
          shell: Shell name.
          rc_content: Full text content of the rc configuration file.

        Returns:
          True if a completion activation line or marker is present.
        """
        marker = "# Flow CLI completion"
        if marker in rc_content:
            return True
        try:
            line = self.get_activation_line(shell)
        except Exception:  # noqa: BLE001
            line = ""
        if line and line in rc_content:
            return True
        substr = {
            "bash": [
                "_FLOW_COMPLETE=bash_source flow",
                "python -m flow.cli completion generate bash",
            ],
            "zsh": ["_FLOW_COMPLETE=zsh_source flow", "python -m flow.cli completion generate zsh"],
            "fish": [
                "_FLOW_COMPLETE=fish_source flow | source",
                "python -m flow.cli completion generate fish",
            ],
        }.get(shell, [])
        return any(s in rc_content for s in substr)

    def get_activation_line(self, shell: str) -> str:
        """Build the activation line to source completion for a shell.

        Args:
          shell: Shell name. One of ``"bash"``, ``"zsh"``, or ``"fish"``.

        Returns:
          A single-line shell snippet for inclusion in the user's rc file.
        """
        if shutil.which("flow"):
            if shell == "bash":
                return 'if [ -n "${BASH_VERSION-}" ]; then eval "$(_FLOW_COMPLETE=bash_source flow)"; fi'
            if shell == "zsh":
                return (
                    'if [ -n "${ZSH_VERSION-}" ]; then eval "$(_FLOW_COMPLETE=zsh_source flow)"; fi'
                )
            if shell == "fish":
                return 'if test -n "$FISH_VERSION"; _FLOW_COMPLETE=fish_source flow | source; end'
            return f"# Unsupported shell: {shell}"
        if shell == "bash":
            return 'if [ -n "${BASH_VERSION-}" ]; then eval "$(python -m flow.cli completion generate bash)"; fi'
        if shell == "zsh":
            return 'if [ -n "${ZSH_VERSION-}" ]; then eval "$(python -m flow.cli completion generate zsh)"; fi'
        if shell == "fish":
            return 'if test -n "$FISH_VERSION"; python -m flow.cli completion generate fish | source; end'
        return f"# Run: flow completion generate {shell}"

    def _read_rc(self, rc_path: Path) -> str:
        """Read rc file content, returning empty string if missing."""
        try:
            return rc_path.read_text()
        except FileNotFoundError:
            return ""

    def _clean_legacy_lines(self, content: str) -> str:
        """Remove bare ``_FLOW_COMPLETE`` eval lines left by ``auto-click-auto``.

        Args:
          content: Raw rc file content.

        Returns:
          Cleaned content with legacy lines removed.
        """
        # Pattern for bare auto-click-auto lines (no "# Flow CLI completion" guard)
        auto_click_pattern = re.compile(
            r'^eval "\$\(_FLOW_COMPLETE=\w+_source flow\)"$', re.MULTILINE
        )
        cleaned = auto_click_pattern.sub("", content)
        # Collapse 3+ newlines to 2
        return re.sub(r"\n{3,}", "\n\n", cleaned)

    def install(self, shell: str | None, path: str | None = None, *, quiet: bool = False) -> None:
        """Install completion script and activation for the specified shell.

        Args:
          shell: Shell name or ``None`` to auto-detect.
          path: Optional explicit rc/config file to append an activation line.
          quiet: When True, skip Rich panel output (used by ``install_if_missing``).
        """
        try:
            if not shell:
                shell = self.detect_shell()
                if not shell:
                    if not quiet:
                        console.print(
                            "[error]Could not auto-detect shell. Please specify with --shell[/error]"
                        )
                    return

            rc_file = (
                Path(path).expanduser()
                if path
                else Path(self.SHELL_CONFIGS[shell]["rc_file"]).expanduser()
            )

            # Read rc file once, clean legacy lines, then check/install
            rc_content = self._read_rc(rc_file)
            cleaned = self._clean_legacy_lines(rc_content)
            if cleaned != rc_content:
                rc_file.write_text(cleaned)
                rc_content = cleaned

            if path:
                rc_file.parent.mkdir(parents=True, exist_ok=True)
                completion_line = self.get_activation_line(shell)
                already_present = self.is_installed(shell, rc_content)
                if not already_present:
                    with open(rc_file, "a") as f:
                        f.write(f"\n# Flow CLI completion\n{completion_line}\n")

                if not quiet:
                    body_lines = [f"  [muted]Shell:[/muted] {shell}"]
                    if already_present:
                        body_lines.append(
                            f"  [muted]Status:[/muted] Already configured in [repr.path]{rc_file}[/repr.path]"
                        )
                    else:
                        body_lines.append(
                            f"  [muted]Installed:[/muted] [repr.path]{rc_file}[/repr.path]"
                        )
                    body_lines.append(
                        f"  [muted]Activate now:[/muted] [accent]source {rc_file}[/accent]"
                    )
                    body_lines.append(
                        f"  [muted]Tip:[/muted] Restart your {shell} shell to persist"
                    )
                    _print_status_panel(body_lines)
                return

            target_file = self.get_completion_path(shell)
            target_file.parent.mkdir(parents=True, exist_ok=True)
            script_text = self.render_script(shell)
            target_file.write_text(script_text)

            completion_line = self.get_activation_line(shell)
            added_activation = False
            if not self.is_installed(shell, rc_content):
                rc_file.parent.mkdir(parents=True, exist_ok=True)
                with open(rc_file, "a") as f:
                    f.write(f"\n# Flow CLI completion\n{completion_line}\n")
                added_activation = True

            if not quiet:
                body_lines = [
                    f"  [muted]Shell:[/muted] {shell}",
                    f"  [muted]Installed:[/muted] [repr.path]{target_file}[/repr.path]",
                ]
                if added_activation:
                    body_lines.append(
                        f"  [muted]Updated:[/muted] [repr.path]{rc_file}[/repr.path] [muted]\u2014 activation line added[/muted]"
                    )
                body_lines.append(
                    f"  [muted]Activate now:[/muted] [accent]source {rc_file}[/accent]"
                )
                body_lines.append(f"  [muted]Tip:[/muted] Restart your {shell} shell to persist")
                _print_status_panel(body_lines)
        except Exception as e:  # noqa: BLE001
            if not quiet:
                from rich.markup import escape

                console.print(f"[error]Installation failed: {escape(str(e))}[/error]")

    def uninstall(self, shell: str | None, path: str | None = None) -> None:
        """Remove Flow CLI completion script and activation lines.

        Args:
          shell: Shell name or ``None`` to auto-detect.
          path: Optional rc/config file to clean instead of the default.
        """
        try:
            if not shell:
                shell = self.detect_shell()
                if not shell:
                    console.print(
                        "[error]Could not auto-detect shell. Please specify with --shell[/error]"
                    )
                    return
            console.print(f"Uninstalling completion for {shell}...")

            try:
                target_file = self.get_completion_path(shell)
                if target_file.exists():
                    target_file.unlink()
                    console.print(f"[success]\u2713[/success] Removed {target_file}")
            except Exception:  # noqa: BLE001
                pass

            rc_file = (
                Path(path).expanduser()
                if path
                else Path(self.SHELL_CONFIGS[shell]["rc_file"]).expanduser()
            )
            if rc_file.exists():
                content = rc_file.read_text()
                lines = content.splitlines()
                new_lines = []
                skip_next = False
                for line in lines:
                    if skip_next:
                        skip_next = False
                        continue
                    if line.strip() == "# Flow CLI completion":
                        skip_next = True
                        continue
                    if ("_FLOW_COMPLETE=" in line and "flow" in line) or (
                        "python -m flow.cli completion generate" in line
                    ):
                        continue
                    new_lines.append(line)
                if new_lines != lines:
                    rc_file.write_text(
                        "\n".join(new_lines) + ("\n" if content.endswith("\n") else "")
                    )
                    console.print(f"[success]\u2713[/success] Cleaned {rc_file}")

            console.print(
                "[success]\u2713[/success] Completion uninstalled\nYou may need to restart your shell or re-source your rc file."
            )
        except Exception as e:  # noqa: BLE001
            from rich.markup import escape

            console.print(f"[error]Uninstall failed: {escape(str(e))}[/error]")

    def install_if_missing(self) -> None:
        """Install shell completion if not already present.

        Auto-detects the shell and installs completion quietly.
        Silently skips if detection fails or completion is already installed.
        """
        shell = self.detect_shell()
        if not shell:
            return
        self.install(shell, quiet=True)

    def detect_shell(self) -> str | None:
        """Best-effort detection of the current interactive shell.

        Returns:
          The detected shell name or ``None`` when detection fails.
        """
        shell_path = os.environ.get("SHELL", "")
        shell_name = os.path.basename(shell_path)
        if shell_name in self.SUPPORTED_SHELLS:
            return shell_name
        try:
            import psutil

            parent = psutil.Process(os.getppid())
            parent_name = parent.name()
            for sh in self.SUPPORTED_SHELLS:
                if sh in parent_name:
                    return sh
        except Exception:  # noqa: BLE001
            pass
        return None
