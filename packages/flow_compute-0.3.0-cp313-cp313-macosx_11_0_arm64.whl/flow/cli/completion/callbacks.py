"""Dynamic shell completion callbacks for the Flow CLI.

Provides completion functions for task IDs, volume IDs, YAML files,
instance types, and SSH key identifiers. These are wired to Click
command parameters via the ``shell_complete`` argument.

All callbacks follow Click's completion protocol: ``(ctx, args, incomplete) -> list``.
"""

from __future__ import annotations

import os
from itertools import islice
from pathlib import Path

from click.shell_completion import CompletionItem

import flow.sdk.factory as sdk_factory

_SEP = " \u00b7 "


def _matches(value: str | None, needle: str) -> bool:
    """Return True if ``value`` starts with ``needle`` (case-insensitive)."""
    if not value:
        return False
    if not needle:
        return True
    try:
        return value.lower().startswith(needle.lower())
    except Exception:  # noqa: BLE001
        return value.startswith(needle)


def _limit(items, n: int) -> list:
    """Return at most ``n`` items from an iterable."""
    return list(islice(items, n))


def _format_task_help(task) -> str:
    """Format a compact help string describing a task."""
    try:
        status = getattr(getattr(task, "status", None), "value", str(getattr(task, "status", "")))
    except Exception:  # noqa: BLE001
        status = ""
    try:
        gpu = getattr(task, "instance_type", None)
        ni = int(getattr(task, "num_instances", 1) or 1)
        if gpu and ni and ni > 1 and "x" not in str(gpu):
            gpu = f"{ni}x{gpu}"
    except Exception:  # noqa: BLE001
        gpu = getattr(task, "instance_type", None)
    try:
        region = getattr(task, "region", None) or ""
    except Exception:  # noqa: BLE001
        region = ""
    parts = [p for p in (status, gpu, region) if p]
    return _SEP.join(parts)


def _tasks_from_api() -> list:
    """Retrieve recent tasks from the API. Returns empty list on error."""
    try:
        flow = sdk_factory.create_client(auto_init=True)
        tasks = flow.tasks.list(limit=100)
        return list(tasks)
    except Exception:  # noqa: BLE001
        return []


def complete_task_ids(ctx, args, incomplete):
    """Complete task identifiers, names, and indices.

    Args:
      ctx: Click context (unused but required by the interface).
      args: Full list of CLI args preceding the incomplete token.
      incomplete: Current prefix being completed.

    Returns:
      A list of ``CompletionItem`` instances.
    """
    try:
        if os.environ.get("_FLOW_COMPLETE") is None:
            return []

        tasks = _tasks_from_api()

        index_items: list[CompletionItem] = []
        try:
            from flow.cli.utils.task_index_cache import TaskIndexCache

            idx_map = TaskIndexCache().get_indices_map()
            for idx, tid in idx_map.items():
                if _matches(idx, incomplete):
                    index_items.append(CompletionItem(idx, f"index \u2192 {tid[:12]}\u2026"))
        except Exception:  # noqa: BLE001
            pass

        task_items: list[CompletionItem] = []
        for t in tasks:
            tid = getattr(t, "task_id", None)
            name = getattr(t, "name", None)
            help_text = _format_task_help(t)
            if tid and _matches(tid, incomplete):
                task_items.append(CompletionItem(tid, help_text or (name or "")))
            if name and name != tid and _matches(name, incomplete):
                task_items.append(CompletionItem(name, help_text or (tid or "")))

        return _limit(index_items + task_items, 50)
    except Exception:  # noqa: BLE001
        return []


def complete_volume_ids(ctx, args, incomplete):
    """Complete volume identifiers and names with contextual annotations.

    Args:
      ctx: Click context (unused).
      args: Full list of CLI args preceding the incomplete token.
      incomplete: Current prefix being completed.

    Returns:
      A list of ``CompletionItem`` instances or an empty list on error.
    """
    try:
        if os.environ.get("_FLOW_COMPLETE") is None:
            return []

        try:
            flow = sdk_factory.create_client(auto_init=True)
            volumes = flow.volumes.list(limit=200)
        except Exception:  # noqa: BLE001
            volumes = []

        items: list[CompletionItem] = []
        for v in volumes:
            vid = getattr(v, "volume_id", getattr(v, "id", None))
            name = getattr(v, "name", None)
            region = getattr(v, "region", "")
            size = getattr(v, "size_gb", None)
            status = "attached" if getattr(v, "attached_to", None) else "available"
            descr_parts = [status]
            if region:
                descr_parts.append(region)
            if size is not None:
                descr_parts.append(f"{size}GB")
            descr = _SEP.join(descr_parts)
            if vid and _matches(vid, incomplete):
                items.append(CompletionItem(vid, descr))
            if name and name != vid and _matches(name, incomplete):
                items.append(CompletionItem(name, f"{descr}{_SEP}{vid}"))

        return _limit(items, 50)
    except Exception:  # noqa: BLE001
        return []


def complete_yaml_files(ctx, args, incomplete):
    """Complete YAML file paths relative to the current directory.

    Args:
      ctx: Click context (unused).
      args: Full list of CLI args preceding the incomplete token.
      incomplete: Current path prefix being completed.

    Returns:
      A sorted list of matching relative paths (strings), capped at 50.
    """
    try:
        cwd = Path.cwd()
        yaml_files = []
        for pattern in ["*.yaml", "*.yml"]:
            yaml_files.extend(cwd.glob(pattern))
        for subdir in ["configs", "config", "tasks", ".flow"]:
            subdir_path = cwd / subdir
            if subdir_path.exists():
                yaml_files.extend(subdir_path.glob("*.yaml"))
                yaml_files.extend(subdir_path.glob("*.yml"))
        results = []
        for f in yaml_files:
            path_str = str(f.relative_to(cwd))
            if path_str.startswith(incomplete):
                results.append(path_str)
        return sorted(results)[:50]
    except Exception:  # noqa: BLE001
        return []


def complete_instance_types(ctx, args, incomplete):
    """Complete instance types from a curated fallback list.

    Args:
      ctx: Click context (unused).
      args: Full list of CLI args preceding the incomplete token.
      incomplete: Current prefix being completed.

    Returns:
      A list of matching instance type strings.
    """
    try:
        if os.environ.get("_FLOW_COMPLETE") is None:
            return []

        shortlist = [
            "8xh100",
            "4xh100",
            "2xh100",
            "1xh100",
            "8xa100",
            "4xa100",
            "2xa100",
            "1xa100",
            "8xb200",
            "1xb200",
            "cpu",
        ]
        return [t for t in shortlist if _matches(t, incomplete)]
    except Exception:  # noqa: BLE001
        return []


def complete_ssh_key_identifiers(ctx, args, incomplete):
    """Complete SSH key identifiers from local files and platform keys.

    Args:
      ctx: Click context (unused).
      args: Full list of CLI args preceding the incomplete token.
      incomplete: Current prefix being completed.

    Returns:
      A list of ``CompletionItem`` instances describing candidate keys.
    """
    try:
        if os.environ.get("_FLOW_COMPLETE") is None:
            return []
        items: list[CompletionItem] = []
        try:
            ssh_dir = Path.home() / ".ssh"
            flow_keys = Path.home() / ".flow" / "keys"
            for d in (ssh_dir, flow_keys):
                if d.exists():
                    for p in d.iterdir():
                        if (
                            p.is_file()
                            and (p.suffix in {"", ".pub"})
                            and not p.name.endswith(".json")
                        ):
                            s = str(p)
                            if _matches(s, incomplete) or _matches(p.name, incomplete):
                                items.append(CompletionItem(s, "local key"))
        except Exception:  # noqa: BLE001
            pass
        try:
            flow = sdk_factory.create_client(auto_init=True)
            provider = flow.provider
            keys = provider.get_ssh_keys()
            for k in keys:
                fid = k.get("id")
                name = k.get("name")
                if fid and _matches(fid, incomplete):
                    items.append(CompletionItem(fid, name or "platform key"))
                if name and _matches(name, incomplete):
                    items.append(CompletionItem(name, fid or "platform key"))
        except Exception:  # noqa: BLE001
            pass
        return _limit(items, 50)
    except Exception:  # noqa: BLE001
        return []
