"""Flow CLI application module.

Main CLI entry point and command registration for Flow.
"""

import logging
import os
import sys
import threading
from collections.abc import Callable
from typing import Any

import click

from flow.cli.commands.base import console

# Apply console patching early to ensure all Console instances respect settings
from flow.cli.ui.presentation.terminal_adapter import TerminalAdapter
from flow.cli.utils.help_manual import render_rich_help
from flow.cli.utils.icons import prefix_with_flow_icon
from flow.cli.utils.theme_manager import theme_manager
from flow.cli.utils.update_notifier import UpdateNotifier
from flow.utils.links import DocsLinks

logger = logging.getLogger(__name__)

# Optional: "did you mean" suggestions (no-op if not installed)
try:
    from click_didyoumean import DYMGroup as _DYMGroup
except Exception:  # pragma: no cover - optional dependency  # noqa: BLE001
    _DYMGroup = click.Group  # type: ignore

# Optional: Trogon TUI decorator (no-op if not installed)
try:
    from trogon import tui as _tui
except Exception:  # pragma: no cover - optional dependency  # noqa: BLE001

    def _tui(*_args, **_kwargs):  # type: ignore
        def _decorator(f):
            return f

        return _decorator


class OrderedDYMGroup(_DYMGroup):
    """Click Group with insertion-order listing and did-you-mean suggestions."""

    def list_commands(self, ctx: click.Context) -> list[str]:
        """Return command names preserving insertion order."""
        return list(self.commands.keys())


class LazyDYMGroup(OrderedDYMGroup):
    """Lazy-loading Click Group.

    Stores loader callables for commands and imports them only when invoked.
    Also allows fast help rendering without importing every command.
    """

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        # Optional short help map to avoid importing modules on --help
        self._help_summaries: dict[str, str] = {}
        # Optional example map for golden-path usage snippets
        self._examples: dict[str, str] = {}
        # Hidden commands not shown in grouped help
        self._hidden: set[str] = set()
        # Guard against double-loading from concurrent help/resolve
        self._cmd_lock = threading.Lock()

    def add_lazy_command(
        self,
        name: str,
        loader: Callable[[], click.Command | click.Group],
        help_summary: str | None = None,
        example: str | None = None,
        hidden: bool | None = None,
    ) -> None:
        # Store a callable that returns a click.Command when invoked
        self.commands[name] = loader
        if help_summary:
            self._help_summaries[name] = help_summary
        if example:
            self._examples[name] = example
        if hidden:
            self._hidden.add(name)

    def get_command(
        self, ctx: click.Context | None, cmd_name: str
    ) -> click.Command | click.Group | None:
        cmd_obj = self.commands.get(cmd_name)
        if cmd_obj is None:
            return None
        # If it's a callable loader, resolve and replace
        if callable(cmd_obj) and not isinstance(cmd_obj, click.Command):
            with self._cmd_lock:
                # Re-check under lock in case another thread resolved it
                current = self.commands.get(cmd_name)
                if isinstance(current, click.Command | click.Group):
                    return current
                try:
                    resolved = cmd_obj()
                    if isinstance(resolved, click.Command | click.Group):
                        # Prefix help text for the resolved command and all of its subcommands
                        try:
                            self._prefix_help_recursive(resolved)
                        except Exception:  # noqa: BLE001
                            pass
                        self.commands[cmd_name] = resolved
                        return resolved
                except Exception as e:  # noqa: BLE001
                    logger.warning("Failed to load command '%s': %s", cmd_name, e)
                    return None
        return cmd_obj

    def _prefix_help_recursive(self, cmd: click.Command | click.Group) -> None:
        """Prefix help text with icon for a command and all nested subcommands.

        Works for both click.Command and click.Group trees.
        """
        try:
            help_text = getattr(cmd, "help", None)
            if isinstance(help_text, str) and help_text.strip():
                cmd.help = prefix_with_flow_icon(help_text)
        except Exception:  # noqa: BLE001
            pass
        # For Groups, recurse into subcommands
        try:
            if isinstance(cmd, click.Group):
                for sub in getattr(cmd, "commands", {}).values():
                    if isinstance(sub, click.Command | click.Group):
                        self._prefix_help_recursive(sub)
        except Exception:  # noqa: BLE001
            pass


def _show_first_run_banner(console) -> None:
    """Display a compact welcome banner for first-time users."""
    muted = theme_manager.get_color("muted")
    accent = theme_manager.get_color("accent")
    console.print()
    console.print(f"  [{muted}]╔══════════════════════════════════════╗[/{muted}]")
    console.print(
        f"  [{muted}]║[/{muted}]   [{accent}]FLOW[/{accent}]  GPU Cloud Platform        [{muted}]║[/{muted}]"
    )
    console.print(f"  [{muted}]╚══════════════════════════════════════╝[/{muted}]")
    console.print()
    console.print(f"  Get started:    [{accent}]flow setup[/{accent}]")
    console.print(f"  Documentation:  [{accent}]flow docs[/{accent}]")
    console.print()


def _show_help(ctx: click.Context, param: click.Option | None, value: bool) -> None:
    """Render grouped Rich help and exit.

    Replaces Click's default --help to produce the same grouped Rich output
    as bare `flow` (no args), without triggering lazy command imports.
    """
    if not value or ctx.resilient_parsing:
        return
    console = theme_manager.create_console()
    help_text = render_rich_help(ctx, show_more=False)
    console.print(help_text)
    ctx.exit(0)


def print_version(ctx: click.Context, param: click.Option | None, value: bool) -> None:
    """Print version and exit.

    Args:
        ctx: Click context.
        param: Bound option (unused).
        value: Whether the option was provided.
    """
    if not value or ctx.resilient_parsing:
        return
    try:
        from flow._version import get_version

        v = get_version()
    except Exception as e:  # noqa: BLE001
        # Do not explode on import issues; offer optional debug
        if os.environ.get("FLOW_DEBUG"):
            try:
                click.echo(f"warning: failed to load version: {e}", err=True)
            except Exception:  # noqa: BLE001
                pass
        v = "0.0.0+unknown"
    click.echo(f"flow, version {v}")
    ctx.exit()


# TUI decorator is optional; if trogon is unavailable, _tui is a no-op
@_tui()
@click.group(
    cls=LazyDYMGroup,
    context_settings={
        "max_content_width": TerminalAdapter.get_terminal_width(),
    },
    invoke_without_command=True,
    add_help_option=False,
)
@click.option(
    "-h",
    "--help",
    is_flag=True,
    callback=_show_help,
    expose_value=False,
    is_eager=True,
    help="Show this message and exit.",
)
@click.option(
    "-V",
    "--version",
    is_flag=True,
    callback=print_version,
    expose_value=False,
    is_eager=False,
    help="Show version and exit.",
)
@click.option(
    "--all",
    is_flag=True,
    help="Display full command list in help output.",
)
@click.option(
    "--provider",
    type=str,
    default=None,
    envvar="FLOW_PROVIDER",
    metavar="NAME",
    help="Compute provider to use (mithril, local, skypilot).",
)
@click.pass_context
def cli(
    ctx: click.Context,
    all: bool = False,
    provider: str | None = None,
) -> None:
    """❊ Flow CLI & SDK - Submit and manage GPU tasks.

    Flow helps you provision GPU instances/clusters, run workloads from YAML or command,
    and monitor/manage tasks end-to-end.

    """
    # Mark origin as CLI for this process (does not override explicit env)
    try:
        from flow.cli.utils.origin import set_cli_origin_env

        set_cli_origin_env()
    except Exception:  # noqa: BLE001
        pass

    # Set provider override if specified via --provider flag
    if provider:
        os.environ["FLOW_PROVIDER"] = provider

    # Store provider in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["provider"] = provider

    # In CI or non-TTY, default to quiet/no animations
    try:
        is_non_interactive = (not sys.stdout.isatty()) or bool(os.environ.get("CI"))
        if is_non_interactive and not os.environ.get("FLOW_NO_ANIMATION", "").strip():
            os.environ["FLOW_NO_ANIMATION"] = "1"
    except Exception:  # noqa: BLE001
        pass

    # Ensure help reflects the invoked name (flow or flow-compute)
    ctx.info_name = ctx.info_name or (sys.argv[0].split("/")[-1] or "flow")

    # If no subcommand was provided, show help.
    if ctx.invoked_subcommand is None:
        console = theme_manager.create_console()

        # First-run detection: show a banner if not yet configured
        try:
            from pathlib import Path

            config_path = Path.home() / ".flow" / "config.yaml"
            if not config_path.exists():
                _show_first_run_banner(console)
        except Exception:  # noqa: BLE001
            pass

        help_text = render_rich_help(ctx, show_more=all)
        console.print(help_text)
        ctx.exit(0)

    # Check for updates only when running actual commands, not help
    notifier = UpdateNotifier()
    notifier.check_and_notify()


def setup_cli() -> click.Group:
    """Set up the CLI by registering all available commands.

    This function discovers and registers all command modules with the
    main CLI group. It supports both individual commands and command groups.

    Returns:
        The configured CLI group with all commands registered.

    Raises:
        TypeError: If a command module returns an invalid command type.
    """

    # Register lazy loaders to avoid importing all command modules at startup
    # Helper to create a loader for a module
    def _loader(mod_name: str):
        def _load():
            from importlib import import_module

            module = import_module(f"flow.cli.commands.{mod_name}")
            return module.command.get_command()

        return _load

    # Register commands from centralized manifest
    try:
        from flow.cli.command_manifest import COMMANDS

        if isinstance(cli, LazyDYMGroup):
            for spec in COMMANDS:
                try:
                    cli.add_lazy_command(
                        spec.name,
                        _loader(spec.module),
                        spec.summary,
                        spec.example,
                        spec.hidden or None,
                    )
                except Exception as e:  # noqa: BLE001
                    logger.warning("Failed to register command '%s': %s", spec.name, e)
    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to load command manifest: %s", e)

    # Register command aliases (hidden in help) ---------------------------------
    def _add_alias_help_text(cmd, target_name: str) -> None:
        """Add alias help text to a command."""
        try:
            if isinstance(cmd.help, str) and cmd.help.strip():
                cmd.help = f"{cmd.help}\n\nAlias of '{target_name}'."
        except Exception:  # noqa: BLE001
            pass

    def _alias_loader(
        alias_name: str, target_mod_name: str, target_args: dict[str, Any] | None = None
    ):
        def _load():
            from importlib import import_module as _import_module

            try:
                module = _import_module(f"flow.cli.commands.{target_mod_name}")
                base_cmd = module.command.get_command()
            except Exception as e:  # noqa: BLE001
                logger.warning("Failed to load alias target '%s': %s", target_mod_name, e)
                return None

            # Store the original name before modifying
            original_name = base_cmd.name

            # Handle parameterized aliases (commands that need specific arguments)
            if target_args:

                @click.command(
                    name=alias_name,
                    help=getattr(base_cmd, "help", None) or f"Alias of '{original_name}'",
                )
                @click.pass_context
                def _parameterized_alias(ctx: click.Context):
                    """Generic parameterized alias that invokes target command with predefined arguments."""
                    try:
                        # Invoke the target command with the specified arguments
                        return ctx.invoke(base_cmd, **target_args)
                    except Exception as e:  # noqa: BLE001
                        # Fallback error handling
                        console.print(f"[error]Error executing alias '{alias_name}': {e}[/error]")
                        console.print(
                            f"[dim]This is an alias for '{original_name}' with arguments: {target_args}[/dim]"
                        )
                        return 1

                _add_alias_help_text(
                    _parameterized_alias,
                    f"{original_name} {' '.join(f'--{k}={v}' for k, v in target_args.items())}",
                )
                return _parameterized_alias

            # Standard alias handling for commands without predefined arguments
            # If the base command is a group, just return it with the alias name
            if isinstance(base_cmd, click.Group):
                base_cmd.name = alias_name
                _add_alias_help_text(base_cmd, original_name)
                return base_cmd
            else:
                # For simple commands, use the original logic
                @click.command(
                    name=alias_name,
                    help=getattr(base_cmd, "help", None),
                    context_settings=getattr(base_cmd, "context_settings", None),
                    params=getattr(base_cmd, "params", None),
                    epilog=getattr(base_cmd, "epilog", None),
                    short_help=getattr(base_cmd, "short_help", None),
                    add_help_option=getattr(base_cmd, "add_help_option", True),
                )
                @click.pass_context
                def _alias(ctx: click.Context, **kwargs):  # type: ignore[no-redef]
                    return ctx.invoke(base_cmd, **kwargs)

                _add_alias_help_text(_alias, original_name)
                return _alias

        return _load

    try:
        if isinstance(cli, LazyDYMGroup):
            from flow.cli.command_manifest import ALIASES

            for alias_spec in ALIASES:
                if cli.commands.get(alias_spec.alias) is None:
                    try:
                        cli.add_lazy_command(
                            alias_spec.alias,
                            _alias_loader(
                                alias_spec.alias, alias_spec.target_module, alias_spec.target_args
                            ),
                            alias_spec.summary or "",
                            alias_spec.example,
                            alias_spec.hidden,
                        )
                    except Exception as e:  # noqa: BLE001
                        logger.warning("Failed to register alias '%s': %s", alias_spec.alias, e)
    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to load aliases: %s", e)

    return cli


def create_cli() -> click.Group:
    """Create the CLI without triggering heavy imports at module import time.

    This defers command registration until runtime, so invocations like
    `flow --version` do not import every command module.
    """
    cli_group = setup_cli()

    return cli_group


def main() -> int:
    """Entry point for the Flow CLI application.

    This function provides a unified interface on top of single-responsibility
    command modules, orchestrating all CLI commands through a central entry point.

    Returns:
        Exit code from the CLI execution.
    """
    # Initialize centralized logging from YAML (idempotent, respects env)
    try:
        from flow.utils.logging_config import initialize_logging

        # Only initialize when explicitly requested or when running CLI (default True here)
        # This avoids affecting host apps when Flow is imported as a library.
        if os.environ.get("FLOW_LOG_INIT", "1") == "1":
            initialize_logging()
    except Exception:  # noqa: BLE001
        # Never fail CLI due to logging setup
        pass

    argv = sys.argv[1:]

    # Fast-path version without building CLI or importing commands
    # Only trigger if --version/-V is used as a global flag (not in subcommands)
    if argv and argv[0] in ("--version", "-V"):
        try:
            from flow._version import get_version as _get_version

            v = _get_version()
        except Exception:  # noqa: BLE001
            v = "0.0.0+unknown"

        click.echo(f"flow, version {v}")
        return 0

    # Fast-path help command as an alias for --help
    if len(argv) > 0 and argv[0] == "help":
        sys.argv[1] = "--help"

    # Quick config check on startup (set FLOW_SKIP_CONFIG_CHECK=1 to disable)
    if (
        os.environ.get("FLOW_SKIP_CONFIG_CHECK") != "1"
        and len(sys.argv) > 1
        and sys.argv[1] not in ["setup", "init", "--help", "-h", "--version"]
        and "--help" not in sys.argv
        and "-h" not in sys.argv
    ):
        # Only check for commands that need config (not init, help, etc)
        try:
            # Try to load config without auto_init to see if it's configured
            from flow.application.config.config import Config

            Config.from_env(require_auth=True)
        except ValueError:
            # Config missing - provide helpful guidance
            console = theme_manager.create_console()
            console.print("[warning]⚠ Flow is not configured[/warning]\n")
            console.print("To get started, run: [accent]flow setup[/accent]")
            console.print("Or set MITHRIL_API_KEY environment variable\n")
            # Documentation link
            try:
                docs_url = DocsLinks.root()
                console.print(
                    f"Documentation: [link]{docs_url}[/link]  [dim](or run 'flow docs')[/dim]"
                )
            except Exception:  # noqa: BLE001
                pass
            console.print("For help: [dim]flow --help[/dim]")
            return 1

    cli_group = create_cli()

    # Usage telemetry (disabled by default; set FLOW_TELEMETRY=1 to opt in)
    try:
        from flow.cli.utils.telemetry import Telemetry

        telemetry = Telemetry()

        # One-time notice when telemetry is active for the first time
        if telemetry.enabled:
            try:
                from pathlib import Path

                notice_path = Path.home() / ".flow" / ".telemetry-noticed"
                if not notice_path.exists():
                    telemetry_console = theme_manager.create_console(stderr=True)
                    telemetry_console.print(
                        "[dim]Flow telemetry is active. Set FLOW_TELEMETRY=0 to disable.[/dim]"
                    )
                    notice_path.parent.mkdir(parents=True, exist_ok=True)
                    notice_path.touch()
            except Exception:  # noqa: BLE001
                pass

            with telemetry.track_invocation(sys.argv[1:]):
                return cli_group()
        else:
            return cli_group()
    except Exception:  # noqa: BLE001
        # Never fail due to telemetry setup issues
        return cli_group()


if __name__ == "__main__":
    cli()

# Ensure subcommands are registered when this module is imported so that
# tests importing `cli` directly can invoke subcommands without calling
# create_cli()/setup_cli() explicitly.
try:
    # Safe to call multiple times; loaders are lightweight and idempotent
    setup_cli()
except Exception:  # noqa: BLE001
    # Never block import due to optional/missing commands in certain envs
    pass
