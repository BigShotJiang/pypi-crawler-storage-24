"""GPU and instance type formatting utilities for CLI output (canonical).

Provides canonical, compact representations using the multiplication sign (×)
and memory dot (·). Width-aware formatting degrades gracefully.
"""

from __future__ import annotations

from flow.cli.ui.formatters.shared_gpu import GPUFormatter as _SharedGPU
from flow.domain.parsers.gpu_display import parse_gpu_display


class GPUFormatter:
    @staticmethod
    def format_gpu_type(instance_type: str | None) -> str:
        return _SharedGPU.format_gpu_type(instance_type)

    @staticmethod
    def parse_gpu_count(instance_type: str | None) -> int:
        info = parse_gpu_display(instance_type)
        return info.gpu_count

    @staticmethod
    def _parse(instance_type: str | None) -> tuple[str, str | None, int, int | None]:
        """Return (model, memory, gpus_per_node, nvl_count).

        Delegates to the canonical gpu_display parser.
        """
        info = parse_gpu_display(instance_type)
        return info.model, info.memory_label, info.gpu_count, info.nvl_count

    @staticmethod
    def format_gpu_details(instance_type: str | None, num_instances: int = 1) -> str:
        model, memory, gpn, nvl = GPUFormatter._parse(instance_type)
        total = gpn * max(1, num_instances or 1)
        if total == 0:
            return "No GPUs"

        # Build base: always include count prefix for consistency (1×A100, 8×H100)
        base = f"{gpn}×{model}"
        if memory:
            base += f"·{memory}"
        if nvl:
            base += f"·NVL{nvl}"

        if (num_instances or 1) == 1:
            return base

        return f"{total}×{model} ({num_instances}×{gpn})"

    @staticmethod
    def format_ultra_compact(instance_type: str | None, num_instances: int = 1) -> str:
        if not instance_type:
            return "-"
        model, memory, gpn, nvl = GPUFormatter._parse(instance_type)

        # Opaque ID case returns short code as model
        if model.startswith("IT_") or model.startswith("IT-"):
            return f"{model}×{num_instances}" if (num_instances and num_instances > 1) else model

        if (num_instances or 1) == 1:
            parts: list[str] = []
            parts.append(f"{gpn}×{model}")
            if memory:
                parts.append(f"·{memory}")
            if nvl:
                parts.append(f"·NVL{nvl}")
            return "".join(parts)
        else:
            # Multi-instance: show count explicitly as "2×8×H100"
            base = f"{num_instances}×{gpn}×{model}"
            if memory:
                base += f"·{memory}"
            if nvl:
                base += f"·NVL{nvl}"
            return base

    @staticmethod
    def format_ultra_compact_width_aware(
        instance_type: str | None, num_instances: int = 1, max_width: int | None = None
    ) -> str:
        if not instance_type:
            return "-"

        # Parse once, build all format variants from the same tuple
        model, memory, gpn, nvl = GPUFormatter._parse(instance_type)

        # Opaque ID shortcut
        if model.startswith("IT_") or model.startswith("IT-"):
            s = f"{model}×{num_instances}" if (num_instances and num_instances > 1) else model
            if max_width is None or len(s) <= max_width:
                return s
            return s[: max(0, max_width or 0)]

        # Build full compact string
        if (num_instances or 1) == 1:
            full_parts = [f"{gpn}×{model}"]
            if memory:
                full_parts.append(f"·{memory}")
            if nvl:
                full_parts.append(f"·NVL{nvl}")
            full = "".join(full_parts)
        else:
            full = f"{num_instances}×{gpn}×{model}"
            if memory:
                full += f"·{memory}"
            if nvl:
                full += f"·NVL{nvl}"

        if max_width is None or len(full) <= max_width:
            return full

        total = gpn * max(1, int(num_instances or 1))

        # Multi-node: try progressively simpler formats
        if (num_instances or 1) > 1:
            parts_no_mem = f"{num_instances}×{gpn}×{model}"
            if len(parts_no_mem) <= max_width:
                return parts_no_mem

            parts_total = f"{total}×{model}"
            if len(parts_total) <= max_width:
                return parts_total

            return parts_total[: max(0, max_width)]

        # Single node: drop memory/NVL first, then collapse to bare model
        no_mem = full.split("·")[0]
        if len(no_mem) <= max_width:
            return no_mem

        bare = f"{gpn}×{model}"
        if len(bare) <= max_width:
            return bare

        return bare[: max(0, max_width)]


__all__ = ["GPUFormatter"]
