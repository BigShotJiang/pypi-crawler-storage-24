"""Unified task presentation utilities.

Consolidates task display logic including filtering, rendering,
and formatting for consistent presentation across CLI commands.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.console import Console

    from flow.sdk.models import Task

from flow.cli.constants import DEFAULT_STATUS_LIMIT


def _get_sdk_factory():
    """Lazy import sdk_factory."""
    import flow.sdk.factory as sdk_factory

    return sdk_factory


@dataclass
class DisplayOptions:
    """Options for task display."""

    show_all: bool = False
    status_filter: str | None = None
    limit: int = DEFAULT_STATUS_LIMIT
    show_details: bool = True
    json_output: bool = False


@dataclass
class TaskSummary:
    """Summary information about displayed tasks."""

    total_shown: int
    total_available: int
    filtered_by_status: bool
    filtered_by_time: bool
    active_tasks: int
    # True if the displayed (shown) tasks are all active (running/pending/paused)
    only_active_shown: bool = False
    total_gpu_hours: float = 0.0
    pending_tasks: int = 0
    running_tasks: int = 0
    paused_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0

    def has_more_tasks(self) -> bool:
        """Check if there are more tasks than shown."""
        return self.total_shown < self.total_available


class TaskPresenter:
    """Unified task presentation handler."""

    def __init__(self, console: Console, flow_client=None):
        """Initialize task presenter.

        Args:
            console: Rich console for output
            flow_client: Optional Flow client (will create if not provided)
        """
        self.console = console
        self.flow_client = flow_client
        self._task_filter = None
        self._table_renderer = None
        self._detail_renderer = None
        self.task_fetcher = None

    @property
    def task_filter(self):
        if self._task_filter is None:
            from flow.cli.utils.task_filter import TaskFilter

            self._task_filter = TaskFilter()
        return self._task_filter

    @property
    def table_renderer(self):
        if self._table_renderer is None:
            from flow.cli.ui.presentation.task_renderer import TaskTableRenderer

            self._table_renderer = TaskTableRenderer(self.console)
        return self._table_renderer

    @property
    def detail_renderer(self):
        if self._detail_renderer is None:
            from flow.cli.ui.presentation.task_renderer import TaskDetailRenderer

            self._detail_renderer = TaskDetailRenderer(self.console)
        return self._detail_renderer

    def present_single_task(self, task_identifier: str) -> bool:
        """Present details for a single task.

        Args:
            task_identifier: Task ID or name to look up

        Returns:
            True if task was found and displayed, False otherwise
        """
        if not self.flow_client:
            self.flow_client = _get_sdk_factory().create_client(auto_init=True)

        from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
        from flow.cli.utils.task_resolver import resolve_task_identifier

        with AnimatedEllipsisProgress(self.console, "Looking up task", start_immediately=True):
            task, error = resolve_task_identifier(self.flow_client, task_identifier)

        if error:
            from rich.markup import escape

            self.console.print(f"[error]Error:[/error] {escape(str(error))}")
            return False

        # Resolve owner context so detail view shows consistent names with list view
        from flow.cli.ui.runtime.owner_resolver import OwnerResolver

        me = None
        owner_map = None
        try:
            resolver = OwnerResolver(self.flow_client)
            me = resolver.get_me()
            owner_map = resolver.get_teammates_map(me=me)
        except Exception:  # noqa: BLE001
            pass

        self.detail_renderer.render_task_details(task, me=me, owner_map=owner_map)
        return True

    def present_task_list(
        self, options: DisplayOptions, tasks: list[Task] | None = None
    ) -> TaskSummary:
        """Present a list of tasks with filtering and formatting.

        Args:
            options: Display options for filtering and presentation
            tasks: Optional pre-fetched task list (will fetch if not provided)

        Returns:
            TaskSummary with information about displayed tasks
        """
        if not self.flow_client:
            self.flow_client = _get_sdk_factory().create_client(auto_init=True)

        # Fetch tasks if not provided
        if tasks is None:
            tasks = self.flow_client.tasks.list(limit=options.limit)
            if not tasks:
                self._show_no_tasks_message(options)
                return TaskSummary(
                    total_shown=0,
                    total_available=0,
                    filtered_by_status=bool(options.status_filter),
                    filtered_by_time=(not options.show_all),
                    active_tasks=0,
                )

        # Apply filters
        filtered_tasks, summary = self._filter_tasks(tasks, options)

        # Handle empty results
        if not filtered_tasks:
            self._show_no_tasks_message(options)
            return summary

        # Show pre-table summary
        self._show_pre_table_summary(summary)

        # Render the task list
        self.table_renderer.render_task_list(
            tasks=filtered_tasks, show_all=options.show_all, limit=options.limit
        )

        # Save task indices for quick reference
        # Only save when showing from command line (not programmatic usage)
        if filtered_tasks and not options.json_output:
            from flow.cli.utils.task_index_cache import TaskIndexCache

            cache = TaskIndexCache()
            cache.save_indices(filtered_tasks)

        # Show summary information
        if options.show_details:
            self._show_summary_messages(summary, options)

        return summary

    def fetch_tasks(self, options: DisplayOptions) -> list[Task]:
        """Public API to fetch tasks for display."""
        return self._fetch_tasks(options)

    def _fetch_tasks(self, options: DisplayOptions) -> list[Task]:
        """Fetch tasks from API based on options."""
        if not self.flow_client:
            self.flow_client = _get_sdk_factory().create_client(auto_init=True)
        if not self.task_fetcher:
            from flow.cli.utils.task_fetcher import TaskFetcher

            self.task_fetcher = TaskFetcher(self.flow_client)

        return self.task_fetcher.fetch_for_display(
            show_all=options.show_all,
            status_filter=options.status_filter,
            limit=options.limit + 1,
        )

    def _get_status_value(self, task: Task) -> str:
        """Extract status string from task, handling enum types."""
        status = task.status
        return status.value if hasattr(status, "value") else str(status)

    def _filter_tasks(
        self, tasks: list[Task], options: DisplayOptions
    ) -> tuple[list[Task], TaskSummary]:
        """Apply filters to task list and compute summary statistics."""
        total_available = len(tasks)
        filtered_tasks = tasks

        if not options.show_all:
            filtered_tasks = self.task_filter.filter_by_time_window(
                filtered_tasks, hours=24, include_active=True
            )

        from flow.cli.utils.task_stats import compute_total_gpu_hours

        pending_tasks = 0
        running_tasks = 0
        paused_tasks = 0
        completed_tasks = 0
        failed_tasks = 0
        active_tasks = 0

        for task in filtered_tasks:
            status_str = self._get_status_value(task)
            if status_str == "pending":
                pending_tasks += 1
                active_tasks += 1
            elif status_str == "running":
                running_tasks += 1
                active_tasks += 1
            elif status_str == "paused":
                paused_tasks += 1
                active_tasks += 1
            elif status_str == "completed":
                completed_tasks += 1
            elif status_str == "failed":
                failed_tasks += 1

        shown_tasks = filtered_tasks[: options.limit]
        total_gpu_hours = compute_total_gpu_hours(filtered_tasks)

        active_statuses = {"pending", "open", "running", "paused"}
        only_active_shown = len(shown_tasks) > 0 and all(
            self._get_status_value(t) in active_statuses for t in shown_tasks
        )

        summary = TaskSummary(
            total_shown=len(shown_tasks),
            total_available=total_available,
            filtered_by_status=bool(options.status_filter),
            filtered_by_time=not options.show_all,
            active_tasks=active_tasks,
            only_active_shown=only_active_shown,
            total_gpu_hours=total_gpu_hours,
            pending_tasks=pending_tasks,
            running_tasks=running_tasks,
            paused_tasks=paused_tasks,
            completed_tasks=completed_tasks,
            failed_tasks=failed_tasks,
        )

        return shown_tasks, summary

    def _show_no_tasks_message(self, options: DisplayOptions) -> None:
        """Display message when no tasks found."""
        from flow.cli.ui.presentation.nomenclature import get_entity_labels

        labels = get_entity_labels()
        if options.status_filter:
            self.console.print(
                f"No {labels.empty_plural} found with status '{options.status_filter}'"
            )
        elif options.show_all:
            self.console.print(f"No {labels.empty_plural} found in project")
        else:
            self.console.print("No recent or running tasks found")
            self.console.print("[dim]Use --all to see all tasks[/dim]")

    def _show_pre_table_summary(self, summary: TaskSummary) -> None:
        """Display summary line before the task table.

        Args:
            summary: Task summary information
        """
        parts = []

        # Active tasks (running + pending + paused)
        if summary.running_tasks > 0:
            parts.append(f"{summary.running_tasks} running")
        if summary.pending_tasks > 0:
            parts.append(f"{summary.pending_tasks} pending")
        if summary.paused_tasks > 0:
            parts.append(f"{summary.paused_tasks} paused")

        # Completed/failed
        if summary.completed_tasks > 0:
            parts.append(f"{summary.completed_tasks} completed")
        if summary.failed_tasks > 0:
            parts.append(f"{summary.failed_tasks} failed")

        # GPU hours
        if summary.total_gpu_hours > 0:
            if summary.total_gpu_hours >= 1:
                gpu_hrs_str = f"{summary.total_gpu_hours:.1f}"
            else:
                # Show more precision for small values
                gpu_hrs_str = f"{summary.total_gpu_hours:.2f}"
            parts.append(f"GPU-hrs: {gpu_hrs_str}")

        if parts:
            summary_line = " · ".join(parts)
            self.console.print(f"[dim]{summary_line}[/dim]\n")

    def _show_summary_messages(self, summary: TaskSummary, options: DisplayOptions) -> None:
        """Display summary messages after task list.

        Args:
            summary: Task summary information
            options: Display options used
        """
        # Determine if we're showing only active tasks or mixed recent tasks
        showing_active_only = (
            not options.show_all and not options.status_filter and summary.only_active_shown
        )

        # Show limit message if applicable
        if summary.total_shown == options.limit and summary.has_more_tasks():
            if options.show_all:
                self.console.print(
                    f"\n\n[dim]Showing first {options.limit} tasks. Use --limit to see more.[/dim]\n"
                )
            elif showing_active_only:
                self.console.print(
                    "\n\n[dim]Showing active tasks (running/pending). "
                    "Use --all to see all tasks.[/dim]\n"
                )
            else:
                self.console.print(f"\n\n[dim]Showing up to {options.limit} recent tasks.[/dim]")
                self.console.print(
                    "[dim]Use --all to see all tasks or --limit to see more.[/dim]\n"
                )
        elif not options.show_all and not options.status_filter:
            if showing_active_only:
                self.console.print(
                    "\n\n[dim]Showing active tasks only. Use --all to see all tasks.[/dim]\n"
                )
            else:
                # General recent mode (either mixed or none active): mention 24h window
                self.console.print(
                    "\n\n[dim]Showing recent tasks from the last 24 hours. Use --all to see all tasks.[/dim]\n"
                )

        # Show debug info if enabled
        if os.environ.get("FLOW_DEBUG"):
            self._show_debug_info(summary)

    def _show_debug_info(self, summary: TaskSummary) -> None:
        """Show debug information about task display.

        Args:
            summary: Task summary information
        """
        self.console.print("\n[dim]Debug info:[/dim]")
        self.console.print(f"[dim]  Total available: {summary.total_available}[/dim]")
        self.console.print(f"[dim]  Shown: {summary.total_shown}[/dim]")
        self.console.print(f"[dim]  Active: {summary.active_tasks}[/dim]")
        self.console.print(f"[dim]  Filtered by status: {summary.filtered_by_status}[/dim]")
        self.console.print(f"[dim]  Filtered by time: {summary.filtered_by_time}[/dim]")

    def format_task_for_json(self, task: Task) -> dict:
        """Format task object for JSON output."""
        return {
            "task_id": task.task_id,
            "name": task.name,
            "status": self._get_status_value(task),
            "gpu_type": task.gpu_type,
            "created_at": str(task.created_at) if task.created_at else "",
            "started_at": str(task.started_at) if task.started_at else "",
            "completed_at": str(task.completed_at) if task.completed_at else "",
            "error": task.error,
        }
