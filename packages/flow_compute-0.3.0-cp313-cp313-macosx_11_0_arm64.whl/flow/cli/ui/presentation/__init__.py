"""Presentation layer for CLI commands.

Contains renderers and UI composition helpers that build Rich renderables.
Import submodules directly to avoid eager loading of heavy dependencies.
"""
