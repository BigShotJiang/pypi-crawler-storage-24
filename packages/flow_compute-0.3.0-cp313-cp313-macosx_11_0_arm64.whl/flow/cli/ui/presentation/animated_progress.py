"""Animated progress indicator for CLI operations.

Renders a themed spinner with animated text effects using Rich Live.
Visual format: ▐ ⠋ Shimmer-animated message...
"""

from __future__ import annotations

import os
import threading
from typing import Any

from rich.console import Console
from rich.live import Live
from rich.text import Text


def _resolve_accent() -> str:
    """Return the theme accent color for the spinner, with a safe fallback."""
    try:
        from flow.cli.utils.theme_manager import theme_manager

        return theme_manager.get_color("aep.accent") or theme_manager.get_color("accent") or "cyan"
    except Exception:  # noqa: BLE001
        return "cyan"


def _is_ascii_only() -> bool:
    """Check if we should use ASCII-only characters."""
    return os.getenv("FLOW_ASCII") == "1"


class AnimatedEllipsisProgress:
    """Progress spinner with animated text effects.

    Renders a solid bar prefix, themed spinner, and shimmer-animated
    message text. Falls back to a static display in CI / non-TTY.

    Accepts the legacy constructor signature for backward compatibility;
    advanced parameters (animation_style, progress bar, etc.) are ignored.
    """

    _FRAME_INTERVAL = 0.08  # seconds between render frames
    _SPINNER_CYCLE = 0.8  # seconds per spinner rotation
    _SHIMMER_CYCLE = 2.4  # seconds per shimmer pass

    def __init__(
        self,
        console: Console,
        message: str,
        transient: bool = True,
        start_immediately: bool = False,
        **_kwargs: Any,
    ) -> None:
        self._console = console
        self._message = message
        self._transient = transient
        self._start_immediately = start_immediately

        # Disable animation in CI / non-TTY
        self._disabled = bool(os.environ.get("FLOW_NO_ANIMATION"))

        self._live: Live | None = None
        self._render_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

    def _render_frame(self) -> Text:
        """Compose one frame: ▐ ⠋ animated-message"""
        from flow.cli.utils.animations import SPINNERS, get_phase, get_spinner_frame, shimmer_effect

        accent = _resolve_accent()
        ascii_only = _is_ascii_only()

        # Solid bar prefix
        bar_char = "|" if ascii_only else "▐"
        frame = Text(f" {bar_char} ", style=accent)

        # Spinner
        spinner_frames = SPINNERS["line"] if ascii_only else SPINNERS["dots"]
        spinner_phase = get_phase(self._SPINNER_CYCLE)
        spinner_char = get_spinner_frame(spinner_frames, spinner_phase)
        frame.append(spinner_char, style=accent)
        frame.append(" ")

        # Animated message text
        shimmer_phase = get_phase(self._SHIMMER_CYCLE)
        animated_msg = shimmer_effect(self._message, shimmer_phase, intensity=0.5)
        frame.append_text(animated_msg)

        return frame

    def _render_loop(self) -> None:
        """Background thread that refreshes the display."""
        while not self._stop_event.is_set():
            with self._lock:
                if self._live is not None:
                    try:
                        self._live.update(self._render_frame())
                    except Exception:  # noqa: BLE001
                        pass
            self._stop_event.wait(self._FRAME_INTERVAL)

    # -- Context manager -----------------------------------------------------

    def __enter__(self) -> AnimatedEllipsisProgress:
        if self._disabled:
            return self
        self._start_live()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> bool:
        self._stop_live()
        return False

    # -- Public API ----------------------------------------------------------

    def update_message(self, new_message: str) -> None:
        """Change the displayed message while the spinner is running."""
        self._message = new_message

    def start(self) -> None:
        """Start the spinner (for non-context-manager usage)."""
        if self._disabled or self._live is not None:
            return
        self._start_live()

    def stop(self) -> None:
        """Stop the spinner (for non-context-manager usage)."""
        self._stop_live()

    # -- Internal ------------------------------------------------------------

    def _start_live(self) -> None:
        """Initialize Live display and start the render thread."""
        self._stop_event.clear()
        self._live = Live(
            self._render_frame(),
            console=self._console,
            transient=self._transient,
            refresh_per_second=12,  # match render thread frame rate (~0.08s interval)
        )
        self._live.start()
        self._render_thread = threading.Thread(
            target=self._render_loop, daemon=True, name="aep-render"
        )
        self._render_thread.start()

    def _stop_live(self) -> None:
        """Stop the render thread and Live display."""
        self._stop_event.set()
        if self._render_thread is not None:
            self._render_thread.join(timeout=1.0)
            self._render_thread = None
        with self._lock:
            if self._live is not None:
                try:
                    self._live.stop()
                except Exception:  # noqa: BLE001
                    pass
                self._live = None
