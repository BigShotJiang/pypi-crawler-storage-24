"""Shared task formatting utilities for CLI UI.

Single source of truth used by both presentation and components layers.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from flow.cli.utils.theme_manager import theme_manager

if TYPE_CHECKING:
    from flow.sdk.models import Task

logger = logging.getLogger(__name__)


class TaskFormatter:
    """Handles task-related formatting for consistent display across CLI commands."""

    @staticmethod
    def format_task_display(task: Task) -> str:
        if task.name:
            if task.task_id and not task.task_id.startswith("bid_"):
                return f"{task.name} ({task.task_id})"
            return task.name
        return task.task_id

    @staticmethod
    def format_short_task_id(task_id: str, length: int = 16) -> str:
        if len(task_id) <= length:
            return task_id
        return task_id[:length] + "..."

    @staticmethod
    def get_status_config(status: str) -> dict[str, str]:
        status_configs = {
            "pending": {
                "symbol": "○",
                "color": theme_manager.get_color("status.pending"),
                "style": "",
            },
            "open": {
                "symbol": "○",
                "color": theme_manager.get_color("status.pending"),
                "style": "",
            },
            "starting": {
                "symbol": "◇",
                "color": theme_manager.get_color("status.starting"),
                "style": "",
            },
            "preparing": {
                "symbol": "◇",
                "color": theme_manager.get_color("status.preparing"),
                "style": "",
            },
            "provisioning": {
                "symbol": "◐",
                "color": theme_manager.get_color("status.preparing"),
                "style": "",
            },
            "running": {
                "symbol": "●",
                "color": theme_manager.get_color("status.running"),
                "style": "",
            },
            "paused": {
                "symbol": "⏸",
                "color": theme_manager.get_color("status.paused"),
                "style": "",
            },
            "preempting": {
                "symbol": "↻",
                "color": theme_manager.get_color("status.preempting"),
                "style": "",
            },
            "completed": {
                "symbol": "✓",
                "color": theme_manager.get_color("status.completed"),
                "style": "",
            },
            "failed": {
                "symbol": "✗",
                "color": theme_manager.get_color("status.failed"),
                "style": "",
            },
            "cancelled": {
                "symbol": "—",
                "color": theme_manager.get_color("status.cancelled"),
                "style": "",
            },
            "unknown": {"symbol": "○", "color": theme_manager.get_color("muted"), "style": ""},
            # Extra labels used by selection/presentation views
            "available": {"symbol": "✓", "color": theme_manager.get_color("success"), "style": ""},
            "unavailable": {"symbol": "✗", "color": theme_manager.get_color("error"), "style": ""},
            "enabled": {"symbol": "✓", "color": theme_manager.get_color("success"), "style": ""},
            "disabled": {"symbol": "○", "color": theme_manager.get_color("muted"), "style": ""},
        }
        return status_configs.get(
            status.lower(),
            {"symbol": "?", "color": theme_manager.get_color("default"), "style": ""},
        )

    @staticmethod
    def get_status_style(status: str) -> str:
        return TaskFormatter.get_status_config(status)["color"]

    # Status abbreviation codes for non-color output
    _STATUS_CODES: dict[str, str] = {
        "running": "RUN",
        "pending": "PEN",
        "open": "OPN",
        "failed": "ERR",
        "completed": "OK",
        "starting": "ST",
        "preparing": "PRP",
        "provisioning": "PRV",
        "paused": "PAU",
        "preempting": "PRM",
        "cancelled": "CAN",
        "unknown": "UNK",
    }

    @staticmethod
    def format_status_with_color(status: str) -> str:
        config = TaskFormatter.get_status_config(status)
        if not theme_manager.is_color_enabled():
            code = TaskFormatter._STATUS_CODES.get(status.lower(), status.upper()[:3])
            return f"{config['symbol']} {code}"
        style_parts = [config["color"]]
        if config["style"]:
            style_parts.append(config["style"])
        style = " ".join(style_parts)
        return f"[{style}]{config['symbol']} {status}[/{style}]"

    @staticmethod
    def format_compact_status(status: str) -> str:
        config = TaskFormatter.get_status_config(status)
        if not theme_manager.is_color_enabled():
            code = TaskFormatter._STATUS_CODES.get(status.lower(), status.upper()[:3])
            return f"{config['symbol']} {code}"
        style_parts = [config["color"]]
        if config["style"]:
            style_parts.append(config["style"])
        style = " ".join(style_parts)
        return f"[{style}]{config['symbol']}[/{style}]"

    @staticmethod
    def get_display_status(task: Task) -> str:
        """Derive a user-facing status with practical 'open' and 'starting' semantics.

        Rules:
        - Terminal states (failed, cancelled) are shown as-is.
        - PENDING tasks are refined based on instance status:
          - "starting" - bid is allocated, instances are booting
          - "open" - bid is open/unallocated, no instances yet
        - RUNNING tasks are shown as "running".

        This provides clear lifecycle visibility: open -> starting -> running
        """
        status = task.status
        status_value = status.value if hasattr(status, "value") else str(status).lower()

        # Terminal states are authoritative
        if status_value in {"failed", "cancelled"}:
            return status_value

        # Refine display for PENDING tasks based on instance status
        if status_value == "pending":
            metadata = task.provider_metadata or {}
            instance_status = metadata.get("instance_status", "")
            if instance_status:
                instance_status_lower = str(instance_status).lower()
                if instance_status_lower.startswith("status_"):
                    instance_status_lower = instance_status_lower[7:]  # Remove "status_" prefix

                # Show "starting" for instance boot states
                if instance_status_lower in {
                    "starting",
                    "initializing",
                    "new",
                    "confirmed",
                    "provisioning",
                }:
                    return "starting"

            # Default for pending: show "open"
            return "open"

        # For RUNNING and other states, passthrough
        return status_value


def _ensure_datetime_utc(value: datetime | str) -> datetime:
    """Normalize a datetime or ISO string to a UTC-aware datetime."""
    if not isinstance(value, datetime):
        value = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value


def format_task_duration(task: Task) -> str:
    """Format task duration or time since creation."""
    if task.started_at:
        start = _ensure_datetime_utc(task.started_at)
        end = (
            _ensure_datetime_utc(task.completed_at)
            if task.completed_at
            else datetime.now(timezone.utc)
        )
        prefix = ""
    else:
        start = _ensure_datetime_utc(task.created_at)
        end = datetime.now(timezone.utc)
        prefix = "created "

    duration = end - start
    if duration.days > 0:
        return f"{prefix}{duration.days}d {duration.seconds // 3600}h ago"
    hours = duration.seconds // 3600
    minutes = (duration.seconds % 3600) // 60
    if hours > 0:
        return f"{prefix}{hours}h {minutes}m ago"
    if minutes > 0:
        return f"{prefix}{minutes}m ago"
    return f"{prefix}just now"
