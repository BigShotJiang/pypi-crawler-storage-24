"""Shared GPU formatting utilities for CLI UI."""

from __future__ import annotations

import re

from flow.domain.models.instance_types import strip_vendor_prefix
from flow.domain.parsers.gpu_display import parse_gpu_display


class GPUFormatter:
    """Handles GPU and instance type formatting (shared)."""

    @staticmethod
    def format_gpu_type(instance_type: str | None) -> str:
        """Format instance type as uppercase, normalizing 'x' to '×' (multiplication sign)."""
        if not instance_type:
            return "N/A"
        if instance_type.startswith("it_"):
            return instance_type[:12].upper() + "..."
        cleaned = strip_vendor_prefix(instance_type)
        upper = cleaned.upper()
        # Normalize "8XH100" → "8×H100" (digit-X-letter pattern)
        return re.sub(r"(\d)X([A-Z])", r"\1×\2", upper)

    @staticmethod
    def format_ultra_compact(instance_type: str | None, num_instances: int = 1) -> str:
        if not instance_type:
            return "-"
        cleaned = strip_vendor_prefix(str(instance_type).strip())
        base = cleaned.upper()
        return f"{base}×{num_instances}" if num_instances and num_instances > 1 else base

    @staticmethod
    def format_ultra_compact_width_aware(
        instance_type: str | None, num_instances: int = 1, max_width: int | None = None
    ) -> str:
        s = GPUFormatter.format_ultra_compact(instance_type, num_instances)
        if max_width is None or len(s) <= max_width:
            return s
        return s[: max_width - 3] + "..." if max_width and max_width > 3 else s[: max_width or 0]

    @staticmethod
    def format_gpu_details(instance_type: str | None, num_instances: int = 1) -> str:
        """Format GPU details with instance count for the detail view."""
        gpn = GPUFormatter.parse_gpu_count(instance_type)
        total = gpn * max(1, num_instances or 1)
        if total == 0:
            return "No GPUs"
        gpu_type = GPUFormatter.format_gpu_type(instance_type)
        if (num_instances or 1) == 1:
            return gpu_type
        mm = re.search(
            r"[AHV]\d{2,3}|RTX\s*\d{4}|T4|[PK]\d{2,3}|M\d{2}|GB\d{2,3}",
            gpu_type,
            re.IGNORECASE,
        )
        model = (
            mm.group(0).upper()
            if mm
            else re.sub(r"^\d+", "", gpu_type.replace("\u00d7", "").replace("X", ""))
        )
        return f"{total}\u00d7{model} ({num_instances}\u00d7{gpn})"

    @staticmethod
    def parse_gpu_count(instance_type: str | None) -> int:
        if not instance_type:
            return 0
        info = parse_gpu_display(instance_type)
        return info.gpu_count
