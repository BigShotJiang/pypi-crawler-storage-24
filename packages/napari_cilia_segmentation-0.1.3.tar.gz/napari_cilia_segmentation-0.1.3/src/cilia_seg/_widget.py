# =============================================================================
# _widget.py  —  Plain Qt widget (no magicgui Container)
# =============================================================================

import os
from datetime import datetime

import numpy as np
import pandas as pd
import tifffile as tiff
from qtpy.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSpinBox, QDoubleSpinBox,
    QCheckBox, QLineEdit, QTextEdit, QFileDialog,
    QGroupBox, QFormLayout,
)
from qtpy.QtCore import Qt


class CiliaWidget(QWidget):

    def __init__(self, viewer: "napari.viewer.Viewer"):
        super().__init__()
        self._viewer = viewer
        self._lbl_final   = None
        self._df_results  = None
        self._rgb_overlay = None
        self._img         = None

        layout = QVBoxLayout()
        layout.setSpacing(6)
        self.setLayout(layout)

        # Channel & voxel size
        grp1 = QGroupBox("Channel & voxel size")
        f1   = QFormLayout()
        grp1.setLayout(f1)
        self._channel = QSpinBox(); self._channel.setRange(0, 10); self._channel.setValue(1)
        self._vx = QDoubleSpinBox(); self._vx.setDecimals(7); self._vx.setRange(0.0001, 10); self._vx.setSingleStep(0.0001); self._vx.setValue(0.0986479)
        self._vz = QDoubleSpinBox(); self._vz.setDecimals(6); self._vz.setRange(0.0001, 10); self._vz.setSingleStep(0.001);  self._vz.setValue(0.240000)
        f1.addRow("Cilia channel (0/1/2):", self._channel)
        f1.addRow("VX / VY (um):", self._vx)
        f1.addRow("VZ (um):", self._vz)
        layout.addWidget(grp1)

        # Segmentation
        grp2 = QGroupBox("Segmentation")
        f2   = QFormLayout()
        grp2.setLayout(f2)
        self._sigma = QDoubleSpinBox(); self._sigma.setRange(0.1, 5); self._sigma.setSingleStep(0.1); self._sigma.setValue(1.0)
        self._thr   = QDoubleSpinBox(); self._thr.setDecimals(2); self._thr.setRange(90, 99.99); self._thr.setSingleStep(0.1); self._thr.setValue(99.7)
        self._opening  = QSpinBox(); self._opening.setRange(0, 5); self._opening.setValue(1)
        self._min_vox  = QSpinBox(); self._min_vox.setRange(1, 1000000); self._min_vox.setValue(150)
        self._max_vox  = QSpinBox(); self._max_vox.setRange(100, 100000000); self._max_vox.setValue(2000000)
        f2.addRow("Gaussian sigma:", self._sigma)
        f2.addRow("Threshold % (raise=less cilia, lower=more):", self._thr)
        f2.addRow("Opening radius:", self._opening)
        f2.addRow("Min voxels:", self._min_vox)
        f2.addRow("Max voxels:", self._max_vox)
        layout.addWidget(grp2)

        # Filters
        grp3 = QGroupBox("Filters")
        f3   = QFormLayout()
        grp3.setLayout(f3)
        self._exclude_border = QCheckBox(); self._exclude_border.setChecked(True)
        self._min_len = QDoubleSpinBox(); self._min_len.setDecimals(3); self._min_len.setRange(0, 100); self._min_len.setSingleStep(0.001); self._min_len.setValue(0.992)
        self._max_len = QDoubleSpinBox(); self._max_len.setDecimals(3); self._max_len.setRange(0, 100); self._max_len.setSingleStep(0.001); self._max_len.setValue(4.865)
        f3.addRow("Exclude border objects:", self._exclude_border)
        f3.addRow("Min length (um):", self._min_len)
        f3.addRow("Max length (um):", self._max_len)
        layout.addWidget(grp3)

        # Output
        grp4 = QGroupBox("Output")
        f4   = QFormLayout()
        grp4.setLayout(f4)
        self._base_name = QLineEdit("Slice1_ROI2_cilia")
        self._scale_bar = QDoubleSpinBox(); self._scale_bar.setRange(1, 200); self._scale_bar.setValue(20)
        dir_layout = QHBoxLayout()
        self._save_dir = QLineEdit(r"D:\Retinal organoids\napari\segmentation_output")
        browse_btn = QPushButton("Browse")
        browse_btn.clicked.connect(self._browse_dir)
        dir_layout.addWidget(self._save_dir)
        dir_layout.addWidget(browse_btn)
        f4.addRow("Base filename:", self._base_name)
        f4.addRow("Scale bar (um):", self._scale_bar)
        f4.addRow("Save directory:", dir_layout)
        layout.addWidget(grp4)

        # Buttons
        self._run_btn  = QPushButton("Run Segmentation")
        self._save_btn = QPushButton("Save Results")
        self._save_btn.setEnabled(False)
        self._run_btn.clicked.connect(self._run)
        self._save_btn.clicked.connect(self._save)
        layout.addWidget(self._run_btn)
        layout.addWidget(self._save_btn)

        # Log
        layout.addWidget(QLabel("Log:"))
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setFixedHeight(180)
        self._log.setText("Ready - press Run to start.")
        layout.addWidget(self._log)

    def _log_append(self, text):
        self._log.append(text)

    def _log_clear(self):
        self._log.clear()

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Select save directory")
        if d:
            self._save_dir.setText(d)

    def _run(self):
        from ._segmentation import run_segmentation
        self._log_clear()
        self._save_btn.setEnabled(False)

        if len(self._viewer.layers) == 0:
            self._log_append("No layers open - load an OME-TIFF first.")
            return

        layer = self._viewer.layers[0]
        data  = np.asarray(layer.data)
        self._log_append(f"Layer: '{layer.name}'  shape: {data.shape}")

        try:
            lbl_final, df_results, rgb_overlay, img, diagnostics = run_segmentation(
                data           = data,
                channel        = self._channel.value(),
                sigma          = self._sigma.value(),
                thr_percentile = self._thr.value(),
                opening_radius = self._opening.value(),
                min_voxels     = self._min_vox.value(),
                max_voxels     = self._max_vox.value(),
                exclude_border = self._exclude_border.isChecked(),
                min_length_um  = self._min_len.value(),
                max_length_um  = self._max_len.value(),
                vx = self._vx.value(),
                vy = self._vx.value(),
                vz = self._vz.value(),
            )
        except Exception as e:
            self._log_append(f"Error: {e}")
            return

        self._lbl_final   = lbl_final
        self._df_results  = df_results
        self._rgb_overlay = rgb_overlay
        self._img         = img
        self._log_append(diagnostics)

        Z  = img.shape[0]
        vx = self._vx.value()
        vy = self._vx.value()
        vz = self._vz.value()

        for lname in ["CILIA_SEGMENTATION", "ARL13B (dimmed)", "DAPI (nucleus)"]:
            if lname in [l.name for l in self._viewer.layers]:
                self._viewer.layers.remove(self._viewer.layers[lname])

        try:
            if data.ndim == 4 and data.shape[1] >= 3:
                dapi = (data[:, 2, :, :] if data.shape[1] <= data.shape[0]
                        else data[2, :, :, :]).astype(np.float32)
                self._viewer.add_image(dapi, name="DAPI (nucleus)", colormap="blue",
                    blending="additive",
                    contrast_limits=(float(np.percentile(dapi, 50)), float(np.percentile(dapi, 99.9))),
                    opacity=0.6, scale=(vz, vy, vx))
        except Exception:
            pass

        self._viewer.add_image(img, name="ARL13B (dimmed)", colormap="gray",
            blending="additive",
            contrast_limits=(float(np.percentile(img, 50)), float(np.percentile(img, 99.9))),
            opacity=0.25, scale=(vz, vy, vx))

        self._viewer.add_image(rgb_overlay, name="CILIA_SEGMENTATION",
            rgb=True, blending="additive", opacity=1.0)

        best_z = max(range(Z), key=lambda z: np.count_nonzero(lbl_final[z]))
        self._viewer.dims.ndisplay = 2
        self._viewer.dims.set_point(0, best_z)
        self._viewer.reset_view()

        self._save_btn.setEnabled(True)
        self._log_append("Done - press Save Results to write files.")

    def _save(self):
        from ._segmentation import add_scale_bar
        if self._lbl_final is None:
            self._log_append("Nothing to save - run segmentation first.")
            return

        save_dir    = self._save_dir.text()
        base_name   = self._base_name.text().strip()
        vx          = self._vx.value()
        vz          = self._vz.value()
        scale_bar   = self._scale_bar.value()
        img         = self._img
        lbl_final   = self._lbl_final
        rgb_overlay = self._rgb_overlay
        data        = np.asarray(self._viewer.layers[0].data)

        os.makedirs(save_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        self._df_results.to_csv(os.path.join(save_dir, f"{base_name}_{ts}.csv"), index=False)
        tiff.imwrite(os.path.join(save_dir, f"{base_name}_{ts}_labels.tif"), lbl_final.astype(np.int32))
        tiff.imwrite(os.path.join(save_dir, f"{base_name}_{ts}_mask.tif"),   (lbl_final > 0).astype(np.uint8) * 255)

        Z      = img.shape[0]
        best_z = max(range(Z), key=lambda z: np.count_nonzero(lbl_final[z]))
        z      = best_z
        raw_s  = img[z].astype(np.float32)
        lo, hi = np.percentile(raw_s, 1), np.percentile(raw_s, 99.9)
        raw_n  = np.clip((raw_s - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)

        try:
            if data.ndim == 4 and data.shape[1] >= 3:
                dapi_s = (data[:, 2, :, :][z] if data.shape[1] <= data.shape[0]
                          else data[2, :, :, :][z]).astype(np.float32)
                lo2, hi2 = np.percentile(dapi_s, 1), np.percentile(dapi_s, 99.9)
                dapi_n   = np.clip((dapi_s - lo2) / (hi2 - lo2) * 180, 0, 255).astype(np.uint8)
                composite = np.stack([raw_n, np.zeros_like(raw_n), dapi_n], axis=-1)
            else:
                raise ValueError
        except Exception:
            composite = np.stack([raw_n, raw_n, raw_n], axis=-1)

        seg_s       = rgb_overlay[z]
        merged      = np.clip(composite.astype(np.int16) + seg_s.astype(np.int16), 0, 255).astype(np.uint8)
        raw_bg      = np.stack([raw_n // 3, raw_n // 3, raw_n // 3], axis=-1)
        seg_on_grey = np.clip(raw_bg.astype(np.int16) + seg_s.astype(np.int16), 0, 255).astype(np.uint8)

        tiff.imwrite(os.path.join(save_dir, f"{base_name}_{ts}_panel_raw.tif"),    add_scale_bar(composite,   vx, scale_bar))
        tiff.imwrite(os.path.join(save_dir, f"{base_name}_{ts}_panel_seg.tif"),    add_scale_bar(seg_on_grey, vx, scale_bar))
        tiff.imwrite(os.path.join(save_dir, f"{base_name}_{ts}_panel_merged.tif"), add_scale_bar(merged,      vx, scale_bar))

        self._log_append(f"Saved to: {save_dir}")
        self._log_append(f"CSV / Labels / Mask / 3 panels written.")
        self._log_append(f"Channel: {self._channel.value()}  Thr: {self._thr.value()}  MinVox: {self._min_vox.value()}")
        self._log_append(f"Length: {self._min_len.value()}-{self._max_len.value()} um  VX: {vx:.6f}  VZ: {vz:.6f}")
