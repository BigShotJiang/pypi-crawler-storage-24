# =============================================================================
# _segmentation.py
# Pure pipeline logic — no napari / viewer dependencies
# Called by the widget with parameters from the GUI
# =============================================================================

import numpy as np
import pandas as pd
from scipy.ndimage import label as ndi_label
from skimage.filters import gaussian
from skimage.morphology import binary_opening, ball
from skimage.measure import regionprops


# =============================================================================
# HELPER — Oriented bounding box length (SVD method)
# Matches Arivis "Long Side, 3D Oriented Bounds"
# =============================================================================
def oriented_length_um(coords_zyx: np.ndarray, voxel_size_zyx: np.ndarray) -> float:
    pts = coords_zyx.astype(float) * voxel_size_zyx[None, :]
    if pts.shape[0] < 3:
        mins = pts.min(axis=0)
        maxs = pts.max(axis=0)
        return float(np.sort(maxs - mins)[::-1][0])
    centered = pts - pts.mean(axis=0)
    _, _, vh = np.linalg.svd(centered, full_matrices=False)
    rot = centered @ vh.T
    lengths = np.sort(rot.max(0) - rot.min(0))[::-1]
    return float(lengths[0])


# =============================================================================
# HELPER — Add scale bar to RGB image (white bar, bottom-right corner)
# =============================================================================
def add_scale_bar(img_rgb: np.ndarray, vx_um: float, scale_bar_um: float) -> np.ndarray:
    out = img_rgb.copy()
    H, W = out.shape[:2]
    bar_px = int(scale_bar_um / vx_um)
    bar_h = max(4, int(H * 0.008))
    margin = max(15, int(W * 0.02))
    x1 = W - margin - bar_px
    x2 = W - margin
    y1 = H - margin - bar_h
    y2 = H - margin
    out[y1:y2, x1:x2] = [255, 255, 255]
    return out


# =============================================================================
# HELPER — Extract cilia channel from multi-dim array
# =============================================================================
def extract_channel(data: np.ndarray, channel: int) -> np.ndarray:
    if data.ndim == 3:
        return data.astype(np.float32)
    elif data.ndim == 4 and data.shape[1] <= data.shape[0]:
        return data[:, channel, :, :].astype(np.float32)   # (Z, C, Y, X)
    elif data.ndim == 4:
        return data[channel, :, :, :].astype(np.float32)   # (C, Z, Y, X)
    elif data.ndim == 5:
        return data[0, channel, :, :, :].astype(np.float32)
    else:
        raise ValueError(f"Unexpected data shape: {data.shape}")


# =============================================================================
# MAIN PIPELINE
# Returns: lbl_final, df_results, rgb_overlay, img, diagnostics_str
# =============================================================================
def run_segmentation(
    data: np.ndarray,
    channel: int       = 1,
    sigma: float       = 1.0,
    thr_percentile: float = 99.7,
    opening_radius: int   = 1,
    min_voxels: int    = 150,
    max_voxels: int    = 2_000_000,
    exclude_border: bool  = True,
    min_length_um: float  = 0.992,
    max_length_um: float  = 4.865,
    vx: float = 0.0986479222774505,
    vy: float = 0.0986479222774505,
    vz: float = 0.239999994635582,
):
    voxel_size_zyx = np.array([vz, vy, vx])
    voxel_vol = vx * vy * vz
    log = []

    # ── Extract channel ──────────────────────────────────────
    img = extract_channel(data, channel)
    Z, Y, X = img.shape
    log.append(f"Channel {channel} shape: {img.shape}  range: {img.min():.0f}–{img.max():.0f}")

    # ── Diagnostics ──────────────────────────────────────────
    nz = img[img > 0]
    log.append(f"\n── Signal diagnostics ──")
    log.append(f"  Non-zero voxels : {int((img > 0).sum()):,}")
    log.append(f"  p99.7 : {np.percentile(nz, 99.7):.1f}  |  max: {img.max():.1f}")

    # ── Smooth + threshold ───────────────────────────────────
    log.append("\nSegmenting...")
    img_s = gaussian(img, sigma=sigma, preserve_range=True)
    flat = img_s[img_s > 0]
    if flat.size == 0:
        raise RuntimeError("Image looks empty — check Cilia Channel index")

    thr = np.percentile(flat, thr_percentile)
    mask = img_s > thr
    log.append(f"Threshold p{thr_percentile} = {thr:.2f}  |  mask voxels: {int(mask.sum())}")

    if opening_radius > 0:
        mask = binary_opening(mask, footprint=ball(opening_radius))

    # ── Connected components ─────────────────────────────────
    lbl, n = ndi_label(mask)
    log.append(f"Initial objects: {n}")
    if n == 0:
        raise RuntimeError("No objects found — lower Threshold % or Min Voxels")

    # ── Voxel size filter ────────────────────────────────────
    sizes = np.bincount(lbl.ravel())
    sizes[0] = 0
    keep = (sizes >= min_voxels) & (sizes <= max_voxels)
    lbl = np.where(keep[lbl], lbl, 0).astype(np.int32)
    uniq = np.unique(lbl)[1:]
    lbl_compact = np.zeros_like(lbl, dtype=np.int32)
    for new_id, old_id in enumerate(uniq, start=1):
        lbl_compact[lbl == old_id] = new_id
    log.append(f"After voxel size filter: {len(uniq)}")

    # ── Border exclusion ─────────────────────────────────────
    if exclude_border:
        keep_labels = []
        for rp in regionprops(lbl_compact):
            minz, miny, minx, maxz, maxy, maxx = rp.bbox
            if not (minz == 0 or miny == 0 or minx == 0 or
                    maxz == Z or maxy == Y or maxx == X):
                keep_labels.append(rp.label)
        lbl_border = np.zeros_like(lbl_compact, dtype=np.int32)
        for new_id, old_id in enumerate(keep_labels, start=1):
            lbl_border[lbl_compact == old_id] = new_id
        log.append(f"Border removed: {len(uniq) - len(keep_labels)}")
    else:
        lbl_border = lbl_compact

    # ── Length filter ────────────────────────────────────────
    keep_length = []
    for rp in regionprops(lbl_border, intensity_image=img.astype(np.float32)):
        ol = oriented_length_um(rp.coords, voxel_size_zyx)
        maj = float(rp.major_axis_length) * vx
        L = max(ol, maj)
        if min_length_um <= L <= max_length_um:
            keep_length.append(rp.label)

    lbl_final = np.zeros_like(lbl_border, dtype=np.int32)
    for new_id, old_id in enumerate(keep_length, start=1):
        lbl_final[lbl_border == old_id] = new_id

    n_final = len(np.unique(lbl_final)) - 1
    log.append(f"After length filter ({min_length_um}–{max_length_um} µm): {n_final} cilia")
    log.append(f"✅ Final cilia count: {n_final}")

    # ── Measure ──────────────────────────────────────────────
    log.append("\nMeasuring...")
    rows = []
    for rp in regionprops(lbl_final, intensity_image=img.astype(np.float32)):
        ol = oriented_length_um(rp.coords, voxel_size_zyx)
        maj = float(rp.major_axis_length) * vx
        rows.append({
            "label"              : int(rp.label),
            "voxel_count"        : int(rp.area),
            "volume_um3"         : round(float(rp.area) * voxel_vol, 4),
            "length_um"          : round(max(ol, maj), 4),
            "oriented_length_um" : round(ol, 4),
            "major_axis_um"      : round(maj, 4),
            "mean_intensity"     : round(float(rp.mean_intensity), 2),
            "max_intensity"      : round(float(rp.max_intensity), 2),
            "centroid_z"         : round(rp.centroid[0], 2),
            "centroid_y"         : round(rp.centroid[1], 2),
            "centroid_x"         : round(rp.centroid[2], 2),
        })

    df_results = pd.DataFrame(rows)
    if not df_results.empty:
        log.append(f"\n📊 Summary ({n_final} cilia):")
        log.append(df_results[["length_um", "volume_um3", "mean_intensity"]].describe().round(3).to_string())

    # ── Colour overlay ───────────────────────────────────────
    np.random.seed(42)
    n_labels = int(lbl_final.max())
    colors = np.zeros((n_labels + 1, 3), dtype=np.uint8)
    for i in range(1, n_labels + 1):
        ch = i % 3
        colors[i, ch]          = 255
        colors[i, (ch+1) % 3]  = np.random.randint(0, 40)
        colors[i, (ch+2) % 3]  = np.random.randint(0, 40)
    rgb_overlay = colors[lbl_final]

    diagnostics = "\n".join(log)
    return lbl_final, df_results, rgb_overlay, img, diagnostics
