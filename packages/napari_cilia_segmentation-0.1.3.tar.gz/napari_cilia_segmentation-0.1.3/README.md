# Cilia Segmentation — napari plugin

Segments ARL13B (647 nm) cilia from retinal organoid OME-TIFF files.
Matches Arivis "Long Side, 3D Oriented Bounds" length measurement.

## Install

```bash
cd cilia_seg_plugin
pip install -e .
```

## Use

1. Open napari
2. Load your OME-TIFF file (File → Open)
3. Go to **Plugins → Cilia Segmentation**
4. Set your parameters in the panel (voxel sizes, threshold, filters)
5. Press **▶ Run Segmentation**
6. Press **💾 Save Results** to write CSV + TIFs + panels

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| Cilia channel | 1 | 0=ARR3_488, 1=ARL13B_647, 2=DAPI |
| VX / VY (µm) | 0.0986 | Lateral pixel size from Arivis |
| VZ (µm) | 0.240 | Axial step size from Arivis |
| Threshold % | 99.7 | ↑ raise if noisy, ↓ lower if missing cilia |
| Gaussian sigma | 1.0 | Smoothing before threshold |
| Opening radius | 1 | Morphological opening, 0 to disable |
| Min voxels | 150 | Lower for small cilia or large pixels |
| Exclude border | True | Remove objects touching volume edge |
| Min length µm | 0.992 | Matches Arivis lower bound |
| Max length µm | 4.865 | Matches Arivis upper bound |
| Scale bar µm | 20 | For saved panel images |

## Outputs (saved to Save directory)

| File | Contents |
|---|---|
| `*_YYYYMMDD_HHMMSS.csv` | Per-cilium: length, volume, intensity, centroid |
| `*_labels.tif` | Integer label map (3D) |
| `*_mask.tif` | Binary mask (3D) |
| `*_panel_raw.tif` | ARL13B (red) + DAPI (blue), best Z |
| `*_panel_seg.tif` | Colour overlay on dimmed grey background |
| `*_panel_merged.tif` | Raw + overlay combined |

## Tuning guide

- **Too much noise** → raise Threshold % (e.g. 99.8, 99.9)
- **Missing cilia** → lower Threshold % (e.g. 99.5, 99.3)
- **Small blobs remain** → raise Min voxels (e.g. 300, 500)
- **Missing small cilia** → lower Min voxels (e.g. 80, 50)
