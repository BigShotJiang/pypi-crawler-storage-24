# ----------------------------------------------------------------------------------------
#   cal_docs_server
#   ---------------
#
#   Entry point. Checks dependencies and starts the asyncio process and launches
#   main.py
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#
#   bena
#
#   History
#   -------
#
#   Mar 2024 - Created
#   Dec 2025 - New version 2.
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Check python and dependencies
# ----------------------------------------------------------------------------------------

import sys

if sys.version_info < (3, 12):
    print("Requires python 3.12 or greater", file=sys.stderr)
    exit(1)

try:
    import asyncio
    import json5
    import yaml

    _ = (json5, yaml)
except ImportError:
    print(
        "Requires Python packages `asyncio`, `pyyaml` and `json5`\n"
        "Run:\n  python3 -m pip install -U asyncio pyyaml json5",
        file=sys.stderr,
    )
    exit(1)

# ----------------------------------------------------------------------------------------
#   Entry
# ----------------------------------------------------------------------------------------

import asyncio
from . import main

result: int = 1
try:
    result = asyncio.run(main.main(sys.argv[1:]))
except KeyboardInterrupt:
    # Avoids a messy exception dump when ctrl-c pressed
    print()
    print("---- Manually Terminated ----")
    print("")

exit(result)
