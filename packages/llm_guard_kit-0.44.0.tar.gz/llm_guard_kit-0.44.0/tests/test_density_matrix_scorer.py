# tests/test_density_matrix_scorer.py
import numpy as np
import pytest
from llm_guard.density_matrix_scorer import PatternGraph, build_pattern_graph

MINIMAL_STEPS = [
    {"thought": "search for answer", "action_type": "Search",
     "action_arg": "who invented telephone", "observation": "Alexander Graham Bell invented the telephone in 1876"},
    {"thought": "found the answer", "action_type": "Finish",
     "action_arg": "Alexander Graham Bell", "observation": ""},
]

def test_pattern_graph_has_nodes():
    g = build_pattern_graph(MINIMAL_STEPS, embedder=None)
    assert len(g.nodes) > 0

def test_pattern_graph_has_sequential_edges():
    g = build_pattern_graph(MINIMAL_STEPS, embedder=None)
    assert len(g.edges) > 0

def test_spectral_gap_non_negative():
    g = build_pattern_graph(MINIMAL_STEPS, embedder=None)
    assert g.spectral_gap() >= 0.0

def test_spectral_gap_single_node_is_zero():
    g = PatternGraph(nodes=[{"id": "t0", "text": "hi"}], edges=[])
    assert g.spectral_gap() == 0.0

def test_pagerank_sums_to_one():
    g = build_pattern_graph(MINIMAL_STEPS, embedder=None)
    pr = g.pagerank()
    assert abs(pr.sum() - 1.0) < 1e-6

def test_adjacency_symmetric():
    g = build_pattern_graph(MINIMAL_STEPS, embedder=None)
    A = g.adjacency()
    np.testing.assert_allclose(A, A.T, atol=1e-10)
