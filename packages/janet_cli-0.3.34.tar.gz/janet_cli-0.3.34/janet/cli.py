"""Main CLI application using Typer."""

import sys
import json
import typer
from typing import Optional, List
from typing_extensions import Annotated

from janet import __version__
from janet.config.manager import ConfigManager
from janet.utils.console import console, print_success, print_error, print_info
from janet.utils.errors import JanetCLIError

# Initialize Typer app
app = typer.Typer(
    name="janet",
    help="Janet AI CLI - Sync tickets to local markdown files",
    add_completion=False,
)

# Sub-commands
auth_app = typer.Typer(help="Authentication commands")
org_app = typer.Typer(help="Organization management")
project_app = typer.Typer(help="Project management")
config_app = typer.Typer(help="Configuration management")
ticket_app = typer.Typer(help="Ticket management")
child_task_app = typer.Typer(help="Child task management")
sub_task_app = typer.Typer(help="Sub-task management (sub-tasks within child tasks)")
comment_app = typer.Typer(help="Comment management")
sprint_app = typer.Typer(help="Sprint management")
position_app = typer.Typer(help="Ticket position/ordering within a status column")

app.add_typer(auth_app, name="auth", rich_help_panel="Management")
app.add_typer(org_app, name="org", rich_help_panel="Management")
app.add_typer(project_app, name="project", rich_help_panel="Management")
app.add_typer(config_app, name="config", rich_help_panel="Management")
app.add_typer(ticket_app, name="ticket", rich_help_panel="Management")
app.add_typer(sprint_app, name="sprint", rich_help_panel="Management")
ticket_app.add_typer(child_task_app, name="child-task")
ticket_app.add_typer(sub_task_app, name="sub-task")
ticket_app.add_typer(comment_app, name="comment")
ticket_app.add_typer(position_app, name="position")

# Initialize config manager
config_manager = ConfigManager()


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"Janet CLI v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool, typer.Option("--version", "-v", callback=version_callback, is_eager=True)
    ] = False,
) -> None:
    """Janet AI CLI - Sync tickets to local markdown files."""
    pass


def _resolve_assignees(
    assignees: List[str], project_id: str, config_mgr: ConfigManager
) -> List[str]:
    """Resolve assignee names/emails to project member emails.

    Matches each value against project members by:
    0. "me" / "myself" → authenticated user's email
    1. Exact email (case-insensitive)
    2. Exact full name (case-insensitive)
    3. First name only (case-insensitive)
    4. Partial / substring name match

    In non-interactive mode (AI agents), ambiguous matches list all options
    and exit with an error so the agent can retry with the correct value.
    """
    from janet.api.projects import ProjectAPI

    try:
        project_api = ProjectAPI(config_mgr)
        members = project_api.list_project_members(project_id)
    except Exception:
        return assignees  # fall back to raw values if fetch fails

    active_members = [m for m in members if m.get("status") == "active"]

    # Get authenticated user's email for "me" resolution
    config = config_mgr.get()
    current_user_email = config.auth.user_email if config.auth else None

    resolved: List[str] = []
    for raw in assignees:
        raw_lower = raw.strip().lower()

        # 0. "me" / "myself" → current authenticated user
        if raw_lower in ("me", "myself"):
            if not current_user_email:
                # Try fetching from user profile API
                try:
                    from janet.api.client import APIClient
                    client = APIClient(config_mgr)
                    profile = client.get("/api/v1/user/profile", include_org=True)
                    current_user_email = profile.get("user", {}).get("email")
                except Exception:
                    pass
            if current_user_email:
                resolved.append(current_user_email)
                continue
            else:
                print_error("Cannot resolve 'me' — not authenticated. Run 'janet login' first.")
                raise typer.Exit(1)

        # 1. Exact email match (case-insensitive)
        email_match = next(
            (m for m in active_members if m.get("userEmail", "").lower() == raw_lower),
            None,
        )
        if email_match:
            resolved.append(email_match["userEmail"])
            continue

        # 2. Full name match (case-insensitive)
        name_matches = [
            m
            for m in active_members
            if m.get("fullName") and raw_lower == m["fullName"].strip().lower()
        ]
        if len(name_matches) == 1:
            resolved.append(name_matches[0]["userEmail"])
            continue

        # 3. First name only match (case-insensitive)
        first_name_matches = [
            m
            for m in active_members
            if m.get("fullName") and raw_lower == m["fullName"].strip().lower().split()[0]
        ]
        if len(first_name_matches) == 1:
            resolved.append(first_name_matches[0]["userEmail"])
            continue

        # 4. Partial / substring name match
        partial_matches = [
            m
            for m in active_members
            if m.get("fullName") and raw_lower in m["fullName"].strip().lower()
        ]
        if len(partial_matches) == 1:
            resolved.append(partial_matches[0]["userEmail"])
            continue

        if len(partial_matches) > 1 or len(name_matches) > 1 or len(first_name_matches) > 1:
            # Combine all matches, deduplicate
            all_matches = {m["userEmail"]: m for m in (partial_matches or name_matches or first_name_matches)}
            matches_list = list(all_matches.values())

            # Check for exact full-name match among them
            exact = [m for m in matches_list if raw_lower == m["fullName"].strip().lower()]
            if len(exact) == 1:
                resolved.append(exact[0]["userEmail"])
                print_info(f"Resolved '{raw}' → {exact[0].get('fullName')} ({exact[0]['userEmail']})")
                continue

            if sys.stdin.isatty():
                from InquirerPy import inquirer

                choices = [
                    {
                        "name": f"{m.get('fullName', 'Unknown')} ({m['userEmail']})",
                        "value": m["userEmail"],
                    }
                    for m in matches_list
                ]
                selected = inquirer.select(
                    message=f"Multiple members match '{raw}':",
                    choices=choices,
                ).execute()
                resolved.append(selected)
                continue

            # Non-interactive (AI agents): list all matches and error so agent can retry
            names = ", ".join(
                f"{m.get('fullName', 'Unknown')} ({m['userEmail']})" for m in matches_list
            )
            print_error(
                f"Ambiguous assignee '{raw}' matched multiple members: {names}. "
                f"Please specify the exact full name or email."
            )
            raise typer.Exit(1)

        # No match — list available members so AI agents can retry
        member_list = ", ".join(
            f"{m.get('fullName', 'Unknown')} ({m['userEmail']})" for m in active_members
        )
        print_error(
            f"No project member found matching '{raw}'. "
            f"Available members: {member_list}"
        )
        raise typer.Exit(1)

    return resolved


def _resolve_status(
    status: Optional[str], project_id: str, config_mgr: ConfigManager
) -> str:
    """Resolve status for ticket/child-task creation.

    - If status is provided, validates it against the project's valid statuses.
    - If not provided, prompts interactively or uses the first status for non-interactive.
    Raises typer.Exit(1) on failure.
    """
    from janet.api.projects import ProjectAPI

    try:
        project_api = ProjectAPI(config_mgr)
        columns = project_api.get_project_columns(project_id)
        valid_statuses = [c.get("status_value", "") for c in columns if c.get("status_value")]
    except Exception:
        # If we can't fetch statuses, fall back
        if status:
            return status
        print_error("Could not fetch project statuses. Please provide --status explicitly.")
        raise typer.Exit(1)

    if not valid_statuses:
        if status:
            return status
        print_error("No statuses configured for this project.")
        raise typer.Exit(1)

    if status:
        # Validate provided status (case-insensitive match)
        for vs in valid_statuses:
            if vs.lower() == status.lower():
                return vs  # Return the canonical casing
        status_list = ", ".join(valid_statuses)
        print_error(
            f"Invalid status '{status}'. "
            f"Valid statuses: {status_list}"
        )
        raise typer.Exit(1)

    # No status provided — prompt or default
    if sys.stdin.isatty():
        from InquirerPy import inquirer

        console.print("\n[bold]Select a status:[/bold]\n")
        selected = inquirer.select(
            message="Status:",
            choices=valid_statuses,
        ).execute()
        return selected
    else:
        # Non-interactive (AI agents): use first status and inform
        first = valid_statuses[0]
        print_info(f"No --status provided, using '{first}'. Valid statuses: {', '.join(valid_statuses)}")
        return first


def _resolve_ticket_key(ticket_key: str, config_mgr: ConfigManager) -> dict:
    """Resolve a ticket key like PROJ-123 to its IDs.

    Returns dict with: project_id, project_key, ticket_id, ticket_identifier.
    Raises typer.Exit(1) on failure.
    """
    import re
    from janet.api.tickets import TicketAPI
    from janet.api.projects import ProjectAPI

    # Check if it looks like a UUID
    if "-" in ticket_key and len(ticket_key) == 36:
        return {"ticket_id": ticket_key, "project_id": None, "project_key": None, "ticket_identifier": None}

    # Parse PROJ-123 format
    parts = ticket_key.upper().rsplit("-", 1)
    if len(parts) != 2 or not parts[1].isdigit():
        print_error(f"Invalid ticket key format: {ticket_key}. Expected format: PROJ-123")
        raise typer.Exit(1)

    project_key, ticket_num = parts

    # Find project
    project_api = ProjectAPI(config_mgr)
    projects = project_api.list_projects()

    project_id = None
    for p in projects:
        if p.get("project_identifier", "").upper() == project_key:
            project_id = p["id"]
            break

    if not project_id:
        print_error(f"Project '{project_key}' not found")
        raise typer.Exit(1)

    # Find ticket
    ticket_api = TicketAPI(config_mgr)
    sync_result = ticket_api.sync_all_tickets(project_id)
    tickets = sync_result.get("tickets", [])

    ticket_id = None
    for t in tickets:
        if str(t.get("ticket_identifier")) == ticket_num:
            ticket_id = t["id"]
            break

    if not ticket_id:
        print_error(f"Ticket '{ticket_key}' not found")
        raise typer.Exit(1)

    return {
        "project_id": project_id,
        "project_key": project_key,
        "ticket_id": ticket_id,
        "ticket_identifier": ticket_num,
    }


def _resolve_ticket_keys_batch(ticket_keys: list, config_mgr: ConfigManager) -> list:
    """Resolve multiple ticket keys efficiently (one API call for all).

    All tickets must be from the same project.
    Returns list of dicts with: project_id, project_key, ticket_id, ticket_identifier.
    """
    import re
    from janet.api.tickets import TicketAPI
    from janet.api.projects import ProjectAPI

    if not ticket_keys:
        return []

    # Parse all keys — extract project key from the first one
    parsed = []
    for key in ticket_keys:
        parts = key.upper().rsplit("-", 1)
        if len(parts) != 2 or not parts[1].isdigit():
            print_error(f"Invalid ticket key format: {key}. Expected format: PROJ-123")
            raise typer.Exit(1)
        parsed.append((parts[0], parts[1]))

    project_key = parsed[0][0]

    # Resolve project once
    project_api = ProjectAPI(config_mgr)
    projects = project_api.list_projects()
    project_id = None
    for p in projects:
        if p.get("project_identifier", "").upper() == project_key:
            project_id = p["id"]
            break
    if not project_id:
        print_error(f"Project '{project_key}' not found")
        raise typer.Exit(1)

    # Fetch all tickets once
    ticket_api = TicketAPI(config_mgr)
    sync_result = ticket_api.sync_all_tickets(project_id)
    all_tickets = sync_result.get("tickets", [])
    ticket_map = {str(t.get("ticket_identifier")): t["id"] for t in all_tickets}

    # Look up each key
    results = []
    for pkey, num in parsed:
        tid = ticket_map.get(num)
        if not tid:
            print_error(f"Ticket '{pkey}-{num}' not found")
            raise typer.Exit(1)
        results.append({
            "project_id": project_id,
            "project_key": project_key,
            "ticket_id": tid,
            "ticket_identifier": num,
        })

    return results


def _resolve_child_task_key(child_task_key: str, config_mgr: ConfigManager) -> dict:
    """Resolve a child task key like PROJ-123A to its IDs.

    Returns dict with: project_id, project_key, ticket_id, ticket_identifier,
    child_task_id, full_identifier.
    Raises typer.Exit(1) on failure.
    """
    import re
    from janet.api.child_tasks import ChildTaskAPI

    # Parse PROJ-123A: split on last hyphen, then separate digits from letters
    parts = child_task_key.upper().rsplit("-", 1)
    if len(parts) != 2:
        print_error(f"Invalid child task key format: {child_task_key}. Expected format: PROJ-123A")
        raise typer.Exit(1)

    project_key = parts[0]
    remainder = parts[1]  # e.g., "123A" or "123AA"

    match = re.match(r"^(\d+)([A-Z]+)$", remainder)
    if not match:
        print_error(f"Invalid child task key format: {child_task_key}. Expected format: PROJ-123A")
        raise typer.Exit(1)

    ticket_num = match.group(1)
    child_suffix = match.group(2)

    # Resolve parent ticket
    parent_key = f"{project_key}-{ticket_num}"
    ticket_info = _resolve_ticket_key(parent_key, config_mgr)

    # Fetch child tasks and match
    child_task_api = ChildTaskAPI(config_mgr)
    child_tasks = child_task_api.list_child_tasks(ticket_info["ticket_id"])

    full_id = f"{project_key}-{ticket_num}{child_suffix}"
    child_task_id = None
    for ct in child_tasks:
        if ct.get("fullIdentifier", "").upper() == full_id:
            child_task_id = ct["id"]
            break

    if not child_task_id:
        if child_tasks:
            available = ", ".join(ct.get("fullIdentifier", "?") for ct in child_tasks)
            print_error(f"Child task '{full_id}' not found. Available: {available}")
        else:
            print_error(f"No child tasks found for ticket {parent_key}")
        raise typer.Exit(1)

    return {
        **ticket_info,
        "child_task_id": child_task_id,
        "full_identifier": full_id,
    }


def _resolve_sub_task_key(sub_task_key: str, config_mgr: ConfigManager) -> dict:
    """Resolve a sub-task key like PROJ-123A-1 to its IDs.

    Returns dict with: project_id, project_key, ticket_id, ticket_identifier,
    child_task_id, full_identifier, sub_task_id, sub_task_full_identifier.
    """
    import re
    from janet.api.child_tasks import ChildTaskAPI

    # Parse PROJ-123A-1: split into parts
    parts = sub_task_key.upper().split("-")
    if len(parts) < 3:
        print_error(f"Invalid sub-task key format: {sub_task_key}. Expected format: PROJ-123A-1")
        raise typer.Exit(1)

    # Last part is the sub-task number
    sub_num = parts[-1]
    if not sub_num.isdigit():
        print_error(f"Invalid sub-task key format: {sub_task_key}. Expected format: PROJ-123A-1")
        raise typer.Exit(1)

    # Everything except the last part is the child task key
    child_task_key_str = "-".join(parts[:-1])
    child_info = _resolve_child_task_key(child_task_key_str, config_mgr)

    # Fetch sub-tasks and match
    child_task_api = ChildTaskAPI(config_mgr)
    sub_tasks = child_task_api.list_sub_tasks(child_info["child_task_id"])

    full_id = f"{child_info['full_identifier']}-{sub_num}"
    sub_task_id = None
    for st in sub_tasks:
        if st.get("fullIdentifier", "").upper() == full_id:
            sub_task_id = st["id"]
            break

    if not sub_task_id:
        if sub_tasks:
            available = ", ".join(st.get("fullIdentifier", "?") for st in sub_tasks)
            print_error(f"Sub-task '{full_id}' not found. Available: {available}")
        else:
            print_error(f"No sub-tasks found for child task {child_info['full_identifier']}")
        raise typer.Exit(1)

    return {
        **child_info,
        "sub_task_id": sub_task_id,
        "sub_task_full_identifier": full_id,
    }


# =============================================================================
# Authentication Commands
# =============================================================================


@app.command(name="login", rich_help_panel="Authentication")
def login() -> None:
    """Authenticate with Janet AI and select organization."""
    try:
        from janet.auth.oauth_flow import OAuthFlow
        from janet.api.organizations import OrganizationAPI
        from InquirerPy import inquirer

        print_info("Starting authentication flow...")

        # Start OAuth flow
        oauth_flow = OAuthFlow(config_manager)
        oauth_flow.start_login()

        # Fetch available organizations
        print_info("Fetching your organizations...")
        org_api = OrganizationAPI(config_manager)
        organizations = org_api.list_organizations()

        if not organizations:
            print_error("No organizations found for your account")
            raise typer.Exit(1)

        # Select organization
        if len(organizations) == 1:
            # Auto-select if only one org
            selected_org = organizations[0]
            print_success(f"Auto-selected organization: {selected_org['name']}")
        else:
            # Show interactive selection
            console.print("\n[bold]Select an organization:[/bold]\n")

            org_choices = []
            for org in organizations:
                role = org.get("userRole", "member")
                label = f"{org['name']} ({role})"
                org_choices.append({"name": label, "value": org})

            selected_org = inquirer.select(
                message="Select organization:",
                choices=org_choices,
            ).execute()

        # Save selected organization
        from janet.config.models import OrganizationInfo

        config = config_manager.get()
        config.selected_organization = OrganizationInfo(
            id=selected_org["id"], name=selected_org["name"], uuid=selected_org["uuid"]
        )
        config_manager.update(config)

        print_success(f"Selected organization: {selected_org['name']}")
        console.print("\n[green]✓ Authentication complete![/green]")
        console.print("Run [cyan]janet sync[/cyan] to sync tickets and watch for real-time updates.")

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update", rich_help_panel="Utilities")
def update(
    test_pypi: bool = typer.Option(False, "--test", help="Update from Test PyPI (for development)")
) -> None:
    """Update Janet CLI to the latest version."""
    import subprocess
    import httpx
    from janet import __version__

    console.print("[cyan]Checking for updates...[/cyan]")

    try:
        # Determine PyPI URL based on flag
        if test_pypi:
            pypi_url = "https://test.pypi.org/pypi/janet-cli/json"
            index_url = "https://test.pypi.org/simple/"
        else:
            pypi_url = "https://pypi.org/pypi/janet-cli/json"
            index_url = None

        # Fetch latest version from PyPI
        try:
            response = httpx.get(pypi_url, timeout=10)
            response.raise_for_status()
            latest_version = response.json()["info"]["version"]
        except Exception as e:
            print_error(f"Failed to check for updates: {e}")
            raise typer.Exit(1)

        current_version = __version__

        console.print(f"[dim]Current version: {current_version}[/dim]")
        console.print(f"[dim]Latest version:  {latest_version}[/dim]")

        # Compare versions
        if current_version == latest_version:
            console.print("[green]Janet CLI is already up to date.[/green]")
            return

        # Build pip command
        pip_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "janet-cli"]
        if index_url:
            pip_cmd.extend(["--index-url", index_url])

        console.print(f"[cyan]Updating to version {latest_version}...[/cyan]")

        result = subprocess.run(pip_cmd, capture_output=True, text=True)

        if result.returncode == 0:
            console.print(f"[green]✓ Janet CLI updated to {latest_version}![/green]")
            console.print("[dim]Restart your terminal to use the new version.[/dim]")
        else:
            print_error(f"Update failed: {result.stderr}")
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Update failed: {e}")
        raise typer.Exit(1)


@app.command(name="logout", rich_help_panel="Authentication")
def logout() -> None:
    """Clear stored credentials."""
    try:
        config = config_manager.get()
        if not config_manager.is_authenticated():
            print_info("Not currently logged in")
            return

        # Clear authentication data
        config.auth.access_token = None
        config.auth.refresh_token = None
        config.auth.expires_at = None
        config.auth.user_id = None
        config.auth.user_email = None
        config.selected_organization = None

        config_manager.update(config)
        print_success("Logged out successfully")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@auth_app.command(name="status")
def auth_status() -> None:
    """Show current authentication status."""
    try:
        config = config_manager.get()

        if not config_manager.is_authenticated():
            console.print("[yellow]Not authenticated[/yellow]")
            console.print("Run 'janet login' to authenticate")
            return

        console.print("[bold green]Authenticated[/bold green]")
        if config.auth.user_email:
            console.print(f"User: [cyan]{config.auth.user_email}[/cyan]")
        if config.selected_organization:
            console.print(f"Organization: [cyan]{config.selected_organization.name}[/cyan]")
            console.print(f"Organization ID: [dim]{config.selected_organization.id}[/dim]")

        if config.auth.expires_at:
            console.print(f"Token expires: [dim]{config.auth.expires_at}[/dim]")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Organization Commands
# =============================================================================


@org_app.command(name="list")
def org_list() -> None:
    """List available organizations."""
    try:
        from janet.api.organizations import OrganizationAPI
        from rich.table import Table

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        print_info("Fetching organizations...")
        org_api = OrganizationAPI(config_manager)
        organizations = org_api.list_organizations()

        if not organizations:
            print_info("No organizations found")
            return

        # Display as table
        table = Table(title="Organizations", show_header=True, header_style="bold cyan")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="bold")
        table.add_column("Role")

        for org in organizations:
            table.add_row(
                org.get("id", ""), org.get("name", ""), org.get("userRole", "member")
            )

        console.print(table)
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@org_app.command(name="select")
def org_select(org_id: str) -> None:
    """
    Switch active organization.

    Args:
        org_id: Organization ID to select
    """
    try:
        from janet.api.organizations import OrganizationAPI
        from janet.config.models import OrganizationInfo

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        print_info(f"Selecting organization: {org_id}")
        org_api = OrganizationAPI(config_manager)

        # Fetch organization details
        org_data = org_api.get_organization(org_id)

        # Update config
        config = config_manager.get()
        old_org_id = config.selected_organization.id if config.selected_organization else None

        config.selected_organization = OrganizationInfo(
            id=org_data["id"], name=org_data["name"], uuid=org_data.get("uuid", org_id)
        )

        # Clear synced projects when switching orgs (they belong to the old org)
        if old_org_id and old_org_id != org_data["id"]:
            config.sync.synced_projects = []
            config.sync.last_sync_org_id = None
            config.sync.last_sync_total_tickets = 0

            # Regenerate README with new org but empty projects (no statuses until sync)
            from janet.utils.paths import expand_path
            from pathlib import Path

            sync_dir = expand_path(config.sync.root_directory)
            if sync_dir.exists():
                from janet.sync.readme_generator import ReadmeGenerator
                readme_gen = ReadmeGenerator()
                readme_gen.write_readme(
                    sync_dir=sync_dir,
                    org_name=org_data["name"],
                    projects=[],
                    total_tickets=0,
                    project_statuses={},
                )
                print_info(f"README updated for new organization. Run 'janet sync' to sync projects.")

        config_manager.update(config)

        print_success(f"Selected organization: {org_data['name']}")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@org_app.command(name="current")
def org_current() -> None:
    """Show current organization."""
    try:
        config = config_manager.get()

        if not config_manager.has_organization():
            print_info("No organization selected")
            console.print("Run 'janet org list' to see available organizations")
            return

        org = config.selected_organization
        console.print(f"[bold]Current Organization:[/bold]")
        console.print(f"  Name: [cyan]{org.name}[/cyan]")
        console.print(f"  ID: [dim]{org.id}[/dim]")
        console.print(f"  UUID: [dim]{org.uuid}[/dim]")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Project Commands
# =============================================================================


@project_app.command(name="list")
def project_list() -> None:
    """List projects in current organization."""
    try:
        from janet.api.projects import ProjectAPI
        from rich.table import Table

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        print_info("Fetching projects...")
        project_api = ProjectAPI(config_manager)
        projects = project_api.list_projects()

        if not projects:
            print_info("No projects found")
            return

        # Display as table
        table = Table(title="Projects", show_header=True, header_style="bold cyan")
        table.add_column("Key", style="bold")
        table.add_column("Name")
        table.add_column("Tickets", justify="right")
        table.add_column("Role")

        for project in projects:
            table.add_row(
                project.get("project_identifier", ""),
                project.get("project_name", ""),
                str(project.get("ticket_count", 0)),
                project.get("user_role", ""),
            )

        console.print(table)
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Sync Commands
# =============================================================================


@app.command(name="sync", rich_help_panel="Syncing")
def sync(
    directory: Annotated[str, typer.Option("--dir", "-d", help="Sync directory")] = None,
    all_projects: Annotated[bool, typer.Option("--all", help="Sync all projects")] = False,
    no_watch: Annotated[bool, typer.Option("--no-watch", help="Exit after sync instead of watching for updates")] = False,
) -> None:
    """
    Sync tickets to local markdown files and watch for real-time updates.

    Interactive mode: prompts for project selection and directory.
    After syncing, stays connected for real-time updates (Ctrl+C to stop).
    """
    try:
        from janet.sync.sync_engine import SyncEngine
        from janet.api.projects import ProjectAPI
        import os

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        org_name = config_manager.get().selected_organization.name

        # Step 1: Select projects to sync
        console.print(f"\n[bold]Sync tickets for {org_name}[/bold]\n")

        # Fetch projects
        print_info("Fetching projects...")
        project_api = ProjectAPI(config_manager)
        all_project_list = project_api.list_projects()

        if not all_project_list:
            print_error("No projects found")
            raise typer.Exit(1)

        # Filter out projects with no tickets
        available_projects = [p for p in all_project_list if p.get("ticket_count", 0) > 0]

        if not available_projects:
            print_info("No projects with tickets found")
            return

        # Show project selection
        selected_projects = []

        if all_projects:
            # Skip selection, use all projects
            selected_projects = available_projects
            console.print(f"Syncing all {len(selected_projects)} projects")
        else:
            # Interactive project selection with checkboxes
            from InquirerPy import inquirer

            console.print("\n[bold]Select projects to sync:[/bold]")
            console.print("[dim]Use ↑/↓ to move, SPACE to toggle selection, ENTER to confirm[/dim]\n")

            # Build choices with formatted display
            choices = []
            for project in available_projects:
                key = project.get("project_identifier", "")
                name = project.get("project_name", "")
                count = project.get("ticket_count", 0)
                label = f"{key:8s} - {name:30s} ({count} tickets)"
                choices.append({"name": label, "value": project, "enabled": True})

            # Show checkbox multi-select
            import sys
            import os as os_module

            # Temporarily suppress InquirerPy's result output
            selected = inquirer.checkbox(
                message="Select projects:",
                choices=choices,
                validate=lambda result: len(result) > 0 or "Please select at least one project",
                instruction="(SPACE to toggle, ENTER to confirm)",
                amark="✓",
                transformer=lambda result: "",  # Suppress the result display
            ).execute()

            if not selected:
                print_info("No projects selected")
                return

            selected_projects = selected

        # Show selected projects cleanly
        console.print(f"\n[green]✓ Selected {len(selected_projects)} project(s):[/green]")
        for proj in selected_projects:
            key = proj.get("project_identifier", "")
            name = proj.get("project_name", "")
            count = proj.get("ticket_count", 0)
            console.print(f"  • {key} - {name} ({count} tickets)")

        # Step 2: Select sync directory
        if directory:
            sync_dir = directory
        else:
            # Get current directory
            current_dir = os.getcwd()
            from InquirerPy import inquirer

            console.print(f"\n[bold]Where should tickets be synced?[/bold]")
            console.print(f"[dim]Current directory: {current_dir}[/dim]\n")

            # Build directory choices
            dir_choices = [
                {
                    "name": f"Current directory ({current_dir}/janet-tickets)",
                    "value": os.path.join(current_dir, "janet-tickets"),
                },
                {
                    "name": "Home directory (~/janet-tickets)",
                    "value": "~/janet-tickets",
                },
                {
                    "name": "Custom path...",
                    "value": "__custom__",
                },
            ]

            choice = inquirer.select(
                message="Select sync location:",
                choices=dir_choices,
            ).execute()

            if choice == "__custom__":
                sync_dir = inquirer.filepath(
                    message="Enter custom path:",
                    default=current_dir,
                    validate=lambda x: len(x) > 0 or "Path cannot be empty",
                ).execute()
                if not sync_dir:
                    print_info("Sync cancelled")
                    return
            else:
                sync_dir = choice

        # Expand path
        from janet.utils.paths import expand_path
        expanded_dir = expand_path(sync_dir)

        console.print(f"\n[green]✓ Sync directory: {expanded_dir}[/green]")

        # Confirm
        from InquirerPy import inquirer
        confirmed = inquirer.confirm(
            message=f"Sync {len(selected_projects)} project(s) to {expanded_dir}?",
            default=True,
        ).execute()

        if not confirmed:
            print_info("Sync cancelled")
            return

        # Step 3: Start sync
        console.print(f"\n[bold]Starting sync...[/bold]\n")

        # Update config with new directory
        config = config_manager.get()
        config.sync.root_directory = str(expanded_dir)
        config_manager.update(config)

        # Initialize sync engine with new directory
        sync_engine = SyncEngine(config_manager)

        # Sync selected projects
        total_tickets = 0
        for project in selected_projects:
            project_key = project.get("project_identifier", "")
            project_name = project.get("project_name", "")

            synced = sync_engine.sync_project(project["id"], project_key, project_name)
            total_tickets += synced

        # Fetch project statuses (kanban columns) for each project
        project_statuses = {}
        try:
            for project in selected_projects:
                project_id = project.get("id", "")
                project_key = project.get("project_identifier", "")
                if project_id:
                    columns = project_api.get_project_columns(project_id)
                    # Extract status values in order
                    statuses = [col.get("status_value", "") for col in sorted(columns, key=lambda x: x.get("column_order", 0))]
                    project_statuses[project_key] = statuses
        except Exception as e:
            print_info(f"Note: Could not fetch project statuses: {e}")

        # Generate README for AI agents
        from janet.sync.readme_generator import ReadmeGenerator
        readme_gen = ReadmeGenerator()
        readme_path = readme_gen.write_readme(
            sync_dir=expanded_dir,
            org_name=org_name,
            projects=selected_projects,
            total_tickets=total_tickets,
            project_statuses=project_statuses,
        )

        # Save synced projects to config for README regeneration on org change
        from janet.config.models import SyncedProject
        config.sync.synced_projects = [
            SyncedProject(
                id=p.get("id", ""),
                project_identifier=p.get("project_identifier", ""),
                project_name=p.get("project_name", ""),
                ticket_count=p.get("ticket_count", 0),
            )
            for p in selected_projects
        ]
        config.sync.last_sync_org_id = config.selected_organization.id
        config.sync.last_sync_total_tickets = total_tickets
        config_manager.update(config)

        # Show summary
        console.print(f"\n[bold green]✓ Sync complete![/bold green]")
        console.print(f"  Projects: {len(selected_projects)}")
        console.print(f"  Tickets: {total_tickets}")
        console.print(f"\n[cyan]Tickets saved to: {expanded_dir}[/cyan]")
        console.print(f"[dim]README for AI agents: {readme_path}[/dim]")

        # Start watch mode (default behavior, unless --no-watch)
        if not no_watch:
            from janet.sync.sse_watcher import SSEWatcher
            from janet.api.organizations import OrganizationAPI

            console.print(f"\n")

            # Fetch org members for name resolution in SSE updates
            org_members = None
            try:
                org_api = OrganizationAPI(config_manager)
                org_id = config.selected_organization.id
                response = org_api.get(f"/api/v1/organizations/{org_id}/members", include_org=False)
                org_members = response.get("members", [])
            except Exception:
                pass  # Will fall back to emails if members can't be fetched

            # Create SSE watcher
            watcher = SSEWatcher(
                config_manager=config_manager,
                projects=selected_projects,
                org_name=org_name,
                sync_dir=str(expanded_dir),
                org_members=org_members,
                project_statuses=project_statuses,
            )

            # This blocks until Ctrl+C
            watcher.watch()

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Sync failed: {e}")
        raise typer.Exit(1)


# =============================================================================
# Status Command
# =============================================================================


@app.command(name="status", rich_help_panel="Syncing")
def status() -> None:
    """Show overall status (auth, org, last sync)."""
    try:
        config = config_manager.get()

        console.print("[bold]Janet CLI Status[/bold]\n")

        # Authentication status
        if config_manager.is_authenticated():
            console.print("✓ [green]Authenticated[/green]")
            if config.auth.user_email:
                console.print(f"  User: {config.auth.user_email}")
        else:
            console.print("✗ [yellow]Not authenticated[/yellow]")
            console.print("  Run 'janet login' to authenticate\n")
            return

        # Organization status
        if config_manager.has_organization():
            console.print(f"✓ [green]Organization selected: {config.selected_organization.name}[/green]")
        else:
            console.print("✗ [yellow]No organization selected[/yellow]")
            console.print("  Run 'janet org list' to select an organization\n")
            return

        # Sync status
        console.print(f"\n[bold]Sync Directory:[/bold] {config.sync.root_directory}")
        if config.sync.last_sync_times:
            console.print(f"[bold]Last Synced Projects:[/bold] {len(config.sync.last_sync_times)}")
        else:
            console.print("[dim]No projects synced yet[/dim]")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Config Commands
# =============================================================================


@config_app.command(name="show")
def config_show() -> None:
    """Display current configuration."""
    try:
        config = config_manager.get()
        console.print_json(config.model_dump_json(indent=2))
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@config_app.command(name="path")
def config_path() -> None:
    """Show config file location."""
    console.print(f"Config file: [cyan]{config_manager.config_path}[/cyan]")


@config_app.command(name="reset")
def config_reset(
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Reset configuration to defaults."""
    try:
        if not confirm:
            console.print("[yellow]This will reset all configuration to defaults.[/yellow]")
            confirmed = typer.confirm("Are you sure?")
            if not confirmed:
                print_info("Reset cancelled")
                return

        config_manager.reset()
        print_success("Configuration reset to defaults")
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Ticket Commands
# =============================================================================


@ticket_app.command(name="list")
def ticket_list(
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Filter by status column")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    List tickets in a project, optionally filtered by status.

    Shows tickets ordered by their position in the column (same order as the UI).

    Examples:
        janet ticket list -p MAIN
        janet ticket list -p MAIN --status "To Do"
        janet ticket list -p MAIN -s "In Progress" --json
    """
    try:
        from janet.api.tickets import TicketAPI
        from janet.api.projects import ProjectAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve project
        project_api = ProjectAPI(config_manager)
        projects = project_api.list_projects()
        if not projects:
            print_error("No projects found")
            raise typer.Exit(1)

        project_id = None
        project_key = None
        if project:
            for p in projects:
                if p.get("project_identifier", "").upper() == project.upper():
                    project_id = p["id"]
                    project_key = p["project_identifier"]
                    break
                if p.get("id") == project:
                    project_id = p["id"]
                    project_key = p.get("project_identifier", "")
                    break
            if not project_id:
                for p in projects:
                    if p.get("project_name", "").lower() == project.lower():
                        project_id = p["id"]
                        project_key = p.get("project_identifier", "")
                        break
            if not project_id:
                avail = ", ".join(p.get("project_identifier", "?") for p in projects)
                print_error(f"Project '{project}' not found. Available: {avail}")
                raise typer.Exit(1)
        else:
            if len(projects) == 1:
                project_id = projects[0]["id"]
                project_key = projects[0].get("project_identifier", "")
            elif sys.stdin.isatty():
                from InquirerPy import inquirer
                choices = [{"name": f"{p.get('project_identifier', '?')} - {p.get('project_name', '')}", "value": p} for p in projects]
                selected = inquirer.select(message="Select project:", choices=choices).execute()
                project_id = selected["id"]
                project_key = selected.get("project_identifier", "")
            else:
                avail = ", ".join(p.get("project_identifier", "?") for p in projects)
                print_error(f"No --project provided. Available: {avail}")
                raise typer.Exit(1)

        ticket_api = TicketAPI(config_manager)
        status_filter = None
        if status:
            resolved_status = _resolve_status(status, project_id, config_manager)
            status_filter = [resolved_status]
        result = ticket_api.list_tickets(project_id, statuses=status_filter)
        all_tickets = result.get("items", []) if isinstance(result, dict) else result
        if not isinstance(all_tickets, list):
            all_tickets = []

        if status:
            all_tickets.sort(key=lambda t: t.get("position") or "zzz")

        if output_json:
            console.print(json.dumps({"success": True, "tickets": all_tickets, "count": len(all_tickets)}, indent=2))
            return

        if not all_tickets:
            print_info(f"No tickets found{f' in {status}' if status else ''}")
            return

        from rich.table import Table
        table = Table(show_header=True, header_style="bold", show_lines=False, pad_edge=False)
        table.add_column("Key", style="dim")
        table.add_column("Title")
        table.add_column("Status")
        table.add_column("Priority")
        table.add_column("Position", style="dim")

        for t in all_tickets:
            key = t.get("ticket_identifier", "?")
            title = (t.get("title") or "?")[:60]
            t_status = t.get("status") or "?"
            priority = t.get("priority") or "—"
            pos = t.get("position") or "—"
            table.add_row(key, title, t_status, priority, pos)

        header = f"{project_key}"
        if status:
            header += f" / {status}"
        console.print(f"\n[bold]{header}[/bold] ({len(all_tickets)} tickets)\n")
        console.print(table)

    except typer.Exit:
        raise
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@ticket_app.command(name="create")
def ticket_create(
    title: Annotated[str, typer.Argument(help="Ticket title")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key (e.g., PROJ) or ID")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="Ticket description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Status (default: To Do)")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="Priority: Low, Medium, High, Critical")] = None,
    issue_type: Annotated[Optional[str], typer.Option("--type", "-t", help="Type: Task, Bug, Story, Epic")] = None,
    assignee: Annotated[Optional[List[str]], typer.Option("--assignee", "-a", help="Assignee name or email (can repeat)")] = None,
    tag: Annotated[Optional[List[str]], typer.Option("--tag", help="Tag (can repeat)")] = None,
    sprint: Annotated[Optional[str], typer.Option("--sprint", help="Sprint name to add ticket to")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Create a new ticket.

    Examples:
        janet ticket create "Fix login bug" -p PROJ
        janet ticket create "Add feature" -p PROJ -d "Details here" --priority High
        janet ticket create "Title" -p PROJ -a "John Doe"
        janet ticket create "Title" -p PROJ --sprint "Sprint 1"
        echo "Description" | janet ticket create "Title" -p PROJ
    """
    try:
        from janet.api.tickets import TicketAPI
        from janet.api.projects import ProjectAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Get project list
        project_api = ProjectAPI(config_manager)
        projects = project_api.list_projects()

        if not projects:
            print_error("No projects found in organization")
            raise typer.Exit(1)

        # Resolve project
        project_id = None
        project_key = None

        if project:
            # Try to match by key, ID, or name
            project_lower = project.strip().lower()
            for p in projects:
                if p.get("project_identifier", "").upper() == project.upper():
                    project_id = p["id"]
                    project_key = p["project_identifier"]
                    break
                if p.get("id") == project:
                    project_id = p["id"]
                    project_key = p.get("project_identifier", "")
                    break

            # Try name match if key/ID didn't work
            if not project_id:
                name_matches = [
                    p for p in projects
                    if p.get("project_name", "").strip().lower() == project_lower
                ]
                if len(name_matches) == 1:
                    project_id = name_matches[0]["id"]
                    project_key = name_matches[0].get("project_identifier", "")
                elif len(name_matches) > 1:
                    options = ", ".join(
                        f"{p.get('project_identifier', '?')} ({p.get('project_name', '')})"
                        for p in name_matches
                    )
                    print_error(
                        f"Multiple projects match name '{project}': {options}. "
                        f"Please specify the project key instead."
                    )
                    raise typer.Exit(1)

            if not project_id:
                available = ", ".join(
                    f"{p.get('project_identifier', '?')} ({p.get('project_name', '')})"
                    for p in projects
                )
                print_error(
                    f"Project '{project}' not found. "
                    f"Available projects: {available}"
                )
                raise typer.Exit(1)
        else:
            # Interactive project selection
            if not sys.stdin.isatty():
                print_error("--project is required for non-interactive use")
                raise typer.Exit(1)

            from InquirerPy import inquirer

            console.print("\n[bold]Select a project:[/bold]\n")

            choices = []
            for p in projects:
                key = p.get("project_identifier", "")
                name = p.get("project_name", "")
                count = p.get("ticket_count", 0)
                label_text = f"{key:8s} - {name} ({count} tickets)"
                choices.append({"name": label_text, "value": p})

            selected = inquirer.select(
                message="Project:",
                choices=choices,
            ).execute()

            project_id = selected["id"]
            project_key = selected.get("project_identifier", "")

        # Check for piped stdin for description
        final_description = description
        if not sys.stdin.isatty() and not description:
            # Read from stdin
            stdin_content = sys.stdin.read().strip()
            if stdin_content:
                final_description = stdin_content

        # Resolve status against project's valid statuses
        resolved_status = _resolve_status(status, project_id, config_manager)

        # Resolve assignee names to emails
        resolved_assignees = None
        if assignee:
            resolved_assignees = _resolve_assignees(assignee, project_id, config_manager)

        # Create ticket
        ticket_api = TicketAPI(config_manager)
        result = ticket_api.create_ticket(
            project_id=project_id,
            title=title,
            description=final_description,
            status=resolved_status,
            priority=priority,
            issue_type=issue_type,
            assignees=resolved_assignees,
            labels=tag,
        )

        ticket_key_result = result.get("ticket_key", f"{project_key}-{result.get('ticket_identifier', '?')}")
        ticket_id = result.get("ticket_id")

        # Add to sprint if specified
        if sprint and ticket_id:
            try:
                from janet.api.sprints import SprintAPI
                resolved_sprint = _resolve_sprint(sprint, project_id)
                sprint_api = SprintAPI(config_manager)
                sprint_api.add_ticket(ticket_id, resolved_sprint["id"], project_id)
            except Exception as e:
                print_error(f"Ticket created but failed to add to sprint: {e}")

        if output_json:
            output = {
                "success": True,
                "ticket_id": ticket_id,
                "ticket_key": ticket_key_result,
                "title": title,
                "project_key": project_key,
            }
            if sprint:
                output["sprint"] = sprint
            console.print(json.dumps(output, indent=2))
        else:
            msg = f"Created {ticket_key_result}: {title}"
            if sprint:
                msg += f' (in sprint "{sprint}")'
            print_success(msg)

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to create ticket: {e}")
        raise typer.Exit(1)


@ticket_app.command(name="update")
def ticket_update(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123) or ticket ID")],
    title: Annotated[Optional[str], typer.Option("--title", help="New title")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="New description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="New status")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="New priority: Low, Medium, High, Critical")] = None,
    issue_type: Annotated[Optional[str], typer.Option("--type", "-t", help="New type: Task, Bug, Story, Epic")] = None,
    assignee: Annotated[Optional[List[str]], typer.Option("--assignee", "-a", help="New assignee name or email (can repeat, replaces all)")] = None,
    tag: Annotated[Optional[List[str]], typer.Option("--tag", help="New tag (can repeat, replaces all)")] = None,
    due_date: Annotated[Optional[str], typer.Option("--due-date", help="New due date (YYYY-MM-DD)")] = None,
    sprint: Annotated[Optional[str], typer.Option("--sprint", help="Sprint name (empty string to remove from sprint)")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Update an existing ticket.

    Examples:
        janet ticket update PROJ-123 --status "In Progress"
        janet ticket update PROJ-123 --title "New title" --priority High
        janet ticket update PROJ-123 -a user@example.com -a user2@example.com
        janet ticket update PROJ-123 --sprint "Sprint 1"
        janet ticket update PROJ-123 --sprint ""
    """
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve ticket_key to ticket_id
        resolved_ticket_key = ticket_key
        info = _resolve_ticket_key(ticket_key, config_manager)
        ticket_id = info["ticket_id"]
        project_id = info["project_id"]

        # Check if any update field was provided
        if not any([title, description, status, priority, issue_type, assignee, tag, due_date, sprint is not None]):
            print_error("No update fields provided. Use --help to see available options.")
            raise typer.Exit(1)

        # Resolve assignee names to emails
        resolved_assignees = assignee
        if assignee and project_id:
            resolved_assignees = _resolve_assignees(assignee, project_id, config_manager)

        # Update ticket
        ticket_api = TicketAPI(config_manager)
        result = ticket_api.update_ticket(
            ticket_id=ticket_id,
            title=title,
            description=description,
            status=status,
            priority=priority,
            issue_type=issue_type,
            assignees=resolved_assignees,
            labels=tag,
            due_date=due_date,
        )

        # Handle sprint assignment/removal
        sprint_msg = ""
        if sprint is not None:
            try:
                from janet.api.sprints import SprintAPI
                sprint_api = SprintAPI(config_manager)
                if sprint == "":
                    # Remove from sprint
                    sprint_api.remove_ticket(ticket_id)
                    sprint_msg = " (removed from sprint)"
                else:
                    resolved_sprint = _resolve_sprint(sprint, project_id)
                    sprint_api.add_ticket(ticket_id, resolved_sprint["id"], project_id)
                    sprint_msg = f' (added to sprint "{sprint}")'
            except Exception as e:
                print_error(f"Sprint update failed: {e}")

        if output_json:
            output = {
                "success": True,
                "ticket_key": resolved_ticket_key,
                "ticket_id": ticket_id,
                "updated_fields": result.get("updated_fields", []),
            }
            if sprint is not None:
                output["sprint"] = sprint if sprint else None
            console.print(json.dumps(output, indent=2))
        else:
            updated = result.get("updated_fields", [])
            if updated:
                print_success(f"Updated {resolved_ticket_key}: {', '.join(updated)}{sprint_msg}")
            else:
                print_success(f"Updated {resolved_ticket_key}{sprint_msg}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to update ticket: {e}")
        raise typer.Exit(1)


# =============================================================================
# Child Task Commands
# =============================================================================


@child_task_app.command(name="create")
def child_task_create(
    ticket_key: Annotated[str, typer.Argument(help="Parent ticket key (e.g., PROJ-123)")],
    title: Annotated[str, typer.Argument(help="Child task title")],
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="Child task description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Status (validated against project statuses)")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="Priority: Low, Medium, High, Critical")] = None,
    assignee: Annotated[Optional[str], typer.Option("--assignee", "-a", help="Assignee name or email")] = None,
    due_date: Annotated[Optional[str], typer.Option("--due-date", help="Due date (YYYY-MM-DD)")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Create a child task on a ticket.

    Examples:
        janet ticket child-task create PROJ-123 "Fix tests"
        janet ticket child-task create PROJ-123 "Review PR" -s "To Do" --priority High
        janet ticket child-task create PROJ-123 "Task" -a "John Doe"
        echo "Description" | janet ticket child-task create PROJ-123 "Task"
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve parent ticket
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Resolve status against project's valid statuses
        resolved_status = _resolve_status(status, info["project_id"], config_manager)

        # Check for piped stdin for description
        final_description = description
        if not sys.stdin.isatty() and not description:
            stdin_content = sys.stdin.read().strip()
            if stdin_content:
                final_description = stdin_content

        # Resolve assignee
        resolved_assignee = None
        if assignee:
            resolved = _resolve_assignees([assignee], info["project_id"], config_manager)
            resolved_assignee = resolved[0] if resolved else assignee

        # Create child task
        child_task_api = ChildTaskAPI(config_manager)
        result = child_task_api.create_child_task(
            ticket_id=info["ticket_id"],
            project_id=info["project_id"],
            ticket_identifier=info["ticket_identifier"],
            project_identifier=info["project_key"],
            title=title,
            status=resolved_status,
            description=final_description,
            priority=priority,
            assignee=resolved_assignee,
            due_date=due_date,
        )

        full_id = result.get("fullIdentifier", result.get("full_identifier", "?"))

        if output_json:
            output = {
                "success": True,
                "child_task_id": result.get("id"),
                "full_identifier": full_id,
                "title": title,
                "parent_ticket": ticket_key.upper(),
            }
            console.print(json.dumps(output, indent=2))
        else:
            print_success(f"Created {full_id}: {title}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to create child task: {e}")
        raise typer.Exit(1)


@child_task_app.command(name="list")
def child_task_list(
    ticket_key: Annotated[str, typer.Argument(help="Parent ticket key (e.g., PROJ-123)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    List child tasks for a ticket.

    Examples:
        janet ticket child-task list PROJ-123
        janet ticket child-task list PROJ-123 --json
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI
        from rich.table import Table

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve parent ticket
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Fetch child tasks
        child_task_api = ChildTaskAPI(config_manager)
        child_tasks = child_task_api.list_child_tasks(info["ticket_id"])

        if output_json:
            console.print(json.dumps({"success": True, "child_tasks": child_tasks}, indent=2))
        else:
            if not child_tasks:
                print_info(f"No child tasks found for {ticket_key.upper()}")
                return

            table = Table(title=f"Child Tasks for {ticket_key.upper()}")
            table.add_column("Key", style="cyan")
            table.add_column("Title", style="white")
            table.add_column("Status", style="green")
            table.add_column("Priority", style="yellow")
            table.add_column("Assignee", style="dim")

            for ct in child_tasks:
                table.add_row(
                    ct.get("fullIdentifier", ct.get("full_identifier", "?")),
                    ct.get("title", ""),
                    ct.get("status", "-"),
                    ct.get("priority", "-"),
                    ct.get("assignee", "-"),
                )

            console.print(table)

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to list child tasks: {e}")
        raise typer.Exit(1)


@child_task_app.command(name="update")
def child_task_update(
    child_task_key: Annotated[str, typer.Argument(help="Child task key (e.g., PROJ-123A)")],
    title: Annotated[Optional[str], typer.Option("--title", help="New title")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="New description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="New status")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="New priority: Low, Medium, High, Critical")] = None,
    assignee: Annotated[Optional[str], typer.Option("--assignee", "-a", help="New assignee name or email")] = None,
    due_date: Annotated[Optional[str], typer.Option("--due-date", help="New due date (YYYY-MM-DD)")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Update a child task.

    Examples:
        janet ticket child-task update PROJ-123A --status "In Progress"
        janet ticket child-task update PROJ-123A --title "New title" --priority High
        janet ticket child-task update PROJ-123A --due-date 2026-04-01
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Check if any update field was provided
        if not any([title, description, status, priority, assignee, due_date]):
            print_error("No update fields provided. Use --help to see available options.")
            raise typer.Exit(1)

        # Resolve child task key
        info = _resolve_child_task_key(child_task_key, config_manager)

        # Resolve assignee
        resolved_assignee = assignee
        if assignee and info["project_id"]:
            resolved = _resolve_assignees([assignee], info["project_id"], config_manager)
            resolved_assignee = resolved[0] if resolved else assignee

        # Update child task
        child_task_api = ChildTaskAPI(config_manager)
        result = child_task_api.update_child_task(
            child_task_id=info["child_task_id"],
            title=title,
            description=description,
            status=status,
            priority=priority,
            assignee=resolved_assignee,
            due_date=due_date,
        )

        if output_json:
            output = {
                "success": True,
                "full_identifier": info["full_identifier"],
                "child_task_id": info["child_task_id"],
            }
            console.print(json.dumps(output, indent=2))
        else:
            updated_fields = []
            if title is not None:
                updated_fields.append("title")
            if description is not None:
                updated_fields.append("description")
            if status is not None:
                updated_fields.append("status")
            if priority is not None:
                updated_fields.append("priority")
            if assignee is not None:
                updated_fields.append("assignee")
            if due_date is not None:
                updated_fields.append("due_date")
            print_success(f"Updated {info['full_identifier']}: {', '.join(updated_fields)}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to update child task: {e}")
        raise typer.Exit(1)


@child_task_app.command(name="delete")
def child_task_delete(
    child_task_key: Annotated[str, typer.Argument(help="Child task key (e.g., PROJ-123A)")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Delete a child task.

    Examples:
        janet ticket child-task delete PROJ-123A
        janet ticket child-task delete PROJ-123A --yes
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve child task key
        info = _resolve_child_task_key(child_task_key, config_manager)

        # Confirm deletion
        if not confirm:
            if sys.stdin.isatty():
                from InquirerPy import inquirer

                confirmed = inquirer.confirm(
                    message=f"Delete child task {info['full_identifier']}?",
                    default=False,
                ).execute()

                if not confirmed:
                    print_info("Cancelled")
                    raise typer.Exit(0)
            else:
                # Non-interactive: require --yes
                print_error("Use --yes to confirm deletion in non-interactive mode")
                raise typer.Exit(1)

        # Delete child task
        child_task_api = ChildTaskAPI(config_manager)
        child_task_api.delete_child_task(info["child_task_id"])

        if output_json:
            output = {
                "success": True,
                "full_identifier": info["full_identifier"],
                "child_task_id": info["child_task_id"],
            }
            console.print(json.dumps(output, indent=2))
        else:
            print_success(f"Deleted {info['full_identifier']}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to delete child task: {e}")
        raise typer.Exit(1)


# =============================================================================
# Sub-Task Commands
# =============================================================================


@sub_task_app.command(name="create")
def sub_task_create(
    child_task_key: Annotated[str, typer.Argument(help="Parent child task key (e.g., PROJ-123A)")],
    title: Annotated[str, typer.Argument(help="Sub-task title")],
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Status")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="Priority: Low, Medium, High, Critical")] = None,
    assignee: Annotated[Optional[str], typer.Option("--assignee", "-a", help="Assignee name or email")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Create a sub-task on a child task.

    Examples:
        janet ticket sub-task create PROJ-123A "Write tests"
        janet ticket sub-task create PROJ-123A "Review PR" -s "To Do" --priority High
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_child_task_key(child_task_key, config_manager)
        child_task_id = info["child_task_id"]
        project_id = info["project_id"]

        # Resolve status
        resolved_status = _resolve_status(status, project_id, config_manager) if status else "To Do"

        # Resolve assignee
        resolved_assignee = None
        if assignee and project_id:
            resolved = _resolve_assignees([assignee], project_id, config_manager)
            resolved_assignee = resolved[0] if resolved else None

        api = ChildTaskAPI(config_manager)
        result = api.create_sub_task(
            child_task_id=child_task_id,
            title=title,
            status=resolved_status,
            priority=priority,
            assignee=resolved_assignee,
        )

        sub_task = result.get("sub_task", {})
        full_id = sub_task.get("fullIdentifier", "?")

        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            print_success(f"Created {full_id}: {title}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sub_task_app.command(name="list")
def sub_task_list(
    child_task_key: Annotated[str, typer.Argument(help="Child task key (e.g., PROJ-123A)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List sub-tasks for a child task."""
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_child_task_key(child_task_key, config_manager)
        api = ChildTaskAPI(config_manager)
        sub_tasks = api.list_sub_tasks(info["child_task_id"])

        if output_json:
            console.print(json.dumps(sub_tasks, indent=2))
            return

        if not sub_tasks:
            print_info(f"No sub-tasks found for {child_task_key.upper()}")
            return

        from rich.table import Table
        table = Table(title=f"Sub-tasks for {child_task_key.upper()}")
        table.add_column("Key")
        table.add_column("Title")
        table.add_column("Status")
        table.add_column("Priority")
        table.add_column("Assignee")

        for st in sub_tasks:
            table.add_row(
                st.get("fullIdentifier", "?"),
                st.get("title", "?"),
                st.get("status") or "—",
                st.get("priority") or "—",
                st.get("assignee") or "—",
            )
        console.print(table)

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sub_task_app.command(name="update")
def sub_task_update(
    sub_task_key: Annotated[str, typer.Argument(help="Sub-task key (e.g., PROJ-123A-1)")],
    title: Annotated[Optional[str], typer.Option("--title", help="New title")] = None,
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="New status")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="New priority")] = None,
    assignee: Annotated[Optional[str], typer.Option("--assignee", "-a", help="New assignee")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Update a sub-task.

    Examples:
        janet ticket sub-task update PROJ-123A-1 --status "Done"
        janet ticket sub-task update PROJ-123A-1 --assignee user@example.com
    """
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        if not any([title, status, priority, assignee]):
            print_error("No update fields provided. Use --help to see options.")
            raise typer.Exit(1)

        info = _resolve_sub_task_key(sub_task_key, config_manager)

        # Resolve assignee
        resolved_assignee = assignee
        if assignee and info.get("project_id"):
            resolved = _resolve_assignees([assignee], info["project_id"], config_manager)
            resolved_assignee = resolved[0] if resolved else assignee

        api = ChildTaskAPI(config_manager)
        result = api.update_sub_task(
            sub_task_id=info["sub_task_id"],
            title=title,
            status=status,
            priority=priority,
            assignee=resolved_assignee,
        )

        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            print_success(f"Updated {sub_task_key.upper()}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sub_task_app.command(name="delete")
def sub_task_delete(
    sub_task_key: Annotated[str, typer.Argument(help="Sub-task key (e.g., PROJ-123A-1)")],
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Delete a sub-task."""
    try:
        from janet.api.child_tasks import ChildTaskAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_sub_task_key(sub_task_key, config_manager)

        if not yes:
            if sys.stdin.isatty():
                from InquirerPy import inquirer
                confirm = inquirer.confirm(message=f"Delete sub-task {sub_task_key.upper()}?", default=False).execute()
                if not confirm:
                    print_info("Cancelled")
                    raise typer.Exit(0)
            else:
                pass  # Non-interactive: proceed without confirmation

        api = ChildTaskAPI(config_manager)
        api.delete_sub_task(info["sub_task_id"])

        if output_json:
            console.print(json.dumps({"success": True, "deleted": sub_task_key.upper()}, indent=2))
        else:
            print_success(f"Deleted {sub_task_key.upper()}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


# =============================================================================
# Comment Commands
# =============================================================================


@comment_app.command(name="add")
def comment_add(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    text: Annotated[Optional[str], typer.Argument(help="Comment text")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Add a comment to a ticket.

    Examples:
        janet ticket comment add PROJ-123 "This is a comment"
        echo "Comment from pipe" | janet ticket comment add PROJ-123
    """
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve ticket key
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Get comment text from argument or stdin
        comment_text = text
        if not comment_text and not sys.stdin.isatty():
            comment_text = sys.stdin.read().strip()

        if not comment_text:
            print_error("Comment text is required. Provide as argument or pipe via stdin.")
            raise typer.Exit(1)

        # Add comment
        ticket_api = TicketAPI(config_manager)
        result = ticket_api.add_comment(info["ticket_id"], comment_text)

        if output_json:
            output = {
                "success": True,
                "ticket_key": ticket_key.upper(),
                "ticket_id": info["ticket_id"],
            }
            console.print(json.dumps(output, indent=2))
        else:
            print_success(f"Added comment to {ticket_key.upper()}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to add comment: {e}")
        raise typer.Exit(1)


@comment_app.command(name="list")
def comment_list(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    List comments on a ticket.

    Examples:
        janet ticket comment list PROJ-123
        janet ticket comment list PROJ-123 --json
    """
    try:
        from janet.api.tickets import TicketAPI
        from rich.table import Table

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve ticket key
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Fetch comments
        ticket_api = TicketAPI(config_manager)
        comments = ticket_api.get_ticket_comments(info["ticket_id"])

        if output_json:
            console.print(json.dumps({"success": True, "comments": comments}, indent=2))
        else:
            if not comments:
                print_info(f"No comments on {ticket_key.upper()}")
                return

            table = Table(title=f"Comments on {ticket_key.upper()}")
            table.add_column("ID", style="dim", max_width=8)
            table.add_column("Author", style="cyan")
            table.add_column("Date", style="green")
            table.add_column("Content", style="white")

            for c in comments:
                comment_id = c.get("id", "")
                short_id = comment_id[:8] if comment_id else "-"
                author = c.get("created_by", "-")
                date = c.get("created_at", "-")
                if date and len(date) > 10:
                    date = date[:10]
                content = c.get("content", "")
                if len(content) > 80:
                    content = content[:77] + "..."
                table.add_row(short_id, author, date, content)

            console.print(table)
            console.print(f"\n[dim]Use --json to see full comment IDs and content[/dim]")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to list comments: {e}")
        raise typer.Exit(1)


@comment_app.command(name="edit")
def comment_edit(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    comment_id: Annotated[str, typer.Argument(help="Comment ID (from 'comment list --json')")],
    text: Annotated[str, typer.Argument(help="New comment text")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Edit a comment on a ticket.

    Get comment IDs with: janet ticket comment list PROJ-123 --json

    Examples:
        janet ticket comment edit PROJ-123 <comment-id> "Updated text"
    """
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve ticket key
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Edit comment
        ticket_api = TicketAPI(config_manager)
        ticket_api.edit_comment(info["ticket_id"], comment_id, text)

        if output_json:
            output = {
                "success": True,
                "ticket_key": ticket_key.upper(),
                "comment_id": comment_id,
            }
            console.print(json.dumps(output, indent=2))
        else:
            print_success(f"Edited comment on {ticket_key.upper()}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to edit comment: {e}")
        raise typer.Exit(1)


@comment_app.command(name="delete")
def comment_delete(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    comment_id: Annotated[str, typer.Argument(help="Comment ID (from 'comment list --json')")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Delete a comment on a ticket.

    Get comment IDs with: janet ticket comment list PROJ-123 --json

    Examples:
        janet ticket comment delete PROJ-123 <comment-id>
        janet ticket comment delete PROJ-123 <comment-id> --yes
    """
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)

        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve ticket key
        info = _resolve_ticket_key(ticket_key, config_manager)

        # Confirm deletion
        if not confirm:
            if sys.stdin.isatty():
                from InquirerPy import inquirer

                confirmed = inquirer.confirm(
                    message=f"Delete comment {comment_id[:8]}... on {ticket_key.upper()}?",
                    default=False,
                ).execute()

                if not confirmed:
                    print_info("Cancelled")
                    raise typer.Exit(0)
            else:
                print_error("Use --yes to confirm deletion in non-interactive mode")
                raise typer.Exit(1)

        # Delete comment
        ticket_api = TicketAPI(config_manager)
        ticket_api.delete_comment(info["ticket_id"], comment_id)

        if output_json:
            output = {
                "success": True,
                "ticket_key": ticket_key.upper(),
                "comment_id": comment_id,
            }
            console.print(json.dumps(output, indent=2))
        else:
            print_success(f"Deleted comment on {ticket_key.upper()}")

    except typer.Exit:
        raise
    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        if output_json:
            console.print(json.dumps({"success": False, "error": str(e)}))
        else:
            print_error(f"Failed to delete comment: {e}")
        raise typer.Exit(1)


# =============================================================================
# Context Command (for AI agents)
# =============================================================================


@app.command(name="context", rich_help_panel="Syncing")
def context(
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Show current context (org, projects) for AI agents.

    Use --json for machine-readable output.
    """
    try:
        from janet.api.projects import ProjectAPI

        config = config_manager.get()

        context_data = {
            "authenticated": config_manager.is_authenticated(),
            "user_email": config.auth.user_email if config.auth else None,
            "organization": None,
            "projects": [],
        }

        if config_manager.is_authenticated() and config.selected_organization:
            context_data["organization"] = {
                "id": config.selected_organization.id,
                "name": config.selected_organization.name,
                "uuid": config.selected_organization.uuid,
            }

            # Fetch projects
            if config_manager.has_organization():
                try:
                    project_api = ProjectAPI(config_manager)
                    projects = project_api.list_projects()
                    context_data["projects"] = [
                        {
                            "id": p.get("id"),
                            "key": p.get("project_identifier"),
                            "name": p.get("project_name"),
                            "ticket_count": p.get("ticket_count", 0),
                        }
                        for p in projects
                    ]
                except Exception:
                    pass  # Projects fetch failed, leave empty

        if output_json:
            console.print(json.dumps(context_data, indent=2))
        else:
            console.print("[bold]Janet CLI Context[/bold]\n")

            if not context_data["authenticated"]:
                console.print("[yellow]Not authenticated[/yellow]")
                console.print("Run 'janet login' to authenticate")
                return

            console.print(f"[green]✓ Authenticated[/green] as {context_data['user_email']}")

            if context_data["organization"]:
                console.print(f"[green]✓ Organization:[/green] {context_data['organization']['name']}")
            else:
                console.print("[yellow]No organization selected[/yellow]")
                return

            if context_data["projects"]:
                console.print(f"\n[bold]Projects ({len(context_data['projects'])}):[/bold]")
                for p in context_data["projects"]:
                    console.print(f"  • {p['key']:8s} - {p['name']} ({p['ticket_count']} tickets)")
            else:
                console.print("\n[dim]No projects found[/dim]")

    except JanetCLIError as e:
        if output_json:
            console.print(json.dumps({"authenticated": False, "error": str(e)}))
        else:
            print_error(str(e))
        raise typer.Exit(1)


# ─── Position Commands ─────────────────────────────────────────────────────────


def _get_tickets_in_status(project_id: str, status: str) -> list:
    """Fetch tickets in a status column ordered by position (lightweight, no cap)."""
    from janet.api.tickets import TicketAPI
    ticket_api = TicketAPI(config_manager)
    return ticket_api.get_positions(project_id, status=status)


@position_app.command(name="top")
def position_top(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Target status column (default: ticket's current status)")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Move a ticket to the top of its status column."""
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_ticket_key(ticket_key, config_manager)
        ticket_id = info["ticket_id"]
        project_id = info["project_id"]

        # Resolve status
        if not status:
            ticket_api = TicketAPI(config_manager)
            ticket = ticket_api.get_ticket(ticket_id)
            status = ticket.get("status", "To Do")

        ticket_api = TicketAPI(config_manager)
        result = ticket_api.move_to_top(ticket_id, status)

        if output_json:
            console.print(json.dumps({"success": True, "ticket_key": ticket_key, "position": "top", "status": status}, indent=2))
        else:
            print_success(f"Moved {ticket_key} to top of {status}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@position_app.command(name="bottom")
def position_bottom(
    ticket_key: Annotated[str, typer.Argument(help="Ticket key (e.g., PROJ-123)")],
    status: Annotated[Optional[str], typer.Option("--status", "-s", help="Target status column (default: ticket's current status)")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Move a ticket to the bottom of its status column."""
    try:
        from janet.api.tickets import TicketAPI
        from janet.utils.lexo_position import generate_between

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_ticket_key(ticket_key, config_manager)
        ticket_id = info["ticket_id"]
        project_id = info["project_id"]

        if not status:
            ticket_api = TicketAPI(config_manager)
            ticket = ticket_api.get_ticket(ticket_id)
            status = ticket.get("status", "To Do")

        tickets = _get_tickets_in_status(project_id, status)
        last_pos = tickets[-1].get("position") if tickets else None
        new_pos = generate_between(last_pos, None)

        ticket_api = TicketAPI(config_manager)
        ticket_api.set_position(ticket_id, new_pos, status)

        if output_json:
            console.print(json.dumps({"success": True, "ticket_key": ticket_key, "position": "bottom", "status": status}, indent=2))
        else:
            print_success(f"Moved {ticket_key} to bottom of {status}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@position_app.command(name="after")
def position_after(
    ticket_key: Annotated[str, typer.Argument(help="Ticket to move (e.g., PROJ-123)")],
    target_key: Annotated[str, typer.Argument(help="Place after this ticket (e.g., PROJ-456)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Move a ticket to the position immediately after another ticket."""
    try:
        from janet.api.tickets import TicketAPI
        from janet.utils.lexo_position import generate_between

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_ticket_key(ticket_key, config_manager)
        ticket_id = info["ticket_id"]
        target_info = _resolve_ticket_key(target_key, config_manager)
        target_id = target_info["ticket_id"]
        project_id = info["project_id"]

        ticket_api = TicketAPI(config_manager)
        target_ticket = ticket_api.get_ticket(target_id)
        target_status = target_ticket.get("status", "To Do")
        target_pos = target_ticket.get("position")

        # Find the ticket below the target
        tickets = _get_tickets_in_status(project_id, target_status)
        below_pos = None
        for i, t in enumerate(tickets):
            if t.get("ticket_id") == target_id and i + 1 < len(tickets):
                below_pos = tickets[i + 1].get("position")
                break

        new_pos = generate_between(target_pos, below_pos)
        ticket_api.set_position(ticket_id, new_pos, target_status)

        if output_json:
            console.print(json.dumps({"success": True, "ticket_key": ticket_key, "after": target_key, "status": target_status}, indent=2))
        else:
            print_success(f"Moved {ticket_key} after {target_key}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@position_app.command(name="before")
def position_before(
    ticket_key: Annotated[str, typer.Argument(help="Ticket to move (e.g., PROJ-123)")],
    target_key: Annotated[str, typer.Argument(help="Place before this ticket (e.g., PROJ-456)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Move a ticket to the position immediately before another ticket."""
    try:
        from janet.api.tickets import TicketAPI
        from janet.utils.lexo_position import generate_between

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        info = _resolve_ticket_key(ticket_key, config_manager)
        ticket_id = info["ticket_id"]
        target_info = _resolve_ticket_key(target_key, config_manager)
        target_id = target_info["ticket_id"]
        project_id = info["project_id"]

        ticket_api = TicketAPI(config_manager)
        target_ticket = ticket_api.get_ticket(target_id)
        target_status = target_ticket.get("status", "To Do")
        target_pos = target_ticket.get("position")

        # Find the ticket above the target
        tickets = _get_tickets_in_status(project_id, target_status)
        above_pos = None
        for i, t in enumerate(tickets):
            if t.get("ticket_id") == target_id and i > 0:
                above_pos = tickets[i - 1].get("position")
                break

        new_pos = generate_between(above_pos, target_pos)
        ticket_api.set_position(ticket_id, new_pos, target_status)

        if output_json:
            console.print(json.dumps({"success": True, "ticket_key": ticket_key, "before": target_key, "status": target_status}, indent=2))
        else:
            print_success(f"Moved {ticket_key} before {target_key}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@position_app.command(name="reorder")
def position_reorder(
    ticket_keys: Annotated[List[str], typer.Argument(help="Ticket keys in desired order (e.g., PROJ-1 PROJ-2 PROJ-3)")],
    status: Annotated[str, typer.Option("--status", "-s", help="Status column to reorder in")] = ...,
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Reorder tickets in a status column to match the given order."""
    try:
        from janet.api.tickets import TicketAPI
        from janet.utils.lexo_position import generate_evenly_spaced

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        # Resolve all ticket keys in one batch (2 API calls total, not 2*N)
        resolved = _resolve_ticket_keys_batch(ticket_keys, config_manager)
        ticket_ids = [r["ticket_id"] for r in resolved]

        # Generate evenly spaced positions
        positions = generate_evenly_spaced(len(ticket_ids))

        # Bulk update all positions in one request
        ticket_api = TicketAPI(config_manager)
        bulk_data = [
            {"ticket_id": tid, "position": pos, "status": status}
            for tid, pos in zip(ticket_ids, positions)
        ]
        ticket_api.bulk_set_positions(bulk_data)

        if output_json:
            console.print(json.dumps({"success": True, "reordered": ticket_keys, "status": status}, indent=2))
        else:
            print_success(f"Reordered {len(ticket_keys)} tickets in {status}: {', '.join(ticket_keys)}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@position_app.command(name="sort")
def position_sort(
    status: Annotated[str, typer.Option("--status", "-s", help="Status column to sort")] = ...,
    project: Annotated[str, typer.Option("--project", "-p", help="Project key")] = ...,
    by: Annotated[str, typer.Option("--by", "-b", help="Sort by: priority, assignee, type, created, updated, due-date")] = "priority",
    reverse: Annotated[bool, typer.Option("--reverse", "-r", help="Reverse sort order")] = False,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """
    Auto-sort all tickets in a status column by a field.

    Examples:
        janet ticket position sort -s "To Do" -p MAIN --by priority
        janet ticket position sort -s Backlog -p MAIN --by assignee
        janet ticket position sort -s "In Progress" -p MAIN --by due-date
        janet ticket position sort -s Backlog -p MAIN --by type --reverse
    """
    try:
        from janet.api.tickets import TicketAPI

        if not config_manager.is_authenticated():
            print_error("Not authenticated. Run 'janet login' first.")
            raise typer.Exit(1)
        if not config_manager.has_organization():
            print_error("No organization selected. Run 'janet org select' first.")
            raise typer.Exit(1)

        valid_fields = ["priority", "assignee", "type", "created", "updated", "due-date"]
        if by not in valid_fields:
            print_error(f"Invalid sort field '{by}'. Valid: {', '.join(valid_fields)}")
            raise typer.Exit(1)

        # Map CLI field names to backend field names
        sort_by_map = {"due-date": "due_date"}
        backend_sort_by = sort_by_map.get(by, by)

        # Resolve project
        from janet.api.projects import ProjectAPI
        project_api = ProjectAPI(config_manager)
        projects = project_api.list_projects()
        project_id = None
        for p in projects:
            if p.get("project_identifier", "").upper() == project.upper():
                project_id = p["id"]
                break
        if not project_id:
            print_error(f"Project '{project}' not found")
            raise typer.Exit(1)

        # Server-side sort — one API call does fetch + sort + update positions
        ticket_api = TicketAPI(config_manager)
        result = ticket_api.sort_column(project_id, status, backend_sort_by, reverse)

        count = result.get("count", 0)
        if output_json:
            console.print(json.dumps({"success": True, "sorted_by": by, "status": status, "count": count}, indent=2))
        else:
            print_success(f"Sorted {count} tickets in {status} by {by}")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


# ─── Sprint Commands ──────────────────────────────────────────────────────────


def _resolve_project_for_sprint(project: Optional[str]) -> tuple:
    """Resolve project arg to (project_id, project_key). Shared by sprint commands."""
    from janet.api.projects import ProjectAPI

    if not config_manager.is_authenticated():
        print_error("Not authenticated. Run 'janet login' first.")
        raise typer.Exit(1)
    if not config_manager.has_organization():
        print_error("No organization selected. Run 'janet org select' first.")
        raise typer.Exit(1)

    project_api = ProjectAPI(config_manager)
    projects = project_api.list_projects()
    if not projects:
        print_error("No projects found in organization")
        raise typer.Exit(1)

    if project:
        for p in projects:
            if p.get("project_identifier", "").upper() == project.upper():
                return p["id"], p["project_identifier"]
            if p.get("id") == project:
                return p["id"], p.get("project_identifier", "")
        # Try name match
        for p in projects:
            if p.get("project_name", "").lower() == project.lower():
                return p["id"], p.get("project_identifier", "")
        avail = ", ".join(f"{p.get('project_identifier', '?')} ({p.get('project_name', '')})" for p in projects)
        print_error(f"Project '{project}' not found. Available: {avail}")
        raise typer.Exit(1)

    # Interactive selection
    if sys.stdin.isatty():
        from InquirerPy import inquirer
        choices = [{"name": f"{p.get('project_identifier', '?')} - {p.get('project_name', '')}", "value": p} for p in projects]
        selected = inquirer.select(message="Select project:", choices=choices).execute()
        return selected["id"], selected.get("project_identifier", "")
    else:
        avail = ", ".join(p.get("project_identifier", "?") for p in projects)
        print_error(f"No --project provided. Available: {avail}")
        raise typer.Exit(1)


def _resolve_sprint(sprint_name: str, project_id: str) -> dict:
    """Resolve a sprint name or ID to its full sprint dict."""
    from janet.api.sprints import SprintAPI
    sprint_api = SprintAPI(config_manager)
    sprints = sprint_api.list_sprints(project_id)

    if not sprints:
        print_error("No sprints found for this project.")
        raise typer.Exit(1)

    # Exact name match (case-insensitive)
    for s in sprints:
        if s.get("sprint_name", "").lower() == sprint_name.lower():
            return s

    # Partial name match
    matches = [s for s in sprints if sprint_name.lower() in s.get("sprint_name", "").lower()]
    if len(matches) == 1:
        return matches[0]

    # ID match
    for s in sprints:
        if s.get("id") == sprint_name:
            return s

    # Interactive selection on ambiguity
    if matches and sys.stdin.isatty():
        from InquirerPy import inquirer
        choices = [{"name": s.get("sprint_name", "?"), "value": s} for s in matches]
        return inquirer.select(message="Multiple matches. Select sprint:", choices=choices).execute()

    avail = ", ".join(f'"{s.get("sprint_name", "?")}"' for s in sprints)
    print_error(f"Sprint '{sprint_name}' not found. Available sprints: {avail}")
    raise typer.Exit(1)


@sprint_app.command(name="list")
def sprint_list(
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List sprints for a project."""
    try:
        from janet.api.sprints import SprintAPI
        project_id, _project_key = _resolve_project_for_sprint(project)
        sprint_api = SprintAPI(config_manager)
        sprints = sprint_api.list_sprints(project_id)

        if output_json:
            console.print(json.dumps({"success": True, "sprints": sprints}, indent=2))
            return

        if not sprints:
            print_info("No sprints found.")
            return

        from rich.table import Table
        table = Table(show_header=True, header_style="bold", show_lines=False, pad_edge=False)
        table.add_column("Name", style="bold")
        table.add_column("Status")
        table.add_column("Dates")
        table.add_column("Tickets", justify="right")

        from datetime import datetime
        for s in sprints:
            status = s.get("status", "planned")
            status_color = {"active": "green", "completed": "blue", "planned": "yellow"}.get(status, "dim")
            start = datetime.fromisoformat(s.get("start_date", "")).strftime("%b %d") if s.get("start_date") else "?"
            end = datetime.fromisoformat(s.get("end_date", "")).strftime("%b %d") if s.get("end_date") else "?"
            stats = s.get("ticket_stats", {})
            ticket_count = stats.get("total_tickets", 0)
            table.add_row(
                s.get("sprint_name", "?"),
                f"[{status_color}]{status}[/{status_color}]",
                f"{start} – {end}",
                str(ticket_count),
            )
        console.print(table)

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="create")
def sprint_create(
    name: Annotated[str, typer.Argument(help="Sprint name")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    start: Annotated[Optional[str], typer.Option("--start", "-s", help="Start date (YYYY-MM-DD, default: today)")] = None,
    end: Annotated[Optional[str], typer.Option("--end", "-e", help="End date (YYYY-MM-DD, default: start + 14 days)")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="Sprint description")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Create a new sprint."""
    try:
        from janet.api.sprints import SprintAPI
        from datetime import datetime, timedelta

        project_id, _project_key = _resolve_project_for_sprint(project)

        # Default dates
        if not start:
            start = datetime.now().strftime("%Y-%m-%d")
        if not end:
            start_dt = datetime.strptime(start, "%Y-%m-%d")
            end = (start_dt + timedelta(days=14)).strftime("%Y-%m-%d")

        start_iso = f"{start}T00:00:00Z"
        end_iso = f"{end}T23:59:59Z"

        sprint_api = SprintAPI(config_manager)
        result = sprint_api.create_sprint(project_id, name, start_iso, end_iso, description)

        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            print_success(f'Created sprint "{name}" ({start} – {end})')

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="update")
def sprint_update(
    sprint: Annotated[str, typer.Argument(help="Sprint name or ID")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    name: Annotated[Optional[str], typer.Option("--name", "-n", help="New sprint name")] = None,
    start: Annotated[Optional[str], typer.Option("--start", "-s", help="New start date (YYYY-MM-DD)")] = None,
    end: Annotated[Optional[str], typer.Option("--end", "-e", help="New end date (YYYY-MM-DD)")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="New description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", help="Status: planned, active, completed")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Update a sprint's name, dates, description, or status."""
    try:
        from janet.api.sprints import SprintAPI

        project_id, _project_key = _resolve_project_for_sprint(project)
        resolved = _resolve_sprint(sprint, project_id)
        sprint_id = resolved["id"]

        if status and status not in ("planned", "active", "completed"):
            print_error(f"Invalid status '{status}'. Must be: planned, active, completed")
            raise typer.Exit(1)

        start_iso = f"{start}T00:00:00Z" if start else None
        end_iso = f"{end}T23:59:59Z" if end else None

        sprint_api = SprintAPI(config_manager)
        result = sprint_api.update_sprint(sprint_id, name, start_iso, end_iso, description, status)

        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            print_success(f'Updated sprint "{resolved.get("sprint_name", sprint)}"')

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="add-ticket")
def sprint_add_ticket(
    sprint: Annotated[str, typer.Argument(help="Sprint name or ID")],
    tickets: Annotated[List[str], typer.Argument(help="Ticket key(s) (e.g., PROJ-1 PROJ-2)")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Add one or more tickets to a sprint."""
    try:
        from janet.api.sprints import SprintAPI

        project_id, _project_key = _resolve_project_for_sprint(project)
        resolved = _resolve_sprint(sprint, project_id)
        sprint_id = resolved["id"]
        sprint_api = SprintAPI(config_manager)

        # Batch resolve all ticket keys (2 API calls, not 2*N)
        resolved_tickets = _resolve_ticket_keys_batch(tickets, config_manager)
        ticket_ids = [r["ticket_id"] for r in resolved_tickets]

        # Bulk add in one request
        sprint_api.bulk_add_tickets(sprint_id, ticket_ids, project_id)

        if output_json:
            console.print(json.dumps({"success": True, "added": tickets}, indent=2))
        else:
            print_success(f'Added {", ".join(tickets)} to "{resolved.get("sprint_name", sprint)}"')

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="remove-ticket")
def sprint_remove_ticket(
    sprint: Annotated[str, typer.Argument(help="Sprint name or ID")],
    tickets: Annotated[List[str], typer.Argument(help="Ticket key(s) (e.g., PROJ-1 PROJ-2)")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Remove one or more tickets from a sprint."""
    try:
        from janet.api.sprints import SprintAPI

        _resolve_project_for_sprint(project)  # validate auth/org
        sprint_api = SprintAPI(config_manager)

        # Batch resolve all ticket keys (2 API calls, not 2*N)
        resolved_tickets = _resolve_ticket_keys_batch(tickets, config_manager)
        ticket_ids = [r["ticket_id"] for r in resolved_tickets]

        project_id, _pk = _resolve_project_for_sprint(project)
        resolved_sprint = _resolve_sprint(sprint, project_id)
        sprint_id_for_remove = resolved_sprint["id"]

        # Bulk remove in one request
        sprint_api.bulk_remove_tickets(sprint_id_for_remove, ticket_ids)

        if output_json:
            console.print(json.dumps({"success": True, "removed": tickets}, indent=2))
        else:
            print_success(f'Removed {", ".join(tickets)} from sprint')

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="reorder")
def sprint_reorder(
    sprint: Annotated[str, typer.Argument(help="Sprint name or ID")],
    ticket_keys: Annotated[List[str], typer.Argument(help="Ticket keys in desired order")],
    status: Annotated[str, typer.Option("--status", "-s", help="Status column to reorder in")] = ...,
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Reorder tickets within a sprint's status column."""
    try:
        from janet.api.sprints import SprintAPI

        project_id, _pk = _resolve_project_for_sprint(project)
        resolved = _resolve_sprint(sprint, project_id)
        sprint_id = resolved["id"]

        # Batch resolve ticket keys
        resolved_tickets = _resolve_ticket_keys_batch(ticket_keys, config_manager)
        ticket_ids = [r["ticket_id"] for r in resolved_tickets]

        sprint_api = SprintAPI(config_manager)
        sprint_api.reorder_tickets(sprint_id, ticket_ids, status)

        if output_json:
            console.print(json.dumps({"success": True, "reordered": ticket_keys, "sprint": sprint, "status": status}, indent=2))
        else:
            print_success(f'Reordered {len(ticket_keys)} tickets in "{resolved.get("sprint_name", sprint)}" / {status}')

    except typer.Exit:
        raise
    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@sprint_app.command(name="tickets")
def sprint_tickets(
    sprint: Annotated[str, typer.Argument(help="Sprint name or ID")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project key or name")] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List tickets in a sprint."""
    try:
        from janet.api.sprints import SprintAPI
        from janet.api.tickets import TicketAPI

        project_id, project_key = _resolve_project_for_sprint(project)
        resolved = _resolve_sprint(sprint, project_id)
        sprint_id = resolved["id"]

        sprint_api = SprintAPI(config_manager)
        ticket_ids = sprint_api.list_tickets(sprint_id)

        if not ticket_ids:
            if output_json:
                console.print(json.dumps({"success": True, "tickets": []}, indent=2))
            else:
                print_info(f'No tickets in "{resolved.get("sprint_name", sprint)}"')
            return

        # Fetch ticket details
        ticket_api = TicketAPI(config_manager)
        tickets_data = []
        for tid in ticket_ids:
            try:
                t = ticket_api.get_ticket(tid)
                tickets_data.append(t)
            except Exception:
                tickets_data.append({"id": tid, "ticket_key": "?", "title": "(could not fetch)", "status": "?", "priority": "?"})

        if output_json:
            console.print(json.dumps({"success": True, "tickets": tickets_data}, indent=2))
            return

        from rich.table import Table
        table = Table(show_header=True, header_style="bold", show_lines=False, pad_edge=False)
        table.add_column("Key")
        table.add_column("Title")
        table.add_column("Status")
        table.add_column("Priority")

        for t in tickets_data:
            key = t.get("ticket_key", "?")
            title = t.get("title", "?")
            status = t.get("status", "?")
            priority = t.get("priority") or "—"
            table.add_row(key, title, status, priority)

        console.print(f'\n[bold]{resolved.get("sprint_name", sprint)}[/bold] ({len(tickets_data)} tickets)\n')
        console.print(table)

    except JanetCLIError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
