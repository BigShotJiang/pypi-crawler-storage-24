"""Sprint API methods."""

from typing import Dict, List, Optional

from janet.api.client import APIClient
from janet.config.manager import ConfigManager


class SprintAPI(APIClient):
    """API methods for sprint management."""

    def __init__(self, config_manager: ConfigManager):
        super().__init__(config_manager)

    def list_sprints(self, project_id: str) -> List[Dict]:
        """List all sprints for a project."""
        response = self.get(f"/api/v1/projects/{project_id}/sprints", include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to fetch sprints"))
        return response.get("sprints", [])

    def get_sprint(self, sprint_id: str) -> Dict:
        """Get a specific sprint by ID."""
        response = self.get(f"/api/v1/sprints/{sprint_id}", include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to fetch sprint"))
        return response.get("sprint", {})

    def create_sprint(
        self,
        project_id: str,
        name: str,
        start_date: str,
        end_date: str,
        description: Optional[str] = None,
    ) -> Dict:
        """Create a new sprint.

        Args:
            project_id: Project ID (UUID)
            name: Sprint name
            start_date: Start date (ISO 8601)
            end_date: End date (ISO 8601)
            description: Optional description
        """
        payload: Dict = {
            "sprint_name": name,
            "start_date": start_date,
            "end_date": end_date,
        }
        if description:
            payload["description"] = description

        response = self.post(f"/api/v1/projects/{project_id}/sprints", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to create sprint"))
        return response

    def update_sprint(
        self,
        sprint_id: str,
        name: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Dict:
        """Update a sprint."""
        payload: Dict = {}
        if name is not None:
            payload["sprint_name"] = name
        if start_date is not None:
            payload["start_date"] = start_date
        if end_date is not None:
            payload["end_date"] = end_date
        if description is not None:
            payload["description"] = description
        if status is not None:
            payload["status"] = status

        if not payload:
            raise Exception("No fields to update")

        response = self.put(f"/api/v1/sprints/{sprint_id}", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to update sprint"))
        return response

    def add_ticket(self, ticket_id: str, sprint_id: str, project_id: str) -> Dict:
        """Add a ticket to a sprint."""
        payload = {"sprint_id": sprint_id, "project_id": project_id}
        response = self.post(f"/api/v1/tickets/{ticket_id}/sprint", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to add ticket to sprint"))
        return response

    def remove_ticket(self, ticket_id: str) -> Dict:
        """Remove a ticket from its sprint."""
        response = self.delete(f"/api/v1/tickets/{ticket_id}/sprint", include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to remove ticket from sprint"))
        return response

    def bulk_add_tickets(self, sprint_id: str, ticket_ids: List[str], project_id: str) -> Dict:
        """Add multiple tickets to a sprint in one request."""
        payload = {"ticket_ids": ticket_ids, "project_id": project_id}
        response = self.post(f"/api/v1/sprints/{sprint_id}/tickets/bulk", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to bulk add tickets to sprint"))
        return response

    def bulk_remove_tickets(self, sprint_id: str, ticket_ids: List[str]) -> Dict:
        """Remove multiple tickets from a sprint in one request."""
        payload = {"ticket_ids": ticket_ids}
        response = self.delete(f"/api/v1/sprints/{sprint_id}/tickets/bulk", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to bulk remove tickets from sprint"))
        return response

    def reorder_tickets(self, sprint_id: str, ticket_ids: List[str], status: str) -> Dict:
        """Reorder tickets within a sprint status column."""
        payload = {"ticket_ids": ticket_ids, "status": status}
        response = self.post(f"/api/v1/sprints/{sprint_id}/tickets/reorder", data=payload, include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to reorder sprint tickets"))
        return response

    def list_tickets(self, sprint_id: str) -> List[str]:
        """List ticket IDs in a sprint."""
        response = self.get(f"/api/v1/sprints/{sprint_id}/tickets", include_org=True)
        if not response.get("success"):
            raise Exception(response.get("error", "Failed to fetch sprint tickets"))
        return response.get("ticket_ids", [])
