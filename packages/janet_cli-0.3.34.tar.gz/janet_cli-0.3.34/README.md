# Janet AI CLI

> Sync your Janet AI tickets to local markdown files with real-time updates, and enable AI coding agents to create and manage tickets.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## What is Janet AI?

[Janet AI](https://janet.ai) is an AI-native project management platform for modern software teams. The Janet CLI allows developers to:

- **Sync tickets** to local markdown files with real-time updates as changes are made on the platform
- **Create tickets** directly from the command line or via AI agents
- **Update tickets** without leaving your terminal
- **Manage child tasks** to break tickets into smaller sub-tasks
- **Comment on tickets** to add updates, notes, and discussion
- **Manage sprints** to organize work into time-boxed iterations

## Why Use the CLI?

AI coding assistants work better when they understand your project's tickets, requirements, and priorities. With Janet CLI, AI agents like Claude Code and Cursor can:

- Reference specific tickets while writing code
- Create new tickets when discovering bugs or needed features
- Update ticket status as work progresses
- Understand requirements and acceptance criteria
- Answer questions about project priorities

## Installation

```bash
pip install janet-cli
```

## Quick Start

```bash
# 1. Authenticate
janet login

# 2. Sync tickets and watch for real-time updates
janet sync
```

## Using with AI Coding Agents

### Claude Code

Add Janet CLI to your Claude Code workflow:

```bash
# In your project directory
janet sync
```

Claude Code can now reference, create, and update tickets. Example natural language prompts:

**Referencing tickets:**
- "Look at ticket BACK-42 and implement the authentication flow"
- "What are the high priority tickets in the Backend project?"
- "Show me all tickets assigned to me"

**Creating tickets:**
- "Create a high-priority bug ticket in BACK for the null pointer exception we just found in auth.py"
- "Make a new feature ticket in FRONT for dark mode support with the description from design-doc.md"
- "Create a ticket to add unit tests for the payment service, assign it to dev@example.com"

**Updating tickets:**
- "Update BACK-42 status to In Progress since I'm working on it now"
- "Mark FRONT-15 as Done and add a comment that it's deployed to staging"
- "Change the priority of BACK-38 to Critical"

**Managing child tasks:**
- "Break BACK-42 into child tasks for each auth provider"
- "Create a child task on FRONT-15 for writing unit tests"
- "Mark child task BACK-42A as Done"
- "List the child tasks for BACK-42"

**Managing sprints:**
- "Create a new sprint for BACK starting next Monday"
- "Add BACK-42 and BACK-43 to Sprint 3"
- "List the tickets in Sprint 3"
- "Mark Sprint 3 as active"
- "Remove BACK-42 from its sprint"

**Commenting on tickets:**
- "Add a comment to BACK-42 saying I've started working on this"
- "List the comments on FRONT-15"
- "Delete my last comment on BACK-42"

Claude Code can run these commands directly:

```bash
janet context --json                    # Discover available projects
janet ticket create "Bug: null pointer in auth" -p BACK --json
janet ticket update BACK-42 --status "In Progress"
janet ticket child-task create BACK-42 "Write tests" -s "To Do" --json
janet ticket child-task list BACK-42
janet sprint list -p BACK                              # List sprints
janet sprint add-ticket "Sprint 1" BACK-42 -p BACK     # Add to sprint
```

### Cursor

1. Sync tickets to your workspace:
```bash
janet sync
```

2. Add to `.cursorrules` or system prompt:
```
Project tickets are in ./janet-tickets/ as markdown files.
Use `janet ticket create` to create new tickets.
Use `janet ticket update` to update ticket status.
Use `janet ticket child-task create` to break tickets into sub-tasks.
Use `janet sprint list` to see sprints and manage them.
Use `janet context --json` to see available projects.
```

3. Use natural language prompts:

**Referencing tickets:**
- "Read ticket BACK-42 and help me implement the OAuth flow"
- "What bugs are currently open in the Frontend project?"

**Creating tickets:**
- "Create a ticket in BACK for refactoring the database layer, high priority"
- "Make a bug ticket for the memory leak we found, include the stack trace"

**Updating tickets:**
- "Update ticket FRONT-28 to In Review status"
- "Mark BACK-51 as complete"

### GitHub Copilot / Other Agents

Any AI agent with terminal access can use the CLI:

```bash
# Get context about the workspace
janet context --json

# Create tickets programmatically
janet ticket create "Title" -p PROJECT --json

# Update tickets
janet ticket update PROJ-123 --status "Done" --json

# Manage child tasks
janet ticket child-task create PROJ-123 "Sub-task" -s "To Do" --json
janet ticket child-task list PROJ-123 --json
janet ticket child-task update PROJ-123A --status "Done" --json

# Manage sprints
janet sprint list -p PROJ --json
janet sprint create "Sprint 1" -p PROJ --json
janet sprint add-ticket "Sprint 1" PROJ-123 -p PROJ --json
```

## Real-Time Sync

After syncing, the CLI stays connected to receive real-time updates:

```bash
janet sync
```

Output:
```
✓ Sync complete!
  Projects: 2
  Tickets: 42

Tickets saved to: ./janet-tickets

Watching for changes... (Ctrl+C to stop)

Watching 2 project(s) in My Org (Backend, Frontend)

   BACK-123 (status)
   BACK-124 (created)
   FRONT-45 (title, description)
```

Real-time updates sync changes whenever tickets are created, updated, or deleted—whether from the web UI, API, or other CLI sessions. Press Ctrl+C to stop watching.

## File Organization

Tickets are organized in a clear hierarchy:

```
janet-tickets/
├── AI_AGENT_INSTRUCTIONS.md     # Instructions for AI coding agents
└── My Organization/
    ├── Backend/
    │   ├── BACK-1.md
    │   ├── BACK-2.md
    │   └── BACK-42.md
    └── Frontend/
        ├── FRONT-1.md
        └── FRONT-15.md
```

## Markdown Format

Each ticket is exported with complete information:

```markdown
# PROJ-42: Add user authentication

## Metadata
- **Status:** In Progress
- **Priority:** High
- **Type:** Feature
- **Assignees:** John Doe, Jane Smith
- **Created:** Jan 07, 2026 10:30 AM
- **Updated:** Jan 07, 2026 02:45 PM
- **Labels:** backend, security

## Description

We need to implement OAuth authentication...

### Requirements
- Support multiple auth providers
- Handle token refresh
- Secure token storage

## Comments (2)

### John Doe - Jan 07, 2026 11:00 AM

Started working on the OAuth flow.

### Jane Smith - Jan 07, 2026 01:30 PM

Looks good! Add tests when done.
```

## Commands

### Authentication

```bash
janet login                     # Authenticate with Janet AI
janet logout                    # Clear credentials
janet auth status               # Show authentication status
```

### Syncing Tickets

```bash
janet sync                      # Sync and watch for real-time updates
janet sync --all                # Sync all projects and watch
janet sync --dir ./tickets      # Specify custom directory
janet sync --no-watch           # Sync once and exit (no real-time updates)
```

### Creating Tickets

```bash
janet ticket create "Title" --project PROJ           # Basic creation
janet ticket create "Title" -p PROJ --priority High  # With priority
janet ticket create "Title" -p PROJ --status "To Do" # With status
janet ticket create "Title" -p PROJ --type Bug       # With type
janet ticket create "Title" -p PROJ --assignee dev@example.com
janet ticket create "Title" -p PROJ --tag backend --tag urgent
janet ticket create "Title" -p PROJ --json           # JSON output for AI agents
cat desc.md | janet ticket create "Title" -p PROJ    # Pipe description

# Full ticket with all fields
janet ticket create "Implement OAuth2 authentication" \
  --project BACK \
  --description "Add Google and GitHub OAuth providers with token refresh" \
  --status "To Do" \
  --priority High \
  --type Feature \
  --assignee dev@example.com \
  --tag backend \
  --tag security \
  --tag authentication
```

### Updating Tickets

```bash
janet ticket update PROJ-123 --status "In Progress"  # Update status
janet ticket update PROJ-123 --priority Critical     # Update priority
janet ticket update PROJ-123 --title "New title"     # Update title
janet ticket update PROJ-123 --assignee dev@example.com
janet ticket update PROJ-123 --json                  # JSON output

# Update multiple fields at once
janet ticket update BACK-42 \
  --title "Fixed: OAuth authentication flow" \
  --description "Implemented token refresh and error handling" \
  --status "In Review" \
  --priority High \
  --assignee reviewer@example.com
```

### Managing Child Tasks

Child tasks break tickets into smaller sub-tasks. Each child task gets a letter suffix appended to the parent ticket key (e.g., `BACK-42A`, `BACK-42B`).

```bash
# Create a child task
janet ticket child-task create BACK-42 "Write unit tests" --status "To Do"
janet ticket child-task create BACK-42 "Review PR" -s "To Do" --priority High
janet ticket child-task create BACK-42 "Deploy" -s "To Do" -a dev@example.com
janet ticket child-task create BACK-42 "Task" -s "To Do" --due-date 2026-04-01

# List child tasks for a ticket
janet ticket child-task list BACK-42
janet ticket child-task list BACK-42 --json

# Update a child task
janet ticket child-task update BACK-42A --status "In Progress"
janet ticket child-task update BACK-42A --title "New title" --priority High
janet ticket child-task update BACK-42A --due-date 2026-04-15

# Delete a child task
janet ticket child-task delete BACK-42A          # Interactive confirmation
janet ticket child-task delete BACK-42A --yes    # Skip confirmation
```

### Listing Tickets

```bash
janet ticket list -p PROJ                           # All tickets in project
janet ticket list -p PROJ --status "To Do"          # Filter by status column
janet ticket list -p PROJ -s "In Progress" --json   # JSON output
```

### Positioning Tickets

Control ticket order within a status column.

```bash
# Move to top/bottom of column
janet ticket position top PROJ-1                    # Top of current status
janet ticket position top PROJ-1 -s "In Progress"  # Top of specific status
janet ticket position bottom PROJ-1                 # Bottom of current status

# Position relative to another ticket
janet ticket position after PROJ-1 PROJ-2           # Place PROJ-1 after PROJ-2
janet ticket position before PROJ-1 PROJ-2          # Place PROJ-1 before PROJ-2

# Reorder entire column
janet ticket position reorder PROJ-3 PROJ-1 PROJ-2 -s "To Do" -p PROJ

# Auto-sort a column by field
janet ticket position sort -s "To Do" -p PROJ --by priority
janet ticket position sort -s Backlog -p PROJ --by assignee
janet ticket position sort -s Backlog -p PROJ --by due-date
janet ticket position sort -s Backlog -p PROJ --by type
janet ticket position sort -s Backlog -p PROJ --by created --reverse
```

### Managing Sprints

Organize tickets into time-boxed sprints.

```bash
# List sprints
janet sprint list -p PROJ
janet sprint list -p PROJ --json

# Create a sprint
janet sprint create "Sprint 3" -p PROJ
janet sprint create "Sprint 3" -p PROJ -s 2026-03-20 -e 2026-04-03
janet sprint create "Sprint 3" -p PROJ -d "Q1 final sprint"

# Update a sprint
janet sprint update "Sprint 3" -p PROJ --status active
janet sprint update "Sprint 3" -p PROJ --name "Sprint 3 - Revised" --end 2026-04-10

# Add tickets to a sprint
janet sprint add-ticket "Sprint 3" PROJ-1 PROJ-2 PROJ-3 -p PROJ

# Remove tickets from a sprint
janet sprint remove-ticket "Sprint 3" PROJ-1 -p PROJ

# Reorder tickets within a sprint
janet sprint reorder "Sprint 3" PROJ-3 PROJ-1 PROJ-2 -s "To Do" -p PROJ

# List tickets in a sprint
janet sprint tickets "Sprint 3" -p PROJ
janet sprint tickets "Sprint 3" -p PROJ --json

# Create ticket directly in a sprint
janet ticket create "New task" -p PROJ --sprint "Sprint 3"

# Move existing ticket to sprint
janet ticket update PROJ-5 --sprint "Sprint 3"

# Remove ticket from its sprint
janet ticket update PROJ-5 --sprint ""
```

### Managing Sub-Tasks

Sub-tasks are nested under child tasks. Each sub-task gets a numeric suffix (e.g., `PROJ-123A-1`, `PROJ-123A-2`).

```bash
# Create a sub-task
janet ticket sub-task create PROJ-123A "Write unit tests" -s "To Do"
janet ticket sub-task create PROJ-123A "Review PR" --priority High -a dev@example.com

# List sub-tasks
janet ticket sub-task list PROJ-123A
janet ticket sub-task list PROJ-123A --json

# Update a sub-task
janet ticket sub-task update PROJ-123A-1 --status "Done"
janet ticket sub-task update PROJ-123A-1 --assignee user@example.com

# Delete a sub-task
janet ticket sub-task delete PROJ-123A-1 --yes
```

### Managing Comments

Add, list, edit, and delete comments on tickets.

```bash
# Add a comment
janet ticket comment add BACK-42 "Started working on the auth flow"
echo "Detailed comment" | janet ticket comment add BACK-42  # Pipe from stdin

# List comments
janet ticket comment list BACK-42
janet ticket comment list BACK-42 --json      # Get full comment IDs

# Edit a comment (get comment ID from list --json)
janet ticket comment edit BACK-42 <comment-id> "Updated comment"

# Delete a comment
janet ticket comment delete BACK-42 <comment-id>          # Interactive confirmation
janet ticket comment delete BACK-42 <comment-id> --yes    # Skip confirmation
```

### Context (for AI Agents)

```bash
janet context                   # Human-readable context
janet context --json            # JSON output for AI agents/scripts
```

### Organization Management

```bash
janet org list                  # List your organizations
janet org select <org-id>       # Switch organization
janet org current               # Show current organization
```

### Project Management

```bash
janet project list              # List projects in current org
```

### Status & Configuration

```bash
janet status                    # Show overall status
janet config show               # Display configuration
janet config path               # Show config file location
janet config reset              # Reset to defaults
janet --version                 # Show CLI version
janet update                    # Update CLI to latest version
```

## Configuration

The CLI stores configuration at:
- **macOS:** `~/Library/Application Support/janet-cli/config.json`
- **Linux:** `~/.config/janet-cli/config.json`
- **Windows:** `%APPDATA%\janet-cli\config.json`

## Requirements

- Python 3.8 or higher
- Janet AI account ([sign up](https://janet.ai))

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Links

- [Janet AI](https://janet.ai) - AI-native project management
- [Documentation](https://docs.janet.ai)
