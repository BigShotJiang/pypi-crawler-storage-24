"""Claude Context Vault — context vault extension for Claude Code."""

__version__ = "0.3.0"
