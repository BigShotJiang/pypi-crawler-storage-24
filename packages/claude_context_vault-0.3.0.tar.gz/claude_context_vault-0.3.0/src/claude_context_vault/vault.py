"""Context vault — file-based storage for archived conversation context."""

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import tiktoken


class ContextVault:
    """Manages storage and retrieval of archived context chunks."""

    def __init__(self, vault_root: Optional[Path] = None):
        self.vault_root = Path(vault_root) if vault_root else None
        if self.vault_root:
            self.vault_root.mkdir(parents=True, exist_ok=True)
        self._encoder = None

    @property
    def encoder(self):
        if self._encoder is None:
            self._encoder = tiktoken.get_encoding("cl100k_base")
        return self._encoder

    def _project_hash(self, project_path: str) -> str:
        return hashlib.sha256(project_path.encode()).hexdigest()[:12]

    def get_project_dir(self, project_path: str) -> Path:
        if self.vault_root:
            # Testing/override: use vault_root with project hash
            project_dir = self.vault_root / self._project_hash(project_path)
        else:
            # Default: store in the project's own .claude directory
            project_dir = Path(project_path) / ".claude" / "context-vault"
        project_dir.mkdir(parents=True, exist_ok=True)
        (project_dir / "chunks").mkdir(exist_ok=True)
        (project_dir / "summaries").mkdir(exist_ok=True)
        return project_dir

    def _next_chunk_id(self, project_path: str) -> str:
        manifest = self.get_manifest(project_path)
        existing = manifest.get("chunks", [])
        num = len(existing) + 1
        return f"chunk_{num:03d}"

    def _extract_keywords(self, text: str) -> list[str]:
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "can", "shall",
            "to", "of", "in", "for", "on", "with", "at", "by", "from",
            "as", "into", "through", "during", "before", "after", "and",
            "but", "or", "nor", "not", "so", "yet", "both", "either",
            "neither", "each", "every", "all", "any", "few", "more",
            "most", "other", "some", "such", "no", "only", "own", "same",
            "than", "too", "very", "just", "about", "above", "also",
            "this", "that", "these", "those", "i", "we", "you", "it",
            "they", "me", "him", "her", "us", "them", "my", "your",
            "his", "its", "our", "their", "what", "which", "who", "whom",
        }
        words = re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", text.lower())
        freq: dict[str, int] = {}
        for w in words:
            if w not in stop_words and len(w) > 2:
                freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq, key=lambda w: freq[w], reverse=True)
        return sorted_words[:20]

    def _generate_summary(self, content: str) -> str:
        lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
        if not lines:
            return ""
        if len(lines) <= 3:
            return " ".join(lines)
        summary_lines = []
        summary_lines.append(lines[0])
        mid = len(lines) // 2
        summary_lines.append(lines[mid])
        summary_lines.append(lines[-1])
        return " ".join(summary_lines)

    def _count_tokens(self, text: str) -> int:
        return len(self.encoder.encode(text))

    def get_manifest(self, project_path: str) -> dict:
        project_dir = self.get_project_dir(project_path)
        manifest_file = project_dir / "manifest.json"
        if manifest_file.exists():
            return json.loads(manifest_file.read_text())
        return {
            "project_path": project_path,
            "project_hash": self._project_hash(project_path),
            "created": datetime.now(timezone.utc).isoformat(),
            "chunks": [],
            "total_tokens_archived": 0,
        }

    def _save_manifest(self, project_path: str, manifest: dict) -> None:
        project_dir = self.get_project_dir(project_path)
        manifest_file = project_dir / "manifest.json"
        manifest_file.write_text(json.dumps(manifest, indent=2))

    def store(self, project_path: str, content: str, label: str) -> str:
        chunk_id = self._next_chunk_id(project_path)
        summary = self._generate_summary(content)
        keywords = self._extract_keywords(content)
        token_estimate = self._count_tokens(content)

        chunk_data = {
            "id": chunk_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "label": label,
            "content": content,
            "summary": summary,
            "keywords": keywords,
            "token_estimate": token_estimate,
            "project": project_path,
        }

        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        chunk_file.write_text(json.dumps(chunk_data, indent=2))

        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        summary_file.write_text(summary)

        manifest = self.get_manifest(project_path)
        manifest["chunks"].append(chunk_id)
        manifest["total_tokens_archived"] += token_estimate
        self._save_manifest(project_path, manifest)

        return chunk_id

    def get_chunk(self, project_path: str, chunk_id: str) -> Optional[dict]:
        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        if not chunk_file.exists():
            return None
        return json.loads(chunk_file.read_text())

    def list_chunks(self, project_path: str) -> list[dict]:
        project_dir = self.get_project_dir(project_path)
        chunks_dir = project_dir / "chunks"
        if not chunks_dir.exists():
            return []
        results = []
        for f in sorted(chunks_dir.glob("chunk_*.json")):
            data = json.loads(f.read_text())
            results.append({
                "id": data["id"],
                "label": data["label"],
                "summary": data["summary"],
                "timestamp": data["timestamp"],
                "token_estimate": data["token_estimate"],
            })
        return results

    def delete_chunk(self, project_path: str, chunk_id: str) -> bool:
        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        if not chunk_file.exists():
            return False
        chunk_data = json.loads(chunk_file.read_text())
        chunk_file.unlink()
        if summary_file.exists():
            summary_file.unlink()
        manifest = self.get_manifest(project_path)
        if chunk_id in manifest["chunks"]:
            manifest["chunks"].remove(chunk_id)
            manifest["total_tokens_archived"] -= chunk_data.get("token_estimate", 0)
            self._save_manifest(project_path, manifest)
        return True

    def search(self, project_path: str, query: str, limit: int = 5) -> list[dict]:
        chunks = self.list_chunks(project_path)
        if not chunks:
            return []
        query_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", query.lower()))
        scored = []
        for chunk_meta in chunks:
            full_chunk = self.get_chunk(project_path, chunk_meta["id"])
            if full_chunk is None:
                continue
            chunk_keywords = set(full_chunk.get("keywords", []))
            label_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", full_chunk["label"].lower()))
            summary_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", full_chunk["summary"].lower()))
            searchable = chunk_keywords | label_words | summary_words
            overlap = query_words & searchable
            if overlap:
                score = len(overlap) / len(query_words) if query_words else 0
                scored.append({
                    "id": full_chunk["id"],
                    "label": full_chunk["label"],
                    "summary": full_chunk["summary"],
                    "timestamp": full_chunk["timestamp"],
                    "token_estimate": full_chunk["token_estimate"],
                    "relevance": round(score, 2),
                })
        scored.sort(key=lambda x: x["relevance"], reverse=True)
        return scored[:limit]
