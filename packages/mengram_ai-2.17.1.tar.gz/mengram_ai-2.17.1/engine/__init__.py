"""Mengram Engine — core components."""
