"""Tests for Docketeer's Docket dependencies."""

from collections.abc import Iterator
from datetime import timedelta
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import pytest

from docketeer.dependencies import (
    CurrentBrain,
    CurrentChatClient,
    CurrentDocket,
    CurrentExecutor,
    CurrentInferenceBackend,
    CurrentSearch,
    CurrentVault,
    EnvironmentInt,
    EnvironmentStr,
    EnvironmentTimedelta,
    WorkspacePath,
    _brain_var,
    _client_var,
    _CurrentBrain,
    _CurrentChatClient,
    _CurrentDocket,
    _CurrentExecutor,
    _CurrentInferenceBackend,
    _CurrentSearch,
    _CurrentVault,
    _docket_var,
    _EnvironmentInt,
    _EnvironmentStr,
    _EnvironmentTimedelta,
    _executor_var,
    _search_var,
    _vault_var,
    _WorkspacePath,
    set_brain,
    set_client,
    set_docket,
    set_executor,
    set_search,
    set_vault,
)

# --- Context var fixtures ---


@pytest.fixture()
def brain_var() -> Iterator[AsyncMock]:
    brain = AsyncMock()
    token = _brain_var.set(brain)
    yield brain
    _brain_var.reset(token)


@pytest.fixture()
def client_var() -> Iterator[AsyncMock]:
    client = AsyncMock()
    token = _client_var.set(client)
    yield client
    _client_var.reset(token)


@pytest.fixture()
def executor_var() -> Iterator[AsyncMock]:
    executor = AsyncMock()
    token = _executor_var.set(executor)
    yield executor
    _executor_var.reset(token)


@pytest.fixture()
def vault_var() -> Iterator[AsyncMock]:
    vault = AsyncMock()
    token = _vault_var.set(vault)
    yield vault
    _vault_var.reset(token)


@pytest.fixture()
def search_var() -> Iterator[AsyncMock]:
    search = AsyncMock()
    token = _search_var.set(search)
    yield search
    _search_var.reset(token)


@pytest.fixture()
def docket_var() -> Iterator[AsyncMock]:
    docket = AsyncMock()
    token = _docket_var.set(docket)
    yield docket
    _docket_var.reset(token)


# --- CurrentBrain ---


async def test_current_brain(brain_var: AsyncMock):
    dep = _CurrentBrain()
    assert await dep.__aenter__() is brain_var


async def test_current_brain_factory_returns_dependency():
    result = CurrentBrain()
    assert isinstance(result, _CurrentBrain)


def test_set_brain():
    brain = AsyncMock()
    set_brain(brain)
    assert _brain_var.get() is brain


# --- CurrentChatClient ---


async def test_current_chat_client(client_var: AsyncMock):
    dep = _CurrentChatClient()
    assert await dep.__aenter__() is client_var


async def test_current_chat_client_factory_returns_dependency():
    result = CurrentChatClient()
    assert isinstance(result, _CurrentChatClient)


def test_set_client():
    client = AsyncMock()
    set_client(client)
    assert _client_var.get() is client


# --- WorkspacePath ---


async def test_workspace_path(tmp_path: Path):
    with patch.dict("os.environ", {"DOCKETEER_DATA_DIR": str(tmp_path)}):
        dep = _WorkspacePath()
        result = await dep.__aenter__()
    assert result == tmp_path / "memory"


async def test_workspace_path_factory_returns_dependency():
    result = WorkspacePath()
    assert isinstance(result, _WorkspacePath)


# --- EnvironmentStr ---


async def test_environment_str_default():
    dep = _EnvironmentStr("TEST_VAR", "fallback")
    with patch.dict("os.environ", {}, clear=False):
        result = await dep.__aenter__()
    assert result == "fallback"


async def test_environment_str_from_env():
    dep = _EnvironmentStr("TEST_VAR", "fallback")
    with patch.dict("os.environ", {"DOCKETEER_TEST_VAR": "from_env"}):
        result = await dep.__aenter__()
    assert result == "from_env"


async def test_environment_str_required():
    dep = _EnvironmentStr("REQUIRED_VAR")
    with patch.dict("os.environ", {"DOCKETEER_REQUIRED_VAR": "found"}):
        result = await dep.__aenter__()
    assert result == "found"


async def test_environment_str_required_missing():
    dep = _EnvironmentStr("MISSING_VAR")
    with patch.dict("os.environ", {}, clear=True):
        with pytest.raises(KeyError):
            await dep.__aenter__()


def test_environment_str_factory():
    result = EnvironmentStr("X", "default")
    assert isinstance(result, _EnvironmentStr)


def test_environment_str_factory_no_default():
    result = EnvironmentStr("X")
    assert isinstance(result, _EnvironmentStr)


# --- EnvironmentInt ---


async def test_environment_int_default():
    dep = _EnvironmentInt("COUNT", 42)
    with patch.dict("os.environ", {}, clear=False):
        result = await dep.__aenter__()
    assert result == 42


async def test_environment_int_from_env():
    dep = _EnvironmentInt("COUNT", 42)
    with patch.dict("os.environ", {"DOCKETEER_COUNT": "99"}):
        result = await dep.__aenter__()
    assert result == 99


def test_environment_int_factory():
    result = EnvironmentInt("X", 10)
    assert isinstance(result, _EnvironmentInt)


# --- EnvironmentTimedelta ---


async def test_environment_timedelta_default():
    dep = _EnvironmentTimedelta("INTERVAL", timedelta(minutes=5))
    with patch.dict("os.environ", {}, clear=False):
        result = await dep.__aenter__()
    assert result == timedelta(minutes=5)


async def test_environment_timedelta_from_env():
    dep = _EnvironmentTimedelta("INTERVAL", timedelta(minutes=5))
    with patch.dict("os.environ", {"DOCKETEER_INTERVAL": "PT10M"}):
        result = await dep.__aenter__()
    assert result == timedelta(minutes=10)


def test_environment_timedelta_factory():
    result = EnvironmentTimedelta("X", timedelta(hours=1))
    assert isinstance(result, _EnvironmentTimedelta)


# --- CurrentExecutor ---


async def test_current_executor(executor_var: AsyncMock):
    dep = _CurrentExecutor()
    assert await dep.__aenter__() is executor_var


async def test_current_executor_factory_returns_dependency():
    result = CurrentExecutor()
    assert isinstance(result, _CurrentExecutor)


def test_set_executor():
    executor = AsyncMock()
    set_executor(executor)
    assert _executor_var.get() is executor


# --- CurrentVault ---


async def test_current_vault(vault_var: AsyncMock):
    dep = _CurrentVault()
    assert await dep.__aenter__() is vault_var


async def test_current_vault_factory_returns_dependency():
    result = CurrentVault()
    assert isinstance(result, _CurrentVault)


def test_set_vault():
    vault = AsyncMock()
    set_vault(vault)
    assert _vault_var.get() is vault


# --- CurrentSearch ---


async def test_current_search(search_var: AsyncMock):
    dep = _CurrentSearch()
    assert await dep.__aenter__() is search_var


async def test_current_search_factory_returns_dependency():
    result = CurrentSearch()
    assert isinstance(result, _CurrentSearch)


def test_set_search():
    search = AsyncMock()
    set_search(search)
    assert _search_var.get() is search


# --- CurrentInferenceBackend ---


async def test_current_inference_backend(executor_var: AsyncMock):
    backend = AsyncMock()
    factory = Mock(return_value=backend)
    ep = Mock()
    ep.load.return_value = factory
    with patch("docketeer.dependencies.discover_one", return_value=ep):
        dep = _CurrentInferenceBackend()
        assert await dep.__aenter__() is backend
    factory.assert_called_once_with(executor=executor_var)


async def test_current_inference_backend_no_plugin():
    with patch("docketeer.dependencies.discover_one", return_value=None):
        dep = _CurrentInferenceBackend()
        assert await dep.__aenter__() is None


def test_current_inference_backend_factory():
    result = CurrentInferenceBackend()
    assert isinstance(result, _CurrentInferenceBackend)


# --- CurrentDocket ---


async def test_current_docket(docket_var: AsyncMock):
    dep = _CurrentDocket()
    assert await dep.__aenter__() is docket_var


async def test_current_docket_factory_returns_dependency():
    result = CurrentDocket()
    assert isinstance(result, _CurrentDocket)


def test_set_docket():
    docket = AsyncMock()
    set_docket(docket)
    assert _docket_var.get() is docket
