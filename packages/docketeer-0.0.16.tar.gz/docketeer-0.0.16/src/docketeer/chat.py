"""Chat client interface for the Docketeer agent."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

from docketeer.plugins import discover_one

if TYPE_CHECKING:
    from docketeer.tools import ToolContext

log = logging.getLogger(__name__)


@dataclass
class Attachment:
    url: str
    media_type: str
    title: str = ""


@dataclass
class RoomMessage:
    """A message from room history, with full context and attachment references."""

    message_id: str
    timestamp: datetime
    username: str
    display_name: str
    text: str
    attachments: list[Attachment] | None = None
    thread_id: str = ""


class RoomKind(Enum):
    public = "public"
    private = "private"
    group = "group"
    direct = "direct"

    @property
    def is_dm(self) -> bool:
        return self in (RoomKind.group, RoomKind.direct)


@dataclass
class RoomInfo:
    """Metadata about the room the agent is operating in."""

    room_id: str
    kind: RoomKind
    members: list[str]
    name: str = ""


@dataclass
class IncomingMessage:
    message_id: str
    user_id: str
    username: str
    display_name: str
    text: str
    room_id: str
    kind: RoomKind
    timestamp: datetime | None = None
    attachments: list[Attachment] | None = None
    thread_id: str = ""
    is_own: bool = False


OnHistoryCallback = Callable[["RoomInfo", list["RoomMessage"]], Awaitable[None]]


class ChatClient(ABC):
    """Abstract chat client interface for testing and alternative backends."""

    username: str
    user_id: str
    _on_message_sent: Callable[[str, str], Awaitable[None]] | None = None

    @abstractmethod
    async def __aenter__(self) -> ChatClient: ...

    @abstractmethod
    async def __aexit__(self, *exc: object) -> None: ...

    @abstractmethod
    def incoming_messages(
        self,
        on_history: OnHistoryCallback | None = None,
    ) -> AsyncGenerator[IncomingMessage, None]: ...

    @abstractmethod
    async def send_message(
        self,
        room_id: str,
        text: str,
        attachments: list[dict[str, Any]] | None = None,
        *,
        thread_id: str = "",
    ) -> None: ...

    @abstractmethod
    async def upload_file(
        self, room_id: str, file_path: str, message: str = "", *, thread_id: str = ""
    ) -> None: ...

    @abstractmethod
    async def fetch_attachment(self, url: str) -> bytes: ...

    @abstractmethod
    async def fetch_message(self, message_id: str) -> dict[str, Any] | None: ...

    @abstractmethod
    async def fetch_messages(
        self,
        room_id: str,
        *,
        before: datetime | None = None,
        after: datetime | None = None,
        count: int = 50,
    ) -> list[RoomMessage]: ...

    @abstractmethod
    async def list_rooms(self) -> list[RoomInfo]: ...

    @abstractmethod
    async def set_status(self, status: str, message: str = "") -> None: ...

    @abstractmethod
    async def send_typing(self, room_id: str, typing: bool) -> None: ...

    @abstractmethod
    async def react(self, message_id: str, emoji: str) -> None: ...

    @abstractmethod
    async def unreact(self, message_id: str, emoji: str) -> None: ...

    async def room_slug(self, room_id: str) -> str:
        """Return a filesystem-friendly slug for the room. Override for rich data."""
        return ""

    async def room_context(self, room_id: str, username: str) -> str:
        """Return per-room context for the system prompt. Override for rich data."""
        return ""


RegisterToolsFn = Callable[["ChatClient", "ToolContext"], None]


def _noop_register_tools(_client: ChatClient, _ctx: ToolContext) -> None:
    pass


def discover_chat_backend() -> tuple[ChatClient, RegisterToolsFn]:
    """Discover the chat backend via entry_points."""
    ep = discover_one("docketeer.chat", "CHAT")
    if ep is None:
        raise RuntimeError("No chat backend installed")
    module = ep.load()
    client = module.create_client()
    register_fn = getattr(module, "register_tools", _noop_register_tools)
    return client, register_fn
