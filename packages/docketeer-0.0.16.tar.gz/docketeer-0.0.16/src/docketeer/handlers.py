"""Message handling: processing loop, content building, response delivery."""

import asyncio
import logging

from docketeer.brain import APOLOGY, CHAT_MODEL, Brain, ProcessCallbacks
from docketeer.brain.backend import BackendAuthError
from docketeer.chat import ChatClient, IncomingMessage, RoomInfo, RoomMessage
from docketeer.prompt import BrainResponse, MessageContent
from docketeer.tools import registry

log = logging.getLogger(__name__)


async def process_messages(client: ChatClient, brain: Brain) -> None:
    """Process incoming messages, interrupting long-running tool loops on new arrivals."""

    async def _on_history(room: RoomInfo, messages: list[RoomMessage]) -> None:
        brain.load_history(room.room_id, messages)

    msg_iter = client.incoming_messages(on_history=_on_history).__aiter__()
    next_msg = asyncio.create_task(anext(msg_iter, None))

    while True:
        msg = await next_msg
        if msg is None:
            break

        if msg.is_own:
            await brain.record_own_message(msg.room_id, msg.text)
            next_msg = asyncio.create_task(anext(msg_iter, None))
            continue

        interrupted = asyncio.Event()
        handle_task = asyncio.create_task(
            handle_message(client, brain, msg, interrupted=interrupted)
        )
        next_msg = asyncio.create_task(anext(msg_iter, None))

        done, _ = await asyncio.wait(
            {handle_task, next_msg}, return_when=asyncio.FIRST_COMPLETED
        )

        if handle_task not in done:
            interrupted.set()
            await handle_task

        _check_handle_result(handle_task)


def _check_handle_result(task: asyncio.Task[None]) -> None:
    """Propagate fatal auth errors, log everything else."""
    exc = task.exception()
    if exc is None:
        return
    if isinstance(exc, BackendAuthError):
        raise exc
    log.exception("Unhandled error processing message", exc_info=exc)


async def handle_message(
    client: ChatClient,
    brain: Brain,
    msg: IncomingMessage,
    interrupted: asyncio.Event | None = None,
) -> None:
    """Handle an incoming message."""
    log.info("Message from %s in %s: %s", msg.username, msg.room_id, msg.text[:50])

    # Load history if this is a new room
    if not brain.has_history(msg.room_id):
        log.info("  New room, loading history...")
        history = await client.fetch_messages(msg.room_id)
        count = brain.load_history(msg.room_id, history)
        log.info("    Loaded %d messages", count)

    content = await build_content(client, msg)
    room_ctx = await client.room_context(msg.room_id, msg.username)
    slug = await client.room_slug(msg.room_id)

    thread_id = msg.thread_id
    tool_emojis: set[str] = set()

    async def _on_tool_start(tool_name: str) -> None:
        await client.send_typing(msg.room_id, False)
        emoji = registry.emoji_for(tool_name)
        log.debug("on_tool_start: tool_name=%r, emoji=%r", tool_name, emoji)
        if emoji and emoji not in tool_emojis:
            tool_emojis.add(emoji)
            await client.react(msg.message_id, emoji)

    callbacks = ProcessCallbacks(
        on_first_text=lambda: client.send_typing(msg.room_id, True),
        on_text=lambda text: client.send_message(
            msg.room_id, text, thread_id=thread_id
        ),
        on_tool_start=_on_tool_start,
        interrupted=interrupted,
    )

    await client.react(msg.message_id, ":brain:")
    try:
        response = await brain.process(
            msg.room_id,
            content,
            callbacks=callbacks,
            tier=CHAT_MODEL,
            room_context=room_ctx,
            room_slug=slug,
        )
    except BackendAuthError:
        raise
    except Exception:
        log.exception(
            "Error processing message from %s in %s", msg.username, msg.room_id
        )
        response = BrainResponse(text=APOLOGY)
    finally:
        await client.unreact(msg.message_id, ":brain:")
        for emoji in tool_emojis:
            await client.unreact(msg.message_id, emoji)
        await client.send_typing(msg.room_id, False)

    try:
        await send_response(client, msg.room_id, response, thread_id=thread_id)
    except Exception:
        log.exception("Failed to send response to %s", msg.room_id)


async def build_content(client: ChatClient, msg: IncomingMessage) -> MessageContent:
    """Build MessageContent from an IncomingMessage, fetching any attachments."""
    images = []

    if msg.attachments:
        for att in msg.attachments:
            try:
                data = await client.fetch_attachment(att.url)
                images.append((att.media_type, data))
            except Exception as e:
                log.warning("Failed to fetch attachment %s: %s", att.url, e)

    return MessageContent(
        username=msg.username,
        message_id=msg.message_id,
        timestamp=msg.timestamp,
        text=msg.text,
        thread_id=msg.thread_id,
        images=images,
    )


async def send_response(
    client: ChatClient, room_id: str, response: BrainResponse, *, thread_id: str = ""
) -> None:
    """Send response to chat (skips empty responses from tool-only turns)."""
    if response.text:
        await client.send_message(room_id, response.text, thread_id=thread_id)
