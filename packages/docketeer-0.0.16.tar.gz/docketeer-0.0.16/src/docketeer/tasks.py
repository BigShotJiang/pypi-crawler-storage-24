"""Docket task handlers — bridges scheduled tasks to the brain."""

import logging
import re
from datetime import datetime, timedelta
from typing import Annotated
from zoneinfo import ZoneInfo

from croniter import croniter
from docket import Logged
from docket.dependencies import Perpetual, TaskKey

from docketeer import environment
from docketeer.brain import APOLOGY, CHAT_MODEL, Brain
from docketeer.brain.backend import BackendAuthError
from docketeer.chat import ChatClient
from docketeer.dependencies import CurrentBrain, CurrentChatClient
from docketeer.prompt import BrainResponse, MessageContent
from docketeer.tools import safe_path

log = logging.getLogger(__name__)

_consecutive_failures: dict[str, int] = {}

_ISO_DURATION_RE = re.compile(
    r"^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$",
    re.IGNORECASE,
)


def parse_every(every: str) -> timedelta | None:
    """Parse an ISO 8601 duration string into a timedelta.

    Returns None if the string isn't a valid ISO 8601 duration, meaning the
    caller should treat it as a cron expression instead.
    """
    m = _ISO_DURATION_RE.match(every)
    if not m or not any(m.groups()):
        return None
    days = int(m.group(1) or 0)
    hours = int(m.group(2) or 0)
    minutes = int(m.group(3) or 0)
    seconds = int(m.group(4) or 0)
    return timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)


async def nudge(
    prompt_file: Annotated[str, Logged],
    room_id: Annotated[str, Logged] = "",
    thread_id: Annotated[str, Logged] = "",
    tier: Annotated[str, Logged] = "",
    brain: Brain = CurrentBrain(),
    client: ChatClient = CurrentChatClient(),
    task_key: str = TaskKey(),
) -> None:
    """Nudge the brain with a prompt from a file.

    The prompt is read from the workspace at prompt_file (relative to workspace root).
    This allows you to write longer prompts, review and edit them, and discuss them
    with the user without needing to modify the scheduled task.
    """
    resolved = safe_path(environment.WORKSPACE_PATH, prompt_file)
    prompt = resolved.read_text()

    if not prompt:
        log.warning("Prompt file is empty: %s", prompt_file)
        return

    now = datetime.now().astimezone()
    content = MessageContent(
        username="system", timestamp=now, text=prompt, thread_id=thread_id
    )

    context_room = room_id or f"__task__:{task_key}"
    key = f"nudge:{task_key}"
    try:
        response: BrainResponse = await brain.process(
            context_room, content, tier=tier or CHAT_MODEL
        )
    except BackendAuthError:
        raise
    except Exception:
        _consecutive_failures[key] = _consecutive_failures.get(key, 0) + 1
        level = logging.ERROR if _consecutive_failures[key] >= 3 else logging.WARNING
        log.log(
            level,
            "Error processing nudge task (attempt %d)",
            _consecutive_failures[key],
            exc_info=True,
        )
        if room_id:
            await client.send_message(room_id, APOLOGY, thread_id=thread_id)
        return
    _consecutive_failures.pop(key, None)

    if room_id and response.text:
        await client.send_message(room_id, response.text, thread_id=thread_id)


async def nudge_every(
    prompt_file: Annotated[str, Logged],
    every: Annotated[str, Logged] = "",
    timezone: Annotated[str, Logged] = "",
    room_id: Annotated[str, Logged] = "",
    thread_id: Annotated[str, Logged] = "",
    tier: Annotated[str, Logged] = "",
    perpetual: Perpetual = Perpetual(),
    brain: Brain = CurrentBrain(),
    client: ChatClient = CurrentChatClient(),
    task_key: str = TaskKey(),
) -> None:
    """Recurring nudge — fires on a fixed interval or cron schedule.

    The prompt is read from the workspace at prompt_file (relative to workspace root).
    This allows you to write longer prompts, review and edit them, and discuss them
    with the user without needing to modify the scheduled task. The prompt file is
    re-read each time the task fires, so you can modify it between runs.
    """
    resolved = safe_path(environment.WORKSPACE_PATH, prompt_file)
    prompt = resolved.read_text()

    if not prompt:
        log.warning("Prompt file is empty: %s", prompt_file)
        return

    duration = parse_every(every)

    now = datetime.now().astimezone()
    content = MessageContent(
        username="system", timestamp=now, text=prompt, thread_id=thread_id
    )

    context_room = room_id or f"__task__:{task_key}"
    key = f"nudge_every:{task_key}"
    try:
        response: BrainResponse = await brain.process(
            context_room, content, tier=tier or CHAT_MODEL
        )
    except BackendAuthError:
        raise
    except Exception:
        _consecutive_failures[key] = _consecutive_failures.get(key, 0) + 1
        level = logging.ERROR if _consecutive_failures[key] >= 3 else logging.WARNING
        log.log(
            level,
            "Error processing recurring nudge task (attempt %d)",
            _consecutive_failures[key],
            exc_info=True,
        )
        if room_id:
            await client.send_message(room_id, APOLOGY, thread_id=thread_id)
    else:
        _consecutive_failures.pop(key, None)
        if room_id and response.text:
            await client.send_message(room_id, response.text, thread_id=thread_id)

    if duration:
        perpetual.after(duration)
    else:
        tz = ZoneInfo(timezone) if timezone else environment.local_timezone()
        now_in_tz = datetime.now(tz)
        next_time = croniter(every, now_in_tz).get_next(datetime)
        perpetual.at(next_time)


docketeer_tasks = [nudge, nudge_every]
