"""System prompt construction and shared message types."""

import importlib.resources
import logging
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from docketeer.plugins import discover_all

log = logging.getLogger(__name__)


@dataclass
class CacheControl:
    """Prompt caching control."""

    ttl: Literal["5m", "1h"] = "5m"

    def to_dict(self) -> dict[str, str]:
        return {"type": "ephemeral", "ttl": self.ttl}


@dataclass
class SystemBlock:
    """A text block in the system prompt."""

    text: str
    cache_control: CacheControl | None = None

    def to_dict(self) -> dict[str, str | dict]:
        """Serialize to a dictionary representation."""
        d = {"type": "text", "text": self.text}
        if self.cache_control:
            d["cache_control"] = self.cache_control.to_dict()
        return d


_prompt_providers: list[Callable[[Path], list[SystemBlock]]] | None = None


def _load_prompt_providers() -> list[Callable[[Path], list[SystemBlock]]]:
    global _prompt_providers
    if _prompt_providers is None:
        _prompt_providers = discover_all("docketeer.prompt")
    return _prompt_providers


@dataclass
class MessageContent:
    """Content to send to the inference backend — text and/or images."""

    username: str
    message_id: str = ""
    timestamp: datetime | None = None
    text: str = ""
    thread_id: str = ""
    images: list[tuple[str, bytes]] = field(default_factory=list)


def format_message_time(timestamp: datetime, previous: datetime | None = None) -> str:
    """Format a message timestamp as absolute time or delta from previous.

    No previous → absolute: 2026-02-06 10:00
    With previous → delta: +30s, +5m, +2h 15m, +1d 3h
    Two units max, trailing zero components dropped, negative deltas clamped to +0s.
    """
    if previous is None:
        return timestamp.astimezone().isoformat(timespec="seconds")

    total_seconds = int((timestamp - previous).total_seconds())
    if total_seconds < 0:
        total_seconds = 0

    days, remainder = divmod(total_seconds, 86_400)
    hours, remainder = divmod(remainder, 3_600)
    minutes, seconds = divmod(remainder, 60)

    parts: list[str] = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds or not parts:
        parts.append(f"{seconds}s")

    return "+" + " ".join(parts[:2])


@dataclass
class BrainResponse:
    """Response from Brain."""

    text: str


def ensure_template(
    workspace: Path, filename: str, *, package: str = "docketeer"
) -> None:
    """Copy a template from a package to the workspace if it doesn't exist."""
    stem, ext = filename.rsplit(".", 1)
    target = workspace / f"{stem.upper()}.{ext}"
    if target.exists():
        return
    source = importlib.resources.files(package).joinpath(filename)
    target.write_text(source.read_text())
    log.info("Copied %s template to %s", filename, target)


def build_system_blocks(workspace: Path) -> list[SystemBlock]:
    """Build system prompt from prompt provider plugins.

    All content here is static between requests so that tools + system form
    a fully cacheable prefix. Dynamic per-request context (time, room, person)
    goes into the user message via _build_content().
    """
    blocks: list[SystemBlock] = []

    for provider in _load_prompt_providers():
        try:
            blocks.extend(provider(workspace))
        except Exception:
            log.warning("Prompt provider %s failed", provider, exc_info=True)

    if blocks:
        blocks[-1].cache_control = CacheControl()

    return blocks


def extract_text(content: str | Iterable) -> str:
    """Pull plain text from message content, skipping images and tool results."""
    if isinstance(content, str):
        return content
    parts = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                parts.append(block["text"])
            elif block.get("type") == "tool_result":
                result = block.get("content", "")
                if isinstance(result, str) and result:
                    parts.append(f"[tool result: {result[:200]}]")
        elif isinstance(block, TextBlockParam):
            parts.append(block.text)
    return "\n".join(parts)


@dataclass
class TextBlockParam:
    """A text block."""

    text: str
    type: Literal["text"] = "text"

    def to_dict(self) -> dict[str, str]:
        return {"type": self.type, "text": self.text}


@dataclass
class Base64ImageSourceParam:
    """Base64 encoded image source."""

    media_type: str
    data: str
    type: Literal["base64"] = "base64"

    def to_dict(self) -> dict[str, str]:
        return {"type": self.type, "media_type": self.media_type, "data": self.data}


@dataclass
class ImageBlockParam:
    """An image block."""

    source: Base64ImageSourceParam
    type: Literal["image"] = "image"

    def to_dict(self) -> dict[str, str | dict[str, str]]:
        return {"type": self.type, "source": self.source.to_dict()}


ContentBlockParam = TextBlockParam | ImageBlockParam


@dataclass
class MessageParam:
    """A message parameter for Chat API."""

    role: Literal["user", "assistant", "system", "tool"]
    content: str | list[Any]
    tool_call_id: str | None = None
    tool_calls: list[dict] | None = None

    def to_dict(self) -> dict:
        """Convert to a dictionary for API usage."""
        result: dict = {"role": self.role}
        if self.tool_call_id:
            result["tool_call_id"] = self.tool_call_id
        if self.tool_calls:
            result["tool_calls"] = self.tool_calls
        if isinstance(self.content, str):
            result["content"] = self.content
        elif isinstance(self.content, list):
            serialized_content = []
            for block in self.content:
                if isinstance(block, (TextBlockParam, ImageBlockParam)):
                    serialized_content.append(block.to_dict())
                elif isinstance(block, dict):
                    serialized_content.append(block)
                else:
                    serialized_content.append({"type": "text", "text": str(block)})
            result["content"] = serialized_content
        else:
            result["content"] = self.content
        return result
