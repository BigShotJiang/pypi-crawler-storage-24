# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Base experiment-related class definitions.
"""

import json
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable
import time
from pydantic import BaseModel
import uuid

from ..utils import LoggerManager
from ..utils.types import MachineType, ExperimentState
logger = LoggerManager.get_logger(name='experiment')

class ExperimentResult:
    """Base class for experiment results."""
    def __init__(self):
        pass

    @abstractmethod
    def append_graph(self, lines: Dict[str, Any]):
        """Append Line Graph"""
        pass

    @abstractmethod
    def get_result(self) -> Dict[str, Any]:
        """Get experiment result.

        This abstract method must be implemented by all experiment subclasses.
        It should return a dictionary containing all experiment results.

        Returns:
            Dict[str, Any]: Dictionary containing experiment results.

        Raises:
            NotImplementedError: If the subclass does not implement this method.
        """
        raise NotImplementedError("get_result method must be implemented in subclass")

class ExperimentParameter(BaseModel):
    """Base class for experiment parameters."""        
    @abstractmethod
    def get_parameters(self) -> Dict[str, Any]:
        """Get experiment parameters.

        This abstract method must be implemented by all experiment subclasses.
        It should return a dictionary containing all experiment parameters
        required for execution.

        Returns:
            Dict[str, Any]: Dictionary containing experiment parameters.

        Raises:
            NotImplementedError: If the subclass does not implement this method.
        """
        raise NotImplementedError("get_parameters method must be implemented in subclass")
    
    class Config:
        validate_assignment = True

class Experiment(ABC):
    """Base class for experiments."""
    def __init__(self, parameters: Optional[ExperimentParameter] = None):
        self.experiment_type = ""
        self.id = str(uuid.uuid4())
        self.name = ""
        self.step = ""
        self.state = "PENDING"
        self.created_at = int(time.time() * 1000)  # Convert to millisecond timestamp
        self.started_at = None
        self.completed_at = None
        self.parameters = parameters
        self.graph_data = []
        self.result = ExperimentResult()

    def register_handler(self, handler_map: dict) -> None:
        """Register message handlers for this experiment."""
        handler_map[MachineType.MSG_RES_ADD_EXP_TASK_RES] = self.handle_exp_added
        handler_map[MachineType.MSG_POST_EXP_STARTED] = self.handle_exp_started
        handler_map[MachineType.MSG_POST_EXP_TERMINATED] = self.handle_exp_terminated
        handler_map[MachineType.MSG_POST_EXP_REMOVED] = self.handle_exp_removed
        handler_map[MachineType.MSG_POST_EXP_STEP_CHANGED] = self.handle_exp_step_changed
        handler_map[MachineType.MSG_POST_EXP_DATA_UPDATED] = self.handle_exp_data_updated
        handler_map[MachineType.MSG_POST_EXP_CHART_UPDATED_STARTED] = self.handle_exp_chart_data_updated_started
        handler_map[MachineType.MSG_POST_EXP_CHART_UPDATED] = self.handle_exp_chart_data_updated
        handler_map[MachineType.MSG_POST_EXP_CHART_UPDATED_FINISHED] = self.handle_exp_chart_data_updated_finished
        handler_map[MachineType.MSG_POST_EXP_FINISHED] = self.handle_exp_finished
    
    @abstractmethod
    def get_experiment_parameter(self) -> Dict[str, Any]:
        """
        Get experiment parameters.

        Returns:
            Dict[str, Any]: Experiment parameters.
        """
        raise NotImplementedError("get_experiment_parameter method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_added(self, data: Dict[str, Any]) -> None:
        """Handle experiment addition."""
        raise NotImplementedError("handle_exp_added method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_started(self, data: Dict[str, Any]) -> None:
        """Handle experiment start."""
        raise NotImplementedError("handle_exp_started method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_terminated(self, data: Dict[str, Any]) -> None:
        """Handle experiment termination."""
        raise NotImplementedError("handle_exp_terminated method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_removed(self, data: Dict[str, Any]) -> None:
        """Handle experiment removal."""
        raise NotImplementedError("handle_exp_removed method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_step_changed(self, data: Dict[str, Any]) -> None:
        """Handle experiment step changes."""
        raise NotImplementedError("handle_exp_step_changed method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_data_updated(self, data: Dict[str, Any]) -> None:
        """Handle experiment data updates."""
        raise NotImplementedError("handle_exp_data_updated method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_chart_data_updated_started(self, data: Dict[str, Any]) -> None:
        """Handle start of experiment chart data updates."""
        raise NotImplementedError("handle_exp_chart_data_updated_started method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_chart_data_updated(self, data: Dict[str, Any]) -> None:
        """Handle experiment chart data updates."""
        raise NotImplementedError("handle_exp_chart_data_updated method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_chart_data_updated_finished(self) -> None:
        """Handle completion of experiment chart data updates."""
        raise NotImplementedError("handle_exp_chart_data_updated_finished method must be implemented in subclass")
    
    @abstractmethod
    def handle_exp_finished(self, data: Dict[str, Any]) -> None:
        """Handle experiment completion."""
        raise NotImplementedError("handle_exp_finished method must be implemented in subclass")
    
    def get_status(self) -> str:
        """Get experiment status."""
        raise NotImplementedError("get_status method must be implemented in subclass")
    
    def get_result(self) -> Dict[str, Any]:
        """Get experiment result."""
        raise NotImplementedError("get_result method must be implemented in subclass")
    