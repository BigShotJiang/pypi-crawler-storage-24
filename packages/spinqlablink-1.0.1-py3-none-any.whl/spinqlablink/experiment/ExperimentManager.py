# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Experiment manager.

Responsible for registering experiments, managing their execution,
waiting for completion, and retrieving results.
"""

from typing import Type
import importlib
import time

from ..utils import LoggerManager
from .experiment_base import Experiment, ExperimentParameter, ExperimentState
from ..utils.types import ExperimentType

# Create logger
logger = LoggerManager.get_logger(name='experiment_manager')

class ExperimentManager:
    """Manager for experiment lifecycle and dispatch."""
    def __init__(self):
        self.EXPERIMENT_TYPE_MAP = {
            ExperimentType.NMR_PHENOMENON_AND_SIGNAL: ('spinqlablink.experiment.exp_pulse', 'ExpPulse', 'ExpPulseParameters'),
            ExperimentType.RABI_OSCILLATIONS: ('spinqlablink.experiment.exp_rabi', 'ExpRabi', 'ExpRabiParameters'),
            ExperimentType.QUANTUM_BIT: ('spinqlablink.experiment.exp_qubit', 'ExpQubit', 'ExpQubitParameters'),
            ExperimentType.QUANTUM_DECOHERENCE_T1: ('spinqlablink.experiment.exp_decot1', 'ExpT1', 'ExpT1Parameters'),
            ExperimentType.QUANTUM_DECOHERENCE_T2: ('spinqlablink.experiment.exp_decot2', 'ExpT2', 'ExpT2Parameters'),
            ExperimentType.QUANTUM_CONTROL: ('spinqlablink.experiment.exp_qcontrol', 'ExpQControl', 'ExpQControlParameters'),
            ExperimentType.QUANTUM_SYSTEM_INITIALIZATION: ('spinqlablink.experiment.exp_sysinit', 'ExpSysInit', 'ExpSysInitParameters'),
            ExperimentType.QUANTUM_GATES_AND_CIRCUIT: ('spinqlablink.experiment.exp_qcircuit', 'ExpQCircuit', 'ExpQCircuitParameters'),
            ExperimentType.QUANTUM_STATE_TOMOGRAPHY: ('spinqlablink.experiment.exp_qrefactor', 'ExpQRefactor', 'ExpQRefactorParameters'),
            ExperimentType.QUANTUM_COMPUTING_TASK: ('spinqlablink.experiment.exp_qtask', 'ExpQTask', 'ExpQTaskParameters'),
            ExperimentType.QUANTUM_ALGORITHM: ('spinqlablink.experiment.exp_qalgorithm', 'ExpQAlgorithm', 'ExpQAlgorithmParameters'),
            ExperimentType.SPIN_ECHO: ('spinqlablink.experiment.exp_spinecho', 'ExpSpinecho', 'ExpSpinechoParameters'),
            ExperimentType.DYNAMIC_DECOUPLING: ('spinqlablink.experiment.exp_dydeco', 'ExpDydeco', 'ExpDydecoParameters'),
            ExperimentType.SHAPE_PULSE: ('spinqlablink.experiment.exp_shapePulse', 'ExpShapePulse', 'ExpShapePulseParameters'),
            ExperimentType.NUMERICAL_OPTIMIZATION_PULSE: ('spinqlablink.experiment.exp_npopti', 'ExpNpopti', 'ExpNpoptiParameters'),
            ExperimentType.PHYSICAL_LAYER_EXPERIMENT: ('spinqlablink.experiment.exp_layer_physical', 'ExpLayerPhysical', 'ExpLayerPhysicalParameters'),
            ExperimentType.CIRCUIT_LAYER_EXPERIMENT: ('spinqlablink.experiment.exp_layer_circuit', 'ExpLayerCircuit', 'ExpLayerCircuitParameters')
        }
        self.current_experiment = None
        self.current_experiment_params = None

    def _get_experiment_class(self, experiment_type: ExperimentType) -> tuple[Type[Experiment], Type[ExperimentParameter]]:
        """
        Get the experiment and parameter classes corresponding to the type.
        
        Args:
            experiment_type: Experiment type.
            
        Returns:
            Tuple of (experiment class, parameter class).
        
        Raises:
            ValueError: If the experiment type is not supported.
        """
        if experiment_type not in self.EXPERIMENT_TYPE_MAP:
            raise ValueError(f"Unknown experiment type: {experiment_type}")
            
        module_path, class_name, parameter_class_name = self.EXPERIMENT_TYPE_MAP[experiment_type]
        try:
            # Dynamically import experiment class
            module = importlib.import_module(module_path)
            experiment_class = getattr(module, class_name)
            parameter_class = getattr(module, parameter_class_name)
            return experiment_class, parameter_class
        except (ImportError, AttributeError) as e:
            logger.error(f"Failed to import experiment class: {e}")
            raise ValueError(f"Cannot load experiment type: {experiment_type}")
        
    def register_experiment(self, experiment_type: ExperimentType, handler_map: dict) -> tuple[Experiment, ExperimentParameter]:
        """
        Register an experiment of the given type.
        
        Args:
            experiment_type: Experiment type.
        """
        if self.current_experiment is not None:
            raise ValueError("Cannot register experiment more than once")
        
        experiment_class, parameter_class = self._get_experiment_class(experiment_type)
        
        self.current_experiment_params = parameter_class()
        self.current_experiment = experiment_class(self.current_experiment_params)
        self.current_experiment.register_handler(handler_map)
        return self.current_experiment, self.current_experiment_params

    def deregister_experiment(self):
        """
        Deregister the current experiment.
        """
        if self.current_experiment is not None or self.current_experiment_params is not None:
            self.current_experiment = None
            self.current_experiment_params = None
        else:
            logger.warning("No experiment registered")

    def get_experiment_parameter(self):
        if self.current_experiment is None:
            logger.error("No experiment registered")
            return {}
        return self.current_experiment.get_experiment_parameter()

    def wait_for_experiment_completion(self):
        """
        Wait for the current experiment to complete.
        """
        if self.current_experiment is None:
            logger.error("No experiment registered or experiment was deregistered due to errors")
            return False
        
        try:
            while(True):
                if self.current_experiment is None:
                    logger.error("Experiment was deregistered during execution")
                    return False

                status = self.current_experiment.get_status()
                if status == ExperimentState.COMPLETED or status == ExperimentState.FAILED:
                    break

                time.sleep(1)
            return True
        except Exception as e:
            logger.error(f"Error waiting for experiment completion: {e}")
            self.deregister_experiment()
            return False

    def get_experiment_result(self):
        """
        Get the result of the current experiment.
        """
        if self.current_experiment is None:
            logger.error("No experiment registered or experiment was deregistered due to errors")
            return {}
        
        if self.current_experiment.get_status() != ExperimentState.COMPLETED and self.current_experiment.get_status() != ExperimentState.FAILED:
            logger.warning("Experiment is not completed or failed, will automatically wait for completion")
            self.wait_for_experiment_completion()
        
        return self.current_experiment.get_result()
