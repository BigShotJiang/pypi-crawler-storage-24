# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Quantum Control Experiment Module

Provides Quantum Control experiment functionality
"""

from typing import Dict, Any, List
import time
import json

from ..experiment.experiment_base import Experiment, ExperimentParameter, ExperimentResult, ExperimentState
from ..utils import LoggerManager
from ..utils.types import ExperimentType
from ..utils.pulse import Pulse, Gradient
from pydantic import Field

# Create logger
logger = LoggerManager.get_logger(name='exp_layer_physical')

class ExpLayerPhysicalResult(ExperimentResult):
    """Physical Layer Experiment Result Class"""
    def __init__(self):
        super().__init__()
        self.type_setting = 0
        self.graph = []
        self.pauli_matrix = {}
        self.matrix = {}
        self.probability = []
    
    def append_graph(self, lines: Dict[str, Any]):
        """Append Line Graph"""
        self.graph.append(lines)

    def get_result(self) -> Dict[str, Any]:
        """Get experiment result"""
        para = {
            "graph": self.graph
        }
        if self.type_setting == 0:
            pass
        elif self.type_setting == 1:
            para["pauli_matrix"] = self.pauli_matrix
        elif self.type_setting == 2:
            para["matrix"] = self.matrix
            para["probability"] = self.probability
        return para

class ExpLayerPhysicalParameters(ExperimentParameter):
    """Physical Layer Experiment Parameters Class"""
    pulses: List[Pulse] = Field(default=[], description="Pulse sequence")
    gradients: List[Gradient] = Field(default=[], description="Gradient sequence")
    samplePath: int = Field(default=0, ge=-1, le=1, description="Sampling path selection: -1 for all channels, 0 for hydrogen channel, 1 for phosphorus channel")
    type_setting: int = Field(default=0, ge=0, le=2, description="Type setting: 0 for Customized Measurement, 1 for Pauli Component Measurement, 2 for Quantum State Tomography")
    relaxation_delay: float = Field(default=0, ge=0, le=25000000, description="Relaxation delay (µs)")
    stepList: List[int] = Field(default=[], description="Step list")
    h_freShift: int = Field(default=0, ge=-1000, le=1000, description="Hydrogen frequency shift")
    p_freShift: int = Field(default=0, ge=-1000, le=1000, description="Phosphorus frequency shift")
    h_freDemo: int = Field(default=0, ge=-1000, le=1000, description="Hydrogen frequency demo")
    p_freDemo: int = Field(default=0, ge=-1000, le=1000, description="Phosphorus frequency demo")
    state_initialization: bool = Field(default=True, description="State initialization: True for state initialization, False for not state initialization")
    sampleFre: int = Field(default=10000, ge=10000, le=100000, step=10000, description="Sample frequency, only accepts 10k-100k, with 10k intervals")
    sampleCount: int = Field(default=16000, ge=1, le=16000, description="Sample point")
    sampleDelay: int = Field(default=0, ge=0, le=2000000, description="Sample delay(us)")

    class Config:
        arbitrary_types_allowed = True

    def append_pulse(self, pulse: Pulse):
        self.pulses.append(pulse)

    def _convert_pulse(self) -> Dict[str, Any]:
        """Convert pulse to dictionary"""
        hpulse, ppulse = [], []
        for pulse in self.pulses:
            if pulse.path == 0:
                hpulse.append(pulse.to_dict())
            else:
                ppulse.append(pulse.to_dict())
        return {"hPulse": hpulse, "pPulse": ppulse}
    
    def append_gradient(self, gradient: Gradient):
        self.gradients.append(gradient)

    def _convert_gradient(self) -> Dict[str, Any]:
        """Convert gradient to dictionary"""
        return [gradient.to_dict() for gradient in self.gradients]

    def get_parameters(self) -> Dict[str, Any]:
        """Convert parameters to dictionary"""
        para = {
            "compute_type": self.type_setting,
            "relaxation_time": self.relaxation_delay,
            "stepList": self.stepList,
            "samplePath": self.samplePath,
            "h_freShift": self.h_freShift,
            "p_freShift": self.p_freShift,
            "h_freDemo": self.h_freDemo,
            "p_freDemo": self.p_freDemo,
            "makePps": self.state_initialization,
            "sampleFre": self.sampleFre,
            "sampleCount": self.sampleCount,
            "sampleDelay": self.sampleDelay,
            "pulse": self._convert_pulse(),
            "gradient": self._convert_gradient()
        }
        if self.type_setting == 1:
            para["makePps"] = True
        elif self.type_setting == 2:
            para["makePps"] = True

        return para

class ExpLayerPhysical(Experiment):
    """Physical Layer Experiment Class"""
    
    def __init__(self, parameters: ExpLayerPhysicalParameters):
        """
        Initialize Physical Layer experiment
        
        Args:
            parameters: Physical Layer experiment parameters
        """
        super().__init__(parameters)
        self.experiment_type = ExperimentType.PHYSICAL_LAYER_EXPERIMENT
        self.name = self.experiment_type + "-" + self.id[:8]
        self.result = ExpLayerPhysicalResult()
        self.step_graph = {}
        self.extra = {}
        self.group_name = "exp_layer_physical"
        logger.info(f"Created Quantum System Initialization experiment: {self.name}")

    def get_experiment_parameter(self) -> Dict[str, Any]:
        """Get experiment parameters."""
        para = {
            "id": self.id,
            "name": self.name,
            "createTime": self.created_at,
            "endTime": 0,
            "startTime": 0,
            "state": ExperimentState.PENDING,
            "type": self.experiment_type,
            "params": json.dumps(self.parameters.get_parameters())
        }

        return para

    def handle_exp_added(self, data: Dict[str, Any]) -> None:
        """Handle experiment addition for this concrete experiment type."""
        if data["code"] == 0:
            self.id = data["taskId"]
            self.created_at = time.time()
        else:
            raise Exception(f"Experiment addition failed: {data}")

    def handle_exp_started(self, data: Dict[str, Any]) -> None:
        """Handle experiment start for this concrete experiment type."""
        if data["taskId"] == self.id:
            queue = data["queue"][0]
            self.started_at = queue["startTime"]
            self.name = queue["name"]
            self.state = ExperimentState.RUNNING
    
    def handle_exp_step_changed(self, data: Dict[str, Any]) -> None:
        """Handle experiment step changes for this concrete experiment type."""
        if data["taskId"] == self.id:
            self.step = data["data"]["step"]
    
    def handle_exp_data_updated(self, data: Dict[str, Any]) -> None:
        """Handle experiment data updates for this concrete experiment type."""
        if data["taskId"] == self.id:
            logger.debug(f"Experiment data updated: {data}")

    def handle_exp_chart_data_updated_started(self, data: Dict[str, Any]) -> None:
        """Handle start of experiment chart data updates for this concrete experiment type."""
        if data["taskId"] == self.id:
            if data["group"] != self.group_name:
                return
            
            self.step_lines = {}
    
    def handle_exp_chart_data_updated(self, data: Dict[str, Any]) -> None:
        """Handle experiment chart data updates for this concrete experiment type."""
        if data["taskId"] == self.id:
            if data["group"] != self.group_name:
                return
            self.step_lines[data["chart_name"]] = data["points"]

    def handle_exp_chart_data_updated_finished(self, data: Dict[str, Any]) -> None:
        """Handle completion of experiment chart data updates for this concrete experiment type."""
        if data["taskId"] == self.id:
            if data["group"] != self.group_name:
                return
            self.result.append_graph(self.step_lines)

    def handle_exp_terminated(self, data: Dict[str, Any]) -> None:
        """Handle experiment termination for this concrete experiment type."""
        self.completed_at = time.time()
        if data["taskId"] == self.id:
            self.state = ExperimentState.FAILED
    
    def handle_exp_removed(self, data: Dict[str, Any]) -> None:
        """Handle experiment removal for this concrete experiment type."""
        self.completed_at = time.time()
        self.state = ExperimentState.FAILED

    def handle_exp_finished(self, data: Dict[str, Any]) -> None:
        """Handle experiment completion for this concrete experiment type."""
        logger.info(f"Experiment finished:{self.name}")
        logger.debug(f"Experiment finished data:{data}")
        if data["taskId"] == self.id:
            self.completed_at = time.time()
            if data["data"]["isTerminated"] == False:
                self.state = ExperimentState.COMPLETED
            else:
                self.state = ExperimentState.FAILED
            parameters = data["data"]["parameters"]
            type = self.parameters.type_setting
            self.result.type_setting = type
            if "result" in parameters and parameters["result"] != "":
                if type == 0:
                    #don't need to do anything
                    pass
                elif type == 1:
                    result = json.loads(parameters["result"])
                    self.result.pauli_matrix = result
                elif type == 2:
                    result = json.loads(parameters["result"])
                    self.result.matrix = {
                        "real": result["real"],
                        "imag": result["imag"]
                    }
                    self.result.probability = result["module"]

    def get_status(self) -> str:
        """Get experiment status."""
        return self.state

    def get_result(self) -> Dict[str, Any]:
        """Get experiment result."""
        return {
            "id": self.id,
            "name": self.name,
            "createTime": self.created_at,
            "endTime": self.completed_at,
            "startTime": self.started_at,
            "state": self.state,
            "type": self.experiment_type,
            "extra": json.dumps(self.extra),
            "params": json.dumps(self.parameters.get_parameters()),
            "result": self.result.get_result()
        }
