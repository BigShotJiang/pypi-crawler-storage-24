# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Low-level TCP connection implementation.

Provides threaded, queue-based buffered send/receive functionality.
"""

import socket
import time
import threading
import queue
from typing import Dict, Any, Callable

# Custom timeout exception
class TimeoutError(Exception):
    """Connection timeout exception."""
    pass

from ..utils import LoggerManager

# Create logger
logger = LoggerManager.get_logger(name='connection')

class TCPConnection:
    """TCP connection class used for communication with remote devices."""
    
    def __init__(self, host: str, port: int, timeout: float = 10.0):
        """
        Initialize a TCP connection.
        
        Args:
            host: Server hostname or IP.
            port: Server port.
            timeout: Connection timeout in seconds.
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        # Connection state
        self.socket = None
        self.connected = False
        self.buffer_size = 32768
        
        # Thread control
        self._lock = threading.Lock()
        self._running = False
        self._send_thread = None
        self._recv_thread = None
        
        # Message queue
        self._send_queue = queue.Queue()
        
        # Callback and pending responses
        self._waiting_responses = {}
        self._message_callback = None
    
    def connect(self) -> bool:
        """
        Connect to the server.
        
        Returns:
            bool: Whether the connection was successful.
        """
        if self.connected:
            return True
        
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            self.socket.connect((self.host, self.port))
            
            # Set non-blocking mode
            self.socket.setblocking(0)
            
            # Start receive thread
            self._running = True
            self.connected = True
            self._recv_thread = threading.Thread(target=self._recv_worker, daemon=True)
            self._recv_thread.start()
            
            # Start send thread
            self._send_thread = threading.Thread(target=self._send_worker, daemon=True)
            self._send_thread.start()
            
            logger.info(f"Connected successfully: {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"Connection failed: {str(e)}")
            return False
    
    def disconnect(self) -> bool:
        """
        Disconnect from the server.
        
        Returns:
            bool: Whether the disconnection was successful.
        """
        if not self.connected:
            return True
            
        try:
            self._running = False
            
            # Wait for threads to finish
            if self._recv_thread and self._recv_thread.is_alive():
                self._recv_thread.join(1.0)  # Wait up to 1 second
            
            if self._send_thread and self._send_thread.is_alive():
                self._send_thread.join(1.0)  # Wait up to 1 second
                
            # Close socket
            try:
                self.socket.shutdown(socket.SHUT_RDWR)
                self.socket.close()
            except Exception as e:
                logger.error(f"Disconnect exception: {str(e)}")
            
            self.connected = False
            logger.warn("Connection disconnected")
            return True
        except Exception as e:
            logger.error(f"Disconnect error: {str(e)}")
            return False
    
    def _start_threads(self) -> None:
        """Start worker threads."""
        # Send thread
        self._send_thread = threading.Thread(
            target=self._send_worker,
            name="SendWorker"
        )
        self._send_thread.daemon = True
        self._send_thread.start()
        
        # Receive thread
        self._recv_thread = threading.Thread(
            target=self._recv_worker,
            name="RecvWorker"
        )
        self._recv_thread.daemon = True
        self._recv_thread.start()
    
    def _wait_threads_end(self) -> None:
        """Wait for worker threads to finish."""
        threads = []
        if self._send_thread and self._send_thread.is_alive():
            threads.append(self._send_thread)
        if self._recv_thread and self._recv_thread.is_alive():
            threads.append(self._recv_thread)
            
        # Wait for threads to finish, up to 5 seconds
        for thread in threads:
            thread.join(timeout=5.0)
            
        # Reset thread references
        self._send_thread = None
        self._recv_thread = None
    
    def _clear_queues(self) -> None:
        """Clear all queues."""
        try:
            while not self._send_queue.empty():
                self._send_queue.get()
            
            while not self._recv_queue.empty():
                self._recv_queue.get()
        except Exception as e:
            logger.error(f"Queue clearing exception: {e}")
    
    def _send_worker(self) -> None:
        """Worker function for the send thread."""
        
        while self._running and self.connected:
            try:
                # Retrieve data to send from the queue, wait up to 0.5 seconds
                try:
                    data = self._send_queue.get(timeout=0.5)
                except queue.Empty:
                    continue
                
                # Send data
                if self.socket and self.connected:
                    with self._lock:
                        self.socket.sendall(data)
                else:
                    logger.warning("Send failed: Not connected")
                    
                # Mark task as done
                self._send_queue.task_done()
                
            except socket.error as e:
                logger.error(f"Send error: {e}")
                self.connected = False
                self._running = False
                break
            except Exception as e:
                logger.error(f"Send thread exception: {e}")
        
    
    def _recv_worker(self) -> None:
        """Worker function for the receive thread."""
        
        # Buffer for partially processed data
        buffer = b''
        
        while self._running and self.connected:
            try:
                # Receive data
                if self.socket and self.connected:
                    # Set non-blocking receive
                    self.socket.settimeout(0.5)
                    
                    try:
                        with self._lock:
                            data = self.socket.recv(self.buffer_size)
                            
                        if not data:
                            time.sleep(0.1)
                            continue
                        
                        # Append newly received data to buffer
                        buffer += data

                        # Try to parse complete messages from the buffer
                        while buffer:
                            self._handle_received_message(buffer)
                            buffer = b''
                            
                    except socket.timeout:
                        # Timeout, continue loop
                        continue
                    except socket.error as e:
                        logger.error(f"Receive error: {e}")
                        self.connected = False
                        self._running = False
                        break
                else:
                    # Not connected; wait briefly
                    time.sleep(0.1)
                    
            except Exception as e:
                logger.error(f"Receive thread exception: {e}")
                time.sleep(0.1)
    
    def _handle_received_message(self, data: bytes) -> None:
        """
        Handle received raw message bytes.
        
        Args:
            data: Raw message bytes.
        """
        if self._message_callback:
            try:
                self._message_callback(data)
            except Exception as e:
                logger.error(f"Message callback execution error: {e}")
    
    def send(self, data: bytes) -> bool:
        """
        Send data.
        
        Args:
            data: Data to send.
            
        Returns:
            bool: Whether the data was enqueued for sending successfully.
        """
        if not self.connected:
            logger.warning("Send failed: Not connected")
            return False
            
        try:
            with self._lock:
                self._send_queue.put(data)
            return True
        except Exception as e:
            logger.error(f"Send error: {e}")
            return False
    
    def set_message_callback(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        """
        Set the message callback function.
        
        Args:
            callback: Callback which receives the parsed message.
        """
        self._message_callback = callback
    
    def is_connected(self) -> bool:
        """
        Check whether the connection is currently established.
        
        Returns:
            bool: True if connected, otherwise False.
        """
        return self.connected