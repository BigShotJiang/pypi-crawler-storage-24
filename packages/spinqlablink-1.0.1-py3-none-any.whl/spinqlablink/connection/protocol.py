# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Communication protocol module.

Responsible for packaging and parsing experiment protocol data.
"""

import json
from typing import Dict, Any, Tuple
import struct

from ..utils import LoggerManager
from . import message_pb2

# Create logger
logger = LoggerManager.get_logger(name='protocol')

class Protocol:
    """Communication protocol class responsible for data packing and unpacking."""
    def __init__(self):
        self.remaining_data = b''
        self.next_data = b''
        # Packet header magic number
        self.HEADER_MAGIC = 0xCAFEBABE
    
    def serialize_message(self, msg_id: str, metadata: Dict[str, Any], json_data: Dict[str, Any]) -> bytes:
        """
        Pack a protobuf message into binary data.

        Args:
            msg_id: Message identifier string.
            metadata: Metadata dictionary.
            json_data: Business JSON data to send.

        Returns:
            Packed binary data.
        """
        try:
            # Serialize protobuf message
            message_data = message_pb2.BaseMessage()
            message_data.msg_id = msg_id
            message_data.metadata.sequence_id = metadata.get("sequence_id")
            message_data.metadata.timestamp = metadata.get("timestamp")
            message_data.metadata.account = metadata.get("account")
            message_data.metadata.session_id = metadata.get("session_id")
            message_data.json_data = json.dumps(json_data)
            
            # Calculate data length
            serialized_message = message_data.SerializeToString()
            data_length = len(serialized_message)
            
            # Assemble header: magic (4 bytes) + length (4 bytes)
            # In '>II', '>' means big-endian, each 'I' is an unsigned 4‑byte integer
            header = struct.pack('>II', self.HEADER_MAGIC, data_length)
            # Assemble full message
            packed_data = header + serialized_message
            
            return packed_data
            
        except Exception as e:
            logger.error(f"Message packing failed: {str(e)}")
            return b""
    
    def deserialize_message(self, data: bytes) -> Tuple[bool, Dict[str, Any]]:
        """
        Parse binary data into a protobuf message and handle
        packet sticking/splitting issues.

        Args:
            data: Received binary data.

        Returns:
            Tuple[bool, Dict[str, Any]]: (success flag, parsed message dict).
        """
        self.remaining_data += data
        
        # Check data length; must at least contain a full header (8 bytes)
        if len(self.remaining_data) < 8:
            # Not enough data; wait for more
            return False, {}
        
        # Parse header
        magic, length = struct.unpack('>II', self.remaining_data[:8])

        # Validate magic number
        if magic != self.HEADER_MAGIC:
            logger.error(f"Invalid header magic number: 0x{magic:04X}")
            return False, {}
        
        # Check if we have enough data for a full message
        total_length = 8 + length  # Header (8 bytes) + body
        if len(self.remaining_data) < total_length:
            # Incomplete data; keep it and wait for more
            return False, {}
        
        # Extract message body
        message_data = self.remaining_data[8:total_length]
        # Save remaining data for subsequent packets
        self.next_data = self.remaining_data[total_length:]
        
        try:
            # Parse protobuf message
            message = message_pb2.BaseMessage()
            message.ParseFromString(message_data)
            
            # Build returned data dictionary
            dict_data = {}
            metadata = {}
            metadata["sequence_id"] = message.metadata.sequence_id
            metadata["timestamp"] = message.metadata.timestamp
            metadata["account"] = message.metadata.account
            metadata["session_id"] = message.metadata.session_id
            dict_data["msg_id"] = message.msg_id
            dict_data["metadata"] = metadata
            
            # Handle different message content types
            if message.HasField("chart_data"):
                chart_data = {}
                chart_data["taskId"] = message.chart_data.task_id
                chart_data["group"] = message.chart_data.group
                chart_data["chart_name"] = message.chart_data.chart_name
                chart_data["path"] = message.chart_data.path
                chart_data["qubit"] = message.chart_data.qubit
                chart_data["step"] = message.chart_data.step
                points = []
                for point in message.chart_data.points:
                    points.append([point.x, point.y])
                chart_data["points"] = points
                dict_data["chart_data"] = chart_data
            elif message.HasField("json_data"):
                json_data = json.loads(message.json_data)
                dict_data["json_data"] = json_data

            self.remaining_data = self.next_data
            self.next_data = b''
            return True, dict_data
        except Exception as e:
            logger.error(f"Message unpacking failed: {str(e)}")
            # Parsing failed; discard current packet
            return False, {}
