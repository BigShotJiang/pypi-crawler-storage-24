# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Heartbeat manager.

Used to manage the heartbeat connection with the server.

Timeout strategy
----------------
* While an experiment is queued or running, the timeout clock is **suspended**
  so that long queue waits do not trigger a forced disconnect.
* Once the experiment finishes (or is deregistered), the clock resumes.
* If no heartbeat response is received within HEARTBEAT_TIMEOUT seconds
  *outside* of a suspended period, the connection is considered lost.
"""

import time
import threading
from typing import Callable, Optional
from ..utils import LoggerManager

# Message type definitions
MSG_HEARTBEAT_REQ = "heartbeat_req"  # Heartbeat request
MSG_HEARTBEAT_RES = "heartbeat_res"  # Heartbeat response

# Base heartbeat timeout in seconds (applies when no experiment is active)
HEARTBEAT_TIMEOUT = 120
# Heartbeat send interval in seconds
HEARTBEAT_INTERVAL = 10

# Create logger
logger = LoggerManager.get_logger(name='heartbeat')


class HeartbeatManager:
    """Heartbeat manager with queue-aware timeout suspension."""

    def __init__(self, send_message_callback: Callable[[str, dict], None]):
        """
        Initialize the heartbeat manager.

        Args:
            send_message_callback: Callback used to send heartbeat messages.
        """
        self.send_message_callback = send_message_callback

        # Heartbeat-related attributes
        self.heartbeat_timer: Optional[threading.Timer] = None
        self.last_heartbeat_response_time = 0
        self.heartbeat_checking_timer: Optional[threading.Timer] = None

        # State
        self._is_running = False

        # When True the timeout clock is suspended (experiment queued/running)
        self._timeout_suspended = False

        # Callback for timeout handling
        self.on_timeout_callback: Optional[Callable[[], None]] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_timeout_callback(self, callback: Callable[[], None]):
        """
        Set the heartbeat timeout callback function.

        Args:
            callback: Callback invoked when a timeout occurs.
        """
        self.on_timeout_callback = callback

    def suspend_timeout(self):
        """Suspend the timeout clock.

        Call this when an experiment enters the queue or starts running so
        that a long wait does not trigger an unwanted disconnect.
        """
        if not self._timeout_suspended:
            logger.debug("Heartbeat timeout suspended (experiment queued/running)")
            self._timeout_suspended = True
            # Reset the response timestamp so the clock starts fresh when resumed
            self.last_heartbeat_response_time = time.time()

    def resume_timeout(self):
        """Resume the timeout clock.

        Call this when the experiment finishes or is deregistered.
        """
        if self._timeout_suspended:
            logger.debug("Heartbeat timeout resumed")
            self._timeout_suspended = False
            # Restart the timestamp so we get a full window before triggering
            self.last_heartbeat_response_time = time.time()

    def start(self):
        """Start the heartbeat mechanism."""
        if self._is_running:
            logger.warning("Heartbeat is already running")
            return

        logger.debug("Starting heartbeat")
        self._is_running = True
        self._timeout_suspended = False
        self.last_heartbeat_response_time = time.time()

        # Start heartbeat send timer
        self._send_heartbeat()

        # Start heartbeat timeout checking timer
        self._check_heartbeat_timeout()

    def stop(self):
        """Stop the heartbeat mechanism."""
        if not self._is_running:
            return

        logger.debug("Stopping heartbeat")
        self._is_running = False
        self._timeout_suspended = False

        if self.heartbeat_timer:
            self.heartbeat_timer.cancel()
            self.heartbeat_timer = None

        if self.heartbeat_checking_timer:
            self.heartbeat_checking_timer.cancel()
            self.heartbeat_checking_timer = None

    def on_heartbeat_response(self):
        """Handle heartbeat response; always refreshes the response timestamp."""
        self.last_heartbeat_response_time = time.time()

    def get_status(self) -> dict:
        """
        Get heartbeat status.

        Returns:
            dict: Heartbeat status information.
        """
        current_time = time.time()
        elapsed_time = (
            current_time - self.last_heartbeat_response_time
            if self.last_heartbeat_response_time > 0
            else 0
        )
        return {
            "is_running": self._is_running,
            "timeout_suspended": self._timeout_suspended,
            "last_response_time": self.last_heartbeat_response_time,
            "elapsed_time": elapsed_time,
            "timeout_threshold": HEARTBEAT_TIMEOUT,
            "send_interval": HEARTBEAT_INTERVAL,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _send_heartbeat(self):
        """Send a heartbeat message."""
        if not self._is_running:
            logger.warning("Heartbeat stopped, not sending")
            return

        try:
            self.send_message_callback(MSG_HEARTBEAT_REQ, {})
        except Exception as e:
            logger.error(f"Failed to send heartbeat: {e}")

        if self._is_running:
            self.heartbeat_timer = threading.Timer(HEARTBEAT_INTERVAL, self._send_heartbeat)
            self.heartbeat_timer.daemon = True
            self.heartbeat_timer.start()

    def _check_heartbeat_timeout(self):
        """Check whether the heartbeat has timed out.

        The check is skipped (clock suspended) while an experiment is queued
        or running to avoid spurious disconnects during long queue waits.
        """
        if not self._is_running:
            logger.debug("Heartbeat is not running; not checking timeout")
            return

        if self._timeout_suspended:
            # Keep rescheduling the check but do not count elapsed time
            logger.debug("Heartbeat timeout check skipped (suspended)")
            self._schedule_next_check()
            return

        current_time = time.time()
        elapsed_time = current_time - self.last_heartbeat_response_time

        if elapsed_time > HEARTBEAT_TIMEOUT:
            logger.error(
                f"Heartbeat timeout ({elapsed_time:.1f} s > {HEARTBEAT_TIMEOUT} s); "
                "considered disconnected"
            )
            self._is_running = False
            if self.on_timeout_callback:
                try:
                    self.on_timeout_callback()
                except Exception as e:
                    logger.error(f"Heartbeat timeout callback execution failed: {e}")
        else:
            self._schedule_next_check()

    def _schedule_next_check(self):
        """Schedule the next heartbeat timeout check."""
        if self._is_running:
            self.heartbeat_checking_timer = threading.Timer(5, self._check_heartbeat_timeout)
            self.heartbeat_checking_timer.daemon = True
            self.heartbeat_checking_timer.start()
