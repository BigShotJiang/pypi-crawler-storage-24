import pyqtgraph as pg
from pyqtgraph.Qt import QtWidgets
import numpy as np
from typing import List
from ..utils.pulse import Pulse

colors = {
    'fidRe': '#2557d5',     # Blue
    'fidIm': '#df265a',     # Red
    'fidMod': '#32325D',    # Green
    'lorenz': '#800000',    # Purple
    'fftRe': '#2557d5',     # Blue
    'fftIm': '#df265a',     # Red
    'fftMod': '#32325D',    # Green
    'fftFit': '#800000'     # Purple
}
        
def print_graph(result):
    # Get chart data
    if "graph" in result:
        graph_data = result["graph"]
    else:
        print("No graph data found")
        return

    # Some experiments may not return chart data at all. Avoid opening an empty
    # window and blocking on the Qt event loop in that case.
    if not graph_data:
        print("No chart points returned (graph is empty).")
        return
    
    # Create application and window
    app = QtWidgets.QApplication([])
    
    # Create main window
    main_window = QtWidgets.QWidget()
    main_window.setWindowTitle("Experiment Signal Result")
    main_window.resize(1200, 700)
    
    # Create main layout
    main_layout = QtWidgets.QVBoxLayout()
    main_window.setLayout(main_layout)
    
    # Create control area
    control_layout = QtWidgets.QHBoxLayout()
    main_layout.addLayout(control_layout)
    
    # Create dropdown
    control_layout.addWidget(QtWidgets.QLabel("Select Step Data:"))
    step_selector = QtWidgets.QComboBox()
    control_layout.addWidget(step_selector)
    control_layout.addStretch()  # Add elastic space to left-align controls
    
    # Fill dropdown options
    for i in range(len(graph_data)):
        step_selector.addItem(f"Step {i+1}")
    
    # Create chart area
    plot_layout = QtWidgets.QVBoxLayout()
    main_layout.addLayout(plot_layout)
    
    # Create plotting window
    win = pg.GraphicsLayoutWidget()
    plot_layout.addWidget(win)
    
    # Set window background to white
    win.setBackground('w')

    
    # Add two plotting areas
    p1 = win.addPlot(title="FID Signal and Lorenz Fitting")
    win.nextRow()
    p2 = win.addPlot(title="FFT Spectrum")
    
    # Set plot area labels
    p1.setLabel('left', 'Amplitude')
    p1.setLabel('bottom', 'Time (ms) / Frequency (Hz)')
    # Set p1 to display grid
    p1.showGrid(x=True, y=True, alpha=0.2)
    p1.getAxis('bottom').setPen(pg.mkPen(color='k', width=1))
    p1.getAxis('left').setPen(pg.mkPen(color='k', width=1))
    p2.setLabel('left', 'Amplitude')
    p2.setLabel('bottom', 'Frequency (Hz)')
    # Set p2 to display grid
    p2.showGrid(x=True, y=True, alpha=0.2)
    p2.getAxis('bottom').setPen(pg.mkPen(color='k', width=1))
    p2.getAxis('left').setPen(pg.mkPen(color='k', width=1))
    
    # Add legend
    p1_legend = p1.addLegend()
    p2_legend = p2.addLegend()
    
    # Define function to update chart
    def update_plot(index):
        # Clear existing charts
        p1.clear()
        p2.clear()
        
        # Re-add legends
        p1_legend = p1.addLegend()
        p2_legend = p2.addLegend()
        
        # Get selected step data
        step_data = graph_data[index]
        
        # Extract different types of chart data
        fftRe, fftIm, fftMod, fftFit, fidRe, fidIm, fidMod, lorenz = [], [], [], [], [], [], [], []

        for chart_name, points in step_data.items():
            if chart_name == "fftRe":
                fftRe = points
            elif chart_name == "fftIm":
                fftIm = points
            elif chart_name == "fftMod":
                fftMod = points
            elif chart_name == "fftFit":
                fftFit = points
            elif chart_name == "fidRe":
                fidRe = points
            elif chart_name == "fidIm":
                fidIm = points
            elif chart_name == "fidMod":
                fidMod = points
            elif chart_name == "lorenz":
                lorenz = points
        
        # Plot FID data and Lorenz fitting curve
        if fidRe:
            x_fid = np.array([point[0] for point in fidRe])
            y_fid_re = np.array([point[1] for point in fidRe])
            p1.plot(x_fid, y_fid_re, pen=pg.mkPen(color=colors['fidRe'], width=1), name='FID Real')
        
        if fidIm:
            x_fid = np.array([point[0] for point in fidIm])
            y_fid_im = np.array([point[1] for point in fidIm])
            p1.plot(x_fid, y_fid_im, pen=pg.mkPen(color=colors['fidIm'], width=1), name='FID Imaginary')
            
        if fidMod:
            x_fid = np.array([point[0] for point in fidMod])
            y_fid_mod = np.array([point[1] for point in fidMod])
            p1.plot(x_fid, y_fid_mod, pen=pg.mkPen(color=colors['fidMod'], width=1), name='FID Magnitude')
            
        if lorenz:
            x_lorenz = np.array([point[0] for point in lorenz])
            y_lorenz = np.array([point[1] for point in lorenz])
            p1.plot(x_lorenz, y_lorenz, pen=pg.mkPen(color=colors['lorenz'], width=1), name='Lorenz Fitting Curve')
        
        # Plot FFT data
        if fftRe:
            x_fft = np.array([point[0] for point in fftRe])
            y_fft_re = np.array([point[1] for point in fftRe])
            p2.plot(x_fft, y_fft_re, pen=pg.mkPen(color=colors['fftRe'], width=1), name='FFT Real')
        
        if fftIm:
            x_fft = np.array([point[0] for point in fftIm])
            y_fft_im = np.array([point[1] for point in fftIm])
            p2.plot(x_fft, y_fft_im, pen=pg.mkPen(color=colors['fftIm'], width=1), name='FFT Imaginary')
            
        if fftMod:
            x_fft = np.array([point[0] for point in fftMod])
            y_fft_mod = np.array([point[1] for point in fftMod])
            p2.plot(x_fft, y_fft_mod, pen=pg.mkPen(color=colors['fftMod'], width=1), name='FFT Magnitude')

        if fftFit:
            x_fft = np.array([point[0] for point in fftFit])
            y_fft_fit = np.array([point[1] for point in fftFit])
            p2.plot(x_fft, y_fft_fit, pen=pg.mkPen(color=colors['fftFit'], width=1), name='FFT Fitting Curve')

    # Connect dropdown signal to update function
    step_selector.currentIndexChanged.connect(update_plot)
    
    # If there is data, initialize chart
    if graph_data:
        update_plot(0)
    
    # Show main window
    main_window.show()
    
    print("Chart data plotting completed")
    app.exec_()

def parse_spinq_file(pulses: List[Pulse], file_path: str):
    try:
        with open(file_path, "r") as file:
            file_dict = file.read()
            
        # Parse pulse file content
        import json
        file_dict = json.loads(file_dict)
        pulses_dict = file_dict["pulse"]
        
        # Parse hydrogen channel pulses
        for pulse in pulses_dict["channel1_pulse"]:
            pulses.append(Pulse(
                path=0,  # Hydrogen channel
                width=pulse.get("width", 0),
                amplitude=pulse.get("amplitude", 0.0),
                phase=pulse.get("phase", 0.0),
                detuning=pulse.get("detuning", 0.0)
            ))
        
        # Parse phosphorus channel pulses
        for pulse in pulses_dict["channel2_pulse"]:
            pulses.append(Pulse(
                path=1,  # Phosphorus channel
                width=pulse.get("width", 0),
                amplitude=pulse.get("amplitude", 0.0),
                phase=pulse.get("phase", 0.0),
                detuning=pulse.get("detuning", 0.0)
            ))
    except FileNotFoundError:
        print(f"could not find pulse file: {file_path}")
    except json.JSONDecodeError:
        print("pulse file format error, could not parse JSON content")
    except Exception as e:
        print(f"error: {str(e)}")

def pulse_domain_analysis(pulses: List[Pulse]):
    """
    Analyze the domain characteristics of a pulse sequence and compute
    the Fourier transform from the time domain to the frequency domain.

    Args:
        pulses: List of pulse sequences.

    Returns:
        A dictionary containing the frequency-domain analysis results,
        including frequency, real part, imaginary part, and magnitude.
    """
    import numpy as np
    from numpy.fft import fft, fftshift
    import math
    
    if not pulses:
        return {
            "freqs": [],
            "real": [],
            "imag": [],
            "magnitude": []
        }
    
    # Extract pulse parameters
    amps = [p.amplitude for p in pulses]
    phases = [p.phase for p in pulses]
    durations = [p.width for p in pulses]
    channels = [p.path for p in pulses]
    detunings = [p.detuning for p in pulses]
    
    max_amp = max(amps) if amps else 1.0
    sample_points = 64  # Number of sampling points
    
    # Compute total time interval
    total_duration = sum(durations)
    t_total = []
    pulse_signals = []
    pulse_signals_norm = []
    
    # Generate time-domain signal for each pulse
    for i, pulse in enumerate(pulses):
        t_init = sum(durations[:i])
        t_end = t_init + durations[i]
        dt = (t_end - t_init) / sample_points
        
        for j in range(sample_points):
            t = t_init + j * dt
            t_total.append(t)
            
            # Generate complex-valued pulse signal
            if amps[i] == 0:
                pulse_signals.append(complex(0, 0))
                pulse_signals_norm.append(complex(0, 0))
            else:
                # Compute phase (degrees to radians)
                phase_rad = phases[i] / 360.0 * 2 * math.pi
                # Compute frequency (considering detuning)
                freq = detunings[i]
                
                # Generate complex signal
                real_part = amps[i] * math.cos(2 * math.pi * freq * t + phase_rad)
                imag_part = amps[i] * math.sin(2 * math.pi * freq * t + phase_rad)
                
                pulse_signals.append(complex(real_part, imag_part))
                pulse_signals_norm.append(complex(real_part / max_amp, imag_part / max_amp))
    
    # Pad signal length to a power of 2 to improve FFT efficiency
    length = 2 ** math.ceil(math.log2(len(pulse_signals) * 5))
    
    # If there is no valid data, return an empty result
    if length == 0:
        return {
            "freqs": [],
            "real": [],
            "imag": [],
            "mod": []
        }
    
    # Zero-pad to the specified length
    pulse_signals = np.pad(pulse_signals, (0, length - len(pulse_signals)), 'constant')
    pulse_signals_norm = np.pad(pulse_signals_norm, (0, length - len(pulse_signals_norm)), 'constant')
    
    # Perform FFT
    fft_result = fft(pulse_signals)
    fft_result_norm = fft(pulse_signals_norm)
    
    # Compute frequency axis
    fs = sample_points / t_total[-1] if t_total else 1.0
    f = np.array([(i - length/2) * fs / length for i in range(length)])
    
    # Shift zero-frequency component to the center
    fft_result = fftshift(fft_result)
    fft_result_norm = fftshift(fft_result_norm)
    
    # Define the frequency range of interest
    freq_range = int(length * 0.1)  # Take the central 10% range
    
    start_idx = length // 2 - freq_range
    end_idx = length // 2 + freq_range
    
    # Extract data in the specified range
    freqs = f[start_idx:end_idx].tolist()
    fft_selected = fft_result[start_idx:end_idx]
    fft_norm_selected = fft_result_norm[start_idx:end_idx]
    
    # Compute magnitudes
    magnitudes = [abs(x) for x in fft_selected]
    norm_factor = max(magnitudes) / (length * 2) if magnitudes else 1.0
    norm_factor = 1.0 if norm_factor == 0 else norm_factor
    
    # Build result
    result = {
        "freqs": freqs,
        "real": [(x.real / (length * 2) / norm_factor) for x in fft_selected],
        "imag": [(x.imag / (length * 2) / norm_factor) for x in fft_selected],
        "mod": [(abs(x) / (length * 2) / norm_factor) for x in fft_selected]
    }
    
    # Display spectrum plot
    app = QtWidgets.QApplication([])
    
    # Create main window
    main_window = QtWidgets.QWidget()
    main_window.setWindowTitle("Pulse Spectrum Analysis")
    main_window.resize(800, 500)
    
    # Create main layout
    main_layout = QtWidgets.QVBoxLayout()
    main_window.setLayout(main_layout)
    
    # Create plotting area
    win = pg.GraphicsLayoutWidget()
    main_layout.addWidget(win)
    win.setBackground('w')
    
    # Add plotting area
    p1 = win.addPlot(title="Spectrum Analysis")
    p1.setLabel('left', 'Amplitude')
    p1.setLabel('bottom', 'Frequency (Hz)')
    
    # Plot spectrum
    p1.plot(result["freqs"], result["mod"], pen=pg.mkPen(color=colors['fftMod'], width=1), name='FFT Magnitude')
    p1.plot(result["freqs"], result["real"], pen=pg.mkPen(color=colors['fftRe'], width=1), name='FFT Real')
    p1.plot(result["freqs"], result["imag"], pen=pg.mkPen(color=colors['fftIm'], width=1), name='FFT Imaginary')
    
    # Show window
    main_window.show()
    app.exec_()
class WaveformGenerator:
    """Waveform generator class used to generate various types of pulse sequences."""
    RECTANGULAR = "Rectangular"
    GAUSSIAN = "Gaussian"
    HERMITE = "Hermite"
    
    @staticmethod
    def generate(channel: int, wave_type: str, samplePoint: int, timeLength: int, phase: float, amplitude: float, detuning: int) -> List[Pulse]:
        """
        Generate a waveform pulse sequence.

        Args:
            channel: Channel selection (0=hydrogen channel, 1=phosphorus channel).
            wave_type: Waveform type ("Rectangular", "Gaussian", "Hermite", "REBURP").
            samplePoint: Number of sampling points.
            timeLength: Pulse length (µs).
            phase: Phase (degrees).
            amplitude: Amplitude (0–100).
            detuning: Frequency offset (Hz).

        Returns:
            The generated pulse sequence.
        """
        if channel < 0 or channel > 1:
            raise ValueError(f"Invalid channel selection: {channel}")
        if wave_type not in [WaveformGenerator.RECTANGULAR, WaveformGenerator.GAUSSIAN, WaveformGenerator.HERMITE]:
            raise ValueError(
                f"Unsupported waveform type: {wave_type}, "
                f"supported types: WaveformGenerator.RECTANGULAR, "
                f"WaveformGenerator.GAUSSIAN, WaveformGenerator.HERMITE, "
                f"WaveformGenerator.REBURP"
            )
        if samplePoint not in [4,8,16,32,64]:
            raise ValueError(f"Sample points must be one of 4, 8, 16, 32, 64: {samplePoint}")
        if phase < 0 or phase > 360:
            raise ValueError(f"Phase must be within 0–360 degrees: {phase}")
        if amplitude < 0 or amplitude > 100:
            raise ValueError(f"Amplitude must be within 0–100: {amplitude}")
        if detuning < -10000 or detuning > 10000:
            raise ValueError(f"Frequency offset must be within -1000–1000 Hz: {detuning}")
        
        pulses = []
        width = timeLength / samplePoint  # Width of each pulse
        
        # Generate time points
        t = np.arange(0, timeLength, width)
        
        # Generate amplitude sequence according to waveform type
        if wave_type == WaveformGenerator.RECTANGULAR:
            y = WaveformGenerator._rectangular_wave(timeLength, samplePoint, t)
        elif wave_type == WaveformGenerator.GAUSSIAN:
            y = WaveformGenerator._gaussian_wave(timeLength, samplePoint, t)
        elif wave_type == WaveformGenerator.HERMITE:
            y = WaveformGenerator._hermite_wave(timeLength, samplePoint, t)
        else:
            raise ValueError(f"Unsupported waveform type: {wave_type}")
        
        # Generate pulse sequence
        for i in range(len(t)):
            # Compute actual phase and amplitude
            pulse_phase = phase if y[i] >= 0 else (phase + 360)
            am = abs(y[i] * amplitude)
            am = min(am, 100)  # Upper bound of amplitude is 100
            
            # Create pulse object
            pulse = Pulse(
                path=channel,
                width=width,
                amplitude=am,
                phase=pulse_phase,
                detuning=detuning
            )
            pulses.append(pulse)
        
        return pulses

    @staticmethod
    def _rectangular_wave(timeLength: float, samplePoint: int, t: np.ndarray) -> np.ndarray:
        """Generate rectangular wave."""
        return np.ones_like(t)

    @staticmethod
    def _gaussian_wave(timeLength: float, samplePoint: int, t: np.ndarray) -> np.ndarray:
        """Generate Gaussian wave."""
        sigma = timeLength / 4
        mu = timeLength / 2
        return np.exp(-((t - mu) ** 2) / (2 * sigma ** 2))

    @staticmethod
    def _hermite_wave(timeLength: float, samplePoint: int, t: np.ndarray) -> np.ndarray:
        """Generate Hermite wave."""
        sigma = timeLength / 4
        mu = timeLength / 2
        x = (t - mu) / sigma
        return (1 - 2 * x**2) * np.exp(-(x**2) / 2)

    @staticmethod
    def _reburp_wave(timeLength: float, samplePoint: int, t: np.ndarray) -> np.ndarray:
        """Generate REBURP waveform."""
        mu = timeLength / 2
        x = 2 * (t - mu) / timeLength  # Normalize to [-1, 1] range
        y = np.zeros_like(t)
        
        # Approximate implementation of REBURP waveform
        for i in range(len(t)):
            if abs(x[i]) <= 1:
                # Approximate REBURP waveform using Fourier series
                val = 0
                for k in range(1, 6):  # Use the first 5 terms
                    val += (1/k) * np.sin(k * np.pi * x[i])
                y[i] = val
        
        return y
