# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pydantic import Field, BaseModel

class Pulse(BaseModel):
    """
    Pulse class
    """
    path: int = Field(default=0, ge=0, le=1, description="Path selection: 0 for hydrogen channel, 1 for phosphorus channel")
    width: float = Field(default=0, ge=0, le=20000000, description="Width (µs)")
    amplitude: float = Field(default=0, ge=0, le=100, description="Amplitude (%)")
    phase: float = Field(default=0, description="Phase (°)")
    detuning: float = Field(default=0, ge=-10000, le=10000, description="Frequency shift (Hz)")

    def to_dict(self) -> dict:
        """
        Convert Pulse object to dictionary
        
        Returns:
            dict: Dictionary representation of pulse
        """
        return {
            "width": self.width,
            "am": self.amplitude,
            "phase": self.phase,
            "freshift": self.detuning
        }
    
class Gradient(BaseModel):
    """
    Gradient class
    """
    path: int = Field(default=1, ge=0, le=13, description="Shimming path: 0 - 13")
    voltage: float = Field(default=0, ge=-1, le=1, description="Voltage (V)")
    duration: float = Field(default=0, ge=0, le=20000000, description="Duration (µs)")

    def to_dict(self) -> dict:
        """
        Convert Gradient object to dictionary
        
        Returns:
            dict: Dictionary representation of gradient
        """
        return {
            "path": self.path,
            "value": self.voltage,
            "delay": self.duration
        }