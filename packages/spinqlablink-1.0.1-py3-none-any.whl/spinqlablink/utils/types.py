# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Experiment-related type definitions.
"""
class MachineType():
    # Message type definitions
    MSG_REQ_USER_LOGIN = "c_user_login_req"  # Login request
    MSG_RES_USER_LOGIN = "s_user_login_res"  # Login response
    MSG_REQ_USER_LOGOUT = "c_user_logout_req"  # Logout request
    MSG_RES_USER_LOGOUT = "s_user_logout_res"  # Logout response

    MSG_RES_HEARTBEAT = "heartbeat_res"  # Heartbeat response

    # Experiment message type definitions
    MSG_REQ_ADD_EXP_TASK_REQ = "c_add_exp_task_req"  # Experiment execution request
    MSG_RES_ADD_EXP_TASK_RES = "s_add_exp_task_res"  # Experiment execution response
    MSG_POST_EXP_TERMINATED = "s_terminate_exp_task_res"  # Experiment termination response
    MSG_POST_EXP_REMOVED = "s_post_exp_removed"  # Experiment removed
    MSG_POST_EXP_STARTED = "s_post_exp_started"  # Experiment started
    MSG_POST_EXP_STEP_CHANGED = "s_post_exp_step_changed"  # Experiment step changed
    MSG_POST_EXP_DATA_UPDATED = "s_post_exp_data_updated"  # Experiment data updated
    MSG_POST_EXP_CHART_UPDATED_STARTED = "s_post_exp_chart_updated_started"  # Experiment chart update started
    MSG_POST_EXP_CHART_UPDATED = "s_post_exp_chart_updated"  # Experiment chart updated
    MSG_POST_EXP_CHART_UPDATED_FINISHED = "s_post_exp_chart_updated_finished"  # Experiment chart update finished
    MSG_POST_EXP_FINISHED = "s_post_exp_finished"  # Experiment task finished

    # Device-initiated messages
    MSG_POST_PARAM = "s_post_device_param"  # Device parameters
    MSG_POST_LOCK_DATA = "s_post_lock_data"  # Device lock data updated
    MSG_POST_INFO = "s_post_device_info"  # Device information
    MSG_POST_SAMPLE_CALIBRATION = "s_post_sample_calibration_data"  # Sample calibration
    MSG_POST_EXP_QUEUE_UPDATE = "s_post_exp_queue_update"  # Experiment queue updated

class ExperimentType():
    NMR_PHENOMENON_AND_SIGNAL = "EXP_PULSE"
    RABI_OSCILLATIONS = "EXP_RABI"
    QUANTUM_BIT = "EXP_QUBIT"
    QUANTUM_DECOHERENCE_T1 = "EXP_T1"
    QUANTUM_DECOHERENCE_T2 = "EXP_T2"
    QUANTUM_CONTROL = "EXP_QCONTROL"
    QUANTUM_SYSTEM_INITIALIZATION = "EXP_PSTATE"
    QUANTUM_GATES_AND_CIRCUIT = "EXP_QCIRCUIT"
    QUANTUM_STATE_TOMOGRAPHY = "EXP_QREFACTOR"
    QUANTUM_COMPUTING_TASK = "EXP_QALGORITHM"
    
    QUANTUM_ALGORITHM = "EXP_QALGORITHMS"
    INTRODUCTION_TO_QUANTUM_COMPUTING = "EXP_ALGORITHM_BASIC"
    DEUTSCH_ALGORITHM = "EXP_DEUTSCH"
    BERNSTEIN_VARIRANI_ALGORITHM = "EXP_BERNSTEIN"
    GROVER_ALGORITHM = "EXP_GROVER"
    QFT_ALGORITHM = "EXP_QFT"
    HHL_ALGORITHM = "EXP_HHL"
    VQE_ALGORITHM = "EXP_VQE"
    QAOA_ALGORITHM = "EXP_QAOA"

    SPIN_ECHO = "EXP_SPINECHO"
    DYNAMIC_DECOUPLING = "EXP_DYDECO"
    SHAPE_PULSE = "EXP_SHAPEPULSE"
    NUMERICAL_OPTIMIZATION_PULSE = "EXP_NPOPTI"

    PHYSICAL_LAYER_EXPERIMENT = "EXP_LAYER_PHYSICAL"
    CIRCUIT_LAYER_EXPERIMENT = "EXP_LAYER_CIRCUIT"
    
class ExperimentState():
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"