# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Logging utility module that provides configurable logging functionality.
"""

import os
import logging
import datetime
from logging.handlers import RotatingFileHandler


class LoggerManager:
    """Logger manager class used to create and configure loggers."""
    
    # Default log format
    DEFAULT_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Log level mapping
    LEVEL_MAP = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR,
        'critical': logging.CRITICAL
    }
    
    # Singleton-style cache storing all logger instances
    _loggers = {}
    
    @classmethod
    def get_logger(cls, name='spinqlablink', level='info', 
                  log_file=None, max_size=10*1024*1024, backup_count=5,
                  log_format='%(asctime)s [%(levelname)s] %(message)s'):
        """
        Get or create a logger instance.

        Args:
            name: Logger name.
            level: Log level, one of: debug, info, warning, error, critical.
            log_file: Optional log file path; if None, logs only to console.
            max_size: Maximum size of a single log file in bytes (default 10MB).
            backup_count: Number of rotated log files to keep (default 5).
            log_format: Log message format; if None, use DEFAULT_FORMAT.

        Returns:
            logger: Configured logger instance.
        """
        # Return existing logger if present
        if name in cls._loggers:
            return cls._loggers[name]
        
        # Create logger
        logger = logging.getLogger(name)
        logger.setLevel(cls.LEVEL_MAP.get(level.lower(), logging.INFO))
        
        # Avoid adding duplicate handlers
        if logger.handlers:
            return logger
        
        # Configure formatter
        formatter = logging.Formatter(log_format or cls.DEFAULT_FORMAT)
        
        # Add console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # If a log file is specified, add a rotating file handler
        if log_file:
            # Ensure log directory exists
            log_dir = os.path.dirname(log_file)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir)
                
            # Create file handler with rotation support
            file_handler = RotatingFileHandler(
                filename=log_file,
                maxBytes=max_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        # Cache logger instance
        cls._loggers[name] = logger
        return logger


def setup_default_logger(log_level='info', log_dir=None):
    """
    Set up the default logger for the package.

    Args:
        log_level: Log level.
        log_dir: Optional directory to store log files. If None, no file logging.

    Returns:
        logger: Configured default logger instance.
    """
    log_file = None
    if log_dir:
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        timestamp = datetime.datetime.now().strftime('%Y%m%d')
        log_file = os.path.join(log_dir, f'spinqlablink_{timestamp}.log')
    
    return LoggerManager.get_logger(name='spinqlablink', level=log_level, log_file=log_file)


# Create a default logger that can be used directly on import
default_logger = setup_default_logger()


def debug(msg, *args, **kwargs):
    """Log a debug-level message."""
    default_logger.debug(msg, *args, **kwargs)


def info(msg, *args, **kwargs):
    """Log an info-level message."""
    default_logger.info(msg, *args, **kwargs)


def warning(msg, *args, **kwargs):
    """Log a warning-level message."""
    default_logger.warning(msg, *args, **kwargs)


def error(msg, *args, **kwargs):
    """Log an error-level message."""
    default_logger.error(msg, *args, **kwargs)


def critical(msg, *args, **kwargs):
    """Log a critical-level message."""
    default_logger.critical(msg, *args, **kwargs) 