# Copyright 2025 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Quantum circuit utilities.
"""
from typing import List, Tuple, Union, Dict, Any
from .gate import Gate

class Circuit():
    """
    Quantum circuit class used to construct and operate quantum circuits.

    Example:
        from spinqlablink.utils.gate import H, X, CNOT
        from spinqlablink.utils.circuit import Circuit
        
        # Create a quantum circuit
        circuit = Circuit()
        qreg = circuit.allocateQubits(2)
        
        # Add quantum gates
        circuit.append(H, [qreg[0]])
        circuit.append(CNOT, [qreg[0], qreg[1]])
        
        # Get JSON representation of the circuit
        circuit_json = circuit.to_dict()
    """
    def __init__(self,qubits_num: int = 0) -> None:
        if qubits_num <= 0 or qubits_num > 2:
            raise ValueError("Invalid qubits number, must be 1 or 2")
        
        self.qubits_num = qubits_num
        self.circuit = []
        
    def __lshift__(self, gate: Gate):
        """Use the << operator to append a quantum gate to the circuit."""
        self.append(gate)
        return self
        
    def append(self, gate: Gate):
        """
        Append a quantum gate to the circuit.

        Args:
            gate: Quantum gate instance.
        """
        # Initialize current timeslot as 0
        current_timeslot = gate.timeslot
        
        # Check whether each timeslot is already occupied
        while True:
            # Check whether there is a conflict
            conflict = False
            
            # Collect occupied qubit positions
            occupied_positions = set()
            for existing_gate in self.circuit:
                if existing_gate.timeslot == current_timeslot:
                    # Add target qubit index
                    occupied_positions.add(existing_gate.qubitIndex)
                    
                    # Add control qubit index (if any)
                    if existing_gate.controlQubit >= 0:
                        occupied_positions.add(existing_gate.controlQubit)
                    
                    # Add second control qubit index (if any)
                    if existing_gate.controlQubit2 >= 0:
                        occupied_positions.add(existing_gate.controlQubit2)
            
            # Check whether the current gate conflicts with occupied positions
            if gate.qubitIndex in occupied_positions:
                conflict = True
            elif gate.controlQubit >= 0 and gate.controlQubit in occupied_positions:
                conflict = True
            elif gate.controlQubit2 >= 0 and gate.controlQubit2 in occupied_positions:
                conflict = True
            
            # If there is no conflict, use the current timeslot
            if not conflict:
                gate.timeslot = current_timeslot
                break
            
            # If there is a conflict, try the next timeslot
            current_timeslot += 1
        self.circuit.append(gate)

    def to_dict(self) -> dict:
        """
        Convert the circuit to a dictionary representation.

        Returns:
            dict: Dictionary representation of the circuit.
        """
        circuit = []
        for gate in self.circuit:
            circuit.append(gate.to_dict())
        return circuit
    
    def print_circuit(self):
        """
        Print the circuit structure organized by timeslot.
        """
        print("--------------------------------")
        
        # Group gates by timeslot
        gates_by_timeslot = {}
        for gate in self.circuit:
            timeslot = gate.timeslot
            if timeslot not in gates_by_timeslot:
                gates_by_timeslot[timeslot] = []
            gates_by_timeslot[timeslot].append(gate)
        
        # Print gates in timeslot order
        for timeslot in sorted(gates_by_timeslot.keys()):
            gates = gates_by_timeslot[timeslot]
            gate_strs = []
            
            for gate in gates:
                gate_str = gate.type
                
                # Single-qubit gate
                if gate.controlQubit < 0 and gate.controlQubit2 < 0:
                    gate_str += f"({gate.qubitIndex})"
                
                # Two-qubit gate
                elif gate.controlQubit >= 0 and gate.controlQubit2 < 0:
                    gate_str += f"({gate.qubitIndex},{gate.controlQubit})"
                
                # Three-qubit gate
                elif gate.controlQubit >= 0 and gate.controlQubit2 >= 0:
                    gate_str += f"({gate.qubitIndex},{gate.controlQubit},{gate.controlQubit2})"
                
                gate_strs.append(gate_str)
            
            print(f"TS {timeslot}: {' '.join(gate_strs)}")
        
        print("--------------------------------")