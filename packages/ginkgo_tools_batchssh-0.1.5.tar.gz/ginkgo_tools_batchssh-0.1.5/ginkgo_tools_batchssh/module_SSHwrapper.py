"""
作者：霍城 495466557@qq.com

SSH 连接封装模块
提供 SSH 连接功能，支持首次连接确认流程
"""
import paramiko
import uuid
from typing import Optional
from . import module_logger
import os
import stat
from pathlib import PurePosixPath, Path
import chardet

BASE_DIR = os.path.dirname(os.path.abspath(__file__))



logger = module_logger.get_logger(__name__)


class SSHWrapper:
    def __init__(self, host_ip="127.0.0.1", port=22, username="test_user", password="password", host_name="", timeout=10):
        self._ssh_client = None
        self._sftp_client = None
        self.ssh_connected = False
        self.sftp_connected = False

        self.host_ip = host_ip
        self.host_name = host_name
        self.port = port
        self.password = password
        self.username = username
        self.timeout = timeout
        self.uuid_mark = str(uuid.uuid4()) # 标记主机+本次操作，方便日志追踪

        self.encoding = "" # 内容编解码记录

    @property
    def ssh_client(self) -> Optional[paramiko.SSHClient]:
        """SSH客户端实例"""
        if self._ssh_client:
            return self._ssh_client
        else:
            return self.ssh_connect()

    @property
    def sftp_client(self) -> Optional[paramiko.SFTPClient]:
        """SFTP客户端实例"""
        if self._sftp_client:
            return self._sftp_client
        else:
            return self.sftp_connect()

    def _ensure_remote_directory(self, remote_dir: str):
        """确保远程目录存在，如果不存在则递归创建"""
        # 标准化路径并分割
        path_parts = remote_dir.strip('/').split('/')
        current_path = ""

        for part in path_parts:
            if not part:  # 跳过空部分
                continue
            current_path = f"{current_path}/{part}" if current_path else f"/{part}"

            try:
                # 尝试创建当前层级目录
                self.sftp_client.mkdir(current_path)
                logger.debug(f"创建远程目录: {current_path}")
            except OSError:
                # 目录可能已存在，验证是否存在且为目录
                try:
                    stat_info = self.sftp_client.stat(current_path)
                    # 使用Python标准库的stat模块进行目录类型检查

                    if stat.S_ISDIR(stat_info.st_mode):
                        logger.debug(f"确认远程目录已存在: {current_path}")
                    else:
                        logger.warning(f"路径存在但不是目录: {current_path}")
                        return False
                except FileNotFoundError:
                    logger.warning(f"无法创建或确认远程目录: {current_path}")
                    return False

        return True

    def _pattern_remote_files(self, path_pattern: str) -> list:
        """
        扫描远程目录，返回符合通配符模式的所有文件路径

        Args:
            path_pattern (str): 包含通配符的路径模式

        Returns:
            list: 符合条件的文件路径列表
        """
        import re

        # 判断是否为绝对路径
        is_absolute = path_pattern.startswith('/')
        
        # 标准化路径（保留开头的/）
        if is_absolute:
            normalized_path = path_pattern.lstrip('/')
            base_path = '/'
        else:
            normalized_path = path_pattern.lstrip('/')
            base_path = '..'
            
        if not normalized_path:
            return []

        def match_pattern(text: str, pattern: str) -> bool:
            """通配符匹配"""
            regex_pattern = pattern.replace('*', '.*').replace('?', '.')
            regex_pattern = f"^{regex_pattern}$"
            try:
                return bool(re.match(regex_pattern, text))
            except:
                return False

        def expand_paths_recursive(segments: list, current_path: str) -> list:
            """递归展开路径段"""
            if not segments:
                return []

            segment = segments[0]
            remaining_segments = segments[1:]
            results = []

            if '*' in segment or '?' in segment:
                # 通配符段：列出当前目录并匹配
                try:
                    items = self.sftp_client.listdir(current_path)

                    for item in items:
                        if match_pattern(item, segment):
                            # 构造完整路径
                            if current_path == '/' or current_path == '.':
                                full_path = f"{current_path}{item}" if current_path == '/' else item
                            else:
                                full_path = f"{current_path}/{item}"
                            
                            try:
                                stat_info = self.sftp_client.stat(full_path)
                                if stat.S_ISDIR(stat_info.st_mode):
                                    # 是目录，继续递归
                                    if remaining_segments:
                                        results.extend(expand_paths_recursive(remaining_segments, full_path))
                                    else:
                                        # 没有更多段了，列出目录中的文件
                                        dir_files = self.sftp_client.listdir(full_path)
                                        for filename in dir_files:
                                            if full_path == '/':
                                                file_full_path = f"/{filename}"
                                            else:
                                                file_full_path = f"{full_path}/{filename}"
                                            try:
                                                file_stat = self.sftp_client.stat(file_full_path)
                                                if stat.S_ISREG(file_stat.st_mode):
                                                    results.append(file_full_path)
                                            except:
                                                continue
                                elif stat.S_ISREG(stat_info.st_mode) and not remaining_segments:
                                    # 是文件且是最后一段，直接添加
                                    results.append(full_path)
                            except:
                                continue
                except Exception as e:
                    logger.warning(f"处理通配符段 {segment} 在路径 {current_path} 下失败: {e}")
            else:
                # 固定路径段
                if current_path == '/' or current_path == '.':
                    next_path = f"{current_path}{segment}" if current_path == '/' else segment
                else:
                    next_path = f"{current_path}/{segment}"
                
                if remaining_segments:
                    results.extend(expand_paths_recursive(remaining_segments, next_path))
                else:
                    # 最后一段，如果是目录则列出其中文件，如果是文件则直接返回
                    try:
                        stat_info = self.sftp_client.stat(next_path)
                        if stat.S_ISDIR(stat_info.st_mode):
                            # 列出目录中的文件
                            dir_files = self.sftp_client.listdir(next_path)
                            for filename in dir_files:
                                if next_path == '/':
                                    file_full_path = f"/{filename}"
                                else:
                                    file_full_path = f"{next_path}/{filename}"
                                try:
                                    file_stat = self.sftp_client.stat(file_full_path)
                                    if stat.S_ISREG(file_stat.st_mode):
                                        results.append(file_full_path)
                                except:
                                    continue
                        elif stat.S_ISREG(stat_info.st_mode):
                            results.append(next_path)
                    except:
                        pass

            return results

        # 处理完整路径
        path_segments = normalized_path.split('/')
        return expand_paths_recursive(path_segments, base_path)


    def ssh_connect(self):
        """
        连接到远程主机SSH
        
        Returns:
            paramiko.SSHClient: SSH客户端实例
        """
        try:
            self._ssh_client = paramiko.SSHClient()
            # 处理首次SSH连接确认流程
            self._ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            self._ssh_client.connect(
                hostname=self.host_ip,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=self.timeout
            )
            self.ssh_connected = True
            logger.info(f"SSH连接成功：{self.host_ip} - {self.host_name}")
            return self._ssh_client
        except Exception as e:
            logger.error(f"SSH连接失败: ：{self.host_ip} - {self.host_name}：{e}")
            raise None

    def sftp_connect(self):
        """
        连接到远程主机SFTP
        
        Returns:
            paramiko.SFTPClient: SFTP客户端实例
        """
        try:
            if not self._ssh_client:
                self.ssh_connect()
                
            self._sftp_client = self._ssh_client.open_sftp()
            self.sftp_connected = True
            logger.info(f"SFTP连接成功：{self.host_ip} - {self.host_name}")
            return self._sftp_client
        except Exception as e:
            logger.error(f"SFTP连接失败: {self.host_ip} - {self.host_name}：{e}")
            raise None

    # 增量数据包解码工具
    # 传入编码的字符串即可，这里的功能是保证解码流程不报错
    def __chunk_decode(self, src_chunk, dectect_size=2048, do_redectet=False):
        if do_redectet or not (self.encoding):
            # 先做编码检测
            detect_chunk = src_chunk[:dectect_size]
            chardet_result = chardet.detect(detect_chunk)
            encoding = chardet_result["encoding"] if chardet_result["encoding"] else "utf-8"
            self.encoding = encoding
        use_encoding = self.encoding

        decode_chunk = src_chunk.decode(use_encoding, errors="replace")
        return decode_chunk

    def _execute_timeout_manage(self, stdin, stdout, stderr, timeout: int) -> dict:
        """
        管理命令执行的超时和输出读取（类函数）
        
        Args:
            stdin: 标准输入通道
            stdout: 标准输出通道  
            stderr: 错误输出通道
            timeout (int): 超时时间（秒）
            
        Returns:
            dict: 包含执行结果的字典，结构如下：
                {
                    "stdout": "标准输出内容",          # 命令的标准输出
                    "stderr": "错误输出内容",          # 命令的错误输出
                    "stdout_buffer":"标准输出内容原始（编码状态）"
                    "stderr_buffer":"错误输出内容原始（编码状态）"
                    "exit_status": None,              # 退出状态码(int)，超时为None
                    "timeout": 30,                    # 超时时间设置(秒)
                    "do_break": False,                # 是否主动断开(bool)
                    "error": "错误信息",              # 异常时的错误描述
                    "result": False,                  # 执行结果(bool)
                    "channels_closed": True           # 通道是否已关闭(bool，异常时存在)
                }
        """
        import time

        response_dict = {
            "stdout": "",
            "stderr": "",
            "stdout_buffer": b"",
            "stderr_buffer": b"",
            "chunk_encoding":"",
            "exit_status": None,
            "timeout": timeout,
            "do_break": False,  # 主动断开
            "error": "",
            "result": False
        }
        
        start_time = time.time()
        
        try:
            while time.time() - start_time < timeout:
                # 检查命令是否完成
                if stdout.channel.exit_status_ready():
                    response_dict["exit_status"] = stdout.channel.recv_exit_status()
                    response_dict["stdout_buffer"] = stdout.read()
                    response_dict["stderr_buffer"] = stderr.read()
                    if response_dict["exit_status"] == 0:
                        response_dict["result"] = True
                    else:
                        response_dict["result"] = False
                    break

                # 非阻塞读取标准输出，超时时有用
                if stdout.channel.recv_ready():
                    chunk = stdout.channel.recv(1024)
                    response_dict["stdout"] += chunk
                # 非阻塞读取错误输出，超时时有用
                if stderr.channel.recv_stderr_ready():
                    chunk = stderr.channel.recv_stderr(1024)
                    response_dict["stderr"] += chunk

                time.sleep(0.1)
                
            # 超时处理
            if time.time() - start_time >= timeout:
                response_dict["error"] = f"命令执行超过设置时间： ({timeout}秒)"
                response_dict["result"] = False
                response_dict["do_break"] = True # 主动中断操作链接
                
            # 关闭通道
            self._close_channels_safely(stdout, stderr, stdin)
            response_dict["channels_closed"] = True

            # 最后集中解析内容
            stdout = self.__chunk_decode(response_dict.get("stdout_buffer"))
            stderr = self.__chunk_decode(response_dict.get("stderr_buffer"))
            response_dict["stdout"] = stdout
            response_dict["stderr"] = stderr
            response_dict["chunk_encoding"] = self.encoding
            
        except Exception as e:
            response_dict["stderr"] = f"超时管理代码异常: {str(e)}"
            logger.error(f"超时管理代码异常: {str(e)}")
            self._close_channels_safely(stdout, stderr, stdin)
            response_dict["channels_closed"] = True
            
        return response_dict
    
    def _close_channels_safely(self, stdout, stderr, stdin):
        """安全关闭SSH通道"""
        channels = [stdout, stderr, stdin]
        for channel_obj in channels:
            try:
                if hasattr(channel_obj, 'channel') and channel_obj.channel:
                    channel_obj.channel.close()
            except:
                pass


    def execute_command(self, command: str, timeout: int = 30) -> dict:
        """
        在远程主机上执行单个命令，支持超时控制
        
        Args:
            command (str): 要执行的命令
            timeout (int): 超时时间（秒），默认30秒
            
        Returns:
            dict: 包含执行结果的字典，结构如下：
                {
                    "command": "执行的命令",           # 执行的完整命令
                    "stdout": "标准输出内容",          # 命令的标准输出
                    "stderr": "错误输出内容",          # 命令的错误输出
                    "exit_status": 0,                 # 退出状态码(int)，超时为None
                    "result": True,                   # 执行结果(bool)
                    "timeout": 30,                    # 超时时间设置(秒)
                    "do_break": False,                # 是否主动断开(bool)
                    "error": "错误信息",              # 异常时的错误描述
                    "channels_closed": True           # 通道是否已关闭(bool)
                }
        """
        response_dict = dict()
        response_dict["command"] = command


        if not self.ssh_client:raise ConnectionError("SSH未连接")

        stdin, stdout, stderr = self.ssh_client.exec_command(command)

        # 管理命令执行的超时和输出读取
        etm_response_dict = self._execute_timeout_manage(stdin, stdout, stderr, timeout)
        # 合并字典
        response_dict.update(etm_response_dict)

        return response_dict


    def execute_multiple_commands(self, command_list: list,combine_str = "&&", timeout: int = 30) -> dict:
        """
        在远程主机上执行多个命令，使用&&连接
        
        Args:
            command_list (list): 要执行的命令列表
            cwd (str, optional): 工作目录，如果不为None，则在此目录下执行命令
            
        Returns:
            dict: 包含执行结果的字典，结构如下：
                {
                    "stdin": "",                    # 标准输入
                    "stdout": "",                   # 标准输出
                    "stderr": "",                   # 错误输出
                    "exit_status": 0,                # 退出状态码(int)或None(异常时)
                    "command": "cmd1 && cmd2",       # 执行的命令
                    "command_count": 2,              # 命令数量
                    "command_list": ["cmd1", "cmd2"], # 命令列表
                    "result": True                   # 执行结果(bool)
                }
        """
        response_dict = dict()
        response_dict["command_count"] = len(command_list)
        response_dict["command"] = f" {combine_str}".join(command_list)
        
        if not self.ssh_client:raise ConnectionError("SSH未连接")


        stdin, stdout, stderr = self.ssh_client.exec_command(response_dict["command"])
        # 管理命令执行的超时和输出读取
        etm_response_dict = self._execute_timeout_manage(stdin, stdout, stderr, timeout)
        # 合并字典
        response_dict.update(etm_response_dict)

        return response_dict

    def execute_shell_commands(self, command_list: list = None, command_str: str = None, timeout: int = 30) -> dict:
        """
        在同一个会话中执行多个命令，打包为shell脚本执行
        
        Args:
            command_list (list): 要执行的命令列表
            cwd (str, optional): 工作目录，如果不为None，则在此目录下执行命令
            
        Returns:
            dict: 包含执行结果的字典，结构如下：
                {
                    "stdin": "",                    # 标准输入
                    "stdout": "",                   # 标准输出
                    "stderr": "",                   # 错误输出
                    "exit_status": 0,                # 退出状态码(int)
                    "command": "bash script",        # 执行的完整脚本命令
                    "command_list": ["cmd1", "cmd2"], # 原始命令列表
                    "result": True                   # 执行结果(bool)
                }
        """
        if not self.ssh_client: raise ConnectionError("SSH未连接")

        response_dict = dict()
        if command_list:
            # 将命令转换为脚本内容
            script_lines = ["#!/bin/bash"]
            script_lines.extend(command_list)
            script_content = "\n".join(script_lines)
        elif command_str:
            command_str = command_str.replace("\r", "\n")  # 处理可能存在的win换行符问题
            script_content = command_str
        # 使用heredoc方式执行脚本内容
        combined_command = f'bash -s << "EOF"\n{script_content}\nEOF'
        response_dict["command"] = combined_command
        response_dict["command_list"] =  command_list
        response_dict["command_str"] = command_str
        logger.debug(f"执行组装的EOF命令：{combined_command}")
        stdin, stdout, stderr = self.ssh_client.exec_command(combined_command)
        # 管理命令执行的超时和输出读取
        etm_response_dict = self._execute_timeout_manage(stdin, stdout, stderr, timeout)
        # 合并字典
        response_dict.update(etm_response_dict)

        return response_dict


    def commands_to_shell_trans(self, command_list: list = None, command_str: str = None,delete_local_shell: bool = True) -> dict:
        """
        将命令生成为shell文件并传输到远程主机，但不执行
        
        Args:
            command_list (list, optional): 命令列表
            command_str (str, optional): 命令字符串
            
        Returns:
            dict: 包含传输结果的字典，结构如下：
                {
                    "file_name": "operation_xxx.sh",     # 生成的shell文件名
                    "uuid": "uuid-string",               # 操作唯一标识
                    "remote_path": "/home/user/file.sh", # 远程文件路径
                    "result": True,                      # 传输结果(bool)
                    "upload_response": {...}             # 上传响应详情
                }
        """
        response_dict = dict()
        response_dict["result"] = False
        operation_uuid = str(uuid.uuid4())
        file_name = "operation_" + operation_uuid + ".sh"
        file_ready = False
        # 分两种情况写shell文件
        if command_list:
            with open(file_name, "w") as f:
                for command in command_list:
                    f.write(command + "\n")
            file_ready = True
        elif command_str:
            command_str = command_str.replace("\r", "\n")# 处理可能存在的win换行符问题
            with open(file_name, "w",newline="\n") as f:
                f.write(command_str)
            file_ready = True

        if file_ready:
            logger.debug(f"命令封装执行前流程，shell操作文件封装完毕：{file_name}")
            remote_path = f"/home/{self.username}/{file_name}"
            response_dict["file_name"] = file_name
            response_dict["uuid"] = operation_uuid
            response_dict["remote_path"] = remote_path
            response_dict["result"] = True

            # 上传后操作状态更新为上传操作
            logger.debug(f"命令封装执行前流程，开始上传shell操作文件{file_name}到远程主机{self.host_name}，目标远端目录：{remote_path}")
            upload_response = self.sftp_upload_file(file_name, remote_path)
            response_dict["upload_response"] = upload_response
            response_dict["result"] = response_dict["result"] and upload_response["result"]
            if delete_local_shell:os.remove(file_name)
            if response_dict["result"]:
                logger.debug(f"命令封装执行前流程，上传shell操作文件{file_name}到远程主机{self.host_name}成功")
            else:
                logger.warning(f"命令封装执行前流程，上传shell操作文件{file_name}到远程主机{self.host_name}失败，请检查反馈异常为：{upload_response['error']}")
        else:
            logger.warning(f"命令封装执行前流程，shell操作文件封装失败，未提供命令列表或命令字符串")
        return response_dict

    def commands_to_shell_run(self, trans_result: dict, sudo_to_user = False, timeout: int = 30 , transfer_directory:str = "") -> dict:
        """
        运行已传输的shell文件
        
        Args:
            trans_result (dict): commands_to_shell_trans函数的返回结果
            sudo_to_user (str, optional): 切换到指定用户执行，默认为False(不切换)
            
        Returns:
            dict: 包含执行结果的字典，结构与execute_command一致，额外包含：
                {
                    "remote_path": "/path/to/script.sh", # 执行的脚本路径
                    "file_name": "script.sh"             # 脚本文件名
                }
        """
        shell_path = trans_result["remote_path"]
        file_name = trans_result["file_name"]
        if sudo_to_user:
            logger.debug(f"命令封装执行前流程，触发sudo切换执行操作")
            # 执行转移和变更操作
            if transfer_directory:
                sudoers_shell_path = PurePosixPath(transfer_directory, file_name)
                logger.debug(f"命令封装执行前流程，触发sudo切换执行操作，指定转移目录为：{transfer_directory}")
            else:
                if sudo_to_user == "root":sudoers_shell_path = f"/root/{file_name}"
                else:sudoers_shell_path = f"/home/{sudo_to_user}/{file_name}"
                logger.debug(f"命令封装执行前流程，触发sudo切换执行操作，未指定转移目录，使用账户关联目录：{sudoers_shell_path}")

            logger.info(f"命令封装执行后流程，开始将shell文件{shell_path}转移至用户{sudo_to_user}，目标路径为：{sudoers_shell_path}")
            mv_result = self.execute_command(f'sudo su - root -c "chown {sudo_to_user} {shell_path};mv {shell_path} {sudoers_shell_path}"')
            logger.debug(mv_result)
            if not mv_result["result"]:
                logger.warning(f"命令封装执行后流程，将shell文件{shell_path}转移至用户{sudo_to_user}失败，请检查反馈异常为：{mv_result['stderr']}")
                return mv_result
            logger.debug(f"命令封装执行后流程，将shell文件{shell_path}转移至用户{sudo_to_user}成功")

            response_dict = self.execute_command(f'sudo su - {sudo_to_user} -c "sh {sudoers_shell_path}"', timeout= timeout)
            response_dict["remote_path"] = sudoers_shell_path
            response_dict["file_name"] = file_name
            logger.debug(f"命令封装执行后流程，sudo执行shell文件{sudoers_shell_path}")

            self.execute_command(f'sudo su - root -c "rm -f {sudoers_shell_path}"')
            logger.debug(f"命令封装执行后流程，sudo删除shell文件{sudoers_shell_path}")
        else:
            logger.debug(f"命令封装执行后流程，常规运行流程")
            response_dict = self.execute_command(f"sh {shell_path}", timeout= timeout)
            response_dict["remote_path"] = shell_path
            response_dict["file_name"] = file_name
            logger.debug(f"命令封装执行后流程，执行shell文件{shell_path}")

            self.execute_command(f"rm -f {shell_path}")
            logger.debug(f"命令封装执行后流程，删除shell文件{shell_path}")
        return response_dict

    def sftp_upload_file(self, local_path: str, remote_path: str = "") -> dict:
        """
        上传单个文件到远程主机（不支持通配符）

        Args:
            local_path (str): 本地文件路径
            remote_path (str, optional): 远程文件路径，为空时使用本地文件名

        Returns:
            dict: 包含上传结果的字典，结构如下：
                {
                    "local_path": "/local/file.txt",     # 本地文件路径
                    "remote_path": "/remote/file.txt",   # 远程文件路径
                    "result": True,                      # 上传结果(bool)
                    "file_size": 1024,                   # 文件大小(bytes)
                    "error": ""                          # 错误信息(失败时存在)
                }
        """
        response_dict = {
            "local_path": local_path,
            "remote_path": remote_path,
            "result": False
        }

        # 本地文件验证
        if not os.path.exists(local_path):
            response_dict["error"] = f"本地文件不存在: {local_path}"
            logger.warning(response_dict["error"])
            return response_dict
        
        if not os.path.isfile(local_path):
            response_dict["error"] = f"指定路径不是文件: {local_path}"
            logger.warning(response_dict["error"])
            return response_dict

        try:
            sftp = self.sftp_client
            # 执行上传
            sftp.put(local_path, remote_path)
            response_dict["result"] = True
            response_dict["file_size"] = os.path.getsize(local_path)
            
            logger.info(f"文件上传成功: {local_path} -> {remote_path}")
            
        except Exception as e:
            response_dict["result"] = False
            response_dict["error"] = str(e)
            logger.error(f"文件上传失败: {local_path} -> {remote_path}, 错误: {e}")
            
        return response_dict

    def sftp_upload_to(self, local_path: str, remote_dir: str = "") -> dict:
        """
        支持通配符的批量SFTP上传方法

        Args:
            local_path (str): 本地路径，支持通配符模式(*, ?, **) 
            remote_dir (str, optional): 远程目录路径，为空时使用本地文件名

        Returns:
            dict: 包含上传结果的字典，结构如下：
                {
                    "local_pattern": "*.txt",            # 本地匹配模式
                    "remote_base": "/remote/dir/",      # 远程基础路径
                    "uploaded_files": [                  # 成功上传的文件列表
                        {
                            "local_path": "/local/file.txt",
                            "remote_path": "/remote/file.txt",
                            "result": True
                        }
                    ],
                    "failed_files": [                     # 上传失败的文件列表
                        {
                            "local_path": "/local/failed.txt",
                            "remote_path": "/remote/failed.txt",
                            "error": "error message",
                            "result": False
                        }
                    ],
                    "result": True                       # 总体结果(bool)
                }
        """
        import glob
        import os

        # 解析通配符，获取所有匹配的本地文件
        matched_files = glob.glob(local_path, recursive=True)

        response_dict = {
            "local_pattern": local_path,
            "remote_base": remote_dir,
            "uploaded_files": [],
            "failed_files": [],
            "result": True
        }

        # 遍历所有匹配的文件进行上传
        for local_file in matched_files:
            # 检查是否为文件（而不是目录）
            if os.path.isfile(local_file):
                # 计算目标远程路径
                if remote_dir:
                    # 如果指定了远程路径
                    remote_path = os.path.join(remote_dir, os.path.basename(local_file)).replace("\\", "/")
                else:
                    # 如果未指定远程路径，则使用本地文件名
                    remote_path = os.path.basename(local_file)

                # 确保远程目录存在
                if remote_dir:
                    if not self._ensure_remote_directory(remote_dir):
                        response_dict["failed_files"].append({
                            "local_path": local_file,
                            "remote_path": remote_path,
                            "error": "无法创建远程目录，请检查是否是账户权限和目标路径不匹配",
                            "result": False
                        })
                        response_dict["result"] = False
                        logger.warning(f"无法创建远程目录: {remote_dir}，请检查是否是账户权限和目标路径不匹配")
                        continue

                # 执行上传
                try:
                    sftp = self.sftp_client
                    sftp.put(local_file, remote_path)
                    response_dict["uploaded_files"].append({
                        "local_path": local_file,
                        "remote_path": remote_path,
                        "result": True
                    })
                except Exception as e:
                    response_dict["failed_files"].append({
                        "local_path": local_file,
                        "remote_path": remote_path,
                        "error": str(e),
                        "result": False
                    })
                    response_dict["result"] = False

        return response_dict

    def sftp_download_file(self, remote_path: str, local_path: str) -> dict:
        """
        从远程主机下载文件

        Args:
            remote_path (str): 远程文件路径
            local_path (str): 本地文件路径

        Returns:
            dict: 包含下载结果的字典，结构如下：
                {
                    "remote_path": "/remote/file.txt",   # 远程文件路径
                    "local_path": "/local/file.txt",     # 本地文件路径
                    "result": True,                      # 下载结果(bool)
                    "error": ""                          # 错误信息(失败时存在)
                }
        """
        response_dict = dict()
        response_dict["remote_path"] = remote_path
        response_dict["local_path"] = local_path

        try:
            sftp = self.sftp_client
            sftp.get(remote_path, local_path)
            response_dict["result"] = True
        except Exception as e:
            response_dict["result"] = False
            response_dict["error"] = str(e)
        return response_dict



    def sftp_download_to(self, remote_path: str, local_dir: str = "") -> dict:
        """
        支持多级通配符的批量SFTP下载方法

        Args:
            remote_path (str): 远程路径，支持多级通配符模式(*, ?, **) 
            local_dir (str, optional): 本地目录路径，为空时使用远程文件名

        Returns:
            dict: 包含下载结果的字典，结构如下：
                {
                    "remote_pattern": "*.txt",           # 远程匹配模式
                    "local_base": "/local/dir/",        # 本地基础路径
                    "downloaded_files": [                # 成功下载的文件列表
                        {
                            "remote_path": "/remote/file.txt",
                            "local_path": "/local/file.txt",
                            "result": True
                        }
                    ],
                    "failed_files": [                     # 下载失败的文件列表
                        {
                            "remote_path": "/remote/failed.txt",
                            "local_path": "/local/failed.txt",
                            "error": "error message",
                            "result": False
                        }
                    ],
                    "result": True                       # 总体结果(bool)
                }
        """
        import os

        response_dict = {
            "remote_pattern": remote_path,
            "local_base": local_dir,
            "downloaded_files": [],
            "failed_files": [],
            "result": True
        }

        try:
            sftp = self.sftp_client
            
            # 获取所有匹配的远程文件路径
            matched_files = self._pattern_remote_files(remote_path)
            
            # 遍历所有匹配的文件进行下载
            for remote_file_path in matched_files:
                try:
                    # 计算目标本地路径
                    if local_dir:
                        local_file_path = os.path.join(local_dir, os.path.basename(remote_file_path))
                    else:
                        local_file_path = os.path.basename(remote_file_path)

                    # 确保本地目录存在
                    if local_dir and not os.path.exists(local_dir):
                        os.makedirs(local_dir, exist_ok=True)

                    # 执行下载
                    sftp.get(remote_file_path, local_file_path)
                    response_dict["downloaded_files"].append({
                        "remote_path": remote_file_path,
                        "local_path": local_file_path,
                        "result": True
                    })
                    logger.info(f"文件下载成功: {remote_file_path} -> {local_file_path}")
                    
                except Exception as e:
                    response_dict["failed_files"].append({
                        "remote_path": remote_file_path,
                        "local_path": local_file_path if 'local_file_path' in locals() else "",
                        "error": str(e),
                        "result": False
                    })
                    response_dict["result"] = False
                    logger.error(f"文件下载失败: {remote_file_path}, 错误: {e}")

        except Exception as e:
            response_dict["result"] = False
            response_dict["error"] = str(e)
            logger.error(f"批量下载初始化失败: {e}")

        return response_dict


    def close(self):
        """关闭SSH和SFTP连接"""
        if self._sftp_client:
            self._sftp_client.close()
            self.sftp_connected = False




