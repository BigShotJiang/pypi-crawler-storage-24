"""Slack-specific Message model.

This module provides the Slack-specific Message class.
"""

from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from chatom.base import Field, Message, Organization, Thread, User

from .user import SlackUser

if TYPE_CHECKING:
    from chatom.format import FormattedMessage

__all__ = (
    "SlackMessage",
    "SlackMessageSubtype",
)


class SlackMessageSubtype(str, Enum):
    """Slack message subtypes.

    Based on Slack API message subtypes.
    """

    BOT_MESSAGE = "bot_message"
    ME_MESSAGE = "me_message"
    MESSAGE_CHANGED = "message_changed"
    MESSAGE_DELETED = "message_deleted"
    MESSAGE_REPLIED = "message_replied"
    CHANNEL_JOIN = "channel_join"
    CHANNEL_LEAVE = "channel_leave"
    CHANNEL_TOPIC = "channel_topic"
    CHANNEL_PURPOSE = "channel_purpose"
    CHANNEL_NAME = "channel_name"
    CHANNEL_ARCHIVE = "channel_archive"
    CHANNEL_UNARCHIVE = "channel_unarchive"
    FILE_SHARE = "file_share"
    FILE_COMMENT = "file_comment"
    FILE_MENTION = "file_mention"
    PINNED_ITEM = "pinned_item"
    UNPINNED_ITEM = "unpinned_item"
    THREAD_BROADCAST = "thread_broadcast"
    REMINDER_ADD = "reminder_add"
    SLACKBOT_RESPONSE = "slackbot_response"


class SlackMessage(Message):
    """Slack-specific message with additional Slack fields.

    Based on the Slack API message structure.

    Note: Use the inherited `channel` field for the SlackChannel object,
    and `channel_id` for the channel ID string. The `sender_id` field is
    deprecated - use `author` or `author_id` instead.

    Attributes:
        team: The team/workspace ID.
        subtype: The message subtype.
        blocks: Slack Block Kit blocks.
        text: The message text (may differ from content due to mentions).
        latest_reply: Timestamp of latest reply.
        reply_users: List of user IDs who replied.
        is_locked: Whether the thread is locked.
        subscribed: Whether user is subscribed to thread.
        last_read: Timestamp of last read message in thread.
        files: List of attached files.
        upload: Whether this is a file upload message.
        display_as_bot: Whether to display as bot.
        edited: Edit information if message was edited.
    """

    subtype: Optional[SlackMessageSubtype] = Field(
        default=None,
        description="The message subtype.",
    )
    blocks: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Slack Block Kit blocks.",
    )
    text: str = Field(
        default="",
        description="The message text.",
    )
    reply_count: int = Field(
        default=0,
        description="Number of replies in thread.",
    )
    latest_reply: Optional[str] = Field(
        default=None,
        description="Timestamp of latest reply.",
    )
    reply_users: List[SlackUser] = Field(
        default_factory=list,
        description="List of user IDs who replied.",
    )
    is_locked: bool = Field(
        default=False,
        description="Whether the thread is locked.",
    )
    subscribed: bool = Field(
        default=False,
        description="Whether user is subscribed to thread.",
    )
    last_read: Optional[str] = Field(
        default=None,
        description="Timestamp of last read message in thread.",
    )
    files: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="List of attached files.",
    )
    upload: bool = Field(
        default=False,
        description="Whether this is a file upload message.",
    )
    display_as_bot: bool = Field(
        default=False,
        description="Whether to display as bot.",
    )
    edited: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Edit information if message was edited.",
    )

    # Backend-compatibility properties

    @property
    def ts(self) -> Optional[str]:
        """Get the message timestamp (ts)."""
        return self.id or None

    @property
    def thread_ts(self) -> Optional[str]:
        """Get the thread timestamp (thread_ts).

        Returns the thread's id if this message is in a thread,
        None otherwise.
        """
        return self.thread.id if self.thread else None

    @property
    def team(self) -> Optional[Organization]:
        """Get the team/workspace ID."""
        return self.organization if self.organization else None

    @property
    def sender_id(self) -> Optional[str]:
        """Get sender ID (deprecated - use author_id instead)."""
        return self.author_id or None

    @property
    def bot_id(self) -> Optional[str]:
        """Get bot ID from author if author is a bot.

        For bots, the bot_id is the same as the author's id.
        """
        if self.author and self.author.is_bot:
            return self.author.id
        return None

    @property
    def app_id(self) -> Optional[str]:
        """Get app ID from author if available."""
        if self.author:
            return self.author.app_id
        return None

    @property
    def is_thread_reply(self) -> bool:
        """Check if this message is a reply in a thread."""
        return self.thread is not None and self.id != self.thread.id

    @property
    def is_thread_parent(self) -> bool:
        """Check if this message started a thread."""
        return self.reply_count > 0

    @property
    def is_bot_message(self) -> bool:
        """Check if this message is from a bot."""
        return self.bot_id is not None or self.subtype == SlackMessageSubtype.BOT_MESSAGE

    @property
    def is_edited(self) -> bool:
        """Check if this message was edited."""
        return self.edited is not None

    @property
    def has_blocks(self) -> bool:
        """Check if this message has Block Kit blocks."""
        return len(self.blocks) > 0

    @property
    def has_files(self) -> bool:
        """Check if this message has attached files."""
        return len(self.files) > 0

    def mentions_user(self, user: User) -> bool:
        """Check if this message mentions a specific user.

        Slack mentions are in the format <@USER_ID> in the message text.

        Args:
            user: The User to check for.

        Returns:
            True if the user is mentioned, False otherwise.
        """
        user_id = str(user.id)
        mention_format = f"<@{user_id}>"

        # Check content field
        if self.content and mention_format in self.content:
            return True

        # Check text field (may differ from content)
        if self.text and mention_format in self.text:
            return True

        # Check mentions list (User objects) if populated
        for m in self.mentions:
            if str(m.id) == user_id:
                return True

        return False

    @property
    def permalink(self) -> Optional[str]:
        """Get the message permalink if channel_id and ts are available."""
        if self.channel:
            # Note: This is a simplified permalink format
            # Real permalinks require the workspace domain
            ts_no_dot = self.id.replace(".", "")
            return f"https://slack.com/archives/{self.channel.id}/p{ts_no_dot}"
        return None

    def to_formatted(self) -> "FormattedMessage":
        """Convert this Slack message to a FormattedMessage.

        Parses Slack mrkdwn formatting and converts to a FormattedMessage
        that can be rendered for other backends.

        Returns:
            FormattedMessage: The formatted message representation.
        """
        from chatom.format import FormattedAttachment, FormattedMessage

        fm = FormattedMessage()

        # Use the text content (which contains Slack mrkdwn)
        content = self.text or self.content
        if content:
            # Store as plain text - could be enhanced to parse mrkdwn
            fm.add_text(content)

        # Add file attachments
        for file_info in self.files:
            fm.attachments.append(
                FormattedAttachment(
                    filename=file_info.get("name", ""),
                    url=file_info.get("url_private", file_info.get("permalink", "")),
                    content_type=file_info.get("mimetype", ""),
                    size=file_info.get("size", 0),
                )
            )

        # Add metadata
        fm.metadata["source_backend"] = "slack"
        fm.metadata["message_id"] = self.id
        fm.metadata["ts"] = self.id
        if self.author:
            fm.metadata["author_id"] = self.author.id
        if self.channel:
            fm.metadata["channel_id"] = self.channel.id
        if self.thread:
            fm.metadata["thread_ts"] = self.thread.id
        if self.organization:
            fm.metadata["team_id"] = self.organization.id

        return fm

    @classmethod
    def from_formatted(
        cls,
        formatted: "FormattedMessage",
        backend: str = "",
        **kwargs: Any,
    ) -> "SlackMessage":
        """Create a SlackMessage from a FormattedMessage.

        Renders the FormattedMessage in Slack mrkdwn format.

        Args:
            formatted: The FormattedMessage to convert.
            backend: Target backend (ignored, always uses slack format).
            **kwargs: Additional message attributes.

        Returns:
            SlackMessage: A new SlackMessage instance.
        """
        from chatom.format import Format

        content = formatted.render(Format.SLACK_MARKDOWN)

        return cls(
            content=content,
            text=content,
            metadata=dict(formatted.metadata),
            **kwargs,
        )

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "SlackMessage":
        """Create a SlackMessage from a Slack API response.

        Args:
            data: The API response data.

        Returns:
            A SlackMessage instance.
        """
        from chatom.slack.channel import SlackChannel
        from chatom.slack.user import SlackUser

        subtype = None
        if "subtype" in data:
            try:
                subtype = SlackMessageSubtype(data["subtype"])
            except ValueError:
                pass

        # Create author User object with bot info
        # For bots, the bot_id from the API becomes the user's id
        user_id = data.get("user", "")
        bot_id = data.get("bot_id")
        app_id = data.get("app_id")
        is_bot = bot_id is not None
        # Use user_id if available, otherwise use bot_id as the id
        author_id = user_id or bot_id or ""
        author = (
            SlackUser(
                id=author_id,
                name="",  # Name not available in message data
                is_bot=is_bot,
                app_id=app_id,
            )
            if author_id
            else None
        )

        channel_id = data.get("channel", "")
        channel = SlackChannel(id=channel_id) if channel_id else None

        organization_id = data.get("team", "")
        organization = Organization(id=organization_id) if organization_id else None

        thread_id = data.get("thread_ts")
        thread = Thread(id=thread_id) if thread_id else None

        reply_user_ids = data.get("reply_users", [])
        reply_users = [SlackUser(id=uid) for uid in reply_user_ids]

        return cls(
            id=data["ts"],
            channel=channel,
            author=author,
            organization=organization,
            subtype=subtype,
            is_bot=is_bot,
            blocks=data.get("blocks", []),
            text=data.get("text", ""),
            content=data.get("text", ""),
            thread=thread,
            reply_count=data.get("reply_count", 0),
            latest_reply=data.get("latest_reply"),
            reply_users=reply_users,
            is_locked=data.get("is_locked", False),
            subscribed=data.get("subscribed", False),
            last_read=data.get("last_read"),
            files=data.get("files", []),
            upload=data.get("upload", False),
            display_as_bot=data.get("display_as_bot", False),
            edited=data.get("edited"),
            raw=data,
            backend="slack",
        )
