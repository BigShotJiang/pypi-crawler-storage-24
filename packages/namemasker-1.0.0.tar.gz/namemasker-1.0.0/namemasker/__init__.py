"""NameMasker - Privacy masking tool for images."""
__version__ = "1.0.0"
