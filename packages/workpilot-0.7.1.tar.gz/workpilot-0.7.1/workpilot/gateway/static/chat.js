(function() {
  'use strict';

  // ── State ──
  const state = {
    ws: null,
    connected: false,
    waiting: false,
    estopActive: false,
    authFailed: false,
    reconnectDelay: 1000,
    reconnectTimer: null,
    healthTimer: null,
    apiKey: localStorage.getItem('workpilot_api_key') || '',
    entraToken: null,      // Entra ID access token (from MSAL.js)
    entraAccount: null,    // MSAL account object
    msalInstance: null,     // MSAL PublicClientApplication
    entraConfig: null,      // {entra_enabled, entra_tenant_id, entra_client_id}
    theme: localStorage.getItem('workpilot_theme') ||
           (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'),
  };

  // ── DOM refs ──
  const $ = id => document.getElementById(id);
  const chatArea = $('chatArea');
  const chatInput = $('chatInput');
  const sendBtn = $('sendBtn');
  const typingRow = $('typingRow');
  const welcomeScreen = $('welcomeScreen');
  const statusDot = $('statusDot');
  const statusText = $('statusText');
  const estopBtn = $('estopBtn');
  const estopBanner = $('estopBanner');
  const estopReason = $('estopReason');
  const estopResetLink = $('estopResetLink');
  const themeToggle = $('themeToggle');
  const sidebar = $('sidebar');
  const sidebarToggle = $('sidebarToggle');
  const sidebarOverlay = $('sidebarOverlay');
  const sessionsList = $('sessionsList');
  const toolsList = $('toolsList');
  const sidebarFooter = $('sidebarFooter');
  const charCount = $('charCount');
  const apiKeyBtn = $('apiKeyBtn');
  const apiKeyModal = $('apiKeyModal');
  const apiKeyClose = $('apiKeyClose');
  const apiKeyInput = $('apiKeyInput');
  const apiKeyToggleVis = $('apiKeyToggleVis');
  const apiKeyStatus = $('apiKeyStatus');
  const apiKeyClear = $('apiKeyClear');
  const apiKeySave = $('apiKeySave');
  const entraSection = $('entraSection');
  const entraSignedOut = $('entraSignedOut');
  const entraSignedIn = $('entraSignedIn');
  const entraDeviceCodeBtn = $('entraDeviceCodeBtn');
  const entraLoginBtn = $('entraLoginBtn');
  const entraLogoutBtn = $('entraLogoutBtn');
  const entraUserName = $('entraUserName');
  const deviceCodeDisplay = $('deviceCodeDisplay');
  const deviceCodeValue = $('deviceCodeValue');
  const deviceCodeLink = $('deviceCodeLink');
  const deviceCodeStatus = $('deviceCodeStatus');

  // ── Markdown setup ──
  if (typeof marked !== 'undefined') {
    marked.setOptions({
      highlight: function(code, lang) {
        if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
          return hljs.highlight(code, { language: lang }).value;
        }
        if (typeof hljs !== 'undefined') {
          return hljs.highlightAuto(code).value;
        }
        return code;
      },
      breaks: true,
      gfm: true,
    });
  }

  function renderMarkdown(text) {
    if (typeof marked !== 'undefined') {
      let html = marked.parse(text);
      // Defense-in-depth sanitization (no DOMPurify dependency):
      // 1. Strip dangerous tags
      html = html.replace(/<(script|iframe|object|embed|form|input|meta|link|base|svg|math)[^>]*>[\s\S]*?<\/\1>/gi, '');
      html = html.replace(/<(script|iframe|object|embed|form|input|meta|link|base|svg|math)[^>]*\/?>/gi, '');
      // 2. Strip inline event handlers (onclick, onerror, onload, etc.)
      html = html.replace(/\son\w+\s*=/gi, ' data-blocked=');
      // 3. Neutralize javascript: / data: URLs in href/src attributes
      html = html.replace(/(href|src)\s*=\s*["']?\s*(javascript|data|vbscript)\s*:/gi, '$1="about:blank" data-blocked-url="$2:');
      return html;
    }
    return text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  }

  function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    // innerHTML escapes < > & but not quotes — add quote escaping for safe attribute use
    return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ── Theme ──
  function applyTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('workpilot_theme', theme);
    themeToggle.textContent = theme === 'dark' ? '\u2600' : '\u263E';
  }
  applyTheme(state.theme);

  themeToggle.addEventListener('click', () => {
    applyTheme(state.theme === 'dark' ? 'light' : 'dark');
  });

  // ── Sidebar toggle (mobile) ──
  sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    sidebarOverlay.classList.toggle('visible');
  });
  sidebarOverlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('visible');
  });

  // ── API helpers ──
  function apiHeaders() {
    const h = { 'Content-Type': 'application/json' };
    if (state.apiKey) h['X-API-Key'] = state.apiKey;
    else if (state.entraToken) h['Authorization'] = `Bearer ${state.entraToken}`;
    return h;
  }

  async function apiFetch(url, opts = {}) {
    opts.headers = { ...apiHeaders(), ...(opts.headers || {}) };
    const resp = await fetch(url, opts);
    if (resp.status === 401) {
      onAuthFailure();
    }
    return resp;
  }

  function onAuthFailure() {
    if (state.authFailed) return;  // idempotent — prevent re-entrant loops
    state.authFailed = true;
    stopToolPoll();
    // Stop WebSocket reconnect attempts
    if (state.reconnectTimer) {
      clearTimeout(state.reconnectTimer);
      state.reconnectTimer = null;
    }
    // Close existing WebSocket (don't trigger reconnect)
    if (state.ws) {
      state.ws.onclose = null;  // detach handler to prevent re-entry
      state.ws.close();
      state.ws = null;
    }
    state.connected = false;
    // Clear invalid credentials
    state.apiKey = '';
    state.entraToken = null;
    state.entraAccount = null;
    localStorage.removeItem('workpilot_api_key');
    // Reset Entra UI if signed in
    const _entraOut = document.getElementById('entraSignedOut');
    const _entraIn = document.getElementById('entraSignedIn');
    if (_entraOut) _entraOut.style.display = '';
    if (_entraIn) _entraIn.style.display = 'none';
    updateKeyBtnState();
    updateStatus('auth required', false);
    // Show login modal
    openApiKeyModal();
  }

  // ── WebSocket ──
  function wsConnect() {
    if (state.authFailed) return;
    if (state.ws && (state.ws.readyState === WebSocket.OPEN || state.ws.readyState === WebSocket.CONNECTING)) return;

    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    let wsUrl = `${proto}//${location.host}/api/ws`;
    if (state.apiKey) wsUrl += `?key=${encodeURIComponent(state.apiKey)}`;
    else if (state.entraToken) wsUrl += `?token=${encodeURIComponent(state.entraToken)}`;
    state.ws = new WebSocket(wsUrl);

    state.ws.onopen = async () => {
      state.connected = true;
      state.authFailed = false;
      state.reconnectDelay = 1000;
      updateStatus('connected', true);
      await loadRecentHistory();
      await reconcileApprovals();
    };

    state.ws.onmessage = (evt) => {
      let data;
      try { data = JSON.parse(evt.data); } catch { return; }

      if (data.type === 'push') {
        // Push notification from scheduler/background job — don't affect waiting/typing state
        addMessage('assistant', data.content);
        return;
      }

      if (data.type === 'tool_progress') {
        removeToolProgress();
        addToolProgress(data.content || 'tool');
        return;
      }

      if (data.type === 'stream' && !data.done) {
        return;
      }

      state.waiting = false;
      typingRow.classList.remove('visible');
      removeToolProgress();
      stopToolPoll();
      updateSendState();

      if (data.type === 'approval_request') {
        addApprovalCard(data);
      } else if (data.error) {
        addMessage('assistant', `Error: ${data.error}`);
      } else if (data.response !== undefined) {
        // Final poll catches all tool results (including errors, now persisted)
        pollToolCalls().then(() => {
          addMessage('assistant', data.response);
        });
      }
    };

    state.ws.onclose = (evt) => {
      const wasConnected = state.connected;
      state.connected = false;
      stopToolPoll();
      // Code 1008 = Policy Violation (explicit auth rejection)
      // Code 1006 = Abnormal closure — treat as auth failure if credentials
      //   were sent but we never successfully connected
      const hadCredentials = !!(state.apiKey || state.entraToken);
      const authRejected = evt.code === 1008 ||
        (evt.code === 1006 && hadCredentials && !wasConnected);
      if (authRejected || state.authFailed) {
        updateStatus('auth required', false);
        onAuthFailure();
        return;
      }
      updateStatus('disconnected', false);
      scheduleReconnect();
    };

    state.ws.onerror = () => {
      state.connected = false;
      updateStatus('error', false);
    };
  }

  function scheduleReconnect() {
    if (state.authFailed) return;  // Don't reconnect after auth failure
    if (state.reconnectTimer) clearTimeout(state.reconnectTimer);
    state.reconnectTimer = setTimeout(() => {
      if (state.authFailed) return;
      wsConnect();
      state.reconnectDelay = Math.min(state.reconnectDelay * 2, 30000);
    }, state.reconnectDelay);
  }

  function updateStatus(text, ok) {
    statusText.textContent = text;
    statusDot.className = 'status-dot' + (ok ? ' ok' : '');
  }

  // ── Approval card ──
  function addApprovalCard(data) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const riskColour = { low: '#22c55e', medium: '#eab308', high: '#ef4444', critical: '#dc2626' };
    const colour = riskColour[data.risk] || '#8b8fa3';
    const argsText = JSON.stringify(data.args, null, 2);

    const card = document.createElement('div');
    card.className = 'approval-card';
    card.dataset.requestId = data.request_id;
    // Use textContent for untrusted fields (tool_name, reason, argsText) to prevent XSS
    card.innerHTML = `
      <div class="approval-header">
        <span class="approval-icon">⚠</span>
        <span class="approval-title">Approval Required</span>
        <span class="approval-risk" style="background:${colour}20;color:${colour};border:1px solid ${colour}40"></span>
      </div>
      <div class="approval-body">
        <div class="approval-row"><b>Tool</b><code class="tool-val"></code></div>
        <div class="approval-row"><b>Reason</b><span class="reason-val"></span></div>
        <details class="approval-args"><summary>Arguments</summary><pre class="args-val"></pre></details>
        ${data.auto_timeout ? `<div class="approval-timeout">Auto-approving in ${data.auto_timeout}s…</div>` : ''}
      </div>
      <div class="approval-actions">
        <button class="approval-btn approve" data-action="approve">✓ Approve</button>
        <button class="approval-btn deny"    data-action="deny">✗ Deny</button>
        <button class="approval-btn always"  data-action="always">♾ Always Allow</button>
      </div>
      <div class="approval-fallback">Or type <code>yes</code> / <code>no</code> / <code>always</code> in the chat</div>`;
    card.querySelector('.approval-risk').textContent = data.risk || '';
    card.querySelector('.tool-val').textContent  = data.tool_name || '';
    card.querySelector('.reason-val').textContent = data.reason || '';
    card.querySelector('.args-val').textContent   = argsText;

    // Wire approval buttons via data attributes (no inline onclick — XSS safe)
    card.querySelectorAll('.approval-btn[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        const approved = action !== 'deny';
        const always = action === 'always';
        resolveApproval(data.request_id, approved, always);
      });
    });

    chatArea.insertBefore(card, typingRow);
    card.scrollIntoView({ behavior: 'smooth' });

    if (data.auto_timeout) {
      const timerEl = card.querySelector('.approval-timeout');
      const end = Date.now() + data.auto_timeout * 1000;
      const iv = setInterval(() => {
        const rem = Math.max(0, Math.ceil((end - Date.now()) / 1000));
        if (timerEl) timerEl.textContent = `Auto-approving in ${rem}s…`;
        if (rem <= 0) clearInterval(iv);
      }, 1000);
      card.dataset.approvalTimerId = String(iv);
    }
  }

  function _collapseApprovalCard(card, outcome) {
    // outcome: 'approved' | 'denied' | 'resolved' (unknown)
    const labels = { approved: '✅ Approved', denied: '❌ Denied', resolved: '☑ Resolved' };
    const colors = { approved: 'var(--risk-low)', denied: 'var(--risk-high)', resolved: 'var(--text-secondary)' };
    const key = outcome || 'resolved';

    // Replace actions/fallback with result row, hide body
    card.querySelectorAll('.approval-actions, .approval-fallback').forEach(el => el.remove());
    const body = card.querySelector('.approval-body');
    if (body) {
      const row = document.createElement('div');
      row.className = 'approval-row';
      row.innerHTML = `<b>Result</b><span style="font-weight:600;color:${colors[key]}">${labels[key]}</span>`;
      body.appendChild(row);
      body.style.display = 'none';
    }

    // Show result badge in header
    const header = card.querySelector('.approval-header');
    header.style.cursor = 'pointer';
    let badge = header.querySelector('.approval-result-badge');
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'approval-result-badge';
      badge.style.cssText = `margin-left:auto;font-size:11px;font-weight:600;color:${colors[key]}`;
      header.appendChild(badge);
    }
    badge.textContent = labels[key];

    // Toggle expand/collapse body on header click
    header.addEventListener('click', () => {
      const b = card.querySelector('.approval-body');
      if (b) b.style.display = b.style.display === 'none' ? '' : 'none';
    });
  }

  function addResolvedApprovalCard(d) {
    const outcome = d.status === 'approved' ? 'approved' : d.status === 'denied' ? 'denied' : 'resolved';
    const card = document.createElement('div');
    card.className = 'approval-card';
    card.dataset.requestId = d.request_id || '';
    card.innerHTML = `
      <div class="approval-header">
        <span class="approval-icon">⚠</span>
        <span class="approval-title hdr-tool"></span>
        <span class="approval-risk hdr-risk"></span>
      </div>
      <div class="approval-body">
        <div class="approval-row"><b>Tool</b><code class="tool-val"></code></div>
      </div>
      <div class="approval-actions"></div>`;
    card.querySelector('.hdr-tool').textContent = d.tool_name || '';
    card.querySelector('.hdr-risk').textContent = d.risk || '';
    card.querySelector('.tool-val').textContent = d.tool_name || '';
    _collapseApprovalCard(card, outcome);
    chatArea.insertBefore(card, typingRow);
  }

  // Exposed globally for approval resolution (called via addEventListener on data-action buttons)
  window.resolveApproval = async function resolveApproval(requestId, approved, always = false) {
    const card = document.querySelector(`.approval-card[data-request-id="${requestId}"]`);
    if (card) {
      card.querySelectorAll('.approval-btn').forEach(b => { b.disabled = true; });
      // Stop countdown timer and hide the text
      if (card.dataset.approvalTimerId) {
        clearInterval(Number(card.dataset.approvalTimerId));
        delete card.dataset.approvalTimerId;
      }
      const timeoutEl = card.querySelector('.approval-timeout');
      if (timeoutEl) timeoutEl.remove();
    }
    try {
      const r = await apiFetch(`/api/approvals/${requestId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved, always, resolver: state.user || 'web-user' }),
      });
      if (!r.ok) throw new Error(`Server returned ${r.status}`);
      if (card) _collapseApprovalCard(card, approved ? 'approved' : 'denied');
      // Agent continues after approval — show typing and resume polling
      if (approved) {
        state.waiting = true;
        typingRow.classList.add('visible');
        startToolPoll();
        scrollToBottom();
      }
    } catch (e) {
      if (card) card.querySelectorAll('.approval-btn').forEach(b => { b.disabled = false; });
    }
  };

  // ── Messages ──
  function addMessage(role, content, insertPoint) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const row = document.createElement('div');
    row.className = `message-row ${role}`;
    const bubble = document.createElement('div');
    bubble.className = 'message';
    if (role === 'assistant') {
      bubble.innerHTML = renderMarkdown(content);
    } else {
      bubble.textContent = content;
    }
    row.appendChild(bubble);
    chatArea.insertBefore(row, insertPoint || typingRow);
    if (!insertPoint) scrollToBottom();
  }

  // ── Tool Call rendering ──
  function _buildToolCallItem(tc, isLive) {
    const fn = tc.function || {};
    const name = fn.name || tc.name || 'unknown';
    let argsStr = '';
    try {
      const args = typeof fn.arguments === 'string' ? JSON.parse(fn.arguments) : (fn.arguments || {});
      argsStr = JSON.stringify(args, null, 2);
    } catch { argsStr = fn.arguments || '{}'; }

    const item = document.createElement('div');
    item.className = 'tool-call-item';
    item.dataset.toolCallId = tc.id || '';

    const header = document.createElement('div');
    header.className = 'tool-call-header';
    const statusLabel = isLive ? '⏳ doing' : '⚙ called';
    header.innerHTML = `<span class="tool-call-name"></span><span class="tool-call-status running">${statusLabel}</span><span class="tool-call-duration"></span><span class="tool-call-chevron">&#9654;</span>`;
    header.querySelector('.tool-call-name').textContent = name;
    header.addEventListener('click', () => item.classList.toggle('expanded'));

    // Live elapsed timer
    if (isLive) {
      const startTime = Date.now();
      item.dataset.startTime = String(startTime);
      const durEl = header.querySelector('.tool-call-duration');
      const _timer = setInterval(() => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        durEl.textContent = elapsed + 's';
      }, 200);
      item.dataset.timerId = String(_timer);
    }

    const detail = document.createElement('div');
    detail.className = 'tool-call-detail';
    detail.innerHTML = `<div class="tool-call-detail-label">Arguments</div><pre class="tool-args-pre"></pre><div class="tool-call-detail-label">Result</div><pre class="tool-result-pre" style="color:var(--text-tertiary);font-style:italic">waiting...</pre>`;
    detail.querySelector('.tool-args-pre').textContent = argsStr;

    item.appendChild(header);
    item.appendChild(detail);
    return item;
  }

  function addToolCallGroup(assistantMsg, insertPoint, isLive) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const toolCalls = assistantMsg.tool_calls || [];
    if (!toolCalls.length) return;

    const group = document.createElement('div');
    group.className = 'tool-call-group';
    toolCalls.forEach(tc => group.appendChild(_buildToolCallItem(tc, !!isLive)));

    chatArea.insertBefore(group, insertPoint || typingRow);
    if (!insertPoint) scrollToBottom();
    return group;
  }

  function updateToolResult(toolCallId, content, isError) {
    const item = chatArea.querySelector(`.tool-call-item[data-tool-call-id="${CSS.escape(toolCallId)}"]`);
    if (!item) return;
    const statusEl = item.querySelector('.tool-call-status');
    const durEl = item.querySelector('.tool-call-duration');
    const resultPre = item.querySelector('.tool-result-pre');

    // Stop elapsed timer and show final duration
    if (item.dataset.timerId) {
      clearInterval(Number(item.dataset.timerId));
      delete item.dataset.timerId;
    }
    if (item.dataset.startTime && durEl) {
      const elapsed = ((Date.now() - Number(item.dataset.startTime)) / 1000).toFixed(1);
      durEl.textContent = elapsed + 's';
    }

    if (statusEl) {
      statusEl.textContent = isError ? '❌ error' : '✅ done';
      statusEl.className = `tool-call-status ${isError ? 'error' : 'done'}`;
    }
    if (resultPre) {
      resultPre.style.color = '';
      resultPre.style.fontStyle = '';
      const display = content.length > 2000 ? content.slice(0, 2000) + '\n... (truncated)' : content;
      resultPre.textContent = display;
    }
  }

  function addToolProgress(toolName) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const row = document.createElement('div');
    row.className = 'tool-progress-row';
    row.id = 'toolProgressCurrent';
    row.innerHTML = `<div class="tool-progress-spinner"></div><span>Running <strong></strong>...</span>`;
    row.querySelector('strong').textContent = toolName;
    chatArea.insertBefore(row, typingRow);
    scrollToBottom();
    return row;
  }

  function removeToolProgress() {
    const el = document.getElementById('toolProgressCurrent');
    if (el) el.remove();
  }

  // ── Live tool call polling ──
  // Poll the session every 1.5s while waiting to detect new tool calls
  // and render them with "doing" status + elapsed timer. Final poll on
  // response arrival updates remaining cards to "done".
  const WEB_SESSION_ID = 'web:web-user';
  const SESSION_URL = `/api/sessions/${encodeURIComponent(WEB_SESSION_ID)}`;
  let _lastSeenMsgCount = 0;
  let _pollTimer = null;

  function startToolPoll() {
    stopToolPoll();
    _pollTimer = setInterval(pollToolCalls, 1500);
  }

  function stopToolPoll() {
    if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
  }

  async function pollToolCalls() {
    if (state.authFailed) { stopToolPoll(); return; }
    try {
      const resp = await apiFetch(SESSION_URL);
      if (!resp.ok) return;
      const data = await resp.json();
      const allMsgs = data.messages || [];
      const newMsgs = allMsgs.slice(_lastSeenMsgCount);
      _lastSeenMsgCount = allMsgs.length;

      for (const m of newMsgs) {
        if (m.role === 'assistant' && m.tool_calls && m.tool_calls.length) {
          removeToolProgress();
          addToolCallGroup(m, null, true);
        } else if (m.role === 'tool') {
          updateToolResult(m.tool_call_id || '', m.content || '', !!m.is_error);
          // After tool result, agent continues LLM call — show typing (only while waiting)
          if (state.waiting) {
            typingRow.classList.add('visible');
            scrollToBottom();
          }
        }
      }
    } catch (_) { /* best-effort */ }
  }

  function clearMessages() {
    // Stop any running tool-call elapsed timers before removing DOM
    chatArea.querySelectorAll('.tool-call-item[data-timer-id]').forEach(el => {
      clearInterval(Number(el.dataset.timerId));
    });
    chatArea.querySelectorAll('.message-row, .tool-call-group, .tool-progress-row, .history-divider, .history-load-more, .approval-card')
      .forEach(r => r.remove());
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      chatArea.scrollTop = chatArea.scrollHeight;
    });
  }

  // ── Send ──
  function sendMessage() {
    const text = chatInput.value.trim();
    if (!text || !state.connected || state.waiting) return;

    addMessage('user', text);
    chatInput.value = '';
    chatInput.style.height = '44px';
    charCount.textContent = '0';
    updateSendState();

    state.waiting = true;
    typingRow.classList.add('visible');
    scrollToBottom();

    // Start polling for tool calls while the agent works
    startToolPoll();

    state.ws.send(JSON.stringify({ prompt: text, sender_id: 'web-user' }));
  }

  function updateSendState() {
    const hasText = chatInput.value.trim().length > 0;
    sendBtn.disabled = !hasText || !state.connected || state.waiting;
  }

  sendBtn.addEventListener('click', sendMessage);
  chatInput.addEventListener('input', () => {
    charCount.textContent = chatInput.value.length;
    updateSendState();
    // Auto-resize
    chatInput.style.height = '44px';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    acUpdate();
  });

  // ── Slash-command autocomplete ──────────────────────────────────────────
  const SLASH_COMMANDS = [
    { cmd: '/new',        desc: 'Clear session, start fresh' },
    { cmd: '/help',       desc: 'Show all available commands' },
    { cmd: '/status',     desc: 'Show agent status and session info' },
    { cmd: '/memory',     desc: 'Show MEMORY.md content' },
    { cmd: '/tools',      desc: 'List available tools' },
    { cmd: '/skills',     desc: 'List loaded skills' },
    { cmd: '/history',    desc: 'Show last 10 messages in session' },
    { cmd: '/history 20', desc: 'Show last 20 messages in session' },
    { cmd: '/model',      desc: 'Show current model' },
  ];

  const acEl = document.getElementById('slashAc');
  let acItems = [], acIdx = -1;

  function acUpdate() {
    const val = chatInput.value;
    if (!val.startsWith('/') || val.includes(' ')) { acHide(); return; }
    const q = val.toLowerCase();
    acItems = SLASH_COMMANDS.filter(c => c.cmd.startsWith(q));
    acIdx = -1;
    acEl.innerHTML = '';
    acItems.forEach((item, i) => {
      const d = document.createElement('div');
      d.className = 'slash-ac-item';
      d.setAttribute('role', 'option');
      d.setAttribute('aria-selected', 'false');
      d.id = `slash-ac-opt-${i}`;
      d.innerHTML = `<span class="slash-ac-cmd">${item.cmd}</span><span class="slash-ac-desc">${item.desc}</span>`;
      d.addEventListener('mousedown', e => { e.preventDefault(); acSelect(i); });
      acEl.appendChild(d);
    });
    const visible = acItems.length > 0;
    acEl.style.display = visible ? 'block' : 'none';
    chatInput.setAttribute('aria-expanded', visible ? 'true' : 'false');
  }

  function acHide() {
    acEl.style.display = 'none';
    chatInput.setAttribute('aria-expanded', 'false');
    chatInput.removeAttribute('aria-activedescendant');
    acItems = []; acIdx = -1;
  }

  function acHighlight(i) {
    [...acEl.querySelectorAll('.slash-ac-item')].forEach((el, j) => {
      el.classList.toggle('active', j === i);
      el.setAttribute('aria-selected', j === i ? 'true' : 'false');
    });
    chatInput.setAttribute('aria-activedescendant', `slash-ac-opt-${i}`);
    acIdx = i;
  }

  function acSelect(i) {
    const item = acItems[i];
    if (!item) return;
    chatInput.value = item.cmd + ' ';
    acHide();
    chatInput.dispatchEvent(new Event('input'));
    chatInput.focus();
  }

  chatInput.addEventListener('keydown', (e) => {
    if (acItems.length) {
      if (e.key === 'ArrowUp')   { e.preventDefault(); acHighlight((acIdx - 1 + acItems.length) % acItems.length); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); acHighlight((acIdx + 1) % acItems.length); return; }
      if (e.key === 'Tab')       { e.preventDefault(); acSelect(acIdx >= 0 ? acIdx : 0); return; }
      if (e.key === 'Escape')    { acHide(); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (acIdx >= 0) { acSelect(acIdx); } else { sendMessage(); } }
  });

  chatInput.addEventListener('blur', () => setTimeout(acHide, 150));

  // ── Health polling ──
  async function reconcileApprovals() {
    // Fetch actually-pending approvals from the server, then:
    // 1. Add any pending approvals not already rendered
    // 2. Mark history approval cards that are no longer pending as resolved
    try {
      const resp = await apiFetch('/api/approvals');
      if (!resp.ok) return;
      const data = await resp.json();
      const pendingIds = new Set((data.pending || []).map(r => r.id));

      // Add truly pending approvals not yet in DOM
      (data.pending || []).forEach(req => {
        if (!chatArea.querySelector(`.approval-card[data-request-id="${CSS.escape(req.id)}"]`)) {
          addApprovalCard({
            type: 'approval_request',
            request_id: req.id,
            tool_name: req.tool_name,
            args: req.args || {},
            risk: req.risk || 'medium',
            reason: req.reason || '',
            agent_name: req.agent_name || '',
            auto_timeout: null,
          });
        }
      });

      // Build resolved outcomes map from server
      const resolvedMap = {};
      (data.resolved || []).forEach(r => { resolvedMap[r.id] = r.status; });

      // Mark stale approval cards (from history) as resolved + collapse
      chatArea.querySelectorAll('.approval-card[data-request-id]').forEach(card => {
        const rid = card.dataset.requestId;
        if (!pendingIds.has(rid) && card.querySelector('.approval-btn')) {
          if (card.dataset.approvalTimerId) {
            clearInterval(Number(card.dataset.approvalTimerId));
            delete card.dataset.approvalTimerId;
          }
          const timeoutEl = card.querySelector('.approval-timeout');
          if (timeoutEl) timeoutEl.remove();
          _collapseApprovalCard(card, resolvedMap[rid] || 'resolved');
        }
      });
    } catch (_) {}
  }

  async function loadRecentHistory() {
    try {
      // Try to load full session history (including tool messages)
      const resp = await apiFetch(SESSION_URL);
      if (!resp.ok) {
        // Fallback to recent visible messages
        await loadRecentHistoryFallback();
        return;
      }
      const data = await resp.json();
      const allMessages = data.messages || [];
      if (!allMessages.length) return;

      // Show last N messages (configurable), with a "load more" button
      const INITIAL_LIMIT = 30;
      const displayMessages = allMessages.length > INITIAL_LIMIT ? allMessages.slice(-INITIAL_LIMIT) : allMessages;
      const hasMore = allMessages.length > INITIAL_LIMIT;

      if (hasMore) {
        const loadMoreDiv = document.createElement('div');
        loadMoreDiv.className = 'history-load-more';
        const btn = document.createElement('button');
        btn.textContent = `Load earlier messages (${allMessages.length - INITIAL_LIMIT} more)`;
        btn.addEventListener('click', () => {
          loadMoreDiv.remove();
          renderSessionMessages(allMessages.slice(0, allMessages.length - INITIAL_LIMIT), true);
        });
        loadMoreDiv.appendChild(btn);
        chatArea.insertBefore(loadMoreDiv, typingRow);
      }

      const divider = document.createElement('div');
      divider.className = 'history-divider';
      divider.textContent = `— session history (${allMessages.length} messages) —`;
      chatArea.insertBefore(divider, typingRow);

      renderSessionMessages(displayMessages, false);
      _lastSeenMsgCount = allMessages.length;  // sync counter
    } catch (_) {
      await loadRecentHistoryFallback();
    }
  }

  async function loadRecentHistoryFallback() {
    try {
      const resp = await apiFetch('/api/session/recent?channel=web&sender_id=web-user&limit=20');
      if (!resp.ok) return;
      const messages = await resp.json();
      if (!messages.length) return;
      const divider = document.createElement('div');
      divider.className = 'history-divider';
      divider.textContent = `— last ${messages.length} messages —`;
      chatArea.insertBefore(divider, typingRow);
      messages.forEach(m => {
        if (m.role === 'user') addMessage('user', m.content || '');
        else if (m.role === 'assistant' && m.content) addMessage('assistant', m.content);
        else if (m.role === 'approval_request') {
          try {
            const d = JSON.parse(m.content);
            if (d.status === 'pending') {
              addApprovalCard({ type: 'approval_request', ...d, auto_timeout: null });
            } else {
              addResolvedApprovalCard(d);
            }
          } catch (_) {}
        }
      });
      // Sync counter — fallback doesn't know total, so fetch it
      apiFetch(SESSION_URL).then(r => r.ok ? r.json() : null)
        .then(d => { if (d) _lastSeenMsgCount = (d.messages || []).length; })
        .catch(() => {});
    } catch (_) {}
  }

  function renderSessionMessages(messages, prepend) {
    const insertPoint = prepend
      ? (chatArea.querySelector('.history-divider') || typingRow)
      : typingRow;

    messages.forEach(m => {
      if (m.role === 'user') {
        addMessage('user', m.content || '', insertPoint);
      } else if (m.role === 'assistant') {
        if (m.tool_calls && m.tool_calls.length) {
          if (m.content) addMessage('assistant', m.content, insertPoint);
          addToolCallGroup(m, insertPoint);
        } else if (m.content) {
          addMessage('assistant', m.content, insertPoint);
        }
      } else if (m.role === 'tool') {
        const toolCallId = m.tool_call_id || '';
        if (toolCallId) {
          updateToolResult(toolCallId, m.content || '', !!m.is_error);
        }
      } else if (m.role === 'approval_request') {
        try {
          const d = JSON.parse(m.content);
          if (d.status === 'pending') {
            addApprovalCard({ type: 'approval_request', ...d, auto_timeout: null });
          } else {
            addResolvedApprovalCard(d);
          }
        } catch (_) {}
      } else if (m.role === 'approval_resolved') {
        // Server persists resolution — update the matching approval card
        try {
          const d = JSON.parse(m.content);
          const rid = d.request_id;
          const card = rid && chatArea.querySelector(`.approval-card[data-request-id="${CSS.escape(rid)}"]`);
          if (card && card.querySelector('.approval-btn')) {
            _collapseApprovalCard(card, d.status || 'resolved');
          }
        } catch (_) {}
      }
    });

  }

  async function fetchHealth() {
    try {
      const resp = await fetch('/api/health');  // public endpoint — no auth needed
      if (!resp.ok) return;
      const data = await resp.json();

      state.estopActive = data.estop?.halted || false;
      estopBanner.classList.toggle('visible', state.estopActive);
      estopReason.textContent = data.estop?.reason || '';
      estopBtn.classList.toggle('active', state.estopActive);

      sidebarFooter.textContent = `WorkPilot ${data.version || ''}`;
    } catch { /* ignore */ }
  }

  // ── Sessions ──
  async function fetchSessions() {
    try {
      sessionsList.innerHTML = '<div class="sidebar-empty">Loading...</div>';
      const resp = await apiFetch('/api/sessions');
      if (!resp.ok) { sessionsList.innerHTML = '<div class="sidebar-empty">Failed to load</div>'; return; }
      const data = await resp.json();

      if (!data.length) {
        sessionsList.innerHTML = '<div class="sidebar-empty">No sessions yet</div>';
        return;
      }

      // Split into user sessions and scheduler sessions
      const userSessions = data.filter(s => !s.session_id.startsWith('scheduler:'));
      const schedSessions = data.filter(s => s.session_id.startsWith('scheduler:'));

      sessionsList.innerHTML = '';
      if (!userSessions.length && !schedSessions.length) {
        sessionsList.innerHTML = '<div class="sidebar-empty">No sessions yet</div>';
        return;
      }

      userSessions.forEach(s => {
        const item = document.createElement('div');
        item.className = 'session-item';
        item.innerHTML = `<span class="session-name" title="${escapeHtml(s.session_id)}">${escapeHtml(s.session_id)}</span><span class="count">${s.message_count}</span>`;
        item.addEventListener('click', () => loadSession(s.session_id));
        sessionsList.appendChild(item);
      });

      // Scheduler sessions — collapsed by default
      if (schedSessions.length) {
        const details = document.createElement('details');
        details.style.cssText = 'margin-top:6px';
        details.innerHTML = `<summary style="font-size:10px;color:var(--text-tertiary);cursor:pointer;padding:4px 10px;user-select:none">Scheduler (${schedSessions.length})</summary>`;
        schedSessions.forEach(s => {
          const item = document.createElement('div');
          item.className = 'session-item';
          item.innerHTML = `<span class="session-name" title="${escapeHtml(s.session_id)}">${escapeHtml(s.session_id.replace('scheduler:', ''))}</span><span class="count">${s.message_count}</span>`;
          item.addEventListener('click', () => loadSession(s.session_id));
          details.appendChild(item);
        });
        sessionsList.appendChild(details);
      }
    } catch {
      sessionsList.innerHTML = '<div class="sidebar-empty">Error loading</div>';
    }
  }

  async function loadSession(sessionId) {
    try {
      const resp = await apiFetch(`/api/sessions/${encodeURIComponent(sessionId)}`);
      if (!resp.ok) return;
      const data = await resp.json();

      clearMessages();
      if (welcomeScreen.parentNode) welcomeScreen.remove();

      const messages = data.messages || [];
      renderSessionMessages(messages, false);
      // Only sync poll counter when viewing the active web session
      if (sessionId === WEB_SESSION_ID) {
        _lastSeenMsgCount = messages.length;
      }
      scrollToBottom();

      // Close mobile sidebar
      sidebar.classList.remove('open');
      sidebarOverlay.classList.remove('visible');
    } catch { /* ignore */ }
  }

  // ── Tools ──
  async function fetchTools() {
    try {
      toolsList.innerHTML = '<div class="sidebar-empty">Loading...</div>';
      const resp = await apiFetch('/api/tools');
      if (!resp.ok) { toolsList.innerHTML = '<div class="sidebar-empty">Failed to load</div>'; return; }
      const data = await resp.json();

      if (!data.length) {
        toolsList.innerHTML = '<div class="sidebar-empty">No tools registered</div>';
        return;
      }

      toolsList.innerHTML = '';
      const builtin = data.filter(t => t.type === 'builtin');
      const mcpAll = data.filter(t => t.type === 'mcp_server' || t.type === 'mcp_tool');

      builtin.forEach(t => {
        const item = document.createElement('div');
        item.className = 'tool-item';
        item.title = t.description || '';
        const status = t.active ? 'active' : 'inactive';
        item.innerHTML = `<span class="status-dot ${status}"></span><span class="tool-name">${escapeHtml(t.name)}</span><span class="tool-type">${status}</span>`;
        toolsList.appendChild(item);
      });

      if (mcpAll.length) {
        const sep = document.createElement('div');
        sep.style.cssText = 'font-size:10px;color:var(--text-tertiary);padding:8px 10px 4px;text-transform:uppercase;letter-spacing:.06em;';
        sep.textContent = 'MCP';
        toolsList.appendChild(sep);
        mcpAll.forEach(t => {
          const item = document.createElement('div');
          item.className = 'tool-item';
          item.title = t.description || '';
          const statusCls = t.type === 'mcp_server' ? (t.state || 'idle') : (t.active ? 'active' : 'inactive');
          const label = t.type === 'mcp_server' ? (t.state || 'idle') : (t.active ? 'active' : 'inactive');
          const extra = t.tool_count ? ` (${t.tool_count})` : '';
          item.innerHTML = `<span class="status-dot ${statusCls}"></span><span class="tool-name">${escapeHtml(t.name)}</span><span class="tool-type">${label}${extra}</span>`;
          toolsList.appendChild(item);
        });
      }
    } catch {
      toolsList.innerHTML = '<div class="sidebar-empty">Error loading</div>';
    }
  }

  // ── E-stop ──
  estopBtn.addEventListener('click', async () => {
    if (state.estopActive) {
      // Already active — show info
      return;
    }
    if (!confirm('Trigger Emergency Stop? This will halt all agent processing.')) return;
    try {
      await apiFetch('/api/estop', {
        method: 'POST',
        body: JSON.stringify({ reason: 'Manual E-stop from web UI' }),
      });
      fetchHealth();
    } catch { /* ignore */ }
  });

  estopResetLink.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/api/reset', {
        method: 'POST',
        body: JSON.stringify({ actor: 'web-ui' }),
      });
      fetchHealth();
    } catch { /* ignore */ }
  });

  // ── Refresh buttons ──
  $('refreshSessions').addEventListener('click', fetchSessions);
  $('refreshTools').addEventListener('click', fetchTools);

  // ── API Key Modal ──
  function updateKeyBtnState() {
    const authed = !!state.apiKey || !!state.entraToken;
    apiKeyBtn.classList.toggle('key-active', authed);
    apiKeyBtn.title = state.entraToken ? 'Signed in (Entra ID)' : state.apiKey ? 'API Key (set)' : 'Authentication';
  }
  updateKeyBtnState();

  function openApiKeyModal() {
    apiKeyInput.value = state.apiKey;
    apiKeyStatus.textContent = '';
    apiKeyStatus.className = 'status-msg';
    apiKeyModal.classList.add('visible');
    setTimeout(() => apiKeyInput.focus(), 100);
  }

  function closeApiKeyModal() {
    apiKeyModal.classList.remove('visible');
  }

  apiKeyBtn.addEventListener('click', openApiKeyModal);
  apiKeyClose.addEventListener('click', closeApiKeyModal);
  apiKeyModal.addEventListener('click', (e) => {
    if (e.target === apiKeyModal) closeApiKeyModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && apiKeyModal.classList.contains('visible')) closeApiKeyModal();
  });

  apiKeyToggleVis.addEventListener('click', () => {
    const isPassword = apiKeyInput.type === 'password';
    apiKeyInput.type = isPassword ? 'text' : 'password';
    apiKeyToggleVis.textContent = isPassword ? 'Hide key' : 'Show key';
  });

  apiKeySave.addEventListener('click', async () => {
    const key = apiKeyInput.value.trim();
    state.apiKey = key;
    if (key) {
      localStorage.setItem('workpilot_api_key', key);
    } else {
      localStorage.removeItem('workpilot_api_key');
    }
    updateKeyBtnState();

    // Test the key by hitting /api/tools (authed)
    apiKeyStatus.textContent = 'Testing...';
    apiKeyStatus.className = 'status-msg';
    try {
      const resp = await apiFetch('/api/tools');
      if (resp.ok) {
        apiKeyStatus.textContent = 'Authenticated';
        apiKeyStatus.className = 'status-msg ok';
        state.authFailed = false;  // clear auth failure so wsConnect works
        setTimeout(closeApiKeyModal, 800);
        // Reconnect WebSocket with new key
        if (state.ws) { state.ws.close(); }
        wsConnect();
        fetchSessions();
        fetchTools();
      } else if (resp.status === 401) {
        apiKeyStatus.textContent = 'Invalid key';
        apiKeyStatus.className = 'status-msg err';
      } else {
        apiKeyStatus.textContent = `Saved (server: ${resp.status})`;
        apiKeyStatus.className = 'status-msg';
        setTimeout(closeApiKeyModal, 800);
      }
    } catch {
      // Server not reachable — just save and close
      apiKeyStatus.textContent = 'Saved (offline)';
      apiKeyStatus.className = 'status-msg';
      setTimeout(closeApiKeyModal, 800);
    }
  });

  apiKeyClear.addEventListener('click', () => {
    apiKeyInput.value = '';
    state.apiKey = '';
    localStorage.removeItem('workpilot_api_key');
    updateKeyBtnState();
    apiKeyStatus.textContent = 'Key cleared';
    apiKeyStatus.className = 'status-msg';
  });

  apiKeyInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') apiKeySave.click();
  });

  // ── Entra ID (MSAL.js) ──
  async function fetchAuthConfig() {
    try {
      const resp = await fetch('/api/auth/config');
      if (!resp.ok) return;
      state.entraConfig = await resp.json();

      if (state.entraConfig.entra_enabled) {
        entraSection.style.display = '';
        // Show popup (redirect) button as primary if MSAL.js loaded
        if (typeof msal !== 'undefined') {
          entraLoginBtn.style.display = 'flex';
          await initMsal(); // May set state.entraToken via silent refresh
        }
      }

      const authRequired = state.entraConfig.api_key_enabled || state.entraConfig.entra_enabled;
      if (state.authFailed || (authRequired && !state.apiKey && !state.entraToken)) {
        openApiKeyModal();
      } else {
        closeApiKeyModal();
        // Auth not required or already authenticated — connect now
        if (!state.ws || state.ws.readyState > WebSocket.OPEN) {
          wsConnect();
          fetchSessions();
          fetchTools();
        }
      }
    } catch { /* ignore */ }
  }

  async function initMsal() {
    const cfg = state.entraConfig;
    if (!cfg || !cfg.entra_enabled) return;

    const msalConfig = {
      auth: {
        clientId: cfg.entra_client_id,
        authority: `https://login.microsoftonline.com/${cfg.entra_tenant_id}`,
        redirectUri: window.location.origin + '/auth/spa-callback',
      },
      cache: { cacheLocation: 'localStorage' },
    };

    state.msalInstance = new msal.PublicClientApplication(msalConfig);

    // MSAL.js v3 requires explicit initialization
    if (typeof state.msalInstance.initialize === 'function') {
      await state.msalInstance.initialize();
    }

    // Check for existing account
    const accounts = state.msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      state.entraAccount = accounts[0];
      acquireTokenSilent();
    }
  }

  async function acquireTokenSilent() {
    if (!state.msalInstance || !state.entraAccount) return;
    try {
      const result = await state.msalInstance.acquireTokenSilent({
        account: state.entraAccount,
        scopes: [`${state.entraConfig.entra_client_id}/access_as_user`],
      });
      onEntraLogin(result);
    } catch {
      // Silent failed — user needs to re-login
      onEntraLogout();
    }
  }

  function onEntraLogin(result) {
    state.entraToken = result.accessToken;
    state.entraAccount = result.account;
    const name = result.account.name || result.account.username || 'Signed in';
    entraUserName.textContent = name;
    entraSignedOut.style.display = 'none';
    entraSignedIn.style.display = '';
    updateKeyBtnState();
    closeApiKeyModal();
    // Reconnect WS with new token
    if (state.ws) { state.ws.close(); }
    wsConnect();
    fetchSessions();
    fetchTools();
  }

  function onEntraLogout() {
    state.entraToken = null;
    state.entraAccount = null;
    entraSignedOut.style.display = '';
    entraSignedIn.style.display = 'none';
    entraUserName.textContent = '';
    updateKeyBtnState();
  }

  // ── Device code flow (no redirect URI needed) ──
  let deviceCodePollTimer = null;

  entraDeviceCodeBtn.addEventListener('click', async () => {
    entraDeviceCodeBtn.disabled = true;
    entraDeviceCodeBtn.style.opacity = '0.6';
    deviceCodeDisplay.style.display = 'none';
    deviceCodeStatus.textContent = 'Starting...';

    try {
      const resp = await fetch('/api/auth/device-code', { method: 'POST' });
      if (!resp.ok) {
        const err = await resp.json();
        apiKeyStatus.textContent = err.message || 'Failed to start';
        apiKeyStatus.className = 'status-msg err';
        entraDeviceCodeBtn.disabled = false;
        entraDeviceCodeBtn.style.opacity = '';
        return;
      }
      const data = await resp.json();
      deviceCodeValue.textContent = data.user_code;
      deviceCodeLink.href = data.verification_uri;
      deviceCodeStatus.textContent = 'Waiting for approval...';
      deviceCodeDisplay.style.display = '';

      // Start polling
      if (deviceCodePollTimer) clearInterval(deviceCodePollTimer);
      deviceCodePollTimer = setInterval(async () => {
        try {
          const pollResp = await fetch('/api/auth/device-code/poll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_code: data.user_code }),
          });
          const pollData = await pollResp.json();

          if (pollData.status === 'complete') {
            clearInterval(deviceCodePollTimer);
            deviceCodePollTimer = null;
            state.entraToken = pollData.access_token;
            state.entraAccount = pollData.account;
            const name = pollData.account.name || pollData.account.username || 'Signed in';
            entraUserName.textContent = name;
            entraSignedOut.style.display = 'none';
            entraSignedIn.style.display = '';
            updateKeyBtnState();
            if (state.ws) { state.ws.close(); }
            wsConnect();
            fetchSessions();
            fetchTools();
            apiKeyStatus.textContent = 'Signed in';
            apiKeyStatus.className = 'status-msg ok';
            setTimeout(closeApiKeyModal, 600);
          } else if (pollData.status === 'error') {
            clearInterval(deviceCodePollTimer);
            deviceCodePollTimer = null;
            deviceCodeStatus.textContent = pollData.message || 'Failed';
            entraDeviceCodeBtn.disabled = false;
            entraDeviceCodeBtn.style.opacity = '';
          }
          // 'pending' — keep polling
        } catch { /* network error — keep polling */ }
      }, 3000);
    } catch {
      apiKeyStatus.textContent = 'Network error';
      apiKeyStatus.className = 'status-msg err';
      entraDeviceCodeBtn.disabled = false;
      entraDeviceCodeBtn.style.opacity = '';
    }
  });

  // ── Popup flow (requires redirect URI configured) ──
  entraLoginBtn.addEventListener('click', async () => {
    if (!state.msalInstance) return;
    try {
      const result = await state.msalInstance.loginPopup({
        scopes: [`${state.entraConfig.entra_client_id}/access_as_user`],
      });
      onEntraLogin(result);
      apiKeyStatus.textContent = 'Signed in';
      apiKeyStatus.className = 'status-msg ok';
      setTimeout(closeApiKeyModal, 600);
    } catch (err) {
      apiKeyStatus.textContent = err.errorMessage || 'Login failed';
      apiKeyStatus.className = 'status-msg err';
    }
  });

  entraLogoutBtn.addEventListener('click', () => {
    if (deviceCodePollTimer) { clearInterval(deviceCodePollTimer); deviceCodePollTimer = null; }
    deviceCodeDisplay.style.display = 'none';
    entraDeviceCodeBtn.disabled = false;
    entraDeviceCodeBtn.style.opacity = '';
    if (state.msalInstance && state.entraAccount) {
      state.msalInstance.logoutPopup({ account: state.entraAccount }).catch(() => {});
    }
    onEntraLogout();
    if (state.ws) { state.ws.close(); }
  });

  // ── Init ──
  fetchAuthConfig();  // Detect Entra ID config, init MSAL if available
  fetchHealth();
  // WS, sessions, and tools require auth — only connect if already authenticated.
  // On fresh login, the save/login handlers call wsConnect + fetchSessions + fetchTools.
  if (state.apiKey || state.entraToken) {
    wsConnect();
    fetchSessions();
    fetchTools();
  }

  state.healthTimer = setInterval(fetchHealth, 30000);
})();
