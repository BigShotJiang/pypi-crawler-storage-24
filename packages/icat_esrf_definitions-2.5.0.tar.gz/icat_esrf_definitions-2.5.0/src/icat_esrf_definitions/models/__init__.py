import warnings

from .dataset import IcatDatasetParameters  # noqa F401


def __getattr__(name: str):
    if name == "IcatDataset":
        warnings.warn(
            "IcatDataset has been renamed to IcatDatasetParameters. "
            "Please update your imports accordingly.",
            DeprecationWarning,
            stacklevel=2,
        )
        return IcatDatasetParameters
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
