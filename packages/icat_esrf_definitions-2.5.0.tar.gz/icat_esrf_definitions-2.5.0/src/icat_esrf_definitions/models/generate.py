import datetime
from enum import Enum
from typing import Any
from typing import List
from typing import Tuple

from pint import Quantity

from .base.custom_types._metadata.quantity import QuantityMeta
from .base.field_utils import get_field_metadata
from .base.field_utils import get_field_type
from .base.field_utils import is_renamed_field
from .dataset import IcatDatasetParameters


def generate_dataset(counter: int = 0) -> IcatDatasetParameters:
    icat_dict = dict()

    for icat_name, icat_field_info in IcatDatasetParameters.icat_fields().items():
        if is_renamed_field(icat_field_info):
            continue
        python_type = _python_type_from_annotation(icat_field_info.annotation)
        if python_type is List[str]:
            value = [f"item{counter}"]
        elif python_type is List[List[str]]:
            value = [[f"item{counter}"]]
        elif python_type is List[Tuple[int, int]]:
            value = [(counter, counter + 1)]
        elif python_type is List[float]:
            value = [counter + 0.1]
        elif python_type is List[int]:
            value = [counter]
        elif not isinstance(python_type, type):
            raise NotImplementedError(
                f"{icat_name}: Unsupported field type {python_type}"
            )
        elif issubclass(python_type, Enum):
            enum_values = list(python_type)
            value = enum_values[counter % len(enum_values)].value
        elif issubclass(python_type, bool):
            value = bool(counter % 2)
        elif issubclass(python_type, int):
            value = counter
        elif issubclass(python_type, float):
            value = counter + 0.1
        elif issubclass(python_type, str):
            value = f"string{counter}"
        elif issubclass(python_type, datetime.datetime):
            value = datetime.datetime.fromtimestamp(1_700_000_000 + counter)
        elif issubclass(python_type, Any):
            value = f"any{counter}"
        else:
            raise NotImplementedError(
                f"{icat_name}: Unsupported field type {python_type}"
            )

        unit_info = icat_field_info.unit_info
        if unit_info is not None and unit_info.units is not None:
            value = value, unit_info.units

        icat_dict[icat_name] = value
        counter += 1

    return IcatDatasetParameters.from_icat_dict(icat_dict)


_TYPES = (
    List[List[str]],
    List[Tuple[int, int]],
    List[str],
    Enum,
    str,
    bool,
    int,
    float,
    datetime.datetime,
    Any,
)


def _python_type_from_annotation(annotation) -> Any:
    for type_ in _TYPES:
        field_type = get_field_type(annotation, type_)
        if field_type is not None:
            return field_type

    qtype = get_field_type(annotation, Quantity)
    if qtype is not None:
        meta = get_field_metadata(annotation, QuantityMeta)
        return meta.value_type or float

    raise TypeError(annotation)
