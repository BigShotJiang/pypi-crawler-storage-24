import datetime
from typing import Any
from typing import Dict
from typing import Literal
from typing import NamedTuple
from typing import Optional
from typing import Tuple
from typing import Type

try:
    from typing import Annotated
    from typing import get_args
    from typing import get_origin
except ImportError:
    # For Python <3.9
    from typing_extensions import Annotated, get_args, get_origin

from pint import Quantity
from pint import Unit
from pint.util import UnitsContainer
from pydantic import BaseModel
from pydantic.fields import FieldInfo

from .custom_types._metadata.base import CustomTypeMetadata
from .custom_types._metadata.quantity import DimensionQuantityMeta
from .custom_types._metadata.quantity import QuantityMeta
from .custom_types._metadata.quantity import UnitQuantityMeta


class UnitInfo(NamedTuple):
    dimension: UnitsContainer
    units: Optional[Unit]

    def __str__(self) -> str:
        if self.units is None:
            return str(self.dimension)
        return f"{self.units:~}"

    def as_str_xml(self) -> str:
        if self.units is None:
            return str(self.dimension)
        return f"{self.units:~P}"


class IcatFieldInfo(NamedTuple):
    icat_name: str
    nexus_nodes: Tuple[str, ...]
    description: str
    required: bool
    unit_info: Optional[UnitInfo]
    nexus_type: str
    annotation: Any  # class or a typing generic
    record: Literal[None, "initial", "final"]
    deprecated: Optional[str]
    rename_to: Optional[str]

    @property
    def nexus_name(self) -> str:
        return ".".join(self.nexus_nodes)


_NEXUS_TYPE_TO_BASE_TYPE: Dict[str, Any] = {
    "NX_CHAR": str,
    "NX_BOOLEAN": bool,
    "NX_INT": int,
    "NX_FLOAT": float,
    "NX_DATE_TIME": datetime.datetime,
}


def get_nexus_type(annotation) -> str:
    for nxtype, type_ in _NEXUS_TYPE_TO_BASE_TYPE.items():
        if get_field_type(annotation, type_):
            return nxtype

    qtype = get_field_type(annotation, Quantity)

    if qtype is not None:
        meta = get_field_metadata(annotation, QuantityMeta)
        if meta is not None:
            for nxtype, type_ in _NEXUS_TYPE_TO_BASE_TYPE.items():
                if _is_subclass(meta.value_type, type_):
                    return nxtype

        return "NX_NUMBER"

    raise ValueError(f"Failed to extract NeXus type from annotation {annotation}")


def get_unit_info(annotation: Any) -> Optional[UnitInfo]:
    """Recursively find a PydanticQuantity-style Annotated field and extract unit info

    Example:
        For annotation = Annotated[Quantity, DimensionQuantityMeta("mm", float)]
        get_unit_info(annotation) → UnitInfo(dimension=<length>, units=<mm>)
    """
    qtype = get_field_type(annotation, Quantity)
    if qtype is None:
        return None

    meta = get_field_metadata(annotation, QuantityMeta)
    if _is_instance(meta, UnitQuantityMeta):
        return UnitInfo(dimension=meta.unit.dimensionality, units=meta.unit)

    if _is_instance(meta, DimensionQuantityMeta):
        return UnitInfo(dimension=meta.dimension, units=None)

    raise ValueError(f"Failed to extract unit from annotation {annotation}")


def get_field_type(annotation: Any, target_type: Any) -> Optional[Any]:
    """Recursively search the `annotation` for `target_type` or a subclass.

    Example:
        For annotation = Optional[Annotated[int, SomeMeta]]
        get_field_type(annotation, int) → int
    """
    # Direct match
    if _is_subclass(annotation, target_type):
        return annotation

    # Get outer type, e.g., Union, Annotated
    origin = get_origin(annotation)
    if origin is None:
        return None

    # Handle Annotated[T, *metadata]
    if origin is Annotated:
        base_type, *_ = get_args(annotation)
        return get_field_type(base_type, target_type)

    # Recurse into other inner types if present
    for arg in get_args(annotation):
        field_type = get_field_type(arg, target_type)
        if field_type is not None:
            return field_type

    return None


def get_field_metadata(annotation: Any, meta_type: Type) -> Optional[Any]:
    """Recursively search `annotation` for Annotated metadata instance or class of type `meta_type`.

    Example:
        For annotation = Optional[Annotated[int, SomeMeta]]
        get_field_metadata(annotation, SomeMeta) → SomeMeta
    """

    origin = get_origin(annotation)
    if origin is None:
        return None

    # Handle Annotated[T, *metadata]
    if origin is Annotated:
        base_type, *metadata = get_args(annotation)

        for meta in metadata:
            if _is_subclass(meta, meta_type) or _is_instance(meta, meta_type):
                return meta

        # Recurse into the wrapped type
        return get_field_metadata(base_type, meta_type)

    # Handle Union / Optional / other generics
    for arg in get_args(annotation):
        meta = get_field_metadata(arg, meta_type)
        if meta is not None:
            return meta

    return None


def _is_instance(obj: Any, class_: Type) -> bool:
    """Check if obj is an insance of class_ safely."""
    return not isinstance(obj, type) and isinstance(obj, class_)


def _is_subclass(obj: Any, type_: Any) -> bool:
    """Check if obj is a subclass of class_ safely."""
    if get_origin(type_) is not None:
        return obj is type_
    if not isinstance(obj, type):
        return None
    try:
        return issubclass(obj, type_)
    except TypeError:
        # For python <=3.10 when `type_` is not a class when
        return obj is type_


def has_custom_serialization(annotation: Any) -> bool:
    """Return True if the field has custom ICAT and NeXus serialization."""
    return get_field_metadata(annotation, CustomTypeMetadata) is not None


def nexus_field_name(field_name: str) -> str:
    return field_name.lower().replace("_", "-")


def resolve_field_description(
    model_cls: Type[BaseModel],
    field_name: str,
    field_info: FieldInfo,
) -> str:
    description = field_info.description or ""

    include_nexus_url = getattr(field_info, "json_schema_extra", {}).get(
        "include_nexus_url", False
    )
    if not include_nexus_url:
        return description

    nexus_class = None
    for base in model_cls.__mro__:
        if base.__name__.startswith("NX"):
            nexus_class = base.__name__
            break

    if nexus_class is None:
        return description

    class_anchor = nexus_field_name(nexus_class)
    field_anchor = nexus_field_name(field_name)

    url = (
        f"https://manual.nexusformat.org/classes/base_classes/"
        f"{nexus_class}.html#{class_anchor}-{field_anchor}-field"
    )

    return f"{description} See {url}"


def is_renamed_field(field_info) -> bool:
    """
    Return True if the field is marked as renamed.
    """
    if hasattr(field_info, "json_schema_extra"):
        extra = field_info.json_schema_extra or {}
        return bool(extra.get("rename_to"))
    return getattr(field_info, "rename_to", False)
