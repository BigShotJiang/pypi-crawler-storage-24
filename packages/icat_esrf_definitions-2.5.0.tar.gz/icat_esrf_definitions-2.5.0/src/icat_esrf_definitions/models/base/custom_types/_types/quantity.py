try:
    from typing import Annotated
except ImportError:
    from typing_extensions import Annotated
from typing import TypeVar

import pint
from pint import Quantity
from pint import Unit
from pint.util import UnitsContainer

from .._metadata import quantity

T = TypeVar("T")


class PydanticQuantity:
    """
    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field0: PydanticQuantity[None]   # dimensionless
            field1: PydanticQuantity["mm"]
            field2: PydanticQuantity["[length]]
            field3: PydanticQuantity["mm", float]
            field4: PydanticQuantity["[length]", float]
    """

    def __class_getitem__(cls, item: T):
        if isinstance(item, tuple):
            unit_spec, value_type = item
        else:
            unit_spec, value_type = item, None

        if unit_spec is None:
            return Annotated[
                Quantity,
                quantity.DimensionQuantityMeta(
                    quantity.REGISTRY.dimensionless,
                    value_type,
                ),
            ]

        if isinstance(unit_spec, Unit):
            return Annotated[
                Quantity,
                quantity.UnitQuantityMeta(unit_spec, value_type),
            ]

        if isinstance(unit_spec, UnitsContainer):
            return Annotated[
                Quantity,
                quantity.DimensionQuantityMeta(unit_spec, value_type),
            ]

        try:
            unit = quantity.REGISTRY.parse_units(unit_spec)
            return Annotated[
                Quantity,
                quantity.UnitQuantityMeta(unit, value_type),
            ]
        except (pint.UndefinedUnitError, pint.DefinitionSyntaxError):
            dimension = quantity.REGISTRY.get_dimensionality(unit_spec)
            return Annotated[
                Quantity,
                quantity.DimensionQuantityMeta(dimension, value_type),
            ]
