from typing import List
from typing import Tuple
from typing import Type
from typing import TypeVar

try:
    from typing import Annotated
except ImportError:
    from typing_extensions import Annotated

from .._metadata import lists

T = TypeVar("T")


class CommaSeparatedList:
    """List serialized as a comma-separated string.

    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field1: CommaSeparatedList[int]
            field2: CommaSeparatedList[str]
    """

    def __class_getitem__(cls, item: Type[T]):
        return Annotated[
            List[item],
            lists.SeparatedListMeta(
                separator=",",
                value_type=item,
                description="Comma-separated list of values",
            ),
        ]


class SpaceSeparatedList:
    """List serialized as a space-separated string.

    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field1: SpaceSeparatedList[int]
            field2: SpaceSeparatedList[str]
    """

    def __class_getitem__(cls, item: Type[T]):
        return Annotated[
            List[item],
            lists.SeparatedListMeta(
                separator=" ",
                value_type=item,
                description="Space-separated list of values",
            ),
        ]


ROIList = Annotated[List[Tuple[int, int]], lists.ROIListMeta()]
"""List of (int, int) tuples serialized as space-separated strings.

.. code-block:: python

    class MyModel(BaseModel):
        rois: ROIList
"""


DOIUsersList = Annotated[List[List[str]], lists.DOIUsersListMeta()]
"""Semicolon-separated list of users with comma-separated sublists.

.. code-block:: python

    class MyModel(BaseModel):
        users: DOIUsersList
"""
