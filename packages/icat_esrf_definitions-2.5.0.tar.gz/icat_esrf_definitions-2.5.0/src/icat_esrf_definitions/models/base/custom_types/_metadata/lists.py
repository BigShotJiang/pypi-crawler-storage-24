from typing import Any
from typing import List
from typing import Optional
from typing import Sequence
from typing import Tuple
from typing import Union

from .base import CustomTypeMetadata


class SeparatedListMeta(CustomTypeMetadata):
    """
    Usage

    .. code-block:: python

        class MyModel(BaseModel):
            field: Annotated[List[int], SeparatedListMeta(" ", int, "Comma-separated list of integers")]
    """

    def __init__(self, separator: str, value_type: type, description: str):
        self._separator = separator
        self._value_type = value_type
        json_schema = {"type": "string", "description": description}
        super().__init__(json_schema)

    def _validate(self, value: Union[Sequence[Any], str, None]) -> List[Any]:
        if value is None:
            return []

        if isinstance(value, (int, float)):
            return [self._value_type(value)]

        if isinstance(value, str):
            return [
                self._value_type(v.strip())
                for v in value.split(self._separator)
                if v.strip()
            ]

        if isinstance(value, (list, tuple)):
            items = []
            for v in value:
                if isinstance(v, str):
                    if self._separator in v:
                        raise ValueError(
                            f"List element contains separator: list={v} separator={self._separator}"
                        )
                    v = _strip_string(v, self._separator)
                    if not v:
                        continue
                items.append(v)
            return items

        raise TypeError(f"Invalid type {type(value)} (value={value})")

    def _icat_serialize(self, value: Optional[Sequence[Any]]) -> Optional[str]:
        if value is None:
            return None
        return self._separator.join(str(self._value_type(v)) for v in value)


class ROIListMeta(CustomTypeMetadata):
    """Usage

    .. code-block:: python

        class MyModel(BaseModel):
            field: Annotated[List[Tuple[int,int]], ROIListMeta()]
    """

    def __init__(self):
        json_schema = {
            "type": "string",
            "description": "Space-separated list of integer tuples, each tuple comma-separated.",
        }
        super().__init__(json_schema)

    def _validate(
        self, value: Union[Sequence[Tuple[int, int]], str, None]
    ) -> List[Tuple[int, int]]:
        if value is None or value == "":
            return []

        if isinstance(value, tuple) and len(value) == 2:
            if not all(isinstance(x, int) for x in value):
                raise TypeError(f"Tuple elements must be integers (value={value})")
            return [value]

        # Convert to list of comma-separated strings
        if isinstance(value, str):
            items = [v.strip() for v in value.split(" ") if v.strip()]
        elif isinstance(value, (list, tuple)):
            items = []
            for v in value:
                if isinstance(v, (tuple, list)) and len(v) == 2:
                    items.append(f"{v[0]},{v[1]}")
                else:
                    raise TypeError(f"Invalid element {v} in ROI list (value={value})")
        else:
            raise TypeError(f"Invalid type {type(value)} (value={value})")

        # Convert strings to (int, int)
        result: List[Tuple[int, int]] = []
        for item in items:
            parts = [_strip_string(p) for p in item.split(",")]
            parts = [p for p in parts if p]
            if len(parts) != 2:
                raise ValueError(f"Expected 2 integers per tuple (value={item})")
            result.append((int(parts[0]), int(parts[1])))

        return result

    def _icat_serialize(self, value: Optional[List[Tuple[int, int]]]) -> Optional[str]:
        if value is None:
            return None
        if not value:
            return ""
        return " ".join(f"{x},{y}" for x, y in value)


class DOIUsersListMeta(CustomTypeMetadata):
    """Usage

    .. code-block:: python

        class MyModel(BaseModel):
            field: Annotated[List[List[str]], DOIUsersListMeta()]
    """

    def __init__(self):
        json_schema = {
            "type": "string",
            "description": "Semicolon-separated list of users, each user as comma-separated values",
        }
        super().__init__(json_schema)

    def _validate(self, value: Union[Sequence[Any], str, None]) -> List[List[str]]:
        if value is None or value == "":
            return []

        # Convert to a list of comma-separated strings
        if isinstance(value, str):
            outer = [_strip_string(v, ",") for v in value.split(";")]
        elif isinstance(value, (list, tuple)):
            outer = []
            for v in value:
                if isinstance(v, str):
                    add = _strip_string(v, ",")
                    if add:
                        outer.append(add)
                elif isinstance(v, (list, tuple)):
                    add = [_strip_string(str(s), ",") for s in v]
                    add = [s for s in add if s]
                    if add:
                        outer.append(",".join(add))
                else:
                    raise TypeError(f"Invalid type: {type(value)}")
        else:
            raise TypeError(f"Invalid type: {type(value)}")

        # Convert strings to lists of strings
        result = []
        for item in outer:
            inner = [_strip_string(v) for v in item.split(",")]
            inner = [s for s in inner if s]
            for field in inner:
                if ";" in field:
                    raise ValueError(
                        f"List element contains separator: list={field} separator=;"
                    )

            if inner:
                result.append(inner)

        return result

    def _icat_serialize(self, value: Optional[List[List[str]]]) -> Optional[str]:
        if value is None:
            return None
        if not value:
            return ""

        parts = []
        for inner in value:
            inner = [_strip_string(str(v), ",") for v in inner]
            inner = [s for s in inner if s]
            if inner:
                parts.append(",".join(inner))

        if not parts:
            return None
        return ";".join(parts)


def _strip_string(string: Any, *separators) -> str:
    """Strip whitespace and any given separators."""
    s = string
    while True:
        s_old = s
        s = s.strip()  # always strip whitespace first
        for sep in separators:
            s = s.strip(sep)
        if s == s_old:  # no change -> done
            break
    return s
