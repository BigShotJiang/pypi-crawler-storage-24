"""Pydantic field annotation metadata classes for custom types, validation and serialization."""
