from typing import Optional

APPLICATIONS_REGISTRY = {}


def register_application(short_name: str, description: Optional[str] = None):
    def wrapper(cls):
        APPLICATIONS_REGISTRY[short_name] = {
            "class": cls,
            "description": description or f"{short_name} application metadata",
        }
        return cls

    return wrapper
