from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXsubentry
from ..base.quantity import KILODALTONS
from ..base.quantity import NANOMETERS_CUBED
from .applications import register_application


@register_application("SAXS", description="Small-Angle X-ray Scattering")
class IcatSaxs(NXsubentry):
    definition: Optional[str] = MetadataField(
        None, description="Technique used to collect this dataset"
    )
    version: Optional[str] = MetadataField(
        None,
        description="Version",
        icat_name="definition.version",
    )
    directory: Optional[str] = MetadataField(
        None,
        description="Data collection directory",
        record=RecordType.final,
    )
    experimentType: Optional[str] = MetadataField(
        None, description="Type of experiment", record=RecordType.final
    )
    prefix: Optional[str] = MetadataField(None, description="", record=RecordType.final)
    maskFile: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    numberFrames: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    timePerFrame: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    concentration: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    comments: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    code: Optional[str] = MetadataField(None, description="", record=RecordType.final)
    detector_distance: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    waveLength: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    pixelSizeX: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    pixelSizeY: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    beam_center_x: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    beam_center_y: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    normalisation: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    diode_currents: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    acronym: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    transmission: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    storage_temperature: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    exposure_temperature: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    column_type: Optional[str] = MetadataField(
        None,
        description="HPLC column type. [ex. Agilent BioSEC 130]",
        record=RecordType.final,
    )
    flow_rate: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    hplc_port: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    sample_type: Optional[str] = MetadataField(
        None,
        description="It can be buffer or sample",
        record=RecordType.final,
    )
    run_number: Optional[str] = MetadataField(
        None,
        description="It can be buffer or sample",
        record=RecordType.final,
    )
    experiment_type: Optional[str] = MetadataField(
        None,
        description="It the kind of experiment: sample changer or HPLC",
        record=RecordType.final,
    )
    guinier_rg: Optional[str] = MetadataField(
        None,
        description="Guinier radius of giration",
        record=RecordType.final,
    )
    guinier_sigma_rg: Optional[str] = MetadataField(
        None,
        description="Guinier radius of giration sigma",
        record=RecordType.final,
    )
    guinier_points: Optional[str] = MetadataField(
        None,
        description="Points of the Guinier region",
        record=RecordType.final,
    )
    guinier_points_start: Optional[str] = MetadataField(
        None,
        description="Points of the Guinier region",
        record=RecordType.final,
    )
    guinier_points_end: Optional[str] = MetadataField(
        None,
        description="Points of the Guinier region",
        record=RecordType.final,
    )
    guinier_i0: Optional[str] = MetadataField(
        None,
        description="Guinier radius of giration",
        record=RecordType.final,
    )
    rg: Optional[str] = MetadataField(
        None,
        description="Calculated radious of giration. It can be calculated with Gnom or BIFT",
        record=RecordType.final,
    )
    rg_std: Optional[str] = MetadataField(
        None,
        description="Calculated std radious of giration",
        record=RecordType.final,
    )
    rg_avg: Optional[str] = MetadataField(
        None,
        description="Calculated average of radious of giration",
        record=RecordType.final,
    )
    total: Optional[str] = MetadataField(None, description="", record=RecordType.final)
    d_max: Optional[str] = MetadataField(
        None,
        description="maximum particle dimension. it is the largest distance between any two points within the particle and is a crucial parameter in SAXS analysis.",
        record=RecordType.final,
    )
    d_max_std: Optional[str] = MetadataField(
        None,
        description="d_max standard deviation",
        record=RecordType.final,
    )
    porod_volume: Optional[str] = MetadataField(
        None,
        description="The Porod volume is an estimate of the molecular volume of a particle derived from SAXS data. It is obtained using the Porod invariant, which is related to the scattering intensity at high angles.",
        record=RecordType.final,
    )
    porod_MM_volume_estimation: Optional[str] = MetadataField(
        None,
        description="molecular weight (MW) of a macromolecule in solution using the Porod volume",
        record=RecordType.final,
    )
    frames_averaged: Optional[str] = MetadataField(
        None, description="", record=RecordType.final
    )
    vc: Optional[NANOMETERS_CUBED] = MetadataField(
        None,
        description="The Volume of Correlation is a SAXS-derived parameter that provides an alternative estimate of the molecular volume of a biomolecule.",
        record=RecordType.final,
    )
    vc_error: Optional[NANOMETERS_CUBED] = MetadataField(
        None,
        description="Volume of correlation error",
        record=RecordType.final,
    )
    mass: Optional[KILODALTONS] = MetadataField(
        None, description="Molecular weight", record=RecordType.final
    )
    mass_error: Optional[KILODALTONS] = MetadataField(
        None,
        description="Molecular weight error",
        record=RecordType.final,
    )
    chi2r: Optional[str] = MetadataField(
        None,
        description="goodness of fit between experimental scattering data and a theoretical model or fit.",
        record=RecordType.final,
    )
    chi2r_error: Optional[str] = MetadataField(
        None,
        description="Error of the agreement",
        record=RecordType.final,
    )
