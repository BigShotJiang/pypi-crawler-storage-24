from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXsubentry
from ..base.quantity import KILOELECTRONVOLTS
from ..base.quantity import MILLIMETERS
from ..base.quantity import SECONDS
from .applications import register_application


@register_application("HTXRPD", description="High-Throughput X-ray Powder Diffraction")
class IcatHtxrpd(NXsubentry):
    energy: Optional[KILOELECTRONVOLTS] = MetadataField(
        None, description="Primary beam energy used for the measurement."
    )
    exposureTime: Optional[SECONDS] = MetadataField(
        None, description="Requested exposure time per diffraction pattern."
    )
    distance: Optional[MILLIMETERS] = MetadataField(
        None, description="The perpendicular sample-detector distance."
    )
    sampleVibration: Optional[float] = MetadataField(
        None, description="The vibration speed of the powder sample (0-100 %)."
    )
