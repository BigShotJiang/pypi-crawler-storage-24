from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXsubentry
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIMETERS
from ..base.quantity import NANOMETERS
from .applications import register_application

_DEPRECATED = "Deprecated. This field is ignored and will be removed."


@register_application("HOLO", description="X-ray Holography")
class IcatHolo(NXsubentry):
    n: Optional[int] = MetadataField(
        None,
        description="Number of planes for holography measurement.",
        icat_name="N",
    )
    pixel_size: Optional[NANOMETERS] = MetadataField(
        None, description="Pixel size at the sample plane in nanometers."
    )
    sample_detector_distances: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Sample/detector distances for all planes used.",
    )
    source_sample_distances: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Source/sample distances for all planes used.",
    )
    pixelSize: Optional[MICROMETERS] = MetadataField(
        None,
        description="Pixel size of first distance in micron.",
        deprecated="Deprecated. Use pixel_size instead.",
        rename_to="pixel_size",
    )
    sampleDetectorDistances: Optional[str] = MetadataField(
        None,
        description="Sample/detector distances for all planes used.",
        icat_name="holoSampleDetectorDistances",
        deprecated="Deprecated. Use sample_detector_distances instead.",
        rename_to="sample_detector_distances",
    )
    sourceSampleDistances: Optional[str] = MetadataField(
        None,
        description="Source/sample distances for all planes used.",
        icat_name="holoSourceSampleDistances",
        deprecated="Deprecated. Use source_sample_distances instead.",
        rename_to="source_sample_distances",
    )
    im01NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 1.",
        icat_name="im01_num_end",
        deprecated=_DEPRECATED,
    )
    im01NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 1.",
        icat_name="im01_num_start",
        deprecated=_DEPRECATED,
    )
    im02NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 2.",
        icat_name="im02_num_end",
        deprecated=_DEPRECATED,
    )
    im02NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 2.",
        icat_name="im02_num_start",
        deprecated=_DEPRECATED,
    )
    im03NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 3.",
        icat_name="im03_num_end",
        deprecated=_DEPRECATED,
    )
    im03NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 3.",
        icat_name="im03_num_start",
        deprecated=_DEPRECATED,
    )
    im04NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 4.",
        icat_name="im04_num_end",
        deprecated=_DEPRECATED,
    )
    im04NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 4.",
        icat_name="im04_num_start",
        deprecated=_DEPRECATED,
    )
    ref01NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 1.",
        icat_name="ref01_num_end",
        deprecated=_DEPRECATED,
    )
    ref02NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 2.",
        icat_name="ref02_num_end",
        deprecated=_DEPRECATED,
    )
    ref02NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 2.",
        icat_name="ref02_num_start",
        deprecated=_DEPRECATED,
    )
    ref03NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 3.",
        icat_name="ref03_num_end",
        deprecated=_DEPRECATED,
    )
    ref03NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 3.",
        icat_name="ref03_num_start",
        deprecated=_DEPRECATED,
    )
    ref04NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 4.",
        icat_name="ref04_num_end",
        deprecated=_DEPRECATED,
    )
    ref04NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 4.",
        icat_name="ref04_num_start",
        deprecated=_DEPRECATED,
    )
    darkNumStart: Optional[float] = MetadataField(
        None,
        description="Index of first dark image.",
        icat_name="dark_num_start",
        deprecated=_DEPRECATED,
    )
    darkNumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last dark image.",
        icat_name="dark_num_end",
        deprecated=_DEPRECATED,
    )
