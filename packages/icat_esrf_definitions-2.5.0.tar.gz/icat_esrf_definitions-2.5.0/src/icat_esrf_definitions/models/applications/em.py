from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXcollection
from ..base.nexus import NXsubentry
from ..base.quantity import ANGSTROMS
from ..base.quantity import DEGREES_ANGLE
from ..base.quantity import ELECTRON_FLUENCE
from ..base.quantity import KILOVOLTS
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIMETERS
from ..base.quantity import PERCENT
from ..base.quantity import PIXELS
from ..base.quantity import SECONDS
from .applications import register_application


class IcatEmCtf(NXcollection):
    total_ctf_number: Optional[int] = MetadataField(
        None,
        description=(
            "Total number of micrographs or movies for which CTF estimation was"
            " performed."
        ),
    )

    resolution_limit: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Estimated highest spatial resolution (Å) at which the CTF fit is"
            " considered reliable."
        ),
    )

    correlation: Optional[float] = MetadataField(
        None,
        description=(
            "Correlation or confidence metric reported by the CTF estimation program"
            " indicating quality of the CTF fit."
        ),
    )

    defocus_u: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Defocus value along the first principal axis (U) of astigmatism, expressed"
            " in Ångström."
        ),
    )

    defocus_v: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Defocus value along the second principal axis (V) of astigmatism,"
            " expressed in Ångström."
        ),
    )

    avg_defocus: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Average defocus value computed from defocus U and V, expressed in"
            " Ångström."
        ),
    )

    defocus_range: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Difference between defocus U and defocus V (astigmatism magnitude),"
            " expressed in Ångström."
        ),
    )

    sample_tilt_azimuth: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description=(
            "Azimuthal angle (in degrees) describing the in-plane direction of the"
            " sample tilt or astigmatism axis."
        ),
    )

    estimated_b_factor: Optional[str] = MetadataField(
        None,
        description=(
            "Estimated B-factor (envelope decay parameter) describing attenuation of"
            " high-resolution signal in the CTF."
        ),
    )

    ctf_fit_limit: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Resolution limit (Å) up to which the CTF model was fitted to the"
            " experimental data."
        ),
    )

    angle: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description=(
            "Magnitude of apparent astigmatism attributed to sample tilt, expressed as"
            " a defocus difference in Ångström."
        ),
    )


class IcatEmMotionCorrection(NXcollection):
    total_mrc_number: Optional[int] = MetadataField(
        None,
        description=(
            "Total number of movies or micrographs processed during motion correction."
        ),
    )

    total_motion: Optional[PIXELS] = MetadataField(
        None,
        description=(
            "Total accumulated specimen motion over the entire movie, expressed in"
            " pixels."
        ),
    )

    average_motion: Optional[PIXELS] = MetadataField(
        None, description="Average specimen motion per frame, expressed in pixels."
    )

    max_motion: Optional[PIXELS] = MetadataField(
        None,
        description=(
            "Maximum observed specimen motion between any two consecutive frames,"
            " expressed in pixels."
        ),
    )

    frame_dose: Optional[ELECTRON_FLUENCE] = MetadataField(
        None,
        description="Electron dose applied to a single frame.",
    )

    frame_range: Optional[str] = MetadataField(
        None,
        description="Frames range used for rest of the workflow.",
    )

    total_dose: Optional[ELECTRON_FLUENCE] = MetadataField(
        None, description="Total accumulated electron dose applied during acquisition."
    )


@register_application("EM", description="Electron Microscopy")
class IcatEm(NXsubentry):
    protein_acronym: Optional[str] = MetadataField(
        None,
        description=(
            "Short acronym or identifier of the protein associated with the sample."
        ),
    )

    voltage: Optional[KILOVOLTS] = MetadataField(
        None, description="Acceleration voltage of the electron beam."
    )

    magnification: Optional[int] = MetadataField(
        None,
        description="Nominal microscope magnification used during data acquisition.",
    )

    images_count: Optional[int] = MetadataField(
        None, description="Number of frames contained in each recorded movie."
    )

    position_x: Optional[MILLIMETERS] = MetadataField(
        None, description="X position of the sample on the microscope stage."
    )

    position_y: Optional[MILLIMETERS] = MetadataField(
        None, description="Y position of the sample on the microscope stage."
    )

    dose_initial: Optional[str] = MetadataField(
        None,
        description=(
            "Initial electron dose applied before or at the start of image acquisition."
        ),
    )

    dose_per_frame: Optional[ELECTRON_FLUENCE] = MetadataField(
        None, description="Electron dose applied per frame during movie acquisition."
    )

    spherical_aberration: Optional[MILLIMETERS] = MetadataField(
        None, description="Spherical aberration coefficient (Cs) of the objective lens."
    )

    amplitude_contrast: Optional[PERCENT] = MetadataField(
        None,
        description=(
            "Amplitude contrast used for CTF estimation, expressed as a percentage."
        ),
    )

    sampling_rate: Optional[ANGSTROMS] = MetadataField(
        None,
        description=(
            "Physical pixel size at the specimen level, expressed in Ångström per"
            " pixel."
        ),
    )

    tilt_angle: Optional[DEGREES_ANGLE] = MetadataField(
        None, description="Specimen tilt angle relative to the electron beam direction."
    )

    grid_name: Optional[str] = MetadataField(
        None,
        description=(
            "Identifier or name of the cryo-EM grid used for sample preparation."
        ),
    )

    grid_square_name: Optional[str] = MetadataField(
        None,
        description="Identifier of the grid square from which data were collected.",
    )

    total_movie_number: Optional[int] = MetadataField(
        None, description="Total number of movies acquired for this dataset."
    )

    microscope_model: Optional[str] = MetadataField(
        None,
        description=(
            "Model of the transmission electron microscope used for data collection."
        ),
    )

    camera_model: Optional[str] = MetadataField(
        None, description="Model of the detector or camera used for image acquisition."
    )

    energy_filter_model: Optional[str] = MetadataField(
        None,
        description="Model of the energy filter used during data acquisition.",
    )

    exposure_time: Optional[SECONDS] = MetadataField(
        None, description="Total exposure time per movie."
    )

    total_dose: Optional[ELECTRON_FLUENCE] = MetadataField(
        None, description="Total accumulated electron dose applied during acquisition."
    )

    energy_filter_on: Optional[bool] = MetadataField(
        None,
        description=(
            "Indicates whether an energy filter was used during data acquisition."
        ),
    )

    energy_filter_slit_width: Optional[MILLIMETERS] = MetadataField(
        None, description="Width of the energy filter slit."
    )

    dose: Optional[ELECTRON_FLUENCE] = MetadataField(
        None, description="Electron dose applied during acquisition."
    )

    objective_aperture: Optional[MICROMETERS] = MetadataField(
        None, description="Diameter of the objective aperture used during imaging."
    )

    motion_correction: Optional[IcatEmMotionCorrection] = MetadataField(
        None,
        description="Results and statistics from motion correction of acquired movies.",
        icat_name="MotionCorrection",
    )

    ctf: Optional[IcatEmCtf] = MetadataField(
        None,
        description="Contrast Transfer Function (CTF) estimation results.",
        icat_name="CTF",
    )
