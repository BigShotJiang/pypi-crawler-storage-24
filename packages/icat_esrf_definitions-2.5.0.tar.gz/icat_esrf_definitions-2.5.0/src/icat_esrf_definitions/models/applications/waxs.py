from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXsubentry
from .applications import register_application


@register_application("WAXS", description="Wide-Angle X-ray Scattering")
class IcatWaxs(NXsubentry):
    definition: Optional[str] = MetadataField(
        None, description="Technique used to collect this dataset."
    )
