from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXsubentry
from ..base.quantity import MICROMETERS
from .applications import register_application


@register_application("BCDI", description="Bragg Coherent Diffraction Imaging")
class IcatBcdi(NXsubentry):
    beamSizeVertical: Optional[MICROMETERS] = MetadataField(
        None,
        description="Vertical beam size on the sample in microns.",
        record=RecordType.final,
    )
    beamSizeHorizontal: Optional[MICROMETERS] = MetadataField(
        None,
        description="Horizontal beam size on the sample in microns.",
        record=RecordType.final,
    )
