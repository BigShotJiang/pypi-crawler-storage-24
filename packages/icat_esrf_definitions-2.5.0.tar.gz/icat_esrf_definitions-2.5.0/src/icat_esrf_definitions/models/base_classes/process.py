from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXprocess


class IcatProcess(NXprocess):
    program: Optional[str] = MetadataField(
        None,
        description="Name of the software or program used to perform this process.",
    )
    sequence_index: Optional[str] = MetadataField(
        None,
        description="Priority index used by the ingester; metadata (existing or new) are applied only if the index is strictly higher than existing.",
    )
    version: Optional[str] = MetadataField(
        None, description="Version of the program or process used."
    )
    note: Optional[str] = MetadataField(
        None, description="Note or comment about the process."
    )
    triggering: Optional[str] = MetadataField(
        None,
        description="Specifies how the process was launched. Possible values are MANUAL or AUTOMATIC.",
    )
