from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXnote

_NOTE_DESCRIPTION = "Note or comment for any relevant information."


class IcatNotes(NXnote):
    note_00: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_01: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_02: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_03: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_04: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_05: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_06: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_07: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_08: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
    note_09: Optional[str] = MetadataField(None, description=_NOTE_DESCRIPTION)
