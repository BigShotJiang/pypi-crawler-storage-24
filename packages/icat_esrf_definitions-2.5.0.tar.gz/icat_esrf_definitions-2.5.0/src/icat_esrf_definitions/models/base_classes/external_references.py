from typing import Optional

from ..base.custom_types import CommaSeparatedList
from ..base.metadata_field import MetadataField
from ..base.nexus import NXcite
from ..base.nexus import NXnote


class IcatExternalReferencesDatacollector(NXcite):
    endnote: Optional[CommaSeparatedList[str]] = MetadataField(
        None,
        description="Contributors who collected or processed the data, provided as a comma-separated list.",
    )


class IcatExternalReferencesPublication(NXcite):
    doi: Optional[str] = MetadataField(
        None, description="DOI of the related publication."
    )
    endnote: Optional[str] = MetadataField(
        None,
        description="Citation or bibliographic reference related to the data collector.",
    )


class IcatExternalReferences(NXnote):
    neuroglancer: Optional[str] = MetadataField(
        None,
        description="Path to the Neuroglancer JSON file describing the dataset for visualization.",
    )
    publication: Optional[IcatExternalReferencesPublication] = MetadataField(
        None,
        description="External references related to publications describing or using the dataset.",
    )
    datacollector: Optional[IcatExternalReferencesDatacollector] = MetadataField(
        None, description="External references related to the data collector."
    )
