from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXaperture
from ..base.nexus import NXgeometry


class IcatApertureGeometry(NXgeometry):
    vertical: Optional[str] = MetadataField(
        None,
        description="Vertical coordinate or reference point of the aperture. "
        "Only present when this represents an additional reference point rather than the position of a physical component.",
    )
    horizontal: Optional[str] = MetadataField(
        None, description="Horizontal coordinate or reference point of the aperture."
    )
    transformation: Optional[str] = MetadataField(
        None,
        description="Transformation applied to the aperture position or orientation.",
    )
    distance: Optional[str] = MetadataField(
        None,
        description="Distance of the aperture along the beam path relative to the sample position.",
    )
    component_index: Optional[str] = MetadataField(
        None,
        description="Position of the component along the beam path. "
        "The sample is at 0, components upstream have a negative component_index, and components downstream a have positive component_index.",
    )


class IcatAperture(NXaperture):
    description: Optional[str] = MetadataField(
        None,
        description="Describes which child group contains a path leading to a NXdata group. "
        "It is recommended (as of NIAC2014) to use this attribute to help define the path to the default dataset to be plotted. "
        "See https://www.nexusformat.org/2014_How_to_find_default_data.html for a summary of the discussion.",
        include_nexus_url=True,
    )
    material: Optional[str] = MetadataField(
        None,
        description="Absorbing material of the aperture.",
        include_nexus_url=True,
    )
    geometry: Optional[IcatApertureGeometry] = MetadataField(
        None, description="Geometrical information about the aperture."
    )
