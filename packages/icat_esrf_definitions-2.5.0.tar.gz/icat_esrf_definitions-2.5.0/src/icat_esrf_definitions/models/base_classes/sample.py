from typing import Optional

from ..base.custom_types import SpaceSeparatedList
from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXcollection
from ..base.nexus import NXenvironment
from ..base.nexus import NXnote
from ..base.nexus import NXpositioner
from ..base.nexus import NXsample
from ..base.nexus import NXsensor
from ..base.nexus import NXsubentry
from ..base.quantity import CELSIUS
from ..base.quantity import CENTIMETERS
from ..base.quantity import KILOGRAMS
from ..base.quantity import YEARS


class IcatSampleChanger(NXcollection):
    position: Optional[str] = MetadataField(
        None, description="Sample changer position."
    )
    name: Optional[str] = MetadataField(
        None,
        description="Name (or ideally identifier) for a batch (series of data collections).",
    )


class IcatSampleEnvironmentSensors(NXsensor):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None, description="Name of the sensor, provided as a space-separated list."
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Value reported by the sensor, provided as a space-separated list.",
    )


class IcatSampleLocalisation(NXcollection):
    name: Optional[str] = MetadataField(
        None, description="Name of the location where the sample was collected."
    )
    country: Optional[str] = MetadataField(
        None, description="Country where the sample was collected."
    )
    continental_region: Optional[str] = MetadataField(
        None, description="Continent or continental region of the collection site."
    )


class IcatSampleNotes(NXnote):
    notes: Optional[str] = MetadataField(
        None,
        description="Note or comment for any relevant information about the sample.",
        record=RecordType.final,
    )


_CLADE_DESCRIPTION = "Next taxonomic level."


class IcatSamplePaleoClassification(NXcollection):
    species: Optional[str] = MetadataField(
        None, description="Species name of the sample."
    )
    material_type: Optional[str] = MetadataField(None, description="Type of material.")
    clade1: Optional[str] = MetadataField(
        None, description="Highest-level taxonomic clade."
    )
    clade2: Optional[str] = MetadataField(None, description=_CLADE_DESCRIPTION)
    clade3: Optional[str] = MetadataField(None, description=_CLADE_DESCRIPTION)
    clade4: Optional[str] = MetadataField(None, description=_CLADE_DESCRIPTION)
    clade5: Optional[str] = MetadataField(None, description=_CLADE_DESCRIPTION)
    clade6: Optional[str] = MetadataField(None, description=_CLADE_DESCRIPTION)


class IcatSamplePaleoGeologicalTime(NXcollection):
    formation: Optional[str] = MetadataField(
        None, description="Geological formation where the sample was collected."
    )
    era: Optional[str] = MetadataField(
        None, description="Geological era of the sample (e.g. Cenozoic)."
    )
    period: Optional[str] = MetadataField(
        None, description="Geological period of the sample (e.g. Quaternary)."
    )
    epoch: Optional[str] = MetadataField(
        None, description="Geological epoch of the sample (e.g. Present)."
    )


class IcatSamplePatient(NXcollection):
    institute: Optional[str] = MetadataField(
        None, description="Institute where the patient originates from."
    )
    number: Optional[int] = MetadataField(
        None, description="Patient identifier or number assigned by the institute."
    )
    age: Optional[YEARS] = MetadataField(None, description="Age of the patient.")
    sex: Optional[str] = MetadataField(None, description="Sex of the patient.")
    weight: Optional[KILOGRAMS] = MetadataField(
        None, description="Weight of the patient."
    )
    size: Optional[CENTIMETERS] = MetadataField(
        None, description="Height of the patient."
    )
    info: Optional[str] = MetadataField(
        None,
        description="Additional information about the patient (e.g., health conditions, notes).",
    )
    organ_name: Optional[str] = MetadataField(None, description="Name of the organ.")
    organ_description: Optional[str] = MetadataField(
        None, description="Description of the organ or tissue sampled."
    )


class IcatSamplePositioners(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name of the positioner, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current position or angle of the positioner, provided as a space-separated list.",
    )


class IcatSampleProtein(NXcollection):
    acronym: Optional[str] = MetadataField(None, description="Acronym of the protein.")
    name: Optional[str] = MetadataField(None, description="Full name of the protein.")


class IcatSampleTrackingContainer(NXcollection):
    type: Optional[str] = MetadataField(
        None, description="Type of container. Example: unipuck, spinepuck, etc..."
    )
    capacity: Optional[str] = MetadataField(
        None,
        description="Total capacity of the container.",
    )
    position: Optional[str] = MetadataField(
        None, description="Position of the sample within the container."
    )
    id: Optional[str] = MetadataField(None, description="Identifier of the container.")
    name: Optional[str] = MetadataField(
        None,
        description="Name of the container where the sample is. Example: puck_name.",
    )


class IcatSampleTrackingParcel(NXsubentry):
    id: Optional[str] = MetadataField(None, description="Identifier of the parcel.")
    name: Optional[str] = MetadataField(
        None, description="Name of the parcel where the sample has been shipped."
    )
    storage_condition: Optional[CELSIUS] = MetadataField(
        None, description="Storage conditions of the parcel. Example: -80 degrees."
    )


class IcatSampleTrackingShipment(NXsubentry):
    id: Optional[str] = MetadataField(None, description="Identifier of the shipment.")
    name: Optional[str] = MetadataField(None, description="Name of the shipment.")


class IcatSampleEnvironment(NXenvironment):
    name: Optional[str] = MetadataField(
        None, description="Apparatus identification code/model number; e.g. OC100 011."
    )
    type: Optional[str] = MetadataField(
        None,
        description="Type of apparatus. This could be the SE codes in scheduling database; e.g. OC/100.",
    )
    description: Optional[str] = MetadataField(
        None,
        description="Description of the apparatus; e.g. 100mm bore orange cryostat with Roots pump.",
    )
    sensors: Optional[IcatSampleEnvironmentSensors] = MetadataField(
        None, description="Parameters for controlling external conditions."
    )


class IcatSamplePaleo(NXcollection):
    scientific_domain: Optional[str] = MetadataField(
        None, description="Scientific domain or field of study related to the sample."
    )
    repository_institution: Optional[str] = MetadataField(
        None, description="Institution or repository where the sample is stored."
    )
    collection_number: Optional[str] = MetadataField(
        None,
        description="Unique collection number assigned to the sample by the repository or institution.",
    )
    geological_time: Optional[IcatSamplePaleoGeologicalTime] = MetadataField(
        None, description="Geological time information of the sample."
    )
    classification: Optional[IcatSamplePaleoClassification] = MetadataField(
        None, description="Taxonomic classification of the sample, including species."
    )


class IcatSampleTracking(NXsubentry):
    shipment: Optional[IcatSampleTrackingShipment] = MetadataField(
        None,
        description="Identifier or name of the shipment used to transport the sample.",
    )
    parcel: Optional[IcatSampleTrackingParcel] = MetadataField(
        None,
        description="Identifier or name of the parcel used to transport the sample.",
    )
    container: Optional[IcatSampleTrackingContainer] = MetadataField(
        None,
        description="Identifier or name of the container holding the sample within the parcel.",
    )


class IcatSample(NXsample):
    name: str = MetadataField(
        ..., description="Name of the sample.", record=RecordType.final
    )
    description: Optional[str] = MetadataField(
        None,
        description="Description of the sample.",
        record=RecordType.final,
    )
    distance: Optional[str] = MetadataField(
        None,
        description="Translation of the sample along the primary beam direction.",
        record=RecordType.final,
    )
    support: Optional[str] = MetadataField(
        None,
        description="Name of the support used to collect the sample. It can be a chip, plate, jet, etc.",
        record=RecordType.final,
    )
    notes: Optional[IcatSampleNotes] = MetadataField(
        None,
        description="Notes or comments about the sample.",
        icat_name="",
    )
    positioners: Optional[IcatSamplePositioners] = MetadataField(
        None,
        description="Information about the sample positioners.",
    )
    protein: Optional[IcatSampleProtein] = MetadataField(
        None, description="Information about any protein associated with the sample."
    )
    changer: Optional[IcatSampleChanger] = MetadataField(
        None,
        description="Information about the sample changer used to handle or load the sample during the experiment.",
    )
    patient: Optional[IcatSamplePatient] = MetadataField(
        None,
        description="Information about the patient if the sample is of human origin.",
    )
    environment: Optional[IcatSampleEnvironment] = MetadataField(
        None, description="Information about the experimental environment or apparatus."
    )
    tracking: Optional[IcatSampleTracking] = MetadataField(
        None, description="Information about sample logistics."
    )
    localisation: Optional[IcatSampleLocalisation] = MetadataField(
        None, description="Information about the sample collection location."
    )
    paleo: Optional[IcatSamplePaleo] = MetadataField(
        None, description="Paleontology-related information for the sample."
    )
    situation: Optional[str] = MetadataField(
        None,
        description="Atmosphere conditions and associated components for the sample; details are stored in the sample_component member.",
        record=RecordType.final,
    )
    ub_matrix: Optional[str] = MetadataField(
        None,
        description="UB matrix of single crystal sample using Busing-Levy convention: "
        "W. R. Busing and H. A. Levy (1967). Acta Cryst. 22, 457-464. This is the multiplication "
        "of the orientation_matrix, given above, with the BB matrix which can be derived from the lattice constants.",
        record=RecordType.final,
    )
    temperature_env: Optional[str] = MetadataField(
        None,
        description="Additional sample temperature environment information.",
        record=RecordType.final,
    )
    chemical_formula: Optional[str] = MetadataField(
        None,
        description="Chemical formula of the sample.",
        record=RecordType.final,
    )
