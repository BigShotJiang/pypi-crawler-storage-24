from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXfresnel_zone_plate
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIMETERS
from ..base.quantity import NANOMETERS


class IcatFresnelZonePlate(NXfresnel_zone_plate):
    outer_diameter: Optional[MICROMETERS] = MetadataField(
        None,
        description="Outer diameter of the Fresnel zone plate.",
        include_nexus_url=True,
    )
    outermost_zone_width: Optional[NANOMETERS] = MetadataField(
        None,
        description="Width of the outermost zone in the Fresnel zone plate.",
        include_nexus_url=True,
    )
    central_stop_diameter: Optional[MICROMETERS] = MetadataField(
        None,
        description="Diameter of the central stop that blocks the zeroth-order (undiffracted) beam in the Fresnel zone plate.",
        include_nexus_url=True,
    )
    fabrication: Optional[str] = MetadataField(
        None,
        description="Manufacturing method of the zone plate. Allowed values are: etched, plated, zone-doubled, or other.",
        include_nexus_url=True,
    )
    zone_height: Optional[MICROMETERS] = MetadataField(
        None,
        description="Height or thickness of the zones in the Fresnel zone plate.",
        include_nexus_url=True,
    )
    zone_material: Optional[str] = MetadataField(
        None,
        description="Material of the zones that diffract the beam.",
        include_nexus_url=True,
    )
    zone_support_material: Optional[str] = MetadataField(
        None,
        description="Material present between the zones. This is usually only present for the zone doubled fabrication process.",
        include_nexus_url=True,
    )
    central_stop_material: Optional[str] = MetadataField(
        None, description="Material used for the central stop.", include_nexus_url=True
    )
    central_stop_thickness: Optional[MICROMETERS] = MetadataField(
        None, description="Thickness of the central stop.", include_nexus_url=True
    )
    support_membrane_material: Optional[str] = MetadataField(
        None,
        description="Material of the supporting membrane holding the zone plate.",
        include_nexus_url=True,
    )
    distance: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Distance of the Fresnel zone plate along the beam path relative to the sample position.",
    )
    component_index: Optional[float] = MetadataField(
        None, description="Position of the component along the beam path."
    )
