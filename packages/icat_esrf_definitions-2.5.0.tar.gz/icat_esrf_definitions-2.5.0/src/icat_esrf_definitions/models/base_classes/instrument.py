from typing import Optional

from ..base.custom_types import ROIList
from ..base.custom_types import SpaceSeparatedList
from ..base.metadata_field import MetadataField
from ..base.nexus import NXattenuator
from ..base.nexus import NXbeam
from ..base.nexus import NXcollection
from ..base.nexus import NXcrystal
from ..base.nexus import NXdetector
from ..base.nexus import NXenvironment
from ..base.nexus import NXinsertion_device
from ..base.nexus import NXinstrument
from ..base.nexus import NXmonochromator
from ..base.nexus import NXpositioner
from ..base.nexus import NXsensor
from ..base.nexus import NXslit
from ..base.nexus import NXsource
from ..base.nexus import NXxraylens
from ..base.quantity import ANGSTROMS
from ..base.quantity import ANGSTROMS_ARRAY
from ..base.quantity import DEGREES_ANGLE
from ..base.quantity import HERTZ
from ..base.quantity import JOULES
from ..base.quantity import KELVINS
from ..base.quantity import KILOELECTRONVOLTS
from ..base.quantity import KILOELECTRONVOLTS_ARRAY
from ..base.quantity import METERS
from ..base.quantity import PHOTON_FLUX
from ..base.quantity import SECONDS


class IcatInstrumentSource(NXsource):
    mode: Optional[str] = MetadataField(
        None, description="Operational mode of the source."
    )
    current: Optional[str] = MetadataField(
        None, description="Beam current or intensity of the source."
    )
    distance: Optional[str] = MetadataField(
        None,
        description="Effective distance from the sample, as seen by radiation emitted from the sample. "
        "This value should be negative to signify that the source is upstream of the sample.",
    )
    name: Optional[str] = MetadataField(None, description="Name of the source.")
    type: Optional[str] = MetadataField(
        None,
        description="Type of radiation source. Pick one value from the enumerated list and spell it exactly: "
        "Spallation Neutron Source, Pulsed Reactor Neutron Source, Reactor Neutron Source, "
        "Synchrotron X-ray Source, Pulsed Muon Source, Rotating Anode X-ray, Fixed Tube X-ray, "
        "UV Laser, Free-Electron Laser, Optical Laser, Ion Source, UV Plasma Source.",
    )
    probe: Optional[str] = MetadataField(
        None, description="Type of radiation probe used in the experiment."
    )
    emittance_x: Optional[str] = MetadataField(
        None, description="Source emittance (nm-rad) in the X (horizontal) direction."
    )
    emittance_y: Optional[str] = MetadataField(
        None, description="Source emittance (nm-rad) in the Y (horizontal) direction."
    )


class IcatInstrumentVariables(NXcollection):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name of the instrument variable or parameter, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Value of the instrument variable or parameter, provided as a space-separated list.",
    )


class IcatInstrumentLaser(NXsource):
    name: Optional[str] = MetadataField(
        None, description="Name of the laser source.", include_nexus_url=True
    )
    type: Optional[str] = MetadataField(
        None, description="Type of laser source.", include_nexus_url=True
    )
    probe: Optional[str] = MetadataField(
        None,
        description="Type of radiation emitted by the laser.",
        include_nexus_url=True,
    )
    energy: Optional[JOULES] = MetadataField(
        None, description="Energy emitted in a single pulse.", include_nexus_url=True
    )
    wavelength: Optional[METERS] = MetadataField(
        None, description="Wavelength emitted in a single pulse."
    )
    repetition_rate: Optional[HERTZ] = MetadataField(
        None, description="Pulse repetition frequency."
    )
    pulse_width: Optional[SECONDS] = MetadataField(
        None,
        description="Time between the start and end of a single pulse.",
        include_nexus_url=True,
    )
    delay: Optional[SECONDS] = MetadataField(
        None,
        description="The time of the start of the laser pulse with respect to the start of the measurement (T=0).",
    )


class IcatInstrumentMonochromatorCrystal(NXcrystal):
    usage: Optional[str] = MetadataField(
        None,
        description="How the crystal is used in the monochromator. "
        "Typical values: 'Bragg' for reflection geometry, 'Laue' for transmission geometry.",
    )
    d_spacing: Optional[str] = MetadataField(
        None, description="Interplanar spacing between the crystal lattice planes."
    )
    type: Optional[str] = MetadataField(None, description="Type of crystal.")
    reflection: Optional[str] = MetadataField(
        None,
        description="Miller indices of the crystal reflection used for monochromatization.",
    )


class IcatInstrumentOpticsPositioners(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the optical component positioner, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current position or setpoint of the optical component, provided as a space-separated list.",
    )


class IcatInstrumentPositioners(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the instrument positioner, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current position or setpoint of the instrument component, provided as a space-separated list.",
    )


class IcatInstrumentPrimarySlit(NXslit):
    name: Optional[str] = MetadataField(
        None, description="Name or identifier of the primary slit."
    )
    vertical_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the upper and lower blades (vertical opening).",
    )
    vertical_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for vertical offset of the slit.",
    )
    horizontal_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the left and right blades (horizontal opening).",
    )
    horizontal_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for horizontal offset of the slit.",
    )
    blade_up: Optional[str] = MetadataField(
        None, description="Position of the upper blade."
    )
    blade_down: Optional[str] = MetadataField(
        None, description="Position of the lower blade."
    )
    blade_front: Optional[str] = MetadataField(
        None, description="Position of the front blade."
    )
    blade_back: Optional[str] = MetadataField(
        None, description="Position of the back blade."
    )


class IcatInstrumentSecondarySlit(NXslit):
    name: Optional[str] = MetadataField(
        None, description="Name or identifier of the secondary slit."
    )
    vertical_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the upper and lower blades (vertical opening).",
    )
    vertical_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for vertical offset of the slit.",
    )
    horizontal_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the left and right blades (horizontal opening).",
    )
    horizontal_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for horizontal offset of the slit.",
    )
    blade_up: Optional[str] = MetadataField(
        None, description="Position of the upper blade."
    )
    blade_down: Optional[str] = MetadataField(
        None, description="Position of the lower blade."
    )
    blade_front: Optional[str] = MetadataField(
        None, description="Position of the front blade."
    )
    blade_back: Optional[str] = MetadataField(
        None, description="Position of the back blade."
    )


class IcatInstrumentSlits(NXslit):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the slit, provided as a space-separated list.",
    )
    vertical_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the upper and lower blades (vertical opening).",
    )
    vertical_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for vertical offset of the slit.",
    )
    horizontal_gap: Optional[str] = MetadataField(
        None,
        description="Distance between the left and right blades (horizontal opening).",
    )
    horizontal_offset: Optional[str] = MetadataField(
        None,
        description="Motor position for horizontal offset of the slit.",
    )
    blade_up: Optional[str] = MetadataField(
        None, description="Position of the upper blade."
    )
    blade_down: Optional[str] = MetadataField(
        None, description="Position of the lower blade."
    )
    blade_front: Optional[str] = MetadataField(
        None, description="Position of the front blade."
    )
    blade_back: Optional[str] = MetadataField(
        None, description="Position of the back blade."
    )


class IcatInstrumentDetectorRois(NXcollection):
    name: Optional[str] = MetadataField(
        None,
        description="Name or identifier of the region of interest (ROI) on the detector.",
    )
    value: Optional[ROIList] = MetadataField(
        None,
        description="Parameters defining the ROI, provided as a space-separated list. Format: R1P1,R1P2 R2P1,R2P2 ... RnP1,RnP2.",
    )


class IcatInstrumentEnvironmentSensors(NXsensor):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or type of the environmental sensor, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Measured value recorded by the sensor, provided as a space-separated list.",
    )


class IcatInstrumentInsertionDeviceGap(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the insertion device gap, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current value or setpoint of the insertion device gap, provided as a space-separated list.",
    )


class IcatInstrumentInsertionDeviceTaper(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the insertion device taper, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current taper value of the insertion device, provided as a space-separated list.",
    )


class IcatInstrumentInsertionDevice(NXinsertion_device):
    gap: Optional[IcatInstrumentInsertionDeviceGap] = MetadataField(
        None,
        description="Gap settings of the insertion device.",
        icat_name="_gap",
    )
    taper: Optional[IcatInstrumentInsertionDeviceTaper] = MetadataField(
        None,
        description="Taper settings of the insertion device.",
        icat_name="_taper",
    )


class IcatInstrumentDetectorPositioners(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the detector positioner, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current position of the detector component, provided as a space-separated list.",
    )


class IcatInstrumentAttenuatorPositioners(NXpositioner):
    name: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Name or identifier of the attenuator positioner, provided as a space-separated list.",
    )
    value: Optional[SpaceSeparatedList[str]] = MetadataField(
        None,
        description="Current position of the attenuator component, provided as a space-separated list.",
    )


class IcatInstrumentBeam(NXbeam):
    distance: Optional[METERS] = MetadataField(
        None,
        description="Distance from sample (recommended via NXtransformations).",
        include_nexus_url=True,
    )
    incident_energy: Optional[KILOELECTRONVOLTS_ARRAY] = MetadataField(
        None,
        description="Energy carried by each particle entering the beamline component, provided as a space-separated list.",
        include_nexus_url=True,
    )
    final_energy: Optional[KILOELECTRONVOLTS] = MetadataField(
        None,
        description="Energy carried by each particle leaving the beamline component.",
        include_nexus_url=True,
    )
    energy_transfer: Optional[KILOELECTRONVOLTS] = MetadataField(
        None,
        description="Change in particle energy caused by the beamline component.",
        include_nexus_url=True,
    )
    incident_wavelength: Optional[ANGSTROMS_ARRAY] = MetadataField(
        None,
        description="Wavelength on entering the beamline component, provided as a space-separated list.",
        include_nexus_url=True,
    )
    incident_wavelength_weights: Optional[SpaceSeparatedList[float]] = MetadataField(
        None,
        description="Weights for polychromatic beam wavelengths, provided as a space-separated list.",
        include_nexus_url=True,
    )
    incident_wavelength_spread: Optional[ANGSTROMS_ARRAY] = MetadataField(
        None,
        description="Wavelength spread FWHM for each incident wavelength, provided as a space-separated list.",
        include_nexus_url=True,
    )
    final_wavelength: Optional[ANGSTROMS] = MetadataField(
        None,
        description="Wavelength on leaving the beamline component.",
        include_nexus_url=True,
    )
    final_wavelength_spread: Optional[ANGSTROMS] = MetadataField(
        None,
        description="Wavelength spread FWHM of beam leaving this component.",
        include_nexus_url=True,
    )
    incident_beam_divergence: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description="Beam crossfire in degrees parallel to the laboratory X axis.",
        include_nexus_url=True,
    )
    horizontal_incident_beam_divergence: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description="Horizontal beam crossfire in degrees parallel to the laboratory X axis.",
    )
    vertical_incident_beam_divergence: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description="Vertical beam crossfire in degrees parallel to the laboratory Y axis.",
    )
    final_beam_divergence: Optional[DEGREES_ANGLE] = MetadataField(
        None,
        description="Divergence FWHM of beam leaving this component.",
        include_nexus_url=True,
    )
    extent: Optional[METERS] = MetadataField(
        None,
        description="Size of the beam entering this component.",
        include_nexus_url=True,
    )
    flux: Optional[PHOTON_FLUX] = MetadataField(
        None, description="Flux incident on beam plane area.", include_nexus_url=True
    )
    incident_polarization: Optional[float] = MetadataField(
        None,
        description="Polarization vector on entering beamline component.",
        include_nexus_url=True,
    )
    final_polarization: Optional[float] = MetadataField(
        None,
        description="Polarization vector on leaving beamline component.",
        include_nexus_url=True,
    )
    incident_polarization_stokes: Optional[float] = MetadataField(
        None,
        description="Polarization vector on entering beamline component using Stokes notation.",
        include_nexus_url=True,
    )
    final_polarization_stokes: Optional[float] = MetadataField(
        None,
        description="Polarization vector on leaving beamline component using Stokes notation.",
        include_nexus_url=True,
    )


class IcatInstrumentXraylens(NXxraylens):
    lens_geometry: Optional[str] = MetadataField(
        None,
        description="Geometry of the lens. Any of these values: paraboloid, spherical, elliptical, hyperbolical.",
    )
    focus_type: Optional[str] = MetadataField(
        None,
        description="The type of focus of the lens. Any of these values: line, point.",
    )
    lens_thickness: Optional[str] = MetadataField(
        None, description="Thickness of the lens"
    )
    lens_length: Optional[str] = MetadataField(None, description="Length of the lens.")
    curvature: Optional[str] = MetadataField(
        None,
        description="Radius of the curvature as measured in the middle of the lens.",
    )
    aperture: Optional[str] = MetadataField(None, description="Diameter of the lens.")
    number_of_lenses: Optional[int] = MetadataField(
        None, description="Number of lenses that make up the compound lens."
    )
    lens_material: Optional[str] = MetadataField(
        None, description="Material used to make the lens."
    )


class IcatInstrumentAttenuator(NXattenuator):
    type: Optional[str] = MetadataField(
        None, description="Type of attenuator or filter."
    )
    thickness: Optional[str] = MetadataField(
        None, description="Thickness of the attenuator material."
    )
    status: Optional[str] = MetadataField(
        None,
        description="Discrete attenuator position label or status (e.g., 'In1', 'In4').",
    )
    distance: Optional[str] = MetadataField(
        None, description="Distance from the sample along the beam path."
    )
    positioners: Optional[IcatInstrumentAttenuatorPositioners] = MetadataField(
        None, description="Positioners controlling the attenuator."
    )


class IcatInstrumentAttenuatorWithDescription(IcatInstrumentAttenuator):
    description: Optional[str] = MetadataField(
        None,
        description="Free-text description of the attenuator, its purpose, or any special characteristics.",
    )


class IcatInstrumentMonochromator(NXmonochromator):
    name: Optional[str] = MetadataField(
        None, description="Name or identifier of the monochromator."
    )
    energy: Optional[str] = MetadataField(
        None,
        description="Photon energy of the radiation selected by the monochromator.",
    )
    wavelength: Optional[str] = MetadataField(
        None, description="Wavelength of the radiation selected by the monochromator."
    )
    crystal: Optional[IcatInstrumentMonochromatorCrystal] = MetadataField(
        None, description="Crystal parameters used in the monochromator."
    )


class IcatInstrumentOptics(NXcollection):
    positioners: Optional[IcatInstrumentOpticsPositioners] = MetadataField(
        None,
        description="Motors or actuators controlling the positions of optical components.",
    )


class IcatInstrumentEnvironment(NXenvironment):
    sensors: Optional[IcatInstrumentEnvironmentSensors] = MetadataField(
        None, description="Parameters for controlling external conditions."
    )


class IcatCryostat(NXenvironment):
    value: Optional[KELVINS] = MetadataField(
        None,
        description="Cryostat setpoint temperature.",
        include_nexus_url=True,
    )


class IcatInstrumentDetector(NXdetector):
    name: Optional[str] = MetadataField(None, description="Name of the detector.")
    type: Optional[str] = MetadataField(
        None,
        description="Type of detector, e.g., "
        "He3 gas cylinder, He3 PSD, scintillator, fission chamber, proportional counter, ion chamber, CCD, pixel, image plate, CMOS, etc.",
    )
    manufacturer: Optional[str] = MetadataField(
        None, description="Name of the manufacturer of the detector. Example: Dectris."
    )
    model: Optional[str] = MetadataField(
        None, description="Model of the detector. Example: Pilatus3_6M."
    )
    preset_time: Optional[float] = MetadataField(
        None, description="Desired measurement time."
    )
    live_time: Optional[float] = MetadataField(
        None,
        description="Time the detector was actively measuring (elapsed_time minus dead_time).",
        icat_name="elapsed_live_time",
    )
    elapsed_time: Optional[float] = MetadataField(
        None,
        description="Elapsed time between the start and stop of the measurement.",
        icat_name="elapsed_real_time",
    )
    calibration: Optional[str] = MetadataField(
        None,
        description="For MCA detectors, coefficients a, b, c used to compute a scale based on channel number as a + b * x + c * x * x.",
    )
    description: Optional[str] = MetadataField(
        None,
        description="General information about the detector, e.g., name, manufacturer, model, etc.",
    )
    local_name: Optional[str] = MetadataField(
        None, description="Local name for the detector."
    )
    x_pixel_size: Optional[str] = MetadataField(
        None,
        description="Size of each detector pixel. If scalar, all pixels have the same size.",
    )
    y_pixel_size: Optional[str] = MetadataField(
        None,
        description="Size of each detector pixel. If scalar, all pixels have the same size.",
    )
    calibration_date: Optional[str] = MetadataField(
        None, description="Date when the detector was last calibrated."
    )
    layout: Optional[str] = MetadataField(
        None,
        description="Detector layout. Possible values are: point, linear, or area.",
    )
    beam_center_x: Optional[str] = MetadataField(
        None,
        description="X position where the direct beam would hit the detector. "
        "Can be outside of the actual detector; units may be physical length or pixels.",
    )
    beam_center_y: Optional[str] = MetadataField(
        None,
        description="Y position where the direct beam would hit the detector. "
        "Can be outside of the actual detector; units may be physical length or pixels.",
    )
    flatfield_applied: Optional[str] = MetadataField(
        None,
        description="True if the flat-field correction has been applied in the electronics, false otherwise.",
        icat_name="flat_field_applied",
    )
    pixel_mask: Optional[str] = MetadataField(
        None, description="32-bit pixel mask for the detector."
    )
    pixel_mask_applied: Optional[str] = MetadataField(
        None,
        description="True if the pixel mask correction has been applied in the electronics, false otherwise.",
    )
    countrate_correction_applied: Optional[str] = MetadataField(
        None,
        description="Count-rate correction applied to account for detector limitations at high count rates.",
    )
    saturation_value: Optional[str] = MetadataField(
        None,
        description="Value at which the detector saturates. Data above this value, common in CCD detectors, are considered invalid.",
    )
    threshold_energy: Optional[str] = MetadataField(
        None,
        description="Energy setting for single-photon counting detectors, defining the optimal energy range.",
    )
    sensor_thickness: Optional[str] = MetadataField(
        None,
        description="Thickness of the detector's sensing material or conversion layer.",
    )
    sensor_material: Optional[str] = MetadataField(
        None,
        description="Material that converts radiation for detection, e.g., scintillator, if the detector does not sense radiation directly.",
    )
    bit_depth_readout: Optional[str] = MetadataField(
        None,
        description="Number of bits read per pixel by the electronics. "
        "For CCDs and single-photon counting detectors, this can be 4, 8, 12, 14, or 16 bits.",
    )
    distance: Optional[str] = MetadataField(
        None,
        description="Distance from the previous component in the instrument, typically the sample. "
        "For irregular detectors, specify the distance for each detector pixel.",
    )
    frame_time: Optional[str] = MetadataField(
        None,
        description="Time per frame, equal to exposure time plus readout time.",
    )
    positioners: Optional[IcatInstrumentDetectorPositioners] = MetadataField(
        None,
        description="Positioners controlling the detector's location or orientation relative to the beamline.",
    )
    rois: Optional[IcatInstrumentDetectorRois] = MetadataField(
        None,
        description="Regions of interest (ROIs) applied to the detector, with names and parameters.",
    )
    acquisition_mode: Optional[str] = MetadataField(
        None,
        description="Acquisition mode of the detector. Possible values are: gated, triggered, summed, event, histogrammed, or decimated.",
    )


_ATTENUATOR_DESCRIPTION = "Beamline attenuator used to reduce beam intensity."
_DETECTOR_DESCRIPTION = "Detector used to measure the beam."
_CRYOSTAT_DESCRIPTION = "Device to maintain low temperatures."
_LENS_DESCRIPTION = "X-ray lens system used for focusing or shaping the beam."


class IcatInstrument(NXinstrument):
    name: Optional[str] = MetadataField(
        None,
        description="Identifier of the beamline.",
        icat_name="beamlineID",
    )
    variables: Optional[IcatInstrumentVariables] = MetadataField(
        None,
        description="Named variables or parameters associated with the instrument.",
    )
    positioners: Optional[IcatInstrumentPositioners] = MetadataField(
        None, description="Motors or actuators controlling instrument components."
    )
    beam: Optional[IcatInstrumentBeam] = MetadataField(
        None, description="Beam properties."
    )
    monochromator: Optional[IcatInstrumentMonochromator] = MetadataField(
        None, description="Monochromator configuration."
    )
    source: Optional[IcatInstrumentSource] = MetadataField(
        None, description="Radiation source properties."
    )
    laser01: Optional[IcatInstrumentLaser] = MetadataField(
        None, description="Laser system 1."
    )
    laser02: Optional[IcatInstrumentLaser] = MetadataField(
        None, description="Laser system 2."
    )
    primary_slit: Optional[IcatInstrumentPrimarySlit] = MetadataField(
        None,
        description="Primary slit configuration used to define or shape the beam.",
        icat_name="slit_primary",
    )
    secondary_slit: Optional[IcatInstrumentSecondarySlit] = MetadataField(
        None,
        description="Secondary slit configuration used to define or shape the beam; located downstream of the primary slit.",
        icat_name="slit_secondary",
    )
    slits: Optional[IcatInstrumentSlits] = MetadataField(
        None, description="Slit configuration for shaping and defining the beam."
    )
    xraylens01: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens02: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens03: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens04: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens05: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens06: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens07: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens08: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens09: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    xraylens10: Optional[IcatInstrumentXraylens] = MetadataField(
        None, description=_LENS_DESCRIPTION
    )
    attenuator01: Optional[IcatInstrumentAttenuatorWithDescription] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator02: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator03: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator04: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator05: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator06: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator07: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator08: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator09: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator10: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator11: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator12: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator13: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator14: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    attenuator15: Optional[IcatInstrumentAttenuator] = MetadataField(
        None, description=_ATTENUATOR_DESCRIPTION
    )
    insertion_device: Optional[IcatInstrumentInsertionDevice] = MetadataField(
        None,
        description="Insertion device such as undulators or wigglers used to generate or shape the beam.",
    )
    optics: Optional[IcatInstrumentOptics] = MetadataField(
        None,
        description="Beamline optical components including mirrors, lenses, and other elements that shape or direct the beam.",
    )
    environment: Optional[IcatInstrumentEnvironment] = MetadataField(
        None,
        description="Parameters for controlling and monitoring the instrument environment.",
    )
    cryostat01: Optional[IcatCryostat] = MetadataField(
        None, description=_CRYOSTAT_DESCRIPTION
    )
    detector01: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector02: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector03: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector04: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector05: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector06: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector07: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector08: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector09: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
    detector10: Optional[IcatInstrumentDetector] = MetadataField(
        None, description=_DETECTOR_DESCRIPTION
    )
