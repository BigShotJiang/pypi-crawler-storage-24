from typing import Optional

import pytest

from ..models.base.field_utils import resolve_field_description
from ..models.base.metadata_field import MetadataField
from ..models.base.model import IcatNexusBaseModel
from ..models.base.nexus import NXbeam
from ..models.base.nexus import NXsource


class MockNXSource(NXsource):
    name: Optional[str] = MetadataField(
        None, description="Laser name", include_nexus_url=True
    )
    pulse_width: Optional[float] = MetadataField(None, description="Pulse width")
    type: Optional[str] = MetadataField(None, description="")


class MockNXBeam(NXbeam):
    distance: Optional[float] = MetadataField(
        None, description="Beam distance", include_nexus_url=True
    )
    final_energy: Optional[float] = MetadataField(
        None, description="Energy", include_nexus_url=True
    )


class MockNoNX(IcatNexusBaseModel):
    name: Optional[str] = MetadataField(
        None, description="No NX", include_nexus_url=True
    )


@pytest.mark.parametrize(
    "model_cls, field_name, expected_contains",
    [
        (
            MockNXSource,
            "name",
            "See https://manual.nexusformat.org/classes/base_classes/NXsource.html#nxsource-name-field",
        ),
        (MockNXSource, "type", ""),
        (MockNXSource, "pulse_width", "Pulse width"),
        (
            MockNXBeam,
            "distance",
            "See https://manual.nexusformat.org/classes/base_classes/NXbeam.html#nxbeam-distance-field",
        ),
        (
            MockNXBeam,
            "final_energy",
            "See https://manual.nexusformat.org/classes/base_classes/NXbeam.html#nxbeam-final-energy-field",
        ),
        (MockNoNX, "name", "No NX"),
    ],
)
def test_resolve_field_description(model_cls, field_name, expected_contains):
    field_info = model_cls.model_fields[field_name]
    desc = resolve_field_description(model_cls, field_name, field_info)
    assert expected_contains in desc
