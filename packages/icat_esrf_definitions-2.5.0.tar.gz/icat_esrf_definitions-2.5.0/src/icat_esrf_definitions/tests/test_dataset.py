from ..models import IcatDatasetParameters
from ..models.applications.applications import APPLICATIONS_REGISTRY


def test_dataset_allows_none_for_optional_fields():
    data = {
        "title": "dummy title",
        "proposal": "hg123",
        "folder_path": "/tmp",
        "start_time": "2025-01-01T08:00:00",
        "end_time": "2025-01-01T05:01:00",
        "sample": {"name": "Sample"},
    }
    assert len(APPLICATIONS_REGISTRY) > 0
    for short_name in APPLICATIONS_REGISTRY:
        data[short_name] = None

    dataset = IcatDatasetParameters(**data)
    assert dataset.title == "dummy title"
    for short_name in APPLICATIONS_REGISTRY:
        assert getattr(dataset, short_name) is None
