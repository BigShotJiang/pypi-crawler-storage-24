import warnings

import pytest

pytest.register_assert_rewrite("icat_esrf_definitions.tests.compare")


@pytest.fixture
def ignore_pydantic_deprecation_warnings():
    """Ignore warnings from deprecated Pydantic fields."""
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=DeprecationWarning,
            module="icat_esrf_definitions.models.base.model",
        )
        yield
