try:
    from typing import Annotated
except ImportError:
    # python <3.9
    from typing_extensions import Annotated
from typing import Optional
from typing import Union

import pytest

from ..models.base.custom_types._metadata.base import CustomTypeMetadata
from ..models.base.field_utils import get_field_metadata
from ..models.base.field_utils import get_field_type


class _CustomMetadata(CustomTypeMetadata):
    pass


@pytest.mark.parametrize(
    "annotation, target_type, expected",
    [
        (int, int, int),
        (int, CustomTypeMetadata, None),
        (_CustomMetadata, CustomTypeMetadata, _CustomMetadata),
        (Annotated[int, _CustomMetadata], int, int),
        (Optional[int], int, int),
        (
            Optional[_CustomMetadata],
            CustomTypeMetadata,
            _CustomMetadata,
        ),
        (
            Union[int, _CustomMetadata],
            CustomTypeMetadata,
            _CustomMetadata,
        ),
    ],
)
def test_get_field_type(annotation, target_type, expected):
    assert get_field_type(annotation, target_type) is expected


@pytest.mark.parametrize(
    "annotation, expected",
    [
        (int, None),
        (Optional[int], None),
        (Union[int, str], None),
        (Annotated[int, _CustomMetadata], _CustomMetadata),
        (Optional[Annotated[int, _CustomMetadata]], _CustomMetadata),
        (
            Union[int, Annotated[str, _CustomMetadata]],
            _CustomMetadata,
        ),
    ],
)
def test_get_field_metadata(annotation, expected):
    result = get_field_metadata(annotation, CustomTypeMetadata)
    assert result == expected
