# icat-esrf-definitions

Python project that defines a schema based on [NeXus](https://www.nexusformat.org/)  
for raw and processed metadata in the data portal of the [European Synchrotron](https://www.esrf.fr/).
