from os import system
def main()->None:
    system("uv pip install --upgrade kbasic kplot kgsim")