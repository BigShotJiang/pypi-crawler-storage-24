"""Service Management resource classes for managing AI service configurations."""

from wiil.resources.service_mgt.agent_configs import AgentConfigurationsResource
from wiil.resources.service_mgt.deployment_configs import (
    DeploymentConfigurationsResource,
)
from wiil.resources.service_mgt.deployment_channels import DeploymentChannelsResource
from wiil.resources.service_mgt.instruction_configs import (
    InstructionConfigurationsResource,
)
from wiil.resources.service_mgt.phone_configs import PhoneConfigurationsResource
from wiil.resources.service_mgt.provisioning_configs import (
    ProvisioningConfigurationsResource,
)
from wiil.resources.service_mgt.conversation_configs import (
    ConversationConfigurationsResource,
)
from wiil.resources.service_mgt.translation_sessions import TranslationSessionsResource
from wiil.resources.service_mgt.knowledge_sources import KnowledgeSourcesResource
from wiil.resources.service_mgt.support_models import SupportModelsResource
from wiil.resources.service_mgt.telephony_provider import TelephonyProviderResource
from wiil.resources.service_mgt.dynamic_agent_status import (
    DynamicAgentStatusResource,
    PollOptions,
    PollTimeoutError,
)
from wiil.resources.service_mgt.dynamic_web_agent import (
    DynamicWebAgentResource,
    WebAgentCreateOptions,
)
from wiil.resources.service_mgt.dynamic_phone_agent import (
    DynamicPhoneAgentResource,
    PhoneAgentCreateOptions,
)

__all__ = [
    'AgentConfigurationsResource',
    'DeploymentConfigurationsResource',
    'DeploymentChannelsResource',
    'InstructionConfigurationsResource',
    'PhoneConfigurationsResource',
    'ProvisioningConfigurationsResource',
    'ConversationConfigurationsResource',
    'TranslationSessionsResource',
    'KnowledgeSourcesResource',
    'SupportModelsResource',
    'TelephonyProviderResource',
    'DynamicAgentStatusResource',
    'PollOptions',
    'PollTimeoutError',
    'DynamicWebAgentResource',
    'WebAgentCreateOptions',
    'DynamicPhoneAgentResource',
    'PhoneAgentCreateOptions',
]
