from __future__ import annotations

from pathlib import Path

from cf_datahive import cf_datahive_cpp_include_path, cf_datahive_cpp_source_path


def test_native_source_surface_is_packaged_under_owner_package() -> None:
    source_root = Path(cf_datahive_cpp_source_path())
    include_root = Path(cf_datahive_cpp_include_path())

    assert source_root.is_dir()
    assert (source_root / "CMakeLists.txt").is_file()
    assert (source_root / "src" / "cf_datahive_cpp.cpp").is_file()
    assert include_root.is_dir()
    assert (include_root / "cf_datahive_cpp" / "cf_datahive_cpp.h").is_file()
