"""Data hive storage client package."""

from pathlib import Path

from .client import DataHiveClient, RunHandle, StorageModePolicy
from .manifest import ArtifactEntry, RunManifest, RunSummary, TableEntry
from .policy import Policy

_PACKAGE_ROOT = Path(__file__).resolve().parent


def cf_datahive_cpp_source_path() -> str:
    """Return the package-owned native cf_datahive_cpp source root."""
    return str(_PACKAGE_ROOT / "cpp")


def cf_datahive_cpp_include_path() -> str:
    """Return the package-owned native cf_datahive_cpp include root."""
    return str(_PACKAGE_ROOT / "cpp" / "include")

__all__ = [
    "ArtifactEntry",
    "DataHiveClient",
    "Policy",
    "RunHandle",
    "StorageModePolicy",
    "RunManifest",
    "RunSummary",
    "TableEntry",
    "cf_datahive_cpp_include_path",
    "cf_datahive_cpp_source_path",
]
