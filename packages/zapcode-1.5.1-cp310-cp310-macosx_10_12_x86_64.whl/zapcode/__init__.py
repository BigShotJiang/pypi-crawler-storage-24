from .zapcode import *

__doc__ = zapcode.__doc__
if hasattr(zapcode, "__all__"):
    __all__ = zapcode.__all__