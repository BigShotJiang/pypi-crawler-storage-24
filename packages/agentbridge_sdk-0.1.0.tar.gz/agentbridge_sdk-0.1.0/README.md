# AgentBridge Python SDK

Official Python SDK for the AgentBridge API. Execute tools across connected providers (GitHub, Slack, Notion, Gmail, Google Drive) with a single API key.

## Installation

```bash
pip install agentbridge-sdk
```

## Quick Start

```python
from agentbridge import AgentBridge

client = AgentBridge(
    api_key="ab_your_api_key_here",
    base_url="http://localhost:3000",  # optional
)

result = client.execute(provider="github", tool="list_repos")
print(result["data"])
```

## Configuration

| Parameter  | Type | Required | Default                 | Description            |
| ---------- | ---- | -------- | ----------------------- | ---------------------- |
| `api_key`  | str  | Yes      | —                       | Your AgentBridge API key |
| `base_url` | str  | No       | `http://localhost:3000` | API base URL           |

## Methods

### `execute(provider, tool, params=None)`

Execute a tool on a connected provider.

```python
result = client.execute(
    provider="github",
    tool="create_issue",
    params={
        "owner": "octocat",
        "repo": "hello-world",
        "title": "Bug report",
        "body": "Something is broken",
    },
)
```

**Parameters:**

| Argument   | Type          | Required | Description                  |
| ---------- | ------------- | -------- | ---------------------------- |
| `provider` | str           | Yes      | Provider slug (e.g. `github`, `slack`, `notion`) |
| `tool`     | str           | Yes      | Tool name (e.g. `list_repos`, `create_issue`)    |
| `params`   | dict or None  | No       | Tool-specific parameters     |

**Returns:** `{"status": "success", "data": ...}`

### `get_providers()`

List all active providers.

```python
providers = client.get_providers()
# [{"id": "...", "name": "GitHub", "slug": "github", "active": True}, ...]
```

### `get_provider_tools(slug)`

List available tools for a provider.

```python
tools = client.get_provider_tools("github")
# [{"name": "list_repos", "description": "...", "parameters": {...}}, ...]
```

## Error Handling

The SDK raises `requests.exceptions.HTTPError` for failed requests:

```python
from requests.exceptions import HTTPError

try:
    result = client.execute(provider="github", tool="list_repos")
except HTTPError as e:
    print(f"Request failed: {e.response.status_code} - {e.response.text}")
```

## Available Providers & Tools

### GitHub

| Tool           | Description                          | Parameters                                  |
| -------------- | ------------------------------------ | ------------------------------------------- |
| `list_repos`   | List authenticated user repositories | —                                           |
| `create_issue` | Create a GitHub issue                | `owner`, `repo`, `title`, `body`(optional)  |
| `create_pr`    | Create a pull request                | `owner`, `repo`, `title`, `head`, `base`, `body`(optional) |
| `get_file`     | Get file contents from a repository  | `owner`, `repo`, `path`                     |

### Slack

Use `get_provider_tools("slack")` to list available tools.

### Notion

Use `get_provider_tools("notion")` to list available tools.

### Gmail

Use `get_provider_tools("gmail")` to list available tools.

### Google Drive

Use `get_provider_tools("google-drive")` to list available tools.

## Requirements

- Python >= 3.9
- requests >= 2.20.0

## License

MIT
