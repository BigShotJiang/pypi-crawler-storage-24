from __future__ import annotations

from typing import Any
from urllib.parse import quote

import requests


class AgentBridge:
    """Python SDK for AgentBridge API."""

    def __init__(self, api_key: str, base_url: str = "http://localhost:3000") -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
        )

    def _request(self, method: str, path: str, json: dict | None = None) -> Any:
        url = f"{self.base_url}/api/mcp{path}"
        resp = self._session.request(method, url, json=json)
        resp.raise_for_status()
        return resp.json()

    def execute(
        self,
        provider: str,
        tool: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a tool on a provider."""
        return self._request(
            "POST",
            "/execute",
            json={"provider": provider, "tool": tool, "params": params or {}},
        )

    def get_providers(self) -> list[dict[str, Any]]:
        """List all active providers."""
        return self._request("GET", "/providers")

    def get_provider_tools(self, slug: str) -> list[dict[str, Any]]:
        """List tools for a provider."""
        return self._request("GET", f"/providers/{quote(slug, safe='')}/tools")
