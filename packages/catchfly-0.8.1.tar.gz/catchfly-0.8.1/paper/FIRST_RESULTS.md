# SICI First Results — 2026-03-23

## Experiments run

### Exp 1: Feedback Loop (Product Type, text-embedding-3-small)

3 iteracje, 1 seed (42+iteration), K~50.

| Iteration | NMI | ARI | Purity |
|-----------|-----|-----|--------|
| 0 | 0.663 | 0.634 | 0.659 |
| 1 | 0.672 | 0.602 | 0.673 |
| 2 | 0.658 | 0.556 | 0.655 |

**Result:** Feedback loop nie poprawia NMI. ARI konsekwentnie spada. Enrichment propaguje błędy z niedoskonałego clusteringu (garbage in, garbage out). Ale problem jest głębszy — sam SICI nie daje przewagi na tym datasecie (patrz Exp 2).

### Exp 2: IE Baselines (Product Type, text-embedding-3-small, 10 seeds)

| Strategy | NMI |
|----------|-----|
| kmeanspp | 0.656±0.010 |
| random_text | 0.653±0.010 |
| label_name | 0.659±0.011 |
| sici_holistic | 0.655±0.009 |
| sici_decomposed | 0.665±0.013 |
| oracle | 0.696±0.004 |

**Result:** Wszystkie strategie w granicach szumu (0.653-0.665). Oracle (idealne seedy) daje zaledwie +0.04 nad kmeanspp. SICI nie pomaga — problem nie jest w inicjalizacji.

### Exp 5: Convergence (Product Type, text-embedding-3-small, 3 seeds, 25 iter)

| Iteration | oracle | kmeanspp |
|-----------|--------|----------|
| 1 | 0.648±0.002 | 0.596±0.012 |
| 5 | 0.701±0.001 | 0.652±0.019 |
| 10 | 0.696±0.004 | 0.658±0.006 |
| 20 | 0.698±0.005 | 0.649±0.016 |
| 21 | 0.703±0.007 | 0.657±0.008 |
| 25 | 0.701±0.007 | 0.656±0.017 |

**Result:** Brak spadku po LLM summary round (iter 20-21) — summaries NIE psują inicjalizacji. Oba convergują w 5-10 iteracjach. Oracle sufit ~0.70, kmeanspp ~0.656. 120 iteracji to overkill.

### Exp 2: IE Baselines (Product Type, text-embedding-3-large, 10 seeds)

| Strategy | NMI |
|----------|-----|
| kmeanspp | 0.690±0.011 |
| random_text | 0.683±0.013 |
| label_name | 0.686±0.014 |
| sici_holistic | 0.690±0.009 |
| sici_decomposed | 0.689±0.013 |
| oracle | 0.706±0.002 |

**Result:** Lepszy embedding podnosi sufit (+0.034 dla kmeanspp), ale gap oracle-kmeanspp skurczył się z 0.04 do 0.016. SICI nadal ≈ kmeanspp.

### Exp 2: IE Baselines (Brand, text-embedding-3-large, 10 seeds)

| Strategy | NMI |
|----------|-----|
| kmeanspp | 0.983±0.001 |
| random_text | 0.910±0.011 |
| label_name | 0.981±0.001 |
| sici_holistic | 0.983±0.001 |
| sici_decomposed | 0.961±0.007 |
| oracle | 0.988±0.000 |

**Result:** Baseline już prawie idealny (0.983). Oracle ceiling = 0.988, gap = 0.005. sici_decomposed (0.961) GORSZY niż kmeanspp — seedy ze schematu actively hurt. Embeddingi dobrze separują Brand, więc k-means++ trafia od razu.

## Key findings

### F1: SICI nie ma sweet spotu na IE normalization

| Atrybut | Typ normalizacji | kmeanspp | oracle | Gap | SICI |
|---------|-----------------|----------|--------|-----|------|
| Product Type | Semantyczna ("Wedding band"→"Rings/Bands") | 0.690 | 0.706 | 0.016 | ≈ baseline |
| Brand | Surface-form ("HP"→"Hewlett-Packard") | 0.983 | 0.988 | 0.005 | < baseline |

- Gdy embeddingi słabe (Product Type) → sufit za niski, inicjalizacja nie pomoże
- Gdy embeddingi dobre (Brand) → podłoga za wysoka, k-means++ i tak trafia
- Nie ma atrybutu gdzie SICI daje istotny zysk

### F2: Embedding-based clustering to zły approach do value normalization

Dwa typy normalizacji, oba źle obsługiwane:
- **Semantyczna** ("Wedding band" → "Rings/Bands") — wymaga wiedzy domenowej, nie embedding similarity
- **Surface-form** ("HP" → "Hewlett-Packard") — embeddingi i tak dobrze rozdzielają, dodatkowe seedy niepotrzebne

### F3: LLM summaries nie psują inicjalizacji

Convergence check wykazał brak degradacji po LLM summary round (iter 20). Odrzucona hipoteza.

### F4: Zbieżność jest szybka

k-LLMmeans converguje w 5-10 iteracjach. 120 iteracji to overkill.

### F5: Schema knowledge jest wartościowe, ale nie jako centroidy

SchemaOptimizer generuje użyteczne metadata (opisy, przykłady, synonimy). Ale użycie ich jako embedding seeds w k-means nie poprawia normalizacji. Wartość schematu leży w kontekście dla LLM reasoning, nie w geometrii embedding space.

## Phase 2: LLMCanonicalization diagnostic (Pivot A test)

### LLMCanonicalization vs KLLMeansClustering

**Brand** (K=170, N=756, 178 unique):

| Method | NMI |
|--------|-----|
| kmeanspp (emb-large, Exp 2) | 0.983±0.001 |
| LLMCanonicalization (no schema) | 0.980±0.001 |
| LLMCanonicalization (with schema) | 0.979±0.001 |

All at ceiling. Schema context irrelevant.

**Product Type** (K=42, N=2590, 1136 unique):

| Method | NMI | Groups |
|--------|-----|--------|
| kmeanspp (emb-small, Exp 2) | 0.656±0.010 | 42 (forced) |
| kmeanspp (emb-large, Exp 2) | 0.690±0.011 | 42 (forced) |
| oracle (emb-large, Exp 2) | 0.706±0.002 | 42 (forced) |
| **LLMCanonicalization (no schema)** | **0.709±0.001** | ~720 |
| **LLMCanonicalization (with schema)** | **0.720±0.002** | ~665 |

## Key findings (updated)

### F1: SICI nie ma sweet spotu na IE normalization (unchanged)

### F2: LLM reasoning > embedding clustering na semantycznej normalizacji

LLMCanonicalization bez schematu (0.709) bije oracle embedding clustering (0.706) na Product Type. LLM *rozumie* że "wedding band" → "Rings/Bands" — embeddingi nie. To fundamentalnie inny mechanism: reasoning vs geometric distance.

### F3: Schema context pomaga LLM normalization

+0.011 NMI (0.709 → 0.720) na Product Type ze schema context. Małe ale konsekwentne (p < 0.01 across runs). Schema także redukuje fragmentację: 720 → 665 grup. Teza "schema knowledge improves normalization" jest walidowana — ale mechanizm to prompt context, nie centroidy.

### F4: Map-reduce batching jest głównym bottleneckiem

LLM tworzy ~665-720 grup zamiast K=42. Batche po 50 wartości → lokalne grupowanie → cross-batch merge tylko case-insensitive string match. "Wedding Rings" z batch 1 i "Rings & Bands" z batch 3 nie mergują. **To jest nisko wiszący owoc** — hierarchiczny merge (drugi pass LLM na canonical names) powinien dramatycznie poprawić NMI.

### F5: LLM summaries nie psują inicjalizacji (unchanged)

### F6: Zbieżność k-LLMmeans jest szybka (unchanged)

## Wniosek strategiczny

**SICI (embedding centroid seeding) to ślepy zaułek.** Schema knowledge jest wartościowe, ale powinno być użyte jako prompt context dla LLM reasoning.

**LLMCanonicalization jest lepszym fundamentem** — już teraz bije embedding clustering na trudnym atrybucie. Główny bottleneck to cross-batch merge, nie samo grupowanie.

## Proponowany kierunek: Schema-guided hierarchical LLM normalization

### Krok 1: Lepszy merge (nisko wiszący owoc)
Obecny merge: case-insensitive string matching.
Propozycja: drugi LLM pass na listę canonical names z batchy → merge semantycznie podobnych grup.
Oczekiwany efekt: 665 grup → ~42-80 grup, duży skok NMI.

### Krok 2: Schema-aware prompting (walidowane)
Schema description w system prompcie daje +0.011 NMI i redukuje fragmentację. Rozbudować: dodać examples, constraints, known canonical forms z SchemaOptimizer.

### Krok 3: Feedback loop v2
Zamiast: normalize → enrich schema → normalize again (embedding-based).
Nowe: LLM normalize → zebrać canonical names → enrich schema z wynikami → re-normalize z lepszym schema context.
To może działać bo LLM normalization faktycznie korzysta ze schema (w odróżnieniu od SICI).

### Krok 4: Hybrid pipeline
1. Embedding clustering (szybki, tani) → wstępne grupy
2. LLM z schema context → merge/split/rename grup
3. Łączy efektywność embeddingów z dokładnością LLM reasoning

## Koszty dotychczas

| Run | Embedding | ~Koszt |
|-----|-----------|--------|
| Exp 1 (feedback, PT, small) | text-embedding-3-small | ~$2 |
| Exp 2 (PT, small, 10 seeds) | text-embedding-3-small | ~$15 |
| Exp 5 (convergence, PT, small) | text-embedding-3-small | ~$7 |
| Exp 2 (PT, large, 10 seeds) | text-embedding-3-large | ~$17 |
| Exp 2 (Brand, large, 10 seeds) | text-embedding-3-large | ~$17 |
| LLMCanon (Brand+PT, 3 runs each) | n/a (LLM only) | ~$5 |
| **Total** | | **~$63** |
