# Catchfly — Implementation Plan

Target: **v0.1 MVP** — `Pipeline.quick()` works end-to-end.

Tooling: `uv` for package management, `ruff` for lint/format, `mypy` for type checking, `pytest` for tests.

---

## Phase 0: Project Scaffold ✅

### Step 0.1 — Initialize uv project and dev environment ✅

- `uv sync --extra all --all-groups` (used `--extra all` instead of `--all-extras` to avoid pulling docling)
- pydantic 2.12.5, httpx 0.28.1, Python 3.11.13
- All extras installed: openai, instructor, sentence-transformers, scikit-learn, umap-learn, pandas, pyarrow, pymupdf, pronto

### Step 0.2 — Create directory skeleton ✅

Created all empty `__init__.py` files and marker files per PRD 9.2. All subpackages import successfully.

```
src/catchfly/
├── py.typed                  (empty file)
├── _types.py
├── _compat.py                (async event-loop detection helper)
├── exceptions.py
├── pipeline.py
├── demo/__init__.py
├── discovery/__init__.py
├── discovery/base.py
├── extraction/__init__.py
├── extraction/base.py
├── extraction/chunking.py
├── normalization/__init__.py
├── normalization/base.py
├── providers/__init__.py
├── providers/llm.py
├── providers/embeddings.py
├── schema/__init__.py
├── schema/converters.py
├── telemetry/__init__.py
├── telemetry/tracker.py
tests/
├── conftest.py
├── unit/
├── integration/
├── fixtures/
│   ├── sample_documents/
│   ├── schemas/
│   └── llm_responses/
```

### Step 0.3 — CI and tooling ✅

- `.github/workflows/ci.yml` — lint, typecheck, test matrix (3.10-3.13) with `astral-sh/setup-uv@v5`
- `.pre-commit-config.yaml` — ruff (lint+format) + mypy strict hooks
- `uv run pre-commit install` — hooks active
- Verified: `ruff check .` ✅, `ruff format --check .` ✅, `mypy src/` ✅ (20 source files, 0 issues), `pytest --collect-only` ✅

---

## Phase 1: Core Types & Providers ✅

> Goal: `LLMClient` and `EmbeddingClient` talk to OpenAI/Ollama. All domain types defined.

### Step 1.1 — `exceptions.py` ✅

```python
class CatchflyError(Exception): ...
class ProviderError(CatchflyError): ...
class DiscoveryError(CatchflyError): ...
class ExtractionError(CatchflyError): ...
class NormalizationError(CatchflyError): ...
class SchemaError(CatchflyError): ...
class BudgetExceededError(CatchflyError): ...
```

### Step 1.2 — `_types.py` ✅

Implement all core types from PRD 9.4:
- `Document` (dataclass: content, id, source, metadata)
- `Schema` (dataclass: model, json_schema, field_metadata, lineage)
- `SchemaT = TypeVar("SchemaT", bound=BaseModel)`
- `ExtractionResult[SchemaT]` (Generic dataclass: records, errors, provenance)
- `RecordProvenance` (dataclass: source_document, chunk_index, char_start, char_end, confidence)
- `NormalizationResult` (dataclass: mapping, clusters, metadata, explain())
- `PipelineResult` (dataclass: schema, records, normalizations, errors, report)

### Step 1.3 — `_compat.py` ✅

Async/sync compatibility layer:
- `run_sync(coro)` — detects running event loop (Jupyter), uses `nest_asyncio` if available, otherwise `asyncio.run()`
- Keep it small: ~20 lines

### Step 1.4 — `providers/llm.py` ✅

- `LLMClient` Protocol: `acomplete(messages, model, **kwargs) -> ChatCompletion`
- `OpenAICompatibleClient` implementation:
  - Takes `model`, `base_url`, `api_key` (or from env `OPENAI_API_KEY`)
  - Uses `openai.AsyncOpenAI` under the hood
  - Retry logic (exponential backoff, max 3 retries on rate limit / 5xx)
  - Token counting from response `usage`
  - `logging.getLogger(__name__)` — DEBUG for each call, WARNING for retries
- Sync wrapper: `complete()` calls `run_sync(acomplete())`

**Tests:**
- `tests/unit/test_llm_client.py` — mock `httpx` responses, verify retry, verify token counting
- `tests/conftest.py` — `MockLLMClient` fixture returning canned JSON from fixtures dir

### Step 1.5 — `providers/embeddings.py` ✅

- `EmbeddingClient` Protocol: `aembed(texts: list[str]) -> list[list[float]]`
- `OpenAIEmbeddingClient` implementation:
  - Uses `openai.AsyncOpenAI` embeddings endpoint
  - Batching (max 2048 texts per call, configurable)
  - In-memory LRU cache for repeated texts
  - Sync wrapper: `embed()`
- Return `list[list[float]]` (not numpy — keep core dep-free; convert to ndarray only in strategies that need it)

**Tests:**
- `tests/unit/test_embedding_client.py` — mock responses, verify caching, verify batching

### Step 1.6 — `schema/converters.py` ✅

- `pydantic_to_json_schema(model: type[BaseModel]) -> dict` — thin wrapper on `model.model_json_schema()`
- `json_schema_to_pydantic(schema: dict, name: str) -> type[BaseModel]` — dynamic model creation via `pydantic.create_model()` from JSON Schema fields
- `schema_to_typed_dict(model: type[BaseModel]) -> type` — for users who prefer TypedDict
- Handles: nested objects, arrays, enums, optional fields

**Tests:**
- `tests/unit/test_schema_converters.py` — roundtrip property tests with Hypothesis (generate random Pydantic models, convert to JSON Schema and back, verify field equivalence)

### Step 1.7 — `telemetry/tracker.py` ✅

- UsageTracker with record(), total_cost(), report(), to_dict(), budget check
- Auto cost estimation from pricing table for common models
- 7 tests covering totals, breakdown, budget exceeded, auto-estimation

**Checkpoint:** 48 tests passing, `mypy src/` clean (20 files, 0 issues), `ruff check .` clean.

---

## Phase 2: Discovery & Extraction ✅

> Goal: SinglePassDiscovery generates a schema, LLMDirectExtraction uses it to extract records.

### Step 2.1 — `discovery/base.py` ✅

- DiscoveryStrategy Protocol + DiscoveryReport dataclass

### Step 2.2 — `discovery/single_pass.py` ✅

- SinglePassDiscovery with async-first design, JSON Schema parsing (handles markdown fences, nested wrappers), Pydantic model generation with fallback. 11 tests.

### Step 2.3 — `extraction/base.py` ✅

- ExtractionStrategy Protocol + ErrorMode Literal type

### Step 2.4 — `extraction/chunking.py` ✅

- chunk_document() with char offset tracking, overlap, metadata preservation. estimate_chunks() for cost estimation. 10 tests covering offsets, overlap, coverage, edge cases.

### Step 2.5 — `extraction/llm_direct.py` ✅

- LLMDirectExtraction with async concurrency (Semaphore), retry with validation feedback, on_error modes (raise/skip/collect), provenance tracking. 11 tests including retry, error modes, chunking.

**Checkpoint:** 80 tests passing, `mypy src/` clean (22 files, 0 issues), `ruff` clean.

---

## Phase 3: Normalization ✅

> Goal: EmbeddingClustering normalizes extracted values.

### Step 3.1 — `normalization/base.py` ✅

- NormalizationStrategy Protocol

### Step 3.2 — `normalization/embedding_cluster.py` ✅

- EmbeddingClustering with HDBSCAN + agglomerative, optional UMAP reduction, frequency-based canonical selection, explain() with cluster metadata. Lazy imports for sklearn/umap with helpful ImportError messages. 8 tests covering clustering, noise points, frequency selection, explain(), error modes.

**Checkpoint:** 88 tests passing, `mypy src/` clean (23 files, 0 issues), `ruff` clean.

---

## Phase 4: Pipeline & Demo ✅

> Goal: `Pipeline.quick()` runs end-to-end. Demo dataset works.

### Step 4.1 — `pipeline.py` ✅

- Pipeline with discovery→extraction→normalization flow, quick() classmethod, arun()/run(), estimate_cost(), budget tracking. Supports user-provided schemas (skip discovery). 9 unit tests.

### Step 4.2 — `demo/` ✅

- load_samples() with 3 bundled datasets (10 docs each): product_reviews, support_tickets, case_reports. Uses importlib.resources for package-safe loading. 6 unit tests.

### Step 4.3 — `__init__.py` exports ✅

- Version bumped to 0.1.0. Public API: Pipeline, Document, Schema, ExtractionResult, NormalizationResult, PipelineResult, RecordProvenance, UsageReport.

### Step 4.4 — Integration tests ✅

- Full end-to-end pipeline test with demo data (discover→extract→to_dataframe). User-provided schema test. Public API import test. 4 integration tests.

**Checkpoint:** 107 tests passing, `mypy src/` clean (23 files), `ruff` clean. Pipeline.quick() → run() works end-to-end. This is v0.1.

---

## Phase 5: Polish & Release v0.1 ✅

### Step 5.1 — Logging audit ✅

- 10/10 modules have `logger = logging.getLogger(__name__)`. Zero `print()` statements.

### Step 5.2 — Type checking ✅

- `mypy src/` strict — 23 files, 0 issues.

### Step 5.3 — Ruff clean ✅

- `ruff check` — all passed. `ruff format --check` — 41 files formatted.

### Step 5.4 — Documentation strings ✅

- All public classes and methods have docstrings. Pipeline.__init__ added.

### Step 5.5 — README.md ✅

- Quick Start with demo, Local Models (Ollama), Modular Usage, Async Support, Installation profiles, Features list, links to catchfly.dev.

### Step 5.6 — Build verified ✅

- `uv build` → `catchfly-0.1.0-py3-none-any.whl` (27 source files + 3 demo JSONs + py.typed + LICENSE). Ready for `git tag v0.1.0`.

---

## Phase 6: SchemaOptimizer (v0.3) ✅

> Goal: PARSE-style iterative schema enrichment. Enriched field descriptions serve as semantic anchors for downstream normalization (seed centroids for kLLMmeans in v0.5).

### Step 6.1 — `discovery/optimizer.py`

- `SchemaOptimizer(BaseModel)`:
  - Config: `model`, `num_iterations=5`, `base_url`, `api_key`
  - `aoptimize(schema, test_documents)` → `Schema` with enriched `field_metadata`:
    1. Take input schema (Pydantic model or JSON Schema)
    2. For each iteration:
       a. Run extraction on test_documents using current schema
       b. Analyze errors/gaps: which fields are empty? which have validation errors?
       c. Ask LLM to enrich field descriptions based on error analysis + sample values
       d. Update schema field_metadata with richer descriptions, examples, synonyms
    3. Return Schema with enriched field_metadata + lineage tracking iterations
  - `optimize()` — sync wrapper
  - Output field_metadata format per field: `{description, examples, synonyms, constraints}`
  - Key: field_metadata is what kLLMmeans (v0.5) will consume as seed centroids

**Tests:**
- `tests/unit/test_optimizer.py` — mock LLM returns enrichment suggestions, verify field_metadata populated, verify iteration count, verify schema lineage updated

---

## Phase 7: LLMCanonicalization (v0.3) ✅

> Goal: LLM-based normalization with map-reduce for large value sets.

### Step 7.1 — `normalization/llm_canonical.py`

- `LLMCanonicalization(BaseModel)`:
  - Config: `model`, `batch_size=50`, `max_values_per_prompt=200`, `base_url`, `api_key`
  - `anormalize(values, context_field)`:
    1. Deduplicate values
    2. If unique count ≤ max_values_per_prompt: single LLM call — ask to group synonyms and assign canonical names
    3. If unique count > max_values_per_prompt: map-reduce:
       a. **Map:** split into batches → LLM canonicalizes each batch independently
       b. **Reduce:** merge canonicals across batches. Use embedding similarity to detect cross-batch duplicates (e.g. batch 1 says "New York", batch 2 says "NYC" → same cluster)
    4. Return NormalizationResult with mapping + rationale in metadata
  - `normalize()` — sync wrapper
  - LLM prompt: output JSON `{"groups": [{"canonical": "...", "members": ["...", ...], "rationale": "..."}]}`

**Tests:**
- `tests/unit/test_llm_canonical.py` — mock LLM returns grouping JSON, verify mapping, verify map-reduce splits correctly for >200 values, verify cross-batch merge

---

## Phase 8: Telemetry Integration + Checkpoint (v0.3) ✅

> Goal: Pipeline tracks real LLM costs per stage. Long pipelines can resume after interruption.

### Step 8.1 — Wire UsageTracker into Pipeline

- Pipeline.arun() creates UsageTracker and passes it through stages
- Each LLM call in discovery/extraction/normalization records tokens + cost via tracker
- `results.report` reflects actual usage (not empty UsageReport)
- `max_cost_usd` halts pipeline mid-execution when budget exceeded

**Approach:** Add optional `tracker: UsageTracker` parameter to strategy methods, or have the LLMClient record usage automatically. Simplest: wrap LLMClient calls in pipeline to record after each response.

### Step 8.2 — Checkpoint/resume

- When `checkpoint_dir` is provided:
  - After discovery: save schema to `{checkpoint_dir}/schema.json`
  - During extraction: save completed records after each batch to `{checkpoint_dir}/records.jsonl`
  - Track processed document IDs in `{checkpoint_dir}/state.json`
- On resume: load existing state, skip already-processed documents
- Format: JSONL for records (append-safe), JSON for schema/state

**Tests:**
- `tests/unit/test_checkpoint.py` — verify state saved/loaded, verify resume skips processed docs
- `tests/integration/test_pipeline_checkpoint.py` — simulate interruption, verify resume produces same results

---

## Phase 9: Polish & Release v0.3 ✅

- Version bumped to 0.3.0
- SchemaOptimizer: PARSE-style iterative enrichment (12 tests)
- LLMCanonicalization: map-reduce for large value sets with cross-batch merge (13 tests)
- Checkpoint/resume: schema, records (JSONL), processed doc IDs (10 tests)
- 144 tests passing, mypy strict clean (25 files), ruff clean

**Checkpoint:** v0.3 complete.

---

## Phase 10: ThreeStageDiscovery (v0.5) ✅

> Goal: Multi-stage schema discovery inspired by SCHEMA-MINER — progressively refines schema through 3 stages with increasing sample size.

### Step 10.1 — `discovery/three_stage.py`

- `ThreeStageDiscovery(BaseModel)`:
  - Config: `model`, `stage1_samples=3`, `stage2_samples=10`, `stage3_samples=50`, `human_review=False`, `base_url`, `api_key`
  - `adiscover(documents, domain_hint)`:
    1. **Stage 1 — Initial:** Sample `stage1_samples` docs → LLM proposes initial schema (reuse SinglePassDiscovery logic)
    2. **Stage 2 — Refinement:** Sample `stage2_samples` docs → attempt extraction → LLM analyzes gaps/redundancies → proposes field additions/removals/type fixes. If `human_review=True`, return intermediate schema for user inspection.
    3. **Stage 3 — Expansion:** Sample `stage3_samples` docs → attempt extraction → compute field coverage stats → propose new recurring fields (>20% coverage) → flag rare fields (<5% coverage) for removal
  - Output: Schema + DiscoveryReport (field_coverage, confidence_scores, fields_added, fields_removed)
  - Key: each stage builds on previous — schema evolves progressively

**Tests:**
- `tests/unit/test_three_stage.py` — mock LLM returns progressively refined schemas, verify 3-stage pipeline, verify field_coverage calculation, verify human_review flag stops after stage 2

---

## Phase 11: KLLMeansClustering (v0.5) ✅

> Goal: k-means in embedding space with LLM-generated textual centroids. Novel contribution: schema-seeded initialization from SchemaOptimizer field_metadata.

### Step 11.1 — `normalization/kllmeans.py`

- `KLLMeansClustering(BaseModel)`:
  - Config: `num_clusters=None` (auto-detect), `embedding_model`, `summarization_model`, `num_iterations=10`, `summarize_every=3`, `seed_from_schema=False`, `base_url`, `api_key`
  - `anormalize(values, context_field, field_metadata=None)`:
    1. Embed all unique values
    2. **Initialize centroids:**
       - If `seed_from_schema=True` and `field_metadata` provided: embed field description → use as initial centroids
       - Else if `num_clusters` specified: k-means++ initialization
       - Else: auto-detect k via silhouette score over range [2, sqrt(n)]
    3. **Iterative refinement (k-LLMmeans loop):**
       - Standard k-means assignment step (assign values to nearest centroid)
       - Standard k-means update step (recompute centroid as mean of assigned embeddings)
       - Every `summarize_every` iterations: LLM summarizes each cluster's members → new textual centroid → embed summary → replace numeric centroid
    4. Final: LLM generates canonical names from cluster summaries
  - Output: NormalizationResult with mapping + cluster summaries as metadata

**Algorithm detail (from k-LLMmeans paper):**
- Between LLM summary steps, standard k-means updates preserve convergence guarantees
- LLM summaries provide human-readable centroids that guide clustering semantically
- Schema-seeded init = warm start that skips random initialization phase

**Tests:**
- `tests/unit/test_kllmeans.py` — mock embeddings + mock LLM summaries, verify clustering, verify schema-seeded init uses field_metadata, verify auto-k detection, verify summarize_every cadence, verify convergence (assignments stabilize)

---

## Phase 12: Schema Registry (v0.5) ✅

> Goal: Version and track schemas across pipeline runs.

### Step 12.1 — `schema/registry.py`

- `SchemaRegistry`:
  - `register(schema, name=None)` → assigns version ID, stores in registry
  - `get(name, version=None)` → retrieve schema by name (latest or specific version)
  - `list_schemas()` → all registered schemas with metadata
  - `diff(schema_a, schema_b)` → field-level diff (added, removed, changed)
  - Storage: in-memory dict + optional persist to JSON file
  - Tracks: name, version, timestamp, lineage, field_metadata

**Tests:**
- `tests/unit/test_registry.py` — register/get/list, versioning, diff, persistence

---

## Phase 13: Polish & Release v0.5 ✅

- Pipeline wired: field_metadata flows from schema → normalization (seed_from_schema for kLLMmeans)
- Version bumped to 0.5.0
- 185 tests passing, mypy strict clean (28 files), ruff clean
- Build: catchfly-0.5.0-py3-none-any.whl

**Checkpoint:** v0.5 complete. ThreeStageDiscovery (15 tests), KLLMeansClustering with schema-seeded warmstart (12 tests), SchemaRegistry with versioning/diff/persistence (14 tests).

---

## Phase 14: README + Documentation (v0.5)

> Goal: Update README with all v0.5 strategies. Set up mkdocs-material site at catchfly.dev.

### Step 14.1 — README.md update

- Add all strategies: ThreeStageDiscovery, SchemaOptimizer, LLMCanonicalization, KLLMeansClustering, SchemaRegistry
- Add architecture diagram (text)
- Add "Strategies at a Glance" table
- Add Schema Optimizer + kLLMmeans examples
- Keep Quick Start simple (Pipeline.quick)

### Step 14.2 — mkdocs setup

- `mkdocs.yml` — material theme, logo/favicon from docs/assets/, nav structure
- `docs/index.md` — landing (copy from README)
- `docs/getting-started/installation.md`
- `docs/getting-started/quickstart.md`
- `docs/guides/discovery.md` — SinglePass + ThreeStage + Optimizer
- `docs/guides/extraction.md` — LLMDirectExtraction
- `docs/guides/normalization.md` — Embedding + LLMCanonical + kLLMmeans
- `docs/guides/pipeline.md` — Pipeline, quick(), checkpoint, cost control
- `docs/api/` — auto-generated from docstrings via mkdocstrings

### Step 14.3 — Verify build

- `uv run mkdocs build` — no errors
- `uv run mkdocs serve` — preview locally

---

## Phase 15: Benchmark Framework (v0.5) ✅

> Goal: Publication-ready evidence that schema-seeded k-LLMmeans outperforms cold-start (PRD §13.3). 30 paired runs, Wilcoxon signed-rank test on NMI, on Bank77+CLINC.

### Step 15.1 — Configurable random seed in KLLMeansClustering ✅

- Added `random_seed: int = 42` field to `KLLMeansClustering` (after `seed_from_schema`, before `base_url`)
- Changed `_kmeans_pp_init` from `@staticmethod` to instance method with `seed` parameter
- Backward-compatible: default stays 42, all 185 existing tests pass unchanged
- New test: `test_different_seeds_different_init` verifies different seeds → different initializations

### Step 15.2 — Metrics module ✅

- `benchmarks/metrics/clustering.py` — `ClusteringMetrics` (NMI, ARI, V-measure, Purity), `compute_clustering_metrics()`, `labels_from_mapping()`, `compute_accuracy()` (Hungarian ACC)
- `benchmarks/metrics/statistical.py` — `PairedTestResult`, `wilcoxon_paired_test()`, `bonferroni_correction()`
- 12 tests: perfect/random clustering, known purity, Wilcoxon significance/non-significance, effect size, CI bounds

### Step 15.3 — Dataset loaders ✅

- `benchmarks/datasets/base.py` — `BenchmarkDataset` (frozen dataclass) with `subsample()` (stratified via sklearn)
- `benchmarks/datasets/bank77.py` — Banking77 via HuggingFace `datasets` (3,080 test, 77 classes)
- `benchmarks/datasets/clinc.py` — CLINC-OOS via HuggingFace (4,500 test, 150 classes)
- `benchmarks/datasets/goemo.py` — GoEmotions (27 emotion categories)
- `benchmarks/datasets/massive.py` — MASSIVE NLU (18 domains / 60 intents)
- All loaders: lazy import `datasets` with helpful ImportError

### Step 15.4 — Benchmark harness ✅

- `benchmarks/harness/config.py` — `BenchmarkConfig`, `ExperimentConfig` (Pydantic)
- `benchmarks/harness/runner.py` — `BenchmarkRunner.arun()` → single strategy+dataset+seed → `BenchmarkRunResult`
- `benchmarks/harness/experiment.py` — `SeededVsColdStartExperiment` → N paired runs + Wilcoxon
- 6 tests: runner valid metrics, metadata recording, config roundtrip, persistence roundtrip, seeded strategy, unsupported strategy error

### Step 15.5 — Results persistence & reporting ✅

- `benchmarks/results/persistence.py` — `ResultStore` (JSON, schema version 1.0, git commit hash)
- `benchmarks/results/reporting.py` — `BenchmarkReporter` → Markdown tables, LaTeX tables, per-seed CSV

### Step 15.6 — Mock conftest & key experiment test ✅

- `benchmarks/conftest.py` — `MockBenchmarkEmbedder` (class-separated vectors + Gaussian noise), `MockBenchmarkLLM`, `_make_synthetic_dataset()`, fixtures
- `benchmarks/test_seeded_vs_coldstart_mock.py` — `SeededAdvantageEmbedder` (tight-pair structure where k-means++ fails), 30 mock pairs → Wilcoxon → p < 0.05 ✅

### Step 15.7 — CLI script ✅

- `scripts/run_benchmark.py` — argparse with `experiment`, `single`, `report`, `estimate` subcommands
- `estimate` works offline using known dataset stats (no HuggingFace download needed)

### Step 15.8 — Config & CI ✅

- `pyproject.toml` — `benchmark` extra (`datasets>=2.14`, `tabulate>=0.9`), `testpaths = ["tests", "benchmarks"]`
- `.gitignore` — added `benchmark_results/`
- `.github/workflows/ci.yml` — added `benchmark` job running `pytest benchmarks/ -m "slow and not llm"`

**Checkpoint:** 206 tests passing (186 existing + 20 benchmark), `ruff check` clean, `mypy src/` clean.

---

## Phase 16: SICI Paper Experiments ✅

> Goal: Experiment framework for the SICI research paper (Schema-Informed Centroid Initialization for LLM-Augmented Text Clustering). All code in `benchmarks/sici/` — the catchfly library is NOT modified.

### Step 16.1 — Initialization strategies ✅

- `benchmarks/sici/strategies.py` — 8 strategies: `kmeans`, `kmeanspp`, `random`, `sici_holistic`, `sici_decomposed`, `sici_hybrid`, `oracle`, `oracle_kmeans`
- Key design: ALL strategies work through the existing `KLLMeansClustering` API by constructing appropriate `field_metadata` + `seed_from_schema` flag + `summarize_every` override
- `StrategyConfig` dataclass + `InitStrategy` protocol + `get_strategy()` registry

### Step 16.2 — SICI runner ✅

- `benchmarks/sici/runner.py` — `SICIRunner.arun(strategy, dataset, seed)` → `SICIRunResult`
- Universal runner accepting any `InitStrategy` — delegates to `KLLMeansClustering` with strategy-configured params

### Step 16.3 — Experiment orchestration ✅

- `benchmarks/sici/experiments.py`:
  - `run_experiment1()` — compare all strategies × datasets × 30 seeds, Wilcoxon per pair
  - `run_experiment2()` — vary schema quality, measure NMI impact
  - `estimate_costs()` — LLM call counts per strategy (Exp 5)
- `benchmarks/sici/convergence.py`:
  - `run_experiment3()` — NMI vs iteration convergence curves
  - Approach: run KLLMeans with `num_iterations=1,2,...,N`, record metrics at each step
- `benchmarks/sici/schema_quality.py`:
  - `generate_quality_levels()` — 9 levels: zero, minimal, manual_sparse, manual_moderate, manual_rich, optimizer_1/3/5iter (placeholders), oracle

### Step 16.4 — Paper template ✅

- `paper/sici_paper.md` — EMNLP-format blank paper: Abstract, Intro, Background, Method (3 SICI variants), Setup (5 datasets, 7 methods, 3 metrics), Results (Tables 1-3, Figures 1-2 with placeholders), Analysis, Related Work, Conclusion

**Checkpoint:** 206 tests passing, `ruff check` clean, `mypy src/` clean. Ready to run experiments.

---

## Phase 17: LLMCanonicalization Enhancements (v0.8) ✅

> Goal: Hierarchical merge for cross-batch consolidation + schema-aware prompting via field_metadata. Addresses main bottleneck from FIRST_RESULTS.md — map-reduce producing ~665 groups instead of ~42.

### Step 17.1 — Schema-aware prompting ✅

- `_format_schema_context()` — extracts description/examples/synonyms/constraints from `field_metadata`
- `_build_system_prompt()` / `_build_hierarchical_system_prompt()` — append schema context to prompts
- `field_metadata` threaded through `anormalize` → `_canonicalize_batch` → `_map_reduce`

### Step 17.2 — Hierarchical merge ✅

- Config fields: `hierarchical_merge: bool = True`, `hierarchical_merge_rounds: int = 1`
- `_HIERARCHICAL_MERGE_PROMPT` — dedicated prompt for consolidating canonical names
- `_build_hierarchical_user_prompt()` — formats canonical names with member counts
- `_hierarchical_merge()` — second LLM pass after string-merge, with batching + multi-round support
- `_apply_hierarchical_merge()` — maps merge instructions to original groups
- Wired into `_map_reduce` after existing `_merge_groups()`

### Step 17.3 — Tests ✅

- 18 new tests in 4 classes: `TestBuildSystemPrompt` (7), `TestSchemaAwareIntegration` (2), `TestApplyHierarchicalMerge` (4), `TestHierarchicalMerge` (5)
- Enhanced `MockCanonicalizationLLM` with call-indexed responses and captured messages
- `_patch_client` converted to `@contextmanager` (~55 lines boilerplate removed)

**Checkpoint:** 203 tests passing, `ruff check` clean.

---

## Phase 18: kLLMmeans SICI Cleanup (v0.8) ✅

> Goal: Remove schema-seeded initialization (SICI) — proven dead end per benchmarks. Keep KLLMeansClustering with k-means++ only.

### Step 18.1 — Remove SICI code ✅

- Removed: `seed_from_schema` field, `_schema_seeded_init()` method, `_init_centroids()` method
- Simplified `anormalize()`/`normalize()` signatures — removed `field_metadata` parameter
- Centroids initialized directly via `_kmeans_pp_init()`

### Step 18.2 — Update references ✅

- `kllmeans.py` docstrings — removed "Novel contribution: SICI", added "For semantic normalization, use LLMCanonicalization"
- `pipeline.py` — comment + docstring updated to reference LLMCanonicalization
- `optimizer.py` — docstring: "prompt context for LLMCanonicalization" instead of "seed centroids for KLLMeansClustering"

### Step 18.3 — Tests ✅

- Removed `test_schema_seeded_init` from `test_kllmeans.py`

**Checkpoint:** 202 tests passing, `ruff check` clean.

---

## Phase 19: OntologyMapping (v0.8) ✅

> Goal: P0 normalization strategy — map extracted values to standardized ontology terms (HPO, custom CSV/JSON). Critical for Silene Systems biomedical use case.

### Step 19.1 — Ontology types ✅

- `src/catchfly/ontology/types.py` — `OntologyEntry` (frozen dataclass: id, name, synonyms, all_texts property) + `OntologySource` protocol

### Step 19.2 — Ontology loaders ✅

- `src/catchfly/ontology/hpo.py` — `HPOSource` via pronto (OBO files), lazy import with helpful error
- `src/catchfly/ontology/csv_json.py` — `CSVSource` (semicolon-separated synonyms), `JSONSource`

### Step 19.3 — Ontology index ✅

- `src/catchfly/ontology/index.py` — `OntologyIndex`:
  - Expands entries to searchable texts (name + synonyms)
  - Embeds via `OpenAIEmbeddingClient` with batching
  - Batch cosine-similarity search via matrix multiplication + `np.argpartition`
  - Deduplication by entry ID (same term matched via name and synonym)
  - Disk cache with model name + size validation

### Step 19.4 — OntologyMapping strategy ✅

- `src/catchfly/normalization/ontology_mapping.py` — `OntologyMapping(BaseModel)`:
  - Config: `ontology`, `embedding_model`, `reranking_model` (None to skip), `top_k`, `confidence_threshold`, `reranking_concurrency`
  - Flow: resolve source → load entries → build index → embed queries → NN search → optional LLM reranking → build result
  - `_resolve_source()` — "hpo" / .obo / .csv / .json
  - `_rerank_batch()` — `asyncio.Semaphore` bounded concurrency, per-value LLM calls
  - `_parse_rerank_response()` — JSON parser with fence stripping, fallback to top-1
  - Output: `mapping[value] = canonical_name`, `metadata["per_value"][value]` has `ontology_id` + `confidence`

### Step 19.5 — pyproject.toml ✅

- `medical` extra: added `numpy>=1.24` alongside `pronto>=2.5`

### Step 19.6 — Tests ✅

- `tests/unit/test_ontology_types.py` (8) — entry frozen, all_texts, CSV/JSON loaders
- `tests/unit/test_ontology_index.py` (7) — build, search, dedup, empty, cache roundtrip, cache invalidation
- `tests/unit/test_ontology_mapping.py` (17) — empty values, exact/synonym match, reranking, reranking override, explain, source resolution, parse response, sync wrapper

**Checkpoint:** 234 tests passing, `ruff check` clean. Version bumped to 0.8.0.

---

## Phase 20: Documentation Update (v0.8) ✅

> Goal: Update all docs to reflect v0.8 changes — OntologyMapping, hierarchical merge, schema-aware prompting, SICI removal.

### Step 20.1 — Normalization guide ✅

- `docs/guides/normalization.md` — rewritten: OntologyMapping as lead strategy with full HPO example, LLMCanonicalization with hierarchical merge + schema-aware prompting, kLLMmeans demoted to surface-form, updated comparison table

### Step 20.2 — API reference ✅

- `docs/api/normalization.md` — added OntologyMapping
- `docs/api/ontology.md` — new page: OntologyEntry, OntologyIndex, HPOSource, CSVSource, JSONSource

### Step 20.3 — Navigation & other pages ✅

- `mkdocs.yml` — added Ontology to nav
- `docs/index.md` — OntologyMapping in strategy table
- `docs/getting-started/installation.md` — medical extra updated
- `docs/guides/pipeline.md` — Custom Pipeline example uses LLMCanonicalization (removed seed_from_schema)
- `docs/getting-started/quickstart.md` — next steps mention OntologyMapping

### Step 20.4 — PRD updated ✅

- `catchfly_prd.md` — v0.8 milestone marked ✅ with actual deliverables

---

## Execution Rules

1. **Every step ends with green tests.** Never move to the next step with failing tests.
2. **Every step ends with `uv run ruff check . && uv run mypy src/`** clean.
3. **Commit after each step.** Small, atomic commits. One step = one commit.
4. **Async-first.** Write the `async` method first, then add sync wrapper. Never the reverse.
5. **Lazy imports.** `sklearn`, `umap`, `pandas`, `numpy` — import inside the function that uses them. Guard with try/except ImportError and helpful message.
6. **No `print()`.** Use `logging` everywhere.
7. **No hardcoded API keys.** Environment variables or explicit parameters.
8. **Test with mocks by default.** Real API tests tagged `@pytest.mark.llm`.
