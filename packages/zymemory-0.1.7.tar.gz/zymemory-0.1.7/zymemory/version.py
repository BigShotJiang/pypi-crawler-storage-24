"""Version information for zymemory."""

__version__ = "0.1.7"
