"""
Zymemory Python SDK

A Python client library for the Zymemory API - a long-term memory system
for AI applications.

Example usage:
    >>> from zymemory import ZymemoryClient
    >>> client = ZymemoryClient(
    ...     api_key="your-org-key",
    ...     org_email="org@example.com",
    ...     user_token="user-token"
    ... )
    >>> results = client.search("coffee preferences")
    >>> for memory in results.memories:
    ...     print(memory.content)
"""

from .client import ZymemoryClient
from .models import (
    Memory,
    SearchResult,
    MemoryList,
    MemoryLink,
    User,
    Representation,
    RepresentationVersion,
    RepresentationVersions,
    Tenant,
    MemoryAccess
)
from .exceptions import (
    ZymemoryError,
    AuthenticationError,
    APIError,
    ValidationError,
    NetworkError,
    RateLimitError
)
from .version import __version__

__all__ = [
    "ZymemoryClient",
    "Memory",
    "SearchResult",
    "MemoryList",
    "MemoryLink",
    "User",
    "Representation",
    "RepresentationVersion",
    "RepresentationVersions",
    "Tenant",
    "MemoryAccess",
    "ZymemoryError",
    "AuthenticationError",
    "APIError",
    "ValidationError",
    "NetworkError",
    "RateLimitError",
    "__version__",
]
