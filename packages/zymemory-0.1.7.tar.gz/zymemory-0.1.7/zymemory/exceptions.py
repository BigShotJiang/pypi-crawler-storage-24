"""Custom exceptions for zymemory SDK."""


class ZymemoryError(Exception):
    """Base exception for all zymemory errors."""
    pass


class AuthenticationError(ZymemoryError):
    """Raised when authentication fails."""
    pass


class APIError(ZymemoryError):
    """Raised when API returns an error response."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ValidationError(ZymemoryError):
    """Raised when request validation fails."""
    pass


class NetworkError(ZymemoryError):
    """Raised when network request fails."""
    pass


class RateLimitError(ZymemoryError):
    """Raised when rate limit is exceeded."""
    pass
