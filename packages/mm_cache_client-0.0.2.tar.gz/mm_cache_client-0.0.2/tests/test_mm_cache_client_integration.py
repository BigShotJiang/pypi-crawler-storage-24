from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Awaitable, Callable
from typing import TypeVar
from uuid import uuid4

import aiohttp
import pytest

from mm_cache_client import CacheHit, MMCacheClient, MMCacheConfig


DEFAULT_BASE_URL = "http://127.0.0.1:8080"
DEFAULT_HEALTH_PATH = "/health"
HEALTH_TIMEOUT_S = 2.0
REQUEST_TIMEOUT_S = 0.75
EVENTUAL_TIMEOUT_S = 1.25
POLL_INTERVAL_S = 0.02

T = TypeVar("T")


async def _await_with_deadline(
    awaitable: Awaitable[T],
    *,
    description: str,
    timeout_s: float = REQUEST_TIMEOUT_S,
) -> T:
    try:
        return await asyncio.wait_for(awaitable, timeout=timeout_s)
    except TimeoutError:
        pytest.fail(f"timed out after {timeout_s:.2f}s waiting for {description}")


def _default_headers() -> dict[str, str]:
    api_key = os.environ.get("MM_CACHE_API_KEY") or os.environ.get("BASETEN_API_KEY")
    if not api_key:
        return {}
    return {"Authorization": f"Api-Key {api_key}"}


async def _wait_for_mm_cache(
    base_url: str,
    *,
    headers: dict[str, str],
    health_path: str | None,
    timeout_s: float = HEALTH_TIMEOUT_S,
) -> None:
    if not health_path:
        return

    deadline = time.monotonic() + timeout_s
    last_error: str | None = None
    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT_S)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        while time.monotonic() < deadline:
            try:
                async with session.get(
                    f"{base_url.rstrip('/')}/{health_path.lstrip('/')}",
                    headers=headers,
                ) as response:
                    if response.status == 200:
                        return
                    last_error = (
                        f"{health_path} returned {response.status}: {await response.text()}"
                    )
            except aiohttp.ClientError as exc:
                last_error = str(exc)
            await asyncio.sleep(POLL_INTERVAL_S)

    pytest.fail(
        f"mm-cache is not reachable at {base_url}. "
        f"Start the server before running this integration test. Last error: {last_error}"
    )


async def _eventually_get_hit(
    fetch_hit: Callable[[], Awaitable[CacheHit | None]],
    *,
    description: str,
    timeout_s: float = EVENTUAL_TIMEOUT_S,
) -> CacheHit:
    deadline = time.monotonic() + timeout_s

    while time.monotonic() < deadline:
        hit = await _await_with_deadline(fetch_hit(), description=description)
        if hit is not None:
            return hit
        await asyncio.sleep(POLL_INTERVAL_S)

    pytest.fail(f"timed out after {timeout_s:.2f}s waiting for {description}")


async def _run_mm_cache_round_trip_against_live_server() -> None:
    base_url = os.environ.get("MM_CACHE_BASE_URL", DEFAULT_BASE_URL)
    headers = _default_headers()
    health_path = os.environ.get("MM_CACHE_HEALTH_PATH", DEFAULT_HEALTH_PATH)
    await _wait_for_mm_cache(base_url, headers=headers, health_path=health_path)

    run_id = uuid4().hex
    model = f"pytest-mm-cache-client-{run_id}"
    other_model = f"{model}-isolated"
    content_type = "image_url"
    url_a = f"https://example.invalid/{run_id}/a.png"
    url_b = f"https://example.invalid/{run_id}/b.png"
    alias_a = MMCacheClient.alias_sha(model=model, content_type=content_type, url=url_a)
    alias_b = MMCacheClient.alias_sha(model=model, content_type=content_type, url=url_b)
    mm_hash_a = f"mm-hash-a-{run_id}"
    mm_hash_b = f"mm-hash-b-{run_id}"
    missing_hash = f"missing-{run_id}"
    payload_a_v1 = f'{{"run":"{run_id}","slot":"a","version":1}}'.encode("utf-8")
    payload_a_v2 = f'{{"run":"{run_id}","slot":"a","version":2}}'.encode("utf-8")
    payload_b = f'{{"run":"{run_id}","slot":"b","version":1}}'.encode("utf-8")

    async with MMCacheClient(
        MMCacheConfig(
            base_url=base_url,
            timeout_s=REQUEST_TIMEOUT_S,
        ),
        default_headers=headers,
    ) as client:
        initial_results = await asyncio.gather(
            _await_with_deadline(
                client.resolve(model=model, content_type=content_type, url=url_a),
                description="initial resolve miss for alias A",
            ),
            _await_with_deadline(
                client.resolve_sha(model=model, sha=alias_b),
                description="initial resolve_sha miss for alias B",
            ),
            _await_with_deadline(
                client.get_payload(model=model, mm_hash=missing_hash),
                description="initial payload miss",
            ),
        )
        assert initial_results == [None, None, None]

        await _await_with_deadline(
            client.put_payload(model=model, mm_hash=mm_hash_b, mm_kwargs=payload_b),
            description="put_payload for hash B without alias",
        )

        payload_only_hit = await _eventually_get_hit(
            lambda: client.get_payload(model=model, mm_hash=mm_hash_b),
            description="payload-only hit for hash B",
        )
        assert payload_only_hit.mm_hash == mm_hash_b
        assert payload_only_hit.mm_kwargs == payload_b
        assert (
            await _await_with_deadline(
                client.resolve_sha(model=model, sha=alias_b),
                description="resolve_sha remains a miss before alias write",
            )
            is None
        )

        await _await_with_deadline(
            client.put_sha(
                model=model,
                sha=alias_b,
                mm_hash=mm_hash_b,
                mm_kwargs=payload_b,
            ),
            description="put_sha for alias B",
        )

        resolve_b_hit, resolve_b_sha_hit = await asyncio.gather(
            _eventually_get_hit(
                lambda: client.resolve(model=model, content_type=content_type, url=url_b),
                description="resolve hit for alias B after put_sha",
            ),
            _eventually_get_hit(
                lambda: client.resolve_sha(model=model, sha=alias_b),
                description="resolve_sha hit for alias B after put_sha",
            ),
        )
        assert resolve_b_hit.mm_hash == mm_hash_b
        assert resolve_b_hit.mm_kwargs == payload_b
        assert resolve_b_sha_hit.mm_hash == mm_hash_b
        assert resolve_b_sha_hit.mm_kwargs == payload_b

        await _await_with_deadline(
            client.put_resolve(
                model=model,
                content_type=content_type,
                url=url_a,
                mm_hash=mm_hash_a,
                mm_kwargs=payload_a_v1,
            ),
            description="put_resolve for alias A",
        )

        resolve_a_hit, resolve_a_sha_hit, payload_a_hit = await asyncio.gather(
            _eventually_get_hit(
                lambda: client.resolve(model=model, content_type=content_type, url=url_a),
                description="resolve hit for alias A after put_resolve",
            ),
            _eventually_get_hit(
                lambda: client.resolve_sha(model=model, sha=alias_a),
                description="resolve_sha hit for alias A after put_resolve",
            ),
            _eventually_get_hit(
                lambda: client.get_payload(model=model, mm_hash=mm_hash_a),
                description="payload hit for hash A after put_resolve",
            ),
        )
        assert resolve_a_hit.mm_hash == mm_hash_a
        assert resolve_a_hit.mm_kwargs == payload_a_v1
        assert resolve_a_sha_hit.mm_hash == mm_hash_a
        assert resolve_a_sha_hit.mm_kwargs == payload_a_v1
        assert payload_a_hit.mm_hash == mm_hash_a
        assert payload_a_hit.mm_kwargs == payload_a_v1

        await _await_with_deadline(
            client.put_payload(model=model, mm_hash=mm_hash_a, mm_kwargs=payload_a_v2),
            description="put_payload overwrite for hash A",
        )

        updated_payload_a_hit, updated_resolve_a_hit = await asyncio.gather(
            _eventually_get_hit(
                lambda: client.get_payload(model=model, mm_hash=mm_hash_a),
                description="updated payload hit for hash A",
            ),
            _eventually_get_hit(
                lambda: client.resolve_alias(model=model, alias=alias_a),
                description="updated resolve hit for alias A",
            ),
        )
        assert updated_payload_a_hit.mm_hash == mm_hash_a
        assert updated_payload_a_hit.mm_kwargs == payload_a_v2
        assert updated_resolve_a_hit.mm_hash == mm_hash_a
        assert updated_resolve_a_hit.mm_kwargs == payload_a_v2

        isolated_results = await asyncio.gather(
            _await_with_deadline(
                client.resolve_sha(model=other_model, sha=alias_a),
                description="cross-model resolve_sha miss for alias A",
            ),
            _await_with_deadline(
                client.get_payload(model=other_model, mm_hash=mm_hash_a),
                description="cross-model payload miss for hash A",
            ),
        )
        assert isolated_results == [None, None]


def test_mm_cache_round_trip_against_live_server() -> None:
    asyncio.run(_run_mm_cache_round_trip_against_live_server())
