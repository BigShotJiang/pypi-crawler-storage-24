from __future__ import annotations

import hashlib

BASETEN_MM_HASH_HEADER = "x-baseten-customer-mm-hash"


def alias_sha(model: str, content_type: str, url: str) -> str:
    material = f"{model}:{content_type}:url:{url}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()
