from __future__ import annotations

from dataclasses import dataclass

import aiohttp

from .protocol import BASETEN_MM_HASH_HEADER, alias_sha


@dataclass(slots=True)
class MMCacheConfig:
    base_url: str
    timeout_s: float = 10.0


@dataclass(slots=True)
class CacheHit:
    mm_hash: str
    mm_kwargs: bytes


class MMCacheClient:
    def __init__(
        self,
        config: MMCacheConfig,
        session: aiohttp.ClientSession | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        self._config = config
        self._session = session
        self._owns_session = False
        self._default_headers = dict(default_headers or {})

        if self._session is None:
            timeout = aiohttp.ClientTimeout(total=self._config.timeout_s)
            self._session = aiohttp.ClientSession(timeout=timeout)
            self._owns_session = True

    async def __aenter__(self) -> MMCacheClient:
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    @staticmethod
    def alias_sha(*, model: str, content_type: str, url: str) -> str:
        return alias_sha(model, content_type, url)

    async def resolve(
        self,
        *,
        model: str,
        content_type: str,
        url: str,
    ) -> CacheHit | None:
        return await self.resolve_alias(
            model=model,
            alias=alias_sha(model, content_type, url),
        )

    async def resolve_sha(self, *, model: str, sha: str) -> CacheHit | None:
        return await self.resolve_alias(model=model, alias=sha)

    async def resolve_alias(
        self,
        *,
        model: str,
        alias: str,
    ) -> CacheHit | None:
        response = await self._request(
            "GET",
            f"/v1/resolve/{alias}",
            params={"model": model},
        )
        if response.status == 404:
            await response.release()
            return None
        if response.status != 200:
            body = await response.text()
            raise RuntimeError(f"mm-cache resolve failed ({response.status}): {body}")
        mm_kwargs = await response.read()
        mm_hash = response.headers.get(BASETEN_MM_HASH_HEADER)
        if not mm_hash:
            raise RuntimeError(
                "mm-cache resolve response missing x-baseten-customer-mm-hash header"
            )
        return CacheHit(mm_hash=mm_hash, mm_kwargs=mm_kwargs)

    async def get_payload(self, *, model: str, mm_hash: str) -> CacheHit | None:
        response = await self._request(
            "GET",
            f"/v1/payload/{mm_hash}",
            params={"model": model},
        )
        if response.status == 404:
            await response.release()
            return None
        if response.status != 200:
            body = await response.text()
            raise RuntimeError(
                f"mm-cache payload lookup failed ({response.status}): {body}"
            )
        mm_kwargs = await response.read()
        header_hash = response.headers.get(BASETEN_MM_HASH_HEADER) or mm_hash
        return CacheHit(mm_hash=header_hash, mm_kwargs=mm_kwargs)

    async def put_resolve(
        self,
        *,
        model: str,
        content_type: str,
        url: str,
        mm_hash: str,
        mm_kwargs: bytes,
    ) -> None:
        await self.put_resolve_alias(
            model=model,
            alias=alias_sha(model, content_type, url),
            mm_hash=mm_hash,
            mm_kwargs=mm_kwargs,
        )

    async def put_sha(
        self,
        *,
        model: str,
        sha: str,
        mm_hash: str,
        mm_kwargs: bytes,
    ) -> None:
        await self.put_resolve_alias(
            model=model,
            alias=sha,
            mm_hash=mm_hash,
            mm_kwargs=mm_kwargs,
        )

    async def put_resolve_alias(
        self,
        *,
        model: str,
        alias: str,
        mm_hash: str,
        mm_kwargs: bytes,
    ) -> None:
        response = await self._request(
            "PUT",
            f"/v1/resolve/{alias}",
            params={"model": model},
            data=mm_kwargs,
            headers={BASETEN_MM_HASH_HEADER: mm_hash},
        )
        await self._expect_no_content(response, "put resolve")

    async def put_payload(self, *, model: str, mm_hash: str, mm_kwargs: bytes) -> None:
        response = await self._request(
            "PUT",
            f"/v1/payload/{mm_hash}",
            params={"model": model},
            data=mm_kwargs,
        )
        await self._expect_no_content(response, "put payload")

    async def _expect_no_content(
        self, response: aiohttp.ClientResponse, operation: str
    ) -> None:
        if 200 <= response.status < 300:
            await response.release()
            return
        body = await response.text()
        raise RuntimeError(f"mm-cache {operation} failed ({response.status}): {body}")

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str],
        data: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> aiohttp.ClientResponse:
        if self._session is None:
            raise RuntimeError("mm-cache client session is closed")
        return await self._session.request(
            method,
            f"{self._config.base_url.rstrip('/')}{path}",
            params=params,
            data=data,
            headers=self._merge_headers(headers),
        )

    def _merge_headers(self, headers: dict[str, str] | None) -> dict[str, str] | None:
        if not self._default_headers:
            return headers
        if not headers:
            return dict(self._default_headers)
        return {**self._default_headers, **headers}
