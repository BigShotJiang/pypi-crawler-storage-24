"""Allow running as: python -m osmp_mcp"""
from osmp_mcp.server import main
main()
