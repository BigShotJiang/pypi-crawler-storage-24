"""OSMP MCP Server -- Octid Semantic Mesh Protocol for MCP clients."""
__version__ = "1.0.5"
