"""
Data utilities for NextRec.

This module provides file I/O helpers and synthetic data generation.

Date: create on 19/12/2025
Checkpoint: edit on 13/03/2026
Author: Yang Zhou, zyaztec@gmail.com
"""

from __future__ import annotations

from pathlib import Path
import time
from typing import Any, Dict, Generator, List, Optional, Tuple

import numpy as np
import pandas as pd
import polars as pl
import pyarrow.parquet as pq
import torch
import yaml

from nextrec.utils.timing import StageTimer


def get_expand_columns(config: dict[str, Any] | None) -> dict[str, list[Any]]:
    """
    Validate and normalize prediction-time row expansion config.
    """
    if config is None:
        return {}

    normalized = {}
    for raw_name, raw_values in config.items():
        name = str(raw_name).strip()
        if isinstance(raw_values, (str, bytes)) or not isinstance(raw_values, (list, tuple)):
            raise TypeError(f"[Predict Config Error] predict.expand.{name} must be a list of candidate values.")
        values = list(raw_values)
        normalized[name] = values
    return normalized


def get_expand_factor(expand: dict[str, list[Any]] | None) -> int:
    factor = 1
    for values in (expand or {}).values():
        factor *= max(len(values), 1)
    return factor


def expand_tabular_rows(
    data: dict[str, Any] | pd.DataFrame | pl.DataFrame,
    expand: dict[str, list[Any]] | None,
) -> dict[str, Any] | pd.DataFrame | pl.DataFrame:
    """
    Expand each row into the cartesian product defined by `expand`.
    """
    if not expand:
        return data

    factor = get_expand_factor(expand)
    if factor <= 1:
        return data

    if isinstance(data, pd.DataFrame):
        row_indices = np.repeat(np.arange(len(data), dtype=np.int64), factor)
        expanded_df = data.iloc[row_indices].reset_index(drop=True)
        prefix = 1
        for column, values in expand.items():
            suffix = factor // (prefix * len(values))
            pattern = np.tile(np.repeat(np.asarray(values, dtype=object), suffix), prefix)
            expanded_df[column] = np.tile(pattern, len(data))
            prefix *= len(values)
        return expanded_df

    if isinstance(data, pl.DataFrame):
        expanded_df = data
        for column, values in expand.items():
            if column in expanded_df.columns:
                expanded_df = expanded_df.drop(column)
            expanded_df = expanded_df.join(pl.DataFrame({column: values}), how="cross")
        return expanded_df

    if isinstance(data, dict):
        lengths_seen = {len(v) for v in data.values()}
        n_rows = lengths_seen.pop()
        expanded = {}
        for key, values in data.items():
            arr = np.asarray(values, dtype=object)
            expanded[key] = np.repeat(arr, factor, axis=0)
        prefix = 1
        for column, values in expand.items():
            suffix = factor // (prefix * len(values))
            pattern = np.tile(np.repeat(np.asarray(values, dtype=object), suffix), prefix)
            expanded[column] = np.tile(pattern, n_rows)
            prefix *= len(values)
        return expanded

    raise TypeError(f"[Predict Expand Error] Unsupported tabular type: {type(data)}")


def resolve_file_paths(path: str) -> tuple[list[str], str]:
    """
    Resolve file or directory path into a sorted list of files and file type.

    Args: path: Path to a file or directory
    Returns: tuple: (list of file paths, file type)
    """
    path_obj = Path(path)

    if path_obj.is_file():
        name = path_obj.name
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
        if ext in {"csv", "txt"}:
            file_format = "csv"
        elif ext == "parquet":
            file_format = "parquet"
        else:
            file_format = None
        if file_format is None:
            raise ValueError(f"Unsupported file extension: {path_obj.suffix}. Supported formats: csv, parquet.")
        return [str(path_obj)], file_format

    if path_obj.is_dir():
        collected_files = [p for p in path_obj.iterdir() if p.is_file()]

        format_groups = {}
        for file in collected_files:
            name = file.name
            ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
            if ext in {"csv", "txt"}:
                file_format = "csv"
            elif ext == "parquet":
                file_format = "parquet"
            else:
                file_format = None
            if file_format:
                format_groups.setdefault(file_format, []).append(str(file))

        if len(format_groups) > 1:
            formats = ", ".join(format_groups.keys())
            raise ValueError(
                f"Directory contains mixed file formats: {formats}. Please keep a single format per directory."
            )

        if not format_groups:
            raise ValueError(f"No supported data files found in directory: {path}. Supported formats: csv, parquet.")

        file_type = list(format_groups.keys())[0]
        file_paths = format_groups[file_type]
        file_paths.sort()
        return file_paths, file_type

    raise ValueError(f"Invalid path: {path}")


def read_table(path: str | Path, data_format: str | None = None) -> pd.DataFrame:
    data_path = Path(path)

    if data_format:
        fmt = data_format
    elif data_path.is_dir():
        _, fmt = resolve_file_paths(str(data_path))
    else:
        raise ValueError(f"Cannot determine format for {data_path}. Please specify data_format parameter.")

    if data_path.is_dir():
        file_paths, _ = resolve_file_paths(str(data_path))
        dataframes = [read_table(fp, fmt) for fp in file_paths]
        if not dataframes:
            raise ValueError(f"No supported data files found in directory: {data_path}")
        if len(dataframes) == 1:
            return dataframes[0]
        return pd.concat(dataframes, ignore_index=True)

    if fmt == "parquet":
        return pd.read_parquet(data_path)
    if fmt == "csv":
        return pd.read_csv(data_path, low_memory=False)
    raise ValueError(f"Unsupported format: {fmt}.")


def iter_file_chunks(
    file_path: str,
    file_type: str,
    chunk_size: int,
    shard_rank: int = 0,
    shard_count: int = 1,
    profiler: "StageTimer | None" = None,
) -> Generator[pl.DataFrame, None, None]:
    """Iterate over file in chunks for streaming reading.

    Args:
        file_path: Path to the file
        file_type: Format type (csv, parquet)
        chunk_size: Number of rows per chunk
        shard_rank: Shard index for parquet row-group sharding
        shard_count: Number of shards for parquet row-group sharding
        profiler: Optional StageTimer for timing data read
    """
    file_type = file_type.lower()
    if file_type == "csv":
        lazy_frame = pl.scan_csv(file_path)
        batch_iter = iter(lazy_frame.collect_batches(chunk_size=chunk_size))
        while True:
            start = time.perf_counter()
            try:
                batch = next(batch_iter)
            except StopIteration:
                break
            if profiler is not None:
                profiler.add("data_read", time.perf_counter() - start)
            yield batch
    elif file_type == "parquet":
        parquet_file = pq.ParquetFile(file_path)
        use_shards = max(int(shard_count), 1) > 1
        if use_shards:
            shard_rank = int(shard_rank) % int(shard_count)
            row_groups = [idx for idx in range(parquet_file.num_row_groups) if (idx % int(shard_count)) == shard_rank]
            if not row_groups:
                return
        else:
            row_groups = None
        batch_iter = iter(parquet_file.iter_batches(batch_size=chunk_size, row_groups=row_groups))
        while True:
            start = time.perf_counter()
            try:
                batch = next(batch_iter)
            except StopIteration:
                break
            if profiler is not None:
                profiler.add("data_read", time.perf_counter() - start)
            yield pl.from_arrow(batch)
    else:
        raise ValueError(f"Unsupported streaming format: {file_type}. Supported formats for streaming: csv, parquet.")


def count_rows(
    path: str | Path,
    data_format: str | None = None,
) -> int | None:
    file_paths, file_type = resolve_file_paths(str(path))
    requested_format = str(data_format).lower() if data_format else "auto"
    if requested_format in {"auto", file_type}:
        format = file_type
    else:
        format = file_type

    if format == "parquet":
        total = 0
        for file_path in file_paths:
            parquet_file = pq.ParquetFile(file_path)
            metadata = parquet_file.metadata
            if metadata is None:
                return None
            total += int(metadata.num_rows)
        return total

    if format == "csv":
        total = 0
        for file_path in file_paths:
            df = pl.scan_csv(file_path).select(pl.len()).collect()
            total += int(df.item(0, 0))
        return total

    return None


def read_yaml(path: str | Path):
    with open(path, "r", encoding="utf-8") as file:
        return yaml.safe_load(file) or {}


def generate_ranking_data(
    n_samples: int = 10000,
    n_dense: int = 5,
    n_sparse: int = 8,
    n_sequences: int = 2,
    user_vocab_size: int = 1000,
    item_vocab_size: int = 500,
    sparse_vocab_size: int = 50,
    sequence_max_len: int = 20,
    embedding_dim: int = 16,
    seed: int = 42,
    custom_sparse_features: Optional[Dict[str, int]] = None,
) -> Tuple[pd.DataFrame, List, List, List]:
    """
    Generate synthetic data for ranking tasks (CTR prediction)

    Returns:
        tuple: (dataframe, dense_features, sparse_features, sequence_features)
    """
    print(f"Generating {n_samples} synthetic ranking samples...")

    np.random.seed(seed)
    data = {}

    for i in range(n_dense):
        data[f"dense_{i}"] = np.random.randn(n_samples).astype(np.float32)

    # Generate basic sparse features (always include user_id and item_id)
    data["user_id"] = np.random.randint(1, user_vocab_size, n_samples)
    data["item_id"] = np.random.randint(1, item_vocab_size, n_samples)

    # Generate additional sparse features
    if custom_sparse_features:
        for feat_name, vocab_size in custom_sparse_features.items():
            data[feat_name] = np.random.randint(0, vocab_size, n_samples)
    else:
        for i in range(n_sparse - 2):
            data[f"sparse_{i}"] = np.random.randint(1, sparse_vocab_size, n_samples)

    # Generate sequence features (list of IDs)
    sequence_names = []
    sequence_vocabs = []

    for i in range(n_sequences):
        sequences = []
        for _ in range(n_samples):
            seq_len = np.random.randint(5, sequence_max_len + 1)
            if i == 0:
                # First sequence uses item vocabulary
                seq = np.random.randint(0, item_vocab_size, seq_len).tolist()
                seq_vocab = item_vocab_size
                if custom_sparse_features:
                    seq_name = "hist_items"
                else:
                    seq_name = "sequence_0"
            else:
                # Other sequences use category vocabulary
                if custom_sparse_features and "category" in custom_sparse_features:
                    seq_vocab = custom_sparse_features["category"]
                    seq = np.random.randint(0, seq_vocab, seq_len).tolist()
                    seq_name = "hist_categories" if i == 1 else f"sequence_{i}"
                else:
                    seq_vocab = sparse_vocab_size
                    seq = np.random.randint(0, seq_vocab, seq_len).tolist()
                    seq_name = f"sequence_{i}"

            # Padding
            seq = seq + [0] * (sequence_max_len - len(seq))
            sequences.append(seq)

        data[seq_name] = sequences
        sequence_names.append(seq_name)
        sequence_vocabs.append(seq_vocab)

    if "gender" in data and "dense_0" in data:
        dense_1 = data.get("dense_1", 0)
        # Complex label generation with feature correlation
        label_probs = 1 / (
            1
            + np.exp(
                -(
                    data["dense_0"] * 0.3
                    + dense_1 * 0.2
                    + (data["gender"] - 0.5) * 0.5
                    + np.random.randn(n_samples) * 0.1
                )
            )
        )
        data["label"] = (label_probs > 0.5).astype(np.float32)
    else:
        data["label"] = np.random.randint(0, 2, n_samples).astype(np.float32)

    df = pd.DataFrame(data)
    print(f"Generated data shape: {df.shape}")
    if "gender" in data:
        print(f"Positive rate: {data['label'].mean():.4f}")

    # Import here to avoid circular import
    from nextrec.basic.features import DenseFeature, SequenceFeature, SparseFeature

    # Create feature definitions
    # Use input_dim for dense features to be compatible with both simple and complex scenarios
    dense_features = [DenseFeature(name=f"dense_{i}", input_dim=1) for i in range(n_dense)]

    # Create sparse features
    sparse_features = [
        SparseFeature(
            name="user_id",
            embedding_name="user_emb",
            vocab_size=user_vocab_size,
            embedding_dim=embedding_dim,
        ),
        SparseFeature(
            name="item_id",
            embedding_name="item_emb",
            vocab_size=item_vocab_size,
            embedding_dim=embedding_dim,
        ),
    ]

    if custom_sparse_features:
        # Add custom sparse features with proper vocab sizes
        for feat_name, vocab_size in custom_sparse_features.items():
            sparse_features.append(
                SparseFeature(
                    name=feat_name,
                    embedding_name=f"{feat_name}_emb",
                    vocab_size=vocab_size,
                    embedding_dim=embedding_dim,
                )
            )
    else:
        # Add generic sparse features
        sparse_features.extend(
            [
                SparseFeature(
                    name=f"sparse_{i}",
                    embedding_name=f"sparse_{i}_emb",
                    vocab_size=sparse_vocab_size,
                    embedding_dim=embedding_dim,
                )
                for i in range(n_sparse - 2)
            ]
        )

    # Create sequence features
    sequence_features = []
    for i, (seq_name, seq_vocab) in enumerate(zip(sequence_names, sequence_vocabs)):
        if i == 0:
            # First sequence shares embedding with item_id
            embedding_name = "item_emb"
        elif custom_sparse_features and "category" in custom_sparse_features and seq_name == "hist_categories":
            # hist_categories shares embedding with category
            embedding_name = "category_emb"
        else:
            # Other sequences share with sparse_0
            embedding_name = "sparse_0_emb"
        sequence_features.append(
            SequenceFeature(
                name=seq_name,
                vocab_size=seq_vocab,
                max_len=sequence_max_len,
                embedding_dim=embedding_dim,
                padding_idx=0,
                embedding_name=embedding_name,
            )
        )
    return df, dense_features, sparse_features, sequence_features


def generate_match_data(
    n_samples: int = 10000,
    user_vocab_size: int = 1000,
    item_vocab_size: int = 5000,
    category_vocab_size: int = 100,
    brand_vocab_size: int = 200,
    city_vocab_size: int = 100,
    user_feature_vocab_size: int = 50,
    item_feature_vocab_size: int = 50,
    sequence_max_len: int = 50,
    user_embedding_dim: int = 32,
    item_embedding_dim: int = 32,
    seed: int = 42,
) -> Tuple[pd.DataFrame, List, List, List, List, List, List]:
    """
    Generate synthetic data for match/retrieval tasks

    Returns:
        tuple: (dataframe, user_dense_features, user_sparse_features, user_sequence_features,
                item_dense_features, item_sparse_features, item_sequence_features)
    """
    print(f"Generating {n_samples} synthetic match samples...")

    np.random.seed(seed)
    data = {}

    # User features
    data["user_id"] = np.random.randint(1, user_vocab_size, n_samples)
    data["user_age"] = np.random.randn(n_samples).astype(np.float32)
    data["user_gender"] = np.random.randint(0, 2, n_samples)
    data["user_city"] = np.random.randint(0, city_vocab_size, n_samples)

    for i in range(3):
        data[f"user_feature_{i}"] = np.random.randint(1, user_feature_vocab_size, n_samples)

    # User behavior sequences
    user_hist_items = []
    user_hist_categories = []
    for _ in range(n_samples):
        seq_len = np.random.randint(10, sequence_max_len + 1)
        hist_items = np.random.randint(1, item_vocab_size, seq_len).tolist()
        hist_items = hist_items + [0] * (sequence_max_len - len(hist_items))
        user_hist_items.append(hist_items)

        hist_cats = np.random.randint(1, category_vocab_size, seq_len).tolist()
        hist_cats = hist_cats + [0] * (sequence_max_len - len(hist_cats))
        user_hist_categories.append(hist_cats)

    data["user_hist_items"] = user_hist_items
    data["user_hist_categories"] = user_hist_categories

    # Item features
    data["item_id"] = np.random.randint(1, item_vocab_size, n_samples)
    data["item_price"] = np.random.randn(n_samples).astype(np.float32)
    data["item_category"] = np.random.randint(1, category_vocab_size, n_samples)
    data["item_brand"] = np.random.randint(1, brand_vocab_size, n_samples)

    for i in range(3):
        data[f"item_feature_{i}"] = np.random.randint(1, item_feature_vocab_size, n_samples)

    # Generate labels with some correlation to features
    label_probs = 1 / (
        1
        + np.exp(
            -(
                data["user_age"] * 0.2
                + (data["user_gender"] - 0.5) * 0.3
                + data["item_price"] * 0.15
                + np.random.randn(n_samples) * 0.5
            )
        )
    )
    data["label"] = (label_probs > 0.5).astype(np.float32)

    df = pd.DataFrame(data)
    print(f"Generated data shape: {df.shape}")
    print(f"Positive rate: {data['label'].mean():.4f}")

    # Import here to avoid circular import
    from nextrec.basic.features import DenseFeature, SequenceFeature, SparseFeature

    # User dense features
    user_dense_features = [DenseFeature(name="user_age", input_dim=1)]

    # User sparse features
    user_sparse_features = [
        SparseFeature(name="user_id", vocab_size=user_vocab_size, embedding_dim=user_embedding_dim),
        SparseFeature(name="user_gender", vocab_size=2, embedding_dim=8),
        SparseFeature(name="user_city", vocab_size=city_vocab_size, embedding_dim=16),
    ]
    user_sparse_features.extend(
        [
            SparseFeature(
                name=f"user_feature_{i}",
                vocab_size=user_feature_vocab_size,
                embedding_dim=8,
            )
            for i in range(3)
        ]
    )

    # User sequence features
    user_sequence_features = [
        SequenceFeature(
            name="user_hist_items",
            vocab_size=item_vocab_size,
            max_len=sequence_max_len,
            embedding_dim=user_embedding_dim,
            padding_idx=0,
        ),
        SequenceFeature(
            name="user_hist_categories",
            vocab_size=category_vocab_size,
            max_len=sequence_max_len,
            embedding_dim=16,
            padding_idx=0,
        ),
    ]

    # Item dense features
    item_dense_features = [DenseFeature(name="item_price", input_dim=1)]

    # Item sparse features
    item_sparse_features = [
        SparseFeature(name="item_id", vocab_size=item_vocab_size, embedding_dim=item_embedding_dim),
        SparseFeature(name="item_category", vocab_size=category_vocab_size, embedding_dim=16),
        SparseFeature(name="item_brand", vocab_size=brand_vocab_size, embedding_dim=16),
    ]
    item_sparse_features.extend(
        [
            SparseFeature(
                name=f"item_feature_{i}",
                vocab_size=item_feature_vocab_size,
                embedding_dim=8,
            )
            for i in range(3)
        ]
    )

    # Item sequence features (empty for most match models)
    item_sequence_features = []

    return (
        df,
        user_dense_features,
        user_sparse_features,
        user_sequence_features,
        item_dense_features,
        item_sparse_features,
        item_sequence_features,
    )


def generate_multitask_data(
    n_samples: int = 10000,
    n_dense: int = 5,
    n_sparse: int = 8,
    n_sequences: int = 2,
    user_vocab_size: int = 1000,
    item_vocab_size: int = 500,
    sparse_vocab_size: int = 50,
    sequence_max_len: int = 20,
    embedding_dim: int = 16,
    seed: int = 42,
) -> Tuple[pd.DataFrame, List, List, List]:
    """
    Generate synthetic data for multi-task learning

    Returns:
        tuple: (dataframe, dense_features, sparse_features, sequence_features)
    """
    print(f"Generating {n_samples} synthetic multi-task samples...")

    np.random.seed(seed)
    data = {}

    # Generate dense features
    for i in range(n_dense):
        data[f"dense_{i}"] = np.random.randn(n_samples).astype(np.float32)

    # Generate sparse features
    data["user_id"] = np.random.randint(1, user_vocab_size, n_samples)
    data["item_id"] = np.random.randint(1, item_vocab_size, n_samples)

    for i in range(n_sparse - 2):
        data[f"sparse_{i}"] = np.random.randint(1, sparse_vocab_size, n_samples)

    # Generate sequence features
    sequence_names = []
    sequence_vocabs = []

    for i in range(n_sequences):
        sequences = []
        for _ in range(n_samples):
            seq_len = np.random.randint(5, sequence_max_len + 1)
            if i == 0:
                seq = np.random.randint(0, item_vocab_size, seq_len).tolist()
                seq_vocab = item_vocab_size
                seq_name = "sequence_0"
            else:
                seq = np.random.randint(0, sparse_vocab_size, seq_len).tolist()
                seq_vocab = sparse_vocab_size
                seq_name = f"sequence_{i}"

            seq = seq + [0] * (sequence_max_len - len(seq))
            sequences.append(seq)

        data[seq_name] = sequences
        sequence_names.append(seq_name)
        sequence_vocabs.append(seq_vocab)

    # Generate multi-task labels with correlation
    # CTR (click) is relatively easier to predict
    dense_0 = data.get("dense_0", 0)
    dense_1 = data.get("dense_1", 0)
    dense_2 = data.get("dense_2", 0)
    dense_3 = data.get("dense_3", 0)
    ctr_logits = dense_0 * 0.3 + dense_1 * 0.2 + np.random.randn(n_samples) * 0.5
    data["click"] = (1 / (1 + np.exp(-ctr_logits)) > 0.5).astype(np.float32)

    # CVR (conversion) depends on click and is harder
    cvr_logits = (
        dense_2 * 0.2
        + dense_3 * 0.15
        + data["click"] * 1.5  # Strong dependency on click
        + np.random.randn(n_samples) * 0.8
    )
    data["conversion"] = (1 / (1 + np.exp(-cvr_logits)) > 0.3).astype(np.float32)

    # CTCVR = click AND conversion
    data["ctcvr"] = (data["click"] * data["conversion"]).astype(np.float32)

    df = pd.DataFrame(data)
    print(f"Generated data shape: {df.shape}")
    print(f"Click rate: {data['click'].mean():.4f}")
    print(f"Conversion rate (overall): {data['conversion'].mean():.4f}")
    if data["click"].sum() > 0:
        print(f"Conversion rate (given click): {data['conversion'][data['click'] == 1].mean():.4f}")
    print(f"CTCVR rate: {data['ctcvr'].mean():.4f}")

    # Import here to avoid circular import
    from nextrec.basic.features import DenseFeature, SequenceFeature, SparseFeature

    # Create feature definitions
    dense_features = [DenseFeature(name=f"dense_{i}", input_dim=1) for i in range(n_dense)]

    # Create sparse features
    sparse_features = [
        SparseFeature(
            name="user_id",
            embedding_name="user_emb",
            vocab_size=user_vocab_size,
            embedding_dim=embedding_dim,
        ),
        SparseFeature(
            name="item_id",
            embedding_name="item_emb",
            vocab_size=item_vocab_size,
            embedding_dim=embedding_dim,
        ),
    ]
    sparse_features.extend(
        [
            SparseFeature(
                name=f"sparse_{i}",
                embedding_name=f"sparse_{i}_emb",
                vocab_size=sparse_vocab_size,
                embedding_dim=embedding_dim,
            )
            for i in range(n_sparse - 2)
        ]
    )

    # Create sequence features
    sequence_features = []
    for i, (seq_name, seq_vocab) in enumerate(zip(sequence_names, sequence_vocabs)):
        if i == 0:
            embedding_name = "item_emb"
        else:
            embedding_name = "sparse_0_emb"
        sequence_features.append(
            SequenceFeature(
                name=seq_name,
                vocab_size=seq_vocab,
                max_len=sequence_max_len,
                embedding_dim=embedding_dim,
                padding_idx=0,
                embedding_name=embedding_name,
            )
        )

    return df, dense_features, sparse_features, sequence_features


def generate_distributed_ranking_data(
    num_samples: int = 100000,
    num_users: int = 10000,
    num_items: int = 5000,
    num_categories: int = 20,
    num_cities: int = 100,
    max_seq_len: int = 50,
    embedding_dim: int = 32,
    seed: int = 42,
) -> Tuple[pd.DataFrame, List, List, List]:
    """
    Generate synthetic data for distributed training scenarios

    Returns:
        tuple: (dataframe, dense_features, sparse_features, sequence_features)
    """
    return generate_ranking_data(
        n_samples=num_samples,
        n_dense=5,
        n_sparse=6,  # user_id, item_id + 4 custom features
        n_sequences=2,
        user_vocab_size=num_users + 1,
        item_vocab_size=num_items + 1,
        sequence_max_len=max_seq_len,
        embedding_dim=embedding_dim,
        seed=seed,
        custom_sparse_features={
            "gender": 2,
            "age_group": 7,
            "category": num_categories,
            "city": num_cities,
        },
    )


def generate_synthetic_embeddings(num_samples=1000, embedding_dim=768):
    """
    Generate synthetic multimodal embeddings for demonstration.

    In practice, you would load real embeddings from:
    - Image embeddings (e.g., from ResNet, ViT)
    - Text embeddings (e.g., from BERT, GPT)
    - Audio embeddings (e.g., from wav2vec)
    """
    # Generate random embeddings
    embeddings = torch.randn(num_samples, embedding_dim)

    # Create item IDs
    item_ids = torch.arange(num_samples)

    return item_ids, embeddings
