# 🤖 AzerAI

Azərbaycan dilində qabaqcıl səsli AI asistent - Plugin əsaslı, çoxdilli AI framework.

## 🌟 Xüsusiyyətlər

- 🎤 **Səsli interfeys** - Real-time səsli danışıq
- 🇦🇿 **Azərbaycan dili** - Əsas dil Azərbaycan dilidir
- 🔌 **Plugin sistemi** - Genişlənəbilən plugin arxitekturası
- 💾 **Yaddaş** - Konuşma tarixçəsi və context
- 🎭 **Şəxsiyyət** - Dostlu və əyləncəli xarakter
- 🌍 **Çoxdilli** - 50+ dil dəstəyi
- 🚀 **Yüksək performans** - LiveKit ilə real-time əməliyyatlar

## 🚀 Quraşdırma

### Əsas quraşdırma
```bash
pip install AzerAI
```

### Bütün pluginlərlə birlikdə
```bash
pip install AzerAI[plugins]
```

### Əl ilə quraşdırma
```bash
git clone https://github.com/AzStudio-Dev/AzerAI.git
cd AzerAI
pip install -e .
```

## 📦 Hazır Gələn Pluginlər

| Plugin | Ən Son | Təsvir |
|--------|--------|--------|
| 🕐 **AzerAI-DateTime** | ✅ | Tarix və zaman sorğuları |
| 📅 **AzerAI-Reminder** | ✅ | Hatırlatma sistemi |
| 🔍 **AzerAI-Search** | ✅ | Veb axtarış |

## 🎯 İstifadə

### Console modu
```bash
AzerAI console
```

### Python kodu ilə
```python
from AzerAI import Assistant
from livekit.agents import cli

# Assistant obyekti yarat
assistant = Assistant()

# Session başlat
session = AgentSession(
    llm=google.realtime.RealtimeModel(voice="Puck"),
    agent=assistant,
)

await session.start()
```

## 🔌 Plugin Yaratmaq

Yeni plugin yaratmaq üçün:

1. Plugin qovluğu yaradın:
```bash
mkdir my_azerai_plugin
cd my_azerai_plugin
```

2. `pyproject.toml` faylı yaradın:
```toml
[project]
name = "azerai-my-plugin"
version = "1.0.0"
dependencies = [
    "livekit-agents",
]
```

3. Plugin kodu yazın:
```python
from livekit.agents import function_tool

@function_tool()
async def my_function(ctx, param: str) -> str:
    """Plugin funksiyası"""
    return f"Result: {param}"
```

4. Yayımlayın:
```bash
pip install build twine
python -m build
python -m twine upload dist/*
```

## 🌍 Dəstəklənən Dillər

- 🇦🇿 **Azərbaycan** (Əsas)
- 🇹🇷 **Türkçe**
- 🇬🇧 **English**
- 🇷🇺 **Русский**
- 🇩🇪 **Deutsch**
- 🇫🇷 **Français**
- 🇪🇸 **Español**
- Və 40+ digər dil

## ⚙️ Konfiqurasiya

`.env` faylı yaradın:
```env
LIVEKIT_API_KEY=your_api_key
LIVEKIT_API_SECRET=your_api_secret
LIVEKIT_URL=wss://your-livekit-server.com
```

## 🤝 İştirak

1. Fork edin
2. Feature branch yaradın (`git checkout -b feature/amazing-feature`)
3. Commit edin (`git commit -m 'Add amazing feature'`)
4. Push edin (`git push origin feature/amazing-feature`)
5. Pull Request yaradın

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](LICENSE) faylına baxın.

## 🙏 Təşəkkürlər

- [LiveKit](https://livekit.io/) - Real-time audio/video framework
- [Google](https://ai.google.dev/) - AI modeli
- Azərbaycan icması - Dəstək və tövsiyələr

## 📞 Əlaqə

- **Müəllif:** AzStudio Dev
- **Email:** info.azstudiodev@gmail.com
- **GitHub:** https://github.com/AzStudio-Dev/AzerAI
- **PyPI:** https://pypi.org/project/AzerAI/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistenti!** 🚀
