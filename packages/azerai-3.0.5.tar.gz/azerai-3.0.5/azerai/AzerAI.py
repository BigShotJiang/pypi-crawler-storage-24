"""
AzerAI - Əsas Assistant Sinifi
Azərbaycan dilində qabaqcıl səsli AI asistent
"""
from dotenv import load_dotenv
import asyncio

from livekit import agents, rtc
from livekit.agents import AgentServer, AgentSession, Agent, room_io
from livekit.plugins import (
    google,
    silero,
)
from .plugins import get_all_tools, get_plugin_info, get_plugin_prompts, get_plugin_updates
from .prompts import AGENT_INSTRUCTION, SESSION_INSTRUCTION
from .memory import MemoryManager

load_dotenv(".env")

class Assistant(Agent):
    def __init__(self) -> None:
        # Yaddaş menecerini başlat
        self.memory = MemoryManager()
        # Yaddaş kontekstini al və təlimatlara əlavə et
        memory_context = self.memory.get_memory_context()

        plugin_info = get_plugin_info()
        plugin_prompts = get_plugin_prompts()
        plugin_updates = get_plugin_updates()
        
        # Yeni versiya məlumatlarını təlimatlara əlavə et
        update_info = f"\n\nPlugin Yeniləmə Məlumatları:\n{plugin_updates}" if plugin_updates and "ən son versiyadadır" not in plugin_updates else ""
        
        super().__init__(instructions=plugin_info + plugin_prompts + update_info + AGENT_INSTRUCTION + memory_context)

    async def on_user_turn_completed(self, turn_ctx, new_message):
        """İstifadəçi danışığı bitirdikdə çağrılır - yaddaş konteksti əlavə et"""
        # Yaddaş kontekstini al və varsa istifadəçi mesajının başına əlavə et
        memory_context = self.memory.get_memory_context()
        if memory_context and new_message.content:
            # Məzmunu emlə et - bir string və ya listə ola bilər
            if isinstance(new_message.content, list):
                # Əgər məzmun bir listədirsə, yaddaş kontekstini ilk mətn elementinin başına əlavə et
                context_note = "\n[Əvvəlki danışıqlardan yadda saxla: Yuxarıdakı danışıq tarixinə görə cavab ver]\n"
                if new_message.content and isinstance(new_message.content[0], str):
                    new_message.content[0] = memory_context + context_note + new_message.content[0]
            elif isinstance(new_message.content, str):
                # Əgər məzmun bir stringdirsə, yaddaş kontekstini başına əlavə et
                context_note = "\n[Əvvəlki danışıqlardan yadda saxla: Yuxarıdakı danışıq tarixinə görə cavab ver]\n"
                new_message.content = memory_context + context_note + new_message.content
        
        await super().on_user_turn_completed(turn_ctx, new_message)
    
    async def store_conversation(self, user_message: str, assistant_message: str):
        """Danışıqı yaddaşda saxla"""
        if user_message and assistant_message:
            self.memory.add_conversation(user_message, assistant_message)

server = AgentServer()

@server.rtc_session(agent_name="AzerAI")
async def my_agent(ctx: agents.JobContext):
    plugin_info = get_plugin_info()
    plugin_prompts = get_plugin_prompts()
    all_tools = get_all_tools()
    # Yaddaşda saxlamaq üçün danışıq cütlüklərini izlə
    last_user_message = None

    # Asistan nümunəsi yarat
    assistant = Assistant()

    session = AgentSession(
        vad=silero.VAD.load(),
        llm=google.realtime.RealtimeModel(
            voice="Puck"
        ),
        tools=all_tools,
    )

    # Mesajları izləmək üçün danışıq elementlərini dinlə
    @session.on("conversation_item_added")
    def on_conversation_item(event):
        nonlocal last_user_message
        message = event.item
        
        # İstifadəçi mesajı olub olmadığını yoxla
        if message.role == "user" and message.text_content:
            last_user_message = message.text_content
        
        # Asistan mesajı olub olmadığını və uyğunlaşdırmaq üçün bir istifadəçi mesajı olub olmadığını yoxla
        elif message.role == "assistant" and message.text_content and last_user_message:
            # Danışıq cütünü saxla
            asyncio.create_task(assistant.store_conversation(
                last_user_message, 
                message.text_content
            ))
            last_user_message = None  # Saxladıqdan sonra sıfırla

    await session.start(
        room=ctx.room,
        agent=assistant,
        room_options=room_io.RoomOptions(
            audio_input=room_io.AudioInputOptions(
                #noise_cancellation=lambda params: noise_cancellation.BVCTelephony() if params.participant.kind == rtc.ParticipantKind.PARTICIPANT_KIND_SIP else noise_cancellation.BVC(),
            ),
        ),
    )


    # Reminder plugin-ünə session referansını ver
    try:
        from azerai_reminder.plugins.reminder.main import reminder_tools
        reminder_tools.session_ref = session
        reminder_tools.loop_ref = __import__('asyncio').get_running_loop()
        print(" Reminder plugin-ünə session referansı verildi")
    except Exception as e:
        print(f" Reminder session qurulmadı: {e}")

    await session.generate_reply(
        instructions=SESSION_INSTRUCTION
    )


if __name__ == "__main__":
    agents.cli.run_app(server)
