"""
AzerAI Konsol Giriş Nöqtəsi
"""
from .AzerAI import server
from livekit.agents import cli

def main():
    cli.run_app(server)

if __name__ == "__main__":
    main()
