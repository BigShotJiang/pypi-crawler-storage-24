"""
AzerAI Plugin System - Plugin yükləyici və idarəetmə sistemi
"""
import importlib
import importlib.util
import inspect
import os
import logging
import subprocess
import requests
import sys
from typing import List, Any, Dict
from livekit.agents import function_tool

logger = logging.getLogger("azerai.plugins")

class PluginManager:
    def __init__(self):
        self.loaded_plugins = {}
        self.plugin_tools = {}
        self.discover_plugins()
        self.check_for_updates()

    def check_for_updates(self):
        """PyPI-də yeni versiyaları yoxla"""
        try:
            for plugin_name in self.loaded_plugins.keys():
                if plugin_name.startswith('azerai-') or plugin_name.startswith('azerai_') or plugin_name.startswith('AzerAI-') or plugin_name == 'AzerAI' or 'azerai' in plugin_name:
                    # Pip-in qlobal versiyasını yoxla
                    current_version = self._get_installed_version(plugin_name)
                    latest_version = self._get_latest_version(plugin_name)
                    
                    if latest_version and current_version and latest_version != current_version:
                        print(f"🔄 Yeni versiya mövcuddur: {plugin_name} {current_version} → {latest_version}")
                        print(f"   Yeniləmək üçün: pip install --upgrade {plugin_name}")
        except Exception as e:
            logger.debug(f"Versiya yoxlaması xətası: {e}")

    def _get_installed_version(self, package_name: str) -> str:
        """Qurulmuş paket versiyasını pip show ilə al"""
        try:
            result = subprocess.run(['pip', 'show', package_name], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Version:'):
                        return line.split(':')[1].strip()
        except Exception:
            pass
        return ""

    def _get_latest_version(self, package_name: str) -> str:
        """PyPI-dən ən son versiyanı al"""
        try:
            response = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=3)
            if response.status_code == 200:
                data = response.json()
                return data.get('info', {}).get('version', '')
        except Exception:
            pass
        return ""

    def discover_plugins(self):
        """Hem lokal hem de pip ile yüklənmiş pluginləri aşkar et"""
        # Pip ile yüklənmiş pluginləri yüklə
        self._load_pip_plugins()
        
        # Lokal pluginləri yüklə
        self._load_local_plugins()

    def _load_pip_plugins(self):
        """Pip ile yüklənmiş pluginləri avtomatik aşkar et"""
        # Pip list ilə avtomatik kəşf
        try:
            result = subprocess.run(['pip', 'list'], capture_output=True, text=True)
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('azerai-') or line.startswith('azerai_') or line.startswith('AzerAI-'):
                        plugin_name = line.split()[0]
                        # Modul adını kiçik hərflərə çevir
                        module_name = plugin_name.replace('-', '_').lower()
                        try:
                            module = importlib.import_module(module_name)
                            
                            # Info faylından detallı məlumatları yoxla
                            plugin_info = self._get_plugin_info(module, plugin_name, line)
                            
                            self.loaded_plugins[plugin_name] = plugin_info
                            print(f"[OK] {plugin_name}")
                        except ImportError as e:
                            print(f"[ERR] {module_name}: {e}")
                            logger.warning(f"Plugin yüklənə bilmədi {module_name}: {e}")
                        except Exception as e:
                            print(f"[ERR] {module_name}: {e}")
                            logger.error(f"Plugin yükləmə xətası {module_name}: {e}")
        except Exception as e:
            logger.error(f"pip list xətası: {e}")
            print(f"[ERR] pip list: {e}")

    def _load_local_plugins(self):
        """Lokal pluginləri yüklə"""
        local_plugins_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'plugins')
        
        if not os.path.exists(local_plugins_dir):
            logger.debug(f"Lokal plugin qovluğu tapılmadı: {local_plugins_dir}")
            return
        
        logger.debug(f"Lokal plugin qovluğu axtarılır: {local_plugins_dir}")
        
        for plugin_name in os.listdir(local_plugins_dir):
            plugin_path = os.path.join(local_plugins_dir, plugin_name)
            
            if os.path.isdir(plugin_path) and not plugin_name.startswith('.'):
                # main.py faylını yoxla
                main_file = os.path.join(plugin_path, '__init__.py')
                if os.path.exists(main_file):
                    try:
                        # Plugin qovluğunu Python path-ə əlavə et
                        if local_plugins_dir not in sys.path:
                            sys.path.insert(0, local_plugins_dir)
                        
                        # Plugin modulunu yüklə
                        module = importlib.import_module(plugin_name)
                        
                        # Info faylından detallı məlumatları yoxla
                        plugin_info = self._get_plugin_info(module, plugin_name, f"{plugin_name} 1.0.0")
                        
                        self.loaded_plugins[plugin_name] = plugin_info
                        print(f"[OK] {plugin_name} (lokal)")
                        
                    except ImportError as e:
                        logger.debug(f"Lokal plugin yüklənə bilmədi {plugin_name}: {e}")
                    except Exception as e:
                        logger.debug(f"Lokal plugin xətası {plugin_name}: {e}")

    def _get_plugin_info(self, module, plugin_name: str, pip_line: str) -> Dict[str, Any]:
        """Plugin məlumatlarını info.py faylından və ya əsas atributlardan alır"""
        base_info = {
            'name': plugin_name,
            'module': module,
            'tools': self._extract_tools(module),
        }
        
        # Əvvəlcə info.py faylını yoxla (pip pluginləri üçün)
        try:
            # plugins.datetime.info yoxla
            info_module = importlib.import_module(f"{module.__name__}.plugins.datetime.info")
            if hasattr(info_module, 'PLUGIN_INFO'):
                plugin_info = info_module.PLUGIN_INFO.copy()
                plugin_info.update(base_info)
                return plugin_info
        except ImportError:
            pass
        
        # Başqa struktur yoxla - birbaşa info
        try:
            info_module = importlib.import_module(f"{module.__name__}.info")
            if hasattr(info_module, 'PLUGIN_INFO'):
                plugin_info = info_module.PLUGIN_INFO.copy()
                plugin_info.update(base_info)
                return plugin_info
        except ImportError:
            pass
        
        # Lokal pluginlər üçün info.py yoxla
        try:
            if hasattr(module, 'plugins') and hasattr(module.plugins, 'local'):
                info_module = importlib.import_module(f"{module.__name__}.plugins.local.info")
                if hasattr(info_module, 'PLUGIN_INFO'):
                    plugin_info = info_module.PLUGIN_INFO.copy()
                    plugin_info.update(base_info)
                    return plugin_info
        except ImportError:
            pass
        
        # Əsas atributları istifadə et (fallback)
        pip_version = pip_line.split()[1] if len(pip_line.split()) > 1 else '1.0.0'
        base_info.update({
            'version': getattr(module, '__version__', pip_version),
            'author': getattr(module, '__author__', 'Unknown'),
            'description': getattr(module, '__doc__', '').split('\\n')[0] if getattr(module, '__doc__', '') else ''
        })
        
        return base_info

    def _extract_tools(self, module) -> List[Any]:
        """Moduldan @function_tool ilə işarələnmiş funksiyaları çıxar"""
        tools = []
        
        try:
            # Moduldaki bütün atributları yoxla
            for attr_name in dir(module):
                if attr_name.startswith('_'):
                    continue
                    
                attr = getattr(module, attr_name)
                
                # Funksi olduğunu yoxla
                if callable(attr):
                    # @function_tool dekoratorunu yoxla
                    if hasattr(attr, '_livekit_function_tool'):
                        tools.append(attr)
                    # alternativ atributları yoxla
                    elif hasattr(attr, '__wrapped__') and hasattr(attr.__wrapped__, '_livekit_function_tool'):
                        tools.append(attr)
                    # LiveKit tool patternini yoxla
                    elif hasattr(attr, '__annotations__') and attr.__annotations__:
                        # ctx parametrini yoxla
                        if 'ctx' in str(attr.__annotations__) or 'RunContext' in str(attr.__annotations__):
                            tools.append(attr)
                    # function_tool importunu yoxla
                    elif 'function_tool' in str(attr) or 'livekit' in str(attr):
                        tools.append(attr)
        except Exception as e:
            logger.error(f"Tool çıxarış xətası: {e}")
        
        return tools

    def get_all_tools(self) -> List[Any]:
        """Bütün yüklənmiş pluginlərdən tool-ları qaytarır"""
        all_tools = []
        for plugin_name, plugin_data in self.loaded_plugins.items():
            if 'tools' in plugin_data:
                all_tools.extend(plugin_data['tools'])
        return all_tools

    def get_plugin_info(self) -> str:
        """Plugin məlumatlarını qaytarır"""
        if not self.loaded_plugins:
            return "Heç bir plugin yüklənməyib."
        
        info_parts = ["Yüklənmiş Pluginlər:"]
        
        for plugin_name, plugin_data in self.loaded_plugins.items():
            info_parts.append(f"\n📦 {plugin_name}")
            info_parts.append(f"   Versiya: {plugin_data['version']}")
            info_parts.append(f"   Müəllif: {plugin_data['author']}")
            info_parts.append(f"   Təsvir: {plugin_data['description']}")
            info_parts.append(f"   Tool sayı: {len(plugin_data['tools'])}")
        
        return "\n".join(info_parts)

    def get_plugin_updates(self) -> str:
        """Yeni versiya məlumatlarını qaytarır"""
        updates = []
        
        for plugin_name in self.loaded_plugins.keys():
            if plugin_name.startswith('azerai-'):
                current_version = self._get_installed_version(plugin_name)
                latest_version = self._get_latest_version(plugin_name)
                
                if latest_version and current_version and latest_version != current_version:
                    updates.append(f"🔄 {plugin_name}: {current_version} → {latest_version}")
                    updates.append(f"   Yeniləmək üçün: pip install --upgrade {plugin_name}")
        
        if updates:
            return "\n".join(["Yeni versiyalar mövcuddur:"] + updates)
        else:
            return "Bütün pluginlər ən son versiyadadır."

    def get_plugin_prompts(self) -> str:
        """Plugin promptlarını qaytarır"""
        if not self.loaded_plugins:
            return ""
        
        prompt_parts = ["Plugin xüsusiyyətləri:"]
        
        for plugin_name, plugin_data in self.loaded_plugins.items():
            if plugin_data['tools']:
                prompt_parts.append(f"\n{plugin_name}: {plugin_data['description']}")
                
                # Plugin prompts faylını yoxla
                try:
                    module = plugin_data.get('module')
                    if module and hasattr(module, 'plugins'):
                        # plugins.datetime.prompts yoxla
                        plugins_path = f"{module.__name__}.plugins"
                        try:
                            prompts_module = importlib.import_module(f"{plugins_path}.datetime.prompts")
                            if hasattr(prompts_module, 'PLUGIN_PROMPT'):
                                prompt_parts.append(prompts_module.PLUGIN_PROMPT)
                        except ImportError:
                            # Başqa struktur yoxla - birbaşa prompts
                            try:
                                prompts_module = importlib.import_module(f"{module.__name__}.prompts")
                                if hasattr(prompts_module, 'PLUGIN_PROMPT'):
                                    prompt_parts.append(prompts_module.PLUGIN_PROMPT)
                            except ImportError:
                                pass
                except Exception as e:
                    logger.debug(f"Plugin prompt yüklənə bilmədi {plugin_name}: {e}")
        
        return "\n".join(prompt_parts)

# Global plugin manager instance
plugin_manager = PluginManager()

# Export functions for backward compatibility
def get_all_tools() -> List[Any]:
        """Bütün yüklənmiş pluginlərdən tool-ları qaytarır"""
        return plugin_manager.get_all_tools()

def get_plugin_info() -> str:
    """Plugin məlumatlarını qaytarır"""
    return plugin_manager.get_plugin_info()

def get_plugin_prompts() -> str:
    """Plugin promptlarını qaytarır"""
    return plugin_manager.get_plugin_prompts()

def get_plugin_updates() -> str:
    """Yeni versiya məlumatlarını qaytarır"""
    return plugin_manager.get_plugin_updates()
