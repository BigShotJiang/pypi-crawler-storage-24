"""GranolaClient - async HTTP client for the Granola public API."""

from __future__ import annotations

from typing import Any

import httpx

from arcade_granola.auth import ApiKeyAuthProvider
from arcade_granola.models import (
    GRANOLA_API_BASE_URL,
    Note,
    NoteSummary,
)

COMMON_HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "arcade-granola/2.0.0",
}


class GranolaClient:
    """Async HTTP client for the Granola public Enterprise API."""

    def __init__(
        self,
        auth: ApiKeyAuthProvider,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._auth = auth
        self._http = http_client or httpx.AsyncClient(
            base_url=GRANOLA_API_BASE_URL,
            headers=COMMON_HEADERS,
            timeout=30.0,
        )
        self._owns_http = http_client is None

    async def _request(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make an authenticated GET request."""
        token = await self._auth.get_access_token()
        headers = {"Authorization": f"Bearer {token}"}
        response = await self._http.get(path, params=params, headers=headers)
        response.raise_for_status()
        return response.json()

    # --- Endpoints ---

    async def list_notes(
        self,
        *,
        page_size: int = 10,
        cursor: str | None = None,
        created_before: str | None = None,
        created_after: str | None = None,
        updated_after: str | None = None,
    ) -> tuple[list[NoteSummary], bool, str | None]:
        """GET /v1/notes - list notes with cursor pagination.

        Returns (notes, has_more, next_cursor).
        """
        params: dict[str, Any] = {"page_size": page_size}
        if cursor:
            params["cursor"] = cursor
        if created_before:
            params["created_before"] = created_before
        if created_after:
            params["created_after"] = created_after
        if updated_after:
            params["updated_after"] = updated_after

        data = await self._request("/v1/notes", params=params)
        notes = [NoteSummary.model_validate(n) for n in data.get("notes", [])]
        has_more = data.get("hasMore", False)
        next_cursor = data.get("cursor")
        return notes, has_more, next_cursor

    async def get_note(
        self,
        note_id: str,
        *,
        include_transcript: bool = False,
    ) -> Note:
        """GET /v1/notes/{note_id} - get a single note with optional transcript."""
        params: dict[str, Any] = {}
        if include_transcript:
            params["include"] = "transcript"

        data = await self._request(f"/v1/notes/{note_id}", params=params or None)
        return Note.model_validate(data)

    async def close(self) -> None:
        """Close the HTTP client if we own it."""
        if self._owns_http:
            await self._http.aclose()
