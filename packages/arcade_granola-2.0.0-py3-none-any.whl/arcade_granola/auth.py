"""Authentication provider for the Granola public API."""


class ApiKeyAuthProvider:
    """Simple bearer-token auth using a Granola Enterprise API key."""

    def __init__(self, api_key: str) -> None:
        self._api_key = api_key

    async def get_access_token(self) -> str:
        return self._api_key
