"""Pydantic v2 models for the Granola public API (https://docs.granola.ai)."""

from __future__ import annotations

from pydantic import BaseModel, Field

# --- Constants ---

GRANOLA_WEB_BASE_URL = "https://app.granola.so"
GRANOLA_API_BASE_URL = "https://public-api.granola.ai"

# Bounds for pagination parameters
MAX_PAGE_SIZE = 30
DEFAULT_PAGE_SIZE = 10


# --- API response models ---


class User(BaseModel):
    """A Granola user."""

    name: str | None = None
    email: str | None = None

    model_config = {"extra": "allow"}


class Folder(BaseModel):
    """A folder containing notes."""

    id: str
    object: str = "folder"
    name: str | None = None

    model_config = {"extra": "allow"}


class CalendarEvent(BaseModel):
    """Calendar event associated with a note."""

    title: str | None = None
    invitees: list[User] = Field(default_factory=list)
    organizer: User | None = None
    event_id: str | None = None
    start_time: str | None = None
    end_time: str | None = None

    model_config = {"extra": "allow"}


class TranscriptSegment(BaseModel):
    """A single transcript segment from the public API."""

    speaker: User | None = None
    text: str = ""
    start_time: str | None = None
    end_time: str | None = None

    model_config = {"extra": "allow"}


class NoteSummary(BaseModel):
    """Summary returned by GET /v1/notes."""

    id: str  # format: not_[a-zA-Z0-9]{14}
    object: str = "note"
    title: str | None = None
    owner: User | None = None
    created_at: str | None = None
    updated_at: str | None = None

    model_config = {"extra": "allow"}


class Note(BaseModel):
    """Full note returned by GET /v1/notes/{note_id}."""

    id: str
    object: str = "note"
    title: str | None = None
    owner: User | None = None
    created_at: str | None = None
    updated_at: str | None = None
    calendar_event: CalendarEvent | None = None
    attendees: list[User] = Field(default_factory=list)
    folder_membership: list[Folder] = Field(default_factory=list)
    summary_text: str | None = None
    summary_markdown: str | None = None
    transcript: list[TranscriptSegment] | None = None

    model_config = {"extra": "allow"}
