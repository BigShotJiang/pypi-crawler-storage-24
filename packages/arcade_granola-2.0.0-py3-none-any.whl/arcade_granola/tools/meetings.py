"""Meeting discovery, retrieval, and transcript tools."""

from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_granola.models import (
    DEFAULT_PAGE_SIZE,
    MAX_PAGE_SIZE,
    Note,
)
from arcade_granola.tools._common import get_client, meeting_url, parse_iso

_READ_ONLY_METADATA = ToolMetadata(
    classification=Classification(
        service_domains=[ServiceDomain.DOCUMENTS],
    ),
    behavior=Behavior(
        operations=[Operation.READ],
        read_only=True,
        destructive=False,
        idempotent=True,
        open_world=True,
    ),
)


def _estimate_calendar_duration(note: Note) -> int | None:
    """Estimate meeting duration in minutes from the calendar event."""
    event = note.calendar_event
    if not event:
        return None
    start = event.start_time
    end = event.end_time
    if start and end:
        start_dt = parse_iso(start)
        end_dt = parse_iso(end)
        if start_dt and end_dt:
            return int((end_dt - start_dt).total_seconds() / 60)
    return None


def _estimate_transcript_duration(note: Note) -> int:
    """Estimate meeting duration in seconds from the transcript segments."""
    if not note.transcript:
        return 0
    first = note.transcript[0]
    last = note.transcript[-1]
    start_dt = parse_iso(first.start_time or "")
    end_dt = parse_iso(last.end_time or last.start_time or "")
    if start_dt and end_dt:
        return int((end_dt - start_dt).total_seconds())
    return 0


@tool(
    requires_secrets=["GRANOLA_API_KEY"],
    metadata=_READ_ONLY_METADATA,
)
async def list_meetings(
    context: Context,
    created_after: Annotated[
        str,
        "Only return meetings created on or after this date (YYYY-MM-DD)."
        " Leave empty for no lower bound.",
    ] = "",
    created_before: Annotated[
        str,
        "Only return meetings created before this date (YYYY-MM-DD)."
        " Leave empty for no upper bound.",
    ] = "",
    page_size: Annotated[
        int, "Number of results per page (1-30). Defaults to 10."
    ] = DEFAULT_PAGE_SIZE,
    cursor: Annotated[
        str,
        "Opaque pagination cursor returned by a previous list_meetings call."
        " Leave empty for the first page.",
    ] = "",
) -> Annotated[dict[str, Any], "List of meetings with metadata and pagination cursor."]:
    """List Granola meetings, optionally filtered by date range, with cursor pagination.

    Returns metadata only — no notes or transcript content. Results are newest first.
    """
    page_size = max(1, min(page_size, MAX_PAGE_SIZE))

    client = await get_client(context)
    try:
        notes, has_more, next_cursor = await client.list_notes(
            page_size=page_size,
            cursor=cursor or None,
            created_after=created_after or None,
            created_before=created_before or None,
        )

        results: list[dict[str, Any]] = []
        for note in notes:
            owner_name = note.owner.name if note.owner else None
            owner_email = note.owner.email if note.owner else None
            results.append({
                "id": note.id,
                "title": note.title,
                "date": note.created_at,
                "owner_name": owner_name,
                "owner_email": owner_email,
                "granola_url": meeting_url(note.id),
            })

        return {
            "meetings": results,
            "has_more": has_more,
            "next_cursor": next_cursor,
        }
    finally:
        await client.close()


@tool(
    requires_secrets=["GRANOLA_API_KEY"],
    metadata=_READ_ONLY_METADATA,
)
async def get_meeting(
    context: Context,
    meeting_id: Annotated[
        str, "Granola note ID in format 'not_<14 chars>' (e.g. 'not_XXXXXXXXXXXXXX')."
    ],
) -> Annotated[dict[str, Any], "Full meeting metadata including attendees and calendar event."]:
    """Get full metadata for one Granola meeting by its note ID.

    Does not return notes or transcript content. Use get_meeting_transcript for the transcript.
    """
    client = await get_client(context)
    try:
        note = await client.get_note(meeting_id)

        attendee_names = [a.name or a.email for a in note.attendees]
        folders = [{"id": f.id, "name": f.name} for f in note.folder_membership]

        return {
            "id": note.id,
            "title": note.title,
            "date": note.created_at,
            "updated_at": note.updated_at,
            "duration_minutes": _estimate_calendar_duration(note),
            "owner": {"name": note.owner.name, "email": note.owner.email} if note.owner else None,
            "attendees": attendee_names,
            "calendar_event": {
                "title": note.calendar_event.title,
                "start_time": note.calendar_event.start_time,
                "end_time": note.calendar_event.end_time,
            }
            if note.calendar_event
            else None,
            "folders": folders,
            "has_notes": bool(note.summary_markdown or note.summary_text),
            "has_transcript": note.transcript is not None,
            "granola_url": meeting_url(note.id),
        }
    finally:
        await client.close()


@tool(
    requires_secrets=["GRANOLA_API_KEY"],
    metadata=_READ_ONLY_METADATA,
)
async def get_meeting_transcript(
    context: Context,
    meeting_id: Annotated[
        str, "Granola note ID in format 'not_<14 chars>' (e.g. 'not_XXXXXXXXXXXXXX')."
    ],
    speaker_filter: Annotated[
        str,
        "Filter by speaker name (case-insensitive match). Leave empty to return all speakers.",
    ] = "",
) -> Annotated[dict[str, Any], "Transcript segments with speaker labels and timestamps."]:
    """Get the verbatim transcript for a Granola meeting, with speaker labels and timestamps.

    Returns all segments by default. Use speaker_filter to narrow to a single speaker.
    Note: transcripts can be large for long meetings.
    """
    client = await get_client(context)
    try:
        note = await client.get_note(meeting_id, include_transcript=True)

        if not note.transcript:
            raise ToolExecutionError(f"No transcript available for meeting {meeting_id}")

        speakers: set[str] = set()
        segments: list[dict[str, Any]] = []
        total_words = 0

        for seg in note.transcript:
            speaker_name = "Unknown"
            if seg.speaker:
                speaker_name = seg.speaker.name or seg.speaker.email or "Unknown"
            speakers.add(speaker_name)

            if speaker_filter and speaker_filter.lower() != speaker_name.lower():
                continue

            total_words += len(seg.text.split())
            segments.append({
                "speaker": speaker_name,
                "start_time": seg.start_time,
                "end_time": seg.end_time,
                "text": seg.text,
            })

        return {
            "meeting_id": meeting_id,
            "duration_seconds": _estimate_transcript_duration(note),
            "speakers": sorted(speakers),
            "segments": segments,
            "word_count": total_words,
            "granola_url": meeting_url(meeting_id),
        }
    finally:
        await client.close()
