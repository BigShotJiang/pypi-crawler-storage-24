"""Shared helpers for Granola tools."""

from datetime import datetime

from arcade_mcp_server import Context

from arcade_granola.auth import ApiKeyAuthProvider
from arcade_granola.client import GranolaClient
from arcade_granola.models import GRANOLA_WEB_BASE_URL


async def get_client(context: Context) -> GranolaClient:
    """Create a GranolaClient from an Arcade-injected API key."""
    api_key = context.get_secret("GRANOLA_API_KEY")
    return GranolaClient(ApiKeyAuthProvider(api_key))


def meeting_url(note_id: str) -> str:
    """Build a Granola web URL for a meeting."""
    return f"{GRANOLA_WEB_BASE_URL}/documents/{note_id}"


def parse_iso(value: str) -> datetime | None:
    """Parse an ISO 8601 datetime string, handling trailing 'Z' for Python 3.10."""
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError, AttributeError):
        return None
