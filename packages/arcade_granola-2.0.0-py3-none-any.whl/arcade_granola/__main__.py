"""Entrypoint for the Granola MCP server."""

import sys
from typing import cast

from arcade_mcp_server import MCPApp
from arcade_mcp_server.mcp_app import TransportType

import arcade_granola

app = MCPApp(
    name="Granola",
    instructions=(
        "Use this server when you need to access Granola meeting notes, "
        "transcripts, action items, or search across meetings. "
        "Requires a Granola Enterprise API key. "
        "NOTE: Granola API keys grant workspace-level read access — all "
        "publicly accessible notes within the workspace are visible to "
        "any user of this MCP, not just the key owner's notes."
    ),
)
app.add_tools_from_module(arcade_granola)


def main() -> None:
    transport = sys.argv[1] if len(sys.argv) > 1 else "stdio"
    host = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
    port = int(sys.argv[3]) if len(sys.argv) > 3 else 8000

    app.run(transport=cast(TransportType, transport), host=host, port=port)


if __name__ == "__main__":
    main()
