"""godoo — Async Python SDK for Odoo JSON-RPC"""
__version__ = "0.0.1"
