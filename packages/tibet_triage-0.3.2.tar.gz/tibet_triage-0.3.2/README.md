# tibet-triage

**Human-in-the-Loop as a discipline. Not a rubber stamp.**

Airlock sandbox execution, isomorphic mirror, risk-gated triage levels with full TIBET provenance. Every action is pre-computed, every change is diffed, every decision is signed.

## The Problem

Compliance frameworks (SOC 2, ISO 27001, NIS2, DORA, PCI DSS, HIPAA) require human oversight. But nobody defines *when*, *how*, or *with what evidence*. The result: operators rubber-stamp everything because stopping the pipeline is worse than the risk.

**Triage is not approval. Triage is assessment by someone who sees the difference.**

## How It Works

```
Process Request → AIRLOCK (sandbox) → RISK GATE → TRIAGE LEVEL → APPLY
```

1. **Airlock**: Run any process in an isolated sandbox. Capture all file changes, side effects, and TIBET tokens.
2. **Risk Gate**: Evaluate trigger rules against the airlock result. Automatically determine what level of oversight is needed.
3. **Triage**: Present evidence to the right level of human reviewer.
4. **Apply**: On approval, apply the pre-computed diff. Deterministic. No drift.

## Triage Levels

| Level | Who | When |
|-------|-----|------|
| L0 AUTO | No human | Trust score high, no triggers fired |
| L1 OPERATOR | One operator, async | Moderate risk, standard review |
| L2 SENIOR | Senior + co-signer | System-critical, intent mismatch |
| L3 CEREMONY | Physical presence | Catastrophic risk, out-of-band |

## Quick Start

```bash
pip install tibet-triage

# Run a command in the airlock
tibet-triage run python deploy.py --source ./app --intent "Deploy API v2.3"

# If triage is needed, review the evidence
tibet-triage pending
tibet-triage review triage-abc123

# Approve or reject
tibet-triage approve triage-abc123 --operator jasper@humotica.com
tibet-triage reject triage-abc123 --reason "Diff too large"
```

## Not Just for AI

tibet-triage is a **universal process integrity engine**. The same airlock + mirror + risk gate pattern works for:

- **CI/CD pipelines** — pre-compute deployments, review before apply
- **Scientific computing** — reproducible experiments with evidence chains
- **Supply chain** — package build verification before publish
- **Financial transactions** — pre-compute + compliance check + execute
- **Infrastructure** — terraform plan is a primitive airlock; this is the full version
- **Medical data** — HIPAA minimum necessary, proven by diff

## Part of the TIBET Ecosystem

- [tibet-core](https://pypi.org/project/tibet-core/) — Token provenance
- [tibet-pol](https://pypi.org/project/tibet-pol/) — Process integrity checker
- [tibet-forge](https://pypi.org/project/tibet-forge/) — Code certification
- [tibet-audit](https://pypi.org/project/tibet-audit/) — Compliance reporting
- [tibet-trail](https://pypi.org/project/tibet-trail/) — Chain tracing

## License

MIT — Humotica AI Lab
