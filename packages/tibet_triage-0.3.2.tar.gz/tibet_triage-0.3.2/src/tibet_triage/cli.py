"""
tibet-triage CLI — Human-in-the-Loop as a discipline.

Commands:
    tibet-triage run <command> [--source <dir>]  Run command in airlock
    tibet-triage review <bundle-id>              Review pending triage
    tibet-triage approve <bundle-id>             Approve a triage bundle
    tibet-triage reject <bundle-id>              Reject a triage bundle
    tibet-triage escalate <bundle-id>            Escalate to higher level
    tibet-triage pending                         List pending triage items
    tibet-triage rules                           Show active trigger rules
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .airlock import Airlock
from .approval import ApprovalChain
from .install_gate import resolve_dependencies, install_in_airlock
from .models import TriageLevel, TriageState
from .replay import export_airlock, save_bundle, load_bundle, replay_bundle, compare_results
from .risk_gate import RiskGate, load_rules_from_file
from .upip import (
    UPIPStack, StateCapture, DepsCapture, ProcessDef,
    capture_and_run, save_upip, load_upip, reproduce_upip,
)
from .zenodo_bundle import (
    create_zenodo_bundle, save_zenodo_bundle, load_zenodo_bundle,
    capture_environment,
)

console = Console()


def cmd_run(args: argparse.Namespace) -> int:
    """Run a command in the airlock and evaluate triage."""
    command = args.command
    # Strip leading '--' from REMAINDER
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        console.print("[red]Error:[/red] No command specified. Use: tibet-triage run [options] -- <command>")
        return 1
    source = args.source or "."
    actor = args.actor or "cli-user"
    intent = args.intent or f"Execute: {' '.join(command)}"

    # Build the risk gate
    gate = RiskGate()
    if args.rules:
        custom = load_rules_from_file(args.rules)
        for r in custom:
            gate.add_rule(r)

    # Run in airlock
    console.print(f"\n[bold]AIRLOCK[/bold] Preparing sandbox...", style="blue")

    with Airlock(
        process_name=intent,
        actor=actor,
        intent=intent,
    ) as airlock:
        workdir = airlock.prepare(source_dir=source)
        console.print(f"  Workdir: {workdir}", style="dim")
        console.print(f"  Source:  {source}", style="dim")
        console.print(f"  Command: {' '.join(command)}", style="dim")
        console.print()

        console.print("[bold]EXECUTE[/bold] Running in sandbox...", style="blue")
        result = airlock.execute(command, timeout=args.timeout)

        # Show execution result
        if result.success:
            console.print(f"  Exit: {result.exit_code} [green]OK[/green]")
        else:
            console.print(f"  Exit: {result.exit_code} [red]FAILED[/red]")

        if result.stdout.strip():
            console.print(Panel(
                result.stdout.strip()[-2000:],
                title="stdout",
                style="dim",
                expand=False,
            ))

        if result.stderr.strip():
            console.print(Panel(
                result.stderr.strip()[-1000:],
                title="stderr",
                style="red" if not result.success else "dim",
                expand=False,
            ))

        # Evaluate risk
        console.print()
        console.print("[bold]RISK GATE[/bold] Evaluating triggers...", style="blue")

        context = {}
        if args.trust_score is not None:
            context["trust_score"] = args.trust_score

        bundle = gate.evaluate(result, context=context)

        # Show risk assessment
        _show_risk_assessment(bundle)

        # Handle based on triage level
        if bundle.triage_level == TriageLevel.L0_AUTO:
            console.print("[bold green]AUTO-CLEAR[/bold green] No triage needed.")
            if args.json:
                _output_json(bundle)
            return 0
        else:
            # Save for pending review
            chain = ApprovalChain(bundle)
            chain.set_deadline()
            chain._save()

            level_colors = {
                TriageLevel.L1_OPERATOR: "yellow",
                TriageLevel.L2_SENIOR: "red",
                TriageLevel.L3_CEREMONY: "bold red",
            }
            color = level_colors.get(bundle.triage_level, "yellow")
            console.print(
                f"[{color}]TRIAGE {bundle.triage_level.name}[/{color}] "
                f"— Human review required."
            )
            console.print(
                f"  Bundle: [bold]{bundle.bundle_id}[/bold]"
            )
            console.print(
                f"  Review: tibet-triage review {bundle.bundle_id}"
            )
            console.print(
                f"  Approve: tibet-triage approve {bundle.bundle_id}"
            )

            if args.json:
                _output_json(bundle)
            return 2  # Exit code 2 = triage needed


def cmd_review(args: argparse.Namespace) -> int:
    """Review a pending triage evidence bundle."""
    try:
        chain = ApprovalChain.load(args.bundle_id)
    except FileNotFoundError:
        console.print(f"[red]Not found:[/red] {args.bundle_id}")
        return 1

    bundle = chain.bundle
    console.print()
    console.print(Panel(
        bundle.summary() if hasattr(bundle, 'summary') and bundle.airlock_result
        else _bundle_summary(bundle),
        title=f"Evidence: {bundle.bundle_id}",
        style="blue",
    ))
    return 0


def cmd_approve(args: argparse.Namespace) -> int:
    """Approve a pending triage bundle."""
    try:
        chain = ApprovalChain.load(args.bundle_id)
    except FileNotFoundError:
        console.print(f"[red]Not found:[/red] {args.bundle_id}")
        return 1

    operator = args.operator or "cli-operator"
    reason = args.reason or ""

    state = chain.approve(operator_id=operator, reason=reason)

    if state == TriageState.APPROVED:
        console.print(f"[green]APPROVED[/green] — {chain.bundle.bundle_id}")
        console.print(f"  Operator: {operator}")
        if reason:
            console.print(f"  Reason: {reason}")
        console.print(f"\n  Apply with: tibet-triage apply {args.bundle_id} --target <dir>")
    elif state == TriageState.AWAITING_TRIAGE:
        console.print(
            f"[yellow]PARTIAL[/yellow] — {chain.bundle.approvals_needed} "
            f"more approval(s) needed"
        )
    elif state == TriageState.EXPIRED:
        console.print("[red]EXPIRED[/red] — Deadline passed, auto-rejected")
    else:
        console.print(f"State: {state.value}")

    return 0


def cmd_reject(args: argparse.Namespace) -> int:
    """Reject a pending triage bundle."""
    try:
        chain = ApprovalChain.load(args.bundle_id)
    except FileNotFoundError:
        console.print(f"[red]Not found:[/red] {args.bundle_id}")
        return 1

    operator = args.operator or "cli-operator"
    reason = args.reason or ""

    chain.reject(operator_id=operator, reason=reason)
    console.print(f"[red]REJECTED[/red] — {chain.bundle.bundle_id}")
    if reason:
        console.print(f"  Reason: {reason}")
    return 0


def cmd_escalate(args: argparse.Namespace) -> int:
    """Escalate to higher triage level."""
    try:
        chain = ApprovalChain.load(args.bundle_id)
    except FileNotFoundError:
        console.print(f"[red]Not found:[/red] {args.bundle_id}")
        return 1

    operator = args.operator or "cli-operator"
    reason = args.reason or ""

    old_level = chain.bundle.triage_level
    chain.escalate(operator_id=operator, reason=reason)
    new_level = chain.bundle.triage_level

    console.print(
        f"[yellow]ESCALATED[/yellow] — {old_level.name} -> {new_level.name}"
    )
    if reason:
        console.print(f"  Reason: {reason}")
    return 0


def cmd_pending(args: argparse.Namespace) -> int:
    """List pending triage items."""
    items = ApprovalChain.list_pending()

    if not items:
        console.print("[dim]No pending triage items.[/dim]")
        return 0

    table = Table(title="Pending Triage")
    table.add_column("Bundle ID", style="bold")
    table.add_column("Process")
    table.add_column("Level")
    table.add_column("State")
    table.add_column("Requested By")
    table.add_column("Deadline")

    level_styles = {
        "L0_AUTO": "green",
        "L1_OPERATOR": "yellow",
        "L2_SENIOR": "red",
        "L3_CEREMONY": "bold red",
    }

    for item in items:
        level = item["level"]
        style = level_styles.get(level, "")
        table.add_row(
            item["bundle_id"],
            item["process"],
            Text(level, style=style),
            item["state"],
            item["requested_by"],
            item.get("deadline", "")[:19] or "-",
        )

    console.print(table)
    return 0


def cmd_rules(args: argparse.Namespace) -> int:
    """Show active trigger rules."""
    gate = RiskGate()
    if args.rules:
        custom = load_rules_from_file(args.rules)
        for r in custom:
            gate.add_rule(r)

    table = Table(title="Active Trigger Rules")
    table.add_column("Name", style="bold")
    table.add_column("Type")
    table.add_column("Weight")
    table.add_column("Min Level")
    table.add_column("Condition")
    table.add_column("Description")

    for rule in gate.rules:
        table.add_row(
            rule.name,
            rule.trigger_type.value,
            f"{rule.weight:.1f}",
            rule.min_level.name,
            rule.condition,
            rule.description,
        )

    console.print(table)
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    """Export an airlock execution as a portable replay bundle."""
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        console.print("[red]Error:[/red] No command specified. Use: tibet-triage export [options] -- <command>")
        return 1

    source = args.source or "."
    actor = args.actor or "cli-user"
    intent = args.intent or f"Execute: {' '.join(command)}"
    output_path = args.output

    console.print(f"\n[bold]AIRLOCK[/bold] Preparing sandbox for export...", style="blue")

    with Airlock(
        process_name=intent,
        actor=actor,
        intent=intent,
    ) as airlock:
        workdir = airlock.prepare(source_dir=source)
        console.print(f"  Workdir: {workdir}", style="dim")
        console.print(f"  Source:  {source}", style="dim")
        console.print(f"  Command: {' '.join(command)}", style="dim")
        console.print()

        console.print("[bold]EXECUTE[/bold] Running in sandbox...", style="blue")
        result = airlock.execute(command, timeout=args.timeout)

        if result.success:
            console.print(f"  Exit: {result.exit_code} [green]OK[/green]")
        else:
            console.print(f"  Exit: {result.exit_code} [red]FAILED[/red]")

        # Export as replay bundle
        console.print()
        console.print("[bold]EXPORT[/bold] Creating replay bundle...", style="blue")

        bundle = export_airlock(
            result=result,
            command=command,
            source_dir=source,
            include_source=args.include_source,
        )
        save_bundle(bundle, output_path)

        console.print(f"  Bundle:  {output_path}")
        console.print(f"  Hash:    {bundle.hash()}")
        console.print(f"  Machine: {bundle.source_machine}")
        console.print(f"  Files:   {len(bundle.source_hashes)} tracked")
        if bundle.source_files:
            console.print(f"  Content: {len(bundle.source_files)} files included (self-contained)")
        console.print()
        console.print("[green]Bundle exported.[/green] Transfer to another machine and replay:")
        console.print(f"  tibet-triage replay {output_path}")

    return 0


def cmd_replay(args: argparse.Namespace) -> int:
    """Replay a bundle on this machine and compare with original."""
    bundle_path = args.bundle_path
    override_source = args.source

    if not Path(bundle_path).exists():
        console.print(f"[red]Not found:[/red] {bundle_path}")
        return 1

    console.print(f"\n[bold]REPLAY[/bold] Loading bundle...", style="blue")
    original_bundle = load_bundle(bundle_path)

    console.print(f"  From:    {original_bundle.source_machine}")
    console.print(f"  Command: {' '.join(original_bundle.command)}")
    console.print(f"  Intent:  {original_bundle.intent}")
    console.print(f"  Hash:    {original_bundle.hash()}")
    console.print()

    console.print("[bold]REPLAY[/bold] Executing on this machine...", style="blue")

    original, replay_result = replay_bundle(
        bundle_path,
        override_source=override_source,
    )

    if replay_result.success:
        console.print(f"  Exit: {replay_result.exit_code} [green]OK[/green]")
    else:
        console.print(f"  Exit: {replay_result.exit_code} [red]FAILED[/red]")

    if replay_result.stdout.strip():
        console.print(Panel(
            replay_result.stdout.strip()[-2000:],
            title="stdout (replay)",
            style="dim",
            expand=False,
        ))

    # Compare results
    console.print()
    console.print("[bold]COMPARE[/bold] Checking isomorphism...", style="blue")
    comparison = compare_results(original, replay_result)

    # Display comparison
    if comparison.is_isomorphic:
        console.print(Panel(
            comparison.summary(),
            title="[green]ISOMORPHIC[/green] — Process Reproducible",
            style="green",
        ))
    else:
        score_pct = f"{comparison.divergence_score:.0%}"
        console.print(Panel(
            comparison.summary(),
            title=f"[red]DIVERGENT[/red] — {score_pct} divergence",
            style="red",
        ))

    return 0 if comparison.is_isomorphic else 3  # Exit 3 = divergent


def cmd_install(args: argparse.Namespace) -> int:
    """Install packages through the triage airlock."""
    packages = args.packages
    if not packages:
        console.print("[red]Error:[/red] No packages specified.")
        return 1

    actor = args.actor or "cli-user"
    trust = args.trust_score

    # Phase 1: Resolve dependency tree (dry-run)
    console.print(f"\n[bold]RESOLVE[/bold] Analyzing dependency tree...", style="blue")

    pip_args = []
    if args.upgrade:
        pip_args.append("--upgrade")
    if args.extra_index:
        pip_args.extend(["--extra-index-url", args.extra_index])

    tree = resolve_dependencies(packages, pip_args=pip_args or None)

    if tree.errors:
        for err in tree.errors:
            console.print(f"[red]Error:[/red] {err}")
        return 1

    # Phase 2: Display dependency tree
    dep_table = Table(title="Dependency Tree")
    dep_table.add_column("Package", style="bold")
    dep_table.add_column("Version")
    dep_table.add_column("License")
    dep_table.add_column("Status")

    for dep in tree.resolved:
        if dep.is_direct:
            name_display = f"[bold cyan]{dep.name}[/bold cyan]"
        else:
            name_display = f"  {dep.name}"

        if dep.is_new:
            status = Text("NEW", style="yellow")
        else:
            status = Text("installed", style="green")

        dep_table.add_row(
            name_display,
            dep.version,
            dep.license or "unknown",
            status,
        )

    console.print(dep_table)
    console.print()

    # Summary line
    console.print(
        f"  Packages: [bold]{tree.total_count}[/bold] total, "
        f"[yellow]{tree.new_count}[/yellow] new, "
        f"{len(tree.will_upgrade)} upgrade, "
        f"{len(tree.already_installed)} already installed"
    )
    if tree.total_download_size:
        console.print(f"  Download: {tree.total_download_size}")
    console.print()

    # Phase 3: Run in airlock
    console.print("[bold]AIRLOCK[/bold] Installing in sandbox...", style="blue")

    tree2, airlock_result = install_in_airlock(
        packages,
        pip_args=pip_args or None,
        actor=actor,
    )

    if airlock_result.success:
        console.print(f"  Exit: {airlock_result.exit_code} [green]OK[/green]")
    else:
        console.print(f"  Exit: {airlock_result.exit_code} [red]FAILED[/red]")
        if airlock_result.stderr.strip():
            console.print(Panel(
                airlock_result.stderr.strip()[-1000:],
                title="stderr",
                style="red",
                expand=False,
            ))

    # Phase 4: Risk assessment
    console.print()
    console.print("[bold]RISK GATE[/bold] Evaluating install risk...", style="blue")

    gate = RiskGate()
    context = {"trust_score": trust if trust is not None else 100}

    # Add dep-specific context
    unknown_licenses = sum(
        1 for d in tree.resolved if not d.license or d.license == "UNKNOWN"
    )
    context["unknown_licenses"] = unknown_licenses
    context["new_packages"] = tree.new_count
    context["total_packages"] = tree.total_count

    bundle = gate.evaluate(airlock_result, context=context)
    _show_risk_assessment(bundle)

    # Phase 5: Show what would happen
    diff = airlock_result.diff
    console.print()
    if not diff.is_empty:
        console.print(
            f"  Files to install: [bold]{len(diff.files_added)}[/bold] new, "
            f"{len(diff.files_changed)} modified"
        )

    # Phase 6: Decision
    if bundle.triage_level == TriageLevel.L0_AUTO:
        console.print()
        console.print("[bold green]AUTO-CLEAR[/bold green] Dependencies verified. Safe to install.")

        if not args.dry_run:
            console.print()
            console.print("[bold]APPLY[/bold] Installing for real...", style="blue")
            import subprocess as sp
            cmd = [sys.executable, "-m", "pip", "install", "--no-input"]
            if pip_args:
                cmd.extend(pip_args)
            cmd.extend(packages)
            proc = sp.run(cmd, capture_output=True, text=True)
            if proc.returncode == 0:
                console.print("[green]Installed successfully.[/green]")
            else:
                console.print(f"[red]Install failed:[/red] {proc.stderr.strip()[-500:]}")
                return 1
        else:
            console.print("[dim]Dry run — skipping actual install.[/dim]")

        if args.json:
            _output_install_json(tree, bundle)
        return 0
    else:
        # Save for triage
        chain = ApprovalChain(bundle)
        chain.set_deadline()
        chain._save()

        level_colors = {
            TriageLevel.L1_OPERATOR: "yellow",
            TriageLevel.L2_SENIOR: "red",
            TriageLevel.L3_CEREMONY: "bold red",
        }
        color = level_colors.get(bundle.triage_level, "yellow")
        console.print()
        console.print(
            f"[{color}]TRIAGE {bundle.triage_level.name}[/{color}] "
            f"— Human approval needed before install."
        )
        console.print(f"  Bundle: [bold]{bundle.bundle_id}[/bold]")
        console.print(f"  Review: tibet-triage review {bundle.bundle_id}")
        console.print(f"  Approve then: tibet-triage install-apply {bundle.bundle_id}")

        if args.json:
            _output_install_json(tree, bundle)
        return 2


def cmd_zenodo_export(args: argparse.Namespace) -> int:
    """Export a computation as a Zenodo-ready reproducibility bundle."""
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        console.print("[red]Error:[/red] No command specified.")
        return 1

    source = args.source or "."
    actor = args.actor or "cli-user"
    intent = args.intent or f"Execute: {' '.join(command)}"
    output_path = args.output
    title = args.title or intent

    # Phase 1: Run in airlock
    console.print(f"\n[bold]AIRLOCK[/bold] Running computation...", style="blue")

    with Airlock(
        process_name=title,
        actor=actor,
        intent=intent,
    ) as airlock:
        workdir = airlock.prepare(source_dir=source)
        console.print(f"  Command: {' '.join(command)}", style="dim")
        console.print()

        result = airlock.execute(command, timeout=args.timeout)

        if result.success:
            console.print(f"  Exit: {result.exit_code} [green]OK[/green]")
        else:
            console.print(f"  Exit: {result.exit_code} [red]FAILED[/red]")

        if result.stdout.strip():
            console.print(Panel(
                result.stdout.strip()[-2000:],
                title="stdout",
                style="dim",
                expand=False,
            ))

        # Phase 2: Create replay bundle
        console.print()
        console.print("[bold]EXPORT[/bold] Creating replay bundle...", style="blue")

        replay = export_airlock(
            result=result,
            command=command,
            source_dir=source,
            include_source=True,  # Always self-contained for Zenodo
        )

    # Phase 3: Wrap in Zenodo bundle
    console.print("[bold]ZENODO[/bold] Building reproducibility bundle...", style="blue")

    authors = []
    if args.authors:
        authors = [a.strip() for a in args.authors.split(",")]

    zenodo = create_zenodo_bundle(
        replay_bundle=replay,
        title=title,
        authors=authors,
        description=args.description or "",
        keywords=args.keywords.split(",") if args.keywords else None,
        actor=actor,
    )

    save_zenodo_bundle(zenodo, output_path)

    env = zenodo.environment
    console.print(f"  Title:    {zenodo.title}")
    console.print(f"  Hash:     {zenodo.hash()}")
    console.print(f"  Machine:  {env.get('hostname', '?')}")
    console.print(f"  Python:   {env.get('python_version', '?')}")
    console.print(f"  Deps:     {len(zenodo.dependencies)} packages frozen")
    console.print(f"  Files:    {len(replay.source_hashes)} tracked")
    console.print(f"  Bundle:   {output_path}")
    console.print()

    console.print(Panel(
        f"Upload to Zenodo for a DOI, then anyone can reproduce:\n\n"
        f"  tibet-triage zenodo-reproduce {output_path}\n\n"
        f"The bundle contains the code, dependencies, environment,\n"
        f"and original results. TIBET provenance chain is embedded.",
        title="[bold]Reproducibility Bundle Ready[/bold]",
        style="green",
    ))

    return 0


def cmd_zenodo_reproduce(args: argparse.Namespace) -> int:
    """Reproduce a computation from a Zenodo TIBET bundle."""
    bundle_path = args.bundle_path
    override_source = args.source

    if not Path(bundle_path).exists():
        console.print(f"[red]Not found:[/red] {bundle_path}")
        return 1

    console.print(f"\n[bold]ZENODO[/bold] Loading reproducibility bundle...", style="blue")
    zenodo = load_zenodo_bundle(bundle_path)

    console.print(f"  Title:    {zenodo.title}")
    if zenodo.authors:
        console.print(f"  Authors:  {', '.join(zenodo.authors)}")
    console.print(f"  Created:  {zenodo.created_at}")
    console.print(f"  Hash:     {zenodo.hash()}")

    # Show environment comparison
    console.print()
    console.print("[bold]ENVIRONMENT[/bold] Comparing...", style="blue")

    orig_env = zenodo.environment
    local_env = capture_environment()

    env_table = Table(title="Environment Comparison")
    env_table.add_column("", style="bold")
    env_table.add_column("Original")
    env_table.add_column("This Machine")
    env_table.add_column("Match")

    checks = [
        ("Hostname", orig_env.get("hostname", "?"), local_env.get("hostname", "?")),
        ("Python", orig_env.get("python_version", "?"), local_env.get("python_version", "?")),
        ("OS", orig_env.get("os", "?"), local_env.get("os", "?")),
        ("Platform", orig_env.get("platform", "?")[:40], local_env.get("platform", "?")[:40]),
        ("Machine", orig_env.get("machine", "?"), local_env.get("machine", "?")),
        ("CPUs", str(orig_env.get("cpu_count", "?")), str(local_env.get("cpu_count", "?"))),
    ]

    for label, orig, local in checks:
        match = "[green]YES[/green]" if orig == local else "[yellow]DIFF[/yellow]"
        env_table.add_row(label, orig, local, Text.from_markup(match))

    console.print(env_table)
    console.print()

    # Show dependency info
    console.print(f"  Dependencies: {len(zenodo.dependencies)} packages in original")

    # Extract replay bundle and run it
    if not zenodo.replay:
        console.print("[red]Error:[/red] No replay data in bundle.")
        return 1

    # Save replay data to temp file, then replay
    import tempfile
    from .replay import ReplayBundle as RB

    replay_data = zenodo.replay
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as f:
        json.dump(replay_data, f)
        replay_path = f.name

    try:
        console.print()
        console.print("[bold]REPLAY[/bold] Reproducing computation...", style="blue")

        original, replay_result = replay_bundle(
            replay_path,
            override_source=override_source,
        )

        if replay_result.success:
            console.print(f"  Exit: {replay_result.exit_code} [green]OK[/green]")
        else:
            console.print(f"  Exit: {replay_result.exit_code} [red]FAILED[/red]")

        if replay_result.stdout.strip():
            console.print(Panel(
                replay_result.stdout.strip()[-2000:],
                title="stdout (reproduction)",
                style="dim",
                expand=False,
            ))

        # Compare
        console.print()
        console.print("[bold]VERIFY[/bold] Checking reproducibility...", style="blue")
        comparison = compare_results(original, replay_result)

        if comparison.is_isomorphic:
            console.print(Panel(
                comparison.summary() + f"\n\nTIBET Bundle Hash: {zenodo.hash()}",
                title=f"[green]REPRODUCIBLE[/green] — {zenodo.title}",
                style="green",
            ))
        else:
            score_pct = f"{comparison.divergence_score:.0%}"
            console.print(Panel(
                comparison.summary(),
                title=f"[red]NOT REPRODUCIBLE[/red] — {score_pct} divergence",
                style="red",
            ))

        return 0 if comparison.is_isomorphic else 3
    finally:
        Path(replay_path).unlink(missing_ok=True)


def cmd_upip_export(args: argparse.Namespace) -> int:
    """Export computation as a UPIP bundle (Universal Process Integrity Protocol)."""
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        console.print("[red]Error:[/red] No command specified.")
        return 1

    source = args.source or "."
    actor = args.actor or "cli-user"
    intent = args.intent or f"Execute: {' '.join(command)}"
    title = args.title or intent
    output_path = args.output

    # L1: STATE
    console.print(f"\n[bold]L1 STATE[/bold] Capturing starting state...", style="blue")
    state = StateCapture.from_directory(source, include_content=True)

    state_label = state.state_hash
    if state.state_type == "git" and state.git_commit:
        state_label = f"git:{state.git_commit[:12]}"
        if state.git_dirty:
            state_label += " [red](dirty)[/red]"
        console.print(f"  Type:   git")
        console.print(f"  Commit: {state.git_commit[:12]}")
        console.print(f"  Branch: {state.git_branch}")
        if state.git_remote:
            console.print(f"  Remote: {state.git_remote}")
        if state.git_dirty:
            console.print(f"  [red]WARNING: Uncommitted changes![/red]")
    else:
        console.print(f"  Type:   files")
    console.print(f"  Files:  {state.file_count}")
    console.print(f"  Hash:   {state.state_hash}")
    console.print()

    # L2: DEPS
    console.print("[bold]L2 DEPS[/bold] Freezing dependencies...", style="blue")
    deps = DepsCapture.from_pip()
    console.print(f"  Python: {deps.python_version}")
    console.print(f"  Packages: {len(deps.packages)}")
    console.print(f"  Hash:   {deps.deps_hash}")
    console.print()

    # L3: PROCESS
    console.print("[bold]L3 PROCESS[/bold] Defining process...", style="blue")
    console.print(f"  Command: {' '.join(command)}")
    console.print(f"  Intent:  {intent}")
    console.print()

    # Execute in airlock → L4: RESULT
    console.print("[bold]L4 RESULT[/bold] Executing in airlock...", style="blue")

    with Airlock(
        process_name=title,
        actor=actor,
        intent=intent,
    ) as airlock:
        if state.source_files:
            workdir = airlock.prepare(files=state.source_files)
        else:
            workdir = airlock.prepare(source_dir=source)

        airlock_result = airlock.execute(command, timeout=args.timeout)

    if airlock_result.success:
        console.print(f"  Exit: {airlock_result.exit_code} [green]OK[/green]")
    else:
        console.print(f"  Exit: {airlock_result.exit_code} [red]FAILED[/red]")

    if airlock_result.stdout.strip():
        console.print(Panel(
            airlock_result.stdout.strip()[-2000:],
            title="stdout",
            style="dim",
            expand=False,
        ))

    from .upip import ResultCapture
    result = ResultCapture.from_airlock(airlock_result)
    console.print(f"  Diff:   +{result.files_added} ~{result.files_changed} -{result.files_removed}")
    console.print(f"  Hash:   {result.result_hash}")
    console.print()

    # Build UPIP stack
    authors = []
    if args.authors:
        authors = [a.strip() for a in args.authors.split(",")]

    process_def = ProcessDef(
        command=command, intent=intent, actor=actor, timeout=args.timeout,
    )

    stack = UPIPStack(
        title=title,
        authors=authors,
        description=args.description or "",
        keywords=args.keywords.split(",") if args.keywords else ["reproducibility", "upip"],
        created_by=actor,
        state=state,
        deps=deps,
        process=process_def,
        result=result,
        source_files=state.source_files,
        tibet_chain=airlock_result.tibet_tokens,
    )
    stack._stdout = airlock_result.stdout
    stack._stderr = airlock_result.stderr
    stack._airlock_diff = airlock_result.diff.to_dict()

    stack.compute_hash()

    # Save
    save_upip(stack, output_path)

    console.print("[bold]L5 VERIFY[/bold] Ready for cross-machine verification", style="blue")
    console.print()

    console.print(Panel(
        f"UPIP Stack: {stack.stack_hash}\n\n"
        f"  L1 STATE:   {state.state_hash}\n"
        f"  L2 DEPS:    {deps.deps_hash}\n"
        f"  L3 PROCESS: {' '.join(command)}\n"
        f"  L4 RESULT:  {result.result_hash}\n"
        f"  L5 VERIFY:  (awaiting reproduction)\n\n"
        f"Reproduce anywhere:\n"
        f"  tibet-triage upip-reproduce {output_path}",
        title=f"[bold]UPIP — {title}[/bold]",
        style="green",
    ))

    return 0


def cmd_upip_reproduce(args: argparse.Namespace) -> int:
    """Reproduce a UPIP bundle on this machine."""
    bundle_path = args.bundle_path
    override_source = args.source

    if not Path(bundle_path).exists():
        console.print(f"[red]Not found:[/red] {bundle_path}")
        return 1

    console.print(f"\n[bold]UPIP[/bold] Loading bundle...", style="blue")
    stack = load_upip(bundle_path)

    console.print(f"  Title:    {stack.title}")
    if stack.authors:
        console.print(f"  Authors:  {', '.join(stack.authors)}")
    console.print(f"  Protocol: {stack.protocol} v{stack.protocol_version}")
    console.print(f"  Hash:     {stack.stack_hash}")
    console.print()

    # Show state comparison
    if stack.state:
        console.print("[bold]L1 STATE[/bold] Original state:", style="blue")
        console.print(f"  Type: {stack.state.state_type}")
        console.print(f"  Hash: {stack.state.state_hash}")
        if stack.state.git_commit:
            console.print(f"  Git:  {stack.state.git_commit[:12]} ({stack.state.git_branch})")
        console.print(f"  Files: {stack.state.file_count}")
        console.print()

    # Show deps comparison
    if stack.deps:
        console.print("[bold]L2 DEPS[/bold] Dependencies:", style="blue")
        console.print(f"  Python: {stack.deps.python_version} (original) vs {sys.version.split()[0]} (this)")
        console.print(f"  Packages: {len(stack.deps.packages)}")
        console.print()

    # Show process
    if stack.process:
        console.print("[bold]L3 PROCESS[/bold] Reproducing:", style="blue")
        console.print(f"  Command: {' '.join(stack.process.command)}")
        console.print()

    # Reproduce
    console.print("[bold]L4 RESULT[/bold] Executing...", style="blue")

    stack_orig, replay_result, verify = reproduce_upip(
        bundle_path, override_source=override_source,
    )

    if replay_result.success:
        console.print(f"  Exit: {replay_result.exit_code} [green]OK[/green]")
    else:
        console.print(f"  Exit: {replay_result.exit_code} [red]FAILED[/red]")

    if replay_result.stdout.strip():
        console.print(Panel(
            replay_result.stdout.strip()[-2000:],
            title="stdout (reproduction)",
            style="dim",
            expand=False,
        ))

    # Show environment diff
    console.print()
    console.print("[bold]L5 VERIFY[/bold] Verification result:", style="blue")

    env_table = Table(title="Environment")
    env_table.add_column("", style="bold")
    env_table.add_column("Original")
    env_table.add_column("This Machine")

    if stack.state:
        orig_env = {}
        if stack.deps:
            orig_env["Python"] = stack.deps.python_version
        # Use verify record environment
        local_env = verify.environment
        checks = [
            ("Hostname", stack.state.source_dir.split("/")[-1] if stack.state.source_dir else "?",
             local_env.get("hostname", "?")),
            ("Python", orig_env.get("Python", "?"), local_env.get("python_version", "?")),
            ("Machine", local_env.get("machine", "?"), local_env.get("machine", "?")),
        ]
        for label, orig, local in checks:
            env_table.add_row(label, orig, local)

    console.print(env_table)
    console.print()

    if verify.is_isomorphic:
        console.print(Panel(
            f"Exit code: {'MATCH' if verify.exit_code_match else 'MISMATCH'}\n"
            f"File diff: {'MATCH' if verify.diff_match else 'MISMATCH'}\n\n"
            f"UPIP Hash:  {stack.stack_hash}\n"
            f"Reproduced: {verify.machine} at {verify.verified_at}",
            title=f"[green]REPRODUCIBLE[/green] — {stack.title}",
            style="green",
        ))
    else:
        console.print(Panel(
            f"Exit code: {'MATCH' if verify.exit_code_match else 'MISMATCH'}\n"
            f"File diff: {'MATCH' if verify.diff_match else 'MISMATCH'}\n"
            f"Divergence: {verify.divergence_score:.0%}",
            title=f"[red]NOT REPRODUCIBLE[/red] — {stack.title}",
            style="red",
        ))

    # ── TRIAGE: write airlock outputs to disk? ───────────────
    airlock_outputs = getattr(replay_result, '_airlock_outputs', [])
    if airlock_outputs:
        console.print()
        console.print("[bold]TRIAGE[/bold] Airlock produced files:", style="yellow")
        file_table = Table()
        file_table.add_column("File", style="cyan")
        file_table.add_column("Size", justify="right")
        file_table.add_column("Target")
        for rel_path, content in airlock_outputs:
            target = Path.cwd() / rel_path
            file_table.add_row(
                Path(rel_path).name,
                f"{len(content):,} bytes",
                str(target),
            )
        console.print(file_table)

        if args.accept:
            approved = True
        else:
            console.print()
            answer = console.input(
                "[yellow]Write these files to disk? [Y/n][/yellow] "
            ).strip().lower()
            approved = answer in ("", "y", "yes")

        if approved:
            for rel_path, content in airlock_outputs:
                target = Path.cwd() / rel_path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
            console.print(
                f"[green]Wrote {len(airlock_outputs)} file(s) to disk.[/green]"
            )
        else:
            console.print("[dim]Files remain in airlock only. Nothing written.[/dim]")

    return 0 if verify.is_isomorphic else 3


def cmd_install_apply(args: argparse.Namespace) -> int:
    """Apply an approved install triage bundle (actually run pip install)."""
    try:
        chain = ApprovalChain.load(args.bundle_id)
    except FileNotFoundError:
        console.print(f"[red]Not found:[/red] {args.bundle_id}")
        return 1

    if chain.bundle.state != TriageState.APPROVED:
        console.print(
            f"[red]Cannot install:[/red] state is {chain.bundle.state.value}, "
            f"need approved"
        )
        return 1

    # Extract packages from the process name
    intent = chain.bundle.declared_intent
    if intent.startswith("pip install "):
        packages = intent[len("pip install "):].split()
    else:
        console.print(f"[red]Error:[/red] Not an install bundle: {intent}")
        return 1

    console.print(f"\n[bold]APPLY[/bold] Installing approved packages...", style="blue")
    console.print(f"  Packages: {' '.join(packages)}")
    console.print(f"  Approved by: {', '.join(a.operator_id for a in chain.bundle.approvals if a.decision == 'approve')}")
    console.print()

    import subprocess as sp
    cmd = [sys.executable, "-m", "pip", "install", "--no-input"]
    cmd.extend(packages)
    proc = sp.run(cmd, capture_output=True, text=True)

    if proc.returncode == 0:
        chain.bundle.state = TriageState.APPLIED
        chain._save()
        console.print("[green]Installed successfully.[/green]")
        return 0
    else:
        console.print(f"[red]Install failed:[/red] {proc.stderr.strip()[-500:]}")
        return 1


# --- Helpers ---

def _show_risk_assessment(bundle):
    """Display the risk assessment in a formatted panel."""
    risk = bundle.risk_score
    if not risk:
        return

    level_colors = {
        TriageLevel.L0_AUTO: "green",
        TriageLevel.L1_OPERATOR: "yellow",
        TriageLevel.L2_SENIOR: "red",
        TriageLevel.L3_CEREMONY: "bold red",
    }
    color = level_colors.get(risk.determined_level, "white")

    lines = [f"[{color}]{risk.determined_level.name}[/{color}]"]
    lines.append(
        f"Triggers: {risk.triggers_fired}/{risk.triggers_evaluated} fired, "
        f"weight: {risk.total_weight:.1f}"
    )

    fired = [r for r in risk.results if r.fired]
    if fired:
        lines.append("")
        for r in fired:
            lines.append(
                f"  [{r.trigger_type.value}] {r.rule_name} "
                f"(w:{r.weight:.1f} min:{r.min_level.name})"
            )
            if r.detail:
                lines.append(f"    {r.detail}")
    else:
        lines.append("[green]No triggers fired.[/green]")

    ar = bundle.airlock_result
    if ar and not ar.diff.is_empty:
        lines.append("")
        lines.append(
            f"Diff: {len(ar.diff.files_changed)} changed, "
            f"{len(ar.diff.files_added)} added, "
            f"{len(ar.diff.files_removed)} removed"
        )

    if ar and ar.side_effects:
        lines.append(f"Side effects: {len(ar.side_effects)}")
        irrev = sum(1 for s in ar.side_effects if not s.reversible)
        if irrev:
            lines.append(f"[red]  {irrev} IRREVERSIBLE[/red]")

    console.print(Panel(
        "\n".join(lines),
        title="Risk Assessment",
        style=color,
    ))


def _bundle_summary(bundle) -> str:
    """Minimal summary when airlock_result is not available."""
    return (
        f"Process:   {bundle.process_name}\n"
        f"Requested: {bundle.requested_by}\n"
        f"Level:     {bundle.triage_level.name}\n"
        f"State:     {bundle.state.value}\n"
        f"Approvals: {len(bundle.approvals)}/{int(bundle.triage_level)}\n"
    )


def _output_json(bundle):
    """Output evidence bundle as JSON."""
    console.print(json.dumps(bundle.to_dict(), indent=2))


def _output_install_json(tree, bundle):
    """Output install evidence as JSON (dep tree + risk bundle)."""
    data = {
        "dependency_tree": tree.to_dict(),
        "evidence": bundle.to_dict(),
    }
    console.print(json.dumps(data, indent=2))


def main():
    parser = argparse.ArgumentParser(
        prog="tibet-triage",
        description="Human-in-the-Loop as a discipline. "
                    "Airlock sandbox, risk-gated triage, TIBET provenance.",
    )
    sub = parser.add_subparsers(dest="command")

    # --- run ---
    p_run = sub.add_parser(
        "run", help="Run command in airlock sandbox",
        usage="tibet-triage run [options] -- <command...>",
    )
    p_run.add_argument("-s", "--source", help="Source directory to mirror")
    p_run.add_argument("-a", "--actor", help="Actor identity")
    p_run.add_argument("-i", "--intent", help="Declared intent")
    p_run.add_argument("-t", "--timeout", type=int, default=300,
                       help="Execution timeout in seconds")
    p_run.add_argument("--trust-score", type=int,
                       help="Override trust score (0-100)")
    p_run.add_argument("--rules", help="Path to custom rules JSON file")
    p_run.add_argument("--json", action="store_true",
                       help="Output evidence as JSON")
    p_run.add_argument("command", nargs=argparse.REMAINDER,
                       help="Command to execute (use -- before command)")
    p_run.set_defaults(func=cmd_run)

    # --- review ---
    p_review = sub.add_parser("review", help="Review pending triage bundle")
    p_review.add_argument("bundle_id", help="Evidence bundle ID")
    p_review.set_defaults(func=cmd_review)

    # --- approve ---
    p_approve = sub.add_parser("approve", help="Approve triage bundle")
    p_approve.add_argument("bundle_id", help="Evidence bundle ID")
    p_approve.add_argument("-o", "--operator", help="Operator identity")
    p_approve.add_argument("-r", "--reason", help="Approval reason")
    p_approve.set_defaults(func=cmd_approve)

    # --- reject ---
    p_reject = sub.add_parser("reject", help="Reject triage bundle")
    p_reject.add_argument("bundle_id", help="Evidence bundle ID")
    p_reject.add_argument("-o", "--operator", help="Operator identity")
    p_reject.add_argument("-r", "--reason", help="Rejection reason")
    p_reject.set_defaults(func=cmd_reject)

    # --- escalate ---
    p_esc = sub.add_parser("escalate", help="Escalate to higher level")
    p_esc.add_argument("bundle_id", help="Evidence bundle ID")
    p_esc.add_argument("-o", "--operator", help="Operator identity")
    p_esc.add_argument("-r", "--reason", help="Escalation reason")
    p_esc.set_defaults(func=cmd_escalate)

    # --- pending ---
    p_pending = sub.add_parser("pending", help="List pending triage items")
    p_pending.set_defaults(func=cmd_pending)

    # --- rules ---
    p_rules = sub.add_parser("rules", help="Show active trigger rules")
    p_rules.add_argument("--rules", help="Path to custom rules JSON file")
    p_rules.set_defaults(func=cmd_rules)

    # --- export ---
    p_export = sub.add_parser(
        "export", help="Export airlock result as replay bundle",
        usage="tibet-triage export [options] -- <command...>",
    )
    p_export.add_argument("-s", "--source", help="Source directory")
    p_export.add_argument("-o", "--output", required=True,
                          help="Output bundle file path")
    p_export.add_argument("-a", "--actor", help="Actor identity")
    p_export.add_argument("-i", "--intent", help="Declared intent")
    p_export.add_argument("-t", "--timeout", type=int, default=300)
    p_export.add_argument("--include-source", action="store_true",
                          help="Include file contents (self-contained bundle)")
    p_export.add_argument("command", nargs=argparse.REMAINDER)
    p_export.set_defaults(func=cmd_export)

    # --- replay ---
    p_replay = sub.add_parser("replay", help="Replay a bundle on this machine")
    p_replay.add_argument("bundle_path", help="Path to replay bundle JSON")
    p_replay.add_argument("-s", "--source", help="Override source directory")
    p_replay.set_defaults(func=cmd_replay)

    # --- install ---
    p_install = sub.add_parser(
        "install", help="Install packages through triage airlock",
        usage="tibet-triage install [options] <package...>",
    )
    p_install.add_argument("packages", nargs="*", help="Packages to install")
    p_install.add_argument("-a", "--actor", help="Actor identity")
    p_install.add_argument("--trust-score", type=int,
                           help="Override trust score (0-100)")
    p_install.add_argument("--upgrade", action="store_true",
                           help="Upgrade packages")
    p_install.add_argument("--extra-index", help="Extra PyPI index URL")
    p_install.add_argument("--dry-run", action="store_true",
                           help="Resolve and assess only, don't install")
    p_install.add_argument("--json", action="store_true",
                           help="Output evidence as JSON")
    p_install.set_defaults(func=cmd_install)

    # --- install-apply ---
    p_iapply = sub.add_parser(
        "install-apply", help="Apply approved install triage",
    )
    p_iapply.add_argument("bundle_id", help="Approved bundle ID")
    p_iapply.set_defaults(func=cmd_install_apply)

    # --- zenodo-export ---
    p_zen = sub.add_parser(
        "zenodo-export",
        help="Export computation as Zenodo reproducibility bundle",
        usage="tibet-triage zenodo-export [options] -- <command...>",
    )
    p_zen.add_argument("-s", "--source", help="Source directory")
    p_zen.add_argument("-o", "--output", required=True,
                       help="Output .tibet.json file")
    p_zen.add_argument("-a", "--actor", help="Actor identity")
    p_zen.add_argument("-i", "--intent", help="Declared intent")
    p_zen.add_argument("-t", "--timeout", type=int, default=300)
    p_zen.add_argument("--title", help="Publication title")
    p_zen.add_argument("--authors", help="Comma-separated author list")
    p_zen.add_argument("--description", help="Description")
    p_zen.add_argument("--keywords", help="Comma-separated keywords")
    p_zen.add_argument("command", nargs=argparse.REMAINDER)
    p_zen.set_defaults(func=cmd_zenodo_export)

    # --- zenodo-reproduce ---
    p_repro = sub.add_parser(
        "zenodo-reproduce",
        help="Reproduce computation from TIBET bundle",
    )
    p_repro.add_argument("bundle_path", help="Path to .tibet.json bundle")
    p_repro.add_argument("-s", "--source", help="Override source directory")
    p_repro.set_defaults(func=cmd_zenodo_reproduce)

    # --- upip-export ---
    p_upip = sub.add_parser(
        "upip-export",
        help="Export UPIP bundle (Universal Process Integrity Protocol)",
        usage="tibet-triage upip-export [options] -- <command...>",
    )
    p_upip.add_argument("-s", "--source", help="Source directory")
    p_upip.add_argument("-o", "--output", required=True,
                        help="Output .upip.json file")
    p_upip.add_argument("-a", "--actor", help="Actor identity")
    p_upip.add_argument("-i", "--intent", help="Declared intent")
    p_upip.add_argument("-t", "--timeout", type=int, default=300)
    p_upip.add_argument("--title", help="Title")
    p_upip.add_argument("--authors", help="Comma-separated authors")
    p_upip.add_argument("--description", help="Description")
    p_upip.add_argument("--keywords", help="Comma-separated keywords")
    p_upip.add_argument("command", nargs=argparse.REMAINDER)
    p_upip.set_defaults(func=cmd_upip_export)

    # --- upip-reproduce ---
    p_urepro = sub.add_parser(
        "upip-reproduce",
        help="Reproduce UPIP bundle on this machine",
    )
    p_urepro.add_argument("bundle_path", help="Path to .upip.json bundle")
    p_urepro.add_argument("-s", "--source", help="Override source directory")
    p_urepro.add_argument("-y", "--accept", action="store_true",
                          help="Auto-accept writing output files to disk (skip triage)")
    p_urepro.set_defaults(func=cmd_upip_reproduce)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main() or 0)
