"""
Core models for tibet-triage.

Every concept maps to a compliance requirement.
Every field has a reason to exist.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, IntEnum
from typing import Any, Optional


class TriageLevel(IntEnum):
    """
    Triage severity levels.

    Higher level = more human oversight required.
    The number IS the minimum number of human approvals needed.
    """
    L0_AUTO = 0    # Auto-clear: no human needed
    L1_OPERATOR = 1  # One operator, async
    L2_SENIOR = 2    # Senior + co-signer, sync
    L3_CEREMONY = 3  # Out-of-band, physical presence


class TriageState(str, Enum):
    """State machine for a triage request."""
    PENDING = "pending"           # Airlock running
    AWAITING_TRIAGE = "awaiting"  # Risk gate assigned level, waiting for human
    APPROVED = "approved"         # All required approvals received
    REJECTED = "rejected"         # Explicitly rejected by operator
    ESCALATED = "escalated"       # Escalated to higher level
    EXPIRED = "expired"           # Timed out without decision (= reject)
    APPLIED = "applied"           # Diff applied to production


class TriggerType(str, Enum):
    """Categories of triage triggers."""
    TRUST_SCORE = "trust_score"          # tibet-forge score below threshold
    INTENT_MISMATCH = "intent_mismatch"  # Declared vs actual actions differ
    CAPABILITY_BREACH = "capability"     # Action exceeds actor's level
    PROCESS_DEVIATION = "deviation"      # tibet-pol step deviates from expected
    SYSTEM_CRITICAL = "system_critical"  # Touches flagged resources
    PUBLICATION_GATE = "publication"     # Anything leaving system boundary
    CUSTOM = "custom"                    # User-defined rule


@dataclass
class TriggerRule:
    """
    A rule that determines when triage is needed.

    Rules are evaluated against the airlock result.
    If the condition fires, the rule contributes its weight
    toward the triage level calculation.
    """
    name: str
    trigger_type: TriggerType
    condition: str  # Python expression evaluated against context
    weight: float = 1.0  # How much this trigger contributes (0.0-10.0)
    min_level: TriageLevel = TriageLevel.L1_OPERATOR  # Minimum level if fired
    description: str = ""

    def evaluate(self, context: dict[str, Any]) -> TriggerResult:
        """
        Evaluate this rule against a context dict.

        Context contains airlock results, trust scores, process state, etc.
        Returns a TriggerResult indicating whether the trigger fired.
        """
        try:
            fired = bool(eval(self.condition, {"__builtins__": {}}, context))
        except Exception:
            # If evaluation fails, trigger fires (fail-closed)
            fired = True

        return TriggerResult(
            rule_name=self.name,
            trigger_type=self.trigger_type,
            fired=fired,
            weight=self.weight if fired else 0.0,
            min_level=self.min_level if fired else TriageLevel.L0_AUTO,
            detail=self.description if fired else "",
        )


@dataclass
class TriggerResult:
    """Result of evaluating a single trigger rule."""
    rule_name: str
    trigger_type: TriggerType
    fired: bool
    weight: float
    min_level: TriageLevel
    detail: str = ""


@dataclass
class RiskScore:
    """
    Composite risk assessment from all trigger evaluations.

    Determines the triage level based on:
    1. Highest min_level from any fired trigger
    2. Combined weight (can escalate level)
    3. Explicit thresholds from configuration
    """
    triggers_evaluated: int = 0
    triggers_fired: int = 0
    total_weight: float = 0.0
    max_level: TriageLevel = TriageLevel.L0_AUTO
    results: list[TriggerResult] = field(default_factory=list)
    determined_level: TriageLevel = TriageLevel.L0_AUTO

    # Weight thresholds for automatic escalation
    L1_THRESHOLD: float = 1.0
    L2_THRESHOLD: float = 5.0
    L3_THRESHOLD: float = 10.0

    def add_result(self, result: TriggerResult):
        """Add a trigger result and recalculate risk."""
        self.results.append(result)
        self.triggers_evaluated += 1
        if result.fired:
            self.triggers_fired += 1
            self.total_weight += result.weight
            if result.min_level > self.max_level:
                self.max_level = result.min_level
        self._recalculate()

    def _recalculate(self):
        """Determine triage level from combined results."""
        # Start with the highest explicit level from triggers
        level = self.max_level

        # Weight-based escalation can push higher
        if self.total_weight >= self.L3_THRESHOLD:
            level = max(level, TriageLevel.L3_CEREMONY)
        elif self.total_weight >= self.L2_THRESHOLD:
            level = max(level, TriageLevel.L2_SENIOR)
        elif self.total_weight >= self.L1_THRESHOLD:
            level = max(level, TriageLevel.L1_OPERATOR)

        self.determined_level = level

    @property
    def is_clear(self) -> bool:
        """True if no triage needed (auto-approve)."""
        return self.determined_level == TriageLevel.L0_AUTO

    def summary(self) -> str:
        """Human-readable risk summary."""
        fired = [r for r in self.results if r.fired]
        if not fired:
            return "CLEAR — No triggers fired. Auto-approve eligible."

        lines = [
            f"TRIAGE {self.determined_level.name} — "
            f"{self.triggers_fired}/{self.triggers_evaluated} triggers fired, "
            f"weight {self.total_weight:.1f}",
            "",
        ]
        for r in fired:
            lines.append(f"  [{r.trigger_type.value}] {r.rule_name} "
                         f"(weight: {r.weight:.1f}, min: {r.min_level.name})")
            if r.detail:
                lines.append(f"    {r.detail}")
        return "\n".join(lines)


@dataclass
class SideEffect:
    """A recorded side effect from airlock execution."""
    effect_type: str  # "file_write", "http_request", "process_exec", "env_change"
    target: str  # Path, URL, process name, variable name
    detail: str = ""  # Method, size, arguments, etc.
    reversible: bool = True  # Can this be undone?


@dataclass
class StateDiff:
    """
    Diff between pre-execution and post-execution state.

    This is what the operator reviews. Deterministic, complete.
    """
    files_changed: list[dict[str, Any]] = field(default_factory=list)
    files_added: list[str] = field(default_factory=list)
    files_removed: list[str] = field(default_factory=list)
    env_changes: dict[str, tuple[str, str]] = field(default_factory=dict)  # key -> (old, new)
    total_lines_added: int = 0
    total_lines_removed: int = 0

    @property
    def is_empty(self) -> bool:
        return (not self.files_changed and not self.files_added
                and not self.files_removed and not self.env_changes)

    def hash(self) -> str:
        """Deterministic hash of the diff for signing."""
        content = json.dumps(self.to_dict(), sort_keys=True)
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"

    def to_dict(self) -> dict:
        return {
            "files_changed": self.files_changed,
            "files_added": self.files_added,
            "files_removed": self.files_removed,
            "env_changes": {k: list(v) for k, v in self.env_changes.items()},
            "total_lines_added": self.total_lines_added,
            "total_lines_removed": self.total_lines_removed,
        }


@dataclass
class AirlockResult:
    """
    Complete result of airlock sandbox execution.

    Contains everything needed for triage: what happened,
    what changed, what side effects occurred, and the full
    TIBET token chain.
    """
    airlock_id: str
    process_name: str
    started_at: str = ""
    completed_at: str = ""
    success: bool = False
    exit_code: int = -1

    # What happened
    tibet_tokens: list[dict[str, Any]] = field(default_factory=list)
    side_effects: list[SideEffect] = field(default_factory=list)

    # What changed
    diff: StateDiff = field(default_factory=StateDiff)

    # Execution context
    environment: str = "airlock"  # Always "airlock" until applied
    actor: str = ""
    declared_intent: str = ""
    stdout: str = ""
    stderr: str = ""

    def __post_init__(self):
        if not self.started_at:
            self.started_at = datetime.utcnow().isoformat() + "Z"

    def hash(self) -> str:
        """Hash of the complete airlock result for evidence signing."""
        content = json.dumps({
            "airlock_id": self.airlock_id,
            "process_name": self.process_name,
            "success": self.success,
            "diff_hash": self.diff.hash(),
            "token_count": len(self.tibet_tokens),
            "side_effect_count": len(self.side_effects),
        }, sort_keys=True)
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"


@dataclass
class Approval:
    """A single approval decision by a human operator."""
    operator_id: str  # JIS identity
    level: TriageLevel
    decision: str  # "approve", "reject", "escalate"
    timestamp: str = ""
    reason: str = ""
    signature: str = ""  # Cryptographic signature over evidence bundle hash

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.utcnow().isoformat() + "Z"


@dataclass
class EvidenceBundle:
    """
    Complete evidence package presented to the triage operator.

    Immutable after creation. Signed for tamper detection.
    This is the single source of truth for the triage decision.
    """
    bundle_id: str
    created_at: str = ""

    # What was requested
    process_name: str = ""
    requested_by: str = ""
    declared_intent: str = ""

    # What the airlock found
    airlock_result: Optional[AirlockResult] = None
    risk_score: Optional[RiskScore] = None

    # Triage assignment
    triage_level: TriageLevel = TriageLevel.L0_AUTO
    state: TriageState = TriageState.PENDING

    # Approvals collected
    approvals: list[Approval] = field(default_factory=list)

    # Timing
    deadline: str = ""  # ISO timestamp, after which auto-reject
    applied_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat() + "Z"

    def hash(self) -> str:
        """
        Deterministic hash of the evidence.

        This is what operators sign. Changing any evidence
        invalidates all signatures.
        """
        content = json.dumps({
            "bundle_id": self.bundle_id,
            "process_name": self.process_name,
            "requested_by": self.requested_by,
            "airlock_hash": self.airlock_result.hash() if self.airlock_result else "",
            "risk_summary": self.risk_score.summary() if self.risk_score else "",
            "triage_level": self.triage_level.value,
        }, sort_keys=True)
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"

    @property
    def approvals_needed(self) -> int:
        """How many approvals still needed."""
        needed = int(self.triage_level)  # L0=0, L1=1, L2=2, L3=3
        got = sum(1 for a in self.approvals if a.decision == "approve")
        return max(0, needed - got)

    @property
    def is_approved(self) -> bool:
        """True if all required approvals are in."""
        return self.approvals_needed == 0 and self.triage_level >= TriageLevel.L0_AUTO

    @property
    def is_rejected(self) -> bool:
        return any(a.decision == "reject" for a in self.approvals)

    def add_approval(self, approval: Approval) -> TriageState:
        """
        Add an approval and update state.

        Returns the new state after this approval.
        """
        self.approvals.append(approval)

        if approval.decision == "reject":
            self.state = TriageState.REJECTED
        elif approval.decision == "escalate":
            self.triage_level = TriageLevel(min(
                self.triage_level + 1,
                TriageLevel.L3_CEREMONY
            ))
            self.state = TriageState.ESCALATED
        elif approval.decision == "approve":
            if self.approvals_needed == 0:
                self.state = TriageState.APPROVED
            # else still awaiting more approvals

        return self.state

    def summary(self) -> str:
        """Human-readable evidence summary for the triage operator."""
        lines = [
            f"=== TRIAGE EVIDENCE: {self.bundle_id} ===",
            f"Process:   {self.process_name}",
            f"Requested: {self.requested_by}",
            f"Intent:    {self.declared_intent}",
            f"Level:     {self.triage_level.name}",
            f"State:     {self.state.value}",
            f"Approvals: {len(self.approvals)}/{int(self.triage_level)} needed",
            "",
        ]

        if self.risk_score:
            lines.append("--- Risk Assessment ---")
            lines.append(self.risk_score.summary())
            lines.append("")

        if self.airlock_result:
            ar = self.airlock_result
            lines.append("--- Airlock Result ---")
            lines.append(f"Success: {ar.success} (exit: {ar.exit_code})")
            lines.append(f"TIBET tokens: {len(ar.tibet_tokens)}")
            lines.append(f"Side effects: {len(ar.side_effects)}")

            if not ar.diff.is_empty:
                lines.append("")
                lines.append("--- State Diff ---")
                d = ar.diff
                lines.append(f"Files changed: {len(d.files_changed)}")
                lines.append(f"Files added:   {len(d.files_added)}")
                lines.append(f"Files removed: {len(d.files_removed)}")
                lines.append(f"Lines: +{d.total_lines_added} -{d.total_lines_removed}")

            if ar.side_effects:
                lines.append("")
                lines.append("--- Side Effects ---")
                for se in ar.side_effects:
                    rev = "reversible" if se.reversible else "IRREVERSIBLE"
                    lines.append(f"  [{se.effect_type}] {se.target} ({rev})")
                    if se.detail:
                        lines.append(f"    {se.detail}")

        lines.append("")
        lines.append(f"Evidence hash: {self.hash()}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Serialize to dict for storage/transport."""
        return {
            "bundle_id": self.bundle_id,
            "created_at": self.created_at,
            "process_name": self.process_name,
            "requested_by": self.requested_by,
            "declared_intent": self.declared_intent,
            "triage_level": self.triage_level.value,
            "state": self.state.value,
            "risk_score": {
                "triggers_fired": self.risk_score.triggers_fired,
                "total_weight": self.risk_score.total_weight,
                "determined_level": self.risk_score.determined_level.value,
                "summary": self.risk_score.summary(),
            } if self.risk_score else None,
            "airlock": {
                "airlock_id": self.airlock_result.airlock_id,
                "success": self.airlock_result.success,
                "diff_hash": self.airlock_result.diff.hash(),
                "token_count": len(self.airlock_result.tibet_tokens),
                "side_effects": len(self.airlock_result.side_effects),
            } if self.airlock_result else None,
            "approvals": [
                {
                    "operator": a.operator_id,
                    "decision": a.decision,
                    "timestamp": a.timestamp,
                    "reason": a.reason,
                }
                for a in self.approvals
            ],
            "evidence_hash": self.hash(),
            "deadline": self.deadline,
        }
