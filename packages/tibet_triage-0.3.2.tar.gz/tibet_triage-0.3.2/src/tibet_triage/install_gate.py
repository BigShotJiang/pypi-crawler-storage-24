"""
Install Gate — Dependency triage through the airlock.

Runs `pip install` in an isolated airlock, captures the full
dependency tree, checks each package, and presents evidence
for human approval before anything touches the real system.

This is the "ultimate triage": you don't just approve the action,
you approve every dependency that comes with it.

Usage:
    tibet-triage install flask --actor jasper@humotica.com

    # Shows:
    #   flask 3.1.0 (MIT, score: 92, 14 deps)
    #   ├── werkzeug 3.1.0 (BSD-3, score: 88)
    #   ├── jinja2 3.1.4 (BSD-3, score: 90)
    #   │   └── markupsafe 3.0.2 (BSD-3, score: 85)
    #   ├── itsdangerous 2.2.0 (BSD-3, score: 82)
    #   ├── click 8.1.7 (BSD-3, score: 87)
    #   └── blinker 1.9.0 (MIT, score: 78)
    #
    #   Risk: L0 AUTO (all deps trusted)
    #   Files: 847 will be installed
    #   Total size: 12.3 MB
    #
    # Approve? [Y/n]
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from .airlock import Airlock
from .models import (
    AirlockResult,
    SideEffect,
    TriageLevel,
)
from .risk_gate import RiskGate


@dataclass
class DepInfo:
    """Information about a single dependency."""
    name: str
    version: str = ""
    required_by: str = ""  # Parent package that requires this
    license: str = ""
    homepage: str = ""
    summary: str = ""
    pypi_score: int = -1  # -1 = not checked
    is_new: bool = True  # Not already installed
    is_direct: bool = False  # Directly requested by user


@dataclass
class DepTree:
    """Full dependency tree for an install operation."""
    requested: list[str] = field(default_factory=list)  # What user asked to install
    resolved: list[DepInfo] = field(default_factory=list)  # Full resolved tree
    already_installed: list[str] = field(default_factory=list)  # Already present
    will_install: list[str] = field(default_factory=list)  # New packages
    will_upgrade: list[str] = field(default_factory=list)  # Version changes
    total_download_size: str = ""
    errors: list[str] = field(default_factory=list)

    @property
    def new_count(self) -> int:
        return len(self.will_install)

    @property
    def total_count(self) -> int:
        return len(self.resolved)

    def to_dict(self) -> dict:
        return {
            "requested": self.requested,
            "resolved": [
                {
                    "name": d.name,
                    "version": d.version,
                    "required_by": d.required_by,
                    "license": d.license,
                    "is_new": d.is_new,
                    "is_direct": d.is_direct,
                }
                for d in self.resolved
            ],
            "already_installed": self.already_installed,
            "will_install": self.will_install,
            "will_upgrade": self.will_upgrade,
            "total_download_size": self.total_download_size,
            "errors": self.errors,
        }


def resolve_dependencies(
    packages: list[str],
    pip_args: Optional[list[str]] = None,
) -> DepTree:
    """
    Resolve the full dependency tree for a pip install without actually installing.

    Uses `pip install --dry-run --report` to get the complete resolution
    without touching the filesystem.
    """
    tree = DepTree(requested=packages)

    # Get what's currently installed
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--format=json"],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            installed = {
                p["name"].lower(): p["version"]
                for p in json.loads(result.stdout)
            }
        else:
            installed = {}
    except Exception:
        installed = {}

    # Dry-run the install with report
    cmd = [
        sys.executable, "-m", "pip", "install",
        "--dry-run", "--report", "-",
        "--quiet",
    ]
    if pip_args:
        cmd.extend(pip_args)
    cmd.extend(packages)

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            tree.errors.append(f"pip resolve failed: {result.stderr.strip()[-500:]}")
            return tree

        report = json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        tree.errors.append("Dependency resolution timed out")
        return tree
    except json.JSONDecodeError:
        tree.errors.append("Could not parse pip report")
        return tree
    except Exception as e:
        tree.errors.append(f"Resolve error: {e}")
        return tree

    # Parse the install report
    for item in report.get("install", []):
        meta = item.get("metadata", {})
        name = meta.get("name", "")
        version = meta.get("version", "")
        name_lower = name.lower()

        is_direct = item.get("is_direct", False)
        is_new = name_lower not in installed
        is_upgrade = (
            not is_new
            and installed.get(name_lower, "") != version
        )

        dep = DepInfo(
            name=name,
            version=version,
            license=meta.get("license", ""),
            summary=meta.get("summary", ""),
            homepage=meta.get("home_page", ""),
            is_new=is_new,
            is_direct=is_direct,
            required_by=item.get("requested_extras", ""),
        )
        tree.resolved.append(dep)

        if is_new:
            tree.will_install.append(f"{name}=={version}")
        elif is_upgrade:
            old = installed.get(name_lower, "?")
            tree.will_upgrade.append(f"{name}: {old} -> {version}")
        else:
            tree.already_installed.append(f"{name}=={version}")

    # Estimate download size from report
    total_bytes = 0
    for item in report.get("install", []):
        dl = item.get("download_info", {})
        if "archive_info" in dl:
            total_bytes += dl.get("archive_info", {}).get("size", 0)
    if total_bytes > 0:
        if total_bytes > 1_000_000:
            tree.total_download_size = f"{total_bytes / 1_000_000:.1f} MB"
        else:
            tree.total_download_size = f"{total_bytes / 1000:.0f} KB"

    return tree


def install_in_airlock(
    packages: list[str],
    pip_args: Optional[list[str]] = None,
    actor: str = "cli-user",
    target: Optional[str] = None,
) -> tuple[DepTree, AirlockResult]:
    """
    Run pip install inside the airlock.

    Performs the actual install in an isolated temp venv,
    captures all file changes, and returns the evidence.

    If target is specified, uses --target to install to a specific dir.
    """
    intent = f"pip install {' '.join(packages)}"

    # Build the pip command
    pip_cmd = [sys.executable, "-m", "pip", "install", "--no-input"]
    if target:
        pip_cmd.extend(["--target", target])
    if pip_args:
        pip_cmd.extend(pip_args)
    pip_cmd.extend(packages)

    # Resolve first (dry run)
    tree = resolve_dependencies(packages, pip_args=pip_args)

    # Now run in airlock
    with Airlock(
        process_name=intent,
        actor=actor,
        intent=intent,
    ) as airlock:
        workdir = airlock.prepare()

        # Install into airlock workdir as target
        install_cmd = [
            sys.executable, "-m", "pip", "install",
            "--target", str(workdir),
            "--no-input", "--quiet",
        ]
        if pip_args:
            install_cmd.extend(pip_args)
        install_cmd.extend(packages)

        result = airlock.execute(install_cmd)

        # Add dep tree info as side effects for risk gate visibility
        for dep in tree.resolved:
            if dep.is_new:
                result.side_effects.append(SideEffect(
                    effect_type="package_install",
                    target=f"{dep.name}=={dep.version}",
                    detail=f"License: {dep.license or 'unknown'}",
                    reversible=True,
                ))

    return tree, result


def check_pypi_metadata(package_name: str) -> dict[str, Any]:
    """
    Quick check of PyPI metadata for a package.

    Returns basic trust signals: age, downloads, maintainers, etc.
    """
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", package_name],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return {"error": "not installed"}

        info = {}
        for line in result.stdout.split("\n"):
            if ": " in line:
                key, val = line.split(": ", 1)
                info[key.strip().lower()] = val.strip()
        return info
    except Exception as e:
        return {"error": str(e)}
