"""
Risk Gate — Automatic triage level determination.

Evaluates trigger rules against airlock results to determine
what level of human oversight is required.

The risk gate is the decision engine. It doesn't approve or reject —
it classifies. The classification determines who needs to look at this.

Default rules cover common compliance scenarios.
Custom rules can be added for domain-specific requirements.
"""

from __future__ import annotations

from typing import Any, Optional

from .models import (
    AirlockResult,
    EvidenceBundle,
    RiskScore,
    TriageLevel,
    TriageState,
    TriggerRule,
    TriggerType,
)


# =============================================================================
# Default trigger rules
# =============================================================================

DEFAULT_RULES: list[TriggerRule] = [
    # Trust score triggers
    TriggerRule(
        name="trust_critical",
        trigger_type=TriggerType.TRUST_SCORE,
        condition="trust_score < 25",
        weight=5.0,
        min_level=TriageLevel.L2_SENIOR,
        description="Trust score critically low — dual review required",
    ),
    TriggerRule(
        name="trust_low",
        trigger_type=TriggerType.TRUST_SCORE,
        condition="trust_score < 50",
        weight=2.0,
        min_level=TriageLevel.L1_OPERATOR,
        description="Trust score below acceptable threshold",
    ),
    TriggerRule(
        name="trust_moderate",
        trigger_type=TriggerType.TRUST_SCORE,
        condition="trust_score < 85",
        weight=0.5,
        min_level=TriageLevel.L0_AUTO,
        description="Trust score below auto-approve threshold",
    ),

    # Process outcome triggers
    TriggerRule(
        name="process_failed",
        trigger_type=TriggerType.PROCESS_DEVIATION,
        condition="not process_success",
        weight=3.0,
        min_level=TriageLevel.L1_OPERATOR,
        description="Process execution failed in airlock",
    ),
    TriggerRule(
        name="large_diff",
        trigger_type=TriggerType.PROCESS_DEVIATION,
        condition="files_changed > 20",
        weight=2.0,
        min_level=TriageLevel.L1_OPERATOR,
        description="Large number of files changed — review scope",
    ),
    TriggerRule(
        name="files_deleted",
        trigger_type=TriggerType.PROCESS_DEVIATION,
        condition="files_removed > 0",
        weight=2.0,
        min_level=TriageLevel.L1_OPERATOR,
        description="Files were deleted — verify intentional",
    ),

    # Side effect triggers
    TriggerRule(
        name="irreversible_effects",
        trigger_type=TriggerType.SYSTEM_CRITICAL,
        condition="irreversible_effects > 0",
        weight=4.0,
        min_level=TriageLevel.L2_SENIOR,
        description="Irreversible side effects detected — senior review",
    ),
    TriggerRule(
        name="many_side_effects",
        trigger_type=TriggerType.PROCESS_DEVIATION,
        condition="side_effect_count > 10",
        weight=1.5,
        min_level=TriageLevel.L1_OPERATOR,
        description="High number of side effects — review scope",
    ),

    # Publication triggers
    TriggerRule(
        name="external_publish",
        trigger_type=TriggerType.PUBLICATION_GATE,
        condition="has_external_effects",
        weight=3.0,
        min_level=TriageLevel.L1_OPERATOR,
        description="Process produces external effects (network, publish)",
    ),

    # Capability triggers
    TriggerRule(
        name="elevated_capability",
        trigger_type=TriggerType.CAPABILITY_BREACH,
        condition="capability_exceeded",
        weight=5.0,
        min_level=TriageLevel.L2_SENIOR,
        description="Action exceeds declared capability level",
    ),
]


class RiskGate:
    """
    Evaluates trigger rules and determines triage level.

    The risk gate takes an airlock result and optional context,
    runs all trigger rules, and produces a RiskScore with the
    determined triage level.

    Usage:
        gate = RiskGate()
        gate.add_rule(custom_rule)
        evidence = gate.evaluate(airlock_result, context={"trust_score": 72})
    """

    def __init__(
        self,
        rules: Optional[list[TriggerRule]] = None,
        include_defaults: bool = True,
    ):
        self.rules: list[TriggerRule] = []
        if include_defaults:
            self.rules.extend(DEFAULT_RULES)
        if rules:
            self.rules.extend(rules)

    def add_rule(self, rule: TriggerRule):
        """Add a custom trigger rule."""
        self.rules.append(rule)

    def evaluate(
        self,
        airlock_result: AirlockResult,
        context: Optional[dict[str, Any]] = None,
        bundle_id: Optional[str] = None,
    ) -> EvidenceBundle:
        """
        Evaluate all rules against the airlock result.

        Builds the evaluation context from the airlock result,
        merges with any provided context, runs all trigger rules,
        and packages everything into an EvidenceBundle.

        Returns a complete EvidenceBundle ready for triage.
        """
        import uuid

        # Build evaluation context from airlock result
        eval_context = self._build_context(airlock_result)
        if context:
            eval_context.update(context)

        # Evaluate all rules
        risk_score = RiskScore()
        for rule in self.rules:
            result = rule.evaluate(eval_context)
            risk_score.add_result(result)

        # Package into evidence bundle
        bid = bundle_id or f"triage-{uuid.uuid4().hex[:12]}"
        bundle = EvidenceBundle(
            bundle_id=bid,
            process_name=airlock_result.process_name,
            requested_by=airlock_result.actor,
            declared_intent=airlock_result.declared_intent,
            airlock_result=airlock_result,
            risk_score=risk_score,
            triage_level=risk_score.determined_level,
            state=(
                TriageState.APPROVED
                if risk_score.is_clear
                else TriageState.AWAITING_TRIAGE
            ),
        )

        return bundle

    @staticmethod
    def _build_context(result: AirlockResult) -> dict[str, Any]:
        """
        Build evaluation context dict from an AirlockResult.

        This is what trigger rule conditions are evaluated against.
        """
        irreversible = sum(
            1 for se in result.side_effects if not se.reversible
        )
        has_external = any(
            se.effect_type in ("http_request", "dns_lookup", "publish")
            for se in result.side_effects
        )

        return {
            # Process outcome
            "process_success": result.success,
            "exit_code": result.exit_code,

            # Diff metrics
            "files_changed": len(result.diff.files_changed),
            "files_added": len(result.diff.files_added),
            "files_removed": len(result.diff.files_removed),
            "lines_added": result.diff.total_lines_added,
            "lines_removed": result.diff.total_lines_removed,
            "diff_empty": result.diff.is_empty,

            # Side effects
            "side_effect_count": len(result.side_effects),
            "irreversible_effects": irreversible,
            "has_external_effects": has_external,

            # TIBET chain
            "token_count": len(result.tibet_tokens),

            # Defaults for optional context (can be overridden)
            "trust_score": 100,  # Assume trusted unless told otherwise
            "capability_exceeded": False,
            "intent_match": 1.0,
        }


def load_rules_from_file(path: str) -> list[TriggerRule]:
    """
    Load custom trigger rules from a JSON file.

    Format:
    [
        {
            "name": "my_rule",
            "trigger_type": "custom",
            "condition": "files_changed > 5",
            "weight": 2.0,
            "min_level": 1,
            "description": "Too many files changed"
        }
    ]
    """
    import json
    from pathlib import Path as P

    rules = []
    data = json.loads(P(path).read_text())

    for item in data:
        rules.append(TriggerRule(
            name=item["name"],
            trigger_type=TriggerType(item.get("trigger_type", "custom")),
            condition=item["condition"],
            weight=item.get("weight", 1.0),
            min_level=TriageLevel(item.get("min_level", 1)),
            description=item.get("description", ""),
        ))

    return rules
