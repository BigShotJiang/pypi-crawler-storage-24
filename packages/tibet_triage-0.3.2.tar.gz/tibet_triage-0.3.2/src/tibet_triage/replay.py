"""
Replay — Cross-machine process reproducibility.

Export an airlock execution as a portable bundle,
replay it on another machine, compare the diffs.

If the diffs are isomorphic: the process is reproducibly proven.
If they diverge: the environment caused different behavior.

This is CERN-level process integrity on your own hardware.

Usage:
    # On machine A (DL360):
    bundle = export_airlock(airlock_result, include_source=True)
    save_bundle(bundle, "/tmp/replay-bundle.json")

    # Transfer to machine B (P520):
    scp /tmp/replay-bundle.json p520:/tmp/

    # On machine B:
    original, replay = replay_bundle("/tmp/replay-bundle.json")
    comparison = compare_results(original, replay)
    print(comparison.summary())
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .airlock import Airlock
from .models import AirlockResult, StateDiff


@dataclass
class ReplayBundle:
    """
    Portable airlock execution bundle for cross-machine replay.

    Contains everything needed to reproduce an execution:
    - The command that was run
    - The source files (hashes + optional content)
    - The original environment
    - The original result for comparison
    """
    bundle_version: int = 1
    created_at: str = ""
    source_machine: str = ""

    # What to replay
    process_name: str = ""
    command: list[str] = field(default_factory=list)
    intent: str = ""
    actor: str = ""
    timeout: int = 300

    # Source files (path -> content for replay)
    source_files: dict[str, str] = field(default_factory=dict)
    # Source file hashes (path -> hash, always present)
    source_hashes: dict[str, str] = field(default_factory=dict)

    # Environment variables to replicate
    env_vars: dict[str, str] = field(default_factory=dict)

    # Original result for comparison
    original_diff: Optional[dict] = None
    original_success: bool = False
    original_exit_code: int = -1
    original_token_count: int = 0
    original_airlock_id: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat() + "Z"

    def hash(self) -> str:
        """Deterministic hash of the replay bundle."""
        content = json.dumps({
            "process_name": self.process_name,
            "command": self.command,
            "source_hashes": self.source_hashes,
            "env_vars": sorted(self.env_vars.items()),
        }, sort_keys=True)
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"

    def to_dict(self) -> dict:
        return {
            "bundle_version": self.bundle_version,
            "created_at": self.created_at,
            "source_machine": self.source_machine,
            "process_name": self.process_name,
            "command": self.command,
            "intent": self.intent,
            "actor": self.actor,
            "timeout": self.timeout,
            "source_files": self.source_files,
            "source_hashes": self.source_hashes,
            "env_vars": self.env_vars,
            "original_diff": self.original_diff,
            "original_success": self.original_success,
            "original_exit_code": self.original_exit_code,
            "original_token_count": self.original_token_count,
            "original_airlock_id": self.original_airlock_id,
            "bundle_hash": self.hash(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> ReplayBundle:
        return cls(
            bundle_version=data.get("bundle_version", 1),
            created_at=data.get("created_at", ""),
            source_machine=data.get("source_machine", ""),
            process_name=data.get("process_name", ""),
            command=data.get("command", []),
            intent=data.get("intent", ""),
            actor=data.get("actor", ""),
            timeout=data.get("timeout", 300),
            source_files=data.get("source_files", {}),
            source_hashes=data.get("source_hashes", {}),
            env_vars=data.get("env_vars", {}),
            original_diff=data.get("original_diff"),
            original_success=data.get("original_success", False),
            original_exit_code=data.get("original_exit_code", -1),
            original_token_count=data.get("original_token_count", 0),
            original_airlock_id=data.get("original_airlock_id", ""),
        )


@dataclass
class ReplayComparison:
    """
    Comparison between original and replayed execution.

    If is_isomorphic is True: the process behaves identically
    on both machines. Reproducibility proven.
    """
    original_machine: str = ""
    replay_machine: str = ""
    original_airlock_id: str = ""
    replay_airlock_id: str = ""

    # Outcome comparison
    same_exit_code: bool = False
    same_success: bool = False
    same_diff: bool = False
    same_file_changes: bool = False

    # Detailed comparison
    original_exit_code: int = -1
    replay_exit_code: int = -1
    diff_differences: list[str] = field(default_factory=list)

    # Files that changed differently
    only_in_original: list[str] = field(default_factory=list)
    only_in_replay: list[str] = field(default_factory=list)
    different_content: list[str] = field(default_factory=list)

    @property
    def is_isomorphic(self) -> bool:
        """True if the execution was identical on both machines."""
        return (self.same_exit_code and self.same_success
                and self.same_file_changes)

    @property
    def divergence_score(self) -> float:
        """0.0 = identical, 1.0 = completely different."""
        checks = [
            self.same_exit_code,
            self.same_success,
            self.same_diff,
            self.same_file_changes,
        ]
        if not checks:
            return 1.0
        return 1.0 - (sum(checks) / len(checks))

    def summary(self) -> str:
        """Human-readable comparison summary."""
        if self.is_isomorphic:
            status = "ISOMORPHIC — Process is reproducible across machines"
        else:
            status = f"DIVERGENT — Divergence score: {self.divergence_score:.0%}"

        lines = [
            f"=== REPLAY COMPARISON ===",
            f"Status: {status}",
            f"",
            f"Original: {self.original_machine} ({self.original_airlock_id})",
            f"Replay:   {self.replay_machine} ({self.replay_airlock_id})",
            f"",
            f"Exit code:    {'SAME' if self.same_exit_code else 'DIFFERENT'} "
            f"(original: {self.original_exit_code}, replay: {self.replay_exit_code})",
            f"Success:      {'SAME' if self.same_success else 'DIFFERENT'}",
            f"File changes: {'SAME' if self.same_file_changes else 'DIFFERENT'}",
        ]

        if self.only_in_original:
            lines.append(f"\nOnly changed on original:")
            for f in self.only_in_original:
                lines.append(f"  - {f}")

        if self.only_in_replay:
            lines.append(f"\nOnly changed on replay:")
            for f in self.only_in_replay:
                lines.append(f"  + {f}")

        if self.different_content:
            lines.append(f"\nChanged differently:")
            for f in self.different_content:
                lines.append(f"  ~ {f}")

        return "\n".join(lines)


def export_airlock(
    result: AirlockResult,
    command: list[str],
    source_dir: Optional[str] = None,
    include_source: bool = False,
    env_vars: Optional[dict[str, str]] = None,
) -> ReplayBundle:
    """
    Export an airlock result as a portable replay bundle.

    If include_source is True, file contents are included
    (makes the bundle self-contained but larger).
    """
    import socket

    bundle = ReplayBundle(
        source_machine=socket.gethostname(),
        process_name=result.process_name,
        command=command,
        intent=result.declared_intent,
        actor=result.actor,
        original_diff=result.diff.to_dict(),
        original_success=result.success,
        original_exit_code=result.exit_code,
        original_token_count=len(result.tibet_tokens),
        original_airlock_id=result.airlock_id,
        env_vars=env_vars or {},
    )

    # Capture source file hashes (and optionally content)
    if source_dir:
        src = Path(source_dir)
        if src.is_dir():
            for file_path in sorted(src.rglob("*")):
                if not file_path.is_file():
                    continue
                rel = str(file_path.relative_to(src))
                if any(skip in rel for skip in
                       (".git", "__pycache__", ".venv", "node_modules")):
                    continue
                try:
                    data = file_path.read_bytes()
                    bundle.source_hashes[rel] = hashlib.sha256(data).hexdigest()
                    if include_source:
                        try:
                            bundle.source_files[rel] = data.decode("utf-8")
                        except UnicodeDecodeError:
                            pass  # Skip binary files in content
                except (OSError, PermissionError):
                    continue

    return bundle


def save_bundle(bundle: ReplayBundle, path: str):
    """Save a replay bundle to a JSON file."""
    Path(path).write_text(json.dumps(bundle.to_dict(), indent=2))


def load_bundle(path: str) -> ReplayBundle:
    """Load a replay bundle from a JSON file."""
    data = json.loads(Path(path).read_text())
    return ReplayBundle.from_dict(data)


def replay_bundle(
    path: str,
    override_source: Optional[str] = None,
) -> tuple[ReplayBundle, AirlockResult]:
    """
    Replay a bundle on the current machine.

    Returns the original bundle and the new airlock result.
    """
    bundle = load_bundle(path)

    # Create airlock for replay
    airlock = Airlock(
        process_name=f"replay:{bundle.process_name}",
        actor=f"replay@{_hostname()}",
        intent=f"Replay of {bundle.original_airlock_id} from {bundle.source_machine}",
    )

    # Prepare with source files from bundle (or override dir)
    if override_source:
        workdir = airlock.prepare(source_dir=override_source)
    elif bundle.source_files:
        workdir = airlock.prepare(files=bundle.source_files)
    else:
        workdir = airlock.prepare()

    # Execute the same command
    result = airlock.execute(
        command=bundle.command,
        timeout=bundle.timeout,
    )

    airlock.cleanup()
    return bundle, result


def compare_results(
    bundle: ReplayBundle,
    replay_result: AirlockResult,
) -> ReplayComparison:
    """
    Compare original execution with replay.

    Produces a ReplayComparison showing exactly where
    the results agree or diverge.
    """
    comparison = ReplayComparison(
        original_machine=bundle.source_machine,
        replay_machine=_hostname(),
        original_airlock_id=bundle.original_airlock_id,
        replay_airlock_id=replay_result.airlock_id,
        original_exit_code=bundle.original_exit_code,
        replay_exit_code=replay_result.exit_code,
    )

    # Compare outcomes
    comparison.same_exit_code = (
        bundle.original_exit_code == replay_result.exit_code
    )
    comparison.same_success = (
        bundle.original_success == replay_result.success
    )

    # Compare diffs
    original_diff = bundle.original_diff or {}
    replay_diff = replay_result.diff.to_dict()

    orig_changed = {f["path"] for f in original_diff.get("files_changed", [])}
    orig_added = set(original_diff.get("files_added", []))
    orig_removed = set(original_diff.get("files_removed", []))
    orig_all = orig_changed | orig_added | orig_removed

    rep_changed = {f["path"] for f in replay_diff.get("files_changed", [])}
    rep_added = set(replay_diff.get("files_added", []))
    rep_removed = set(replay_diff.get("files_removed", []))
    rep_all = rep_changed | rep_added | rep_removed

    comparison.same_file_changes = (orig_all == rep_all)
    comparison.same_diff = (original_diff == replay_diff)

    comparison.only_in_original = sorted(orig_all - rep_all)
    comparison.only_in_replay = sorted(rep_all - orig_all)

    # Files that changed in both but differently
    common = orig_all & rep_all
    for f in sorted(common):
        orig_hash = next(
            (fc.get("after_hash") for fc in original_diff.get("files_changed", [])
             if fc.get("path") == f), None
        )
        rep_hash = next(
            (fc.get("after_hash") for fc in replay_diff.get("files_changed", [])
             if fc.get("path") == f), None
        )
        if orig_hash and rep_hash and orig_hash != rep_hash:
            comparison.different_content.append(f)

    return comparison


def _hostname() -> str:
    import socket
    return socket.gethostname()
