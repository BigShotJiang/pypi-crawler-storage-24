"""
tibet-triage — Human-in-the-Loop as a discipline.

Airlock sandbox, isomorphic mirror, risk-gated triage levels
with TIBET provenance. Not a rubber stamp.
"""

__version__ = "0.3.2"

from .models import (
    TriageLevel,
    TriageState,
    TriggerRule,
    TriggerResult,
    RiskScore,
    EvidenceBundle,
    SideEffect,
    AirlockResult,
    Approval,
)

__all__ = [
    "TriageLevel",
    "TriageState",
    "TriggerRule",
    "TriggerResult",
    "RiskScore",
    "EvidenceBundle",
    "SideEffect",
    "AirlockResult",
    "Approval",
]
