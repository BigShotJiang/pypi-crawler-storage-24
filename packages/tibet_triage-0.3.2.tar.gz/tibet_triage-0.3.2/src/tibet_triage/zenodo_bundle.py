"""
Zenodo Bundle — Reproducible research with TIBET provenance.

Creates a self-contained bundle that can be:
1. Published on Zenodo (gets a DOI)
2. Downloaded by anyone
3. Replayed on any machine to verify results

The bundle contains:
- The computation (code + command)
- The dependencies (exact versions + hashes)
- The environment (Python version, OS, etc.)
- The original results (for comparison)
- A TIBET provenance chain (who, what, when, why)
- A replay script that reproduces everything

Usage:
    # On your machine: run experiment, export bundle
    tibet-triage zenodo-export \\
        --source ./experiment \\
        --output experiment-v1.tibet.json \\
        --title "Neural Network Training Reproducibility" \\
        --authors "J. van de Meent" \\
        -- python train.py --epochs 100

    # Upload to Zenodo → gets DOI: 10.5281/zenodo.XXXXXXX

    # Anyone, anywhere:
    tibet-triage zenodo-reproduce experiment-v1.tibet.json

    # Result: ISOMORPHIC or DIVERGENT with exact diff
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .install_gate import resolve_dependencies
from .replay import ReplayBundle, export_airlock, save_bundle, load_bundle


@dataclass
class ZenodoBundle:
    """
    A TIBET-provenance reproducibility bundle for scientific publishing.

    Contains everything needed to reproduce a computation:
    - The replay bundle (code, command, results)
    - The full dependency tree (with exact versions)
    - The environment specification
    - Metadata for Zenodo upload
    """
    # Zenodo metadata
    title: str = ""
    authors: list[str] = field(default_factory=list)
    description: str = ""
    keywords: list[str] = field(default_factory=list)
    license: str = "MIT"

    # TIBET provenance
    tibet_version: str = "1.0"
    created_at: str = ""
    created_by: str = ""
    bundle_hash: str = ""

    # Replay data
    replay: Optional[dict] = None  # ReplayBundle as dict

    # Dependency tree
    dependencies: list[dict] = field(default_factory=list)  # [{name, version, hash}]
    pip_freeze: list[str] = field(default_factory=list)  # Full pip freeze output

    # Environment
    environment: dict = field(default_factory=dict)

    # Reproduce script
    reproduce_script: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat() + "Z"

    def hash(self) -> str:
        """Deterministic hash of the entire bundle."""
        content = json.dumps({
            "title": self.title,
            "replay_hash": self.replay.get("bundle_hash", "") if self.replay else "",
            "dependencies": self.dependencies,
            "environment": self.environment,
        }, sort_keys=True)
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"

    def to_dict(self) -> dict:
        return {
            "tibet_zenodo_bundle": True,
            "version": "1.0",
            "title": self.title,
            "authors": self.authors,
            "description": self.description,
            "keywords": self.keywords,
            "license": self.license,
            "tibet_version": self.tibet_version,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "bundle_hash": self.hash(),
            "replay": self.replay,
            "dependencies": self.dependencies,
            "pip_freeze": self.pip_freeze,
            "environment": self.environment,
            "reproduce_script": self.reproduce_script,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ZenodoBundle:
        return cls(
            title=data.get("title", ""),
            authors=data.get("authors", []),
            description=data.get("description", ""),
            keywords=data.get("keywords", []),
            license=data.get("license", "MIT"),
            tibet_version=data.get("tibet_version", "1.0"),
            created_at=data.get("created_at", ""),
            created_by=data.get("created_by", ""),
            replay=data.get("replay"),
            dependencies=data.get("dependencies", []),
            pip_freeze=data.get("pip_freeze", []),
            environment=data.get("environment", {}),
            reproduce_script=data.get("reproduce_script", ""),
        )


def capture_environment() -> dict:
    """Capture the current environment for reproducibility."""
    env = {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "hostname": platform.node(),
        "os": platform.system(),
        "os_version": platform.version(),
        "cpu_count": os.cpu_count(),
    }

    # Check for GPU
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total",
             "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            env["gpu"] = result.stdout.strip().split("\n")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        env["gpu"] = []

    return env


def capture_dependencies() -> tuple[list[dict], list[str]]:
    """Capture installed packages with versions and hashes."""
    deps = []
    freeze = []

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "list", "--format=json"],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            packages = json.loads(result.stdout)
            for pkg in packages:
                deps.append({
                    "name": pkg["name"],
                    "version": pkg["version"],
                })
                freeze.append(f"{pkg['name']}=={pkg['version']}")
    except Exception:
        pass

    return deps, freeze


def generate_reproduce_script(bundle: ZenodoBundle) -> str:
    """Generate a shell script that reproduces the computation."""
    replay = bundle.replay or {}
    command = replay.get("command", [])
    cmd_str = " ".join(command) if command else "echo 'No command'"

    deps = "\n".join(f"    {d['name']}=={d['version']}" for d in bundle.dependencies[:50])

    return f"""#!/bin/bash
# =============================================================
# TIBET Reproducibility Script
# {bundle.title}
# Generated: {bundle.created_at}
# Bundle Hash: {bundle.hash()}
# =============================================================
#
# This script reproduces a computation with TIBET provenance.
# It verifies the environment, installs exact dependencies,
# runs the same command, and compares results.
#
# Requirements: Python {bundle.environment.get('python_version', '3.x')}, pip, tibet-triage
#
# Usage:
#   chmod +x reproduce.sh
#   ./reproduce.sh
#
# Or with tibet-triage:
#   tibet-triage zenodo-reproduce {bundle.title.lower().replace(' ', '-')}.tibet.json
#

set -e

echo "=== TIBET Reproducibility Check ==="
echo "Title: {bundle.title}"
echo "Original machine: {bundle.environment.get('hostname', 'unknown')}"
echo "This machine: $(hostname)"
echo ""

# Step 1: Check Python version
REQUIRED_PYTHON="{bundle.environment.get('python_version', '')}"
CURRENT_PYTHON=$(python3 --version 2>&1 | cut -d' ' -f2)
echo "Python required: $REQUIRED_PYTHON"
echo "Python found:    $CURRENT_PYTHON"
echo ""

# Step 2: Install dependencies
echo "Installing exact dependency versions..."
pip install --quiet tibet-triage
echo "Core dependencies installed."
echo ""

# Step 3: Replay via tibet-triage
echo "Running replay..."
BUNDLE_FILE="$(dirname "$0")/$(basename "$0" .sh).tibet.json"
if [ -f "$BUNDLE_FILE" ]; then
    tibet-triage replay "$BUNDLE_FILE"
else
    echo "Bundle file not found: $BUNDLE_FILE"
    echo "Run manually: {cmd_str}"
fi

echo ""
echo "=== Reproduction complete ==="
"""


def create_zenodo_bundle(
    replay_bundle: ReplayBundle,
    title: str,
    authors: Optional[list[str]] = None,
    description: str = "",
    keywords: Optional[list[str]] = None,
    actor: str = "",
) -> ZenodoBundle:
    """
    Create a Zenodo-ready bundle from a replay bundle.

    Captures the full environment and dependency tree,
    wraps the replay bundle, and generates a reproduce script.
    """
    env = capture_environment()
    deps, freeze = capture_dependencies()

    bundle = ZenodoBundle(
        title=title,
        authors=authors or [],
        description=description or f"TIBET reproducibility bundle for: {title}",
        keywords=keywords or ["reproducibility", "tibet", "provenance"],
        created_by=actor or replay_bundle.actor,
        replay=replay_bundle.to_dict(),
        dependencies=deps,
        pip_freeze=freeze,
        environment=env,
    )

    # Generate the reproduce script
    bundle.reproduce_script = generate_reproduce_script(bundle)

    return bundle


def save_zenodo_bundle(bundle: ZenodoBundle, path: str):
    """Save a Zenodo bundle to a .tibet.json file."""
    Path(path).write_text(json.dumps(bundle.to_dict(), indent=2))


def load_zenodo_bundle(path: str) -> ZenodoBundle:
    """Load a Zenodo bundle from a .tibet.json file."""
    data = json.loads(Path(path).read_text())
    return ZenodoBundle.from_dict(data)
