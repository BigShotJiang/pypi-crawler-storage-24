"""
Airlock — Isolated sandbox execution with full provenance.

The airlock runs a process in an isolated environment:
- Temporary directory (or VM/container in future)
- Captures all file changes as a diff
- Records TIBET tokens for every action
- Logs all side effects (network, filesystem, processes)
- Produces a deterministic AirlockResult

The airlock is isomorphic to production: same code paths,
same token structure, but synthetic data and no real side effects.

This is not an AI tool. This is a process integrity engine.
A CERN experiment, a CI/CD pipeline, a financial settlement,
a medical data transform — they all follow the same pattern:
prepare, execute in isolation, verify, then apply.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from .models import AirlockResult, SideEffect, StateDiff


class Airlock:
    """
    Isolated execution sandbox.

    Runs a process in a temporary environment, captures all changes,
    and produces a deterministic result with full TIBET provenance.

    Usage:
        airlock = Airlock("deploy-api")
        airlock.prepare(source_dir="/app", env={"DEBUG": "0"})
        result = airlock.execute(["python", "deploy.py"])
        # result contains: diff, side effects, TIBET tokens
    """

    def __init__(
        self,
        process_name: str,
        actor: str = "",
        intent: str = "",
        base_dir: Optional[str] = None,
    ):
        self.process_name = process_name
        self.actor = actor
        self.intent = intent
        self.airlock_id = f"airlock-{uuid.uuid4().hex[:12]}"

        # Working directories
        self._base_dir = base_dir
        self._workdir: Optional[Path] = None
        self._snapshot_before: dict[str, str] = {}  # path -> hash
        self._tibet_tokens: list[dict[str, Any]] = []
        self._side_effects: list[SideEffect] = []
        self._prepared = False

    def prepare(
        self,
        source_dir: Optional[str] = None,
        files: Optional[dict[str, str]] = None,
        env: Optional[dict[str, str]] = None,
        copy_source: bool = True,
    ) -> Path:
        """
        Prepare the airlock environment.

        Creates an isolated working directory with either:
        - A copy of source_dir (for filesystem-based processes)
        - Specific files provided as dict (for programmatic use)
        - An empty directory (for processes that create from scratch)

        Returns the working directory path.
        """
        # Create temporary directory
        self._workdir = Path(tempfile.mkdtemp(
            prefix=f"triage-{self.airlock_id}-",
            dir=self._base_dir,
        ))

        # Populate with source
        if source_dir and copy_source:
            src = Path(source_dir)
            if src.is_dir():
                # Copy contents, not the dir itself
                for item in src.iterdir():
                    if item.name in (".git", "__pycache__", ".venv", "venv",
                                     "node_modules", ".triage"):
                        continue
                    dest = self._workdir / item.name
                    if item.is_dir():
                        shutil.copytree(item, dest, symlinks=True,
                                        ignore=shutil.ignore_patterns(
                                            "__pycache__", "*.pyc", ".git"))
                    else:
                        shutil.copy2(item, dest)

        if files:
            for path, content in files.items():
                file_path = self._workdir / path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content)

        # Take "before" snapshot
        self._snapshot_before = self._snapshot_directory(self._workdir)

        # Record environment
        self._env = dict(os.environ)
        if env:
            self._env.update(env)
        self._env["TIBET_TRIAGE_AIRLOCK"] = self.airlock_id
        self._env["TIBET_TRIAGE_ENVIRONMENT"] = "airlock"

        # TIBET token: airlock prepared
        self._add_token("AIRLOCK_PREPARED", {
            "airlock_id": self.airlock_id,
            "process": self.process_name,
            "actor": self.actor,
            "intent": self.intent,
            "source_files": len(self._snapshot_before),
            "workdir": str(self._workdir),
        })

        self._prepared = True
        return self._workdir

    def execute(
        self,
        command: list[str],
        timeout: int = 300,
        stdin_data: Optional[str] = None,
    ) -> AirlockResult:
        """
        Execute a command in the airlock.

        Runs the command in the isolated working directory,
        captures stdout/stderr, records the diff, and produces
        a complete AirlockResult.
        """
        if not self._prepared:
            raise RuntimeError("Airlock not prepared. Call prepare() first.")

        started_at = datetime.utcnow().isoformat() + "Z"

        # TIBET token: execution start
        self._add_token("AIRLOCK_EXECUTE", {
            "command": command,
            "timeout": timeout,
        })

        # Run the process
        try:
            proc = subprocess.run(
                command,
                cwd=str(self._workdir),
                env=self._env,
                capture_output=True,
                text=True,
                timeout=timeout,
                stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
                input=stdin_data,
            )
            success = proc.returncode == 0
            exit_code = proc.returncode
            stdout = proc.stdout
            stderr = proc.stderr
        except subprocess.TimeoutExpired:
            success = False
            exit_code = -1
            stdout = ""
            stderr = f"Process timed out after {timeout}s"
        except Exception as e:
            success = False
            exit_code = -2
            stdout = ""
            stderr = str(e)

        completed_at = datetime.utcnow().isoformat() + "Z"

        # Take "after" snapshot and compute diff
        snapshot_after = self._snapshot_directory(self._workdir)
        diff = self._compute_diff(self._snapshot_before, snapshot_after)

        # TIBET token: execution complete
        self._add_token("AIRLOCK_COMPLETE", {
            "success": success,
            "exit_code": exit_code,
            "diff_hash": diff.hash(),
            "files_changed": len(diff.files_changed),
            "files_added": len(diff.files_added),
            "files_removed": len(diff.files_removed),
            "side_effects": len(self._side_effects),
        })

        return AirlockResult(
            airlock_id=self.airlock_id,
            process_name=self.process_name,
            started_at=started_at,
            completed_at=completed_at,
            success=success,
            exit_code=exit_code,
            tibet_tokens=list(self._tibet_tokens),
            side_effects=list(self._side_effects),
            diff=diff,
            environment="airlock",
            actor=self.actor,
            declared_intent=self.intent,
            stdout=stdout[-10000:] if len(stdout) > 10000 else stdout,
            stderr=stderr[-5000:] if len(stderr) > 5000 else stderr,
        )

    def execute_callable(
        self,
        fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> AirlockResult:
        """
        Execute a Python callable in the airlock.

        For processes that don't need a subprocess — direct
        function execution with the same isolation guarantees.
        """
        if not self._prepared:
            raise RuntimeError("Airlock not prepared. Call prepare() first.")

        started_at = datetime.utcnow().isoformat() + "Z"

        self._add_token("AIRLOCK_EXECUTE", {
            "callable": fn.__qualname__,
            "args_count": len(args),
        })

        # Change to workdir for the callable
        old_cwd = os.getcwd()
        try:
            os.chdir(self._workdir)
            os.environ["TIBET_TRIAGE_AIRLOCK"] = self.airlock_id
            os.environ["TIBET_TRIAGE_ENVIRONMENT"] = "airlock"

            result = fn(*args, **kwargs)
            success = True
            exit_code = 0
            stdout = str(result) if result is not None else ""
            stderr = ""
        except Exception as e:
            success = False
            exit_code = 1
            stdout = ""
            stderr = str(e)
        finally:
            os.chdir(old_cwd)
            os.environ.pop("TIBET_TRIAGE_AIRLOCK", None)
            os.environ.pop("TIBET_TRIAGE_ENVIRONMENT", None)

        completed_at = datetime.utcnow().isoformat() + "Z"

        snapshot_after = self._snapshot_directory(self._workdir)
        diff = self._compute_diff(self._snapshot_before, snapshot_after)

        self._add_token("AIRLOCK_COMPLETE", {
            "success": success,
            "diff_hash": diff.hash(),
        })

        return AirlockResult(
            airlock_id=self.airlock_id,
            process_name=self.process_name,
            started_at=started_at,
            completed_at=completed_at,
            success=success,
            exit_code=exit_code,
            tibet_tokens=list(self._tibet_tokens),
            side_effects=list(self._side_effects),
            diff=diff,
            environment="airlock",
            actor=self.actor,
            declared_intent=self.intent,
            stdout=stdout,
            stderr=stderr,
        )

    def cleanup(self):
        """Remove the airlock working directory."""
        if self._workdir and self._workdir.exists():
            shutil.rmtree(self._workdir, ignore_errors=True)
            self._add_token("AIRLOCK_CLEANUP", {
                "workdir": str(self._workdir),
            })

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.cleanup()

    # --- Internal helpers ---

    def _add_token(self, token_type: str, data: dict[str, Any]):
        """Record a TIBET-style token."""
        self._tibet_tokens.append({
            "token_id": f"t-{uuid.uuid4().hex[:8]}",
            "type": token_type,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "airlock_id": self.airlock_id,
            "environment": "airlock",
            "data": data,
        })

    @staticmethod
    def _snapshot_directory(directory: Path) -> dict[str, str]:
        """Create a hash snapshot of all files in a directory."""
        snapshot = {}
        for file_path in sorted(directory.rglob("*")):
            if not file_path.is_file():
                continue
            rel = str(file_path.relative_to(directory))
            try:
                content = file_path.read_bytes()
                file_hash = hashlib.sha256(content).hexdigest()
                snapshot[rel] = file_hash
            except (OSError, PermissionError):
                snapshot[rel] = "ERROR"
        return snapshot

    @staticmethod
    def _compute_diff(
        before: dict[str, str],
        after: dict[str, str],
    ) -> StateDiff:
        """Compute the diff between two directory snapshots."""
        diff = StateDiff()

        all_files = set(before.keys()) | set(after.keys())
        for f in sorted(all_files):
            in_before = f in before
            in_after = f in after

            if in_before and not in_after:
                diff.files_removed.append(f)
            elif not in_before and in_after:
                diff.files_added.append(f)
            elif before[f] != after[f]:
                diff.files_changed.append({
                    "path": f,
                    "before_hash": before[f],
                    "after_hash": after[f],
                })

        return diff
