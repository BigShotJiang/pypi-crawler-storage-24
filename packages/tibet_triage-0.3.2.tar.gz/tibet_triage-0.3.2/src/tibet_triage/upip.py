"""
UPIP — Universal Process Integrity Protocol

A process is reproducible if and only if:
1. The STATE is fully defined (code, deps, env, data)
2. The PROCESS is deterministic (same input → same output)
3. The RESULT is verifiable (cross-machine replay proves it)

UPIP defines five layers:

    ┌─────────────────────────────────────┐
    │  L5  VERIFY    Cross-machine proof  │
    │  L4  RESULT    Output + diff + hash │
    │  L3  PROCESS   Command + intent     │
    │  L2  DEPS      Exact dependency set │
    │  L1  STATE     Code + env + data    │
    └─────────────────────────────────────┘

Each layer is immutable after creation.
Each layer references the layer below it.
The full stack is signed with a TIBET token.

Without L1 (STATE), nothing above it means anything.
That's why "van welke staat?" is the first question.

UPIP State Types:
    - GIT    : A git commit hash (deterministic, auditable)
    - FILES  : SHA-256 hashes of every file (no git needed)
    - IMAGE  : Container/VM image hash (Docker, OCI)
    - EMPTY  : Clean slate (process creates from scratch)

Usage:
    from tibet_triage.upip import UPIPStack, StateCapture

    # Capture current state
    state = StateCapture.from_directory("./experiment", state_type="git")

    # Build the full stack
    stack = UPIPStack(
        state=state,
        deps=DepsCapture.from_pip(),
        process=ProcessDef(command=["python", "train.py"]),
    )

    # Run through airlock
    result = stack.execute()

    # Export as UPIP bundle
    stack.export("experiment.upip.json")

    # Anyone, anywhere:
    tibet-triage upip-reproduce experiment.upip.json
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .airlock import Airlock
from .models import AirlockResult


# =============================================================================
# L1: STATE — Where you start from
# =============================================================================

@dataclass
class StateCapture:
    """
    L1: Complete definition of the starting state.

    Without this, nothing is reproducible. This answers:
    "Van welke staat beginnen we?"

    State types:
        git   - Git repo at exact commit (most common)
        files - SHA-256 manifest of all files (no git needed)
        image - Container image digest (Docker/OCI)
        empty - Clean slate (process creates everything)
    """
    state_type: str = "files"  # git, files, image, empty
    state_hash: str = ""  # The single hash that defines this state

    # Git state
    git_remote: str = ""       # e.g. https://github.com/user/repo
    git_commit: str = ""       # Full SHA
    git_branch: str = ""       # Branch name
    git_tag: str = ""          # Tag if any
    git_dirty: bool = False    # Uncommitted changes?

    # File state (always captured, even for git)
    file_manifest: dict[str, str] = field(default_factory=dict)  # path -> sha256
    file_count: int = 0
    total_size_bytes: int = 0

    # Image state
    image_ref: str = ""        # e.g. python:3.13-slim
    image_digest: str = ""     # sha256:...

    # Source directory
    source_dir: str = ""
    source_files: dict[str, str] = field(default_factory=dict)  # path -> content (optional)

    # Timestamp
    captured_at: str = ""

    def __post_init__(self):
        if not self.captured_at:
            self.captured_at = datetime.utcnow().isoformat() + "Z"

    @classmethod
    def from_directory(
        cls,
        directory: str,
        state_type: str = "auto",
        include_content: bool = False,
    ) -> StateCapture:
        """
        Capture the full state of a directory.

        Auto-detects git if available, falls back to file manifest.
        """
        src = Path(directory).resolve()
        capture = cls(source_dir=str(src))

        # Check if it's a git repo
        git_dir = src / ".git"
        is_git = git_dir.is_dir()

        if state_type == "auto":
            state_type = "git" if is_git else "files"
        capture.state_type = state_type

        # Always capture file manifest
        total_size = 0
        for file_path in sorted(src.rglob("*")):
            if not file_path.is_file():
                continue
            rel = str(file_path.relative_to(src))
            if any(skip in rel for skip in
                   (".git/", "__pycache__", ".venv", "venv",
                    "node_modules", ".triage", "*.pyc")):
                continue
            try:
                data = file_path.read_bytes()
                file_hash = hashlib.sha256(data).hexdigest()
                capture.file_manifest[rel] = file_hash
                total_size += len(data)
                if include_content:
                    try:
                        capture.source_files[rel] = data.decode("utf-8")
                    except UnicodeDecodeError:
                        pass
            except (OSError, PermissionError):
                continue

        capture.file_count = len(capture.file_manifest)
        capture.total_size_bytes = total_size

        # Git-specific capture
        if is_git and state_type == "git":
            capture._capture_git(str(src))

        # Compute state hash
        capture.state_hash = capture._compute_hash()

        return capture

    @classmethod
    def empty(cls) -> StateCapture:
        """Create an empty state (process creates from scratch)."""
        return cls(state_type="empty", state_hash="empty:0")

    def _capture_git(self, directory: str):
        """Capture git state."""
        try:
            def git(*args):
                r = subprocess.run(
                    ["git"] + list(args),
                    cwd=directory, capture_output=True, text=True, timeout=10,
                )
                return r.stdout.strip() if r.returncode == 0 else ""

            self.git_commit = git("rev-parse", "HEAD")
            self.git_branch = git("rev-parse", "--abbrev-ref", "HEAD")
            self.git_tag = git("describe", "--tags", "--exact-match")

            # Get remote URL
            self.git_remote = git("remote", "get-url", "origin")

            # Check for dirty state
            status = git("status", "--porcelain")
            self.git_dirty = bool(status)

        except Exception:
            pass

    def _compute_hash(self) -> str:
        """Single hash representing this entire state."""
        if self.state_type == "git" and self.git_commit and not self.git_dirty:
            return f"git:{self.git_commit}"
        elif self.state_type == "image" and self.image_digest:
            return f"image:{self.image_digest}"
        elif self.state_type == "empty":
            return "empty:0"
        else:
            # Hash from file manifest
            content = json.dumps(
                sorted(self.file_manifest.items()), sort_keys=True
            )
            h = hashlib.sha256(content.encode()).hexdigest()
            return f"files:{h}"

    def to_dict(self) -> dict:
        return {
            "state_type": self.state_type,
            "state_hash": self.state_hash,
            "git_remote": self.git_remote,
            "git_commit": self.git_commit,
            "git_branch": self.git_branch,
            "git_tag": self.git_tag,
            "git_dirty": self.git_dirty,
            "file_manifest": self.file_manifest,
            "file_count": self.file_count,
            "total_size_bytes": self.total_size_bytes,
            "image_ref": self.image_ref,
            "image_digest": self.image_digest,
            "source_dir": self.source_dir,
            "captured_at": self.captured_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> StateCapture:
        return cls(
            state_type=data.get("state_type", "files"),
            state_hash=data.get("state_hash", ""),
            git_remote=data.get("git_remote", ""),
            git_commit=data.get("git_commit", ""),
            git_branch=data.get("git_branch", ""),
            git_tag=data.get("git_tag", ""),
            git_dirty=data.get("git_dirty", False),
            file_manifest=data.get("file_manifest", {}),
            file_count=data.get("file_count", 0),
            total_size_bytes=data.get("total_size_bytes", 0),
            image_ref=data.get("image_ref", ""),
            image_digest=data.get("image_digest", ""),
            source_dir=data.get("source_dir", ""),
            captured_at=data.get("captured_at", ""),
        )


# =============================================================================
# L2: DEPS — Exact dependency set
# =============================================================================

@dataclass
class DepsCapture:
    """
    L2: Complete dependency specification.

    Exact versions. Exact hashes. No ambiguity.
    """
    python_version: str = ""
    packages: list[dict] = field(default_factory=list)  # [{name, version, hash}]
    pip_freeze: list[str] = field(default_factory=list)  # pip freeze output
    system_packages: list[str] = field(default_factory=list)  # dpkg/rpm
    captured_at: str = ""
    deps_hash: str = ""

    def __post_init__(self):
        if not self.captured_at:
            self.captured_at = datetime.utcnow().isoformat() + "Z"

    @classmethod
    def from_pip(cls) -> DepsCapture:
        """Capture current pip environment."""
        capture = cls(python_version=platform.python_version())

        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "list", "--format=json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                for pkg in json.loads(result.stdout):
                    capture.packages.append({
                        "name": pkg["name"],
                        "version": pkg["version"],
                    })
                    capture.pip_freeze.append(
                        f"{pkg['name']}=={pkg['version']}"
                    )
        except Exception:
            pass

        capture.deps_hash = capture._compute_hash()
        return capture

    def _compute_hash(self) -> str:
        content = json.dumps(
            [(p["name"], p["version"]) for p in self.packages],
            sort_keys=True,
        )
        h = hashlib.sha256(content.encode()).hexdigest()
        return f"deps:{h}"

    def to_dict(self) -> dict:
        return {
            "python_version": self.python_version,
            "packages": self.packages,
            "pip_freeze": self.pip_freeze,
            "system_packages": self.system_packages,
            "captured_at": self.captured_at,
            "deps_hash": self.deps_hash,
        }

    @classmethod
    def from_dict(cls, data: dict) -> DepsCapture:
        c = cls(
            python_version=data.get("python_version", ""),
            packages=data.get("packages", []),
            pip_freeze=data.get("pip_freeze", []),
            system_packages=data.get("system_packages", []),
            captured_at=data.get("captured_at", ""),
            deps_hash=data.get("deps_hash", ""),
        )
        return c


# =============================================================================
# L3: PROCESS — What you run
# =============================================================================

@dataclass
class ProcessDef:
    """
    L3: Exact process definition.

    Command, intent, actor, timeout — everything needed
    to know WHAT will be executed.
    """
    command: list[str] = field(default_factory=list)
    intent: str = ""
    actor: str = ""
    timeout: int = 300
    env_vars: dict[str, str] = field(default_factory=dict)
    working_dir: str = ""  # Relative to state source

    def to_dict(self) -> dict:
        return {
            "command": self.command,
            "intent": self.intent,
            "actor": self.actor,
            "timeout": self.timeout,
            "env_vars": self.env_vars,
            "working_dir": self.working_dir,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ProcessDef:
        return cls(
            command=data.get("command", []),
            intent=data.get("intent", ""),
            actor=data.get("actor", ""),
            timeout=data.get("timeout", 300),
            env_vars=data.get("env_vars", {}),
            working_dir=data.get("working_dir", ""),
        )


# =============================================================================
# L4: RESULT — What happened
# =============================================================================

@dataclass
class ResultCapture:
    """
    L4: Complete result of execution.

    Exit code, output, file diff, side effects, TIBET tokens.
    """
    success: bool = False
    exit_code: int = -1
    stdout_hash: str = ""  # Hash of stdout (not full content — could be huge)
    stderr_hash: str = ""
    diff_hash: str = ""
    files_added: int = 0
    files_changed: int = 0
    files_removed: int = 0
    side_effects: int = 0
    tibet_tokens: int = 0
    airlock_id: str = ""
    result_hash: str = ""

    # Full airlock result (for replay comparison)
    airlock_result_dict: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "exit_code": self.exit_code,
            "stdout_hash": self.stdout_hash,
            "stderr_hash": self.stderr_hash,
            "diff_hash": self.diff_hash,
            "files_added": self.files_added,
            "files_changed": self.files_changed,
            "files_removed": self.files_removed,
            "side_effects": self.side_effects,
            "tibet_tokens": self.tibet_tokens,
            "airlock_id": self.airlock_id,
            "result_hash": self.result_hash,
        }

    @classmethod
    def from_airlock(cls, result: AirlockResult) -> ResultCapture:
        """Capture result from an airlock execution."""
        return cls(
            success=result.success,
            exit_code=result.exit_code,
            stdout_hash=hashlib.sha256(
                result.stdout.encode()
            ).hexdigest() if result.stdout else "",
            stderr_hash=hashlib.sha256(
                result.stderr.encode()
            ).hexdigest() if result.stderr else "",
            diff_hash=result.diff.hash(),
            files_added=len(result.diff.files_added),
            files_changed=len(result.diff.files_changed),
            files_removed=len(result.diff.files_removed),
            side_effects=len(result.side_effects),
            tibet_tokens=len(result.tibet_tokens),
            airlock_id=result.airlock_id,
            result_hash=result.hash(),
        )

    @classmethod
    def from_dict(cls, data: dict) -> ResultCapture:
        return cls(
            success=data.get("success", False),
            exit_code=data.get("exit_code", -1),
            stdout_hash=data.get("stdout_hash", ""),
            stderr_hash=data.get("stderr_hash", ""),
            diff_hash=data.get("diff_hash", ""),
            files_added=data.get("files_added", 0),
            files_changed=data.get("files_changed", 0),
            files_removed=data.get("files_removed", 0),
            side_effects=data.get("side_effects", 0),
            tibet_tokens=data.get("tibet_tokens", 0),
            airlock_id=data.get("airlock_id", ""),
            result_hash=data.get("result_hash", ""),
        )


# =============================================================================
# L5: VERIFY — Cross-machine proof
# =============================================================================

@dataclass
class VerifyRecord:
    """
    L5: Verification record from a replay.

    Each machine that reproduces the experiment adds a record.
    """
    machine: str = ""
    verified_at: str = ""
    is_isomorphic: bool = False
    divergence_score: float = 0.0
    exit_code_match: bool = False
    diff_match: bool = False
    environment: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "machine": self.machine,
            "verified_at": self.verified_at,
            "is_isomorphic": self.is_isomorphic,
            "divergence_score": self.divergence_score,
            "exit_code_match": self.exit_code_match,
            "diff_match": self.diff_match,
            "environment": self.environment,
        }

    @classmethod
    def from_dict(cls, data: dict) -> VerifyRecord:
        return cls(
            machine=data.get("machine", ""),
            verified_at=data.get("verified_at", ""),
            is_isomorphic=data.get("is_isomorphic", False),
            divergence_score=data.get("divergence_score", 0.0),
            exit_code_match=data.get("exit_code_match", False),
            diff_match=data.get("diff_match", False),
            environment=data.get("environment", {}),
        )


# =============================================================================
# UPIP Stack — The complete protocol bundle
# =============================================================================

@dataclass
class UPIPStack:
    """
    The complete UPIP stack: five layers of process integrity.

    This is the publishable, reproducible, verifiable unit.
    Upload to Zenodo, share on GitHub, embed in a paper.

    Anyone with this file can:
    1. See exactly what state you started from
    2. See exactly what dependencies you had
    3. See exactly what process you ran
    4. See exactly what result you got
    5. Reproduce it themselves and verify
    """
    # Protocol metadata
    protocol: str = "UPIP"
    protocol_version: str = "1.0"
    created_at: str = ""
    created_by: str = ""

    # Publication metadata
    title: str = ""
    authors: list[str] = field(default_factory=list)
    description: str = ""
    keywords: list[str] = field(default_factory=list)
    license: str = "MIT"
    doi: str = ""  # Zenodo DOI after upload

    # The five layers
    state: Optional[StateCapture] = None      # L1
    deps: Optional[DepsCapture] = None        # L2
    process: Optional[ProcessDef] = None      # L3
    result: Optional[ResultCapture] = None    # L4
    verifications: list[VerifyRecord] = field(default_factory=list)  # L5

    # Source files for self-contained bundles
    source_files: dict[str, str] = field(default_factory=dict)

    # TIBET provenance
    tibet_chain: list[dict] = field(default_factory=list)

    # The stack hash — single hash over all five layers
    stack_hash: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat() + "Z"

    def compute_hash(self) -> str:
        """Compute the hash over all five layers."""
        content = json.dumps({
            "state": self.state.state_hash if self.state else "",
            "deps": self.deps.deps_hash if self.deps else "",
            "process": self.process.to_dict() if self.process else {},
            "result": self.result.result_hash if self.result else "",
        }, sort_keys=True)
        h = hashlib.sha256(content.encode()).hexdigest()
        self.stack_hash = f"upip:{h}"
        return self.stack_hash

    def to_dict(self) -> dict:
        self.compute_hash()
        return {
            "protocol": self.protocol,
            "protocol_version": self.protocol_version,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "title": self.title,
            "authors": self.authors,
            "description": self.description,
            "keywords": self.keywords,
            "license": self.license,
            "doi": self.doi,
            "stack_hash": self.stack_hash,
            "layers": {
                "L1_state": self.state.to_dict() if self.state else None,
                "L2_deps": self.deps.to_dict() if self.deps else None,
                "L3_process": self.process.to_dict() if self.process else None,
                "L4_result": self.result.to_dict() if self.result else None,
                "L5_verify": [v.to_dict() for v in self.verifications],
            },
            "source_files": self.source_files,
            "tibet_chain": self.tibet_chain,
        }

    @classmethod
    def from_dict(cls, data: dict) -> UPIPStack:
        layers = data.get("layers", {})
        stack = cls(
            protocol=data.get("protocol", "UPIP"),
            protocol_version=data.get("protocol_version", "1.0"),
            created_at=data.get("created_at", ""),
            created_by=data.get("created_by", ""),
            title=data.get("title", ""),
            authors=data.get("authors", []),
            description=data.get("description", ""),
            keywords=data.get("keywords", []),
            license=data.get("license", "MIT"),
            doi=data.get("doi", ""),
            stack_hash=data.get("stack_hash", ""),
            source_files=data.get("source_files", {}),
            tibet_chain=data.get("tibet_chain", []),
        )
        if layers.get("L1_state"):
            stack.state = StateCapture.from_dict(layers["L1_state"])
        if layers.get("L2_deps"):
            stack.deps = DepsCapture.from_dict(layers["L2_deps"])
        if layers.get("L3_process"):
            stack.process = ProcessDef.from_dict(layers["L3_process"])
        if layers.get("L4_result"):
            stack.result = ResultCapture.from_dict(layers["L4_result"])
        for v in layers.get("L5_verify", []):
            stack.verifications.append(VerifyRecord.from_dict(v))
        return stack


# =============================================================================
# High-level API
# =============================================================================

def capture_and_run(
    command: list[str],
    source_dir: str = ".",
    title: str = "",
    authors: Optional[list[str]] = None,
    actor: str = "",
    intent: str = "",
    timeout: int = 300,
    include_source: bool = True,
) -> UPIPStack:
    """
    Full UPIP capture: state → deps → process → airlock → result.

    Returns a complete UPIPStack ready for export.
    """
    # L1: STATE
    state = StateCapture.from_directory(
        source_dir,
        include_content=include_source,
    )

    # L2: DEPS
    deps = DepsCapture.from_pip()

    # L3: PROCESS
    process = ProcessDef(
        command=command,
        intent=intent or f"Execute: {' '.join(command)}",
        actor=actor,
        timeout=timeout,
    )

    # Execute in airlock
    with Airlock(
        process_name=title or process.intent,
        actor=actor,
        intent=process.intent,
    ) as airlock:
        if include_source and state.source_files:
            workdir = airlock.prepare(files=state.source_files)
        else:
            workdir = airlock.prepare(source_dir=source_dir)

        airlock_result = airlock.execute(command, timeout=timeout)

    # L4: RESULT
    result = ResultCapture.from_airlock(airlock_result)

    # Build the stack
    stack = UPIPStack(
        title=title or process.intent,
        authors=authors or [],
        created_by=actor,
        state=state,
        deps=deps,
        process=process,
        result=result,
        source_files=state.source_files if include_source else {},
        tibet_chain=airlock_result.tibet_tokens,
    )

    # Store stdout/stderr for replay display
    stack._stdout = airlock_result.stdout
    stack._stderr = airlock_result.stderr
    stack._airlock_diff = airlock_result.diff.to_dict()

    stack.compute_hash()
    return stack


def save_upip(stack: UPIPStack, path: str):
    """Save a UPIP stack to a .upip.json file."""
    data = stack.to_dict()
    # Also store replay data for reproduction
    if hasattr(stack, '_stdout'):
        data["_replay"] = {
            "stdout": getattr(stack, '_stdout', ''),
            "stderr": getattr(stack, '_stderr', ''),
            "diff": getattr(stack, '_airlock_diff', {}),
        }
    Path(path).write_text(json.dumps(data, indent=2))


def load_upip(path: str) -> UPIPStack:
    """Load a UPIP stack from a .upip.json file."""
    data = json.loads(Path(path).read_text())
    return UPIPStack.from_dict(data)


def reproduce_upip(
    path: str,
    override_source: Optional[str] = None,
) -> tuple[UPIPStack, AirlockResult, VerifyRecord]:
    """
    Reproduce a UPIP bundle on the current machine.

    Returns the original stack, the replay result, and a verification record.
    """
    from .zenodo_bundle import capture_environment
    from .replay import compare_results, ReplayBundle

    stack = load_upip(path)

    if not stack.process:
        raise ValueError("No process definition in UPIP bundle")

    # Build source files for airlock
    source_files = stack.source_files
    source_dir = override_source

    # Execute in airlock
    with Airlock(
        process_name=f"upip-reproduce:{stack.title}",
        actor=f"reproduce@{platform.node()}",
        intent=f"UPIP reproduction of {stack.stack_hash}",
    ) as airlock:
        if source_files and not override_source:
            workdir = airlock.prepare(files=source_files)
        elif override_source:
            workdir = airlock.prepare(source_dir=override_source)
        else:
            workdir = airlock.prepare()

        replay_result = airlock.execute(
            command=stack.process.command,
            timeout=stack.process.timeout,
        )

        # Collect NEW files INSIDE airlock (before cleanup) — read into memory
        airlock_outputs: list[tuple[str, bytes]] = []  # (relative_path, content)
        source_keys = set(source_files.keys()) if source_files else set()

        if replay_result.diff and (replay_result.diff.files_added or replay_result.diff.files_changed):
            # Primary: use diff info from airlock
            for added_path in replay_result.diff.files_added:
                airlock_file = Path(workdir) / added_path
                if airlock_file.is_file():
                    airlock_outputs.append((added_path, airlock_file.read_bytes()))
            for change in replay_result.diff.files_changed:
                changed_path = change["path"] if isinstance(change, dict) else change
                airlock_file = Path(workdir) / changed_path
                if airlock_file.is_file():
                    airlock_outputs.append((changed_path, airlock_file.read_bytes()))
        else:
            # Fallback: scan workdir for files not in source_files
            for file_path in sorted(Path(workdir).rglob("*")):
                if not file_path.is_file():
                    continue
                rel = str(file_path.relative_to(workdir))
                if rel not in source_keys:
                    airlock_outputs.append((rel, file_path.read_bytes()))

    # Store for triage — caller decides whether to write to disk
    replay_result._airlock_outputs = airlock_outputs

    # Compare with original
    same_exit = (
        stack.result.exit_code == replay_result.exit_code
        if stack.result else False
    )
    same_success = (
        stack.result.success == replay_result.success
        if stack.result else False
    )

    # Compare file changes
    original_diff = getattr(stack, '_airlock_diff', None)
    # Try loading from saved replay data
    raw_data = json.loads(Path(path).read_text())
    replay_data = raw_data.get("_replay", {})
    original_diff = replay_data.get("diff", {})

    replay_diff = replay_result.diff.to_dict()

    orig_all = set()
    if original_diff:
        orig_all = (
            {f["path"] for f in original_diff.get("files_changed", [])}
            | set(original_diff.get("files_added", []))
            | set(original_diff.get("files_removed", []))
        )
    rep_all = (
        {f["path"] for f in replay_diff.get("files_changed", [])}
        | set(replay_diff.get("files_added", []))
        | set(replay_diff.get("files_removed", []))
    )

    same_files = orig_all == rep_all
    is_iso = same_exit and same_success and same_files
    div_score = 1.0 - (
        sum([same_exit, same_success, same_files]) / 3.0
    )

    env = capture_environment()
    record = VerifyRecord(
        machine=platform.node(),
        verified_at=datetime.utcnow().isoformat() + "Z",
        is_isomorphic=is_iso,
        divergence_score=div_score,
        exit_code_match=same_exit,
        diff_match=same_files,
        environment=env,
    )

    return stack, replay_result, record
