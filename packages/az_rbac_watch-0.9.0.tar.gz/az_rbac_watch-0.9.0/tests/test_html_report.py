"""Tests for the HTML report generator."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from az_rbac_watch.analyzers.compliance import (
    GOVERNANCE_VIOLATION,
    OUT_OF_BASELINE,
    ComplianceFinding,
    ComplianceReport,
    ComplianceSummary,
    Severity,
)
from az_rbac_watch.reporters.html_report import (
    _build_executive_summary,
    _compute_compliance_score,
    _compute_donut_arcs,
    _score_color,
    _truncate_scope,
    generate_html_report,
)

SUB_1 = "11111111-1111-1111-1111-111111111111"
SUB_2 = "22222222-2222-2222-2222-222222222222"


def _empty_report() -> ComplianceReport:
    """Compliant report without findings."""
    return ComplianceReport(
        policy_version="2.0",
        tenant_id="aaaa-bbbb-cccc",
        scan_timestamp=datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC),
        findings=[],
        summary=ComplianceSummary(total_assignments_checked=10),
    )


def _report_with_findings() -> ComplianceReport:
    """Report with findings of multiple severities in a single scope."""
    findings = [
        ComplianceFinding(
            rule_id=OUT_OF_BASELINE,
            severity=Severity.HIGH,
            message="Unauthorized assignment",
            principal_id="user-1111",
            principal_type="User",
            role_name="Contributor",
            scope=f"/subscriptions/{SUB_1}/resourceGroups/rg-infra",
        ),
        ComplianceFinding(
            rule_id="no-direct-users",
            severity=Severity.MEDIUM,
            message="Governance rule violation",
            principal_id="group-2222",
            principal_type="Group",
            role_name="Reader",
            scope=f"/subscriptions/{SUB_1}/resourceGroups/rg-dev",
        ),
    ]
    return ComplianceReport(
        policy_version="2.0",
        tenant_id="aaaa-bbbb-cccc",
        scan_timestamp=datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC),
        findings=findings,
        summary=ComplianceSummary(
            total_assignments_checked=20,
            total_findings=2,
            drift_count=1,
            violation_count=1,
            findings_by_severity={"high": 1, "medium": 1},
        ),
    )


def _report_multi_scope() -> ComplianceReport:
    """Report with findings on 2 different subscriptions."""
    findings = [
        ComplianceFinding(
            rule_id=OUT_OF_BASELINE,
            severity=Severity.HIGH,
            message="Unauthorized assignment",
            principal_id="user-1111",
            principal_type="User",
            role_name="Owner",
            scope=f"/subscriptions/{SUB_1}",
        ),
        ComplianceFinding(
            rule_id=OUT_OF_BASELINE,
            severity=Severity.HIGH,
            message="Unauthorized assignment",
            principal_id="user-3333",
            principal_type="User",
            role_name="Contributor",
            scope=f"/subscriptions/{SUB_1}/resourceGroups/rg-infra",
        ),
        ComplianceFinding(
            rule_id="no-direct-users",
            severity=Severity.MEDIUM,
            message="Governance rule violation",
            principal_id="group-4444",
            principal_type="Group",
            role_name="Reader",
            scope=f"/subscriptions/{SUB_2}/resourceGroups/rg-dev",
        ),
    ]
    return ComplianceReport(
        policy_version="2.0",
        tenant_id="aaaa-bbbb-cccc",
        scan_timestamp=datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC),
        findings=findings,
        summary=ComplianceSummary(
            total_assignments_checked=40,
            total_findings=3,
            drift_count=2,
            violation_count=1,
            findings_by_severity={"high": 2, "medium": 1},
        ),
    )


def _report_with_errors() -> ComplianceReport:
    """Report with scan errors."""
    return ComplianceReport(
        policy_version="2.0",
        tenant_id="aaaa-bbbb-cccc",
        scan_timestamp=datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC),
        findings=[],
        summary=ComplianceSummary(total_assignments_checked=5),
        scan_errors=["Subscription sub-x: access denied", "Timeout on sub-y"],
    )


# ── Empty report tests ─────────────────────────────────────


class TestEmptyReport:
    def test_generates_valid_html(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert html.startswith("<!DOCTYPE html>")
        assert 'charset="utf-8"' in html.lower() or "charset=utf-8" in html.lower()

    def test_contains_compliant(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "Compliant" in html or "no findings" in html.lower()

    def test_contains_header_info(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "aaaa-bbbb-cccc" in html
        assert "2.0" in html
        assert "2026-01-15" in html

    def test_no_findings_table(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "<tbody>" not in html

    def test_no_toc_without_findings(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "Findings by scope" not in html


# ── Tests rapport avec findings (1 scope) ──────────────────


class TestReportWithFindings:
    def test_file_written(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        assert out.exists()
        assert out.stat().st_size > 0

    def test_contains_rule_ids(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert OUT_OF_BASELINE in html
        assert "no-direct-users" in html

    def test_contains_principals(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "user-1111" in html
        assert "group-2222" in html

    def test_contains_roles(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "Contributor" in html
        assert "Reader" in html

    def test_contains_scopes(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert f"/subscriptions/{SUB_1}" in html
        assert "rg-dev" in html

    def test_verdict_shows_count(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "2 finding(s)" in html

    def test_severity_css_classes(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "severity-high" in html
        assert "severity-medium" in html

    def test_severity_colors_present(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "#e74c3c" in html  # HIGH
        assert "#f39c12" in html  # MEDIUM

    def test_findings_sorted_by_severity(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        high_pos = html.index("severity-high")
        medium_pos = html.index("severity-medium")
        assert high_pos < medium_pos

    def test_html_structure(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in html
        assert "<table>" in html
        assert "</table>" in html
        assert "<thead>" in html
        assert "<tbody>" in html

    def test_no_toc_single_scope(self, tmp_path: Path) -> None:
        """No table of contents when all findings are in the same scope."""
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "Findings by scope" not in html

    def test_scope_group_header(self, tmp_path: Path) -> None:
        """Scope group header is present with count badge."""
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "count-badge" in html
        assert "2 finding(s)" in html

    def test_scope_names_in_header(self, tmp_path: Path) -> None:
        """Subscription name appears if scope_names is provided."""
        out = tmp_path / "report.html"
        generate_html_report(
            _report_with_findings(),
            out,
            scope_names={SUB_1.lower(): "Production"},
        )
        html = out.read_text(encoding="utf-8")
        assert "Production" in html


class TestReportDisplayName:
    def test_display_name_shown_in_html(self, tmp_path: Path) -> None:
        """Display name appears with principal_id when available."""
        report = _report_with_findings()
        report.findings[0].principal_display_name = "GRP-TEAM-INFRA"
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "GRP-TEAM-INFRA" in html
        assert "user-1111" in html


# ── Multi-scope report tests (TOC) ─────────────────────────


class TestReportMultiScope:
    def test_toc_present(self, tmp_path: Path) -> None:
        """Table of contents appears when there are 2+ scope groups."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        assert "Findings by scope" in html
        assert 'id="toc"' in html

    def test_toc_links(self, tmp_path: Path) -> None:
        """TOC contains links to scope sections."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        assert "toc-link" in html
        assert f"scope-{SUB_1.replace('-', '-')}" in html.replace("-", "-")

    def test_toc_counts(self, tmp_path: Path) -> None:
        """TOC displays counters by scope."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        # SUB_1 has 2 drift, 0 violations
        # SUB_2 has 0 drift, 1 violation
        assert "Drift" in html or "drift" in html
        assert "Violation" in html or "violation" in html

    def test_back_to_top_links(self, tmp_path: Path) -> None:
        """'Summary' links appear in each scope section."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        assert "back-to-top" in html
        assert "Summary" in html

    def test_two_scope_sections(self, tmp_path: Path) -> None:
        """Two distinct scope sections are generated."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        assert html.count("<tbody>") == 3  # 1 TOC + 2 scope tables

    def test_scope_names_in_toc(self, tmp_path: Path) -> None:
        """Subscription names appear in the TOC."""
        out = tmp_path / "report.html"
        generate_html_report(
            _report_multi_scope(),
            out,
            scope_names={SUB_1.lower(): "Production", SUB_2.lower(): "Development"},
        )
        html = out.read_text(encoding="utf-8")
        assert "Production" in html
        assert "Development" in html

    def test_findings_grouped_correctly(self, tmp_path: Path) -> None:
        """Findings for each scope are in the correct section."""
        out = tmp_path / "report.html"
        generate_html_report(_report_multi_scope(), out)
        html = out.read_text(encoding="utf-8")
        # Use id= to find actual sections (not TOC links)
        sub1_section_start = html.index(f'id="scope-{SUB_1}"')
        sub2_section_start = html.index(f'id="scope-{SUB_2}"')
        user_1111_pos = html.index("user-1111")
        group_4444_pos = html.index("group-4444")
        assert sub1_section_start < user_1111_pos < sub2_section_start
        assert sub2_section_start < group_4444_pos


# ── Scan error tests ─────────────────────────────────────


class TestReportWithErrors:
    def test_contains_error_section(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_errors(), out)
        html = out.read_text(encoding="utf-8")
        assert "Scan errors" in html

    def test_contains_error_messages(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_errors(), out)
        html = out.read_text(encoding="utf-8")
        assert "access denied" in html or "access denied" in html
        assert "Timeout" in html

    def test_no_error_section_when_empty(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "Scan errors" not in html


# ── Security tests ──────────────────────────────────────────


class TestHtmlEscaping:
    def test_xss_in_principal_id(self, tmp_path: Path) -> None:
        """Verify that values are escaped (no XSS)."""
        report = _empty_report()
        report.findings = [
            ComplianceFinding(
                rule_id=OUT_OF_BASELINE,
                severity=Severity.HIGH,
                message="test",
                principal_id='<script>alert("xss")</script>',
                role_name="Reader",
                scope="/subscriptions/sub-1",
            ),
        ]
        report.summary.total_findings = 1
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert '<script>alert("xss")</script>' not in html
        assert "&lt;script&gt;" in html


# ── TestTruncateScope ────────────────────────────────────────


class TestTruncateScope:
    def test_short_scope_unchanged(self) -> None:
        scope = "/subscriptions/sub-1"
        assert _truncate_scope(scope) == scope

    def test_long_scope_truncated(self) -> None:
        scope = "/subscriptions/sub-1/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/vm-1"
        result = _truncate_scope(scope)
        assert result.startswith("...")
        assert "virtualMachines/vm-1" in result

    def test_exact_threshold(self) -> None:
        scope = "/subscriptions/sub-1/resourceGroups/rg"
        assert _truncate_scope(scope) == scope


# ── TestHtmlWarnings ─────────────────────────────────────────


class TestHtmlWarnings:
    def test_no_warnings_no_banner(self, tmp_path: Path) -> None:
        report = _empty_report()
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "Warnings" not in html

    def test_warnings_shown(self, tmp_path: Path) -> None:
        report = _empty_report()
        report.warnings = ["Graph API indisponible"]
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "Warnings" in html
        assert "Graph API indisponible" in html


# ── TestHtmlFiltering ────────────────────────────────────────


class TestHtmlFiltering:
    def test_filter_bar_present(self, tmp_path: Path) -> None:
        report = _report_with_findings()
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "filter-bar" in html
        assert "toggleFilter" in html
        assert "applyFilters" in html
        assert "filter-search" in html

    def test_data_severity_attributes(self, tmp_path: Path) -> None:
        report = _report_with_findings()
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert 'data-severity="high"' in html
        assert 'data-severity="medium"' in html


# ── TestHtmlRemediation ──────────────────────────────────────


class TestHtmlRemediation:
    def test_remediation_shown(self, tmp_path: Path) -> None:
        report = _empty_report()
        report.findings = [
            ComplianceFinding(
                rule_id=GOVERNANCE_VIOLATION,
                severity=Severity.HIGH,
                message="test",
                principal_id="p1",
                role_name="Owner",
                scope=f"/subscriptions/{SUB_1}",
                details={"remediation": "Remove Owner role"},
            ),
        ]
        report.summary.total_findings = 1
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "Remove Owner role" in html
        assert "remediation" in html

    def test_no_remediation_no_div(self, tmp_path: Path) -> None:
        report = _report_with_findings()
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        # Existing findings don't have remediation, so no remediation divs
        assert 'class="remediation"' not in html


# ── TestComplianceScore ─────────────────────────────────────


class TestComplianceScore:
    def test_no_assignments(self) -> None:
        assert _compute_compliance_score(0, 0) == 100

    def test_no_findings(self) -> None:
        assert _compute_compliance_score(50, 0) == 100

    def test_all_findings(self) -> None:
        assert _compute_compliance_score(10, 10) == 0

    def test_partial(self) -> None:
        assert _compute_compliance_score(100, 13) == 87

    def test_rounding(self) -> None:
        assert _compute_compliance_score(3, 1) == 67

    def test_more_findings_than_assignments(self) -> None:
        assert _compute_compliance_score(5, 8) == 0


# ── TestScoreColor ──────────────────────────────────────────


class TestScoreColor:
    def test_green(self) -> None:
        assert _score_color(90) == "#27ae60"
        assert _score_color(100) == "#27ae60"

    def test_yellow(self) -> None:
        assert _score_color(70) == "#f39c12"
        assert _score_color(89) == "#f39c12"

    def test_orange(self) -> None:
        assert _score_color(50) == "#e67e22"
        assert _score_color(69) == "#e67e22"

    def test_red(self) -> None:
        assert _score_color(0) == "#e74c3c"
        assert _score_color(49) == "#e74c3c"


# ── TestExecutiveSummary ────────────────────────────────────


class TestExecutiveSummary:
    def test_no_findings(self) -> None:
        summary = _build_executive_summary(total_assignments=50, scope_count=3, findings_by_severity={})
        assert "50 assignments" in summary
        assert "3 scopes" in summary
        assert "No findings" in summary

    def test_with_findings(self) -> None:
        summary = _build_executive_summary(
            total_assignments=128,
            scope_count=3,
            findings_by_severity={"critical": 2, "high": 3, "medium": 2},
        )
        assert "128 assignments" in summary
        assert "7 findings" in summary
        assert "2 critical" in summary
        assert "3 high" in summary
        assert "2 medium" in summary

    def test_single_scope(self) -> None:
        summary = _build_executive_summary(total_assignments=10, scope_count=1, findings_by_severity={"low": 1})
        assert "1 scope" in summary
        assert "1 finding" in summary

    def test_zero_assignments(self) -> None:
        summary = _build_executive_summary(total_assignments=0, scope_count=0, findings_by_severity={})
        assert "0 assignments" in summary


# ── TestDonutArcs ───────────────────────────────────────────


class TestDonutArcs:
    def test_empty_findings(self) -> None:
        arcs = _compute_donut_arcs({})
        assert arcs == []

    def test_single_severity(self) -> None:
        arcs = _compute_donut_arcs({"critical": 5})
        assert len(arcs) == 1
        assert arcs[0].severity == "critical"
        assert arcs[0].count == 5
        assert arcs[0].percentage == 100.0
        assert arcs[0].offset == 0.0

    def test_two_severities(self) -> None:
        arcs = _compute_donut_arcs({"critical": 1, "high": 3})
        assert len(arcs) == 2
        assert arcs[0].severity == "critical"
        assert arcs[0].percentage == 25.0
        assert arcs[0].offset == 0.0
        assert arcs[1].severity == "high"
        assert arcs[1].percentage == 75.0
        assert arcs[1].offset == 25.0

    def test_severity_order(self) -> None:
        arcs = _compute_donut_arcs({"low": 1, "critical": 1, "medium": 1})
        severities = [a.severity for a in arcs]
        assert severities == ["critical", "medium", "low"]

    def test_color_mapping(self) -> None:
        arcs = _compute_donut_arcs({"critical": 1})
        assert arcs[0].color == "#dc3545"


# ── TestHtmlComplianceScore ──────────────────────────────────


class TestHtmlComplianceScore:
    def test_score_displayed_in_empty_report(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert "100%" in html
        assert "compliance-score" in html

    def test_score_displayed_with_findings(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        # 20 assignments, 2 findings → 90%
        assert "90%" in html

    def test_score_gauge_svg(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "<svg" in html
        assert "stroke-dasharray" in html

    def test_executive_summary_present(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "executive-summary" in html
        assert "20 assignments" in html


# ── TestHtmlDonutChart ───────────────────────────────────────


class TestHtmlDonutChart:
    def test_donut_present_with_findings(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "donut-chart" in html

    def test_no_donut_without_findings(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_empty_report(), out)
        html = out.read_text(encoding="utf-8")
        assert '<div class="donut-chart">' not in html

    def test_donut_legend(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "donut-legend" in html


# ── TestHtmlOrphanCard ───────────────────────────────────────


class TestHtmlOrphanCard:
    def test_orphan_card_shown(self, tmp_path: Path) -> None:
        report = _report_with_findings()
        report.summary.orphan_count = 3
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "Orphaned" in html

    def test_no_orphan_card_when_zero(self, tmp_path: Path) -> None:
        report = _report_with_findings()
        report.summary.orphan_count = 0
        out = tmp_path / "report.html"
        generate_html_report(report, out)
        html = out.read_text(encoding="utf-8")
        assert "Orphaned" not in html


# ── TestHtmlPortalLinks ────────────────────────────────────


class TestHtmlPortalLinks:
    def test_scope_link_present(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "portal.azure.com" in html
        assert 'target="_blank"' in html

    def test_principal_link_present(self, tmp_path: Path) -> None:
        out = tmp_path / "report.html"
        generate_html_report(_report_with_findings(), out)
        html = out.read_text(encoding="utf-8")
        assert "ManagedAppMenuBlade" in html
        assert "user-1111" in html
