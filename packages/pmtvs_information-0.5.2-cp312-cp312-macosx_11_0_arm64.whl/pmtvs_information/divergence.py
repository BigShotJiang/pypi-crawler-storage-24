"""Divergence and distance between distributions."""
import numpy as np

from pmtvs_information._core import (
    cross_entropy as _rust_ce,
    hellinger_distance as _rust_hd,
    total_variation_distance as _rust_tvd,
)


def cross_entropy(p, q, bins=None, base=2):
    """Cross entropy H(P, Q) = -sum(p * log(q))."""
    p = np.ascontiguousarray(np.asarray(p, dtype=np.float64).flatten())
    q = np.ascontiguousarray(np.asarray(q, dtype=np.float64).flatten())
    p = p[np.isfinite(p)]
    q = q[np.isfinite(q)]
    if len(p) == 0 or len(q) == 0:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_ce(p, q, nb, float(base)))


def hellinger_distance(p, q, bins=None):
    """Hellinger distance between distributions."""
    p = np.ascontiguousarray(np.asarray(p, dtype=np.float64).flatten())
    q = np.ascontiguousarray(np.asarray(q, dtype=np.float64).flatten())
    p = p[np.isfinite(p)]
    q = q[np.isfinite(q)]
    if len(p) == 0 or len(q) == 0:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_hd(p, q, nb))


def total_variation_distance(p, q, bins=None):
    """Total variation distance TV(P,Q) = 0.5 * sum(|p-q|)."""
    p = np.ascontiguousarray(np.asarray(p, dtype=np.float64).flatten())
    q = np.ascontiguousarray(np.asarray(q, dtype=np.float64).flatten())
    p = p[np.isfinite(p)]
    q = q[np.isfinite(q)]
    if len(p) == 0 or len(q) == 0:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_tvd(p, q, nb))
