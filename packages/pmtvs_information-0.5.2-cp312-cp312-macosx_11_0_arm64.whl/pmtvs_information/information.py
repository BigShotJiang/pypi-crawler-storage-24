"""
Information Theory Functions
"""

import numpy as np
from typing import Optional

from pmtvs_information._core import (
    mutual_information as _rust_mi,
    transfer_entropy as _rust_te,
    conditional_entropy as _rust_ce,
    joint_entropy as _rust_je,
    kl_divergence as _rust_kl,
    js_divergence as _rust_js,
    information_gain as _rust_ig,
)


def mutual_information(x, y, n_bins=10):
    """Compute mutual information between two signals."""
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    if len(x) != len(y) or len(x) < 2:
        return np.nan
    return float(_rust_mi(x, y, n_bins))


def transfer_entropy(source, target, lag=1, n_bins=10):
    """Compute transfer entropy from source to target."""
    source = np.ascontiguousarray(np.asarray(source, dtype=np.float64).flatten())
    target = np.ascontiguousarray(np.asarray(target, dtype=np.float64).flatten())
    n = min(len(source), len(target))
    if n < lag + 2:
        return np.nan
    return float(_rust_te(source[:n], target[:n], n_bins, lag))


def conditional_entropy(x, y, n_bins=10):
    """Compute conditional entropy H(X|Y)."""
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return float(_rust_ce(x, y, n_bins))


def joint_entropy(x, y, n_bins=10):
    """Compute joint entropy H(X,Y)."""
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return float(_rust_je(x, y, n_bins))


def _entropy(x, n_bins=10):
    """Compute Shannon entropy."""
    from pmtvs_information._core import shannon_entropy
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    return float(shannon_entropy(x, n_bins, 2.0))


def kl_divergence(p, q, n_bins=10):
    """Compute KL divergence D_KL(P||Q)."""
    p = np.ascontiguousarray(np.asarray(p, dtype=np.float64).flatten())
    q = np.ascontiguousarray(np.asarray(q, dtype=np.float64).flatten())
    return float(_rust_kl(p, q, n_bins))


def js_divergence(p, q, n_bins=10):
    """Compute Jensen-Shannon divergence."""
    p = np.ascontiguousarray(np.asarray(p, dtype=np.float64).flatten())
    q = np.ascontiguousarray(np.asarray(q, dtype=np.float64).flatten())
    return float(_rust_js(p, q, n_bins))


def information_gain(x, y, n_bins=10):
    """Compute information gain IG(X;Y) = H(X) - H(X|Y)."""
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return float(_rust_ig(x, y, n_bins))
