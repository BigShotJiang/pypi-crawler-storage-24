"""
pmtvs-information — Information theory primitives.

Rust backend (_core) required for hot-path functions.
"""

__version__ = "0.5.1"

try:
    from pmtvs_information._core import (
        mutual_information,
        transfer_entropy,
        batch_transfer_entropy_py as batch_transfer_entropy,
        cond_mutual_information,
        cond_mutual_information as conditional_mutual_information,
    )
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-information && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

BACKEND = "rust"

from pmtvs_information.information import (
    conditional_entropy,
    joint_entropy,
    kl_divergence,
    js_divergence,
    information_gain,
)

from pmtvs_information.entropy import (
    shannon_entropy,
    renyi_entropy,
    tsallis_entropy,
)

from pmtvs_information.divergence import (
    cross_entropy,
    hellinger_distance,
    total_variation_distance,
)

from pmtvs_information.mutual import (
    multivariate_mutual_information,
    total_correlation,
    interaction_information,
    dual_total_correlation,
)

from pmtvs_information.decomposition import (
    partial_information_decomposition,
    redundancy,
    synergy,
    information_atoms,
)

from pmtvs_information.causality import (
    granger_causality,
    convergent_cross_mapping,
    phase_coupling,
    information_flow,
)

__all__ = [
    "__version__",
    "BACKEND",
    # Rust-accelerated
    "batch_transfer_entropy",
    "cond_mutual_information",
    # information.py
    "mutual_information",
    "transfer_entropy",
    "conditional_entropy",
    "joint_entropy",
    "kl_divergence",
    "js_divergence",
    "information_gain",
    # entropy.py
    "shannon_entropy",
    "renyi_entropy",
    "tsallis_entropy",
    # divergence.py
    "cross_entropy",
    "hellinger_distance",
    "total_variation_distance",
    # mutual.py
    "conditional_mutual_information",
    "multivariate_mutual_information",
    "total_correlation",
    "interaction_information",
    "dual_total_correlation",
    # decomposition.py
    "partial_information_decomposition",
    "redundancy",
    "synergy",
    "information_atoms",
    # causality.py
    "granger_causality",
    "convergent_cross_mapping",
    "phase_coupling",
    "information_flow",
]
