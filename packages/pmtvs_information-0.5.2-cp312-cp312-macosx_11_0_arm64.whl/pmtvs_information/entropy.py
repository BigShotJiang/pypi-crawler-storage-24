"""Entropy variant primitives."""
import numpy as np

from pmtvs_information._core import (
    shannon_entropy as _rust_shannon,
    renyi_entropy as _rust_renyi,
    tsallis_entropy as _rust_tsallis,
)


def _estimate_probabilities(data, bins=None):
    data = np.asarray(data, dtype=np.float64).flatten()
    data = data[np.isfinite(data)]
    if len(data) < 2:
        return np.array([])
    if bins is None:
        bins = max(10, int(np.sqrt(len(data))))
    counts, _ = np.histogram(data, bins=bins)
    probs = counts / counts.sum()
    return probs[probs > 0]


def shannon_entropy(data, bins=None, base=2):
    """Shannon entropy H(X) = -sum(p * log(p))."""
    data = np.ascontiguousarray(np.asarray(data, dtype=np.float64).flatten())
    data = data[np.isfinite(data)]
    if len(data) < 2:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_shannon(data, nb, float(base)))


def renyi_entropy(data, alpha=2.0, bins=None, base=2):
    """Renyi entropy of order alpha."""
    data = np.ascontiguousarray(np.asarray(data, dtype=np.float64).flatten())
    data = data[np.isfinite(data)]
    if len(data) < 2:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_renyi(data, alpha, nb, float(base)))


def tsallis_entropy(data, q=2.0, bins=None):
    """Tsallis entropy."""
    data = np.ascontiguousarray(np.asarray(data, dtype=np.float64).flatten())
    data = data[np.isfinite(data)]
    if len(data) < 2:
        return np.nan
    nb = bins if bins is not None else -1
    return float(_rust_tsallis(data, q, nb))
