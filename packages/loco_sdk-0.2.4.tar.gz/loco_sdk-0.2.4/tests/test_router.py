"""Tests for RequestRouter."""

import pytest

from loco_sdk.plugin.server.router import RequestRouter


class FakeHandler:
    """Minimal handler for testing."""

    def __init__(self, tag: str = "default"):
        self.tag = tag

    async def handle(self, method, params):
        return {"handler": self.tag, "method": method, "params": params}


class TestRequestRouter:
    def test_register_handler(self):
        router = RequestRouter()
        router.register("test", FakeHandler())
        assert "test" in router._handlers

    @pytest.mark.asyncio
    async def test_exact_match(self):
        router = RequestRouter()
        router.register("execute_node", FakeHandler("node"))
        result = await router.route("execute_node", {"a": 1})
        assert result["handler"] == "node"
        assert result["method"] == "execute_node"

    @pytest.mark.asyncio
    async def test_prefix_match(self):
        router = RequestRouter()
        router.register("ai_provider", FakeHandler("ai"))
        result = await router.route("ai_provider:invoke", {"b": 2})
        assert result["handler"] == "ai"
        assert result["method"] == "ai_provider:invoke"

    @pytest.mark.asyncio
    async def test_no_handler_raises(self):
        router = RequestRouter()
        with pytest.raises(ValueError, match="No handler registered"):
            await router.route("unknown_method", {})

    @pytest.mark.asyncio
    async def test_multiple_handlers(self):
        router = RequestRouter()
        router.register("execute_node", FakeHandler("node"))
        router.register("ai_provider", FakeHandler("ai"))

        r1 = await router.route("execute_node", {})
        r2 = await router.route("ai_provider:embed", {})

        assert r1["handler"] == "node"
        assert r2["handler"] == "ai"

    @pytest.mark.asyncio
    async def test_exact_match_takes_precedence(self):
        """If a handler is registered with the full method name, it wins."""
        router = RequestRouter()
        router.register("ai_provider", FakeHandler("prefix"))
        router.register("ai_provider:invoke", FakeHandler("exact"))

        result = await router.route("ai_provider:invoke", {})
        assert result["handler"] == "exact"
