"""Tests for the refactored PluginServer (slim orchestrator)."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from loco_sdk.plugin.base import NodePlugin
from loco_sdk.plugin.server.server import PluginServer


class EchoNode(NodePlugin):
    async def execute(self, inputs, context):
        return {"echo": inputs}


class TestPluginServerHandleRequest:
    """Test handle_request dispatching without actual stdin/stdout."""

    @pytest.fixture
    def server(self, tmp_path):
        return PluginServer(plugin_dir=tmp_path)

    @pytest.mark.asyncio
    async def test_ping(self, server):
        resp = await server.handle_request({"jsonrpc": "2.0", "method": "ping", "id": 1})
        assert resp["result"]["status"] == "ok"
        assert resp["id"] == 1

    @pytest.mark.asyncio
    async def test_shutdown(self, server):
        server.running = True
        resp = await server.handle_request({"jsonrpc": "2.0", "method": "shutdown", "id": 2})
        assert resp["result"]["status"] == "shutting_down"
        assert server.running is False

    @pytest.mark.asyncio
    async def test_unknown_method_returns_error(self, server):
        resp = await server.handle_request({"jsonrpc": "2.0", "method": "nonexistent", "id": 3})
        assert resp["error"]["code"] == -32601

    @pytest.mark.asyncio
    async def test_execute_node_via_router(self, server):
        """Register a node handler directly and verify routing works."""
        from concurrent.futures import ThreadPoolExecutor

        from loco_sdk.plugin.server.handlers.node_handler import NodeHandler

        handler = NodeHandler({"echo": EchoNode}, ThreadPoolExecutor(max_workers=1))
        server.router.register("execute_node", handler)

        resp = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "method": "execute_node",
                "params": {
                    "node_name": "echo",
                    "inputs": {"val": 42},
                    "context": {},
                },
                "id": 4,
            }
        )
        assert resp["result"]["echo"] == {"val": 42}
        assert resp["id"] == 4


class TestPluginServerDiscovery:
    """Test _discover_and_register with mocked discovery."""

    @pytest.mark.asyncio
    async def test_discover_registers_handlers(self, tmp_path):
        """Mocking discovery classes so we don't need real plugin files."""
        server = PluginServer(plugin_dir=tmp_path)

        with (
            patch("loco_sdk.plugin.server.server.NodeDiscovery") as MockNodeDisc,
            patch("loco_sdk.plugin.server.server.AIProviderDiscovery") as MockAIDisc,
        ):
            MockNodeDisc.return_value.discover.return_value = {"echo": EchoNode}
            MockAIDisc.return_value.discover.return_value = {}

            summary = server._discover_and_register()

        assert summary["nodes"] == ["echo"]
        assert summary["ai_providers"] == []
        assert "execute_node" in server.router._handlers

    @pytest.mark.asyncio
    async def test_discover_no_nodes_dir(self, tmp_path):
        """NodeDiscovery raises FileNotFoundError → gracefully skipped."""
        server = PluginServer(plugin_dir=tmp_path)

        with (
            patch("loco_sdk.plugin.server.server.NodeDiscovery") as MockNodeDisc,
            patch("loco_sdk.plugin.server.server.AIProviderDiscovery") as MockAIDisc,
        ):
            MockNodeDisc.return_value.discover.side_effect = FileNotFoundError
            MockAIDisc.return_value.discover.return_value = {}

            summary = server._discover_and_register()

        assert summary["nodes"] == []
        assert "execute_node" not in server.router._handlers
