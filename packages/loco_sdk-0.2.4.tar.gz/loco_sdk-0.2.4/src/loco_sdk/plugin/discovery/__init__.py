"""Component discovery module.

Provides pluggable discovery for different component types
(nodes, AI providers) inside a plugin directory.
"""

from loco_sdk.plugin.discovery.ai_discovery import AIProviderDiscovery
from loco_sdk.plugin.discovery.base import ComponentDiscovery
from loco_sdk.plugin.discovery.node_discovery import NodeDiscovery

__all__ = [
    "ComponentDiscovery",
    "NodeDiscovery",
    "AIProviderDiscovery",
]
