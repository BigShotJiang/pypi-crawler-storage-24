"""Abstract base for component discovery."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any


class ComponentDiscovery(ABC):
    """Base class for discovering plugin components from a directory.

    Subclasses implement :meth:`discover` to scan a specific subdirectory
    (``nodes/``, ``providers/``, …) and return a mapping of component
    names to their classes.

    Args:
        plugin_dir: Root path of the plugin (contains ``nodes/``, ``providers/``, etc.).
    """

    def __init__(self, plugin_dir: Path):
        self.plugin_dir = plugin_dir

    @abstractmethod
    def discover(self) -> dict[str, type[Any]]:
        """Discover components and return ``{name: cls}``."""
