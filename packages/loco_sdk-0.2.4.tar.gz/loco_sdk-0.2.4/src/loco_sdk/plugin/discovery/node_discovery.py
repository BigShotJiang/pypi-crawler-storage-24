"""Node component discovery.

Extracted from ``PluginServer.discover_nodes()`` — same logic, standalone class.
"""

import logging
import sys
import traceback
from importlib import import_module

from loco_sdk.plugin.base import NodePlugin
from loco_sdk.plugin.discovery.base import ComponentDiscovery

logger = logging.getLogger(__name__)


class NodeDiscovery(ComponentDiscovery):
    """Discover :class:`NodePlugin` subclasses in ``nodes/`` directory.

    For each ``*.py`` file (excluding ``_``-prefixed), imports the module
    and picks the first ``NodePlugin`` subclass found.

    Returns:
        Mapping of ``{node_name: NodePluginSubclass}``.
    """

    def discover(self) -> dict[str, type[NodePlugin]]:
        nodes_dir = self.plugin_dir / "nodes"
        if not nodes_dir.exists():
            raise FileNotFoundError(f"Nodes directory not found: {nodes_dir}")

        nodes: dict[str, type[NodePlugin]] = {}
        sys.path.insert(0, str(self.plugin_dir))

        try:
            for node_file in nodes_dir.glob("*.py"):
                if node_file.name.startswith("_"):
                    continue

                module_name = f"nodes.{node_file.stem}"
                try:
                    module = import_module(module_name)

                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (
                            isinstance(attr, type)
                            and issubclass(attr, NodePlugin)
                            and attr is not NodePlugin
                        ):
                            node_name = node_file.stem
                            nodes[node_name] = attr
                            logger.info(f"Loaded node: {node_name} ({attr.__name__})")
                            break

                except Exception as e:
                    logger.error(f"Failed to load node {node_file.name}: {e}")
                    traceback.print_exc()
        finally:
            sys.path.pop(0)

        return nodes
