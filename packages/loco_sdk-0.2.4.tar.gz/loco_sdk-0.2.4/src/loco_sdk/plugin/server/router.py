"""Request router — maps JSON-RPC methods to handlers.

Provides a thin dispatch layer: incoming ``method`` strings are matched
against registered prefixes and forwarded to the corresponding handler.
"""

import logging
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class RequestHandler(Protocol):
    """Protocol that all handler classes must satisfy."""

    async def handle(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Handle a routed request.

        Args:
            method: Full JSON-RPC method name (e.g. ``"ai_provider:invoke"``).
            params: Request parameters.

        Returns:
            Result dict to include in the JSON-RPC response.
        """
        ...


class RequestRouter:
    """Route JSON-RPC methods to registered handlers.

    Handlers are registered with a prefix.  When a request arrives the
    router finds the handler whose prefix matches the method (exact match
    or ``prefix:`` prefix) and delegates to it.

    Built-in methods (``ping``, ``shutdown``) are handled externally by
    :class:`PluginServer` and never reach the router.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, RequestHandler] = {}

    def register(self, prefix: str, handler: RequestHandler) -> None:
        """Register *handler* for all methods starting with *prefix*.

        Args:
            prefix: Method prefix (e.g. ``"execute_node"``, ``"ai_provider"``).
            handler: Handler instance implementing :class:`RequestHandler`.
        """
        self._handlers[prefix] = handler
        logger.debug(f"Registered handler for prefix '{prefix}'")

    async def route(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Route *method* to the appropriate handler.

        Resolution order:
        1. Exact match on *method*.
        2. Prefix match — ``method`` starts with ``"<prefix>:"``.

        Args:
            method: Full JSON-RPC method string.
            params: Request parameters.

        Returns:
            Handler result dict.

        Raises:
            ValueError: If no handler matches.
        """
        # Exact match
        handler = self._handlers.get(method)
        if handler is not None:
            return await handler.handle(method, params)

        # Prefix match (e.g. "ai_provider:invoke" → prefix "ai_provider")
        prefix = method.split(":")[0] if ":" in method else None
        if prefix:
            handler = self._handlers.get(prefix)
            if handler is not None:
                return await handler.handle(method, params)

        raise ValueError(f"No handler registered for method: {method}")
