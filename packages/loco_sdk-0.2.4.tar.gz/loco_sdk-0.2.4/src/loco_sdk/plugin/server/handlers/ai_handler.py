"""AI provider handler.

Handles ``ai_provider:*`` JSON-RPC requests by dispatching to the
appropriate :class:`AIProviderPlugin` subclass.

Supported sub-methods:
    - ``ai_provider:invoke``
    - ``ai_provider:stream``
    - ``ai_provider:embed``
    - ``ai_provider:rerank``
    - ``ai_provider:validate_credentials``
    - ``ai_provider:list_models``
"""

import logging
from typing import Any

from loco_sdk.plugin.ai_provider import AIProviderPlugin

logger = logging.getLogger(__name__)


class AIHandler:
    """Handle ``ai_provider:*`` JSON-RPC requests.

    Args:
        providers: Mapping of ``{provider_name: AIProviderPluginClass}``
                   from :class:`AIProviderDiscovery`.
    """

    def __init__(self, providers: dict[str, type[AIProviderPlugin]]):
        self.providers = providers

    async def handle(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Dispatch to the correct sub-handler based on *method*.

        Args:
            method: Full method name (e.g. ``"ai_provider:invoke"``).
            params: Request parameters.  Must include ``provider_name``
                    and ``credentials``.

        Returns:
            Result dict.

        Raises:
            ValueError: If provider or sub-method is invalid.
        """
        # e.g. "ai_provider:invoke" → "invoke"
        _, _, action = method.partition(":")
        if not action:
            raise ValueError(f"Invalid ai_provider method: {method}")

        provider_name = params.get("provider_name")
        if not provider_name:
            raise ValueError("Missing required parameter: provider_name")

        provider_cls = self.providers.get(provider_name)
        if not provider_cls:
            raise ValueError(f"AI provider not found: {provider_name}")

        # Instantiate and inject credentials
        provider = provider_cls()
        credentials = params.get("credentials", {})
        provider.set_credentials(credentials)

        dispatch = {
            "invoke": self._handle_invoke,
            "stream": self._handle_stream,
            "embed": self._handle_embed,
            "rerank": self._handle_rerank,
            "validate_credentials": self._handle_validate,
            "list_models": self._handle_list_models,
        }

        handler_fn = dispatch.get(action)
        if handler_fn is None:
            raise ValueError(f"Unknown ai_provider action: {action}")

        return await handler_fn(provider, params)

    # ── Sub-handlers ─────────────────────────────────────────

    @staticmethod
    async def _handle_invoke(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_llm():
            raise ValueError(
                f"Provider '{provider.provider_name}' does not support invoke (not an LLM)"
            )
        inner = params.get("params", {})
        return await provider.invoke(
            model=inner["model"],
            messages=inner["messages"],
            temperature=inner.get("temperature", 0.7),
            max_tokens=inner.get("max_tokens"),
            tools=inner.get("tools"),
            stream=inner.get("stream", False),
        )

    @staticmethod
    async def _handle_stream(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_llm():
            raise ValueError(
                f"Provider '{provider.provider_name}' does not support stream (not an LLM)"
            )
        inner = params.get("params", {})
        # Collect all chunks into a list for JSON-RPC response.
        # Real streaming over stdio would use line-delimited JSON,
        # which is handled at the transport layer, not here.
        chunks: list[dict[str, Any]] = []
        async for chunk in provider.stream(
            model=inner["model"],
            messages=inner["messages"],
            **{k: v for k, v in inner.items() if k not in ("model", "messages")},
        ):
            chunks.append(chunk)
        return {"chunks": chunks}

    @staticmethod
    async def _handle_embed(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_embedding():
            raise ValueError(f"Provider '{provider.provider_name}' does not support embed")
        inner = params.get("params", {})
        return await provider.embed(
            model=inner["model"],
            texts=inner["texts"],
            dimensions=inner.get("dimensions"),
        )

    @staticmethod
    async def _handle_rerank(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_rerank():
            raise ValueError(f"Provider '{provider.provider_name}' does not support rerank")
        inner = params.get("params", {})
        return await provider.rerank(
            model=inner["model"],
            query=inner["query"],
            documents=inner["documents"],
            top_n=inner.get("top_n"),
        )

    @staticmethod
    async def _handle_validate(
        provider: AIProviderPlugin, params: dict[str, Any]
    ) -> dict[str, Any]:
        credentials = params.get("credentials", {})
        valid = await provider.validate_credentials(credentials)
        return {"valid": valid}

    @staticmethod
    async def _handle_list_models(
        provider: AIProviderPlugin, params: dict[str, Any]
    ) -> dict[str, Any]:
        models = await provider.list_models()
        return {"models": models}
