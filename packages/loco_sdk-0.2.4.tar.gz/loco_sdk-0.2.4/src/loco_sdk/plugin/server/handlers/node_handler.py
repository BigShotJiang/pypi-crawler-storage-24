"""Node execution handler.

Handles ``execute_node`` JSON-RPC requests by instantiating the correct
:class:`NodePlugin` subclass and running its ``execute`` method.
"""

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from loco_sdk.plugin.base import NodePlugin

logger = logging.getLogger(__name__)


class NodeHandler:
    """Handle ``execute_node`` requests.

    Args:
        nodes: Mapping of ``{node_name: NodePluginClass}`` from discovery.
        executor: Thread pool for running plugin code that may block.
    """

    def __init__(
        self,
        nodes: dict[str, type[NodePlugin]],
        executor: ThreadPoolExecutor,
    ):
        self.nodes = nodes
        self.executor = executor

    async def handle(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Execute a node plugin.

        Expected *params*:
            - ``node_name``: Name of the node to run.
            - ``inputs``: Node inputs dict.
            - ``context``: Workflow execution context dict.

        Returns:
            Node execution result dict.

        Raises:
            ValueError: If ``node_name`` is missing or unknown.
        """
        node_name = params.get("node_name")
        if not node_name:
            raise ValueError("Missing required parameter: node_name")

        node_class = self.nodes.get(node_name)
        if not node_class:
            raise ValueError(f"Node not found: {node_name}")

        inputs = params.get("inputs", {})
        context = params.get("context", {})

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor,
            self._execute_sync,
            node_class,
            inputs,
            context,
        )

    @staticmethod
    def _execute_sync(
        node_class: type[NodePlugin],
        inputs: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Run ``node.execute()`` synchronously inside a thread."""
        node = node_class()
        return asyncio.run(node.execute(inputs, context))
