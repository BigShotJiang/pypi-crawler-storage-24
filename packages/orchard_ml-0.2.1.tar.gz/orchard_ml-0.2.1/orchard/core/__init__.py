"""
Core Utilities Package.

This package exposes the essential components for configuration, logging,
system management, project constants, and the dynamic dataset registry.
It also includes the RootOrchestrator to manage experiment lifecycle initialization.
"""

# Configuration
from .config import (
    ArchitectureConfig,
    AugmentationConfig,
    Config,
    DatasetConfig,
    EvaluationConfig,
    ExportConfig,
    HardwareConfig,
    OptunaConfig,
    TelemetryConfig,
    TrackingConfig,
    TrainingConfig,
)

# Environment Orchestration
from .config.infrastructure_config import InfraManagerProtocol

# Environment & Hardware
from .environment import (
    apply_cpu_threads,
    configure_system_libraries,
    detect_best_device,
    determine_tta_mode,
    ensure_single_instance,
    get_accelerator_name,
    get_num_workers,
    has_mps_backend,
    release_single_instance,
    set_seed,
    to_device_obj,
    worker_init_fn,
)
from .environment.timing import TimeTracker, TimeTrackerProtocol

# Input/Output Utilities
from .io import (
    load_config_from_yaml,
    load_model_weights,
    md5_checksum,
    save_config_as_yaml,
    validate_npz_keys,
)

# Logging
from .logger import (
    Logger,
    LogStyle,
    Reporter,
    log_optimization_header,
    log_optimization_summary,
    log_pipeline_summary,
    log_trial_start,
)

# Dataset Registry
from .metadata import DatasetMetadata, DatasetRegistryWrapper
from .orchestrator import RootOrchestrator

# Constants & Paths
from .paths import (
    DATASET_DIR,
    LOGGER_NAME,
    OUTPUTS_ROOT,
    PROJECT_ROOT,
    STATIC_DIRS,
    RunPaths,
    get_project_root,
    setup_static_directories,
)

__all__ = [
    # Configuration
    "Config",
    "HardwareConfig",
    "TelemetryConfig",
    "DatasetConfig",
    "ArchitectureConfig",
    "TrainingConfig",
    "AugmentationConfig",
    "EvaluationConfig",
    "OptunaConfig",
    "ExportConfig",
    "TrackingConfig",
    # Constants & Paths
    "PROJECT_ROOT",
    "DATASET_DIR",
    "OUTPUTS_ROOT",
    "STATIC_DIRS",
    "LOGGER_NAME",
    "RunPaths",
    "setup_static_directories",
    "get_project_root",
    # Metadata
    "DatasetMetadata",
    "DatasetRegistryWrapper",
    # Orchestration
    "RootOrchestrator",
    "InfraManagerProtocol",
    "TimeTracker",
    "TimeTrackerProtocol",
    # Logging
    "Logger",
    "Reporter",
    "log_optimization_header",
    "LogStyle",
    "log_trial_start",
    "log_optimization_summary",
    "log_pipeline_summary",
    # Environment
    "set_seed",
    "detect_best_device",
    "get_num_workers",
    "get_accelerator_name",
    "has_mps_backend",
    "to_device_obj",
    "configure_system_libraries",
    "apply_cpu_threads",
    "determine_tta_mode",
    "worker_init_fn",
    "ensure_single_instance",
    "release_single_instance",
    # I/O
    "save_config_as_yaml",
    "load_config_from_yaml",
    "load_model_weights",
    "validate_npz_keys",
    "md5_checksum",
]
