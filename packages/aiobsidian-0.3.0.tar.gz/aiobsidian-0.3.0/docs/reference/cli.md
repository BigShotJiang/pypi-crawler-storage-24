# ObsidianCLI

::: aiobsidian.ObsidianCLI
