# ObsidianClient (REST)

::: aiobsidian.ObsidianClient
