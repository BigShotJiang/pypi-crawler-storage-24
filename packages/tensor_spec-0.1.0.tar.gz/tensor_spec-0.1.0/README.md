# tensor-spec

<p align="center">
   <a href="https://python.org/" target="_blank"><img alt="PyPI - Python Version" src="https://img.shields.io/pypi/pyversions/tensor-spec?logo=python&style=flat-square"></a>
   <a href="https://pypi.org/project/tensor-spec/" target="_blank"><img src="https://img.shields.io/pypi/v/tensor-spec?style=flat-square" alt="pypi"></a>
   <a href="https://pypi.org/project/tensor-spec/" target="_blank"><img alt="PyPI - Downloads" src="https://img.shields.io/pypi/dm/tensor-spec?style=flat-square"></a>
   <a href="LICENSE"><img alt="LICENSE" src="https://img.shields.io/github/license/zrr1999/tensor-spec?style=flat-square"></a>
   <br/>
   <a href="https://codecov.io/gh/zrr1999/tensor-spec"><img src="https://codecov.io/gh/zrr1999/tensor-spec/graph/badge.svg"/></a>
   <br/>
   <a href="https://github.com/astral-sh/uv"><img alt="uv" src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json&style=flat-square"></a>
   <a href="https://github.com/astral-sh/ruff"><img alt="ruff" src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json&style=flat-square"></a>
   <a href="https://gitmoji.dev"><img alt="Gitmoji" src="https://img.shields.io/badge/gitmoji-%20😜%20😍-FFDD67?style=flat-square"></a>
</p>

## Overview

tensor-spec is a framework-agnostic deep learning API quality verification tool. It compares tensor operation precision across deep learning frameworks (currently PaddlePaddle vs PyTorch) using process isolation and CUDA IPC zero-copy GPU data sharing.

## Features

- **Framework-agnostic** -- Pluggable backend architecture supporting PaddlePaddle and PyTorch
- **Process isolation** -- Each framework runs in its own subprocess to avoid CUDA/import conflicts
- **CUDA IPC zero-copy** -- GPU tensor sharing via CUDA IPC handles (1000x faster than CPU roundtrip)
- **Secure config parsing** -- Whitelist recursive descent parser (no `eval()`)
- **Constraint-driven data generation** -- Generate test tensors from specs with composable constraints
- **Per-API tolerance** -- Configurable atol/rtol with TOML-based overrides per operator
- **Structured logging** -- JSON Lines output for machine-parseable test results
- **CLI interface** -- `run`, `validate`, and `accuracy` commands via Typer

## Installation

```bash
pip install tensor-spec
```

Or with [uv](https://github.com/astral-sh/uv):

```bash
uv add tensor-spec
```

## Quick Start

```bash
# Validate a case config (parse-only, no framework needed)
tensor-spec validate "abs(x=Tensor.float32((2, 3)))"

# Run single-backend execution
tensor-spec run --backend paddle "abs(x=Tensor.float32((2, 3)))"

# Cross-framework accuracy comparison (subprocess-isolated)
tensor-spec accuracy "matmul(x=Tensor.float32((2, 3)), y=Tensor.float32((3, 4)))"
```

## Development

### Prerequisites

- Python >= 3.12
- [uv](https://github.com/astral-sh/uv) for dependency management
- [just](https://github.com/casey/just) for task running

### Setup

```bash
just install
```

### Common Commands

```bash
just            # List all available commands
just format     # Format code (Python + justfile)
just lint       # Run linter
just check      # Type checking (pyright)
just test       # Run all tests
just cov        # Run tests with coverage
just docs       # Serve docs locally
just ci         # Full CI check (format + check + lint + cov)
```

## Architecture

The project follows a 10-layer modular architecture:

| Layer | Module | Responsibility |
|-------|--------|---------------|
| 1 | `spec` | Pure data structures for tensor specifications |
| 2 | `config` | Secure whitelist recursive descent parser |
| 3 | `datagen` | Constraint-driven numpy array generation |
| 4 | `backend` | Pluggable framework backends (Paddle, PyTorch) |
| 5 | `mapping` | API name/argument mapping between frameworks |
| 6 | `compare` | Tensor comparison with configurable tolerance |
| 7 | `tester` | Test execution modes (in-process, isolated) |
| 8 | `worker` | Subprocess management and IPC protocol |
| 9 | `ipc` | SharedMemory (CPU) and CUDA IPC (GPU) transport |
| 10 | `cli` | Typer-based CLI entry point |

## Documentation

For detailed usage and API documentation, please visit our [documentation site](https://zrr1999.github.io/tensor-spec/).

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for development setup and contribution guidelines.
