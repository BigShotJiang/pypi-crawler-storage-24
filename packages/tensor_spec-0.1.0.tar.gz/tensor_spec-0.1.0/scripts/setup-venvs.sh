#!/usr/bin/env bash
# scripts/setup-venvs.sh
#
# 为 tensor-spec 精度对比创建隔离的框架虚拟环境。
#
# 用法:
#   bash scripts/setup-venvs.sh            # 创建 paddle + torch 两个 venv
#   bash scripts/setup-venvs.sh paddle     # 只创建 paddle
#   bash scripts/setup-venvs.sh torch      # 只创建 torch
#
# 创建后的目录结构:
#   .tensor_spec/venvs/paddle/bin/python
#   .tensor_spec/venvs/torch/bin/python
#
# 每个 venv 安装:
#   1. tensor-spec 本体 (editable，提供 worker 进程)
#   2. numpy (tensor-spec 的依赖，自动带入)
#   3. 对应的框架包
#
# 环境变量:
#   PYTHON_VERSION  — 指定 Python 版本 (默认: 3.10)
#   CUDA_VERSION    — paddle 的 CUDA 版本 (默认: cu129)
#   TORCH_INDEX     — torch 的 index URL (默认: cu124)
#   PADDLE_VERSION  — paddlepaddle-gpu 版本 (默认: 不限定)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

VENV_BASE="$PROJECT_ROOT/.tensor_spec/venvs"
PYTHON_VERSION="${PYTHON_VERSION:-3.10}"
CUDA_VERSION="${CUDA_VERSION:-cu129}"
TORCH_INDEX="${TORCH_INDEX:-https://download.pytorch.org/whl/cu124}"
PADDLE_VERSION="${PADDLE_VERSION:-}"

# 检查 uv 是否可用
if ! command -v uv &>/dev/null; then
    echo "Error: uv is required but not found. Install: https://docs.astral.sh/uv/"
    exit 1
fi

setup_paddle() {
    local venv_dir="$VENV_BASE/paddle"
    echo "=== Setting up paddle venv at $venv_dir ==="

    if [ -d "$venv_dir" ]; then
        echo "  Venv already exists, reinstalling packages..."
    else
        echo "  Creating venv (Python $PYTHON_VERSION)..."
        uv venv --python "$PYTHON_VERSION" "$venv_dir"
    fi

    local paddle_pkg="paddlepaddle-gpu"
    if [ -n "$PADDLE_VERSION" ]; then
        paddle_pkg="paddlepaddle-gpu==$PADDLE_VERSION"
    fi

    local paddle_index="https://www.paddlepaddle.org.cn/packages/stable/${CUDA_VERSION}/"

    echo "  Installing paddlepaddle-gpu..."
    uv pip install --python "$venv_dir/bin/python" \
        "$paddle_pkg" \
        setuptools \
        -i "$paddle_index" \
        --extra-index-url https://pypi.org/simple/

    echo "  Verifying paddle import..."
    "$venv_dir/bin/python" -c "import paddle; print(f'  paddle {paddle.__version__}')"

    echo "=== paddle venv ready ==="
    echo ""
}

setup_torch() {
    local venv_dir="$VENV_BASE/torch"
    echo "=== Setting up torch venv at $venv_dir ==="

    if [ -d "$venv_dir" ]; then
        echo "  Venv already exists, reinstalling packages..."
    else
        echo "  Creating venv (Python $PYTHON_VERSION)..."
        uv venv --python "$PYTHON_VERSION" "$venv_dir"
    fi

    echo "  Installing tensor-spec (editable) + torch..."
    uv pip install --python "$venv_dir/bin/python" \
        torch \
        --index-url "$TORCH_INDEX" \
        --extra-index-url https://pypi.org/simple/

    echo "  Verifying torch import..."
    "$venv_dir/bin/python" -c "import torch; print(f'  torch {torch.__version__}')"

    echo "=== torch venv ready ==="
    echo ""
}

# ── main ──

mkdir -p "$VENV_BASE"

targets="${1:-all}"

case "$targets" in
    paddle)
        setup_paddle
        ;;
    torch)
        setup_torch
        ;;
    all|"")
        setup_paddle
        setup_torch
        ;;
    *)
        echo "Usage: $0 [paddle|torch|all]"
        exit 1
        ;;
esac

echo "Done. Venvs are at:"
for d in "$VENV_BASE"/*/; do
    [ -d "$d" ] && echo "  $d"
done
echo ""
echo "Run accuracy tests with:"
echo "  tensor-spec accuracy --backend-a paddle --backend-b torch --case 'abs(x=Tensor.float32((100,)))'"
