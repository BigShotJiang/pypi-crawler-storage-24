Task 1: variable_length_memory_efficient_attention — GPU cuda error 700

根因模式: seq_lens 或 kv_seq_lens 中含 0 值

# case 1: seq_lens 以 0 开头
incubate.nn.functional.variable_length_memory_efficient_attention(
    query=Tensor.float16((1, 1, 31, 64)),
    key=Tensor.float16((1, 1, 31, 64)),
    value=Tensor.float16((1, 1, 31, 64)),
    seq_lens=Tensor.int32((2,)).stats(low=0, high=1),   # [0, 1]
    kv_seq_lens=Tensor.int32((2,)).stats(low=1, high=1), # [1, 1]
    mask=Tensor.float16((1, 1, 50, 50)),
    scale=0.125,
)

# case 2: seq_lens 以 0 结尾
# seq_lens=[1, 0], kv_seq_lens=[1, 1]

# case 3: kv_seq_lens 以 0 开头
# seq_lens=[1, 1], kv_seq_lens=[0, 1]

# case 4: kv_seq_lens 以 0 结尾
# seq_lens=[1, 1], kv_seq_lens=[1, 0]

---
Task 2: flashmask_attention — GPU cuda error 700

根因模式: Q/K/V 某个维度为 0（num_heads=0 或 head_dim=0 或 batch=0 或
seq_len=0）

# case 1: query num_heads=0
nn.functional.flashmask_attention(
    query=Tensor.float16((1, 2048, 0, 96)),
    key=Tensor.float16((1, 2048, 8, 96)),
    value=Tensor.float16((1, 2048, 8, 96)),
    startend_row_indices=Tensor.int32((1, 1, 2048, 1)),
    causal=True,
)

# case 2: key num_heads=0
nn.functional.flashmask_attention(
    query=Tensor.float16((1, 2048, 8, 96)),
    key=Tensor.float16((1, 2048, 0, 96)),
    value=Tensor.float16((1, 2048, 8, 96)),
    startend_row_indices=Tensor.int32((1, 1, 2048, 1)),
    causal=True,
)

# case 3: key head_dim=0
# key shape: (1, 2048, 8, 0)

# case 4: value batch=0
# value shape: (0, 2048, 8, 96)

# case 5: value seq_len=0
# value shape: (1, 0, 8, 96)

# case 6: value num_heads=0
# value shape: (1, 2048, 0, 96)

# case 7: value head_dim=0
# value shape: (1, 2048, 8, 0)

---
Task 3: weight_only_linear — GPU cuda error 700

根因模式: weight 第一维为 0 → Tensor.int8((0, N))

# case 1
nn.quant.weight_only_linear(
    x=Tensor.float16((1, 32, 128)),
    weight=Tensor.int8((0, 128)),
    bias=Tensor.float16((288,)),
    weight_scale=Tensor.float16((288,)),
    weight_dtype="int8",
    group_size=-1,
)

# case 2: int4 mode
nn.quant.weight_only_linear(
    x=Tensor.float16((1, 32, 64)),
    weight=Tensor.int8((0, 64)),
    bias=Tensor.float16((256,)),
    weight_scale=Tensor.float16((256,)),
    weight_dtype="int4",
    group_size=-1,
)

# case 3-9: 同一模式，不同 shape，均为 weight 第一维=0
# x shapes: (1,32,64), (100,320), (100,512), (101,64), (123,768), (131,768),
(2,1,512), (2,1,64)

---
Task 4: generate_proposals — GPU cuda error 700

根因模式: im_shape 第二维为 0 → Tensor.float32((N, 0))

# case 1
vision.ops.generate_proposals(
    scores=Tensor.float32((1, 15, 40, 60)),
    bbox_deltas=Tensor.float32((1, 60, 40, 60)),
    im_shape=Tensor.float32((1, 0)),
    anchors=Tensor.float32((36000, 4)),
    variances=Tensor.float32((36000, 4)),
    pre_nms_top_n=12000,
    post_nms_top_n=2000,
    nms_thresh=0.7,
    min_size=0.0,
    eta=1.0,
    return_rois_num=True,
)

# case 2-8: 同一模式 im_shape=(N, 0), 不同 scores/bbox_deltas/anchors shapes

---
Task 5: Tensor.set_ — CPU 精度错误

根因模式: source tensor 含 0 维 → Tensor.xxx((0, 3))

# case 1: complex64
Tensor.set_(
    self=Tensor.complex64((20,)),
    source=Tensor.complex64((0, 3)),
    storage_offset=0,
    size=[20],
    stride=[2],
)

# case 2: float32
Tensor.set_(
    self=Tensor.float32((20,)),
    source=Tensor.float32((0, 3)),
    storage_offset=0,
    size=[20],
    stride=[2],
)

---
Task 6: __getitem__ + ctc_loss + put_along_axis — CPU crash (0-dim tensor)

6a: __getitem__ — 对 batch=0 的 tensor 做高级索引 crash

# case 1: bool, negative indices
Tensor.__getitem__(
    self=Tensor.bool((0, 5, 4, 3)),
    indices=[[2, -3, -4], [-1, 2, 5]],
)

# case 2: bool, positive indices
Tensor.__getitem__(
    self=Tensor.bool((0, 5, 4, 3)),
    indices=[[2, 3, 4], [1, 2, 5]],
)

# case 3-4: complex128, 同上两种 indices

6b: ctc_loss — input_lengths 或 label_lengths 为 0-dim tensor

# case 1: labels 第一维=0
nn.functional.ctc_loss(
    log_probs=Tensor.float32((40, 128, 6625)),
    labels=Tensor.int32((0, 25)),
    input_lengths=Tensor.int64((128,)),
    label_lengths=Tensor.int64((128,)),
    blank=0,
    reduction="none",
    norm_by_times=False,
)

# case 2: input_lengths 为 0-dim → Tensor.int64((0,))
# case 3: label_lengths 为 0-dim → Tensor.int64((0,))

6c: put_along_axis — values 含 0 维

# case 1: values 第一维=0
put_along_axis(
    arr=Tensor.uint8((10, 10, 10)),
    indices=Tensor.int64((5, 5, 5)),
    values=Tensor.uint8((0, 5, 5)),
    axis=1,
    reduce="mul",
    include_self=True,
    broadcast=False,
)

# case 2: values 第三维=0
# values shape: (5, 5, 0)

---
Task 7: generate_proposals — CPU crash

根因模式: bbox_deltas 第一维=0 或 im_shape 第二维=0

# case 1: bbox_deltas batch=0, im_shape 正常
vision.ops.generate_proposals(
    scores=Tensor.float32((1, 15, 40, 60)),
    bbox_deltas=Tensor.float32((0, 60, 40, 60)),
    im_shape=Tensor.float32((1, 2)),
    anchors=Tensor.float32((36000, 4)),
    variances=Tensor.float32((36000, 4)),
    pre_nms_top_n=12000,
    post_nms_top_n=2000,
    nms_thresh=0.7,
    min_size=0.0,
    eta=1.0,
    return_rois_num=True,
)

# case 2: im_shape=(1, 0), bbox_deltas 正常 (与 GPU 同模式)

# case 3-16: 同两种模式，不同 shape 组合

---
Task 8: cdist — CPU crash

根因模式: 第二个输入 tensor 第一维=0

# case 1
cdist(
    x=Tensor.float32((8550, 4)),
    y=Tensor.float32((0, 4)),
    p=1,
)

# case 2
cdist(
    x=Tensor.float32((900, 4)),
    y=Tensor.float32((0, 4)),
    p=1,
)

---
总结

┌─────┬───────────────────────────────┬──────┬───────┬────────────────┬─────┐
│     │                               │ Devi │       │                │ Cas │
│  #  │              API              │  ce  │ 错误  │    根因模式    │ e   │
│     │                               │      │       │                │ 数  │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│     │ variable_length_memory_effici │      │ cuda  │ seq_lens/kv_se │     │
│ 1   │ ent_attention                 │ GPU  │ error │ q_lens 含 0    │ 4   │
│     │                               │      │  700  │                │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│     │                               │      │ cuda  │                │     │
│ 2   │ flashmask_attention           │ GPU  │ error │ Q/K/V 含 0-dim │ 7   │
│     │                               │      │  700  │                │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│     │                               │      │ cuda  │ weight         │     │
│ 3   │ weight_only_linear            │ GPU  │ error │ 第一维=0       │ 11  │
│     │                               │      │  700  │                │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│     │                               │      │ cuda  │ im_shape 含    │     │
│ 4   │ generate_proposals            │ GPU  │ error │ 0-dim          │ 8   │
│     │                               │      │  700  │                │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│ 5   │ Tensor.set_                   │ CPU  │ 精度  │ source 含      │ 2   │
│     │                               │      │ 错误  │ 0-dim          │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│ 6   │ __getitem__/ctc_loss/put_alon │ CPU  │ crash │ 输入含 0-dim   │ 9   │
│     │ g_axis                        │      │       │                │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│     │                               │      │       │ bbox_deltas/im │     │
│ 7   │ generate_proposals            │ CPU  │ crash │ _shape 含      │ 16  │
│     │                               │      │       │ 0-dim          │     │
├─────┼───────────────────────────────┼──────┼───────┼────────────────┼─────┤
│ 8   │ cdist                         │ CPU  │ crash │ y 第一维=0     │ 2   │
└─────┴───────────────────────────────┴──────┴───────┴────────────────┴─────┘

共性根因: 几乎所有 case 都是 tensor 含 0-size 维度 时缺少边界校验，导致 CUDA
非法内存访问（GPU）或 segfault（CPU）。
