"""Tests for IsolatedAccuracyTester."""

from __future__ import annotations

import sys

import pytest

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import Tensor
from tensor_spec.tester.base import TestStatus


@pytest.fixture()
def _both_frameworks():
    pytest.importorskip("paddle")
    pytest.importorskip("torch")


@pytest.fixture()
def isolated_tester(_both_frameworks):
    """IsolatedAccuracyTester with real workers using current Python."""
    from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

    mapping = MappingRegistry()
    mapping.load_bundled("paddle")
    mapping.load_bundled("torch")
    tester = IsolatedAccuracyTester(
        backends=[
            ("paddle", sys.executable, "paddle"),
            ("torch", sys.executable, "torch"),
        ],
        mapping=mapping,
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    yield tester
    tester.shutdown()


class TestIsolatedAccuracyPass:
    def test_abs_passes(self, isolated_tester):
        case = CaseConfig(
            api_name="abs",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED
        assert result.compare_result is not None
        assert result.compare_result.passed is True

    def test_add_passes(self, isolated_tester):
        case = CaseConfig(
            api_name="add",
            args=(),
            kwargs={"x": Tensor.float32((3,)), "y": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status == TestStatus.PASSED


class TestIsolatedAccuracyError:
    def test_unknown_api_returns_error(self, isolated_tester):
        case = CaseConfig(
            api_name="totally_fake_api",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.status in (
            TestStatus.BACKEND_ERROR,
            TestStatus.ERROR,
        )
        assert result.error is not None


class TestIsolatedAccuracyDuration:
    def test_duration_is_positive(self, isolated_tester):
        case = CaseConfig(
            api_name="abs",
            args=(),
            kwargs={"x": Tensor.float32((3,))},
        )
        result = isolated_tester.test(case)
        assert result.duration_ms > 0
