"""Tests for the Coordinator that manages worker subprocesses."""

from __future__ import annotations

import sys

import numpy as np
import pytest

from tensor_spec.worker.coordinator import Coordinator


class TestCoordinatorLifecycle:
    def test_start_and_ping(self):
        coord = Coordinator()
        try:
            coord.start_worker("w1", sys.executable, "paddle")
            assert "w1" in coord.workers
        finally:
            coord.shutdown_all()

    def test_shutdown_all(self):
        coord = Coordinator()
        coord.start_worker("w1", sys.executable, "paddle")
        coord.shutdown_all()
        assert coord.workers["w1"].process.returncode is not None


@pytest.fixture()
def coord_with_paddle():
    """Coordinator with one paddle worker (skips if no paddle)."""
    pytest.importorskip("paddle")
    coord = Coordinator()
    coord.start_worker("paddle", sys.executable, "paddle")
    coord.import_framework("paddle")
    yield coord
    coord.shutdown_all()


class TestCoordinatorSendReceive:
    def test_send_numpy_and_get_back(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        assert tid.startswith("t")
        result = coord_with_paddle.get_numpy("paddle", tid)
        np.testing.assert_array_equal(result, arr)

    def test_exec_api_abs(self, coord_with_paddle):
        arr = np.array([-1.0, 2.0, -3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api("paddle", "abs", [tid], {})
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_exec_api_with_kwargs(self, coord_with_paddle):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        result_tid = coord_with_paddle.exec_api(
            "paddle",
            "abs",
            [],
            {"x": tid},
        )
        result = coord_with_paddle.get_numpy("paddle", result_tid)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))

    def test_free_tensor(self, coord_with_paddle):
        arr = np.array([1.0], dtype=np.float32)
        tid = coord_with_paddle.send_numpy("paddle", arr)
        coord_with_paddle.free_tensor("paddle", tid)


class TestCoordinatorErrors:
    def test_exec_api_failure(self, coord_with_paddle):
        with pytest.raises(RuntimeError, match="error"):
            coord_with_paddle.exec_api("paddle", "nonexistent_api_xyz", [], {})

    def test_unknown_worker(self):
        coord = Coordinator()
        with pytest.raises(KeyError):
            coord.send_numpy("nonexistent", np.array([1.0]))
        coord.shutdown_all()
