"""Tests for the API mapping registry."""

from __future__ import annotations

import json

import pytest

from tensor_spec.mapping.registry import APIMapping, MappingRegistry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_PADDLE = {
    "abs": {"api": "abs", "args_map": {"x": "x"}},
    "add": {"api": "add", "args_map": {"x": "x", "y": "y"}},
}

SAMPLE_TORCH = {
    "abs": {"api": "abs", "args_map": {"x": "input"}},
    "add": {"api": "add", "args_map": {"x": "input", "y": "other"}},
}


def _write_json(tmp_path, name: str, data: dict) -> str:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return str(path)


# ---------------------------------------------------------------------------
# 1. test_load_and_resolve — load paddle.json, resolve "abs"
# ---------------------------------------------------------------------------


def test_load_and_resolve(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "paddle.json", SAMPLE_PADDLE)
    registry.load("paddle", path)

    mapping = registry.resolve("abs", "paddle")
    assert isinstance(mapping, APIMapping)
    assert mapping.api == "abs"
    assert mapping.args_map == {"x": "x"}


# ---------------------------------------------------------------------------
# 2. test_resolve_torch — load torch.json, resolve "abs", check x→input
# ---------------------------------------------------------------------------


def test_resolve_torch(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    mapping = registry.resolve("abs", "torch")
    assert mapping.api == "abs"
    assert mapping.args_map["x"] == "input"


# ---------------------------------------------------------------------------
# 3. test_resolve_unknown_api — KeyError for unknown API
# ---------------------------------------------------------------------------


def test_resolve_unknown_api(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "paddle.json", SAMPLE_PADDLE)
    registry.load("paddle", path)

    with pytest.raises(KeyError):
        registry.resolve("nonexistent_api", "paddle")


# ---------------------------------------------------------------------------
# 4. test_resolve_unknown_framework — KeyError for unknown framework
# ---------------------------------------------------------------------------


def test_resolve_unknown_framework():
    registry = MappingRegistry()

    with pytest.raises(KeyError):
        registry.resolve("abs", "unknown_framework")


# ---------------------------------------------------------------------------
# 5. test_map_kwargs — remap {"x": 1, "y": 2} → {"input": 1, "other": 2}
# ---------------------------------------------------------------------------


def test_map_kwargs(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    result = registry.map_kwargs("add", "torch", {"x": 1, "y": 2})
    assert result == {"input": 1, "other": 2}


# ---------------------------------------------------------------------------
# 6. test_map_kwargs_passthrough_unmapped — unmapped keys pass through
# ---------------------------------------------------------------------------


def test_map_kwargs_passthrough_unmapped(tmp_path):
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", SAMPLE_TORCH)
    registry.load("torch", path)

    result = registry.map_kwargs("abs", "torch", {"x": 1, "alpha": 0.5})
    assert result == {"input": 1, "alpha": 0.5}


# ---------------------------------------------------------------------------
# 7. test_resolve_api_name — resolve_api returns framework-specific path
# ---------------------------------------------------------------------------


def test_resolve_api_name(tmp_path):
    data = {
        "relu": {"api": "nn.functional.relu", "args_map": {"x": "input"}},
    }
    registry = MappingRegistry()
    path = _write_json(tmp_path, "torch.json", data)
    registry.load("torch", path)

    assert registry.resolve_api("relu", "torch") == "nn.functional.relu"


# ---------------------------------------------------------------------------
# 8. test_api_mapping_frozen — APIMapping dataclass is frozen
# ---------------------------------------------------------------------------


def test_api_mapping_frozen():
    mapping = APIMapping(api="abs", args_map={"x": "input"})

    with pytest.raises(AttributeError):
        mapping.api = "changed"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# 9. test_load_from_package — load_bundled works for paddle and torch
# ---------------------------------------------------------------------------


def test_load_from_package():
    registry = MappingRegistry()
    registry.load_bundled("paddle")
    registry.load_bundled("torch")

    # Verify paddle mappings loaded correctly
    assert registry.resolve_api("abs", "paddle") == "abs"
    assert registry.map_kwargs("abs", "paddle", {"x": 1}) == {"x": 1}

    # Verify torch mappings loaded correctly
    assert registry.resolve_api("abs", "torch") == "abs"
    assert registry.map_kwargs("abs", "torch", {"x": 1}) == {"input": 1}

    # Verify all 10 APIs are present for each framework
    for api_name in ("abs", "add", "matmul", "sum", "mean", "sqrt", "exp", "log", "nn.functional.relu", "nn.functional.sigmoid"):
        assert registry.resolve(api_name, "paddle").api is not None
        assert registry.resolve(api_name, "torch").api is not None
