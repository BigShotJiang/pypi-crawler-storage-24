import pytest

from tensor_spec.spec.device import Device, DeviceSpec, DeviceType


def test_device_spec_creation():
    d = DeviceSpec(device_type=DeviceType.CUDA, device_id=0)
    assert d.device_type == DeviceType.CUDA
    assert d.device_id == 0


def test_device_spec_frozen():
    d = DeviceSpec(device_type=DeviceType.CPU)
    with pytest.raises(AttributeError):
        d.device_type = DeviceType.CUDA


def test_device_type_dlpack_values():
    """DLPack integer values must match the spec."""
    assert int(DeviceType.CPU) == 1
    assert int(DeviceType.CUDA) == 2
    assert int(DeviceType.ROCM) == 10
    assert int(DeviceType.ONEAPI) == 14


def test_device_cpu():
    d = Device.cpu()
    assert d.device_type == DeviceType.CPU
    assert d.device_id == 0
    assert str(d) == "cpu"


def test_device_cuda():
    d = Device.cuda(0)
    assert d.device_type == DeviceType.CUDA
    assert d.device_id == 0
    assert str(d) == "cuda:0"


def test_device_cuda_index():
    d = Device.cuda(3)
    assert d.device_id == 3
    assert str(d) == "cuda:3"


def test_device_rocm():
    d = Device.rocm(1)
    assert d.device_type == DeviceType.ROCM
    assert d.device_id == 1


def test_device_oneapi():
    d = Device.oneapi(0)
    assert d.device_type == DeviceType.ONEAPI
    assert d.device_id == 0


def test_dlpack_device_property():
    d = Device.cuda(2)
    assert d.dlpack_device == (2, 2)  # (kDLCUDA=2, device_id=2)

    d_cpu = Device.cpu()
    assert d_cpu.dlpack_device == (1, 0)  # (kDLCPU=1, device_id=0)
