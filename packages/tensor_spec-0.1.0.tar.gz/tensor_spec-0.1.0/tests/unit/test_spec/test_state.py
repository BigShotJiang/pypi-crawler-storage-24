from tensor_spec.spec.state import TensorState


def test_tensor_state_defaults():
    s = TensorState()
    assert s.need_grad is None
    assert s.is_contiguous is True


def test_tensor_state_custom():
    s = TensorState(need_grad=True, is_contiguous=False)
    assert s.need_grad is True
    assert s.is_contiguous is False


def test_tensor_state_frozen():
    import pytest

    s = TensorState()
    with pytest.raises(AttributeError):
        s.need_grad = True
