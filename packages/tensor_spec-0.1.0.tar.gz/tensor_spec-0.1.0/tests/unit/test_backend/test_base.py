import pytest

from tensor_spec.backend.base import BackendBase


def test_backend_base_is_abstract():
    with pytest.raises(TypeError):
        BackendBase()


def test_backend_base_has_compute_grad():
    assert hasattr(BackendBase, "compute_grad")


def test_backend_base_has_check_cuda_error():
    assert hasattr(BackendBase, "check_cuda_error")
