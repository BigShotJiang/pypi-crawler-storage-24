import pytest

try:
    import torch

    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

from tensor_spec.backend.torch_backend import TorchBackend

pytestmark = pytest.mark.skipif(not HAS_TORCH, reason="torch not installed")


@pytest.fixture
def backend():
    b = TorchBackend()
    b.import_framework()
    return b


def test_name(backend):
    assert backend.name == "torch"


def test_import_framework():
    b = TorchBackend()
    b.import_framework()
    assert b._torch is not None


def test_numpy_to_tensor_float(backend):
    import numpy as np

    from tensor_spec.spec.tensor import Tensor

    spec = Tensor.float32((2, 3))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert tuple(t.shape) == (2, 3)
    assert t.dtype == torch.float32


def test_numpy_to_tensor_with_grad(backend):
    import numpy as np

    from tensor_spec.spec.state import TensorState
    from tensor_spec.spec.tensor import Tensor

    spec = Tensor.float32((2, 3)).with_state(TensorState(need_grad=True))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.requires_grad is True


def test_tensor_to_numpy(backend):
    import numpy as np

    t = torch.tensor([1.0, 2.0, 3.0])
    result = backend.tensor_to_numpy(t)
    assert isinstance(result, np.ndarray)
    np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])


def test_exec_api(backend):
    import numpy as np

    t = torch.tensor([-1.0, 2.0, -3.0])
    result = backend.exec_api("abs", (t,), {})
    expected = np.array([1.0, 2.0, 3.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_dotted(backend):
    import numpy as np

    t = torch.tensor([-1.0, 2.0, -3.0])
    result = backend.exec_api("nn.functional.relu", (t,), {})
    expected = np.array([0.0, 2.0, 0.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_empty_cache(backend):
    # Should not raise, even without CUDA
    backend.empty_cache()


def test_check_cuda_error(backend):
    # Should not raise, even without CUDA
    backend.check_cuda_error()


def test_compute_grad(backend):
    x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
    y = torch.sum(x * x)
    grads = backend.compute_grad(y, [x])
    assert len(grads) == 1
    expected = [2.0, 4.0, 6.0]
    for g, e in zip(grads[0].detach().numpy().tolist(), expected, strict=True):
        assert abs(g - e) < 1e-5
