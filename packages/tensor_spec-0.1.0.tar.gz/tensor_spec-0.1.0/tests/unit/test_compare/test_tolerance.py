"""Tests for tolerance configuration."""

from __future__ import annotations

import os
import tempfile

import pytest

from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig


class TestToleranceConfig:
    """Tests for ToleranceConfig dataclass."""

    def test_defaults(self) -> None:
        tc = ToleranceConfig()
        assert tc.atol == pytest.approx(1e-2)
        assert tc.rtol == pytest.approx(1e-2)

    def test_custom_values(self) -> None:
        tc = ToleranceConfig(atol=0.5, rtol=0.1)
        assert tc.atol == pytest.approx(0.5)
        assert tc.rtol == pytest.approx(0.1)

    def test_frozen(self) -> None:
        tc = ToleranceConfig()
        with pytest.raises(AttributeError):
            tc.atol = 0.5  # type: ignore[misc]


class TestTolerance:
    """Tests for Tolerance per-API configuration."""

    def test_defaults(self) -> None:
        tol = Tolerance()
        cfg = tol.get("some_api")
        assert cfg.atol == pytest.approx(1e-2)
        assert cfg.rtol == pytest.approx(1e-2)

    def test_get_with_override(self) -> None:
        overrides = {
            "matmul": ToleranceConfig(atol=2.0, rtol=0.05),
        }
        tol = Tolerance(overrides=overrides)
        cfg = tol.get("matmul")
        assert cfg.atol == pytest.approx(2.0)
        assert cfg.rtol == pytest.approx(0.05)

    def test_get_fallback_to_default(self) -> None:
        overrides = {
            "matmul": ToleranceConfig(atol=2.0, rtol=0.05),
        }
        tol = Tolerance(overrides=overrides)
        cfg = tol.get("unknown_api")
        assert cfg.atol == pytest.approx(1e-2)
        assert cfg.rtol == pytest.approx(1e-2)

    def test_get_with_custom_default(self) -> None:
        default = ToleranceConfig(atol=0.5, rtol=0.5)
        tol = Tolerance(default=default)
        cfg = tol.get("any_api")
        assert cfg.atol == pytest.approx(0.5)
        assert cfg.rtol == pytest.approx(0.5)

    def test_frozen(self) -> None:
        tol = Tolerance()
        with pytest.raises(AttributeError):
            tol.default = ToleranceConfig()  # type: ignore[misc]

    def test_from_toml(self) -> None:
        toml_content = b"""\
[default]
atol = 0.1
rtol = 0.2

[overrides.matmul]
atol = 2.0
rtol = 0.05

[overrides."nn.layer_norm"]
atol = 0.2
rtol = 0.02
"""
        with tempfile.NamedTemporaryFile(suffix=".toml", delete=False) as f:
            f.write(toml_content)
            f.flush()
            path = f.name

        try:
            tol = Tolerance.from_toml(path)
            assert tol.default.atol == pytest.approx(0.1)
            assert tol.default.rtol == pytest.approx(0.2)

            matmul_cfg = tol.get("matmul")
            assert matmul_cfg.atol == pytest.approx(2.0)
            assert matmul_cfg.rtol == pytest.approx(0.05)

            ln_cfg = tol.get("nn.layer_norm")
            assert ln_cfg.atol == pytest.approx(0.2)
            assert ln_cfg.rtol == pytest.approx(0.02)

            # Fallback to default for unknown API
            unknown_cfg = tol.get("unknown")
            assert unknown_cfg.atol == pytest.approx(0.1)
            assert unknown_cfg.rtol == pytest.approx(0.2)
        finally:
            os.unlink(path)

    def test_from_toml_missing_default(self) -> None:
        toml_content = b"""\
[overrides.matmul]
atol = 2.0
rtol = 0.05
"""
        with tempfile.NamedTemporaryFile(suffix=".toml", delete=False) as f:
            f.write(toml_content)
            f.flush()
            path = f.name

        try:
            tol = Tolerance.from_toml(path)
            # Default should use class defaults
            assert tol.default.atol == pytest.approx(1e-2)
            assert tol.default.rtol == pytest.approx(1e-2)
        finally:
            os.unlink(path)

    def test_from_toml_partial_override(self) -> None:
        """Override that only specifies atol should inherit rtol from default."""
        toml_content = b"""\
[default]
atol = 0.1
rtol = 0.2

[overrides.relu]
atol = 0.5
"""
        with tempfile.NamedTemporaryFile(suffix=".toml", delete=False) as f:
            f.write(toml_content)
            f.flush()
            path = f.name

        try:
            tol = Tolerance.from_toml(path)
            relu_cfg = tol.get("relu")
            assert relu_cfg.atol == pytest.approx(0.5)
            # rtol should fall back to default's rtol
            assert relu_cfg.rtol == pytest.approx(0.2)
        finally:
            os.unlink(path)

    def test_from_toml_configs_file(self) -> None:
        """Test loading the actual configs/tolerance.toml shipped with the project."""
        config_path = os.path.join(
            os.path.dirname(__file__),
            "..",
            "..",
            "configs",
            "tolerance.toml",
        )
        if not os.path.exists(config_path):
            pytest.skip("configs/tolerance.toml not found")

        tol = Tolerance.from_toml(config_path)
        assert tol.default.atol == pytest.approx(1e-2)
        assert tol.default.rtol == pytest.approx(1e-2)
        assert tol.get("matmul").atol == pytest.approx(2.0)
        assert tol.get("nn.layer_norm").atol == pytest.approx(0.2)

    def test_from_dict(self) -> None:
        data = {
            "default": {"atol": 0.1, "rtol": 0.2},
            "overrides": {
                "matmul": {"atol": 2.0, "rtol": 0.05},
            },
        }
        tol = Tolerance.from_dict(data)
        assert tol.default.atol == pytest.approx(0.1)
        assert tol.default.rtol == pytest.approx(0.2)
        assert tol.get("matmul").atol == pytest.approx(2.0)
        assert tol.get("unknown").atol == pytest.approx(0.1)

    def test_from_dict_empty(self) -> None:
        tol = Tolerance.from_dict({})
        assert tol.default.atol == pytest.approx(1e-2)
        assert tol.default.rtol == pytest.approx(1e-2)
