import json

from tensor_spec.compare.comparator import CompareResult
from tensor_spec.config.case import CaseConfig
from tensor_spec.log.writer import LogWriter
from tensor_spec.tester.base import TestResult, TestStatus


def _make_case(api_name="abs"):
    return CaseConfig(api_name=api_name, args=(), kwargs={})


def test_writer_creates_file(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    writer.write(TestResult(case=_make_case(), status=TestStatus.PASSED, duration_ms=1.5))
    writer.close()
    assert path.exists()


def test_writer_writes_valid_json(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    writer.write(TestResult(case=_make_case(), status=TestStatus.PASSED, duration_ms=1.5))
    writer.close()
    record = json.loads(path.read_text().strip())
    assert record["api"] == "abs"
    assert record["status"] == "pass"
    assert record["duration_ms"] == 1.5
    assert "ts" in record
    assert "pid" in record


def test_writer_accuracy_error_includes_diff(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    cmp = CompareResult(
        passed=False,
        max_abs_diff=0.05,
        max_rel_diff=0.02,
        mismatched_count=3,
        total_count=100,
    )
    result = TestResult(
        case=_make_case(),
        status=TestStatus.ACCURACY_ERROR,
        compare_result=cmp,
        duration_ms=2.3,
    )
    writer.write(result)
    writer.close()
    record = json.loads(path.read_text().strip())
    assert record["status"] == "accuracy_error"
    assert record["max_abs_diff"] == 0.05
    assert record["max_rel_diff"] == 0.02
    assert record["mismatched_count"] == 3


def test_writer_error_includes_message(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    result = TestResult(
        case=_make_case(),
        status=TestStatus.TORCH_ERROR,
        error="RuntimeError: cuda out of memory",
        duration_ms=0.1,
    )
    writer.write(result)
    writer.close()
    record = json.loads(path.read_text().strip())
    assert record["status"] == "torch_error"
    assert "cuda out of memory" in record["error"]


def test_writer_multiple_lines(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    for i in range(3):
        writer.write(
            TestResult(
                case=_make_case(f"api_{i}"),
                status=TestStatus.PASSED,
                duration_ms=float(i),
            )
        )
    writer.close()
    lines = path.read_text().strip().split("\n")
    assert len(lines) == 3
    for line in lines:
        json.loads(line)


def test_writer_context_manager(tmp_path):
    path = tmp_path / "test.jsonl"
    with LogWriter(str(path)) as writer:
        writer.write(TestResult(case=_make_case(), status=TestStatus.PASSED))
    assert path.exists()
    assert len(path.read_text().strip().split("\n")) == 1
