"""Validate mapping rules produce correct results.

Usage:
    python tests/validate_mapping_rules.py

Checks per framework:
1. Every canonical API in apis.toml resolves to a non-empty API path
2. API prefix rules only reference known canonical names
3. arg_rules with explicit apis only reference known canonical names
4. Cross-framework: paddle and torch resolve the same set of canonical APIs
5. Regression: spot-check key mappings against known-correct values
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from tensor_spec.mapping.registry import MappingRegistry, _load_canonical_api_names, _load_toml
from tensor_spec.mapping.registry import MappingRules

MAPPINGS_DIR = Path(__file__).resolve().parent.parent / "src" / "tensor_spec" / "mapping" / "mappings"

# Known-correct spot checks: (framework, canonical, expected_api, {arg: expected})
SPOT_CHECKS = [
    # Paddle — canonical name == paddle API path, args identity
    ("paddle", "abs", "abs", {"x": "x", "axis": "axis"}),
    ("paddle", "nn.functional.relu", "nn.functional.relu", {"x": "x"}),
    ("paddle", "nn.functional.tanh", "nn.functional.tanh", {"x": "x"}),
    ("paddle", "concat", "concat", {"x": "x", "axis": "axis"}),
    ("paddle", "nn.functional.cross_entropy", "nn.functional.cross_entropy", {"x": "x", "label": "label"}),
    # PyTorch — arg renames
    ("torch", "abs", "abs", {"x": "input"}),
    ("torch", "add", "add", {"x": "input", "y": "other"}),
    ("torch", "pow", "pow", {"x": "input", "y": "exponent"}),
    ("torch", "dot", "dot", {"x": "input", "y": "tensor"}),
    ("torch", "bmm", "bmm", {"x": "input", "y": "mat2"}),
    ("torch", "concat", "cat", {"x": "tensors", "axis": "dim"}),
    ("torch", "linalg.det", "linalg.det", {"x": "A"}),
    ("torch", "flip", "flip", {"x": "input", "axis": "dims"}),
    ("torch", "sum", "sum", {"x": "input", "axis": "dim"}),
    ("torch", "nn.functional.relu", "nn.functional.relu", {"x": "input"}),
    ("torch", "nn.functional.tanh", "nn.functional.tanh", {"x": "input"}),
    ("torch", "nn.functional.cross_entropy", "nn.functional.cross_entropy", {"x": "input", "label": "target"}),
    ("torch", "tile", "tile", {"x": "input", "repeat_times": "dims"}),
    ("torch", "scatter", "scatter", {"x": "input", "updates": "src"}),
    # Passthrough: unmapped args should pass through unchanged
    ("torch", "abs", "abs", {"keepdim": "keepdim"}),
    ("paddle", "abs", "abs", {"keepdim": "keepdim"}),
]


def validate() -> list[str]:
    errors: list[str] = []
    api_names = _load_canonical_api_names(MAPPINGS_DIR)
    api_set = set(api_names)

    # Load both frameworks via rules
    reg = MappingRegistry()
    for fw in ("paddle", "torch"):
        rules_path = MAPPINGS_DIR / f"{fw}.rules.toml"
        if not rules_path.exists():
            errors.append(f"Missing {fw}.rules.toml")
            continue
        reg.load_bundled(fw)

    # Check 1: every canonical API resolves to a non-empty path
    for fw in ("paddle", "torch"):
        for api in api_names:
            resolved = reg.resolve_api(api, fw)
            if not resolved:
                errors.append(f"[{fw}] {api}: resolved to empty API path")

    # Check 2: api_rules/arg_rules only reference known canonical names
    for fw in ("paddle", "torch"):
        data = _load_toml(MAPPINGS_DIR / f"{fw}.rules.toml")
        rules = MappingRules.from_dict(data)
        for pr in rules.api_prefix_rules:
            unknown = pr.apis - api_set
            if unknown:
                errors.append(f"[{fw}] api_rules prefix '{pr.prefix}': unknown APIs {unknown}")
        for ar in rules.arg_rules:
            if ar.apis is not None:
                unknown = ar.apis - api_set
                if unknown:
                    errors.append(f"[{fw}] arg_rule '{ar.from_}' -> '{ar.to}': unknown APIs {unknown}")

    # Check 3: spot checks
    for fw, canonical, expected_api, expected_args in SPOT_CHECKS:
        actual_api = reg.resolve_api(canonical, fw)
        if actual_api != expected_api:
            errors.append(f"[{fw}] {canonical}: api={actual_api!r}, expected={expected_api!r}")
        for arg, expected_mapped in expected_args.items():
            result = reg.map_kwargs(canonical, fw, {arg: "V"})
            actual_mapped = list(result.keys())[0]
            if actual_mapped != expected_mapped:
                errors.append(
                    f"[{fw}] {canonical}: arg {arg!r} -> {actual_mapped!r}, expected {expected_mapped!r}"
                )

    return errors


def main() -> int:
    api_names = _load_canonical_api_names(MAPPINGS_DIR)
    errors = validate()

    if errors:
        print(f"FAIL: {len(errors)} error(s) in {len(api_names)} APIs")
        for e in errors:
            print(f"  {e}")
        return 1

    print(f"OK: all {len(api_names)} APIs x 2 frameworks validated")
    print(f"   {len(SPOT_CHECKS)} spot checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
