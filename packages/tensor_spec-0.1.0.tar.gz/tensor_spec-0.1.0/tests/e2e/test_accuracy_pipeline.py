"""End-to-end integration tests for Phase 0 and Phase 1."""

import importlib.util
import json

import numpy as np
import pytest

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.parser import parse_case
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.log.writer import LogWriter
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import TensorSpec
from tensor_spec.tester.accuracy import AccuracyTester
from tensor_spec.tester.base import TestStatus

HAS_PADDLE = importlib.util.find_spec("paddle") is not None
_has_paddle = HAS_PADDLE
_has_torch = importlib.util.find_spec("torch") is not None
_has_both = _has_paddle and _has_torch


class TestParseAndGenerate:
    """Test parse + generate pipeline without any framework."""

    def test_abs(self):
        case = parse_case("abs(x=Tensor.float64((1, 100)))")
        gen = TensorGenerator(seed=42)
        data = gen.generate(case.kwargs["x"])
        assert data.shape == (1, 100)
        assert data.dtype == np.float64

    def test_add(self):
        case = parse_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))")
        gen = TensorGenerator(seed=42)
        x = gen.generate(case.kwargs["x"])
        y = gen.generate(case.kwargs["y"])
        assert x.shape == (2, 3)
        assert y.shape == (2, 3)

    def test_matmul(self):
        case = parse_case("matmul(x=Tensor.float64((4, 5)), y=Tensor.float64((5, 3)))")
        gen = TensorGenerator(seed=42)
        x = gen.generate(case.kwargs["x"])
        y = gen.generate(case.kwargs["y"])
        result = np.matmul(x, y)
        assert result.shape == (4, 3)

    def test_cholesky_positive_definite(self):
        case = parse_case("linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))")
        gen = TensorGenerator(seed=42)
        data = gen.generate(case.kwargs["x"])
        L = np.linalg.cholesky(data)
        assert L.shape == (4, 4)


@pytest.mark.skipif(not HAS_PADDLE, reason="paddle not installed")
class TestFullPipeline:
    """Test full pipeline including Paddle backend execution."""

    @pytest.fixture
    def backend(self):
        from tensor_spec.backend.paddle_backend import PaddleBackend

        b = PaddleBackend()
        b.import_framework()
        return b

    def _run_case(self, case_str: str, backend):
        case = parse_case(case_str)
        gen = TensorGenerator(seed=42)
        kwargs = {}
        for key, val in case.kwargs.items():
            if isinstance(val, TensorSpec):
                np_data = gen.generate(val)
                kwargs[key] = backend.numpy_to_tensor(np_data, val)
            else:
                kwargs[key] = val
        return backend.exec_api(case.api_name, case.args, kwargs)

    def test_abs_paddle(self, backend):
        result = self._run_case("abs(x=Tensor.float32((100,)))", backend)
        result_np = backend.tensor_to_numpy(result)
        assert np.all(result_np >= 0)

    def test_add_paddle(self, backend):
        result = self._run_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))", backend)
        assert backend.tensor_to_numpy(result).shape == (2, 3)

    def test_matmul_paddle(self, backend):
        result = self._run_case("matmul(x=Tensor.float64((4, 5)), y=Tensor.float64((5, 3)))", backend)
        assert backend.tensor_to_numpy(result).shape == (4, 3)


@pytest.mark.skipif(not _has_both, reason="Both paddle and torch required")
class TestAccuracyIntegration:
    def _make_tester(self):
        from tensor_spec.backend.paddle_backend import PaddleBackend
        from tensor_spec.backend.torch_backend import TorchBackend

        ba = PaddleBackend()
        bb = TorchBackend()
        ba.import_framework()
        bb.import_framework()
        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        return AccuracyTester(
            backend_a=ba,
            backend_b=bb,
            mapping=mapping,
            comparator=NumpyComparator(),
            tolerance=Tolerance(),
            generator=TensorGenerator(seed=42),
        )

    def test_abs_accuracy(self):
        tester = self._make_tester()
        case = parse_case("abs(x=Tensor.float64((10,)))")
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_add_accuracy(self):
        tester = self._make_tester()
        case = parse_case("add(x=Tensor.float64((5, 5)), y=Tensor.float64((5, 5)))")
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_matmul_accuracy(self):
        tester = self._make_tester()
        case = parse_case("matmul(x=Tensor.float64((4, 3)), y=Tensor.float64((3, 5)))")
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_sqrt_accuracy(self):
        tester = self._make_tester()
        case = parse_case("sqrt(x=Tensor.float64((10,)).stats(min=0.01, max=10.0))")
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_log_writer_integration(self, tmp_path):
        tester = self._make_tester()
        case = parse_case("abs(x=Tensor.float64((10,)))")
        result = tester.test(case)
        log_path = tmp_path / "test.jsonl"
        with LogWriter(str(log_path)) as writer:
            writer.write(result)
        record = json.loads(log_path.read_text().strip())
        assert record["api"] == "abs"
        assert record["status"] == "pass"


class TestMappingIntegration:
    def test_load_both_mappings(self):
        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        paddle_abs = mapping.resolve("abs", "paddle")
        torch_abs = mapping.resolve("abs", "torch")
        assert paddle_abs.api == "abs"
        assert torch_abs.api == "abs"
        assert paddle_abs.args_map["x"] == "x"
        assert torch_abs.args_map["x"] == "input"

    def test_tolerance_from_bundled_config(self):
        from pathlib import Path

        from tensor_spec.compare.tolerance import Tolerance as ToleranceLocal

        config_path = Path(__file__).parent.parent / "configs" / "tolerance.toml"
        if config_path.exists():
            tol = ToleranceLocal.from_toml(str(config_path))
            assert tol.default.atol > 0
            assert tol.get("matmul").atol > tol.default.atol


@pytest.mark.skipif(not _has_both, reason="Need both paddle and torch")
class TestIsolatedAccuracyIntegration:
    """End-to-end tests for process-isolated accuracy pipeline."""

    def test_isolated_abs(self):
        import sys

        from tensor_spec.compare.comparator import NumpyComparator as NpComp
        from tensor_spec.compare.tolerance import Tolerance as Tol
        from tensor_spec.datagen.generator import TensorGenerator as TGen
        from tensor_spec.mapping.registry import MappingRegistry as MReg
        from tensor_spec.tester.base import TestStatus
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

        case_config = parse_case("abs(x=Tensor.float32((100,)))")
        mapping = MReg()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        tester = IsolatedAccuracyTester(
            backends=[
                ("paddle", sys.executable, "paddle"),
                ("torch", sys.executable, "torch"),
            ],
            mapping=mapping,
            comparator=NpComp(),
            tolerance=Tol(),
            generator=TGen(seed=42),
        )
        try:
            result = tester.test(case_config)
            assert result.status == TestStatus.PASSED
        finally:
            tester.shutdown()

    def test_isolated_matmul(self):
        import sys

        from tensor_spec.compare.comparator import NumpyComparator as NpComp
        from tensor_spec.compare.tolerance import Tolerance as Tol
        from tensor_spec.datagen.generator import TensorGenerator as TGen
        from tensor_spec.mapping.registry import MappingRegistry as MReg
        from tensor_spec.tester.base import TestStatus
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

        case_config = parse_case("matmul(x=Tensor.float32((4, 3)), y=Tensor.float32((3, 5)))")
        mapping = MReg()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")
        tester = IsolatedAccuracyTester(
            backends=[
                ("paddle", sys.executable, "paddle"),
                ("torch", sys.executable, "torch"),
            ],
            mapping=mapping,
            comparator=NpComp(),
            tolerance=Tol(),
            generator=TGen(seed=42),
        )
        try:
            result = tester.test(case_config)
            assert result.status == TestStatus.PASSED
        finally:
            tester.shutdown()

    def test_isolated_cli_smoke(self):
        """Smoke test: CLI check with process isolation."""
        import sys

        from typer.testing import CliRunner as TRunner

        from tensor_spec.cli import app as cli_app

        cli_runner = TRunner()
        result = cli_runner.invoke(
            cli_app,
            [
                "check",
                "--backend",
                "paddle",
                "--backend",
                "torch",
                "--case",
                "abs(x=Tensor.float32((10,)))",
                "--python",
                sys.executable,
                "--python",
                sys.executable,
            ],
        )
        assert result.exit_code == 0
        assert "pass" in result.output.lower()
