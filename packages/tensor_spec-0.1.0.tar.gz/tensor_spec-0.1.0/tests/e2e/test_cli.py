from typer.testing import CliRunner

from tensor_spec.cli import app

runner = CliRunner()


def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "tensor-spec" in result.output.lower() or "run" in result.output


def test_cli_run_help():
    result = runner.invoke(app, ["run", "--help"])
    assert result.exit_code == 0
    assert "--backend" in result.output
    assert "--case" in result.output


def test_cli_validate_help():
    result = runner.invoke(app, ["validate", "--help"])
    assert result.exit_code == 0
    assert "--case" in result.output


def test_cli_validate_valid_case():
    result = runner.invoke(app, ["validate", "--case", "abs(x=Tensor.float64((1, 100)))"])
    assert result.exit_code == 0
    assert "Valid" in result.output
    assert "abs" in result.output


def test_cli_validate_invalid_case():
    result = runner.invoke(app, ["validate", "--case", ""])
    assert result.exit_code != 0


def test_check_command_exists():
    result = runner.invoke(app, ["check", "--help"])
    assert result.exit_code == 0
    assert "--backend" in result.output
    assert "--python" in result.output
    assert "--case-file" in result.output
    assert "--verbose" in result.output


def test_check_no_isolated_flag():
    """--isolated flag should not exist — process isolation is the only mode."""
    result = runner.invoke(app, ["check", "--help"])
    assert "--isolated" not in result.output


def test_check_missing_case():
    result = runner.invoke(app, ["check", "--backend", "paddle"])
    assert result.exit_code != 0


def test_check_invalid_case():
    result = runner.invoke(
        app,
        ["check", "--backend", "paddle", "--backend", "torch", "--case", "???invalid"],
    )
    assert result.exit_code != 0


def test_check_missing_venv():
    """Without venvs set up, check should fail with a helpful message."""
    result = runner.invoke(
        app,
        [
            "check",
            "--backend",
            "paddle",
            "--backend",
            "torch",
            "--case",
            "abs(x=Tensor.float32((3,)))",
            "--python",
            "/nonexistent/venvs/paddle/bin/python",
            "--python",
            "/nonexistent/venvs/torch/bin/python",
        ],
    )
    assert result.exit_code != 0
    assert "setup" in result.output or "not found" in result.output


def test_check_case_file(tmp_path):
    """--case-file should accept a file with cases."""
    cf = tmp_path / "cases.txt"
    cf.write_text("# comment line\nabs(x=Tensor.float32((3,)))\n\ncos(x=Tensor.float32((5,)))\n")
    result = runner.invoke(
        app,
        [
            "check",
            "--backend",
            "paddle",
            "--backend",
            "torch",
            "--case-file",
            str(cf),
            "--python",
            "/nonexistent/bin/python",
            "--python",
            "/nonexistent/bin/python",
        ],
    )
    # Should fail because python paths don't exist, but should parse 2 cases
    assert result.exit_code != 0
    assert "2 case(s)" in result.output or "not found" in result.output


def test_check_case_file_missing():
    """--case-file with non-existent file should error."""
    result = runner.invoke(
        app,
        [
            "check",
            "--backend",
            "paddle",
            "--backend",
            "torch",
            "--case-file",
            "/nonexistent/cases.txt",
        ],
    )
    assert result.exit_code != 0


def test_check_multiple_cases():
    """Multiple --case flags should be accepted."""
    result = runner.invoke(
        app,
        [
            "check",
            "--backend",
            "paddle",
            "--backend",
            "torch",
            "--case",
            "abs(x=Tensor.float32((3,)))",
            "--case",
            "cos(x=Tensor.float32((5,)))",
            "--python",
            "/nonexistent/bin/python",
            "--python",
            "/nonexistent/bin/python",
        ],
    )
    assert result.exit_code != 0
    assert "2 case(s)" in result.output or "not found" in result.output


def test_check_single_backend():
    """Single --backend should be accepted (check-only mode)."""
    result = runner.invoke(
        app,
        [
            "check",
            "--backend",
            "paddle",
            "--case",
            "abs(x=Tensor.float32((3,)))",
            "--python",
            "/nonexistent/bin/python",
        ],
    )
    assert result.exit_code != 0
    assert "not found" in result.output or "setup" in result.output


def test_cli_setup_help():
    result = runner.invoke(app, ["setup", "--help"])
    assert result.exit_code == 0
    assert "--backend" in result.output
    assert "--config" in result.output
