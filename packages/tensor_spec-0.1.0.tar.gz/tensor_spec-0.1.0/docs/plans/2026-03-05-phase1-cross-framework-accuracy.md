# Phase 1: Cross-Framework Accuracy Comparison — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build the cross-framework (Paddle vs PyTorch) accuracy comparison pipeline, replacing PaddleAPITest's accuracy mode for 100 common APIs.

**Architecture:** Extends Phase 0 with 5 new layers: TorchBackend, API Mapping (JSON-based name + arg mapping), Compare (numpy comparator + per-API tolerance), Tester (template method + AccuracyTester), and Log (JSON Lines writer). Phase 1 runs single-process with both frameworks imported; comparison happens via numpy on CPU (Path A). CUDA IPC GPU comparison is deferred to Phase 3.

**Tech Stack:** Python 3.10+, numpy, click, pytest, tomli/tomllib (TOML parsing), json (log writer)

---

## Context for Implementer

**Existing codebase (Phase 0):**
- `src/tensor_spec/spec/` — TensorSpec hierarchy, Device (DLPack-aligned), Stats, State
- `src/tensor_spec/config/parser.py` — Whitelist recursive descent parser → CaseConfig
- `src/tensor_spec/config/case.py` — CaseConfig(api_name, args, kwargs)
- `src/tensor_spec/datagen/generator.py` — TensorSpec → numpy array
- `src/tensor_spec/backend/base.py` — BackendBase ABC (name, import_framework, numpy_to_tensor, tensor_to_numpy, exec_api, empty_cache)
- `src/tensor_spec/backend/paddle_backend.py` — PaddleBackend
- `src/tensor_spec/cli.py` — click CLI with `run` and `validate` commands

**Key design decision:** Canonical API names in case strings (e.g., `abs`, `nn.conv2d`) are framework-agnostic. The mapping layer translates them to framework-specific API paths and remaps argument names (e.g., `x` → `input` for torch).

**Data flow for accuracy testing:**
```
CaseConfig → TensorGenerator → numpy arrays
                                    ↓
                    ┌───────────────┼───────────────┐
                    ↓                               ↓
              BackendA.exec_api()            BackendB.exec_api()
              (mapped API + args)            (mapped API + args)
                    ↓                               ↓
              tensor_to_numpy()              tensor_to_numpy()
                    ↓                               ↓
                    └───────┬───────────────────────┘
                            ↓
                    NumpyComparator.compare(np_a, np_b, tolerance)
                            ↓
                    CompareResult → TestResult → LogWriter
```

---

### Task 1: Extend BackendBase + Update PaddleBackend

Add `compute_grad` and `check_cuda_error` methods to the backend interface, needed by AccuracyTester for gradient comparison and CUDA error detection.

**Files:**
- Modify: `src/tensor_spec/backend/base.py`
- Modify: `src/tensor_spec/backend/paddle_backend.py`
- Modify: `tests/test_backend/test_base.py`
- Modify: `tests/test_backend/test_paddle_backend.py`

**Step 1: Write failing tests**

In `tests/test_backend/test_base.py`, add:

```python
def test_backend_base_has_compute_grad():
    assert hasattr(BackendBase, "compute_grad")

def test_backend_base_has_check_cuda_error():
    assert hasattr(BackendBase, "check_cuda_error")
```

In `tests/test_backend/test_paddle_backend.py`, add:

```python
@pytest.mark.skipif(not _has_paddle(), reason="paddle not installed")
def test_paddle_check_cuda_error():
    b = PaddleBackend()
    b.import_framework()
    # Should not raise on CPU
    b.check_cuda_error()

@pytest.mark.skipif(not _has_paddle(), reason="paddle not installed")
def test_paddle_compute_grad():
    b = PaddleBackend()
    b.import_framework()
    import paddle
    x = paddle.to_tensor([1.0, 2.0, 3.0])
    x.stop_gradient = False
    y = paddle.sum(x * x)
    grads = b.compute_grad(y, [x])
    assert len(grads) == 1
    # grad of sum(x^2) = 2x
    expected = [2.0, 4.0, 6.0]
    for g, e in zip(grads[0].numpy().tolist(), expected):
        assert abs(g - e) < 1e-5
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_backend/ -v`
Expected: FAIL (compute_grad and check_cuda_error not defined)

**Step 3: Implement**

In `src/tensor_spec/backend/base.py`, add two abstract methods:

```python
@abstractmethod
def compute_grad(
    self, output: Any, inputs: list[Any], grad_output: Any | None = None
) -> list[Any]:
    """Compute gradients of output w.r.t. inputs."""
    ...

@abstractmethod
def check_cuda_error(self) -> None:
    """Check for asynchronous CUDA errors. No-op on CPU."""
    ...
```

In `src/tensor_spec/backend/paddle_backend.py`, add:

```python
def compute_grad(
    self, output: Any, inputs: list[Any], grad_output: Any | None = None
) -> list[Any]:
    paddle = self._paddle
    return paddle.grad(output, inputs, grad_outputs=grad_output, allow_unused=True)

def check_cuda_error(self) -> None:
    paddle = self._paddle
    if hasattr(paddle, "base") and hasattr(paddle.base, "core"):
        import contextlib
        with contextlib.suppress(Exception):
            paddle.base.core.eager._for_test_check_cuda_error()
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_backend/ -v`
Expected: All PASS (paddle tests skip if not installed)

**Step 5: Commit**

```bash
git add src/tensor_spec/backend/base.py src/tensor_spec/backend/paddle_backend.py tests/test_backend/
git commit -m "feat(backend): add compute_grad and check_cuda_error to BackendBase"
```

---

### Task 2: TorchBackend

Implement PyTorch backend with all BackendBase methods. Mirrors PaddleBackend structure.

**Files:**
- Create: `src/tensor_spec/backend/torch_backend.py`
- Create: `tests/test_backend/test_torch_backend.py`

**Step 1: Write failing tests**

Create `tests/test_backend/test_torch_backend.py`:

```python
import importlib.util

import pytest

_has_torch = importlib.util.find_spec("torch") is not None


@pytest.mark.skipif(not _has_torch, reason="torch not installed")
class TestTorchBackend:
    def _make_backend(self):
        from tensor_spec.backend.torch_backend import TorchBackend
        b = TorchBackend()
        b.import_framework()
        return b

    def test_name(self):
        from tensor_spec.backend.torch_backend import TorchBackend
        assert TorchBackend().name == "torch"

    def test_import_framework(self):
        b = self._make_backend()
        assert b._torch is not None

    def test_numpy_to_tensor_float(self):
        import numpy as np
        from tensor_spec.spec.tensor import Tensor
        b = self._make_backend()
        spec = Tensor.float32((2, 3))
        np_arr = np.ones((2, 3), dtype="float32")
        t = b.numpy_to_tensor(np_arr, spec)
        assert t.shape == (2, 3)
        assert t.dtype.__str__() == "torch.float32"

    def test_numpy_to_tensor_with_grad(self):
        import numpy as np
        from tensor_spec.spec.state import TensorState
        from tensor_spec.spec.tensor import Tensor
        b = self._make_backend()
        spec = Tensor.float32((3,)).with_state(TensorState(need_grad=True))
        np_arr = np.array([1.0, 2.0, 3.0], dtype="float32")
        t = b.numpy_to_tensor(np_arr, spec)
        assert t.requires_grad is True

    def test_tensor_to_numpy(self):
        import numpy as np
        b = self._make_backend()
        import torch
        t = torch.tensor([1.0, 2.0, 3.0])
        result = b.tensor_to_numpy(t)
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])

    def test_exec_api(self):
        import numpy as np
        b = self._make_backend()
        import torch
        x = torch.tensor([1.0, -2.0, 3.0])
        result = b.exec_api("abs", (), {"input": x})
        np.testing.assert_array_equal(b.tensor_to_numpy(result), [1.0, 2.0, 3.0])

    def test_exec_api_dotted(self):
        b = self._make_backend()
        import torch
        x = torch.tensor([1.0, 2.0, 3.0])
        result = b.exec_api("nn.functional.relu", (), {"input": x})
        expected = [1.0, 2.0, 3.0]
        for a, e in zip(b.tensor_to_numpy(result).tolist(), expected):
            assert abs(a - e) < 1e-6

    def test_empty_cache(self):
        b = self._make_backend()
        b.empty_cache()  # Should not raise

    def test_check_cuda_error(self):
        b = self._make_backend()
        b.check_cuda_error()  # Should not raise on CPU

    def test_compute_grad(self):
        import numpy as np
        b = self._make_backend()
        import torch
        x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
        y = torch.sum(x * x)
        grads = b.compute_grad(y, [x])
        assert len(grads) == 1
        np.testing.assert_allclose(grads[0].numpy(), [2.0, 4.0, 6.0], atol=1e-6)
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_backend/test_torch_backend.py -v`
Expected: FAIL (import error — module not found)

**Step 3: Implement**

Create `src/tensor_spec/backend/torch_backend.py`:

```python
"""TorchBackend: PyTorch framework backend implementation."""

from __future__ import annotations

import contextlib
from typing import Any

import numpy as np

from tensor_spec.backend.base import BackendBase
from tensor_spec.spec.tensor import TensorSpec


class TorchBackend(BackendBase):
    """Backend for PyTorch framework."""

    def __init__(self) -> None:
        self._torch: Any = None

    @property
    def name(self) -> str:
        return "torch"

    def import_framework(self) -> None:
        import torch

        self._torch = torch

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        torch = self._torch
        t = torch.tensor(np_array)
        if spec.state and spec.state.need_grad:
            t = t.requires_grad_(True)
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.detach().cpu().numpy()

    def exec_api(self, api_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        api_func = self._resolve_api(api_name)
        return api_func(*args, **kwargs)

    def compute_grad(
        self, output: Any, inputs: list[Any], grad_output: Any | None = None
    ) -> list[Any]:
        torch = self._torch
        grads = torch.autograd.grad(
            output, inputs, grad_outputs=grad_output, allow_unused=True
        )
        return list(grads)

    def empty_cache(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def check_cuda_error(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            with contextlib.suppress(Exception):
                torch.cuda.synchronize()

    def _resolve_api(self, api_name: str) -> Any:
        """Resolve a dotted API name to a callable on the torch module."""
        obj = self._torch
        for part in api_name.split("."):
            obj = getattr(obj, part)
        return obj
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_backend/test_torch_backend.py -v`
Expected: All PASS (or skip if torch not installed)

**Step 5: Commit**

```bash
git add src/tensor_spec/backend/torch_backend.py tests/test_backend/test_torch_backend.py
git commit -m "feat(backend): add TorchBackend implementation"
```

---

### Task 3: Compare Layer — Tolerance + Comparator

Build the comparison infrastructure: `ToleranceConfig` (per-API atol/rtol from TOML), `CompareResult` (structured comparison output), and `NumpyComparator` (numpy-based comparison logic).

**Files:**
- Create: `src/tensor_spec/compare/__init__.py`
- Create: `src/tensor_spec/compare/tolerance.py`
- Create: `src/tensor_spec/compare/comparator.py`
- Create: `configs/tolerance.toml`
- Create: `tests/test_compare/__init__.py`
- Create: `tests/test_compare/test_tolerance.py`
- Create: `tests/test_compare/test_comparator.py`
- Modify: `pyproject.toml` (add tomli dependency)

**Step 1: Write failing tests for tolerance**

Create `tests/test_compare/__init__.py` (empty).

Create `tests/test_compare/test_tolerance.py`:

```python
import pytest

from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig


def test_tolerance_config_defaults():
    tc = ToleranceConfig()
    assert tc.atol == 1e-2
    assert tc.rtol == 1e-2


def test_tolerance_config_custom():
    tc = ToleranceConfig(atol=0.2, rtol=0.05)
    assert tc.atol == 0.2
    assert tc.rtol == 0.05


def test_tolerance_get_default():
    tol = Tolerance()
    result = tol.get("abs")
    assert result.atol == 1e-2
    assert result.rtol == 1e-2


def test_tolerance_get_override():
    overrides = {"matmul": ToleranceConfig(atol=2.0, rtol=0.05)}
    tol = Tolerance(overrides=overrides)
    result = tol.get("matmul")
    assert result.atol == 2.0
    assert result.rtol == 0.05


def test_tolerance_get_fallback_to_default():
    overrides = {"matmul": ToleranceConfig(atol=2.0, rtol=0.05)}
    tol = Tolerance(overrides=overrides)
    result = tol.get("abs")  # not in overrides
    assert result.atol == 1e-2


def test_tolerance_from_toml(tmp_path):
    toml_content = """
[default]
atol = 0.01
rtol = 0.01

[overrides.matmul]
atol = 2.0
rtol = 0.05

[overrides."nn.layer_norm"]
atol = 0.2
rtol = 0.02
"""
    p = tmp_path / "tolerance.toml"
    p.write_text(toml_content)
    tol = Tolerance.from_toml(str(p))
    assert tol.default.atol == 0.01
    assert tol.get("matmul").atol == 2.0
    assert tol.get("nn.layer_norm").rtol == 0.02
    assert tol.get("abs").atol == 0.01  # fallback


def test_tolerance_frozen():
    tc = ToleranceConfig()
    with pytest.raises(AttributeError):
        tc.atol = 0.5
```

**Step 2: Write failing tests for comparator**

Create `tests/test_compare/test_comparator.py`:

```python
import numpy as np

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import ToleranceConfig


def test_compare_result_creation():
    r = CompareResult(passed=True, max_abs_diff=0.0, max_rel_diff=0.0)
    assert r.passed is True


def test_exact_match():
    c = NumpyComparator()
    a = np.array([True, False, True])
    b = np.array([True, False, True])
    result = c.compare(a, b, ToleranceConfig())
    assert result.passed is True
    assert result.mismatched_count == 0


def test_exact_mismatch():
    c = NumpyComparator()
    a = np.array([True, False, True])
    b = np.array([True, True, True])
    result = c.compare(a, b, ToleranceConfig())
    assert result.passed is False
    assert result.mismatched_count == 1


def test_close_match():
    c = NumpyComparator()
    a = np.array([1.0, 2.0, 3.0])
    b = np.array([1.001, 2.001, 3.001])
    result = c.compare(a, b, ToleranceConfig(atol=0.01, rtol=0.01))
    assert result.passed is True


def test_close_mismatch():
    c = NumpyComparator()
    a = np.array([1.0, 2.0, 3.0])
    b = np.array([1.5, 2.0, 3.0])
    result = c.compare(a, b, ToleranceConfig(atol=0.01, rtol=0.01))
    assert result.passed is False
    assert result.mismatched_count == 1
    assert result.max_abs_diff >= 0.49


def test_nan_equal():
    c = NumpyComparator()
    a = np.array([1.0, float("nan"), 3.0])
    b = np.array([1.0, float("nan"), 3.0])
    result = c.compare(a, b, ToleranceConfig(atol=0.01, rtol=0.01))
    assert result.passed is True


def test_shape_mismatch():
    c = NumpyComparator()
    a = np.array([1.0, 2.0])
    b = np.array([1.0, 2.0, 3.0])
    result = c.compare(a, b, ToleranceConfig())
    assert result.passed is False
    assert "shape" in result.detail.lower()


def test_compare_result_has_total_count():
    c = NumpyComparator()
    a = np.array([1.0, 2.0, 3.0])
    b = np.array([1.0, 2.0, 3.0])
    result = c.compare(a, b, ToleranceConfig())
    assert result.total_count == 3
```

**Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/test_compare/ -v`
Expected: FAIL (modules not found)

**Step 4: Implement tolerance**

Add `tomli` dependency to `pyproject.toml`:

```toml
dependencies = [
    "numpy>=1.24",
    "click>=8.0",
    "tomli>=1.0; python_version < '3.11'",
]
```

Create `src/tensor_spec/compare/__init__.py` (empty).

Create `src/tensor_spec/compare/tolerance.py`:

```python
"""Tolerance configuration for accuracy comparison."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ToleranceConfig:
    """Tolerance for a single comparison (atol + rtol)."""

    atol: float = 1e-2
    rtol: float = 1e-2


@dataclass(frozen=True, slots=True)
class Tolerance:
    """Per-API tolerance configuration.

    Provides a default tolerance and optional per-API overrides.
    Overrides are loaded from a TOML file.
    """

    default: ToleranceConfig = field(default_factory=ToleranceConfig)
    overrides: dict[str, ToleranceConfig] = field(default_factory=dict)

    def get(self, api_name: str) -> ToleranceConfig:
        """Get tolerance for an API, falling back to default."""
        return self.overrides.get(api_name, self.default)

    @classmethod
    def from_toml(cls, path: str) -> Tolerance:
        """Load tolerance from a TOML file."""
        import sys

        if sys.version_info >= (3, 11):
            import tomllib
        else:
            import tomli as tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)

        default_data = data.get("default", {})
        default = ToleranceConfig(
            atol=default_data.get("atol", 1e-2),
            rtol=default_data.get("rtol", 1e-2),
        )

        overrides = {}
        for api_name, tol_data in data.get("overrides", {}).items():
            overrides[api_name] = ToleranceConfig(
                atol=tol_data.get("atol", default.atol),
                rtol=tol_data.get("rtol", default.rtol),
            )

        return cls(default=default, overrides=overrides)
```

**Step 5: Implement comparator**

Create `src/tensor_spec/compare/comparator.py`:

```python
"""Numpy-based comparison for accuracy testing."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from tensor_spec.compare.tolerance import ToleranceConfig


@dataclass(frozen=True, slots=True)
class CompareResult:
    """Result of comparing two numpy arrays."""

    passed: bool
    max_abs_diff: float = 0.0
    max_rel_diff: float = 0.0
    mismatched_count: int = 0
    total_count: int = 0
    detail: str = ""


class NumpyComparator:
    """Compares two numpy arrays with tolerance."""

    def compare(
        self, actual: np.ndarray, expected: np.ndarray, tol: ToleranceConfig
    ) -> CompareResult:
        if actual.shape != expected.shape:
            return CompareResult(
                passed=False,
                total_count=max(actual.size, expected.size),
                detail=f"Shape mismatch: {actual.shape} vs {expected.shape}",
            )

        if actual.dtype == np.bool_:
            return self._compare_exact(actual, expected)
        return self._compare_close(actual, expected, tol.atol, tol.rtol)

    def _compare_exact(
        self, actual: np.ndarray, expected: np.ndarray
    ) -> CompareResult:
        mismatched = int(np.sum(actual != expected))
        return CompareResult(
            passed=mismatched == 0,
            mismatched_count=mismatched,
            total_count=actual.size,
        )

    def _compare_close(
        self,
        actual: np.ndarray,
        expected: np.ndarray,
        atol: float,
        rtol: float,
    ) -> CompareResult:
        # Cast to float64 for comparison precision
        a = actual.astype(np.float64)
        b = expected.astype(np.float64)

        abs_diff = np.abs(a - b)
        # Mask NaN positions (NaN == NaN for our purposes)
        nan_mask = np.isnan(a) & np.isnan(b)
        non_nan_diff = np.where(nan_mask, 0.0, abs_diff)

        max_abs = float(np.max(non_nan_diff)) if non_nan_diff.size > 0 else 0.0
        denom = np.maximum(np.abs(b), 1e-12)
        max_rel = float(np.max(np.where(nan_mask, 0.0, non_nan_diff / denom)))

        close = np.allclose(a, b, atol=atol, rtol=rtol, equal_nan=True)
        not_close = ~np.isclose(a, b, atol=atol, rtol=rtol, equal_nan=True)
        mismatched = int(np.sum(not_close))

        return CompareResult(
            passed=close,
            max_abs_diff=max_abs,
            max_rel_diff=max_rel,
            mismatched_count=mismatched,
            total_count=actual.size,
        )
```

**Step 6: Create default tolerance config**

Create `configs/tolerance.toml`:

```toml
[default]
atol = 1e-2
rtol = 1e-2

[overrides.matmul]
atol = 2.0
rtol = 0.05

[overrides."nn.layer_norm"]
atol = 0.2
rtol = 0.02

[overrides.cumsum]
atol = 2.0
rtol = 0.01

[overrides."linalg.det"]
atol = 1.0
rtol = 0.1

[overrides."linalg.inv"]
atol = 1.0
rtol = 0.1
```

**Step 7: Run tests**

Run: `uv run pytest tests/test_compare/ -v`
Expected: All PASS

**Step 8: Commit**

```bash
git add src/tensor_spec/compare/ tests/test_compare/ configs/ pyproject.toml
git commit -m "feat(compare): add Tolerance config and NumpyComparator"
```

---

### Task 4: API Mapping Layer

JSON-based bidirectional mapping: canonical API name → framework-specific API path + argument name remapping.

**Files:**
- Create: `src/tensor_spec/mapping/__init__.py`
- Create: `src/tensor_spec/mapping/registry.py`
- Create: `src/tensor_spec/mapping/mappings/` (directory)
- Create: `src/tensor_spec/mapping/mappings/paddle.json` (starter: 10 APIs)
- Create: `src/tensor_spec/mapping/mappings/torch.json` (starter: 10 APIs)
- Create: `tests/test_mapping/__init__.py`
- Create: `tests/test_mapping/test_registry.py`

**Step 1: Write failing tests**

Create `tests/test_mapping/__init__.py` (empty).

Create `tests/test_mapping/test_registry.py`:

```python
import json

import pytest

from tensor_spec.mapping.registry import APIMapping, MappingRegistry


@pytest.fixture
def sample_paddle_json(tmp_path):
    data = {
        "abs": {"api": "abs", "args_map": {"x": "x"}},
        "add": {"api": "add", "args_map": {"x": "x", "y": "y"}},
        "nn.conv2d": {
            "api": "nn.functional.conv2d",
            "args_map": {"x": "x", "weight": "weight", "bias": "bias"},
        },
    }
    p = tmp_path / "paddle.json"
    p.write_text(json.dumps(data))
    return str(p)


@pytest.fixture
def sample_torch_json(tmp_path):
    data = {
        "abs": {"api": "abs", "args_map": {"x": "input"}},
        "add": {"api": "add", "args_map": {"x": "input", "y": "other"}},
        "nn.conv2d": {
            "api": "nn.functional.conv2d",
            "args_map": {"x": "input", "weight": "weight", "bias": "bias"},
        },
    }
    p = tmp_path / "torch.json"
    p.write_text(json.dumps(data))
    return str(p)


def test_load_and_resolve(sample_paddle_json):
    reg = MappingRegistry()
    reg.load("paddle", sample_paddle_json)
    m = reg.resolve("abs", "paddle")
    assert m.api == "abs"
    assert m.args_map == {"x": "x"}


def test_resolve_torch(sample_torch_json):
    reg = MappingRegistry()
    reg.load("torch", sample_torch_json)
    m = reg.resolve("abs", "torch")
    assert m.api == "abs"
    assert m.args_map == {"x": "input"}


def test_resolve_unknown_api(sample_paddle_json):
    reg = MappingRegistry()
    reg.load("paddle", sample_paddle_json)
    with pytest.raises(KeyError):
        reg.resolve("unknown_api", "paddle")


def test_resolve_unknown_framework(sample_paddle_json):
    reg = MappingRegistry()
    reg.load("paddle", sample_paddle_json)
    with pytest.raises(KeyError):
        reg.resolve("abs", "torch")


def test_map_kwargs(sample_torch_json):
    reg = MappingRegistry()
    reg.load("torch", sample_torch_json)
    mapped = reg.map_kwargs("add", "torch", {"x": 1, "y": 2})
    assert mapped == {"input": 1, "other": 2}


def test_map_kwargs_passthrough_unmapped(sample_torch_json):
    reg = MappingRegistry()
    reg.load("torch", sample_torch_json)
    mapped = reg.map_kwargs("abs", "torch", {"x": 1, "extra": 42})
    assert mapped == {"input": 1, "extra": 42}


def test_resolve_api_name(sample_paddle_json):
    reg = MappingRegistry()
    reg.load("paddle", sample_paddle_json)
    assert reg.resolve_api("nn.conv2d", "paddle") == "nn.functional.conv2d"


def test_api_mapping_frozen():
    m = APIMapping(api="abs", args_map={"x": "input"})
    assert m.api == "abs"


def test_load_from_package():
    """Test loading bundled mapping files from the package."""
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    reg.load_bundled("torch")
    # Both should have "abs" mapped
    assert reg.resolve("abs", "paddle").api == "abs"
    assert reg.resolve("abs", "torch").api == "abs"
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_mapping/ -v`
Expected: FAIL (module not found)

**Step 3: Implement**

Create `src/tensor_spec/mapping/__init__.py` (empty).

Create `src/tensor_spec/mapping/registry.py`:

```python
"""API mapping registry: canonical name → framework-specific API + arg names."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path


@dataclass(frozen=True, slots=True)
class APIMapping:
    """Mapping for a single API: framework-specific path + arg name map."""

    api: str
    args_map: dict[str, str] = field(default_factory=dict)


class MappingRegistry:
    """Registry of API mappings per framework.

    Loads JSON files with the format:
    {
        "canonical_name": {
            "api": "framework.specific.path",
            "args_map": {"canonical_arg": "framework_arg"}
        }
    }
    """

    def __init__(self) -> None:
        self._mappings: dict[str, dict[str, APIMapping]] = {}

    def load(self, framework: str, path: str) -> None:
        """Load mappings from a JSON file."""
        with open(path) as f:
            data = json.load(f)
        self._mappings[framework] = {
            canonical: APIMapping(
                api=entry["api"],
                args_map=entry.get("args_map", {}),
            )
            for canonical, entry in data.items()
        }

    def load_bundled(self, framework: str) -> None:
        """Load bundled mapping file from the package."""
        mappings_dir = Path(__file__).parent / "mappings"
        path = mappings_dir / f"{framework}.json"
        self.load(framework, str(path))

    def resolve(self, canonical_name: str, framework: str) -> APIMapping:
        """Resolve a canonical API name to its framework mapping."""
        return self._mappings[framework][canonical_name]

    def resolve_api(self, canonical_name: str, framework: str) -> str:
        """Get the framework-specific API path."""
        return self._mappings[framework][canonical_name].api

    def map_kwargs(
        self, canonical_name: str, framework: str, kwargs: dict
    ) -> dict:
        """Remap kwarg names from canonical to framework-specific."""
        mapping = self._mappings[framework][canonical_name]
        return {mapping.args_map.get(k, k): v for k, v in kwargs.items()}
```

Create starter `src/tensor_spec/mapping/mappings/paddle.json` (10 APIs for now — Task 8 will expand to 100):

```json
{
    "abs": {"api": "abs", "args_map": {"x": "x"}},
    "add": {"api": "add", "args_map": {"x": "x", "y": "y"}},
    "matmul": {"api": "matmul", "args_map": {"x": "x", "y": "y"}},
    "sum": {"api": "sum", "args_map": {"x": "x", "axis": "axis"}},
    "mean": {"api": "mean", "args_map": {"x": "x", "axis": "axis"}},
    "sqrt": {"api": "sqrt", "args_map": {"x": "x"}},
    "exp": {"api": "exp", "args_map": {"x": "x"}},
    "log": {"api": "log", "args_map": {"x": "x"}},
    "relu": {"api": "nn.functional.relu", "args_map": {"x": "x"}},
    "sigmoid": {"api": "nn.functional.sigmoid", "args_map": {"x": "x"}}
}
```

Create starter `src/tensor_spec/mapping/mappings/torch.json`:

```json
{
    "abs": {"api": "abs", "args_map": {"x": "input"}},
    "add": {"api": "add", "args_map": {"x": "input", "y": "other"}},
    "matmul": {"api": "matmul", "args_map": {"x": "input", "y": "other"}},
    "sum": {"api": "sum", "args_map": {"x": "input", "axis": "dim"}},
    "mean": {"api": "mean", "args_map": {"x": "input", "axis": "dim"}},
    "sqrt": {"api": "sqrt", "args_map": {"x": "input"}},
    "exp": {"api": "exp", "args_map": {"x": "input"}},
    "log": {"api": "log", "args_map": {"x": "input"}},
    "relu": {"api": "nn.functional.relu", "args_map": {"x": "input"}},
    "sigmoid": {"api": "nn.functional.sigmoid", "args_map": {"x": "input"}}
}
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_mapping/ -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/mapping/ tests/test_mapping/
git commit -m "feat(mapping): add API mapping registry with JSON loading"
```

---

### Task 5: Tester Layer — TestResult + TesterBase + AccuracyTester

Template method pattern: TesterBase defines the skeleton (generate → execute → compare), AccuracyTester implements dual-backend accuracy comparison.

**Files:**
- Create: `src/tensor_spec/tester/__init__.py`
- Create: `src/tensor_spec/tester/base.py`
- Create: `src/tensor_spec/tester/accuracy.py`
- Create: `tests/test_tester/__init__.py`
- Create: `tests/test_tester/test_base.py`
- Create: `tests/test_tester/test_accuracy.py`

**Step 1: Write failing tests for TesterBase**

Create `tests/test_tester/__init__.py` (empty).

Create `tests/test_tester/test_base.py`:

```python
from enum import Enum

import pytest

from tensor_spec.tester.base import TestResult, TestStatus


def test_test_status_values():
    assert TestStatus.PASSED.value == "pass"
    assert TestStatus.ACCURACY_ERROR.value == "accuracy_error"
    assert TestStatus.PADDLE_ERROR.value == "paddle_error"
    assert TestStatus.TORCH_ERROR.value == "torch_error"
    assert TestStatus.CUDA_ERROR.value == "cuda_error"
    assert TestStatus.OOM_ERROR.value == "oom"
    assert TestStatus.ERROR.value == "error"


def test_test_result_creation():
    from tensor_spec.config.case import CaseConfig

    case = CaseConfig(api_name="abs", args=(), kwargs={})
    result = TestResult(case=case, status=TestStatus.PASSED)
    assert result.status == TestStatus.PASSED
    assert result.error is None
    assert result.compare_result is None
    assert result.duration_ms == 0.0


def test_test_result_with_error():
    from tensor_spec.config.case import CaseConfig

    case = CaseConfig(api_name="abs", args=(), kwargs={})
    result = TestResult(case=case, status=TestStatus.ERROR, error="some error")
    assert result.error == "some error"
```

**Step 2: Write failing tests for AccuracyTester**

Create `tests/test_tester/test_accuracy.py`:

```python
from unittest.mock import MagicMock

import numpy as np
import pytest

from tensor_spec.compare.comparator import CompareResult, NumpyComparator
from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import APIMapping, MappingRegistry
from tensor_spec.spec.tensor import Tensor
from tensor_spec.tester.accuracy import AccuracyTester
from tensor_spec.tester.base import TestStatus


def _make_mock_backend(name: str):
    """Create a mock backend that returns identity for exec_api."""
    backend = MagicMock()
    backend.name = name

    def numpy_to_tensor(np_arr, spec):
        return np_arr  # pass-through for testing

    def tensor_to_numpy(tensor):
        return tensor  # pass-through

    def exec_api(api_name, args, kwargs):
        # Return first kwarg value (simulates identity API)
        for v in kwargs.values():
            if isinstance(v, np.ndarray):
                return v
        return np.array([0.0])

    backend.numpy_to_tensor = MagicMock(side_effect=numpy_to_tensor)
    backend.tensor_to_numpy = MagicMock(side_effect=tensor_to_numpy)
    backend.exec_api = MagicMock(side_effect=exec_api)
    backend.empty_cache = MagicMock()
    backend.check_cuda_error = MagicMock()
    return backend


def _make_mapping_registry():
    """Create a registry with abs mapped for both frameworks."""
    reg = MappingRegistry()
    reg._mappings["paddle"] = {
        "abs": APIMapping(api="abs", args_map={"x": "x"}),
    }
    reg._mappings["torch"] = {
        "abs": APIMapping(api="abs", args_map={"x": "input"}),
    }
    return reg


def test_accuracy_tester_pass():
    backend_a = _make_mock_backend("paddle")
    backend_b = _make_mock_backend("torch")
    tester = AccuracyTester(
        backend_a=backend_a,
        backend_b=backend_b,
        mapping=_make_mapping_registry(),
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": Tensor.float32((3,))},
    )
    result = tester.test(case)
    assert result.status == TestStatus.PASSED
    assert result.duration_ms > 0
    backend_a.exec_api.assert_called_once()
    backend_b.exec_api.assert_called_once()
    backend_a.empty_cache.assert_called_once()


def test_accuracy_tester_mismatch():
    backend_a = _make_mock_backend("paddle")
    backend_b = _make_mock_backend("torch")

    # Make backend_b return different values
    def exec_b(api_name, args, kwargs):
        for v in kwargs.values():
            if isinstance(v, np.ndarray):
                return v + 100.0  # large difference
        return np.array([100.0])

    backend_b.exec_api = MagicMock(side_effect=exec_b)

    tester = AccuracyTester(
        backend_a=backend_a,
        backend_b=backend_b,
        mapping=_make_mapping_registry(),
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": Tensor.float32((3,))},
    )
    result = tester.test(case)
    assert result.status == TestStatus.ACCURACY_ERROR
    assert result.compare_result is not None
    assert result.compare_result.passed is False


def test_accuracy_tester_backend_error():
    backend_a = _make_mock_backend("paddle")
    backend_b = _make_mock_backend("torch")
    backend_b.exec_api = MagicMock(side_effect=RuntimeError("torch crash"))

    tester = AccuracyTester(
        backend_a=backend_a,
        backend_b=backend_b,
        mapping=_make_mapping_registry(),
        comparator=NumpyComparator(),
        tolerance=Tolerance(),
        generator=TensorGenerator(seed=42),
    )
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": Tensor.float32((3,))},
    )
    result = tester.test(case)
    assert result.status == TestStatus.TORCH_ERROR
    assert "torch crash" in result.error
```

**Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/test_tester/ -v`
Expected: FAIL (modules not found)

**Step 4: Implement TesterBase**

Create `src/tensor_spec/tester/__init__.py` (empty).

Create `src/tensor_spec/tester/base.py`:

```python
"""Tester base class with template method pattern."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from tensor_spec.compare.comparator import CompareResult
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.spec.tensor import TensorSpec


class TestStatus(Enum):
    """Status of a test result."""

    PASSED = "pass"
    ACCURACY_ERROR = "accuracy_error"
    PADDLE_ERROR = "paddle_error"
    TORCH_ERROR = "torch_error"
    CUDA_ERROR = "cuda_error"
    OOM_ERROR = "oom"
    ERROR = "error"


@dataclass
class TestResult:
    """Result of running a single test case."""

    case: CaseConfig
    status: TestStatus
    compare_result: CompareResult | None = None
    error: str | None = None
    duration_ms: float = 0.0


@dataclass
class GeneratedInputs:
    """Numpy arrays generated from a CaseConfig's TensorSpec values."""

    arg_arrays: list[np.ndarray | None] = field(default_factory=list)
    kwarg_arrays: dict[str, np.ndarray] = field(default_factory=dict)


class TesterBase(ABC):
    """Base class for all test modes. Implements template method pattern.

    Subclasses implement execute() and compare().
    """

    def __init__(self, generator: TensorGenerator) -> None:
        self._generator = generator

    def test(self, case: CaseConfig) -> TestResult:
        """Run a single test case: generate → execute → compare."""
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except MemoryError as e:
            return TestResult(
                case=case, status=TestStatus.OOM_ERROR, error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            return TestResult(
                case=case, status=TestStatus.ERROR, error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    def _generate_inputs(self, case: CaseConfig) -> GeneratedInputs:
        """Generate numpy arrays for all TensorSpec values in the case."""
        arg_arrays: list[np.ndarray | None] = []
        for val in case.args:
            if isinstance(val, TensorSpec):
                arg_arrays.append(self._generator.generate(val))
            else:
                arg_arrays.append(None)

        kwarg_arrays: dict[str, np.ndarray] = {}
        for key, val in case.kwargs.items():
            if isinstance(val, TensorSpec):
                kwarg_arrays[key] = self._generator.generate(val)

        return GeneratedInputs(arg_arrays=arg_arrays, kwarg_arrays=kwarg_arrays)

    @abstractmethod
    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute the API call(s). Returns outputs dict."""
        ...

    @abstractmethod
    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """Compare outputs and return a TestResult."""
        ...
```

**Step 5: Implement AccuracyTester**

Create `src/tensor_spec/tester/accuracy.py`:

```python
"""AccuracyTester: dual-backend cross-framework accuracy comparison."""

from __future__ import annotations

from typing import Any

from tensor_spec.backend.base import BackendBase
from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import TensorSpec
from tensor_spec.tester.base import GeneratedInputs, TestResult, TestStatus, TesterBase


class BackendError(Exception):
    """Error raised by a specific backend during execution."""

    def __init__(self, backend_name: str, original: Exception) -> None:
        self.backend_name = backend_name
        self.original = original
        super().__init__(f"{backend_name} error: {original}")


class AccuracyTester(TesterBase):
    """Cross-framework accuracy comparison tester.

    Executes the same API on two backends, compares numpy outputs.
    Execution order: backend_a first, empty_cache, then backend_b.
    """

    def __init__(
        self,
        backend_a: BackendBase,
        backend_b: BackendBase,
        mapping: MappingRegistry,
        comparator: NumpyComparator,
        tolerance: Tolerance,
        generator: TensorGenerator,
    ) -> None:
        super().__init__(generator)
        self.backend_a = backend_a
        self.backend_b = backend_b
        self.mapping = mapping
        self.comparator = comparator
        self.tolerance = tolerance

    def test(self, case: CaseConfig) -> TestResult:
        """Override to catch backend-specific errors."""
        import time

        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except BackendError as e:
            status = self._backend_error_status(e.backend_name)
            return TestResult(
                case=case, status=status, error=str(e.original),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except MemoryError as e:
            return TestResult(
                case=case, status=TestStatus.OOM_ERROR, error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            return TestResult(
                case=case, status=TestStatus.ERROR, error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    def execute(
        self, case: CaseConfig, inputs: GeneratedInputs
    ) -> dict[str, Any]:
        # Execute backend A
        a_api, a_args, a_kwargs = self._prepare_call(
            case, inputs, self.backend_a
        )
        try:
            output_a = self.backend_a.exec_api(a_api, a_args, a_kwargs)
            self.backend_a.check_cuda_error()
        except Exception as e:
            raise BackendError(self.backend_a.name, e) from e

        self.backend_a.empty_cache()

        # Execute backend B
        b_api, b_args, b_kwargs = self._prepare_call(
            case, inputs, self.backend_b
        )
        try:
            output_b = self.backend_b.exec_api(b_api, b_args, b_kwargs)
            self.backend_b.check_cuda_error()
        except Exception as e:
            raise BackendError(self.backend_b.name, e) from e

        return {"a_output": output_a, "b_output": output_b}

    def compare(
        self, case: CaseConfig, outputs: dict[str, Any]
    ) -> TestResult:
        np_a = self.backend_a.tensor_to_numpy(outputs["a_output"])
        np_b = self.backend_b.tensor_to_numpy(outputs["b_output"])
        tol = self.tolerance.get(case.api_name)
        cmp_result = self.comparator.compare(np_a, np_b, tol)
        status = TestStatus.PASSED if cmp_result.passed else TestStatus.ACCURACY_ERROR
        return TestResult(
            case=case, status=status, compare_result=cmp_result
        )

    def _prepare_call(
        self,
        case: CaseConfig,
        inputs: GeneratedInputs,
        backend: BackendBase,
    ) -> tuple[str, tuple[Any, ...], dict[str, Any]]:
        """Prepare framework-specific API call from canonical case."""
        mapping = self.mapping.resolve(case.api_name, backend.name)

        # Convert positional args
        args: list[Any] = []
        for i, val in enumerate(case.args):
            if isinstance(val, TensorSpec) and inputs.arg_arrays[i] is not None:
                args.append(
                    backend.numpy_to_tensor(inputs.arg_arrays[i], val)
                )
            else:
                args.append(val)

        # Convert and remap keyword args
        kwargs: dict[str, Any] = {}
        for key, val in case.kwargs.items():
            mapped_key = mapping.args_map.get(key, key)
            if isinstance(val, TensorSpec) and key in inputs.kwarg_arrays:
                kwargs[mapped_key] = backend.numpy_to_tensor(
                    inputs.kwarg_arrays[key], val
                )
            else:
                kwargs[mapped_key] = val

        return mapping.api, tuple(args), kwargs

    def _backend_error_status(self, backend_name: str) -> TestStatus:
        """Map backend name to error status."""
        if backend_name == "paddle":
            return TestStatus.PADDLE_ERROR
        if backend_name == "torch":
            return TestStatus.TORCH_ERROR
        return TestStatus.ERROR
```

**Step 6: Run tests**

Run: `uv run pytest tests/test_tester/ -v`
Expected: All PASS

**Step 7: Commit**

```bash
git add src/tensor_spec/tester/ tests/test_tester/
git commit -m "feat(tester): add TesterBase template and AccuracyTester"
```

---

### Task 6: LogWriter — JSON Lines Structured Logging

Append-only JSON Lines log writer. Each line is a JSON object with timestamp, API name, case string, status, diff metrics, PID.

**Files:**
- Create: `src/tensor_spec/log/__init__.py`
- Create: `src/tensor_spec/log/writer.py`
- Create: `tests/test_log/__init__.py`
- Create: `tests/test_log/test_writer.py`

**Step 1: Write failing tests**

Create `tests/test_log/__init__.py` (empty).

Create `tests/test_log/test_writer.py`:

```python
import json

import pytest

from tensor_spec.config.case import CaseConfig
from tensor_spec.compare.comparator import CompareResult
from tensor_spec.log.writer import LogWriter
from tensor_spec.tester.base import TestResult, TestStatus


def _make_case(api_name: str = "abs") -> CaseConfig:
    return CaseConfig(api_name=api_name, args=(), kwargs={})


def test_writer_creates_file(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    result = TestResult(case=_make_case(), status=TestStatus.PASSED, duration_ms=1.5)
    writer.write(result)
    writer.close()
    assert path.exists()


def test_writer_writes_valid_json(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    result = TestResult(case=_make_case(), status=TestStatus.PASSED, duration_ms=1.5)
    writer.write(result)
    writer.close()

    line = path.read_text().strip()
    record = json.loads(line)
    assert record["api"] == "abs"
    assert record["status"] == "pass"
    assert record["duration_ms"] == 1.5
    assert "ts" in record
    assert "pid" in record


def test_writer_accuracy_error_includes_diff(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    cmp = CompareResult(
        passed=False, max_abs_diff=0.05, max_rel_diff=0.02,
        mismatched_count=3, total_count=100,
    )
    result = TestResult(
        case=_make_case(), status=TestStatus.ACCURACY_ERROR,
        compare_result=cmp, duration_ms=2.3,
    )
    writer.write(result)
    writer.close()

    record = json.loads(path.read_text().strip())
    assert record["status"] == "accuracy_error"
    assert record["max_abs_diff"] == 0.05
    assert record["max_rel_diff"] == 0.02
    assert record["mismatched_count"] == 3


def test_writer_error_includes_message(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    result = TestResult(
        case=_make_case(), status=TestStatus.TORCH_ERROR,
        error="RuntimeError: cuda out of memory", duration_ms=0.1,
    )
    writer.write(result)
    writer.close()

    record = json.loads(path.read_text().strip())
    assert record["status"] == "torch_error"
    assert "cuda out of memory" in record["error"]


def test_writer_multiple_lines(tmp_path):
    path = tmp_path / "test.jsonl"
    writer = LogWriter(str(path))
    for i in range(3):
        result = TestResult(
            case=_make_case(f"api_{i}"), status=TestStatus.PASSED, duration_ms=float(i),
        )
        writer.write(result)
    writer.close()

    lines = path.read_text().strip().split("\n")
    assert len(lines) == 3
    for line in lines:
        json.loads(line)  # each line is valid JSON


def test_writer_context_manager(tmp_path):
    path = tmp_path / "test.jsonl"
    with LogWriter(str(path)) as writer:
        writer.write(TestResult(case=_make_case(), status=TestStatus.PASSED))
    assert path.exists()
    assert len(path.read_text().strip().split("\n")) == 1
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_log/ -v`
Expected: FAIL (module not found)

**Step 3: Implement**

Create `src/tensor_spec/log/__init__.py` (empty).

Create `src/tensor_spec/log/writer.py`:

```python
"""JSON Lines structured log writer."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import IO

from tensor_spec.tester.base import TestResult


class LogWriter:
    """Append-only JSON Lines log writer.

    Each line is a JSON object:
    {"ts": "...", "api": "abs", "status": "pass", "duration_ms": 1.5, "pid": 12345, ...}
    """

    def __init__(self, path: str) -> None:
        self._path = path
        self._file: IO[str] = open(path, "a")  # noqa: SIM115

    def write(self, result: TestResult) -> None:
        """Write a single test result as a JSON line."""
        record: dict = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "api": result.case.api_name,
            "status": result.status.value,
            "duration_ms": round(result.duration_ms, 2),
            "pid": os.getpid(),
        }
        if result.compare_result is not None:
            record["max_abs_diff"] = result.compare_result.max_abs_diff
            record["max_rel_diff"] = result.compare_result.max_rel_diff
            record["mismatched_count"] = result.compare_result.mismatched_count
            record["total_count"] = result.compare_result.total_count
        if result.error is not None:
            record["error"] = result.error

        self._file.write(json.dumps(record) + "\n")
        self._file.flush()

    def close(self) -> None:
        """Close the log file."""
        self._file.close()

    def __enter__(self) -> LogWriter:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_log/ -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/log/ tests/test_log/
git commit -m "feat(log): add JSON Lines LogWriter"
```

---

### Task 7: CLI Accuracy Command

Add `tensor-spec accuracy` CLI command for cross-framework comparison. Also update `_load_backend` to support torch.

**Files:**
- Modify: `src/tensor_spec/cli.py`
- Modify: `tests/test_cli.py`

**Step 1: Write failing tests**

Add to `tests/test_cli.py`:

```python
from click.testing import CliRunner
from tensor_spec.cli import main


def test_accuracy_command_exists():
    runner = CliRunner()
    result = runner.invoke(main, ["accuracy", "--help"])
    assert result.exit_code == 0
    assert "backend-a" in result.output or "backend_a" in result.output


def test_accuracy_missing_case():
    runner = CliRunner()
    result = runner.invoke(main, ["accuracy", "--backend-a", "paddle", "--backend-b", "torch"])
    assert result.exit_code != 0


def test_accuracy_invalid_case():
    runner = CliRunner()
    result = runner.invoke(main, [
        "accuracy", "--backend-a", "paddle", "--backend-b", "torch",
        "--case", "???invalid",
    ])
    assert result.exit_code != 0
    assert "error" in result.output.lower() or "invalid" in result.output.lower()
```

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_cli.py -v -k "accuracy"`
Expected: FAIL

**Step 3: Implement**

Update `src/tensor_spec/cli.py` — add `accuracy` command and update `_load_backend`:

```python
# Add at the end of _load_backend:
def _load_backend(name: str) -> Any:
    """Load a backend by name."""
    if name == "paddle":
        from tensor_spec.backend.paddle_backend import PaddleBackend
        return PaddleBackend()
    if name == "torch":
        from tensor_spec.backend.torch_backend import TorchBackend
        return TorchBackend()
    raise ValueError(f"Unknown backend: {name}. Available: paddle, torch")


# Add new command:
@main.command()
@click.option("--backend-a", required=True, help="First backend (e.g., paddle)")
@click.option("--backend-b", required=True, help="Second backend (e.g., torch)")
@click.option("--case", required=True, help='Case string (e.g., "abs(x=Tensor.float32((100,)))")')
@click.option("--seed", default=42, type=int, help="Random seed")
@click.option("--tolerance-config", default=None, type=str, help="Path to tolerance TOML")
@click.option("--log-file", default=None, type=str, help="Path to JSON Lines log file")
def accuracy(
    backend_a: str, backend_b: str, case: str, seed: int,
    tolerance_config: str | None, log_file: str | None,
) -> None:
    """Run cross-framework accuracy comparison for a single case."""
    from tensor_spec.compare.comparator import NumpyComparator
    from tensor_spec.compare.tolerance import Tolerance
    from tensor_spec.datagen.generator import TensorGenerator
    from tensor_spec.log.writer import LogWriter
    from tensor_spec.mapping.registry import MappingRegistry
    from tensor_spec.tester.accuracy import AccuracyTester

    # Parse case
    try:
        case_config = parse_case(case)
    except ValueError as e:
        click.echo(f"Parse error: {e}", err=True)
        sys.exit(1)
    click.echo(f"API: {case_config.api_name}")

    # Load tolerance
    if tolerance_config:
        tol = Tolerance.from_toml(tolerance_config)
    else:
        tol = Tolerance()

    # Load mappings
    mapping = MappingRegistry()
    mapping.load_bundled(backend_a)
    mapping.load_bundled(backend_b)

    # Init backends
    ba = _load_backend(backend_a)
    bb = _load_backend(backend_b)
    ba.import_framework()
    bb.import_framework()

    # Run test
    tester = AccuracyTester(
        backend_a=ba, backend_b=bb,
        mapping=mapping, comparator=NumpyComparator(),
        tolerance=tol, generator=TensorGenerator(seed=seed),
    )
    result = tester.test(case_config)

    # Output
    click.echo(f"Status: {result.status.value}")
    if result.compare_result:
        click.echo(f"  max_abs_diff: {result.compare_result.max_abs_diff:.6e}")
        click.echo(f"  max_rel_diff: {result.compare_result.max_rel_diff:.6e}")
    if result.error:
        click.echo(f"  error: {result.error}", err=True)

    # Log
    if log_file:
        with LogWriter(log_file) as writer:
            writer.write(result)
        click.echo(f"Log written to {log_file}")

    sys.exit(0 if result.status == result.status.PASSED else 1)
```

**Step 4: Run tests**

Run: `uv run pytest tests/test_cli.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/cli.py tests/test_cli.py
git commit -m "feat(cli): add accuracy command for cross-framework comparison"
```

---

### Task 8: Populate 100 API Mappings

Expand mapping JSON files to cover 100 common APIs. Organized by category: math unary, math binary, reduction, linear algebra, shape ops, nn functional.

**Files:**
- Modify: `src/tensor_spec/mapping/mappings/paddle.json`
- Modify: `src/tensor_spec/mapping/mappings/torch.json`
- Create: `tests/test_mapping/test_mapping_coverage.py`

**Step 1: Write coverage test**

Create `tests/test_mapping/test_mapping_coverage.py`:

```python
import json
from pathlib import Path

import pytest

from tensor_spec.mapping.registry import MappingRegistry

MAPPING_DIR = Path(__file__).parent.parent.parent / "src" / "tensor_spec" / "mapping" / "mappings"

REQUIRED_APIS = [
    # Math unary (30)
    "abs", "acos", "acosh", "asin", "asinh", "atan", "atanh",
    "ceil", "cos", "cosh", "erf", "exp", "expm1", "floor",
    "log", "log10", "log1p", "log2", "neg", "reciprocal",
    "round", "rsqrt", "sign", "sin", "sinh", "sqrt", "square",
    "tan", "tanh", "trunc",
    # Math binary (10)
    "add", "subtract", "multiply", "divide", "remainder",
    "pow", "maximum", "minimum", "fmod", "atan2",
    # Reduction (10)
    "sum", "mean", "max", "min", "prod",
    "any", "all", "argmax", "argmin", "cumsum",
    # Linear algebra (5)
    "matmul", "dot", "bmm", "linalg.norm", "linalg.det",
    # Shape (15)
    "reshape", "transpose", "squeeze", "unsqueeze", "flatten",
    "concat", "stack", "split", "tile", "flip",
    "roll", "gather", "scatter", "index_select", "masked_select",
    # NN functional (20)
    "relu", "sigmoid", "softmax", "log_softmax", "tanh_",
    "gelu", "silu", "leaky_relu", "elu", "dropout",
    "linear", "conv1d", "conv2d", "batch_norm", "layer_norm",
    "pad", "interpolate", "cross_entropy", "mse_loss", "l1_loss",
    # Creation/manipulation (10)
    "zeros_like", "ones_like", "full_like", "clone",
    "where", "sort", "topk", "unique", "isnan", "isfinite",
]


def test_paddle_has_all_required_apis():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    for api in REQUIRED_APIS:
        assert api in reg._mappings["paddle"], f"Missing paddle mapping for: {api}"


def test_torch_has_all_required_apis():
    reg = MappingRegistry()
    reg.load_bundled("torch")
    for api in REQUIRED_APIS:
        assert api in reg._mappings["torch"], f"Missing torch mapping for: {api}"


def test_mapping_count():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    reg.load_bundled("torch")
    assert len(reg._mappings["paddle"]) >= 100
    assert len(reg._mappings["torch"]) >= 100


def test_all_mappings_have_api_field():
    reg = MappingRegistry()
    reg.load_bundled("paddle")
    reg.load_bundled("torch")
    for framework in ["paddle", "torch"]:
        for name, mapping in reg._mappings[framework].items():
            assert mapping.api, f"{framework}.{name} has empty api field"
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_mapping/test_mapping_coverage.py -v`
Expected: FAIL (only 10 APIs currently)

**Step 3: Populate full mapping files**

Replace `src/tensor_spec/mapping/mappings/paddle.json` with complete 100-API mapping.

Key patterns for paddle:
- Most unary ops: `x` param name
- Most binary ops: `x`, `y` param names
- Reduction ops: `x`, `axis` for dimension
- NN functional: under `nn.functional.*`, `x` param
- Shape ops: `x`, various extra params

Replace `src/tensor_spec/mapping/mappings/torch.json` with complete 100-API mapping.

Key patterns for torch:
- Most unary ops: `input` param name
- Most binary ops: `input`, `other` param names
- Reduction ops: `input`, `dim` for dimension
- NN functional: under `nn.functional.*`, `input` param
- Shape ops: `input`, various extra params

**Canonical name → paddle/torch mapping conventions:**

| Category | Canonical args | Paddle args | Torch args |
|----------|---------------|-------------|------------|
| Unary math | x | x | input |
| Binary math | x, y | x, y | input, other |
| Reduction | x, axis | x, axis | input, dim |
| NN functional | x | x | input |
| Shape | x | x | input |

Special cases to note:
- `pow`: torch uses `exponent` not `other` for second arg
- `dot`: torch uses `tensor` not `other`
- `bmm`: torch uses `mat2` not `other`
- `concat`: paddle uses `x` (list), torch uses `tensors`
- `stack`: paddle uses `x` (list), torch uses `tensors`
- `clone`: paddle uses `x`, torch uses `input` — but paddle's API is `paddle.clone(x)` and torch's is `torch.clone(input)`
- NN ops: both frameworks use `nn.functional.*` paths but arg names differ
- `cross_entropy`: paddle `nn.functional.cross_entropy(input, label)`, torch `nn.functional.cross_entropy(input, target)`
- `dropout`: both use `nn.functional.dropout` with `p` param, but paddle's first arg is `x`, torch's is `input`

**Step 4: Run tests**

Run: `uv run pytest tests/test_mapping/test_mapping_coverage.py -v`
Expected: All PASS

**Step 5: Commit**

```bash
git add src/tensor_spec/mapping/mappings/ tests/test_mapping/test_mapping_coverage.py
git commit -m "feat(mapping): add 100 API mappings for paddle and torch"
```

---

### Task 9: Integration Tests

End-to-end tests verifying the full accuracy pipeline: parse → generate → map → execute → compare → log.

**Files:**
- Modify: `tests/test_integration.py`

**Step 1: Write integration tests**

Add to `tests/test_integration.py`:

```python
import importlib.util
import json

import pytest

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.parser import parse_case
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.log.writer import LogWriter
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.tester.accuracy import AccuracyTester
from tensor_spec.tester.base import TestStatus

_has_paddle = importlib.util.find_spec("paddle") is not None
_has_torch = importlib.util.find_spec("torch") is not None
_has_both = _has_paddle and _has_torch


@pytest.mark.skipif(not _has_both, reason="Both paddle and torch required")
class TestAccuracyIntegration:
    """End-to-end accuracy tests requiring both frameworks."""

    def _make_tester(self):
        from tensor_spec.backend.paddle_backend import PaddleBackend
        from tensor_spec.backend.torch_backend import TorchBackend

        ba = PaddleBackend()
        bb = TorchBackend()
        ba.import_framework()
        bb.import_framework()

        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")

        return AccuracyTester(
            backend_a=ba, backend_b=bb,
            mapping=mapping, comparator=NumpyComparator(),
            tolerance=Tolerance(), generator=TensorGenerator(seed=42),
        )

    def test_abs_accuracy(self):
        tester = self._make_tester()
        case = parse_case('abs(x=Tensor.float64((10,)))')
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_add_accuracy(self):
        tester = self._make_tester()
        case = parse_case('add(x=Tensor.float64((5, 5)), y=Tensor.float64((5, 5)))')
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_matmul_accuracy(self):
        tester = self._make_tester()
        case = parse_case('matmul(x=Tensor.float64((4, 3)), y=Tensor.float64((3, 5)))')
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_sqrt_accuracy(self):
        tester = self._make_tester()
        case = parse_case('sqrt(x=Tensor.float64((10,)).stats(min=0.01, max=10.0))')
        result = tester.test(case)
        assert result.status == TestStatus.PASSED

    def test_log_writer_integration(self, tmp_path):
        tester = self._make_tester()
        case = parse_case('abs(x=Tensor.float64((10,)))')
        result = tester.test(case)

        log_path = tmp_path / "test.jsonl"
        with LogWriter(str(log_path)) as writer:
            writer.write(result)

        record = json.loads(log_path.read_text().strip())
        assert record["api"] == "abs"
        assert record["status"] == "pass"


class TestMappingIntegration:
    """Test mapping loading without frameworks."""

    def test_load_both_mappings(self):
        mapping = MappingRegistry()
        mapping.load_bundled("paddle")
        mapping.load_bundled("torch")

        # abs is in both
        paddle_abs = mapping.resolve("abs", "paddle")
        torch_abs = mapping.resolve("abs", "torch")
        assert paddle_abs.api == "abs"
        assert torch_abs.api == "abs"
        assert paddle_abs.args_map["x"] == "x"
        assert torch_abs.args_map["x"] == "input"

    def test_tolerance_from_bundled_config(self):
        from tensor_spec.compare.tolerance import Tolerance
        from pathlib import Path

        config_path = Path(__file__).parent.parent / "configs" / "tolerance.toml"
        if config_path.exists():
            tol = Tolerance.from_toml(str(config_path))
            assert tol.default.atol > 0
            assert tol.get("matmul").atol > tol.default.atol
```

**Step 2: Run tests**

Run: `uv run pytest tests/test_integration.py -v`
Expected: All PASS (accuracy tests skip if frameworks not installed)

**Step 3: Commit**

```bash
git add tests/test_integration.py
git commit -m "test: add Phase 1 accuracy pipeline integration tests"
```

---

### Task 10: Lint + Format

Run ruff to fix any lint/format issues across all new and modified files.

**Step 1: Run ruff check**

```bash
uvx ruff check src/ tests/ --fix
uvx ruff format src/ tests/
```

**Step 2: Run full test suite**

```bash
uv run pytest tests/ -v
```
Expected: All PASS (framework tests skip if not installed)

**Step 3: Commit if needed**

```bash
git add -u
git commit -m "chore: lint and format Phase 1 code"
```

---

## Acceptance Criteria Summary

1. **TorchBackend** implements all BackendBase methods (import, convert, exec, grad, cache, cuda error)
2. **API Mapping** loads 100 APIs from JSON for both paddle and torch
3. **NumpyComparator** correctly compares arrays with per-API tolerance
4. **AccuracyTester** executes same API on two backends and compares outputs
5. **LogWriter** produces valid JSON Lines with status, diffs, timestamps
6. **CLI** `tensor-spec accuracy` command runs single-case comparison
7. **All tests pass** (framework tests skip gracefully if not installed)
8. **ruff clean** — no lint errors
