# API Reference

::: tensor_spec
    options:
      show_submodules: true
