"""JSON Lines structured log writer."""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from typing import IO

from tensor_spec.tester.base import TestResult


class LogWriter:
    """Append-only JSON Lines log writer.

    Each line: {"ts": "...", "api": "abs", "status": "pass", "duration_ms": 1.5, "pid": 12345, ...}
    """

    def __init__(self, path: str) -> None:
        self._path = path
        self._file: IO[str] = open(path, "a")  # noqa: SIM115

    def write(self, result: TestResult) -> None:
        record: dict = {
            "ts": datetime.now(UTC).isoformat(),
            "api": result.case.api_name,
            "status": result.status.value,
            "duration_ms": round(result.duration_ms, 2),
            "pid": os.getpid(),
        }
        if result.compare_result is not None:
            record["max_abs_diff"] = result.compare_result.max_abs_diff
            record["max_rel_diff"] = result.compare_result.max_rel_diff
            record["mismatched_count"] = result.compare_result.mismatched_count
            record["total_count"] = result.compare_result.total_count
        if result.error is not None:
            record["error"] = result.error
        self._file.write(json.dumps(record) + "\n")
        self._file.flush()

    def close(self) -> None:
        self._file.close()

    def __enter__(self) -> LogWriter:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
