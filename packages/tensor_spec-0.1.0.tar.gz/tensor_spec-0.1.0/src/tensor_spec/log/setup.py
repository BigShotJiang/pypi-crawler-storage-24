"""Loguru configuration for tensor-spec."""

from __future__ import annotations

import sys

from loguru import logger

_configured = False


def setup_logging(*, verbose: bool = False) -> None:
    """Configure loguru for CLI usage. Safe to call multiple times."""
    global _configured
    if _configured:
        return
    _configured = True

    logger.remove()  # remove default stderr handler

    level = "DEBUG" if verbose else "INFO"
    fmt = "<green>{time:HH:mm:ss.SSS}</green> | <level>{level: <7}</level> | <level>{message}</level>"
    logger.add(sys.stderr, format=fmt, level=level, colorize=True)
