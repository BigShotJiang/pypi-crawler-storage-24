"""Tolerance configuration for accuracy comparison."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ToleranceConfig:
    """Tolerance for a single comparison (atol + rtol)."""

    atol: float = 1e-2
    rtol: float = 1e-2


@dataclass(frozen=True, slots=True)
class Tolerance:
    """Per-API tolerance configuration with TOML loading."""

    default: ToleranceConfig = field(default_factory=ToleranceConfig)
    overrides: dict[str, ToleranceConfig] = field(default_factory=dict)

    def get(self, api_name: str) -> ToleranceConfig:
        return self.overrides.get(api_name, self.default)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Tolerance:
        """Build Tolerance from a dict (e.g. parsed TOML section)."""
        default_data = data.get("default", {})
        default = ToleranceConfig(
            atol=default_data.get("atol", 1e-2),
            rtol=default_data.get("rtol", 1e-2),
        )
        overrides = {}
        for api_name, tol_data in data.get("overrides", {}).items():
            overrides[api_name] = ToleranceConfig(
                atol=tol_data.get("atol", default.atol),
                rtol=tol_data.get("rtol", default.rtol),
            )
        return cls(default=default, overrides=overrides)

    @classmethod
    def from_toml(cls, path: str) -> Tolerance:
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)
        return cls.from_dict(data)
