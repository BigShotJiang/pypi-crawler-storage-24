"""CLI entry point for tensor-spec."""

from __future__ import annotations

from typing import Annotated, Any

import typer
from loguru import logger

from tensor_spec.config.parser import parse_case
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.log.setup import setup_logging
from tensor_spec.spec.tensor import TensorSpec
from tensor_spec.ui.console import console, print_result_summary, print_setup_summary

app = typer.Typer(
    name="tensor-spec",
    help="Framework-agnostic deep learning API quality verification tool.",
)


@app.command()
def run(
    backend: Annotated[str, typer.Option(help="Backend to use (e.g., paddle)")],
    case: Annotated[str, typer.Option(help='Case string (e.g., "abs(x=Tensor.float32((100,)))")')],
    seed: Annotated[int, typer.Option(help="Random seed for data generation")] = 42,
) -> None:
    """Run a single test case against a backend."""
    with console.status("[bold cyan]Parsing case..."):
        try:
            case_config = parse_case(case)
        except ValueError as e:
            console.print(f"[red]Parse error:[/] {e}")
            raise typer.Exit(1) from e
    console.print(f"  API: [cyan]{case_config.api_name}[/]")

    with console.status("[bold cyan]Generating test data..."):
        gen = TensorGenerator(seed=seed)
        numpy_inputs: dict[str, Any] = {}
        for key, val in case_config.kwargs.items():
            if isinstance(val, TensorSpec):
                numpy_inputs[key] = gen.generate(val)

    for key, arr in numpy_inputs.items():
        console.print(f"  {key}: shape={arr.shape}, dtype={arr.dtype}")

    backend_impl = _load_backend(backend)
    backend_impl.import_framework()
    console.print(f"Backend: [cyan]{backend_impl.name}[/]")

    tensor_kwargs: dict[str, Any] = {}
    for key, val in case_config.kwargs.items():
        if key in numpy_inputs:
            tensor_kwargs[key] = backend_impl.numpy_to_tensor(numpy_inputs[key], case_config.kwargs[key])
        else:
            tensor_kwargs[key] = val

    tensor_args_list: list[Any] = []
    for val in case_config.args:
        if isinstance(val, TensorSpec):
            np_data = gen.generate(val)
            tensor_args_list.append(backend_impl.numpy_to_tensor(np_data, val))
        elif isinstance(val, tuple) and any(isinstance(v, TensorSpec) for v in val):
            converted = []
            for v in val:
                if isinstance(v, TensorSpec):
                    np_data = gen.generate(v)
                    converted.append(backend_impl.numpy_to_tensor(np_data, v))
                else:
                    converted.append(v)
            tensor_args_list.append(tuple(converted))
        else:
            tensor_args_list.append(val)

    with console.status(f"[bold cyan]Executing {case_config.api_name}..."):
        try:
            result = backend_impl.exec_api(case_config.api_name, tuple(tensor_args_list), tensor_kwargs)
            result_np = backend_impl.tensor_to_numpy(result)
        except Exception as e:
            console.print(f"[bold red]FAILED:[/] {e}")
            raise typer.Exit(1) from e

    console.print(f"  Result type: {type(result).__name__}")
    console.print(f"  Result shape: {result_np.shape}, dtype: {result_np.dtype}")
    console.print("[bold green]PASSED[/]")


@app.command()
def validate(
    case: Annotated[str, typer.Option(help="Case string to validate")],
) -> None:
    """Validate a case string without executing it."""
    try:
        case_config = parse_case(case)
        console.print(
            f"[bold green]Valid:[/] api={case_config.api_name}, "
            f"args={len(case_config.args)}, kwargs={list(case_config.kwargs.keys())}"
        )
    except ValueError as e:
        console.print(f"[bold red]Invalid:[/] {e}")
        raise typer.Exit(1) from e


_VENV_BASE = ".tensor_spec/venvs"


@app.command()
def setup(
    backend: Annotated[
        list[str] | None,
        typer.Option(help="Backend to set up (repeatable, or omit for all)"),
    ] = None,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Set up framework virtual environments.

    Creates isolated venvs under .tensor_spec/venvs/ and installs the
    specified frameworks. Reads source configuration from tensor-spec.toml.

    \b
    Examples:
      tensor-spec setup                           # set up all configured backends
      tensor-spec setup --backend paddle           # set up paddle only
      tensor-spec setup --config my-config.toml    # use custom config file
    """
    from tensor_spec.config.project import ProjectConfig
    from tensor_spec.setup_cmd import run_setup

    config = ProjectConfig.from_toml(config_file) if config_file else ProjectConfig.find_and_load() or ProjectConfig()

    results = run_setup(backends=backend, config=config)
    print_setup_summary(results)

    if any(r["status"] != "ok" for r in results):
        raise typer.Exit(1)


@app.command()
def check(
    backend: Annotated[
        list[str] | None,
        typer.Option(help="Backend to test (repeatable, 1=check-only, 2+=accuracy comparison)"),
    ] = None,
    case: Annotated[
        list[str] | None,
        typer.Option(help="Case string (repeatable)"),
    ] = None,
    case_file: Annotated[
        str | None,
        typer.Option(help="File with one case per line"),
    ] = None,
    seed: Annotated[int | None, typer.Option(help="Random seed")] = None,
    tolerance_config: Annotated[str | None, typer.Option(help="Path to tolerance TOML")] = None,
    log_file: Annotated[str | None, typer.Option(help="Path to JSON Lines log file")] = None,
    python: Annotated[
        list[str] | None,
        typer.Option(help="Python interpreter (repeatable, 1:1 with --backend)"),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug logs")] = False,
    config_file: Annotated[
        str | None,
        typer.Option("--config", help="Path to tensor-spec.toml"),
    ] = None,
) -> None:
    """Run single-backend execution check or cross-framework accuracy comparison.

    With 1 backend: checks that execution succeeds (no crash/error).
    With 2+ backends: compares all against the first for accuracy.

    \b
    Examples:
      tensor-spec check --backend paddle --case 'abs(x=Tensor.float32((100,)))'
      tensor-spec check --backend paddle --backend torch --case 'abs(x=Tensor.float32((100,)))'
      tensor-spec check --backend paddle --backend torch --backend jax --case-file cases.txt
    """
    from pathlib import Path

    from rich.progress import Progress

    from tensor_spec.compare.comparator import NumpyComparator
    from tensor_spec.compare.tolerance import Tolerance
    from tensor_spec.config.project import ProjectConfig
    from tensor_spec.log.writer import LogWriter
    from tensor_spec.mapping.registry import MappingRegistry
    from tensor_spec.tester.base import TestResult, TestStatus

    # --- Load project config, CLI params override ---
    if config_file:
        project_config = ProjectConfig.from_toml(config_file)
    else:
        project_config = ProjectConfig.find_and_load() or ProjectConfig()

    cfg_defaults = project_config.defaults

    # --- Resolve backends ---
    effective_backends: list[str] = []
    if backend:
        effective_backends = list(backend)
    elif cfg_defaults.backends:
        effective_backends = list(cfg_defaults.backends)
    elif cfg_defaults.backend_a and cfg_defaults.backend_b:
        # Legacy fallback
        effective_backends = [cfg_defaults.backend_a, cfg_defaults.backend_b]

    if not effective_backends:
        logger.error("Must specify at least one --backend (or set in tensor-spec.toml [defaults])")
        raise typer.Exit(1)

    effective_seed = seed if seed is not None else cfg_defaults.seed
    effective_verbose = verbose or cfg_defaults.verbose

    setup_logging(verbose=effective_verbose)

    # --- Collect case strings ---
    case_strings: list[str] = []
    if case:
        case_strings.extend(case)
    if case_file:
        cf = Path(case_file)
        if not cf.exists():
            logger.error("Case file not found: {}", case_file)
            raise typer.Exit(1)
        for line in cf.read_text().splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                case_strings.append(stripped)
    if not case_strings:
        logger.error("No cases provided. Use --case or --case-file.")
        raise typer.Exit(1)

    # --- Parse all cases upfront ---
    cases = []
    for cs in case_strings:
        try:
            cases.append(parse_case(cs))
        except ValueError as e:
            logger.error("Parse error in '{}': {}", cs, e)
            raise typer.Exit(1) from e
    logger.info("{} case(s) to run", len(cases))

    # --- Resolve python paths ---
    effective_pythons: list[str] = []
    if python:
        effective_pythons = list(python)
    elif cfg_defaults.pythons:
        effective_pythons = list(cfg_defaults.pythons)
    elif cfg_defaults.python_a and cfg_defaults.python_b:
        # Legacy fallback
        effective_pythons = [cfg_defaults.python_a, cfg_defaults.python_b]

    # Fill missing python paths with venv defaults
    while len(effective_pythons) < len(effective_backends):
        b = effective_backends[len(effective_pythons)]
        effective_pythons.append(f"{_VENV_BASE}/{b}/bin/python")

    for i, py_path in enumerate(effective_pythons):
        if not Path(py_path).exists():
            logger.error("Python not found at {} (for backend '{}')", py_path, effective_backends[i])
            logger.error("Run 'tensor-spec setup' to create framework venvs.")
            raise typer.Exit(1)

    # --- Tolerance: CLI --tolerance-config > config file [tolerance] > default ---
    if tolerance_config:
        tol = Tolerance.from_toml(tolerance_config)
    elif project_config.tolerance_data:
        tol = Tolerance.from_dict(project_config.tolerance_data)
    else:
        tol = Tolerance()

    # --- Load mappings for all backends ---
    mapping = MappingRegistry()
    for b in effective_backends:
        mapping.load_bundled(b)

    # --- Create tester ---
    if len(effective_backends) == 1:
        from tensor_spec.tester.check import IsolatedCheckTester

        with console.status("[bold cyan]Starting worker..."):
            tester = IsolatedCheckTester(
                python_path=effective_pythons[0],
                backend_name=effective_backends[0],
                mapping=mapping,
                generator=TensorGenerator(seed=effective_seed),
            )
    else:
        from tensor_spec.tester.isolated_accuracy import IsolatedAccuracyTester

        with console.status("[bold cyan]Starting workers..."):
            worker_specs = [
                (effective_backends[i], effective_pythons[i], effective_backends[i])
                for i in range(len(effective_backends))
            ]
            tester = IsolatedAccuracyTester(
                backends=worker_specs,
                mapping=mapping,
                comparator=NumpyComparator(),
                tolerance=tol,
                generator=TensorGenerator(seed=effective_seed),
            )

    passed = 0
    failed = 0
    results: list[TestResult] = []
    try:
        writer = LogWriter(log_file) if log_file else None
        try:
            use_progress = len(cases) > 1
            if use_progress:
                with Progress(console=console) as progress:
                    task = progress.add_task("Running cases...", total=len(cases))
                    for case_config in cases:
                        result = tester.test(case_config)
                        results.append(result)
                        if writer:
                            writer.write(result)
                        if result.status == TestStatus.PASSED:
                            passed += 1
                        else:
                            failed += 1
                        progress.advance(task)
            else:
                with console.status("[bold cyan]Running test case..."):
                    for case_config in cases:
                        result = tester.test(case_config)
                        results.append(result)
                        if writer:
                            writer.write(result)
                        if result.status == TestStatus.PASSED:
                            passed += 1
                        else:
                            failed += 1
                            if result.error:
                                logger.error("  error: {}", result.error)
        finally:
            if writer:
                writer.close()
    finally:
        tester.shutdown()

    # --- Summary ---
    print_result_summary(results)

    if log_file:
        logger.info("Log written to {}", log_file)

    if failed > 0:
        raise typer.Exit(1)


def _load_backend(name: str) -> Any:
    """Load a backend by name."""
    if name == "paddle":
        from tensor_spec.backend.paddle_backend import PaddleBackend

        return PaddleBackend()
    if name == "torch":
        from tensor_spec.backend.torch_backend import TorchBackend

        return TorchBackend()
    raise ValueError(f"Unknown backend: {name}. Available: paddle, torch")
