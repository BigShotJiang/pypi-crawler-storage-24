"""IsolatedCheckTester: single-backend execution check (no comparison)."""

from __future__ import annotations

import time
from typing import Any

from loguru import logger

from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.spec.tensor import TensorSpec
from tensor_spec.tester.base import GeneratedInputs, TesterBase, TestResult, TestStatus
from tensor_spec.worker.coordinator import Coordinator


class IsolatedCheckTester(TesterBase):
    """Single-backend tester: just execute, no comparison."""

    def __init__(
        self,
        python_path: str,
        backend_name: str,
        mapping: MappingRegistry,
        generator: TensorGenerator,
    ) -> None:
        super().__init__(generator)
        self._backend_name = backend_name
        self._mapping = mapping
        self._coordinator = Coordinator()
        self._coordinator.start_workers_parallel(
            [("worker", python_path, backend_name)]
        )

    def shutdown(self) -> None:
        """Shutdown worker processes."""
        self._coordinator.shutdown_all()

    def test(self, case: CaseConfig) -> TestResult:
        """Override template to handle subprocess errors."""
        logger.info("Checking {} on {} ...", case.api_name, self._backend_name)
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "{} -> {} ({:.0f}ms)",
                case.api_name,
                result.status.value,
                result.duration_ms,
            )
            return result
        except _WorkerBackendError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.warning("{} -> backend_error : {}", case.api_name, e.message)
            return TestResult(
                case=case,
                status=TestStatus.BACKEND_ERROR,
                error=f"[{e.backend_name}] {e.message}",
                duration_ms=dur,
            )
        except MemoryError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> OOM: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=dur,
            )
        except Exception as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> error: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=dur,
            )

    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute API on single worker and return numpy output."""
        np_result = self._execute_on_worker(case, inputs)
        return {"result_numpy": np_result}

    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """No comparison needed — execution success means PASSED."""
        return TestResult(case=case, status=TestStatus.PASSED)

    def _execute_on_worker(
        self,
        case: CaseConfig,
        inputs: GeneratedInputs,
    ) -> Any:
        """Send data to worker, execute API, retrieve numpy result."""
        coord = self._coordinator
        worker_name = "worker"
        mapping = self._mapping.resolve(case.api_name, self._backend_name)

        # Send tensor args
        arg_refs: list[Any] = []
        for i, val in enumerate(case.args):
            if isinstance(val, TensorSpec) and inputs.arg_arrays[i] is not None:
                tid = coord.send_numpy(worker_name, inputs.arg_arrays[i])
                arg_refs.append(tid)
            elif isinstance(val, tuple):
                items = []
                for v in val:
                    if isinstance(v, TensorSpec):
                        np_data = self._generator.generate(v)
                        items.append(coord.send_numpy(worker_name, np_data))
                    else:
                        items.append(v)
                arg_refs.append(tuple(items))
            else:
                arg_refs.append(val)

        # Send tensor kwargs (with name remapping)
        kwarg_refs: dict[str, Any] = {}
        for key, val in case.kwargs.items():
            mapped_key = mapping.args_map.get(key, key)
            if isinstance(val, TensorSpec) and key in inputs.kwarg_arrays:
                tid = coord.send_numpy(worker_name, inputs.kwarg_arrays[key])
                kwarg_refs[mapped_key] = tid
            else:
                kwarg_refs[mapped_key] = val

        # Execute
        try:
            result_tid = coord.exec_api(
                worker_name,
                mapping.api,
                list(arg_refs),
                kwarg_refs,
            )
        except RuntimeError as e:
            raise _WorkerBackendError(self._backend_name, str(e)) from e

        # Get result numpy
        coord.check_cuda_error(worker_name)
        return coord.get_numpy(worker_name, result_tid)


class _WorkerBackendError(Exception):
    """Internal: raised when a worker's exec_api fails."""

    def __init__(self, backend_name: str, message: str) -> None:
        self.backend_name = backend_name
        self.message = message
        super().__init__(f"{backend_name}: {message}")
