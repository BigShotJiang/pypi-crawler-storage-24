"""JSON-over-pipe message protocol for worker communication."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Request:
    """A message from the coordinator to a worker."""

    id: int
    type: str
    payload: dict[str, Any]


@dataclass(frozen=True, slots=True)
class Response:
    """A message from a worker back to the coordinator."""

    id: int
    ok: bool
    result: Any = None
    error: str | None = None


def encode_request(req: Request) -> str:
    """Serialize a Request to a single JSON line."""
    return json.dumps({"id": req.id, "type": req.type, "payload": req.payload})


def decode_request(line: str) -> Request:
    """Deserialize a JSON line into a Request."""
    d = json.loads(line)
    return Request(id=d["id"], type=d["type"], payload=d.get("payload", {}))


def encode_response(resp: Response) -> str:
    """Serialize a Response to a single JSON line."""
    d: dict[str, Any] = {"id": resp.id, "ok": resp.ok}
    if resp.result is not None:
        d["result"] = resp.result
    if resp.error is not None:
        d["error"] = resp.error
    return json.dumps(d)


def decode_response(line: str) -> Response:
    """Deserialize a JSON line into a Response."""
    d = json.loads(line)
    return Response(
        id=d["id"],
        ok=d["ok"],
        result=d.get("result"),
        error=d.get("error"),
    )


def encode_arg_value(val: Any) -> Any:
    """Encode an argument value for JSON transport.

    Scalars (int, float, bool, None, str) pass through.
    Dicts with "_ref" key are tensor references --- pass through.
    Tuples/lists are wrapped with a type tag so we can restore them.
    """
    if isinstance(val, dict):
        return val
    if isinstance(val, tuple):
        return {"_t": "tuple", "items": [encode_arg_value(v) for v in val]}
    if isinstance(val, list):
        return {"_t": "list", "items": [encode_arg_value(v) for v in val]}
    return val  # scalar


def decode_arg_value(val: Any, tensors: dict[str, Any]) -> Any:
    """Decode an argument value, resolving tensor references.

    Args:
        val: Encoded value from JSON.
        tensors: Map of tensor_id -> framework tensor.
    """
    if isinstance(val, dict):
        if "_ref" in val:
            return tensors[val["_ref"]]
        if "_t" in val:
            items = [decode_arg_value(v, tensors) for v in val["items"]]
            if val["_t"] == "tuple":
                return tuple(items)
            return items  # list
        return val
    return val  # scalar
