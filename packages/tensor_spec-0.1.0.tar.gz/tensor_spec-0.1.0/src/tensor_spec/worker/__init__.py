"""Worker process layer for framework-isolated execution."""
