"""Entry point for ``python -m tensor_spec.worker.process``."""

from tensor_spec.worker.process import main

main()
