"""SharedMemory-based numpy array transport for CPU tensors."""

from __future__ import annotations

import contextlib
from dataclasses import dataclass
from multiprocessing import resource_tracker as _rt
from multiprocessing.shared_memory import SharedMemory

import numpy as np


def _unregister_from_resource_tracker(name: str) -> None:
    """Remove a SharedMemory segment from the current process's resource tracker.

    This prevents the tracker from emitting 'leaked shared_memory' warnings
    when the segment's lifecycle is managed externally (e.g., by Coordinator).
    """
    with contextlib.suppress(KeyError):
        _rt.unregister(f"/{name}" if not name.startswith("/") else name, "shared_memory")


@dataclass(frozen=True, slots=True)
class ShmBuffer:
    """Metadata describing a numpy array stored in SharedMemory."""

    name: str
    shape: tuple[int, ...]
    dtype: str
    nbytes: int

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict."""
        return {
            "name": self.name,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "nbytes": self.nbytes,
        }

    @classmethod
    def from_dict(cls, d: dict) -> ShmBuffer:
        """Deserialize from a dict."""
        return cls(
            name=d["name"],
            shape=tuple(d["shape"]),
            dtype=d["dtype"],
            nbytes=d["nbytes"],
        )


def write_array(arr: np.ndarray, *, untrack: bool = False) -> ShmBuffer:
    """Write a numpy array to a new SharedMemory block.

    The caller is responsible for calling unlink() after the consumer has read.

    Args:
        arr: The array to write.
        untrack: If True, unregister from this process's resource tracker.
            Use when the segment's lifecycle is managed by another process.
    """
    sm = SharedMemory(create=True, size=max(arr.nbytes, 1))
    shared = np.ndarray(arr.shape, dtype=arr.dtype, buffer=sm.buf)
    np.copyto(shared, arr)
    buf = ShmBuffer(
        name=sm.name,
        shape=arr.shape,
        dtype=str(arr.dtype),
        nbytes=arr.nbytes,
    )
    sm.close()
    if untrack:
        _unregister_from_resource_tracker(sm.name)
    return buf


def read_array(buf: ShmBuffer) -> np.ndarray:
    """Read a numpy array from SharedMemory, returning an owned copy.

    Does NOT unlink --- caller must do that.
    """
    sm = SharedMemory(name=buf.name)
    arr = np.ndarray(buf.shape, dtype=np.dtype(buf.dtype), buffer=sm.buf).copy()
    sm.close()
    # Lifecycle is managed by the creator (Coordinator), not this reader.
    _unregister_from_resource_tracker(buf.name)
    return arr


def unlink(name: str) -> None:
    """Unlink (destroy) a SharedMemory block by name."""
    sm = SharedMemory(name=name)
    sm.close()
    sm.unlink()
