"""GpuArrayView: exposes a GPU pointer via __cuda_array_interface__.

This allows paddle.to_tensor(view) and torch.as_tensor(view, device='cuda')
to create framework tensors from a raw GPU pointer with zero copy.
"""

from __future__ import annotations

DTYPE_TO_TYPESTR: dict[str, str] = {
    "float16": "<f2",
    "float32": "<f4",
    "float64": "<f8",
    "bfloat16": "<V2",
    "int8": "<i1",
    "int16": "<i2",
    "int32": "<i4",
    "int64": "<i8",
    "uint8": "<u1",
    "bool": "|b1",
    "complex64": "<c8",
    "complex128": "<c16",
}


class GpuArrayView:
    """Wraps a GPU device pointer as a __cuda_array_interface__ object.

    Usage::

        view = GpuArrayView(ptr=device_ptr, shape=(32, 3, 224, 224), dtype="float32")
        torch_tensor = torch.as_tensor(view, device='cuda')
        paddle_tensor = paddle.to_tensor(view)
    """

    __slots__ = ("__cuda_array_interface__",)

    def __init__(self, ptr: int, shape: tuple[int, ...], dtype: str) -> None:
        typestr = DTYPE_TO_TYPESTR.get(dtype)
        if typestr is None:
            msg = f"Unsupported dtype: {dtype}"
            raise ValueError(msg)
        self.__cuda_array_interface__ = {
            "shape": shape,
            "typestr": typestr,
            "data": (ptr, False),
            "version": 2,
        }
