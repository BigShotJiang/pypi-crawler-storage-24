"""Implementation of the `tensor-spec setup` command."""

from __future__ import annotations

import subprocess
from pathlib import Path

from loguru import logger

from tensor_spec.config.project import ProjectConfig, SourceConfig
from tensor_spec.ui.console import console

_VENV_BASE = Path(".tensor_spec/venvs")


def setup_backend(
    backend: str,
    *,
    index_url: str = "",
    extra_index_url: str = "https://pypi.org/simple/",
    package: str = "",
    version: str = "",
    whl: str = "",
    python_version: str = "3.10",
) -> dict[str, str]:
    """Create a venv for *backend*, install the framework, and verify import.

    Returns a dict with keys: backend, status, detail.
    """
    venv_dir = _VENV_BASE / backend
    python_path = venv_dir / "bin" / "python"
    result: dict[str, str] = {"backend": backend}

    # --- create venv ---
    with console.status(f"[bold cyan]Creating venv for {backend}..."):
        proc = subprocess.run(
            ["uv", "venv", str(venv_dir), "--python", python_version],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            result.update(status="failed", detail=f"venv creation failed: {proc.stderr.strip()}")
            return result

    # --- install package ---
    install_cmd: list[str] = ["uv", "pip", "install", "--python", str(python_path)]

    if whl:
        install_cmd.append(whl)
    else:
        pkg = package or backend
        if version:
            pkg = f"{pkg}=={version}"
        install_cmd.append(pkg)
        if index_url:
            install_cmd.extend(["--index-url", index_url])
        if extra_index_url:
            install_cmd.extend(["--extra-index-url", extra_index_url])

    with console.status(f"[bold cyan]Installing {backend}..."):
        proc = subprocess.run(install_cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            result.update(status="failed", detail=f"install failed: {proc.stderr.strip()}")
            return result

    # paddle needs setuptools
    if backend == "paddle":
        with console.status("[bold cyan]Installing setuptools for paddle..."):
            subprocess.run(
                ["uv", "pip", "install", "--python", str(python_path), "setuptools"],
                capture_output=True,
                text=True,
            )

    # --- verify import ---
    import_name = "paddle" if backend == "paddle" else backend
    with console.status(f"[bold cyan]Verifying {backend} import..."):
        proc = subprocess.run(
            [str(python_path), "-c", f"import {import_name}; print({import_name}.__version__)"],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            result.update(status="failed", detail=f"import verification failed: {proc.stderr.strip()}")
            return result

    version_str = proc.stdout.strip()
    result.update(status="ok", detail=f"v{version_str}")
    return result


def run_setup(
    backends: list[str] | None = None,
    config: ProjectConfig | None = None,
) -> list[dict[str, str]]:
    """Set up one or more backends. Returns list of result dicts."""
    if config is None:
        config = ProjectConfig.find_and_load() or ProjectConfig()

    if not backends:
        backends = ["paddle", "torch"]

    results: list[dict[str, str]] = []
    for backend in backends:
        src: SourceConfig = config.get_source(backend)
        index_url = config.resolve_index_url(backend)
        logger.info("Setting up backend: {}", backend)
        r = setup_backend(
            backend,
            index_url=index_url,
            extra_index_url=src.extra_index_url,
            package=src.package,
            version=src.version,
            whl=src.whl,
            python_version=src.python_version,
        )
        results.append(r)
        if r["status"] == "ok":
            logger.info("  {} installed successfully ({})", backend, r["detail"])
        else:
            logger.error("  {} failed: {}", backend, r["detail"])

    return results
