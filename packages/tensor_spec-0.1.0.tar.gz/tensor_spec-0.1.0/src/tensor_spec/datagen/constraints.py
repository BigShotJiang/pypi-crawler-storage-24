"""Constraint implementations for tensor data generation."""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class Constraint(ABC):
    """Base class for data constraints applied post-generation."""

    @abstractmethod
    def apply(self, data: np.ndarray) -> np.ndarray: ...


class NonZeroConstraint(Constraint):
    """Replace zeros with small non-zero values."""

    def apply(self, data: np.ndarray) -> np.ndarray:
        if np.issubdtype(data.dtype, np.floating):
            data = data.copy()
            data[data == 0] = np.finfo(data.dtype).tiny
        elif np.issubdtype(data.dtype, np.integer):
            data = data.copy()
            data[data == 0] = 1
        return data


class PositiveDefiniteConstraint(Constraint):
    """Make the matrix positive definite via A @ A^T + I."""

    def apply(self, data: np.ndarray) -> np.ndarray:
        n = data.shape[-1]
        original_shape = data.shape
        data = data.reshape(-1, n, n)
        data = data @ np.swapaxes(data, -1, -2) + np.eye(n, dtype=data.dtype)
        return data.reshape(original_shape)
