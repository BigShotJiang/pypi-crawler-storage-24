"""tensor-spec: Framework-agnostic deep learning API quality verification tool."""
