"""Statistical constraints for tensor data generation."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class FloatStats:
    """Statistical constraints for float tensors."""

    min: float = -0.5
    max: float = 0.5
    nonzero: bool = False
    positive: bool = False
    positive_definite: bool = False
    symmetric: bool = False
    normalized: bool = False
    unique: bool = False
    has_nan: bool = False
    has_inf: bool = False

    def __post_init__(self) -> None:
        if self.min >= self.max:
            raise ValueError(f"min({self.min}) must be < max({self.max})")


@dataclass(frozen=True, slots=True)
class IntStats:
    """Statistical constraints for integer tensors."""

    low: int = -65535
    high: int = 65535
    nonzero: bool = False
    unique: bool = False
    sorted: bool = False

    def __post_init__(self) -> None:
        if self.low >= self.high:
            raise ValueError(f"low({self.low}) must be < high({self.high})")


@dataclass(frozen=True, slots=True)
class BoolStats:
    """Statistical constraints for boolean tensors."""

    true_ratio: float = 0.5
    all_true: bool = False
    all_false: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.true_ratio <= 1.0:
            raise ValueError(f"true_ratio must be in [0, 1], got {self.true_ratio}")


@dataclass(frozen=True, slots=True)
class ComplexStats:
    """Statistical constraints for complex tensors."""

    real_min: float = -0.5
    real_max: float = 0.5
    imag_min: float = -0.5
    imag_max: float = 0.5
    hermitian: bool = False

    def __post_init__(self) -> None:
        if self.real_min >= self.real_max:
            raise ValueError(f"real_min({self.real_min}) must be < real_max({self.real_max})")
        if self.imag_min >= self.imag_max:
            raise ValueError(f"imag_min({self.imag_min}) must be < imag_max({self.imag_max})")
