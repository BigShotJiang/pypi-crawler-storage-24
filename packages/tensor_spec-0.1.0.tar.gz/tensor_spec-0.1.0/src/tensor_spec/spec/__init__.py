"""Tensor specification layer — zero framework dependencies."""
