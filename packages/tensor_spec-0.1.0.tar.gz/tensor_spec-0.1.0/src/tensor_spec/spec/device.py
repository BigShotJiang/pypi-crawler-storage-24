"""Device specification, aligned with DLPack DLDeviceType convention."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class DeviceType(IntEnum):
    """Device types, integer values match DLPack's DLDeviceType.

    See: https://github.com/dmlc/dlpack/blob/main/include/dlpack/dlpack.h
    """

    CPU = 1
    CUDA = 2
    CUDA_HOST = 3
    ROCM = 10
    ROCM_HOST = 11
    ONEAPI = 14
    VULKAN = 7
    METAL = 8
    # kDLExtDev = 12 — reserved for extension devices, not exposed here


@dataclass(frozen=True, slots=True)
class DeviceSpec:
    """Specification for a device, modeled after DLPack's DLDevice.

    Fields use DLPack naming: device_type + device_id.
    """

    device_type: DeviceType
    device_id: int = 0

    def __str__(self) -> str:
        name = self.device_type.name.lower()
        if self.device_type == DeviceType.CPU:
            return name
        return f"{name}:{self.device_id}"

    @property
    def dlpack_device(self) -> tuple[int, int]:
        """Return (device_type, device_id) as expected by __dlpack_device__()."""
        return (int(self.device_type), self.device_id)


class Device:
    """Namespace class with factory methods for creating DeviceSpec.

    Method names match DLPack DLDeviceType names (lowercased).
    """

    @staticmethod
    def cpu() -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.CPU, device_id=0)

    @staticmethod
    def cuda(device_id: int = 0) -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.CUDA, device_id=device_id)

    @staticmethod
    def rocm(device_id: int = 0) -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.ROCM, device_id=device_id)

    @staticmethod
    def oneapi(device_id: int = 0) -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.ONEAPI, device_id=device_id)

    @staticmethod
    def vulkan(device_id: int = 0) -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.VULKAN, device_id=device_id)

    @staticmethod
    def metal(device_id: int = 0) -> DeviceSpec:
        return DeviceSpec(device_type=DeviceType.METAL, device_id=device_id)
