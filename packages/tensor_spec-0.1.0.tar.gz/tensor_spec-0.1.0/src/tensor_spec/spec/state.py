"""Tensor state specification (grad, contiguity, etc.)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TensorState:
    """State of a tensor (gradient requirements, memory layout, etc.)."""

    need_grad: bool | None = None
    is_contiguous: bool = True
    stop_gradient: bool | None = None
