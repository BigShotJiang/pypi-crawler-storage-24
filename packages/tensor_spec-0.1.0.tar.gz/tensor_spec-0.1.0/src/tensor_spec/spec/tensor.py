"""Tensor specifications and the Tensor factory class."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tensor_spec.spec.device import DeviceSpec
    from tensor_spec.spec.state import TensorState
    from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats


@dataclass(frozen=True, slots=True)
class TensorSpec:
    """Base class for all tensor specifications."""

    shape: tuple[int, ...]
    dtype: str
    device: DeviceSpec | None = None
    state: TensorState | None = None


@dataclass(frozen=True, slots=True)
class FloatTensorSpec(TensorSpec):
    """Specification for float tensors (float16, float32, float64, bfloat16)."""

    stats: FloatStats | None = None

    def with_stats(self, stats: FloatStats) -> FloatTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> FloatTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class IntTensorSpec(TensorSpec):
    """Specification for integer tensors (int8-64, uint8)."""

    stats: IntStats | None = None

    def with_stats(self, stats: IntStats) -> IntTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> IntTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class BoolTensorSpec(TensorSpec):
    """Specification for boolean tensors."""

    stats: BoolStats | None = None

    def with_stats(self, stats: BoolStats) -> BoolTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> BoolTensorSpec:
        return replace(self, state=state)


@dataclass(frozen=True, slots=True)
class ComplexTensorSpec(TensorSpec):
    """Specification for complex tensors (complex64, complex128)."""

    stats: ComplexStats | None = None

    def with_stats(self, stats: ComplexStats) -> ComplexTensorSpec:
        return replace(self, stats=stats)

    def with_state(self, state: TensorState) -> ComplexTensorSpec:
        return replace(self, state=state)


_DTYPE_MAP: dict[str, type[TensorSpec]] = {
    "float16": FloatTensorSpec,
    "float32": FloatTensorSpec,
    "float64": FloatTensorSpec,
    "bfloat16": FloatTensorSpec,
    "int8": IntTensorSpec,
    "int16": IntTensorSpec,
    "int32": IntTensorSpec,
    "int64": IntTensorSpec,
    "uint8": IntTensorSpec,
    "bool": BoolTensorSpec,
    "complex64": ComplexTensorSpec,
    "complex128": ComplexTensorSpec,
}


class Tensor:
    """Namespace class with factory methods for creating TensorSpec instances.

    Usage: Tensor.float32((2, 3)) -> FloatTensorSpec
    """

    @classmethod
    def _make(cls, dtype: str, shape: tuple[int, ...], device: DeviceSpec | None = None) -> TensorSpec:
        spec_cls = _DTYPE_MAP.get(dtype)
        if spec_cls is None:
            raise ValueError(f"Unsupported dtype: {dtype}")
        return spec_cls(shape=shape, dtype=dtype, device=device)

    # Float family
    @classmethod
    def float16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float16", device=device)

    @classmethod
    def float32(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float32", device=device)

    @classmethod
    def float64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="float64", device=device)

    @classmethod
    def bfloat16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> FloatTensorSpec:
        return FloatTensorSpec(shape=shape, dtype="bfloat16", device=device)

    # Int family
    @classmethod
    def int8(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int8", device=device)

    @classmethod
    def int16(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int16", device=device)

    @classmethod
    def int32(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int32", device=device)

    @classmethod
    def int64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="int64", device=device)

    @classmethod
    def uint8(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> IntTensorSpec:
        return IntTensorSpec(shape=shape, dtype="uint8", device=device)

    # Bool
    @classmethod
    def bool(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> BoolTensorSpec:
        return BoolTensorSpec(shape=shape, dtype="bool", device=device)

    # Complex family
    @classmethod
    def complex64(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> ComplexTensorSpec:
        return ComplexTensorSpec(shape=shape, dtype="complex64", device=device)

    @classmethod
    def complex128(cls, shape: tuple[int, ...], device: DeviceSpec | None = None) -> ComplexTensorSpec:
        return ComplexTensorSpec(shape=shape, dtype="complex128", device=device)
