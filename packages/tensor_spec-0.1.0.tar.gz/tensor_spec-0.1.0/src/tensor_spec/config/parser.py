"""Whitelist recursive descent parser for case strings.

Parses case strings like:
    abs(x=Tensor.float64((1, 100)))
    nn.conv2d(x=Tensor.float32((1, 3, 224, 224)), stride=2, padding=3)

No eval() is used. Only whitelisted constructors are allowed.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any

from tensor_spec.config.case import CaseConfig
from tensor_spec.spec.device import Device, DeviceSpec
from tensor_spec.spec.state import TensorState
from tensor_spec.spec.stats import BoolStats, ComplexStats, FloatStats, IntStats
from tensor_spec.spec.tensor import (
    BoolTensorSpec,
    ComplexTensorSpec,
    FloatTensorSpec,
    IntTensorSpec,
    Tensor,
    TensorSpec,
)


class TokenType(Enum):
    IDENT = auto()
    INT = auto()
    FLOAT = auto()
    STRING = auto()
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    DOT = auto()
    EQUALS = auto()
    EOF = auto()


@dataclass(slots=True)
class Token:
    type: TokenType
    value: str
    pos: int


_KEYWORDS = {"True": True, "False": False, "None": None}


def _tokenize(s: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    while i < len(s):
        c = s[i]
        if c in " \t\n\r":
            i += 1
            continue
        if c == "(":
            tokens.append(Token(TokenType.LPAREN, "(", i))
            i += 1
        elif c == ")":
            tokens.append(Token(TokenType.RPAREN, ")", i))
            i += 1
        elif c == "[":
            tokens.append(Token(TokenType.LBRACKET, "[", i))
            i += 1
        elif c == "]":
            tokens.append(Token(TokenType.RBRACKET, "]", i))
            i += 1
        elif c == ",":
            tokens.append(Token(TokenType.COMMA, ",", i))
            i += 1
        elif c == ".":
            tokens.append(Token(TokenType.DOT, ".", i))
            i += 1
        elif c == "=":
            tokens.append(Token(TokenType.EQUALS, "=", i))
            i += 1
        elif c in ('"', "'"):
            quote = c
            j = i + 1
            while j < len(s) and s[j] != quote:
                if s[j] == "\\":
                    j += 1
                j += 1
            if j >= len(s):
                raise ValueError(f"Unterminated string at position {i}")
            tokens.append(Token(TokenType.STRING, s[i + 1 : j], i))
            i = j + 1
        elif c.isdigit() or (c == "-" and i + 1 < len(s) and (s[i + 1].isdigit() or s[i + 1] == ".")):
            m = re.match(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", s[i:])
            if m:
                val = m.group()
                if "." in val or "e" in val or "E" in val:
                    tokens.append(Token(TokenType.FLOAT, val, i))
                else:
                    tokens.append(Token(TokenType.INT, val, i))
                i += len(val)
            else:
                raise ValueError(f"Invalid number at position {i}")
        elif c.isalpha() or c == "_":
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            word = s[i:j]
            tokens.append(Token(TokenType.IDENT, word, i))
            i = j
        else:
            raise ValueError(f"Unexpected character '{c}' at position {i}")
    tokens.append(Token(TokenType.EOF, "", len(s)))
    return tokens


class _Parser:
    """Recursive descent parser for case strings."""

    def __init__(self, tokens: list[Token]) -> None:
        self._tokens = tokens
        self._pos = 0

    def _peek(self) -> Token:
        return self._tokens[self._pos]

    def _advance(self) -> Token:
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def _expect(self, tt: TokenType) -> Token:
        tok = self._advance()
        if tok.type != tt:
            raise ValueError(f"Expected {tt.name}, got {tok.type.name} ('{tok.value}') at pos {tok.pos}")
        return tok

    def _at(self, tt: TokenType) -> bool:
        return self._peek().type == tt

    def parse_case(self) -> CaseConfig:
        """Parse top-level: api_name(args...)"""
        api_name = self._parse_dotted_name()
        self._expect(TokenType.LPAREN)
        args, kwargs = self._parse_arg_list()
        self._expect(TokenType.RPAREN)
        return CaseConfig(api_name=api_name, args=tuple(args), kwargs=kwargs)

    def _parse_dotted_name(self) -> str:
        """Parse 'ident' or 'ident.ident.ident' for API names."""
        name = self._expect(TokenType.IDENT).value
        while self._at(TokenType.DOT) and self._pos + 1 < len(self._tokens):
            next_tok = self._tokens[self._pos + 1]
            if next_tok.type == TokenType.IDENT:
                self._advance()  # consume DOT
                name += "." + self._advance().value
            else:
                break
        return name

    def _parse_arg_list(self) -> tuple[list[Any], dict[str, Any]]:
        """Parse comma-separated args. Returns (positional, keyword)."""
        args: list[Any] = []
        kwargs: dict[str, Any] = {}

        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            if (
                self._at(TokenType.IDENT)
                and self._pos + 1 < len(self._tokens)
                and self._tokens[self._pos + 1].type == TokenType.EQUALS
                and self._peek().value not in ("Tensor", "Device", "tuple", "list", "slice", "True", "False", "None")
            ):
                key = self._advance().value
                self._advance()  # consume EQUALS
                val = self._parse_value()
                kwargs[key] = val
            else:
                val = self._parse_value()
                args.append(val)

            if self._at(TokenType.COMMA):
                self._advance()

        return args, kwargs

    def _parse_value(self) -> Any:
        """Parse a single value."""
        tok = self._peek()

        if tok.type == TokenType.IDENT:
            if tok.value in _KEYWORDS:
                self._advance()
                return _KEYWORDS[tok.value]
            if tok.value == "Tensor":
                return self._parse_tensor()
            if tok.value == "Device":
                return self._parse_device()
            if tok.value == "tuple":
                return self._parse_tuple_constructor()
            if tok.value == "list":
                return self._parse_list_constructor()
            if tok.value == "slice":
                return self._parse_slice_constructor()
            raise ValueError(f"Unknown identifier '{tok.value}' at position {tok.pos}")

        if tok.type == TokenType.INT:
            self._advance()
            return int(tok.value)

        if tok.type == TokenType.FLOAT:
            self._advance()
            return float(tok.value)

        if tok.type == TokenType.STRING:
            self._advance()
            return tok.value

        if tok.type == TokenType.LPAREN:
            return self._parse_tuple_literal()

        if tok.type == TokenType.LBRACKET:
            return self._parse_list_literal()

        raise ValueError(f"Unexpected token {tok.type.name} ('{tok.value}') at position {tok.pos}")

    def _parse_tensor(self) -> TensorSpec:
        """Parse: Tensor.dtype(shape, device?).stats(...)?.state(...)?"""
        self._expect(TokenType.IDENT)  # 'Tensor'
        self._expect(TokenType.DOT)
        dtype_tok = self._expect(TokenType.IDENT)
        dtype = dtype_tok.value

        factory = getattr(Tensor, dtype, None)
        if factory is None:
            raise ValueError(f"Unknown dtype '{dtype}' at position {dtype_tok.pos}")

        self._expect(TokenType.LPAREN)
        shape = self._parse_tuple_literal()
        device: DeviceSpec | None = None
        if self._at(TokenType.COMMA):
            self._advance()
            if not self._at(TokenType.RPAREN):
                device = self._parse_device()
                if self._at(TokenType.COMMA):
                    self._advance()
        self._expect(TokenType.RPAREN)

        spec: TensorSpec = factory(shape, device)

        while self._at(TokenType.DOT):
            self._advance()
            method_tok = self._expect(TokenType.IDENT)
            method = method_tok.value

            self._expect(TokenType.LPAREN)
            _, method_kwargs = self._parse_arg_list()
            self._expect(TokenType.RPAREN)

            if method == "stats":
                spec = self._apply_stats(spec, method_kwargs)
            elif method == "state":
                spec = self._apply_state(spec, method_kwargs)
            else:
                raise ValueError(f"Unknown method '.{method}()' at position {method_tok.pos}")

        return spec

    def _apply_stats(self, spec: TensorSpec, kwargs: dict[str, Any]) -> TensorSpec:
        if isinstance(spec, FloatTensorSpec):
            return spec.with_stats(FloatStats(**kwargs))
        if isinstance(spec, IntTensorSpec):
            return spec.with_stats(IntStats(**kwargs))
        if isinstance(spec, BoolTensorSpec):
            return spec.with_stats(BoolStats(**kwargs))
        if isinstance(spec, ComplexTensorSpec):
            return spec.with_stats(ComplexStats(**kwargs))
        raise ValueError(f"Cannot apply stats to {type(spec).__name__}")

    def _apply_state(self, spec: TensorSpec, kwargs: dict[str, Any]) -> TensorSpec:
        state = TensorState(**kwargs)
        if isinstance(spec, (FloatTensorSpec, IntTensorSpec, BoolTensorSpec, ComplexTensorSpec)):
            return spec.with_state(state)
        raise ValueError(f"Cannot apply state to {type(spec).__name__}")

    def _parse_device(self) -> DeviceSpec:
        """Parse: Device.cuda(0) or Device.cpu()"""
        self._expect(TokenType.IDENT)  # 'Device'
        self._expect(TokenType.DOT)
        method = self._expect(TokenType.IDENT).value
        self._expect(TokenType.LPAREN)

        factory = getattr(Device, method, None)
        if factory is None:
            raise ValueError(f"Unknown Device method '{method}'")

        if self._at(TokenType.RPAREN):
            self._expect(TokenType.RPAREN)
            return factory()
        else:
            index = int(self._expect(TokenType.INT).value)
            if self._at(TokenType.COMMA):
                self._advance()
            self._expect(TokenType.RPAREN)
            return factory(index)

    def _parse_tuple_literal(self) -> tuple[Any, ...]:
        """Parse: (item, item, ...)"""
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return tuple(items)

    def _parse_tuple_constructor(self) -> tuple[Any, ...]:
        """Parse: tuple(item, item, ...)"""
        self._expect(TokenType.IDENT)  # 'tuple'
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return tuple(items)

    def _parse_list_literal(self) -> list[Any]:
        """Parse: [item, item, ...]"""
        self._expect(TokenType.LBRACKET)
        items: list[Any] = []
        while not self._at(TokenType.RBRACKET) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RBRACKET)
        return items

    def _parse_list_constructor(self) -> list[Any]:
        """Parse: list(item, item, ...)"""
        self._expect(TokenType.IDENT)  # 'list'
        self._expect(TokenType.LPAREN)
        items: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            items.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return items

    def _parse_slice_constructor(self) -> slice:
        """Parse: slice(start, stop, step)"""
        self._expect(TokenType.IDENT)  # 'slice'
        self._expect(TokenType.LPAREN)
        args: list[Any] = []
        while not self._at(TokenType.RPAREN) and not self._at(TokenType.EOF):
            args.append(self._parse_value())
            if self._at(TokenType.COMMA):
                self._advance()
        self._expect(TokenType.RPAREN)
        return slice(*args)


def parse_case(case_str: str) -> CaseConfig:
    """Parse a case string into a CaseConfig.

    Args:
        case_str: A case string like "abs(x=Tensor.float64((1, 100)))"

    Returns:
        A CaseConfig object.

    Raises:
        ValueError: If the case string is malformed.
    """
    case_str = case_str.strip()
    if not case_str:
        raise ValueError("Empty case string")
    tokens = _tokenize(case_str)
    parser = _Parser(tokens)
    return parser.parse_case()
