"""Configuration parsing and case representation."""
