"""Shared Rich console and output helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.console import Console
from rich.table import Table

if TYPE_CHECKING:
    from tensor_spec.tester.base import TestResult

console = Console(highlight=False)


def status_style(status_value: str) -> str:
    """Return a Rich-markup styled status string."""
    mapping = {
        "pass": "[bold green]PASSED[/]",
        "accuracy_error": "[bold red]FAILED[/]",
        "backend_error": "[bold red]BACKEND_ERR[/]",
        "cuda_error": "[bold red]CUDA_ERR[/]",
        "oom": "[bold yellow]OOM[/]",
        "error": "[bold red]ERROR[/]",
    }
    return mapping.get(status_value, status_value)


def print_result_summary(results: list[TestResult]) -> None:
    """Print a Rich table summarizing test results."""
    table = Table(title="Accuracy Results", show_lines=True)
    table.add_column("API", style="cyan")
    table.add_column("Status")
    table.add_column("max_abs", justify="right")
    table.add_column("max_rel", justify="right")
    table.add_column("Duration", justify="right")

    for r in results:
        styled = status_style(r.status.value)
        max_abs = f"{r.compare_result.max_abs_diff:.2e}" if r.compare_result else "-"
        max_rel = f"{r.compare_result.max_rel_diff:.2e}" if r.compare_result else "-"
        duration = f"{r.duration_ms:.0f}ms"
        table.add_row(r.case.api_name, styled, max_abs, max_rel, duration)

    console.print(table)


def print_setup_summary(results: list[dict[str, str]]) -> None:
    """Print a Rich table summarizing setup results."""
    table = Table(title="Setup Results", show_lines=True)
    table.add_column("Backend", style="cyan")
    table.add_column("Status")
    table.add_column("Detail")

    for r in results:
        styled = "[bold green]OK[/]" if r.get("status") == "ok" else "[bold red]FAILED[/]"
        table.add_row(r.get("backend", ""), styled, r.get("detail", ""))

    console.print(table)
