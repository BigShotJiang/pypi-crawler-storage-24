# 贡献指南

感谢你为 tensor-spec 做出贡献！请在提交前阅读以下约定。

## Commit Message 规范

格式：`<emoji> <type>(<scope>): <description>`

### Type 词表

| Emoji | Type | 用途 |
|-------|------|------|
| ✨ | `feat` | 新功能 |
| 🐛 | `fix` | Bug 修复 |
| ♻️ | `refactor` | 重构（不改变行为） |
| ⚡ | `perf` | 性能优化 |
| 📝 | `docs` | 文档 |
| ✅ | `test` | 测试 |
| 📦 | `build` | 构建 / 依赖 |
| 👷 | `ci` | CI 配置 |
| 🔧 | `chore` | 杂项 |

### Scope（可选）

从模块名中选取：`spec`, `config`, `datagen`, `backend`, `mapping`, `compare`, `tester`, `worker`, `ipc`, `log`, `cli`

### 示例

```
✨ feat(cli): add batch mode
🐛 fix(ipc): suppress shared_memory leak warnings
♻️ refactor: simplify tolerance config loading
📝 docs: update architecture design
📦 build: add pytest-xdist to dev dependencies
👷 ci: add test coverage workflow
⚡ perf(worker): parallelize worker startup
✅ test(compare): add edge case for NaN handling
🔧 chore: update .gitignore
```

## PR 标题规范

- 与 Commit Message 格式一致
- 描述用简洁的动宾短语，说明「做了什么」
- **CI 会自动检查 PR 标题格式**，不符合规范将阻止合并

## 提交流程

1. Fork 仓库并创建分支
2. 小步提交，每个 commit 聚焦单一主题
3. 确保 `just lint` 和 `just test` 通过
4. 创建 PR，标题遵循上述规范
