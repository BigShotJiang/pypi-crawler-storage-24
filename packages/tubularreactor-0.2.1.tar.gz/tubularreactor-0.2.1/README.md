# tubularreactor

Collection of functions for tubular reactors and especially microreactor usage.

![PyPI - Version](https://img.shields.io/pypi/v/tubularreactor)
![GitHub License](https://img.shields.io/gitlab/license/caeglx/tubularreactor)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tubularreactor)

## Installation

tubularreactor is [available from the Python Package
Index](https://pypi.org/project/tubularreactor/), so simply install it with

```
pip install tubularreactor
```

## Usage

The package consists of several modules for the different usecases.