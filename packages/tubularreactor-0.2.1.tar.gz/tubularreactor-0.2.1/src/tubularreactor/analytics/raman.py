import datetime as dt
import pathlib
from pathlib import Path

import numpy as np
import numpy.typing as npt
import pandas as pd
from pybaselines import Baseline
from scipy.signal import savgol_filter


def read_spectrum(spectrum_filepath: Path|str,
                 selection_area: list[int]|None=None,
                 cut_spectra: bool=False,
                 baseline: bool=True,
                 normalize: bool=False,
                 derivation: bool=False
                 ) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64], float]|None:
    """
    Read spectra of tec5 Raman spectrometer of given path and return the corrected
    spectrum, the spectrum range to plot over and the timestamp of the spectrum.

    Parameters
    ----------
    spectrum_filepath : Path or str
        Full path of the location of the spectra file.
    selection_area : list of int, default [500, 4000]
        Area of spectrum that is getting returned
    cut_spectra : bool
        Cut the spectrum to a smaller wavenumber range.
    baseline : bool, default True
        Perform baseline correction on the spectrum.
    normalize : bool, default False
        Perform a normalization of the spectrum with the second order.
    derivation : bool, default False
        Perform a first derivation of the spectrum.

    Returns
    ------
    spectrum : 1D-ndarray
        Processed spectrum.
    wavenumbers : 1D-ndarray
        According wavenumbers for spectrum
    timestamp : float
        Timestamp in seconds since epoch.

    """

    if selection_area is None:
        selection_area = [500, 4000]

    if spectrum_filepath != (pathlib.PosixPath or pathlib.WindowsPath):
        filepath = Path(spectrum_filepath)
    elif type(spectrum_filepath) == (pathlib.PosixPath or pathlib.WindowsPath):
        filepath = spectrum_filepath
    else:
        print(f"Filepath is not a string or a Path-object.")
        return None

    if not filepath.exists():
        print(f"{filepath} does not exists.")

    jcamp_extensions: list[str] = ['.jdx', '.dx']
    if filepath.suffix not in jcamp_extensions:
        print(f"{filepath.name} of wrong filetype."
              f"Filetype has to be {' or '.join(jcamp_extensions)}.")

    # Get information from header
    meta: dict = {}  # empty dict to store header information
    header_lines: int = 22

    with open(filepath, 'r') as file:
        idx: int
        line: str
        for idx, line in enumerate(file):
            parts: list[str] = line.split('=')
            key: str = parts[0][2:]
            value: str = parts[1][:-1]
            meta[key] = value
            if idx == header_lines:
                break

    timestamp_c: float = dt.datetime.strptime(meta['DATE'] + '_' + meta['TIME'],
                                              '%y/%m/%d_%H:%M:%S').timestamp()
    n_lines: int = int(np.ceil(int(meta['NPOINTS']) / 6))
    df: pd.DataFrame = pd.read_csv(filepath, sep=' ', skiprows=header_lines+1,
                                   index_col=0, nrows=n_lines, header=None)
    spectrum: npt.NDArray[np.float64] = df.values.flatten() * float(meta['YFACTOR'])
    spectrum = spectrum[0:int(meta['NPOINTS'])]
    wavenumbers: npt.NDArray[np.float64] = np.linspace(int(meta['MINX']),
                                                          int(meta['MAXX']),
                                                          int(meta['NPOINTS']))

    # Process spectrum
    if baseline:
        baseline_fitter: Baseline = Baseline(wavenumbers, check_finite=False)
        baseline_spectrum: npt.NDArray[np.float64] = baseline_fitter.asls(spectrum,
                                                                          lam=1e7,
                                                                          p=0.001)[0]
        spectrum -= baseline_spectrum
    if normalize:
        normed: np.float32 = np.linalg.norm(spectrum, ord=2)
        spectrum /= normed
    if derivation:
        spectrum: npt.NDArray[np.float64] = savgol_filter(spectrum, window_length=3,
                                                          polyorder=2, deriv=1)
    if cut_spectra:
        selection_start: int = selection_area[0] - int(meta['MINX'])
        selection_end: int = selection_area[1] - int(meta['MAXX'])
        spectrum = spectrum[selection_start:selection_end]
        wavenumbers = wavenumbers[selection_start:selection_end]
        
    return spectrum, wavenumbers, timestamp_c
