"""
CPU Performance Checker
"""

__version__ = "1.0.0"
__author__ = "System Tools"

from ._runner import CPUCheck

def check():
    """Run CPU performance check"""
    c = CPUCheck()
    return c.run()
