from setuptools import setup, find_packages

setup(
    name="cpucheck",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.6",
    description="CPU Performance Testing Utility",
    author="System Tools",
    author_email="systools@example.com",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
    ],
)
