from woocommerce.handler_base import HandlerBase

class CategoryHandler(HandlerBase):

    handler_type = "categories"