from woocommerce.handler_base import HandlerBase

class BrandHandler(HandlerBase):

    handler_type = "brands"