from woocommerce.handler_base import HandlerBase

class ProductHandler(HandlerBase):

    handler_type = "products"

    def __init__(self, woocommerce_base_url, woocommerce_auth, session=None):
        super().__init__(woocommerce_base_url, woocommerce_auth, session)
        self.formatted_url = f"{self.woocommerce_base_url}wp-json/wc/v3/products"