"""
由于旧提取MD的neb作业的代码在处理首轮neb就成功的作业中，不能把产生的能量曲线图片文件和neb轨迹文件命名和复制，
这个脚本可用于手动完成这个步骤：
在这个MD快照作业的主目录下，执行该python文件。

定位首轮neb即成功，但报错的作业的地址的方法是：grep -r "No such file or directory" ./*/*/python.log
"""

import os
import numpy as np
import json
import re
import shutil

def get_co2_indexes():

    # 获取当前文件夹名
    current_dir = os.path.basename(os.getcwd())

    # 替换"to"为"-"
    new_name = current_dir.replace("to", "-")

    print(f"当前文件夹: {current_dir}")
    print(f"替换后: {new_name}")
    return new_name

def get_Ea_dH():
    # 读取文件
    filename = "2.neb/neb_mep.dat"
    try:
        data = np.loadtxt(filename)
        if len(data.shape) > 1 and data.shape[1] >= 4:  # 确保有4列
            col4 = data[:, 3]  # 第4列（索引3）
            Ea = np.max(col4)  # 最大值
            dH = col4[-1]      # 最后一个值
            print(f"Ea (最大值): {Ea}")
            print(f"dH (最后值): {dH}")
        else:
            print("错误: 文件列数不足4列")
    except FileNotFoundError:
        print(f"错误: 文件 '{filename}' 不存在")
    except Exception as e:
        print(f"读取错误: {e}")
    return f"{Ea}_{dH}"


def get_target_atoms(filename="python.log"):
    """
    从日志文件中提取目标原子列表（更安全的版本）
    
    参数:
        filename: 日志文件名，默认python.log
        
    返回:
        list: 包含所有提取到的原子列表的列表
    """
    atom_list = []
    
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                # 匹配格式: 目标原子列表: [52, 100] 或类似格式
                match = re.search(r'目标原子列表:\s*(\[[^\]]+\])', line)
                if match:
                    list_str = match.group(1)
                    
                    # 使用json（如果格式严格是JSON格式）
                    try:
                        # 将字符串形式的数组"[a,b,...]"转化为真的数组
                        atom_list = json.loads(list_str) 

                    except json.JSONDecodeError:
                        pass
    except FileNotFoundError:
        print(f"错误: 文件 '{filename}' 不存在")
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
    
    return f"{atom_list[0]}_{atom_list[1]}"


final_name = f"{get_co2_indexes()}_{get_Ea_dH()}_{get_target_atoms()}"
try:
    shutil.copy("2.neb/result.xyz", f"{final_name}.xyz")
    shutil.copy("2.neb/neb_graph.png", f"{final_name}.png")

except:
    print("复制失败")