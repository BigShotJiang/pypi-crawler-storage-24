"""Memory module for SmithAI - Vector storage, knowledge graphs, and embeddings."""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable
import math

__version__ = "1.0.0"

@dataclass
class Document:
    id: str
    content: str
    metadata: Dict[str, Any]
    embedding: Optional[List[float]] = None

@dataclass
class SearchResult:
    document: Document
    score: float
    distance: float

@dataclass
class MemoryConfig:
    store_type: str = "in_memory"
    embedding_model: str = "default"
    dimension: int = 384
    persist_path: Optional[str] = None

class EmbeddingModel:
    def __init__(self, model_name: str = "default", dimension: int = 384):
        self.model_name = model_name
        self.dimension = dimension
    
    def embed(self, text: str) -> List[float]:
        words = text.lower().split()
        if not words:
            return [0.0] * self.dimension
        vector = [0.0] * self.dimension
        for i, word in enumerate(words[:self.dimension]):
            vector[i] = hash(word) % 1000 / 1000.0
        norm = math.sqrt(sum(v * v for v in vector))
        if norm > 0:
            vector = [v / norm for v in vector]
        return vector

def get_embeddings(texts: List[str], model: Optional[EmbeddingModel] = None) -> List[List[float]]:
    if model is None:
        model = EmbeddingModel()
    return [model.embed(text) for text in texts]

def cosine_similarity(a: List[float], b: List[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)

@runtime_checkable
class VectorStore(Protocol):
    def add(self, documents: List[Document]) -> None: ...
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]: ...
    def delete(self, doc_id: str) -> bool: ...

class InMemoryVectorStore:
    def __init__(self, config: Optional[MemoryConfig] = None):
        self.config = config or MemoryConfig()
        self.documents: Dict[str, Document] = {}
        self.embedding_model = EmbeddingModel(
            model_name=self.config.embedding_model,
            dimension=self.config.dimension
        )
    
    def add(self, documents: List[Document]) -> None:
        for doc in documents:
            if doc.embedding is None:
                doc.embedding = self.embedding_model.embed(doc.content)
            self.documents[doc.id] = doc
    
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]:
        query_embedding = self.embedding_model.embed(query)
        results = []
        for doc in self.documents.values():
            if doc.embedding:
                score = cosine_similarity(query_embedding, doc.embedding)
                distance = 1 - score
                results.append(SearchResult(document=doc, score=score, distance=distance))
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def delete(self, doc_id: str) -> bool:
        if doc_id in self.documents:
            del self.documents[doc_id]
            return True
        return False

class ChromaStore:
    def __init__(self, config: Optional[MemoryConfig] = None):
        self.config = config or MemoryConfig()
        self.store = InMemoryVectorStore(config)
    
    def add(self, documents: List[Document]) -> None:
        self.store.add(documents)
    
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]:
        return self.store.search(query, top_k)
    
    def delete(self, doc_id: str) -> bool:
        return self.store.delete(doc_id)

class FAISSStore:
    def __init__(self, config: Optional[MemoryConfig] = None):
        self.config = config or MemoryConfig()
        self.store = InMemoryVectorStore(config)
    
    def add(self, documents: List[Document]) -> None:
        self.store.add(documents)
    
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]:
        return self.store.search(query, top_k)
    
    def delete(self, doc_id: str) -> bool:
        return self.store.delete(doc_id)

class PineconeStore:
    def __init__(self, config: Optional[MemoryConfig] = None):
        self.config = config or MemoryConfig()
        self.store = InMemoryVectorStore(config)
    
    def add(self, documents: List[Document]) -> None:
        self.store.add(documents)
    
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]:
        return self.store.search(query, top_k)
    
    def delete(self, doc_id: str) -> bool:
        return self.store.delete(doc_id)

@runtime_checkable
class MemoryStore(Protocol):
    def add(self, documents: List[Document]) -> None: ...
    def search(self, query: str, top_k: int = 5) -> List[SearchResult]: ...
    def delete(self, doc_id: str) -> bool: ...

class KnowledgeGraph:
    def __init__(self):
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.edges: Dict[str, List[str]] = {}
    
    def add_node(self, node_id: str, properties: Dict[str, Any]) -> None:
        self.nodes[node_id] = properties
    
    def add_edge(self, from_id: str, to_id: str, relation: str) -> None:
        if from_id not in self.edges:
            self.edges[from_id] = []
        self.edges[from_id].append(to_id)
        if from_id not in self.nodes:
            self.nodes[from_id] = {}
        if to_id not in self.nodes:
            self.nodes[to_id] = {}
        self.nodes[from_id][f"has_{relation}"] = to_id
    
    def get_neighbors(self, node_id: str) -> List[str]:
        return self.edges.get(node_id, [])
    
    def search_path(self, start: str, end: str) -> List[str]:
        visited = set()
        queue = [[start]]
        while queue:
            path = queue.pop(0)
            node = path[-1]
            if node == end:
                return path
            if node in visited:
                continue
            visited.add(node)
            for neighbor in self.get_neighbors(node):
                new_path = list(path) + [neighbor]
                queue.append(new_path)
        return []
