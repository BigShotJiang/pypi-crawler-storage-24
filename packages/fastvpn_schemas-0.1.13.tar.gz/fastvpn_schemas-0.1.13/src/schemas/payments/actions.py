import uuid as py_uuid
from datetime import datetime

from pydantic import BaseModel


class ProcessSuccessfulPayment(BaseModel):
    payment_id: py_uuid.UUID
    user_id: int
    plan_id: py_uuid.UUID
    telegram_charge_id: str
    amount_stars: int
    paid_at: datetime
    is_recurring: bool
    subscription_days: int
