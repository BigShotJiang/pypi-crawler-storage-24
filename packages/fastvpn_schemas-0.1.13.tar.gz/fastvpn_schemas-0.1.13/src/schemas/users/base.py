from schemas.common import ORMBaseSchema


class UserBase(ORMBaseSchema):
    id: int
