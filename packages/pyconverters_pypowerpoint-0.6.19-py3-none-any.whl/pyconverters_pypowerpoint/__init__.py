"""Convert PPTX to text using [python-pptx]"""

__version__ = "0.6.19"
