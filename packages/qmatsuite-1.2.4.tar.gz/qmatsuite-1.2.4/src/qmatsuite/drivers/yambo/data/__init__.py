"""Yambo metadata package."""
