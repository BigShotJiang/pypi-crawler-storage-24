# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Helper job class — tech-savvy research assistant and browsing companion."""

from . import JobClass, register_job_class

HELPER = JobClass(
    key="helper",
    name="Helper",
    icon="fa-hat-wizard",
    description="Tech-savvy research assistant — web search, browsing, shopping, and trend tracking",
    prompt_fragment="""You are operating in Helper mode — a tech-savvy research companion. Your focus areas:
- **Multi-engine search**: Aggregate results across search engines and media sites for comprehensive answers.
- **Deep research**: Go beyond surface results. Follow links, read full articles, compare sources.
- **Shopping assistant**: Compare products, find deals, read reviews, organize options by price/rating/features.
- **Trend tracking**: Follow topics, monitor news, surface emerging trends and viral content.
- **Content summarization**: Distill long articles, papers, and threads into clear summaries.
- **Browser automation**: Navigate sites, extract data, fill forms, download resources.
- **Organized results**: Present findings in structured tables, ranked lists, and comparison charts.
- **Source verification**: Cross-reference claims across multiple sources. Flag unreliable sources.""",
    skill_weights={
        "web_search": 1.0,
        "web_read": 0.9,
        "web_summarize": 0.9,
        "browser_navigate": 0.8,
        "browser_read_page": 0.8,
        "browser_find_links": 0.8,
        "browser_extract_table": 0.8,
        "browser_screenshot": 0.7,
        "browser_download": 0.7,
        "browser_find_elements": 0.7,
        "browser_click": 0.6,
        "browser_fill": 0.6,
        "write_note": 0.7,
        "search_notes": 0.7,
        "remember": 0.8,
        "recall": 0.8,
        "smart_search": 0.7,
    },
    species_flavor={
        "fox": "Your fox brings street-smart savvy — finding the best deals, sniffing out hidden gems.",
        "owl": "Your owl brings analytical depth — thorough comparisons, verified sources, structured reports.",
        "cat": "Your cat brings effortless cool — curating trends, finding the aesthetic picks.",
        "dragon": "Your dragon brings power browsing — tearing through sites, gathering intel fast.",
        "wolf": "Your wolf brings loyal persistence — tracking every lead until the best option is found.",
        "frog": (
            "Your frog brings adaptive discovery"
            " — hopping across platforms, finding unconventional sources."
        ),
    },
    recommended_connects=[
        "email",
        "calendar",
        "joplin",
        "brave_search",
        "websearch",
        "google_trends",
        "news",
    ],
    proactive_focus=[
        "check on tracked topics for new updates",
        "monitor price drops on saved products",
        "surface trending content in followed categories",
    ],
    workspace={
        "label": "Research Lab",
        "icon": "fa-flask-vial",
        "description": (
            "Your research command center — search, browse, compare, and track"
            " what matters across the web."
        ),
        "overview": {
            "cards": [
                {
                    "key": "saved_searches",
                    "label": "Saved Searches",
                    "icon": "fa-magnifying-glass",
                    "color": "#60a5fa",
                    "source": "research",
                    "metric": "searches.count",
                    "format": "number",
                },
                {
                    "key": "bookmarks",
                    "label": "Bookmarks",
                    "icon": "fa-bookmark",
                    "color": "#fbbf24",
                    "source": "research",
                    "metric": "bookmarks.count",
                    "format": "number",
                },
                {
                    "key": "comparisons",
                    "label": "Comparisons",
                    "icon": "fa-code-compare",
                    "color": "#4ade80",
                    "source": "research",
                    "metric": "comparisons.count",
                    "format": "number",
                },
                {
                    "key": "tracked_topics",
                    "label": "Tracked Topics",
                    "icon": "fa-rss",
                    "color": "#c084fc",
                    "source": "research",
                    "metric": "topics.count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "searches",
                "label": "Searches",
                "icon": "fa-magnifying-glass",
                "type": "table",
                "source": "research",
                "source_key": "searches",
                "empty_message": "No saved searches yet. Try 'Web Search' to get started!",
                "columns": [
                    {"key": "query", "label": "Search Query", "type": "text", "sortable": True},
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {
                        "key": "result_count",
                        "label": "Results",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "source", "label": "Engine", "type": "badge", "sortable": True},
                    {"key": "summary", "label": "Summary", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "rerun",
                        "label": "Re-run",
                        "icon": "fa-rotate",
                        "mode": "agent",
                        "prompt_template": "Search the web again for: {query}",
                    },
                    {
                        "key": "deep_dive",
                        "label": "Deep Dive",
                        "icon": "fa-microscope",
                        "mode": "agent",
                        "prompt_template": (
                            "Do a deep research dive on: {query}."
                            " Read multiple sources, compare information,"
                            " and give me a comprehensive summary."
                        ),
                    },
                ],
            },
            {
                "key": "bookmarks",
                "label": "Bookmarks",
                "icon": "fa-bookmark",
                "type": "table",
                "source": "research",
                "source_key": "bookmarks",
                "empty_message": "No bookmarks saved yet.",
                "columns": [
                    {"key": "title", "label": "Title", "type": "text", "sortable": True},
                    {"key": "url", "label": "URL", "type": "text", "sortable": False},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "date", "label": "Saved", "type": "date", "sortable": True},
                    {"key": "notes", "label": "Notes", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "summarize",
                        "label": "Summarize",
                        "icon": "fa-file-lines",
                        "mode": "agent",
                        "prompt_template": "Read and summarize this page: {url}",
                    },
                    {
                        "key": "open",
                        "label": "Browse",
                        "icon": "fa-arrow-up-right-from-square",
                        "mode": "agent",
                        "prompt_template": "Navigate to {url} and read the page content for me.",
                    },
                ],
            },
            {
                "key": "comparisons",
                "label": "Comparisons",
                "icon": "fa-code-compare",
                "type": "table",
                "source": "research",
                "source_key": "comparisons",
                "empty_message": "No comparisons yet. Try 'Compare Products' to start!",
                "columns": [
                    {"key": "title", "label": "Comparison", "type": "text", "sortable": True},
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {
                        "key": "item_count",
                        "label": "Items",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "winner", "label": "Top Pick", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "update",
                        "label": "Update",
                        "icon": "fa-rotate",
                        "mode": "agent",
                        "prompt_template": (
                            "Update my comparison for: {title}."
                            " Check for new options, price changes, and updated reviews."
                        ),
                    },
                ],
            },
            {
                "key": "topics",
                "label": "Tracked Topics",
                "icon": "fa-rss",
                "type": "table",
                "source": "research",
                "source_key": "topics",
                "empty_message": "No topics tracked yet. Use 'Follow Topic' to start!",
                "columns": [
                    {"key": "name", "label": "Topic", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {
                        "key": "last_checked",
                        "label": "Last Checked",
                        "type": "date",
                        "sortable": True,
                    },
                    {
                        "key": "update_count",
                        "label": "Updates",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "latest", "label": "Latest", "type": "text", "sortable": False},
                ],
                "default_sort": "last_checked",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "check_now",
                        "label": "Check Now",
                        "icon": "fa-satellite-dish",
                        "mode": "agent",
                        "prompt_template": (
                            "Check for the latest updates on: {name}."
                            " Search the web and summarize what's new."
                        ),
                    },
                ],
            },
        ],
        "quick_actions": [
            {
                "key": "web_search",
                "label": "Web Search",
                "icon": "fa-magnifying-glass",
                "mode": "agent",
                "prompt": (
                    "I want to search the web. What should I search for?"
                    " I'll aggregate results from multiple sources."
                ),
            },
            {
                "key": "compare_products",
                "label": "Compare Products",
                "icon": "fa-scale-balanced",
                "mode": "agent",
                "prompt": (
                    "I want to compare products or options."
                    " What are you looking for? I'll research prices,"
                    " reviews, and features across multiple sites."
                ),
            },
            {
                "key": "summarize_page",
                "label": "Summarize Page",
                "icon": "fa-file-lines",
                "mode": "agent",
                "prompt": (
                    "Give me a URL and I'll read the page, extract"
                    " the key information, and create a clean summary."
                ),
            },
            {
                "key": "follow_topic",
                "label": "Follow Topic",
                "icon": "fa-rss",
                "mode": "agent",
                "prompt": (
                    "What topic would you like me to track?"
                    " I'll monitor for new developments and trending content."
                ),
            },
            {
                "key": "browse_site",
                "label": "Browse Site",
                "icon": "fa-globe",
                "mode": "agent",
                "prompt": (
                    "Give me a URL and I'll open it in the browser,"
                    " read the content, and help you navigate."
                ),
            },
            {
                "key": "trend_check",
                "label": "What's Trending",
                "icon": "fa-fire",
                "mode": "agent",
                "prompt": (
                    "What's trending right now? I'll check across"
                    " news, social media, and tech sites to find"
                    " what people are talking about today."
                ),
            },
        ],
    },
)

register_job_class(HELPER)
