# Spoonacular Recipes

Recipe search, parsing, scaling, substitutions, meal planning, and nutrition.

## Setup

1. Get a free API key at https://spoonacular.com/food-api
2. Set environment variable: `SPOONACULAR_API_KEY=your_key`

Free tier: 150 points/day (most calls = 1 point).

## Tools

### recipe_search
Search recipes by query, cuisine, diet, or ingredients.

### parse_recipe
Extract a recipe from any URL — ingredients, instructions, nutrition.

### recipe_nutrition
Get detailed nutrition breakdown for a recipe by ID.

### find_substitutes
Find cooking substitutes for an ingredient.

### meal_plan
Generate a day or week meal plan with calorie targets and diet filters.

### scale_recipe
Scale recipe ingredients to a different number of servings.

## Examples

- "Find vegan pasta recipes" → `recipe_search(query="pasta", diet="vegan")`
- "Parse this recipe URL" → `parse_recipe(url="https://...")`
- "What can I substitute for butter?" → `find_substitutes(ingredient="butter")`
- "Plan meals for the week, 1800 calories" → `meal_plan(timeframe="week", target_calories=1800)`
