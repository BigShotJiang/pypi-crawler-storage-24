# Email Triage Skill - Themis, Titan of Order

*Themis was the Titan of divine law, order, and custom. She weighs each matter with her scales and assigns it to its proper place.*

Automatically sort and categorize incoming emails for nonprofit operations.

## Categories

- **Campaign** - Advocacy campaigns, action alerts, political organizing
- **Trans Pride** - Trans Pride events, planning, volunteers
- **GJL Operations** - Internal operations, admin, facilities, general org
- **Staff** - Staff communications, HR, team coordination
- **Board** - Board members, governance, board meetings
- **Coalitions** - Partner organizations, coalition work, allied groups
- **Donors** - Donations, fundraising, grant funders
- **Grants** - Foundation grants, proposals, applications
- **Media** - Press inquiries, media requests, communications
- **Volunteers** - Volunteer opportunities, shifts
- **Notifications** - CI/CD alerts, GitHub Actions, system monitoring, automated alerts
- **Promotional** - Marketing emails, newsletters, ads, credit offers, retail
- **Other** - Uncategorized

## Priority Flags

- 🔴 Urgent: Time-sensitive, deadlines, "urgent"/"critical"/"outage" in subject
- 🟡 Action needed: Requests, questions, CI failures, grant deadlines, board emails
- 🟢 FYI: Informational, newsletters, promotional

Priority is determined in order:
1. **Sender priority rules** — per-sender or per-domain overrides (highest precedence)
2. **Urgent keywords** — configurable keyword list (defaults + custom)
3. **Category logic** — Board → action, Notification failures → action, Grant deadlines → action
4. **Action keywords** — configurable keyword list (defaults + custom)
5. **Fallback** — fyi

## Classification

Emails are classified using a 5-tier priority system:

1. **Learned senders** (95% confidence) - Taught via `teach_sender`
2. **Learned domains** (85% confidence) - Taught via `teach_sender` with domain
3. **Promotional heuristic** (80%) - Known marketing domains + "unsubscribe" + promo signals
4. **Notification heuristic** (80%) - GitHub/GitLab/CI domains + noreply + tech content
5. **Keyword matching** (10-70%) - Configurable keywords per category

## Custom Keywords

Keywords can be managed dynamically:

- **Add**: "add keyword 'james talarico' to Promotional"
- **Remove**: "remove keyword 'schedule' from GJL Operations"
- **List**: "show keywords for Staff" or "list all triage keywords"
- **Reset**: "reset Campaign keywords to defaults"

Custom keywords persist in `~/.familiar/data/email_triage.json`.

## Custom Priority Keywords

Priority keywords control urgency flags (separate from category keywords):

- **Add**: "add 'lawsuit' as urgent keyword", "add 'invoice' to action keywords"
- **Remove**: "remove 'p1' from urgent keywords"
- **List**: "list urgent keywords", "show priority keywords"
- **Reset**: "reset urgent keywords to defaults"

Managed via `manage_priority_keywords` tool.

## Sender Priority Rules

Override priority for specific senders or domains:

- **Set**: "make emails from boss@company.com always urgent"
- **Remove**: "remove priority rule for company.com"
- **List**: "show sender priority rules"

Managed via `set_sender_priority` tool. Sender rules take highest precedence.

## Explaining & Reclassifying

After triage, interact with results using `#N` references:

- **Explain**: "why is #3 promotional?" → shows classification reasoning chain
- **Reclassify**: "move #5 to Board" or "make #2 urgent" → updates category/priority, auto-teaches sender

Managed via `explain_triage` and `reclassify_email` tools.
