# Todoist

Manage tasks and projects via Todoist.

## Setup

```bash
export TODOIST_API_TOKEN=your_token
```

Get a token at: https://todoist.com/app/settings/integrations/developer

## Tools

| Tool | Description |
|------|-------------|
| `todoist_tasks` | List active tasks |
| `todoist_add_task` | Create a new task |
| `todoist_complete` | Mark a task as done |
| `todoist_projects` | List projects |
