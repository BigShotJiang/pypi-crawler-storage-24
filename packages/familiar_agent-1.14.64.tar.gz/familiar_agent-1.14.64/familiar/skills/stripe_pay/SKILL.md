# Stripe Payments

Accept payments, create invoices, manage donations, and process refunds via Stripe.

## Setup

1. Create a Stripe account at https://stripe.com
2. Get your API key from https://dashboard.stripe.com/apikeys
3. Set environment variable:

```bash
export STRIPE_SECRET_KEY=sk_live_...   # or sk_test_... for testing
```

## Tools

| Tool | Description |
|------|-------------|
| `create_payment_link` | Create a shareable payment link for a product/service |
| `list_payments` | List recent payments with amounts, status, and customers |
| `create_invoice` | Create and optionally send an invoice to a customer by email |
| `donation_link` | Create a payment link configured for nonprofit donations |
| `refund_payment` | Process a full or partial refund on a charge |

## Examples

- "Create a payment link for a painting for $150"
- "Show my recent payments"
- "Invoice jane@example.com for $500 consulting work"
- "Create a donation link for our food bank"
- "Refund charge ch_1abc123"

## Pricing

Stripe charges 2.9% + $0.30 per transaction (2.2% for qualified nonprofits).
No monthly fee. API usage is free.
