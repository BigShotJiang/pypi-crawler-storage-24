# Square

Browse payments, manage customers, view invoices, and explore catalog items via Square.

## Setup

1. Create a Square developer account at https://developer.squareup.com/apps
2. Create an application and get your access token
3. Set environment variables:

```bash
export SQUARE_ACCESS_TOKEN=your_access_token
export SQUARE_LOCATION_ID=your_location_id  # from Square Dashboard > Locations
```

## Tools

| Tool | Description |
|------|-------------|
| `square_payments` | List recent payments with amounts, status, and receipts |
| `square_customers` | Browse customers with contact info and history |
| `square_invoices` | List invoices with status and amounts (needs SQUARE_LOCATION_ID) |
| `square_catalog` | Browse catalog items, categories, prices |

## Examples

- "Show my recent Square payments"
- "List my Square customers"
- "Show recent invoices"
- "Browse my catalog items"

## Pricing

Square charges 2.6% + $0.10 per in-person transaction, 2.9% + $0.30 online.
No monthly fee. API usage is free.
