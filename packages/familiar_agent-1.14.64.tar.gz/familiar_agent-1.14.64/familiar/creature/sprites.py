# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Sprite Frame Data

Per-species, per-stage, per-animation-state pixel art frames.

Each frame is a list of strings (rows). Each character is a role code:
  . = transparent (space)
  # = outline (dark gray)
  B = body color
  E = eyes color
  A = accent color
  H = highlight (auto-computed lighter body)
  S = shadow (auto-computed darker body)

Structure: SPRITES[species][stage][activity][frame_index] -> list[str]

All 6 species fully drawn at all 3 stages (baby, juvenile, adult).
"""

# ── Fox ──────────────────────────────────────────────────────────────

_FOX_BABY = {
    "idle": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A..A...",
            ".ABBBBA..",
            "ABBBBBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "thinking": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABE.EBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A..A.H.",
            ".ABBBBA..",
            "ABE.EBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "working": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            ".ABBHBBAA",
            "..BSBSB..",
            ".BB..BB..",
        ],
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            "AABBHBBA.",
            "..BSBSB..",
            "..BB..BB.",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..A..A...",
            ".ABBBBA..",
            ".AB##BBA.",
            ".ABBHBBA.",
            "..BBBBB..",
        ],
    ],
}

_FOX_JUVENILE = {
    "idle": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBBBBBBBA",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
    ],
    "thinking": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBE.EBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
        [
            "..A...A.H.",
            ".ABBBBBA..",
            "ABBE.EBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
    ],
    "working": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "..BBBBBBAA",
            "..BSBBSB..",
            ".BB...BB..",
        ],
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "AABBBBBB..",
            "..BSBBSB..",
            "..BB...BB.",
        ],
    ],
    "sleeping": [
        [
            "..........",
            "..A...A...",
            ".ABBBBBA..",
            ".ABB##BBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "...BBBBB..",
        ],
    ],
}

_FOX_ADULT = {
    "idle": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBBBBBBBA",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
    ],
    "thinking": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBE..BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A.H.",
            ".ABBBBBBA..",
            "ABBBE..BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
    ],
    "working": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBAA",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            ".BB....BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            "AABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB....BB.",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "..A....A...",
            ".ABBBBBBA..",
            ".ABBB##BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBB..",
            "...........",
        ],
    ],
}

# ── Owl ──────────────────────────────────────────────────────────────

_OWL_BABY = {
    "idle": [
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
        [
            ".BBBBB.",
            "BBBBBBB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
    ],
    "thinking": [
        [
            ".BBBBB.",
            "BE.B.EB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
        [
            ".BBBBB.H",
            "BE.B.EB.",
            "BBBHBBB.",
            ".BBABB..",
            ".BSSBB..",
            "..B.B...",
        ],
    ],
    "working": [
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            ".BBAABB",
            ".BSSBB.",
            ".BB.B..",
        ],
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            "BBABBBA",
            ".BSSBB.",
            "..B.BB.",
        ],
    ],
    "sleeping": [
        [
            ".BBBBB.",
            "B##B##B",
            "BBBHBBB",
            ".BBABB.",
            ".BBBBB.",
            "..B.B..",
        ],
    ],
}

_OWL_JUVENILE = {
    "idle": [
        [
            "..BBBBB..",
            ".BEBEBEB.",
            ".BBBHBBB.",
            "..BBABB..",
            ".BBBBBBB.",
            "..BSSBB..",
            "...B.B...",
        ],
        [
            "..BBBBB..",
            ".BBBBBBB.",
            ".BBBHBBB.",
            "..BBABB..",
            ".BBBBBBB.",
            "..BSSBB..",
            "...B.B...",
        ],
    ],
    "thinking": [
        [
            "..BBBBB..",
            ".BE.B.EB.",
            ".BBBHBBB.",
            "..BBABB..",
            ".BBBBBBB.",
            "..BSSBB..",
            "...B.B...",
        ],
        [
            "..BBBBB.H",
            ".BE.B.EB.",
            ".BBBHBBB.",
            "..BBABB..",
            ".BBBBBBB.",
            "..BSSBB..",
            "...B.B...",
        ],
    ],
    "working": [
        [
            "..BBBBB..",
            ".BEBEBEB.",
            ".BBBHBBB.",
            "..BBAABB.",
            ".BBBBBBB.",
            "..BSSBB..",
            "..BB.B...",
        ],
        [
            "..BBBBB..",
            ".BEBEBEB.",
            ".BBBHBBB.",
            ".ABBABB..",
            ".BBBBBBB.",
            "..BSSBB..",
            "...B.BB..",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..BBBBB..",
            ".B##B##B.",
            ".BBBHBBB.",
            "..BBABB..",
            ".BBBBBBB.",
            "..BBBBB..",
        ],
    ],
}

_OWL_ADULT = {
    "idle": [
        [
            "...BBBBB...",
            "..BEBEBEB..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
        [
            "...BBBBB...",
            "..BBBBBBB..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
        [
            "...BBBBB...",
            "..BEBEBEB..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
    ],
    "thinking": [
        [
            "...BBBBB...",
            "..BE.B.EB..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
        [
            "...BBBBB..H",
            "..BE.B.EB..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
    ],
    "working": [
        [
            "...BBBBB...",
            "..BEBEBEB..",
            "..BBBHBBB..",
            "...BBABBBA.",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "..BB..B....",
        ],
        [
            "...BBBBB...",
            "..BEBEBEB..",
            "..BBBHBBB..",
            ".ABBABB....",
            "..BBBBBBB..",
            "..BBBBBBB..",
            "...BSSBB...",
            "...B..BB...",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "...BBBBB...",
            "..B##B##B..",
            "..BBBHBBB..",
            "...BBABB...",
            "..BBBBBBB..",
            "...BBBBB...",
            "...........",
        ],
    ],
}

# ── Cat ──────────────────────────────────────────────────────────────

_CAT_BABY = {
    "idle": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BBBBBBB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
    ],
    "thinking": [
        [
            ".A...A.",
            "ABBBBBA",
            "BE.B.BB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
        [
            ".A...A.H",
            "ABBBBBA.",
            "BE.B.BB.",
            "BBBHBBB.",
            ".BSBSB..",
            ".BB.BB..",
        ],
    ],
    "working": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBBA",
            ".BSBSB.",
            "BB..BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "ABBBHBBB",
            ".BSBSB.",
            ".BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".A...A..",
            "ABBBBBA.",
            "B##B##B.",
            "BBBHBBB.",
            ".BBBBB..",
        ],
    ],
}

_CAT_JUVENILE = {
    "idle": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            ".BBBHBBB.",
            "..BBBBBBA",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BBBBBBB.",
            ".BBBHBBB.",
            "..BBBBBBA",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "thinking": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BE.B.BB.",
            ".BBBHBBB.",
            "..BBBBBBA",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A...A.H",
            ".ABBBBBA.",
            ".BE.B.BB.",
            ".BBBHBBB.",
            "..BBBBBBA",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "working": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            ".BBBHBBBA",
            "..BBBBBBA",
            "..BSBSB..",
            ".BB..BB..",
        ],
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            "ABBBHBBB.",
            "..BBBBBBA",
            "..BSBSB..",
            "..BB..BB.",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..A...A..",
            ".ABBBBBA.",
            ".B##B##B.",
            ".BBBHBBB.",
            "..BBBBBBA",
            "..BBBBB..",
        ],
    ],
}

_CAT_ADULT = {
    "idle": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBBBBBBB.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB..BB..",
        ],
    ],
    "thinking": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBE.B.BB.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            "...A....A.H",
            "..ABBBBBBA.",
            "..BBE.B.BB.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB..BB..",
        ],
    ],
    "working": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBBA",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "..BB...BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            ".ABBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBBA",
            "...BSBBSB..",
            "...BB...BB.",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "...A....A..",
            "..ABBBBBBA.",
            "..BB##B##B.",
            "..BBBBHBBB.",
            "...BBBBBBBA",
            "...BBBBBBB.",
            "...........",
        ],
    ],
}

# ── Dragon ───────────────────────────────────────────────────────────

_DRAGON_BABY = {
    "idle": [
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
        [
            "A.......",
            ".ABBBBA.",
            ".BBBBBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
    ],
    "thinking": [
        [
            "A.......",
            ".ABBBBA.",
            ".BE.EBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
        [
            "A.....H.",
            ".ABBBBA.",
            ".BE.EBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
    ],
    "working": [
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            ".BBBHBBA",
            "..BSSB..",
            ".BB..BB.",
        ],
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            "ABBBHBB.",
            "..BSSB..",
            "..BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            "A.......",
            ".ABBBBA.",
            ".B##BBBA",
            ".BBBHBB.",
            "..BBBB..",
        ],
    ],
}

_DRAGON_JUVENILE = {
    "idle": [
        [
            ".A........",
            "..ABBBBA..",
            "..BEBEBBA.",
            "..BBBHBBA.",
            "...BBBBBA.",
            "...BSSB...",
            "...BB.BB..",
        ],
        [
            ".A........",
            "..ABBBBA..",
            "..BBBBBBA.",
            "..BBBHBBA.",
            "...BBBBBA.",
            "...BSSB...",
            "...BB.BB..",
        ],
    ],
    "thinking": [
        [
            ".A........",
            "..ABBBBA..",
            "..BE.EBBA.",
            "..BBBHBBA.",
            "...BBBBBA.",
            "...BSSB...",
            "...BB.BB..",
        ],
        [
            ".A......H.",
            "..ABBBBA..",
            "..BE.EBBA.",
            "..BBBHBBA.",
            "...BBBBBA.",
            "...BSSB...",
            "...BB.BB..",
        ],
    ],
    "working": [
        [
            ".A........",
            "..ABBBBA..",
            "..BEBEBBA.",
            "..BBBHBBAA",
            "...BBBBBA.",
            "...BSSB...",
            "..BB..BB..",
        ],
        [
            ".A........",
            "..ABBBBA..",
            "..BEBEBBA.",
            ".ABBBHBBA.",
            "...BBBBBA.",
            "...BSSB...",
            "...BB..BB.",
        ],
    ],
    "sleeping": [
        [
            "..........",
            ".A........",
            "..ABBBBA..",
            "..B##BBBA.",
            "..BBBHBBA.",
            "...BBBBBA.",
            "...BBBBB..",
        ],
    ],
}

_DRAGON_ADULT = {
    "idle": [
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBEBEBBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBBBBBBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBEBEBBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB..BB..",
        ],
    ],
    "thinking": [
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBBE.EBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB..BB..",
        ],
        [
            ".A.......H.",
            "..ABBBBBA..",
            "..BBBE.EBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB..BB..",
        ],
    ],
    "working": [
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBEBEBBA.",
            "..BBBBHBBAA",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "..BB...BB..",
        ],
        [
            ".A.........",
            "..ABBBBBA..",
            "..BBEBEBBA.",
            ".ABBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBA.",
            "...BSBBSB..",
            "...BB...BB.",
        ],
    ],
    "sleeping": [
        [
            "...........",
            ".A.........",
            "..ABBBBBA..",
            "..BBB##BBA.",
            "..BBBBHBBA.",
            "...BBBBBBA.",
            "...BBBBBBB.",
            "...........",
        ],
    ],
}

# ── Wolf ─────────────────────────────────────────────────────────────

_WOLF_BABY = {
    "idle": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BBBBBBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
    ],
    "thinking": [
        [
            ".A...A.",
            "ABBBBBA",
            "BE..BBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
        [
            ".A...A.H",
            "ABBBBBA.",
            "BE..BBB.",
            "BBBHBBB.",
            ".BSSBB..",
            ".BB.BB..",
        ],
    ],
    "working": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBBA",
            ".BSSBB.",
            "BB..BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "ABBBHBBB",
            ".BSSBB.",
            ".BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".A...A..",
            "ABBBBBA.",
            "B##B##B.",
            "BBBHBBB.",
            ".BBBBB..",
        ],
    ],
}

_WOLF_JUVENILE = {
    "idle": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            ".BBBHBBB.",
            "..BBBBBB.",
            "..BSSBB..",
            "..BB.BB..",
        ],
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BBBBBBB.",
            ".BBBHBBB.",
            "..BBBBBB.",
            "..BSSBB..",
            "..BB.BB..",
        ],
    ],
    "thinking": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BE..BBB.",
            ".BBBHBBB.",
            "..BBBBBB.",
            "..BSSBB..",
            "..BB.BB..",
        ],
        [
            "..A...A.H",
            ".ABBBBBA.",
            ".BE..BBB.",
            ".BBBHBBB.",
            "..BBBBBB.",
            "..BSSBB..",
            "..BB.BB..",
        ],
    ],
    "working": [
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            ".BBBHBBBA",
            "..BBBBBB.",
            "..BSSBB..",
            ".BB..BB..",
        ],
        [
            "..A...A..",
            ".ABBBBBA.",
            ".BEBEBBB.",
            "ABBBHBBB.",
            "..BBBBBB.",
            "..BSSBB..",
            "..BB..BB.",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..A...A..",
            ".ABBBBBA.",
            ".B##B##B.",
            ".BBBHBBB.",
            "..BBBBBB.",
            "..BBBBB..",
        ],
    ],
}

_WOLF_ADULT = {
    "idle": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB..BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBBBBBBB.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB..BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB..BB..",
        ],
    ],
    "thinking": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBE..BBB.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB..BB..",
        ],
        [
            "...A....A.H",
            "..ABBBBBBA.",
            "..BBE..BBB.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB..BB..",
        ],
    ],
    "working": [
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            "..BBBBHBBBA",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "..BB...BB..",
        ],
        [
            "...A....A..",
            "..ABBBBBBA.",
            "..BBEBEBBB.",
            ".ABBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...BSSBBB..",
            "...BB...BB.",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "...A....A..",
            "..ABBBBBBA.",
            "..BB##B##B.",
            "..BBBBHBBB.",
            "...BBBBBBB.",
            "...BBBBBBB.",
            "...........",
        ],
    ],
}

# ── Frog ─────────────────────────────────────────────────────────────

_FROG_BABY = {
    "idle": [
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            "..B.B..",
        ],
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            "..BSSB.",
            "..B.B..",
        ],
    ],
    "thinking": [
        [
            ".E...E.",
            "E.BBB.B",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            "..B.B..",
        ],
        [
            ".E...E.H",
            "E.BBB.B.",
            "BBBBBBB.",
            "BAHHHAB.",
            ".BSSB...",
            "..B.B...",
        ],
    ],
    "working": [
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            ".BB.B..",
        ],
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            "..BSSB.",
            "..B.BB.",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".#...#..",
            "#BBBB#B.",
            "BBBBBBB.",
            "BAHHHAB.",
            ".BBBBB..",
        ],
    ],
}

_FROG_JUVENILE = {
    "idle": [
        [
            "..E...E..",
            ".EBBBBEB.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "..BSSB...",
            "...B.B...",
        ],
        [
            "..E...E..",
            ".EBBBBEB.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "...BSSB..",
            "...B.B...",
        ],
    ],
    "thinking": [
        [
            "..E...E..",
            ".E.BBB.B.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "..BSSB...",
            "...B.B...",
        ],
        [
            "..E...E.H",
            ".E.BBB.B.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "..BSSB...",
            "...B.B...",
        ],
    ],
    "working": [
        [
            "..E...E..",
            ".EBBBBEB.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "..BSSB...",
            "..BB.B...",
        ],
        [
            "..E...E..",
            ".EBBBBEB.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "...BSSB..",
            "...B.BB..",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..#...#..",
            ".#BBBB#B.",
            ".BBBBBBB.",
            ".BAHHHAB.",
            "..BBBBB..",
            "..BBBBB..",
        ],
    ],
}

_FROG_ADULT = {
    "idle": [
        [
            "...E....E..",
            "..EBBBBBEB.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
        [
            "...E....E..",
            "..EBBBBBEB.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "..BBBBBB...",
            "..BBBBBB...",
            "....BSSB...",
            "...B..B....",
        ],
        [
            "...E....E..",
            "..EBBBBBEB.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
    ],
    "thinking": [
        [
            "...E....E..",
            "..E.BBBB.B.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
        [
            "...E....E.H",
            "..E.BBBB.B.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "...B..B....",
        ],
    ],
    "working": [
        [
            "...E....E..",
            "..EBBBBBEB.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "..BB..B....",
        ],
        [
            "...E....E..",
            "..EBBBBBEB.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...BSSBB...",
            "...B..BB...",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "...#....#..",
            "..#BBBBB#B.",
            "..BBBBBBB..",
            "..BAHHHHAB.",
            "...BBBBBB..",
            "...BBBBBB..",
            "...........",
        ],
    ],
}

# ── Egg (for intro sequence) ────────────────────────────────────────

EGG_FRAMES = [
    [
        "..###..",
        ".#BBB#.",
        "#BBBBB#",
        "#BBHBB#",
        "#BBBBB#",
        ".#BBB#.",
        "..###..",
    ],
    [
        "..###..",
        ".#BBB#.",
        "#BBHBB#",
        "#BBBBB#",
        "#BBHBB#",
        ".#BBB#.",
        "..###..",
    ],
]

# ── Master sprite dictionary ────────────────────────────────────────

SPRITES: dict[str, dict[str, dict[str, list[list[str]]]]] = {
    "fox": {
        "baby": _FOX_BABY,
        "juvenile": _FOX_JUVENILE,
        "adult": _FOX_ADULT,
    },
    "owl": {
        "baby": _OWL_BABY,
        "juvenile": _OWL_JUVENILE,
        "adult": _OWL_ADULT,
    },
    "cat": {
        "baby": _CAT_BABY,
        "juvenile": _CAT_JUVENILE,
        "adult": _CAT_ADULT,
    },
    "dragon": {
        "baby": _DRAGON_BABY,
        "juvenile": _DRAGON_JUVENILE,
        "adult": _DRAGON_ADULT,
    },
    "wolf": {
        "baby": _WOLF_BABY,
        "juvenile": _WOLF_JUVENILE,
        "adult": _WOLF_ADULT,
    },
    "frog": {
        "baby": _FROG_BABY,
        "juvenile": _FROG_JUVENILE,
        "adult": _FROG_ADULT,
    },
}


CUSTOM_SPRITES: dict[str, dict[str, dict[str, list[list[str]]]]] = {}


def register_custom_sprites(species_key: str, sprites_dict: dict) -> None:
    """Register custom sprites for a species."""
    CUSTOM_SPRITES[species_key] = sprites_dict


def get_sprite_frames(species: str, stage: str, activity: str) -> list[list[str]]:
    """Get sprite frames for a species/stage/activity combination.

    Falls back gracefully: unknown species -> fox, unknown stage -> baby,
    unknown activity -> idle.  Checks CUSTOM_SPRITES before built-in SPRITES.
    """
    all_sprites = {**SPRITES, **CUSTOM_SPRITES}
    sp = all_sprites.get(species, SPRITES["fox"])
    st = sp.get(stage, sp.get("baby", {}))
    frames = st.get(activity, st.get("idle", []))
    return frames if frames else SPRITES["fox"]["baby"]["idle"]
