"""
Test suite for HTtoHP package
"""

import pytest
import tempfile
import os
from HTtoHP import get_code, save_code_to_file, list_available_sets

class TestHTtoHP:
    """Test cases for HTtoHP"""
    
    def test_get_code_valid_inputs(self):
        """Test get_code with valid inputs"""
        # Test Python questions
        for set_num in range(1, 9):
            code = get_code(set_num, "python")
            assert isinstance(code, str)
            assert len(code) > 0
            assert f"SET {set_num}" in code
        
        # Test ML questions
        for set_num in range(1, 9):
            code = get_code(set_num, "ml")
            assert isinstance(code, str)
            assert len(code) > 0
            assert f"SET {set_num}" in code
    
    def test_get_code_invalid_set_number(self):
        """Test get_code with invalid set numbers"""
        with pytest.raises(ValueError, match="Invalid set number"):
            get_code(0, "python")
        
        with pytest.raises(ValueError, match="Invalid set number"):
            get_code(9, "ml")
        
        with pytest.raises(ValueError, match="Invalid set number"):
            get_code(-1, "python")
    
    def test_get_code_invalid_part(self):
        """Test get_code with invalid part parameter"""
        with pytest.raises(ValueError, match="Invalid part"):
            get_code(1, "invalid")
        
        with pytest.raises(ValueError, match="Invalid part"):
            get_code(1, "PYTHON")  # Case sensitive
    
    def test_get_code_case_insensitive_part(self):
        """Test that part parameter is case insensitive"""
        code1 = get_code(1, "python")
        code2 = get_code(1, "PYTHON")
        code3 = get_code(1, "Python")
        
        assert code1 == code2 == code3
        
        code1 = get_code(1, "ml")
        code2 = get_code(1, "ML")
        code3 = get_code(1, "Ml")
        
        assert code1 == code2 == code3
    
    def test_get_code_with_kwargs(self):
        """Test get_code with keyword arguments"""
        # Test with custom dataset name
        code = get_code(1, "ml", dataset_name="custom.csv")
        assert "custom.csv" in code
        
        # Test with custom value for SET 1 Python
        code = get_code(1, "python", value=99)
        assert "99" in code
    
    def test_save_code_to_file(self):
        """Test save_code_to_file functionality"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Test with auto-generated filename
            file_path = save_code_to_file(1, "python")
            assert os.path.exists(file_path)
            assert file_path.endswith("set1_python_code.py")
            
            # Clean up
            os.remove(file_path)
            
            # Test with custom filename
            custom_filename = os.path.join(temp_dir, "test_code.py")
            file_path = save_code_to_file(2, "ml", custom_filename)
            assert os.path.exists(file_path)
            assert file_path == os.path.abspath(custom_filename)
            
            # Verify file content
            with open(file_path, 'r') as f:
                content = f.read()
                assert "SET 2" in content
                assert len(content) > 0
    
    def test_list_available_sets(self):
        """Test list_available_sets functionality"""
        sets_info = list_available_sets()
        
        # Check return type
        assert isinstance(sets_info, dict)
        
        # Check all sets are present
        assert len(sets_info) == 8
        for i in range(1, 9):
            assert i in sets_info
        
        # Check descriptions are strings
        for description in sets_info.values():
            assert isinstance(description, str)
            assert len(description) > 0
    
    def test_code_content_quality(self):
        """Test that generated code has good quality"""
        # Test SET 1 ML code
        code = get_code(1, "ml")
        
        # Check for essential imports
        assert "import numpy as np" in code
        assert "import pandas as pd" in code
        assert "import matplotlib.pyplot as plt" in code
        assert "from sklearn" in code
        
        # Check for key ML concepts
        assert "LinearRegression" in code
        assert "train_test_split" in code
        assert "mean_squared_error" in code
        
        # Test SET 3 Python code
        code = get_code(3, "python")
        
        # Check for statistical functions
        assert "mean()" in code
        assert "median()" in code
        assert "std()" in code
        assert "boxplot" in code
    
    def test_all_sets_generate_successfully(self):
        """Test that all sets can generate code without errors"""
        for set_num in range(1, 9):
            # Test Python questions
            python_code = get_code(set_num, "python")
            assert len(python_code) > 100  # Reasonable minimum length
            
            # Test ML questions
            ml_code = get_code(set_num, "ml")
            assert len(ml_code) > 200  # ML code should be longer
    
    def test_dynamic_parameters(self):
        """Test dynamic parameter functionality"""
        # Test SET 1 with custom value
        code = get_code(1, "python", value=123)
        assert "123" in code
        
        # Test SET 2 with custom dataset
        code = get_code(2, "ml", dataset_name="test.csv", target_column="output")
        assert "test.csv" in code
        assert "output" in code
        
        # Test SET 5 with custom gradient descent parameters
        code = get_code(5, "ml", learning_rate=0.001, iterations=5000)
        assert "0.001" in code
        assert "5000" in code

if __name__ == "__main__":
    pytest.main([__file__])