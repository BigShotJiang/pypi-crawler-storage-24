"""
Setup script for ml_lab_generator package
"""

from setuptools import setup, find_packages

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="HTtoHP",
    version="1.0.0",
    author="ML Lab Generator Team",
    author_email="contact@mllabgenerator.com",
    description="A Python package that generates code templates for ML lab questions - HTtoHP",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/HTtoHP",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Education",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Education",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Code Generators",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    keywords="machine learning, code generator, education, templates, python, sklearn",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/HTtoHP/issues",
        "Source": "https://github.com/yourusername/HTtoHP",
        "Documentation": "https://github.com/yourusername/HTtoHP#readme",
    },
    include_package_data=True,
    zip_safe=False,
)