"""
Central loader module for ML Lab Code Generator
"""

import os
from typing import Optional

# Import all set modules
from . import set1, set2, set3, set4, set5, set6, set7, set8

# Mapping of set numbers to modules
SET_MODULES = {
    1: set1,
    2: set2,
    3: set3,
    4: set4,
    5: set5,
    6: set6,
    7: set7,
    8: set8
}

def get_code(set_number: int, part: str, **kwargs) -> str:
    """
    Get code template for a specific set and part.
    
    Args:
        set_number (int): Set number (1-8)
        part (str): Either "python" or "ml"
        **kwargs: Additional parameters for dynamic templates
        
    Returns:
        str: Generated code template
        
    Raises:
        ValueError: If set_number or part is invalid
    """
    if set_number not in SET_MODULES:
        raise ValueError(f"Invalid set number: {set_number}. Must be between 1 and 8.")
    
    if part.lower() not in ["python", "ml"]:
        raise ValueError(f"Invalid part: {part}. Must be 'python' or 'ml'.")
    
    module = SET_MODULES[set_number]
    
    if part.lower() == "python":
        return module.python_question(**kwargs)
    else:
        return module.ml_question(**kwargs)

def save_code_to_file(set_number: int, part: str, filename: Optional[str] = None, **kwargs) -> str:
    """
    Save generated code to a Python file.
    
    Args:
        set_number (int): Set number (1-8)
        part (str): Either "python" or "ml"
        filename (str, optional): Output filename. If None, auto-generates name.
        **kwargs: Additional parameters for dynamic templates
        
    Returns:
        str: Path to the saved file
    """
    code = get_code(set_number, part, **kwargs)
    
    if filename is None:
        filename = f"set{set_number}_{part.lower()}_code.py"
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(code)
    
    return os.path.abspath(filename)

def list_available_sets() -> dict:
    """
    List all available sets and their descriptions.
    
    Returns:
        dict: Dictionary with set numbers as keys and descriptions as values
    """
    descriptions = {
        1: "Python: 2D arrays and indexing | ML: Simple Linear Regression",
        2: "Python: 1D arrays and reversal | ML: Multiple Linear Regression", 
        3: "Python: Statistics and boxplots | ML: Binary Logistic Regression",
        4: "Python: Matrix operations | ML: Decision Tree",
        5: "Python: Matrix creation and slicing | ML: Gradient Descent for Linear Regression",
        6: "Python: DataFrame and missing values | ML: Logistic Regression",
        7: "Python: Line plots and labeling | ML: K-Nearest Neighbors (KNN)",
        8: "Python: Scatter plots and styling | ML: K-Means Clustering"
    }
    return descriptions