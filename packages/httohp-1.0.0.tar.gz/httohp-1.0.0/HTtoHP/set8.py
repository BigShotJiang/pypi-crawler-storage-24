"""
SET 8: Scatter Plots and K-Means Clustering
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 8 Python question.
    Creates scatter plots with styling.
    """
    code = '''# SET 8 - Python: Scatter Plot with Styling
import matplotlib.pyplot as plt
import numpy as np

# Create two arrays with 50 random numbers each
np.random.seed(42)  # For reproducible results
array1 = np.random.randn(50) * 10 + 20  # Mean=20, std=10
array2 = np.random.randn(50) * 8 + 15   # Mean=15, std=8

print("Array 1 statistics:")
print(f"Mean: {np.mean(array1):.2f}, Std: {np.std(array1):.2f}")
print("Array 2 statistics:")
print(f"Mean: {np.mean(array2):.2f}, Std: {np.std(array2):.2f}")

# Create scatter plot with various styling options
plt.figure(figsize=(15, 5))

# Plot 1: Basic scatter plot with color and size
plt.subplot(1, 3, 1)
plt.scatter(array1, array2, 
           c='blue',           # Color
           s=60,              # Size
           alpha=0.7,         # Transparency
           edgecolors='black', # Edge color
           linewidth=0.5)     # Edge width
plt.xlabel('Array 1 Values')
plt.ylabel('Array 2 Values')
plt.title('Basic Scatter Plot')
plt.grid(True, alpha=0.3)

# Plot 2: Scatter plot with color mapping
plt.subplot(1, 3, 2)
# Create color values based on distance from origin
colors = np.sqrt(array1**2 + array2**2)
scatter = plt.scatter(array1, array2, 
                     c=colors,          # Color mapping
                     s=80,              # Size
                     cmap='viridis',    # Color map
                     alpha=0.8,
                     edgecolors='white',
                     linewidth=1)
plt.colorbar(scatter, label='Distance from Origin')
plt.xlabel('Array 1 Values')
plt.ylabel('Array 2 Values')
plt.title('Color-Mapped Scatter Plot')
plt.grid(True, alpha=0.3)

# Plot 3: Scatter plot with varying sizes and multiple colors
plt.subplot(1, 3, 3)
# Create different groups
group1_mask = array1 > np.median(array1)
group2_mask = ~group1_mask

# Plot different groups with different colors and sizes
plt.scatter(array1[group1_mask], array2[group1_mask], 
           c='red', s=100, alpha=0.7, label='Group 1 (High Array1)', 
           marker='o', edgecolors='darkred')
plt.scatter(array1[group2_mask], array2[group2_mask], 
           c='green', s=60, alpha=0.7, label='Group 2 (Low Array1)', 
           marker='^', edgecolors='darkgreen')

plt.xlabel('Array 1 Values')
plt.ylabel('Array 2 Values')
plt.title('Multi-Group Scatter Plot')
plt.legend(loc='upper right', framealpha=0.9)
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# Advanced scatter plot with annotations
plt.figure(figsize=(10, 8))

# Create size array based on values
sizes = (array1 + array2) * 2  # Size based on sum of values
sizes = np.abs(sizes)  # Ensure positive sizes

# Create the scatter plot
scatter = plt.scatter(array1, array2, 
                     c=colors,              # Color by distance
                     s=sizes,               # Variable sizes
                     cmap='plasma',         # Different colormap
                     alpha=0.6,
                     edgecolors='black',
                     linewidth=0.5)

# Add colorbar
cbar = plt.colorbar(scatter)
cbar.set_label('Distance from Origin', rotation=270, labelpad=20)

# Add labels and title
plt.xlabel('Array 1 Values', fontsize=12, fontweight='bold')
plt.ylabel('Array 2 Values', fontsize=12, fontweight='bold')
plt.title('Advanced Scatter Plot\\nColor: Distance, Size: Sum of Values', 
          fontsize=14, fontweight='bold')

# Add grid and customize
plt.grid(True, alpha=0.3, linestyle='--')

# Add legend for size
sizes_legend = [50, 100, 150]
for size in sizes_legend:
    plt.scatter([], [], s=size, c='gray', alpha=0.6, 
               edgecolors='black', label=f'Size {size}')
plt.legend(title='Size Legend', loc='upper left', framealpha=0.9)

# Add statistics text box
stats_text = "Statistics:\\n"
stats_text += f"Array 1: μ={{np.mean(array1):.1f}}, σ={{np.std(array1):.1f}}\\n"
stats_text += f"Array 2: μ={{np.mean(array2):.1f}}, σ={{np.std(array2):.1f}}\\n"
stats_text += f"Correlation: {{np.corrcoef(array1, array2)[0,1]:.3f}}"

plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes, 
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

plt.tight_layout()
plt.show()

print("\\nCorrelation between arrays:", np.corrcoef(array1, array2)[0,1])
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 8 Machine Learning question.
    Implements K-Means Clustering.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    
    code = f'''# SET 8 - Machine Learning: K-Means Clustering
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import seaborn as sns

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data (assuming all columns are features for clustering)
X = df.select_dtypes(include=[np.number])  # Select only numeric columns

print("Dataset shape:", df.shape)
print("Features for clustering:", list(X.columns))
print("\\nFirst few rows:")
print(X.head())

# Scale the features (important for K-means)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Perform K-Means clustering with K=3
k = 3
print(f"\\nPerforming K-Means clustering with K={{k}}...")

kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(X_scaled)
centroids = kmeans.cluster_centers_

print(f"Clustering completed!")
print(f"Cluster centers shape: {{centroids.shape}}")

# Add cluster labels to the original dataframe
df_clustered = df.copy()
df_clustered['Cluster'] = cluster_labels

print(f"\\nCluster distribution:")
print(df_clustered['Cluster'].value_counts().sort_index())

# Calculate silhouette score
silhouette_avg = silhouette_score(X_scaled, cluster_labels)
print(f"\\nSilhouette Score: {{silhouette_avg:.4f}}")

# Plot clusters and centroids (for 2D visualization)
plt.figure(figsize=(15, 10))

if X.shape[1] >= 2:
    # Plot 1: Clusters with centroids (using first two features)
    plt.subplot(2, 2, 1)
    
    colors = ['red', 'blue', 'green', 'purple', 'orange']
    for i in range(k):
        cluster_points = X_scaled[cluster_labels == i]
        plt.scatter(cluster_points[:, 0], cluster_points[:, 1], 
                   c=colors[i], label=f'Cluster {{i}}', alpha=0.6, s=50)
    
    # Plot centroids
    plt.scatter(centroids[:, 0], centroids[:, 1], 
               c='black', marker='x', s=200, linewidths=3, label='Centroids')
    
    plt.xlabel(f'{{X.columns[0]}} (scaled)')
    plt.ylabel(f'{{X.columns[1]}} (scaled)')
    plt.title(f'K-Means Clustering (K={{{{k}}}})') 
    plt.legend()
    plt.grid(True, alpha=0.3)

# Plot 2: Elbow method to determine optimal K
plt.subplot(2, 2, 2)

k_range = range(1, 11)
inertias = []
silhouette_scores = []

for k_test in k_range:
    kmeans_test = KMeans(n_clusters=k_test, random_state=42, n_init=10)
    kmeans_test.fit(X_scaled)
    inertias.append(kmeans_test.inertia_)
    
    if k_test > 1:  # Silhouette score requires at least 2 clusters
        sil_score = silhouette_score(X_scaled, kmeans_test.labels_)
        silhouette_scores.append(sil_score)
    else:
        silhouette_scores.append(0)

plt.plot(k_range, inertias, 'bo-', linewidth=2, markersize=8)
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Inertia (Within-cluster sum of squares)')
plt.title('Elbow Method for Optimal K')
plt.grid(True, alpha=0.3)

# Mark the chosen K
plt.axvline(x=k, color='red', linestyle='--', alpha=0.7, label=f'Chosen K={{{{k}}}}')
plt.legend()

# Plot 3: Silhouette scores
plt.subplot(2, 2, 3)
plt.plot(k_range, silhouette_scores, 'go-', linewidth=2, markersize=8)
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score vs Number of Clusters')
plt.grid(True, alpha=0.3)
plt.axvline(x=k, color='red', linestyle='--', alpha=0.7, label=f'Chosen K={{{{k}}}}')
plt.legend()

# Plot 4: Cluster characteristics
plt.subplot(2, 2, 4)
cluster_means = df_clustered.groupby('Cluster')[X.columns].mean()

# Heatmap of cluster characteristics
sns.heatmap(cluster_means.T, annot=True, cmap='viridis', 
           xticklabels=[f'Cluster {{i}}' for i in range(k)],
           yticklabels=X.columns)
plt.title('Cluster Characteristics\\n(Mean values for each feature)')

plt.tight_layout()
plt.show()

# Interpret clustering results
print(f"\\nClustering Results Interpretation:")
print(f"="*50)

# Find optimal K from elbow method
inertia_diffs = [inertias[i-1] - inertias[i] for i in range(1, len(inertias))]
elbow_k = inertia_diffs.index(max(inertia_diffs[:5])) + 2  # +2 because we start from K=2

print(f"Suggested optimal K from elbow method: {{elbow_k}}")

# Find optimal K from silhouette score
best_sil_k = silhouette_scores.index(max(silhouette_scores[1:])) + 1  # +1 for 0-indexing
print(f"Optimal K from silhouette score: {{best_sil_k + 1}}")

print(f"\\nChosen K={{k}} analysis:")
if silhouette_avg > 0.5:
    print("✓ Good clustering structure (Silhouette > 0.5)")
elif silhouette_avg > 0.25:
    print("⚠ Moderate clustering structure (0.25 < Silhouette ≤ 0.5)")
else:
    print("⚠ Weak clustering structure (Silhouette ≤ 0.25)")

# Cluster summary statistics
print(f"\\nCluster Summary:")
for i in range(k):
    cluster_data = df_clustered[df_clustered['Cluster'] == i]
    print(f"\\nCluster {{i}} ({{len(cluster_data)}} points):")
    for col in X.columns[:3]:  # Show first 3 features
        mean_val = cluster_data[col].mean()
        print(f"  {{col}}: {{mean_val:.2f}}")

# Distance between centroids
print(f"\\nCentroid distances:")
from scipy.spatial.distance import pdist, squareform
centroid_distances = squareform(pdist(centroids))
for i in range(k):
    for j in range(i+1, k):
        print(f"Cluster {{i}} ↔ Cluster {{j}}: {{centroid_distances[i,j]:.3f}}")
'''
    return code