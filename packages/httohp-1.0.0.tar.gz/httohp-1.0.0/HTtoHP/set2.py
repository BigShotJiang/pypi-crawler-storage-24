"""
SET 2: 1D Arrays and Multiple Linear Regression
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 2 Python question.
    Creates and reverses a vowels array.
    """
    code = '''# SET 2 - Python: 1D Array of Vowels and Reversal
import numpy as np

# Create a 1D array of vowels
vowels = ['a', 'e', 'i', 'o', 'u']
print("Original vowels array:", vowels)

# Method 1: Reverse using slicing
vowels_reversed_slice = vowels[::-1]
print("Reversed vowels (slicing):", vowels_reversed_slice)

# Method 2: Reverse using built-in reverse() method
vowels_copy = vowels.copy()
vowels_copy.reverse()
print("Reversed vowels (reverse method):", vowels_copy)

# Method 3: Using NumPy
vowels_np = np.array(vowels)
vowels_np_reversed = np.flip(vowels_np)
print("Reversed vowels (NumPy flip):", vowels_np_reversed)
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 2 Machine Learning question.
    Implements Multiple Linear Regression.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    target_column = kwargs.get('target_column', 'target')
    
    code = f'''# SET 2 - Machine Learning: Multiple Linear Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df.drop('{target_column}', axis=1)  # Features
y = df['{target_column}']               # Target

print("Dataset shape:", df.shape)
print("Features:", list(X.columns))

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Print coefficients and intercept
print("\\nModel Parameters:")
print(f"Intercept: {{{{model.intercept_:.4f}}}}")
print("Coefficients:")
for i, coef in enumerate(model.coef_):
    print(f"  {{{{X.columns[i]}}}}: {{{{coef:.4f}}}}")

# Make predictions and calculate R² score
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
print(f"\\nR² Score: {{{{r2:.4f}}}}")

# Predict with new data
new_data = [[1, 2, 3]]  # Replace with actual values
prediction = model.predict(new_data)
print(f"Prediction for new data: {{{{prediction[0]:.4f}}}}")

# Visualize actual vs predicted values
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred, alpha=0.6)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Multiple Linear Regression: Actual vs Predicted')
plt.grid(True, alpha=0.3)
plt.show()
'''
    return code