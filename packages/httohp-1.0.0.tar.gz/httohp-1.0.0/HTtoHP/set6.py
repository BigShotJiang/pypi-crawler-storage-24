"""
SET 6: DataFrame Operations and Logistic Regression
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 6 Python question.
    DataFrame with missing values handling.
    """
    code = '''# SET 6 - Python: DataFrame with Missing Values
import pandas as pd
import numpy as np

# Create a DataFrame with missing values
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve'],
    'Age': [25, np.nan, 30, 28, np.nan],
    'Salary': [50000, 60000, np.nan, 55000, 65000],
    'Department': ['IT', 'HR', 'IT', np.nan, 'Finance']
}

df = pd.DataFrame(data)
print("Original DataFrame with missing values:")
print(df)
print("\\nMissing values info:")
print(df.isnull().sum())

# Method 1: Replace missing values with the mean of each column
df_mean_filled = df.copy()

# Fill numeric columns with mean
numeric_columns = df.select_dtypes(include=[np.number]).columns
for col in numeric_columns:
    mean_value = df[col].mean()
    df_mean_filled[col].fillna(mean_value, inplace=True)
    print(f"\\nMean of {col}: {mean_value:.2f}")

print("\\nDataFrame after replacing missing values with mean:")
print(df_mean_filled)

# Method 2: Drop rows that contain missing values
df_dropped = df.dropna()
print("\\nDataFrame after dropping rows with missing values:")
print(df_dropped)

# Additional methods for handling missing values
print("\\nAdditional methods:")

# Fill with forward fill
df_ffill = df.fillna(method='ffill')
print("\\nForward fill:")
print(df_ffill)

# Fill with specific values
df_custom_fill = df.fillna({
    'Age': df['Age'].median(),
    'Salary': df['Salary'].mean(),
    'Department': 'Unknown'
})
print("\\nCustom fill (median for Age, mean for Salary, 'Unknown' for Department):")
print(df_custom_fill)

# Statistics before and after handling missing values
print("\\nComparison of statistics:")
print("Original data statistics:")
print(df.describe())
print("\\nAfter mean imputation:")
print(df_mean_filled.describe())
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 6 Machine Learning question.
    Implements Logistic Regression with sigmoid visualization.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    target_column = kwargs.get('target_column', 'target')
    
    code = f'''# SET 6 - Machine Learning: Logistic Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, classification_report
from sklearn.preprocessing import StandardScaler

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df.drop('{target_column}', axis=1)  # Features
y = df['{target_column}']               # Target (binary: 0 or 1)

print("Dataset shape:", df.shape)
print("Target distribution:")
print(y.value_counts())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create and train the logistic regression model
model = LogisticRegression(random_state=42)
model.fit(X_train_scaled, y_train)

print("\\nLogistic Regression Training Completed!")
print(f"Model coefficients: {{model.coef_[0]}}")
print(f"Model intercept: {{model.intercept_[0]:.4f}}")

# Make predictions
y_pred = model.predict(X_test_scaled)
y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]

# Calculate metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)

print(f"\\nModel Performance:")
print(f"Accuracy: {{accuracy:.4f}}")
print(f"Precision: {{precision:.4f}}")
print(f"Recall: {{recall:.4f}}")

# Plot the Sigmoid function
def sigmoid(z):
    """Sigmoid activation function"""
    return 1 / (1 + np.exp(-np.clip(z, -500, 500)))  # Clip to prevent overflow

# Create range for sigmoid plot
z = np.linspace(-10, 10, 100)
sigmoid_values = sigmoid(z)

plt.figure(figsize=(15, 5))

# Plot 1: Sigmoid Function
plt.subplot(1, 3, 1)
plt.plot(z, sigmoid_values, 'b-', linewidth=2)
plt.axhline(y=0.5, color='r', linestyle='--', alpha=0.7, label='Decision boundary (0.5)')
plt.axvline(x=0, color='k', linestyle='-', alpha=0.3)
plt.xlabel('z (linear combination)')
plt.ylabel('σ(z) = 1/(1+e^(-z))')
plt.title('Sigmoid Function')
plt.grid(True, alpha=0.3)
plt.legend()

# Plot 2: Prediction Probabilities
plt.subplot(1, 3, 2)
plt.hist(y_pred_proba[y_test == 0], bins=20, alpha=0.7, label='Class 0', color='red')
plt.hist(y_pred_proba[y_test == 1], bins=20, alpha=0.7, label='Class 1', color='blue')
plt.axvline(x=0.5, color='k', linestyle='--', label='Decision threshold')
plt.xlabel('Predicted Probability')
plt.ylabel('Frequency')
plt.title('Distribution of Predicted Probabilities')
plt.legend()

# Plot 3: ROC-like visualization
plt.subplot(1, 3, 3)
thresholds = np.linspace(0, 1, 100)
precisions = []
recalls = []

for threshold in thresholds:
    y_pred_thresh = (y_pred_proba >= threshold).astype(int)
    if len(np.unique(y_pred_thresh)) > 1:
        prec = precision_score(y_test, y_pred_thresh)
        rec = recall_score(y_test, y_pred_thresh)
    else:
        prec = 0 if threshold > 0.5 else 1
        rec = 0 if threshold > 0.5 else 1
    precisions.append(prec)
    recalls.append(rec)

plt.plot(recalls, precisions, 'g-', linewidth=2)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# Detailed classification report
print("\\nDetailed Classification Report:")
print(classification_report(y_test, y_pred))

# Example prediction with probability
print("\\nExample Predictions:")
for i in range(min(5, len(X_test))):
    prob = y_pred_proba[i]
    pred = y_pred[i]
    actual = y_test.iloc[i]
    print(f"Sample {{i+1}}: Probability={{prob:.3f}}, Predicted={{pred}}, Actual={{actual}}")
'''
    return code