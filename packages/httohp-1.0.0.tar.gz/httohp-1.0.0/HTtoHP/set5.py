"""
SET 5: Matrix Creation and Gradient Descent
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 5 Python question.
    Matrix creation and sub-matrix extraction.
    """
    code = '''# SET 5 - Python: 5x5 Matrix and Sub-matrix Extraction
import numpy as np

# Create a 5x5 matrix filled with numbers 1 to 25
matrix_5x5 = np.arange(1, 26).reshape(5, 5)

print("5x5 Matrix filled with numbers 1 to 25:")
print(matrix_5x5)

# Extract the 3x3 middle sub-matrix (elements 7-9, 12-14, 17-19)
# These correspond to rows 1-3 and columns 1-3 (0-indexed)
middle_submatrix = matrix_5x5[1:4, 1:4]

print("\\n3x3 Middle Sub-matrix (elements 7-9, 12-14, 17-19):")
print(middle_submatrix)

# Alternative method: explicit indexing
print("\\nAlternative extraction method:")
sub_matrix_alt = matrix_5x5[np.ix_([1, 2, 3], [1, 2, 3])]
print(sub_matrix_alt)

# Verify the elements
print("\\nVerification - Elements in the sub-matrix:")
print("Row 1:", [7, 8, 9])
print("Row 2:", [12, 13, 14])
print("Row 3:", [17, 18, 19])

# Display matrix with indices for clarity
print("\\nOriginal matrix with position labels:")
for i in range(5):
    for j in range(5):
        print(f"{matrix_5x5[i,j]:2d}({i},{j})", end="  ")
    print()
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 5 Machine Learning question.
    Implements Gradient Descent for Linear Regression.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    learning_rate = kwargs.get('learning_rate', 0.01)
    iterations = kwargs.get('iterations', 1000)
    
    code = f'''# SET 5 - Machine Learning: Gradient Descent for Linear Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data (assuming simple linear regression with one feature)
X = df.iloc[:, 0].values.reshape(-1, 1)  # First column as feature
y = df.iloc[:, 1].values                 # Second column as target

# Normalize the features
X_mean = np.mean(X)
X_std = np.std(X)
X_normalized = (X - X_mean) / X_std

# Add bias term (intercept)
X_with_bias = np.c_[np.ones(X_normalized.shape[0]), X_normalized]

# Initialize parameters
theta = np.random.randn(2, 1) * 0.01  # [bias, weight]
m = len(y)
learning_rate = {learning_rate}
iterations = {iterations}

# Store cost history
cost_history = []

def compute_cost(X, y, theta):
    """Compute the cost function (Mean Squared Error)"""
    predictions = X.dot(theta)
    cost = (1 / (2 * m)) * np.sum((predictions - y.reshape(-1, 1)) ** 2)
    return cost

def gradient_descent(X, y, theta, learning_rate, iterations):
    """Implement gradient descent algorithm"""
    cost_history = []
    
    for i in range(iterations):
        # Forward propagation
        predictions = X.dot(theta)
        
        # Compute cost
        cost = compute_cost(X, y, theta)
        cost_history.append(cost)
        
        # Compute gradients
        gradients = (1 / m) * X.T.dot(predictions - y.reshape(-1, 1))
        
        # Update parameters (gradient descent step)
        theta = theta - learning_rate * gradients
        
        # Print cost every 100 iterations
        if i % 100 == 0:
            print(f"Cost after iteration {{i}}: {{cost:.6f}}")
    
    return theta, cost_history

print("Starting Gradient Descent...")
print(f"Learning rate: {{learning_rate}}")
print(f"Number of iterations: {{iterations}}")

# Run gradient descent
final_theta, cost_history = gradient_descent(X_with_bias, y, theta, learning_rate, iterations)

print(f"\\nFinal parameters:")
print(f"Bias (θ₀): {{final_theta[0][0]:.6f}}")
print(f"Weight (θ₁): {{final_theta[1][0]:.6f}}")

# Plot cost vs iterations
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(cost_history)
plt.title('Cost vs Number of Iterations')
plt.xlabel('Iterations')
plt.ylabel('Cost (MSE)')
plt.grid(True, alpha=0.3)

# Check convergence
final_costs = cost_history[-50:]  # Last 50 iterations
cost_change = abs(final_costs[-1] - final_costs[0])
print(f"\\nConvergence Analysis:")
print(f"Cost change in last 50 iterations: {{cost_change:.8f}}")

if cost_change < 1e-6:
    print("✓ Algorithm has converged (cost change < 1e-6)")
else:
    print("⚠ Algorithm may not have fully converged")
    print("Consider increasing iterations or adjusting learning rate")

# Plot the regression line
plt.subplot(1, 2, 2)
plt.scatter(X_normalized, y, alpha=0.6, label='Data points')

# Generate predictions for plotting
X_plot = np.linspace(X_normalized.min(), X_normalized.max(), 100).reshape(-1, 1)
X_plot_with_bias = np.c_[np.ones(X_plot.shape[0]), X_plot]
y_plot = X_plot_with_bias.dot(final_theta)

plt.plot(X_plot, y_plot, 'r-', linewidth=2, label='Regression line')
plt.xlabel('Normalized Feature')
plt.ylabel('Target')
plt.title('Linear Regression with Gradient Descent')
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# Final cost
final_cost = cost_history[-1]
print(f"\\nFinal cost (MSE): {{final_cost:.6f}}")
'''
    return code