"""
SET 7: Line Plots and K-Nearest Neighbors
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 7 Python question.
    Creates line plots with labels and titles.
    """
    code = '''# SET 7 - Python: Line Plot with Labels and Title
import matplotlib.pyplot as plt
import numpy as np

# Generate sample data
x = np.linspace(0, 10, 50)
y1 = np.sin(x)
y2 = np.cos(x)
y3 = np.sin(x) * np.cos(x)

# Create the line plot
plt.figure(figsize=(12, 8))

# Plot multiple lines
plt.plot(x, y1, 'b-', linewidth=2, label='sin(x)', marker='o', markersize=4)
plt.plot(x, y2, 'r--', linewidth=2, label='cos(x)', marker='s', markersize=4)
plt.plot(x, y3, 'g:', linewidth=2, label='sin(x)cos(x)', marker='^', markersize=4)

# Add labels and title
plt.xlabel('X-axis (Radians)', fontsize=12, fontweight='bold')
plt.ylabel('Y-axis (Function Values)', fontsize=12, fontweight='bold')
plt.title('Trigonometric Functions Comparison', fontsize=14, fontweight='bold', pad=20)

# Add grid for better readability
plt.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)

# Add legend
plt.legend(loc='upper right', fontsize=10, framealpha=0.9)

# Customize the plot appearance
plt.xlim(0, 10)
plt.ylim(-1.5, 1.5)

# Add annotations
plt.annotate('Maximum of sin(x)', xy=(np.pi/2, 1), xytext=(2, 1.3),
            arrowprops=dict(arrowstyle='->', color='blue', alpha=0.7),
            fontsize=10, color='blue')

# Show the plot
plt.tight_layout()
plt.show()

# Alternative: Simple line plot example
print("\\nSimple line plot example:")
plt.figure(figsize=(10, 6))

# Simple data
days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
temperature = [22, 25, 23, 26, 24, 28, 27]

plt.plot(days, temperature, 'ro-', linewidth=2, markersize=8)
plt.xlabel('Days of the Week')
plt.ylabel('Temperature (°C)')
plt.title('Weekly Temperature Variation')
plt.grid(True, alpha=0.3)
plt.show()
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 7 Machine Learning question.
    Implements K-Nearest Neighbors classifier.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    target_column = kwargs.get('target_column', 'target')
    
    code = f'''# SET 7 - Machine Learning: K-Nearest Neighbors (KNN)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
import seaborn as sns

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df.drop('{target_column}', axis=1)  # Features
y = df['{target_column}']               # Target

print("Dataset shape:", df.shape)
print("Features:", list(X.columns))
print("Target classes:", y.unique())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the features (important for KNN)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train models with K=3 and K=5
k_values = [3, 5]
models = {{}}
accuracies = {{}}

for k in k_values:
    print(f"\\nTraining KNN with K={{k}}...")
    
    # Create and train the model
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train_scaled, y_train)
    
    # Make predictions
    y_pred = knn.predict(X_test_scaled)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    
    # Store results
    models[k] = knn
    accuracies[k] = accuracy
    
    print(f"Accuracy with K={{k}}: {{{{accuracy:.4f}}}}")
    
    # Print classification report
    print(f"\\nClassification Report for K={{k}}:")
    print(classification_report(y_test, y_pred))

# Compare accuracies
print(f"\\nAccuracy Comparison:")
for k in k_values:
    print(f"K={{k}}: {{{{accuracies[k]:.4f}}}}")

# Determine which K performs better
best_k = max(accuracies, key=accuracies.get)
print(f"\\nBest performing K: {{{{best_k}}}} with accuracy {{{{accuracies[best_k]:.4f}}}}")

# Plot accuracy comparison
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.bar([f'K={{k}}' for k in k_values], [accuracies[k] for k in k_values], 
        color=['skyblue', 'lightcoral'])
plt.ylabel('Accuracy')
plt.title('KNN Accuracy Comparison')
plt.ylim(0, 1)
for i, k in enumerate(k_values):
    plt.text(i, accuracies[k] + 0.01, f'{{{{accuracies[k]:.3f}}}}', 
             ha='center', va='bottom', fontweight='bold')

# Plot classification results for the best K (if 2D data)
if X.shape[1] == 2:
    plt.subplot(1, 3, 2)
    
    # Create a mesh for decision boundary
    h = 0.02
    x_min, x_max = X_train_scaled[:, 0].min() - 1, X_train_scaled[:, 0].max() + 1
    y_min, y_max = X_train_scaled[:, 1].min() - 1, X_train_scaled[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    
    # Make predictions on the mesh
    Z = models[best_k].predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot decision boundary
    plt.contourf(xx, yy, Z, alpha=0.8, cmap=plt.cm.RdYlBu)
    
    # Plot training points
    scatter = plt.scatter(X_train_scaled[:, 0], X_train_scaled[:, 1], 
                         c=y_train, cmap=plt.cm.RdYlBu, edgecolors='black')
    plt.colorbar(scatter)
    plt.title(f'KNN Classification (K={{{{best_k}}}})') 
    plt.xlabel('Feature 1 (scaled)')
    plt.ylabel('Feature 2 (scaled)')

# Test different K values to find optimal
plt.subplot(1, 3, 3)
k_range = range(1, 21)
test_accuracies = []

for k in k_range:
    knn_temp = KNeighborsClassifier(n_neighbors=k)
    knn_temp.fit(X_train_scaled, y_train)
    y_pred_temp = knn_temp.predict(X_test_scaled)
    test_accuracies.append(accuracy_score(y_test, y_pred_temp))

plt.plot(k_range, test_accuracies, 'bo-', linewidth=2, markersize=6)
plt.xlabel('K Value')
plt.ylabel('Test Accuracy')
plt.title('KNN Accuracy vs K Value')
plt.grid(True, alpha=0.3)

# Mark the best K values we tested
for k in k_values:
    idx = k - 1
    plt.plot(k, test_accuracies[idx], 'ro', markersize=10, alpha=0.7)
    plt.annotate(f'K={{{{k}}}}\\nAcc={{{{test_accuracies[idx]:.3f}}}}', 
                xy=(k, test_accuracies[idx]), xytext=(k, test_accuracies[idx] + 0.02),
                ha='center', fontsize=9, color='red')

plt.tight_layout()
plt.show()

# Explanation of K performance
print(f"\\nPerformance Analysis:")
print(f"K=3 achieved {{{{accuracies[3]:.4f}}}} accuracy")
print(f"K=5 achieved {{{{accuracies[5]:.4f}}}} accuracy")

if accuracies[3] > accuracies[5]:
    print("\\nK=3 performs better than K=5.")
    print("Smaller K values can capture more local patterns but may be sensitive to noise.")
elif accuracies[5] > accuracies[3]:
    print("\\nK=5 performs better than K=3.")
    print("Larger K values provide smoother decision boundaries and better generalization.")
else:
    print("\\nBoth K values perform equally well.")

print("\\nGeneral KNN Guidelines:")
print("- Smaller K: More sensitive to local patterns, may overfit")
print("- Larger K: Smoother decision boundaries, may underfit")
print("- Odd K values help avoid ties in binary classification")
'''
    return code