"""
SET 4: Matrix Operations and Decision Tree
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 4 Python question.
    Matrix rank and determinant operations.
    """
    code = '''# SET 4 - Python: Matrix Rank and Determinant
import numpy as np

# Create sample matrices for demonstration
matrix_a = np.array([[1, 2, 3],
                     [4, 5, 6],
                     [7, 8, 9]])

matrix_b = np.array([[2, 1],
                     [1, 2]])

matrix_c = np.array([[1, 2, 3],
                     [0, 1, 4],
                     [5, 6, 0]])

print("Matrix A:")
print(matrix_a)
print("Matrix B:")
print(matrix_b)
print("Matrix C:")
print(matrix_c)

# Find the rank of matrices
rank_a = np.linalg.matrix_rank(matrix_a)
rank_b = np.linalg.matrix_rank(matrix_b)
rank_c = np.linalg.matrix_rank(matrix_c)

print(f"\\nRank of Matrix A: {rank_a}")
print(f"Rank of Matrix B: {rank_b}")
print(f"Rank of Matrix C: {rank_c}")

# Find the determinant of square matrices
det_a = np.linalg.det(matrix_a)
det_b = np.linalg.det(matrix_b)
det_c = np.linalg.det(matrix_c)

print(f"\\nDeterminant of Matrix A: {det_a:.4f}")
print(f"Determinant of Matrix B: {det_b:.4f}")
print(f"Determinant of Matrix C: {det_c:.4f}")

# Additional matrix properties
print("\\nAdditional Matrix Properties:")
print(f"Matrix A is singular: {abs(det_a) < 1e-10}")
print(f"Matrix B is singular: {abs(det_b) < 1e-10}")
print(f"Matrix C is singular: {abs(det_c) < 1e-10}")

# Example with user input matrix
print("\\nExample with custom matrix:")
custom_matrix = np.array([[4, 7],
                          [2, 6]])
print("Custom Matrix:")
print(custom_matrix)
print(f"Rank: {np.linalg.matrix_rank(custom_matrix)}")
print(f"Determinant: {np.linalg.det(custom_matrix):.4f}")
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 4 Machine Learning question.
    Implements Decision Tree classifier.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    target_column = kwargs.get('target_column', 'target')
    
    code = f'''# SET 4 - Machine Learning: Decision Tree Classifier
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df.drop('{target_column}', axis=1)  # Features
y = df['{target_column}']               # Target

print("Dataset shape:", df.shape)
print("Features:", list(X.columns))
print("Target classes:", y.unique())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the Decision Tree
dt_model = DecisionTreeClassifier(
    random_state=42,
    max_depth=5,  # Limit depth to prevent overfitting
    min_samples_split=10,
    min_samples_leaf=5
)

dt_model.fit(X_train, y_train)

print("\\nDecision Tree Training Completed!")

# Make predictions
y_pred = dt_model.predict(X_test)

# Calculate accuracy score
accuracy = accuracy_score(y_test, y_pred)
print(f"\\nAccuracy Score: {{accuracy:.4f}}")

# Plot the Decision Tree
plt.figure(figsize=(20, 10))
plot_tree(dt_model, 
          feature_names=X.columns,
          class_names=[str(cls) for cls in dt_model.classes_],
          filled=True,
          rounded=True,
          fontsize=10)
plt.title('Decision Tree Visualization')
plt.show()

# Feature importance
feature_importance = dt_model.feature_importances_
feature_names = X.columns

plt.figure(figsize=(10, 6))
indices = np.argsort(feature_importance)[::-1]
plt.bar(range(len(feature_importance)), feature_importance[indices])
plt.xticks(range(len(feature_importance)), [feature_names[i] for i in indices], rotation=45)
plt.title('Feature Importance in Decision Tree')
plt.xlabel('Features')
plt.ylabel('Importance')
plt.tight_layout()
plt.show()

# Print classification report
print("\\nClassification Report:")
print(classification_report(y_test, y_pred))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()

# Predict class for new input
print("\\nPrediction for new input:")
# Example new input (replace with actual values)
new_input = [[5.1, 3.5, 1.4, 0.2]]  # Replace with appropriate feature values
prediction = dt_model.predict(new_input)
prediction_proba = dt_model.predict_proba(new_input)

print(f"New input: {{new_input[0]}}")
print(f"Predicted class: {{prediction[0]}}")
print(f"Prediction probabilities: {{prediction_proba[0]}}")
'''
    return code