"""
SET 1: 2D Arrays and Simple Linear Regression
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 1 Python question.
    Creates a 2D array and displays specific elements.
    """
    value = kwargs.get('value', 42)  # Default value for the third row
    
    code = f'''# SET 1 - Python: 2D Array Creation and Indexing
import numpy as np

# Create a nested Python list to represent a 2D array
myarray1 = [
    [2.7, -2, 19],
    [0, 3.4, 99.9],
    [10.6, 0.13, {value}]
]

print("Original 2D array:")
for i, row in enumerate(myarray1):
    print(f"Row {{i+1}}: {{row}}")

# Display elements in the 1st column of the 2nd and 3rd rows
print("\\nElements in 1st column of 2nd and 3rd rows:")
print(f"2nd row, 1st column: {{myarray1[1][0]}}")
print(f"3rd row, 1st column: {{myarray1[2][0]}}")

# Alternative using numpy for better array operations
myarray1_np = np.array(myarray1)
print("\\nUsing NumPy array:")
print("1st column of 2nd and 3rd rows:", myarray1_np[1:3, 0])
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 1 Machine Learning question.
    Implements Simple Linear Regression.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    x_column = kwargs.get('x_column', 'X')
    y_column = kwargs.get('y_column', 'y')
    
    code = f'''# SET 1 - Machine Learning: Simple Linear Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Load the dataset
# Replace '{dataset_name}' with your actual dataset file
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df[['{x_column}']].values  # Feature (independent variable)
y = df['{y_column}'].values    # Target (dependent variable)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

print("Model Training Completed!")
print(f"Coefficient (slope): {{model.coef_[0]:.4f}}")
print(f"Intercept: {{model.intercept_:.4f}}")

# Make predictions
y_pred = model.predict(X_test)

# Calculate Mean Squared Error (MSE)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\\nModel Performance:")
print(f"Mean Squared Error (MSE): {{mse:.4f}}")
print(f"R² Score: {{r2:.4f}}")

# Plot the data points and regression line
plt.figure(figsize=(10, 6))
plt.scatter(X_test, y_test, color='blue', alpha=0.6, label='Actual Data')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Regression Line')
plt.xlabel('{x_column}')
plt.ylabel('{y_column}')
plt.title('Simple Linear Regression')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# Interpret the model fit
print(f"\\nModel Interpretation:")
if r2 > 0.8:
    print("The model shows a strong fit to the data (R² > 0.8)")
elif r2 > 0.6:
    print("The model shows a moderate fit to the data (0.6 < R² ≤ 0.8)")
else:
    print("The model shows a weak fit to the data (R² ≤ 0.6)")
    print("Consider feature engineering or a different model.")
'''
    return code