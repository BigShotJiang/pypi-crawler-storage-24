"""
SET 3: Statistics and Binary Logistic Regression
"""

def python_question(**kwargs):
    """
    Returns Python code for SET 3 Python question.
    Calculates statistics and creates boxplots.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    
    code = f'''# SET 3 - Python: Statistics and Boxplots
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Assuming the dataset has 'age' and 'fat' columns
# Replace with actual column names if different
age_col = 'age'
fat_col = 'fat'

# Calculate mean, median, and standard deviation
print("Statistics for Age:")
print(f"Mean: {{df[age_col].mean():.2f}}")
print(f"Median: {{df[age_col].median():.2f}}")
print(f"Standard Deviation: {{df[age_col].std():.2f}}")

print("\\nStatistics for Fat:")
print(f"Mean: {{df[fat_col].mean():.2f}}")
print(f"Median: {{df[fat_col].median():.2f}}")
print(f"Standard Deviation: {{df[fat_col].std():.2f}}")

# Create boxplots
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Boxplot for age
axes[0].boxplot(df[age_col].dropna())
axes[0].set_title('Boxplot of Age')
axes[0].set_ylabel('Age')

# Boxplot for fat
axes[1].boxplot(df[fat_col].dropna())
axes[1].set_title('Boxplot of Fat')
axes[1].set_ylabel('Fat')

plt.tight_layout()
plt.show()

# Alternative using seaborn for better visualization
plt.figure(figsize=(10, 6))
data_to_plot = [df[age_col].dropna(), df[fat_col].dropna()]
plt.boxplot(data_to_plot, labels=['Age', 'Fat'])
plt.title('Boxplots of Age and Fat')
plt.ylabel('Values')
plt.grid(True, alpha=0.3)
plt.show()
'''
    return code

def ml_question(**kwargs):
    """
    Returns ML code for SET 3 Machine Learning question.
    Implements Binary Logistic Regression.
    """
    dataset_name = kwargs.get('dataset_name', 'your_dataset.csv')
    target_column = kwargs.get('target_column', 'target')
    
    code = f'''# SET 3 - Machine Learning: Binary Logistic Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler
import seaborn as sns

# Load the dataset
df = pd.read_csv('{dataset_name}')

# Prepare the data
X = df.drop('{target_column}', axis=1)  # Features
y = df['{target_column}']               # Target (binary: 0 or 1)

print("Dataset shape:", df.shape)
print("Target distribution:")
print(y.value_counts())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create and train the logistic regression model
model = LogisticRegression(random_state=42)
model.fit(X_train_scaled, y_train)

print("\\nModel Training Completed!")

# Make predictions
y_pred = model.predict(X_test_scaled)
y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]

# Print confusion matrix and accuracy
cm = confusion_matrix(y_test, y_pred)
accuracy = accuracy_score(y_test, y_pred)

print(f"\\nAccuracy Score: {{accuracy:.4f}}")
print("\\nConfusion Matrix:")
print(cm)

# Visualize confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Class 0', 'Class 1'], 
            yticklabels=['Class 0', 'Class 1'])
plt.title('Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()

# Plot decision boundary (for 2D data)
if X.shape[1] == 2:
    plt.figure(figsize=(10, 8))
    
    # Create a mesh
    h = 0.02
    x_min, x_max = X_train_scaled[:, 0].min() - 1, X_train_scaled[:, 0].max() + 1
    y_min, y_max = X_train_scaled[:, 1].min() - 1, X_train_scaled[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    
    # Make predictions on the mesh
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot the decision boundary
    plt.contourf(xx, yy, Z, alpha=0.8, cmap=plt.cm.RdYlBu)
    
    # Plot the data points
    scatter = plt.scatter(X_train_scaled[:, 0], X_train_scaled[:, 1], 
                         c=y_train, cmap=plt.cm.RdYlBu, edgecolors='black')
    plt.colorbar(scatter)
    plt.title('Logistic Regression Decision Boundary')
    plt.xlabel('Feature 1 (scaled)')
    plt.ylabel('Feature 2 (scaled)')
    plt.show()

# Print classification report
print("\\nClassification Report:")
print(classification_report(y_test, y_pred))
'''
    return code