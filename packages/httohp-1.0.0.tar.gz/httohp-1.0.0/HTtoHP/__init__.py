"""
HTtoHP - ML Lab Code Generator

A Python package that generates code templates for ML lab questions.
This package does NOT execute ML code, but returns Python/ML code as output.
"""

from .loader import get_code, save_code_to_file, list_available_sets

__version__ = "1.0.0"
__author__ = "HTtoHP Team"
__email__ = "contact@httohp.com"

__all__ = ["get_code", "save_code_to_file", "list_available_sets"]