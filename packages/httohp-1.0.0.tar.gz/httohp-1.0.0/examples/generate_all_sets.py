"""
Generate code files for all sets (both Python and ML questions)
"""

import HTtoHP
import os

def generate_all_sets():
    """Generate code files for all 8 sets"""
    
    # Create output directory
    output_dir = "generated_codes"
    os.makedirs(output_dir, exist_ok=True)
    
    print("=== Generating All HTtoHP Code Sets ===\n")
    
    # Generate Python questions for all sets
    print("Generating Python questions:")
    print("-" * 40)
    for set_num in range(1, 9):
        try:
            filename = os.path.join(output_dir, f"set{set_num}_python.py")
            HTtoHP.save_code_to_file(set_num, "python", filename)
            print(f"✓ SET {set_num} Python code -> {filename}")
        except Exception as e:
            print(f"✗ Error generating SET {set_num} Python: {e}")
    
    print()
    
    # Generate ML questions for all sets
    print("Generating ML questions:")
    print("-" * 40)
    for set_num in range(1, 9):
        try:
            filename = os.path.join(output_dir, f"set{set_num}_ml.py")
            HTtoHP.save_code_to_file(set_num, "ml", filename)
            print(f"✓ SET {set_num} ML code -> {filename}")
        except Exception as e:
            print(f"✗ Error generating SET {set_num} ML: {e}")
    
    print(f"\n=== Generation Complete ===")
    print(f"All files saved in '{output_dir}' directory")
    
    # List generated files
    generated_files = os.listdir(output_dir)
    print(f"\nGenerated {len(generated_files)} files:")
    for file in sorted(generated_files):
        print(f"  - {file}")

def generate_with_custom_parameters():
    """Generate some sets with custom parameters"""
    
    output_dir = "generated_codes_custom"
    os.makedirs(output_dir, exist_ok=True)
    
    print("\n=== Generating with Custom Parameters ===\n")
    
    # SET 1 with custom dataset
    filename = os.path.join(output_dir, "set1_ml_iris.py")
    HTtoHP.save_code_to_file(1, "ml", filename,
                            dataset_name="iris.csv",
                            x_column="sepal_length",
                            y_column="petal_length")
    print(f"✓ SET 1 ML (Iris dataset) -> {filename}")
    
    # SET 2 with custom target
    filename = os.path.join(output_dir, "set2_ml_housing.py")
    HTtoHP.save_code_to_file(2, "ml", filename,
                            dataset_name="housing.csv",
                            target_column="price")
    print(f"✓ SET 2 ML (Housing dataset) -> {filename}")
    
    # SET 5 with custom gradient descent parameters
    filename = os.path.join(output_dir, "set5_ml_custom_gd.py")
    HTtoHP.save_code_to_file(5, "ml", filename,
                            dataset_name="boston.csv",
                            learning_rate=0.001,
                            iterations=2000)
    print(f"✓ SET 5 ML (Custom GD params) -> {filename}")
    
    print(f"\nCustom parameter files saved in '{output_dir}' directory")

if __name__ == "__main__":
    generate_all_sets()
    generate_with_custom_parameters()