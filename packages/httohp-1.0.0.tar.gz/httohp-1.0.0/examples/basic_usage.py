"""
Basic usage examples for HTtoHP package
"""

import HTtoHP

def main():
    print("=== HTtoHP - Basic Usage Examples ===\n")
    
    # Example 1: Get code for SET 1 ML question
    print("1. Getting ML code for SET 1 (Simple Linear Regression):")
    print("-" * 60)
    ml_code = HTtoHP.get_code(1, "ml")
    print(ml_code[:500] + "...\n")  # Show first 500 characters
    
    # Example 2: Get code for SET 3 Python question
    print("2. Getting Python code for SET 3 (Statistics and Boxplots):")
    print("-" * 60)
    python_code = HTtoHP.get_code(3, "python")
    print(python_code[:500] + "...\n")
    
    # Example 3: List all available sets
    print("3. Available Sets:")
    print("-" * 60)
    sets_info = HTtoHP.list_available_sets()
    for set_num, description in sets_info.items():
        print(f"SET {set_num}: {description}")
    print()
    
    # Example 4: Save code to file
    print("4. Saving code to file:")
    print("-" * 60)
    file_path = HTtoHP.save_code_to_file(2, "ml", "multiple_regression_example.py")
    print(f"Code saved to: {file_path}")
    
    # Example 5: Using dynamic parameters
    print("\n5. Using dynamic parameters:")
    print("-" * 60)
    custom_code = HTtoHP.get_code(1, "ml", 
                                 dataset_name="iris.csv",
                                 x_column="sepal_length", 
                                 y_column="sepal_width")
    print("Generated code with custom dataset parameters")
    print("Dataset: iris.csv, X: sepal_length, Y: sepal_width")

if __name__ == "__main__":
    main()