# HTtoHP - ML Lab Code Generator

[![Python Version](https://img.shields.io/badge/python-3.7+-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/HTtoHP.svg)](https://badge.fury.io/py/HTtoHP)

A Python package that generates clean, well-formatted code templates for Machine Learning lab questions. This package **does NOT execute ML code**, but instead **returns Python/ML code as strings** that can be used as templates or starting points for ML assignments.

## 🎯 Features

- **8 Complete Sets** of ML lab questions covering fundamental topics
- **Python & ML Code Generation** for each set
- **Dynamic Templates** with customizable parameters
- **Clean, Ready-to-Execute Code** with proper imports and structure
- **Educational Focus** - perfect for learning and teaching ML concepts
- **Easy Installation** via pip

## 📦 Installation

### From PyPI (Recommended)
```bash
pip install HTtoHP
```

### From Source
```bash
git clone https://github.com/yourusername/HTtoHP.git
cd HTtoHP
pip install .
```

### Development Installation
```bash
git clone https://github.com/yourusername/HTtoHP.git
cd HTtoHP
pip install -e .
```

## 🚀 Quick Start

```python
import HTtoHP

# Get code for SET 1 Machine Learning question
ml_code = HTtoHP.get_code(1, "ml")
print(ml_code)

# Get code for SET 3 Python question
python_code = HTtoHP.get_code(3, "python")
print(python_code)

# Save code to a file
file_path = HTtoHP.save_code_to_file(2, "ml", "my_regression.py")
print(f"Code saved to: {file_path}")

# List all available sets
sets_info = HTtoHP.list_available_sets()
for set_num, description in sets_info.items():
    print(f"SET {set_num}: {description}")
```

## 📚 Available Sets

| Set | Python Topic | ML Topic |
|-----|-------------|----------|
| **SET 1** | 2D Arrays & Indexing | Simple Linear Regression |
| **SET 2** | 1D Arrays & Reversal | Multiple Linear Regression |
| **SET 3** | Statistics & Boxplots | Binary Logistic Regression |
| **SET 4** | Matrix Operations | Decision Tree |
| **SET 5** | Matrix Creation & Slicing | Gradient Descent for Linear Regression |
| **SET 6** | DataFrame & Missing Values | Logistic Regression |
| **SET 7** | Line Plots & Labeling | K-Nearest Neighbors (KNN) |
| **SET 8** | Scatter Plots & Styling | K-Means Clustering |

## 🔧 API Reference

### Core Functions

#### `get_code(set_number, part, **kwargs)`
Generate code template for a specific set and part.

**Parameters:**
- `set_number` (int): Set number (1-8)
- `part` (str): Either "python" or "ml"
- `**kwargs`: Additional parameters for dynamic templates

**Returns:** `str` - Generated code template

**Example:**
```python
# Basic usage
code = HTtoHP.get_code(1, "ml")

# With custom parameters
code = HTtoHP.get_code(1, "ml", 
                      dataset_name="iris.csv", 
                      x_column="sepal_length",
                      y_column="sepal_width")
```

#### `save_code_to_file(set_number, part, filename=None, **kwargs)`
Save generated code to a Python file.

**Parameters:**
- `set_number` (int): Set number (1-8)
- `part` (str): Either "python" or "ml"
- `filename` (str, optional): Output filename. Auto-generated if None.
- `**kwargs`: Additional parameters for dynamic templates

**Returns:** `str` - Path to the saved file

#### `list_available_sets()`
List all available sets and their descriptions.

**Returns:** `dict` - Dictionary with set numbers as keys and descriptions as values

## 🎨 Dynamic Templates

Many code templates support dynamic parameters:

```python
import HTtoHP

# Customize dataset name and columns
ml_code = HTtoHP.get_code(2, "ml", 
                         dataset_name="housing.csv",
                         target_column="price")

# Customize gradient descent parameters
gd_code = HTtoHP.get_code(5, "ml",
                         learning_rate=0.001,
                         iterations=2000)

# Customize matrix value
matrix_code = HTtoHP.get_code(1, "python", value=99)
```

## 📋 Example Usage

### Generate and Execute ML Code

```python
import HTtoHP

# Generate logistic regression code
log_reg_code = HTtoHP.get_code(6, "ml", 
                              dataset_name="titanic.csv",
                              target_column="survived")

# Save to file
HTtoHP.save_code_to_file(6, "ml", "logistic_regression_analysis.py",
                        dataset_name="titanic.csv",
                        target_column="survived")

# The generated file is ready to run!
# python logistic_regression_analysis.py
```

### Batch Generate All Sets

```python
import HTtoHP

# Generate all Python questions
for set_num in range(1, 9):
    code = HTtoHP.get_code(set_num, "python")
    filename = f"set{set_num}_python.py"
    HTtoHP.save_code_to_file(set_num, "python", filename)
    print(f"Generated {filename}")

# Generate all ML questions
for set_num in range(1, 9):
    code = HTtoHP.get_code(set_num, "ml")
    filename = f"set{set_num}_ml.py"
    HTtoHP.save_code_to_file(set_num, "ml", filename)
    print(f"Generated {filename}")
```

## 🛠️ Development

### Setting up Development Environment

```bash
# Clone the repository
git clone https://github.com/yourusername/HTtoHP.git
cd HTtoHP

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e .

# Install development dependencies
pip install -e .[dev]
```

### Running Tests

```bash
pytest tests/
```

### Code Formatting

```bash
black HTtoHP/
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request. For major changes, please open an issue first to discuss what you would like to change.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Support

If you encounter any problems or have questions, please:

1. Check the [documentation](https://github.com/yourusername/ml_lab_generator#readme)
2. Search [existing issues](https://github.com/yourusername/ml_lab_generator/issues)
3. Create a [new issue](https://github.com/yourusername/ml_lab_generator/issues/new)

## 🙏 Acknowledgments

- Built for educational purposes to help students learn Machine Learning
- Inspired by common ML lab assignments and best practices
- Uses popular ML libraries: scikit-learn, pandas, numpy, matplotlib

## 📊 Package Statistics

- **8 Sets** of questions
- **16 Code templates** (Python + ML for each set)
- **Clean, documented code** ready for execution
- **Customizable parameters** for dynamic templates
- **Educational focus** with detailed comments and explanations

---

**Happy Learning! 🎓**