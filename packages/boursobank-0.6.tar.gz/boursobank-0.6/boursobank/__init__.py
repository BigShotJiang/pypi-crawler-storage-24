"""BoursoBank library."""

__version__ = "0.6"

from .statements import AccountStatement, CardStatement, Line, Statement

__all__ = ["AccountStatement", "CardStatement", "Statement", "Line"]
