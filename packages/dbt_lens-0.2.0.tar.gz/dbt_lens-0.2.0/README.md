# dbt-lens

CLI tool for navigating and understanding dbt projects. Read your `manifest.json` and get instant answers about impact, lineage, and project health.

## Install

```bash
pip install dbt-lens
```

## Quick Start

```bash
# Generate your manifest first
dbt compile

# See what breaks if you change a model
dbt-lens impact stg_shopify_orders

# Trace upstream lineage back to sources
dbt-lens upstream mrt_daily_revenue

# Find models, columns, macros
dbt-lens find "subscription churn"

# Project health report
dbt-lens health
```

## Commands

| Command | Description |
|---------|------------|
| `impact <model>` | Show downstream models/tests affected by a change |
| `upstream <model>` | Trace a model back to its sources |
| `find <query>` | Fuzzy search across models, columns, macros |
| `health` | Project health: test coverage, doc gaps, model sizes |

## Global Options

| Option | Default | Description |
|--------|---------|------------|
| `--manifest PATH` | `target/manifest.json` | Path to manifest.json |
| `--format terminal\|json` | `terminal` | Output format |

## Requirements

- Python >= 3.9
- dbt-core >= 1.4 (manifest v7+)

## License

MIT
