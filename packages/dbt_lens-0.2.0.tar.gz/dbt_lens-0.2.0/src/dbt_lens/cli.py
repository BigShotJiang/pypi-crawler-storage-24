from __future__ import annotations

from pathlib import Path

import click

from dbt_lens import __version__
from dbt_lens.core.manifest import ProjectGraph, load_manifest


class Context:
    def __init__(self, graph: ProjectGraph, output_format: str, dialect: str | None = None) -> None:
        self.graph = graph
        self.format = output_format
        self.dialect = dialect


pass_context = click.make_pass_decorator(Context)


@click.group()
@click.version_option(version=__version__, prog_name="dbt-lens")
@click.option(
    "--manifest",
    type=click.Path(exists=False),
    default="target/manifest.json",
    help="Path to manifest.json (default: target/manifest.json)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["terminal", "json"]),
    default="terminal",
    help="Output format (default: terminal)",
)
@click.option(
    "--dialect",
    default=None,
    help="sqlglot dialect override (e.g., bigquery, snowflake, postgres)",
)
@click.pass_context
def cli(ctx: click.Context, manifest: str, output_format: str, dialect: str | None) -> None:
    """Navigate and understand dbt projects."""
    manifest_path = Path(manifest)
    try:
        graph = load_manifest(manifest_path)
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e))
    ctx.obj = Context(graph=graph, output_format=output_format, dialect=dialect)
