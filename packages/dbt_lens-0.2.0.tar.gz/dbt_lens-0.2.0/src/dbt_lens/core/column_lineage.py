from __future__ import annotations

import warnings as _warnings
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError

from dbt_lens.core.manifest import DbtNode, ProjectGraph

_DIALECT_MAP: dict[str, str] = {
    "bigquery": "bigquery",
    "snowflake": "snowflake",
    "postgres": "postgres",
    "redshift": "redshift",
    "duckdb": "duckdb",
}


@dataclass
class ColumnTraceNode:
    model: str
    column: str
    expression: str
    inferred: bool = False
    is_source: bool = False
    children: list[ColumnTraceNode] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "column": self.column,
            "expression": self.expression,
            "inferred": self.inferred,
            "is_source": self.is_source,
            "children": [c.to_dict() for c in self.children],
        }


@dataclass
class ColumnTrace:
    target_model: str
    target_column: str
    root: ColumnTraceNode
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "target_model": self.target_model,
            "target_column": self.target_column,
            "root": self.root.to_dict(),
            "warnings": self.warnings,
        }


@dataclass
class JoinInfo:
    join_type: str
    target: str
    condition: str


@dataclass
class ModelSummary:
    model: str
    name: str
    layer: str
    materialization: str
    line_count: int
    sources: list[str]
    joins: list[JoinInfo]
    filters: list[str]
    macros: list[str]
    aggregations: str
    output_columns: int
    partition_by: str | None
    cluster_by: list[str]
    tests: list[str]

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "name": self.name,
            "layer": self.layer,
            "materialization": self.materialization,
            "line_count": self.line_count,
            "sources": self.sources,
            "joins": [{"join_type": j.join_type, "target": j.target, "condition": j.condition} for j in self.joins],
            "filters": self.filters,
            "macros": self.macros,
            "aggregations": self.aggregations,
            "output_columns": self.output_columns,
            "partition_by": self.partition_by,
            "cluster_by": self.cluster_by,
            "tests": self.tests,
        }


def get_dialect(graph: ProjectGraph, override: str | None = None) -> str | None:
    if override is not None:
        return override
    dialect = _DIALECT_MAP.get(graph.adapter_type)
    if dialect is None:
        _warnings.warn(f"Unknown adapter type '{graph.adapter_type}'. Using generic SQL parser.")
    return dialect


def _resolve_table_aliases(
    parsed: exp.Expression,
    depends_on_nodes: list[str],
    graph: ProjectGraph,
) -> dict[str, str]:
    """Map SQL table aliases/names to manifest unique_ids."""
    alias_map: dict[str, str] = {}
    # Build a lookup from node short name to unique_id
    name_to_uid: dict[str, str] = {}
    for uid in depends_on_nodes:
        node = graph.nodes.get(uid)
        if node is not None:
            name_to_uid[node.name.lower()] = uid

    # Collect CTE names so we can resolve them separately
    cte_names: set[str] = set()
    cte_table_map: dict[str, str] = {}  # cte_name -> upstream uid
    with_clause = parsed.find(exp.With)
    if with_clause:
        for cte in with_clause.expressions:
            cte_alias = cte.alias.lower() if cte.alias else ""
            if cte_alias:
                cte_names.add(cte_alias)
                # Find tables referenced in this CTE and map the CTE name
                # to the first matching upstream node
                for table in cte.find_all(exp.Table):
                    tname = table.name
                    if tname:
                        matched = name_to_uid.get(tname.lower())
                        if matched:
                            cte_table_map[cte_alias] = matched
                            break

    for table in parsed.find_all(exp.Table):
        table_name = table.name  # last segment, unquoted by sqlglot
        if not table_name:
            continue
        alias = table.alias or table_name
        tname_lower = table_name.lower()

        # If this table references a CTE, map via the CTE's upstream
        if tname_lower in cte_names:
            upstream_uid = cte_table_map.get(tname_lower)
            if upstream_uid:
                alias_map[alias.lower()] = upstream_uid
                if alias.lower() != tname_lower:
                    alias_map[tname_lower] = upstream_uid
            continue

        # Match against depends_on node names
        matched_uid = name_to_uid.get(tname_lower)
        if matched_uid:
            alias_map[alias.lower()] = matched_uid
            # Also map the full table name if alias differs
            if alias.lower() != tname_lower:
                alias_map[tname_lower] = matched_uid
    return alias_map


def explain_model(
    graph: ProjectGraph,
    model_name: str,
    dialect: str | None = None,
) -> ModelSummary:
    """Produce a structured summary of a model's SQL and metadata."""
    dialect = get_dialect(graph, dialect)
    node = graph.resolve_node(model_name)

    if node.compiled_code is None:
        raise ValueError(f"Model '{model_name}' has no compiled SQL. Run 'dbt compile' to generate it.")

    parsed = sqlglot.parse_one(node.compiled_code, read=dialect)
    alias_map = _resolve_table_aliases(parsed, node.depends_on_nodes, graph)

    # --- sources: all FROM/JOIN table refs, deduplicated, resolved to model names ---
    sources_seen: list[str] = []
    for table in parsed.find_all(exp.Table):
        tname = table.name
        if not tname:
            continue
        # Try to resolve via alias_map
        resolved_uid = alias_map.get(tname.lower())
        if resolved_uid:
            resolved_node = graph.nodes.get(resolved_uid)
            resolved_name = resolved_node.name if resolved_node else tname
        else:
            resolved_name = tname
        if resolved_name not in sources_seen:
            sources_seen.append(resolved_name)

    # --- joins ---
    joins: list[JoinInfo] = []
    for join in parsed.find_all(exp.Join):
        # Join type from side + kind
        parts: list[str] = []
        if join.side:
            parts.append(join.side)
        if join.kind:
            parts.append(join.kind)
        parts.append("JOIN")
        join_type = " ".join(parts)

        # Target table
        join_table = join.find(exp.Table)
        if join_table:
            jtname = join_table.name
            resolved_uid = alias_map.get(jtname.lower()) if jtname else None
            if resolved_uid:
                resolved_node = graph.nodes.get(resolved_uid)
                target = resolved_node.name if resolved_node else jtname
            else:
                target = jtname or ""
        else:
            target = ""

        # Condition from ON clause
        on_expr = join.args.get("on")
        condition = on_expr.sql(dialect=dialect) if on_expr else ""

        joins.append(JoinInfo(join_type=join_type, target=target, condition=condition))

    # --- filters: WHERE clause expressions ---
    filters: list[str] = []
    where = parsed.find(exp.Where)
    if where:
        filters.append(where.this.sql(dialect=dialect))

    # --- macros: short names from depends_on_macros ---
    macros: list[str] = []
    for macro_uid in node.depends_on_macros:
        macro = graph.macros.get(macro_uid)
        if macro:
            macros.append(macro.name)
        else:
            # Extract short name from uid
            short = macro_uid.rsplit(".", 1)[-1] if "." in macro_uid else macro_uid
            macros.append(short)

    # --- aggregations ---
    has_group_by = parsed.find(exp.Group) is not None
    aggregations = "aggregated" if has_group_by else "1:1 grain"

    # --- output_columns: count of SELECT expressions ---
    outer_select = parsed if isinstance(parsed, exp.Select) else parsed.find(exp.Select)
    output_columns = len(outer_select.expressions) if outer_select else 0

    # --- partition_by ---
    partition_by_raw = node.config.get("partition_by")
    if isinstance(partition_by_raw, dict):
        partition_by = partition_by_raw.get("field")
    elif isinstance(partition_by_raw, str):
        partition_by = partition_by_raw
    else:
        partition_by = None

    # --- cluster_by ---
    cluster_by_raw = node.config.get("cluster_by")
    if isinstance(cluster_by_raw, list):
        cluster_by = cluster_by_raw
    elif isinstance(cluster_by_raw, str):
        cluster_by = [cluster_by_raw]
    else:
        cluster_by = []

    # --- tests ---
    test_uids = graph.tests_for_node(node.unique_id)
    tests = []
    for tuid in test_uids:
        test_node = graph.nodes.get(tuid)
        if test_node:
            tests.append(test_node.name)
        else:
            tests.append(tuid)

    return ModelSummary(
        model=node.unique_id,
        name=node.name,
        layer=node.layer,
        materialization=node.materialization,
        line_count=node.raw_code_lines,
        sources=sources_seen,
        joins=joins,
        filters=filters,
        macros=macros,
        aggregations=aggregations,
        output_columns=output_columns,
        partition_by=partition_by,
        cluster_by=cluster_by,
        tests=tests,
    )


def trace_column(
    graph: ProjectGraph,
    model_name: str,
    column_name: str,
    dialect: str | None = None,
) -> ColumnTrace:
    """Trace a column back through the DAG to its sources."""
    dialect = get_dialect(graph, dialect)
    node = graph.resolve_node(model_name)

    if node.compiled_code is None:
        raise ValueError(f"Model '{model_name}' has no compiled SQL. Run 'dbt compile' first.")

    warnings: list[str] = []
    visited: set[tuple[str, str]] = set()

    root = _trace_recursive(graph, node, column_name, dialect, warnings, visited)

    return ColumnTrace(
        target_model=node.unique_id,
        target_column=column_name,
        root=root,
        warnings=warnings,
    )


def _find_select_column(
    select: exp.Select,
    column_name: str,
) -> exp.Expression | None:
    """Find a column expression in a SELECT by output alias or name."""
    for expr in select.expressions:
        # Check alias first
        if isinstance(expr, exp.Alias):
            if expr.alias.lower() == column_name.lower():
                return expr
        # Check if it's a bare column reference
        elif isinstance(expr, exp.Column):
            if expr.name.lower() == column_name.lower():
                return expr
    return None


def _extract_source_columns(expr: exp.Expression) -> list[tuple[str, str]]:
    """Extract (table_alias, column_name) pairs from an expression.

    Returns a list of tuples. table_alias may be empty string for unqualified refs.
    """
    cols: list[tuple[str, str]] = []
    for col in expr.find_all(exp.Column):
        table_ref = col.table or ""
        cols.append((table_ref.lower(), col.name.lower()))
    return cols


def _trace_recursive(
    graph: ProjectGraph,
    node: DbtNode,
    column_name: str,
    dialect: str | None,
    warnings: list[str],
    visited: set[tuple[str, str]],
) -> ColumnTraceNode:
    """Recursively trace a column through the DAG."""
    # Cycle detection
    key = (node.unique_id, column_name.lower())
    if key in visited:
        warnings.append(f"Circular reference detected at {node.name}.{column_name}")
        return ColumnTraceNode(
            model=node.unique_id,
            column=column_name,
            expression="(cycle detected)",
        )
    visited.add(key)

    # Leaf nodes: sources and seeds
    if node.resource_type in ("source", "seed"):
        return ColumnTraceNode(
            model=node.unique_id,
            column=column_name,
            expression=column_name,
            is_source=True,
        )

    # Missing compiled code (for intermediate nodes discovered during recursion)
    if node.compiled_code is None:
        warnings.append(f"Model '{node.name}' has no compiled SQL; cannot trace further.")
        return ColumnTraceNode(
            model=node.unique_id,
            column=column_name,
            expression="(no compiled SQL)",
        )

    # Parse SQL
    try:
        parsed = sqlglot.parse_one(node.compiled_code, read=dialect)
    except ParseError as e:
        warnings.append(f"Failed to parse SQL for '{node.name}': {e}")
        return ColumnTraceNode(
            model=node.unique_id,
            column=column_name,
            expression="(parse error)",
        )

    # Build alias map
    alias_map = _resolve_table_aliases(parsed, node.depends_on_nodes, graph)

    # Find the outermost SELECT (parsed IS the outer statement for CTEs)
    select: exp.Select | None
    if isinstance(parsed, exp.Select):
        select = parsed
    else:
        select = parsed.find(exp.Select)
    if select is None:
        warnings.append(f"No SELECT found in '{node.name}'.")
        return ColumnTraceNode(
            model=node.unique_id,
            column=column_name,
            expression="(no SELECT)",
        )

    # Check for SELECT *
    has_star = any(isinstance(e, exp.Star) for e in select.expressions)

    # Find the target column
    col_expr = _find_select_column(select, column_name)

    if col_expr is None and has_star:
        return _trace_select_star(graph, node, column_name, dialect, warnings, visited, alias_map)

    if col_expr is None:
        # List available columns for error message
        available = []
        for expr in select.expressions:
            if isinstance(expr, exp.Alias):
                available.append(expr.alias)
            elif isinstance(expr, exp.Column):
                available.append(expr.name)
            elif isinstance(expr, exp.Star):
                available.append("*")
        raise ValueError(
            f"Column '{column_name}' not found in model '{node.name}'. Available columns: {', '.join(available)}"
        )

    # Get the expression text (exclude alias from expression string)
    if isinstance(col_expr, exp.Alias):
        source_expr = col_expr.this
        expr_sql = source_expr.sql(dialect=dialect)
    else:
        source_expr = col_expr
        expr_sql = col_expr.sql(dialect=dialect)

    # Extract upstream column references
    source_cols = _extract_source_columns(source_expr)

    children: list[ColumnTraceNode] = []
    if source_cols:
        for table_alias, col_name in source_cols:
            upstream_uid = None
            if table_alias:
                upstream_uid = alias_map.get(table_alias)
            else:
                # Unqualified column - try to find in upstream models
                upstream_uid = _resolve_unqualified_column(graph, node, col_name, alias_map, warnings)

            if upstream_uid:
                upstream_node = graph.nodes.get(upstream_uid)
                if upstream_node:
                    child = _trace_recursive(graph, upstream_node, col_name, dialect, warnings, visited)
                    children.append(child)
                else:
                    warnings.append(f"Upstream node '{upstream_uid}' not found in graph.")
            else:
                # Could be a literal or function - just note it
                if table_alias:
                    warnings.append(
                        f"Could not resolve table alias '{table_alias}' for column '{col_name}' in '{node.name}'."
                    )
    else:
        # Expression has no column references (e.g., a literal or function)
        # Try to trace through all upstreams if it's a simple passthrough
        pass

    return ColumnTraceNode(
        model=node.unique_id,
        column=column_name,
        expression=expr_sql,
        children=children,
    )


def _resolve_unqualified_column(
    graph: ProjectGraph,
    node: DbtNode,
    col_name: str,
    alias_map: dict[str, str],
    warnings: list[str],
) -> str | None:
    """Resolve an unqualified column reference to an upstream model uid."""
    # Check documented columns in upstream models
    candidates: list[str] = []
    for uid in set(alias_map.values()):
        upstream = graph.nodes.get(uid)
        if upstream and upstream.columns:
            col_names = [c.lower() for c in upstream.columns]
            if col_name.lower() in col_names:
                candidates.append(uid)

    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        warnings.append(
            f"Ambiguous unqualified column '{col_name}' in '{node.name}' could come from: {', '.join(candidates)}"
        )
        return candidates[0]

    # If no documented columns match, try the first upstream
    all_uids = list(set(alias_map.values()))
    if len(all_uids) == 1:
        return all_uids[0]

    return None


def _trace_select_star(
    graph: ProjectGraph,
    node: DbtNode,
    column_name: str,
    dialect: str | None,
    warnings: list[str],
    visited: set[tuple[str, str]],
    alias_map: dict[str, str],
) -> ColumnTraceNode:
    """Handle SELECT * by looking at upstream documented columns."""
    # Try each upstream model
    for uid in node.depends_on_nodes:
        upstream = graph.nodes.get(uid)
        if upstream is None:
            continue

        # Check if upstream has documented columns
        if upstream.columns:
            col_names = [c.lower() for c in upstream.columns]
            if column_name.lower() in col_names:
                child = _trace_recursive(graph, upstream, column_name, dialect, warnings, visited)
                return ColumnTraceNode(
                    model=node.unique_id,
                    column=column_name,
                    expression=f"* (from {upstream.name})",
                    inferred=True,
                    children=[child],
                )

        # If upstream is source/seed with no documented columns, warn
        if upstream.resource_type in ("source", "seed") and not upstream.columns:
            warnings.append(
                f"SELECT * from {upstream.resource_type} '{upstream.name}' "
                f"which has no documented columns; cannot verify column '{column_name}'."
            )
            return ColumnTraceNode(
                model=node.unique_id,
                column=column_name,
                expression=f"* (from {upstream.name})",
                inferred=True,
                children=[
                    ColumnTraceNode(
                        model=upstream.unique_id,
                        column=column_name,
                        expression=column_name,
                        is_source=True,
                        inferred=True,
                    )
                ],
            )

        # Try tracing into upstream model
        if upstream.compiled_code is not None:
            try:
                child = _trace_recursive(graph, upstream, column_name, dialect, warnings, visited)
                return ColumnTraceNode(
                    model=node.unique_id,
                    column=column_name,
                    expression=f"* (from {upstream.name})",
                    inferred=True,
                    children=[child],
                )
            except ValueError:
                continue

    warnings.append(f"Column '{column_name}' could not be resolved through SELECT * in model '{node.name}'.")
    return ColumnTraceNode(
        model=node.unique_id,
        column=column_name,
        expression="*",
        inferred=True,
    )
