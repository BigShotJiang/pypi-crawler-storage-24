from __future__ import annotations

from dataclasses import dataclass

from rapidfuzz import fuzz, process

from dbt_lens.core.manifest import ProjectGraph


@dataclass
class SearchResult:
    name: str
    result_type: str  # "model", "column", "source", "macro", "seed"
    unique_id: str
    score: float
    path: str
    parent_model: str | None = None


class SearchIndex:
    def __init__(self, graph: ProjectGraph) -> None:
        self._entries: list[tuple[str, SearchResult]] = []
        self._build(graph)

    def _build(self, graph: ProjectGraph) -> None:
        for uid, node in graph.nodes.items():
            if node.resource_type in ("model", "seed", "snapshot"):
                rtype = node.resource_type if node.resource_type != "snapshot" else "model"
                self._entries.append(
                    (
                        node.name,
                        SearchResult(
                            name=node.name,
                            result_type=rtype,
                            unique_id=uid,
                            score=0,
                            path=node.original_file_path,
                        ),
                    )
                )
                if node.description:
                    self._entries.append(
                        (
                            node.description,
                            SearchResult(
                                name=node.name,
                                result_type=rtype,
                                unique_id=uid,
                                score=0,
                                path=node.original_file_path,
                            ),
                        )
                    )
                for col_name, col_data in node.columns.items():
                    self._entries.append(
                        (
                            col_name,
                            SearchResult(
                                name=f"{node.name}.{col_name}",
                                result_type="column",
                                unique_id=uid,
                                score=0,
                                path=node.original_file_path,
                                parent_model=node.name,
                            ),
                        )
                    )
                    if col_data.get("description"):
                        self._entries.append(
                            (
                                col_data["description"],
                                SearchResult(
                                    name=f"{node.name}.{col_name}",
                                    result_type="column",
                                    unique_id=uid,
                                    score=0,
                                    path=node.original_file_path,
                                    parent_model=node.name,
                                ),
                            )
                        )

            elif node.resource_type == "source":
                self._entries.append(
                    (
                        node.source_key,
                        SearchResult(
                            name=node.source_key,
                            result_type="source",
                            unique_id=uid,
                            score=0,
                            path=node.original_file_path,
                        ),
                    )
                )

        for uid, macro in graph.macros.items():
            self._entries.append(
                (
                    macro.name,
                    SearchResult(
                        name=macro.name,
                        result_type="macro",
                        unique_id=uid,
                        score=0,
                        path=macro.original_file_path,
                    ),
                )
            )

    def search(
        self,
        query: str,
        result_type: str | None = None,
        limit: int = 20,
    ) -> list[SearchResult]:
        if not self._entries:
            return []

        entries = self._entries
        if result_type:
            entries = [(text, sr) for text, sr in entries if sr.result_type == result_type]

        if not entries:
            return []

        texts = [text for text, _ in entries]
        matches = process.extract(query, texts, scorer=fuzz.WRatio, limit=min(limit * 2, len(texts)))

        results: list[SearchResult] = []
        seen: set[str] = set()
        for text, score, idx in matches:
            if score < 50:  # threshold filters noise; real matches score 70+
                continue
            sr = entries[idx][1]
            dedup_key = f"{sr.result_type}:{sr.name}"
            if dedup_key in seen:
                continue
            seen.add(dedup_key)
            results.append(
                SearchResult(
                    name=sr.name,
                    result_type=sr.result_type,
                    unique_id=sr.unique_id,
                    score=round(score, 1),
                    path=sr.path,
                    parent_model=sr.parent_model,
                )
            )

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:limit]
