from __future__ import annotations

from collections import deque

from dbt_lens.core.manifest import DbtNode, ProjectGraph


def downstream(
    graph: ProjectGraph,
    start_id: str,
    max_depth: int | None = None,
    include_tests: bool = True,
) -> list[DbtNode]:
    return _bfs(
        graph=graph,
        start_id=start_id,
        adjacency=graph.child_map,
        max_depth=max_depth,
        include_tests=include_tests,
    )


def upstream(
    graph: ProjectGraph,
    start_id: str,
    max_depth: int | None = None,
    include_tests: bool = False,
) -> list[DbtNode]:
    return _bfs(
        graph=graph,
        start_id=start_id,
        adjacency=graph.parent_map,
        max_depth=max_depth,
        include_tests=include_tests,
    )


def _bfs(
    graph: ProjectGraph,
    start_id: str,
    adjacency: dict[str, list[str]],
    max_depth: int | None,
    include_tests: bool,
) -> list[DbtNode]:
    visited: set[str] = set()
    result: list[DbtNode] = []
    queue: deque[tuple[str, int]] = deque()

    for neighbor_id in adjacency.get(start_id, []):
        queue.append((neighbor_id, 1))

    while queue:
        node_id, depth = queue.popleft()

        if node_id in visited:
            continue
        visited.add(node_id)

        if max_depth is not None and depth > max_depth:
            continue

        node = graph.nodes.get(node_id)
        if node is None:
            continue

        if not include_tests and node.resource_type == "test":
            continue

        result.append(node)

        if max_depth is None or depth < max_depth:
            for neighbor_id in adjacency.get(node_id, []):
                if neighbor_id not in visited:
                    queue.append((neighbor_id, depth + 1))

    return result
