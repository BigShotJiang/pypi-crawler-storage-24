# Register all commands
import dbt_lens.commands.explain  # noqa: F401
import dbt_lens.commands.find  # noqa: F401
import dbt_lens.commands.health  # noqa: F401
import dbt_lens.commands.impact  # noqa: F401
import dbt_lens.commands.trace  # noqa: F401
import dbt_lens.commands.upstream  # noqa: F401
from dbt_lens.cli import cli


def main() -> None:
    cli()
