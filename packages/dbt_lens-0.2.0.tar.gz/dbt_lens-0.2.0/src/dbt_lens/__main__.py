from dbt_lens.app import main

if __name__ == "__main__":
    main()
