from __future__ import annotations

import json
import sys


def output_json(data: dict | list) -> None:
    json.dump(data, sys.stdout, indent=2, default=str)
    sys.stdout.write("\n")
