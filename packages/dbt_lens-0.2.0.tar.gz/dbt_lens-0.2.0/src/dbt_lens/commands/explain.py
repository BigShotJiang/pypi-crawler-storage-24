from __future__ import annotations

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.column_lineage import explain_model
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_explain


@cli.command()
@click.argument("model")
@pass_context
def explain(ctx: Context, model: str) -> None:
    """Auto-generated summary of a model — what it reads, how it transforms, what it outputs."""
    try:
        summary = explain_model(ctx.graph, model, dialect=ctx.dialect)
    except (KeyError, ValueError) as e:
        raise click.ClickException(str(e))

    if ctx.format == "json":
        output_json(summary.to_dict())
        return

    render_explain(summary)
