from __future__ import annotations

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.search import SearchIndex
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_search_results


@cli.command()
@click.argument("query")
@click.option("--type", "result_type", type=click.Choice(["model", "column", "macro", "source"]), default=None)
@click.option("--limit", type=int, default=20)
@pass_context
def find(ctx: Context, query: str, result_type: str | None, limit: int) -> None:
    """Fuzzy search across models, columns, macros, and sources."""
    index = SearchIndex(ctx.graph)
    results = index.search(query, result_type=result_type, limit=limit)

    if ctx.format == "json":
        output_json(
            {
                "query": query,
                "results": [
                    {
                        "name": r.name,
                        "type": r.result_type,
                        "unique_id": r.unique_id,
                        "score": r.score,
                        "path": r.path,
                    }
                    for r in results
                ],
            }
        )
        return

    render_search_results(results, result_type=result_type)
