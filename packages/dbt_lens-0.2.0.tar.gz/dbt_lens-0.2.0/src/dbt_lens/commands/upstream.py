from __future__ import annotations

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.graph import upstream
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import console, render_dependency_tree


@cli.command("upstream")
@click.argument("model")
@click.option("--depth", type=int, default=None, help="Limit traversal depth")
@click.option("--tests/--no-tests", default=False, help="Show/hide test nodes")
@pass_context
def upstream_cmd(ctx: Context, model: str, depth: int | None, tests: bool) -> None:
    """Show upstream lineage of a model back to sources."""
    graph = ctx.graph

    try:
        start_node = graph.resolve_node(model)
    except KeyError as e:
        raise click.ClickException(str(e))

    nodes = upstream(graph, start_node.unique_id, max_depth=depth, include_tests=tests)

    if ctx.format == "json":
        output_json(
            {
                "model": start_node.unique_id,
                "upstream": [
                    {
                        "unique_id": n.unique_id,
                        "name": n.name,
                        "resource_type": n.resource_type,
                        "layer": n.layer,
                    }
                    for n in nodes
                ],
            }
        )
        return

    tree = render_dependency_tree(
        graph,
        start_node,
        children_fn=lambda nid: graph.parent_map.get(nid, []),
        include_tests=tests,
        max_depth=depth,
    )
    console.print(tree)
