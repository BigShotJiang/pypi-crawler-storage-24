from __future__ import annotations

from collections import deque

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.graph import downstream
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import console, render_dependency_tree, render_summary_line


@cli.command()
@click.argument("model")
@click.option("--depth", type=int, default=None, help="Limit traversal depth")
@click.option("--tests/--no-tests", default=True, help="Show/hide test nodes")
@pass_context
def impact(ctx: Context, model: str, depth: int | None, tests: bool) -> None:
    """Show downstream impact of changing a model."""
    graph = ctx.graph

    try:
        start_node = graph.resolve_node(model)
    except KeyError as e:
        raise click.ClickException(str(e))

    nodes = downstream(graph, start_node.unique_id, max_depth=depth, include_tests=tests)

    if ctx.format == "json":
        output_json(
            {
                "model": start_node.unique_id,
                "downstream": [
                    {
                        "unique_id": n.unique_id,
                        "name": n.name,
                        "resource_type": n.resource_type,
                        "layer": n.layer,
                        "materialization": n.materialization,
                    }
                    for n in nodes
                ],
                "summary": {
                    "model_count": len([n for n in nodes if n.resource_type == "model"]),
                    "test_count": len([n for n in nodes if n.resource_type == "test"]),
                },
            }
        )
        return

    tree = render_dependency_tree(
        graph,
        start_node,
        children_fn=lambda nid: graph.child_map.get(nid, []),
        include_tests=tests,
        max_depth=depth,
    )
    console.print(tree)

    model_count = len([n for n in nodes if n.resource_type == "model"])
    test_count = len([n for n in nodes if n.resource_type == "test"])
    max_layer = _max_depth_of(nodes, graph, start_node.unique_id)
    console.print(render_summary_line(model_count, test_count, max_layer))


def _max_depth_of(nodes: list, graph, start_id: str) -> int:
    if not nodes:
        return 0
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(start_id, 0)])
    max_d = 0
    node_ids = {n.unique_id for n in nodes}
    while queue:
        nid, d = queue.popleft()
        if nid in visited:
            continue
        visited.add(nid)
        if nid in node_ids:
            max_d = max(max_d, d)
        for child in graph.child_map.get(nid, []):
            if child not in visited:
                queue.append((child, d + 1))
    return max_d
