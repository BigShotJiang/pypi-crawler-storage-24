from __future__ import annotations

from collections import Counter

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_health_report


@cli.command()
@click.option("--warn-lines", type=int, default=200, help="Line count threshold for size warnings")
@pass_context
def health(ctx: Context, warn_lines: int) -> None:
    """Project health report: test coverage, docs, model sizes."""
    graph = ctx.graph
    models = graph.model_nodes()
    sources = graph.source_nodes()

    # Coverage
    untested = 0
    undocumented = 0
    undocumented_columns = 0
    for uid, node in models.items():
        tests = graph.tests_for_node(uid)
        if len(tests) == 0:
            untested += 1
        if not node.description:
            undocumented += 1
        for col_name, col_data in node.columns.items():
            if not col_data.get("description"):
                undocumented_columns += 1

    total = len(models)
    untested_pct = (untested / total * 100) if total > 0 else 0
    undocumented_pct = (undocumented / total * 100) if total > 0 else 0

    # Sizes
    over_500 = 0
    over_threshold = 0
    largest = None
    largest_lines = 0
    for node in models.values():
        lines = node.raw_code_lines
        if lines > 500:
            over_500 += 1
        if lines > warn_lines:
            over_threshold += 1
        if lines > largest_lines:
            largest_lines = lines
            largest = node

    # Macros
    project_macros = graph.project_macros()
    macro_usage: Counter[str] = Counter()
    for node in models.values():
        for macro_id in node.depends_on_macros:
            macro_usage[macro_id] += 1

    most_used = None
    if macro_usage:
        top_id, top_count = macro_usage.most_common(1)[0]
        macro = graph.macros.get(top_id)
        if macro:
            most_used = {"name": macro.name, "count": top_count}

    unused_count = sum(1 for uid in project_macros if macro_usage.get(uid, 0) == 0)

    # Source Freshness — check the freshness field on the DbtNode (NOT config or meta)
    total_sources = len(sources)
    no_freshness = sum(1 for node in sources.values() if node.freshness is None)

    # Layer Summary
    layers: Counter[str] = Counter()
    for node in models.values():
        layers[node.layer] += 1

    report = {
        "coverage": {
            "total": total,
            "untested": untested,
            "untested_pct": untested_pct,
            "undocumented": undocumented,
            "undocumented_pct": undocumented_pct,
            "undocumented_columns": undocumented_columns,
        },
        "sizes": {
            "over_500": over_500,
            "over_threshold": over_threshold,
            "threshold": warn_lines,
            "largest": {"name": largest.name, "lines": largest_lines} if largest else None,
        },
        "macros": {
            "most_used": most_used,
            "unused_count": unused_count,
        },
        "freshness": {
            "total": total_sources,
            "no_freshness": no_freshness,
        },
        "layers": dict(layers),
    }

    if ctx.format == "json":
        output_json(report)
        return

    render_health_report(report)
