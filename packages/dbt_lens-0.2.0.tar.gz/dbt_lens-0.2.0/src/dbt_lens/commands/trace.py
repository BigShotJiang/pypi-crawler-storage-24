from __future__ import annotations

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.column_lineage import trace_column
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_column_trace


@cli.command()
@click.argument("model_column")
@pass_context
def trace(ctx: Context, model_column: str) -> None:
    """Trace a column's lineage back to its source.

    MODEL_COLUMN should be in the format model_name.column_name
    """
    dot_idx = model_column.rfind(".")
    if dot_idx == -1:
        raise click.ClickException("Expected format: model_name.column_name")

    model_name = model_column[:dot_idx]
    column_name = model_column[dot_idx + 1 :]

    if not column_name:
        raise click.ClickException("Expected format: model_name.column_name")

    try:
        result = trace_column(ctx.graph, model_name, column_name, dialect=ctx.dialect)
    except (KeyError, ValueError) as e:
        raise click.ClickException(str(e))

    if ctx.format == "json":
        output_json(result.to_dict())
        return

    render_column_trace(result)
