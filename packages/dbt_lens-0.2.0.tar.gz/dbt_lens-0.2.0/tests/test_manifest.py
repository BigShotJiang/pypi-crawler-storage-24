from pathlib import Path

import pytest

from dbt_lens.core.manifest import DbtNode, ProjectGraph, load_manifest


class TestLoadManifest:
    def test_loads_from_path(self, small_manifest_path: Path) -> None:
        graph = load_manifest(small_manifest_path)
        assert isinstance(graph, ProjectGraph)

    def test_rejects_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError, match="No manifest.json found"):
            load_manifest(tmp_path / "nonexistent.json")

    def test_checks_schema_version(self, tmp_path: Path) -> None:
        bad = tmp_path / "manifest.json"
        bad.write_text('{"metadata": {"dbt_schema_version": "https://schemas.getdbt.com/dbt/manifest/v5.json"}}')
        with pytest.raises(ValueError, match="requires dbt-core >= 1.4"):
            load_manifest(bad)


class TestProjectGraph:
    @pytest.fixture
    def graph(self, small_manifest_path: Path) -> ProjectGraph:
        return load_manifest(small_manifest_path)

    def test_model_count(self, graph: ProjectGraph) -> None:
        models = [n for n in graph.nodes.values() if n.resource_type == "model"]
        assert len(models) == 10

    def test_source_count(self, graph: ProjectGraph) -> None:
        sources = [n for n in graph.nodes.values() if n.resource_type == "source"]
        assert len(sources) == 2

    def test_test_count(self, graph: ProjectGraph) -> None:
        tests = [n for n in graph.nodes.values() if n.resource_type == "test"]
        assert len(tests) == 3

    def test_seed_count(self, graph: ProjectGraph) -> None:
        seeds = [n for n in graph.nodes.values() if n.resource_type == "seed"]
        assert len(seeds) == 1

    def test_macro_count(self, graph: ProjectGraph) -> None:
        assert len(graph.macros) == 3

    def test_node_has_correct_fields(self, graph: ProjectGraph) -> None:
        node = graph.nodes["model.test_project.stg_orders"]
        assert node.name == "stg_orders"
        assert node.resource_type == "model"
        assert node.package_name == "test_project"
        assert node.layer == "staging"
        assert node.materialization == "view"
        assert node.description == "Staged orders from raw source"
        assert "order_id" in node.columns

    def test_layer_detection_from_fqn(self, graph: ProjectGraph) -> None:
        assert graph.nodes["model.test_project.dim_order"].layer == "dimension"
        assert graph.nodes["model.test_project.mrt_order_summary"].layer == "mart"
        assert graph.nodes["model.test_project.int_orders_enriched"].layer == "intermediate"

    def test_child_map(self, graph: ProjectGraph) -> None:
        children = graph.child_map["model.test_project.stg_orders"]
        assert "model.test_project.int_orders_enriched" in children

    def test_parent_map(self, graph: ProjectGraph) -> None:
        parents = graph.parent_map["model.test_project.int_orders_enriched"]
        assert "model.test_project.stg_orders" in parents
        assert "model.test_project.stg_customers" in parents

    def test_project_name(self, graph: ProjectGraph) -> None:
        assert graph.project_name == "test_project"

    def test_adapter_type(self, graph: ProjectGraph) -> None:
        assert graph.adapter_type == "bigquery"

    def test_macro_depends_on(self, graph: ProjectGraph) -> None:
        macro = graph.macros["macro.test_project.generate_surrogate_key"]
        assert macro.depends_on_macros == []

    def test_model_depends_on_macros(self, graph: ProjectGraph) -> None:
        node = graph.nodes["model.test_project.int_orders_enriched"]
        assert "macro.test_project.generate_surrogate_key" in node.depends_on_macros

    def test_resolve_model_by_short_name(self, graph: ProjectGraph) -> None:
        node = graph.resolve_node("stg_orders")
        assert node.unique_id == "model.test_project.stg_orders"

    def test_resolve_model_by_unique_id(self, graph: ProjectGraph) -> None:
        node = graph.resolve_node("model.test_project.stg_orders")
        assert node.name == "stg_orders"

    def test_resolve_source(self, graph: ProjectGraph) -> None:
        node = graph.resolve_node("source:raw.orders")
        assert node.unique_id == "source.test_project.raw.orders"

    def test_resolve_ambiguous_prefers_project_local(self, graph: ProjectGraph) -> None:
        fake_node = DbtNode(
            unique_id="model.other_pkg.stg_orders",
            name="stg_orders",
            resource_type="model",
            package_name="other_pkg",
            fqn=["other_pkg", "staging", "stg_orders"],
            description="",
            columns={},
            tags=[],
            meta={},
            config={},
            depends_on_macros=[],
            depends_on_nodes=[],
            raw_code="",
            compiled_code=None,
            original_file_path="",
            path="",
        )
        graph.nodes[fake_node.unique_id] = fake_node
        graph._name_to_ids.setdefault("stg_orders", []).append(fake_node.unique_id)
        node = graph.resolve_node("stg_orders")
        assert node.package_name == "test_project"

    def test_resolve_not_found_raises(self, graph: ProjectGraph) -> None:
        with pytest.raises(KeyError, match="not found"):
            graph.resolve_node("nonexistent_model")

    def test_raw_code_line_count(self, graph: ProjectGraph) -> None:
        node = graph.nodes["model.test_project.stg_orders"]
        assert node.raw_code_lines > 0

    def test_no_compiled_code(self, graph: ProjectGraph) -> None:
        node = graph.nodes["model.test_project.mrt_no_compiled"]
        assert node.compiled_code is None
