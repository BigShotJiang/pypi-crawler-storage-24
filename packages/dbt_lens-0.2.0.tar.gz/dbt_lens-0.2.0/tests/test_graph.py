from pathlib import Path

import pytest

from dbt_lens.core.graph import downstream, upstream
from dbt_lens.core.manifest import ProjectGraph, load_manifest


@pytest.fixture
def graph(small_manifest_path: Path) -> ProjectGraph:
    return load_manifest(small_manifest_path)


class TestDownstream:
    def test_stg_orders_reaches_mart(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.stg_orders")
        ids = {n.unique_id for n in result}
        assert "model.test_project.int_orders_enriched" in ids
        assert "model.test_project.dim_order" in ids
        assert "model.test_project.mrt_order_summary" in ids

    def test_includes_tests_by_default(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.dim_order")
        ids = {n.unique_id for n in result}
        assert "test.test_project.unique_dim_order_order_id.abc123" in ids

    def test_excludes_tests_when_flag_off(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.dim_order", include_tests=False)
        ids = {n.unique_id for n in result}
        assert all(not uid.startswith("test.") for uid in ids)

    def test_depth_limit(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.stg_orders", max_depth=1)
        ids = {n.unique_id for n in result}
        assert "model.test_project.int_orders_enriched" in ids
        assert "model.test_project.dim_order" not in ids

    def test_leaf_node_returns_empty(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.mrt_no_compiled", include_tests=False)
        assert len(result) == 0

    def test_source_downstream(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "source.test_project.raw.orders", include_tests=False)
        ids = {n.unique_id for n in result}
        assert "model.test_project.stg_orders" in ids

    def test_does_not_include_start_node(self, graph: ProjectGraph) -> None:
        result = downstream(graph, "model.test_project.stg_orders")
        ids = {n.unique_id for n in result}
        assert "model.test_project.stg_orders" not in ids


class TestUpstream:
    def test_mrt_reaches_sources(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "model.test_project.mrt_order_summary")
        ids = {n.unique_id for n in result}
        assert "source.test_project.raw.orders" in ids
        assert "source.test_project.raw.customers" in ids
        assert "seed.test_project.date_spine" in ids

    def test_excludes_tests_by_default(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "model.test_project.mrt_order_summary")
        ids = {n.unique_id for n in result}
        assert all(not uid.startswith("test.") for uid in ids)

    def test_includes_tests_when_flag_on(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "model.test_project.mrt_order_summary", include_tests=True)
        ids = {n.unique_id for n in result}
        assert all(not uid.startswith("test.") for uid in ids)

    def test_depth_limit(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "model.test_project.mrt_order_summary", max_depth=1)
        ids = {n.unique_id for n in result}
        assert "model.test_project.dim_order" in ids
        assert "model.test_project.stg_orders" not in ids

    def test_source_has_no_upstream(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "source.test_project.raw.orders")
        assert len(result) == 0

    def test_does_not_include_start_node(self, graph: ProjectGraph) -> None:
        result = upstream(graph, "model.test_project.mrt_order_summary")
        ids = {n.unique_id for n in result}
        assert "model.test_project.mrt_order_summary" not in ids
