from pathlib import Path

from click.testing import CliRunner

from dbt_lens.cli import cli


def test_find_basic(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "find", "orders"])
    assert result.exit_code == 0
    assert "stg_orders" in result.output


def test_find_with_type_filter(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "find", "order_id", "--type", "column"])
    assert result.exit_code == 0
    assert "column" in result.output.lower() or "order_id" in result.output


def test_find_with_limit(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "find", "order", "--limit", "2"])
    assert result.exit_code == 0


def test_find_json(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "--format", "json", "find", "orders"])
    assert result.exit_code == 0
    import json

    data = json.loads(result.output)
    assert "results" in data


def test_find_no_results(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "find", "zzz_nothing_xyz"])
    assert result.exit_code == 0
    assert "no results" in result.output.lower()
