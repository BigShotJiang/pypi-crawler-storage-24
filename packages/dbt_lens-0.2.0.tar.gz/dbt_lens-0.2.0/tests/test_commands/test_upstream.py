from pathlib import Path

from click.testing import CliRunner

from dbt_lens.cli import cli


def test_upstream_basic(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "upstream", "mrt_order_summary"])
    assert result.exit_code == 0
    assert "dim_order" in result.output
    assert "source" in result.output.lower()


def test_upstream_depth_limit(small_manifest_path: Path) -> None:
    runner = CliRunner()
    manifest = str(small_manifest_path)
    result = runner.invoke(cli, ["--manifest", manifest, "upstream", "mrt_order_summary", "--depth", "1"])
    assert result.exit_code == 0
    assert "dim_order" in result.output


def test_upstream_json(small_manifest_path: Path) -> None:
    runner = CliRunner()
    manifest = str(small_manifest_path)
    result = runner.invoke(cli, ["--manifest", manifest, "--format", "json", "upstream", "mrt_order_summary"])
    assert result.exit_code == 0
    import json

    data = json.loads(result.output)
    assert "upstream" in data


def test_upstream_not_found(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "upstream", "nonexistent"])
    assert result.exit_code != 0
