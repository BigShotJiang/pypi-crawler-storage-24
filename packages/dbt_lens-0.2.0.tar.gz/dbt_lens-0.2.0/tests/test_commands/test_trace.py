from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dbt_lens.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def manifest_args(small_manifest_path):
    return ["--manifest", str(small_manifest_path)]


class TestTraceCommand:
    def test_basic_trace(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "trace", "stg_orders.order_id"])
        assert result.exit_code == 0
        assert "order_id" in result.output

    def test_json_output(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "trace", "stg_orders.order_id"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["target_column"] == "order_id"
        assert "root" in data
        assert "children" in data["root"]

    def test_model_not_found(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "trace", "nonexistent_model.col"])
        assert result.exit_code != 0

    def test_no_dot_in_argument(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "trace", "nodothere"])
        assert result.exit_code != 0
        assert "model_name.column_name" in result.output

    def test_column_not_found(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "trace", "stg_orders.nonexistent"])
        assert result.exit_code != 0

    def test_missing_compiled_code(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "trace", "mrt_no_compiled.order_id"])
        assert result.exit_code != 0
        assert "compiled" in result.output.lower()

    def test_dialect_override(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--dialect", "bigquery", "trace", "stg_orders.order_id"])
        assert result.exit_code == 0
