from pathlib import Path

from click.testing import CliRunner

from dbt_lens.cli import cli


def test_impact_basic(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "impact", "stg_orders"])
    assert result.exit_code == 0
    assert "int_orders_enriched" in result.output
    assert "dim_order" in result.output
    assert "mrt_order_summary" in result.output


def test_impact_depth_limit(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "impact", "stg_orders", "--depth", "1"])
    assert result.exit_code == 0
    assert "int_orders_enriched" in result.output


def test_impact_no_tests(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "impact", "dim_order", "--no-tests"])
    assert result.exit_code == 0
    assert "unique_dim_order" not in result.output


def test_impact_json_output(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "--format", "json", "impact", "stg_orders"])
    assert result.exit_code == 0
    import json

    data = json.loads(result.output)
    assert "downstream" in data
    assert isinstance(data["downstream"], list)


def test_impact_model_not_found(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "impact", "nonexistent"])
    assert result.exit_code != 0
    assert "not found" in result.output.lower()


def test_impact_source(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "impact", "source:raw.orders"])
    assert result.exit_code == 0
    assert "stg_orders" in result.output
