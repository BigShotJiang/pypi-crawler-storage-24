from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dbt_lens.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def manifest_args(small_manifest_path):
    return ["--manifest", str(small_manifest_path)]


class TestExplainCommand:
    def test_basic_explain(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "explain", "mrt_order_summary"])
        assert result.exit_code == 0
        assert "mrt_order_summary" in result.output

    def test_json_output(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "explain", "mrt_order_summary"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "mrt_order_summary"
        assert "sources" in data
        assert "joins" in data
        assert "output_columns" in data

    def test_model_not_found(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "explain", "nonexistent_model"])
        assert result.exit_code != 0

    def test_missing_compiled_code(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "explain", "mrt_no_compiled"])
        assert result.exit_code != 0
        assert "compiled" in result.output.lower()

    def test_has_joins_info(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "explain", "mrt_order_summary"])
        data = json.loads(result.output)
        assert len(data["joins"]) == 2

    def test_has_filters_info(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "explain", "dim_customer"])
        data = json.loads(result.output)
        assert len(data["filters"]) >= 1

    def test_partition_and_cluster(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "explain", "mrt_order_summary"])
        data = json.loads(result.output)
        assert data["partition_by"] == "order_date"
        assert data["cluster_by"] == ["customer_id"]

    def test_dialect_override(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--dialect", "bigquery", "explain", "mrt_order_summary"])
        assert result.exit_code == 0
