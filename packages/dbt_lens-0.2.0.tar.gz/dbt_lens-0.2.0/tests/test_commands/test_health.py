from pathlib import Path

from click.testing import CliRunner

from dbt_lens.cli import cli


def test_health_basic(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "health"])
    assert result.exit_code == 0
    assert "Model Coverage" in result.output
    assert "Size Warnings" in result.output
    assert "Macro Usage" in result.output
    assert "Source Freshness" in result.output
    assert "Layer Summary" in result.output


def test_health_shows_untested_models(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "health"])
    assert result.exit_code == 0
    assert "0 tests" in result.output


def test_health_shows_source_freshness(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "health"])
    assert result.exit_code == 0
    # One source (raw.customers) has no freshness config, raw.orders does
    assert "1/2" in result.output


def test_health_json(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "--format", "json", "health"])
    assert result.exit_code == 0
    import json

    data = json.loads(result.output)
    assert "coverage" in data
    assert "sizes" in data
    assert "macros" in data
    assert "freshness" in data
    assert "layers" in data


def test_health_custom_warn_lines(small_manifest_path: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--manifest", str(small_manifest_path), "health", "--warn-lines", "3"])
    assert result.exit_code == 0
