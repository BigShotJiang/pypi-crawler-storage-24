from __future__ import annotations

import warnings

import pytest

from dbt_lens.core.column_lineage import ColumnTrace, ModelSummary, explain_model, get_dialect, trace_column


class TestGetDialect:
    def test_bigquery_autodetect(self, graph):
        assert get_dialect(graph) == "bigquery"

    def test_override(self, graph):
        assert get_dialect(graph, override="snowflake") == "snowflake"

    def test_unknown_adapter(self, graph):
        graph.adapter_type = "unknown_adapter"
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = get_dialect(graph)
        graph.adapter_type = "bigquery"  # restore
        assert result is None
        assert len(w) == 1
        assert "Unknown adapter type" in str(w[0].message)


class TestTraceColumnSimple:
    def test_simple_passthrough(self, graph):
        """stg_orders.order_id = id AS order_id from source."""
        trace = trace_column(graph, "stg_orders", "order_id", dialect="bigquery")
        assert isinstance(trace, ColumnTrace)
        assert trace.target_model == "model.test_project.stg_orders"
        assert trace.target_column == "order_id"
        assert trace.root.column == "order_id"
        assert len(trace.root.children) >= 1

    def test_simple_rename(self, graph):
        """stg_orders.total_amount = amount AS total_amount from source."""
        trace = trace_column(graph, "stg_orders", "total_amount", dialect="bigquery")
        assert trace.root.column == "total_amount"
        assert len(trace.root.children) >= 1

    def test_multi_hop_trace(self, graph):
        """dim_order.order_id traces through int_orders_enriched -> stg_orders -> source."""
        trace = trace_column(graph, "dim_order", "order_id", dialect="bigquery")
        assert trace.root.column == "order_id"
        assert len(trace.root.children) >= 1

    def test_join_column_from_second_table(self, graph):
        """int_orders_enriched.customer_name comes from stg_customers.name via JOIN."""
        trace = trace_column(graph, "int_orders_enriched", "customer_name", dialect="bigquery")
        assert trace.root.column == "customer_name"
        assert len(trace.root.children) >= 1

    def test_multi_table_mart(self, graph):
        """mrt_order_summary.customer_name joins dim_order, dim_customer, dim_date."""
        trace = trace_column(graph, "mrt_order_summary", "customer_name", dialect="bigquery")
        assert trace.root.column == "customer_name"

    def test_column_not_found(self, graph):
        with pytest.raises(ValueError, match="not found"):
            trace_column(graph, "stg_orders", "nonexistent_col", dialect="bigquery")

    def test_missing_compiled_code(self, graph):
        with pytest.raises(ValueError, match="compiled"):
            trace_column(graph, "mrt_no_compiled", "order_id", dialect="bigquery")

    def test_select_star_warning(self, graph):
        """dim_date uses SELECT * from seed with no documented columns -- should warn."""
        trace = trace_column(graph, "dim_date", "date_day", dialect="bigquery")
        assert len(trace.warnings) > 0

    def test_cte_resolution(self, graph):
        """int_orders_with_cte uses a CTE; should resolve through to stg_orders."""
        trace = trace_column(graph, "int_orders_with_cte", "order_id", dialect="bigquery")
        assert trace.root.column == "order_id"
        assert trace.root.model == "model.test_project.int_orders_with_cte"
        # Should trace through CTE into stg_orders
        assert len(trace.root.children) >= 1
        child = trace.root.children[0]
        assert child.model == "model.test_project.stg_orders"
        assert child.column == "order_id"

    def test_cte_resolution_second_column(self, graph):
        """CTE model total_amount also traces through correctly."""
        trace = trace_column(graph, "int_orders_with_cte", "total_amount", dialect="bigquery")
        assert trace.root.column == "total_amount"
        assert len(trace.root.children) >= 1
        child = trace.root.children[0]
        assert child.model == "model.test_project.stg_orders"
        assert child.column == "total_amount"

    def test_expression_excludes_alias(self, graph):
        """Expression text for aliased columns should not include the alias."""
        trace = trace_column(graph, "stg_orders", "total_amount", dialect="bigquery")
        # The SQL is `amount AS total_amount`; expression should be just `amount`
        assert "AS" not in trace.root.expression.upper() or "total_amount" not in trace.root.expression

    def test_to_dict_serialization(self, graph):
        trace = trace_column(graph, "stg_orders", "order_id", dialect="bigquery")
        d = trace.to_dict()
        assert "root" in d
        assert "children" in d["root"]
        assert d["target_column"] == "order_id"


class TestTraceColumnEdgeCases:
    def test_cycle_detection(self, graph):
        """Cycle should produce warning, not infinite loop."""
        orig_deps = graph.nodes["model.test_project.stg_orders"].depends_on_nodes[:]
        graph.nodes["model.test_project.stg_orders"].depends_on_nodes.append("model.test_project.dim_order")
        try:
            trace = trace_column(graph, "stg_orders", "order_id", dialect="bigquery")
            assert isinstance(trace, ColumnTrace)
            # Should complete without hanging
        finally:
            graph.nodes["model.test_project.stg_orders"].depends_on_nodes = orig_deps

    def test_multi_branch_expression(self, graph):
        """combined_metric = o.total_amount + c.customer_id -- should have children from both upstreams."""
        trace = trace_column(graph, "int_order_metrics", "combined_metric", dialect="bigquery")
        assert trace.root.column == "combined_metric"
        assert len(trace.root.children) >= 2  # from dim_order and dim_customer

    def test_case_expression(self, graph):
        """order_tier = CASE WHEN o.total_amount > 100 ... -- should trace total_amount."""
        trace = trace_column(graph, "int_order_metrics", "order_tier", dialect="bigquery")
        assert trace.root.column == "order_tier"
        assert len(trace.root.children) >= 1  # at least total_amount


class TestExplainModel:
    def test_basic_explain(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert isinstance(summary, ModelSummary)
        assert summary.name == "mrt_order_summary"
        assert summary.layer == "mart"
        assert summary.materialization == "table"

    def test_sources_detected(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert len(summary.sources) >= 3

    def test_joins_detected(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert len(summary.joins) == 2
        assert all("LEFT" in j.join_type.upper() for j in summary.joins)

    def test_filters_detected(self, graph):
        summary = explain_model(graph, "dim_customer", dialect="bigquery")
        assert len(summary.filters) >= 1

    def test_no_aggregation(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert summary.aggregations == "1:1 grain"

    def test_output_columns_count(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert summary.output_columns == 6

    def test_partition_by_dict(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert summary.partition_by == "order_date"

    def test_cluster_by(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        assert summary.cluster_by == ["customer_id"]

    def test_tests_detected(self, graph):
        summary = explain_model(graph, "dim_order", dialect="bigquery")
        assert len(summary.tests) == 2

    def test_macros_detected(self, graph):
        summary = explain_model(graph, "dim_customer", dialect="bigquery")
        assert "filter_test_emails" in summary.macros

    def test_missing_compiled_code(self, graph):
        with pytest.raises(ValueError, match="compiled"):
            explain_model(graph, "mrt_no_compiled", dialect="bigquery")

    def test_to_dict(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        d = summary.to_dict()
        assert d["name"] == "mrt_order_summary"
        assert isinstance(d["joins"], list)
        assert isinstance(d["sources"], list)

    def test_line_count(self, graph):
        summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
        node = graph.resolve_node("mrt_order_summary")
        assert summary.line_count == node.raw_code_lines

    def test_simple_model_no_joins(self, graph):
        summary = explain_model(graph, "stg_orders", dialect="bigquery")
        assert len(summary.joins) == 0
        assert len(summary.sources) == 1

    def test_partition_by_string_form(self, graph):
        node = graph.resolve_node("mrt_order_summary")
        orig = node.config.get("partition_by")
        node.config["partition_by"] = "order_date"
        try:
            summary = explain_model(graph, "mrt_order_summary", dialect="bigquery")
            assert summary.partition_by == "order_date"
        finally:
            node.config["partition_by"] = orig
