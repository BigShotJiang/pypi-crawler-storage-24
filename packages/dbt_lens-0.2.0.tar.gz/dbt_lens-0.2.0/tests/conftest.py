import json
from pathlib import Path

import pytest


@pytest.fixture
def small_manifest_path() -> Path:
    return Path(__file__).parent / "fixtures" / "small_manifest.json"


@pytest.fixture
def small_manifest_data(small_manifest_path: Path) -> dict:
    with open(small_manifest_path) as f:
        return json.load(f)


@pytest.fixture
def graph(small_manifest_path: Path):
    from dbt_lens.core.manifest import load_manifest

    return load_manifest(small_manifest_path)


def _register_commands() -> None:
    """Import command modules to register them with the CLI group.
    Uses try/except so tests pass even when not all commands exist yet."""
    for mod in [
        "dbt_lens.commands.impact",
        "dbt_lens.commands.upstream",
        "dbt_lens.commands.find",
        "dbt_lens.commands.health",
        "dbt_lens.commands.trace",
        "dbt_lens.commands.explain",
    ]:
        try:
            __import__(mod)
        except ImportError:
            pass


_register_commands()
