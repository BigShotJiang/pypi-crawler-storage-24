from pathlib import Path

import pytest

from dbt_lens.core.manifest import ProjectGraph, load_manifest
from dbt_lens.core.search import SearchIndex


@pytest.fixture
def graph(small_manifest_path: Path) -> ProjectGraph:
    return load_manifest(small_manifest_path)


@pytest.fixture
def index(graph: ProjectGraph) -> SearchIndex:
    return SearchIndex(graph)


class TestSearchIndex:
    def test_exact_model_name(self, index: SearchIndex) -> None:
        results = index.search("stg_orders")
        assert len(results) > 0
        assert results[0].name == "stg_orders"
        assert results[0].result_type == "model"

    def test_fuzzy_model_name(self, index: SearchIndex) -> None:
        results = index.search("orders")
        names = {r.name for r in results}
        assert "stg_orders" in names

    def test_column_search(self, index: SearchIndex) -> None:
        results = index.search("customer_id")
        col_results = [r for r in results if r.result_type == "column"]
        assert len(col_results) > 0

    def test_description_search(self, index: SearchIndex) -> None:
        results = index.search("enriched")
        names = {r.name for r in results}
        assert "int_orders_enriched" in names

    def test_filter_by_type_model(self, index: SearchIndex) -> None:
        results = index.search("order", result_type="model")
        assert all(r.result_type == "model" for r in results)

    def test_filter_by_type_column(self, index: SearchIndex) -> None:
        results = index.search("order_id", result_type="column")
        assert all(r.result_type == "column" for r in results)

    def test_limit(self, index: SearchIndex) -> None:
        results = index.search("order", limit=2)
        assert len(results) <= 2

    def test_no_results(self, index: SearchIndex) -> None:
        results = index.search("zzz_nonexistent_xyz")
        assert len(results) == 0

    def test_results_sorted_by_score(self, index: SearchIndex) -> None:
        results = index.search("stg_orders")
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_source_appears_in_results(self, index: SearchIndex) -> None:
        results = index.search("raw.orders", result_type="source")
        assert len(results) > 0
