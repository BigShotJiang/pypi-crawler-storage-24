"""Session migration test: xiaohongshu login state transfer between browser-use sessions.

Usage:
    Step 1: python scripts/session_migration_test.py open
            -> Creates session, navigates to xiaohongshu.com
            -> Prints live URL for user to log in
            -> Keeps session open (saves session info to /tmp/bu_session.json)

    Step 2: python scripts/session_migration_test.py extract
            -> Connects to existing session via saved CDP URL
            -> Extracts cookies + localStorage
            -> Saves to /tmp/bu_state.json
            -> Closes session 1

    Step 3: python scripts/session_migration_test.py migrate
            -> Creates new session 2
            -> Injects cookies + localStorage from /tmp/bu_state.json
            -> Navigates to xiaohongshu.com to verify login state
            -> Prints live URL for visual verification
"""

import json
import os
import sys

os.environ.setdefault(
    "BROWSER_USE_API_KEY",
    "bu_rgIr9nOAFHq02d-ZIW2wDTAkbJNKuUnTlSlZ6EL1pvA",
)

STATE_FILE = "/tmp/bu_state.json"
SESSION_FILE = "/tmp/bu_session.json"

from browser_use_lite import BrowserUseCloud
from playwright.sync_api import sync_playwright


def cmd_open():
    """Create session, navigate to xiaohongshu.com."""
    client = BrowserUseCloud()
    session = client.sessions.create(timeout=30)

    print(f"Session ID: {session.session_id}")
    print(f"CDP URL:    {session.cdp_url}")
    print(f"Live URL:   {session.inspect_url}")

    # Save session info for extract step
    with open(SESSION_FILE, "w") as f:
        json.dump({"session_id": session.session_id, "cdp_url": session.cdp_url}, f)

    pw = sync_playwright().start()
    browser = pw.chromium.connect_over_cdp(session.cdp_url)
    context = browser.contexts[0]
    page = context.pages[0] if context.pages else context.new_page()

    page.goto("https://www.xiaohongshu.com", wait_until="domcontentloaded", timeout=30000)
    print(f"Page title: {page.title()}")
    print(f"Page URL:   {page.url}")
    print()
    print("Session is open. Log in via Live URL, then run 'extract' command.")

    # Disconnect playwright but keep session alive
    browser.close()
    pw.stop()
    client.close()


def cmd_extract():
    """Connect to existing session, extract state, close session."""
    if not os.path.exists(SESSION_FILE):
        print(f"No session file at {SESSION_FILE}. Run 'open' first.")
        sys.exit(1)

    with open(SESSION_FILE) as f:
        sess = json.load(f)

    print(f"Connecting to session: {sess['session_id']}")

    pw = sync_playwright().start()
    browser = pw.chromium.connect_over_cdp(sess["cdp_url"])
    context = browser.contexts[0]
    page = context.pages[0] if context.pages else context.new_page()

    print(f"Page URL:   {page.url}")
    print(f"Page title: {page.title()}")

    # Extract cookies
    cookies = context.cookies()

    # Extract localStorage
    ls_data = page.evaluate("""() => {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            data[key] = localStorage.getItem(key);
        }
        return data;
    }""")

    state = {
        "cookies": cookies,
        "localStorage": ls_data,
        "url": page.url,
    }

    with open(STATE_FILE, "w") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

    print(f"\nState saved to {STATE_FILE}")
    print(f"  Cookies: {len(cookies)}")
    print(f"  localStorage keys: {len(ls_data)}")

    # Close session 1
    browser.close()
    pw.stop()

    client = BrowserUseCloud()
    client.sessions.delete(sess["session_id"])
    client.close()
    print("Session 1 closed.")
    os.remove(SESSION_FILE)


def cmd_migrate():
    """Create new session, inject saved state, verify login."""
    if not os.path.exists(STATE_FILE):
        print(f"No state file at {STATE_FILE}. Run 'open' then 'extract' first.")
        sys.exit(1)

    with open(STATE_FILE) as f:
        state = json.load(f)

    print(f"Loaded state: {len(state['cookies'])} cookies, "
          f"{len(state['localStorage'])} localStorage keys")

    # Create new session
    client = BrowserUseCloud()
    session = client.sessions.create(timeout=30)

    print(f"\nSession 2 ID: {session.session_id}")
    print(f"CDP URL:      {session.cdp_url}")
    print(f"Live URL:     {session.inspect_url}")

    pw = sync_playwright().start()
    browser = pw.chromium.connect_over_cdp(session.cdp_url)
    context = browser.contexts[0]
    page = context.pages[0] if context.pages else context.new_page()

    # Inject cookies via CDP
    cdp_session = context.new_cdp_session(page)

    cookie_ok = 0
    for cookie in state["cookies"]:
        params = {
            "name": cookie["name"],
            "value": cookie["value"],
            "domain": cookie.get("domain", ""),
            "path": cookie.get("path", "/"),
        }
        if cookie.get("expires", -1) > 0:
            params["expires"] = cookie["expires"]
        if cookie.get("httpOnly"):
            params["httpOnly"] = True
        if cookie.get("secure"):
            params["secure"] = True
        if cookie.get("sameSite"):
            params["sameSite"] = cookie["sameSite"]
        try:
            cdp_session.send("Network.setCookie", params)
            cookie_ok += 1
        except Exception as e:
            print(f"  Cookie '{cookie['name']}' failed: {e}")

    print(f"\nInjected {cookie_ok}/{len(state['cookies'])} cookies via CDP")

    # Navigate to xiaohongshu to inject localStorage
    page.goto("https://www.xiaohongshu.com", wait_until="domcontentloaded", timeout=30000)

    # Inject localStorage
    if state["localStorage"]:
        page.evaluate("""(items) => {
            for (const [key, value] of Object.entries(items)) {
                localStorage.setItem(key, value);
            }
        }""", state["localStorage"])
        print(f"Injected {len(state['localStorage'])} localStorage keys")

    # Reload to apply injected state
    page.reload(wait_until="domcontentloaded", timeout=30000)

    print(f"\nPage title: {page.title()}")
    print(f"Page URL:   {page.url}")
    print("\nCheck Live URL above to verify login state was migrated.")
    print("Session 2 is kept open. Save session info for later cleanup.")

    with open(SESSION_FILE, "w") as f:
        json.dump({"session_id": session.session_id, "cdp_url": session.cdp_url}, f)

    browser.close()
    pw.stop()
    client.close()


def cmd_close():
    """Close any open session."""
    if not os.path.exists(SESSION_FILE):
        print("No open session.")
        return
    with open(SESSION_FILE) as f:
        sess = json.load(f)
    client = BrowserUseCloud()
    client.sessions.delete(sess["session_id"])
    client.close()
    os.remove(SESSION_FILE)
    print(f"Session {sess['session_id']} closed.")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    cmds = {"open": cmd_open, "extract": cmd_extract, "migrate": cmd_migrate, "close": cmd_close}
    fn = cmds.get(cmd)
    if fn is None:
        print(f"Unknown command: {cmd}")
        print(f"Available: {', '.join(cmds)}")
        sys.exit(1)
    fn()


if __name__ == "__main__":
    main()
