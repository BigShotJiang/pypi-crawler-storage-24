# pyprover9

`pyprover9` is a lightweight Python wrapper for the **Prover9** automated
theorem prover developed by William McCune.

**Status:** Experimental research and teaching tool.

The package is designed primarily for use in interactive environments such as
Google Colab, providing a simple interface for running Prover9 from Python
code and capturing the resulting proofs and diagnostic output.

## Installation

```bash
pip install pyprover9
```
