# nlai

**Evidence-gated claims, continuity anchors, and receipts for agent workflows.**

Language is a proposal, not an authority. When an AI agent says "tests pass" or
"the code is thread-safe," those are *claims* — not facts. `nlai` provides the
irreducible mechanism for tracking what was claimed, checking it against
constraints, and producing content-addressed receipts that prove the decision.

## 10-second demo

```python
from nlai import gate, Anchor

# Gate agent output — extract claims, produce receipt
result = gate("The tests definitely pass and the code is thread-safe.")
print(result.verdict)       # "pass" (no anchors to violate)
print(result.claims)        # [Claim("definitely", assertive), ...]
print(result.receipt.receipt_id)  # "sha256:..."

# Add constraints
anchors = [
    Anchor(id="no-thread-claims", description="Don't claim thread safety",
           forbidden=("thread-safe", "thread safe")),
]

result = gate("The code is thread-safe.", anchors=anchors)
print(result.verdict)       # "block"
print(result.violations)    # [Violation("no-thread-claims", ...)]
```

## What this is

The kernel that [Agent Governor](https://github.com/unpingable/agent_gov) builds on.
Same law, smaller jurisdiction.

- Claims require evidence
- Decisions produce receipts
- Anchors enforce continuity
- Violations resolve deterministically

## What this is NOT

- No daemon, no socket, no RPC
- No adaptive policy, no orchestration
- No external dependencies (stdlib only)
- No "lite mode" weaker enforcement

## Install

```bash
pip install nlai
```

Requires Python 3.10+. Zero dependencies.

## API

```python
# The gate function
gate(text, *, anchors=None) -> GateResult

# Data types
GateResult(verdict, receipt, claims, violations)
Receipt(receipt_id, schema_version, timestamp, gate, verdict, subject_hash, evidence_hash)
Anchor(id, description, required, forbidden, severity, constraint_class)
Claim(text, strength, status, span)
Violation(anchor_id, severity, description, evidence)

# Utilities
canonical_json(obj) -> bytes
content_hash(data: bytes) -> str
verify_receipt(receipt) -> bool
extract_claims(text) -> list[Claim]
assertiveness_score(text) -> float
```

## Verdicts

| Verdict | Meaning |
|---------|---------|
| `pass` | No violations |
| `warn` | Violations found, but only at `warn` severity |
| `block` | Violations at `correct` or `reject` severity |
| `observe` | Informational only (used by infrastructure) |

## Receipts

Every `gate()` call produces a content-addressed receipt:

```
receipt_id = H(schema_version + gate + subject_hash + evidence_hash)
```

Same inputs = same receipt_id. Timestamp is metadata, not identity.
Receipts can be verified offline with `verify_receipt()`.

## Relationship to Agent Governor

```
nlai (kernel)
    ^
agent_gov (runtime + policy + orchestration)
    ^
plugins / clerk / phosphor (distribution surfaces)
```

`nlai` is the foundation. Agent Governor adds regime detection, lane routing,
multi-agent coordination, and everything else needed for production governance.

## License

Apache-2.0
