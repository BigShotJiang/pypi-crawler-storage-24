# SPDX-License-Identifier: Apache-2.0
"""Resolver: determine verdict from violations.

Given a list of anchor violations, determine the overall verdict.
The verdict hierarchy: block > warn > pass.
"""

from __future__ import annotations

from .anchors import Violation, SEVERITY_REJECT, SEVERITY_CORRECT, SEVERITY_WARN
from .receipt import VERDICT_PASS, VERDICT_WARN, VERDICT_BLOCK


def resolve_verdict(violations: list[Violation]) -> str:
    """Determine verdict from violations.

    - No violations → pass
    - Any REJECT severity → block
    - Any CORRECT severity → block (needs correction, can't proceed)
    - Only WARN severity → warn
    """
    if not violations:
        return VERDICT_PASS

    for v in violations:
        if v.severity in (SEVERITY_REJECT, SEVERITY_CORRECT):
            return VERDICT_BLOCK

    return VERDICT_WARN
