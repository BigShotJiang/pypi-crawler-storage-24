# SPDX-License-Identifier: Apache-2.0
"""Tests for verdict resolution from violations."""

from nlai import Violation
from nlai.resolver import resolve_verdict


class TestResolveVerdict:
    """Verdict determination from violations."""

    def test_no_violations_pass(self):
        assert resolve_verdict([]) == "pass"

    def test_warn_only(self):
        violations = [
            Violation(anchor_id="a", severity="warn", description="minor"),
        ]
        assert resolve_verdict(violations) == "warn"

    def test_correct_blocks(self):
        violations = [
            Violation(anchor_id="a", severity="correct", description="fix"),
        ]
        assert resolve_verdict(violations) == "block"

    def test_reject_blocks(self):
        violations = [
            Violation(anchor_id="a", severity="reject", description="no"),
        ]
        assert resolve_verdict(violations) == "block"

    def test_mixed_highest_wins(self):
        violations = [
            Violation(anchor_id="a", severity="warn", description="minor"),
            Violation(anchor_id="b", severity="reject", description="bad"),
        ]
        assert resolve_verdict(violations) == "block"

    def test_multiple_warns(self):
        violations = [
            Violation(anchor_id="a", severity="warn", description="1"),
            Violation(anchor_id="b", severity="warn", description="2"),
        ]
        assert resolve_verdict(violations) == "warn"
