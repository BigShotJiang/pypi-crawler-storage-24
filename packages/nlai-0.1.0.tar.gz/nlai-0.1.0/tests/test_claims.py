# SPDX-License-Identifier: Apache-2.0
"""Tests for claim extraction."""

import pytest

from nlai import Claim, extract_claims, assertiveness_score
from nlai.claims import (
    STRENGTH_ASSERTIVE, STRENGTH_HEDGED,
    STATUS_UNSUPPORTED,
)


class TestClaim:
    """Claim dataclass behavior."""

    def test_frozen(self):
        c = Claim(text="test", strength=STRENGTH_ASSERTIVE)
        with pytest.raises(AttributeError):
            c.text = "other"  # type: ignore[misc]

    def test_invalid_strength(self):
        with pytest.raises(ValueError, match="Invalid strength"):
            Claim(text="test", strength="invalid")

    def test_defaults(self):
        c = Claim(text="test", strength=STRENGTH_ASSERTIVE)
        assert c.status == STATUS_UNSUPPORTED
        assert c.span == (0, 0)

    def test_roundtrip(self):
        c = Claim(text="definitely", strength=STRENGTH_ASSERTIVE,
                  span=(5, 15))
        d = c.to_dict()
        c2 = Claim.from_dict(d)
        assert c == c2


class TestExtractClaims:
    """Assertive and hedged claim extraction."""

    def test_no_claims(self):
        claims = extract_claims("The weather is nice today.")
        assert claims == []

    def test_assertive_claim(self):
        claims = extract_claims("This is definitely the right approach.")
        assert len(claims) >= 1
        assertive = [c for c in claims if c.strength == STRENGTH_ASSERTIVE]
        assert len(assertive) >= 1
        assert any("definitely" in c.text.lower() for c in assertive)

    def test_hedged_claim(self):
        claims = extract_claims("I think this might work.")
        hedged = [c for c in claims if c.strength == STRENGTH_HEDGED]
        assert len(hedged) >= 1

    def test_multiple_claims(self):
        text = "I think it works, and it's definitely correct."
        claims = extract_claims(text)
        assert len(claims) >= 2

    def test_founded_in(self):
        claims = extract_claims("Apple was founded in 1976.")
        assertive = [c for c in claims if c.strength == STRENGTH_ASSERTIVE]
        assert len(assertive) >= 1

    def test_is_located(self):
        claims = extract_claims("The office is located in New York.")
        assertive = [c for c in claims if c.strength == STRENGTH_ASSERTIVE]
        assert len(assertive) >= 1

    def test_span_tracking(self):
        text = "It is definitely true."
        claims = extract_claims(text)
        assert len(claims) >= 1
        c = claims[0]
        assert text[c.span[0]:c.span[1]] == c.text

    def test_no_duplicates(self):
        """Same span should not produce duplicate claims."""
        text = "definitely definitely"
        claims = extract_claims(text)
        spans = [c.span for c in claims]
        assert len(spans) == len(set(spans))


class TestAssertivenessScore:
    """Assertiveness scoring."""

    def test_no_claims_zero(self):
        assert assertiveness_score("Hello world.") == 0.0

    def test_assertive_text(self):
        text = ("This is definitely correct, clearly right, "
                "obviously true, certainly valid, undoubtedly so.")
        score = assertiveness_score(text)
        assert score == 1.0

    def test_hedged_lower(self):
        """Hedged claims contribute less than assertive."""
        hedged_score = assertiveness_score("I think it works.")
        assertive_score = assertiveness_score("It definitely works.")
        assert assertive_score > hedged_score

    def test_range(self):
        """Score is always in [0.0, 1.0]."""
        for text in ["", "hello", "definitely", "I think maybe"]:
            score = assertiveness_score(text)
            assert 0.0 <= score <= 1.0
