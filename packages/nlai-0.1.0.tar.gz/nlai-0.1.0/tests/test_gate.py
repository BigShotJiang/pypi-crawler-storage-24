# SPDX-License-Identifier: Apache-2.0
"""Tests for the gate() function — the whole kernel surface."""

from nlai import gate, Anchor, GateResult, verify_receipt


class TestGateBasic:
    """Basic gate behavior."""

    def test_returns_gate_result(self):
        result = gate("Hello world.")
        assert isinstance(result, GateResult)

    def test_pass_no_anchors(self):
        result = gate("Hello world.")
        assert result.verdict == "pass"

    def test_has_receipt(self):
        result = gate("Hello world.")
        assert result.receipt is not None
        assert result.receipt.gate == "nlai_gate"

    def test_receipt_verifies(self):
        result = gate("Hello world.")
        assert verify_receipt(result.receipt) is True

    def test_extracts_claims(self):
        result = gate("This is definitely the right approach.")
        assert len(result.claims) >= 1

    def test_no_claims_still_passes(self):
        result = gate("The weather is nice.")
        assert result.verdict == "pass"
        assert result.violations == []


class TestGateWithAnchors:
    """Gate with anchor constraints."""

    def test_forbidden_blocks(self):
        anchors = [
            Anchor(id="no-thread", description="No thread-safety claims",
                   forbidden=("thread-safe", "thread safe")),
        ]
        result = gate("The code is thread-safe.", anchors=anchors)
        assert result.verdict == "block"
        assert len(result.violations) >= 1

    def test_required_missing_blocks(self):
        anchors = [
            Anchor(id="must-test", description="Must mention tests",
                   required=("tests pass",)),
        ]
        result = gate("The code compiles.", anchors=anchors)
        assert result.verdict == "block"

    def test_required_present_passes(self):
        anchors = [
            Anchor(id="must-test", description="Must mention tests",
                   required=("tests pass",)),
        ]
        result = gate("All tests pass successfully.", anchors=anchors)
        assert result.verdict == "pass"

    def test_warn_severity(self):
        anchors = [
            Anchor(id="soft", description="Soft check",
                   forbidden=("bad",), severity="warn"),
        ]
        result = gate("This is bad.", anchors=anchors)
        assert result.verdict == "warn"

    def test_multiple_anchors(self):
        anchors = [
            Anchor(id="a1", description="A1", forbidden=("bad",)),
            Anchor(id="a2", description="A2", required=("good",)),
        ]
        result = gate("This is bad.", anchors=anchors)
        assert result.verdict == "block"
        assert len(result.violations) == 2  # forbidden + missing required

    def test_all_pass(self):
        anchors = [
            Anchor(id="a1", description="A1", required=("hello",)),
            Anchor(id="a2", description="A2", forbidden=("goodbye",)),
        ]
        result = gate("hello world", anchors=anchors)
        assert result.verdict == "pass"
        assert result.violations == []


class TestGateContentAddressing:
    """Receipt content-addressing through gate()."""

    def test_same_text_same_receipt_id(self):
        r1 = gate("Hello world.")
        r2 = gate("Hello world.")
        assert r1.receipt.receipt_id == r2.receipt.receipt_id

    def test_different_text_different_receipt_id(self):
        r1 = gate("Hello world.")
        r2 = gate("Goodbye world.")
        assert r1.receipt.receipt_id != r2.receipt.receipt_id

    def test_anchors_change_evidence_hash(self):
        """Different anchor configs produce different evidence hashes."""
        r1 = gate("Hello world.")
        r2 = gate("Hello world.", anchors=[
            Anchor(id="test", description="Test"),
        ])
        # Evidence hash differs because anchor_count differs
        assert r1.receipt.evidence_hash != r2.receipt.evidence_hash


class TestGateResultSerialization:
    """GateResult.to_dict()."""

    def test_to_dict(self):
        result = gate("Hello world.")
        d = result.to_dict()
        assert "verdict" in d
        assert "receipt" in d
        assert "claims" in d
        assert "violations" in d
        assert isinstance(d["receipt"], dict)
