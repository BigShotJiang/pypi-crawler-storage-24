# SPDX-License-Identifier: Apache-2.0
"""Tests for serialization roundtrips and future version rejection."""

import json

import pytest

from nlai import (
    Receipt, Anchor, Claim, Violation,
    canonical_json, verify_receipt, create_receipt,
)
from nlai.receipt import RECEIPT_SCHEMA_VERSION


class TestReceiptRoundtrip:
    """Receipt serialize/deserialize."""

    def test_json_roundtrip(self):
        r = create_receipt(gate="test", verdict="pass",
                           subject_kind="text", subject_bytes=b"hello")
        j = json.dumps(r.to_dict())
        d = json.loads(j)
        r2 = Receipt.from_dict(d)
        assert r == r2
        assert verify_receipt(r2)

    def test_canonical_json_roundtrip(self):
        r = create_receipt(gate="test", verdict="pass",
                           subject_kind="text", subject_bytes=b"hello")
        b = canonical_json(r.to_dict())
        d = json.loads(b)
        r2 = Receipt.from_dict(d)
        assert r == r2


class TestAnchorRoundtrip:
    """Anchor serialize/deserialize."""

    def test_json_roundtrip(self):
        a = Anchor(id="test", description="Test",
                   required=("foo",), forbidden=("bar",),
                   severity="reject", constraint_class="invariant")
        j = json.dumps(a.to_dict())
        d = json.loads(j)
        a2 = Anchor.from_dict(d)
        assert a == a2

    def test_minimal_dict(self):
        """from_dict with only required fields."""
        d = {"id": "test", "description": "Test"}
        a = Anchor.from_dict(d)
        assert a.required == ()
        assert a.forbidden == ()


class TestClaimRoundtrip:
    """Claim serialize/deserialize."""

    def test_json_roundtrip(self):
        c = Claim(text="definitely", strength="assertive",
                  status="unsupported", span=(5, 15))
        j = json.dumps(c.to_dict())
        d = json.loads(j)
        c2 = Claim.from_dict(d)
        assert c == c2


class TestViolationRoundtrip:
    """Violation serialize/deserialize."""

    def test_json_roundtrip(self):
        v = Violation(anchor_id="test", severity="reject",
                      description="Bad thing",
                      evidence=("found 'foo'",))
        j = json.dumps(v.to_dict())
        d = json.loads(j)
        v2 = Violation.from_dict(d)
        assert v == v2


class TestFutureVersionRejection:
    """Future schema version handling."""

    def test_receipt_rejects_future(self):
        d = {
            "receipt_id": "abc",
            "schema_version": RECEIPT_SCHEMA_VERSION + 1,
            "timestamp": "now",
            "gate": "test",
            "verdict": "pass",
            "subject_hash": "abc",
            "evidence_hash": "def",
        }
        with pytest.raises(ValueError, match="newer than supported"):
            Receipt.from_dict(d)

    def test_receipt_accepts_current(self):
        d = {
            "receipt_id": "abc",
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "timestamp": "now",
            "gate": "test",
            "verdict": "pass",
            "subject_hash": "abc",
            "evidence_hash": "def",
        }
        r = Receipt.from_dict(d)
        assert r.schema_version == RECEIPT_SCHEMA_VERSION

    def test_receipt_accepts_older(self):
        """Schema version 0 (hypothetical older) should still work."""
        d = {
            "receipt_id": "abc",
            "schema_version": 0,
            "timestamp": "now",
            "gate": "test",
            "verdict": "pass",
            "subject_hash": "abc",
            "evidence_hash": "def",
        }
        r = Receipt.from_dict(d)
        assert r.schema_version == 0
