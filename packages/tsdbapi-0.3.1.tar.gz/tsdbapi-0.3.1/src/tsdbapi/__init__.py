import threading
from queue import Queue

from werkzeug import Request
from werkzeug import Response
from werkzeug.serving import make_server
import webbrowser
from time import time
from datetime import date
import polars as pl

from requests_oauthlib import OAuth2Session
import requests
import os

# OAuth token storage
token = None

config = {
    "api_key": os.getenv("TSDBAPI_API_KEY", None),
    "oauth_client_id": os.getenv("TSDBAPI_OAUTH_CLIENT_ID", "tsdb-api"),
    "oauth_token_url": os.getenv("TSDBAPI_OAUTH_TOKEN_URL", "https://keycloak.kof.ethz.ch/realms/main/protocol/openid-connect/token"),
    "oauth_auth_url": os.getenv("TSDBAPI_OAUTH_AUTH_URL", "https://keycloak.kof.ethz.ch/realms/main/protocol/openid-connect/auth"),
    "url_production": os.getenv("TSDBAPI_URL_PRODUCTION", "https://tsdb-api.kof.ethz.ch/v2/"),
    "url_staging": os.getenv("TSDBAPI_URL_STAGING", "https://tsdb-api.stage.kof.ethz.ch/v2/"),
    "url_test": os.getenv("TSDBAPI_URL_TEST", "http://localhost:3001/v2/"),
    "environment": os.getenv("TSDBAPI_ENVIRONMENT", "production"),
    "access_type": os.getenv("TSDBAPI_ACCESS_TYPE", "auth"),
    "read_before_release": os.getenv("TSDBAPI_READ_BEFORE_RELEASE", True),
}

def _base_url():
    if config["environment"] == "production":
        return config["url_production"]
    elif config["environment"] == "staging":
        return config["url_staging"]
    elif config["environment"] == "test":
        return config["url_test"]
    else:
        raise ValueError(f"Unknown environment: {config['environment']}")
    
def get_config() -> dict:
    """Get the current package configuration.

    Returns:
        dict: Current package configuration
    """
    return config

def set_config(**kwargs: str) -> None:
    """Update package configuration.

    Args:
        **kwargs: Configuration values to set. Recognized keys:
            api_key (str): API key for programmatic access.
            oauth_client_id (str): OAuth client identifier (default: "tsdb-api").
            environment (str): Whether to use the production, staging or test API. Must be one of 'production', 'staging', 'test'.
            oauth_token_url (str): OAuth token URL.
            oauth_auth_url (str): OAuth authorization URL.
            url_production (str): Base URL of the production API.
            url_staging (str): Base URL of the staging API.
            url_test (str): Base URL of the test API.
            access_type (str): How to access time series data. Must be one of 'auth' (the default), 'public' or 'preview'.
                The access types 'public' and 'preview' bypass authentication.
                Use the access type 'public' to read public time series and the access type 'preview' to read time series previews (latest 2 years of data missing).
                Use 'auth' for authenticated access.
            read_before_release (bool): Whether to read time series vintages before their official release. Defaults to True. This option will only have
                an effect if you have pre release access to the requested time series.

    """
    global config
    config = { **config, **kwargs }

def _get_token(access_type = None):

    env_set = "OAUTHLIB_INSECURE_TRANSPORT" in os.environ
    # Enable redirect to loopback address (ok since HTTP request never leaves the device, see RFC 8252 section 8.3).
    os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

    session = OAuth2Session(client_id=config["oauth_client_id"], pkce="S256")
    url = _get_auth_code_url(session)
    token = session.fetch_token(token_url=config["oauth_token_url"],
                                authorization_response=url,
                                access_type=access_type)
    token["refresh_time"] = time()

    if not env_set:
        del os.environ["OAUTHLIB_INSECURE_TRANSPORT"]

    return token

def _get_auth_code_url(session):

    @Request.application
    def app(request):
        q.put(request.url)
        return Response("Authentication complete. You can close this page now.", 200, content_type="text/plain")

    s = make_server("127.0.0.1", 0, app)
    session.redirect_uri = f"http://127.0.0.1:{s.port}/"
    authorization_url, state = session.authorization_url(config["oauth_auth_url"])
    print("Waiting for authentication in browser...")
    webbrowser.open(authorization_url)
    
    q = Queue()
    t = threading.Thread(target=s.serve_forever)
    t.start()
    print("waiting")
    url = q.get(block=True)
    s.shutdown()
    t.join()

    return url

def _refresh_token(refresh_token):
    global token
    session = OAuth2Session(client_id=config["oauth_client_id"], pkce="S256")
    token = session.refresh_token(
        token_url=config["oauth_token_url"],
        client_id=config["oauth_client_id"],
        refresh_token=refresh_token
    )
    token["refresh_time"] = time()

def _make_request(method, url, **kwargs):
    
    if config["api_key"] is not None:
        res = requests.request(method, url, headers={ "x-api-key": config["api_key"] }, **kwargs)
    else:
        global token
        if token is None:
            token = _get_token()
        else:
            if token["refresh_time"] + token["refresh_expires_in"] < time() + 10:
                token = _get_token()
            if token["refresh_time"] + token["expires_in"] < time() + 10:
                _refresh_token(token["refresh_token"])

        session = OAuth2Session(client_id=config["oauth_client_id"], pkce="S256", token=token)
        res = session.request(method, url, **kwargs)
    
    data = res.json()
    if not res.ok:
        print(res.status_code, res.reason)
        print(data["message"])
        raise RuntimeError(data["message"])
        
    return data

def _to_bool_query_param(value):
    "true" if value else ""

def read_ts_release(
        ts_keys: list[str],
        valid_on: date = date.today(),
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read a time series vintage release information. The vintage is specified by the valid_on parameter.

    Args:
        ts_keys (list[str]): Unique time series identifiers (keys)
        valid_on (date, optional): Selects the time series vintage with the vintage date equal to or before this date. Defaults to date.today().
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series data. Defaults to False.

    Returns:
        pl.DataFrame: Table with columns ts_key, vintage_date, release_topic, release_year, release_period and release_time
    """

    if isinstance(ts_keys, str):
        ts_keys = [ts_keys]
    
    data = _make_request(
        "GET",
        _base_url() + "ts/release",
        params={
            "keys": ",".join(ts_keys),
            "valid_on": valid_on.strftime("%Y-%m-%d"),
            "ignore_missing": _to_bool_query_param(ignore_missing)
        }
    )
    return pl.DataFrame(data)

def read_ts_release_future(
        ts_keys: list[str],
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read the release information of future time series vintages.

    Args:
        ts_keys (list[str]): Unique time series identifiers (keys)
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series data. Defaults to False.

    Returns:
        pl.DataFrame: Table with columns ts_key, release_topic, release_year, release_period and release_time
    """
    if isinstance(ts_keys, str):
        ts_keys = [ts_keys]
    
    data = _make_request(
        "GET",
        _base_url() + "ts/release/future",
        params={
            "keys": ",".join(ts_keys),
            "ignore_missing": _to_bool_query_param(ignore_missing)
        }
    )
    return pl.DataFrame(data)

def read_ts(
        ts_keys: list[str],
        valid_on: date = date.today(),
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read time series given by their unique identifiers (keys). The vintage is specified by the valid_on parameter.
    By default, the most recent vintage is read.

    Args:
        ts_keys (list[str]): Unique time series identifiers (keys)
        valid_on (date, optional): Selects the time series vintage with the vintage date equal to or before this date. Defaults to date.today().
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series data. Defaults to False.

    Returns:
        pl.DataFrame: Table with colunms ts_key, time, value
    """

    if isinstance(ts_keys, str):
        ts_keys = [ts_keys]
        
    data = _make_request(
        "GET", 
        _base_url() + "ts",
        params={
            "keys": ",".join(ts_keys),
            "df": "Y-m-d",
            "mime": "json",
            "valid_on": valid_on.strftime("%Y-%m-%d"),
            "ignore_missing": _to_bool_query_param(ignore_missing)
        }
    )

    return _ts_data_to_df(data)

def read_collection_ts(
        collection: str,
        owner: str = "self",
        valid_on: date = date.today(),
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read the time series in a time series collection. The time series vintage is specified by the valid_on parameter.
    By default, the most recent vintage is read.

    Args:
        collection (str): Name of the time series collection
        owner (str, optional): Username of the owner of the time series collection. Defaults to "self".
        valid_on (date, optional): Selects the time series vintage with the vintage date equal to or before this date. Defaults to date.today().
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series data. Defaults to False.

    Returns:
        pl.DataFrame: Table with columns ts_key, time, value
    """
    data = _make_request(
        "GET", 
        _base_url() + f"collections/{owner}/{collection}/ts",
        params={
            "df": "Y-m-d",
            "mime": "json",
            "valid_on": valid_on.strftime("%Y-%m-%d"),
            "ignore_missing": _to_bool_query_param(ignore_missing)
        }
    )

    return _ts_data_to_df(data)

def list_collections(
        owner: str = "self") -> list[str]:
    """Read information on existing time series collections.
    By default, the collections of the authenticated user are listed.
    To list the collections of another user, provide the username of that user as the owner parameter.

    Args:
        owner (str, optional): Username of the owner of the time series collections. Defaults to "self".

    Returns:
        pl.DataFrame: Table with a row for every existing collection.
    """
    data = _make_request(
        "GET", 
        _base_url() + f"collections/{owner}"
    )
    return pl.DataFrame(data)

def read_ts_metadata(
        ts_keys: list[str],
        locale: str = None,
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read the time series metadata of a particular locale.

    Args:
        ts_keys (list[str]): Unique time series identifiers (keys)
        locale (str, optional): The locale of the metadata. 
            Can be any string, but ISO codes are recommended (such as 'en', 'de', 'fr', 'it').
            Set to None for unlocalized metadata (default).
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series metadata. Defaults to False.

    Returns:
        pl.DataFrame: Table with columns ts_key, key, value
    """

    if isinstance(ts_keys, str):
        ts_keys = [ts_keys]
    
    data = _make_request(
        "GET", 
        _base_url() + "ts/metadata",
        params={
            "keys": ",".join(ts_keys),
            "locale": locale,
            "ignore_missing": _to_bool_query_param(ignore_missing) 
        }
    )

    return _ts_metadata_to_df(data)

def read_user_quota(
        username = "self") -> dict:
    """Check the number of time series downloads remaining in the current subscription year.

    Args:
        username (str, optional): Username of the user whose quota is to be checked. Defaults to "self".

    Returns:
        dict: Dictionary with quota information
    """
    data = _make_request(
        "GET",
        _base_url() + f"users/{username}/quota"
    )
    return data

def create_user_api_key(
        username = "self") -> dict:
    """Create an API key for a user for programmatic access.
    Any previously created API key for the user will be overwritten and therefore invalidated.
    Store the newly created API key securely because it cannot be retrieved later.

    Args:
        username (str, optional): Username of the user for whom to create an API key. Defaults to "self".

    Returns:
        dict: Dictionary with API key
    """
    data = _make_request(
        "GET",
        _base_url() + f"users/{username}/api-key"
    )
    return data

def read_collection_ts_metadata(
        collection: str,
        owner: str = "self",
        locale: str = None,
        ignore_missing: bool = False) -> pl.DataFrame:
    """Read the time series metadata of a particular locale.

    Args:
        collection (str): Name of the time series collection
        owner (str, optional): Username of the owner of the time series collection. Defaults to "self".
        locale (str, optional): The locale of the metadata. 
            Can be any string, but ISO codes are recommended (such as 'en', 'de', 'fr', 'it').
            Set to None for unlocalized metadata (default).
        ignore_missing (bool, optional): Whether to ignore missing or forbidden time series when requesting time series metadata. Defaults to False.

    Returns:
        pl.DataFrame: Table with columns ts_key, key, value
    """
    
    data = _make_request(
        "GET", 
        _base_url() + f"collections/{owner}/{collection}/ts/metadata",
        params={
            "locale": locale,
            "ignore_missing": _to_bool_query_param(ignore_missing)
        }
    )

    return _ts_metadata_to_df(data)

def _ts_metadata_to_df(data):
    df_schema = {
        "ts_key": pl.String,
        "key": pl.String,
        "value": pl.String
    }
    dfs = []
    for elem in data:
        dfs.append(
            pl.DataFrame(
                {"ts_key": elem, "key": data[elem].keys(), "value": data[elem].values()},
                schema=df_schema,
            )
        )
    if len(dfs) == 0:
        return pl.DataFrame(
            {"ts_key": [], "key": [], "value": []},
            schema=df_schema,
        )
    return pl.concat(dfs)

def _ts_data_to_df(data):
    df_schema = {
        "ts_key": pl.String,
        "time": pl.Date,
        "value": pl.Float32
    }
    dfs = []
    for elem in data:
        dfs.append(
            pl.DataFrame(
                {"ts_key": elem["ts_key"], "time": elem["time"], "value": elem["value"]},
                schema=df_schema,
            )
        )
    if len(dfs) == 0:
        return pl.DataFrame(
            {"ts_key": [], "time": [], "value": []},
            schema=df_schema,
        )
    return pl.concat(dfs)