# 天忒量化 SDK (Tiantei SDK)

股票量化交易 SDK，提供数据源插件化和特征计算功能。

## 功能特性

- **数据源插件化**：支持富途等多种数据源
- **特征计算**：内置历史特征计算管道
- **模型推理**：支持 LightGBM 和 ONNX 模型

## 安装

```bash
pip install tiantei
```

安装富途数据源支持：
```bash
pip install tiantei[futu]
```

## 快速开始

```python
from tiantei_sdk import PluginManager, calculate_his_features

# 加载数据源
pm = PluginManager(plugins_dir='./plugins')
futu = pm.load_plugin_from_file('futu')

# 获取历史数据
futu.get_history_price(num_bars=1000)

# 计算特征
calculate_his_features()
```

## 配置数据源

编辑 `plugins/futu/config.json`：

```json
{
  "host": "127.0.0.1",
  "port": 11111,
  "rsa_private_key": ""
}
```

## 许可证

MIT License
