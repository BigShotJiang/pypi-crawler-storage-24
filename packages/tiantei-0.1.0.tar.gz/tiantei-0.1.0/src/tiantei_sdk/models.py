#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一数据模型定义

与 data_sources 模块的模型保持一致，确保数据流通过程中格式统一
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any
import pandas as pd


@dataclass
class StockInfo:
    """股票基本信息"""
    symbol: str                    # AAPL
    name: str                      # Apple Inc.
    exchange: str                  # US
    industry: str = ""             # 行业
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'symbol': self.symbol,
            'name': self.name,
            'exchange': self.exchange,
            'industry': self.industry,
        }


@dataclass
class PriceData:
    """价格数据（统一格式）"""
    symbol: str
    timestamp: datetime            # 时间戳
    open: float
    high: float
    low: float
    close: float
    volume: int
    amount: Optional[float] = None  # 成交额
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'symbol': self.symbol,
            'timestamp': self.timestamp.isoformat(),
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume,
            'amount': self.amount,
        }
