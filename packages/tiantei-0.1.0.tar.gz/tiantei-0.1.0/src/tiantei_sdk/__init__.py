#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tiantei SDK - Python 版本

核心功能：
    1. 数据源插件 (DataSourcePlugin) - 获取实时和历史数据
    2. 特征引擎 (FeaturePipeline) - 批量计算历史/开盘特征
    3. 模型插件 (ModelPlugin) - 模型预测
    4. 插件管理器 (PluginManager) - 管理数据源插件

使用示例：
    from sdk import PluginManager
    
    # 加载数据源插件
    pm = PluginManager()
    futu = pm.load_plugin_from_file('futu')
    
    # 获取数据
    futu.get_history_price()  # 历史K线
    futu.get_realtime_open('2025-02-26')  # 实时开盘价
"""

from .plugin_manager import (
    PluginManager,
    DataSourcePlugin,
    ModelPlugin,
)
from .his_feature_calculator import (
    HisFeatureCalculator,
    calculate_his_features,
)
from .models import StockInfo, PriceData

__all__ = [
    'PluginManager',
    'DataSourcePlugin',
    'ModelPlugin',
    'HisFeatureCalculator',
    'calculate_his_features',
    'StockInfo',
    'PriceData',
]

__version__ = '1.0.0'
