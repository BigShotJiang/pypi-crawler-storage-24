#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
插件管理器 - 管理数据源和模型插件

支持动态加载和注册插件
"""

import os
import sys
import importlib
from typing import Dict, List, Type, Any, Optional

from sdk.models import StockInfo, PriceData


class DataSourcePlugin:
    """数据源插件基类
    
    标准接口（所有数据源必须实现）：
        - get_realtime_open(prev_trading_date):  批量更新当天的开盘价
        - get_history_price():                   批量更新历史K线日线价格
        - test_connection():                     测试连接状态
    """
    
    name: str = ""
    description: str = ""
    
    def get_realtime_open(self, prev_trading_date: str) -> bool:
        """批量更新当天的开盘价
        
        将当天的开盘价更新到上一交易日的 o1 字段：
            prev_trading_date.o1 = current_day.open
        
        Args:
            prev_trading_date: 上一交易日日期 'YYYY-MM-DD'
            
        Returns:
            bool: 是否成功
        """
        raise NotImplementedError
    
    def get_history_price(self, num_bars: int = 1000) -> bool:
        """批量更新历史K线日线价格
        
        用途：收盘后批量更新日线数据（run_after_market.bat 步骤1）
        目标：stock_daily_prices 表
        
        Args:
            num_bars: K线数量，默认1000
            
        Returns:
            bool: 是否成功
        """
        raise NotImplementedError
    
    def test_connection(self) -> bool:
        """测试连接状态"""
        return True


class ModelPlugin:
    """模型插件基类"""
    
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    
    def predict(self, model_name: str, last_trading_date: str) -> bool:
        """加载指定模型，自动获取所需特征数据，并将预测结果输出到数据库
        
        Args:
            model_name: 模型名称
            last_trading_date: 最后交易日日期 'YYYY-MM-DD'
            
        Returns:
            bool: 是否成功
        """
        raise NotImplementedError


class PluginManager:
    """
    数据源插件管理器
    
    使用示例：
        pm = PluginManager()
        
        # 动态加载数据源插件
        futu = pm.load_plugin_from_file('futu')
        
        # 使用数据源
        futu.get_history_price()
        futu.get_realtime_open('2025-02-26')
    """
    
    def __init__(self, plugins_dir: str = None):
        """
        Args:
            plugins_dir: 插件目录路径，默认为 sdk/plugins
        """
        self._data_sources: Dict[str, Type[DataSourcePlugin]] = {}
        self._data_source_instances: Dict[str, DataSourcePlugin] = {}
        self._plugins_dir = plugins_dir
    
    # ==================== 数据源管理 ====================
    
    def register_data_source(self, name: str, data_source_class: Type[DataSourcePlugin]):
        """注册数据源插件"""
        if not issubclass(data_source_class, DataSourcePlugin):
            raise ValueError(f"数据源插件必须继承 DataSourcePlugin")
        self._data_sources[name] = data_source_class
        print(f"已注册数据源: {name}")
    
    def get_data_source(self, name: str, **kwargs) -> DataSourcePlugin:
        """获取数据源实例"""
        if name not in self._data_source_instances:
            if name not in self._data_sources:
                raise ValueError(f"未找到数据源: {name}")
            self._data_source_instances[name] = self._data_sources[name](**kwargs)
        return self._data_source_instances[name]
    
    def list_data_sources(self) -> List[str]:
        """列出所有已注册的数据源"""
        return list(self._data_sources.keys())
    
    # ==================== 动态加载 ====================
    
    def load_plugin_from_file(self, data_source_name: str) -> Optional[DataSourcePlugin]:
        """
        动态加载数据源插件
        
        Args:
            data_source_name: 数据源名称（如 'futu', 'yahoo'）
            
        Returns:
            DataSourcePlugin: 数据源实例，加载失败返回 None
        """
        # 内置数据源映射（新目录结构：每个插件一个目录）
        built_in_sources = {
            'futu': 'sdk.plugins.futu.data_source.FutuDataSource',
        }
        
        try:
            if data_source_name in built_in_sources:
                # 加载内置数据源
                module_path, class_name = built_in_sources[data_source_name].rsplit('.', 1)
                module = importlib.import_module(module_path)
                data_source_class = getattr(module, class_name)
                self.register_data_source(data_source_name, data_source_class)
                return self.get_data_source(data_source_name)
            else:
                # 尝试从 plugins 目录加载第三方数据源（新结构：插件目录/data_source.py）
                if self._plugins_dir is None:
                    plugins_dir = os.path.join(os.path.dirname(__file__), 'plugins')
                else:
                    plugins_dir = self._plugins_dir
                plugin_dir = os.path.join(plugins_dir, data_source_name)
                file_path = os.path.join(plugin_dir, 'data_source.py')
                
                if not os.path.exists(file_path):
                    print(f"数据源插件不存在: {data_source_name}")
                    return None
                
                # 动态导入模块
                module_name = f"sdk.plugins.{data_source_name}.data_source"
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
                
                # 查找数据源插件类
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if isinstance(attr, type) and issubclass(attr, DataSourcePlugin) and attr != DataSourcePlugin:
                        self.register_data_source(data_source_name, attr)
                        return self.get_data_source(data_source_name)
                
                print(f"未在 {file_path} 中找到 DataSourcePlugin 实现")
                return None
                
        except Exception as e:
            print(f"加载数据源插件失败: {e}")
            return None
