#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
历史特征计算器 - SDK标准实现

整合 run_after_market.bat 步骤2-5：
    步骤2: process_daily_prices.py - 添加派生字段（总股本、均线、涨跌幅等）
    步骤3: update_history_rank.py - 更新历史排名字段
    步骤4: update_days_since_rank1.py - 计算距离历史最高排名天数
    步骤5: update_market_indicators.py - 计算市场排名、市场情绪等
"""

import sys
import os
from datetime import datetime
from typing import List

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from config import get_connection


class HisFeatureCalculator:
    """历史特征计算器 - SDK标准实现"""
    
    def __init__(self):
        self.name = "HisFeatureCalculator"
    
    def calculate(self) -> bool:
        """执行完整的历史特征计算流程
        
        Returns:
            bool: 是否成功
        """
        print("=" * 70)
        print("历史特征计算器 - SDK标准实现")
        print("=" * 70)
        print(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # 步骤2: 添加派生字段
        print("[步骤2] 添加派生字段（总股本、均线、涨跌幅等）")
        print("-" * 70)
        if not self._step2_process_daily_prices():
            return False
        print()
        
        # 步骤3: 更新历史排名
        print("[步骤3] 更新历史排名字段")
        print("-" * 70)
        if not self._step3_update_history_rank():
            return False
        print()
        
        # 步骤4: 计算距离历史最高排名天数
        print("[步骤4] 计算距离历史最高排名天数")
        print("-" * 70)
        if not self._step4_update_days_since_rank1():
            return False
        print()
        
        # 步骤5: 计算市场排名、市场情绪
        print("[步骤5] 计算市场排名、市场情绪等")
        print("-" * 70)
        if not self._step5_update_market_indicators():
            return False
        print()
        
        print("=" * 70)
        print("完成!")
        print("=" * 70)
        
        return True
    
    def _step2_process_daily_prices(self) -> bool:
        """步骤2: 添加派生字段并计算"""
        try:
            import process_daily_prices
            process_daily_prices.main()
            return True
        except Exception as e:
            print(f"ERROR: 派生字段计算失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _step3_update_history_rank(self) -> bool:
        """步骤3: 更新历史排名字段"""
        try:
            from update_history_rank import update_history_rank
            
            fields = ["close", "open_change_pct", "close_change_pct", 
                     "net_inflow", "ma_density", "market_cap", "turnover"]
            
            success_count = 0
            fail_count = 0
            
            for field in fields:
                print(f"  更新 {field}_history_rank...", end=" ")
                try:
                    if update_history_rank(field):
                        print("OK")
                        success_count += 1
                    else:
                        print("失败")
                        fail_count += 1
                except Exception as e:
                    print(f"失败: {e}")
                    fail_count += 1
            
            print(f"\n  成功: {success_count} 个字段, 失败: {fail_count} 个字段")
            return fail_count == 0
        except Exception as e:
            print(f"ERROR: 历史排名更新失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _step4_update_days_since_rank1(self) -> bool:
        """步骤4: 计算距离历史最高排名天数"""
        try:
            from update_days_since_rank1 import calculate_days_since_rank1
            
            fields = ["net_inflow_history_rank", "turnover_history_rank", "market_cap_history_rank"]
            
            success_count = 0
            fail_count = 0
            
            for field in fields:
                print(f"  更新 {field}_days_since_rank1...", end=" ")
                try:
                    if calculate_days_since_rank1(field):
                        print("OK")
                        success_count += 1
                    else:
                        print("失败")
                        fail_count += 1
                except Exception as e:
                    print(f"失败: {e}")
                    fail_count += 1
            
            print(f"\n  成功: {success_count} 个字段, 失败: {fail_count} 个字段")
            return fail_count == 0
        except Exception as e:
            print(f"ERROR: rank1天数计算失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _step5_update_market_indicators(self) -> bool:
        """步骤5: 计算市场排名、市场情绪等"""
        try:
            import update_market_indicators
            update_market_indicators.main()
            return True
        except Exception as e:
            print(f"ERROR: 市场指标计算失败: {e}")
            import traceback
            traceback.print_exc()
            return False


# SDK标准接口
def calculate_his_features() -> bool:
    """SDK标准接口：计算历史特征
    
    对应 run_after_market.bat 步骤2-5：
        - 步骤2: 添加派生字段（总股本、均线、涨跌幅等）
        - 步骤3: 更新历史排名字段
        - 步骤4: 计算距离历史最高排名天数
        - 步骤5: 计算市场排名、市场情绪等
    
    Returns:
        bool: 是否成功
    """
    calculator = HisFeatureCalculator()
    return calculator.calculate()


if __name__ == '__main__':
    success = calculate_his_features()
    sys.exit(0 if success else 1)
