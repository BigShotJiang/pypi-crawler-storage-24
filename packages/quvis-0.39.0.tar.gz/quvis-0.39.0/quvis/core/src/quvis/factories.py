"""
Factories and topology definitions for quantum circuits and coupling maps.

Circuit handles algorithm-based circuit creation.
Topology unifies coupling map creation with deterministic 2D layout generation
— each static method returns a TopologyResult containing both.
"""
import math
from collections.abc import Callable
from dataclasses import dataclass
from qiskit import QuantumCircuit
from qiskit.circuit.library import QFT, QFTGate, qaoa_ansatz
from qiskit.transpiler import CouplingMap

from .enums import AlgorithmType, TopologyType
from .config import CircuitGenerationConfig


@dataclass
class LayoutNode:
    id: int
    x: float
    y: float
    z: float = 0.0


@dataclass
class ModularInfo:
    """Stores information about the modular architecture."""
    num_cores: int
    qubits_per_core: int
    global_topology: str
    inter_core_links: list[list[int]]


@dataclass
class TopologyResult:
    coupling_map: CouplingMap
    layout: list[LayoutNode] | None


class Circuit:
    """Factory for creating quantum circuits based on AlgorithmType."""

    @classmethod
    def register(cls, algorithm_type: AlgorithmType, creator: Callable[[CircuitGenerationConfig], QuantumCircuit]):
        """Register a new circuit creator."""
        cls._creators[algorithm_type] = creator

    @classmethod
    def create(cls, config: CircuitGenerationConfig) -> QuantumCircuit:
        """Create a quantum circuit from configuration.""" 
        match config.algorithm:
            case AlgorithmType.QFT:
                return QFTGate(num_qubits=config.num_qubits)
            
            case AlgorithmType.GHZ:
                return cls._create_ghz(num_qubits=config.num_qubits)
            
            case AlgorithmType.QAOA:
                return cls._create_qaoa(config.num_qubits, config.algorithm_params["reps"])
            
            case AlgorithmType.CUSTOM_QASM:
                return QuantumCircuit.from_qasm_file(config.algorithm_params["qasm_path"])

            case _:
                raise ValueError(f"Algorithm {config.algorithm} not supported.")
    
    @classmethod
    def _create_ghz(cls, num_qubits: int) -> QuantumCircuit:
        circuit = QuantumCircuit(num_qubits, name=f"GHZ-{num_qubits}")
        circuit.h(0)
        for i in range(1, num_qubits):
            circuit.cx(0, i)
        return circuit

    @classmethod
    def _create_qaoa(cls, num_qubits: int, reps: int) -> QuantumCircuit:
        circuit = QuantumCircuit(num_qubits, name=f"QAOA-{num_qubits}-p{reps}")

        for _ in range(reps):
            # Problem layer (ZZ interactions)
            for i in range(num_qubits - 1):
                circuit.rzz(0.5, i, i + 1)

            # Mixer layer (X rotations)
            for i in range(num_qubits):
                circuit.rx(0.3, i)

        return circuit


def _layout_heavy_hex_nodes(coupling_map: CouplingMap, distance: int) -> list[LayoutNode]:
    N = len(coupling_map.graph)
    d = distance
    coords: dict[int, tuple[float, float]] = {}

    # 1. Data nodes: 0 to d*d - 1
    for r in range(d):
        for c in range(d):
            idx = r * d + c
            coords[idx] = (float(2 * c), float(2 * r))

    # 2. Vertical edge nodes
    v_start = d * d
    v_nodes_per_row = (d + 1) // 2
    for r in range(d - 1):
        for k in range(v_nodes_per_row):
            idx = v_start + r * v_nodes_per_row + k
            if r % 2 == 0:
                x = 0.0 if k == 0 else float(4 * k - 1)
            else:
                x = float(2 * d - 2) if k == v_nodes_per_row - 1 else float(4 * k + 1)
            coords[idx] = (x, float(2 * r + 1))

    # 3. Horizontal edge nodes
    h_start = v_start + (d - 1) * v_nodes_per_row
    for r in range(d):
        for c in range(d - 1):
            idx = h_start + r * (d - 1) + c
            coords[idx] = (float(2 * c + 1), float(2 * r))

    return [
        LayoutNode(id=i, x=coords.get(i, (0.0, 0.0))[0], y=coords.get(i, (0.0, 0.0))[1])
        for i in range(N)
    ]



# ---------------------------------------------------------------------------
# Unified Topology class
# ---------------------------------------------------------------------------

class Topology:
    """
    Unified topology: each static method returns a TopologyResult containing
    both the Qiskit CouplingMap and a deterministic 2D layout.
    """

    @staticmethod
    def line(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_line(physical_qubits)
        layout = [LayoutNode(id=i, x=float(i), y=0.0) for i in range(physical_qubits)]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def ring(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_ring(physical_qubits)
        r = physical_qubits / (2 * math.pi)
        layout = [
            LayoutNode(
                id=i,
                x=r * math.cos(2 * math.pi * i / physical_qubits),
                y=r * math.sin(2 * math.pi * i / physical_qubits),
            )
            for i in range(physical_qubits)
        ]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def grid(physical_qubits: int, **_) -> TopologyResult:
        n = math.ceil(math.sqrt(physical_qubits))
        cm = CouplingMap.from_grid(n, n)
        N = len(cm.graph)
        layout = [LayoutNode(id=i, x=float(i % n), y=float(i // n)) for i in range(N)]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def heavy_hex(physical_qubits: int, **kwargs) -> TopologyResult:
        distance = kwargs["distance"]
        cm = CouplingMap.from_heavy_hex(distance)
        layout = _layout_heavy_hex_nodes(cm, distance)
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def full(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_full(physical_qubits)
        r = physical_qubits / (2 * math.pi)
        layout = [
            LayoutNode(
                id=i,
                x=r * math.cos(2 * math.pi * i / physical_qubits),
                y=r * math.sin(2 * math.pi * i / physical_qubits),
            )
            for i in range(physical_qubits)
        ]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def custom(physical_qubits: int, **kwargs) -> TopologyResult:
        edges = kwargs["coupling_map_edges"]
        cm = CouplingMap(couplinglist=edges)
        return TopologyResult(coupling_map=cm, layout=None)

    @classmethod
    def create(cls, topology: TopologyType, physical_qubits: int, **kwargs) -> TopologyResult:
        """Dispatch to the appropriate topology method by enum value."""
        method = getattr(cls, topology.value, None)
        if method is None:
            raise ValueError(f"Unsupported topology: {topology}")
        return method(physical_qubits, **kwargs)


_INTER_CORE_SPACING = 20.0  # world-unit gap between core edges — must match frontend: web/src/config/defaults.ts multicore.interCoreSpacing


def _compute_polygon_core_centers(n: int, d: float) -> list[tuple[float, float]]:
    """Return N core centre positions on a regular N-gon with side length d."""
    if n == 1:
        return [(0.0, 0.0)]
    if n == 2:
        return [(-d / 2, 0.0), (d / 2, 0.0)]
    R = d / (2 * math.sin(math.pi / n))
    return [(R * math.cos(2 * math.pi * k / n), R * math.sin(2 * math.pi * k / n)) for k in range(n)]


def build_multicore_topology(
    single_core_result: TopologyResult,
    num_cores: int,
    qubits_per_core: int,
    core_connectivity: str,
) -> tuple[TopologyResult, ModularInfo]:
    """
    Replicate a single-core topology N times and add inter-core edges.

    single_core_result must have exactly qubits_per_core qubits (ids 0..Q-1).
    Communication qubit for core i: last qubit, i.e. (i+1)*Q - 1.
    Layout: each core's qubit cluster is placed at a polygon vertex.
    """
    edges: list[list[int]] = []

    # Intra-core: replicate single-core coupling map for each core
    for c in range(num_cores):
        offset = c * qubits_per_core
        for u, v in single_core_result.coupling_map.get_edges():
            edges.append([u + offset, v + offset])

    # Communication qubit = last qubit of each core
    comm = [(c + 1) * qubits_per_core - 1 for c in range(num_cores)]
    inter_core_links: list[list[int]] = []

    if core_connectivity == 'all-to-all':
        for i in range(num_cores):
            for j in range(i + 1, num_cores):
                inter_core_links.append([comm[i], comm[j]])

    elif core_connectivity == 'line':
        for i in range(num_cores - 1):
            inter_core_links.append([comm[i], comm[i + 1]])

    elif core_connectivity == 'ring':
        for i in range(num_cores - 1):
            inter_core_links.append([comm[i], comm[i + 1]])
        if num_cores > 2:
            inter_core_links.append([comm[num_cores - 1], comm[0]])

    elif core_connectivity == 'grid':
        grid_n = math.ceil(math.sqrt(num_cores))
        for i in range(num_cores):
            row, col = divmod(i, grid_n)
            if col + 1 < grid_n and i + 1 < num_cores:
                inter_core_links.append([comm[i], comm[i + 1]])
            if row + 1 < grid_n and i + grid_n < num_cores:
                inter_core_links.append([comm[i], comm[i + grid_n]])

    else:
        raise ValueError(f"Unsupported core_connectivity: {core_connectivity!r}")

    multicore_cm = CouplingMap(couplinglist=edges + inter_core_links)
    modular_info = ModularInfo(
        num_cores=num_cores,
        qubits_per_core=qubits_per_core,
        global_topology=core_connectivity,
        inter_core_links=inter_core_links,
    )

    # Polygon layout: place each core cluster at a vertex of a regular N-gon
    layout_nodes: list[LayoutNode] | None = None
    if single_core_result.layout:
        xs = [n.x for n in single_core_result.layout]
        ys = [n.y for n in single_core_result.layout]
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        max_r = max(math.sqrt((n.x - cx) ** 2 + (n.y - cy) ** 2)
                    for n in single_core_result.layout)
        d = 2 * max_r + _INTER_CORE_SPACING
        core_centers = _compute_polygon_core_centers(num_cores, d)

        layout_nodes = []
        for c in range(num_cores):
            dx = core_centers[c][0] - cx
            dy = core_centers[c][1] - cy
            for node in single_core_result.layout:
                layout_nodes.append(LayoutNode(
                    id=c * qubits_per_core + node.id,
                    x=node.x + dx,
                    y=node.y + dy,
                ))

    return TopologyResult(coupling_map=multicore_cm, layout=layout_nodes), modular_info
