"""
Interactive Playground API

This module provides the backend for the interactive playground mode,
generating quantum circuits on-demand based on user selections.
"""

import sys, json, os, argparse, logging, math
from typing import Any
from pathlib import Path
from qiskit import QuantumCircuit
from qiskit import transpile
from dataclasses import asdict
from ..compiler.utils import (
    extract_operations_per_slice,
    extract_routing_operations_per_slice,
    analyze_routing_overhead,
    LogicalCircuitInfo,
    CompiledCircuitInfo,
    RoutingCircuitInfo,
    DeviceInfo,
    ModularInfo,
)
from ..enums import AlgorithmType, TopologyType
from ..config import CircuitGenerationConfig
from ..factories import Circuit, Topology, TopologyResult, build_multicore_topology

# Create module logger
logger = logging.getLogger(__name__)


class PlaygroundAPI:
    """
    API for generating quantum circuits and visualization data on-demand
    for the interactive playground mode.
    """

    def __init__(self):
        """Initialize the Playground API."""
        pass

    def generate_visualization_data(
        self,
        config: CircuitGenerationConfig
    ) -> dict[str, Any]:
        """
        Generate visualization data for a quantum circuit.

        Args:
            config: Configuration object containing all generation parameters.

        Returns:
            Dictionary containing visualization data in library_multi format
        """

        circuit = Circuit.create(config)

        # Pass extra configuration into topology generation
        topology_kwargs = {}
        if config.heavy_hex_distance is not None:
            topology_kwargs["distance"] = config.heavy_hex_distance

        modular_info: ModularInfo | None = None

        # Handle custom topology (doesn't support multicore)
        if config.topology == TopologyType.CUSTOM:
            topology_result = Topology.create(
                config.topology,
                config.physical_qubits,
                coupling_map_edges=config.coupling_map_edges,
            )
        elif config.num_cores > 1:
            if config.topology == TopologyType.GRID:
                per_core_n = math.ceil(math.sqrt(config.physical_qubits / config.num_cores))
                actual_qpc = per_core_n * per_core_n
                single_core = Topology.create(config.topology, actual_qpc, **topology_kwargs)
            elif config.topology == TopologyType.HEAVY_HEX:
                target_per_core = config.physical_qubits / config.num_cores
                hh_qubits = lambda d: (5 * d * d - 2 * d - 1) / 2
                per_core_d = config.heavy_hex_distance or 3
                # Find smallest odd d where qubits(d) >= target
                per_core_d = 3  # minimum heavy hex distance
                while hh_qubits(per_core_d) < target_per_core and per_core_d < 100:
                    per_core_d += 2
                single_core = Topology.create(config.topology, 0, distance=per_core_d)
                actual_qpc = single_core.coupling_map.size()
            else:
                actual_qpc = config.physical_qubits // config.num_cores
                single_core = Topology.create(config.topology, actual_qpc, **topology_kwargs)
            topology_result, modular_info = build_multicore_topology(
                single_core, config.num_cores, actual_qpc, config.core_connectivity
            )
        else:
            topology_result = Topology.create(config.topology, config.physical_qubits, **topology_kwargs)

        # Handle precompiled circuit: skip transpilation entirely
        if config.is_precompiled:
            return self._process_precompiled_circuit(circuit, topology_result, config)

        basis_gates = ["id", "rz", "sx", "x", "cx", "swap"]

        logger.info("Processing circuit for playground visualization...")

        # Process logical circuit
        logger.info("Processing logical circuit...")
        logical_circuit_data = self._process_logical_circuit(circuit, config, topology_result.layout)

        # Process compiled circuit for each optimization level
        compiled_circuits = []
        for opt_level in config.optimization_levels:
            logger.info(f"Processing compiled circuit at optimization level {opt_level}...")
            compiled_circuit_data = self._process_compiled_circuit(
                circuit,
                topology_result,
                basis_gates,
                config,
                modular_info,
                optimization_level=opt_level,
            )
            compiled_circuits.append(compiled_circuit_data)

        result = {
            "circuits": [logical_circuit_data] + compiled_circuits,
            "total_circuits": 1 + len(compiled_circuits),
        }

        logger.info("Playground circuit generation completed successfully!")
        logger.info("Generated logical and compiled versions")

        return result

    def _process_precompiled_circuit(
        self,
        circuit: QuantumCircuit,
        topology_result: TopologyResult,
        config: CircuitGenerationConfig,
    ) -> dict[str, Any]:
        """Process a precompiled circuit, skipping transpilation entirely."""
        logger.info("Processing precompiled circuit (skipping transpilation)...")

        decomposed = circuit.decompose()
        compiled_operations_per_slice = extract_operations_per_slice(decomposed)
        logger.info(
            f"   Extracted {len(compiled_operations_per_slice)} time slices from precompiled circuit"
        )

        routing_result = extract_routing_operations_per_slice(decomposed)
        routing_analysis = analyze_routing_overhead(decomposed, decomposed)

        compiled_info = CompiledCircuitInfo(
            num_qubits=decomposed.num_qubits,
            compiled_interaction_graph_ops_per_slice=compiled_operations_per_slice,
        )

        routing_info = RoutingCircuitInfo(
            num_qubits=decomposed.num_qubits,
            routing_ops_per_slice=routing_result.routing_ops_per_slice,
            swaps=routing_result.swaps,
            routing_depth=routing_result.routing_depth,
        )

        device_info = DeviceInfo(
            num_qubits_on_device=topology_result.coupling_map.size(),
            connectivity_graph_coupling_map=list(topology_result.coupling_map.get_edges()),
            layout_nodes=topology_result.layout,
        )

        circuit_data = {
            "circuit_info": asdict(compiled_info),
            "routing_info": asdict(routing_info),
            "device_info": asdict(device_info),
            "algorithm_name": "CUSTOM QASM (Pre-compiled)",
            "circuit_type": "compiled",
            "algorithm_params": config.algorithm_params,
            "routing_analysis": routing_analysis,
            "circuit_stats": {
                "original_gates": len(circuit.data),
                "transpiled_gates": len(decomposed.data),
                "depth": len(compiled_operations_per_slice),
                "qubits": decomposed.num_qubits,
                "swap_count": routing_result.swaps,
            },
        }

        logger.info("Precompiled circuit processing completed successfully!")

        return {
            "circuits": [circuit_data],
            "total_circuits": 1,
        }

    def _process_logical_circuit(
        self,
        circuit: QuantumCircuit,
        config: CircuitGenerationConfig,
        layout_nodes: list | None = None,
    ) -> dict[str, Any]:
        """Process the logical version of the circuit."""
        decomposed_circuit = circuit.decompose()
        logical_operations_per_slice = extract_operations_per_slice(decomposed_circuit)
        logger.info(
            f"   ✓ Extracted {len(logical_operations_per_slice)} time slices from logical circuit"
        )

        logical_info = LogicalCircuitInfo(
            num_qubits=decomposed_circuit.num_qubits,
            interaction_graph_ops_per_slice=logical_operations_per_slice,
        )

        n = decomposed_circuit.num_qubits
        device_info = DeviceInfo(
            num_qubits_on_device=n,
            connectivity_graph_coupling_map=[],
            layout_nodes=layout_nodes[:n] if layout_nodes else None,
        )

        return {
            "circuit_info": asdict(logical_info),
            "device_info": asdict(device_info),
            "algorithm_name": f"{config.algorithm.value.upper()} (Logical)",
            "circuit_type": "logical",
            "algorithm_params": config.algorithm_params,
            "circuit_stats": {
                "original_gates": len(circuit.data),
                "depth": len(logical_operations_per_slice),
                "qubits": decomposed_circuit.num_qubits,
            },
        }

    def _process_compiled_circuit(
        self,
        circuit: QuantumCircuit,
        topology_result: TopologyResult,
        basis_gates: list[str],
        config: CircuitGenerationConfig,
        modular_info: ModularInfo | None = None,
        optimization_level: int = 1,
    ) -> dict[str, Any]:
        """Process the compiled version of the circuit."""
        logger.info(
            f"🔧 Transpiling for optimization level {optimization_level}..."
        )

        transpiled_circuit = transpile(
            circuit,
            basis_gates=basis_gates,
            optimization_level=optimization_level,
            coupling_map=topology_result.coupling_map)
        logger.info(
            f"   ✓ Transpilation complete: {len(transpiled_circuit.data)} gates total"
        )

        compiled_operations_per_slice = extract_operations_per_slice(transpiled_circuit)
        logger.info(
            f"   ✓ Extracted {len(compiled_operations_per_slice)} time slices from compiled circuit"
        )

        routing_result = extract_routing_operations_per_slice(transpiled_circuit)
        logger.info(
            f"   ✓ Found {routing_result.swaps} SWAP gates for qubit routing"
        )

        routing_analysis = analyze_routing_overhead(
            circuit.decompose(), transpiled_circuit
        )
        logger.info(
            f"   ✓ Routing overhead: {routing_analysis['routing_overhead_percentage']:.1f}%"
        )

        compiled_info = CompiledCircuitInfo(
            num_qubits=transpiled_circuit.num_qubits,
            compiled_interaction_graph_ops_per_slice=compiled_operations_per_slice,
        )

        routing_info = RoutingCircuitInfo(
            num_qubits=transpiled_circuit.num_qubits,
            routing_ops_per_slice=routing_result.routing_ops_per_slice,
            swaps=routing_result.swaps,
            routing_depth=routing_result.routing_depth,
        )

        layout_nodes = topology_result.layout

        device_info = DeviceInfo(
            num_qubits_on_device=topology_result.coupling_map.size(),
            connectivity_graph_coupling_map=list(topology_result.coupling_map.get_edges()),
            modular_info=modular_info,
            layout_nodes=layout_nodes,
        )

        return {
            "circuit_info": asdict(compiled_info),
            "routing_info": asdict(routing_info),
            "device_info": asdict(device_info),
            "algorithm_name": f"{config.algorithm.value.upper()} (Compiled O{optimization_level})",
            "circuit_type": "compiled",
            "algorithm_params": config.algorithm_params,
            "routing_analysis": routing_analysis,
            "circuit_stats": {
                "original_gates": len(circuit.data),
                "transpiled_gates": len(transpiled_circuit.data),
                "depth": len(compiled_operations_per_slice),
                "qubits": transpiled_circuit.num_qubits,
                "swap_count": routing_result.swaps,
            },
        }

    def get_supported_algorithms(self) -> list:
        """Get list of supported algorithms."""
        return [algo.value for algo in AlgorithmType]


def generate_playground_circuit(
    algorithm: str, num_qubits: int, physical_qubits: int , topology: str,  **kwargs
) -> dict[str, Any]:
    """
    High-level function to generate a playground circuit.
    """
    config = CircuitGenerationConfig(
        algorithm=AlgorithmType(algorithm),
        num_qubits=num_qubits,
        physical_qubits=physical_qubits,
        topology=TopologyType(topology),
        algorithm_params=kwargs
    )
    api = PlaygroundAPI()
    return api.generate_visualization_data(config)


def main():
    parser = argparse.ArgumentParser(
        description="Generate a quantum circuit for the Quvis playground."
    )
    parser.add_argument(
        "--algorithm", required=True, type=str, help="The algorithm to use."
    )
    parser.add_argument(
        "--num-qubits", required=True, type=int, help="The number of logical qubits."
    )
    parser.add_argument(
        "--qasm-file", type=str, help="Path to the custom QASM file."
    )
    parser.add_argument(
        "--physical-qubits", type=int, help="The number of physical qubits for the device topology."
    )
    parser.add_argument(
        "--heavy-hex-distance", type=int, help="The distance for the Heavy Hex topology."
    )
    parser.add_argument(
        "--topology", required=True, type=str, help="The circuit topology."
    )
    parser.add_argument(
        "--optimization-levels", type=int, nargs="+", default=[1], help="The optimization levels to compile at."
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Enable verbose logging."
    )
    args = parser.parse_args()

    # Configure logging based on verbose setting
    if args.verbose:
        logging.basicConfig(level=logging.INFO, format='%(message)s', stream=sys.stderr)
    else:
        logging.basicConfig(level=logging.WARNING, format='%(message)s', stream=sys.stderr)

    api = PlaygroundAPI()

    # Generate circuit with the API
    try:
        logger.info(
            f"INFO: Generating circuit - algorithm: {args.algorithm}, qubits: {args.num_qubits}, topology: {args.topology}"
        )

        kwargs = {}
        if args.qasm_file:
            kwargs["qasm_path"] = args.qasm_file

        config = CircuitGenerationConfig(
            algorithm=AlgorithmType(args.algorithm),
            num_qubits=args.num_qubits,
            physical_qubits=args.physical_qubits or args.num_qubits,
            topology=TopologyType(args.topology),
            optimization_levels=args.optimization_levels,
            heavy_hex_distance=args.heavy_hex_distance,
            algorithm_params=kwargs
        )

        result = api.generate_visualization_data(config)

        # Add generation success flag
        result["generation_successful"] = True

        # Save to public directory for frontend
        cwd = Path(os.getcwd())
        output_path = cwd / "quvis/web/public/playground_circuit_data.json"

        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                json.dump(result, f, separators=(",", ":"))
            logger.info(f"INFO: Saved circuit data to: {output_path}")
        except (OSError, IOError) as e:
            logger.warning(
                f"WARNING: Could not save circuit data to {output_path}: {e}"
            )

        logger.info(f"INFO: Circuit generation completed successfully")

        # Output result to stdout (this MUST be the last print to stdout)
        print(json.dumps(result, separators=(",", ":")))

    except Exception as e:
        logger.error(f"ERROR: Circuit generation failed: {e}")
        import traceback

        logger.error(f"ERROR: Traceback: {traceback.format_exc()}")
        error_result = {"generation_successful": False, "error": str(e)}
        print(json.dumps(error_result, separators=(",", ":")))
        sys.exit(1)


if __name__ == "__main__":
    main()
