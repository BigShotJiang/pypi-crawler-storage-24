"""
Coupling Map Validation CLI

Reads a coupling map CSV from stdin and validates it, printing JSON to stdout.
"""

import sys
import json
import logging

from .coupling_map_utils import parse_coupling_map_csv, detect_topology

logger = logging.getLogger(__name__)


def main():
    csv_str = sys.stdin.read()
    edges, error = parse_coupling_map_csv(csv_str)

    if error:
        print(json.dumps({"valid": False, "error": error}, separators=(",", ":")))
        sys.exit(1)

    info = detect_topology(edges)
    result = {
        "valid": True,
        "num_qubits": info["num_qubits"],
        "num_edges": info["num_edges"],
        "detected_topology": info["detected_topology"],
        "detected_params": info["detected_params"],
    }
    print(json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
