"""
Coupling Map Utilities

Provides CSV parsing, validation, and topology auto-detection for coupling maps.
"""

import math
from typing import Any, TypedDict

from qiskit.transpiler import CouplingMap


class TopologyDetectionResult(TypedDict):
    num_qubits: int
    num_edges: int
    detected_topology: str | None
    detected_params: dict[str, Any]


def parse_coupling_map_csv(csv_str: str) -> tuple[list[list[int]] | None, str | None]:
    """
    Parse a CSV string representing a coupling map edge list.

    Accepts CSV with or without a ``source,target`` header row.
    Each data row must contain exactly 2 non-negative integer values.

    Returns:
        (edges, None) on success, or (None, error_message) on failure.
    """
    lines = [line.strip() for line in csv_str.strip().splitlines() if line.strip()]

    if not lines:
        return None, "CSV is empty: no edges provided."

    # Detect and skip header row
    first_cols = lines[0].split(",")
    if len(first_cols) == 2:
        try:
            int(first_cols[0])
        except ValueError:
            # First row is not numeric — treat it as a header
            lines = lines[1:]

    if not lines:
        return None, "CSV is empty: no data rows after header."

    edges: list[list[int]] = []
    for i, line in enumerate(lines, start=1):
        cols = line.split(",")
        if len(cols) != 2:
            return None, f"Row {i} has {len(cols)} columns; expected 2 columns per row."

        try:
            source = int(cols[0].strip())
            target = int(cols[1].strip())
        except ValueError:
            return None, f"Row {i} contains non-integer values; all values must be integer."

        if source < 0 or target < 0:
            return None, f"Row {i} contains negative indices; all indices must be non-negative."

        edges.append([source, target])

    return edges, None


def detect_topology(edges: list[list[int]]) -> TopologyDetectionResult:
    """
    Detect a known topology from a set of directed edges.

    Compares the edge set against: line, ring, grid, heavy_hex, and full topologies.

    Returns a dict with keys: num_qubits, num_edges, detected_topology, detected_params.
    """
    all_indices = set()
    for src, tgt in edges:
        all_indices.add(src)
        all_indices.add(tgt)

    n = max(all_indices) + 1 if all_indices else 0
    edge_set = {(s, t) for s, t in edges}
    num_edges = len(edges)

    # Symmetrize: Qiskit topologies are bidirectional, but users may upload
    # unidirectional edges (e.g. 0→1, 1→2 instead of 0↔1, 1↔2).
    symmetric_edge_set = edge_set | {(t, s) for s, t in edge_set}

    result = {
        "num_qubits": n,
        "num_edges": num_edges,
        "detected_topology": None,
        "detected_params": {},
    }

    if n < 2:
        return result

    # --- Line ---
    cm_line = CouplingMap.from_line(n)
    if symmetric_edge_set == set(cm_line.get_edges()):
        result["detected_topology"] = "line"
        result["detected_params"] = {"n": n}
        return result

    # --- Ring ---
    cm_ring = CouplingMap.from_ring(n)
    if symmetric_edge_set == set(cm_ring.get_edges()):
        result["detected_topology"] = "ring"
        result["detected_params"] = {"n": n}
        return result

    # --- Grid (check if n is a perfect rectangle; try square first, then other combos) ---
    sqrt_n = int(math.isqrt(n))
    if sqrt_n * sqrt_n == n and sqrt_n >= 2:
        cm_grid = CouplingMap.from_grid(sqrt_n, sqrt_n)
        if symmetric_edge_set == set(cm_grid.get_edges()):
            result["detected_topology"] = "grid"
            result["detected_params"] = {"rows": sqrt_n, "cols": sqrt_n}
            return result

    # Also try non-square grids: iterate factors
    for rows in range(2, int(math.isqrt(n)) + 1):
        if n % rows == 0:
            cols = n // rows
            if cols >= 2:
                cm_grid = CouplingMap.from_grid(rows, cols)
                if symmetric_edge_set == set(cm_grid.get_edges()):
                    result["detected_topology"] = "grid"
                    result["detected_params"] = {"rows": rows, "cols": cols}
                    return result

    # --- Heavy Hex ---
    # Formula: num_qubits = (5d^2 - 2d - 1) / 2 for odd d >= 3
    for d in range(3, 30, 2):
        expected_n = (5 * d * d - 2 * d - 1) // 2
        if expected_n == n:
            cm_hh = CouplingMap.from_heavy_hex(d)
            if symmetric_edge_set == set(cm_hh.get_edges()):
                result["detected_topology"] = "heavy_hex"
                result["detected_params"] = {"distance": d}
                return result
        if expected_n > n:
            break

    # --- Full ---
    cm_full = CouplingMap.from_full(n)
    if symmetric_edge_set == set(cm_full.get_edges()):
        result["detected_topology"] = "full"
        result["detected_params"] = {"n": n}
        return result

    return result
