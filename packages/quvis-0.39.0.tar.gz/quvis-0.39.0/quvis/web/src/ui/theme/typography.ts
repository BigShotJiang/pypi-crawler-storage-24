// Typography tokens for Quvis Web Application
// Centralized font-size, weight, and family management

export const typography = {
    // Font families
    fontFamily: {
        ui: "Inter, system-ui, sans-serif",
        scene: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    },

    // Font sizes — semantic scale
    fontSize: {
        // Absolute px sizes (used where CSS em inheritance is unreliable, e.g. Three.js DOM overlays)
        xs: "11px",   // Fine print, subtitles
        sm: "12px",   // Secondary labels, badges
        md: "13px",   // Body / legend items
        base: "14px", // Default panel text, header titles
        lg: "16px",   // Sub-headings
        xl: "20px",   // Icon buttons
        xxl: "24px",  // Modal headings

        // Relative em sizes (used in React components where panel base size is inherited)
        panelBase: "0.9em",  // Panel content inheriting from root
        panelSmall: "0.85em", // Slider inputs
        panelXs: "0.8em",    // Compact footnotes within panels
        panelTiny: "0.75em", // Very compact sub-labels
    },

    // Font weights
    fontWeight: {
        normal: 400,
        medium: 500,
        semiBold: 600,
        bold: 700,
    },
} as const;

export type TypographyTokens = typeof typography;

export default typography;
