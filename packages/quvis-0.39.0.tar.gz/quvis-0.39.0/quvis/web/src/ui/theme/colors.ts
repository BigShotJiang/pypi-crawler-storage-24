// Color Palette for Quvis Web Application
// Centralized color management system

export const colors = {
    // Primary Brand Colors
    // Palette: #171E26 · #222E39 · #384959 · #6A89A7 · #88BDF2 · #BDDDFC
    primary: {
        main: "#6A89A7",              // Mid blue-gray — buttons, active states, borders
        accent: "#88BDF2",            // Bright blue — titles, links, highlights
        light: "#BDDDFC",             // Lightest blue — subtle fills, hover glows
        dark: "#384959",              // Dark blue-gray — pressed states, deep accents
    },

    // Background Colors
    background: {
        main: "#171E26",                      // Deepest background
        panel: "rgba(34, 46, 57, 0.85)",      // Semi-transparent panel (#222E39)
        panelSolid: "#222E39",                // Solid panel / card background
        panelAlt: "rgba(23, 30, 38, 0.9)",    // Deeper inset areas (#171E26)
        hover: "#384959",                     // Hover state background
    },

    // Text Colors
    text: {
        primary: "#D8EEFF",   // Light blue-white — primary readable text
        secondary: "#A8D0F5", // Medium blue — secondary labels
        muted: "#6A89A7",     // Mid blue-gray — hints, captions
        disabled: "#4a6070",  // Dark muted — disabled / placeholder
    },

    // Border and UI Element Colors
    border: {
        main: "#384959",                       // Card and component borders
        light: "rgba(136, 189, 242, 0.2)",     // Subtle blue-tinted border
        active: "#88BDF2",                     // Active / focused border
        separator: "#2d3d4a",                  // Section dividers
    },

    // State Colors (kept semantic — red/yellow/green are universally understood)
    state: {
        success: "#28a745",
        warning: "#ffc107",
        error: "#dc3545",
        info: "#88BDF2",
    },

    // Loading and Progress Colors
    loading: {
        track: "#384959",    // Loading spinner track
        progress: "#88BDF2", // Loading spinner progress
    },

    // Shadow and Overlay Colors
    shadow: {
        light: "rgba(0, 0, 0, 0.3)",
        medium: "rgba(0, 0, 0, 0.5)",
        dark: "rgba(0, 0, 0, 0.7)",
        text: "#000000",
    },

    // Interactive Element Colors
    interactive: {
        button: {
            background: "rgba(106, 137, 167, 0.15)",
            border: "rgba(106, 137, 167, 0.35)",
            hover: "rgba(106, 137, 167, 0.25)",
        },
        slider: {
            track: "#384959",
            rail: "#384959",
            handle: "#88BDF2",
            selected: "#88BDF2",
        },
    },

    // Transparent Variations (commonly used)
    transparent: {
        white10: "rgba(255, 255, 255, 0.1)",
        white20: "rgba(255, 255, 255, 0.2)",
        white30: "rgba(255, 255, 255, 0.3)",
        black30: "rgba(0, 0, 0, 0.3)",
        black50: "rgba(0, 0, 0, 0.5)",
    },

    // Heatmap and Visualization Colors (semantic — kept as-is)
    visualization: {
        heatmapGradient: {
            start: "#00FF00", // Green
            middle: "#FFFF00", // Yellow
            end: "#FF0000",   // Red
        },
        legendBorder: "#6A89A7",
    },

    // UI Component Colors
    ui: {
        background: "rgba(34, 46, 57, 0.9)",
        surface: "rgba(106, 137, 167, 0.15)",
        accent: "#88BDF2",
        border: "rgba(106, 137, 167, 0.3)",
    },

    // Circuit Type Colors (adapted to blue palette)
    circuit: {
        logical: "#4CAF82",   // Green for logical circuits
        compiled: "#E8924A",  // Orange for compiled circuits
    },
} as const;

// Type definitions for better TypeScript support
export type ColorPalette = typeof colors;
export type PrimaryColors = keyof typeof colors.primary;
export type BackgroundColors = keyof typeof colors.background;
export type TextColors = keyof typeof colors.text;

// Helper functions for common color operations
export const colorHelpers = {
    // Get RGB values from hex
    hexToRgb: (hex: string): { r: number; g: number; b: number } | null => {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result
            ? {
                  r: parseInt(result[1], 16),
                  g: parseInt(result[2], 16),
                  b: parseInt(result[3], 16),
              }
            : null;
    },

    // Convert CSS color to THREE.js hex format
    cssColorToHex: (cssColor: string): number => {
        // Handle hex colors
        if (cssColor.startsWith("#")) {
            return parseInt(cssColor.replace("#", "0x"));
        }

        // Handle rgba/rgb colors - extract RGB values and convert to hex
        const rgbMatch = cssColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (rgbMatch) {
            const r = parseInt(rgbMatch[1]);
            const g = parseInt(rgbMatch[2]);
            const b = parseInt(rgbMatch[3]);
            return (r << 16) | (g << 8) | b;
        }

        // Fallback to white if color format is not recognized
        return 0xffffff;
    },

    // Create rgba string with custom opacity
    withOpacity: (color: string, opacity: number): string => {
        if (color.startsWith("rgba")) {
            // Replace existing opacity
            return color.replace(/,\s*[\d.]+\)$/, `, ${opacity})`);
        } else if (color.startsWith("rgb")) {
            // Convert rgb to rgba
            return color.replace("rgb", "rgba").replace(")", `, ${opacity})`);
        } else if (color.startsWith("#")) {
            // Convert hex to rgba
            const rgb = colorHelpers.hexToRgb(color);
            return rgb
                ? `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${opacity})`
                : color;
        }
        return color;
    },

    // Common color combinations for components
    getButtonStyle: (isActive: boolean = false, disabled: boolean = false) => ({
        backgroundColor: isActive
            ? colors.primary.main
            : colors.interactive.button.background,
        borderColor: isActive
            ? colors.primary.main
            : colors.interactive.button.border,
        color: colors.text.primary,
        opacity: disabled ? 0.5 : 1,
    }),

    getPanelStyle: () => ({
        backgroundColor: colors.background.panel,
        color: colors.text.primary,
        borderRadius: "8px",
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
    }),
};

export default colors;
