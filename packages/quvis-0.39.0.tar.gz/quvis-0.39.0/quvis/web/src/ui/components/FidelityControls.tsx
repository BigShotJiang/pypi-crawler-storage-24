import React, { useState, useEffect, useCallback } from "react";
import type { Playground } from "../../scene/Playground.js";
import { colors } from "../theme/colors.js";
import { typography } from "../theme/typography.js";
import Slider from "./Slider.js";

interface FidelityControlsProps {
    playground: Playground | null;
    initialValues: {
        oneQubitBase: number;
        twoQubitBase: number;
    };
}

const FidelityControls: React.FC<FidelityControlsProps> = ({
    playground,
    initialValues,
}) => {
    const [oneQubitFidelity, setOneQubitFidelity] = useState(
        initialValues.oneQubitBase,
    );
    const [twoQubitFidelity, setTwoQubitFidelity] = useState(
        initialValues.twoQubitBase,
    );

    useEffect(() => {
        setOneQubitFidelity(initialValues.oneQubitBase);
        setTwoQubitFidelity(initialValues.twoQubitBase);
    }, [initialValues]);

    const handleOneQubitFidelityChange = useCallback(
        (value: number) => {
            setOneQubitFidelity(value);
            if (playground) {
                playground.updateFidelityParameters({ oneQubitBase: value });
            }
        },
        [playground],
    );

    const handleTwoQubitFidelityChange = useCallback(
        (value: number) => {
            setTwoQubitFidelity(value);
            if (playground) {
                playground.updateFidelityParameters({ twoQubitBase: value });
            }
        },
        [playground],
    );

    const panelStyle: React.CSSProperties = {
        background: colors.background.panel,
        color: colors.text.primary,
        padding: "15px",
        borderRadius: "8px",
        width: "250px",
        fontFamily: typography.fontFamily.ui,
        fontSize: typography.fontSize.panelBase,
        zIndex: 10,
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
        overflow: "hidden",
    };

    const headerStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
        borderBottom: `1px solid ${colors.border.separator}`,
        paddingBottom: "10px",
        marginBottom: "10px",
    };

    const headerTitleStyle: React.CSSProperties = {
        margin: "0",
        fontSize: typography.fontSize.base,
        fontWeight: 600,
        color: colors.text.primary,
        textTransform: "uppercase",
        letterSpacing: "0.5px",
    };

    const controlGroupStyle: React.CSSProperties = {
        marginBottom: "15px",
    };

    const labelStyle: React.CSSProperties = {
        display: "block",
        marginBottom: "8px",
        fontWeight: 500,
        color: colors.text.primary,
    };

    const sliderContainerStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
    };

    return (
        <div style={panelStyle}>
            <div style={headerStyle}>
                <h4 style={headerTitleStyle}>Fidelity Controls</h4>
            </div>

            <div style={controlGroupStyle}>
                <label style={labelStyle}>
                    One-Qubit Gate Fidelity
                </label>
                <div style={sliderContainerStyle}>
                    <Slider
                        id="one-qubit-fidelity"
                        min={0.90}
                        max={1.0}
                        step={0.001}
                        value={oneQubitFidelity}
                        onChange={handleOneQubitFidelityChange}
                        style={{ flex: 1 }}
                        showInput
                        precision={3}
                        inputWidth="50px"
                    />
                </div>
            </div>

            <div style={controlGroupStyle}>
                <label htmlFor="two-qubit-fidelity" style={labelStyle}>
                    Two-Qubit Gate Fidelity
                </label>
                <div style={sliderContainerStyle}>
                    <Slider
                        id="two-qubit-fidelity"
                        min={0.90}
                        max={1.0}
                        step={0.001}
                        value={twoQubitFidelity}
                        onChange={handleTwoQubitFidelityChange}
                        style={{ flex: 1 }}
                        showInput
                        precision={3}
                        inputWidth="50px"
                    />
                </div>
            </div>
        </div>
    );
};

export default FidelityControls;
