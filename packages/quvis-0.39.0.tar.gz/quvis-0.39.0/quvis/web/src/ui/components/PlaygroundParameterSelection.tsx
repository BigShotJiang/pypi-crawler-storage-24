import React, { useState, useEffect } from 'react';
import { colors } from '../theme/colors.js';
import { typography } from '../theme/typography.js';
import Slider from './Slider.js';
import HelpIcon from './HelpIcon.js';
import { AppConstants } from '../../config/constants.js';
import { CoreConnectivity } from '../../config/defaults.js';

const version = "v0.39.0";


interface PlaygroundParameterSelectionProps {
    onGenerate: (params: PlaygroundParams) => void;
    constants: AppConstants;
}

interface PlaygroundParams {
    algorithm: string;
    numQubits: number;
    physicalQubits: number;
    topology: string;
    optimizationLevels: number[];
    customParams?: Record<string, any>;
    qasm?: string;
    heavyHexDistance?: number;
    couplingMapEdges?: number[][];
    isPrecompiled?: boolean;
    numCores: number;
    coreConnectivity: CoreConnectivity;
}

const PlaygroundParameterSelection: React.FC<
    PlaygroundParameterSelectionProps
> = ({ onGenerate, constants }) => {
    const [algorithm, setAlgorithm] = useState<string>('qft');
    const [logicalQubits, setLogicalQubits] = useState<number>(constants.qubits.default);
    const [physicalQubits, setPhysicalQubits] = useState<number>(constants.qubits.default);
    const [topology, setTopology] = useState<string>('grid');
    const [heavyHexDistance, setHeavyHexDistance] = useState<number>(constants.heavy_hex_distance.default);
    const [gridSize, setGridSize] = useState<number>(constants.grid_size.default);
    const [optimizationLevels, setOptimizationLevels] = useState<number[]>([constants.optimization_level.default]);
    const [customParams, setCustomParams] = useState<Record<string, any>>({});
    const [numCores, setNumCores] = useState<number>(1);
    const [coreConnectivity, setCoreConnectivity] = useState<CoreConnectivity>('all-to-all');

    const [isGenerating, setIsGenerating] = useState(false);
    const [logicalQubitsInput, setLogicalQubitsInput] = useState<string>(
        logicalQubits.toString()
    );
    const [physicalQubitsInput, setPhysicalQubitsInput] = useState<string>(
        physicalQubits.toString()
    );
    const [qasmContent, setQasmContent] = useState<string | null>(null);
    const [qasmValidationStatus, setQasmValidationStatus] = useState<
        'idle' | 'loading' | 'success' | 'error'
    >('idle');
    const [qasmValidationError, setQasmValidationError] = useState<string | null>(null);
    const [isHelpOpen, setIsHelpOpen] = useState(false);
    const [isButtonHovered, setIsButtonHovered] = useState(false);
    const [couplingMapEdges, setCouplingMapEdges] = useState<number[][] | null>(null);
    const [couplingMapValidation, setCouplingMapValidation] = useState<{
        status: 'idle' | 'loading' | 'success' | 'error';
        numQubits?: number;
        numEdges?: number;
        detectedTopology?: string | null;
        detectedParams?: Record<string, any> | null;
        error?: string | null;
    }>({ status: 'idle' });
    const [isPrecompiled, setIsPrecompiled] = useState(false);

    useEffect(() => {
        if (topology === 'heavy_hex') {
            const d = heavyHexDistance;
            const calculatedPhysicalQubits = (5 * d * d - 2 * d - 1) / 2;
            if (physicalQubits !== calculatedPhysicalQubits) {
                setPhysicalQubits(calculatedPhysicalQubits);
            }
            if (logicalQubits > calculatedPhysicalQubits) {
                setLogicalQubits(calculatedPhysicalQubits);
            }
        } else if (topology === 'grid') {
            const calculatedPhysicalQubits = gridSize * gridSize;
            if (physicalQubits !== calculatedPhysicalQubits) {
                setPhysicalQubits(calculatedPhysicalQubits);
            }
            if (logicalQubits > calculatedPhysicalQubits) {
                setLogicalQubits(calculatedPhysicalQubits);
            }
        } else {
            if (physicalQubits < logicalQubits) {
                setPhysicalQubits(logicalQubits);
            }
        }
    }, [logicalQubits, physicalQubits, topology, heavyHexDistance, gridSize]);

    useEffect(() => {
        setLogicalQubitsInput(logicalQubits.toString());
    }, [logicalQubits]);

    useEffect(() => {
        setPhysicalQubitsInput(physicalQubits.toString());
    }, [physicalQubits]);

    // Lock topology to 'custom' when precompiled
    useEffect(() => {
        if (isPrecompiled) {
            setTopology('custom');
        }
    }, [isPrecompiled]);

    // Reset precompiled when switching away from custom_qasm
    useEffect(() => {
        if (algorithm !== 'custom_qasm') {
            setIsPrecompiled(false);
        }
    }, [algorithm]);

    const topologyLocked = isPrecompiled;

    // Snap physicalQubits to nearest multiple of numCores
    useEffect(() => {
        if (numCores <= 1) return;
        if (topology === 'heavy_hex' || topology === 'grid') return;
        const snapped = Math.round(physicalQubits / numCores) * numCores;
        if (snapped !== physicalQubits && snapped > 0) {
            setPhysicalQubits(snapped);
        }
    }, [numCores, physicalQubits, topology]);


    const containerStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        minHeight: '100vh',
        width: '100vw',
        backgroundColor: colors.background.main,
        color: colors.text.primary,
        fontFamily: typography.fontFamily.ui,
        padding: '60px 20px 120px',
        boxSizing: 'border-box',
    };

    const mainTitleStyle: React.CSSProperties = {
        fontSize: '64px',
        fontWeight: 'bold',
        color: colors.primary.accent,
        textShadow: `2px 2px 4px ${colors.shadow.text}`,
        marginBottom: '4px',
        textAlign: 'center',
    };

    const subtitleStyle: React.CSSProperties = {
        fontSize: '18px',
        color: colors.primary.accent,
        marginBottom: '16px',
        textAlign: 'center',
        letterSpacing: '0.02em',
    };

    const versionStyle: React.CSSProperties = {
        fontSize: '18px',
        color: colors.text.disabled,
        marginBottom: '60px',
        textAlign: 'center',
    };

    const linkStyle: React.CSSProperties = {
        color: colors.primary.accent,
        textDecoration: 'none',
    };

    // All sections share the same card style for visual consistency
    const sectionStyle: React.CSSProperties = {
        marginBottom: '20px',
        width: '100%',
        maxWidth: '400px',
        padding: '20px 24px',
        backgroundColor: colors.background.panelSolid,
        borderRadius: '12px',
        border: `1px solid ${colors.border.main}`,
        boxSizing: 'border-box',
    };

    const columnsContainerStyle: React.CSSProperties = {
        display: 'flex',
        gap: '40px',
        justifyContent: 'center',
        alignItems: 'flex-start',
        width: '100%',
        maxWidth: '1400px',
        marginBottom: '40px',
    };

    const columnStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        flex: 1,
        minWidth: '320px',
    };

    const sectionTitleStyle: React.CSSProperties = {
        fontSize: '20px',
        fontWeight: 'bold',
        color: colors.text.primary,
        marginBottom: '16px',
        marginTop: 0,
        textAlign: 'center',
    };

    const buttonGroupStyle: React.CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        gap: '12px',
        flexWrap: 'wrap',
    };

    // Topology and connectivity buttons use flex-stretch for uniform sizing
    const stretchButtonGroupStyle: React.CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        gap: '10px',
        flexWrap: 'wrap',
        width: '100%',
    };

    const circuitButtonStyle = (isActive: boolean): React.CSSProperties => ({
        padding: '12px 24px',
        fontSize: '16px',
        fontWeight: 'bold',
        border: `2px solid ${isActive ? colors.primary.accent : colors.border.main}`,
        borderRadius: '12px',
        backgroundColor: isActive
            ? colors.primary.accent
            : colors.background.main,
        color: isActive ? colors.background.main : colors.text.primary,
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        minWidth: '90px',
        textAlign: 'center',
        boxShadow: isActive ? `0 4px 15px ${colors.primary.accent}40` : 'none',
    });

    const topologyButtonStyle = (isActive: boolean): React.CSSProperties => ({
        padding: '10px 16px',
        fontSize: '15px',
        fontWeight: '600',
        border: `2px solid ${isActive ? colors.primary.accent : colors.border.main}`,
        borderRadius: '8px',
        backgroundColor: isActive
            ? colors.primary.accent
            : colors.background.main,
        color: isActive ? colors.background.main : colors.text.primary,
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        flex: '1 1 0',
        minWidth: '80px',
        textAlign: 'center',
        boxShadow: isActive ? `0 2px 10px ${colors.primary.accent}40` : 'none',
    });

    const sliderContainerStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        gap: '12px',
    };

    const sliderLabelStyle: React.CSSProperties = {
        fontSize: '17px',
        fontWeight: '600',
        color: colors.text.primary,
        textAlign: 'left',
    };

    const sliderWrapperStyle: React.CSSProperties = {
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        width: '100%',
    };

    const sliderStyle: React.CSSProperties = {
        flex: 1,
        height: '6px',
        background: colors.border.main,
        borderRadius: '3px',
        outline: 'none',
        WebkitAppearance: 'none',
        cursor: 'pointer',
    };

    const sliderValueStyle: React.CSSProperties = {
        fontSize: '16px',
        fontWeight: 'bold',
        color: colors.primary.accent,
        width: '64px',
        flexShrink: 0,
        textAlign: 'center',
        backgroundColor: colors.background.main,
        padding: '7px 10px',
        borderRadius: '6px',
        border: `1px solid ${colors.border.main}`,
        boxSizing: 'border-box',
    };

    const helperTextStyle: React.CSSProperties = {
        fontSize: '15px',
        color: colors.text.secondary,
        textAlign: 'left',
    };

    const isButtonDisabled = isGenerating;
    const generateButtonStyle: React.CSSProperties = {
        position: 'fixed',
        bottom: '48px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 10,
        padding: '18px 60px',
        fontSize: '22px',
        fontWeight: 'bold',
        backgroundColor: isButtonDisabled
            ? colors.background.panel
            : isButtonHovered
                ? colors.primary.accent
                : 'transparent',
        color: isButtonDisabled
            ? colors.text.disabled
            : isButtonHovered
                ? colors.background.main
                : colors.primary.accent,
        border: `2px solid ${isButtonDisabled ? colors.text.disabled : colors.primary.accent}`,
        borderRadius: '12px',
        cursor: isButtonDisabled ? 'not-allowed' : 'pointer',
        transition: 'all 0.25s ease',
        opacity: isButtonDisabled ? 0.6 : 1,
        boxShadow: isButtonHovered && !isButtonDisabled
            ? `0 4px 20px ${colors.primary.accent}40`
            : 'none',
    };

    const qaoacParamsStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        gap: '12px',
        marginTop: '16px',
        padding: '16px',
        backgroundColor: colors.background.panel,
        borderRadius: '8px',
        border: `1px solid ${colors.border.main}`,
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setQasmValidationStatus('loading');
        setQasmValidationError(null);

        const reader = new FileReader();
        reader.onload = async (event) => {
            const content = event.target?.result as string;
            setQasmContent(content);

            try {
                const response = await fetch('/api/validate-qasm', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ qasm: content }),
                });

                const result = await response.json();
                if (response.ok && result.valid) {
                    setQasmValidationStatus('success');
                    setLogicalQubits(result.num_qubits);
                } else {
                    setQasmValidationStatus('error');
                    setQasmValidationError(result.error || 'Failed to validate QASM');
                    setLogicalQubits(constants.qubits.min); // Reset to minimum
                }
            } catch (err) {
                setQasmValidationStatus('error');
                setQasmValidationError('Network error while validating QASM');
            }
        };
        reader.onerror = () => {
            setQasmValidationStatus('error');
            setQasmValidationError('Failed to read file');
        };
        reader.readAsText(file);
    };

    const handleCouplingMapUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setCouplingMapValidation({ status: 'loading' });
        const reader = new FileReader();
        reader.onload = async (event) => {
            const content = event.target?.result as string;

            try {
                const response = await fetch('/api/validate-coupling-map', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ csv: content }),
                });
                const result = await response.json();
                if (response.ok && result.valid) {
                    const lines = content.trim().split('\n');
                    const startIdx = isNaN(parseInt(lines[0].split(',')[0])) ? 1 : 0;
                    const edges = lines.slice(startIdx).map(line => {
                        const [s, t] = line.split(',').map(v => parseInt(v.trim()));
                        return [s, t];
                    });
                    setCouplingMapEdges(edges);
                    setPhysicalQubits(result.num_qubits);
                    setCouplingMapValidation({
                        status: 'success',
                        numQubits: result.num_qubits,
                        numEdges: result.num_edges,
                        detectedTopology: result.detected_topology,
                        detectedParams: result.detected_params,
                    });
                } else {
                    setCouplingMapEdges(null);
                    setCouplingMapValidation({ status: 'error', error: result.error || 'Failed to validate coupling map' });
                }
            } catch (err) {
                setCouplingMapEdges(null);
                setCouplingMapValidation({ status: 'error', error: 'Network error while validating coupling map' });
            }
        };
        reader.onerror = () => {
            setCouplingMapValidation({ status: 'error', error: 'Failed to read file' });
        };
        reader.readAsText(file);
    };

    const handleGenerate = async () => {
        if (isGenerating) return;

        setIsGenerating(true);

        // If the uploaded coupling map matches a known topology, use it for
        // deterministic (static) layout instead of force-directed.
        const detectedTopology = topology === 'custom' ? couplingMapValidation.detectedTopology ?? null : null;
        const effectiveTopology = detectedTopology ?? topology;

        const params: PlaygroundParams = {
            algorithm,
            numQubits: logicalQubits,
            physicalQubits: physicalQubits,
            topology: effectiveTopology,
            optimizationLevels: isPrecompiled ? [] : optimizationLevels,
            customParams: getCustomParams(),
            ...(algorithm === 'custom_qasm' && qasmContent ? { qasm: qasmContent } : {}),
            // Pass heavy hex distance: from detected params when auto-detected, or from slider
            ...(effectiveTopology === 'heavy_hex'
                ? { heavyHexDistance: couplingMapValidation.detectedParams?.distance ?? heavyHexDistance }
                : {}),
            // Only send coupling map edges when no known topology was detected
            ...(topology === 'custom' && couplingMapEdges && !detectedTopology ? { couplingMapEdges } : {}),
            ...(isPrecompiled ? { isPrecompiled: true } : {}),
            numCores: topology === 'custom' ? 1 : numCores,
            coreConnectivity,
        };

        try {
            onGenerate(params);
        } finally {
            setIsGenerating(false);
        }
    };

    const getCustomParams = () => {
        const params: Record<string, any> = {};

        // Add algorithm-specific parameters
        if (algorithm === 'qaoa') {
            params.reps = customParams.reps || constants.qaoa_reps.default;
        }

        return params;
    };

    const handleCustomParamChange = (key: string, value: any) => {
        setCustomParams((prev) => ({
            ...prev,
            [key]: value,
        }));
    };

    const handleLogicalQubitsInputChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        setLogicalQubitsInput(e.target.value);
    };

    const handleLogicalQubitsInputBlur = () => {
        let value = parseInt(logicalQubitsInput, 10);
        if (isNaN(value)) {
            value = constants.qubits.min;
        }
        setLogicalQubits(Math.max(constants.qubits.min, Math.min(value, constants.qubits.max)));
    };

    const handlePhysicalQubitsInputChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        setPhysicalQubitsInput(e.target.value);
    };

    const handlePhysicalQubitsInputBlur = () => {
        let value = parseInt(physicalQubitsInput, 10);
        if (isNaN(value)) {
            value = logicalQubits;
        }
        setPhysicalQubits(Math.max(logicalQubits, Math.min(value, constants.qubits.max)));
    };

    const renderQAOAParams = () => {
        if (algorithm === 'qaoa') {
            return (
                <div style={qaoacParamsStyle}>
                    <div style={sliderLabelStyle}>QAOA Layers (p-value)</div>
                    <div style={sliderWrapperStyle}>
                        <Slider
                            min={constants.qaoa_reps.min}
                            max={constants.qaoa_reps.max}
                            step={1}
                            value={customParams.reps || constants.qaoa_reps.default}
                            onChange={(value) =>
                                handleCustomParamChange('reps', value)
                            }
                            style={{ flex: 1 }}
                        />
                        <input
                            type="number"
                            min={constants.qaoa_reps.min}
                            max={constants.qaoa_reps.max}
                            value={customParams.reps || constants.qaoa_reps.default}
                            onChange={(e) =>
                                handleCustomParamChange(
                                    'reps',
                                    parseInt(e.target.value)
                                )
                            }
                            style={sliderValueStyle}
                        />
                    </div>
                </div>
            );
        }

        if (algorithm === 'custom_qasm') {
            return (
                <div style={qaoacParamsStyle}>
                    {/* Logical / Compiled toggle */}
                    <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
                        <button style={topologyButtonStyle(!isPrecompiled)} onClick={() => setIsPrecompiled(false)}>Logical</button>
                        <button style={topologyButtonStyle(isPrecompiled)} onClick={() => setIsPrecompiled(true)}>Compiled</button>
                    </div>
                    <div style={{ ...sliderLabelStyle, display: 'flex', alignItems: 'center', gap: '8px' }}>
                        {isPrecompiled ? 'Upload Compiled QASM File' : 'Upload QASM File'}
                        <HelpIcon mode="modal" onClick={() => setIsHelpOpen(true)} />
                    </div>
                    <input
                        type="file"
                        accept=".qasm,.txt"
                        onChange={handleFileUpload}
                        style={{
                            padding: '10px',
                            backgroundColor: colors.background.main,
                            color: colors.text.primary,
                            borderRadius: '8px',
                            border: `1px solid ${colors.border.main}`,
                            width: '100%',
                            boxSizing: 'border-box'
                        }}
                    />

                    {qasmValidationStatus === 'loading' && (
                        <div style={{ color: colors.text.secondary, marginTop: '8px' }}>
                            Validating QASM...
                        </div>
                    )}

                    {qasmValidationStatus === 'success' && (
                        <div style={{ color: colors.state.success, marginTop: '8px', textAlign: 'center' }}>
                            ✓ Valid QASM<br />
                            <span style={{ fontSize: '14px', color: colors.text.secondary }}>
                                Parsed {logicalQubits} logical qubits
                            </span>
                        </div>
                    )}

                    {qasmValidationStatus === 'error' && (
                        <div style={{ color: colors.state.error, marginTop: '8px', fontSize: '14px', wordBreak: 'break-word', textAlign: 'center' }}>
                            ✗ Validation Failed<br />
                            {qasmValidationError}
                        </div>
                    )}
                </div>
            );
        }

        return null;
    };

    const renderHelpModal = () => {
        if (!isHelpOpen) return null;

        return (
            <div style={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100vw',
                height: '100vh',
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 1000,
            }}>
                <div style={{
                    backgroundColor: colors.background.panelSolid,
                    border: `1px solid ${colors.border.active}`,
                    borderRadius: '12px',
                    padding: '30px',
                    maxWidth: '600px',
                    width: '90%',
                    boxShadow: `0 10px 30px ${colors.shadow.dark}`,
                    position: 'relative',
                }}>
                    <button
                        onClick={() => setIsHelpOpen(false)}
                        style={{
                            position: 'absolute',
                            top: '15px',
                            right: '20px',
                            background: 'none',
                            border: 'none',
                            color: colors.text.muted,
                            fontSize: '24px',
                            cursor: 'pointer',
                        }}
                    >
                        ×
                    </button>
                    <h2 style={{ ...sectionTitleStyle, textAlign: 'left', color: colors.primary.accent }}>
                        {isPrecompiled ? 'Exporting a Compiled Circuit & Coupling Map' : 'Generating QASM from Qiskit'}
                    </h2>
                    <p style={{ color: colors.text.secondary, marginBottom: '20px', lineHeight: '1.5' }}>
                        {isPrecompiled
                            ? 'Export a pre-compiled circuit and its coupling map for visualization in Quvis.'
                            : 'You can easily export any `QuantumCircuit` to OpenQASM 2.0 format using the `qiskit.qasm2` module.'}
                    </p>
                    <div style={{
                        backgroundColor: colors.background.main,
                        padding: '15px',
                        borderRadius: '8px',
                        border: `1px solid ${colors.border.main}`,
                        overflowX: 'auto',
                    }}>
                        {isPrecompiled ? (
                        <pre style={{ margin: 0, color: colors.text.primary, fontSize: '14px', fontFamily: 'monospace', lineHeight: '1.4' }}>
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> QuantumCircuit, transpile<br />
                            <span style={{ color: '#c678dd' }}>from</span> qiskit.transpiler <span style={{ color: '#c678dd' }}>import</span> CouplingMap<br />
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> qasm2<br />
                            <span style={{ color: '#c678dd' }}>import</span> csv<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Define your coupling map</span><br />
                            coupling_map = CouplingMap([[<span style={{ color: '#d19a66' }}>0</span>, <span style={{ color: '#d19a66' }}>1</span>], [<span style={{ color: '#d19a66' }}>1</span>, <span style={{ color: '#d19a66' }}>2</span>], [<span style={{ color: '#d19a66' }}>2</span>, <span style={{ color: '#d19a66' }}>3</span>]])<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Create and compile your circuit</span><br />
                            qc = QuantumCircuit(<span style={{ color: '#d19a66' }}>3</span>)<br />
                            qc.h(<span style={{ color: '#d19a66' }}>0</span>)<br />
                            qc.cx(<span style={{ color: '#d19a66' }}>0</span>, <span style={{ color: '#d19a66' }}>1</span>)<br />
                            compiled = transpile(qc, coupling_map=coupling_map)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Export compiled circuit</span><br />
                            qasm2.dump(compiled, <span style={{ color: '#98c379' }}>"compiled.qasm"</span>)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Export coupling map to CSV</span><br />
                            <span style={{ color: '#c678dd' }}>with</span> open(<span style={{ color: '#98c379' }}>"coupling_map.csv"</span>, <span style={{ color: '#98c379' }}>"w"</span>) <span style={{ color: '#c678dd' }}>as</span> f:<br />
                            {'    '}writer = csv.writer(f)<br />
                            {'    '}writer.writerow([<span style={{ color: '#98c379' }}>"source"</span>, <span style={{ color: '#98c379' }}>"target"</span>])<br />
                            {'    '}<span style={{ color: '#c678dd' }}>for</span> edge <span style={{ color: '#c678dd' }}>in</span> coupling_map.get_edges():<br />
                            {'        '}writer.writerow(edge)
                        </pre>
                        ) : (
                        <pre style={{ margin: 0, color: colors.text.primary, fontSize: '14px', fontFamily: 'monospace', lineHeight: '1.4' }}>
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> QuantumCircuit<br />
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> qasm2<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Create your circuit</span><br />
                            qc = QuantumCircuit(<span style={{ color: '#d19a66' }}>2</span>)<br />
                            qc.h(<span style={{ color: '#d19a66' }}>0</span>)<br />
                            qc.cx(<span style={{ color: '#d19a66' }}>0</span>, <span style={{ color: '#d19a66' }}>1</span>)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Export to OpenQASM 2.0 string</span><br />
                            qasm_str = qasm2.dumps(qc)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Or save directly to a file</span><br />
                            qasm2.dump(qc, <span style={{ color: '#98c379' }}>"my_circuit.qasm"</span>)
                        </pre>
                        )}
                    </div>
                </div>
            </div>
        );
    };

    const qubitsPerCoreLabel = () => {
        if (topology === 'grid') {
            return `${Math.ceil(Math.sqrt(physicalQubits / numCores)) ** 2} qubits per core`;
        } else if (topology === 'heavy_hex') {
            const target = physicalQubits / numCores;
            const hhQ = (d: number) => (5 * d * d - 2 * d - 1) / 2;
            let d = 3;
            while (hhQ(d) < target && d < 100) d += 2;
            return `${hhQ(d)} qubits per core (d=${d})`;
        }
        return `${Math.floor(physicalQubits / numCores)} qubits per core`;
    };

    return (
        <div style={containerStyle}>
            <style>
                {`
                    /* Hide number input spinners */
                    input[type="number"]::-webkit-outer-spin-button,
                    input[type="number"]::-webkit-inner-spin-button {
                        -webkit-appearance: none;
                        margin: 0;
                    }

                    input[type="number"] {
                        -moz-appearance: textfield;
                    }
                `}
            </style>
            <h1 style={mainTitleStyle}>Quvis</h1>
            <p style={subtitleStyle}>Visualisation Framework for the Compilation of Large-Scale Quantum Circuits</p>
            <p style={versionStyle}>
                Version {version} &nbsp;·&nbsp; Made by{' '}
                <a
                    href="https://github.com/alejandrogonzalvo/"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={linkStyle}
                >
                    @alejandrogonzalvo
                </a> — Source code on request.
            </p>

            <div style={columnsContainerStyle}>
                {/* Column 1: Circuit + Logical Qubits */}
                <div style={columnStyle}>
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Circuit</h2>
                        <div style={buttonGroupStyle}>
                            <button
                                style={circuitButtonStyle(algorithm === 'ghz')}
                                onClick={() => setAlgorithm('ghz')}
                            >
                                GHZ
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'qft')}
                                onClick={() => setAlgorithm('qft')}
                            >
                                QFT
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'qaoa')}
                                onClick={() => setAlgorithm('qaoa')}
                            >
                                QAOA
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'custom_qasm')}
                                onClick={() => setAlgorithm('custom_qasm')}
                            >
                                Custom QASM
                            </button>
                        </div>
                        {renderQAOAParams()}
                        {algorithm !== 'custom_qasm' && (
                            <div style={{ marginTop: '16px' }}>
                                <div style={sliderContainerStyle}>
                                    <div style={sliderLabelStyle}>Logical Qubits</div>
                                    <div style={sliderWrapperStyle}>
                                        <Slider
                                            min={constants.qubits.min}
                                            max={topology === 'heavy_hex' ? physicalQubits : constants.qubits.max}
                                            step={1}
                                            value={logicalQubits}
                                            onChange={(value) => setLogicalQubits(value)}
                                            style={{ flex: 1 }}
                                            inputWidth="30px"
                                        />
                                        <input
                                            type="number"
                                            min={constants.qubits.min}
                                            max={topology === 'heavy_hex' ? physicalQubits : constants.qubits.max}
                                            value={logicalQubitsInput}
                                            onChange={handleLogicalQubitsInputChange}
                                            onBlur={handleLogicalQubitsInputBlur}
                                            style={sliderValueStyle}
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Column 2: Topology + Physical Qubits + Multicore */}
                <div style={columnStyle}>
                    {/* Topology Selection + Physical Qubits / Size Parameter */}
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Topology</h2>
                        <div style={stretchButtonGroupStyle}>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'line'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('line')}
                                disabled={topologyLocked}
                            >
                                Line
                            </button>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'ring'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('ring')}
                                disabled={topologyLocked}
                            >
                                Ring
                            </button>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'grid'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('grid')}
                                disabled={topologyLocked}
                            >
                                Grid
                            </button>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'heavy_hex'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('heavy_hex')}
                                disabled={topologyLocked}
                            >
                                Heavy Hex
                            </button>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'full'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('full')}
                                disabled={topologyLocked}
                            >
                                Full
                            </button>
                            <button
                                style={{
                                    ...topologyButtonStyle(topology === 'custom'),
                                    ...(topologyLocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}),
                                }}
                                onClick={() => !topologyLocked && setTopology('custom')}
                            >
                                Custom
                            </button>
                        </div>
                        <div style={{ marginTop: '24px' }}>
                            {topology === 'custom' ? (
                                <div style={sliderContainerStyle}>
                                    <div style={sliderLabelStyle}>Upload Coupling Map (CSV)</div>
                                    <input type="file" accept=".csv,.txt" onChange={handleCouplingMapUpload}
                                        style={{ padding: '10px', backgroundColor: colors.background.main, color: colors.text.primary, borderRadius: '8px', border: `1px solid ${colors.border.main}`, width: '100%', boxSizing: 'border-box' as const }}
                                    />
                                    {couplingMapValidation.status === 'loading' && (
                                        <div style={{ color: colors.text.secondary, marginTop: '8px' }}>Validating coupling map...</div>
                                    )}
                                    {couplingMapValidation.status === 'success' && (
                                        <div style={{ color: colors.state.success, marginTop: '8px', textAlign: 'center' }}>
                                            ✓ Valid coupling map<br />
                                            <span style={{ fontSize: '14px', color: colors.text.secondary }}>
                                                {couplingMapValidation.numQubits} qubits, {couplingMapValidation.numEdges} edges
                                                {couplingMapValidation.detectedTopology && (<><br />Detected topology: {couplingMapValidation.detectedTopology}</>)}
                                            </span>
                                        </div>
                                    )}
                                    {couplingMapValidation.status === 'error' && (
                                        <div style={{ color: colors.state.error, marginTop: '8px', fontSize: '14px', wordBreak: 'break-word', textAlign: 'center' }}>
                                            ✗ Validation Failed<br />{couplingMapValidation.error}
                                        </div>
                                    )}
                                </div>
                            ) : topology === 'heavy_hex' ? (
                                <div style={sliderContainerStyle}>
                                    <div style={sliderLabelStyle}>Heavy Hex Distance (d)</div>
                                    <div style={sliderWrapperStyle}>
                                        <Slider
                                            min={constants.heavy_hex_distance.min}
                                            max={constants.heavy_hex_distance.max}
                                            step={constants.heavy_hex_distance.step}
                                            value={heavyHexDistance}
                                            onChange={(value) => setHeavyHexDistance(value)}
                                            style={{ flex: 1 }}
                                            inputWidth="50px"
                                        />
                                        <div style={sliderValueStyle}>
                                            {heavyHexDistance}
                                        </div>
                                    </div>
                                    <div style={helperTextStyle}>
                                        Calculated Physical Qubits: {physicalQubits}
                                    </div>
                                </div>
                            ) : topology === 'grid' ? (
                                <div style={sliderContainerStyle}>
                                    <div style={sliderLabelStyle}>Grid Row Size (n)</div>
                                    <div style={sliderWrapperStyle}>
                                        <Slider
                                            min={constants.grid_size.min}
                                            max={constants.grid_size.max}
                                            step={1}
                                            value={gridSize}
                                            onChange={(value) => setGridSize(value)}
                                            style={{ flex: 1 }}
                                            inputWidth="50px"
                                        />
                                        <div style={sliderValueStyle}>
                                            {gridSize}
                                        </div>
                                    </div>
                                    <div style={helperTextStyle}>
                                        Calculated Physical Qubits: {gridSize * gridSize}
                                    </div>
                                </div>
                            ) : (
                                <div style={sliderContainerStyle}>
                                    <div style={sliderLabelStyle}>Physical Qubits</div>
                                    <div style={sliderWrapperStyle}>
                                        <Slider
                                            min={logicalQubits}
                                            max={constants.qubits.max}
                                            step={1}
                                            value={physicalQubits}
                                            onChange={(value) => setPhysicalQubits(value)}
                                            style={{ flex: 1 }}
                                            inputWidth="50px"
                                        />
                                        <input
                                            type="number"
                                            min={logicalQubits}
                                            max={constants.qubits.max}
                                            value={physicalQubitsInput}
                                            onChange={handlePhysicalQubitsInputChange}
                                            onBlur={handlePhysicalQubitsInputBlur}
                                            style={sliderValueStyle}
                                        />
                                    </div>
                                    <div style={{ ...helperTextStyle, visibility: 'hidden' }}>placeholder</div>
                                </div>
                            )}
                        </div>

                        {topology !== 'custom' && (<div style={{ borderTop: `1px solid ${colors.border.separator}`, marginTop: '20px', paddingTop: '16px' }}>
                            <h2 style={sectionTitleStyle}>Multicore</h2>
                            <div style={sliderContainerStyle}>
                                <div style={sliderLabelStyle}>Number of Cores</div>
                                <div style={sliderWrapperStyle}>
                                    <Slider
                                        min={1}
                                        max={5}
                                        step={1}
                                        value={numCores}
                                        onChange={(value) => setNumCores(value)}
                                        style={{ flex: 1 }}
                                        inputWidth="50px"
                                    />
                                    <div style={sliderValueStyle}>{numCores}</div>
                                </div>
                                <div style={{
                                    overflow: 'hidden',
                                    maxHeight: numCores > 1 ? '60px' : '0px',
                                    transition: 'max-height 0.3s ease',
                                }}>
                                    <div style={{ ...helperTextStyle, paddingTop: '4px' }}>{qubitsPerCoreLabel()}</div>
                                </div>
                            </div>

                            <div style={{
                                overflow: 'hidden',
                                maxHeight: numCores > 1 ? '200px' : '0px',
                                transition: 'max-height 0.3s ease',
                            }}>
                                <div style={{ ...sliderContainerStyle, marginTop: '20px' }}>
                                    <div style={sliderLabelStyle}>Core Connectivity</div>
                                    <div style={stretchButtonGroupStyle}>
                                        <button
                                            style={topologyButtonStyle(coreConnectivity === 'all-to-all')}
                                            onClick={() => setCoreConnectivity('all-to-all')}
                                        >
                                            All-to-All
                                        </button>
                                        <button
                                            style={topologyButtonStyle(coreConnectivity === 'grid')}
                                            onClick={() => setCoreConnectivity('grid')}
                                        >
                                            Grid
                                        </button>
                                        <button
                                            style={topologyButtonStyle(coreConnectivity === 'line')}
                                            onClick={() => setCoreConnectivity('line')}
                                        >
                                            Line
                                        </button>
                                        <button
                                            style={topologyButtonStyle(coreConnectivity === 'ring')}
                                            onClick={() => setCoreConnectivity('ring')}
                                        >
                                            Ring
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>)}
                    </div>
                </div>

                {/* Column 3: Compiler */}
                <div style={columnStyle}>
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Compiler</h2>
                        <div style={sliderContainerStyle}>
                            <div style={{ ...sliderLabelStyle, display: 'flex', alignItems: 'center', gap: '8px' }}>
                                Optimization Level
                                <HelpIcon
                                    mode="tooltip"
                                    text="The optimization level of the Qiskit transpiler. Higher levels produce more efficient circuits but take longer to compile."
                                />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', opacity: isPrecompiled ? 0.4 : 1, pointerEvents: isPrecompiled ? 'none' : 'auto' }}>
                                {[
                                    { value: 0, label: 'Level 0 — No optimization' },
                                    { value: 1, label: 'Level 1 — Light optimization' },
                                    { value: 2, label: 'Level 2 — Heavy optimization' },
                                    { value: 3, label: 'Level 3 — Max optimization' },
                                ].map(({ value, label }) => {
                                    const isChecked = optimizationLevels.includes(value);
                                    return (
                                        <label
                                            key={value}
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '12px',
                                                cursor: 'pointer',
                                                fontSize: '15px',
                                                fontWeight: '600',
                                                color: colors.text.primary,
                                                padding: '10px 14px',
                                                borderRadius: '8px',
                                                border: `2px solid ${isChecked ? colors.primary.accent : colors.border.main}`,
                                                backgroundColor: isChecked
                                                    ? `${colors.primary.accent}15`
                                                    : colors.background.main,
                                                transition: 'all 0.3s ease',
                                            }}
                                        >
                                            <div
                                                style={{
                                                    width: '20px',
                                                    height: '20px',
                                                    borderRadius: '4px',
                                                    border: `2px solid ${isChecked ? colors.primary.accent : colors.border.main}`,
                                                    backgroundColor: isChecked ? colors.primary.accent : 'transparent',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    flexShrink: 0,
                                                    transition: 'all 0.3s ease',
                                                }}
                                            >
                                                {isChecked && (
                                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                                                        <path
                                                            d="M2 6L5 9L10 3"
                                                            stroke={colors.background.main}
                                                            strokeWidth="2"
                                                            strokeLinecap="round"
                                                            strokeLinejoin="round"
                                                        />
                                                    </svg>
                                                )}
                                            </div>
                                            <input
                                                type="checkbox"
                                                checked={isChecked}
                                                onChange={() => {
                                                    setOptimizationLevels((prev) => {
                                                        if (prev.includes(value)) {
                                                            return prev.filter((v) => v !== value);
                                                        }
                                                        return [...prev, value].sort();
                                                    });
                                                }}
                                                style={{ display: 'none' }}
                                            />
                                            {label}
                                        </label>
                                    );
                                })}
                            </div>
                            {isPrecompiled && (
                                <div style={{ ...helperTextStyle, marginTop: '12px', textAlign: 'center' }}>
                                    Compilation skipped — using pre-compiled circuit.
                                </div>
                            )}
                            {!isPrecompiled && optimizationLevels.length === 0 && (
                                <div style={{ ...helperTextStyle, marginTop: '12px', textAlign: 'center' }}>
                                    No compilation — only the logical circuit will be shown.
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <button
                onClick={handleGenerate}
                style={generateButtonStyle}
                disabled={
                    isGenerating
                    || (algorithm === 'custom_qasm' && qasmValidationStatus !== 'success')
                    || (topology === 'custom' && couplingMapValidation.status !== 'success')
                }
                onMouseEnter={() => setIsButtonHovered(true)}
                onMouseLeave={() => setIsButtonHovered(false)}
            >
                {isGenerating ? 'Generating...' : 'Visualize'}
            </button>
            {renderHelpModal()}
        </div>
    );
};

export default PlaygroundParameterSelection;
export type { PlaygroundParams };
