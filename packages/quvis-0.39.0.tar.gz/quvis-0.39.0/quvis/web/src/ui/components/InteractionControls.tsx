import React from "react";
import { colors } from "../theme/colors.js";
import { typography } from "../theme/typography.js";

interface InteractionControlsProps { }

const InteractionControls: React.FC<InteractionControlsProps> = () => {
    const panelStyle: React.CSSProperties = {
        backgroundColor: colors.background.panel,
        padding: "15px",
        borderRadius: "8px",
        color: colors.text.primary,
        fontFamily: typography.fontFamily.ui,
        zIndex: 10,
        width: "250px",
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
        transition: "all 0.3s ease",
    };

    const headerStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
        borderBottom: `1px solid ${colors.border.separator}`,
        paddingBottom: "10px",
        marginBottom: "10px",
    };

    const headerTitleStyle: React.CSSProperties = {
        margin: "0",
        fontSize: "14px",
        fontWeight: 600,
        color: colors.text.primary,
        textTransform: "uppercase",
        letterSpacing: "0.5px",
    };

    return (
        <div style={panelStyle}>
            <div style={headerStyle}>
                <h4 style={headerTitleStyle}>Interaction Data</h4>
            </div>

            <div
                id="heatmap-legend-container"
                style={{
                    backgroundColor: colors.ui.surface,
                    borderRadius: "6px",
                    border: `1px solid ${colors.border.separator}`,
                    padding: "0", // Legend will handle its own padding
                }}
            ></div>
        </div>
    );
};

export default InteractionControls;
