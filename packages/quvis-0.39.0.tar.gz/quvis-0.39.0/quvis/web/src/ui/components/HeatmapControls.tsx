import React, { useState, useEffect } from "react";
import type { Playground } from "../../scene/Playground.js";
import { colors } from "../theme/colors.js";
import { typography } from "../theme/typography.js";
import { CircleHelp } from "lucide-react";
import Slider from "./Slider.js";

interface HeatmapControlsProps {
    playground: Playground | null;
    initialValues: {
        maxSlices: number;
        baseSize: number;
        fadeThreshold?: number;
        greenThreshold?: number;
        yellowThreshold?: number;
        intensityPower?: number;
        minIntensity?: number;
        borderWidth?: number;
    };
}

type TooltipId =
    | "slices"
    | "baseSize"
    | "fadeStart"
    | "greenZone"
    | "yellowZone"
    | "powerCurve"
    | "minIntensity"
    | "borderWidth"
    | null;

const TOOLTIP_TEXT: Record<NonNullable<TooltipId>, string> = {
    slices: "Controls the time window for heat accumulation. Set to -1 for a cumulative view across all time slices.",
    baseSize: "Base size of heatmap spheres and visual indicators. Higher values make elements larger and more prominent.",
    fadeStart: "Intensity ratio below which green spheres start fading out. Controls the low-end visibility cutoff.",
    greenZone: "Intensity ratio below which qubits appear green (low activity).",
    yellowZone: "Intensity ratio below which qubits appear yellow (medium activity). Above this threshold they turn red.",
    powerCurve: "Gamma/power applied to the raw intensity before mapping to color. Values < 1 boost dim qubits; values > 1 compress them.",
    minIntensity: "Minimum rendered intensity. Qubits below this threshold are hidden entirely.",
    borderWidth: "Width of the dark contour drawn around each heatmap sphere for shape definition.",
};

const HeatmapControls: React.FC<HeatmapControlsProps> = ({
    playground,
    initialValues,
}) => {
    const [isHovered, setIsHovered] = useState(false);
    const [maxSlices, setMaxSlices] = useState(initialValues.maxSlices);
    const [baseSize, setBaseSize] = useState(initialValues.baseSize);

    // Color parameters state
    const [fadeThreshold, setFadeThreshold] = useState(0.1);
    const [greenThreshold, setGreenThreshold] = useState(0.3);
    const [yellowThreshold, setYellowThreshold] = useState(0.7);
    const [intensityPower, setIntensityPower] = useState(0.3);
    const [minIntensity, setMinIntensity] = useState(0.01);
    const [borderWidth, setBorderWidth] = useState(0.0);

    const [activeTooltip, setActiveTooltip] = useState<TooltipId>(null);
    const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
    const [tooltipFading, setTooltipFading] = useState(false);

    // CSS animation styles for tooltip fade in/out
    const fadeInKeyframes = `
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-100%) translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(-100%) translateY(0px);
            }
        }
        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateY(-100%) translateY(0px);
            }
            to {
                opacity: 0;
                transform: translateY(-100%) translateY(-10px);
            }
        }
    `;

    React.useEffect(() => {
        const styleId = 'tooltip-animations';
        if (!document.getElementById(styleId)) {
            const style = document.createElement('style');
            style.id = styleId;
            style.textContent = fadeInKeyframes;
            document.head.appendChild(style);
        }
    }, []);

    useEffect(() => {
        setMaxSlices(initialValues.maxSlices);
        setBaseSize(initialValues.baseSize);

        if (initialValues.fadeThreshold !== undefined) setFadeThreshold(initialValues.fadeThreshold);
        else if (playground) setFadeThreshold(playground.getHeatmapColorParameters().fadeThreshold);

        if (initialValues.greenThreshold !== undefined) setGreenThreshold(initialValues.greenThreshold);
        else if (playground) setGreenThreshold(playground.getHeatmapColorParameters().greenThreshold);

        if (initialValues.yellowThreshold !== undefined) setYellowThreshold(initialValues.yellowThreshold);
        else if (playground) setYellowThreshold(playground.getHeatmapColorParameters().yellowThreshold);

        if (initialValues.intensityPower !== undefined) setIntensityPower(initialValues.intensityPower);
        else if (playground) setIntensityPower(playground.getHeatmapColorParameters().intensityPower);

        if (initialValues.minIntensity !== undefined) setMinIntensity(initialValues.minIntensity);
        else if (playground) setMinIntensity(playground.getHeatmapColorParameters().minIntensity);

        if (initialValues.borderWidth !== undefined) setBorderWidth(initialValues.borderWidth);
        else if (playground) setBorderWidth(playground.getHeatmapColorParameters().borderWidth);

    }, [initialValues, playground]);

    const handleMaxSlicesChange = (value: number) => {
        setMaxSlices(value);
        if (playground) playground.updateHeatmapSlices(value);
    };

    const handleBaseSizeChange = (value: number) => {
        setBaseSize(value);
        if (playground) playground.updateAppearanceParameters({ baseSize: value });
    };

    const handleFadeThresholdChange = (value: number) => {
        setFadeThreshold(value);
        if (playground) playground.updateHeatmapColorParameters({ fadeThreshold: value });
    };

    const handleGreenThresholdChange = (value: number) => {
        setGreenThreshold(value);
        if (playground) playground.updateHeatmapColorParameters({ greenThreshold: value });
    };

    const handleYellowThresholdChange = (value: number) => {
        setYellowThreshold(value);
        if (playground) playground.updateHeatmapColorParameters({ yellowThreshold: value });
    };

    const handleIntensityPowerChange = (value: number) => {
        setIntensityPower(value);
        if (playground) playground.updateHeatmapColorParameters({ intensityPower: value });
    };

    const handleMinIntensityChange = (value: number) => {
        setMinIntensity(value);
        if (playground) playground.updateHeatmapColorParameters({ minIntensity: value });
    };

    const handleBorderWidthChange = (value: number) => {
        setBorderWidth(value);
        if (playground) playground.updateHeatmapColorParameters({ borderWidth: value });
    };

    const openTooltip = (id: NonNullable<TooltipId>, e: React.MouseEvent) => {
        const rect = e.currentTarget.getBoundingClientRect();
        setTooltipPosition({
            top: rect.top - 10,
            left: Math.max(20, rect.left - 150),
        });
        setTooltipFading(false);
        setActiveTooltip(id);
    };

    const closeTooltip = () => {
        setTooltipFading(true);
        setTimeout(() => {
            setActiveTooltip(null);
            setTooltipFading(false);
        }, 150);
    };

    const helpIcon = (id: NonNullable<TooltipId>) => (
        <span
            style={{ display: "inline-flex", alignItems: "center", cursor: "help", color: colors.text.muted, marginLeft: "4px" }}
            onMouseEnter={(e) => openTooltip(id, e)}
            onMouseLeave={closeTooltip}
        >
            <CircleHelp size={13} strokeWidth={1.8} />
        </span>
    );

    const panelStyle: React.CSSProperties = {
        backgroundColor: colors.background.panel,
        padding: "15px",
        borderRadius: "8px",
        color: colors.text.primary,
        fontFamily: typography.fontFamily.ui,
        width: "250px",
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
        transition: "all 0.3s ease",
    };

    const headerStyle: React.CSSProperties = {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        cursor: "pointer",
        padding: "4px 8px",
        borderRadius: "4px",
        transition: "background-color 0.2s ease",
        borderBottom: `1px solid ${colors.border.separator}`,
        paddingBottom: "10px",
        marginBottom: "0",
    };

    const headerTitleStyle: React.CSSProperties = {
        margin: "0",
        fontSize: "14px",
        fontWeight: 600,
        color: colors.text.primary,
        textTransform: "uppercase",
        letterSpacing: "0.5px",
    };

    const contentStyle: React.CSSProperties = {
        opacity: 1,
        maxHeight: "1000px",
        overflow: "auto",
        transition: "all 0.3s ease",
        marginTop: "10px",
    };

    const controlGroupStyle: React.CSSProperties = {
        marginBottom: "15px",
    };

    const labelStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
        marginBottom: "8px",
        fontSize: "0.9em",
        fontWeight: 500,
        color: colors.text.primary,
    };

    const subLabelStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
        fontSize: "0.8em",
        color: colors.text.secondary,
        marginBottom: "3px",
    };

    const sliderContainerStyle: React.CSSProperties = {
        display: "flex",
        alignItems: "center",
    };

    const colorControlsStyle: React.CSSProperties = {
        marginTop: "12px",
        padding: "12px",
        backgroundColor: colors.ui.surface,
        borderRadius: "6px",
        border: `1px solid ${colors.border.separator}`,
    };

    return (
        <div style={panelStyle}>
            <div style={headerStyle}>
                <h4 style={headerTitleStyle}>
                    Heatmap Controls
                </h4>
            </div>

            <div style={contentStyle}>
                {/* Max Heatmap Slices */}
                <div style={controlGroupStyle}>
                    <label htmlFor="max-slices" style={labelStyle}>
                        Max Heatmap Slices
                        {helpIcon("slices")}
                    </label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="max-slices"
                            min={-1}
                            max={1000}
                            step={1}
                            value={maxSlices}
                            onChange={handleMaxSlicesChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={0}
                        />
                    </div>
                </div>

                {/* Heatmap Base Size */}
                <div style={controlGroupStyle}>
                    <label htmlFor="heatmap-base-size" style={labelStyle}>
                        Heatmap Base Size
                        {helpIcon("baseSize")}
                    </label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="heatmap-base-size"
                            min={0}
                            max={4000}
                            step={10}
                            value={baseSize}
                            onChange={handleBaseSizeChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={0}
                        />
                    </div>
                </div>

                {/* Color Controls */}
                <div style={controlGroupStyle}>
                    <label style={labelStyle}>Color Controls</label>

                    <div style={colorControlsStyle}>
                        {/* Thresholds */}
                        <div style={controlGroupStyle}>
                            <label style={{ ...labelStyle, marginBottom: "6px" }}>
                                Thresholds
                            </label>
                            <div style={{ marginBottom: "10px" }}>
                                <div style={subLabelStyle}>
                                    Fade Start {helpIcon("fadeStart")}
                                </div>
                                <Slider
                                    min={0} max={1} step={0.001}
                                    value={fadeThreshold}
                                    onChange={handleFadeThresholdChange}
                                    showInput precision={3} inputWidth="50px"
                                />
                            </div>
                            <div style={{ marginBottom: "10px" }}>
                                <div style={subLabelStyle}>
                                    Green Zone {helpIcon("greenZone")}
                                </div>
                                <Slider
                                    min={0} max={1} step={0.001}
                                    value={greenThreshold}
                                    onChange={handleGreenThresholdChange}
                                    showInput precision={3} inputWidth="50px"
                                />
                            </div>
                            <div style={{ marginBottom: "4px" }}>
                                <div style={subLabelStyle}>
                                    Yellow Zone {helpIcon("yellowZone")}
                                </div>
                                <Slider
                                    min={0} max={1} step={0.001}
                                    value={yellowThreshold}
                                    onChange={handleYellowThresholdChange}
                                    showInput precision={3} inputWidth="50px"
                                />
                            </div>
                        </div>

                        {/* Intensity Controls */}
                        <div style={controlGroupStyle}>
                            <label style={{ ...labelStyle, marginBottom: "6px" }}>
                                Intensity Controls
                            </label>
                            <div style={{ marginBottom: "10px" }}>
                                <div style={subLabelStyle}>
                                    Power Curve {helpIcon("powerCurve")}
                                </div>
                                <Slider
                                    min={0.01} max={2} step={0.01}
                                    value={intensityPower}
                                    onChange={handleIntensityPowerChange}
                                    showInput precision={2} inputWidth="50px"
                                />
                            </div>
                            <div style={{ marginBottom: "10px" }}>
                                <div style={subLabelStyle}>
                                    Min Intensity {helpIcon("minIntensity")}
                                </div>
                                <Slider
                                    min={0} max={0.9} step={0.001}
                                    value={minIntensity}
                                    onChange={handleMinIntensityChange}
                                    showInput precision={3} inputWidth="50px"
                                />
                            </div>
                            <div style={{ marginBottom: "4px" }}>
                                <div style={subLabelStyle}>
                                    Border Width {helpIcon("borderWidth")}
                                </div>
                                <Slider
                                    min={0} max={0.9} step={0.001}
                                    value={borderWidth}
                                    onChange={handleBorderWidthChange}
                                    showInput precision={3} inputWidth="50px"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Single shared tooltip rendered once via portal */}
            {activeTooltip && (
                <div style={{
                    position: "fixed",
                    top: `${tooltipPosition.top}px`,
                    left: `${tooltipPosition.left}px`,
                    padding: "12px 16px",
                    backgroundColor: colors.background.panelSolid,
                    color: colors.text.primary,
                    fontSize: "13px",
                    borderRadius: "8px",
                    whiteSpace: "normal",
                    width: "280px",
                    maxWidth: "calc(100vw - 40px)",
                    boxShadow: `0 4px 20px ${colors.shadow.medium}`,
                    zIndex: 10000,
                    lineHeight: "1.5",
                    border: `1px solid ${colors.border.light}`,
                    transform: "translateY(-100%)",
                    animation: `${tooltipFading ? "fadeOut" : "fadeIn"} 0.15s ease-out`,
                    pointerEvents: "none",
                }}>
                    {TOOLTIP_TEXT[activeTooltip]}
                    <div style={{
                        position: "absolute",
                        top: "100%",
                        left: "150px",
                        width: "0",
                        height: "0",
                        borderLeft: "6px solid transparent",
                        borderRight: "6px solid transparent",
                        borderTop: `6px solid ${colors.background.panelSolid}`,
                    }} />
                </div>
            )}
        </div>
    );
};

export default HeatmapControls;
