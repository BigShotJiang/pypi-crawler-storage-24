import React, { useEffect, useCallback } from 'react';
import { colors } from '../theme/colors.js';
import { typography } from '../theme/typography.js';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import Slider from './Slider.js';

interface TimelineSliderProps {
    min: number;
    max: number;
    value: number;
    onChange: (newValue: number) => void;
    disabled: boolean;
    label?: string;
}

const TimelineSlider: React.FC<TimelineSliderProps> = ({
    min,
    max,
    value,
    onChange,
    disabled,
    label,
}) => {
    const containerStyle: React.CSSProperties = {
        position: 'fixed',
        bottom: '10px',
        left: '50%',
        transform: 'translateX(-50%)',
        width: '80%',
        maxWidth: '800px',
        height: '48px',
        padding: '0 15px',
        display: 'flex',
        alignItems: 'center',
        boxSizing: 'border-box',
        zIndex: 10,
        backgroundColor: colors.background.panel,
        borderRadius: '8px',
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
        color: colors.text.primary,
        fontFamily: typography.fontFamily.ui,
    };

    const controlsRowStyle: React.CSSProperties = {
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        width: '100%',
    };

    const arrowButtonStyle: React.CSSProperties = {
        background: colors.interactive.button.background,
        color: colors.text.primary,
        border: `1px solid ${colors.border.light}`,
        borderRadius: '4px',
        padding: '4px 8px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: '32px',
        minHeight: '24px',
    };

    const disabledArrowButtonStyle: React.CSSProperties = {
        ...arrowButtonStyle,
        opacity: 0.5,
        cursor: 'not-allowed',
    };

    const maxCountStyle: React.CSSProperties = {
        fontSize: '0.9em',
        fontWeight: 'bold',
        color: colors.text.secondary,
        marginRight: '8px',
        whiteSpace: 'nowrap',
    };

    const isOverallDisabled = disabled || max < min;

    const handleLeftArrowClick = useCallback(() => {
        if (!isOverallDisabled && value > min) {
            onChange(value - 1);
        }
    }, [value, min, onChange, isOverallDisabled]);

    const handleRightArrowClick = useCallback(() => {
        if (!isOverallDisabled && value < max) {
            onChange(value + 1);
        }
    }, [value, max, onChange, isOverallDisabled]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (isOverallDisabled) return;

            if (event.key === 'ArrowLeft') {
                event.preventDefault();
                handleLeftArrowClick();
            } else if (event.key === 'ArrowRight') {
                event.preventDefault();
                handleRightArrowClick();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [handleLeftArrowClick, handleRightArrowClick, isOverallDisabled]);

    const isLeftDisabled = isOverallDisabled || value <= min;
    const isRightDisabled = isOverallDisabled || value >= max;

    return (
        <div style={containerStyle}>
            <div style={controlsRowStyle}>
                <Slider
                    min={min}
                    max={max}
                    value={value}
                    onChange={onChange}
                    disabled={isOverallDisabled}
                    style={{ flex: 1 }}
                    showInput
                    precision={0}
                    inputWidth="50px"
                />

                <span style={maxCountStyle}>/ {max}</span>

                <div style={{ display: 'flex', gap: '4px' }}>
                    <button
                        onClick={handleLeftArrowClick}
                        disabled={isLeftDisabled}
                        style={
                            isLeftDisabled
                                ? disabledArrowButtonStyle
                                : arrowButtonStyle
                        }
                    >
                        <ChevronLeft size={14} strokeWidth={2} />
                    </button>
                    <button
                        onClick={handleRightArrowClick}
                        disabled={isRightDisabled}
                        style={
                            isRightDisabled
                                ? disabledArrowButtonStyle
                                : arrowButtonStyle
                        }
                    >
                        <ChevronRight size={14} strokeWidth={2} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TimelineSlider;