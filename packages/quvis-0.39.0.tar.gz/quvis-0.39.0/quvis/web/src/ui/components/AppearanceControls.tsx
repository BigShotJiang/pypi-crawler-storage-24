import React, { useState, useEffect } from "react";
import type { Playground } from "../../scene/Playground.js";
import { colors } from "../theme/colors.js";
import { typography } from "../theme/typography.js";
import { Check } from "lucide-react";
import Slider from "./Slider.js";
import LayoutControls from "./LayoutControls.js";

interface AppearanceControlsProps {
    playground: Playground | null;
    initialValues: {
        qubitSize: number;
        connectionThickness: number;
        inactiveAlpha: number;
        renderBlochSpheres: boolean;
        renderConnectionLines: boolean;
    };
    onRenderBlochSpheresChange: (checked: boolean) => void;
    onRenderConnectionLinesChange: (checked: boolean) => void;
    showLayoutTab?: boolean;
    layoutInitialValues?: {
        repelForce: number;
        idealDistance: number;
        iterations: number;
        attractForce?: number;
        coreDistance?: number;
        is3D?: boolean;
        distanceMaxMultiplier?: number;
    };
    setIsLoading?: (loading: boolean) => void;
}

const panelStyle: React.CSSProperties = {
    backgroundColor: colors.background.panel,
    padding: "0",
    borderRadius: "8px",
    color: colors.text.primary,
    fontFamily: typography.fontFamily.ui,
    zIndex: 10,
    width: "250px",
    boxShadow: `0 2px 10px ${colors.shadow.light}`,
    overflow: "hidden", // Ensure border radius clips tabs
};

const tabHeaderStyle: React.CSSProperties = {
    display: "flex",
    borderBottom: `1px solid ${colors.border.separator}`,
    backgroundColor: colors.background.panelAlt,
};

const tabStyle = (active: boolean): React.CSSProperties => ({
    flex: 1,
    padding: "12px 5px",
    textAlign: "center",
    cursor: "pointer",
    fontSize: "12px",
    fontWeight: 600,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    color: active ? colors.text.primary : colors.text.muted,
    backgroundColor: active ? "transparent" : "transparent",
    borderBottom: active ? `2px solid ${colors.primary.main}` : "2px solid transparent",
    transition: "all 0.2s ease",
});

const contentPaddingStyle: React.CSSProperties = {
    padding: "15px",
};

const headerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    borderBottom: `1px solid ${colors.border.separator}`,
    paddingBottom: "10px",
    marginBottom: "10px",
};

const headerTitleStyle: React.CSSProperties = {
    marginTop: "0",
    marginBottom: "0",
    fontSize: "14px",
    fontWeight: 600,
    color: colors.text.primary,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
};

const controlGroupStyle: React.CSSProperties = {
    marginBottom: "15px",
};

const labelStyle: React.CSSProperties = {
    display: "block",
    marginBottom: "8px", // Matches FidelityControls
    fontSize: "0.9em",
    fontWeight: 500,
};

const valueStyle: React.CSSProperties = {
    marginLeft: "10px",
    fontSize: "0.9em",
};

// Custom Checkbox Styles
const customCheckboxWrapperStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "15px",
    cursor: "pointer",
    userSelect: "none",
};

const hiddenInputStyle: React.CSSProperties = {
    position: "absolute",
    opacity: 0,
    cursor: "pointer",
    height: 0,
    width: 0,
};

const getCustomCheckboxBoxStyle = (checked: boolean): React.CSSProperties => ({
    width: "18px",
    height: "18px",
    borderRadius: "4px",
    border: `1px solid ${checked ? colors.primary.main : colors.border.light}`,
    backgroundColor: checked ? colors.primary.main : colors.background.panelSolid,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.2s ease",
});

const toggleLabelStyle: React.CSSProperties = {
    fontSize: "0.9em",
};

const sliderContainerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
};

const AppearanceControls: React.FC<AppearanceControlsProps> = ({
    playground,
    initialValues,
    onRenderBlochSpheresChange,
    onRenderConnectionLinesChange,
    showLayoutTab = false,
    layoutInitialValues,
    setIsLoading,
}) => {
    const [activeTab, setActiveTab] = useState<'appearance' | 'layout'>('appearance');
    const [qubitSize, setQubitSize] = useState(initialValues.qubitSize);
    const [connectionThickness, setConnectionThickness] = useState(
        initialValues.connectionThickness,
    );
    const [inactiveAlpha, setInactiveAlpha] = useState(
        initialValues.inactiveAlpha,
    );
    const [renderBlochSpheres, setRenderBlochSpheres] = useState(
        initialValues.renderBlochSpheres,
    );
    const [renderConnectionLines, setRenderConnectionLines] = useState(
        initialValues.renderConnectionLines,
    );

    useEffect(() => {
        setQubitSize(initialValues.qubitSize);
        setConnectionThickness(initialValues.connectionThickness);
        setInactiveAlpha(initialValues.inactiveAlpha);
        setRenderBlochSpheres(initialValues.renderBlochSpheres);
        setRenderConnectionLines(initialValues.renderConnectionLines);
    }, [initialValues]);

    const handleQubitSizeChange = (numValue: number) => {
        setQubitSize(numValue);
        if (playground) {
            playground.updateAppearanceParameters({ qubitSize: numValue });
        }
    };

    const handleConnectionThicknessChange = (numValue: number) => {
        setConnectionThickness(numValue);
        if (playground) {
            playground.updateAppearanceParameters({
                connectionThickness: numValue,
            });
        }
    };

    const handleInactiveAlphaChange = (numValue: number) => {
        setInactiveAlpha(numValue);
        if (playground) {
            playground.updateAppearanceParameters({ inactiveAlpha: numValue });
        }
    };

    const handleRenderBlochSpheresChange = (
        event: React.ChangeEvent<HTMLInputElement>,
    ) => {
        const checked = event.target.checked;
        setRenderBlochSpheres(checked);
        onRenderBlochSpheresChange(checked);
    };

    const handleRenderConnectionLinesChange = (
        event: React.ChangeEvent<HTMLInputElement>,
    ) => {
        const checked = event.target.checked;
        setRenderConnectionLines(checked);
        onRenderConnectionLinesChange(checked);
    };

    if (!playground) {
        return null;
    }

    const renderAppearanceContent = () => (
        <>
            {!showLayoutTab && (
                <div style={headerStyle}>
                    <h4 style={headerTitleStyle}>Appearance</h4>
                </div>
            )}

            <label style={customCheckboxWrapperStyle}>
                <span style={toggleLabelStyle}>Render Bloch Spheres</span>
                <input
                    type="checkbox"
                    style={hiddenInputStyle}
                    checked={renderBlochSpheres}
                    onChange={handleRenderBlochSpheresChange}
                />
                <div style={getCustomCheckboxBoxStyle(renderBlochSpheres)}>
                    {renderBlochSpheres && (
                        <Check size={14} color={colors.background.panel} strokeWidth={3} />
                    )}
                </div>
            </label>

            <div style={{ opacity: renderBlochSpheres ? 1 : 0.4, pointerEvents: renderBlochSpheres ? 'auto' : 'none', transition: 'opacity 0.2s ease' }}>
                <div style={controlGroupStyle}>
                    <label style={labelStyle}>Bloch Sphere Size</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            min={0.2}
                            max={2.0}
                            step={0.05}
                            value={qubitSize}
                            onChange={handleQubitSizeChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={2}
                            disabled={!renderBlochSpheres}
                        />
                    </div>
                </div>
            </div>

            <label style={customCheckboxWrapperStyle}>
                <span style={toggleLabelStyle}>Render Connection Lines</span>
                <input
                    type="checkbox"
                    style={hiddenInputStyle}
                    checked={renderConnectionLines}
                    onChange={handleRenderConnectionLinesChange}
                />
                <div style={getCustomCheckboxBoxStyle(renderConnectionLines)}>
                    {renderConnectionLines && (
                        <Check size={14} color={colors.background.panel} strokeWidth={3} />
                    )}
                </div>
            </label>

            <div style={{ opacity: renderConnectionLines ? 1 : 0.4, pointerEvents: renderConnectionLines ? 'auto' : 'none', transition: 'opacity 0.2s ease' }}>
                <div style={controlGroupStyle}>
                    <label style={labelStyle}>Connection Thickness</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            min={0.01}
                            max={0.25}
                            step={0.005}
                            value={connectionThickness}
                            onChange={handleConnectionThicknessChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={3}
                            disabled={!renderConnectionLines}
                        />
                    </div>
                </div>
            </div>

            <div style={controlGroupStyle}>
                <label style={labelStyle}>Inactive Connections Alpha</label>
                <div style={sliderContainerStyle}>
                    <Slider
                        min={0.0}
                        max={1.0}
                        step={0.01}
                        value={inactiveAlpha}
                        onChange={handleInactiveAlphaChange}
                        style={{ flex: 1 }}
                        showInput
                        precision={2}
                    />
                </div>
            </div>
        </>
    );

    return (
        <div style={panelStyle}>
            {showLayoutTab && (
                <div style={tabHeaderStyle}>
                    <div
                        style={tabStyle(activeTab === 'appearance')}
                        onClick={() => setActiveTab('appearance')}
                    >
                        Appearance
                    </div>
                    <div
                        style={tabStyle(activeTab === 'layout')}
                        onClick={() => setActiveTab('layout')}
                    >
                        Layout
                    </div>
                </div>
            )}

            <div style={contentPaddingStyle}>
                {activeTab === 'appearance' ? (
                    renderAppearanceContent()
                ) : (
                    layoutInitialValues && setIsLoading && (
                        <LayoutControls
                            playground={playground}
                            initialValues={layoutInitialValues}
                            setIsLoading={setIsLoading}
                            isEmbedded={true}
                        />
                    )
                )}
            </div>
        </div>
    );
};

export default AppearanceControls;