from pathlib import Path
from setuptools import setup, find_packages

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="aromatools",
    version="0.2.7",
    packages=find_packages(),
    description="Python tools for aromaticity analysis using geometric and magnetic criteria",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Fernando Martinez-Villarino",
    author_email="fernandomv5897@gmail.com",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "numpy",
        "networkx",
        "matplotlib",
        "art",
        "ase",
        "pandas",
        "plotly",
        "pymatgen"
    ],
    entry_points={
        "console_scripts": [
            "aromagnetic=aromatools.aromagnetic.aromagnetic:main",
            "work_amg=aromatools.aromagnetic.aromagnetic:main",
            "analyze_amg=aromatools.aromagnetic.aromagnetic:main",
            "mo_amg=aromatools.aromagnetic.aromagnetic:main",
            "reset_amg=aromatools.aromagnetic.aromagnetic:main",
            "check_outs=aromatools.aromagnetic.aromagnetic:main",
            "add_amg=aromatools.aromagnetic.aromagnetic:main",
            "sub_amg=aromatools.aromagnetic.aromagnetic:main",
            "arogeometric=aromatools.arogeometric.arogeometric:main",
        ]
    }
)

