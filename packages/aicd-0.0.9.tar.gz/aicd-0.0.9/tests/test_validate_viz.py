"""validate_viz / script_syntax (Python + graph)."""

from __future__ import annotations

from aicd.kit import script_syntax, validate_viz


def test_graph_json_valid() -> None:
    r = validate_viz.validate_graph_json(
        [{"id": "a", "label": "A"}, {"id": "b"}],
        [{"from": "a", "to": "b"}],
    )
    assert r["ok"]
    assert "normalized" in r
    assert r["normalized"]["edges"][0]["from"] == "a"


def test_graph_json_bad_edge() -> None:
    r = validate_viz.validate_graph_json([{"id": "x"}], [{"from": "x", "to": "missing"}])
    assert not r["ok"]


def test_chartjs_ok() -> None:
    cfg = {
        "type": "bar",
        "data": {
            "labels": ["a", "b"],
            "datasets": [{"label": "s", "data": [1, 2]}],
        },
    }
    r = validate_viz.validate_chartjs_config(cfg)
    assert r["ok"]


def test_mermaid_issues_backticks() -> None:
    r = validate_viz.validate_mermaid_body("```mermaid\nx\n```")
    assert not r["ok"]


def test_python_syntax() -> None:
    assert script_syntax.check_python("def f():\n    pass")["ok"]
    bad = script_syntax.check_python("def f(\n")
    assert not bad["ok"]
    assert bad.get("lineno")


def test_bat_heuristic() -> None:
    r = script_syntax.check_bat_heuristic("@echo off\n(echo a")
    assert r["ok"] and r.get("heuristic_only")
    assert any("parentheses" in w.lower() for w in r.get("warnings", []))
