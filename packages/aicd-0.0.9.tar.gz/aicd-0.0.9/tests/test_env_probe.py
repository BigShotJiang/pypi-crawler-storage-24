"""runtime_env.yaml 生成与刷新。"""

from __future__ import annotations

from pathlib import Path

import yaml

from aicd.env_probe import (
    CAPABILITIES_SUMMARY_FILENAME,
    RUNTIME_ENV_FILENAME,
    collect_runtime_env,
    format_env_capabilities_for_prompt,
    refresh_runtime_env_file,
    runtime_env_path,
    summarize_commands,
)


def test_collect_runtime_env_shape() -> None:
    data = collect_runtime_env()
    assert "generated_at" in data
    assert "os" in data and "system" in data["os"]
    assert "terminal" in data
    assert "python" in data
    assert "commands" in data
    assert "python_modules_optional" in data
    assert isinstance(data["commands"], dict)


def test_refresh_writes_yaml(tmp_path: Path) -> None:
    layout = {
        "data": tmp_path / "data",
        "root": tmp_path,
    }
    layout["data"].mkdir(parents=True)
    path, data = refresh_runtime_env_file(layout)
    assert path == tmp_path / "data" / RUNTIME_ENV_FILENAME
    assert path.is_file()
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert raw["aicd_version"] == data["aicd_version"]
    avail, total = summarize_commands(data)
    assert total == len(data["commands"])
    assert 0 <= avail <= total
    cap = tmp_path / "data" / CAPABILITIES_SUMMARY_FILENAME
    assert cap.is_file()
    assert "Host capability snapshot" in cap.read_text(encoding="utf-8")


def test_format_env_capabilities_lists_missing(tmp_path: Path) -> None:
    data = collect_runtime_env()
    text = format_env_capabilities_for_prompt(data, yaml_path="/tmp/x.yaml")
    assert "Host capability snapshot" in text
    assert "runtime_env_refresh" in text.lower() or "skip" in text.lower()


def test_runtime_env_path_helper(tmp_path: Path) -> None:
    layout = {"data": tmp_path / "d"}
    assert runtime_env_path(layout) == tmp_path / "d" / RUNTIME_ENV_FILENAME
