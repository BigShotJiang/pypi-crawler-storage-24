from __future__ import annotations

from typing import Any

from aicd.env_probe import (
    capabilities_summary_path,
    refresh_runtime_env_file,
    summarize_commands,
)


def _runtime_env_refresh(router: Any, args: dict[str, Any]) -> dict[str, Any]:
    del args  # 无参数；保留以兼容 OpenAI tools schema
    path, data = refresh_runtime_env_file(router._layout)
    router.notify_env_capabilities_updated(data, path)
    avail, total = summarize_commands(data)
    return {
        "ok": True,
        "path": str(path),
        "capabilities_summary_path": str(capabilities_summary_path(router._layout)),
        "generated_at": data.get("generated_at"),
        "commands_available": avail,
        "commands_total": total,
        "hint": "Use fs_read_file on path for full YAML; capabilities_summary_path mirrors the model-facing "
        "snapshot; call again after user installs tools.",
    }


HANDLERS: dict[str, Any] = {
    "runtime_env_refresh": _runtime_env_refresh,
}
