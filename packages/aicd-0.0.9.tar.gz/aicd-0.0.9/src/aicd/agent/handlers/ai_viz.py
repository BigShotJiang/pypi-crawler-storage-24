from __future__ import annotations

from typing import TYPE_CHECKING, Any

import aicd.tools.viz_assets as viz_assets
from aicd.kit import chart_spec

if TYPE_CHECKING:
    from aicd.agent.tool_router import ToolRouter


def _ai_output_info(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": True,
        "workspace": str(router._cwd),
        "ai_output_dir": str(router._ai_output),
        "ai_tmp_dir": str(router._ai_tmp),
        "note": "Write scratch/intermediate analysis under ai_tmp_dir; clean up when done. "
        "Durable artifacts go under ai_output_dir (not inside tmp unless explicitly temporary).",
    }


def _ai_ensure_layout(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    router._ai_output.mkdir(parents=True, exist_ok=True)
    router._ai_tmp.mkdir(parents=True, exist_ok=True)
    return {
        "ok": True,
        "ai_output_dir": str(router._ai_output),
        "ai_tmp_dir": str(router._ai_tmp),
        "created": True,
    }


def _ai_workspace_set(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    fn = router._ai_workspace_setter
    if fn is None:
        return {
            "ok": False,
            "error": "ai_workspace_set is only available in the main chat session; use TUI /work <path>.",
        }
    raw = args.get("path")
    if raw is None or (isinstance(raw, str) and not str(raw).strip()):
        ok, msg = fn(None)
    else:
        ok, msg = fn(str(raw).strip())
    if not ok:
        return {"ok": False, "error": msg}
    return {
        "ok": True,
        "workspace": msg,
        "note": "fs_* relative paths and default run_command cwd use this directory.",
    }


def _viz_list_bundled_assets(
    router: ToolRouter, args: dict[str, Any]
) -> dict[str, Any]:
    return {
        "ok": True,
        "bundled_dir": str(viz_assets.bundled_res_dir()),
        "files": viz_assets.list_bundled_viz_files(),
    }


def _viz_copy_resources(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    dest = router._resolve_path(args["target_directory"])
    if not dest.is_dir():
        return {"ok": False, "error": "target_directory must be an existing directory"}
    return viz_assets.copy_viz_resources(dest)


def _viz_export_html(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    out = router._resolve_path(args["html_path"])
    out.parent.mkdir(parents=True, exist_ok=True)
    title = str(args.get("title") or "Analysis")
    raw_body = args.get("body_html")
    body = (raw_body if raw_body is not None else "").strip()
    if not body:
        body = viz_assets.demo_body_snippet()
        boot = True
    else:
        body = str(raw_body)
        boot = bool(args.get("include_demo_chart_vis_bootstrap", False))
    html = viz_assets.build_viz_html_document(
        title,
        body,
        extra_head=str(args.get("extra_head") or ""),
        extra_scripts=str(args.get("extra_scripts") or ""),
        include_default_chart_vis_init=boot,
    )
    html = viz_assets.reorder_body_scripts_before_vis_usage(html)
    out.write_text(html, encoding="utf-8")
    copied: dict[str, Any] = {"skipped": True}
    if bool(args.get("copy_resources", True)):
        copied = viz_assets.copy_viz_resources(out.parent)
    return {
        "ok": True,
        "html_path": str(out),
        "copy_resources": copied,
    }


def _viz_data_chart(router: ToolRouter, args: dict[str, Any]) -> dict[str, Any]:
    out = router._resolve_path(args["html_path"])
    out.parent.mkdir(parents=True, exist_ok=True)
    title = str(args.get("title") or "Chart")
    chart_type = str(args.get("chart_type") or "bar")
    labels = list(args.get("labels") or [])
    values = list(args.get("values") or [])
    dataset_label = str(args.get("dataset_label") or "")
    html = chart_spec.build_html_with_chart(
        title,
        chart_type,
        labels,
        values,
        dataset_label=dataset_label or "Series",
    )
    out.write_text(html, encoding="utf-8")
    copied: dict[str, Any] = {"skipped": True}
    if bool(args.get("copy_resources", True)):
        copied = viz_assets.copy_viz_resources(out.parent)
    return {
        "ok": True,
        "html_path": str(out),
        "copy_resources": copied,
        "ascii_preview": chart_spec.mermaid_bar_from_counts(
            [str(x) for x in labels],
            [int(round(float(v))) for v in values],
        )
        if len(labels) == len(values)
        else "",
    }


HANDLERS: dict[str, Any] = {
    "ai_output_info": _ai_output_info,
    "ai_ensure_layout": _ai_ensure_layout,
    "ai_workspace_set": _ai_workspace_set,
    "viz_list_bundled_assets": _viz_list_bundled_assets,
    "viz_copy_resources": _viz_copy_resources,
    "viz_export_html": _viz_export_html,
    "viz_data_chart": _viz_data_chart,
}
