"""主对话与子 Agent 的「无用户输入」定时唤醒文案（TUI 心跳 / 子任务协调）。"""

from __future__ import annotations

# 与 TUI 侧识别一致：勿改前缀，否则 _chat_pump_loop 无法标记系统行
MAIN_IDLE_PULSE_PREFIX = "（Aicd·主对话·定时心跳）"


def is_main_idle_pulse(user_text: str) -> bool:
    return user_text.lstrip().startswith(MAIN_IDLE_PULSE_PREFIX)


def main_idle_pulse_user_text() -> str:
    return (
        MAIN_IDLE_PULSE_PREFIX
        + " 当前无新的真人输入。请用 **task_list**、**task_result**、必要时 **task_thread_stats** "
        "检查 **running** / **failed** / **pending** 的后台任务；关注 **parent_id** 与 **timeline** / **sub_agent_trace**。"
        "若有失败、长期停滞或需要用户决策，用中文在聊天区**简短**说明并视情况 **task_cancel** 或 **task_message_send**（对仍运行的子任务 **to_task_id** 发 **directive** / **status** / **question**）。"
        "若一切正常、无需打扰用户，可只回复一个字：**·**（中间点）。"
    )


def sub_agent_idle_pulse_user_text() -> str:
    return (
        "（Aicd·子 Agent·定时心跳）收件箱暂无新 **task_message**，但你仍有 **running** 或 **pending** 的子任务（**task_list** 里 **parent_id** 等于你当前 **task_id** 的行）。"
        "请用 **task_result** 查看子任务；需要上级同步时，先 **task_result**（**task_id**=你自己）读 **parent_id**：若非空则 **task_message_send** 的 **to_task_id**=该 **parent_id**，**kind** 用 **status** / **question** / **alert**；"
        "若为顶层子任务（**parent_id** 为空），主对话会通过定时心跳与用户输入查看 **task_list**，你应继续用 **task_progress** 保持可见。"
        "失败子任务可考虑 **task_cancel** 或拆成更小的 **task_ai**。无事可回复 **·**。"
    )
