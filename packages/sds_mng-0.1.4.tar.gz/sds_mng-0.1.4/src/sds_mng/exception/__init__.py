class UnauthorizedError(Exception):
    pass
