import requests
import time
from sds_mng.util import logger

def get_token(username, password):
    COMPANY_NO = "印美达"
    EXTRA_INFO = "eyJpcCI6IjM4LjcxLjEyNy4xODkiLCJsb2NhdGlvbiI6eyJsYXQiOjM4Ljg4MzMsImxuZyI6LTc3fSwiYWRfaW5mbyI6eyJuYXRpb24iOiLnvo7lm70iLCJwcm92aW5jZSI6IiIsImNpdHkiOiIiLCJkaXN0cmljdCI6IiIsImFkY29kZSI6LTEsIm5hdGlvbl9jb2RlIjo4NDB9LCJmaW5nZXJwcmludElkIjoiN2M3YzllMDUxYWU2NDkzOTEzMGY5OWI0NjhiY2FhYTUiLCJ1c2VyQWdlbnQiOiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTM4LjAuMC4wIFNhZmFyaS81MzcuMzYiLCJocmVmIjoiaHR0cHM6Ly9tYW5hZ2Uuc2RzcG9kLmNvbS91c2VyL2xvZ2luIn0="
    timestamp = int(time.time() * 1000)
    url = f"https://pod-api.sdspod.com/pod/auth/login?t={timestamp}"

    headers = {
        "content-type": "application/json;charset=UTF-8",
    }

    payload = {
        "no": COMPANY_NO,
        "password": password,
        "username": username,
        "extraInfo": EXTRA_INFO,
    }

    logger.debug(f"请求URL: {url}")
    logger.debug(f"请求 payload: {payload}")

    resp = requests.post(url=url, headers=headers, json=payload)
    logger.debug(f"响应状态码: {resp.status_code}")
    resp.raise_for_status()
    data = resp.json()
    logger.debug(f"响应数据: {data}")

    token = data.get("data", {}).get("accessToken")
    logger.info(f"获取token成功")
    return token