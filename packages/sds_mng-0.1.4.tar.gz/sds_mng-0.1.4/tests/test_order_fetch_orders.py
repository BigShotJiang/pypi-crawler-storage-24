import os

from sds_mng.order.fetch_orders import _fetch


def test_fetch_orders():
    token = os.environ.get("SDS_MNG_TOKEN")
    orders = _fetch(token, {"merchantIds": [53292]})
    assert (
        orders.get("list", [])[-1].get("merchant", {}).get("name") == "印美达测试账号1"
    )
