import os

from sds_mng.order.fetch_orders import _fetch
from sds_mng.auth.get_token import get_token


def test_fetch_orders():
    username = os.environ.get("SDS_MNG_USERNAME")
    password = os.environ.get("SDS_MNG_PASSWORD")
    token = get_token(username, password)
    os.environ['SDS_MNG_TOKEN'] = token
    orders = _fetch(token, {"merchantIds": [53292]})
    assert (
        orders.get("list", [])[-1].get("merchant", {}).get("name") == "印美达测试账号1"
    )
