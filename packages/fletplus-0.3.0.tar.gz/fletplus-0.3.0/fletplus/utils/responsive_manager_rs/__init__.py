"""Backend opcional en Rust para aplicar estilos responsivos."""
from __future__ import annotations

import importlib
import importlib.util
from typing import Any, Iterable, List, Mapping, Sequence, Tuple

ApplyStyleResult = List[Tuple[Any, str, Any]]

_spec = importlib.util.find_spec("fletplus.utils.responsive_manager_rs._native")
if _spec is None:
    _native = None
else:
    try:
        _native = importlib.import_module("fletplus.utils.responsive_manager_rs._native")
    except (ImportError, OSError, RuntimeError):
        _native = None
    except Exception:
        _native = None


def _py_apply_styles(
    styles: Iterable[tuple[Any, Any]],
    attrs: Sequence[str],
    base_attrs_map: Mapping[Any, Mapping[str, Any]] | None = None,
) -> ApplyStyleResult:
    updates: ApplyStyleResult = []
    for control, rstyle in styles:
        base = getattr(control, "__fletplus_base_attrs__", None)
        if base is None and base_attrs_map is not None:
            base = base_attrs_map.get(control)
        if isinstance(base, dict):
            for attr in attrs:
                if attr in base:
                    updates.append((control, attr, base[attr]))

        page = getattr(rstyle, "_fletplus_page", None) or getattr(control, "page", None)
        if page is None:
            continue

        style = rstyle.get_style(page)
        if not style:
            continue

        styled_container = style.apply(control)
        for attr in attrs:
            if hasattr(control, attr):
                value = getattr(styled_container, attr, None)
                # Si el estilo declara el campo, se aplica aunque sea None.
                if style.declares_container_attr(attr) or value is not None:
                    updates.append((control, attr, value))
    return updates


def apply_styles(
    styles: Iterable[tuple[Any, Any]],
    attrs: Sequence[str],
    base_attrs_map: Mapping[Any, Mapping[str, Any]] | None = None,
) -> ApplyStyleResult:
    if _native is not None and base_attrs_map is None:
        return _native.apply_styles(styles, attrs)
    return _py_apply_styles(styles, attrs, base_attrs_map=base_attrs_map)

__all__ = ["apply_styles"]
