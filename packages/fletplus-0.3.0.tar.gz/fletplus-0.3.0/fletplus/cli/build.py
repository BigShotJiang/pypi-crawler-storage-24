"""Infraestructura de compilación para el comando ``fletplus build``."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterable, List

import click

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - compatibilidad
    import tomli as tomllib  # type: ignore


class PackagingError(RuntimeError):
    """Error de alto nivel al empaquetar la aplicación."""


DEFAULT_BUILD_TIMEOUT_SECONDS = 900.0

# Variables base permitidas para cualquier comando de build.
BUILD_ENV_BASE_WHITELIST = (
    "PATH",
    "SystemRoot",
    "WINDIR",
    "COMSPEC",
    "PATHEXT",
    "TEMP",
    "TMP",
    "HOME",
    "USERPROFILE",
)

# Perfiles mínimos por tipo de comando para evitar sobreexposición del entorno.
BUILD_ENV_PROFILES: dict[str, tuple[str, ...]] = {
    "flet_build": (
        *BUILD_ENV_BASE_WHITELIST,
        "VIRTUAL_ENV",
        "PYTHONPATH",
        "PYTHONHOME",
        "PYTHONUTF8",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
        "LD_LIBRARY_PATH",
        "DYLD_LIBRARY_PATH",
    ),
    "pyinstaller": (
        *BUILD_ENV_BASE_WHITELIST,
        "VIRTUAL_ENV",
        "PYTHONPATH",
        "PYTHONHOME",
        "PYTHONUTF8",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
        "LD_LIBRARY_PATH",
        "DYLD_LIBRARY_PATH",
    ),
    "briefcase": (
        *BUILD_ENV_BASE_WHITELIST,
        "APPDATA",
        "LOCALAPPDATA",
        "VIRTUAL_ENV",
        "PYTHONPATH",
        "PYTHONHOME",
        "PYTHONUTF8",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
        "LD_LIBRARY_PATH",
        "DYLD_LIBRARY_PATH",
        "FLETPLUS_METADATA",
        "FLETPLUS_ICON",
    ),
}


class BuildTarget(str, Enum):
    """Objetivos soportados por el comando de compilación."""

    WEB = "web"
    DESKTOP = "desktop"
    MOBILE = "mobile"

    @classmethod
    def parse_option(cls, value: str) -> List["BuildTarget"]:
        if value == "all":
            return list(cls)
        try:
            return [cls(value)]
        except ValueError as exc:  # pragma: no cover - validado por Click
            raise PackagingError(str(exc)) from exc


@dataclass(slots=True)
class BuildMetadata:
    """Metadatos del proyecto normalizados para compilación.

    El nombre se normaliza en `_load_metadata` para usar solo letras, números,
    guiones y guiones bajos; los separadores de ruta (`/`, `\\`) y espacios se
    reemplazan por guiones, y el resto de caracteres inseguros se elimina.
    """

    name: str
    version: str
    author: str | None = None
    description: str | None = None

    def to_dict(self) -> dict[str, str]:
        data = {"name": self.name, "version": self.version}
        if self.author:
            data["author"] = self.author
        if self.description:
            data["description"] = self.description
        return data


@dataclass(slots=True)
class BuildContext:
    """Información común compartida por los adaptadores."""

    project_dir: Path
    app_path: Path
    dist_dir: Path
    build_dir: Path
    metadata: BuildMetadata
    assets_dir: Path | None
    icon_path: Path | None
    build_timeout: float

    @classmethod
    def from_project(
        cls, project_dir: Path, app_path: Path, build_timeout: float = DEFAULT_BUILD_TIMEOUT_SECONDS
    ) -> "BuildContext":
        project_dir = project_dir.resolve()
        if not project_dir.exists():
            raise PackagingError(f"No se encontró el proyecto en {project_dir}.")

        app_path = app_path if app_path.is_absolute() else project_dir / app_path
        if not app_path.exists():
            raise PackagingError(f"No se encontró la aplicación principal: {app_path}.")
        if not app_path.is_file():
            raise PackagingError(
                "La ruta de la aplicación principal debe ser un archivo: "
                f"{app_path}."
            )

        dist_dir = project_dir / "dist"
        dist_dir.mkdir(parents=True, exist_ok=True)
        build_dir = project_dir / "build"
        build_dir.mkdir(parents=True, exist_ok=True)

        metadata = _load_metadata(project_dir)
        assets_dir = _detect_assets(project_dir)
        icon_path = _detect_icon(project_dir, assets_dir)

        return cls(
            project_dir=project_dir,
            app_path=app_path,
            dist_dir=dist_dir,
            build_dir=build_dir,
            metadata=metadata,
            assets_dir=assets_dir,
            icon_path=icon_path,
            build_timeout=build_timeout,
        )


def _load_metadata(project_dir: Path) -> BuildMetadata:
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists():
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        project_data = data.get("project", {}) if isinstance(data, dict) else {}
    else:
        project_data = {}

    raw_name = project_data.get("name") or project_dir.name
    name = _normalize_build_name(raw_name)
    version = project_data.get("version", "0.0.0")
    author = None
    authors = project_data.get("authors")
    if isinstance(authors, list) and authors:
        first = authors[0]
        if isinstance(first, dict):
            author = first.get("name")
        elif isinstance(first, str):
            author = first
    description = project_data.get("description")

    return BuildMetadata(name=name, version=version, author=author, description=description)


def _normalize_build_name(value: str) -> str:
    normalized = re.sub(r"[\\/\s]+", "-", value)
    normalized = re.sub(r"[^A-Za-z0-9_-]", "", normalized)
    normalized = normalized.strip("-_")
    return normalized or "app"


def _detect_assets(project_dir: Path) -> Path | None:
    candidates = [project_dir / "assets", project_dir / "static"]
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    return None


def _detect_icon(project_dir: Path, assets_dir: Path | None) -> Path | None:
    candidates = []
    if assets_dir:
        candidates.append(assets_dir / "icon.png")
        candidates.append(assets_dir / "icons" / "app.png")
    candidates.extend([project_dir / "icon.png", project_dir / "app.png"])
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _copy_assets(source: Path | None, destination: Path) -> None:
    if not source or not source.exists():
        return
    target = destination / source.name
    if target.exists():
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
    for root, dirs, files in os.walk(source, followlinks=False):
        root_path = Path(root)
        relative_root = root_path.relative_to(source)
        target_root = target / relative_root
        target_root.mkdir(parents=True, exist_ok=True)

        for dirname in list(dirs):
            source_dir = root_path / dirname
            if source_dir.is_symlink():
                click.echo(f"Advertencia: se omitió el enlace simbólico {source_dir}.")
                dirs.remove(dirname)

        for filename in files:
            source_file = root_path / filename
            if source_file.is_symlink():
                click.echo(f"Advertencia: se omitió el enlace simbólico {source_file}.")
                continue
            shutil.copy2(source_file, target_root / filename)


def _copy_icon(icon_path: Path | None, destination: Path) -> Path | None:
    if not icon_path or not icon_path.exists():
        return None
    destination.mkdir(parents=True, exist_ok=True)
    target_icon = destination / icon_path.name
    shutil.copy2(icon_path, target_icon)
    return target_icon


def _write_metadata(metadata: BuildMetadata, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    metadata_path = destination / "metadata.json"
    metadata_path.write_text(json.dumps(metadata.to_dict(), indent=2), encoding="utf-8")
    return metadata_path


def _run_command(
    command: List[str],
    *,
    cwd: Path | None = None,
    timeout: float | None = None,
    env_overrides: dict[str, str] | None = None,
    env_profile: str,
) -> None:
    click.echo(f"Ejecutando: {' '.join(command)}")
    whitelist = BUILD_ENV_PROFILES.get(env_profile)
    if whitelist is None:
        raise PackagingError(f"Perfil de entorno no soportado: {env_profile}.")

    env = os.environ.copy()
    if env_overrides:
        env.update(env_overrides)

    try:
        from fletplus.utils.safe_subprocess import safe_run

        safe_run(
            command,
            cwd=str(cwd) if cwd else None,
            check=True,
            timeout=timeout,
            env=env,
            env_whitelist=whitelist,
        )
    except FileNotFoundError as exc:  # pragma: no cover - depende del entorno
        missing_tool = command[0]
        raise PackagingError(
            f"No se encontró la herramienta requerida: {missing_tool}. "
            "Asegúrate de que esté instalada y disponible en el PATH."
        ) from exc
    except subprocess.TimeoutExpired as exc:
        executed_command = " ".join(str(part) for part in command)
        cwd_label = str(cwd) if cwd else os.getcwd()
        timeout_label = exc.timeout if exc.timeout is not None else timeout
        raise PackagingError(
            "El subproceso de compilación excedió el tiempo límite "
            f"({timeout_label}s, cwd={cwd_label}, comando='{executed_command}')."
        ) from exc
    except subprocess.CalledProcessError as exc:  # pragma: no cover - manejado en adaptador
        executed_command = " ".join(str(part) for part in (exc.cmd or command))
        cwd_label = str(cwd) if cwd else os.getcwd()
        raise PackagingError(
            "El subproceso de compilación falló "
            f"(código={exc.returncode}, cwd={cwd_label}, comando='{executed_command}')."
        ) from exc


class _BaseAdapter:
    target: BuildTarget

    def __init__(self, context: BuildContext) -> None:
        self.context = context
        self.output_dir = context.dist_dir / self.target.value
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.staging_dir = context.build_dir / self.target.value
        self.staging_dir.mkdir(parents=True, exist_ok=True)

    def prepare(self) -> dict[str, Path | None]:
        metadata_path = _write_metadata(self.context.metadata, self.staging_dir)
        _copy_assets(self.context.assets_dir, self.staging_dir)
        icon_target = _copy_icon(self.context.icon_path, self.staging_dir)
        return {"metadata": metadata_path, "icon": icon_target}

    def build(self, prepared: dict[str, Path | None]) -> None:
        raise NotImplementedError

    def run(self) -> Path:
        prepared = self.prepare()
        self.build(prepared)
        return self.output_dir


class WebAdapter(_BaseAdapter):
    target = BuildTarget.WEB

    def build(self, prepared: dict[str, Path | None]) -> None:  # pragma: no cover - invocado por run()
        command = [
            sys.executable,
            "-m",
            "flet",
            "build",
            "web",
            str(self.context.app_path),
            "--output",
            str(self.output_dir),
        ]
        _run_command(
            command,
            cwd=self.context.project_dir,
            timeout=self.context.build_timeout,
            env_profile="flet_build",
        )


class DesktopAdapter(_BaseAdapter):
    target = BuildTarget.DESKTOP

    def build(self, prepared: dict[str, Path | None]) -> None:
        add_data_args: list[str] = []
        assets_dir = self.context.assets_dir
        if assets_dir and assets_dir.exists():
            staging_assets = self.staging_dir / assets_dir.name
            if staging_assets.exists():
                add_data_args.extend(
                    [
                        "--add-data",
                        f"{staging_assets}{os.pathsep}{assets_dir.name}",
                    ]
                )

        icon_arg: list[str] = []
        icon_path = prepared.get("icon")
        if icon_path:
            icon_arg = ["--icon", str(icon_path)]

        command = [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--name",
            self.context.metadata.name,
            "--distpath",
            str(self.output_dir),
            "--workpath",
            str(self.context.build_dir / "pyinstaller"),
            "--specpath",
            str(self.context.build_dir / "pyinstaller"),
            *icon_arg,
            *add_data_args,
            str(self.context.app_path),
        ]
        _run_command(
            command,
            cwd=self.context.project_dir,
            timeout=self.context.build_timeout,
            env_profile="pyinstaller",
        )


class MobileAdapter(_BaseAdapter):
    target = BuildTarget.MOBILE

    def build(self, prepared: dict[str, Path | None]) -> None:
        icon_path = prepared.get("icon")
        metadata_path = prepared.get("metadata")

        env = {}
        if metadata_path:
            env["FLETPLUS_METADATA"] = str(metadata_path)
        if icon_path:
            env["FLETPLUS_ICON"] = str(icon_path)

        command = [
            "briefcase",
            "package",
            "android",
            "--no-input",
            "--output",
            str(self.output_dir),
        ]
        click.echo("Preparando paquete móvil (android)")
        _run_command(
            command,
            cwd=self.context.project_dir,
            timeout=self.context.build_timeout,
            env_overrides=env,
            env_profile="briefcase",
        )


def create_adapter(target: BuildTarget, context: BuildContext) -> _BaseAdapter:
    if target is BuildTarget.WEB:
        return WebAdapter(context)
    if target is BuildTarget.DESKTOP:
        return DesktopAdapter(context)
    if target is BuildTarget.MOBILE:
        return MobileAdapter(context)
    raise PackagingError(f"Objetivo no soportado: {target}")


@dataclass(slots=True)
class BuildReport:
    target: BuildTarget
    success: bool
    message: str
    output_dir: Path | None = None


class BuildManager:
    """Gestiona la ejecución de los adaptadores para cada objetivo."""

    def __init__(self, context: BuildContext) -> None:
        self.context = context

    def build(self, targets: Iterable[BuildTarget]) -> List[BuildReport]:
        reports: List[BuildReport] = []
        for target in targets:
            adapter = create_adapter(target, self.context)
            try:
                output_dir = adapter.run()
                reports.append(
                    BuildReport(
                        target=target,
                        success=True,
                        message=f"Artefactos disponibles en {output_dir}",
                        output_dir=output_dir,
                    )
                )
            except PackagingError as exc:
                reports.append(BuildReport(target=target, success=False, message=str(exc)))
        return reports


def run_build(
    project_dir: Path,
    app_path: Path,
    target: str,
    build_timeout: float = DEFAULT_BUILD_TIMEOUT_SECONDS,
) -> List[BuildReport]:
    context = BuildContext.from_project(project_dir, app_path, build_timeout=build_timeout)
    targets = BuildTarget.parse_option(target)
    manager = BuildManager(context)
    return manager.build(targets)
