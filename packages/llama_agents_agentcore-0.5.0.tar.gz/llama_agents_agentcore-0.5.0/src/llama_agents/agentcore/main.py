from argparse import ArgumentParser

from .entrypoint import app

if __name__ == "__main__":
    parser = ArgumentParser()

    parser.add_argument(
        "--run",
        help="Run the application in the target environment",
        action="store_true",
        default=False,
    )

    args = parser.parse_args()

    if args.run:
        print("Starting app on 0.0.0.0:8080")  # noqa
        app.run(port=8080, host="0.0.0.0")
