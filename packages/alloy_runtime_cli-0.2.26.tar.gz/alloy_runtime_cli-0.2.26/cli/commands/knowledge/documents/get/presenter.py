"""Presenter for knowledge document get command output."""

import json

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_uuid,
)
from cli.infrastructure.output import OutputFormat, OutputService
from alloy_runtime_types.dtos.knowledge import GetDocumentResponse


def _format_status(status: str) -> str:
    """Format processing status with color."""
    status_colors = {
        "completed": "[green]completed[/]",
        "processing": "[yellow]processing[/]",
        "pending": "[blue]pending[/]",
        "failed": "[red]failed[/]",
    }
    return status_colors.get(status, status)


def present_document_details(
    response: GetDocumentResponse, show_content: bool = False
) -> None:
    """Present document details with Rich formatting.

    Args:
        response: GetDocumentResponse from server
        show_content: Whether to show original content panel
    """
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Collection ID", format_uuid(response.collection_id, short=False))
    table.add_row("Title", response.title)
    table.add_row("Source Type", response.source_type)
    table.add_row("Character Count", f"{response.character_count:,}")
    table.add_row(
        "Estimated Tokens",
        f"{response.estimated_tokens:,}" if response.estimated_tokens else "-",
    )
    table.add_row("Processing Status", _format_status(response.processing_status))
    if response.processing_error:
        table.add_row("Processing Error", f"[red]{response.processing_error}[/]")
    table.add_row("Chunks Count", str(response.chunks_count))
    table.add_row("Chunks Failed", str(response.chunks_failed))
    table.add_row("Questions Generated", str(response.questions_generated))
    if response.metadata:
        table.add_row("Metadata", json.dumps(response.metadata, indent=2))
    table.add_row("Created At", format_datetime(response.created_at))
    table.add_row("Updated At", format_datetime(response.updated_at))

    panel = Panel(
        table,
        title=f"Document: {response.title}",
        border_style="green",
    )
    output.console.print(panel)

    if show_content and response.original_content:
        content_panel = Panel(
            response.original_content,
            title="Original Content",
            border_style="blue",
        )
        output.console.print(content_panel)
    elif show_content and not response.original_content:
        output.info("No original content available")
