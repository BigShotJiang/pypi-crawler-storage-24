"""Presenter for synthesis list output."""

import json

from rich.table import Table

from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import ListSynthesesResponse


def present_syntheses_list(response: ListSynthesesResponse, output_format: str) -> None:
    """Present synthesis list results.

    Args:
        response: List syntheses response from server
        output_format: Output format ('table' or 'json')
    """
    output = OutputService.get()

    if output_format == "json":
        # JSON output
        data = {
            "syntheses": [
                {
                    "id": str(s.id),
                    "topic": s.topic,
                    "title": s.title,
                    "status": s.status,
                    "is_stale": s.is_stale,
                    "source_chunk_count": s.source_chunk_count,
                    "collection_ids": [str(c) for c in s.collection_ids],
                    "created_at": s.created_at.isoformat(),
                    "updated_at": s.updated_at.isoformat(),
                }
                for s in response.syntheses
            ],
            "total": response.total,
        }
        output.console.print_json(json.dumps(data))
        return

    # Table output
    if not response.syntheses:
        output.info("No syntheses found")
        return

    table = Table(title=f"Syntheses ({response.total} total)")
    table.add_column("ID", style="dim")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Stale", justify="center")
    table.add_column("Sources", justify="right")
    table.add_column("Created")

    for synthesis in response.syntheses:
        # Status styling
        status = synthesis.status
        if status == "completed":
            status_display = f"[green]{status}[/green]"
        elif status == "failed":
            status_display = f"[red]{status}[/red]"
        elif status == "processing":
            status_display = f"[yellow]{status}[/yellow]"
        else:
            status_display = f"[dim]{status}[/dim]"

        # Stale indicator
        stale_display = (
            "[yellow]⚠[/yellow]" if synthesis.is_stale else "[green]✓[/green]"
        )

        table.add_row(
            format_uuid(synthesis.id, short=True),
            synthesis.title,
            status_display,
            stale_display,
            str(synthesis.source_chunk_count),
            format_datetime(synthesis.created_at),
        )

    output.console.print(table)
