"""Presenter for session get command output."""

from rich.panel import Panel
from rich.table import Table

from alloy_runtime_types.dtos.sessions import SessionDetailResponse

from cli.infrastructure.output import OutputFormat, OutputService


def _truncate(text: str | None, max_len: int = 200) -> str:
    """Truncate text for display."""
    if not text:
        return "-"
    _ = max_len
    return text


def present_session(response: SessionDetailResponse) -> None:
    """Present session details with Rich formatting."""
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    # Create session info table
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", str(response.id))
    table.add_row("Name", response.name or "(unnamed)")
    table.add_row("Message Count", str(response.total_messages))
    table.add_row("Created", response.created_at.strftime("%Y-%m-%d %H:%M:%S"))

    output.console.print(
        Panel(table, title=f"Session: {response.name or str(response.id)}")
    )

    # Show recent messages if available
    if response.messages:
        output.info(f"\nRecent Messages ({len(response.messages)}):")
        for msg in response.messages:
            role_style = {
                "user": "green",
                "assistant": "blue",
                "system": "yellow",
                "tool": "magenta",
            }.get(msg.role, "white")

            # Get content preview
            content_preview = "-"
            if msg.content_parts:
                first_part = msg.content_parts[0]
                if first_part.content_text:
                    content_preview = _truncate(first_part.content_text, 100)

            output.console.print(
                f"  [{role_style}]{msg.role}[/{role_style}] "
                f"({msg.sequence_number}): {content_preview}"
            )
