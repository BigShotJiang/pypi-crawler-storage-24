"""Models list command implementation."""

from enum import Enum
from typing import Optional

import typer

from cli.commands.models.list.presenter import present_models_list
from cli.infrastructure.command import async_command, authenticated_client


class DisplayColumn(str, Enum):
    """Column display options."""

    MODEL = "model"
    PROVIDER = "provider"


def models_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    provider_filter: Optional[str] = typer.Option(
        None,
        "-p",
        "--provider",
        help="Filter by provider",
    ),
    configured_only: bool = typer.Option(
        False,
        "--configured",
        help="Only show models with credentials",
    ),
    limit: int = typer.Option(
        100,
        "--limit",
        min=1,
        max=10000,
        help="Maximum number of models to return",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Number of matching models to skip before returning results",
    ),
    display: DisplayColumn | None = typer.Option(
        None,
        "--display",
        help="Show only: model or provider",
    ),
    extra_fields: bool = typer.Option(
        False,
        "--extra",
        help="Show detailed table",
    ),
) -> None:
    """List available AI models.

    Examples:
        alloy models list
        alloy models list -s "claude sonnet"
        alloy models list -p anthropic
        alloy models list --configured
        alloy models list --display model
        alloy models list --extra
    """
    _execute_list(
        search=search,
        provider_filter=provider_filter,
        configured_only=configured_only,
        limit=limit,
        offset=offset,
        display=display,
        extra_fields=extra_fields,
    )


@async_command
async def _execute_list(
    search: Optional[str],
    provider_filter: Optional[str],
    configured_only: bool,
    limit: int,
    offset: int,
    display: DisplayColumn | None,
    extra_fields: bool,
) -> None:
    """Execute list models operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_models(
            search=search,
            provider_filter=provider_filter,
            configured_only=configured_only,
            limit=limit,
            offset=offset,
        )

    present_models_list(response, display_column=display, extra_fields=extra_fields)
