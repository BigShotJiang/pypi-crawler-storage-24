"""Presenter for template render output."""

import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.editor import EditorError, get_editor
from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.macro_parser import extract_jinja_syntax
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import RenderTemplateResponse

# Import pyperclip at module level for easier mocking in tests
pyperclip: Any | None = None
try:
    import pyperclip as _pyperclip
except ImportError:
    pass
else:
    pyperclip = _pyperclip

PYPERCLIP_AVAILABLE = pyperclip is not None


def present_render_result(
    response: RenderTemplateResponse,
    template_name: str,
    output_mode: str = "console",
    output_file: str | None = None,
    print_escaped: bool = False,
) -> bool:
    """Present the rendered template result.

    Args:
        response: Render response from server
        template_name: Name of the rendered template
        output_mode: Output destination - 'console', 'clipboard', 'file', or 'editor'
        output_file: File path for 'file' output mode
        print_escaped: If True, print Jinja syntax found in rendered output

    Returns:
        True if output was successful, False if output failed
    """
    output = OutputService.get()

    if output_mode == "clipboard":
        result = _copy_to_clipboard(response.rendered_text, template_name, output)
    elif output_mode == "file":
        result = _save_to_file(response, template_name, output_file, output)
    elif output_mode == "editor":
        result = _open_in_editor(response.rendered_text, template_name, output)
    else:
        result = _display_to_console(response, template_name, output)

    # Print escaped Jinja syntax after output if requested
    if print_escaped:
        _print_escaped_jinja(response.rendered_text, output)

    return result


def _print_escaped_jinja(rendered_text: str, output: OutputService) -> None:
    """Print Jinja syntax found in rendered output.

    Extracts and prints {{ }}, {% %}, and {# #} blocks that remain
    in the rendered output (typically from {% raw %} blocks).

    Args:
        rendered_text: The rendered template content
        output: Output service for printing
    """
    matches = extract_jinja_syntax(rendered_text)

    if not matches:
        output.info("No escaped Jinja syntax found in rendered output")
        return

    # Print to stderr so it doesn't interfere with piped output
    stderr_console = Console(file=sys.stderr, force_terminal=True)
    stderr_console.print(
        f"\n[bold cyan]Escaped Jinja Syntax[/bold cyan] ({len(matches)} found):"
    )

    for match in matches:
        # Print the full content of each match
        stderr_console.print(match.content)

    stderr_console.print()  # Blank line after


def _display_to_console(
    response: RenderTemplateResponse,
    template_name: str,
    _output: OutputService,
) -> bool:
    """Display rendered template to console.

    Metadata and status messages are printed to stderr for piping support.
    The actual rendered content is printed to stdout without formatting.
    """
    # Create a console for stderr output (for metadata/status)
    stderr_console = Console(file=sys.stderr, force_terminal=True)

    # Print success message to stderr (directly, not through output service)
    stderr_console.print(
        f"[green]✓[/green] Template '{template_name}' rendered successfully"
    )

    # Metadata table - print to stderr
    meta_table = Table(show_header=False, box=None, padding=(0, 1))
    meta_table.add_column("Field", style="dim")
    meta_table.add_column("Value")

    meta_table.add_row("Character Count", f"{response.character_count:,}")
    meta_table.add_row(
        "Version ID", format_uuid(response.template_version_id, short=True)
    )
    meta_table.add_row("Content Hash", response.content_hash)
    meta_table.add_row("Render Log ID", format_uuid(response.render_log_id, short=True))

    meta_panel = Panel(meta_table, title="Render Metadata", border_style="blue")
    stderr_console.print(meta_panel)

    # Print the actual rendered content to stdout (for piping)
    # No formatting, no panel - just the raw content
    print(response.rendered_text, file=sys.stdout)

    return True


def _save_to_file(
    response: RenderTemplateResponse,
    template_name: str,
    output_file: str | None,
    output: OutputService,
) -> bool:
    """Save rendered template to a file.

    Returns True on success, False on failure.
    """
    if not output_file:
        output.warning("No output file specified")
        return False

    try:
        file_path = Path(output_file).expanduser().resolve()

        # Ensure parent directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write the content to the file
        file_path.write_text(response.rendered_text, encoding="utf-8")

        output.success(
            f"Template '{template_name}' rendered and saved to {file_path} "
            f"({response.character_count:,} characters)"
        )
        return True
    except PermissionError:
        output.warning(f"Permission denied: Cannot write to '{output_file}'")
        return False
    except OSError as e:
        output.warning(f"Failed to save file: {e}")
        return False


def _copy_to_clipboard(
    rendered_text: str,
    template_name: str,
    output: OutputService,
) -> bool:
    """Copy rendered template to clipboard.

    All output goes to stderr since clipboard mode doesn't output the content to stdout.

    Returns True on success, False on failure.
    """
    if not PYPERCLIP_AVAILABLE or pyperclip is None:
        output.warning("pyperclip not installed. Install with: pip install pyperclip")
        output.info("Falling back to console output...")
        # Fallback: print to stdout for piping
        print(rendered_text, file=sys.stdout)
        return False

    try:
        pyperclip.copy(rendered_text)
        output.success(
            f"Template '{template_name}' rendered and copied to clipboard "
            f"({len(rendered_text):,} characters)"
        )
        return True
    except Exception as e:
        output.warning(f"Failed to copy to clipboard: {e}")
        output.info("Falling back to console output...")
        # Fallback: print to stdout for piping
        print(rendered_text, file=sys.stdout)
        return False


def _open_in_editor(
    rendered_text: str,
    template_name: str,
    output: OutputService,
) -> bool:
    """Open rendered template in the user's $EDITOR.

    Creates a temporary file, opens it in the editor, and waits for the editor
    to close. The temporary file is cleaned up afterward.

    Returns True on success, False on failure.
    """
    try:
        editor = get_editor()
    except EditorError:
        output.warning(
            "No editor found. Set $EDITOR environment variable or install nano/vim."
        )
        output.info("Falling back to console output...")
        print(rendered_text, file=sys.stdout)
        return False

    # Create temp file with .txt extension
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".txt",
            delete=False,
            encoding="utf-8",
        ) as f:
            f.write(rendered_text)
            temp_path = Path(f.name)
    except OSError as e:
        output.warning(f"Failed to create temporary file: {e}")
        output.info("Falling back to console output...")
        print(rendered_text, file=sys.stdout)
        return False

    try:
        # Open editor and wait for it to close
        editor_parts = editor.split()
        cmd = editor_parts + [str(temp_path)]

        result = subprocess.call(cmd)

        if result != 0:
            output.warning(f"Editor exited with non-zero status: {result}")
            return False

        output.success(
            f"Template '{template_name}' rendered and opened in editor "
            f"({len(rendered_text):,} characters)"
        )
        return True

    except FileNotFoundError:
        output.warning(f"Editor '{editor}' not found")
        output.info("Falling back to console output...")
        print(rendered_text, file=sys.stdout)
        return False
    except OSError as e:
        output.warning(f"Failed to open editor: {e}")
        output.info("Falling back to console output...")
        print(rendered_text, file=sys.stdout)
        return False
    finally:
        # Clean up temp file
        try:
            temp_path.unlink()
        except OSError:
            pass  # Best effort cleanup
