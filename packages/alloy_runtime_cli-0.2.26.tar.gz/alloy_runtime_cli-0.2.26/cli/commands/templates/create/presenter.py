"""Presenter for template creation output."""

from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import CreateTemplateResponse


def present_template_create_success(response: CreateTemplateResponse) -> None:
    """Present successful template creation.

    Args:
        response: Template creation response from server
    """
    output = OutputService.get()

    template = response.template
    version = response.version
    dependencies = response.dependencies

    output.success("Template created successfully")

    # Build a table for template display
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    # Template info
    table.add_row("ID", format_uuid(template.id, short=False))
    table.add_row("Name", template.name)
    table.add_row("Content Type", template.content_type_id)
    table.add_row("Visibility", template.visibility_id)
    table.add_row("Description", format_optional(template.description))

    # Version info
    table.add_row("Version", str(version.version))
    table.add_row("Version ID", format_uuid(version.id, short=True))
    table.add_row("Content Length", f"{len(version.content)} chars")

    # Tags
    if template.tags:
        tag_str = ", ".join(t.tag_path for t in template.tags)
        table.add_row("Tags", tag_str)
    else:
        table.add_row("Tags", "(none)")

    # Dependencies
    if dependencies:
        dep_str = ", ".join(d.child_template_name for d in dependencies)
        table.add_row("Dependencies", dep_str)
    else:
        table.add_row("Dependencies", "(none)")

    # Ownership
    table.add_row(
        "Organization ID",
        format_optional(template.organization_id, lambda x: format_uuid(x, short=True)),
    )
    table.add_row(
        "User ID",
        format_optional(template.user_id, lambda x: format_uuid(x, short=True)),
    )
    table.add_row("Created At", format_datetime(template.created_at))

    panel = Panel(table, title=f"Template: {template.name}", border_style="green")
    output.console.print(panel)

    # Show content preview
    if version.content:
        content_panel = Panel(
            Text(version.content, style="dim"),
            title="Content Preview",
            border_style="blue",
        )
        output.console.print(content_panel)
