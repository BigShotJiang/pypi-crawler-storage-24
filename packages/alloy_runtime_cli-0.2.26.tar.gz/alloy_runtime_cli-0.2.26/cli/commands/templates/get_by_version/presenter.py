"""Presenter for templates get_by_version command output."""

from rich.table import Table

from cli.infrastructure.output import OutputFormat, OutputService
from alloy_runtime_types.dtos.templates import GetTemplateResponse


def present_template_details(response: GetTemplateResponse) -> None:
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    output.success(f"Retrieved template: {response.template.name}")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim", width=20)
    table.add_column("Value")

    table.add_row("ID", str(response.template.id))
    table.add_row("Name", response.template.name)
    table.add_row("Description", response.template.description or "-")
    table.add_row("Content Type", response.template.content_type_id)
    table.add_row("Visibility", response.template.visibility_id)
    table.add_row(
        "Tags",
        ", ".join(t.tag_path for t in response.template.tags)
        if response.template.tags
        else "-",
    )

    output.console.print(table)
