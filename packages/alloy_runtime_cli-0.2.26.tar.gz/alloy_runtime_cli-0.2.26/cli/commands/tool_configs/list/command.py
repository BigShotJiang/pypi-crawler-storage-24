"""Tool configs list command implementation."""

from typing import Optional

import typer

from cli.commands.tool_configs.list.presenter import present_tool_configs_list
from cli.infrastructure.command import async_command, authenticated_client


def tool_configs_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search by name or description",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List tool configs accessible to you.

    Shows tool configs owned by you, your organization, or global configs.

    Examples:
        alloy tool-configs list
        alloy tool-configs list -s "rag"
        alloy tool-configs list -l 20
    """
    _execute_list(search=search, limit=limit, offset=offset)


@async_command
async def _execute_list(
    search: Optional[str],
    limit: int,
    offset: int,
) -> None:
    """Execute list tool configs operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_tool_configs(
            search=search,
            limit=limit,
            offset=offset,
        )

    present_tool_configs_list(response)
