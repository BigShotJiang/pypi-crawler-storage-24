"""Presenter for tool configs list command output."""

from alloy_runtime_types.dtos.tool_configs import ListToolConfigsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_tool_configs_list(response: ListToolConfigsResponse) -> None:
    """Present list of tool configs with Rich table formatting.

    Args:
        response: List tool configs response from server
    """
    output = OutputService.get()

    if not response.tool_configs:
        output.info("No tool configs found")
        return

    columns = [
        ColumnConfig(
            source_field="slug",
            header_label="Slug",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="tool_id",
            header_label="Tool",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="updated_at",
            header_label="Updated",
            formatter=lambda x: x.strftime("%Y-%m-%d") if x else "-",
            compact_line=1,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.tool_configs,  # type: ignore[arg-type]
        title=f"Tool Configs ({response.total})",
        columns=columns,
        raw_payload=response,
    )
