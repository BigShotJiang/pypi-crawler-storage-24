from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import get_console


def _mask_api_key_prefix(api_key: str) -> str:
    normalized = api_key.strip()
    visible_chars = min(20, max(4, len(normalized) - 4))
    return f"{normalized[:visible_chars]}..."


def _format_build_age(build_age: str | None, build_age_seconds: int | None) -> str:
    if build_age:
        return build_age
    if build_age_seconds is None:
        return "n/a"
    if build_age_seconds < 60:
        return "fresh"
    minutes = build_age_seconds // 60
    if minutes < 60:
        unit = "minute" if minutes == 1 else "minutes"
        return f"{minutes} {unit}"
    hours = build_age_seconds // 3600
    if hours < 48:
        unit = "hour" if hours == 1 else "hours"
        return f"{hours} {unit}"
    days = build_age_seconds // 86400
    unit = "day" if days == 1 else "days"
    return f"{days} {unit}"


def _format_ms(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{value:.1f} ms"


def ping_command() -> None:
    _execute_ping()


@async_command
async def _execute_ping() -> None:
    console = get_console()

    async with authenticated_client() as (config, client):
        ping = await client.get_ping()

    api_key_prefix = ping.api_key_prefix or _mask_api_key_prefix(config.api_key)

    console.print("[bold]Identity[/bold]")
    console.print(f"Email: {ping.email}")
    console.print(f"Name: {ping.name}")
    console.print(f"User ID: {ping.user_id}")
    if ping.organization_id:
        console.print(f"Organization: {ping.organization_name or ping.organization_id}")
        console.print(f"Organization ID: {ping.organization_id}")
    else:
        console.print("Organization: personal")
    console.print(f"System Admin: {'yes' if ping.is_system_admin else 'no'}")
    console.print("")

    console.print("[bold]Connection[/bold]")
    console.print(f"API Host: {ping.api_host or 'n/a'}")
    console.print(f"API Key: {api_key_prefix}")
    console.print(
        f"HTTP Status: {ping.http_status if ping.http_status is not None else 'n/a'}"
    )
    console.print(f"HTTP Version: {ping.http_version or 'n/a'}")
    console.print(f"TLS Version: {ping.tls_version or 'n/a'}")
    console.print("")

    console.print("[bold]Build[/bold]")
    console.print(f"Release: {ping.release_version or 'n/a'}")
    console.print(f"Build ID: {ping.build_id or 'n/a'}")
    console.print(
        f"Build Age: {_format_build_age(ping.build_age, ping.build_age_seconds)}"
    )
    console.print(f"Instance: {ping.instance_label or 'n/a'}")
    console.print("")

    console.print("[bold]Timing[/bold]")
    console.print(f"DNS: {_format_ms(ping.dns_ms)}")
    console.print(f"Connect: {_format_ms(ping.connect_ms)}")
    console.print(f"TLS: {_format_ms(ping.tls_ms)}")
    console.print(f"TTFB: {_format_ms(ping.ttfb_ms)}")
    console.print(f"Wait: {_format_ms(ping.wait_ms)}")
    console.print(f"Transfer: {_format_ms(ping.transfer_ms)}")
    console.print(f"Total: {_format_ms(ping.total_ms)}")
