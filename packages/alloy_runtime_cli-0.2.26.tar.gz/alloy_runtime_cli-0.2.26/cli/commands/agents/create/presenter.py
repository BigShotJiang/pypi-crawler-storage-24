"""Presenter for agent creation output."""

from cli.commands.agents.create.fields import (
    format_generation_params,
    format_models,
    format_tags,
    format_tools,
)
from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.agents import CreateAgentResponse


def present_agent_create_success(response: CreateAgentResponse) -> None:
    """Present successful agent creation.

    Args:
        response: Agent creation response from server
    """
    output = OutputService.get()
    output.success("Agent created successfully")
    system_prompt_id = (
        response.system_instruction_template_id
        or response.system_instruction_version_id
    )

    fields = [
        FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig("models", "Models", lambda _: format_models(response)),
        FieldConfig("tools", "Tools", lambda _: format_tools(response)),
        FieldConfig("tags", "Tags", lambda _: format_tags(response)),
        FieldConfig(
            "generation_params",
            "Generation Params",
            lambda _: format_generation_params(response),
        ),
        FieldConfig(
            "system_instruction_template_id",
            "System Prompt ID",
            lambda _: format_optional(
                system_prompt_id, lambda x: format_uuid(x, short=False)
            ),
        ),
        FieldConfig(
            "input_schema_id",
            "Input Schema ID",
            lambda v: format_optional(v, lambda x: format_uuid(x, short=False)),
        ),
        FieldConfig(
            "output_schema_id",
            "Output Schema ID",
            lambda v: format_optional(v, lambda x: format_uuid(x, short=False)),
        ),
        FieldConfig(
            "organization_id",
            "Organization ID",
            lambda v: format_optional(v, lambda x: format_uuid(x, short=True)),
        ),
        FieldConfig(
            "user_id",
            "User ID",
            lambda v: format_optional(v, lambda x: format_uuid(x, short=True)),
        ),
        FieldConfig("created_at", "Created At", format_datetime),
    ]

    output.entity(response, f"Agent: {response.name}", fields, raw_payload=response)
