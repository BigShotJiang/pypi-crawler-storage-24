"""Presenter for agents get command output."""

from rich.table import Table

from cli.infrastructure.output import OutputFormat, OutputService
from alloy_runtime_types.dtos.agents import GetAgentResponse


def present_agent_details(response: GetAgentResponse) -> None:
    """Present agent details with Rich formatting.

    Args:
        response: GetAgentResponse from server
    """
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    output.success(f"Retrieved agent: {response.name}")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim", width=20)
    table.add_column("Value")

    table.add_row("ID", str(response.id))
    table.add_row("Name", response.name)
    table.add_row("Description", response.description or "-")
    table.add_row("Models", f"{len(response.models)} configured")
    table.add_row("Tools", f"{len(response.tools)} configured")
    table.add_row(
        "Tags", ", ".join(t.tag_path for t in response.tags) if response.tags else "-"
    )

    output.console.print(table)
