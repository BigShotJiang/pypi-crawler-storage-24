"""Concurrent execution renderer with side-by-side display.

Manages multiple simultaneous text generations with a clean
layout that adapts based on the number of concurrent executions.
"""

import asyncio
from collections.abc import AsyncGenerator

from rich.console import Console, Group, RenderableType
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from alloy_runtime_types.dtos.generation import GenerateTextStreamChunk

# Display configuration
CONCURRENT_REFRESH_RATE = 8  # Frames per second
CHUNK_UPDATE_INTERVAL = 5  # Update display every N chunks
THINKING_HEIGHT_RATIO = 0.25  # Thinking panel gets 25% of space


class ExecutionState:
    """Tracks state for a single concurrent execution."""

    def __init__(self, index: int, agent_identifier: str | None = None):
        """Initialize execution state.

        Args:
            index: Execution index (0-based)
            agent_identifier: Agent name or UUID for display (optional)
        """
        self.index = index
        self.agent_identifier = agent_identifier
        self.thinking_text = ""
        self.content_text = ""
        self.execution_id: str | None = None
        self.session_id: str | None = None
        self.is_complete = False
        self.has_error = False
        self.error_message: str | None = None

    def process_chunk(self, chunk: GenerateTextStreamChunk) -> None:
        """Process a stream chunk and update state.

        Args:
            chunk: Stream chunk to process
        """
        if self.execution_id is None:
            self.execution_id = str(chunk.execution_id)

        if chunk.chunk_type == "thinking":
            if chunk.reasoning_content:
                self.thinking_text += chunk.reasoning_content
        elif chunk.chunk_type == "metadata":
            # Metadata chunks - capture session_id from final metadata
            if chunk.metadata and "chat_session_id" in chunk.metadata:
                self.session_id = chunk.metadata["chat_session_id"]
        else:
            if chunk.content:
                self.content_text += chunk.content


class ConcurrentRenderer:
    """Renders multiple concurrent text generations.

    Features:
    - Side-by-side layout for 2-3 concurrent executions
    - Stacked layout for 4+ executions
    - Individual thinking and content panels per execution
    - Graceful error handling per execution
    - Agent name display for multi-agent comparison mode
    """

    def __init__(
        self,
        console: Console,
        execution_count: int,
        agent_identifiers: list[str] | None = None,
    ):
        """Initialize concurrent renderer.

        Args:
            console: Rich console for output
            execution_count: Number of concurrent executions (1-10)
            agent_identifiers: Optional list of agent names/UUIDs for display
        """
        self.console = console
        self.execution_count = min(max(execution_count, 1), 10)  # Clamp 1-10
        self._agent_identifiers = agent_identifiers

        # Create execution states with optional agent identifiers
        self._states: list[ExecutionState] = []
        for i in range(self.execution_count):
            agent_id = (
                agent_identifiers[i]
                if agent_identifiers and i < len(agent_identifiers)
                else None
            )
            self._states.append(ExecutionState(i, agent_identifier=agent_id))

        self._use_side_by_side = execution_count <= 3

        # Calculate dimensions based on terminal size
        terminal_height = console.size.height or 24
        terminal_width = console.size.width or 80

        # Calculate panel width (account for side-by-side splitting and borders)
        if self._use_side_by_side:
            # Each panel gets equal share, minus borders (2 chars each side)
            self._panel_width = max((terminal_width // execution_count) - 4, 20)
        else:
            self._panel_width = max(terminal_width - 4, 20)

        # Calculate max lines per panel
        reserved_lines = 6  # Status bar, panel borders, spacing
        available_height = max(terminal_height - reserved_lines, 10)
        self._max_panel_lines = available_height

    async def render_streams(
        self,
        streams: list[AsyncGenerator[GenerateTextStreamChunk, None]],
        show_thinking: bool = True,
    ) -> list[tuple[str, str, str | None, str | None]]:
        """Render multiple concurrent streams.

        Args:
            streams: List of async generators for each execution
            show_thinking: Whether to display thinking blocks

        Returns:
            List of (content_text, thinking_text, error, session_id) tuples for each execution
        """
        if len(streams) != self.execution_count:
            raise ValueError(
                f"Expected {self.execution_count} streams, got {len(streams)}"
            )

        with Live(
            self._build_display(),
            console=self.console,
            refresh_per_second=CONCURRENT_REFRESH_RATE,
            transient=False,
        ) as live:
            # Create tasks for each stream, passing live for updates
            tasks = [
                self._consume_stream(i, stream, show_thinking, live)
                for i, stream in enumerate(streams)
            ]

            # Run all streams concurrently
            await asyncio.gather(*tasks, return_exceptions=True)

            # Final update
            live.update(self._build_display())

        # Return results
        return [
            (
                state.content_text,
                state.thinking_text,
                state.error_message,
                state.session_id,
            )
            for state in self._states
        ]

    async def _consume_stream(
        self,
        index: int,
        stream: AsyncGenerator[GenerateTextStreamChunk, None],
        show_thinking: bool,
        live: Live,
    ) -> None:
        """Consume a single stream and update its state.

        Args:
            index: Execution index
            stream: Async generator of chunks
            show_thinking: Whether to process thinking chunks
            live: Rich Live display to update
        """
        state = self._states[index]
        chunk_count = 0
        try:
            async for chunk in stream:
                if show_thinking or chunk.chunk_type != "thinking":
                    state.process_chunk(chunk)
                    chunk_count += 1
                    # Update display every N chunks to reduce flicker
                    if chunk_count % CHUNK_UPDATE_INTERVAL == 0:
                        live.update(self._build_display())
            state.is_complete = True
            # Final update when complete
            live.update(self._build_display())
        except Exception as e:
            state.has_error = True
            state.error_message = str(e)
            state.is_complete = True
            # Update display to show error
            live.update(self._build_display())

    def _build_display(self) -> Layout | Group:
        """Build the display layout based on execution count.

        Returns:
            Layout for side-by-side or Group for stacked
        """
        if self._use_side_by_side:
            return self._build_side_by_side_layout()
        else:
            return self._build_stacked_layout()

    def _build_side_by_side_layout(self) -> Layout:
        """Build side-by-side layout for 2-3 executions.

        Returns:
            Layout with horizontal split
        """
        layout = Layout()

        # Create columns
        columns = [
            Layout(self._render_execution_panel(state), name=f"exec_{state.index}")
            for state in self._states
        ]

        layout.split_row(*columns)
        return layout

    def _build_stacked_layout(self) -> Group:
        """Build stacked layout for 4+ executions.

        Returns:
            Group of panels
        """
        panels = [self._render_execution_panel(state) for state in self._states]
        return Group(*panels)

    def _tail_text(self, text: str, max_visual_lines: int, width: int) -> str:
        """Return full text without truncation.

        Args:
            text: Full text content
            max_visual_lines: Unused compatibility parameter
            width: Unused compatibility parameter

        Returns:
            Full text content
        """
        _ = max_visual_lines
        _ = width
        return text

    def _render_execution_panel(self, state: ExecutionState) -> Panel:
        """Render a single execution as a panel.

        Args:
            state: Execution state to render

        Returns:
            Panel with execution content
        """
        content_parts: list[RenderableType] = []

        # Calculate line budget - split between thinking and content
        thinking_max_lines = int(self._max_panel_lines * THINKING_HEIGHT_RATIO)
        content_max_lines = (
            self._max_panel_lines - thinking_max_lines - 4
        )  # 4 for borders

        # Content width accounts for panel padding (2 chars each side)
        content_width = max(self._panel_width - 4, 10)

        # Add thinking section if present (show tail/latest)
        if state.thinking_text:
            thinking_display = self._tail_text(
                state.thinking_text, thinking_max_lines, content_width
            )
            thinking_text = Text(thinking_display, style="dim italic")
            thinking_panel = Panel(
                thinking_text,
                title="[red]Thinking[/red]",
                title_align="left",
                border_style="red",
                padding=(0, 1),
            )
            content_parts.append(thinking_panel)

        # Add content (show tail/latest)
        if state.content_text:
            content_display = self._tail_text(
                state.content_text, content_max_lines, content_width
            )
            content_parts.append(Text(content_display))
        elif state.has_error:
            content_parts.append(Text(f"Error: {state.error_message}", style="red"))
        elif not state.is_complete:
            content_parts.append(Text("Generating...", style="dim"))
        else:
            content_parts.append(Text("(empty response)", style="dim"))

        # Determine panel styling
        # Use agent identifier if available, otherwise fall back to execution number
        if state.agent_identifier:
            title = f"Agent: {state.agent_identifier}"
        else:
            title = f"Execution {state.index + 1}"

        if state.is_complete:
            if state.has_error:
                border_style = "red"
                title = f"{title} [red](error)[/red]"
            else:
                border_style = "green"
                title = f"{title} [green](complete)[/green]"
        else:
            border_style = "blue"
            title = f"{title} [blue](running)[/blue]"

        return Panel(
            Group(*content_parts) if content_parts else Text(""),
            title=title,
            title_align="left",
            border_style=border_style,
            padding=(0, 1),
        )
