"""Presenter for async generation status command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_cost,
    format_datetime,
    format_duration_ms,
    format_optional,
    format_tokens,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.generation import AsyncGenerationStatusResponse


def present_generation_status(response: AsyncGenerationStatusResponse) -> None:
    """Present async generation status details."""
    output = OutputService.get()

    border_style = {
        "completed": "green",
        "failed": "red",
        "cancelled": "yellow",
        "timeout": "yellow",
        "running": "blue",
        "pending": "dim",
    }.get(response.status, "dim")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Execution ID", format_uuid(response.execution_id, short=False))
    table.add_row("Status", response.status)
    table.add_row("Queued At", format_datetime(response.queued_at))

    if response.started_at:
        table.add_row("Started At", format_datetime(response.started_at))

    if response.completed_at:
        table.add_row("Completed At", format_datetime(response.completed_at))

    if response.total_duration_ms:
        table.add_row("Duration", format_duration_ms(response.total_duration_ms))

    if response.output_text:
        table.add_row("Output", response.output_text)

    if response.usage:
        table.add_row("Input Tokens", format_tokens(response.usage.input_tokens))
        table.add_row("Output Tokens", format_tokens(response.usage.output_tokens))

    if response.cost:
        table.add_row("Cost", format_cost(response.cost.total_cost_usd))

    if response.provider_key:
        table.add_row("Provider", response.provider_key)

    if response.provider_model_name:
        table.add_row("Model", response.provider_model_name)

    if response.error_message:
        table.add_row("Error", response.error_message)

    if response.error_type:
        table.add_row("Error Type", response.error_type)

    table.add_row("External ID", format_optional(response.external_id))

    panel = Panel(table, title="Generation Status", border_style=border_style)
    output.console.print(panel)
