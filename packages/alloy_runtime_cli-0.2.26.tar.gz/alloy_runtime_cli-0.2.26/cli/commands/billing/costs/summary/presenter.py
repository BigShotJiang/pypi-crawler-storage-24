"""Presenter for billing project cost summary command output."""

from decimal import Decimal

from alloy_runtime_types.dtos.billing import ProjectCostSummary

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_cost(cost: Decimal | None) -> str:
    """Format cost for display."""
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def _format_period(response: ProjectCostSummary) -> str:
    """Format period dates for display."""
    return f"{response.period_start.strftime('%Y-%m-%d')} to {response.period_end.strftime('%Y-%m-%d')}"


def present_billing_cost_summary(response: ProjectCostSummary) -> None:
    """Present billing project cost summary."""
    output = OutputService.get()

    fields = [
        FieldConfig("project_id", "Project ID", str),
        FieldConfig("project_name", "Project Name"),
        FieldConfig("period", "Period", lambda _: _format_period(response)),
        FieldConfig("execution_count", "Total Executions", str),
        FieldConfig("completed_count", "Completed", str),
        FieldConfig("failed_count", "Failed", str),
        FieldConfig("llm_cost_usd", "LLM Cost", _format_cost),
        FieldConfig("rag_cost_usd", "RAG Cost", _format_cost),
        FieldConfig("total_cost_usd", "Total Cost", _format_cost),
        FieldConfig("avg_cost_usd", "Avg Cost", _format_cost),
        FieldConfig("min_cost_usd", "Min Cost", _format_cost),
        FieldConfig("max_cost_usd", "Max Cost", _format_cost),
    ]

    output.entity(
        response, "Billing Project Cost Summary", fields, raw_payload=response
    )
