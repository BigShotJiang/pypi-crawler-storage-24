"""Presenter for pipeline get command output."""

import json

from rich.panel import Panel
from rich.syntax import Syntax

from alloy_runtime_types.dtos.pipeline import (
    GetPipelineResponse,
    UpdatePipelineResponse,
)

from cli.infrastructure.formatting.fields import format_datetime, format_optional
from cli.infrastructure.output import OutputFormat, OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_pipeline(response: GetPipelineResponse | UpdatePipelineResponse) -> None:
    """Present pipeline details with Rich formatting."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig("is_public", "Public", lambda v: "Yes" if v else "No"),
        FieldConfig("created_at", "Created", format_datetime),
        FieldConfig("updated_at", "Updated", format_datetime),
    ]

    output.entity(response, f"Pipeline: {response.name}", fields, raw_payload=response)

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        return

    if response.input_schema:
        schema_str = json.dumps(response.input_schema, indent=2)
        syntax = Syntax(schema_str, "json", theme="monokai", line_numbers=True)
        output.console.print(Panel(syntax, title="Input Schema"))

    # Show module content if available (only for owners)
    if response.module_content:
        syntax = Syntax(
            response.module_content,
            "python",
            theme="monokai",
            line_numbers=True,
        )
        output.console.print(Panel(syntax, title="Module Content"))
