"""Presenter for pipelines list command output."""

from alloy_runtime_types.dtos.pipeline import ListPipelinesResponse

from cli.infrastructure.output import OutputFormat, OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_description(description: str | None) -> str:
    """Format description for display, truncating if too long."""
    if not description:
        return "-"
    return description


def present_pipelines_list(response: ListPipelinesResponse) -> None:
    """Present list of pipelines with Rich table formatting."""
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    if not response.pipelines:
        output.info("No pipelines found")
        return

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="is_public",
            header_label="Public",
            formatter=lambda x: "Yes" if x else "No",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Created",
            formatter=lambda x: x.strftime("%Y-%m-%d") if x else "-",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=_format_description,
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.pipelines,  # type: ignore[arg-type]
        title=f"Pipelines ({response.total})",
        columns=columns,
        raw_payload=response,
    )
