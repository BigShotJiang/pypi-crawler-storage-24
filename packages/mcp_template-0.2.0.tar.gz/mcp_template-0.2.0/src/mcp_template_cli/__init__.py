"""Public package for the mcp-template command."""

__version__ = "0.2.0"
