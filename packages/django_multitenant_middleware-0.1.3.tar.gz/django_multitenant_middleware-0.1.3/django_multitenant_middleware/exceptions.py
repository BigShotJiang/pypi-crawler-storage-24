class TenantNotFound(Exception):
    """Raised when tenant cannot be resolved."""

    pass
