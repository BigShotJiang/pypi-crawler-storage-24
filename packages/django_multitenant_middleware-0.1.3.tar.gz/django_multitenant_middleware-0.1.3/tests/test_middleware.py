from channels_multitenant.resolvers import SubdomainTenantResolver


def test_resolver():

    resolver = SubdomainTenantResolver("example.com")

    assert resolver.resolve("client1.example.com") == "client1"
