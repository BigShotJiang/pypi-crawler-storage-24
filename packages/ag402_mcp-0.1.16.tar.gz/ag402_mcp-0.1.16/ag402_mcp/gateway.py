"""
x402 MCP Gateway -- reverse proxy that adds x402 payment gating to any HTTP API.

Wraps any upstream HTTP service (e.g. a weather API, an MCP server) and
requires x402 payment before proxying requests. Clients that do not present
a valid payment proof receive HTTP 402 with a WWW-Authenticate challenge.

Usage as library:
    gateway = X402Gateway(target_url="http://localhost:8000", price="0.02", address="...")
    app = gateway.create_app()
    uvicorn.run(app, host="0.0.0.0", port=8001)

Usage as CLI:
    ag402-gateway --target http://localhost:8000 --price 0.02 --address SolAddr...
"""

from __future__ import annotations

import argparse
import logging
import os
import re
import time
from contextlib import asynccontextmanager

import httpx
from ag402_core.gateway.auth import PaymentVerifier
from ag402_core.prepaid.verifier import PrepaidVerifier
from ag402_core.security.rate_limiter import RateLimiter
from ag402_core.security.replay_guard import (
    PersistentReplayGuard,
    ReplayGuard,
    TxHashStatus,
)
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from open402.headers import build_www_authenticate
from open402.spec import X402PaymentChallenge, X402ServiceDescriptor
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class _PrepaidPurchaseRequest(BaseModel):
    buyer_address: str
    package_id: str
    tx_hash: str

class X402Gateway:
    """Wraps any HTTP API/MCP server and adds x402 payment gate."""

    def __init__(
        self,
        target_url: str,
        price: str,
        chain: str = "solana",
        token: str = "USDC",
        address: str = "",
        verifier: PaymentVerifier | None = None,
        replay_window: int = 30,
        replay_db_path: str = "",
        rate_limit_per_minute: int = 60,
        prepaid_signing_key: str = "",
    ):
        self.target_url = target_url.rstrip("/")
        self.price = price
        self.chain = chain
        self.token = token
        self.address = address or "GtwRecipientAddr1111111111111111111111111111"
        self._replay_guard = ReplayGuard(window_seconds=replay_window)

        # P0-1.2: Detect test mode from environment; warn prominently
        self._is_test_mode = os.getenv("X402_MODE", "test").lower() == "test"
        if verifier is not None:
            self.verifier = verifier
        elif self._is_test_mode:
            logger.warning(
                "========================================\n"
                "  WARNING: GATEWAY RUNNING IN TEST MODE\n"
                "  No on-chain payment verification!\n"
                "  Set X402_MODE=production for real use.\n"
                "========================================"
            )
            self.verifier = PaymentVerifier()  # test mode
        else:
            raise ValueError(
                "Production mode (X402_MODE=production) requires an explicit "
                "PaymentVerifier with a payment provider. Either provide a "
                "'verifier' argument or set X402_MODE=test for development."
            )
        # Persistent tx_hash deduplication (survives restarts)
        self._replay_db_path = replay_db_path or os.path.expanduser("~/.ag402/gateway_replay.db")
        self._persistent_guard = PersistentReplayGuard(db_path=self._replay_db_path)
        # Shared httpx client (created/closed via lifespan)
        self._http_client: httpx.AsyncClient | None = None

        # P1-2.7: IP-based rate limiter
        self._rate_limiter = RateLimiter(
            max_requests=rate_limit_per_minute, window_seconds=60
        )

        # P2-3.6: Lightweight metrics counters
        self._metrics = {
            "requests_total": 0,
            "payments_verified": 0,
            "payments_rejected": 0,
            "replays_rejected": 0,
            "challenges_issued": 0,
            "proxy_errors": 0,
            "prepaid_verified": 0,
            "prepaid_rejected": 0,
            "started_at": time.time(),
        }

        # P0-2: Prepaid credential verifier (seller side).
        # Enabled when prepaid_signing_key is non-empty.
        # Falls back to AG402_PREPAID_SIGNING_KEY env var if not passed explicitly.
        _signing_key = prepaid_signing_key or os.getenv("AG402_PREPAID_SIGNING_KEY", "")
        if _signing_key and self.address:
            # Warn on weak keys (minimum 32 chars recommended for HMAC-SHA256)
            if len(_signing_key) < 32:
                logger.warning(
                    "[GATEWAY] Prepaid signing key is short (%d chars). "
                    "Recommend >= 32 random characters. "
                    "Generate one: python -c \"import secrets; print(secrets.token_hex(32))\"",
                    len(_signing_key),
                )
            self._prepaid_verifier: PrepaidVerifier | None = PrepaidVerifier(
                signing_key=_signing_key,
                seller_address=self.address,
            )
            logger.info("[GATEWAY] Prepaid credential verification enabled")
        else:
            self._prepaid_verifier = None
            if not _signing_key:
                logger.info(
                    "[GATEWAY] Prepaid verification disabled "
                    "(set AG402_PREPAID_SIGNING_KEY to enable)"
                )

        # Build the service descriptor for 402 challenges
        self._service = X402ServiceDescriptor(
            endpoint=self.target_url,
            price=self.price,
            chain=self.chain,
            token=self.token,
            address=self.address,
        )

    def _build_challenge(self) -> X402PaymentChallenge:
        """Build the payment challenge for 402 responses."""
        return self._service.to_challenge()

    def _build_402_response(self) -> JSONResponse:
        """Build an HTTP 402 response with x402 WWW-Authenticate header."""
        challenge = self._build_challenge()
        www_auth_value = build_www_authenticate(challenge)
        return JSONResponse(
            status_code=402,
            content={
                "error": "Payment Required",
                "protocol": "x402",
                "chain": challenge.chain,
                "token": challenge.token,
                "amount": challenge.amount,
                "address": challenge.address,
            },
            headers={"WWW-Authenticate": www_auth_value},
        )

    def create_app(self) -> FastAPI:
        """Create a FastAPI app that proxies requests with payment gate."""
        gateway = self

        @asynccontextmanager
        async def lifespan(app: FastAPI):
            """Manage shared resources: httpx client and persistent replay guard."""
            gateway._http_client = httpx.AsyncClient(timeout=30.0)
            await gateway._persistent_guard.init_db()
            yield
            await gateway._http_client.aclose()
            gateway._http_client = None
            await gateway._persistent_guard.close()

        app = FastAPI(
            title="x402 Payment Gateway",
            description=f"Payment-gated proxy to {self.target_url}",
            lifespan=lifespan,
        )

        # P2-3.6: Health check endpoint (not gated behind payment)
        # S2-1 FIX: In production mode, return minimal info only.
        @app.get("/health")
        async def health_check() -> JSONResponse:
            """Return gateway health status.

            In production mode, only status and mode are returned to avoid
            leaking internal infrastructure details (target_url, metrics).
            In test mode, full details are available for debugging.
            """
            uptime = time.time() - self._metrics["started_at"]

            if not self._is_test_mode:
                # S2-1: Production — minimal response, no internal details
                return JSONResponse(content={
                    "status": "healthy",
                    "mode": "production",
                    "uptime_seconds": round(uptime, 1),
                })

            # Test mode — full details for debugging
            return JSONResponse(content={
                "status": "healthy",
                "mode": "test",
                "target_url": self.target_url,
                "uptime_seconds": round(uptime, 1),
                "metrics": {
                    "requests_total": self._metrics["requests_total"],
                    "payments_verified": self._metrics["payments_verified"],
                    "payments_rejected": self._metrics["payments_rejected"],
                    "replays_rejected": self._metrics["replays_rejected"],
                    "challenges_issued": self._metrics["challenges_issued"],
                    "proxy_errors": self._metrics["proxy_errors"],
                    "prepaid_verified": self._metrics["prepaid_verified"],
                    "prepaid_rejected": self._metrics["prepaid_rejected"],
                },
            })

        # P0-3: Prepaid purchase endpoints (not gated behind payment)

        @app.get("/prepaid/packages")
        async def list_packages() -> JSONResponse:
            """Return available prepaid package tiers and prices."""
            from ag402_core.prepaid.models import PACKAGES
            return JSONResponse(content={
                "packages": [
                    {
                        "package_id": pkg_id,
                        "name": info["name"],
                        "calls": info["calls"],
                        "days": info["days"],
                        "price_usdc": info["price"],
                        "token": self.token,
                        "seller_address": self.address,
                    }
                    for pkg_id, info in PACKAGES.items()
                ]
            })

        @app.post("/prepaid/purchase")
        async def purchase_package(request: Request, body: _PrepaidPurchaseRequest) -> JSONResponse:
            """Verify on-chain USDC payment and issue a prepaid credential.

            In test mode, tx_hash is accepted as-is without on-chain check.
            In production mode, the verifier validates the transaction.
            """
            client_ip = request.client.host if request.client else "unknown"
            if not self._rate_limiter.allow(client_ip):
                return JSONResponse(
                    status_code=429,
                    content={"error": "Too Many Requests", "detail": "Rate limit exceeded"},
                )

            if not self._prepaid_verifier:
                return JSONResponse(
                    status_code=503,
                    content={"error": "Prepaid purchase not enabled on this gateway"},
                )

            from ag402_core.prepaid.models import PACKAGES
            pkg = PACKAGES.get(body.package_id)
            if pkg is None:
                return JSONResponse(
                    status_code=400,
                    content={"error": "invalid_package", "detail": f"Unknown package_id: {body.package_id!r}"},
                )

            # Verify on-chain payment (test mode: accepted if well-formed)
            # Validate tx_hash before embedding in Authorization header string
            # (prevents header injection via crafted tx_hash values)
            if not re.fullmatch(r"[A-Za-z0-9_\-]{1,128}", body.tx_hash):
                return JSONResponse(
                    status_code=400,
                    content={"error": "invalid_tx_hash", "detail": "tx_hash contains invalid characters"},
                )
            # Use legacy x402 format: "x402 <tx_hash>" — compatible with PaymentVerifier
            expected_amount = float(pkg["price"])
            pay_result = await self.verifier.verify(
                f"x402 {body.tx_hash}",
                expected_amount=expected_amount,
                expected_address=self.address,
            )
            if not pay_result.valid:
                logger.warning("[GATEWAY] Purchase payment rejected: %s", pay_result.error)
                return JSONResponse(
                    status_code=402,
                    content={"error": "payment_verification_failed", "detail": pay_result.error},
                )

            # Issue credential — build only, do NOT store on seller side
            # (seller returns JSON; buyer calls add_credential() locally)
            from datetime import datetime
            from datetime import timezone as _tz

            from ag402_core.prepaid.client import _compute_hmac
            from ag402_core.prepaid.models import PrepaidCredential, calculate_expiry
            _signing_key = self._prepaid_verifier._signing_key
            expires_at = calculate_expiry(pkg["days"])
            signature = _compute_hmac(_signing_key, body.buyer_address, body.package_id, expires_at)
            cred = PrepaidCredential(
                buyer_address=body.buyer_address,
                package_id=body.package_id,
                remaining_calls=pkg["calls"],
                expires_at=expires_at,
                signature=signature,
                seller_address=self.address,
                created_at=datetime.now(_tz.utc),
            )
            logger.info(
                "[GATEWAY] Issued prepaid credential: buyer=%s package=%s calls=%d",
                body.buyer_address[:24], body.package_id, cred.remaining_calls,
            )
            return JSONResponse(
                status_code=201,
                content={"credential": cred.to_dict()},
            )

        @app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"])
        async def gateway_handler(request: Request, path: str) -> Response:
            """Catch-all route that gates all requests behind x402 payment."""
            self._metrics["requests_total"] += 1

            # P1-2.7: IP-based rate limiting
            client_ip = request.client.host if request.client else "unknown"
            if not self._rate_limiter.allow(client_ip):
                self._metrics["rate_limited"] = self._metrics.get("rate_limited", 0) + 1
                logger.warning("[GATEWAY] Rate limited: %s", client_ip)
                return JSONResponse(
                    status_code=429,
                    content={"error": "Too Many Requests", "detail": "Rate limit exceeded"},
                )

            authorization = request.headers.get("authorization", "")

            # 0.5. P0-2: Prepaid credential fast-path (1ms local verify, no chain call)
            prepaid_header = request.headers.get("x-prepaid-credential", "")
            if prepaid_header and self._prepaid_verifier is not None:
                result = self._prepaid_verifier.verify(prepaid_header)
                if result.valid:
                    self._metrics["prepaid_verified"] += 1
                    logger.info("[GATEWAY] Prepaid credential accepted — proxying")
                    try:
                        return await self._proxy_request(request, path)
                    except Exception as exc:
                        self._metrics["proxy_errors"] += 1
                        logger.error("[GATEWAY] Proxy error (prepaid): %s", exc)
                        return JSONResponse(status_code=502, content={"error": "Bad Gateway"})
                else:
                    # Invalid prepaid → fall through to standard 402 so buyer retries on-chain
                    logger.info(
                        "[GATEWAY] Prepaid credential rejected (%s) — returning 402",
                        result.error,
                    )
                    self._metrics["prepaid_rejected"] += 1
                    self._metrics["challenges_issued"] += 1
                    return self._build_402_response()

            # 1. Check for Authorization header
            if not authorization:
                # No auth at all -> 402 challenge
                logger.info("[GATEWAY] No Authorization header -- returning 402")
                self._metrics["challenges_issued"] += 1
                return self._build_402_response()

            # 2. Check if it's x402 format
            if not authorization.strip().lower().startswith("x402 "):
                # Non-x402 auth (e.g. Bearer token) -> 403 Forbidden
                logger.info("[GATEWAY] Non-x402 Authorization -- returning 403")
                return JSONResponse(
                    status_code=403,
                    content={"error": "Forbidden", "detail": "x402 payment proof required"},
                )

            # 3. Replay protection (timestamp + nonce check) — MANDATORY
            ts = request.headers.get("x-x402-timestamp", "")
            nonce = request.headers.get("x-x402-nonce", "")
            replay_ok, replay_err = self._replay_guard.check(ts, nonce)
            if not replay_ok:
                logger.warning("[GATEWAY] Replay check failed: %s", replay_err)
                self._metrics["replays_rejected"] += 1
                return JSONResponse(
                    status_code=403,
                    content={"error": "Replay rejected", "detail": replay_err},
                )

            # 4. Verify the x402 proof
            result = await self.verifier.verify(
                authorization,
                expected_amount=float(self.price),
                expected_address=self.address,
            )

            if not result.valid:
                logger.warning("[GATEWAY] Invalid payment proof: %s", result.error)
                self._metrics["payments_rejected"] += 1
                return JSONResponse(
                    status_code=403,
                    content={"error": "Payment verification failed", "detail": result.error},
                )

            # 5b. Persistent tx_hash replay check with grace window
            #
            # Three-state logic:
            #   NEW          → first time, record and proxy
            #   WITHIN_GRACE → previously consumed but delivery may have failed,
            #                   serve cached response or re-proxy
            #   EXPIRED      → grace window expired, reject as replay
            tx_status = await self._persistent_guard.check_tx_status(result.tx_hash)

            if tx_status == TxHashStatus.EXPIRED:
                logger.warning("[GATEWAY] Expired tx_hash rejected: %s", result.tx_hash[:32])
                self._metrics["replays_rejected"] += 1
                return self._build_402_response()

            if tx_status == TxHashStatus.WITHIN_GRACE:
                # Buyer is retrying a previously consumed tx_hash within grace window.
                # Try to serve cached response first (if upstream succeeded before).
                cached = await self._persistent_guard.get_cached_response(result.tx_hash)
                if cached:
                    status_code, cached_headers, cached_body = cached
                    logger.info(
                        "[GATEWAY] Serving cached response for tx_hash retry: %s (status=%d)",
                        result.tx_hash[:32], status_code,
                    )
                    self._metrics["receipts_reused"] = self._metrics.get("receipts_reused", 0) + 1
                    return Response(
                        content=cached_body,
                        status_code=status_code,
                        headers=cached_headers,
                    )
                # No cached response — upstream previously failed, re-proxy
                logger.info(
                    "[GATEWAY] Re-proxying for tx_hash within grace window: %s",
                    result.tx_hash[:32],
                )
            else:
                # NEW — atomically record the tx_hash.
                # check_and_record_tx uses INSERT OR IGNORE, so if a concurrent
                # request recorded first, is_new=False. In that case, treat it
                # as WITHIN_GRACE (the other request may still be in flight).
                is_new = await self._persistent_guard.check_and_record_tx(result.tx_hash)
                if not is_new:
                    # Concurrent request recorded it first — check if it was already delivered.
                    recheck = await self._persistent_guard.check_tx_status(result.tx_hash)
                    if recheck == TxHashStatus.EXPIRED:
                        self._metrics["replays_rejected"] += 1
                        return self._build_402_response()
                    # Otherwise it's WITHIN_GRACE — fall through to proxy

            # 6. Proxy the request to the target
            self._metrics["payments_verified"] += 1
            logger.info("[GATEWAY] Payment verified (tx: %s) -- proxying to %s", result.tx_hash, self.target_url)
            try:
                proxy_response = await self._proxy_request(request, path)
                # Cache successful responses so grace-window retries get the same answer
                if proxy_response.status_code < 400:
                    await self._persistent_guard.mark_delivered(result.tx_hash)
                    # Extract headers from the Response object
                    resp_headers = {}
                    if hasattr(proxy_response, 'headers') and proxy_response.headers:
                        resp_headers = dict(proxy_response.headers)
                    await self._persistent_guard.cache_response(
                        result.tx_hash,
                        proxy_response.status_code,
                        resp_headers,
                        proxy_response.body,
                    )
                return proxy_response
            except Exception as exc:
                self._metrics["proxy_errors"] += 1
                logger.error("[GATEWAY] Proxy error: %s", exc)
                # Do NOT mark as delivered — buyer can retry within grace window
                return JSONResponse(status_code=502, content={"error": "Bad Gateway"})

        return app

    async def _proxy_request(self, request: Request, path: str) -> Response:
        """Forward the request to the upstream target service."""
        target = f"{self.target_url}/{path}"
        if request.url.query:
            target = f"{target}?{request.url.query}"

        # Read request body
        body = await request.body()

        # P2-3.4: Whitelist-based header forwarding — only pass known-safe headers
        # to prevent X-Forwarded-For spoofing, Cookie leakage, Connection abuse, etc.
        _ALLOWED_HEADERS = {
            "accept", "accept-encoding", "accept-language",
            "content-type", "user-agent", "origin", "referer",
            "cache-control", "if-none-match", "if-modified-since",
            "x-request-id", "x-correlation-id",
        }
        proxy_headers = {}
        for key, value in request.headers.items():
            if key.lower() in _ALLOWED_HEADERS:
                proxy_headers[key] = value

        # Use shared client (falls back to per-request if lifespan not used)
        client = self._http_client
        if client is None:
            client = httpx.AsyncClient(timeout=30.0)

        try:
            upstream_response = await client.request(
                method=request.method,
                url=target,
                headers=proxy_headers,
                content=body if body else None,
            )
        finally:
            # Only close if we created a fallback client
            if self._http_client is None:
                await client.aclose()

        # Build response headers (exclude hop-by-hop)
        response_headers = {}
        skip_response_headers = {"transfer-encoding", "content-encoding", "content-length"}
        for key, value in upstream_response.headers.items():
            if key.lower() not in skip_response_headers:
                response_headers[key] = value

        return Response(
            content=upstream_response.content,
            status_code=upstream_response.status_code,
            headers=response_headers,
        )


def cli_main() -> None:
    """Entry point for `ag402-gateway` CLI command."""
    parser = argparse.ArgumentParser(
        description="x402 Payment Gateway -- adds pay-per-call to any HTTP API",
    )
    parser.add_argument(
        "--target",
        required=True,
        help="URL of the upstream service to protect (e.g. http://localhost:8000)",
    )
    parser.add_argument(
        "--price",
        default="0.02",
        help="Price per call in token units (default: 0.02)",
    )
    parser.add_argument(
        "--address",
        default="",
        help="Recipient wallet address for payments",
    )
    parser.add_argument(
        "--prepaid-signing-key",
        default="",
        help=(
            "HMAC signing key for X-Prepaid-Credential verification "
            "(or set AG402_PREPAID_SIGNING_KEY env var). "
            "Recommend >= 32 random chars: "
            "python -c \"import secrets; print(secrets.token_hex(32))\""
        ),
    )
    parser.add_argument(
        "--chain",
        default="solana",
        help="Blockchain network (default: solana)",
    )
    parser.add_argument(
        "--token",
        default="USDC",
        help="Payment token (default: USDC)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind the gateway (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8001,
        help="Port to bind the gateway (default: 8001)",
    )

    args = parser.parse_args()

    import uvicorn

    # S1-2 FIX: Mode-aware host selection, consistent with `ag402 serve`.
    # If user did not explicitly pass --host, choose based on X402_MODE.
    host = args.host
    is_test = os.getenv("X402_MODE", "test").lower() == "test"
    if host == "127.0.0.1" and not is_test:
        # Production mode: default to 0.0.0.0 (bind all interfaces)
        host = "0.0.0.0"
    elif host == "127.0.0.1" and is_test:
        pass  # Keep 127.0.0.1 in test mode (safe default)

    gateway = X402Gateway(
        target_url=args.target,
        price=args.price,
        chain=args.chain,
        token=args.token,
        address=args.address,
        prepaid_signing_key=args.prepaid_signing_key,
    )
    app = gateway.create_app()

    logger.info(
        "[GATEWAY] Starting x402 gateway on %s:%d -> %s (price: %s %s)",
        host, args.port, args.target, args.price, args.token,
    )

    # B1 FIX: Explicitly use asyncio event loop to avoid uvloop + aiosqlite conflicts.
    uvicorn.run(app, host=host, port=args.port, loop="asyncio")


if __name__ == "__main__":
    cli_main()
