"""Hook tests package."""
