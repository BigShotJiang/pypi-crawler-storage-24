# Groq Whisper Transcribe
This script transcribes audio files using the Whisper model via the Groq API

Usage costs can be found at: https://console.groq.com/docs/model/whisper-large-v3

# Usage

## Install the Requirements

To install the necessary requirements, run the following command:

```sh
pip install groq-whisper-transcribe
```

### FFmpeg

This tool requires FFmpeg for audio processing.

* **macOS / Windows** — FFmpeg is bundled automatically via the `static-ffmpeg` package. No extra installation needed.
* **Linux** — Install FFmpeg using your system package manager:
  ```sh
  # Debian / Ubuntu
  sudo apt install ffmpeg

  # Fedora
  sudo dnf install ffmpeg

  # Arch
  sudo pacman -S ffmpeg
  ```

> On Linux, you can also `pip install static-ffmpeg` if you prefer not to use the system package.

## Typical Usage

```sh
# Transcribe to SRT (English)
groq-whisper-transcribe audio.mp3
# Transcribe Spanish audio
groq-whisper-transcribe audio.aac -l es
# French audio to VTT
groq-whisper-transcribe audio.wav -f vtt -l fr
# Both SRT and VTT
groq-whisper-transcribe audio.wav -f srt vtt
# All three formats
groq-whisper-transcribe audio.wav -f srt vtt txt
# Plain text only
groq-whisper-transcribe audio.wav -f txt
# Custom output path
groq-whisper-transcribe audio.m4a -o result.srt
# Use turbo model
groq-whisper-transcribe audio.mp3 -m whisper-large-v3-turbo
# Set API key interactively
groq-whisper-transcribe --set-key
# Set API key via pipe
echo "gsk_..." | groq-whisper-transcribe --set-key
```

## Arguments

| Argument || Description |
|-|-|-|
| | input | Input audio file path |
| -o | --output | Output file path (default: input with new extension). Ignored when multiple formats are requested |
| -f | --format | Output format(s): srt, vtt, txt (default: srt). Multiple formats can be specified |
| -l | --language | Language code, e.g. en, es, fr, de, ja (default: en) |
| -m | --model | Whisper model name (default: whisper-large-v3) |
| | --set-key | Set the GROQ_API_KEY in ~/.groq (accepts piped input or prompts interactively) |


### API Key

An API Key is required to use this script, and usage incurs a cost. This tool utilizes Groq because of its high speed and low cost. However, if you have the necessary hardware, it is recommended to use the official Whisper version, which is free

The easiest way to set up your API key is using the built-in command:

```sh
# Interactive prompt (key input is hidden)
groq-whisper-transcribe --set-key

# Or pipe the key directly
echo "gsk_..." | groq-whisper-transcribe --set-key
```

This saves the key to `~/.groq`. You can also set it manually by creating the file or using the `GROQ_API_KEY` environment variable.

The file path for `~/.groq` varies by platform:

* **Linux** — `/home/<user>/.groq`
* **macOS** — `/Users/<user>/.groq`
* **Windows** — `C:\Users\<user>\.groq`

The file content should look like:

```
GROQ_API_KEY=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
```
