#!/usr/bin/env python
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
  long_description = fh.read()

setup(
  name="groq-whisper-transcribe",
  version="1.0",
  packages=find_packages(),
  description="A simple script that uses the Groq API to transcribe audio files using the Whisper model",
  entry_points={
    'console_scripts': [
      'groq-whisper-transcribe = groq_whisper_transcribe.__main__:main',
    ],
  },
  url="https://github.com/jfhack/groq-whisper-transcribe",
  install_requires=[
    'groq',
    'python-dotenv',
    'static-ffmpeg; sys_platform != "linux"',
  ],
  long_description=long_description,
  long_description_content_type="text/markdown"
)
