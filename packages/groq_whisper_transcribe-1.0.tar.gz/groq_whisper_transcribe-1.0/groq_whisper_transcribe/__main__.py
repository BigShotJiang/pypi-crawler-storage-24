#!/usr/bin/env python3

import argparse
import getpass
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from groq_whisper_transcribe import Transcriber

GROQ_ENV_PATH = Path.home() / ".groq"


def setup_api_key():
    if not sys.stdin.isatty():
        api_key = sys.stdin.read().strip()
    else:
        api_key = getpass.getpass("Enter your GROQ_API_KEY: ").strip()

    if not api_key:
        print("Error: No API key provided.")
        sys.exit(1)

    GROQ_ENV_PATH.write_text(f"GROQ_API_KEY={api_key}\n", encoding="utf-8")
    print(f"API key saved to {GROQ_ENV_PATH}")


def main():
    parser = argparse.ArgumentParser(
        description="Transcribe audio files using Groq Whisper",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s audio.mp3                    # Transcribe to SRT (English)
  %(prog)s audio.aac -l es              # Transcribe Spanish audio
  %(prog)s audio.wav -f vtt -l fr       # French audio to VTT
  %(prog)s audio.wav -f srt vtt         # Both SRT and VTT
  %(prog)s audio.wav -f srt vtt txt     # All three formats
  %(prog)s audio.wav -f txt             # Plain text only
  %(prog)s audio.m4a -o result.srt      # Custom output path
  %(prog)s audio.mp3 -m whisper-large-v3-turbo  # Use turbo model
  %(prog)s --set-key                    # Set API key interactively
  echo "gsk_..." | %(prog)s --set-key   # Set API key via pipe
        """,
    )
    parser.add_argument("input", nargs="?", help="Input audio file path")
    parser.add_argument("--set-key", action="store_true",
                        help="Set the GROQ_API_KEY in ~/.groq (accepts piped input or prompts interactively)")
    parser.add_argument("-o", "--output", help="Output file path (default: input with new extension). "
                        "When multiple formats are requested, this is ignored.")
    parser.add_argument("-f", "--format", nargs="+", choices=["srt", "vtt", "txt"], default=["srt"],
                        help="Output format(s): srt, vtt, txt (default: srt)")
    parser.add_argument("-l", "--language", default="en",
                        help="Language code, e.g. en, es, fr, de, ja (default: en)")
    parser.add_argument("-m", "--model", default="whisper-large-v3",
                        help="Whisper model name (default: whisper-large-v3)")
    args = parser.parse_args()

    if args.set_key:
        setup_api_key()
        return

    if not args.input:
        parser.error("the following arguments are required: input")

    args.format = list(dict.fromkeys(args.format))

    input_path = Path(args.input)
    if not input_path.is_file():
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    groq_home = GROQ_ENV_PATH
    if groq_home.is_file():
        load_dotenv(groq_home)
    load_dotenv()
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        print("Error: GROQ_API_KEY not found.")
        print("  Set it in ~/.groq, a local .env file, or as an environment variable.")
        sys.exit(1)

    output_paths = {}
    if args.output and len(args.format) == 1:
        output_paths[args.format[0]] = args.output
    else:
        for fmt in args.format:
            output_paths[fmt] = str(input_path.with_suffix(f".{fmt}"))

    Transcriber(api_key=api_key, language=args.language, model=args.model).run(input_path, output_paths)


if __name__ == "__main__":
    main()
