import math
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from groq import Groq

try:
    import static_ffmpeg
    static_ffmpeg.add_paths()
except ImportError:
    pass

MAX_CHUNK_SIZE = 24 * 1024 * 1024
CHUNK_OVERLAP = 3.0


class Transcriber:

    def __init__(self, api_key, language="en", model="whisper-large-v3"):
        self.client = Groq(api_key=api_key)
        self.language = language
        self.model = model

        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            raise RuntimeError(
                "ffmpeg/ffprobe not found. On Linux, install ffmpeg via your package manager "
                "(e.g. sudo apt install ffmpeg). On macOS/Windows, install the package: pip install static-ffmpeg"
            )

    def run(self, input_path, output_paths):
        input_path = Path(input_path)
        formats_str = ", ".join(f.upper() for f in output_paths)
        outputs_str = ", ".join(str(p) for p in output_paths.values())
        print(f"Input:    {input_path}")
        print(f"Output:   {outputs_str}")
        print(f"Format:   {formats_str}")
        print(f"Language: {self.language}")
        print(f"Model:    {self.model}")
        print()

        with tempfile.TemporaryDirectory(prefix="groq_whisper_") as tmp:
            temp_dir = Path(tmp)

            print("Step 1: Preparing audio chunks...")
            chunks = self._split_audio(input_path, temp_dir)
            print(f"  Total chunks: {len(chunks)}\n")

            print(f"Step 2: Transcribing with Groq {self.model}...")
            all_segments = []
            total = 0

            for i, (chunk_path, offset) in enumerate(chunks):
                size_mb = chunk_path.stat().st_size / 1024 / 1024
                print(f"  Chunk {i + 1}/{len(chunks)} "
                      f"(offset: {offset:.1f}s, size: {size_mb:.1f}MB)...", end=" ", flush=True)

                result = self._transcribe_chunk(chunk_path)
                chunk_segments = self._extract_segments(result, offset, chunk_path)
                all_segments.extend(chunk_segments)
                total += len(chunk_segments)
                print(f"got {len(chunk_segments)} segments")

            print(f"\n  Total raw segments: {total}")

            print("\nStep 3: Merging and de-duplicating segments...")
            merged = self._merge_segments(all_segments)
            print(f"  Final segments: {len(merged)}")

            print("\nStep 4: Writing output...")
            writers = {"srt": self._to_srt, "vtt": self._to_vtt, "txt": self._to_txt}
            for fmt, out_path in output_paths.items():
                Path(out_path).write_text(writers[fmt](merged), encoding="utf-8")
                print(f"  Wrote {fmt.upper()}: {out_path}")

            print("\nDone!")
            print(f"  Segments: {len(merged)}")
            if merged:
                print(f"  Duration covered: {merged[-1]['end'] / 60:.1f} min")

    @staticmethod
    def _ffmpeg(*args, check=True, capture_text=False):
        return subprocess.run(
            ["ffmpeg", *args],
            capture_output=True,
            text=capture_text,
            check=check,
        )

    @staticmethod
    def _ffprobe(file_path):
        result = subprocess.run(
            [
                "ffprobe", "-v", "quiet",
                "-show_entries", "format=duration,size",
                "-of", "default=noprint_wrappers=1",
                str(file_path),
            ],
            capture_output=True, text=True, check=True,
        )
        info = {}
        for line in result.stdout.strip().split("\n"):
            key, val = line.split("=")
            info[key] = float(val)
        return info

    @staticmethod
    def _detect_silences(file_path, min_len=0.3, thresh=-35):
        result = Transcriber._ffmpeg(
            "-i", str(file_path),
            "-af", f"silencedetect=noise={thresh}dB:d={min_len}",
            "-f", "null", "-",
            check=False, capture_text=True,
        )
        silences = []
        start = None
        for line in result.stderr.split("\n"):
            if "silence_start:" in line:
                m = re.search(r"silence_start:\s*([\d.]+)", line)
                if m:
                    start = float(m.group(1))
            elif "silence_end:" in line and start is not None:
                m = re.search(r"silence_end:\s*([\d.]+)", line)
                if m:
                    silences.append((start, float(m.group(1))))
                    start = None
        return silences

    @staticmethod
    def _find_nearest_silence(silences, target, tolerance=90.0):
        best, best_diff = None, float("inf")
        for s, e in silences:
            mid = (s + e) / 2
            diff = abs(mid - target)
            if diff < best_diff and diff <= tolerance:
                best, best_diff = mid, diff
        return best if best is not None else target

    @staticmethod
    def _extract_chunk(input_path, output_path, start, end, bitrate="48k"):
        Transcriber._ffmpeg(
            "-y", "-i", str(input_path),
            "-ss", f"{start:.3f}", "-to", f"{end:.3f}",
            "-vn", "-acodec", "libmp3lame",
            "-b:a", bitrate, "-ar", "16000", "-ac", "1",
            str(output_path),
        )
        return output_path

    def _split_audio(self, file_path, temp_dir):
        info = self._ffprobe(file_path)
        duration, file_size = info["duration"], info["size"]

        if file_size <= MAX_CHUNK_SIZE:
            single = temp_dir / "single.mp3"
            self._extract_chunk(file_path, single, 0, duration)
            if single.stat().st_size <= MAX_CHUNK_SIZE:
                print(f"  File fits in a single chunk ({single.stat().st_size / 1024 / 1024:.1f}MB)")
                return [(single, 0.0)]
            single.unlink()

        sample_dur = min(60, duration)
        sample = temp_dir / "sample.mp3"
        self._extract_chunk(file_path, sample, 0, sample_dur)
        bytes_per_sec = sample.stat().st_size / sample_dur
        sample.unlink()

        target_chunk_dur = (MAX_CHUNK_SIZE / bytes_per_sec) * 0.90
        num_chunks = math.ceil(duration / (target_chunk_dur - CHUNK_OVERLAP))

        print(f"  Duration: {duration:.0f}s ({duration/60:.1f}min)")
        print(f"  Estimated bytes/sec (compressed): {bytes_per_sec:.0f}")
        print(f"  Target chunk duration: {target_chunk_dur:.0f}s ({target_chunk_dur/60:.1f}min)")
        print(f"  Estimated chunks: {num_chunks}")

        print("  Detecting silence points for clean splits...")
        silences = self._detect_silences(file_path)
        print(f"  Found {len(silences)} silence periods")

        split_starts = [0.0]
        for i in range(1, num_chunks):
            target_time = i * (target_chunk_dur - CHUNK_OVERLAP)
            if target_time >= duration:
                break
            point = self._find_nearest_silence(silences, target_time)
            split_starts.append(max(0, point - CHUNK_OVERLAP))

        boundaries = []
        for i, start in enumerate(split_starts):
            end = (split_starts[i + 1] + CHUNK_OVERLAP) if i + 1 < len(split_starts) else duration
            boundaries.append((start, min(end, duration)))

        min_chunk_dur = max(120.0, target_chunk_dur * 0.1)
        if len(boundaries) > 1:
            last_s, last_e = boundaries[-1]
            if (last_e - last_s) < min_chunk_dur:
                prev_s, _ = boundaries[-2]
                boundaries[-2] = (prev_s, last_e)
                boundaries.pop()
                print(f"  Merged short trailing chunk ({last_e - last_s:.0f}s) into previous one")

        chunks = []
        for i, (start, end) in enumerate(boundaries):
            chunk_path = temp_dir / f"chunk_{i:04d}.mp3"
            print(f"  Extracting chunk {i + 1}/{len(boundaries)}: "
                  f"{start:.1f}s - {end:.1f}s ({(end - start):.0f}s)")

            self._extract_chunk(file_path, chunk_path, start, end)
            chunk_size = chunk_path.stat().st_size

            if chunk_size > MAX_CHUNK_SIZE:
                print(f"    WARNING: Chunk too large ({chunk_size / 1024 / 1024:.1f}MB), re-encoding at 32kbps...")
                small = temp_dir / f"chunk_{i:04d}_small.mp3"
                self._extract_chunk(chunk_path, small, start, end, bitrate="32k")
                chunk_path.unlink()
                chunk_path = small
                chunk_size = chunk_path.stat().st_size

            print(f"    Size: {chunk_size / 1024 / 1024:.1f}MB")

            if chunk_size < 10 * 1024:
                print(f"    Skipping: chunk file too small ({chunk_size} bytes)")
                continue

            chunks.append((chunk_path, start))

        return chunks

    def _transcribe_chunk(self, chunk_path, max_retries=5):
        for attempt in range(max_retries):
            try:
                data = chunk_path.read_bytes()
                return self.client.audio.transcriptions.create(
                    file=(chunk_path.name, data),
                    model=self.model,
                    language=self.language,
                    response_format="verbose_json",
                    temperature=0.0,
                )
            except Exception as e:
                err = str(e)
                if "400" in err or "invalid_request" in err.lower():
                    raise
                if "rate_limit" in err.lower() or "429" in err:
                    wait = min(2 ** attempt * 5, 60)
                    print(f"    Rate limited, waiting {wait}s (attempt {attempt + 1}/{max_retries})...")
                elif attempt < max_retries - 1:
                    wait = 2 ** attempt
                    print(f"    Error: {e}")
                    print(f"    Retrying in {wait}s (attempt {attempt + 1}/{max_retries})...")
                else:
                    raise
                time.sleep(wait)

    def _extract_segments(self, result, offset, chunk_path):
        if hasattr(result, "segments") and result.segments:
            return [
                {"start": s["start"] + offset, "end": s["end"] + offset, "text": s["text"]}
                for s in result.segments
            ]
        if hasattr(result, "text") and result.text:
            info = self._ffprobe(chunk_path)
            return [{"start": offset, "end": offset + info["duration"], "text": result.text}]
        return []

    @staticmethod
    def _merge_segments(all_segments):
        if not all_segments:
            return []
        all_segments.sort(key=lambda s: s["start"])
        merged = [all_segments[0]]
        for seg in all_segments[1:]:
            prev = merged[-1]
            overlap = prev["end"] - seg["start"]
            if overlap > 0.5:
                if seg["end"] > prev["end"] + 0.5:
                    seg = {**seg, "start": prev["end"]}
                    if seg["start"] < seg["end"]:
                        merged.append(seg)
            else:
                merged.append(seg)
        return merged

    @staticmethod
    def _format_ts(seconds, sep=","):
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = min(int(round((seconds % 1) * 1000)), 999)
        return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"

    @classmethod
    def _to_subtitles(cls, segments, sep=",", header=None):
        lines = [header, ""] if header else []
        for i, seg in enumerate(segments, 1):
            text = seg["text"].strip()
            if not text:
                continue
            lines.append(str(i))
            lines.append(f"{cls._format_ts(seg['start'], sep)} --> {cls._format_ts(seg['end'], sep)}")
            lines.append(text)
            lines.append("")
        return "\n".join(lines) + "\n"

    @classmethod
    def _to_srt(cls, segments):
        return cls._to_subtitles(segments, sep=",")

    @classmethod
    def _to_vtt(cls, segments):
        return cls._to_subtitles(segments, sep=".", header="WEBVTT")

    @staticmethod
    def _to_txt(segments):
        return "\n".join(s["text"].strip() for s in segments if s["text"].strip()) + "\n"
