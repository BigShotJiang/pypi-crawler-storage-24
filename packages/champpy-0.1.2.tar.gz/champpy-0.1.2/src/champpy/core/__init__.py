"""Core models and logic."""
