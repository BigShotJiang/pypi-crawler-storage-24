class RDMOException(Exception):
    pass
