# tecjustica-transcribe

CLI para transcrição de audiências judiciais com WhisperX e diarização de falantes.

## Pré-requisitos

- GPU NVIDIA com **6 GB+ de VRAM** (ex: RTX 3050, RTX 3060)
- Driver NVIDIA instalado
- ffmpeg instalado (`sudo apt install ffmpeg`)
- Python 3.10 a 3.13

### Token HuggingFace (para identificar falantes)

A diarização (identificar quem está falando) usa o modelo [pyannote](https://huggingface.co/pyannote/speaker-diarization-community-1), que exige um token gratuito do HuggingFace:

1. Crie uma conta em https://huggingface.co
2. Aceite os termos do modelo em https://huggingface.co/pyannote/speaker-diarization-community-1
3. Gere um token em https://huggingface.co/settings/tokens

O comando `init` vai pedir esse token e salvá-lo automaticamente.

> Sem o token, você ainda pode transcrever usando `--sem-diarizacao` — a transcrição funciona, só não identifica os falantes.

## Instalação

```bash
uv tool install tecjustica-transcribe
```

Ou com pip:

```bash
pip install tecjustica-transcribe
```

## Uso

```bash
# 1. Diagnosticar e preparar a máquina (pede o token na primeira vez)
tecjustica-transcribe init

# 2. Transcrever uma audiência (gera .txt, .srt e .json)
tecjustica-transcribe transcrever audiencia.mp4

# Transcrever sem identificar falantes (não precisa de token)
tecjustica-transcribe transcrever audiencia.mp4 --sem-diarizacao

# Escolher pasta de saída
tecjustica-transcribe transcrever audiencia.mp4 --output ./minha-pasta
```

## Saída

O comando gera 3 arquivos na pasta `./transcricoes/`:

- **`.txt`** — texto puro com `[SPEAKER_00]`, `[SPEAKER_01]`, etc.
- **`.srt`** — legendas com timestamps (compatível com players de vídeo)
- **`.json`** — dados completos com timestamps por palavra e falantes
