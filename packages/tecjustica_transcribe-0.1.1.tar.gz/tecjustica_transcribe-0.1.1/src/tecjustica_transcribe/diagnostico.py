"""Lógica do comando init — diagnóstico e setup."""

from __future__ import annotations

import json
import platform
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

CONFIG_DIR = Path.home() / ".config" / "tecjustica"
CONFIG_FILE = CONFIG_DIR / "config.json"

console = Console()


@dataclass
class CheckResult:
    nome: str
    ok: bool
    detalhe: str = ""


def _carregar_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _salvar_config(config: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def verificar_nvidia() -> CheckResult:
    """Verifica driver NVIDIA via nvidia-smi."""
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            capture_output=True,
            text=True,
        )
        if r.returncode == 0:
            versao = r.stdout.strip().split("\n")[0]
            return CheckResult("Driver NVIDIA", True, versao)
        return CheckResult("Driver NVIDIA", False, "nvidia-smi falhou")
    except FileNotFoundError:
        return CheckResult("Driver NVIDIA", False, "nvidia-smi não encontrado")


def verificar_cuda() -> CheckResult:
    """Verifica CUDA via PyTorch."""
    try:
        import torch

        if torch.cuda.is_available():
            versao = torch.version.cuda or "desconhecida"
            return CheckResult("CUDA", True, versao)
        return CheckResult("CUDA", False, "CUDA não disponível no PyTorch")
    except ImportError:
        return CheckResult("CUDA", False, "PyTorch não instalado")


def verificar_gpu() -> CheckResult:
    """Verifica GPU e VRAM disponível."""
    try:
        import torch

        if torch.cuda.is_available():
            nome = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory
            vram_gb = vram / (1024**3)
            detalhe = f"{nome} ({vram_gb:.1f} GB)"
            if vram_gb < 5.5:
                return CheckResult(
                    "GPU", False, f"{detalhe} — mínimo 6 GB de VRAM"
                )
            return CheckResult("GPU", True, detalhe)
        return CheckResult("GPU", False, "Nenhuma GPU CUDA detectada")
    except ImportError:
        return CheckResult("GPU", False, "PyTorch não instalado")


def verificar_ffmpeg() -> CheckResult:
    """Verifica ffmpeg instalado."""
    try:
        r = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
        )
        if r.returncode == 0:
            primeira_linha = r.stdout.split("\n")[0]
            # Ex: "ffmpeg version 6.1.1 ..."
            partes = primeira_linha.split()
            versao = partes[2] if len(partes) >= 3 else "instalado"
            return CheckResult("ffmpeg", True, versao)
        return CheckResult("ffmpeg", False, "ffmpeg falhou")
    except FileNotFoundError:
        return CheckResult("ffmpeg", False, "não encontrado — instale com: sudo apt install ffmpeg")


def verificar_python() -> CheckResult:
    """Verifica versão do Python."""
    versao = platform.python_version()
    major, minor = sys.version_info[:2]
    if major == 3 and 10 <= minor < 14:
        return CheckResult("Python", True, versao)
    return CheckResult("Python", False, f"{versao} — requer >=3.10,<3.14")


def verificar_token_hf() -> CheckResult:
    """Verifica se o token HuggingFace está configurado."""
    config = _carregar_config()
    token = config.get("hf_token", "")
    if token:
        return CheckResult("Token HuggingFace", True, f"{token[:8]}...")
    return CheckResult("Token HuggingFace", False, "Não configurado")


def configurar_token_hf() -> None:
    """Pede o token HuggingFace ao usuário e salva."""
    console.print()
    console.print(
        "[yellow]⚠️  Token HuggingFace necessário para diarização.[/yellow]"
    )
    console.print(
        "Obtenha seu token em: [link=https://huggingface.co/settings/tokens]"
        "huggingface.co/settings/tokens[/link]"
    )
    console.print(
        "Aceite os termos em: [link=https://huggingface.co/pyannote/speaker-diarization-3.1]"
        "huggingface.co/pyannote/speaker-diarization-3.1[/link]"
    )
    console.print()

    token = console.input("Cole seu token: ").strip()
    if token:
        config = _carregar_config()
        config["hf_token"] = token
        _salvar_config(config)
        console.print("[green]✅ Token salvo![/green]")
    else:
        console.print("[red]Token vazio — diarização não funcionará.[/red]")


def baixar_modelos() -> CheckResult:
    """Pré-baixa os modelos WhisperX para evitar surpresa na primeira transcrição."""
    try:
        console.print("\n[cyan]⬇️  Verificando modelos WhisperX...[/cyan]")
        from faster_whisper import WhisperModel

        console.print("   Carregando large-v2 (pode demorar no primeiro uso)...")
        WhisperModel("large-v2", device="cuda", compute_type="float16")
        return CheckResult("Modelos", True, "large-v2 pronto")
    except Exception as e:
        return CheckResult("Modelos", False, str(e)[:80])


def _mostrar_relatorio(resultados: list[CheckResult]) -> None:
    """Exibe o relatório de diagnóstico como tabela rich."""
    table = Table(show_header=False, border_style="cyan", pad_edge=False)
    table.add_column("Item", min_width=20)
    table.add_column("Status", min_width=40)

    for r in resultados:
        icone = "[green]✅[/green]" if r.ok else "[red]❌[/red]"
        table.add_row(r.nome, f"{icone} {r.detalhe}")

    panel = Panel(
        table,
        title="[bold]TecJustiça Transcribe — Diagnóstico[/bold]",
        border_style="cyan",
    )
    console.print(panel)


def executar_diagnostico() -> None:
    """Verifica pré-requisitos e prepara a máquina."""
    resultados: list[CheckResult] = []

    # Verificações rápidas
    resultados.append(verificar_python())
    resultados.append(verificar_nvidia())
    resultados.append(verificar_cuda())
    resultados.append(verificar_gpu())
    resultados.append(verificar_ffmpeg())
    resultados.append(verificar_token_hf())

    _mostrar_relatorio(resultados)

    # Token HuggingFace — oferecer configuração se ausente
    check_token = resultados[-1]
    if not check_token.ok:
        configurar_token_hf()

    # Download de modelos — só se GPU estiver OK
    check_gpu = next((r for r in resultados if r.nome == "GPU"), None)
    if check_gpu and check_gpu.ok:
        resultado_modelos = baixar_modelos()
        console.print()
        icone = "[green]✅[/green]" if resultado_modelos.ok else "[red]❌[/red]"
        console.print(f"Modelos: {icone} {resultado_modelos.detalhe}")
    else:
        console.print(
            "\n[yellow]⚠️  GPU não detectada — pulando download de modelos.[/yellow]"
        )

    # Resumo
    falhas = [r for r in resultados if not r.ok]
    console.print()
    if not falhas:
        console.print("[bold green]✅ Tudo pronto para transcrever![/bold green]")
    else:
        console.print(
            f"[bold yellow]⚠️  {len(falhas)} problema(s) encontrado(s). "
            "Resolva antes de transcrever.[/bold yellow]"
        )
