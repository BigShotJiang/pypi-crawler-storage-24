"""Lógica do comando transcrever — transcrição com diarização."""

from __future__ import annotations

import json
import logging
import os
import sys
import warnings
from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from tecjustica_transcribe.diagnostico import _carregar_config

console = Console()


def _obter_batch_size() -> int:
    """Ajusta batch_size automaticamente baseado na VRAM."""
    import torch

    if not torch.cuda.is_available():
        return 4
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    if vram_gb >= 10:
        return 16
    if vram_gb >= 6:
        return 8
    return 4


def _obter_token_hf() -> str | None:
    """Lê o token HuggingFace salvo pelo init."""
    config = _carregar_config()
    return config.get("hf_token") or None


def _formatar_timestamp_srt(segundos: float) -> str:
    """Converte segundos para formato SRT: HH:MM:SS,mmm"""
    h = int(segundos // 3600)
    m = int((segundos % 3600) // 60)
    s = int(segundos % 60)
    ms = int((segundos % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _salvar_srt(segments: list[dict], caminho: Path) -> None:
    """Gera arquivo .srt com timestamps e falantes."""
    linhas: list[str] = []
    for i, seg in enumerate(segments, 1):
        inicio = _formatar_timestamp_srt(seg["start"])
        fim = _formatar_timestamp_srt(seg["end"])
        falante = seg.get("speaker", "")
        texto = seg.get("text", "").strip()
        prefixo = f"[{falante}] " if falante else ""
        linhas.append(f"{i}")
        linhas.append(f"{inicio} --> {fim}")
        linhas.append(f"{prefixo}{texto}")
        linhas.append("")
    caminho.write_text("\n".join(linhas), encoding="utf-8")


def _salvar_txt(segments: list[dict], caminho: Path) -> None:
    """Gera arquivo .txt com texto puro e identificação de falantes."""
    linhas: list[str] = []
    falante_atual = ""
    for seg in segments:
        falante = seg.get("speaker", "")
        texto = seg.get("text", "").strip()
        if falante and falante != falante_atual:
            falante_atual = falante
            linhas.append(f"\n[{falante}]")
        linhas.append(texto)
    caminho.write_text("\n".join(linhas).strip(), encoding="utf-8")


def _salvar_json(segments: list[dict], caminho: Path) -> None:
    """Gera arquivo .json com dados completos."""
    dados = {
        "segments": segments,
        "total_segments": len(segments),
    }
    caminho.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")


def executar_transcricao(
    arquivo: str,
    output: str,
    *,
    sem_diarizacao: bool = False,
) -> None:
    """Transcreve um arquivo MP4 usando WhisperX."""
    arquivo_path = Path(arquivo)
    output_path = Path(output)

    # Validações
    if not arquivo_path.exists():
        console.print(f"[red]❌ Arquivo não encontrado: {arquivo}[/red]")
        sys.exit(1)

    token: str | None = None
    if not sem_diarizacao:
        token = _obter_token_hf()
        if not token:
            console.print(
                "[red]❌ Token HuggingFace não configurado.[/red]\n"
                "Execute [bold]tecjustica-transcribe init[/bold] primeiro,\n"
                "ou use [bold]--sem-diarizacao[/bold] para transcrever sem identificar falantes."
            )
            sys.exit(1)

    # Criar pasta de saída
    output_path.mkdir(parents=True, exist_ok=True)
    nome_base = arquivo_path.stem

    console.print(f"\n[bold cyan]🎙️  Transcrevendo:[/bold cyan] {arquivo_path.name}")

    try:
        # Suprimir warnings inofensivos de torchcodec, onnxruntime e pyannote
        warnings.filterwarnings("ignore", message=".*torchcodec.*")
        warnings.filterwarnings("ignore", message=".*TensorFloat-32.*")
        warnings.filterwarnings("ignore", message=".*std\\(\\).*degrees of freedom.*")
        logging.getLogger("onnxruntime").setLevel(logging.ERROR)
        os.environ.setdefault("ONNXRUNTIME_LOG_SEVERITY_LEVEL", "3")

        import torch
        import whisperx

        device = "cuda" if torch.cuda.is_available() else "cpu"
        compute_type = "float16" if device == "cuda" else "int8"
        batch_size = _obter_batch_size()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            # 1. Carregar modelo
            task = progress.add_task("Carregando modelo WhisperX...", total=None)
            model = whisperx.load_model(
                "large-v2",
                device=device,
                compute_type=compute_type,
                language="pt",
            )
            progress.update(task, description="Modelo carregado ✓")

            # 2. Carregar áudio
            progress.update(task, description="Carregando áudio...")
            audio = whisperx.load_audio(str(arquivo_path))
            progress.update(task, description="Áudio carregado ✓")

            # 3. Transcrever
            progress.update(task, description=f"Transcrevendo (batch_size={batch_size})...")
            result = model.transcribe(audio, batch_size=batch_size)
            progress.update(task, description="Transcrição concluída ✓")

            # 4. Alinhar timestamps
            progress.update(task, description="Alinhando timestamps...")
            model_a, metadata = whisperx.load_align_model(
                language_code="pt", device=device
            )
            result = whisperx.align(
                result["segments"], model_a, metadata, audio, device=device
            )
            progress.update(task, description="Timestamps alinhados ✓")

            # 5. Diarizar (se solicitado)
            if not sem_diarizacao:
                progress.update(task, description="Identificando falantes...")
                from whisperx.diarize import DiarizationPipeline

                diarize_model = DiarizationPipeline(
                    token=token, device=device
                )
                diarize_segments = diarize_model(audio)
                result = whisperx.assign_word_speakers(diarize_segments, result)
                progress.update(task, description="Falantes identificados ✓")

            progress.update(task, description="Concluído ✓")

        segments = result.get("segments", result) if isinstance(result, dict) else result

        # 6. Salvar arquivos
        caminho_srt = output_path / f"{nome_base}.srt"
        caminho_txt = output_path / f"{nome_base}.txt"
        caminho_json = output_path / f"{nome_base}.json"

        _salvar_srt(segments, caminho_srt)
        _salvar_txt(segments, caminho_txt)
        _salvar_json(segments, caminho_json)

        console.print(f"\n[bold green]✅ Transcrição concluída![/bold green]")
        console.print(f"[bold]📁 Arquivos gerados em {output_path}/:[/bold]")
        console.print(f"   • {caminho_txt.name}  (texto puro)")
        console.print(f"   • {caminho_srt.name}  (legendas com timestamps)")
        console.print(f"   • {caminho_json.name} (dados completos + falantes)")

    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            console.print(
                "\n[red]❌ Memória da GPU insuficiente (OOM).[/red]\n"
                "Tente fechar outras aplicações ou use um vídeo mais curto."
            )
        else:
            console.print(f"\n[red]❌ Erro durante transcrição: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"\n[red]❌ Erro durante transcrição: {e}[/red]")
        sys.exit(1)
