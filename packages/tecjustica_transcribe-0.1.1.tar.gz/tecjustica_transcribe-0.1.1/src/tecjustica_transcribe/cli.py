"""CLI principal — comandos init e transcrever."""

import click

from tecjustica_transcribe import __version__


@click.group()
@click.version_option(version=__version__, prog_name="tecjustica-transcribe")
def main() -> None:
    """TecJustiça Transcribe — transcrição de audiências judiciais com WhisperX."""


@main.command()
def init() -> None:
    """Diagnostica e prepara a máquina para transcrição."""
    from tecjustica_transcribe.diagnostico import executar_diagnostico

    executar_diagnostico()


@main.command()
@click.argument("arquivo", type=click.Path(exists=True))
@click.option("--output", "-o", default="./transcricoes", help="Pasta de saída.")
@click.option("--sem-diarizacao", is_flag=True, help="Transcrever sem identificar falantes.")
def transcrever(arquivo: str, output: str, sem_diarizacao: bool) -> None:
    """Transcreve um arquivo MP4 de audiência judicial."""
    from tecjustica_transcribe.transcrever import executar_transcricao

    executar_transcricao(arquivo, output, sem_diarizacao=sem_diarizacao)
