import base64
import os
import zlib
import random
import string
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend

# ===================== CONFIG =====================
ITERATIONS = 200_000
CUSTOM_PASSES = 3
CHUNK_SIZE = 5000 

# ===================== PASSWORD GENERATOR =====================
def generate_password(length: int = 24) -> str:
    """Generates a high-entropy secure password."""
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.SystemRandom().choice(chars) for _ in range(length))

# ===================== CORE CRYPTO FUNCTIONS =====================
def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
        backend=default_backend()
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def _aes_encrypt(data: bytes, password: str) -> bytes:
    salt = os.urandom(16)
    key = _derive_key(password, salt)
    return salt + Fernet(key).encrypt(data)

def _aes_decrypt(data: bytes, password: str) -> bytes:
    salt, encrypted = data[:16], data[16:]
    key = _derive_key(password, salt)
    return Fernet(key).decrypt(encrypted)

def _custom_encode(data: bytes, password: str, r: int) -> bytes:
    shift = (sum(password.encode()) + r) % 256
    return bytes((b + shift) % 256 for b in data)

def _custom_decode(data: bytes, password: str, r: int) -> bytes:
    shift = (sum(password.encode()) + r) % 256
    return bytes((b - shift) % 256 for b in data)

def _rotate_bits(data: bytes, password: str, rev=False) -> bytes:
    r = len(password) % 8
    if r == 0: return data
    out = bytearray()
    for b in data:
        out.append(((b >> r | b << (8 - r)) if rev else (b << r | b >> (8 - r))) & 0xFF)
    return bytes(out)

def _substitution_table(password: str) -> bytes:
    seed = sum(password.encode())
    table = list(range(256))
    for i in range(256):
        j = (i + seed) % 256
        table[i], table[j] = table[j], table[i]
    return bytes(table)

def _substitute(data: bytes, table: bytes, rev=False) -> bytes:
    if not rev: return bytes(table[b] for b in data)
    inv = bytearray(256)
    for i, v in enumerate(table): inv[v] = i
    return bytes(inv[b] for b in data)

# ===================== MAIN WRAPPERS =====================
def _encrypt_text(raw_text: str, password: str) -> str:
    chunks = [raw_text[i:i+CHUNK_SIZE] for i in range(0, len(raw_text), CHUNK_SIZE)]
    encrypted_chunks = []
    table = _substitution_table(password)
    
    for chunk in chunks:
        data = chunk.encode()
        for i in range(CUSTOM_PASSES): 
            data = _custom_encode(data, password, i)
        data = _rotate_bits(data, password)
        data = zlib.compress(data)
        data = _aes_encrypt(data, password)
        data = _substitute(data, table)
        encrypted_chunks.append(base64.b64encode(data).decode())
    
    return "\n".join(encrypted_chunks)

def _decrypt_text(encrypted_text: str, password: str) -> str:
    chunks = encrypted_text.strip().split("\n")
    decrypted_chunks = []
    table = _substitution_table(password)
    
    for chunk in chunks:
        data = base64.b64decode(chunk)
        data = _substitute(data, table, True)
        data = _aes_decrypt(data, password)
        data = zlib.decompress(data)
        data = _rotate_bits(data, password, True)
        for i in reversed(range(CUSTOM_PASSES)): 
            data = _custom_decode(data, password, i)
        decrypted_chunks.append(data.decode())
    
    return "".join(decrypted_chunks)

# ===================== EXPORTED FUNCTIONS =====================

def password_gen() -> str:
    """Returns a safe random password."""
    return generate_password()

def encrypt(raw_text: str, password: str) -> str:
    """
    Encrypts text using AES-256 and custom bit rotation.
    :param raw_text: The string message to be encrypted.
    :param password: The secret key for encryption.
    :return: A base64 encoded string of encrypted chunks.
    """
    return _encrypt_text(raw_text, password)

def decrypt(encrypted_text: str, password: str) -> str:
    """
    Decrypts text using AES-256 and custom bit rotation.
    :param encrypted_text: The string message to be decrypted.
    :param password: The secret key used during encryption.
    :return: A plain decoded string.
    """
    return _decrypt_text(encrypted_text, password)
