"""
HITLInterceptor - Terminal-based Human-in-the-Loop for development and testing.

Hooks into the real agentic loop via PRE_ACT so the LLM-decided tool calls
are intercepted automatically — no need to manually call `agent.act()`.

Usage:
    from cogent.interceptors import HITLInterceptor

    agent = Agent(
        name="assistant",
        model=model,
        tools=[delete_file, write_file, read_file],
        interrupt_on={"delete_file": True, "write_file": True},
        intercept=[HITLInterceptor()],
    )

    # When agent.run() triggers delete_file, you'll be prompted in the terminal.
    result = await agent.run("Clean up /tmp and delete old logs")
"""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from cogent.agent.hitl import should_interrupt
from cogent.interceptors.base import (
    InterceptContext,
    Interceptor,
    InterceptResult,
)

# Same type as agent config interrupt_on
InterruptRule = bool | Callable[[str, dict[str, Any]], bool]


@dataclass
class HITLInterceptor(Interceptor):
    """Terminal-based HITL interceptor for development and testing.

    Intercepts tool calls during agent.run() — not just agent.act() — so
    human approval happens naturally as the LLM decides which tools to call.

    Checks `interrupt_on` rules (same format as Agent's `interrupt_on` config).
    Falls back to the agent's own `interrupt_on` config when none is provided.

    Decisions:
        y / enter  — Approve: run the tool as-is
        n          — Reject: optionally provide feedback so the LLM can replan
        e          — Edit: modify args as JSON before running
        a          — Abort: stop the entire agent run

    Attributes:
        interrupt_on: Tool-name → rule mapping. None = use agent's config.
        show_args: Whether to display tool arguments in the prompt.

    Example:
        # Use agent's interrupt_on config (most common)
        agent = Agent(
            interrupt_on={"delete_file": True},
            intercept=[HITLInterceptor()],
        )

        # Or override with explicit rules on the interceptor
        agent = Agent(
            intercept=[HITLInterceptor(interrupt_on={"*": True})],
        )
    """

    interrupt_on: dict[str, InterruptRule] | None = None
    show_args: bool = True
    _approved: int = field(default=0, repr=False, compare=False)
    _rejected: int = field(default=0, repr=False, compare=False)

    @property
    def approved(self) -> int:
        """Number of tool calls approved in this run."""
        return self._approved

    @property
    def rejected(self) -> int:
        """Number of tool calls rejected in this run."""
        return self._rejected

    async def pre_run(self, ctx: InterceptContext) -> InterceptResult:
        self._approved = 0
        self._rejected = 0
        return InterceptResult.ok()

    async def pre_act(self, ctx: InterceptContext) -> InterceptResult:
        tool_name = ctx.tool_name or ""
        args = ctx.tool_args or {}

        # Resolve which interrupt_on rules to apply
        rules = self.interrupt_on
        if rules is None:
            rules = getattr(getattr(ctx.agent, "config", None), "interrupt_on", None)

        if not should_interrupt(tool_name, args, rules):
            return InterceptResult.ok()

        return await self._prompt(tool_name, args)

    async def _prompt(self, tool_name: str, args: dict[str, Any]) -> InterceptResult:
        """Display a terminal prompt and return the human's decision."""
        import asyncio

        print("\n⏸️  HITL approval required")
        print(f"   Tool : {tool_name}")
        if self.show_args and args:
            args_str = json.dumps(args, indent=6, default=str)
            print(f"   Args : {args_str}")
        print("   [y] approve  [n] reject  [e] edit args  [a] abort")

        while True:
            try:
                raw = await asyncio.to_thread(input, "   Decision [y/n/e/a]: ")
            except (EOFError, KeyboardInterrupt):
                raw = "a"

            choice = raw.strip().lower() or "y"

            if choice == "y":
                self._approved += 1
                print(f"   ✅ Approved: {tool_name}")
                return InterceptResult.ok()

            if choice == "n":
                self._rejected += 1
                feedback = await self._ask_feedback()
                reason = (
                    f" Reason: {feedback}"
                    if feedback
                    else " Please suggest an alternative approach."
                )
                print(f"   ❌ Rejected: {tool_name}")
                return InterceptResult.stop(
                    f"Human declined the {tool_name} call.{reason}"
                )

            if choice == "e":
                new_args = await self._edit_args(args)
                if new_args is None:
                    print("   ⚠️  Invalid JSON — keeping original args")
                    continue
                self._approved += 1
                print(f"   ✏️  Approved with edits: {tool_name}")
                return InterceptResult.modify_args(new_args)

            if choice == "a":
                print("   🛑 Aborting agent run")
                return InterceptResult.stop("Agent run aborted by human oversight.")

            print("   Please enter y, n, e, or a")

    async def _ask_feedback(self) -> str:
        """Prompt for optional rejection feedback."""
        import asyncio

        try:
            raw = await asyncio.to_thread(
                input, "   Feedback (optional, Enter to skip): "
            )
            return raw.strip()
        except (EOFError, KeyboardInterrupt):
            return ""

    async def _edit_args(self, current_args: dict[str, Any]) -> dict[str, Any] | None:
        """Prompt user to supply modified args as JSON."""
        import asyncio

        current_json = json.dumps(current_args, indent=2, default=str)
        print(f"\n   Current args:\n{current_json}")
        print("   Enter new args as JSON (single line):")

        try:
            raw = await asyncio.to_thread(input, "   New args: ")
            return json.loads(raw.strip())
        except (json.JSONDecodeError, EOFError):
            return None
