"""
Agent - an autonomous entity that can think, act, and communicate.
"""

from __future__ import annotations

import asyncio
from contextvars import ContextVar
import inspect
import json
import uuid
from collections.abc import AsyncIterator, Callable, Coroutine, Sequence
from io import StringIO
from typing import (
    TYPE_CHECKING,
    Any,
)

from cogent.agent.config import AgentConfig
from cogent.agent.output import (
    ResponseSchema,
)
from cogent.agent.reasoning import (
    ReasoningConfig,
)
from cogent.agent.state import AgentState
from cogent.core.enums import AgentRole, AgentStatus
from cogent.core.messages import AIMessage, HumanMessage, SystemMessage
from cogent.core.response import (
    ErrorInfo,
    Response,
    ResponseMetadata,
    TokenUsage,
)
from cogent.core.utils import generate_id, model_identifier, now_utc
from cogent.models.base import BaseChatModel
from cogent.tools.base import BaseTool

if TYPE_CHECKING:
    from cogent.agent.resilience import ResilienceConfig, ToolResilience
    from cogent.agent.streaming import StreamChunk, StreamEvent, StreamMode
    from cogent.core.context import RunContext
    from cogent.graph import GraphView
    from cogent.memory.acc import AgentCognitiveCompressor
    from cogent.memory.cache import SemanticCache
    from cogent.observability.core.bus import EventBus
    from cogent.observability import Observer
    from cogent.observability.progress import ProgressTracker
    from cogent.tools.deferred import DeferredToolManager
    from cogent.tools.registry import ToolRegistry

# Import taskboard (real implementation)
from cogent.agent.taskboard import (
    TASKBOARD_INSTRUCTIONS,
    TaskBoard,
    TaskBoardConfig,
    create_taskboard_tools,
)

# Task type for execute_task (legacy multi-agent feature)
if TYPE_CHECKING:

    class Task:
        id: str
        name: str
        description: str | None
        tool: str | None
        args: dict


class Agent:
    """
    An autonomous entity that can think, act, and communicate.

    Agents are the primary actors in the system. Each agent has:
    - A unique identity and role
    - Configuration defining its capabilities
    - Runtime state tracking its activity
    - Access to tools and the event bus

    Agents communicate through the event bus and can:
    - Receive and process tasks
    - Use tools to accomplish goals
    - Spawn subtasks for complex work
    - Send messages to other agents

    Simplified API (recommended):
        ```python
        from cogent.models import ChatModel
        from cogent.tools import tool

        @tool
        def search(query: str) -> str:
            '''Search for information.'''
            return f"Results for {query}"

        model = ChatModel(model="gpt-4o")

        agent = Agent(
            name="Researcher",
            model=model,
            tools=[search],  # Pass tool functions directly
            description="Researches topics",
        )

        result = await agent.think("What should I research?")
        ```

    Advanced API (with AgentConfig):
        ```python
        from cogent import Agent, AgentConfig, AgentRole

        config = AgentConfig(
            name="Writer",
            role=AgentRole.WORKER,
            model=model,
            tools=["write_poem", "write_story"],
            resilience_config=ResilienceConfig.aggressive(),
        )

        agent = Agent(config=config, event_bus=event_bus)
        ```

    Standalone usage:
        ```python
        from cogent import Agent

        agent = Agent(name="Worker", model="gpt4", tools=[my_tool])
        result = await agent.run("Do something")
        ```
    """

    def __init__(
        self,
        *,
        # Core parameters
        name: str,
        model: BaseChatModel | str | None = None,
        model_kwargs: dict[str, Any] | None = None,
        description: str = "",
        instructions: str | None = None,
        tools: Sequence[BaseTool | str | Callable] | None = None,
        capabilities: Sequence[BaseTool | str | Callable | type] | None = None,
        subagents: dict[str, Agent] | Sequence[Agent] | None = None,
        returns: type | dict | None = None,
        system_prompt: str | None = None,
        resilience: ResilienceConfig | None = None,
        # Advanced parameters
        tool_registry: ToolRegistry | None = None,
        # Memory and state (4-layer architecture)
        conversation: bool = True,  # Layer 1: Thread-based message history (always on by default)
        acc: bool
        | AgentCognitiveCompressor = False,  # Layer 2: ACC for drift prevention
        memory: bool
        | Any = False,  # Layer 3: Long-term memory with remember/recall tools (or Memory object)
        cache: bool | SemanticCache = False,  # Layer 4: Semantic cache for tool outputs
        # HITL and streaming
        interrupt_on: dict[str, bool | Callable[[str, dict], bool]] | None = None,
        stream: bool = False,
        # Advanced features
        reasoning: bool | ReasoningConfig = False,
        output: type | dict | ResponseSchema | None = None,
        intercept: Sequence[Callable] | None = None,
        taskboard: bool | TaskBoardConfig = False,
        # Observability
        verbosity: bool | str | int | None = None,
        observer: Observer | None = None,
    ) -> None:
        """
        Initialize an Agent.

        Args:
            name: Agent name
            model: Chat model - string (e.g., "gpt4", "claude"), provider:model (e.g., "anthropic:claude-sonnet-4"), or BaseChatModel instance
            model_kwargs: Additional model-specific parameters (when model is a string).
                Examples:
                - Gemini: model_kwargs={"thinking_budget": 0} to disable native thinking
                - OpenAI: model_kwargs={"temperature": 0.7, "max_tokens": 1000}
                - DeepSeek: model_kwargs={"reasoning_mode": "off"}
                Note: Use Agent's 'reasoning' parameter for framework-level chain-of-thought (works on any model).
            description: Agent description
            instructions: Instructions for the agent - defines behavior and personality
            tools: List of tools - BaseTool objects, strings, or callables
            capabilities: Additional capabilities to enable
            subagents: Specialized agents for delegation
                - dict: Explicit tool names {"tool_name": agent}
                - list/tuple: Uses agent.name as tool name [agent1, agent2]
            system_prompt: System prompt (alias for instructions)
            resilience: ResilienceConfig for retry logic and circuit breakers
            tool_registry: Registry of available tools (optional)
            conversation: Layer 1 - Thread-based message history (default: True)
                - Maintains conversation context across turns
                - Thread-scoped with thread_id parameter
                - Always enabled for natural multi-turn conversations
            acc: Layer 2 - Agent Cognitive Compressor (default: False)
                - Prevents memory poisoning and context drift
                - Replaces full transcript with bounded internal state
                - Based on arXiv:2601.11653
                - Enable for long conversations (>10 turns)
                - Can pass True (auto-create) or AgentCognitiveCompressor instance
            memory: Layer 3 - Long-term memory with tools (default: False, or Memory object)
                - Adds remember/recall tools for persistent facts
                - Cross-thread memory retrieval
                - Enable for agents that need to learn user preferences
                - Can pass bool (True) or Memory object with vectorstore for semantic search
                - Example: `memory=Memory(vectorstore=VectorStore())` for semantic key matching
            cache: Layer 4 - Semantic cache for tool outputs (default: False)
                - Caches similar tool calls using embedding similarity
                - 80%+ hit rates, 7-10× speedup for repeated queries
                - Enable for expensive tools (WebSearch, Database)
                - Can pass True (auto-create) or SemanticCache instance
            interrupt_on: HITL rules - dict mapping tool names to approval rules
            stream: Enable token-by-token streaming by default
            reasoning: Enable extended thinking/chain-of-thought mode
            output: Enforce structured output schema
            intercept: List of interceptors for execution hooks
            verbosity: Observability level - ObservabilityLevel enum, int (0-5), string, bool, or None
            observer: Observer instance for rich observability (takes precedence over verbosity)

        Model Examples:
            ```python
            # High-level: Just model name (auto-detects provider)
            agent = Agent(name="Helper", model="gpt4")
            agent = Agent(name="Helper", model="claude")

            # With provider prefix for explicit control
            agent = Agent(name="Helper", model="anthropic:claude-sonnet-4")
            agent = Agent(name="Helper", model="groq:llama-70b")
            ```

        Memory Layer Examples:
            ```python
            # Layer 1: Conversation (default ON)
            agent = Agent(name="Assistant", model=model)
            response = await agent.run("Hi, I'm Alice", thread_id="conv-1")
            response = await agent.run("What's my name?", thread_id="conv-1")  # Remembers!

            # Layer 2: Bounded memory (ACC) for long conversations
            agent = Agent(name="Assistant", model=model, acc=True)
            # Prevents drift in 50+ turn conversations

            # Layer 3: Long-term memory with tools
            agent = Agent(name="Assistant", model=model, memory=True)
            response = await agent.run("Remember: I prefer dark mode")
            # Agent gets remember() and recall() tools

            # Layer 4: Semantic cache for expensive tools
            from cogent.capabilities import WebSearch
            agent = Agent(
                name="Researcher",
                model=model,
                capabilities=[WebSearch],
                cache=True,  # Cache web search results
            )
            # Similar queries hit cache (7-10× speedup)

            # All layers together
            agent = Agent(
                name="SuperAgent",
                model=model,
                conversation=True,     # Default - thread-based history
                acc=True,              # ACC for drift prevention
                memory=True,           # Long-term facts
                cache=True,            # Cache tool outputs
            )
            ```

        Example with structured output:
            ```python
            from pydantic import BaseModel, Field

            class ContactInfo(BaseModel):
                name: str = Field(description="Full name")
                email: str = Field(description="Email address")

            agent = Agent(name="Extractor", model=model, output=ContactInfo)
            result = await agent.run("Extract: John Doe, john@acme.com")
            print(result.data)  # ContactInfo(name="John Doe", email="john@acme.com")
            ```
        """
        # Extract tool names and store tool objects
        tool_names: list[str] = []
        self._direct_tools: list[BaseTool] = []

        if tools:
            for tool in tools:
                if isinstance(tool, str):
                    tool_names.append(tool)
                elif isinstance(tool, BaseTool):
                    tool_names.append(tool.name)
                    self._direct_tools.append(tool)
                else:
                    # Try to get name attribute
                    tool_names.append(getattr(tool, "name", str(tool)))

        # Initialize subagent registry
        from cogent.agent.subagent import SubagentRegistry

        self._subagent_registry = SubagentRegistry()

        # Normalize subagents to dict (supports dict, list, or tuple)
        if subagents:
            if isinstance(subagents, dict):
                subagents_dict = subagents
            else:
                # Sequence (list/tuple) - use agent.name as key
                subagents_dict = {agent.config.name: agent for agent in subagents}

            for subagent_name, subagent in subagents_dict.items():
                # Register subagent in registry (returns schema comes from agent.config.returns)
                self._subagent_registry.register(subagent_name, subagent)

                # Create tool wrapper for LLM
                subagent_tool = self._create_subagent_tool(subagent_name, subagent)
                tool_names.append(subagent_tool.name)
                self._direct_tools.append(subagent_tool)

        # instructions takes priority over system_prompt
        effective_prompt = (
            instructions or system_prompt or "You are a helpful AI assistant."
        )

        # Convert string model to BaseChatModel if needed
        if isinstance(model, str):
            from cogent.models import create_chat

            model_kwargs_dict = model_kwargs or {}
            model = create_chat(model, **model_kwargs_dict)

        # Create config from parameters (internal use only)
        config = AgentConfig(
            name=name,
            description=description,
            model=model,
            system_prompt=effective_prompt,
            tools=tool_names,
            resilience_config=resilience,
            interrupt_on=interrupt_on or {},
            stream=stream,
            returns=returns,
        )

        # Initialize agent state
        self.id = generate_id()
        self.config = config
        self.state = AgentState()
        self.tool_registry = tool_registry
        self._event_bus: EventBus | None = None
        self._model = None
        self._lock = asyncio.Lock()
        self._resilience: ToolResilience | None = None
        self._capabilities: list[Any] = []
        self._capabilities_initialized: bool = False  # Track if async init done
        self._observer = None  # Observer for standalone usage
        self._setup_resilience()

        # Setup observer for standalone agent usage
        # observer parameter takes precedence over verbosity
        if observer is not None:
            self._setup_observer(observer)
        elif verbosity is not None:
            self._setup_verbosity_observer(verbosity)

        # Deferred tool execution manager (event-driven completion)
        self._deferred_manager: DeferredToolManager | None = None

        # Setup capabilities (adds tools from each capability)
        if capabilities:
            self._setup_capabilities(capabilities)

        # Setup memory (4-layer architecture)
        self._setup_memory(
            conversation=conversation,
            acc=acc,
            long_term_memory=memory,
            semantic_cache=cache,
        )

        # Setup reasoning mode
        self._setup_reasoning(reasoning)

        # Setup structured output
        self._setup_output(output)

        # Setup interceptors
        self._interceptors: list[Callable] = list(intercept) if intercept else []

        # Setup taskboard if enabled
        self._taskboard: TaskBoard | None = None
        self._taskboard_enabled: bool = False
        if taskboard:
            self._setup_taskboard(taskboard)

        # Performance caches (invalidated when tools change)
        self._cached_tool_descriptions: str | None = None
        self._cached_system_prompt: str | None = None
        self._cached_bound_model: BaseChatModel | None = None
        self._turbo_mode: bool = False  # Skip events for max speed
        self._active_run_id_var: ContextVar[str | None] = ContextVar(
            f"agent_{self.id}_active_run_id",
            default=None,
        )
        self._active_parent_run_id_var: ContextVar[str | None] = ContextVar(
            f"agent_{self.id}_active_parent_run_id",
            default=None,
        )
        self._active_step_id_var: ContextVar[str | None] = ContextVar(
            f"agent_{self.id}_active_step_id",
            default=None,
        )

    @property
    def _active_run_id(self) -> str | None:
        """Return the current task-local run identifier."""
        return self._active_run_id_var.get()

    @_active_run_id.setter
    def _active_run_id(self, value: str | None) -> None:
        """Set the current task-local run identifier."""
        self._active_run_id_var.set(value)

    @property
    def _active_parent_run_id(self) -> str | None:
        """Return the current task-local parent run identifier."""
        return self._active_parent_run_id_var.get()

    @_active_parent_run_id.setter
    def _active_parent_run_id(self, value: str | None) -> None:
        """Set the current task-local parent run identifier."""
        self._active_parent_run_id_var.set(value)

    @property
    def _active_step_id(self) -> str | None:
        """Return the current task-local step identifier."""
        return self._active_step_id_var.get()

    @_active_step_id.setter
    def _active_step_id(self, value: str | None) -> None:
        """Set the current task-local step identifier."""
        self._active_step_id_var.set(value)

    @property
    def observer(self) -> Observer | None:
        """Get the attached observer, if any."""
        return self._observer

    def _ensure_internal_observer(self) -> Observer:
        """Create a silent observer for internal eventing when needed."""
        if self._observer is None:
            from cogent.observability import Observer

            self._observer = Observer(level="trace", stream=StringIO())
        return self._observer

    def emit_event(self, event_type: str, **data: object) -> None:
        """Emit a custom event through the agent observer.

        This ensures deferred workflows and external integrations can publish
        events without depending on legacy observability buses.
        """
        observer = self._ensure_internal_observer()
        event = observer.emit(
            event_type,
            correlation_id=self._active_run_id,
            agent_name=self.name,
            agent_id=self.id,
            **self._lineage_fields(),
            **data,
        )
        if event is not None:
            self.state.emitted_events.append(event)

    def _prepare_run_context(
        self,
        context: dict[str, Any] | RunContext | None,
        task: str,
    ) -> RunContext:
        """Normalize invocation context and ensure run lineage fields exist."""
        import copy

        from cogent.core.context import EMPTY_CONTEXT, RunContext

        run_context: RunContext
        if context is None:
            run_context = copy.copy(EMPTY_CONTEXT)
        elif isinstance(context, RunContext):
            run_context = copy.copy(context)
        else:
            run_context = RunContext(metadata=dict(context))

        if not run_context.query:
            run_context.query = task

        if not run_context.run_id:
            metadata_run_id = run_context.metadata.get("run_id")
            run_context.run_id = (
                str(metadata_run_id) if metadata_run_id else generate_id(12)
            )

        if run_context.parent_run_id is None:
            metadata_parent_run_id = run_context.metadata.get("parent_run_id")
            if metadata_parent_run_id is not None:
                run_context.parent_run_id = str(metadata_parent_run_id)

        run_context.metadata = {**run_context.metadata, "run_id": run_context.run_id}
        if run_context.parent_run_id is not None:
            run_context.metadata.setdefault("parent_run_id", run_context.parent_run_id)

        return run_context

    def _set_observability_context(
        self,
        *,
        run_id: str | None,
        parent_run_id: str | None = None,
    ) -> None:
        """Set active run lineage used by agent-emitted events."""
        self._active_run_id = run_id
        self._active_parent_run_id = parent_run_id
        self._active_step_id = None

    def _set_observability_step(self, step_id: str | None) -> None:
        """Set the active step identifier for the current run."""
        self._active_step_id = step_id

    def _clear_observability_context(self) -> None:
        """Clear active run lineage after an invocation completes."""
        self._active_run_id = None
        self._active_parent_run_id = None
        self._active_step_id = None

    def _lineage_fields(
        self,
        *,
        step_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> dict[str, object]:
        """Return active lineage fields for observability events."""
        payload: dict[str, object] = {}
        if self._active_run_id:
            payload["run_id"] = self._active_run_id
        if self._active_parent_run_id:
            payload["parent_run_id"] = self._active_parent_run_id

        active_step_id = step_id if step_id is not None else self._active_step_id
        if active_step_id:
            payload["step_id"] = active_step_id
        if tool_call_id:
            payload["tool_call_id"] = tool_call_id
        return payload

    def _setup_resilience(self) -> None:
        """Setup resilience layer if configured."""
        from cogent.agent.resilience import (
            FallbackRegistry,
            ResilienceConfig,
            ToolResilience,
        )

        # Use explicit resilience config or create from legacy settings
        if self.config.resilience_config:
            resilience_config = self.config.resilience_config
        elif self.config.retry_on_error:
            # Create config from legacy settings
            from cogent.agent.resilience import RetryPolicy, RetryStrategy

            resilience_config = ResilienceConfig(
                retry_policy=RetryPolicy(
                    max_retries=self.config.max_retries,
                    strategy=RetryStrategy.EXPONENTIAL_JITTER,
                ),
                timeout_seconds=self.config.timeout_seconds,
            )
        else:
            resilience_config = ResilienceConfig.fast_fail()

        # Setup fallback registry
        fallback_registry = FallbackRegistry()
        for primary, fallbacks in self.config.fallback_tools.items():
            fallback_registry.register(primary, fallbacks)

        self._resilience = ToolResilience(
            config=resilience_config,
            fallback_registry=fallback_registry,
        )

    def _create_subagent_tool(self, name: str, agent: Agent) -> BaseTool:
        """Create a tool wrapper for a subagent.

        The tool is callable by the LLM via normal tool calling, but the
        executor will intercept and handle it specially to preserve Response metadata.

        Args:
            name: Name to register the subagent tool under
            agent: The subagent Agent instance

        Returns:
            BaseTool that wraps the subagent
        """
        from pydantic import BaseModel, Field

        class SubagentInput(BaseModel):
            """Input schema for subagent delegation."""

            task: str = Field(
                description=f"Specific task or question for {name} to handle. Be clear and detailed."
            )

        # Placeholder function - actual execution happens in executor
        async def _subagent_placeholder(task: str) -> str:
            """Placeholder - executor intercepts subagent calls."""
            raise RuntimeError(
                f"Subagent {name} execution must be handled by executor. "
                "This should never be called directly."
            )

        description = (
            agent.config.description or f"Delegate task to {name} specialist agent"
        )

        return BaseTool(
            name=name,
            description=description,
            func=_subagent_placeholder,
            args_schema=SubagentInput,
        )

    def _setup_verbosity_observer(self, verbosity: bool | str | int) -> None:
        """Setup observer for standalone agent usage.

        Args:
            verbosity: Observability level:
                - False/0/"off": No output
                - True/2/"progress": Progress milestones (default when True)
                - 1/"result"/"minimal": Only final results
                - 3/"detailed"/"verbose": Tool calls and timing
                - 4/"debug": Everything including internal events
                - 5/"trace": Maximum detail + execution graph
        """
        from cogent.observability import Observer

        # Map verbosity to level string
        if isinstance(verbosity, bool):
            level = "progress" if verbosity else "off"
        elif isinstance(verbosity, int):
            level_map = {
                0: "off",
                1: "minimal",
                2: "progress",
                3: "detailed",
                4: "debug",
                5: "trace",
            }
            level = level_map.get(verbosity, "progress")
        elif isinstance(verbosity, str):
            # Normalize aliases
            alias_map = {
                "off": "off",
                "result": "minimal",
                "minimal": "minimal",
                "progress": "progress",
                "normal": "progress",
                "detailed": "detailed",
                "verbose": "detailed",
                "debug": "debug",
                "trace": "trace",
            }
            level = alias_map.get(verbosity.lower())
            if level is None:
                raise ValueError(
                    f"Invalid verbosity level: {verbosity!r}. "
                    f"Use: {', '.join(repr(k) for k in alias_map)}"
                )
        else:
            level = "progress"

        if level == "off":
            return  # No observer

        self._observer = Observer(level=level)

    def _setup_observer(self, observer: Observer) -> None:
        """Setup observer instance for standalone agent usage.

        Args:
            observer: Observer instance to attach.
        """
        self._observer = observer

    def add_observer(self, observer: Observer) -> None:
        """Add an observer for monitoring agent execution.

        This allows attaching a Observer to a standalone agent for
        rich observability including event tracking, metrics, and traces.

        Args:
            observer: Observer instance to attach.

        Example:
            ```python
            from cogent import Agent, Observer

            observer = Observer(level="verbose")
            agent = Agent(name="Worker", model=model)
            agent.add_observer(observer)

            await agent.run("Do something")
            print(observer.summary())
            ```
        """
        self._setup_observer(observer)

    def _setup_reasoning(self, reasoning: bool | ReasoningConfig | None) -> None:
        """Setup reasoning for extended thinking before actions.

        Args:
            reasoning: Reasoning configuration:
                - None/False: Reasoning disabled
                - True: Enable with default config (budget=5000, deliberate style)
                - ReasoningConfig: Enable with custom config
        """
        if reasoning is None or reasoning is False:
            self._reasoning_config = None
            return

        if reasoning is True:
            self._reasoning_config = ReasoningConfig()
        else:
            self._reasoning_config = reasoning

    def _apply_reasoning_override(self, reasoning: bool | ReasoningConfig) -> None:
        """Apply reasoning override for a specific run() call.

        Args:
            reasoning: Reasoning override:
                - True: Enable with default config
                - False: Disable reasoning
                - ReasoningConfig: Enable with custom config
        """
        if reasoning is False:
            self._reasoning_config = None
        elif reasoning is True:
            self._reasoning_config = ReasoningConfig()
        else:
            self._reasoning_config = reasoning

    def _extract_token_usage(self, result: Any) -> TokenUsage | None:
        """Extract token usage from model result (Phase 6).

        Args:
            result: Result from model.ainvoke() or similar

        Returns:
            TokenUsage if available, None otherwise
        """
        # Check for metadata.tokens (our native models)
        if hasattr(result, "metadata") and result.metadata:
            meta = result.metadata
            if hasattr(meta, "tokens") and meta.tokens:
                tokens = meta.tokens
                return TokenUsage(
                    prompt_tokens=getattr(tokens, "prompt_tokens", 0),
                    completion_tokens=getattr(tokens, "completion_tokens", 0),
                    total_tokens=getattr(tokens, "total_tokens", 0),
                    reasoning_tokens=getattr(tokens, "reasoning_tokens", None),
                )

        # Check for usage attribute (common pattern)
        if hasattr(result, "usage"):
            usage = result.usage
            # Handle dict-like usage
            if isinstance(usage, dict):
                return TokenUsage(
                    prompt_tokens=usage.get("prompt_tokens", 0),
                    completion_tokens=usage.get("completion_tokens", 0),
                    total_tokens=usage.get("total_tokens", 0),
                    reasoning_tokens=usage.get("reasoning_tokens"),
                )
            # Handle object with attributes
            if hasattr(usage, "prompt_tokens"):
                return TokenUsage(
                    prompt_tokens=getattr(usage, "prompt_tokens", 0),
                    completion_tokens=getattr(usage, "completion_tokens", 0),
                    total_tokens=getattr(usage, "total_tokens", 0),
                    reasoning_tokens=getattr(usage, "reasoning_tokens", None),
                )

        # Check for usage_metadata (Anthropic/some providers)
        if hasattr(result, "usage_metadata"):
            metadata = result.usage_metadata
            if isinstance(metadata, dict):
                return TokenUsage(
                    prompt_tokens=metadata.get("input_tokens", 0),
                    completion_tokens=metadata.get("output_tokens", 0),
                    total_tokens=metadata.get("input_tokens", 0)
                    + metadata.get("output_tokens", 0),
                    reasoning_tokens=metadata.get("reasoning_tokens"),
                )

        return None

    def _aggregate_tokens_from_messages(
        self, messages: list | None = None
    ) -> TokenUsage | None:
        """Aggregate token usage from all AI messages.

        Sums up tokens from all AIMessage metadata in the given messages.

        Args:
            messages: List of messages to aggregate from. If None, uses state history.

        Returns:
            TokenUsage with totals, or None if no token info available.
        """
        if messages is None:
            messages = self.state.message_history

        total_prompt = 0
        total_completion = 0
        total_reasoning = 0
        found_any = False
        has_reasoning = False

        for msg in messages:
            # Check if it's an AI message with metadata
            if hasattr(msg, "metadata") and msg.metadata:
                metadata = msg.metadata
                if hasattr(metadata, "tokens") and metadata.tokens:
                    tokens = metadata.tokens
                    if hasattr(tokens, "prompt_tokens"):
                        total_prompt += tokens.prompt_tokens or 0
                        total_completion += tokens.completion_tokens or 0
                        found_any = True
                        # Aggregate reasoning tokens if present
                        if (
                            hasattr(tokens, "reasoning_tokens")
                            and tokens.reasoning_tokens
                        ):
                            total_reasoning += tokens.reasoning_tokens
                            has_reasoning = True

        if found_any:
            return TokenUsage(
                prompt_tokens=total_prompt,
                completion_tokens=total_completion,
                total_tokens=total_prompt + total_completion,
                reasoning_tokens=total_reasoning if has_reasoning else None,
            )
        return None

    def _setup_output(self, output: type | dict | ResponseSchema | None) -> None:
        """Setup structured output for response schema enforcement.

        Args:
            output: Structured output configuration:
                - None: No schema enforcement
                - Pydantic/dataclass/TypedDict class: Use with default config
                - dict: JSON Schema with default config
                - ResponseSchema: Full configuration control
        """
        if output is None:
            self._output_config: ResponseSchema | None = None
            return

        if isinstance(output, ResponseSchema):
            self._output_config = output
        else:
            # Wrap schema in default config
            self._output_config = ResponseSchema(schema=output)

    @property
    def output_config(self) -> ResponseSchema | None:
        """Get the structured output configuration."""
        return getattr(self, "_output_config", None)

    @property
    def has_output_schema(self) -> bool:
        """Whether the agent has a structured output schema configured."""
        return self._output_config is not None

    @property
    def interceptors(self) -> list[Callable]:
        """Get the list of interceptors for this agent."""
        return getattr(self, "_interceptors", [])

    @property
    def has_interceptors(self) -> bool:
        """Whether the agent has interceptors configured."""
        return bool(getattr(self, "_interceptors", None))

    @property
    def deferred_manager(self) -> Any:
        """Get the deferred manager for async tool completion.

        Lazily initialized on first access.
        """
        if self._deferred_manager is None:
            from cogent.tools.deferred import DeferredManager

            self._deferred_manager = DeferredManager(self._ensure_internal_observer())

        return self._deferred_manager

    async def _execute_tool(
        self,
        tool: Any,
        tool_args: dict[str, Any],
        tool_id: str,
        correlation_id: str | None = None,
    ) -> tuple[Any, Exception | None]:
        """
        Execute a tool with support for deferred/async completion.

        Handles:
        - Sync tools
        - Async tools
        - Deferred tools (return DeferredResult for async completion)
        - Tools with func attribute (Cogent BaseTool)
        - Tools with ainvoke/invoke methods (LangChain-style)

        Args:
            tool: The tool to execute.
            tool_args: Arguments to pass to the tool.
            tool_id: Unique ID for this tool call.
            correlation_id: Correlation ID for tracing.

        Returns:
            Tuple of (result, error). Error is None on success.
        """
        from cogent.tools.deferred import DeferredResult, is_deferred

        result = None
        error = None

        try:
            # Execute the tool - support multiple interfaces
            if hasattr(tool, "func"):
                # Cogent BaseTool with func attribute
                if inspect.iscoroutinefunction(tool.func):
                    result = await tool.func(**tool_args)
                else:
                    result = tool.func(**tool_args)
            elif hasattr(tool, "ainvoke"):
                # Async invoke interface
                result = await tool.ainvoke(tool_args)
            elif hasattr(tool, "invoke"):
                # Sync invoke interface
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, lambda: tool.invoke(tool_args)
                )
            else:
                # Callable tool
                if inspect.iscoroutinefunction(tool):
                    result = await tool(**tool_args)
                else:
                    result = tool(**tool_args)

            # Check if result is deferred (async completion)
            if is_deferred(result):
                deferred: DeferredResult = result

                # Emit deferred event
                await self._emit_event(
                    "tool.deferred",
                    {
                        "agent_id": self.id,
                        "agent_name": self.name,
                        "tool_name": tool.name,
                        "tool_id": tool_id,
                        "job_id": deferred.job_id,
                        "wait_for": str(deferred.wait_for),
                        "timeout": deferred.timeout,
                    },
                    correlation_id,
                )

                # Emit waiting event
                await self._emit_event(
                    "tool.deferred.waiting",
                    {
                        "agent_id": self.id,
                        "agent_name": self.name,
                        "tool_name": tool.name,
                        "job_id": deferred.job_id,
                    },
                    correlation_id,
                )

                try:
                    # Wait for async completion
                    result = await self.deferred_manager.wait_for(deferred)

                    # Emit completion event
                    await self._emit_event(
                        "tool.deferred.completed",
                        {
                            "agent_id": self.id,
                            "agent_name": self.name,
                            "tool_name": tool.name,
                            "job_id": deferred.job_id,
                            "result_preview": str(result)[:200] if result else "",
                            "elapsed_seconds": deferred.elapsed_seconds,
                        },
                        correlation_id,
                    )

                except TimeoutError as e:
                    # Emit timeout event
                    await self._emit_event(
                        "tool.deferred.timeout",
                        {
                            "agent_id": self.id,
                            "agent_name": self.name,
                            "tool_name": tool.name,
                            "job_id": deferred.job_id,
                            "timeout": deferred.timeout,
                        },
                        correlation_id,
                    )
                    error = e
                    result = f"Timeout: {e}"

        except Exception as e:
            error = e
            result = f"Error: {e}"

        return result, error

    def _setup_taskboard(self, taskboard: bool | TaskBoardConfig) -> None:
        """Setup taskboard for task tracking.

        Args:
            taskboard: TaskBoard configuration:
                - True: Enable with default config (adds tools + instructions)
                - TaskBoardConfig: Enable with custom config
        """
        # Enable taskboard with tools
        config = TaskBoardConfig() if taskboard is True else taskboard

        self._taskboard = TaskBoard(config)
        self._taskboard_enabled = True

        # Add taskboard tools to agent
        taskboard_tools = create_taskboard_tools(self._taskboard)
        for tool in taskboard_tools:
            if tool not in self._direct_tools:
                self._direct_tools.append(tool)
                if tool.name not in self.config.tools:
                    self.config.tools.append(tool.name)

        # Inject taskboard instructions into system prompt
        if config.include_instructions and self.config.system_prompt:
            self.config = AgentConfig(
                name=self.config.name,
                description=self.config.description,
                model=self.config.model,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                system_prompt=self.config.system_prompt
                + "\n\n"
                + TASKBOARD_INSTRUCTIONS,
                model_kwargs=self.config.model_kwargs,
                stream=self.config.stream,
                tools=self.config.tools,
                max_concurrent_tasks=self.config.max_concurrent_tasks,
                timeout_seconds=self.config.timeout_seconds,
                retry_on_error=self.config.retry_on_error,
                max_retries=self.config.max_retries,
                resilience_config=self.config.resilience_config,
                fallback_tools=self.config.fallback_tools,
                interrupt_on=self.config.interrupt_on,
                metadata=self.config.metadata,
            )

    def _setup_capabilities(self, capabilities: Sequence[Any]) -> None:
        """Setup capabilities and extract their tools.

        Args:
            capabilities: List of BaseCapability instances.
        """
        from cogent.capabilities.base import BaseCapability

        for cap in capabilities:
            if not isinstance(cap, BaseCapability):
                raise TypeError(
                    f"Expected BaseCapability, got {type(cap).__name__}. "
                    "Capabilities must extend BaseCapability."
                )

            self._capabilities.append(cap)

            # Add capability's tools to agent's direct tools
            for tool in cap.tools:
                if tool not in self._direct_tools:
                    self._direct_tools.append(tool)
                    # Also update config.tools for consistency
                    if tool.name not in self.config.tools:
                        self.config.tools.append(tool.name)

    async def initialize_capabilities(self) -> None:
        """Initialize all capabilities asynchronously.

        This is called automatically on first agent.run() call.
        You typically don't need to call this manually.
        """
        if self._capabilities_initialized:
            return

        tools_added = False
        for cap in self._capabilities:
            await cap.initialize(self)
            # Re-collect tools after initialization (for async capabilities like MCP)
            for tool in cap.tools:
                if tool not in self._direct_tools:
                    self._direct_tools.append(tool)
                    tools_added = True
                    if tool.name not in self.config.tools:
                        self.config.tools.append(tool.name)

        # Invalidate caches so bound_model gets refreshed with new tools
        if tools_added:
            self.invalidate_caches()

        self._capabilities_initialized = True

    async def shutdown_capabilities(self) -> None:
        """Shutdown all capabilities (cleanup resources)."""
        for cap in self._capabilities:
            await cap.shutdown()
        self._capabilities_initialized = False

    @property
    def capabilities(self) -> list[object]:
        """List of capabilities attached to this agent."""
        return self._capabilities.copy()

    def get_capability(self, name: str) -> object | None:
        """Get a capability by name."""
        for cap in self._capabilities:
            if cap.name == name:
                return cap
        return None

    def _setup_memory(
        self,
        *,
        conversation: bool = True,
        acc: bool | AgentCognitiveCompressor = False,
        long_term_memory: bool | Any = False,
        semantic_cache: bool | SemanticCache = False,
    ) -> None:
        """Setup memory using 4-layer architecture.

        Args:
            conversation: Layer 1 - Thread-based message history (default: True)
            acc: Layer 2 - Agent Cognitive Compressor (bool or ACC instance)
            long_term_memory: Layer 3 - Long-term memory with tools (bool or Memory object)
            semantic_cache: Layer 4 - Semantic cache (bool or SemanticCache instance)
        """
        from cogent.memory import InMemorySaver, Memory
        from cogent.memory.cache import SemanticCache

        # Check if user passed a Memory object directly
        if isinstance(long_term_memory, Memory):
            self._memory = long_term_memory
            # Add memory tools since user provided Memory with tools
            self._add_memory_tools()
        else:
            # Create unified Memory instance
            # It handles both conversation (Layer 1) and long-term facts (Layer 3)
            backend = InMemorySaver() if conversation else None
            self._memory = Memory(
                saver=backend,  # Checkpointing for conversation
                acc=acc,  # Layer 2: ACC (bool or instance)
            )

            # Layer 3: Long-term memory with remember/recall tools
            if long_term_memory:
                # Tools are built into Memory.tools property
                self._add_memory_tools()

        # Layer 4: Semantic cache for tool outputs (shared across all tools)
        if semantic_cache:
            if isinstance(semantic_cache, SemanticCache):
                # Use provided SemanticCache instance
                self._semantic_cache = semantic_cache
            else:
                # Create default SemanticCache
                from cogent.models import create_embedding

                embed_model = create_embedding("openai", "text-embedding-3-small")
                self._semantic_cache = SemanticCache(
                    embedding=embed_model,
                    similarity_threshold=0.85,  # 85% similarity for cache hits
                    max_entries=10000,
                    default_ttl=86400,  # 24 hours
                )
        else:
            self._semantic_cache = None

    def _add_memory_tools(self) -> None:
        """Add memory tools to agent."""
        # Memory.tools provides remember/recall/forget/search tools
        memory_tools = self._memory.tools
        for tool in memory_tools:
            # Avoid duplicates
            if not any(t.name == tool.name for t in self._direct_tools):
                self._direct_tools.append(tool)

        # Invalidate caches since tools changed
        self._cached_tool_descriptions = None
        self._cached_bound_model = None

    @property
    def memory(self):
        """Access the agent's unified memory.

        Returns:
            Memory instance for conversation history and long-term facts.

        Example:
            ```python
            # Conversation history
            messages = await agent.memory.get_messages(thread_id="conv-1")

            # Long-term facts
            await agent.memory.remember("user_preference", "dark_mode")
            pref = await agent.memory.recall("user_preference")
            ```
        """
        return self._memory

    @property
    def memory_manager(self):
        """Access the unified memory (alias for memory property).

        Returns:
            Memory instance.

        Example:
            ```python
            # Same as agent.memory
            await agent.memory_manager.remember("name", "Alice")
            facts = await agent.memory_manager.recall("name")
            ```
        """
        return self._memory

    @property
    def cache(self):
        """Access the agent's semantic cache (if configured).

        Returns:
            SemanticCache instance or None if caching is disabled.

        Example:
            ```python
            # Check cache status
            if agent.cache:
                stats = agent.cache.stats()
                print(f"Hit rate: {stats['hit_rate']:.1%}")

            # Capabilities automatically use agent.cache when available
            ```
        """
        return getattr(self, "_semantic_cache", None)

    @property
    def has_memory(self) -> bool:
        """Whether the agent has a memory persistence backend configured."""
        return self._memory.has_persistence

    @property
    def taskboard(self) -> TaskBoard | None:
        """Access the agent's taskboard for task tracking.

        Returns None if taskboard is not enabled. Enable with `taskboard=True`.

        The taskboard provides:
        - Tasks: Track work items with status
        - Notes: Store observations and insights
        - Learning: Remember what worked/didn't (Reflexion-style)

        Example:
            ```python
            agent = Agent(name="Worker", model="gpt4", taskboard=True)

            # Agent now has taskboard tools:
            # - add_task, update_task, add_note, verify_task, get_taskboard_status

            result = await agent.run("Research Python tutorials and track your work")

            # Check taskboard after run
            print(agent.taskboard.summary())
            ```
        """
        return self._taskboard

    @property
    def resilience(self) -> ToolResilience:
        """Access the resilience layer for this agent."""
        if self._resilience is None:
            self._setup_resilience()
        return self._resilience

    @property
    def name(self) -> str:
        """Agent's display name."""
        return self.config.name

    @property
    def role(self) -> AgentRole:
        """Agent's role in the system."""
        return self.config.role

    @property
    def role_behavior(self):
        """Get behavior definition for this agent's role."""
        # Return a simple object with role capabilities
        role = self.role
        return type(
            "RoleBehavior",
            (),
            {
                "can_delegate": role == AgentRole.SUPERVISOR,
                "can_finish": role
                in (AgentRole.SUPERVISOR, AgentRole.AUTONOMOUS, AgentRole.REVIEWER),
                "can_use_tools": role in (AgentRole.WORKER, AgentRole.AUTONOMOUS),
            },
        )()

    @property
    def can_delegate(self) -> bool:
        """Whether this agent can delegate to other agents."""
        # Check RoleConfig first
        if hasattr(self, "_role_config") and self._role_config:
            return self._role_config.get_capabilities()["can_delegate"]
        # Then check capability overrides
        if "can_delegate" in self._capability_overrides:
            return self._capability_overrides["can_delegate"]
        # Fall back to role behavior
        return self.role_behavior.can_delegate

    @property
    def can_finish(self) -> bool:
        """Whether this agent can provide final answers."""
        # Check RoleConfig first
        if hasattr(self, "_role_config") and self._role_config:
            return self._role_config.get_capabilities()["can_finish"]
        # Then check capability overrides
        if "can_finish" in self._capability_overrides:
            return self._capability_overrides["can_finish"]
        # Fall back to role behavior
        return self.role_behavior.can_finish

    @property
    def can_use_tools(self) -> bool:
        """Whether this agent can use tools directly."""
        # Check RoleConfig first
        if hasattr(self, "_role_config") and self._role_config:
            return self._role_config.get_capabilities()["can_use_tools"]
        # Then check capability overrides
        if "can_use_tools" in self._capability_overrides:
            return self._capability_overrides["can_use_tools"]
        # Fall back to role behavior
        return self.role_behavior.can_use_tools

    @property
    def status(self) -> AgentStatus:
        """Current agent status."""
        return self.state.status

    @property
    def direct_tools(self) -> list[BaseTool]:
        """Get tools passed directly to the agent (not via registry)."""
        return self._direct_tools

    @property
    def all_tools(self) -> list[BaseTool]:
        """Get all available tools (direct + registry).

        Returns tools in priority order:
        1. Direct tools (passed to Agent constructor)
        2. Registry tools (if tool_registry is set)
        """
        tools: list[BaseTool] = list(self._direct_tools)

        # Add registry tools that aren't already in direct tools
        if self.tool_registry:
            direct_names = {t.name for t in tools}
            for name in self.config.tools:
                if name not in direct_names:
                    tool = self.tool_registry.get(name)
                    if tool:
                        tools.append(tool)

        return tools

    def _get_tool(self, tool_name: str) -> BaseTool | None:
        """Get a tool by name from direct tools or registry.

        Args:
            tool_name: Name of the tool to retrieve.

        Returns:
            The tool object, or None if not found.
        """
        # Check direct tools first (higher priority)
        for tool in self._direct_tools:
            if tool.name == tool_name:
                return tool

        # Fall back to registry
        if self.tool_registry:
            return self.tool_registry.get(tool_name)

        return None

    def get_tool_descriptions(self) -> str:
        """Get formatted descriptions of all available tools (cached).

        Returns:
            Formatted string with tool names and descriptions.
        """
        if self._cached_tool_descriptions is not None:
            return self._cached_tool_descriptions

        tools = self.all_tools
        if not tools:
            return "No tools available."

        descriptions = []
        for tool in tools:
            desc = getattr(tool, "description", "No description")
            descriptions.append(f"- {tool.name}: {desc}")

        self._cached_tool_descriptions = "\n".join(descriptions)
        return self._cached_tool_descriptions

    def invalidate_caches(self) -> None:
        """Invalidate all performance caches. Call when tools change."""
        self._cached_tool_descriptions = None
        self._cached_system_prompt = None
        self._cached_bound_model = None

    @property
    def bound_model(self) -> BaseChatModel:
        """Get model with tools bound (cached for performance).

        This is faster than calling model.bind_tools() repeatedly.
        """
        if self._cached_bound_model is not None:
            return self._cached_bound_model

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        tools = self.all_tools
        if tools:
            self._cached_bound_model = self.model.bind_tools(tools)
        else:
            self._cached_bound_model = self.model

        return self._cached_bound_model

    def enable_turbo_mode(self, enabled: bool = True) -> None:
        """Enable turbo mode for maximum speed.

        In turbo mode:
        - Events are skipped (no observability overhead)
        - Status updates are skipped
        - Minimal logging

        Use when latency is critical and you don't need observability.

        Args:
            enabled: Whether to enable turbo mode.
        """
        self._turbo_mode = enabled

    def get_capabilities_description(self) -> str:
        """Get formatted descriptions of all capabilities and their tools.

        Returns:
            Formatted string describing each capability and its tools.
        """
        if not self._capabilities:
            return ""

        sections = []
        for cap in self._capabilities:
            cap_tools = cap.tools
            if cap_tools:
                tool_list = "\n".join(
                    f"  - {t.name}: {t.description}" for t in cap_tools
                )
                sections.append(f"**{cap.name}** - {cap.description}\n{tool_list}")
            else:
                sections.append(f"**{cap.name}** - {cap.description}")

        return "\n\n".join(sections)

    def get_effective_system_prompt(self) -> str | None:
        """Get the system prompt with capabilities and tools automatically injected.

        Supports placeholders:
        - {tools}: Replaced with tool descriptions
        - {capabilities}: Replaced with capability descriptions

        If no placeholders are present and tools exist, they are appended.
        If no system prompt but tools exist, generates a minimal prompt with tools.

        Returns:
            The system prompt with tools/capabilities injected, or None if no prompt and no tools.
        """
        base_prompt = self.config.system_prompt
        tools = self.all_tools
        tools_desc = self.get_tool_descriptions()
        caps_desc = self.get_capabilities_description()

        # If no base prompt but we have tools, generate a minimal prompt
        if not base_prompt:
            if tools or caps_desc:
                # Generate minimal role-based prompt
                base_prompt = "You are a helpful AI assistant."
                if tools:
                    base_prompt += " Use your tools to help accomplish tasks."
            else:
                return None

        result = base_prompt

        # Replace placeholders if present
        has_tools_placeholder = "{tools}" in result
        has_caps_placeholder = "{capabilities}" in result

        if has_tools_placeholder:
            result = result.replace("{tools}", tools_desc)

        if has_caps_placeholder:
            result = result.replace(
                "{capabilities}", caps_desc if caps_desc else "No capabilities."
            )

        # Auto-append if no placeholders and we have tools/capabilities
        if not has_tools_placeholder and not has_caps_placeholder:
            appendix_parts = []

            if caps_desc:
                appendix_parts.append(f"## Capabilities\n\n{caps_desc}")
            elif tools:
                # Only show flat tool list if no capabilities (to avoid duplication)
                appendix_parts.append(f"## Available Tools\n\n{tools_desc}")

            if appendix_parts:
                result = f"{result}\n\n" + "\n\n".join(appendix_parts)

        # Add memory system prompt if long-term memory tools are configured
        # Check if any of the memory tools (remember/recall) are present
        has_memory_tools = any(
            tool.name in ("remember", "recall", "forget", "search_memories")
            for tool in self._direct_tools
        )
        if has_memory_tools:
            from cogent.memory.tools import get_memory_prompt_addition

            memory_prompt = get_memory_prompt_addition(has_tools=True)
            result = f"{result}\n\n{memory_prompt}"

        # Add subagent documentation if subagents are registered
        if self._subagent_registry and self._subagent_registry.count > 0:
            subagent_docs = self._subagent_registry.generate_documentation()
            if subagent_docs:
                result = f"{result}\n\n{subagent_docs}"

        return result

    @property
    def instructions(self) -> str | None:
        """Agent's instructions (system prompt)."""
        return self.config.system_prompt

    @instructions.setter
    def instructions(self, value: str | None) -> None:
        """Set agent's instructions."""
        self.config = AgentConfig(
            name=self.config.name,
            role=self.config.role,
            description=self.config.description,
            model=self.config.model,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
            system_prompt=value,
            model_kwargs=self.config.model_kwargs.copy(),
            tools=self.config.tools.copy(),
            max_concurrent_tasks=self.config.max_concurrent_tasks,
            timeout_seconds=self.config.timeout_seconds,
            retry_on_error=self.config.retry_on_error,
            max_retries=self.config.max_retries,
            resilience_config=self.config.resilience_config,
            fallback_tools=self.config.fallback_tools.copy(),
            metadata=self.config.metadata.copy(),
        )

    @property
    def model(self) -> BaseChatModel | None:
        """Get the LLM model.

        Accepts:
        - String model names: "gpt4", "claude", "gemini"
        - Provider:model syntax: "anthropic:claude-sonnet-4", "groq:llama-70b"
        - Native Cogent models: ChatModel, AzureOpenAIChat, AnthropicChat, GroqChat, etc.

        Example:
            ```python
            # High-level: String model
            agent = Agent(name="Helper", model="gpt4")
            agent = Agent(name="Helper", model="anthropic:claude-sonnet-4")

            # Medium-level: Factory function
            from cogent.models import create_chat
            agent = Agent(name="Helper", model=create_chat("openai", "gpt-4o"))

            # Low-level: Direct model instance
            from cogent.models import ChatModel
            agent = Agent(name="Helper", model=ChatModel(model="gpt-4o"))
            ```
        """
        if self._model is None:
            model_spec = self.config.effective_model
            if model_spec is not None:
                if isinstance(model_spec, str):
                    # Resolve string to model instance
                    from cogent.models import resolve_and_create_model

                    try:
                        self._model = resolve_and_create_model(model_spec)
                    except Exception as e:
                        raise ValueError(
                            f"Failed to resolve model '{model_spec}': {e}\n"
                            f"Valid examples: 'gpt4', 'claude', 'anthropic:claude-sonnet-4', 'groq:llama-70b'"
                        ) from e
                elif isinstance(model_spec, BaseChatModel):
                    self._model = model_spec
                else:
                    raise TypeError(
                        f"model must be a string or BaseChatModel, got {type(model_spec).__name__}. "
                        f"Use: 'gpt4', 'claude', ChatModel(model='gpt-4o'), or create_chat('openai', 'gpt-4o')"
                    )
        return self._model

    async def _set_status(
        self,
        status: AgentStatus,
        correlation_id: str | None = None,
    ) -> None:
        """Update agent status and emit event."""
        old_status = self.state.status
        self.state.status = status
        self.state.record_activity()

        # Skip event in turbo mode
        if self._turbo_mode:
            return

        if self._observer:
            event = self._observer.emit(
                "agent.status_changed",
                correlation_id=correlation_id or self._active_run_id,
                agent_id=self.id,
                agent_name=self.name,
                old_status=old_status.value,
                new_status=status.value,
                **self._lineage_fields(),
            )
            if event is not None:
                self.state.emitted_events.append(event)

    def _emit(
        self,
        event_type: str,
        **data: object,
    ) -> None:
        """Emit an event from this agent (v2 Observer)."""
        # Skip events in turbo mode for max speed
        if self._turbo_mode:
            return
        if self._observer:
            event = self._observer.emit(
                event_type,
                correlation_id=self._active_run_id,
                agent_name=self.name,
                agent_id=self.id,
                **self._lineage_fields(),
                **data,
            )
            if event is not None:
                self.state.emitted_events.append(event)

    async def _emit_event(
        self,
        event_type: str,
        data: dict,
        correlation_id: str | None = None,
    ) -> None:
        """Emit an event from this agent (legacy compatibility).

        This method exists for backward compatibility.
        Prefer using _emit() for new code.
        """
        # Skip events in turbo mode for max speed
        if self._turbo_mode:
            return
        if self._observer:
            if hasattr(event_type, "value"):
                event_type = event_type.value
            metadata_correlation_id = data.pop("correlation_id", None)
            event_correlation_id = (
                correlation_id or metadata_correlation_id or self._active_run_id
            )
            event = self._observer.emit(
                event_type,
                correlation_id=event_correlation_id,
                **self._lineage_fields(),
                **data,
            )
            if event is not None:
                self.state.emitted_events.append(event)

    def _extract_response_metadata(self, response: Response[Any]) -> dict[str, Any]:
        """Extract Response metadata for observability events.

        Returns dictionary with response metadata suitable for event data.
        """
        metadata: dict[str, Any] = {}

        # Add token usage if available
        if response.metadata and response.metadata.tokens:
            metadata["tokens"] = {
                "prompt": response.metadata.tokens.prompt_tokens,
                "completion": response.metadata.tokens.completion_tokens,
                "total": response.metadata.tokens.total_tokens,
            }

        # Add duration
        if response.metadata:
            metadata["duration"] = response.metadata.duration
            metadata["model"] = response.metadata.model
            if response.metadata.correlation_id:
                metadata["correlation_id"] = response.metadata.correlation_id

        # Add tool call count
        if response.tool_calls:
            metadata["tool_calls_count"] = len(response.tool_calls)
            metadata["tool_calls"] = [
                {
                    "tool": tc.tool_name,
                    "duration": tc.duration,
                    "success": tc.success,
                }
                for tc in response.tool_calls
            ]

        # Add success/error info
        metadata["success"] = response.success
        if response.error:
            metadata["error"] = response.error.message
            metadata["error_type"] = response.error.type

        return metadata

    def think(
        self,
        prompt: str,
        correlation_id: str | None = None,
        *,
        stream: bool | None = None,
        include_tools: bool = True,
        system_prompt_override: str | None = None,
    ) -> Coroutine[Any, Any, Response[str]] | AsyncIterator[StreamChunk]:
        """
        Process a prompt through the agent's reasoning.

        This is the agent's "thinking" phase where it uses its LLM
        to reason about the input and determine what to do.

        Args:
            prompt: The prompt to process
            correlation_id: Optional correlation ID for event tracking
            stream: Enable streaming response. If None, uses agent's default.
                If True, returns async iterator. If False, returns awaitable.
            include_tools: Whether to include tools in system prompt (default: True).
            system_prompt_override: If provided, use this instead of agent's system prompt.

        Returns:
            If stream=False: Awaitable that yields the response when awaited.
            If stream=True: AsyncIterator[StreamChunk] for direct iteration.

        Raises:
            RuntimeError: If no model is configured

        Examples:
            # Non-streaming (await required)
            response = await agent.think("What should I do?")

            # Streaming (no await - direct iteration)
            async for chunk in agent.think("Write a poem", stream=True):
                print(chunk.content, end="", flush=True)
        """
        # Determine if streaming based on parameter or agent default
        use_streaming = stream if stream is not None else self.config.stream

        if use_streaming:
            # Streaming: return async iterator (no await needed)
            return self._think_stream_impl(
                prompt,
                correlation_id=correlation_id,
                include_tools=include_tools,
                system_prompt_override=system_prompt_override,
            )

        # Non-streaming: return coroutine (must be awaited)
        return self._think_impl(
            prompt,
            correlation_id=correlation_id,
            include_tools=include_tools,
            system_prompt_override=system_prompt_override,
        )

    async def _think_impl(
        self,
        prompt: str,
        correlation_id: str | None = None,
        *,
        include_tools: bool = True,
        system_prompt_override: str | None = None,
    ) -> Response[str]:
        """Internal implementation of non-streaming think."""
        import traceback as tb

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        # Auto-initialize capabilities on first call
        if self._capabilities and not self._capabilities_initialized:
            await self.initialize_capabilities()

        await self._set_status(AgentStatus.THINKING, correlation_id)

        await self._emit_event(
            "agent.thinking",
            {
                "agent_id": self.id,
                "agent_name": self.name,
                "prompt_preview": prompt[:200],
            },
            correlation_id,
        )

        start_time = now_utc()

        # Build messages - determine which system prompt to use
        messages: list[Any] = []
        if system_prompt_override is not None:
            effective_prompt = system_prompt_override
        elif include_tools:
            effective_prompt = self.get_effective_system_prompt()
        else:
            effective_prompt = self.config.system_prompt
        if effective_prompt:
            messages.append(SystemMessage(content=effective_prompt))

        # Add relevant history
        messages.extend(self.state.get_recent_history(10))
        messages.append(HumanMessage(content=prompt))

        # Convert to dict format for native models
        dict_messages = [msg.to_dict() for msg in messages]

        # Emit detailed LLM request event (for deep observability)
        await self._emit_event(
            "llm.request",
            {
                "agent_id": self.id,
                "agent_name": self.name,
                "model": model_identifier(self.model),
                "messages": dict_messages,
                "message_count": len(dict_messages),
                "system_prompt_length": len(effective_prompt)
                if effective_prompt
                else 0,
                "tools_available": [t.name for t in self.all_tools]
                if include_tools and self.all_tools
                else [],
            },
            correlation_id,
        )

        try:
            response = await self.model.ainvoke(dict_messages)
            result = response.content

            # Track timing
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            self.state.add_thinking_time(duration_ms)

            # Extract thinking/reasoning content if available
            thinking_content = getattr(response, "thinking", None)
            thoughts_content = getattr(response, "thoughts", None)

            # Extract token usage including reasoning tokens
            token_data = {}
            if hasattr(response, "metadata") and response.metadata:
                meta = response.metadata
                if hasattr(meta, "tokens") and meta.tokens:
                    token_data = {
                        "prompt": meta.tokens.prompt_tokens,
                        "completion": meta.tokens.completion_tokens,
                        "total": meta.tokens.total_tokens,
                        "reasoning": meta.tokens.reasoning_tokens,
                    }

            # Emit raw LLM response event (before any parsing)
            llm_response_data = {
                "agent_id": self.id,
                "agent_name": self.name,
                "response": result,
                "response_length": len(result) if result else 0,
                "duration_ms": duration_ms,
                "has_tool_calls": hasattr(response, "tool_calls")
                and bool(response.tool_calls),
                "tokens": token_data,
            }

            # Add thinking preview if available
            if thinking_content:
                llm_response_data["thinking_preview"] = thinking_content[:300]
                llm_response_data["thinking_length"] = len(thinking_content)
            elif thoughts_content:
                llm_response_data["thinking_preview"] = thoughts_content[:300]
                llm_response_data["thinking_length"] = len(thoughts_content)

            await self._emit_event(
                "llm.response",
                llm_response_data,
                correlation_id,
            )

            # Emit dedicated thinking event if extended thinking was used
            if thinking_content or thoughts_content:
                await self._emit_event(
                    "llm.thinking",
                    {
                        "agent_id": self.id,
                        "agent_name": self.name,
                        "thinking": thinking_content or thoughts_content,
                        "thinking_tokens": token_data.get("reasoning", 0),
                    },
                    correlation_id,
                )

            # Update history
            self.state.add_message(HumanMessage(content=prompt))
            self.state.add_message(AIMessage(content=result))

            await self._set_status(AgentStatus.IDLE, correlation_id)

            # Build Response object
            metadata = ResponseMetadata(
                agent=self.name,
                model=model_identifier(self.model),
                tokens=self._extract_token_usage(response),
                duration=duration_ms / 1000,  # Convert to seconds
                correlation_id=correlation_id,
            )

            response_obj = Response(
                content=result,
                metadata=metadata,
                tool_calls=[],
                events=[],
                messages=messages
                + [AIMessage(content=result)],  # Include full conversation
                error=None,
            )

            # Emit response event with Response metadata
            event_data = {
                "agent_id": self.id,
                "agent_name": self.name,
                "response": result,
                "response_preview": result[:500] if result else "",
                "duration_ms": duration_ms,
            }
            event_data.update(self._extract_response_metadata(response_obj))
            await self._emit_event(
                "agent.responded",
                event_data,
                correlation_id,
            )

            return response_obj

        except Exception as e:
            self.state.record_error(str(e))
            await self._set_status(AgentStatus.ERROR, correlation_id)
            await self._emit_event(
                "agent.error",
                {
                    "agent_id": self.id,
                    "agent_name": self.name,
                    "error": str(e),
                    "phase": "thinking",
                },
                correlation_id,
            )

            # Return Response with error instead of raising
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            metadata = ResponseMetadata(
                agent=self.name,
                model=model_identifier(self.model) if self.model else None,
                duration=duration_ms / 1000,
                correlation_id=correlation_id,
            )

            return Response(
                content="",
                metadata=metadata,
                tool_calls=[],
                events=[],
                messages=messages,  # Include messages even on error
                error=ErrorInfo(
                    message=str(e),
                    type=type(e).__name__,
                    traceback=tb.format_exc(),
                ),
            )

    async def get_thread_history(
        self,
        thread_id: str,
        limit: int | None = None,
    ) -> list:
        """
        Get conversation history for a thread.

        Args:
            thread_id: Thread identifier.
            limit: Maximum number of messages to return.

        Returns:
            List of messages in the thread.
        """
        return await self._memory.get_messages(thread_id, limit=limit)

    async def clear_thread(self, thread_id: str) -> None:
        """
        Clear conversation history for a thread.

        Args:
            thread_id: Thread identifier to clear.
        """
        await self._memory.clear_thread(thread_id)

    # =========================================================================
    # STREAMING METHODS (Internal - use think(stream=True) instead)
    # =========================================================================

    async def _think_stream_impl(
        self,
        prompt: str,
        correlation_id: str | None = None,
        *,
        include_tools: bool = True,
        system_prompt_override: str | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Internal implementation of streaming think."""
        from cogent.agent.streaming import (
            chunk_from_message,
        )

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        # Auto-initialize capabilities on first call
        if self._capabilities and not self._capabilities_initialized:
            await self.initialize_capabilities()

        await self._set_status(AgentStatus.THINKING, correlation_id)

        await self._emit_event(
            "agent.thinking",
            {
                "agent_id": self.id,
                "agent_name": self.name,
                "prompt_preview": prompt[:200],
                "streaming": True,
            },
            correlation_id,
        )

        start_time = now_utc()

        # Build messages
        messages: list[Any] = []
        if system_prompt_override is not None:
            effective_prompt = system_prompt_override
        elif include_tools:
            effective_prompt = self.get_effective_system_prompt()
        else:
            effective_prompt = self.config.system_prompt
        if effective_prompt:
            messages.append(SystemMessage(content=effective_prompt))

        messages.extend(self.state.get_recent_history(10))
        messages.append(HumanMessage(content=prompt))

        # Convert to dict format for native models
        dict_messages = [msg.to_dict() for msg in messages]

        accumulated_content = ""
        index = 0

        try:
            async for chunk in self.model.astream(dict_messages):
                stream_chunk = chunk_from_message(chunk, index)
                accumulated_content += stream_chunk.content
                index += 1

                # Emit token event
                if stream_chunk.content:
                    await self._emit_event(
                        "stream.token",
                        {
                            "agent_id": self.id,
                            "agent_name": self.name,
                            "token": stream_chunk.content,
                            "index": index,
                        },
                        correlation_id,
                    )

                yield stream_chunk

            # Track timing
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            self.state.add_thinking_time(duration_ms)

            # Update history with final result
            self.state.add_message(HumanMessage(content=prompt))
            self.state.add_message(AIMessage(content=accumulated_content))

            await self._set_status(AgentStatus.IDLE, correlation_id)

            await self._emit_event(
                "agent.responded",
                {
                    "agent_id": self.id,
                    "agent_name": self.name,
                    "response": accumulated_content,
                    "response_preview": accumulated_content[:500]
                    if accumulated_content
                    else "",
                    "duration_ms": duration_ms,
                    "streaming": True,
                    "token_count": index,
                },
                correlation_id,
            )

        except Exception as e:
            self.state.record_error(str(e))
            await self._set_status(AgentStatus.ERROR, correlation_id)
            await self._emit_event(
                "agent.error",
                {
                    "agent_id": self.id,
                    "agent_name": self.name,
                    "error": str(e),
                    "phase": "thinking_stream",
                },
                correlation_id,
            )
            raise

    async def stream_events(
        self,
        prompt: str,
        correlation_id: str | None = None,
        *,
        include_tools: bool = True,
        system_prompt_override: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """
        Stream structured events during agent thinking.

        This provides more detailed events than think_stream(), including:
        - STREAM_START: Beginning of stream with metadata
        - TOKEN: Each token as it arrives
        - TOOL_CALL_START: When a tool call begins
        - TOOL_CALL_ARGS: Tool call argument chunks
        - TOOL_CALL_END: Tool call complete
        - STREAM_END: End of stream with full content
        - ERROR: If an error occurs

        Args:
            prompt: The prompt to process.
            correlation_id: Optional correlation ID for event tracking.
            include_tools: Whether to include tools in system prompt.
            system_prompt_override: Optional system prompt override.

        Yields:
            StreamEvent objects with structured information.

        Example:
            ```python
            async for event in agent.stream_events("Search for Python tutorials"):
                if event.type == StreamTraceType.TOKEN:
                    print(event.content, end="", flush=True)
                elif event.type == StreamTraceType.TOOL_CALL_START:
                    print(f"\\n[Calling {event.tool_name}...]")
            ```
        """
        from cogent.agent.streaming import (
            StreamEvent,
            StreamTraceType,
            ToolCallChunk,
            chunk_from_message,
            extract_tool_calls,
        )

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        # Auto-initialize capabilities on first call
        if self._capabilities and not self._capabilities_initialized:
            await self.initialize_capabilities()

        await self._set_status(AgentStatus.THINKING, correlation_id)

        start_time = now_utc()

        # Build messages
        messages: list[Any] = []
        if system_prompt_override is not None:
            effective_prompt = system_prompt_override
        elif include_tools:
            effective_prompt = self.get_effective_system_prompt()
        else:
            effective_prompt = self.config.system_prompt
        if effective_prompt:
            messages.append(SystemMessage(content=effective_prompt))

        messages.extend(self.state.get_recent_history(10))
        messages.append(HumanMessage(content=prompt))

        # Convert to dict format for native models
        dict_messages = [msg.to_dict() for msg in messages]

        # Emit start event
        yield StreamEvent(
            type=StreamTraceType.STREAM_START,
            metadata={
                "agent_id": self.id,
                "agent_name": self.name,
                "prompt": prompt[:200],
            },
            index=0,
        )

        accumulated_content = ""
        index = 1
        active_tool_calls: dict[int, ToolCallChunk] = {}

        try:
            async for chunk in self.model.astream(dict_messages):
                stream_chunk = chunk_from_message(chunk, index)

                # Handle text content
                if stream_chunk.content:
                    accumulated_content += stream_chunk.content
                    yield StreamEvent(
                        type=StreamTraceType.TOKEN,
                        content=stream_chunk.content,
                        accumulated=accumulated_content,
                        index=index,
                    )
                    index += 1

                # Handle tool calls
                tool_chunks = extract_tool_calls(chunk)
                for tc in tool_chunks:
                    tc_index = tc.index

                    if tc_index not in active_tool_calls:
                        # New tool call
                        active_tool_calls[tc_index] = tc
                        if tc.name:
                            yield StreamEvent(
                                type=StreamTraceType.TOOL_CALL_START,
                                tool_call=tc,
                                tool_name=tc.name,
                                index=index,
                            )
                            index += 1
                    else:
                        # Update existing tool call
                        existing = active_tool_calls[tc_index]
                        if tc.args:
                            existing.args += tc.args
                            yield StreamEvent(
                                type=StreamTraceType.TOOL_CALL_ARGS,
                                tool_call=existing,
                                tool_name=existing.name,
                                index=index,
                            )
                            index += 1

            # Emit tool call end events
            for tc in active_tool_calls.values():
                yield StreamEvent(
                    type=StreamTraceType.TOOL_CALL_END,
                    tool_call=tc,
                    tool_name=tc.name,
                    index=index,
                )
                index += 1

            # Track timing
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            self.state.add_thinking_time(duration_ms)

            # Update history
            self.state.add_message(HumanMessage(content=prompt))
            self.state.add_message(AIMessage(content=accumulated_content))

            await self._set_status(AgentStatus.IDLE, correlation_id)

            # Emit end event
            yield StreamEvent(
                type=StreamTraceType.STREAM_END,
                accumulated=accumulated_content,
                metadata={
                    "duration_ms": duration_ms,
                    "token_count": index,
                    "tool_calls": len(active_tool_calls),
                },
                index=index,
            )

        except Exception as e:
            self.state.record_error(str(e))
            await self._set_status(AgentStatus.ERROR, correlation_id)
            yield StreamEvent(
                type=StreamTraceType.ERROR,
                error=str(e),
                accumulated=accumulated_content,
                index=index,
            )
            raise

    # =========================================================================
    # TOOL EXECUTION (ACT)
    # =========================================================================

    async def act(
        self,
        tool_name: str,
        args: dict,
        correlation_id: str | None = None,
        tracker: ProgressTracker | None = None,
        use_resilience: bool = True,
    ) -> Any:
        """
        Execute an action using a tool with intelligent retry and recovery.

        This is the agent's "acting" phase where it interacts with
        the world through tools. When use_resilience=True (default),
        the agent will:
        - Retry on transient failures with exponential backoff
        - Use circuit breakers to prevent cascading failures
        - Fall back to alternative tools if configured
        - Learn from failures to adapt future behavior

        Args:
            tool_name: Name of the tool to use
            args: Arguments for the tool
            correlation_id: Optional correlation ID for event tracking
            tracker: Optional progress tracker for real-time output
            use_resilience: Whether to use intelligent retry/recovery (default: True)

        Returns:
            The tool's result

        Raises:
            RuntimeError: If no tool registry is configured
            ValueError: If tool is not found
            PermissionError: If agent is not authorized to use the tool

        Example:
            ```python
            # With full resilience (retry, circuit breaker, fallback)
            result = await agent.act("web_search", {"query": "Python async"})

            # Disable resilience for testing
            result = await agent.act("web_search", {"query": "test"}, use_resilience=False)
            ```
        """
        tool_obj = self._get_tool(tool_name)
        if not tool_obj:
            raise ValueError(
                f"Unknown tool: {tool_name}. Available: {[t.name for t in self.all_tools]}"
            )

        # Check if agent is allowed to use this tool
        if not self.config.can_use_tool(tool_name):
            raise PermissionError(
                f"Agent {self.name} not authorized to use tool: {tool_name}"
            )

        await self._set_status(AgentStatus.ACTING, correlation_id)

        await self._emit_event(
            "tool.called",
            {
                "agent_id": self.id,
                "agent_name": self.name,
                "tool": tool_name,
                "args": args,
            },
            correlation_id,
        )

        # Emit to progress tracker if provided
        if tracker:
            tracker.tool_call(tool_name, args, agent=self.name)
            # Attach tracker to resilience layer for retry/fallback tracking
            if self._resilience:
                self._resilience.tracker = tracker

        start_time = now_utc()

        try:
            if use_resilience and self._resilience:
                # Use resilience layer for intelligent retry/recovery
                def get_fallback_tool(name: str):
                    t = self._get_tool(name)
                    return t.invoke if t else None

                exec_result = await self._resilience.execute(
                    tool_fn=tool_obj.invoke,
                    tool_name=tool_name,
                    args=args,
                    fallback_fn=get_fallback_tool,
                    tool_obj=tool_obj,  # Pass tool object for ainvoke support
                )

                if exec_result.success:
                    result = exec_result.result
                    duration_ms = exec_result.total_time_ms

                    # Emit additional info if fallback was used
                    if exec_result.used_fallback:
                        await self._emit_event(
                            "tool.result",
                            {
                                "agent_id": self.id,
                                "tool": tool_name,
                                "actual_tool": exec_result.tool_used,
                                "used_fallback": True,
                                "fallback_chain": exec_result.fallback_chain,
                                "attempts": exec_result.attempts,
                                "result_preview": str(result)[:200],
                                "duration_ms": duration_ms,
                            },
                            correlation_id,
                        )
                        if tracker:
                            tracker.update(
                                f"✅ {tool_name} succeeded via fallback → {exec_result.tool_used}"
                            )
                    else:
                        await self._emit_event(
                            "tool.result",
                            {
                                "agent_id": self.id,
                                "tool": tool_name,
                                "attempts": exec_result.attempts,
                                "result_preview": str(result)[:200],
                                "duration_ms": duration_ms,
                            },
                            correlation_id,
                        )
                        if tracker and exec_result.attempts > 1:
                            tracker.update(
                                f"✅ {tool_name} succeeded after {exec_result.attempts} attempts"
                            )
                else:
                    # All retries and fallbacks exhausted
                    error = exec_result.error or RuntimeError(
                        f"Tool {tool_name} failed"
                    )

                    await self._emit_event(
                        "tool.error",
                        {
                            "agent_id": self.id,
                            "tool": tool_name,
                            "error": str(error),
                            "attempts": exec_result.attempts,
                            "fallback_chain": exec_result.fallback_chain,
                            "circuit_state": exec_result.circuit_state.value
                            if exec_result.circuit_state
                            else None,
                            "recovery_action": exec_result.recovery_action.value
                            if exec_result.recovery_action
                            else None,
                        },
                        correlation_id,
                    )

                    if tracker:
                        tracker.tool_error(
                            tool_name,
                            f"{error} (after {exec_result.attempts} attempts, "
                            f"fallbacks: {exec_result.fallback_chain or 'none'})",
                        )

                    self.state.record_error(str(error))
                    await self._set_status(AgentStatus.ERROR, correlation_id)
                    raise error
            else:
                # Direct execution without resilience - use _execute_tool for deferred support
                tool_id = f"act_{uuid.uuid4().hex[:8]}"
                result, tool_error = await self._execute_tool(
                    tool_obj, args, tool_id, correlation_id
                )
                if tool_error:
                    raise tool_error
                duration_ms = (now_utc() - start_time).total_seconds() * 1000

            # Track timing
            self.state.add_acting_time(duration_ms)

            if tracker:
                tracker.tool_result(
                    tool_name, str(result)[:200], duration_ms=duration_ms
                )

            await self._set_status(AgentStatus.IDLE, correlation_id)
            return result

        except Exception as e:
            # Only catch if not already handled by resilience layer
            if not (use_resilience and self._resilience):
                self.state.record_error(str(e))
                await self._set_status(AgentStatus.ERROR, correlation_id)
                await self._emit_event(
                    "tool.error",
                    {
                        "agent_id": self.id,
                        "tool": tool_name,
                        "error": str(e),
                    },
                    correlation_id,
                )

                if tracker:
                    tracker.tool_error(tool_name, str(e))

            raise

    async def act_many(
        self,
        tool_calls: list[tuple[str, dict]],
        correlation_id: str | None = None,
        fail_fast: bool = False,
        tracker: ProgressTracker | None = None,
        use_resilience: bool = True,
    ) -> list[Any]:
        """
        Execute multiple tool calls in parallel with intelligent retry and recovery.

        This enables concurrent tool execution when an LLM requests
        multiple tools simultaneously. Results are returned in the
        same order as the input tool_calls. Each tool call uses the
        resilience layer independently for retry and fallback.

        Args:
            tool_calls: List of (tool_name, args) tuples
            correlation_id: Optional correlation ID for event tracking
            fail_fast: If True, cancel remaining on first error
            tracker: Optional progress tracker for real-time output
            use_resilience: Whether to use intelligent retry/recovery (default: True)

        Returns:
            List of results (or exceptions if fail_fast=False)

        Example:
            ```python
            results = await agent.act_many([
                ("search_web", {"query": "Python async"}),
                ("read_file", {"path": "data.json"}),
                ("calculate", {"expr": "2 + 2"}),
            ])
            ```
        """
        if not tool_calls:
            return []

        await self._set_status(AgentStatus.ACTING, correlation_id)

        await self._emit_event(
            "tool.called",
            {
                "agent_id": self.id,
                "agent_name": self.name,
                "tool": f"parallel:{len(tool_calls)} tools",
                "tools": [tc[0] for tc in tool_calls],
            },
            correlation_id,
        )

        # Emit to progress tracker
        if tracker:
            tracker.update(f"Executing {len(tool_calls)} tools in parallel")
            for tool_name, args in tool_calls:
                tracker.tool_call(tool_name, args, agent=self.name, parallel=True)
            # Attach tracker to resilience layer
            if self._resilience:
                self._resilience.tracker = tracker

        start_time = now_utc()

        async def execute_single(tool_name: str, args: dict) -> Any:
            """Execute a single tool with resilience (for parallel execution)."""
            tool_obj = self._get_tool(tool_name)
            if not tool_obj:
                raise ValueError(
                    f"Unknown tool: {tool_name}. Available: {[t.name for t in self.all_tools]}"
                )

            if not self.config.can_use_tool(tool_name):
                raise PermissionError(
                    f"Agent {self.name} not authorized to use tool: {tool_name}"
                )

            if use_resilience and self._resilience:
                # Use resilience layer
                def get_fallback_tool(name: str):
                    t = self._get_tool(name)
                    return t.invoke if t else None

                exec_result = await self._resilience.execute(
                    tool_fn=tool_obj.invoke,
                    tool_name=tool_name,
                    args=args,
                    fallback_fn=get_fallback_tool,
                    tool_obj=tool_obj,  # Pass tool object for ainvoke support
                )

                if exec_result.success:
                    return exec_result.result
                else:
                    raise exec_result.error or RuntimeError(f"Tool {tool_name} failed")
            else:
                # Direct execution - use ainvoke for async support
                if hasattr(tool_obj, "ainvoke"):
                    return await tool_obj.ainvoke(args)
                else:
                    loop = asyncio.get_event_loop()
                    return await loop.run_in_executor(
                        None, lambda: tool_obj.invoke(args)
                    )

        # Create tasks for parallel execution
        tasks = [execute_single(name, args) for name, args in tool_calls]

        try:
            if fail_fast:
                # Cancel all on first error
                results = await asyncio.gather(*tasks)
            else:
                # Return exceptions instead of raising
                results = await asyncio.gather(*tasks, return_exceptions=True)

            # Track timing
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            self.state.add_acting_time(duration_ms)

            # Count successes/failures
            successes = sum(1 for r in results if not isinstance(r, Exception))
            failures = len(results) - successes

            await self._emit_event(
                "tool.result",
                {
                    "agent_id": self.id,
                    "tools": [tc[0] for tc in tool_calls],
                    "successes": successes,
                    "failures": failures,
                    "duration_ms": duration_ms,
                },
                correlation_id,
            )

            # Emit results to progress tracker
            if tracker:
                for (tool_name, _), result in zip(tool_calls, results, strict=False):
                    if isinstance(result, Exception):
                        tracker.tool_error(tool_name, str(result))
                    else:
                        tracker.tool_result(tool_name, str(result)[:100])
                tracker.update(
                    f"Completed {successes}/{len(tool_calls)} tools ({duration_ms:.0f}ms)"
                )

            await self._set_status(AgentStatus.IDLE, correlation_id)
            return results

        except Exception as e:
            self.state.record_error(str(e))
            await self._set_status(AgentStatus.ERROR, correlation_id)
            await self._emit_event(
                "tool.error",
                {
                    "agent_id": self.id,
                    "tools": [tc[0] for tc in tool_calls],
                    "error": str(e),
                },
                correlation_id,
            )

            # Emit error to progress tracker
            if tracker:
                tracker.tool_error("parallel_execution", str(e))

            raise

    async def execute_task(
        self,
        task: Task,
        correlation_id: str | None = None,
    ) -> Any:
        """
        Execute a task assigned to this agent.

        Handles the full task lifecycle:
        1. Mark task as started
        2. Think about the task (if no tool specified)
        3. Act using the specified tool (if any)
        4. Return the result

        Args:
            task: The task to execute
            correlation_id: Optional correlation ID for event tracking

        Returns:
            The task result
        """
        self.state.start_task(task.id)

        try:
            await self._emit_event(
                "agent.invoked",
                {
                    "agent_id": self.id,
                    "agent_name": self.name,
                    "task_id": task.id,
                    "task_name": task.name,
                },
                correlation_id,
            )

            result = None

            if task.tool:
                # Direct tool execution
                result = await self.act(task.tool, task.args, correlation_id)
            else:
                # Use LLM to process the task
                prompt = f"Task: {task.name}\n"
                if task.description:
                    prompt += f"Description: {task.description}\n"
                if task.args:
                    prompt += f"Context: {json.dumps(task.args)}\n"
                result = await self.think(prompt, correlation_id)

            self.state.finish_task(task.id, success=True)

            await self._emit_event(
                "agent.responded",
                {
                    "agent_id": self.id,
                    "agent_name": self.name,
                    "task_id": task.id,
                    "result_preview": str(result)[:200],
                },
                correlation_id,
            )

            return result

        except Exception:
            self.state.finish_task(task.id, success=False)
            raise

    def run(
        self,
        task: str,
        *,
        context: dict[str, Any] | RunContext | None = None,
        thread_id: str | None = None,
        stream: bool | StreamMode = False,
        max_iterations: int = 25,
        reasoning: bool | ReasoningConfig | None = None,
        returns: type | dict | ResponseSchema | None = None,
    ) -> Coroutine[Any, Any, Response[Any]] | AsyncIterator[StreamChunk]:
        """
        Execute a task with full agent capabilities.

        This is the PRIMARY method for interacting with agents. It handles:
        - Tool execution (agentic loop)
        - Conversation memory (when thread_id provided)
        - Streaming output (when stream=True)
        - Structured output (when configured)
        - Reasoning/chain-of-thought (when configured)

        Args:
            task: The task or message to process.
            context: Optional context dict passed to tools.
            thread_id: Conversation thread ID. When provided:
                - Loads conversation history from memory
                - Saves the exchange after completion
                - Enables multi-turn conversations
            stream: Controls streaming behaviour.
                - False / StreamMode.OFF: returns an awaitable Response (default)
                - True / StreamMode.ALL: streams content and reasoning/thinking tokens
                - StreamMode.CONTENT: streams regular response tokens only
                - StreamMode.REASONING: streams reasoning/thinking tokens only
            max_iterations: Maximum LLM call iterations (default: 25).
            reasoning: Override reasoning for this call:
                - None: Use agent's configured reasoning (default)
                - True: Enable reasoning with default config
                - False: Disable reasoning for this call
                - ReasoningConfig: Enable with custom config
            returns: Override structured output for this call:
                - None: Use agent's configured output schema (default)
                - Pydantic/dataclass/TypedDict class: Enforce this schema
                - dict: JSON Schema
                - ResponseSchema: Full configuration control

        Returns:
            If stream=False: Awaitable that yields the final result when awaited.
            If stream=True: AsyncIterator[StreamChunk] for direct iteration.

        Examples:
            # Simple one-shot task (await required)
            result = await agent.run("What is 2+2?")

            # With tools (await required)
            result = await agent.run("Search for Python tutorials")

            # Multi-turn conversation
            await agent.run("Hi, I'm Alice", thread_id="conv-1")
            result = await agent.run("What's my name?", thread_id="conv-1")

            # Streaming (no await - direct iteration)
            async for chunk in agent.run("Write a poem", stream=True):
                print(chunk.content, end="", flush=True)

            # Streaming with conversation
            async for chunk in agent.run("Tell me more", stream=True, thread_id="conv-1"):
                print(chunk.content, end="")

            # Enable reasoning for complex task
            result = await agent.run("Analyze this codebase", reasoning=True)

            # Custom reasoning config for this call
            result = await agent.run(
                "Debug this issue",
                reasoning=ReasoningConfig(max_thinking_rounds=10, show_thinking=True),
            )

            # Disable reasoning even if agent has it enabled
            result = await agent.run("What time is it?", reasoning=False)
        """
        # Resolve stream argument to StreamMode
        from cogent.agent.streaming import StreamMode as _StreamMode

        if isinstance(stream, _StreamMode):
            stream_mode = stream
        elif stream:  # True
            stream_mode = _StreamMode.ALL
        else:  # False
            stream_mode = _StreamMode.OFF

        # Streaming: return async iterator directly (no await needed)
        if stream_mode != _StreamMode.OFF:
            return self._run_stream(
                task,
                context=context,
                thread_id=thread_id,
                max_iterations=max_iterations,
                reasoning=reasoning,
                returns=returns,
                stream_mode=stream_mode,
            )

        # Non-streaming: return coroutine (must be awaited)
        return self._run_impl(
            task,
            context=context,
            thread_id=thread_id,
            max_iterations=max_iterations,
            reasoning=reasoning,
            returns=returns,
        )

    async def _run_impl(
        self,
        task: str,
        *,
        context: dict[str, Any] | RunContext | None = None,
        thread_id: str | None = None,
        max_iterations: int = 25,
        reasoning: bool | ReasoningConfig | None = None,
        returns: type | dict | ResponseSchema | None = None,
    ) -> Response[Any]:
        """Internal implementation of non-streaming run()."""
        import traceback as tb

        from cogent.executors import create_executor

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        # Auto-initialize capabilities
        if self._capabilities and not self._capabilities_initialized:
            await self.initialize_capabilities()

        # Clear previous state to avoid mixing conversations
        self.state.clear_history()
        self.state.clear_tool_calls()

        # Load conversation context if thread_id provided
        if thread_id:
            # Set current thread on memory for tools to access
            if self._memory and hasattr(self._memory, "_current_thread_id"):
                self._memory._current_thread_id = thread_id

            # Use ACC (bounded memory) or transcript replay (legacy)
            if self._memory._acc_enabled:
                # ACC: Load bounded memory state instead of full transcript
                acc = await self._memory.get_acc_state(thread_id)

                # Pass agent's model to ACC if it needs one for AI extraction
                if (
                    hasattr(acc, "extraction_mode")
                    and acc.extraction_mode == "model"
                    and acc._get_model() is None
                    and self.model is not None
                ):
                    acc.set_model(self.model)

                memory_context = acc.format_for_prompt(task)

                # Add formatted memory as system message
                if memory_context:
                    from cogent.core.messages import SystemMessage

                    memory_msg = SystemMessage(
                        content=f"# Memory Context\n\n{memory_context}"
                    )
                    self.state.add_message(memory_msg)
            else:
                # Legacy: Load full conversation history (transcript replay)
                if self._memory:
                    history = await self._memory.get_messages(thread_id)
                    # Add history to agent state so executor can use it
                    for msg in history:
                        self.state.add_message(msg)

        # Apply reasoning and output overrides for this call
        original_reasoning = self._reasoning_config
        original_output = self._output_config
        run_context = self._prepare_run_context(context, task)
        self._set_observability_context(
            run_id=run_context.run_id,
            parent_run_id=run_context.parent_run_id,
        )
        start_time = now_utc()

        try:
            if reasoning is not None:
                # Override reasoning for this call
                self._apply_reasoning_override(reasoning)

            if returns is not None:
                # Override output schema for this call
                self._setup_output(returns)

            # Create executor based on config.execution_strategy
            executor = create_executor(self, strategy=self.config.execution_strategy)
            executor.max_iterations = max_iterations

            # Clear subagent responses from previous runs
            if hasattr(self, "_subagent_registry") and self._subagent_registry:
                self._subagent_registry.clear()

            # Execute task
            result = await executor.execute(task, run_context)

            # Get messages from executor for token aggregation
            executor_messages = getattr(executor, "_last_messages", None) or []

            # Get subagent responses if any were executed
            subagent_responses = []
            delegation_chain = []
            if hasattr(self, "_subagent_registry") and self._subagent_registry:
                subagent_responses = self._subagent_registry.get_responses()

                # Build delegation chain metadata
                for resp in subagent_responses:
                    if resp.metadata:
                        delegation_chain.append(
                            {
                                "agent": resp.metadata.agent,
                                "model": resp.metadata.model,
                                "tokens": resp.metadata.tokens.total_tokens
                                if resp.metadata.tokens
                                else 0,
                                "duration": resp.metadata.duration,
                            }
                        )

            # Save to conversation history if thread_id provided
            if thread_id:
                # Update ACC state from this turn
                if self._memory and self._memory._acc_enabled:
                    acc = await self._memory.get_acc_state(thread_id)

                    # Extract tool calls for ACC
                    tool_calls_data = [
                        {"name": tc.tool_name, "args": getattr(tc, "arguments", {})}
                        for tc in self.state.tool_calls
                    ]

                    # Update ACC from this turn
                    await acc.update_from_turn(
                        user_message=task,
                        assistant_message=str(result),
                        tool_calls=tool_calls_data,
                        current_task=task,
                    )

                    # Save updated ACC state
                    await self._memory.save_acc_state(thread_id, acc)
                else:
                    # Legacy: Save full transcript
                    await self._save_to_thread(thread_id, task, result)

            # Build Response object
            duration_ms = (now_utc() - start_time).total_seconds() * 1000

            # Aggregate token usage from coordinator messages
            coordinator_tokens = self._aggregate_tokens_from_messages(executor_messages)

            # Aggregate tokens from all subagent responses
            total_tokens = coordinator_tokens
            if subagent_responses:
                for resp in subagent_responses:
                    if resp.metadata and resp.metadata.tokens:
                        if total_tokens:
                            # Aggregate reasoning tokens if present in either
                            total_reasoning = (total_tokens.reasoning_tokens or 0) + (
                                resp.metadata.tokens.reasoning_tokens or 0
                            )
                            reasoning_tokens = (
                                total_reasoning if total_reasoning > 0 else None
                            )

                            total_tokens = TokenUsage(
                                prompt_tokens=total_tokens.prompt_tokens
                                + resp.metadata.tokens.prompt_tokens,
                                completion_tokens=total_tokens.completion_tokens
                                + resp.metadata.tokens.completion_tokens,
                                total_tokens=total_tokens.total_tokens
                                + resp.metadata.tokens.total_tokens,
                                reasoning_tokens=reasoning_tokens,
                            )
                        else:
                            total_tokens = resp.metadata.tokens

            metadata = ResponseMetadata(
                agent=self.name,
                model=model_identifier(self.model),
                tokens=total_tokens,
                duration=duration_ms / 1000,
                correlation_id=run_context.run_id,
                delegation_chain=delegation_chain if delegation_chain else None,
            )

            response_obj = Response(
                content=result,
                metadata=metadata,
                tool_calls=list(self.state.tool_calls),
                messages=executor_messages,  # Use executor's messages with token info
                events=list(self.state.emitted_events),
                error=None,
                subagent_responses=subagent_responses if subagent_responses else None,
            )

            # Emit AGENT_RESPONDED event with Response metadata
            event_data = {
                "agent_id": self.id,
                "agent_name": self.name,
                "response": result,
                "response_preview": str(result)[:500] if result else "",
                "duration_ms": duration_ms,
            }
            event_data.update(self._extract_response_metadata(response_obj))
            await self._emit_event(
                "agent.responded",
                event_data,
                run_context.run_id,
            )

            return response_obj

        except Exception as e:
            # Build Response with error
            duration_ms = (now_utc() - start_time).total_seconds() * 1000
            metadata = ResponseMetadata(
                agent=self.name,
                model=model_identifier(self.model) if self.model else None,
                duration=duration_ms / 1000,
                correlation_id=run_context.run_id,
            )

            return Response(
                content=None,
                metadata=metadata,
                tool_calls=list(self.state.tool_calls),
                messages=list(
                    self.state.message_history
                ),  # Include messages even on error
                events=list(self.state.emitted_events),
                error=ErrorInfo(
                    message=str(e),
                    type=type(e).__name__,
                    traceback=tb.format_exc(),
                ),
            )
        finally:
            # Restore original configs
            if reasoning is not None:
                self._reasoning_config = original_reasoning
            if returns is not None:
                self._output_config = original_output
            self._clear_observability_context()

    async def _run_stream(
        self,
        task: str,
        *,
        context: dict[str, Any] | RunContext | None = None,
        thread_id: str | None = None,
        max_iterations: int = 25,
        reasoning: bool | ReasoningConfig | None = None,
        returns: type | dict | ResponseSchema | None = None,
        stream_mode: StreamMode | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Internal streaming implementation of run()."""
        from cogent.agent.streaming import StreamMode, chunk_from_message

        # Default to ALL when called directly (e.g. from _think_stream_impl)
        if stream_mode is None:
            stream_mode = StreamMode.ALL

        if not self.model:
            raise RuntimeError(f"Agent {self.name} has no model configured")

        # Auto-initialize capabilities
        if self._capabilities and not self._capabilities_initialized:
            await self.initialize_capabilities()

        run_context = self._prepare_run_context(context, task)
        self._set_observability_context(
            run_id=run_context.run_id,
            parent_run_id=run_context.parent_run_id,
        )

        # Apply reasoning and output overrides for this call
        original_reasoning = self._reasoning_config
        original_output = self._output_config
        try:
            if reasoning is not None:
                # Override reasoning for this call
                self._apply_reasoning_override(reasoning)

            if returns is not None:
                # Override output schema for this call
                self._setup_output(returns)

            # Build messages with optional conversation history
            messages = await self._build_run_messages(task, thread_id)
            dict_messages = [msg.to_dict() for msg in messages]

            # Get bound model (with tools)
            bound_model = self.bound_model
            accumulated_content = ""

            # Streaming agentic loop
            for iteration in range(max_iterations):
                async for chunk in bound_model.astream(dict_messages):
                    stream_chunk = chunk_from_message(chunk, iteration)

                    # Always accumulate regular content for history / tool context
                    if stream_chunk.content:
                        accumulated_content += stream_chunk.content

                    # Apply stream mode filter before yielding
                    if stream_mode == StreamMode.CONTENT and stream_chunk.is_reasoning:
                        pass  # skip reasoning-only chunks
                    elif (
                        stream_mode == StreamMode.REASONING
                        and not stream_chunk.is_reasoning
                    ):
                        pass  # skip regular content chunks
                    elif stream_chunk.content or stream_chunk.reasoning:
                        yield stream_chunk

                    # Check for tool calls at end of stream
                    tool_calls = getattr(chunk, "tool_calls", None)
                    if tool_calls:
                        # Execute tools and continue loop
                        dict_messages.append(
                            {
                                "role": "assistant",
                                "content": accumulated_content,
                                "tool_calls": [
                                    {
                                        "id": tc.get("id", f"call_{i}"),
                                        "name": tc.get("name"),
                                        "args": tc.get("args", {}),
                                    }
                                    for i, tc in enumerate(tool_calls)
                                ]
                                if tool_calls
                                else [],
                            }
                        )

                        for tc in tool_calls:
                            tool_name = (
                                tc.get("name", "")
                                if isinstance(tc, dict)
                                else getattr(tc, "name", "")
                            )
                            tool_args = (
                                tc.get("args", {})
                                if isinstance(tc, dict)
                                else getattr(tc, "args", {})
                            )
                            tool_id = (
                                tc.get("id", "call_0")
                                if isinstance(tc, dict)
                                else getattr(tc, "id", "call_0")
                            )

                            result = await self._execute_tool(tool_name, tool_args)
                            dict_messages.append(
                                {
                                    "role": "tool",
                                    "tool_call_id": tool_id,
                                    "content": str(result),
                                }
                            )

                        accumulated_content = ""
                        break  # Continue outer loop for next iteration
                else:
                    # No tool calls - we're done
                    break

            # Save to conversation history if thread_id provided
            if thread_id and accumulated_content:
                await self._save_to_thread(thread_id, task, accumulated_content)
        finally:
            # Restore original configs
            if reasoning is not None:
                self._reasoning_config = original_reasoning
            if returns is not None:
                self._output_config = original_output
            self._clear_observability_context()

    async def _build_run_messages(
        self,
        task: str,
        thread_id: str | None = None,
    ) -> list[Any]:
        """Build messages for run(), optionally including conversation history."""
        messages: list[Any] = []

        # System prompt
        effective_prompt = self.get_effective_system_prompt()
        if effective_prompt:
            messages.append(SystemMessage(content=effective_prompt))

        # Load conversation history if thread_id provided
        if thread_id:
            # Set current thread on memory for tools to access
            if self._memory and hasattr(self._memory, "_current_thread_id"):
                self._memory._current_thread_id = thread_id

            if self._memory:
                history = await self._memory.get_messages(thread_id)
            messages.extend(history)

        # Add user message
        messages.append(HumanMessage(content=task))

        return messages

    async def _save_to_thread(
        self,
        thread_id: str,
        user_message: str,
        assistant_response: str,
    ) -> None:
        """Save exchange to conversation history."""
        if self._memory:
            await self._memory.add_message(
                HumanMessage(content=user_message), thread_id=thread_id
            )
            await self._memory.add_message(
                AIMessage(content=str(assistant_response)), thread_id=thread_id
            )
            await self._memory.add_message(
                AIMessage(content=str(assistant_response)), thread_id=thread_id
            )

    # =========================================================================
    # DEPRECATED METHODS (kept for backward compatibility)
    # =========================================================================

    def is_available(self) -> bool:
        """Check if agent can accept new work."""
        return self.state.is_available() and self.state.has_capacity(
            self.config.max_concurrent_tasks
        )

    # --- Resilience Control Methods ---

    def get_circuit_status(self, tool_name: str | None = None) -> dict[str, Any]:
        """
        Get circuit breaker status for tools.

        Args:
            tool_name: Specific tool name, or None for all tools

        Returns:
            Circuit breaker status dict

        Example:
            ```python
            # Check specific tool
            status = agent.get_circuit_status("web_search")
            if status["state"] == "open":
                print(f"web_search circuit is open!")

            # Check all tools
            all_status = agent.get_circuit_status()
            ```
        """
        if not self._resilience:
            return {"state": "no_resilience_configured"}

        if tool_name:
            return self._resilience.get_circuit_status(tool_name)
        return self._resilience.get_all_circuit_status()

    def reset_circuit(self, tool_name: str | None = None) -> None:
        """
        Reset circuit breaker(s) to closed state.

        Args:
            tool_name: Specific tool, or None to reset all

        Example:
            ```python
            # Reset specific tool
            agent.reset_circuit("web_search")

            # Reset all circuits
            agent.reset_circuit()
            ```
        """
        if not self._resilience:
            return

        if tool_name:
            self._resilience.reset_circuit(tool_name)
        else:
            self._resilience.reset_all_circuits()

    def get_failure_suggestions(self, tool_name: str) -> dict[str, Any] | None:
        """
        Get suggestions for a failing tool based on learned patterns.

        Args:
            tool_name: Name of the tool

        Returns:
            Suggestions dict with failure_rate, common_errors, recommendations

        Example:
            ```python
            suggestions = agent.get_failure_suggestions("web_search")
            print(f"Failure rate: {suggestions['failure_rate']:.1%}")
            print(f"Common errors: {suggestions['common_errors']}")
            for rec in suggestions['recommendations']:
                print(f"  - {rec}")
            ```
        """
        if not self._resilience:
            return None
        return self._resilience.get_failure_suggestions(tool_name)

    def clear_failure_memory(self) -> None:
        """Clear all learned failure patterns (reset memory)."""
        if self._resilience and self._resilience.failure_memory:
            self._resilience.failure_memory.clear()

    def to_dict(self) -> dict:
        """Convert agent info to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role.value,
            "status": self.status.value,
            "description": self.config.description,
            "tools": self.config.tools,
            "state": self.state.to_dict(),
        }

    def draw_mermaid(
        self,
        *,
        theme: str = "default",
        direction: str = "TB",
        title: str | None = None,
        show_tools: bool = True,
        show_roles: bool = True,
        show_config: bool = False,
    ) -> str:
        """
        Generate a Mermaid diagram showing this agent and its tools.

        .. deprecated::
            Use `agent.graph().mermaid()` instead for the new API.

        Args:
            theme: Mermaid theme (default, forest, dark, neutral, base)
            direction: Graph direction (TB, TD, BT, LR, RL)
            title: Optional diagram title
            show_tools: Whether to show agent tools
            show_roles: Whether to show agent role (unused in new API)
            show_config: Whether to show model configuration

        Returns:
            Mermaid diagram code as string
        """
        from cogent.graph import GraphDirection, GraphTheme, GraphView

        view = GraphView.from_agent(
            self,
            show_tools=show_tools,
            show_config=show_config,
        )

        if title:
            view = view.with_title(title)
        if theme != "default":
            view = view.with_theme(GraphTheme(theme))
        if direction not in ("TB", "TD"):
            view = view.with_direction(GraphDirection(direction))

        return view.mermaid()

    def draw_mermaid_png(
        self,
        *,
        theme: str = "default",
        direction: str = "TB",
        title: str | None = None,
        show_tools: bool = True,
        show_roles: bool = True,
        show_config: bool = False,
    ) -> bytes:
        """
        Generate a PNG image of this agent's Mermaid diagram.

        Requires httpx to be installed for mermaid.ink API.

        .. deprecated::
            Use `agent.graph().png()` instead for the new API.

        Args:
            theme: Mermaid theme (default, forest, dark, neutral, base)
            direction: Graph direction (TB, TD, BT, LR, RL)
            title: Optional diagram title
            show_tools: Whether to show agent tools
            show_roles: Whether to show agent role (unused in new API)
            show_config: Whether to show model configuration

        Returns:
            PNG image as bytes
        """
        from cogent.graph import GraphDirection, GraphTheme, GraphView

        view = GraphView.from_agent(
            self,
            show_tools=show_tools,
            show_config=show_config,
        )

        if title:
            view = view.with_title(title)
        if theme != "default":
            view = view.with_theme(GraphTheme(theme))
        if direction not in ("TB", "TD"):
            view = view.with_direction(GraphDirection(direction))

        return view.png()

    # =========================================================================
    # Factory Methods - Legacy aliases (deprecated, use role= argument)
    # =========================================================================

    @classmethod
    def as_planner(
        cls,
        name: str,
        model: Any,
        *,
        available_agents: list[str] | None = None,
        instructions: str | None = None,
        **kwargs,
    ) -> Agent:
        """Create a planner agent (autonomous with planning focus).

        Planners create execution plans with steps and dependencies.
        They are autonomous agents with planning-focused instructions.

        Args:
            name: Agent name
            model: LLM model to use
            available_agents: List of agents that can execute plan steps
            instructions: Additional instructions
            **kwargs: Additional Agent parameters

        Returns:
            Agent configured as a planner
        """
        base_prompt = """You create execution plans with steps and dependencies.

Output plans in this format:
PLAN:
1. [Step 1] - [assigned_to] - [dependencies: none/step_n]
2. [Step 2] - [assigned_to] - [dependencies: step_1]
...
END PLAN

When plan is complete: "FINAL ANSWER: [plan summary]"
"""
        if available_agents:
            base_prompt += f"\n\nAvailable agents for task assignment: {', '.join(available_agents)}"
        if instructions:
            base_prompt += f"\n\n{instructions}"

        return cls(
            name=name,
            model=model,
            role=AgentRole.AUTONOMOUS,  # Planners are autonomous - they can finish
            instructions=base_prompt,
            **kwargs,
        )

    @classmethod
    def as_researcher(
        cls,
        name: str,
        model: Any,
        *,
        tools: list | None = None,
        focus_areas: list[str] | None = None,
        instructions: str | None = None,
        **kwargs,
    ) -> Agent:
        """Create a researcher agent (worker with research focus).

        Researchers gather and synthesize information using tools.
        They are workers with research-focused instructions.

        Args:
            name: Agent name
            model: LLM model to use
            tools: Research tools (search, scrape, etc.)
            focus_areas: Areas of research focus
            instructions: Additional instructions
            **kwargs: Additional Agent parameters

        Returns:
            Agent configured as a researcher
        """
        base_prompt = """You gather and synthesize information using your tools.

Structure your findings:
- Key facts discovered
- Sources used
- Confidence level (high/medium/low)
- Areas needing more research
"""
        if focus_areas:
            base_prompt += f"\n\nFocus areas: {', '.join(focus_areas)}"
        if instructions:
            base_prompt += f"\n\n{instructions}"

        return cls(
            name=name,
            model=model,
            role=AgentRole.WORKER,  # Researchers are workers - they use tools but can't finish
            tools=tools,
            instructions=base_prompt,
            **kwargs,
        )

    # ─────────────────────────────────────────────────────────────────────
    # Visualization (Graph API)
    # ─────────────────────────────────────────────────────────────────────

    def graph(
        self,
        *,
        show_tools: bool = True,
        show_config: bool = False,
    ) -> GraphView:
        """Get a graph visualization of this agent.

        Returns a GraphView that provides a unified interface for
        rendering to multiple formats (Mermaid, ASCII, HTML).

        Args:
            show_tools: Whether to show tools in the diagram.
            show_config: Whether to show configuration node.

        Returns:
            GraphView instance for rendering.

        Example:
            >>> # Get Mermaid code
            >>> print(agent.graph().mermaid())

            >>> # Get ASCII for terminal
            >>> print(agent.graph().ascii())

            >>> # Save as PNG (requires Mermaid CLI)
            >>> agent.graph().save("agent.png")

            >>> # Get shareable URL
            >>> print(agent.graph().url())
        """
        from cogent.graph import GraphView

        return GraphView.from_agent(
            self,
            show_tools=show_tools,
            show_config=show_config,
        )

    def _repr_html_(self) -> str:
        """IPython/Jupyter HTML representation."""
        return self.graph().html()

    def __repr__(self) -> str:
        return f"Agent(id={self.id}, name={self.name}, role={self.role.value})"
