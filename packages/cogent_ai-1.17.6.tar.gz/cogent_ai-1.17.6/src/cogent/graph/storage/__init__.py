"""Storage backends for the graph module.

This module provides different storage implementations for persisting graph data.
"""

from cogent.graph.storage.base import Storage
from cogent.graph.storage.file import FileStorage
from cogent.graph.storage.memory import MemoryStorage

try:
    from cogent.graph.storage.sql import SQLStorage as SQLStorage

    _has_sqlalchemy = True
except ImportError:
    _has_sqlalchemy = False

__all__ = [
    "Storage",
    "MemoryStorage",
    "FileStorage",
    *(["SQLStorage"] if _has_sqlalchemy else []),
]
