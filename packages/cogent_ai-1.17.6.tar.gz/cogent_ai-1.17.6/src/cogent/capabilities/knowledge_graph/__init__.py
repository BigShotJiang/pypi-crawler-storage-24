"""
KnowledgeGraph capability for persistent entity/relationship memory.

This module provides a knowledge graph capability with multiple storage backends:
- In-memory graph (uses networkx if available)
- SQLite database for persistence and large graphs
- JSON file for simple persistence with auto-save

Example:
    ```python
    from cogent.capabilities import KnowledgeGraph

    # In-memory (default)
    kg = KnowledgeGraph()

    # SQLite for persistence
    kg = KnowledgeGraph(backend="sqlite", path="knowledge.db")

    # Or load from file (auto-detects backend)
    kg = KnowledgeGraph.from_file("knowledge.db")
    ```
"""

from cogent.capabilities.knowledge_graph.backends import (
    _HAS_SQLITE,
)
from cogent.capabilities.knowledge_graph.backends import (
    GraphBackend as GraphBackend,
)
from cogent.capabilities.knowledge_graph.backends import (
    InMemoryGraph as InMemoryGraph,
)
from cogent.capabilities.knowledge_graph.backends import (
    JSONFileGraph as JSONFileGraph,
)
from cogent.capabilities.knowledge_graph.backends import (
    SQLiteGraph as SQLiteGraph,
)
from cogent.capabilities.knowledge_graph.capability import (
    KnowledgeGraph as KnowledgeGraph,
)
from cogent.capabilities.knowledge_graph.models import Entity as Entity
from cogent.capabilities.knowledge_graph.models import Relationship as Relationship

_base_all = [
    # Main capability
    "KnowledgeGraph",
    # Models
    "Entity",
    "Relationship",
    # Backends
    "GraphBackend",
    "InMemoryGraph",
    "JSONFileGraph",
]

if _HAS_SQLITE:
    _base_all.append("SQLiteGraph")

__all__ = _base_all
