"""Tests for PCA."""
import numpy as np
import pytest
from pygapit.pca.pca import compute_pca


@pytest.fixture
def geno():
    np.random.seed(1)
    return np.random.choice([0,1,2], size=(50, 300)).astype(float)


def test_pca_shape(geno):
    pc_df, explained = compute_pca(geno, n_components=3)
    assert pc_df.shape == (50, 3)
    assert len(explained) == 3


def test_pca_explained_sums_to_one_ish(geno):
    _, explained = compute_pca(geno, n_components=5)
    assert all(0 <= e <= 1 for e in explained)


def test_pca_col_names(geno):
    pc_df, _ = compute_pca(geno, n_components=4)
    assert list(pc_df.columns) == ["PC1", "PC2", "PC3", "PC4"]
