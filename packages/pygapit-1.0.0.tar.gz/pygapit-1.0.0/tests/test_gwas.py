"""Tests for GWAS models."""
import numpy as np
import pandas as pd
import pytest
from pygapit.gwas.glm import GLM
from pygapit.gwas.mlm import MLM
from pygapit.kinship.kinship import VanRaden_kinship


@pytest.fixture
def sim_data():
    np.random.seed(42)
    n, m = 100, 200
    geno = np.random.choice([0,1,2], size=(n,m), p=[0.25,0.5,0.25]).astype(float)
    causal = [10, 50, 150]
    y = geno[:, causal].sum(axis=1) + np.random.normal(0, 1, n)
    snp_info = pd.DataFrame({
        "SNP": [f"SNP_{i}" for i in range(m)],
        "Chromosome": [i//(m//5)+1 for i in range(m)],
        "Position": [i * 10_000 for i in range(m)],
    })
    return y, geno, snp_info, causal


def test_glm_returns_dataframe(sim_data):
    y, geno, snp_info, _ = sim_data
    res = GLM(y, geno, snp_info)
    assert isinstance(res, pd.DataFrame)
    assert "P.value" in res.columns
    assert len(res) == geno.shape[1]


def test_glm_pvalues_in_range(sim_data):
    y, geno, snp_info, _ = sim_data
    res = GLM(y, geno, snp_info)
    assert (res["P.value"].dropna() >= 0).all()
    assert (res["P.value"].dropna() <= 1).all()


def test_glm_detects_causal(sim_data):
    y, geno, snp_info, causal = sim_data
    res = GLM(y, geno, snp_info)
    # All 3 causal SNPs should rank in top 20 by p-value
    top20 = set(res.nsmallest(20, "P.value").index)
    found = sum(c in top20 for c in causal)
    assert found >= 2, f"Only {found}/3 causal SNPs in top 20"


def test_mlm_returns_dataframe(sim_data):
    y, geno, snp_info, _ = sim_data
    K = VanRaden_kinship(geno)
    res = MLM(y, geno, snp_info, K)
    assert isinstance(res, pd.DataFrame)
    assert "P.value" in res.columns


def test_mlm_controls_inflation(sim_data):
    """MLM should have lower genomic inflation than GLM."""
    from pygapit.utils.stats import genomic_inflation
    y, geno, snp_info, _ = sim_data
    K   = VanRaden_kinship(geno)
    glm = GLM(y, geno, snp_info)
    mlm = MLM(y, geno, snp_info, K)
    lambda_glm = genomic_inflation(glm["P.value"].dropna().values)
    lambda_mlm = genomic_inflation(mlm["P.value"].dropna().values)
    # MLM lambda should generally be closer to 1 than GLM
    assert abs(lambda_mlm - 1) <= abs(lambda_glm - 1) + 0.5
