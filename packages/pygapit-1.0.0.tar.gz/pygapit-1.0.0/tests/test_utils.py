"""Tests for statistical utilities."""
import numpy as np
from pygapit.utils.stats import bonferroni_threshold, fdr_threshold, genomic_inflation


def test_bonferroni():
    assert abs(bonferroni_threshold(10000) - 5e-6) < 1e-10


def test_fdr_threshold_returns_float():
    p = np.random.uniform(0, 1, 1000)
    p[:10] = np.random.uniform(0, 1e-5, 10)
    t = fdr_threshold(p, fdr=0.05)
    assert isinstance(t, float)
    assert 0 <= t <= 1


def test_genomic_inflation_null():
    # Under null (uniform p-values), lambda should be close to 1
    np.random.seed(0)
    p = np.random.uniform(0, 1, 10000)
    lam = genomic_inflation(p)
    assert 0.8 < lam < 1.3
