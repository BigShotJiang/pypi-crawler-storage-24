"""Tests for I/O readers."""
import numpy as np
import pandas as pd
import pytest
import tempfile, os
from pygapit.io.readers import read_phenotype


def test_read_phenotype_basic(tmp_path):
    pheno_file = tmp_path / "pheno.txt"
    pheno_file.write_text("Taxa\tYield\tHeight\nT1\t1.2\t45.0\nT2\t2.3\t50.0\nT3\t0.9\t42.0\n")
    df = read_phenotype(str(pheno_file))
    assert df.shape == (3, 2)
    assert "Yield" in df.columns
    assert df.index[0] == "T1"


def test_read_phenotype_missing(tmp_path):
    pheno_file = tmp_path / "pheno.txt"
    pheno_file.write_text("Taxa\tYield\nT1\t1.2\nT2\tNA\nT3\t0.9\n")
    df = read_phenotype(str(pheno_file))
    assert df.shape[0] == 3
