"""Tests for kinship matrix computation."""
import numpy as np
import pytest
from pygapit.kinship.kinship import VanRaden_kinship, loiselle_kinship, EMMA_kinship


@pytest.fixture
def small_geno():
    np.random.seed(0)
    return np.random.choice([0, 1, 2], size=(20, 100), p=[0.25, 0.5, 0.25]).astype(float)


def test_vanraden_shape(small_geno):
    K = VanRaden_kinship(small_geno)
    assert K.shape == (20, 20)


def test_vanraden_symmetric(small_geno):
    K = VanRaden_kinship(small_geno)
    np.testing.assert_allclose(K, K.T, atol=1e-10)


def test_vanraden_diagonal_near_one(small_geno):
    K = VanRaden_kinship(small_geno)
    # Mean diagonal should be close to 1 for VanRaden
    assert 0.5 < np.mean(np.diag(K)) < 2.0


def test_vanraden_removes_monomorphic():
    G = np.ones((10, 50))   # all monomorphic
    G[:, :30] = np.random.choice([0,1,2], size=(10,30))
    K = VanRaden_kinship(G)
    assert K.shape == (10, 10)


def test_loiselle_shape(small_geno):
    K = loiselle_kinship(small_geno)
    assert K.shape == (20, 20)


def test_emma_shape(small_geno):
    K = EMMA_kinship(small_geno)
    assert K.shape == (20, 20)


def test_emma_diagonal_one(small_geno):
    K = EMMA_kinship(small_geno)
    np.testing.assert_allclose(np.diag(K), np.ones(20), atol=1e-6)
