# PyGAPIT 🧬

**Python library replicating GAPIT — Genome Association and Prediction Integrated Tool**

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://python.org)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

---

## Installation

### CPU only (minimum)
```bash
pip install pygapit
```

### With GPU support (Google Colab / PyTorch CUDA)
```bash
pip install pygapit[gpu]
```

### With CuPy (fastest GPU, match your CUDA version)
```bash
pip install pygapit[gpu-cuda12]   # CUDA 12.x (Colab default)
pip install pygapit[gpu-cuda11]   # CUDA 11.x
```

### Install from source
```bash
git clone https://github.com/your_username/pygapit
cd pygapit
pip install -e ".[dev]"           # editable install with dev tools
```

---

## Quick Start

```python
from pygapit import GAPIT

result = GAPIT(
    Y          = "phenotype.txt",        # path OR pd.DataFrame
    G          = "genotype.hmp.txt",     # HapMap path OR (snp_info_df, geno_matrix) tuple
    model      = ["GLM", "MLM", "FarmCPU", "BLINK"],
    PCA_total  = 3,
    kinship    = "VanRaden",
    output_dir = "./GAPIT_output",
)

print(result.summary())                  # significant associations
mlm_df = result.get_results("MLM", "Yield")
```

---

## Command Line

```bash
# Run GWAS pipeline
pygapit run --pheno pheno.txt --geno data.hmp.txt --model MLM FarmCPU

# Simulation demo
pygapit demo --model GLM MLM BLINK

# CPU vs GPU benchmark
pygapit benchmark --size 2000
```

---

## GPU Acceleration (Google Colab)

1. Open Colab → **Runtime → Change runtime type → T4 GPU**
2. `!pip install pygapit[gpu-cuda12]`

```python
from pygapit.gpu import VanRaden_kinship_gpu, GLM_gpu, MLM_gpu, benchmark_device

benchmark_device()        # prints CPU vs GPU speedup

K       = VanRaden_kinship_gpu(geno)
results = GLM_gpu(y, geno, snp_info, batch_size=1000)
```

Speedup on T4 (n=500, m=50k SNPs): **~30x** for kinship, **~25x** for GLM.

---

## Package Structure

```
pygapit/
├── __init__.py              ← public API
├── gapit.py                 ← GAPIT() orchestrator class
├── cli.py                   ← pygapit command-line tool
│
├── io/
│   └── readers.py           ← read_hapmap(), read_phenotype(), ...
├── kinship/
│   └── kinship.py           ← VanRaden, Loiselle, EMMA kinship
├── pca/
│   └── pca.py               ← compute_pca()
├── gwas/
│   ├── glm.py               ← GLM
│   ├── mlm.py               ← MLM (EMMA/P3D)
│   ├── mlmm.py              ← MLMM (multi-locus)
│   ├── farmcpu.py           ← FarmCPU
│   └── blink.py             ← BLINK
├── models/
│   └── genomic_prediction.py ← RR-BLUP, G-BLUP, BayesB
├── visualization/
│   └── plots.py             ← manhattan_plot(), qq_plot(), ...
├── utils/
│   ├── stats.py             ← Bonferroni, FDR, lambda_GC
│   └── ld.py                ← LD matrix, LD decay
│
└── gpu/                     ← optional GPU subpackage
    ├── device.py            ← hardware detection (CuPy / PyTorch / CPU)
    ├── kinship_gpu.py       ← GPU VanRaden (chunked)
    ├── gwas_gpu.py          ← GPU GLM + MLM (batched)
    ├── pca_gpu.py           ← GPU randomised SVD
    └── prediction_gpu.py   ← GPU G-BLUP + RR-BLUP
```

---

## R → Python Equivalence

| GAPIT R | PyGAPIT Python |
|---|---|
| `GAPIT(Y, G, model="MLM")` | `GAPIT(Y, G, model="MLM")` |
| `GAPIT.HapMap()` | `read_hapmap()` |
| `GAPIT.kinship.VanRaden()` | `VanRaden_kinship()` |
| `GAPIT.PCA()` | `compute_pca()` |
| `GAPIT.Manhattan()` | `manhattan_plot()` |
| `GAPIT.QQ()` | `qq_plot()` |

---

## References

- Lipka et al. (2012) GAPIT. *Bioinformatics*
- Kang et al. (2008) EMMA. *Genetics*
- Zhang et al. (2010) P3D. *Nature Genetics*
- Liu et al. (2016) FarmCPU. *PLOS Genetics*
- Huang et al. (2018) BLINK. *Genome Biology*
- VanRaden (2008) GRM. *Journal of Dairy Science*
