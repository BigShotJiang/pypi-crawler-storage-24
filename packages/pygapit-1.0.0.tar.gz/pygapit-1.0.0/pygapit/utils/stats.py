"""
PyGAPIT Statistical Utilities
"""
import numpy as np
import pandas as pd
from scipy import stats
from typing import Optional


def bonferroni_threshold(n_tests: int, alpha: float = 0.05) -> float:
    """Bonferroni-corrected p-value threshold."""
    return alpha / n_tests


def fdr_threshold(p_values: np.ndarray, fdr: float = 0.05) -> float:
    """
    Benjamini-Hochberg FDR threshold.
    Returns the p-value cutoff for the given FDR level.
    """
    n = len(p_values)
    sorted_p = np.sort(p_values)
    bh = (np.arange(1, n+1) / n) * fdr
    passing = sorted_p[sorted_p <= bh]
    return float(passing.max()) if len(passing) > 0 else 0.0


def genomic_inflation(p_values: np.ndarray) -> float:
    """
    Compute genomic inflation factor lambda_GC.

    Uses the correct formula:
        lambda_GC = median(chi2_obs) / chi2_expected_median
    where chi2_obs = scipy.stats.chi2.ppf(1 - p, df=1)
    and   chi2_expected_median = chi2.ppf(0.5, df=1) = 0.4549

    Note: the common approximation -2*log(p) gives a different (incorrect)
    chi2 statistic and should NOT be used for lambda_GC.
    """
    p = np.asarray(p_values, dtype=float)
    p = p[(~np.isnan(p)) & (p > 0) & (p < 1)]
    if len(p) == 0:
        return np.nan
    chi2_obs = stats.chi2.ppf(1.0 - p, df=1)
    chi2_expected_median = stats.chi2.ppf(0.5, df=1)   # = 0.4549
    return float(np.median(chi2_obs) / chi2_expected_median)


def compress_results(results: pd.DataFrame,
                     p_threshold: float = 0.05,
                     max_rows: int = 1000) -> pd.DataFrame:
    """
    Reduce result size for output: keep all significant + random sample of rest.
    """
    sig  = results[results["P.value"] <= p_threshold]
    rest = results[results["P.value"] >  p_threshold]
    if len(rest) > max_rows:
        rest = rest.sample(max_rows, random_state=42)
    return pd.concat([sig, rest]).sort_values(["Chromosome", "Position"])
