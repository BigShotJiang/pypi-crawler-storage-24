from .stats import bonferroni_threshold, fdr_threshold, genomic_inflation, compress_results
from .ld import LD_decay, LD_matrix
