"""
PyGAPIT LD Utilities - Linkage Disequilibrium calculations.
"""
import numpy as np
import pandas as pd
from scipy import stats
from typing import Optional


def LD_matrix(genotype: np.ndarray, max_snps: int = 500) -> np.ndarray:
    """
    Compute pairwise LD (r^2) matrix for up to max_snps SNPs.

    Parameters
    ----------
    genotype : np.ndarray (n, m)
    max_snps : int  -- trim to this many if m > max_snps

    Returns
    -------
    r2_matrix : np.ndarray (m', m')
    """
    G = np.nan_to_num(genotype[:, :max_snps].astype(float))
    m = G.shape[1]
    r2 = np.zeros((m, m))
    for i in range(m):
        for j in range(i, m):
            r, _ = stats.pearsonr(G[:, i], G[:, j])
            r2[i, j] = r2[j, i] = r**2
    return r2


def LD_decay(genotype: np.ndarray,
             snp_info: pd.DataFrame,
             chrom: Optional[int] = None,
             max_dist: int = 1_000_000) -> pd.DataFrame:
    """
    Compute LD decay (r^2 vs physical distance).

    Parameters
    ----------
    genotype  : np.ndarray (n, m)
    snp_info  : pd.DataFrame with Chromosome, Position columns
    chrom     : int -- restrict to this chromosome (None = first found)
    max_dist  : int -- max bp distance

    Returns
    -------
    pd.DataFrame with columns: distance, r2
    """
    if chrom is None:
        chrom = snp_info["Chromosome"].iloc[0]
    mask = snp_info["Chromosome"] == chrom
    idx  = np.where(mask)[0]
    G    = np.nan_to_num(genotype[:, idx].astype(float))
    pos  = snp_info["Position"].values[idx]

    records = []
    m = len(idx)
    for i in range(m):
        for j in range(i+1, m):
            d = abs(int(pos[j]) - int(pos[i]))
            if d > max_dist:
                break
            r, _ = stats.pearsonr(G[:, i], G[:, j])
            records.append({"distance": d, "r2": r**2})

    return pd.DataFrame(records)
