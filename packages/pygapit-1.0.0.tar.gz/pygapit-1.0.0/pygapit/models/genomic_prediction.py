"""
PyGAPIT - Genomic Prediction / Genomic Selection (GS) Models
=============================================================
Mirrors GAPIT's prediction functions:
  - RR-BLUP  (Ridge Regression BLUP)
  - G-BLUP   (Genomic BLUP via kinship)
  - BayesB   (Meuwissen et al. 2001, simplified)

All return: (predicted_breeding_values, accuracy_cv)
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple
from scipy import linalg


def RR_BLUP(phenotype: np.ndarray,
            genotype: np.ndarray,
            lambda_: Optional[float] = None,
            n_folds: int = 5) -> Tuple[np.ndarray, float]:
    """
    Ridge Regression BLUP (RR-BLUP) for genomic prediction.

    Solves:  [ X'X + lambda*I  X'Z ] [b]   [X'y]
             [ Z'X             Z'Z  ] [u] = [Z'y]

    Parameters
    ----------
    phenotype : np.ndarray (n,)
    genotype  : np.ndarray (n, m)   -- marker matrix (0/1/2)
    lambda_   : float  -- ridge parameter. If None, estimated via VC ratio
    n_folds   : int    -- cross-validation folds for accuracy estimation

    Returns
    -------
    gebv  : np.ndarray (n,) -- genomic estimated breeding values
    acc   : float           -- cross-validated accuracy (Pearson r)
    """
    print("[PyGAPIT] Running RR-BLUP genomic prediction ...")
    y = phenotype.astype(float)
    Z = np.nan_to_num(genotype.astype(float))
    n, m = Z.shape

    if lambda_ is None:
        # Simple estimate: lambda = Ve/Vg = (1 - h2) / h2 * m
        # Use VanRaden heritability proxy
        from ..kinship.kinship import VanRaden_kinship
        K = VanRaden_kinship(Z)
        # REML-like: assume h2 ~ 0.5
        lambda_ = m * (1 - 0.5) / 0.5
        print(f"[PyGAPIT]  lambda estimated = {lambda_:.2f}")

    A = Z.T @ Z + lambda_ * np.eye(m)
    rhs = Z.T @ y
    u = np.linalg.solve(A, rhs)
    gebv = Z @ u

    # Cross-validation accuracy
    acc = _cross_validate(y, Z, lambda_, n_folds)
    print(f"[PyGAPIT]  RR-BLUP CV accuracy (r): {acc:.4f}")
    return gebv, acc


def GBLUP(phenotype: np.ndarray,
          kinship: np.ndarray,
          n_folds: int = 5) -> Tuple[np.ndarray, float]:
    """
    Genomic BLUP (G-BLUP) using a pre-computed GRM.

    Solves Henderson's MME:
      u = Vg * K * V^{-1} * (y - X*b)

    Parameters
    ----------
    phenotype : np.ndarray (n,)
    kinship   : np.ndarray (n, n)
    n_folds   : int

    Returns
    -------
    gebv : np.ndarray (n,)
    acc  : float
    """
    print("[PyGAPIT] Running G-BLUP genomic prediction ...")
    y = phenotype.astype(float)
    n = len(y)
    X = np.ones((n, 1))

    # Estimate VC: assume h2 = 0.5 for simplicity
    h2 = 0.5
    lambda_ = (1 - h2) / h2

    V = kinship + lambda_ * np.eye(n)
    Vinv = np.linalg.inv(V)
    XtVinv = X.T @ Vinv
    beta = np.linalg.solve(XtVinv @ X, XtVinv @ y)
    gebv = kinship @ Vinv @ (y - X @ beta)

    # CV
    fold_size = n // n_folds
    predictions = np.zeros(n)
    for fold in range(n_folds):
        test = np.arange(fold * fold_size, min((fold + 1) * fold_size, n))
        train = np.setdiff1d(np.arange(n), test)
        K_tt = kinship[np.ix_(train, train)]
        K_pt = kinship[np.ix_(test,  train)]
        y_t  = y[train]
        V_t  = K_tt + lambda_ * np.eye(len(train))
        Vinv_t = np.linalg.inv(V_t)
        mu_t = np.mean(y_t)
        predictions[test] = K_pt @ Vinv_t @ (y_t - mu_t) + mu_t

    valid = ~np.isnan(y)
    acc = float(np.corrcoef(y[valid], predictions[valid])[0, 1])
    print(f"[PyGAPIT]  G-BLUP CV accuracy (r): {acc:.4f}")
    return gebv, acc


def BayesB(phenotype: np.ndarray,
           genotype: np.ndarray,
           n_iter: int = 5000,
           burn_in: int = 1000,
           pi: float = 0.95) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simplified BayesB via Gibbs sampling.
    (pi = prior probability of SNP having zero effect)

    Parameters
    ----------
    phenotype : np.ndarray (n,)
    genotype  : np.ndarray (n, m)
    n_iter    : int -- total Gibbs iterations
    burn_in   : int -- burn-in iterations (discarded)
    pi        : float -- sparsity prior

    Returns
    -------
    beta_hat  : np.ndarray (m,) -- posterior mean marker effects
    gebv      : np.ndarray (n,) -- genomic estimated breeding values
    """
    print(f"[PyGAPIT] Running BayesB ({n_iter} iterations, burn-in={burn_in}) ...")
    y = phenotype.astype(float)
    Z = np.nan_to_num(genotype.astype(float))
    n, m = Z.shape
    y -= np.mean(y)

    # Initialize
    beta  = np.zeros(m)
    delta = np.ones(m, dtype=bool)   # inclusion indicator
    Ve    = np.var(y) * (1 - 0.5)
    Vb    = np.var(y) * 0.5 / (m * (1 - pi))

    beta_samples = np.zeros((n_iter - burn_in, m))

    for it in range(n_iter):
        residual = y - Z @ beta

        for j in np.random.permutation(m):
            zj = Z[:, j]
            zz = np.dot(zj, zj)
            residual += zj * beta[j]   # restore this SNP's contribution

            # Compute inclusion probability
            mean_j = np.dot(zj, residual) / (zz + Ve / Vb)
            var_j  = Ve / (zz + Ve / Vb)
            log_p1 = (0.5 * mean_j**2 / var_j
                      - 0.5 * np.log(Ve / Vb + zz / Ve * Ve)
                      + np.log((1 - pi) / pi))
            p_incl = 1.0 / (1.0 + np.exp(-log_p1))

            if np.random.rand() < p_incl:
                delta[j] = True
                beta[j] = np.random.normal(mean_j, np.sqrt(var_j))
            else:
                delta[j] = False
                beta[j]  = 0.0

            residual -= zj * beta[j]

        # Sample variances
        Ve = _sample_var(residual, n, a=4, b=np.var(y) * 0.5)
        Vb = _sample_var(beta[delta], max(delta.sum(), 1), a=4,
                         b=np.var(y) * 0.5 / (m * (1 - pi)))

        if it >= burn_in:
            beta_samples[it - burn_in] = beta

        if (it + 1) % 1000 == 0:
            print(f"[PyGAPIT]  BayesB iter {it+1}/{n_iter}, Ve={Ve:.4f}")

    beta_hat = beta_samples.mean(axis=0)
    gebv = Z @ beta_hat + np.mean(phenotype)
    print(f"[PyGAPIT]  BayesB done. Non-zero loci: {(np.abs(beta_hat) > 1e-6).sum()}")
    return beta_hat, gebv


def _sample_var(residuals, n, a=4, b=1):
    """Sample from Scaled-Inverse-Chi-Squared distribution."""
    if n < 2:
        return b / a
    shape = (a + n) / 2
    scale = (a * b + np.sum(residuals**2)) / 2
    return scale / np.random.gamma(shape)


def _cross_validate(y, Z, lambda_, n_folds):
    n, m = Z.shape
    fold_size = n // n_folds
    preds = np.zeros(n)
    for fold in range(n_folds):
        test  = np.arange(fold * fold_size, min((fold+1) * fold_size, n))
        train = np.setdiff1d(np.arange(n), test)
        Zt, yt = Z[train], y[train]
        A = Zt.T @ Zt + lambda_ * np.eye(m)
        u = np.linalg.solve(A, Zt.T @ yt)
        preds[test] = Z[test] @ u
    return float(np.corrcoef(y, preds)[0, 1])
