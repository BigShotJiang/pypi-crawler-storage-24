from .genomic_prediction import RR_BLUP, GBLUP, BayesB
