"""
PyGAPIT Visualization Module
=============================
Publication-quality plots mirroring GAPIT's output:
  - Manhattan plot
  - QQ plot  (quantile-quantile)
  - PCA scatter plot
  - Kinship heatmap
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from typing import Optional, List
import os


# ── Colour palette matching GAPIT's default ──────────────────────────────────
CHROM_COLORS = [
    "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
    "#FF7F00", "#A65628", "#F781BF", "#999999",
    "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3",
]


def manhattan_plot(results: pd.DataFrame,
                   title: str = "Manhattan Plot",
                   significance: float = 5e-8,
                   suggestive: float = 1e-5,
                   point_size: float = 3.0,
                   output_file: Optional[str] = None,
                   highlight_snps: Optional[List[str]] = None) -> plt.Figure:
    """
    Draw a Manhattan plot.

    Parameters
    ----------
    results      : pd.DataFrame with Chromosome, Position, P.value columns
    significance : float -- genome-wide significance threshold (red line)
    suggestive   : float -- suggestive threshold (blue dashed line)
    output_file  : str   -- save path (PNG/PDF); None = return figure only
    highlight_snps: list -- SNP names to highlight in gold

    Returns
    -------
    matplotlib Figure
    """
    df = results.dropna(subset=["P.value", "Chromosome", "Position"]).copy()
    df["Chromosome"] = pd.to_numeric(df["Chromosome"], errors="coerce")
    df = df.dropna(subset=["Chromosome"])
    df["Chromosome"] = df["Chromosome"].astype(int)
    df["-log10P"] = -np.log10(df["P.value"].clip(lower=1e-300))
    df = df.sort_values(["Chromosome", "Position"])

    # Compute cumulative x-axis positions
    chrom_offsets = {}
    cumpos = 0
    xtick_pos, xtick_labels = [], []
    for chrom in sorted(df["Chromosome"].unique()):
        sub = df[df["Chromosome"] == chrom]
        chrom_offsets[chrom] = cumpos
        xtick_pos.append(cumpos + (sub["Position"].max() - sub["Position"].min()) / 2)
        xtick_labels.append(str(chrom))
        cumpos += sub["Position"].max() - sub["Position"].min() + 1e7

    df["cumpos"] = df.apply(
        lambda r: r["Position"] - df.loc[df["Chromosome"] == r["Chromosome"], "Position"].min()
                  + chrom_offsets[r["Chromosome"]], axis=1)

    fig, ax = plt.subplots(figsize=(14, 5))
    for i, chrom in enumerate(sorted(df["Chromosome"].unique())):
        sub = df[df["Chromosome"] == chrom]
        color = CHROM_COLORS[i % len(CHROM_COLORS)]
        ax.scatter(sub["cumpos"], sub["-log10P"], c=color, s=point_size, alpha=0.7, linewidths=0)

    if highlight_snps:
        hi = df[df["SNP"].isin(highlight_snps)]
        ax.scatter(hi["cumpos"], hi["-log10P"], c="gold", s=20, zorder=5,
                   edgecolors="black", linewidths=0.5, label="Highlighted")

    # Threshold lines
    if significance:
        ax.axhline(-np.log10(significance), color="red", lw=1.0, ls="--",
                   label=f"Genome-wide (p={significance:.0e})")
    if suggestive:
        ax.axhline(-np.log10(suggestive), color="blue", lw=0.8, ls=":",
                   label=f"Suggestive (p={suggestive:.0e})")

    ax.set_xticks(xtick_pos)
    ax.set_xticklabels(xtick_labels, fontsize=7)
    ax.set_xlabel("Chromosome", fontsize=11)
    ax.set_ylabel(r"$-\log_{10}(P)$", fontsize=11)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.legend(fontsize=8, loc="upper right")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.tight_layout()

    if output_file:
        fig.savefig(output_file, dpi=200, bbox_inches="tight")
        print(f"[PyGAPIT] Manhattan plot saved -> {output_file}")
    return fig


def qq_plot(results: pd.DataFrame,
            title: str = "QQ Plot",
            output_file: Optional[str] = None) -> plt.Figure:
    """
    Draw a QQ plot (observed vs expected -log10 p-values).

    Parameters
    ----------
    results     : pd.DataFrame with P.value column
    output_file : str -- save path

    Returns
    -------
    matplotlib Figure
    """
    pvals = results["P.value"].dropna().values
    pvals = np.sort(pvals[pvals > 0])
    n = len(pvals)
    expected = -np.log10(np.arange(1, n + 1) / (n + 1))
    observed = -np.log10(pvals[::-1])

    # Genomic inflation factor lambda
    chi2_obs = -2 * np.log(pvals)
    lambda_gc = np.median(chi2_obs) / 0.4549  # chi2(1) median = 0.4549

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(expected, observed, c="#377EB8", s=5, alpha=0.6, linewidths=0)
    max_val = max(expected.max(), observed.max()) * 1.05
    ax.plot([0, max_val], [0, max_val], "r--", lw=1.2, label="Expected")

    # 95% CI band
    ci_upper = -np.log10(np.array(
        [max(1e-15, x) for x in
         [stats_beta_ppf(0.975, i, n - i + 1) for i in range(1, n + 1)]]))
    ci_lower = -np.log10(np.array(
        [max(1e-15, x) for x in
         [stats_beta_ppf(0.025, i, n - i + 1) for i in range(1, n + 1)]]))

    ax.fill_between(expected, ci_lower[::-1], ci_upper[::-1],
                    alpha=0.15, color="grey", label="95% CI")

    ax.set_xlabel(r"Expected $-\log_{10}(P)$", fontsize=11)
    ax.set_ylabel(r"Observed $-\log_{10}(P)$", fontsize=11)
    ax.set_title(f"{title}\n" + r"$\lambda_{GC}$" + f" = {lambda_gc:.3f}", fontsize=12)
    ax.legend(fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.tight_layout()

    if output_file:
        fig.savefig(output_file, dpi=200, bbox_inches="tight")
        print(f"[PyGAPIT] QQ plot saved -> {output_file}")
    return fig


def stats_beta_ppf(p, a, b):
    from scipy.stats import beta
    return beta.ppf(p, a, b)


def pca_plot(pc_df: pd.DataFrame,
             group_labels: Optional[pd.Series] = None,
             title: str = "PCA Plot",
             x_pc: int = 1, y_pc: int = 2,
             output_file: Optional[str] = None) -> plt.Figure:
    """
    Draw a PCA scatter plot.

    Parameters
    ----------
    pc_df        : pd.DataFrame with PC1, PC2, ... columns
    group_labels : pd.Series mapping taxon -> group (for colouring)
    x_pc, y_pc  : which PCs to plot on X and Y axes
    output_file  : str save path

    Returns
    -------
    matplotlib Figure
    """
    xc, yc = f"PC{x_pc}", f"PC{y_pc}"
    fig, ax = plt.subplots(figsize=(7, 6))

    if group_labels is not None:
        groups = group_labels.unique()
        palette = plt.cm.get_cmap("tab10", len(groups))
        for i, grp in enumerate(groups):
            mask = group_labels == grp
            idx = pc_df.index[pc_df.index.isin(group_labels[mask].index)]
            sub = pc_df.loc[idx]
            ax.scatter(sub[xc], sub[yc], c=[palette(i)], s=30,
                       label=str(grp), alpha=0.8, edgecolors="white", linewidths=0.3)
        ax.legend(title="Group", fontsize=8, markerscale=1.5)
    else:
        ax.scatter(pc_df[xc], pc_df[yc], s=20, alpha=0.7, c="#377EB8",
                   edgecolors="white", linewidths=0.3)

    ax.axhline(0, color="grey", lw=0.5, ls="--")
    ax.axvline(0, color="grey", lw=0.5, ls="--")
    ax.set_xlabel(xc, fontsize=11)
    ax.set_ylabel(yc, fontsize=11)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.tight_layout()

    if output_file:
        fig.savefig(output_file, dpi=200, bbox_inches="tight")
        print(f"[PyGAPIT] PCA plot saved -> {output_file}")
    return fig


def kinship_heatmap(K: np.ndarray,
                    taxa_names: Optional[List[str]] = None,
                    title: str = "Kinship Matrix",
                    output_file: Optional[str] = None) -> plt.Figure:
    """
    Draw a heatmap of the kinship / GRM matrix.

    Parameters
    ----------
    K           : np.ndarray (n, n)
    taxa_names  : list of taxon labels (shown on axes if n <= 50)
    output_file : str save path

    Returns
    -------
    matplotlib Figure
    """
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(K, aspect="auto", cmap="RdYlBu_r",
                   vmin=np.percentile(K, 1), vmax=np.percentile(K, 99))
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="Kinship")

    n = K.shape[0]
    if taxa_names and n <= 50:
        ax.set_xticks(range(n))
        ax.set_xticklabels(taxa_names, rotation=90, fontsize=6)
        ax.set_yticks(range(n))
        ax.set_yticklabels(taxa_names, fontsize=6)
    else:
        ax.set_xticks([])
        ax.set_yticks([])

    ax.set_title(title, fontsize=13, fontweight="bold")
    plt.tight_layout()

    if output_file:
        fig.savefig(output_file, dpi=200, bbox_inches="tight")
        print(f"[PyGAPIT] Kinship heatmap saved -> {output_file}")
    return fig
