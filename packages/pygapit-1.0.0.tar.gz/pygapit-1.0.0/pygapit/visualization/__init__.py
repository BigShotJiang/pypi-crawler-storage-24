from .plots import manhattan_plot, qq_plot, pca_plot, kinship_heatmap
