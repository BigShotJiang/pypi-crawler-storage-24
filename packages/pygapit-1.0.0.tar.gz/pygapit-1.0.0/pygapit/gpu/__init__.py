"""
pygapit.gpu — GPU-accelerated backends (optional)
==================================================
Requires: torch (PyTorch) and/or cupy

Auto-detects available hardware:
  CUDA GPU  → CuPy (fastest) or PyTorch CUDA
  Apple M*  → PyTorch MPS
  CPU       → silent fallback to NumPy

Usage
-----
>>> from pygapit.gpu import VanRaden_kinship_gpu, GLM_gpu, MLM_gpu
>>> from pygapit.gpu import benchmark_device
>>> benchmark_device()
"""

from .device       import get_device, gpu_available, benchmark_device, to_cpu, to_gpu
from .kinship_gpu  import VanRaden_kinship_gpu
from .gwas_gpu     import GLM_gpu, MLM_gpu
from .pca_gpu      import compute_pca_gpu
from .prediction_gpu import GBLUP_gpu, RR_BLUP_gpu

__all__ = [
    "get_device", "gpu_available", "benchmark_device", "to_cpu", "to_gpu",
    "VanRaden_kinship_gpu",
    "GLM_gpu", "MLM_gpu",
    "compute_pca_gpu",
    "GBLUP_gpu", "RR_BLUP_gpu",
]
