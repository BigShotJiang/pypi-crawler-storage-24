"""
PyGAPIT-GPU: GPU-accelerated Kinship Matrix
=============================================
Implements VanRaden (2008) GRM on GPU using CuPy or PyTorch.

For large datasets (n > 1000 taxa, m > 50,000 SNPs), the kinship
matrix computation dominates runtime. GPU acceleration gives 10-50x
speedup over NumPy depending on matrix size.

Key operation:  K = Z @ Z.T / denom   (n x m) @ (m x n) -> (n x n)
This is a BLAS DGEMM call — ideal for GPU.
"""

import numpy as np
from typing import Optional
from .device import gpu_available, to_cpu, to_gpu, get_device


def VanRaden_kinship_gpu(geno: np.ndarray,
                         freq: Optional[np.ndarray] = None,
                         chunk_size: int = 10000) -> np.ndarray:
    """
    GPU-accelerated VanRaden (2008) kinship matrix.

    Matches GAPIT.kinship.VanRaden.R exactly, but computes on GPU
    when available (CuPy/CUDA or PyTorch).

    For very large SNP panels (m > 100k), processes in chunks to
    avoid GPU memory overflow.

    Parameters
    ----------
    geno       : np.ndarray (n, m) -- genotype matrix, values 0/1/2
    freq       : optional pre-computed allele frequencies
    chunk_size : int -- SNP chunk size for memory management

    Returns
    -------
    K : np.ndarray (n, n) -- always returned as CPU numpy array
    """
    n, m = geno.shape
    print(f"[PyGAPIT-GPU] VanRaden kinship: {n} taxa × {m} SNPs on {get_device().upper()}")

    G_np = np.nan_to_num(geno.astype(np.float32))

    # Step 1: Remove invariant SNPs (same as GAPIT source)
    fa = G_np.mean(axis=0) / 2.0
    valid = (fa > 0) & (fa < 1)
    removed = (~valid).sum()
    if removed > 0:
        print(f"[PyGAPIT-GPU]  Removing {removed} invariant SNPs.")
    G_np = G_np[:, valid]
    p = G_np.sum(axis=0) / (2.0 * n)    # allele frequencies

    # Denominator: 2 * sum(p*(1-p))
    adj = float(2.0 * np.sum(p * (1.0 - p)))
    if adj < 1e-10:
        raise ValueError("All SNPs monomorphic after filtering.")

    # ── GPU path ──────────────────────────────────────────────────────────────
    if gpu_available():
        K_gpu = _kinship_gpu_chunked(G_np, p, adj, chunk_size)
        K = to_cpu(K_gpu)
    else:
        # Fast NumPy path with float32
        Z = G_np - 2.0 * p
        K = (Z @ Z.T) / adj

    print(f"[PyGAPIT-GPU]  -> K done. Mean diag = {np.mean(np.diag(K)):.4f}")
    return K.astype(np.float64)


def _kinship_gpu_chunked(G_np, p, adj, chunk_size):
    """Accumulate K = Z Z' / adj in SNP chunks to manage GPU memory."""
    n = G_np.shape[0]
    m = G_np.shape[1]

    # Try CuPy first
    try:
        import cupy as cp
        K_gpu = cp.zeros((n, n), dtype=cp.float32)
        for start in range(0, m, chunk_size):
            end = min(start + chunk_size, m)
            G_chunk = cp.asarray(G_np[:, start:end])
            p_chunk = cp.asarray(p[start:end])
            Z_chunk = G_chunk - 2.0 * p_chunk
            K_gpu += Z_chunk @ Z_chunk.T
            del G_chunk, Z_chunk
            cp.get_default_memory_pool().free_all_blocks()
        K_gpu /= adj
        return K_gpu

    except ImportError:
        pass

    # PyTorch fallback
    import torch
    device = "cuda" if torch.cuda.is_available() else "mps"
    K_t = torch.zeros((n, n), dtype=torch.float32, device=device)
    for start in range(0, m, chunk_size):
        end = min(start + chunk_size, m)
        G_chunk = torch.tensor(G_np[:, start:end], device=device)
        p_chunk = torch.tensor(p[start:end], device=device)
        Z_chunk = G_chunk - 2.0 * p_chunk
        K_t += Z_chunk @ Z_chunk.T
        del G_chunk, Z_chunk
        if device == "cuda":
            torch.cuda.empty_cache()
    K_t /= adj
    return K_t.cpu().numpy()
