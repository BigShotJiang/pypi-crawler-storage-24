"""
PyGAPIT-GPU: GPU-accelerated Genomic Prediction
=================================================
RR-BLUP and G-BLUP using GPU linear solvers.

The bottleneck in RR-BLUP is solving (Z'Z + λI)β = Z'y — an m×m system.
For m=500k SNPs this is dominated by the Z'Z matrix multiply and solve.
GPU gives 10-40x speedup on this step.
"""

import numpy as np
from typing import Optional, Tuple
from .device import gpu_available, to_cpu, get_device


def RR_BLUP_gpu(phenotype:  np.ndarray,
                genotype:   np.ndarray,
                lambda_:    Optional[float] = None,
                n_folds:    int = 5) -> Tuple[np.ndarray, float]:
    """
    GPU-accelerated Ridge Regression BLUP.

    Solves: (Z'Z + λI) u = Z'y   on GPU (m×m system)
    Then GEBV = Z @ u

    Parameters
    ----------
    phenotype : np.ndarray (n,)
    genotype  : np.ndarray (n, m)
    lambda_   : float  ridge parameter (estimated if None, assuming h²=0.5)
    n_folds   : int    cross-validation folds

    Returns
    -------
    gebv : np.ndarray (n,)
    acc  : float  cross-validated Pearson r
    """
    print(f"[PyGAPIT-GPU] RR-BLUP on {get_device().upper()}")
    y = phenotype.astype(np.float64)
    Z = np.nan_to_num(genotype.astype(np.float64))
    n, m = Z.shape

    if lambda_ is None:
        # h² ~ 0.5 assumption (as in GAPIT default)
        lambda_ = float(m * (1.0 - 0.5) / 0.5)
        print(f"[PyGAPIT-GPU]  lambda = {lambda_:.2f}  (h²=0.5 assumption)")

    if gpu_available():
        gebv = _rrblup_solve_gpu(Z, y, lambda_)
    else:
        A    = Z.T @ Z + lambda_ * np.eye(m)
        u    = np.linalg.solve(A, Z.T @ y)
        gebv = Z @ u

    acc = _cv_rrblup(y, Z, lambda_, n_folds)
    print(f"[PyGAPIT-GPU]  RR-BLUP CV accuracy (r): {acc:.4f}")
    return gebv, acc


def _rrblup_solve_gpu(Z, y, lambda_):
    """Solve (Z'Z + λI)u = Z'y on GPU."""
    n, m = Z.shape
    try:
        import cupy as cp
        from cupy import linalg as cpla
        Z_gpu  = cp.asarray(Z.astype(np.float32))
        y_gpu  = cp.asarray(y.astype(np.float32))
        ZtZ    = Z_gpu.T @ Z_gpu
        ZtZ   += lambda_ * cp.eye(m, dtype=cp.float32)
        Zty    = Z_gpu.T @ y_gpu
        u      = cpla.solve(ZtZ, Zty)
        gebv   = Z_gpu @ u
        return to_cpu(gebv).astype(np.float64)

    except ImportError:
        pass

    import torch
    device = "cuda" if torch.cuda.is_available() else "mps"
    Z_t  = torch.tensor(Z, dtype=torch.float32, device=device)
    y_t  = torch.tensor(y, dtype=torch.float32, device=device)
    ZtZ  = Z_t.T @ Z_t
    ZtZ += lambda_ * torch.eye(m, device=device)
    Zty  = Z_t.T @ y_t
    u    = torch.linalg.solve(ZtZ, Zty)
    return (Z_t @ u).cpu().numpy().astype(np.float64)


def _cv_rrblup(y, Z, lambda_, n_folds):
    n, m = Z.shape
    fold  = n // n_folds
    preds = np.zeros(n)
    for f in range(n_folds):
        test  = np.arange(f*fold, min((f+1)*fold, n))
        train = np.setdiff1d(np.arange(n), test)
        Zt, yt = Z[train], y[train]
        A = Zt.T @ Zt + lambda_ * np.eye(m)
        u = np.linalg.solve(A, Zt.T @ yt)
        preds[test] = Z[test] @ u
    return float(np.corrcoef(y, preds)[0, 1])


def GBLUP_gpu(phenotype: np.ndarray,
              kinship:   np.ndarray,
              n_folds:   int = 5,
              h2:        float = 0.5) -> Tuple[np.ndarray, float]:
    """
    GPU-accelerated G-BLUP.

    Solves Henderson's MME:  (K + λI) v = y_adjusted   on GPU (n×n system)
    GEBV = K @ v

    Parameters
    ----------
    phenotype : np.ndarray (n,)
    kinship   : np.ndarray (n, n)  -- GRM
    h2        : float  heritability (default 0.5)

    Returns
    -------
    gebv : np.ndarray (n,)
    acc  : float
    """
    print(f"[PyGAPIT-GPU] G-BLUP on {get_device().upper()}")
    y  = phenotype.astype(np.float64)
    n  = len(y)
    mu = np.nanmean(y)
    lambda_ = (1.0 - h2) / h2

    if gpu_available():
        gebv = _gblup_solve_gpu(y - mu, kinship, lambda_)
    else:
        V    = kinship + lambda_ * np.eye(n)
        Vinv = np.linalg.inv(V)
        gebv = kinship @ Vinv @ (y - mu)

    # Cross-validation
    fold_size = n // n_folds
    preds = np.zeros(n)
    for fold in range(n_folds):
        test  = np.arange(fold*fold_size, min((fold+1)*fold_size, n))
        train = np.setdiff1d(np.arange(n), test)
        K_tt  = kinship[np.ix_(train, train)]
        K_pt  = kinship[np.ix_(test, train)]
        y_t   = y[train] - np.mean(y[train])
        V_t   = K_tt + lambda_ * np.eye(len(train))
        preds[test] = K_pt @ np.linalg.solve(V_t, y_t) + np.mean(y[train])

    acc = float(np.corrcoef(y, preds)[0, 1])
    print(f"[PyGAPIT-GPU]  G-BLUP CV accuracy (r): {acc:.4f}")
    return gebv + mu, acc


def _gblup_solve_gpu(y_centered, K, lambda_):
    n = len(y_centered)
    try:
        import cupy as cp
        K_gpu  = cp.asarray(K.astype(np.float32))
        y_gpu  = cp.asarray(y_centered.astype(np.float32))
        V      = K_gpu + lambda_ * cp.eye(n, dtype=cp.float32)
        v      = cp.linalg.solve(V, y_gpu)
        gebv   = K_gpu @ v
        return to_cpu(gebv).astype(np.float64)
    except ImportError:
        pass

    import torch
    device = "cuda" if torch.cuda.is_available() else "mps"
    K_t = torch.tensor(K, dtype=torch.float32, device=device)
    y_t = torch.tensor(y_centered, dtype=torch.float32, device=device)
    V   = K_t + lambda_ * torch.eye(n, device=device)
    v   = torch.linalg.solve(V, y_t)
    return (K_t @ v).cpu().numpy().astype(np.float64)
