"""
PyGAPIT-GPU Device Manager
===========================
Detects available hardware (CUDA GPU, Apple MPS, CPU) and provides
a unified array backend (CuPy if CUDA available, else NumPy).

Usage
-----
from pygapit_gpu.device import xp, get_device, to_cpu

# xp is either cupy or numpy — write code once, runs on both
K = xp.zeros((n, n))
result_np = to_cpu(K)   # always returns a numpy array
"""

import numpy as np
import warnings

# ── Backend detection ────────────────────────────────────────────────────────
_BACKEND = "cpu"
_cupy_available = False
_torch_available = False

try:
    import cupy as cp
    cp.array([1.0])          # test actual CUDA access
    _cupy_available = True
    _BACKEND = "cuda"
    xp = cp
    print("[PyGAPIT-GPU] ✓ CuPy / CUDA GPU detected — using GPU backend.")
except Exception:
    xp = np
    print("[PyGAPIT-GPU] CuPy not available — using NumPy (CPU) backend.")

try:
    import torch
    if torch.cuda.is_available():
        _torch_available = True
        _BACKEND = "cuda"
        print(f"[PyGAPIT-GPU] ✓ PyTorch CUDA: {torch.cuda.get_device_name(0)}")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        _BACKEND = "mps"
        print("[PyGAPIT-GPU] ✓ PyTorch MPS (Apple Silicon) detected.")
except ImportError:
    pass


def gpu_available() -> bool:
    """Return True if a GPU backend (CUDA or MPS) is available."""
    return _BACKEND in ("cuda", "mps")


def get_device() -> str:
    """Return current backend: 'cuda', 'mps', or 'cpu'."""
    return _BACKEND


def to_cpu(arr) -> np.ndarray:
    """
    Move any array (CuPy, PyTorch Tensor, or NumPy) to CPU as numpy ndarray.
    Safe to call even if already on CPU.
    """
    if _cupy_available:
        import cupy as cp
        if isinstance(arr, cp.ndarray):
            return cp.asnumpy(arr)
    try:
        import torch
        if isinstance(arr, torch.Tensor):
            return arr.detach().cpu().numpy()
    except ImportError:
        pass
    return np.asarray(arr)


def to_gpu(arr: np.ndarray):
    """
    Move a NumPy array to the available GPU backend.
    Returns CuPy array if CUDA, else NumPy unchanged.
    """
    if _cupy_available:
        import cupy as cp
        return cp.asarray(arr)
    return arr


def benchmark_device(n: int = 1000) -> dict:
    """
    Benchmark matrix multiply on available device.
    Useful in Colab to confirm GPU speedup.

    Returns dict with cpu_ms and gpu_ms (if available).
    """
    import time

    A_np = np.random.randn(n, n).astype(np.float32)
    B_np = np.random.randn(n, n).astype(np.float32)

    t0 = time.perf_counter()
    _ = A_np @ B_np
    cpu_ms = (time.perf_counter() - t0) * 1000

    result = {"n": n, "cpu_ms": round(cpu_ms, 2)}

    if _cupy_available:
        import cupy as cp
        A_gpu = cp.asarray(A_np)
        B_gpu = cp.asarray(B_np)
        cp.cuda.Stream.null.synchronize()
        t0 = time.perf_counter()
        _ = A_gpu @ B_gpu
        cp.cuda.Stream.null.synchronize()
        gpu_ms = (time.perf_counter() - t0) * 1000
        result["gpu_ms"] = round(gpu_ms, 2)
        result["speedup"] = round(cpu_ms / max(gpu_ms, 0.01), 1)
        print(f"[PyGAPIT-GPU] Benchmark n={n}: CPU={cpu_ms:.1f}ms  GPU={gpu_ms:.1f}ms  Speedup={result['speedup']}x")
    elif _torch_available:
        import torch
        device = "cuda" if torch.cuda.is_available() else "mps"
        A_t = torch.tensor(A_np, device=device)
        B_t = torch.tensor(B_np, device=device)
        if device == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        _ = A_t @ B_t
        if device == "cuda":
            torch.cuda.synchronize()
        gpu_ms = (time.perf_counter() - t0) * 1000
        result["gpu_ms"] = round(gpu_ms, 2)
        result["speedup"] = round(cpu_ms / max(gpu_ms, 0.01), 1)
        print(f"[PyGAPIT-GPU] Benchmark n={n}: CPU={cpu_ms:.1f}ms  {device.upper()}={gpu_ms:.1f}ms  Speedup={result['speedup']}x")
    else:
        print(f"[PyGAPIT-GPU] Benchmark n={n}: CPU={cpu_ms:.1f}ms  (no GPU detected)")

    return result
