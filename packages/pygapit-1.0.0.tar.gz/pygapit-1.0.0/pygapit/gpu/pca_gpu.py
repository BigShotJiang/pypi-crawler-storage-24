"""
PyGAPIT-GPU: GPU-accelerated PCA
==================================
SVD of large genotype matrices on GPU.
For n=5000 taxa, m=500k SNPs the truncated SVD is the bottleneck.
GPU-based randomised SVD (via CuPy or torch.linalg.svd) is 20-50x faster.
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple
from .device import gpu_available, to_cpu, get_device


def compute_pca_gpu(geno:         np.ndarray,
                    n_components: int = 3,
                    taxa_names:   Optional[list] = None,
                    method:       str = "randomised") -> Tuple[pd.DataFrame, np.ndarray]:
    """
    GPU-accelerated PCA via randomised or full SVD.

    Parameters
    ----------
    geno         : np.ndarray (n, m)
    n_components : int
    method       : 'randomised'  -- fast approximate SVD (recommended for m>10k)
                   'full'        -- exact SVD (slower, more accurate)

    Returns
    -------
    pc_df    : pd.DataFrame (n, n_components)
    explained: np.ndarray proportion variance explained
    """
    print(f"[PyGAPIT-GPU] PCA ({method}, {n_components} PCs) on {get_device().upper()}")
    G = np.nan_to_num(geno.astype(np.float32))
    col_mean = G.mean(axis=0)
    Gc = G - col_mean

    if gpu_available() and method == "randomised":
        scores, explained = _randomised_svd_gpu(Gc, n_components)
    elif gpu_available() and method == "full":
        scores, explained = _full_svd_gpu(Gc, n_components)
    else:
        U, S, _ = np.linalg.svd(Gc, full_matrices=False)
        scores   = U[:, :n_components] * S[:n_components]
        var      = S**2
        explained = var[:n_components] / var.sum()

    cols  = [f"PC{i+1}" for i in range(n_components)]
    pc_df = pd.DataFrame(scores, columns=cols, index=taxa_names)
    pct   = [f"{e*100:.2f}%" for e in explained]
    print(f"[PyGAPIT-GPU]  Variance explained: {', '.join(pct)}")
    return pc_df, explained


def _full_svd_gpu(Gc, k):
    try:
        import cupy as cp
        from cupy import linalg as cpla
        Gc_gpu = cp.asarray(Gc)
        U, S, _ = cpla.svd(Gc_gpu, full_matrices=False)
        S_np = to_cpu(S)
        U_np = to_cpu(U[:, :k])
        scores   = U_np * S_np[:k]
        var      = S_np**2
        explained = var[:k] / var.sum()
        return scores, explained
    except ImportError:
        pass

    import torch
    device = "cuda" if torch.cuda.is_available() else "mps"
    Gc_t = torch.tensor(Gc, device=device)
    U, S, _ = torch.linalg.svd(Gc_t, full_matrices=False)
    S_np = S.cpu().numpy()
    scores   = U[:, :k].cpu().numpy() * S_np[:k]
    var      = S_np**2
    explained = var[:k] / var.sum()
    return scores, explained


def _randomised_svd_gpu(Gc, k, oversampling=10, n_power_iter=2):
    """
    Randomised SVD (Halko et al. 2011) on GPU.
    Much faster than full SVD for large m >> n, k << n.
    """
    n, m = Gc.shape
    l = k + oversampling    # sketch size

    try:
        import cupy as cp
        Gc_gpu = cp.asarray(Gc)
        # Sketch: Y = Gc @ Omega,  Omega ~ N(0,1)
        Omega  = cp.random.randn(m, l).astype(cp.float32)
        Y      = Gc_gpu @ Omega
        # Power iteration for better approximation
        for _ in range(n_power_iter):
            Y = Gc_gpu @ (Gc_gpu.T @ Y)
        Q, _ = cp.linalg.qr(Y)
        B    = Q.T @ Gc_gpu                # (l, m)
        _, S, Vt = cp.linalg.svd(B, full_matrices=False)
        U    = Q @ _  if False else Q   # skip — use Q directly
        # Reconstruct U: U = Q * U_B
        U_B, S_B, Vt_B = cp.linalg.svd(B, full_matrices=False)
        U    = Q @ U_B
        S_np = to_cpu(S_B[:k])
        U_np = to_cpu(U[:, :k])
        scores    = U_np * S_np
        # Approximate variance explained
        var       = S_np**2
        explained = var / to_cpu(cp.sum(Gc_gpu**2))
        return scores, explained

    except ImportError:
        pass

    # PyTorch randomised SVD
    import torch
    device = "cuda" if torch.cuda.is_available() else "mps"
    Gc_t  = torch.tensor(Gc, device=device)
    Omega = torch.randn(m, l, dtype=torch.float32, device=device)
    Y     = Gc_t @ Omega
    for _ in range(n_power_iter):
        Y = Gc_t @ (Gc_t.T @ Y)
    Q, _  = torch.linalg.qr(Y)
    B     = Q.T @ Gc_t
    U_B, S_B, _ = torch.linalg.svd(B, full_matrices=False)
    U     = Q @ U_B
    S_np  = S_B[:k].cpu().numpy()
    U_np  = U[:, :k].cpu().numpy()
    scores    = U_np * S_np
    total_var = float((Gc_t**2).sum().cpu())
    explained = S_np**2 / total_var
    return scores, explained
