"""
PyGAPIT PCA Module
==================
Principal Component Analysis for population structure control.
Mirrors GAPIT's PCA computation (via SVD of the kinship / genotype matrix).
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional


def compute_pca(geno: np.ndarray,
                n_components: int = 3,
                taxa_names: Optional[list] = None,
                method: str = "genotype") -> Tuple[pd.DataFrame, np.ndarray]:
    """
    Compute principal components from genotype data.

    Parameters
    ----------
    geno        : np.ndarray (n_taxa, n_snps)
    n_components: int  -- number of PCs to retain
    taxa_names  : list of taxon IDs
    method      : 'genotype'  -> SVD of centered genotype matrix
                  'kinship'   -> eigen-decomposition of GRM

    Returns
    -------
    pc_df       : pd.DataFrame  (n_taxa, n_components)  columns = PC1 .. PCk
    explained   : np.ndarray    proportion of variance explained per PC
    """
    print(f"[PyGAPIT] Computing PCA ({method}, {n_components} components) ...")
    G = np.nan_to_num(geno.astype(float))

    if method == "kinship":
        from ..kinship.kinship import VanRaden_kinship
        K = VanRaden_kinship(G)
        eigvals, eigvecs = np.linalg.eigh(K)
        # eigh returns ascending; flip
        idx = np.argsort(eigvals)[::-1]
        eigvals, eigvecs = eigvals[idx], eigvecs[:, idx]
        scores = eigvecs[:, :n_components] * eigvals[:n_components]
        explained = eigvals[:n_components] / eigvals.sum()
    else:
        # Centre columns
        col_mean = np.nanmean(G, axis=0)
        Gc = G - col_mean
        U, S, Vt = np.linalg.svd(Gc, full_matrices=False)
        scores = U[:, :n_components] * S[:n_components]
        var = S ** 2
        explained = var[:n_components] / var.sum()

    cols = [f"PC{i+1}" for i in range(n_components)]
    pc_df = pd.DataFrame(scores, columns=cols, index=taxa_names)
    pct = [f"{e*100:.2f}%" for e in explained]
    print(f"[PyGAPIT]  -> Variance explained: {', '.join(pct)}")
    return pc_df, explained
