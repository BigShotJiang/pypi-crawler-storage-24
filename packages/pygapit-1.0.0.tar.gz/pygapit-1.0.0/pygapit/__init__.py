"""
pygapit — Genome Association and Prediction Integrated Tool (Python)
=====================================================================
A Python library replicating the GAPIT R package for GWAS and
genomic prediction.

Basic usage
-----------
>>> from pygapit import GAPIT
>>> result = GAPIT(Y=pheno_df, G=(snp_info, geno), model=["MLM","BLINK"])

GPU usage (requires torch or cupy)
-----------------------------------
>>> from pygapit.gpu import GLM_gpu, MLM_gpu, VanRaden_kinship_gpu
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("pygapit")
except PackageNotFoundError:
    __version__ = "1.0.0"

# ── Core API ──────────────────────────────────────────────────────────────────
from .gapit import GAPIT

# I/O
from .io.readers import read_hapmap, read_numeric_genotype, read_phenotype

# Kinship
from .kinship.kinship import VanRaden_kinship, loiselle_kinship, EMMA_kinship

# PCA
from .pca.pca import compute_pca

# GWAS models
from .gwas.glm     import GLM
from .gwas.mlm     import MLM
from .gwas.mlmm    import MLMM
from .gwas.farmcpu import FarmCPU
from .gwas.blink   import BLINK

# Genomic prediction
from .models.genomic_prediction import RR_BLUP, GBLUP, BayesB

# Visualisation
from .visualization.plots import manhattan_plot, qq_plot, pca_plot, kinship_heatmap

# Utilities
from .utils.stats import bonferroni_threshold, fdr_threshold, genomic_inflation
from .utils.ld    import LD_decay, LD_matrix

__all__ = [
    # Main
    "GAPIT",
    # I/O
    "read_hapmap", "read_numeric_genotype", "read_phenotype",
    # Kinship
    "VanRaden_kinship", "loiselle_kinship", "EMMA_kinship",
    # PCA
    "compute_pca",
    # GWAS
    "GLM", "MLM", "MLMM", "FarmCPU", "BLINK",
    # Prediction
    "RR_BLUP", "GBLUP", "BayesB",
    # Plots
    "manhattan_plot", "qq_plot", "pca_plot", "kinship_heatmap",
    # Utils
    "bonferroni_threshold", "fdr_threshold", "genomic_inflation",
    "LD_decay", "LD_matrix",
]
