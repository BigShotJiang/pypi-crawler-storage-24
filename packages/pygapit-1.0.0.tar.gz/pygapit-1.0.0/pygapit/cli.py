"""
pygapit CLI — command-line entry point
=======================================

Usage
-----
  pygapit --help
  pygapit run --pheno pheno.txt --geno mydata.hmp.txt --model MLM FarmCPU
  pygapit demo
  pygapit benchmark
"""

import argparse
import sys


def _run(args):
    import numpy as np
    import pandas as pd
    from pygapit import GAPIT

    print(f"[pygapit] Loading phenotype: {args.pheno}")
    print(f"[pygapit] Loading genotype:  {args.geno}")
    print(f"[pygapit] Models: {args.model}")

    GAPIT(
        Y          = args.pheno,
        G          = args.geno,
        model      = args.model,
        PCA_total  = args.pca,
        kinship    = args.kinship,
        output_dir = args.output,
        SNP_impute = args.impute,
    )


def _demo(args):
    """Run the built-in simulation demo."""
    import numpy as np
    import pandas as pd
    from pygapit import GAPIT, VanRaden_kinship, compute_pca

    np.random.seed(42)
    N, M = 200, 500
    print(f"[pygapit demo] Simulating {N} taxa × {M} SNPs ...")

    geno = np.random.choice([0,1,2], size=(N, M), p=[0.25,0.5,0.25]).astype(float)
    snp_info = pd.DataFrame({
        "SNP":        [f"SNP_{i}" for i in range(M)],
        "Chromosome": [i//(M//5)+1 for i in range(M)],
        "Position":   [i*100_000 for i in range(M)],
    })
    causal  = np.random.choice(M, 5, replace=False)
    effects = np.random.normal(0, 1, 5)
    y       = geno[:, causal] @ effects + np.random.normal(0, 1, N)
    pheno   = pd.DataFrame({"Yield": y}, index=[f"Taxa_{i}" for i in range(N)])

    GAPIT(
        Y          = pheno,
        G          = (snp_info, geno),
        model      = args.model,
        output_dir = args.output,
    )


def _benchmark(args):
    """Benchmark CPU vs GPU."""
    try:
        from pygapit.gpu import benchmark_device
        benchmark_device(n=args.size)
    except ImportError:
        print("[pygapit] GPU module not available. Install with: pip install pygapit[gpu]")


def main():
    parser = argparse.ArgumentParser(
        prog="pygapit",
        description="PyGAPIT — Genome Association and Prediction Integrated Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pygapit run --pheno pheno.txt --geno data.hmp.txt --model MLM FarmCPU
  pygapit demo --model GLM MLM --output ./results
  pygapit benchmark --size 2000
        """,
    )
    parser.add_argument("--version", action="version", version="%(prog)s 1.0.0")

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── run ──────────────────────────────────────────────────────────────────
    p_run = subparsers.add_parser("run", help="Run GWAS pipeline")
    p_run.add_argument("--pheno",   required=True,  help="Phenotype file (TSV, taxa × traits)")
    p_run.add_argument("--geno",    required=True,  help="Genotype file (HapMap or numeric TSV)")
    p_run.add_argument("--model",   nargs="+",      default=["MLM"],
                       choices=["GLM","MLM","MLMM","FarmCPU","BLINK"],
                       help="GWAS model(s) to run (default: MLM)")
    p_run.add_argument("--pca",     type=int,       default=3,
                       help="Number of PCs for population structure (default: 3)")
    p_run.add_argument("--kinship", default="VanRaden",
                       choices=["VanRaden","Loiselle","EMMA"],
                       help="Kinship estimation method (default: VanRaden)")
    p_run.add_argument("--impute",  default="Middle",
                       choices=["Major","Middle","Minor"],
                       help="Missing genotype imputation (default: Middle)")
    p_run.add_argument("--output",  default="./GAPIT_output",
                       help="Output directory (default: ./GAPIT_output)")
    p_run.set_defaults(func=_run)

    # ── demo ─────────────────────────────────────────────────────────────────
    p_demo = subparsers.add_parser("demo", help="Run built-in simulation demo")
    p_demo.add_argument("--model",  nargs="+", default=["GLM","MLM"],
                        choices=["GLM","MLM","MLMM","FarmCPU","BLINK"])
    p_demo.add_argument("--output", default="./GAPIT_demo")
    p_demo.set_defaults(func=_demo)

    # ── benchmark ────────────────────────────────────────────────────────────
    p_bench = subparsers.add_parser("benchmark", help="Benchmark CPU vs GPU speed")
    p_bench.add_argument("--size", type=int, default=1000,
                         help="Matrix size n for benchmark (default: 1000)")
    p_bench.set_defaults(func=_benchmark)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
