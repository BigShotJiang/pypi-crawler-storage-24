"""
PyGAPIT I/O Module
==================
Readers for HapMap, numeric genotype, and phenotype files.
Mirrors GAPIT.HapMap(), GAPIT.Numericalization(), etc.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional


def read_hapmap(filepath: str, SNP_impute: str = "Middle") -> Tuple[pd.DataFrame, np.ndarray]:
    """
    Read a HapMap-format genotype file and convert to numeric (0/1/2) matrix.

    Parameters
    ----------
    filepath : str
        Path to HapMap file (.hmp.txt or .hmp.txt.gz)
    SNP_impute : str
        Imputation method: 'Major', 'Middle', 'Minor'

    Returns
    -------
    snp_info : pd.DataFrame
        Columns: rs, alleles, chrom, pos, strand, ...
    geno_numeric : np.ndarray
        shape (n_taxa, n_snps), values in {0, 1, 2}
    """
    print(f"[PyGAPIT] Reading HapMap file: {filepath}")
    hmp = pd.read_csv(filepath, sep="\t", header=0, low_memory=False)

    # Standard HapMap columns
    meta_cols = ["rs#", "alleles", "chrom", "pos", "strand",
                 "assembly#", "center", "protLSID", "assayLSID",
                 "panelLSID", "QCcode"]
    available_meta = [c for c in meta_cols if c in hmp.columns]
    snp_info = hmp[available_meta].copy()
    snp_info.rename(columns={"rs#": "SNP", "chrom": "Chromosome", "pos": "Position"}, inplace=True)

    taxa_data = hmp.drop(columns=available_meta)
    iupac = _build_iupac_table()
    geno_numeric = _hapmap_to_numeric(taxa_data, snp_info, iupac, SNP_impute)

    print(f"[PyGAPIT]  -> {geno_numeric.shape[1]} SNPs x {geno_numeric.shape[0]} taxa loaded.")
    return snp_info, geno_numeric


def _build_iupac_table() -> dict:
    """IUPAC ambiguity code -> set of bases."""
    return {
        "A": {"A", "A"}, "T": {"T", "T"}, "C": {"C", "C"}, "G": {"G", "G"},
        "R": {"A", "G"}, "Y": {"C", "T"}, "S": {"G", "C"},
        "W": {"A", "T"}, "K": {"G", "T"}, "M": {"A", "C"},
        "N": {None},     "0": {None},     "-": {None},
    }


def _hapmap_to_numeric(taxa_data: pd.DataFrame,
                        snp_info: pd.DataFrame,
                        iupac: dict,
                        SNP_impute: str) -> np.ndarray:
    """Convert IUPAC HapMap genotypes to 0/1/2 allele-count matrix."""
    n_taxa = taxa_data.shape[1]
    n_snps = taxa_data.shape[0]
    geno = np.full((n_taxa, n_snps), np.nan)

    for j, (_, row) in enumerate(taxa_data.iterrows()):
        alleles_str = snp_info.iloc[j]["alleles"] if "alleles" in snp_info.columns else None
        if alleles_str and "/" in str(alleles_str):
            ref, alt = str(alleles_str).split("/")[:2]
        else:
            bases = [b for b in row if b in "ATCG"]
            freqs = pd.Series(bases).value_counts()
            ref = freqs.index[0] if len(freqs) > 0 else "A"
            alt = freqs.index[1] if len(freqs) > 1 else "T"

        for i, geno_call in enumerate(row):
            g = str(geno_call).upper()
            bases = iupac.get(g, {None})
            if None in bases:
                geno[i, j] = np.nan
            else:
                count = sum(1 for b in bases if b == alt)
                geno[i, j] = float(count)

    # Impute missing
    geno = _impute(geno, method=SNP_impute)
    return geno


def _impute(geno: np.ndarray, method: str = "Middle") -> np.ndarray:
    """Impute missing genotype values."""
    for j in range(geno.shape[1]):
        col = geno[:, j]
        missing = np.isnan(col)
        if not missing.any():
            continue
        valid = col[~missing]
        if method == "Major":
            fill = float(np.bincount(valid.astype(int)).argmax())
        elif method == "Minor":
            counts = np.bincount(valid.astype(int))
            fill = float(np.argmin(counts[counts > 0]))
        else:  # Middle
            fill = np.nanmean(col)
        geno[missing, j] = fill
    return geno


def read_numeric_genotype(filepath: str) -> Tuple[pd.DataFrame, np.ndarray]:
    """
    Read a pre-converted numeric genotype file (taxa x SNPs, values 0/1/2).

    Returns
    -------
    snp_info : pd.DataFrame  (SNP, Chromosome, Position)
    geno     : np.ndarray    (n_taxa, n_snps)
    """
    print(f"[PyGAPIT] Reading numeric genotype: {filepath}")
    df = pd.read_csv(filepath, sep="\t", header=0, index_col=0)
    # Expect first 3 rows to be SNP / Chrom / Pos
    snp_info = df.iloc[:3].T.copy()
    snp_info.columns = ["SNP", "Chromosome", "Position"]
    snp_info["Chromosome"] = pd.to_numeric(snp_info["Chromosome"], errors="coerce")
    snp_info["Position"] = pd.to_numeric(snp_info["Position"], errors="coerce")
    geno = df.iloc[3:].values.astype(float)
    print(f"[PyGAPIT]  -> {geno.shape[1]} SNPs x {geno.shape[0]} taxa loaded.")
    return snp_info, geno


def read_phenotype(filepath: str, sep: str = "\t") -> pd.DataFrame:
    """
    Read phenotype file.  First column = taxon name, remaining = traits.

    Returns
    -------
    pd.DataFrame with index = taxon names, columns = trait names
    """
    print(f"[PyGAPIT] Reading phenotype: {filepath}")
    pheno = pd.read_csv(filepath, sep=sep, header=0, index_col=0)
    print(f"[PyGAPIT]  -> {pheno.shape[0]} taxa, {pheno.shape[1]} trait(s): {list(pheno.columns)}")
    return pheno
