from .readers import read_hapmap, read_numeric_genotype, read_phenotype
