"""
PyGAPIT - Multi-Locus Mixed Model (MLMM)
=========================================
Step-wise regression that adds associated SNPs as cofactors into the MLM.
Ref: Segura et al. (2012) Nature Genetics.
"""

import numpy as np
import pandas as pd
from .mlm import MLM
from typing import Optional


def MLMM(phenotype: np.ndarray,
         genotype: np.ndarray,
         snp_info: pd.DataFrame,
         kinship: np.ndarray,
         covariates: Optional[np.ndarray] = None,
         trait_name: str = "Trait",
         max_cofactors: int = 10,
         p_threshold: float = 0.05 / 10000) -> pd.DataFrame:
    """
    Multi-Locus Mixed Model (MLMM) GWAS via forward stepwise selection.

    Parameters
    ----------
    max_cofactors : int   -- max SNPs to add as cofactors
    p_threshold   : float -- Bonferroni-style threshold to stop adding cofactors

    Returns
    -------
    results : pd.DataFrame (final round results)
    """
    print(f"[PyGAPIT] Running MLMM GWAS for trait: {trait_name}")
    cofactor_idx = []
    covar = covariates.copy() if covariates is not None else None

    for step in range(max_cofactors):
        print(f"[PyGAPIT]  MLMM step {step+1}: {len(cofactor_idx)} cofactor(s)")
        results = MLM(phenotype, genotype, snp_info, kinship,
                      covariates=covar, trait_name=trait_name)

        # Exclude already-selected cofactors
        candidate = results.drop(index=cofactor_idx, errors="ignore")
        best_idx = candidate["P.value"].idxmin()
        best_p = candidate.loc[best_idx, "P.value"]

        if best_p > p_threshold:
            print(f"[PyGAPIT]  MLMM stopping: best p={best_p:.2e} > threshold")
            break

        cofactor_idx.append(best_idx)
        new_snp = genotype[:, best_idx].reshape(-1, 1).astype(float)
        covar = np.hstack([covar, new_snp]) if covar is not None else new_snp
        print(f"[PyGAPIT]  Added cofactor SNP: {snp_info.iloc[best_idx]['SNP']} (p={best_p:.2e})")

    results["Cofactor"] = results.index.isin(cofactor_idx)
    print(f"[PyGAPIT]  -> MLMM done with {len(cofactor_idx)} cofactor(s).")
    return results
