"""
PyGAPIT - Mixed Linear Model (MLM / P3D)
"""
import numpy as np
import pandas as pd
from scipy import stats
from typing import Optional
import warnings


def _EMMA_vc(y, X, K):
    """EMMA variance component estimation via spectral decomposition."""
    n = len(y)
    eigvals, U = np.linalg.eigh(K)
    eigvals = np.maximum(eigvals, 1e-8)
    Uy = U.T @ y
    UX = U.T @ X

    def neg_reml(delta):
        d = eigvals + delta
        UXd = UX / d[:, np.newaxis]          # (n, k)
        gram = UX.T @ UXd                    # (k, k)
        rhs  = UXd.T @ Uy                    # (k,)
        try:
            beta = np.linalg.solve(gram, rhs)
        except np.linalg.LinAlgError:
            return 1e15
        res  = Uy - UX @ beta
        s2   = np.sum(res**2 / d) / (n - X.shape[1])
        ll   = np.sum(np.log(d)) + (n - X.shape[1]) * np.log(max(s2, 1e-15)) + n
        return ll

    from scipy.optimize import minimize_scalar
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        opt = minimize_scalar(neg_reml, bounds=(1e-4, 1e4), method="bounded")

    delta = opt.x
    d = eigvals + delta
    UXd  = UX / d[:, np.newaxis]
    gram = UX.T @ UXd
    rhs  = UXd.T @ Uy
    beta = np.linalg.lstsq(gram, rhs, rcond=None)[0]
    resid = Uy - UX @ beta
    Vg = np.sum(resid**2 / d) / (n - X.shape[1])
    Ve = delta * Vg
    return delta, Vg, Ve, U, eigvals, beta


def MLM(phenotype, genotype, snp_info, kinship,
        covariates=None, trait_name="Trait", method="P3D"):
    """Mixed Linear Model (EMMA/P3D) GWAS."""
    print(f"[PyGAPIT] Running MLM ({method}) GWAS for trait: {trait_name}")
    y = phenotype.astype(float)
    mask = ~np.isnan(y)
    y, K = y[mask], kinship[np.ix_(mask, mask)]
    G = genotype[mask, :]
    n, m = G.shape

    X_base = np.ones((n, 1))
    if covariates is not None:
        X_base = np.hstack([X_base, covariates[mask]])

    # Estimate VC once (P3D)
    delta, Vg, Ve, _, _, _ = _EMMA_vc(y, X_base, K)
    print(f"[PyGAPIT]  Vg={Vg:.4f}  Ve={Ve:.4f}  delta={delta:.4f}")

    # Pre-compute eigen of K for fast per-SNP testing
    eigvals_K, U_K = np.linalg.eigh(K)
    eigvals_K = np.maximum(eigvals_K, 1e-8)
    d0 = eigvals_K + delta          # base denominator

    Uy_base = U_K.T @ y
    UX_base = U_K.T @ X_base

    results = []
    for j in range(m):
        snp_col = G[:, j].astype(float)
        valid = ~np.isnan(snp_col)
        if valid.sum() < X_base.shape[1] + 2 or np.std(snp_col[valid]) < 1e-8:
            results.append({"SNP": snp_info.iloc[j]["SNP"],
                            "Chromosome": snp_info.iloc[j].get("Chromosome", np.nan),
                            "Position": snp_info.iloc[j].get("Position", np.nan),
                            "Effect": 0.0, "SE": np.nan, "P.value": 1.0})
            continue

        try:
            Uz = U_K.T @ snp_col
            UX = np.hstack([UX_base, Uz.reshape(-1, 1)])   # (n, k+1)
            UXd  = UX / d0[:, np.newaxis]
            gram = UX.T @ UXd
            rhs  = UXd.T @ Uy_base
            beta = np.linalg.lstsq(gram, rhs, rcond=None)[0]
            res  = Uy_base - UX @ beta
            df_res = n - UX.shape[1]
            sigma2 = np.sum(res**2 / d0) / df_res if df_res > 0 else 1e15
            cov_b = sigma2 * np.linalg.pinv(gram)
            effect = float(beta[-1])
            se     = float(np.sqrt(max(cov_b[-1, -1], 0)))
            t_stat = effect / se if se > 1e-12 else 0.0
            p_val  = float(2 * stats.t.sf(abs(t_stat), df=df_res))
        except Exception:
            p_val, effect, se = 1.0, 0.0, np.nan

        results.append({"SNP": snp_info.iloc[j]["SNP"],
                        "Chromosome": snp_info.iloc[j].get("Chromosome", np.nan),
                        "Position": snp_info.iloc[j].get("Position", np.nan),
                        "Effect": effect, "SE": se, "P.value": p_val})

    df = pd.DataFrame(results)
    df["-log10(P)"] = -np.log10(df["P.value"].clip(lower=1e-300))
    print(f"[PyGAPIT]  -> MLM done. Significant (p<0.05): {(df['P.value']<0.05).sum()}")
    return df
