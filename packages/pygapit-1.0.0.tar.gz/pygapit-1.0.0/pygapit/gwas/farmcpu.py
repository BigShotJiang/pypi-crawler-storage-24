"""
PyGAPIT - FarmCPU (Fixed and random model Circulating Probability Unification)
===============================================================================
Iterative procedure alternating between:
  1. Fixed-effect model (GLM with pseudo-QTNs as cofactors)
  2. Random-effect model (MLM to update pseudo-QTN selection)

Ref: Liu et al. (2016) PLOS Genetics.
"""

import numpy as np
import pandas as pd
from .glm import GLM
from .mlm import MLM
from ..kinship.kinship import VanRaden_kinship
from typing import Optional


def FarmCPU(phenotype: np.ndarray,
            genotype: np.ndarray,
            snp_info: pd.DataFrame,
            kinship: Optional[np.ndarray] = None,
            covariates: Optional[np.ndarray] = None,
            trait_name: str = "Trait",
            max_iterations: int = 10,
            p_threshold: float = 1.0,
            bin_size: int = 10,
            bin_selection: int = 10) -> pd.DataFrame:
    """
    Run FarmCPU GWAS.

    Parameters
    ----------
    max_iterations : int   -- max EM-like iterations
    bin_size       : int   -- bin size for pseudo-QTN binning
    bin_selection  : int   -- top SNPs selected per bin

    Returns
    -------
    results : pd.DataFrame
    """
    print(f"[PyGAPIT] Running FarmCPU GWAS for trait: {trait_name}")
    if kinship is None:
        kinship = VanRaden_kinship(genotype)

    pseudo_qtns = []   # column indices of current pseudo-QTNs
    prev_qtns = set()
    covar = covariates.copy() if covariates is not None else None

    for iteration in range(max_iterations):
        print(f"[PyGAPIT]  FarmCPU iteration {iteration+1}, pseudo-QTNs: {len(pseudo_qtns)}")

        # Step 1: Fixed model with pseudo-QTNs as covariates
        fixed_covar = covar
        if pseudo_qtns:
            qtn_matrix = genotype[:, pseudo_qtns].astype(float)
            fixed_covar = np.hstack([fixed_covar, qtn_matrix]) if fixed_covar is not None else qtn_matrix

        glm_results = GLM(phenotype, genotype, snp_info,
                          covariates=fixed_covar, trait_name=trait_name)

        # Step 2: Bin and select new pseudo-QTNs
        new_qtns = _bin_and_select(glm_results, genotype, snp_info,
                                   bin_size, bin_selection)

        if set(new_qtns) == prev_qtns:
            print("[PyGAPIT]  FarmCPU converged.")
            break
        prev_qtns = set(new_qtns)
        pseudo_qtns = new_qtns

    glm_results["Pseudo_QTN"] = glm_results.index.isin(pseudo_qtns)
    print(f"[PyGAPIT]  -> FarmCPU done. Pseudo-QTNs: {len(pseudo_qtns)}")
    return glm_results


def _bin_and_select(results: pd.DataFrame,
                    genotype: np.ndarray,
                    snp_info: pd.DataFrame,
                    bin_size: int,
                    bin_selection: int) -> list:
    """Select top pseudo-QTNs via chromosome binning."""
    selected = []
    for chrom in results["Chromosome"].unique():
        chrom_df = results[results["Chromosome"] == chrom].sort_values("P.value")
        # Take top bin_selection per chromosome
        top = chrom_df.head(bin_selection)
        selected.extend(top.index.tolist())
    return selected[:bin_size]
