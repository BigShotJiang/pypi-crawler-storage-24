"""
PyGAPIT - BLINK (Bayesian information and Linkage disequilibrium Iteratively Nested Keyway)
============================================================================================
Multiple-locus model using Bayesian information criterion (BIC) for model selection
and LD-based filtering for computational efficiency.

Ref: Huang et al. (2018) Genome Biology.
"""

import numpy as np
import pandas as pd
from scipy import stats
from .glm import GLM
from typing import Optional


def BLINK(phenotype: np.ndarray,
          genotype: np.ndarray,
          snp_info: pd.DataFrame,
          covariates: Optional[np.ndarray] = None,
          trait_name: str = "Trait",
          max_snps: int = 20,
          ld_threshold: float = 0.7,
          p_threshold: float = 0.05) -> pd.DataFrame:
    """
    Run BLINK GWAS.

    Parameters
    ----------
    max_snps      : int   -- max number of loci to include
    ld_threshold  : float -- LD r^2 threshold for redundancy filtering
    p_threshold   : float -- threshold for adding loci

    Returns
    -------
    results : pd.DataFrame
    """
    print(f"[PyGAPIT] Running BLINK GWAS for trait: {trait_name}")
    selected_snps = []
    selected_idx  = []
    covar = covariates.copy() if covariates is not None else None
    bonferroni = p_threshold / genotype.shape[1]

    for step in range(max_snps):
        results = GLM(phenotype, genotype, snp_info,
                      covariates=covar, trait_name=trait_name)

        # Exclude already selected
        cand = results.drop(index=selected_idx, errors="ignore")
        best_idx = cand["P.value"].idxmin()
        best_p   = cand.loc[best_idx, "P.value"]

        if best_p > bonferroni:
            print(f"[PyGAPIT]  BLINK stopping: best p={best_p:.2e}")
            break

        # LD check: filter out SNPs in LD with already selected
        if selected_idx:
            new_snp = genotype[:, best_idx]
            ld_ok = True
            for prev_idx in selected_idx:
                prev_snp = genotype[:, prev_idx]
                r2 = _compute_r2(new_snp, prev_snp)
                if r2 > ld_threshold:
                    ld_ok = False
                    break
            if not ld_ok:
                print(f"[PyGAPIT]  SNP {snp_info.iloc[best_idx]['SNP']} in LD with selected; skip.")
                selected_idx.append(best_idx)  # mark as seen but skip as covariate
                continue

        selected_snps.append(snp_info.iloc[best_idx]["SNP"])
        selected_idx.append(best_idx)

        # BIC check
        bic_new = _compute_bic(phenotype, genotype, covar, selected_idx)
        if step > 0:
            bic_old = _compute_bic(phenotype, genotype, covar, selected_idx[:-1])
            if bic_new >= bic_old:
                print(f"[PyGAPIT]  BIC did not improve ({bic_old:.2f} -> {bic_new:.2f}), stopping.")
                selected_idx.pop()
                break

        new_snp_col = genotype[:, best_idx].reshape(-1, 1).astype(float)
        covar = np.hstack([covar, new_snp_col]) if covar is not None else new_snp_col
        print(f"[PyGAPIT]  Step {step+1}: added {snp_info.iloc[best_idx]['SNP']} (p={best_p:.2e})")

    results["Selected"] = results.index.isin(selected_idx)
    print(f"[PyGAPIT]  -> BLINK done. Selected loci: {len(selected_snps)}")
    return results


def _compute_r2(x: np.ndarray, y: np.ndarray) -> float:
    mask = ~(np.isnan(x) | np.isnan(y))
    if mask.sum() < 3:
        return 0.0
    r, _ = stats.pearsonr(x[mask], y[mask])
    return r**2


def _compute_bic(y, G, covar, snp_indices):
    """Compute BIC for a GLM with selected SNPs as fixed effects."""
    X = np.ones((len(y), 1))
    if covar is not None:
        X = np.hstack([X, covar])
    for idx in snp_indices:
        X = np.hstack([X, G[:, idx].reshape(-1, 1)])
    mask = ~np.isnan(y)
    Xm, ym = X[mask].astype(float), y[mask].astype(float)
    beta, _, _, _ = np.linalg.lstsq(Xm, ym, rcond=None)
    resid = ym - Xm @ beta
    n, k = Xm.shape
    sigma2 = np.sum(resid**2) / n
    ll = -0.5 * n * (np.log(2 * np.pi * sigma2) + 1)
    bic = -2 * ll + k * np.log(n)
    return bic
