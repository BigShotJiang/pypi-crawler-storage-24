"""
PyGAPIT - General Linear Model (GLM)
=====================================
Equivalent to GAPIT's GLM: tests each SNP via OLS regression
with optional fixed covariates (Q matrix from PCA).

Model:  y = X*beta + Q*alpha + e,  e ~ N(0, sigma^2 * I)
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Optional


def GLM(phenotype: np.ndarray,
        genotype: np.ndarray,
        snp_info: pd.DataFrame,
        covariates: Optional[np.ndarray] = None,
        trait_name: str = "Trait") -> pd.DataFrame:
    """
    Run General Linear Model GWAS.

    Parameters
    ----------
    phenotype  : np.ndarray (n,)
    genotype   : np.ndarray (n, m)
    snp_info   : pd.DataFrame with SNP, Chromosome, Position columns
    covariates : np.ndarray (n, k) optional PCs / Q matrix
    trait_name : str

    Returns
    -------
    results : pd.DataFrame  columns = [SNP, Chromosome, Position, Effect, SE, P.value]
    """
    print(f"[PyGAPIT] Running GLM GWAS for trait: {trait_name}")
    y = phenotype.astype(float)
    n, m = genotype.shape

    # Build fixed-effect design matrix (intercept + covariates)
    X_fixed = np.ones((n, 1))
    if covariates is not None:
        X_fixed = np.hstack([X_fixed, covariates])

    results = []
    for j in range(m):
        snp_col = genotype[:, j].astype(float)
        # skip monomorphic
        if np.nanstd(snp_col) < 1e-8:
            p_val, effect, se = 1.0, 0.0, np.nan
        else:
            X = np.hstack([X_fixed, snp_col.reshape(-1, 1)])
            mask = ~np.isnan(y) & ~np.isnan(snp_col)
            Xm, ym = X[mask], y[mask]
            try:
                beta, res, rank, sv = np.linalg.lstsq(Xm, ym, rcond=None)
                y_hat = Xm @ beta
                residuals = ym - y_hat
                df_res = Xm.shape[0] - Xm.shape[1]
                sigma2 = np.sum(residuals**2) / df_res if df_res > 0 else np.inf
                XtXinv = np.linalg.pinv(Xm.T @ Xm)
                se_all = np.sqrt(np.maximum(sigma2 * np.diag(XtXinv), 0))
                effect = beta[-1]
                se = se_all[-1]
                t_stat = effect / se if se > 1e-12 else 0.0
                p_val = 2 * stats.t.sf(abs(t_stat), df=df_res)
            except Exception:
                p_val, effect, se = 1.0, 0.0, np.nan

        row = {
            "SNP": snp_info.iloc[j]["SNP"],
            "Chromosome": snp_info.iloc[j].get("Chromosome", np.nan),
            "Position": snp_info.iloc[j].get("Position", np.nan),
            "Effect": effect,
            "SE": se,
            "P.value": p_val,
        }
        results.append(row)

    df = pd.DataFrame(results)
    df["-log10(P)"] = -np.log10(df["P.value"].clip(lower=1e-300))
    print(f"[PyGAPIT]  -> GLM done. Significant (p<0.05): {(df['P.value']<0.05).sum()}")
    return df
