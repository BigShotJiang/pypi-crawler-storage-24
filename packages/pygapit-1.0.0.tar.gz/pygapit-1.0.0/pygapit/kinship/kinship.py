"""
PyGAPIT Kinship Module
======================
Verified against actual GAPIT3 source code (jiabowang/GAPIT3 on GitHub).

Functions matched to GAPIT source:
  - VanRaden_kinship  -> GAPIT.kinship.VanRaden.R
  - loiselle_kinship  -> GAPIT.kinship.loiselle (in gapit_functions.R)
  - EMMA_kinship      -> GAPIT.kinship.Zhang.R
"""

import numpy as np
from typing import Optional


def VanRaden_kinship(geno: np.ndarray,
                     freq: Optional[np.ndarray] = None) -> np.ndarray:
    """
    VanRaden (2008) GRM.  Matches GAPIT.kinship.VanRaden.R exactly.

    R source logic:
        fa = colSums(snps)/(2*nrow(snps))
        index.non = fa>=1 | fa<=0          # remove invariants
        p = colSums(snps)/(2*nInd)
        P = 2*(p-0.5)                      # = 2p - 1
        snps = snps - 1                    # 0/1/2 -> -1/0/1
        Z = t(snps) - P                    # Z[j,i] = snps[i,j]-1 - (2p[j]-1) = snps[i,j]-2p[j]
        K = crossprod(Z,Z) / (2*sum(p*(1-p)))

    Python equivalent: Z = G - 2*p  (same result, see derivation in comments)
    """
    print("[PyGAPIT] Computing VanRaden kinship matrix ...")
    G = np.nan_to_num(geno.astype(float))

    # Step 1: Remove invariant SNPs (fa>=1 or fa<=0)
    fa = G.mean(axis=0) / 2.0
    valid = (fa > 0) & (fa < 1)
    n_removed = (~valid).sum()
    if n_removed > 0:
        print(f"[PyGAPIT]  Removing {n_removed} invariant SNPs.")
    G = G[:, valid]

    # Step 2: Allele frequency p
    n = G.shape[0]
    p = G.sum(axis=0) / (2.0 * n)          # = colSums/(2*nInd)

    # Step 3: Center matrix
    # GAPIT: Z[j,i] = (snps[i,j]-1) - (2p[j]-1) = snps[i,j] - 2p[j]
    # Python: Z[i,j] = G[i,j] - 2*p[j]   (same, just transposed)
    Z = G - 2.0 * p                         # shape (n, m)

    # Step 4: GRM
    adj = 2.0 * np.sum(p * (1.0 - p))
    if adj < 1e-10:
        raise ValueError("All SNPs monomorphic after filtering.")
    K = (Z @ Z.T) / adj                     # = crossprod(Z,Z)/adj in GAPIT

    print(f"[PyGAPIT]  -> K shape: {K.shape}, mean diag: {np.mean(np.diag(K)):.4f}")
    return K


def loiselle_kinship(geno: np.ndarray) -> np.ndarray:
    """
    Loiselle et al. (1995) kinship. Matches GAPIT.kinship.loiselle.

    R source (from gapit_functions.R):
        for i,j pairs:
          num1 = (snps[,i]-mafs[,i])*(snps[,j]-mafs[,j])
          num2 = (snps_comp[,i]-mafs_comp[,i])*(snps_comp[,j]-mafs_comp[,j])
          First_Term = sum(num1) + sum(num2)
          bias = mafs*(1-mafs) / (2n - missing - 1)
          K[i,j] = (First_Term + sum(bias)) / sum(2*mafs*(1-mafs))
    """
    print("[PyGAPIT] Computing Loiselle kinship matrix ...")
    G = np.nan_to_num(geno.astype(float))
    n, m = G.shape

    mafs = G.mean(axis=0) / 2.0       # minor allele frequency per SNP
    mafs_comp = 1.0 - mafs

    denom = 2.0 * np.sum(mafs * (1.0 - mafs))
    if denom < 1e-10:
        print("[PyGAPIT]  Warning: very low polymorphism for Loiselle kinship.")
        denom = 1.0

    K = np.zeros((n, n))
    # Bias correction term (per SNP): mafs*(1-mafs) / (2n-1)
    bias_total = np.sum(mafs * (1.0 - mafs) / (2 * n - 1))

    # Vectorised computation
    G_c = G - 2 * mafs                # centred around 2*p  (n x m)
    K = (G_c @ G_c.T + bias_total) / denom

    print(f"[PyGAPIT]  -> K shape: {K.shape}")
    return K


def EMMA_kinship(geno: np.ndarray) -> np.ndarray:
    """
    Zhang kinship (IBS-based). Matches GAPIT.kinship.Zhang.R.

    R source:
        fa = colSums(snps)/(2*nrow(snps)); remove invariants
        snpMean = apply(snps,2,mean)
        snps = t(snps) - snpMean          # (m x n), mean-centred
        K = crossprod(snps, snps)         # (n x n)
        # Normalise by diagonal:  K[i,j] / sqrt(K[i,i]*K[j,j])
    """
    print("[PyGAPIT] Computing IBS (Zhang) kinship matrix ...")
    G = np.nan_to_num(geno.astype(float))

    # Remove invariants (same as VanRaden)
    fa = G.mean(axis=0) / 2.0
    valid = (fa > 0) & (fa < 1)
    G = G[:, valid]

    snp_mean = G.mean(axis=0)
    Z = (G - snp_mean).T               # (m, n)
    K = Z.T @ Z                        # (n, n)

    # Normalise: K[i,j] = K[i,j] / sqrt(K[i,i] * K[j,j])
    d = np.sqrt(np.diag(K))
    d[d == 0] = 1.0
    K = K / np.outer(d, d)

    print(f"[PyGAPIT]  -> K shape: {K.shape}")
    return K
