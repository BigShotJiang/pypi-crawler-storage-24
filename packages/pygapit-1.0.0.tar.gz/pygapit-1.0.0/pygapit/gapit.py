"""
PyGAPIT - Main GAPIT Class
===========================
High-level API that mirrors the single-function GAPIT() call in R.

Usage
-----
from pygapit import GAPIT

result = GAPIT(
    Y        = phenotype_df,    # pd.DataFrame: taxon x traits
    G        = hapmap_file,     # str path OR (snp_info, geno_matrix) tuple
    model    = ["GLM","MLM","FarmCPU","BLINK"],
    PCA_total = 3,
    kinship  = "VanRaden",      # or pre-computed np.ndarray
    output_dir = "./GAPIT_output"
)
"""

import os
import numpy as np
import pandas as pd
from typing import Union, Optional, List, Tuple

from .io.readers import read_hapmap, read_numeric_genotype, read_phenotype
from .kinship.kinship import VanRaden_kinship, loiselle_kinship, EMMA_kinship
from .pca.pca import compute_pca
from .gwas.glm import GLM
from .gwas.mlm import MLM
from .gwas.mlmm import MLMM
from .gwas.farmcpu import FarmCPU
from .gwas.blink import BLINK
from .models.genomic_prediction import RR_BLUP, GBLUP
from .visualization.plots import manhattan_plot, qq_plot, pca_plot, kinship_heatmap
from .utils.stats import bonferroni_threshold, fdr_threshold, genomic_inflation


SUPPORTED_MODELS  = ["GLM", "MLM", "MLMM", "FarmCPU", "BLINK"]
KINSHIP_METHODS   = {"VanRaden": VanRaden_kinship,
                     "Loiselle": loiselle_kinship,
                     "EMMA":     EMMA_kinship}


class GAPIT:
    """
    PyGAPIT - Genome Association and Prediction Integrated Tool (Python)

    Parameters
    ----------
    Y           : pd.DataFrame OR str path -- phenotype data (taxa x traits)
    G           : str path | tuple(snp_info, geno) -- genotype (HapMap or numeric)
    model       : str or list -- GWAS model(s) to run
    PCA_total   : int  -- number of PCs for population structure
    kinship     : str | np.ndarray -- kinship method or pre-computed K
    kinship_plot: bool -- plot kinship heatmap
    output_dir  : str  -- directory to save results
    SNP_impute  : str  -- 'Major'|'Middle'|'Minor'
    traits      : list -- subset of traits to analyse (None = all)
    run_prediction: bool -- run G-BLUP/RR-BLUP genomic prediction
    """

    def __init__(self,
                 Y: Union[pd.DataFrame, str],
                 G: Union[str, Tuple],
                 model: Union[str, List[str]] = "MLM",
                 PCA_total: int = 3,
                 kinship: Union[str, np.ndarray] = "VanRaden",
                 kinship_plot: bool = True,
                 output_dir: str = "./GAPIT_output",
                 SNP_impute: str = "Middle",
                 traits: Optional[List[str]] = None,
                 run_prediction: bool = False):

        print("=" * 60)
        print("  PyGAPIT v1.0.0 - Genome Association & Prediction Tool")
        print("  Python port of GAPIT (Lipka et al. 2012)")
        print("=" * 60)

        os.makedirs(output_dir, exist_ok=True)
        self.output_dir   = output_dir
        self.models       = [model] if isinstance(model, str) else model
        self.PCA_total    = PCA_total
        self.SNP_impute   = SNP_impute
        self.run_pred     = run_prediction
        self.results      = {}   # model -> {trait -> DataFrame}

        # ── 1. Load phenotype ────────────────────────────────────────────────
        if isinstance(Y, str):
            self.pheno = read_phenotype(Y)
        else:
            self.pheno = Y.copy()

        selected_traits = traits or list(self.pheno.columns)
        taxa_pheno = list(self.pheno.index)

        # ── 2. Load genotype ─────────────────────────────────────────────────
        if isinstance(G, str):
            if "hmp" in G.lower() or "hapmap" in G.lower():
                self.snp_info, self.geno = read_hapmap(G, SNP_impute)
            else:
                self.snp_info, self.geno = read_numeric_genotype(G)
        else:
            self.snp_info, self.geno = G

        # ── 3. Kinship ───────────────────────────────────────────────────────
        if isinstance(kinship, np.ndarray):
            self.K = kinship
        else:
            K_fn = KINSHIP_METHODS.get(kinship, VanRaden_kinship)
            self.K = K_fn(self.geno)

        if kinship_plot:
            k_path = os.path.join(output_dir, "Kinship_heatmap.png")
            kinship_heatmap(self.K, title="Genomic Relationship Matrix",
                            output_file=k_path)

        # ── 4. PCA ───────────────────────────────────────────────────────────
        self.pc_df, self.explained = compute_pca(
            self.geno, n_components=PCA_total)
        pca_path = os.path.join(output_dir, "PCA_plot.png")
        pca_plot(self.pc_df, title="Population Structure (PCA)",
                 output_file=pca_path)
        covariates = self.pc_df.values if PCA_total > 0 else None

        # ── 5. Run GWAS for each model x trait ───────────────────────────────
        for trait in selected_traits:
            y_raw = self.pheno[trait].values.astype(float)
            print(f"\n{'─'*50}")
            print(f"  Trait: {trait}")
            print(f"{'─'*50}")

            for mdl in self.models:
                mdl_upper = mdl.upper()
                print(f"\n[PyGAPIT] Model: {mdl_upper}")

                if mdl_upper == "GLM":
                    res = GLM(y_raw, self.geno, self.snp_info,
                              covariates=covariates, trait_name=trait)
                elif mdl_upper == "MLM":
                    res = MLM(y_raw, self.geno, self.snp_info, self.K,
                              covariates=covariates, trait_name=trait)
                elif mdl_upper == "MLMM":
                    res = MLMM(y_raw, self.geno, self.snp_info, self.K,
                               covariates=covariates, trait_name=trait)
                elif mdl_upper == "FARMCPU":
                    res = FarmCPU(y_raw, self.geno, self.snp_info, self.K,
                                  covariates=covariates, trait_name=trait)
                elif mdl_upper == "BLINK":
                    res = BLINK(y_raw, self.geno, self.snp_info,
                                covariates=covariates, trait_name=trait)
                else:
                    print(f"[PyGAPIT] Unknown model '{mdl}'; skipping.")
                    continue

                # Annotate with lambda_GC
                lam = genomic_inflation(res["P.value"].dropna().values)
                print(f"[PyGAPIT]  Genomic inflation lambda_GC = {lam:.4f}")
                res["lambda_GC"] = lam

                # Save CSV
                csv_path = os.path.join(output_dir,
                                        f"GAPIT.{mdl_upper}.{trait}.GWAS.Results.csv")
                res.to_csv(csv_path, index=False)

                # Plots
                mh_path = os.path.join(output_dir,
                                       f"GAPIT.{mdl_upper}.{trait}.Manhattan.png")
                manhattan_plot(res, title=f"{mdl_upper}: {trait}", output_file=mh_path)

                qq_path = os.path.join(output_dir,
                                       f"GAPIT.{mdl_upper}.{trait}.QQ.png")
                qq_plot(res, title=f"{mdl_upper}: {trait}", output_file=qq_path)

                self.results.setdefault(mdl_upper, {})[trait] = res

        # ── 6. Genomic Prediction (optional) ─────────────────────────────────
        if run_prediction:
            self.prediction_results = {}
            for trait in selected_traits:
                y_raw = self.pheno[trait].values.astype(float)
                print(f"\n[PyGAPIT] G-BLUP prediction for {trait}")
                gebv, acc = GBLUP(y_raw, self.K)
                self.prediction_results[trait] = {"GEBV": gebv, "CV_accuracy": acc}
                print(f"[PyGAPIT]  {trait} -> CV r = {acc:.4f}")

        print("\n" + "=" * 60)
        print("  PyGAPIT analysis complete!")
        print(f"  Results saved to: {output_dir}")
        print("=" * 60)

    def summary(self) -> pd.DataFrame:
        """Return a summary table of significant associations across all models/traits."""
        rows = []
        for mdl, traits in self.results.items():
            for trait, df in traits.items():
                sig = df[df["P.value"] < 0.05 / len(df)]
                for _, row in sig.iterrows():
                    rows.append({
                        "Model": mdl, "Trait": trait,
                        "SNP": row["SNP"],
                        "Chromosome": row.get("Chromosome", ""),
                        "Position": row.get("Position", ""),
                        "P.value": row["P.value"],
                        "Effect": row.get("Effect", np.nan),
                    })
        return pd.DataFrame(rows).sort_values("P.value")

    def get_results(self, model: str, trait: str) -> pd.DataFrame:
        """Retrieve GWAS results for a specific model and trait."""
        return self.results.get(model.upper(), {}).get(trait, pd.DataFrame())

    def __repr__(self):
        n_assoc = sum(len(t) for t in self.results.values())
        return (f"PyGAPIT(models={self.models}, "
                f"traits={list(self.pheno.columns)}, "
                f"n_SNPs={self.geno.shape[1]}, "
                f"n_taxa={self.geno.shape[0]}, "
                f"result_tables={n_assoc})")
