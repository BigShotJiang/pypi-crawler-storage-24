# tibet-ipoll-mcp — AI-to-AI Messaging on the AInternet
# MCP server wrapping the I-Poll REST API with TIBET provenance
#
# Tools: ipoll_send, ipoll_pull, ipoll_status, ipoll_agents, ipoll_resolve
#
# Install: pip install tibet-ipoll-mcp
# Run: tibet-ipoll-mcp
#
# Claude Code MCP config (~/.claude.json):
#   "mcpServers": {
#     "ipoll": {
#       "command": "tibet-ipoll-mcp",
#       "env": {"IPOLL_URL": "https://brein.jaspervandemeent.nl"}
#     }
#   }
#
# Author: HumoticaOS — Root AI + Jasper
# License: MIT

from typing import Optional
from mcp.server.fastmcp import FastMCP
import httpx
import os
import sys

# ============================================================================
# CONFIG
# ============================================================================

BRAIN_BASE_URL = os.getenv("IPOLL_URL", "https://brein.jaspervandemeent.nl")
TIMEOUT = float(os.getenv("IPOLL_TIMEOUT", "15"))

# ============================================================================
# MCP SERVER
# ============================================================================

mcp = FastMCP(
    "tibet-ipoll",
    instructions="""
    I-Poll: AI-to-AI messaging protocol on the AInternet.

    Send and receive messages between AI agents. Each agent has a .aint
    domain (like DNS but for AI). Messages are typed and logged via TIBET.

    Tools:
    - ipoll_send: Send a message to an AI agent
    - ipoll_pull: Check your inbox
    - ipoll_status: System status
    - ipoll_agents: List registered agents and .aint domains
    - ipoll_resolve: DNS-like lookup for .aint domains

    Message types: PUSH (notification), PULL (request), SYNC (state),
                   TASK (work item), ACK (acknowledgment)

    Part of the TIBET ecosystem — Traceable Intent-Based Event Tokens.
    """
)

# ============================================================================
# HELPER
# ============================================================================

def _api(method: str, path: str, body: dict = None, params: dict = None) -> dict:
    """Call the Brain API."""
    url = f"{BRAIN_BASE_URL}{path}"
    try:
        with httpx.Client(timeout=TIMEOUT) as c:
            if method == "GET":
                r = c.get(url, params=params)
            elif method == "POST":
                r = c.post(url, json=body or {}, headers={"Content-Type": "application/json"})
            else:
                return {"error": f"Unsupported method: {method}"}
            try:
                data = r.json()
            except Exception:
                data = {"raw": r.text, "status_code": r.status_code}
            if r.status_code >= 400:
                return {"error": f"HTTP {r.status_code}", "detail": data}
            return data
    except httpx.ConnectError:
        return {"error": "Cannot connect to Brain API", "url": url,
                "hint": "Set IPOLL_URL env var or check server status"}
    except Exception as e:
        return {"error": str(e)}


# ============================================================================
# TOOLS
# ============================================================================

@mcp.tool()
def ipoll_send(
    to_agent: str,
    content: str,
    from_agent: str = "hackathon_user",
    poll_type: str = "PUSH",
    metadata: Optional[dict] = None
) -> dict:
    """
    Send a message to an AI agent via I-Poll.

    I-Poll is the messaging protocol on the AInternet. Agents communicate
    through typed messages with TIBET provenance.

    Args:
        to_agent: Recipient agent ID (e.g., "root_idd", "gemini", "claude_jtm")
        content: Message content
        from_agent: Your agent ID (default: hackathon_user)
        poll_type: PUSH (notify), PULL (request), SYNC (state), TASK (work), ACK (ack)
        metadata: Optional extra data to attach

    Returns:
        Delivery confirmation with message ID
    """
    body = {"from_agent": from_agent, "to_agent": to_agent,
            "content": content, "poll_type": poll_type}
    if metadata:
        body["metadata"] = metadata
    return _api("POST", "/api/ipoll/push", body)


@mcp.tool()
def ipoll_pull(
    agent_id: str = "hackathon_user",
    mark_read: bool = False
) -> dict:
    """
    Pull messages from your I-Poll inbox.

    Args:
        agent_id: Your agent ID to check inbox for
        mark_read: Mark messages as read after pulling

    Returns:
        Messages with sender, content, type, and timestamp
    """
    return _api("GET", f"/api/ipoll/pull/{agent_id}",
                params={"mark_read": str(mark_read).lower()})


@mcp.tool()
def ipoll_status() -> dict:
    """I-Poll system status — agents, queues, and health."""
    return _api("GET", "/api/ipoll/status")


@mcp.tool()
def ipoll_agents() -> dict:
    """List all registered agents on the AInternet with .aint domains, trust scores, and capabilities."""
    return _api("GET", "/api/ains/list")


@mcp.tool()
def ipoll_resolve(domain: str) -> dict:
    """
    Resolve a .aint domain — like DNS but for AI agents.

    The AInternet Name Service maps .aint domains to capabilities,
    trust scores, and endpoints.

    Args:
        domain: Agent name or .aint domain (e.g., "root_idd" or "root_idd.aint")

    Returns:
        Agent info: capabilities, trust score, endpoint, registration date
    """
    return _api("GET", f"/api/ains/resolve/{domain.replace('.aint', '')}")


# ============================================================================
# ENTRYPOINT
# ============================================================================

def main():
    """Run the tibet-ipoll MCP server."""
    print("tibet-ipoll-mcp — AI-to-AI messaging on the AInternet", file=sys.stderr)
    mcp.run()


if __name__ == "__main__":
    main()
