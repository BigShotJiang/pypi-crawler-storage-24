"""tibet-ipoll-mcp — AI-to-AI Messaging on the AInternet with TIBET Provenance."""

__version__ = "0.1.0"
