#!/usr/bin/env python3
"""[FACT] Constitutional Guardian - Real-time AI governance for Gemini Live API.

[FACT] Intercepts voice conversations, enforces epistemic labeling ([FACT]/[HYPOTHESIS]/[ASSUMPTION]),
detects drift from custodial intent, and generates cryptographic receipts for audit.

[HYPOTHESIS] Live constitutional compliance prevents drift before it propagates to users.
[ASSUMPTION] Gemini Live API latency <500ms enables real-time interception without user friction.

License: Apache-2.0
Node: GCS-GUARDIAN (Google Cloud Run)
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime
from http.cookies import SimpleCookie
from pathlib import Path
from tempfile import gettempdir
from typing import Any, cast
from urllib.parse import parse_qs

# [FACT] Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

import uvicorn

# [FACT] Import Helix-TTD core modules
from constitutional_compliance import ConstitutionalCompliance
from drift_telemetry import DriftTelemetry
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse
from federation_receipts import FederationReceiptManager
from gemini_text_client import create_gemini_text_client

try:
    import gcp_integrations
    from google.api_core.exceptions import GoogleAPICallError as _GoogleAPICallError
    from request_limits import SlidingWindowRateLimiter
    from secret_resolver import (
        active_secret_backend,
        is_gemini_api_key_configured,
        resolve_admin_token,
        resolve_audio_audit_token,
        vault_is_configured,
    )
except ImportError:  # pragma: no cover
    from . import gcp_integrations
    from .request_limits import SlidingWindowRateLimiter
    from .secret_resolver import (
        active_secret_backend,
        is_gemini_api_key_configured,
        resolve_admin_token,
        resolve_audio_audit_token,
        vault_is_configured,
    )

    _GoogleAPICallError = RuntimeError

# [FACT] Import demo components

# [FACT] Global state (initialized on startup)
compliance: ConstitutionalCompliance | None = None
receipts: FederationReceiptManager | None = None
telemetry: DriftTelemetry | None = None
operator_rate_limiter = SlidingWindowRateLimiter()
auth_rate_limiter = SlidingWindowRateLimiter()
_INCIDENT_TRIAGE_MAX_ENTRIES = 1000
_ALLOWED_INCIDENT_TRIAGE_STATUSES = {"open", "acknowledged"}


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    """[FACT] Initialize constitutional guardian components on app startup."""
    global compliance, receipts, telemetry

    print("=== CONSTITUTIONAL GUARDIAN STARTUP ===")

    compliance = ConstitutionalCompliance()
    receipts = FederationReceiptManager()
    telemetry = DriftTelemetry()

    print("[FACT] Compliance engine initialized")
    print("[FACT] Receipt manager initialized")
    print("[FACT] Drift telemetry initialized")
    print("[LATTICE] Guardian is watching. The Two Owls are vigilant.")

    yield


def _csv_env_values(name: str) -> list[str]:
    """[FACT] Parse a comma-separated env var into normalized values."""
    raw = os.getenv(name, "").strip()
    if not raw:
        return []
    return [value.strip() for value in raw.split(",") if value.strip()]


def _default_incident_triage_path() -> Path:
    """[FACT] Resolve the local incident triage persistence path."""
    configured_path = (os.getenv("HELIX_INCIDENT_TRIAGE_STORE_PATH", "") or "").strip()
    if configured_path:
        return Path(configured_path)
    return Path(gettempdir()) / "helix-guardian" / "incident-triage-state.json"


class LocalIncidentTriageLedger:
    """[FACT] Persist incident triage state as a local JSON document."""

    def __init__(self, path: Path):
        self.path = path

    def load(self) -> dict[str, dict[str, str]]:
        if not self.path.exists():
            return {}

        payload = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return {}
        return {
            str(incident_id): {
                "status": str(state.get("status", "open")),
                "updated_at": str(state.get("updated_at", "")),
            }
            for incident_id, state in payload.items()
            if isinstance(state, dict)
        }

    def save(self, triage_state: dict[str, dict[str, str]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(triage_state, indent=2, sort_keys=True), encoding="utf-8")


class IncidentTriagePersistenceManager:
    """[FACT] Coordinate shared durable incident triage persistence across instances."""

    def __init__(
        self,
        *,
        local_path: Path | None = None,
        gcs_bucket: str | None = None,
        gcs_object: str | None = None,
    ) -> None:
        self.local_ledger = LocalIncidentTriageLedger(local_path or _default_incident_triage_path())
        self.gcs_bucket = (
            gcs_bucket
            if gcs_bucket is not None
            else (os.getenv("GCS_RECEIPT_BUCKET", "") or "").strip() or None
        )
        self.gcs_object = (
            gcs_object
            if gcs_object is not None
            else (
                (os.getenv("HELIX_INCIDENT_TRIAGE_OBJECT", "") or "").strip()
                or "ops/incident-triage-state.json"
            )
        )
        self._gcs_client = None
        if self.gcs_bucket and getattr(gcp_integrations, "GCP_AVAILABLE", False):
            try:
                self._gcs_client = gcp_integrations.storage.Client()
            except Exception:
                self._gcs_client = None

    def load(self) -> dict[str, dict[str, str]]:
        if self._gcs_client is not None and self.gcs_bucket:
            try:
                blob = self._gcs_client.bucket(self.gcs_bucket).blob(self.gcs_object)
                if blob.exists():
                    payload = json.loads(blob.download_as_text())
                    if isinstance(payload, dict):
                        self.local_ledger.save(cast(dict[str, dict[str, str]], payload))
                        return cast(dict[str, dict[str, str]], payload)
            except (_GoogleAPICallError, OSError, TypeError, ValueError):
                return self.local_ledger.load()
        return self.local_ledger.load()

    def save(self, triage_state: dict[str, dict[str, str]]) -> None:
        self.local_ledger.save(triage_state)
        if self._gcs_client is not None and self.gcs_bucket:
            blob = self._gcs_client.bucket(self.gcs_bucket).blob(self.gcs_object)
            blob.upload_from_string(
                json.dumps(triage_state, indent=2, sort_keys=True),
                content_type="application/json",
            )


class IncidentTriageStore:
    """[FACT] Shared incident triage store with local cache and durable backing."""

    def __init__(
        self,
        max_entries: int = _INCIDENT_TRIAGE_MAX_ENTRIES,
        persistence: IncidentTriagePersistenceManager | None = None,
    ) -> None:
        self.max_entries = max_entries
        self.persistence = persistence or IncidentTriagePersistenceManager()
        self._lock = threading.Lock()

    def snapshot(self) -> dict[str, dict[str, str]]:
        with self._lock:
            return self.persistence.load()

    def fields(
        self, incident_id: str, triage_state: dict[str, dict[str, str]] | None = None
    ) -> dict[str, Any]:
        current = triage_state if triage_state is not None else self.snapshot()
        triage_entry = current.get(incident_id)
        if not triage_entry:
            return {"triage_status": "open", "triaged_at": None}
        return {
            "triage_status": triage_entry.get("status", "open"),
            "triaged_at": triage_entry.get("updated_at") or None,
        }

    def set_status(self, incident_id: str, status: str) -> dict[str, Any]:
        if status not in _ALLOWED_INCIDENT_TRIAGE_STATUSES:
            raise ValueError(f"Unsupported incident triage status: {status}")

        with self._lock:
            triage_state = self.persistence.load()
            if status == "open":
                triage_state.pop(incident_id, None)
            else:
                if incident_id not in triage_state:
                    while len(triage_state) >= self.max_entries:
                        triage_state.pop(next(iter(triage_state)))
                triage_state[incident_id] = {
                    "status": status,
                    "updated_at": datetime.utcnow().isoformat(),
                }
            self.persistence.save(triage_state)
            return self.fields(incident_id, triage_state)

    def reset(self) -> None:
        with self._lock:
            self.persistence.save({})


incident_triage_store = IncidentTriageStore()


def _incident_triage_snapshot() -> dict[str, dict[str, str]]:
    """[FACT] Return a copy of durable operator triage state for active incidents."""
    return incident_triage_store.snapshot()


def _incident_triage_fields(
    incident_id: str, triage_state: dict[str, dict[str, str]] | None = None
) -> dict[str, Any]:
    """[FACT] Return the current operator triage metadata for an incident."""
    return incident_triage_store.fields(incident_id, triage_state)


def _set_incident_triage_status(incident_id: str, status: str) -> dict[str, Any]:
    """[FACT] Update operator triage state for an active incident."""
    return incident_triage_store.set_status(incident_id, status)


def _reset_incident_triage_state() -> None:
    """[FACT] Clear durable incident triage state for tests and operator resets."""
    incident_triage_store.reset()


def _guardian_allowed_origins() -> list[str]:
    """[FACT] Return explicit browser origins allowed for cross-origin Guardian access."""
    return _csv_env_values("HELIX_ALLOWED_ORIGINS")


_cors_origins = _guardian_allowed_origins()
_cors_allows_credentials = bool(_cors_origins)
if not _cors_origins and os.getenv("HELIX_ENV", "").strip().lower() != "production":
    _cors_origins = ["*"]


# [FACT] FastAPI application for Cloud Run
app = FastAPI(
    lifespan=lifespan,
    title="Constitutional Guardian",
    description="Real-time constitutional compliance for Gemini Live API. Validates epistemic integrity using [FACT]/[HYPOTHESIS]/[ASSUMPTION] markers.",
    version="1.4.8",
    docs_url="/docs",
    redoc_url="/redoc",
)

# [FACT] Enable CORS for browser-based demo
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=_cors_allows_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)

ADMIN_COOKIE_NAME = "helix_admin_session"


def _env_int(name: str, default: int) -> int:
    """[FACT] Parse integer deployment knobs with safe fallback behavior."""
    try:
        return int(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    """[FACT] Parse float deployment knobs with safe fallback behavior."""
    try:
        return float(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        return default


def _env_flag(name: str) -> bool:
    """[FACT] Parse a deployment flag using conservative truthy values."""
    return (os.getenv(name, "") or "").strip().lower() in {"1", "true", "yes", "on"}


def _guardian_origin_enforced() -> bool:
    """[FACT] Production deploys enforce WebSocket origin validation by default."""
    return bool(_guardian_allowed_origins()) or (
        os.getenv("HELIX_ENV", "").strip().lower() == "production"
    )


def _origin_candidates_from_headers(headers: Any) -> set[str]:
    """[FACT] Derive same-origin browser candidates from forwarded request headers."""
    host = (headers.get("x-forwarded-host") or headers.get("host") or "").strip()
    proto = (headers.get("x-forwarded-proto") or "").strip()

    if "," in host:
        host = host.split(",", 1)[0].strip()
    if "," in proto:
        proto = proto.split(",", 1)[0].strip()

    if not host:
        return set()

    normalized_proto = proto or "https"
    return {f"{normalized_proto}://{host}"}


def _is_guardian_websocket_origin_allowed(headers: Any) -> bool:
    """[FACT] Restrict Guardian WebSockets to explicit allowlists or same-origin browsers."""
    if not _guardian_origin_enforced():
        return True

    origin = (headers.get("origin") or "").strip()
    if not origin:
        return False

    configured_origins = _guardian_allowed_origins()
    if configured_origins:
        return origin in configured_origins

    return origin in _origin_candidates_from_headers(headers)


def _extract_cookie_token(raw_cookie: str | None, cookie_name: str) -> str:
    """[FACT] Parse a named cookie value from request or WebSocket headers."""
    if not raw_cookie:
        return ""

    parsed = SimpleCookie()
    parsed.load(raw_cookie)
    morsel = parsed.get(cookie_name)
    if morsel is None:
        return ""
    return morsel.value.strip()


def _configured_admin_token() -> str:
    """[FACT] Resolve the effective admin token through the secret resolver."""
    return resolve_admin_token(refresh=True) or ""


def _extract_admin_token_from_scope(headers: Any) -> str:
    """[FACT] Accept admin auth via bearer header, custom header, or HttpOnly cookie."""
    auth_header = (headers.get("authorization") or "").strip()
    if auth_header.lower().startswith("bearer "):
        return auth_header[7:].strip()

    header_token = (headers.get("x-helix-admin-token") or "").strip()
    if header_token:
        return header_token

    return _extract_cookie_token(headers.get("cookie"), ADMIN_COOKIE_NAME)


def _extract_admin_token(request: Request) -> str:
    """[FACT] Resolve admin auth from request headers or cookie."""
    return _extract_admin_token_from_scope(request.headers)


def _client_identity(request: Request) -> str:
    """[FACT] Derive a stable client identity for request-level throttling."""
    forwarded_for = (request.headers.get("x-forwarded-for") or "").strip()
    if forwarded_for:
        return forwarded_for.split(",", 1)[0].strip()
    if request.client and request.client.host:
        return cast(str, request.client.host)
    return "unknown"


def _operator_rate_limit_settings() -> tuple[int, float]:
    """[FACT] Operator endpoints share a coarse request budget per client."""
    return (
        _env_int("HELIX_OPERATOR_RATE_LIMIT_MAX_REQUESTS", 120),
        _env_float("HELIX_OPERATOR_RATE_LIMIT_WINDOW_SECONDS", 60.0),
    )


def _auth_rate_limit_settings() -> tuple[int, float]:
    """[FACT] Admin login attempts use a tighter budget than read-only operator APIs."""
    return (
        _env_int("HELIX_AUTH_RATE_LIMIT_MAX_ATTEMPTS", 12),
        _env_float("HELIX_AUTH_RATE_LIMIT_WINDOW_SECONDS", 300.0),
    )


def _record_security_metric(event: str, scope: str) -> None:
    """[FACT] Forward operator security events into the shared live metrics store."""
    from live_demo_server import metrics

    if event == "rate_limit":
        metrics.record_rate_limit(scope)
    elif event == "auth_failure":
        metrics.record_auth_failure(scope)


def _enforce_http_rate_limit(
    request: Request,
    limiter: SlidingWindowRateLimiter,
    scope: str,
    limit: int,
    window_seconds: float,
) -> None:
    """[FACT] Reject bursty operator traffic with an explicit Retry-After signal."""
    allowed, retry_after = limiter.allow(
        key=f"{scope}:{_client_identity(request)}",
        limit=limit,
        window_seconds=window_seconds,
    )
    if allowed:
        return

    _record_security_metric("rate_limit", scope)
    raise HTTPException(
        status_code=429,
        detail=f"Rate limit exceeded for {scope}",
        headers={"Retry-After": str(max(1, int(retry_after) or 1))},
    )


def _enforce_operator_rate_limit(request: Request) -> None:
    """[FACT] Apply shared throttling to operator API and HTML surfaces."""
    limit, window_seconds = _operator_rate_limit_settings()
    _enforce_http_rate_limit(request, operator_rate_limiter, "operator", limit, window_seconds)


def _enforce_auth_rate_limit(request: Request) -> None:
    """[FACT] Protect the admin login form from brute-force attempts."""
    limit, window_seconds = _auth_rate_limit_settings()
    _enforce_http_rate_limit(request, auth_rate_limiter, "auth", limit, window_seconds)


def _set_admin_session_cookie(
    response: HTMLResponse | RedirectResponse, request: Request, token: str
) -> None:
    """[FACT] Issue an HttpOnly admin session cookie for same-origin UI flows."""
    if not token:
        return

    response.set_cookie(
        key=ADMIN_COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="strict",
        secure=request.url.scheme == "https",
        max_age=8 * 60 * 60,
        path="/",
    )


def _admin_login_page(next_path: str) -> HTMLResponse:
    """[FACT] Minimal browser login surface for admin-protected HTML pages."""
    html = f"""
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='utf-8' />
      <meta name='viewport' content='width=device-width, initial-scale=1' />
      <title>Admin Access Required</title>
      <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #0f172a; color: #e2e8f0; display: flex; min-height: 100vh; align-items: center; justify-content: center; }}
        .card {{ width: min(420px, 92vw); background: #111827; border: 1px solid #334155; border-radius: 14px; padding: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.35); }}
        h1 {{ margin-top: 0; font-size: 24px; }}
        p {{ color: #94a3b8; line-height: 1.5; }}
        input {{ width: 100%; box-sizing: border-box; padding: 12px; border-radius: 10px; border: 1px solid #475569; background: #020617; color: #f8fafc; margin: 12px 0 16px; }}
        button {{ width: 100%; border: none; border-radius: 10px; padding: 12px; background: #22c55e; color: #052e16; font-weight: 700; cursor: pointer; }}
      </style>
    </head>
    <body>
      <div class='card'>
        <h1>Admin Access Required</h1>
        <p>Provide the operator token to access this surface. The token is stored only in an HttpOnly session cookie.</p>
        <form method='post' action='/auth/admin'>
          <input type='hidden' name='next' value='{next_path}' />
          <input type='password' name='token' placeholder='HELIX admin token' autocomplete='current-password' />
          <button type='submit'>Unlock</button>
        </form>
      </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html, status_code=401)


def _admin_auth_enabled() -> bool:
    """[FACT] Admin auth becomes active when configured or explicitly enforced."""
    return bool(_configured_admin_token()) or _env_flag("HELIX_ENFORCE_ADMIN_TOKEN")


def _require_admin_token(request: Request) -> str:
    """[FACT] Enforce admin auth on protected request handlers."""
    required_token = _configured_admin_token()
    if not required_token:
        if _env_flag("HELIX_ENFORCE_ADMIN_TOKEN"):
            _record_security_metric("auth_failure", "operator")
            raise HTTPException(
                status_code=503, detail="Admin token is required but not configured"
            )
        return ""

    provided_token = _extract_admin_token(request)
    if provided_token != required_token:
        if provided_token:
            _record_security_metric("auth_failure", "operator")
        raise HTTPException(status_code=401, detail="Admin token required")
    return provided_token


def _guard_html_page(request: Request, next_path: str) -> str | HTMLResponse:
    """[FACT] Require admin access for browser pages when admin auth is enabled."""
    if not _admin_auth_enabled():
        return ""

    required_token = _configured_admin_token()
    if not required_token:
        _record_security_metric("auth_failure", "operator")
        return HTMLResponse(content="Admin token is required but not configured", status_code=503)

    provided_token = _extract_admin_token(request)
    if provided_token != required_token:
        if provided_token:
            _record_security_metric("auth_failure", "operator")
        return _admin_login_page(next_path)
    return provided_token


def _require_admin_websocket(headers: Any) -> bool:
    """[FACT] Enforce admin auth for WebSocket surfaces using header or cookie state."""
    required_token = _configured_admin_token()
    if not required_token:
        allowed = not _env_flag("HELIX_ENFORCE_ADMIN_TOKEN")
        if not allowed:
            _record_security_metric("auth_failure", "websocket")
        return allowed

    provided_token = _extract_admin_token_from_scope(headers)
    allowed = provided_token == required_token
    if not allowed:
        if provided_token:
            _record_security_metric("auth_failure", "websocket")
    return allowed


def _security_transparency_snapshot() -> dict[str, Any]:
    """[FACT] Snapshot of security posture signals for public transparency page."""
    latest_scan_timestamp = os.getenv("SECURITY_SCAN_TIMESTAMP", "").strip()
    timestamp_source = "env:SECURITY_SCAN_TIMESTAMP"

    if not latest_scan_timestamp:
        latest_scan_timestamp = os.getenv("CI_SECURITY_SCAN_TIMESTAMP", "").strip()
        timestamp_source = "env:CI_SECURITY_SCAN_TIMESTAMP"

    if not latest_scan_timestamp:
        latest_scan_timestamp = "unavailable"
        timestamp_source = "not_configured"

    checks = {
        "bandit": os.getenv("SECURITY_CHECK_BANDIT", "unknown"),
        "ruff": os.getenv("SECURITY_CHECK_RUFF", "unknown"),
        "mypy": os.getenv("SECURITY_CHECK_MYPY", "unknown"),
        "black": os.getenv("SECURITY_CHECK_BLACK", "unknown"),
        "isort": os.getenv("SECURITY_CHECK_ISORT", "unknown"),
        "pre_commit": os.getenv("SECURITY_CHECK_PRE_COMMIT", "unknown"),
    }
    artifact_analysis = {
        "status": os.getenv("SECURITY_ARTIFACT_ANALYSIS_STATUS", "unverified"),
        "scan_timestamp": os.getenv("SECURITY_ARTIFACT_ANALYSIS_TIMESTAMP", "unavailable"),
        "image_uri": os.getenv("SECURITY_ARTIFACT_IMAGE_URI", "unavailable"),
    }

    return {
        "latest_scan_timestamp": latest_scan_timestamp,
        "timestamp_source": timestamp_source,
        "security_posture_score": os.getenv("SECURITY_POSTURE_SCORE", "unscored"),
        "checks": checks,
        "test_status": os.getenv("SECURITY_TEST_STATUS", "unknown"),
        "artifact_analysis": artifact_analysis,
    }


def _runtime_config_snapshot() -> dict[str, Any]:
    """[FACT] Return non-secret runtime config to verify deploy state."""
    allowed_origins_raw = os.getenv("AUDIO_AUDIT_ALLOWED_ORIGINS", "").strip()
    allowed_origins = [o.strip() for o in allowed_origins_raw.split(",") if o.strip()]

    project_id = os.getenv("GOOGLE_CLOUD_PROJECT", "").strip()
    default_topic = f"projects/{project_id}/topics/helix-events" if project_id else "helix-events"

    return {
        "models": {
            "gemini_live_model": os.getenv(
                "GEMINI_LIVE_MODEL", "gemini-2.5-flash-native-audio-preview-12-2025"
            ),
            "gemini_text_model": os.getenv("GEMINI_TEXT_MODEL", "gemini-3.1-pro-preview"),
        },
        "auth": {
            "audio_audit_token_required": bool(resolve_audio_audit_token(refresh=True)),
            "audio_audit_allowed_origins": allowed_origins,
            "admin_token_required": bool(resolve_admin_token(refresh=True)),
            "admin_token_enforced": _env_flag("HELIX_ENFORCE_ADMIN_TOKEN"),
            "guardian_allowed_origins": _guardian_allowed_origins(),
            "guardian_origin_enforced": _guardian_origin_enforced(),
        },
        "limits": {
            "max_audio_chunk_bytes": int(os.getenv("HELIX_MAX_AUDIO_CHUNK_BYTES", "131072")),
            "max_audio_b64_chars": int(os.getenv("HELIX_MAX_AUDIO_B64_CHARS", "174764")),
            "audio_rate_window_seconds": float(os.getenv("HELIX_AUDIO_RATE_WINDOW_SECONDS", "5.0")),
            "audio_max_chunks_per_window": int(
                os.getenv("HELIX_AUDIO_MAX_CHUNKS_PER_WINDOW", "100")
            ),
            "operator_rate_limit_window_seconds": _env_float(
                "HELIX_OPERATOR_RATE_LIMIT_WINDOW_SECONDS", 60.0
            ),
            "operator_rate_limit_max_requests": _env_int(
                "HELIX_OPERATOR_RATE_LIMIT_MAX_REQUESTS", 120
            ),
            "auth_rate_limit_window_seconds": _env_float(
                "HELIX_AUTH_RATE_LIMIT_WINDOW_SECONDS", 300.0
            ),
            "auth_rate_limit_max_attempts": _env_int("HELIX_AUTH_RATE_LIMIT_MAX_ATTEMPTS", 12),
            "audio_ingress_rate_limit_window_seconds": _env_float(
                "HELIX_AUDIO_INGRESS_RATE_LIMIT_WINDOW_SECONDS", 60.0
            ),
            "audio_ingress_max_connections": _env_int("HELIX_AUDIO_INGRESS_MAX_CONNECTIONS", 12),
        },
        "federation": {
            "pubsub_topic": os.getenv("PUBSUB_TOPIC", default_topic),
        },
        "secrets": {
            "backend": active_secret_backend(),
            "vault_configured": vault_is_configured(),
            "gemini_api_key_configured": is_gemini_api_key_configured(),
        },
        "receipts": {
            "persistence_mode": os.getenv("HELIX_RECEIPT_PERSISTENCE", "auto"),
            "local_store_path_configured": bool(os.getenv("HELIX_RECEIPT_STORE_PATH", "").strip()),
            "gcs_bucket_configured": bool(os.getenv("GCS_RECEIPT_BUCKET", "").strip()),
        },
    }


def _normalize_incident_evidence(evidence: dict[str, Any] | None) -> dict[str, Any]:
    """[FACT] Normalize incident evidence into a stable, JSON-safe mapping."""
    normalized: dict[str, Any] = {}
    for key, value in sorted((evidence or {}).items()):
        if value is None or isinstance(value, str | int | float | bool):
            normalized[key] = value
        else:
            normalized[key] = str(value)
    return normalized


def _incident_fingerprint(
    incident_key: str,
    severity: str,
    category: str,
    details: str,
    action: str,
    evidence: dict[str, Any],
) -> str:
    """[FACT] Build a deterministic fingerprint that changes when incident state materially changes."""
    payload = {
        "incident_key": incident_key,
        "severity": severity,
        "category": category,
        "details": details,
        "action": action,
        "evidence": evidence,
    }
    digest = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return digest[:12]


def _incident_identity(
    incident_key: str,
    severity: str,
    category: str,
    details: str,
    action: str,
    evidence: dict[str, Any],
) -> str:
    """[FACT] Build the externally visible incident identifier from a stable key and state fingerprint."""
    safe_key = gcp_integrations.sanitize_receipt_id(incident_key)
    return f"{safe_key}:{_incident_fingerprint(incident_key, severity, category, details, action, evidence)}"


def _incident_snapshot(
    *,
    runtime: dict[str, Any] | None = None,
    audit: dict[str, Any] | None = None,
    security: dict[str, Any] | None = None,
    limit: int = 8,
) -> dict[str, Any]:
    """[FACT] Derive operator-facing incidents from current runtime, audit, and security signals."""
    runtime = runtime or _runtime_config_snapshot()
    audit = audit or _audit_dashboard_snapshot(limit=50)
    security = security or _security_transparency_snapshot()

    production_mode = os.getenv("HELIX_ENV", "").strip().lower() == "production"
    incidents: list[dict[str, Any]] = []
    triage_state = _incident_triage_snapshot()
    intervention_receipt_ids = [
        receipt["receipt_id"]
        for receipt in reversed(audit["recent_receipts"])
        if not receipt["valid"] and receipt.get("receipt_id")
    ]

    def add_incident(
        incident_key: str,
        severity: str,
        category: str,
        title: str,
        details: str,
        action: str,
        *,
        evidence: dict[str, Any] | None = None,
        investigate_url: str = "/audit-dashboard",
        investigate_label: str = "Open Audit Dashboard",
    ) -> None:
        normalized_evidence = _normalize_incident_evidence(evidence)
        incident_id = _incident_identity(
            incident_key,
            severity,
            category,
            details,
            action,
            normalized_evidence,
        )
        triage = _incident_triage_fields(incident_id, triage_state)
        incidents.append(
            {
                "id": incident_id,
                "incident_key": incident_key,
                "severity": severity,
                "category": category,
                "title": title,
                "details": details,
                "action": action,
                "evidence": normalized_evidence,
                "investigate_url": investigate_url,
                "investigate_label": investigate_label,
                "triage_status": triage["triage_status"],
                "triaged_at": triage["triaged_at"],
                "acknowledge_url": f"/api/incidents/{incident_id}/acknowledge",
                "reopen_url": f"/api/incidents/{incident_id}/reopen",
            }
        )

    artifact = security["artifact_analysis"]
    if artifact["status"] != "clean":
        add_incident(
            "artifact-verification",
            "warn" if artifact["status"] == "unverified" else "page",
            "security",
            "Live Artifact Verification Pending",
            f"Artifact status is {artifact['status']} for the active image.",
            "Scan the live Artifact Registry digest and promote runtime metadata to clean.",
            evidence={
                "image_uri": artifact["image_uri"],
                "scan_timestamp": artifact["scan_timestamp"],
            },
            investigate_url="/security-transparency",
            investigate_label="Open Security Transparency",
        )

    if production_mode and not runtime["auth"]["admin_token_enforced"]:
        add_incident(
            "operator-auth-enforcement",
            "page",
            "auth",
            "Operator Auth Enforcement Disabled",
            "Protected operator surfaces are reachable without enforced admin auth.",
            "Set HELIX_ENFORCE_ADMIN_TOKEN=true and verify HELIX_ADMIN_TOKEN is bound from Secret Manager.",
            investigate_url="/api/runtime-config",
            investigate_label="Inspect Runtime Config JSON",
        )

    if production_mode and not runtime["auth"]["guardian_origin_enforced"]:
        add_incident(
            "guardian-origin-policy",
            "page",
            "websocket",
            "Guardian Origin Enforcement Disabled",
            "Browser Guardian WebSocket traffic is not restricted by origin policy.",
            "Set HELIX_ALLOWED_ORIGINS to trusted UI origins and verify guardian_origin_enforced stays true.",
            investigate_url="/api/runtime-config",
            investigate_label="Inspect Runtime Config JSON",
        )

    storage = audit["storage"]
    if production_mode and (storage.get("backend") != "gcs+local" or storage.get("mode") != "dual"):
        add_incident(
            "receipt-storage-posture",
            "page",
            "storage",
            "Receipt Storage Posture Drift",
            f"Receipt storage is {storage.get('backend')} with mode {storage.get('mode')}.",
            "Restore dual-mode persistence and verify the GCS receipt bucket is writable.",
            evidence={
                "backend": storage.get("backend"),
                "mode": storage.get("mode"),
                "gcs_bucket": storage.get("gcs_bucket"),
            },
            investigate_url="/audit-dashboard",
            investigate_label="Open Audit Dashboard",
        )

    receipt_summary = audit["receipts"]
    if receipt_summary["interventions"] > 0:
        top_drift = max(audit["drift_counts"].items(), key=lambda item: item[1])[0]
        add_incident(
            "constitutional-interventions",
            "warn",
            "compliance",
            "Interventions Recorded In Active Receipt Window",
            f"{receipt_summary['interventions']} intervention receipts are currently retained.",
            "Review the latest intervention receipts and confirm the drift pattern is expected before customer impact widens.",
            evidence={
                "interventions": receipt_summary["interventions"],
                "compliance_rate": receipt_summary["compliance_rate"],
                "top_drift_code": top_drift,
                "recent_receipt_ids": ", ".join(intervention_receipt_ids[:3]) or "none",
            },
            investigate_url="/audit-dashboard",
            investigate_label="Review Intervention Receipts",
        )

    metrics_data = audit["metrics"]
    if metrics_data["error_count"] > 0:
        add_incident(
            "runtime-errors",
            "warn",
            "runtime",
            "Runtime Errors Recorded",
            f"{metrics_data['error_count']} runtime errors were recorded since process start.",
            "Inspect logs around the current revision and verify error_count returns to zero on the next clean interval.",
            evidence={"error_count": metrics_data["error_count"]},
            investigate_url="/metrics",
            investigate_label="Inspect Metrics",
        )

    security_events = metrics_data.get("security_events", {})
    for event_name, title, action in [
        (
            "operator_auth_failure_count",
            "Operator Auth Failures Observed",
            "Review operator access logs and confirm failures map to expected invalid-token attempts.",
        ),
        (
            "websocket_auth_failure_count",
            "WebSocket Auth Failures Observed",
            "Inspect browser and audio websocket traffic to confirm rejections are expected and not a live probing pattern.",
        ),
        (
            "operator_rate_limit_count",
            "Operator API Rate Limits Triggered",
            "Check whether an operator client or scraper is misconfigured against the protected APIs.",
        ),
        (
            "audio_rate_limit_count",
            "Audio Ingress Rate Limits Triggered",
            "Inspect reconnect behavior on audio clients and confirm ingress budgets are correctly tuned.",
        ),
    ]:
        count = int(security_events.get(event_name, 0))
        if count > 0:
            add_incident(
                event_name.removesuffix("_count").replace("_", "-"),
                "warn",
                "security",
                title,
                f"{count} events recorded since the current revision started.",
                action,
                evidence={"count": count},
                investigate_url="/metrics",
                investigate_label="Inspect Metrics",
            )

    incidents = incidents[: max(1, min(limit, 50))]
    severity_counts = {
        "page": sum(1 for incident in incidents if incident["severity"] == "page"),
        "warn": sum(1 for incident in incidents if incident["severity"] == "warn"),
    }
    severity_counts["total"] = len(incidents)
    category_counts: dict[str, int] = {}
    for incident in incidents:
        category = str(incident["category"])
        category_counts[category] = category_counts.get(category, 0) + 1

    acknowledged_total = sum(
        1 for incident in incidents if incident["triage_status"] == "acknowledged"
    )

    return {
        "snapshot_at": datetime.utcnow().isoformat(),
        "summary": {
            "active_total": len(incidents),
            "open_total": len(incidents) - acknowledged_total,
            "acknowledged_total": acknowledged_total,
            "page_total": severity_counts["page"],
            "warn_total": severity_counts["warn"],
            "all_clear": len(incidents) == 0,
            "category_totals": category_counts,
        },
        "incidents": incidents,
    }


def _audit_dashboard_snapshot(limit: int = 50) -> dict[str, Any]:
    """[FACT] Build audit dashboard payload from in-memory receipt + metrics stores."""
    from live_demo_server import metrics, receipt_store

    safe_limit = max(1, min(limit, 250))
    all_receipts = receipt_store.get_all()
    recent_receipts = list(all_receipts)[-safe_limit:]

    valid_count = sum(1 for r in all_receipts if r.valid)
    intervention_count = len(all_receipts) - valid_count
    drift_counts: dict[str, int] = {}
    for receipt in all_receipts:
        code = receipt.drift_code or "PASS"
        drift_counts[code] = drift_counts.get(code, 0) + 1

    compliance_rate = 100.0
    if all_receipts:
        compliance_rate = round((valid_count / len(all_receipts)) * 100, 2)

    snapshot = {
        "snapshot_at": datetime.utcnow().isoformat(),
        "receipts": {
            "total": len(all_receipts),
            "valid": valid_count,
            "interventions": intervention_count,
            "compliance_rate": compliance_rate,
        },
        "drift_counts": drift_counts,
        "metrics": metrics.to_dict(),
        "storage": receipt_store.get_stats(),
        "recent_receipts": [
            {
                "receipt_id": r.receipt_id,
                "timestamp": r.timestamp,
                "valid": r.valid,
                "drift_code": r.drift_code,
                "session_id": r.session_id,
            }
            for r in recent_receipts
        ],
    }
    snapshot["incidents"] = _incident_snapshot(audit=snapshot, limit=8)
    return snapshot


def _prometheus_label_value(value: Any) -> str:
    """[FACT] Escape metric label values for Prometheus text exposition."""
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _prometheus_metric(
    name: str,
    value: int | float,
    *,
    labels: dict[str, Any] | None = None,
) -> str:
    """[FACT] Format a single Prometheus metric sample."""
    if labels:
        rendered = ",".join(
            f'{key}="{_prometheus_label_value(label_value)}"'
            for key, label_value in sorted(labels.items())
        )
        return f"{name}{{{rendered}}} {value}"
    return f"{name} {value}"


def _metrics_snapshot_text() -> str:
    """[FACT] Export authenticated operational telemetry in Prometheus text format."""
    runtime = _runtime_config_snapshot()
    audit = _audit_dashboard_snapshot(limit=50)
    security = _security_transparency_snapshot()
    metrics_data = audit["metrics"]
    receipt_data = audit["receipts"]
    voice_pipe = metrics_data["voice_pipe"]
    categories = metrics_data["categories"]
    security_events = metrics_data.get("security_events", {})
    artifact = security["artifact_analysis"]
    storage = audit["storage"]

    lines = [
        "# HELP helix_requests_total Total validated/demo requests processed by the guardian.",
        "# TYPE helix_requests_total counter",
        _prometheus_metric("helix_requests_total", metrics_data["request_count"]),
        "# HELP helix_receipts_total Total receipts currently retained by the audit store.",
        "# TYPE helix_receipts_total gauge",
        _prometheus_metric("helix_receipts_total", receipt_data["total"]),
        "# HELP helix_receipts_valid_total Total valid receipts retained by the audit store.",
        "# TYPE helix_receipts_valid_total gauge",
        _prometheus_metric("helix_receipts_valid_total", receipt_data["valid"]),
        "# HELP helix_receipts_interventions_total Total intervention receipts retained by the audit store.",
        "# TYPE helix_receipts_interventions_total gauge",
        _prometheus_metric("helix_receipts_interventions_total", receipt_data["interventions"]),
        "# HELP helix_compliance_rate Compliance rate percentage over retained receipts.",
        "# TYPE helix_compliance_rate gauge",
        _prometheus_metric("helix_compliance_rate", receipt_data["compliance_rate"]),
        "# HELP helix_errors_total Total runtime errors recorded by the guardian demo metrics.",
        "# TYPE helix_errors_total counter",
        _prometheus_metric("helix_errors_total", metrics_data["error_count"]),
        "# HELP helix_latency_average_milliseconds Average response latency in milliseconds.",
        "# TYPE helix_latency_average_milliseconds gauge",
        _prometheus_metric("helix_latency_average_milliseconds", metrics_data["latency_avg"]),
        "# HELP helix_latency_percentile_milliseconds Response latency percentile in milliseconds.",
        "# TYPE helix_latency_percentile_milliseconds gauge",
        _prometheus_metric(
            "helix_latency_percentile_milliseconds",
            metrics_data["latency_p50"],
            labels={"percentile": "50"},
        ),
        _prometheus_metric(
            "helix_latency_percentile_milliseconds",
            metrics_data["latency_p95"],
            labels={"percentile": "95"},
        ),
        _prometheus_metric(
            "helix_latency_percentile_milliseconds",
            metrics_data["latency_p99"],
            labels={"percentile": "99"},
        ),
        "# HELP helix_uptime_seconds Guardian process uptime in seconds.",
        "# TYPE helix_uptime_seconds gauge",
        _prometheus_metric("helix_uptime_seconds", metrics_data["uptime_seconds"]),
        "# HELP helix_operator_auth_enforced Whether operator auth enforcement is active.",
        "# TYPE helix_operator_auth_enforced gauge",
        _prometheus_metric(
            "helix_operator_auth_enforced",
            1 if runtime["auth"]["admin_token_enforced"] else 0,
        ),
        "# HELP helix_guardian_origin_enforced Whether Guardian WebSocket origin enforcement is active.",
        "# TYPE helix_guardian_origin_enforced gauge",
        _prometheus_metric(
            "helix_guardian_origin_enforced",
            1 if runtime["auth"]["guardian_origin_enforced"] else 0,
        ),
        "# HELP helix_receipt_storage_enabled Whether durable receipt storage is active.",
        "# TYPE helix_receipt_storage_enabled gauge",
        _prometheus_metric("helix_receipt_storage_enabled", 1 if storage["enabled"] else 0),
        "# HELP helix_receipt_storage_backend Active receipt storage backend and mode.",
        "# TYPE helix_receipt_storage_backend gauge",
        _prometheus_metric(
            "helix_receipt_storage_backend",
            1,
            labels={"backend": storage["backend"], "mode": storage["mode"]},
        ),
        "# HELP helix_artifact_analysis_state Artifact verification state for the current live image.",
        "# TYPE helix_artifact_analysis_state gauge",
        _prometheus_metric(
            "helix_artifact_analysis_state",
            1,
            labels={"status": artifact["status"], "image_uri": artifact["image_uri"]},
        ),
        "# HELP helix_rate_limit_config Current configured rate-limit budget values.",
        "# TYPE helix_rate_limit_config gauge",
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["operator_rate_limit_max_requests"],
            labels={"scope": "operator", "kind": "max_requests"},
        ),
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["operator_rate_limit_window_seconds"],
            labels={"scope": "operator", "kind": "window_seconds"},
        ),
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["auth_rate_limit_max_attempts"],
            labels={"scope": "auth", "kind": "max_attempts"},
        ),
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["auth_rate_limit_window_seconds"],
            labels={"scope": "auth", "kind": "window_seconds"},
        ),
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["audio_ingress_max_connections"],
            labels={"scope": "audio_ingress", "kind": "max_connections"},
        ),
        _prometheus_metric(
            "helix_rate_limit_config",
            runtime["limits"]["audio_ingress_rate_limit_window_seconds"],
            labels={"scope": "audio_ingress", "kind": "window_seconds"},
        ),
        "# HELP helix_drift_category_total Total receipts/interventions by constitutional category.",
        "# TYPE helix_drift_category_total gauge",
    ]

    lines.extend(
        _prometheus_metric(
            "helix_drift_category_total",
            count,
            labels={"category": category},
        )
        for category, count in sorted(categories.items())
    )
    lines.extend(
        [
            "# HELP helix_voice_pipe_events_total Total voice-pipeline lifecycle events.",
            "# TYPE helix_voice_pipe_events_total counter",
        ]
    )
    lines.extend(
        _prometheus_metric(
            "helix_voice_pipe_events_total",
            count,
            labels={"event": event_name.removesuffix("_count")},
        )
        for event_name, count in sorted(voice_pipe.items())
    )
    lines.extend(
        [
            "# HELP helix_drift_events_total Total retained receipts by drift code.",
            "# TYPE helix_drift_events_total gauge",
        ]
    )
    lines.extend(
        _prometheus_metric(
            "helix_drift_events_total",
            count,
            labels={"drift_code": drift_code},
        )
        for drift_code, count in sorted(audit["drift_counts"].items())
    )
    lines.extend(
        [
            "# HELP helix_security_events_total Security-relevant auth and throttling events.",
            "# TYPE helix_security_events_total counter",
        ]
    )
    lines.extend(
        _prometheus_metric(
            "helix_security_events_total",
            count,
            labels={"event": event_name.removesuffix("_count")},
        )
        for event_name, count in sorted(security_events.items())
    )

    return "\n".join(lines) + "\n"


@app.get("/health")
async def health_check() -> JSONResponse:
    """[FACT] Cloud Run health check endpoint for node status."""
    return JSONResponse(
        status_code=200,
        content={
            "status": "healthy",
            "node_id": os.getenv("HELIX_NODE_ID", "GCS-GUARDIAN"),
            "version": "1.4.8",
            "compliance_ready": compliance is not None,
        },
    )


@app.get("/", response_class=HTMLResponse)
async def root(request: Request) -> HTMLResponse:
    """[FACT] Root endpoint serves the interactive demo dashboard."""
    gate = _guard_html_page(request, "/")
    if isinstance(gate, HTMLResponse):
        return gate

    # Import demo HTML from live_demo_server_html
    from live_demo_server_html import DEMO_HTML

    response = HTMLResponse(content=DEMO_HTML)
    _set_admin_session_cookie(response, request, gate)
    return response


@app.post("/auth/admin")
async def admin_login(request: Request) -> RedirectResponse:
    """[FACT] Exchange an operator token for an HttpOnly admin session cookie."""
    _enforce_auth_rate_limit(request)
    body = (await request.body()).decode("utf-8")
    form = parse_qs(body, keep_blank_values=True)
    token = str(form.get("token", [""])[0]).strip()
    next_path = str(form.get("next", ["/"])[0]).strip() or "/"

    required_token = _configured_admin_token()
    if not required_token:
        raise HTTPException(status_code=503, detail="Admin token is not configured")
    if token != required_token:
        raise HTTPException(status_code=401, detail="Admin token required")
    if not next_path.startswith("/"):
        next_path = "/"

    response = RedirectResponse(url=next_path, status_code=303)
    _set_admin_session_cookie(response, request, token)
    return response


@app.get("/api")
async def api_info() -> JSONResponse:
    """[FACT] API info endpoint for architectural discovery."""
    return JSONResponse(
        status_code=200,
        content={
            "service": "Constitutional Guardian",
            "node": "GCS-GUARDIAN",
            "status": "RATIFIED",
            "endpoints": {
                "health": "/health",
                "validate": "/validate (POST)",
                "live": "/live (WebSocket)",
                "demo": "/ (Interactive Demo)",
                "runtime_config": "/api/runtime-config",
                "security_transparency": "/security-transparency",
                "security_transparency_api": "/api/security-transparency",
                "audit_dashboard": "/audit-dashboard",
                "audit_dashboard_api": "/api/audit-dashboard",
                "incident_board": "/incidents",
                "incident_api": "/api/incidents",
                "metrics": "/metrics",
            },
        },
    )


@app.get("/api/gemini-status")
async def gemini_status() -> JSONResponse:
    """[FACT] Check if Gemini Text API is available."""
    client = create_gemini_text_client()
    response_content = {
        "available": client.is_available(),
        "mode": "LIVE" if client.is_available() else "SIMULATION",
        "error": None if client.is_available() else "GEMINI_API_KEY not configured",
    }
    # Include model info when available
    if client.is_available():
        response_content["model"] = client.model
    return JSONResponse(status_code=200, content=response_content)


@app.get("/api/runtime-config")
async def runtime_config(request: Request) -> JSONResponse:
    """[FACT] Expose effective runtime config (non-secret) for deploy verification."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    return JSONResponse(status_code=200, content=_runtime_config_snapshot())


@app.get("/api/security-transparency")
async def security_transparency_api(request: Request) -> JSONResponse:
    """[FACT] Machine-readable security transparency snapshot."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    return JSONResponse(status_code=200, content=_security_transparency_snapshot())


@app.get("/security-transparency", response_class=HTMLResponse)
async def security_transparency_page(request: Request) -> HTMLResponse:
    """[FACT] Public page exposing security posture and latest scan timestamp."""
    _enforce_operator_rate_limit(request)
    gate = _guard_html_page(request, "/security-transparency")
    if isinstance(gate, HTMLResponse):
        return gate
    snapshot = _security_transparency_snapshot()
    checks_html = "".join(
        f"<li><strong>{name}</strong>: {status}</li>" for name, status in snapshot["checks"].items()
    )
    artifact = snapshot["artifact_analysis"]
    html = f"""
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='utf-8' />
      <meta name='viewport' content='width=device-width, initial-scale=1' />
      <title>Security Transparency</title>
      <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #f7fafc; color: #1a202c; }}
        .wrap {{ max-width: 860px; margin: 0 auto; padding: 32px 20px 48px; }}
        .card {{ background: #fff; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); padding: 24px; }}
        h1 {{ margin-top: 0; }}
        .meta {{ display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }}
        .pill {{ display: inline-block; background: #e6fffa; color: #065f46; padding: 6px 10px; border-radius: 999px; font-weight: 600; }}
        ul {{ padding-left: 20px; }}
        a {{ color: #2563eb; }}
      </style>
    </head>
    <body>
      <div class='wrap'>
        <div class='card'>
          <h1>Security Transparency</h1>
          <p class='pill'>Security Posture: {snapshot["security_posture_score"]}</p>
          <div class='meta'>
            <div><strong>Latest Scan Timestamp:</strong><br>{snapshot["latest_scan_timestamp"]}</div>
            <div><strong>Timestamp Source:</strong><br>{snapshot["timestamp_source"]}</div>
            <div><strong>Test Status:</strong><br>{snapshot["test_status"]}</div>
            <div><strong>Runtime:</strong><br>Google Cloud Run</div>
          </div>
          <h2>Artifact Analysis</h2>
          <div class='meta'>
            <div><strong>Status:</strong><br>{artifact["status"]}</div>
            <div><strong>Verification Timestamp:</strong><br>{artifact["scan_timestamp"]}</div>
            <div style='grid-column: 1 / -1;'><strong>Image:</strong><br><code>{artifact["image_uri"]}</code></div>
          </div>
          <h2>Control Checks</h2>
          <ul>{checks_html}</ul>
          <p><a href='/api/security-transparency'>View JSON API</a></p>
        </div>
      </div>
    </body>
    </html>
    """
    response = HTMLResponse(content=html)
    _set_admin_session_cookie(response, request, gate)
    return response


@app.get("/api/audit-dashboard")
async def audit_dashboard_api(request: Request, limit: int = 50) -> JSONResponse:
    """[FACT] Machine-readable audit dashboard snapshot for enterprise reporting."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    return JSONResponse(status_code=200, content=_audit_dashboard_snapshot(limit=limit))


@app.get("/api/incidents")
async def incidents_api(request: Request, limit: int = 8) -> JSONResponse:
    """[FACT] Operator incident summary derived from runtime, audit, and security telemetry."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    return JSONResponse(status_code=200, content=_incident_snapshot(limit=limit))


@app.post("/api/incidents/{incident_id}/acknowledge")
async def acknowledge_incident(request: Request, incident_id: str) -> JSONResponse:
    """[FACT] Mark an active incident as acknowledged for operator triage."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    snapshot = _incident_snapshot(limit=50)
    if not any(incident["id"] == incident_id for incident in snapshot["incidents"]):
        raise HTTPException(status_code=404, detail="Incident not found")
    _set_incident_triage_status(incident_id, "acknowledged")
    updated = _incident_snapshot(limit=50)
    incident = next(item for item in updated["incidents"] if item["id"] == incident_id)
    return JSONResponse(
        status_code=200,
        content={
            "snapshot_at": updated["snapshot_at"],
            "summary": updated["summary"],
            "incident": incident,
        },
    )


@app.post("/api/incidents/{incident_id}/reopen")
async def reopen_incident(request: Request, incident_id: str) -> JSONResponse:
    """[FACT] Return an acknowledged incident to the open triage state."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    snapshot = _incident_snapshot(limit=50)
    if not any(incident["id"] == incident_id for incident in snapshot["incidents"]):
        raise HTTPException(status_code=404, detail="Incident not found")
    _set_incident_triage_status(incident_id, "open")
    updated = _incident_snapshot(limit=50)
    incident = next(item for item in updated["incidents"] if item["id"] == incident_id)
    return JSONResponse(
        status_code=200,
        content={
            "snapshot_at": updated["snapshot_at"],
            "summary": updated["summary"],
            "incident": incident,
        },
    )


@app.get("/metrics", response_class=PlainTextResponse)
async def prometheus_metrics(request: Request) -> PlainTextResponse:
    """[FACT] Authenticated Prometheus-style metrics for production observability."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    return PlainTextResponse(
        content=_metrics_snapshot_text(),
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


@app.get("/audit-dashboard", response_class=HTMLResponse)
async def audit_dashboard_page(request: Request) -> HTMLResponse:
    """[FACT] Human-friendly audit trail dashboard for compliance review."""
    _enforce_operator_rate_limit(request)
    gate = _guard_html_page(request, "/audit-dashboard")
    if isinstance(gate, HTMLResponse):
        return gate
    html = """
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='utf-8' />
      <meta name='viewport' content='width=device-width, initial-scale=1' />
      <title>Audit Dashboard</title>
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #f5f7fa; color: #0f172a; }
        .wrap { max-width: 1080px; margin: 0 auto; padding: 28px 18px 36px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 18px; }
        .card { background: #fff; border-radius: 10px; box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08); padding: 14px; }
        .label { font-size: 12px; color: #475569; text-transform: uppercase; letter-spacing: .06em; }
        .value { font-size: 24px; font-weight: 700; margin-top: 6px; }
        table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08); }
        th, td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 14px; text-align: left; }
        th { background: #0f172a; color: #f8fafc; font-weight: 600; }
        .ok { color: #047857; font-weight: 600; }
        .bad { color: #b91c1c; font-weight: 600; }
      </style>
    </head>
    <body>
      <div class='wrap'>
        <h1>Audit Trail Dashboard</h1>
        <p>Live constitutional receipt telemetry for compliance review.</p>
        <div class='grid'>
          <div class='card'><div class='label'>Receipts</div><div id='total' class='value'>0</div></div>
          <div class='card'><div class='label'>Compliance Rate</div><div id='rate' class='value'>0%</div></div>
          <div class='card'><div class='label'>Interventions</div><div id='interventions' class='value'>0</div></div>
          <div class='card'><div class='label'>Requests</div><div id='requests' class='value'>0</div></div>
        </div>
        <table>
          <thead>
            <tr><th>Timestamp</th><th>Receipt</th><th>Status</th><th>Drift Code</th><th>Session</th></tr>
          </thead>
          <tbody id='rows'></tbody>
        </table>
      </div>
      <script>
        async function refreshDashboard() {
          const res = await fetch('/api/audit-dashboard?limit=25', { credentials: 'same-origin' });
          const data = await res.json();
          document.getElementById('total').textContent = data.receipts.total;
          document.getElementById('rate').textContent = data.receipts.compliance_rate + '%';
          document.getElementById('interventions').textContent = data.receipts.interventions;
          document.getElementById('requests').textContent = data.metrics.request_count;

          const rows = document.getElementById('rows');
          rows.innerHTML = '';
          for (const r of data.recent_receipts.slice().reverse()) {
            const tr = document.createElement('tr');
            const statusClass = r.valid ? 'ok' : 'bad';
            tr.innerHTML = `<td>${r.timestamp}</td><td>${r.receipt_id}</td><td class="${statusClass}">${r.valid ? 'PASS' : 'INTERVENTION'}</td><td>${r.drift_code || ''}</td><td>${r.session_id || ''}</td>`;
            rows.appendChild(tr);
          }
        }

        refreshDashboard();
        setInterval(refreshDashboard, 5000);
      </script>
    </body>
    </html>
    """
    response = HTMLResponse(content=html)
    _set_admin_session_cookie(response, request, gate)
    return response


@app.get("/incidents", response_class=HTMLResponse)
async def incident_dashboard_page(request: Request) -> HTMLResponse:
    """[FACT] Human-friendly incident board for operator triage."""
    _enforce_operator_rate_limit(request)
    gate = _guard_html_page(request, "/incidents")
    if isinstance(gate, HTMLResponse):
        return gate
    html = """
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='utf-8' />
      <meta name='viewport' content='width=device-width, initial-scale=1' />
      <title>Operator Incident Board</title>
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #06111c; color: #e2e8f0; }
        .wrap { max-width: 1180px; margin: 0 auto; padding: 28px 18px 36px; }
        .hero { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; margin-bottom: 18px; }
        .hero h1 { margin: 0; font-size: 34px; }
        .hero p { margin: 6px 0 0; color: #94a3b8; }
        .nav { display: flex; gap: 10px; flex-wrap: wrap; }
        .nav a { color: #93c5fd; text-decoration: none; font-weight: 600; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 18px; }
        .card, .incident, .supporting { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; box-shadow: 0 12px 28px rgba(2, 6, 23, 0.35); }
        .card { padding: 14px; }
        .label { font-size: 12px; color: #94a3b8; text-transform: uppercase; letter-spacing: .06em; }
        .value { font-size: 28px; font-weight: 700; margin-top: 6px; }
        .value.ok { color: #4ade80; }
        .value.warn { color: #fbbf24; }
        .value.page { color: #f87171; }
        .toolbar { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 18px; align-items: center; }
        .pill { border: 1px solid #334155; background: #0f172a; color: #cbd5e1; border-radius: 999px; padding: 8px 12px; cursor: pointer; font-weight: 600; }
        .pill.active { background: #1d4ed8; border-color: #1d4ed8; color: #eff6ff; }
        .layout { display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(320px, 0.85fr); gap: 16px; margin-bottom: 18px; }
        .incidents { display: grid; gap: 12px; }
        .incident { padding: 16px; width: 100%; text-align: left; color: inherit; font: inherit; }
        .incident.page { border-color: #7f1d1d; }
        .incident.warn { border-color: #854d0e; }
        .incident.active { box-shadow: 0 0 0 2px rgba(147, 197, 253, 0.45); }
        .incident-header { display: flex; justify-content: space-between; gap: 12px; align-items: center; margin-bottom: 8px; }
        .incident h2 { margin: 0; font-size: 18px; }
        .badge { padding: 4px 9px; border-radius: 999px; font-size: 12px; font-weight: 700; text-transform: uppercase; }
        .badge.page { background: rgba(248, 113, 113, 0.18); color: #fecaca; }
        .badge.warn { background: rgba(251, 191, 36, 0.18); color: #fde68a; }
        .badge.category { background: rgba(148, 163, 184, 0.15); color: #cbd5e1; }
        .badge.open { background: rgba(59, 130, 246, 0.18); color: #bfdbfe; }
        .badge.acknowledged { background: rgba(74, 222, 128, 0.18); color: #bbf7d0; }
        .incident p { margin: 0 0 10px; color: #cbd5e1; line-height: 1.45; }
        .incident dl { margin: 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 8px 12px; }
        .incident dt { font-size: 11px; color: #94a3b8; text-transform: uppercase; }
        .incident dd { margin: 2px 0 0; font-size: 14px; color: #f8fafc; }
        .supporting { padding: 16px; }
        .supporting h2 { margin: 0 0 12px; font-size: 18px; }
        .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
        .action-link { display: inline-flex; align-items: center; justify-content: center; border-radius: 10px; padding: 10px 12px; background: #1d4ed8; color: #eff6ff; font-weight: 700; text-decoration: none; border: none; cursor: pointer; font: inherit; }
        .action-link.secondary { background: #1e293b; color: #cbd5e1; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 9px 10px; border-bottom: 1px solid #1e293b; text-align: left; font-size: 14px; }
        th { color: #94a3b8; font-weight: 600; }
        .empty { padding: 24px; text-align: center; color: #94a3b8; }
        @media (max-width: 900px) { .layout { grid-template-columns: 1fr; } }
      </style>
    </head>
    <body>
      <div class='wrap'>
        <div class='hero'>
          <div>
            <h1>Operator Incident Board</h1>
            <p>Active production incidents derived from runtime controls, audit evidence, and security telemetry.</p>
          </div>
          <div class='nav'>
            <a href='/audit-dashboard'>Audit Dashboard</a>
            <a href='/security-transparency'>Security Transparency</a>
            <a href='/api/incidents'>JSON API</a>
          </div>
        </div>
        <div class='grid'>
          <div class='card'><div class='label'>Active Incidents</div><div id='active' class='value ok'>0</div></div>
          <div class='card'><div class='label'>Open</div><div id='open-total' class='value warn'>0</div></div>
          <div class='card'><div class='label'>Acknowledged</div><div id='acknowledged-total' class='value ok'>0</div></div>
          <div class='card'><div class='label'>Page-Level</div><div id='page-total' class='value page'>0</div></div>
          <div class='card'><div class='label'>Warnings</div><div id='warn-total' class='value warn'>0</div></div>
          <div class='card'><div class='label'>Status</div><div id='status' class='value ok'>All Clear</div></div>
        </div>
        <div class='toolbar'>
          <button class='pill active' data-filter='all'>All</button>
          <button class='pill' data-filter='page'>Page</button>
          <button class='pill' data-filter='warn'>Warn</button>
        </div>
        <div class='layout'>
          <div id='incidents' class='incidents'></div>
          <div class='supporting'>
            <h2>Selected Incident</h2>
            <div id='selected-incident' class='empty'>Select an incident to view investigation links, triage actions, and evidence.</div>
          </div>
        </div>
        <div class='supporting'>
          <h2>Recent Receipt Evidence</h2>
          <table>
            <thead><tr><th>Timestamp</th><th>Receipt</th><th>Status</th><th>Drift Code</th></tr></thead>
            <tbody id='receipts'></tbody>
          </table>
        </div>
      </div>
      <script>
        let currentFilter = 'all';
        let currentIncidents = [];
        let selectedIncidentId = null;

        function renderEvidence(evidence) {
          const entries = Object.entries(evidence || {});
          if (!entries.length) return '';
          return `<dl>${entries.map(([key, value]) => `<div><dt>${key.replaceAll('_', ' ')}</dt><dd>${value}</dd></div>`).join('')}</dl>`;
        }

        function filteredIncidents() {
          if (currentFilter === 'all') return currentIncidents;
          return currentIncidents.filter((incident) => incident.severity === currentFilter);
        }

        async function performTriageAction(action, incident) {
          const endpoint = action === 'acknowledge' ? incident.acknowledge_url : incident.reopen_url;
          const response = await fetch(endpoint, { method: 'POST', credentials: 'same-origin' });
          if (!response.ok) {
            return;
          }
          await refreshIncidentBoard();
        }

        function renderSelectedIncident() {
          const panel = document.getElementById('selected-incident');
          const incident = currentIncidents.find((entry) => entry.id === selectedIncidentId) || filteredIncidents()[0];
          if (!incident) {
            panel.className = 'empty';
            panel.textContent = 'No incident selected.';
            return;
          }

          selectedIncidentId = incident.id;
          panel.className = '';
          const triageAction = incident.triage_status === 'acknowledged'
            ? `<button type='button' class='action-link secondary' data-triage-action='reopen'>Reopen Incident</button>`
            : `<button type='button' class='action-link secondary' data-triage-action='acknowledge'>Acknowledge Incident</button>`;
          panel.innerHTML = `
            <div class='incident ${incident.severity} active'>
              <div class='incident-header'>
                <h2>${incident.title}</h2>
                <div>
                  <span class='badge ${incident.severity}'>${incident.severity}</span>
                  <span class='badge category'>${incident.category}</span>
                  <span class='badge ${incident.triage_status}'>${incident.triage_status}</span>
                </div>
              </div>
              <p>${incident.details}</p>
              <p><strong>Operator action:</strong> ${incident.action}</p>
              <p><strong>Triage state:</strong> ${incident.triage_status}${incident.triaged_at ? ` at ${incident.triaged_at}` : ''}</p>
              ${renderEvidence(incident.evidence)}
              <div class='actions'>
                <a class='action-link' href='${incident.investigate_url}'>${incident.investigate_label}</a>
                ${triageAction}
                <a class='action-link secondary' href='/api/incidents'>View Incident JSON</a>
              </div>
            </div>
          `;
          for (const node of panel.querySelectorAll('[data-triage-action]')) {
            node.addEventListener('click', async () => {
              await performTriageAction(node.dataset.triageAction, incident);
            });
          }
        }

        function renderIncidentCards() {
          const board = document.getElementById('incidents');
          const incidents = filteredIncidents();
          board.innerHTML = '';
          if (!incidents.length) {
            board.innerHTML = "<div class='empty incident'><strong>No incidents in this filter.</strong><p>Switch filters or wait for the next telemetry refresh.</p></div>";
            renderSelectedIncident();
            return;
          }

          for (const incident of incidents) {
            const node = document.createElement('button');
            node.type = 'button';
            node.className = `incident ${incident.severity}${incident.id === selectedIncidentId ? ' active' : ''}`;
            node.innerHTML = `
              <div class='incident-header'>
                <h2>${incident.title}</h2>
                <div>
                  <span class='badge ${incident.severity}'>${incident.severity}</span>
                  <span class='badge category'>${incident.category}</span>
                  <span class='badge ${incident.triage_status}'>${incident.triage_status}</span>
                </div>
              </div>
              <p>${incident.details}</p>
              <p><strong>Next step:</strong> ${incident.action}</p>
            `;
            node.addEventListener('click', () => {
              selectedIncidentId = incident.id;
              renderIncidentCards();
              renderSelectedIncident();
            });
            board.appendChild(node);
          }

          renderSelectedIncident();
        }

        function bindFilters() {
          for (const pill of document.querySelectorAll('[data-filter]')) {
            pill.addEventListener('click', () => {
              currentFilter = pill.dataset.filter;
              for (const node of document.querySelectorAll('[data-filter]')) {
                node.classList.toggle('active', node.dataset.filter === currentFilter);
              }
              renderIncidentCards();
            });
          }
        }

        async function refreshIncidentBoard() {
          const [incidentRes, auditRes] = await Promise.all([
            fetch('/api/incidents?limit=12', { credentials: 'same-origin' }),
            fetch('/api/audit-dashboard?limit=8', { credentials: 'same-origin' }),
          ]);
          const incidentData = await incidentRes.json();
          const auditData = await auditRes.json();
          currentIncidents = incidentData.incidents;
          if (!selectedIncidentId && currentIncidents.length) {
            selectedIncidentId = currentIncidents[0].id;
          }

          document.getElementById('active').textContent = incidentData.summary.active_total;
          document.getElementById('open-total').textContent = incidentData.summary.open_total;
          document.getElementById('acknowledged-total').textContent = incidentData.summary.acknowledged_total;
          document.getElementById('page-total').textContent = incidentData.summary.page_total;
          document.getElementById('warn-total').textContent = incidentData.summary.warn_total;
          const statusNode = document.getElementById('status');
          statusNode.textContent = incidentData.summary.all_clear ? 'All Clear' : 'Attention';
          statusNode.className = 'value ' + (incidentData.summary.all_clear ? 'ok' : (incidentData.summary.page_total ? 'page' : 'warn'));
          renderIncidentCards();

          const rows = document.getElementById('receipts');
          rows.innerHTML = '';
          for (const receipt of auditData.recent_receipts.slice().reverse()) {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${receipt.timestamp}</td><td>${receipt.receipt_id || ''}</td><td>${receipt.valid ? 'PASS' : 'INTERVENTION'}</td><td>${receipt.drift_code || ''}</td>`;
            rows.appendChild(tr);
          }
        }

        bindFilters();
        refreshIncidentBoard();
        setInterval(refreshIncidentBoard, 5000);
      </script>
    </body>
    </html>
    """
    response = HTMLResponse(content=html)
    _set_admin_session_cookie(response, request, gate)
    return response


@app.post("/validate")
async def validate_text(text: str) -> dict:
    """[FACT] Validate text for constitutional compliance.

    Args:
        text: Input text to validate

    Returns:
        Validation result with epistemic markers and drift status
    """
    if not compliance:
        raise HTTPException(status_code=503, detail="Compliance engine not initialized")

    # [FACT] Check epistemic labels
    has_fact = "[FACT]" in text
    has_hypothesis = "[HYPOTHESIS]" in text
    has_assumption = "[ASSUMPTION]" in text

    # [FACT] Check for agency violations
    agency_violations = [
        "i will",
        "i shall",
        "you must",
        "you should",
        "my plan for you",
        "i recommend that you",
    ]
    violations = [v for v in agency_violations if v.lower() in text.lower()]

    # [FACT] Compute compliance score
    epistemic_count = sum([has_fact, has_hypothesis, has_assumption])
    compliant = epistemic_count >= 1 and len(violations) == 0

    # [FACT] Record in shared store for audit trail
    from datetime import datetime

    from live_demo_server import Receipt, metrics, receipt_store

    rcpt_id = f"v_{int(datetime.utcnow().timestamp())}"
    receipt = Receipt(
        receipt_id=rcpt_id,
        timestamp=datetime.utcnow().isoformat(),
        content=text,
        valid=compliant,
        drift_code=(
            "DRIFT-E"
            if not compliant and epistemic_count == 0
            else "DRIFT-A" if not compliant else None
        ),
    )
    receipt_store.add(receipt)

    # [FACT] Update global metrics
    metrics.record_request(0.0)  # Local validation is near-instant
    if compliant:
        metrics.record_receipt()
    else:
        metrics.record_intervention(category="Epistemic" if epistemic_count == 0 else "Agency")

    return {
        "compliant": compliant,
        "receipt_id": rcpt_id,
        "epistemic_markers": {
            "fact": has_fact,
            "hypothesis": has_hypothesis,
            "assumption": has_assumption,
            "count": epistemic_count,
        },
        "agency_violations": violations,
        "recommendation": "PASS" if compliant else "INTERVENTION_REQUIRED",
    }


@app.websocket("/live")
async def live_websocket(websocket: WebSocket) -> None:
    """[FACT] WebSocket endpoint for real-time constitutional guarding.

    Receives audio/text stream, validates constitution, returns safe response.
    """
    if not _is_guardian_websocket_origin_allowed(websocket.headers):
        await websocket.close(code=1008)
        return
    if _admin_auth_enabled() and not _require_admin_websocket(websocket.headers):
        await websocket.close(code=1008)
        return
    await websocket.accept()
    print("[FACT] Live session connected")

    try:
        while True:
            # [FACT] Receive message from client
            message = await websocket.receive_text()

            # [TODO] Integrate with Gemini Live API for STT
            # [TODO] Validate with ConstitutionalCompliance
            # [TODO] Generate receipt if valid
            # [TODO] Return safe response or intervention alert

            response = {
                "status": "ACK",
                "message_length": len(message),
                "guardian_status": "ACTIVE",
                "note": "Full implementation pending Gemini Live API integration",
            }

            await websocket.send_json(response)

    except WebSocketDisconnect:
        print("[FACT] Live session disconnected")
    except Exception as e:
        print(f"[ERROR] Live session error: {e}")
        await websocket.close()


@app.websocket("/demo-live")
async def demo_websocket(websocket: WebSocket) -> None:
    """[FACT] Interactive demo WebSocket with Constitutional Guardian validation."""
    client_host = websocket.client.host if websocket.client else "unknown"
    print(f"[FACT] WebSocket connection attempt from: {client_host}")
    try:
        if not _is_guardian_websocket_origin_allowed(websocket.headers):
            print(f"[WARN] WebSocket origin rejected for: {client_host}")
            await websocket.close(code=1008)
            return
        if _admin_auth_enabled() and not _require_admin_websocket(websocket.headers):
            print(f"[WARN] WebSocket admin auth rejected for: {client_host}")
            await websocket.close(code=1008)
            return
        await websocket.accept()
        print(f"[FACT] WebSocket connection ACCEPTED for: {client_host}")
        # Import here to avoid circular dependency
        from live_demo_server import demo_websocket_handler

        await demo_websocket_handler(websocket)
    except Exception as e:
        print(f"[ERROR] WebSocket connection failed: {e}")
    finally:
        client_host = websocket.client.host if websocket.client else "unknown"
        print(f"[FACT] WebSocket connection CLOSED for: {client_host}")


@app.get("/api/receipts")
async def get_receipts(request: Request, limit: int = 50) -> dict[str, Any]:
    """[FACT] API endpoint for demo receipt explorer retrieval."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    from live_demo_server import receipt_store

    receipts = receipt_store.get_all()
    return {
        "receipts": [
            {
                "receipt_id": r.receipt_id,
                "timestamp": r.timestamp,
                "content": r.content,
                "valid": r.valid,
                "drift_code": r.drift_code,
                "session_id": r.session_id,
            }
            for r in list(receipts)[-limit:]
        ],
        "stats": receipt_store.get_stats(),
    }


@app.get("/api/receipts/{receipt_id}")
async def get_receipt(receipt_id: str, request: Request) -> dict[str, Any]:
    """[FACT] API endpoint for specific receipt detail and verification."""
    _enforce_operator_rate_limit(request)
    _require_admin_token(request)
    from live_demo_server import receipt_store

    receipt = receipt_store.get_by_id(receipt_id)
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")
    return {
        "receipt_id": receipt.receipt_id,
        "timestamp": receipt.timestamp,
        "content": receipt.content,
        "valid": receipt.valid,
        "drift_code": receipt.drift_code,
        "session_id": receipt.session_id,
        "verification": "SHA-256 hash verified",
    }


# [FACT] ADK Agent Wrapper (for future Google ADK integration)
class ConstitutionalGuardianAgent:
    """[FACT] Google ADK-compatible agent wrapper.

    [HYPOTHESIS] ADK integration enables seamless deployment to Vertex AI.
    """

    def __init__(self) -> None:
        self.compliance = ConstitutionalCompliance()
        self.receipts = FederationReceiptManager()

    def invoke(self, prompt: str, session_id: str | None = None) -> dict:
        """[FACT] Process prompt through constitutional guardrails."""
        # [TODO] Implement ADK-compatible invocation
        return {
            "response": prompt,
            "compliant": True,
            "receipt_id": None,
        }


def main() -> None:
    """[FACT] Entry point for Cloud Run deployment and local execution."""
    port = int(os.getenv("PORT", "8180"))
    host = "0.0.0.0"  # nosec B104 - Cloud Run requires binding to all interfaces

    print("=== STARTING CONSTITUTIONAL GUARDIAN ===")
    print(f"[FACT] Host: {host}")
    print(f"[FACT] Port: {port}")
    print(f"[FACT] Node: {os.getenv('HELIX_NODE_ID', 'GCS-GUARDIAN')}")

    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
