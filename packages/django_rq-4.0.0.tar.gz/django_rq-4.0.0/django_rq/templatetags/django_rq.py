import datetime

from django import template
from django.urls import reverse
from django.utils import timezone
from django.utils.html import escape

register = template.Library()


@register.filter
def to_localtime(time):
    """Converts naive datetime to localtime based on settings"""

    utc_time = time.replace(tzinfo=datetime.timezone.utc)
    to_zone = timezone.get_default_timezone()
    return utc_time.astimezone(to_zone)


@register.filter
def show_func_name(job):
    """Shows job.func_name and handles errors during deserialization"""
    try:
        return job.func_name
    except Exception as e:
        return repr(e)


@register.filter
def force_escape(text):
    return escape(text)


@register.filter
def items(dictionary):
    """
    Explicitly calls `dictionary.items` function
    to avoid django from accessing the key `items` if any.
    """
    return dictionary.items()


@register.simple_tag(takes_context=True)
def rq_url(context, viewname, *args, **kwargs):
    """
    Reverse django-rq URLs for both admin integration and standalone URLs.

    The django-rq views live under different namespaces depending on how they
    are wired: admin integration uses the admin site's namespace (e.g.
    "admin:django_rq_*"), while standalone URLs use the "django_rq:" namespace.
    This tag detects the current admin namespace from request.current_app and
    builds the correct namespaced view name.
    """
    request = context.get("request")
    current_app = getattr(request, "current_app", None) if request else None
    if current_app:
        prefix = f"{current_app}:django_rq_"
    else:
        prefix = "django_rq:"
    return reverse(f"{prefix}{viewname}", args=args, kwargs=kwargs)
