"""
CarrierClient unit tests — uses respx to mock httpx transport.
"""

import pytest
import respx
import httpx

from gate_carrier_sdk import (
    CarrierClient,
    CarrierAuthError,
    CarrierConflictError,
    CarrierNotFoundError,
    CarrierQuotaExceededError,
    CarrierServerError,
    CarrierError,
    verify_webhook_signature,
    verify_policy_compliance,
)
from gate_carrier_sdk.types import (
    ActivePolicyResponse,
    PolicyRule,
    PolicyHistoryResponse,
    PolicyVersion,
    KmsInventoryResponse,
    IamVerification,
    BaselinePolicyResponse,
    BaselineSpec,
    BaselineRule,
    BaselineRuleResult,
    PolicyComplianceDiff,
    SimulationResponse,
    MatchedRule,
    WebhookRegistrationResponse,
    WebhookListResponse,
    WebhookListItem,
)

BASE_URL = "https://api.gate.blockintelai.net/api/v1/gate"
API_KEY = "carrier_test_key_abc123"


def make_client() -> CarrierClient:
    return CarrierClient(api_key=API_KEY, base_url=BASE_URL, carrier_id="carrier_test", max_retries=0)


# ─── create_underwriting_trial ────────────────────────────────────────────────

class TestCreateUnderwritingTrial:
    @respx.mock
    def test_success(self):
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            201,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "contactEmail": "security@acme.io",
                    "status": "OBSERVING",
                    "durationDays": 14,
                    "startedAt": "2026-03-10T00:00:00Z",
                    "expiresAt": "2026-03-24T00:00:00Z",
                    "adoptionStage": "SHADOW",
                    "message": "Trial tenant created in SHADOW mode.",
                },
            },
        ))

        client = make_client()
        result = client.create_underwriting_trial(
            prospect_name="Acme Exchange",
            contact_email="security@acme.io",
        )

        assert result.trial_id == "trial_abc"
        assert result.tenant_id == "tenant_xyz"
        assert result.status == "OBSERVING"
        assert result.adoption_stage == "SHADOW"

    @respx.mock
    def test_raises_auth_error_on_401(self):
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            401,
            json={"success": False, "error": {"code": "UNAUTHORIZED", "message": "Invalid key"}},
        ))
        with pytest.raises(CarrierAuthError):
            make_client().create_underwriting_trial("X", "x@x.com")

    @respx.mock
    def test_prospect_api_key_returned_on_creation(self):
        """H1: new trial response includes prospectApiKey."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            201,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "contactEmail": "security@acme.io",
                    "status": "OBSERVING",
                    "durationDays": 14,
                    "startedAt": "2026-03-10T00:00:00Z",
                    "expiresAt": "2026-03-24T00:00:00Z",
                    "adoptionStage": "SHADOW",
                    "prospectApiKey": "gate_abc123def456",
                    "message": "Trial tenant created in SHADOW mode.",
                },
            },
        ))
        result = make_client().create_underwriting_trial("Acme Exchange", "security@acme.io")
        assert result.prospect_api_key == "gate_abc123def456"

    @respx.mock
    def test_prospect_api_key_null_on_idempotent_recreate(self):
        """Server returns null prospectApiKey on idempotent re-create."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "contactEmail": "security@acme.io",
                    "status": "OBSERVING",
                    "durationDays": 14,
                    "startedAt": "2026-03-10T00:00:00Z",
                    "expiresAt": "2026-03-24T00:00:00Z",
                    "adoptionStage": "SHADOW",
                    "prospectApiKey": None,
                    "message": "Trial already exists for this prospect.",
                },
            },
        ))
        result = make_client().create_underwriting_trial("Acme Exchange", "security@acme.io")
        assert result.prospect_api_key is None

    @respx.mock
    def test_raises_not_found_when_carrier_not_found(self):
        """M2: CARRIER_NOT_FOUND 404 raises CarrierNotFoundError."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            404,
            json={
                "success": False,
                "error": {"code": "CARRIER_NOT_FOUND", "message": "Carrier account not found. Please contact support."},
            },
        ))
        with pytest.raises(CarrierNotFoundError):
            make_client().create_underwriting_trial("X", "x@x.com")

    @respx.mock
    def test_raises_carrier_error_on_400_float_duration_days(self):
        """M1: server rejects float durationDays with 400."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            400,
            json={
                "success": False,
                "error": {"code": "VALIDATION_ERROR", "message": "durationDays must be an integer between 1 and 90"},
            },
        ))
        with pytest.raises(CarrierError):
            make_client().create_underwriting_trial("X", "x@x.com", duration_days=14)

    @respx.mock
    def test_raises_quota_exceeded_on_burst_rate_limit(self):
        """L2: burst rate limiter returns 429 RATE_LIMIT_EXCEEDED."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            429,
            json={
                "success": False,
                "error": {"code": "RATE_LIMIT_EXCEEDED", "message": "Too many trial creation requests. Please wait a minute and retry."},
            },
        ))
        with pytest.raises(CarrierQuotaExceededError):
            make_client().create_underwriting_trial("X", "x@x.com")

    @respx.mock
    def test_prospect_api_key_recovered_on_idempotent_recreate(self):
        """M1 repair path: non-null prospectApiKey returned when GateAPIKeys was repaired."""
        respx.post(f"{BASE_URL}/carrier/trials/create").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "contactEmail": "security@acme.io",
                    "status": "OBSERVING",
                    "durationDays": 14,
                    "startedAt": "2026-03-10T00:00:00Z",
                    "expiresAt": "2026-03-24T00:00:00Z",
                    "adoptionStage": "SHADOW",
                    "prospectApiKey": "gate_recovered_key_abc123",
                    "message": "Trial already exists for this prospect.",
                },
            },
        ))
        result = make_client().create_underwriting_trial("Acme Exchange", "security@acme.io")
        assert result.prospect_api_key == "gate_recovered_key_abc123"


# ─── get_trial_status ─────────────────────────────────────────────────────────

class TestGetTrialStatus:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/trials/trial_abc/status").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "contactEmail": "security@acme.io",
                    "status": "OBSERVING",
                    "durationDays": 14,
                    "daysElapsed": 3,
                    "daysRemaining": 11,
                    "progressPercent": 21,
                    "startedAt": "2026-03-07T00:00:00Z",
                    "expiresAt": "2026-03-21T00:00:00Z",
                    "observation": {
                        "decisionsObserved": 150,
                        "wouldBlockCount": 5,
                        "wouldBlockRate": 3.33,
                    },
                },
            },
        ))

        result = make_client().get_trial_status("trial_abc")
        assert result.observation.decisions_observed == 150
        assert result.progress_percent == 21
        assert result.days_remaining == 11

    @respx.mock
    def test_raises_not_found_on_404(self):
        respx.get(f"{BASE_URL}/carrier/trials/nonexistent/status").mock(
            return_value=httpx.Response(
                404,
                json={"success": False, "error": {"code": "TRIAL_NOT_FOUND", "message": "Trial not found"}},
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().get_trial_status("nonexistent")

    @respx.mock
    def test_raises_not_found_for_cross_carrier_trial(self):
        """L1: server now returns 404 (not 403) to avoid timing oracle."""
        respx.get(f"{BASE_URL}/carrier/trials/trial_other_carrier/status").mock(
            return_value=httpx.Response(
                404,
                json={"success": False, "error": {"code": "TRIAL_NOT_FOUND", "message": "Trial not found"}},
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().get_trial_status("trial_other_carrier")


# ─── list_trials ──────────────────────────────────────────────────────────────

class TestListTrials:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trials": [
                        {
                            "trialId": "t1",
                            "tenantId": "ten1",
                            "prospectName": "Alpha",
                            "contactEmail": "alpha@example.com",
                            "status": "OBSERVING",
                            "durationDays": 14,
                            "startedAt": "2026-03-01T00:00:00Z",
                            "expiresAt": "2026-03-15T00:00:00Z",
                            "decisionsObserved": 10,
                            "wouldBlockCount": 1,
                        }
                    ],
                    "count": 1,
                    "hasMore": False,
                },
            },
        ))

        result = make_client().list_trials()
        assert result.count == 1
        assert result.has_more is False
        assert result.trials[0].trial_id == "t1"


# ─── convert_trial ────────────────────────────────────────────────────────────

class TestConvertTrial:
    @respx.mock
    def test_success(self):
        respx.post(f"{BASE_URL}/carrier/trials/trial_abc/convert").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "status": "CONVERTED",
                    "policyId": "policy_123",
                    "convertedAt": "2026-03-10T12:00:00Z",
                    "message": "Trial successfully converted.",
                },
            },
        ))

        result = make_client().convert_trial("trial_abc", "policy_123")
        assert result.status == "CONVERTED"
        assert result.policy_id == "policy_123"

    @respx.mock
    def test_raises_conflict_error_on_409_policy_mismatch(self):
        """M1: different policyId on already-converted trial returns 409 POLICY_MISMATCH."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_abc/convert").mock(
            return_value=httpx.Response(
                409,
                json={
                    "success": False,
                    "error": {
                        "code": "POLICY_MISMATCH",
                        "message": "Trial was already converted with policy 'policy_A'. Supply the same policyId to retrieve the result idempotently.",
                    },
                },
            )
        )
        with pytest.raises(CarrierConflictError) as exc_info:
            make_client().convert_trial("trial_abc", "policy_B")
        assert exc_info.value.code == "POLICY_MISMATCH"

    @respx.mock
    def test_raises_conflict_error_on_409_expired(self):
        """H2: server rejects conversion of expired trial with 409."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_expired/convert").mock(
            return_value=httpx.Response(
                409,
                json={
                    "success": False,
                    "error": {"code": "TRIAL_EXPIRED", "message": "This trial has expired and cannot be converted"},
                },
            )
        )
        with pytest.raises(CarrierConflictError) as exc_info:
            make_client().convert_trial("trial_expired", "policy_123")
        assert exc_info.value.code == "TRIAL_EXPIRED"

    @respx.mock
    def test_raises_not_found_for_cross_carrier_trial(self):
        """H1: convertTrial returns 404 (not 403) for cross-carrier isolation."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_other_carrier/convert").mock(
            return_value=httpx.Response(
                404,
                json={"success": False, "error": {"code": "TRIAL_NOT_FOUND", "message": "Trial not found"}},
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().convert_trial("trial_other_carrier", "policy_123")

    @respx.mock
    def test_idempotent_convert_returns_200(self):
        """Idempotent re-convert returns 200 (not 409)."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_abc/convert").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_abc",
                    "tenantId": "tenant_xyz",
                    "prospectName": "Acme Exchange",
                    "status": "CONVERTED",
                    "policyId": "policy_123",
                    "convertedAt": "2026-03-10T12:00:00Z",
                    "message": "Trial was already converted.",
                },
            },
        ))
        result = make_client().convert_trial("trial_abc", "policy_123")
        assert result.status == "CONVERTED"


# ─── get_underwriting_report ──────────────────────────────────────────────────

class TestGetUnderwritingReport:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/underwriting-report/tenant_xyz").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "tenantName": "Acme Exchange",
                        "reportGeneratedAt": "2026-03-10T00:00:00Z",
                        "adoptionStage": "SOFT_ENFORCE",
                        "isEnabled": True,
                        "iamEnforced": False,
                        "decisions30d": {
                            "total": 5000,
                            "allow": 4800,
                            "block": 150,
                            "wouldBlock": 50,
                            "stepUp": 0,
                            "withReceiptSignature": 4999,
                            "violationRate": 4.0,
                            "attestationCoverage": 99.98,
                        },
                        "signers": {"activeCount": 2},
                        "snapshot": {"version": "snap_001", "policyHash": "abc123"},
                    },
                },
            )
        )

        result = make_client().get_underwriting_report("tenant_xyz")
        assert result.decisions_30d.total == 5000
        assert result.decisions_30d.attestation_coverage == 99.98
        assert result.active_signers == 2


# ─── get_risk_score ───────────────────────────────────────────────────────────

class TestGetRiskScore:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/risk-score/tenant_xyz").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "tenantId": "tenant_xyz",
                    "tenantName": "Acme Exchange",
                    "adoptionStage": "HARD_KMS_GATEWAY",
                    "compositeScore": 78,
                    "riskLabel": "LOW",
                    "scoredAt": "2026-03-10T00:00:00Z",
                    "factors": {
                        "adoptionStage": {"weight": 0.30, "rawScore": 85, "contribution": 26, "description": "HARD_KMS_GATEWAY"},
                        "attestationCoverage": {"weight": 0.25, "rawScore": 92, "contribution": 23, "description": "92%"},
                        "wouldBlockRate": {"weight": 0.20, "rawScore": 80, "contribution": 16, "description": "5%"},
                        "blastRadius": {"weight": 0.15, "rawScore": 100, "contribution": 15, "description": "IAM enforced"},
                        "signerDiversity": {"weight": 0.10, "rawScore": 100, "contribution": 10, "description": "3 signers"},
                    },
                },
            },
        ))

        result = make_client().get_risk_score("tenant_xyz")
        assert result.composite_score == 78
        assert result.risk_label == "LOW"
        assert result.factors.blast_radius.contribution == 15


# ─── generate_claim_pack ──────────────────────────────────────────────────────

class TestGenerateClaimPack:
    @respx.mock
    def test_posts_to_carrier_scoped_url(self):
        """URL must embed carrierId and tenantId — not the tenant-JWT insurance route."""
        url = f"{BASE_URL}/carrier/carrier_test/tenants/tenant_xyz/claim-pack"
        respx.post(url).mock(return_value=httpx.Response(
            202,
            json={
                "success": True,
                "data": {
                    "jobId": "job_123",
                    "status": "PENDING",
                    "pollUrl": "/api/v1/gate/carrier/claim-pack/job_123",
                },
            },
        ))

        result = make_client().generate_claim_pack("tenant_xyz", period_start="2026-02-01", period_end="2026-03-01")
        assert result.job_id == "job_123"
        assert result.status == "PENDING"
        assert result.poll_url == "/api/v1/gate/carrier/claim-pack/job_123"

    @respx.mock
    def test_raises_auth_error_on_401(self):
        respx.post(f"{BASE_URL}/carrier/carrier_test/tenants/tenant_xyz/claim-pack").mock(
            return_value=httpx.Response(
                401,
                json={"success": False, "error": {"code": "UNAUTHORIZED", "message": "Invalid key"}},
            )
        )
        with pytest.raises(CarrierAuthError):
            make_client().generate_claim_pack("tenant_xyz", period_start="2026-02-01", period_end="2026-03-01")


# ─── get_claim_pack_status ────────────────────────────────────────────────────

class TestGetClaimPackStatus:
    @respx.mock
    def test_gets_from_carrier_claim_pack_url(self):
        respx.get(f"{BASE_URL}/carrier/claim-pack/job_123").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "jobId": "job_123",
                    "status": "COMPLETE",
                    "tenantId": "tenant_xyz",
                    "createdAt": "2026-03-10T00:00:00Z",
                    "completedAt": "2026-03-10T01:00:00Z",
                    "downloadUrl": "https://example.com/pack.zip",
                    "error": None,
                },
            },
        ))

        result = make_client().get_claim_pack_status("job_123")
        assert result.status == "COMPLETE"
        assert result.download_url == "https://example.com/pack.zip"
        assert result.tenant_id == "tenant_xyz"
        assert result.created_at == "2026-03-10T00:00:00Z"

    @respx.mock
    def test_running_status_has_no_download_url(self):
        respx.get(f"{BASE_URL}/carrier/claim-pack/job_456").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "jobId": "job_456",
                    "status": "RUNNING",
                    "tenantId": "tenant_xyz",
                    "createdAt": "2026-03-10T00:00:00Z",
                    "completedAt": None,
                    "downloadUrl": None,
                    "error": None,
                },
            },
        ))

        result = make_client().get_claim_pack_status("job_456")
        assert result.status == "RUNNING"
        assert result.download_url is None


# ─── get_alerts ───────────────────────────────────────────────────────────────

class TestGetAlerts:
    @respx.mock
    def test_alert_summary_includes_tenant_id_and_type(self):
        """AlertSummary must expose tenant_id and alert_type (camelCase after H5 backend normalization)."""
        respx.get(f"{BASE_URL}/carrier/alerts").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": [
                    {
                        "alertId": "alert_001",
                        "tenantId": "tenant_xyz",
                        "alertType": "VIOLATION_SPIKE",
                        "severity": "HIGH",
                        "message": "Unusual block rate detected",
                        "createdAt": "2026-03-10T00:00:00Z",
                    }
                ],
            },
        ))
        result = make_client().get_alerts()
        assert len(result.alerts) == 1
        assert result.alerts[0].tenant_id == "tenant_xyz"
        assert result.alerts[0].alert_type == "VIOLATION_SPIKE"
        assert result.alerts[0].severity == "HIGH"


# ─── acknowledge_alert ────────────────────────────────────────────────────────

class TestAcknowledgeAlert:
    @respx.mock
    def test_success_returns_only_acknowledged(self):
        """Response must only contain acknowledged boolean — no alertId or acknowledgedAt."""
        respx.post(f"{BASE_URL}/carrier/alerts/alert_abc/acknowledge").mock(
            return_value=httpx.Response(
                200,
                json={"success": True, "data": {"acknowledged": True}},
            )
        )

        result = make_client().acknowledge_alert("alert_abc")
        assert result.acknowledged is True
        assert not hasattr(result, "alert_id")
        assert not hasattr(result, "acknowledged_at")

    @respx.mock
    def test_raises_not_found_on_404(self):
        respx.post(f"{BASE_URL}/carrier/alerts/nonexistent/acknowledge").mock(
            return_value=httpx.Response(
                404,
                json={"success": False, "error": {"code": "ALERT_NOT_FOUND", "message": "Alert not found"}},
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().acknowledge_alert("nonexistent")


# ─── list_trials pagination ────────────────────────────────────────────────────

class TestListTrialsPagination:
    @respx.mock
    def test_passes_next_token_as_query_param(self):
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {"trials": [], "count": 0, "hasMore": True, "nextToken": "cursor_page2"},
            },
        ))

        result = make_client().list_trials(next_token="cursor_page1")

        assert result.next_token == "cursor_page2"
        assert "nextToken=cursor_page1" in str(route.calls[0].request.url)

    @respx.mock
    def test_omits_next_token_when_not_provided(self):
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))

        result = make_client().list_trials()

        assert result.next_token is None
        assert "nextToken" not in str(route.calls[0].request.url)

    @respx.mock
    def test_context_manager(self):
        """Verify context manager closes HTTP pool cleanly."""
        respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))
        with CarrierClient(api_key=API_KEY, base_url=BASE_URL, carrier_id="carrier_test", max_retries=0) as client:
            result = client.list_trials()
        assert result.count == 0

    @respx.mock
    def test_raises_carrier_error_on_400_for_cross_carrier_cursor(self):
        """L1 / cursor isolation: tampered nextToken returns 400."""
        respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            400,
            json={
                "success": False,
                "error": {"code": "VALIDATION_ERROR", "message": "Invalid nextToken"},
            },
        ))
        with pytest.raises(CarrierError):
            make_client().list_trials(next_token="tampered_cursor_from_other_carrier")

    @respx.mock
    def test_passes_status_expired_filter(self):
        """Verify status=EXPIRED is forwarded as a query param."""
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))

        result = make_client().list_trials(status="EXPIRED")

        assert result.count == 0
        assert "status=EXPIRED" in str(route.calls[0].request.url)

    @respx.mock
    def test_passes_limit_as_query_param(self):
        """M2: limit param is forwarded to the API."""
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))

        make_client().list_trials(limit=50)

        assert "limit=50" in str(route.calls[0].request.url)

    @respx.mock
    def test_passes_limit_1_boundary(self):
        """limit=1 boundary is forwarded and single item is returned."""
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trials": [{
                        "trialId": "t1", "tenantId": "ten1", "prospectName": "A",
                        "contactEmail": "a@example.com", "status": "OBSERVING",
                        "durationDays": 14, "startedAt": "2026-03-01T00:00:00Z",
                        "expiresAt": "2026-03-15T00:00:00Z",
                        "decisionsObserved": 0, "wouldBlockCount": 0,
                    }],
                    "count": 1,
                    "hasMore": False,
                },
            },
        ))

        result = make_client().list_trials(limit=1)

        assert "limit=1" in str(route.calls[0].request.url)
        assert len(result.trials) == 1

    @respx.mock
    def test_passes_status_next_token_and_limit_together(self):
        """All three optional params are forwarded simultaneously."""
        route = respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))

        make_client().list_trials(status="OBSERVING", next_token="cursor_p2", limit=25)

        url = str(route.calls[0].request.url)
        assert "status=OBSERVING" in url
        assert "nextToken=cursor_p2" in url
        assert "limit=25" in url


# ─── Error handling ───────────────────────────────────────────────────────────

class TestErrorHandling:
    @respx.mock
    def test_quota_exceeded_on_429(self):
        respx.post(f"{BASE_URL}/carrier/bbr/create-test").mock(return_value=httpx.Response(
            429,
            json={
                "success": False,
                "error": {"code": "QUOTA_EXCEEDED", "message": "Monthly quota exhausted", "resetAt": "2026-04-01"},
            },
        ))
        with pytest.raises(CarrierQuotaExceededError) as exc_info:
            make_client().create_bbr_test("tenant_xyz")
        assert exc_info.value.reset_at == "2026-04-01"

    @respx.mock
    def test_server_error_on_500(self):
        respx.get(f"{BASE_URL}/carrier/v2/portfolio").mock(return_value=httpx.Response(
            500,
            json={"success": False, "error": {"code": "SERVER_ERROR", "message": "Internal error"}},
        ))
        with pytest.raises(CarrierServerError):
            make_client().get_portfolio()

    @respx.mock
    def test_context_manager(self):
        """Verify context manager closes the HTTP client without error."""
        respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))
        with CarrierClient(api_key=API_KEY, base_url=BASE_URL, carrier_id="carrier_test", max_retries=0) as client:
            result = client.list_trials()
        assert result.count == 0


# ─── 409 ConflictError ───────────────────────────────────────────────────────

class TestConflictError:
    @respx.mock
    def test_conflict_error_inherits_carrier_error(self):
        """CarrierConflictError must be catchable as CarrierError."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_abc/convert").mock(
            return_value=httpx.Response(
                409,
                json={
                    "success": False,
                    "error": {"code": "CONCURRENT_MODIFICATION", "message": "Concurrent modification"},
                },
            )
        )
        with pytest.raises(CarrierError):
            make_client().convert_trial("trial_abc", "policy_123")

    @respx.mock
    def test_conflict_error_preserves_code(self):
        """CarrierConflictError exposes the error code from the response."""
        respx.post(f"{BASE_URL}/carrier/trials/trial_abc/convert").mock(
            return_value=httpx.Response(
                409,
                json={
                    "success": False,
                    "error": {"code": "TRIAL_ALREADY_CONVERTED", "message": "Already converted"},
                },
            )
        )
        with pytest.raises(CarrierConflictError) as exc_info:
            make_client().convert_trial("trial_abc", "policy_123")
        assert exc_info.value.status_code == 409
        assert exc_info.value.code == "TRIAL_ALREADY_CONVERTED"


# ─── observation.truncated ───────────────────────────────────────────────────

class TestObservationTruncated:
    @respx.mock
    def test_truncated_true_when_capped(self):
        respx.get(f"{BASE_URL}/carrier/trials/trial_large/status").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_large", "tenantId": "tenant_xyz", "prospectName": "Big",
                    "contactEmail": "b@ex.io", "status": "COMPLETED", "durationDays": 14,
                    "daysElapsed": 14, "daysRemaining": 0, "progressPercent": 100,
                    "startedAt": "2026-02-25T00:00:00Z", "expiresAt": "2026-03-11T00:00:00Z",
                    "observation": {"decisionsObserved": 10000, "wouldBlockCount": 500, "wouldBlockRate": 5.0, "truncated": True},
                },
            },
        ))
        result = make_client().get_trial_status("trial_large")
        assert result.observation.truncated is True
        assert result.observation.decisions_observed == 10000

    @respx.mock
    def test_truncated_defaults_false(self):
        respx.get(f"{BASE_URL}/carrier/trials/trial_small/status").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_small", "tenantId": "tenant_xyz", "prospectName": "Small",
                    "contactEmail": "s@ex.io", "status": "OBSERVING", "durationDays": 14,
                    "daysElapsed": 3, "daysRemaining": 11, "progressPercent": 21,
                    "startedAt": "2026-03-01T00:00:00Z", "expiresAt": "2026-03-15T00:00:00Z",
                    "observation": {"decisionsObserved": 50, "wouldBlockCount": 2, "wouldBlockRate": 4.0},
                },
            },
        ))
        result = make_client().get_trial_status("trial_small")
        assert result.observation.truncated is False

    @respx.mock
    def test_null_observation_handled_gracefully(self):
        """L4: observation=null must not crash — should produce zero-initialized TrialObservation."""
        respx.get(f"{BASE_URL}/carrier/trials/trial_new/status").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "trialId": "trial_new", "tenantId": "tenant_xyz", "prospectName": "New",
                    "contactEmail": "n@ex.io", "status": "OBSERVING", "durationDays": 14,
                    "daysElapsed": 0, "daysRemaining": 14, "progressPercent": 0,
                    "startedAt": "2026-03-11T00:00:00Z", "expiresAt": "2026-03-25T00:00:00Z",
                    "observation": None,
                },
            },
        ))
        result = make_client().get_trial_status("trial_new")
        assert result.observation.decisions_observed == 0
        assert result.observation.would_block_count == 0
        assert result.observation.truncated is False


# ─── decisionsAfterReceiptFix ────────────────────────────────────────────────

class TestDecisionsAfterReceiptFix:
    @respx.mock
    def test_present_in_underwriting_report(self):
        respx.get(f"{BASE_URL}/carrier/underwriting-report/tenant_xyz").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz", "tenantName": "Acme", "reportGeneratedAt": "2026-03-10T00:00:00Z",
                        "adoptionStage": "PROVENANCE", "isEnabled": True, "iamEnforced": True,
                        "decisions30d": {
                            "total": 10000, "allow": 9500, "block": 300, "wouldBlock": 200, "stepUp": 0,
                            "withReceiptSignature": 9800, "decisionsAfterReceiptFix": 8000,
                            "violationRate": 5.0, "attestationCoverage": 99.5,
                        },
                        "signers": {"activeCount": 3},
                        "snapshot": {"version": "snap_002", "policyHash": "def456"},
                    },
                },
            )
        )
        result = make_client().get_underwriting_report("tenant_xyz")
        assert result.decisions_30d.decisions_after_receipt_fix == 8000

    @respx.mock
    def test_defaults_to_zero_when_absent(self):
        respx.get(f"{BASE_URL}/carrier/underwriting-report/tenant_xyz").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz", "tenantName": "Acme", "reportGeneratedAt": "2026-03-10T00:00:00Z",
                        "adoptionStage": "SOFT_ENFORCE", "isEnabled": True, "iamEnforced": False,
                        "decisions30d": {
                            "total": 5000, "allow": 4800, "block": 150, "wouldBlock": 50, "stepUp": 0,
                            "withReceiptSignature": 4999, "violationRate": 4.0, "attestationCoverage": 99.98,
                        },
                        "signers": {"activeCount": 2},
                        "snapshot": {"version": "snap_001", "policyHash": "abc123"},
                    },
                },
            )
        )
        result = make_client().get_underwriting_report("tenant_xyz")
        assert result.decisions_30d.decisions_after_receipt_fix == 0


# ─── list_all_trials (auto-pagination) ───────────────────────────────────────

class TestListAllTrials:
    @respx.mock
    def test_auto_paginates_through_two_pages(self):
        """list_all_trials must follow nextToken across pages."""
        def trial_data(trial_id):
            return {
                "trialId": trial_id, "tenantId": "ten1", "prospectName": "A",
                "contactEmail": "a@ex.com", "status": "OBSERVING", "durationDays": 14,
                "startedAt": "2026-03-01T00:00:00Z", "expiresAt": "2026-03-15T00:00:00Z",
                "decisionsObserved": 10, "wouldBlockCount": 1,
            }

        # Page 1: has nextToken
        page1 = respx.get(f"{BASE_URL}/carrier/trials").mock(
            side_effect=[
                httpx.Response(200, json={
                    "success": True,
                    "data": {"trials": [trial_data("t1")], "count": 1, "hasMore": True, "nextToken": "cursor_2"},
                }),
                httpx.Response(200, json={
                    "success": True,
                    "data": {"trials": [trial_data("t2")], "count": 1, "hasMore": False},
                }),
            ]
        )

        trials = list(make_client().list_all_trials())
        assert len(trials) == 2
        assert trials[0].trial_id == "t1"
        assert trials[1].trial_id == "t2"

    @respx.mock
    def test_yields_nothing_for_empty_result(self):
        respx.get(f"{BASE_URL}/carrier/trials").mock(return_value=httpx.Response(
            200,
            json={"success": True, "data": {"trials": [], "count": 0, "hasMore": False}},
        ))
        trials = list(make_client().list_all_trials())
        assert len(trials) == 0


# ─── poll_claim_pack ─────────────────────────────────────────────────────────

class TestPollClaimPack:
    @respx.mock
    def test_resolves_on_complete(self):
        respx.get(f"{BASE_URL}/carrier/claim-pack/job_done").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "jobId": "job_done", "status": "COMPLETE", "tenantId": "tenant_xyz",
                    "createdAt": "2026-03-10T00:00:00Z", "completedAt": "2026-03-10T00:05:00Z",
                    "downloadUrl": "https://example.com/pack.zip", "error": None,
                },
            },
        ))
        result = make_client().poll_claim_pack("job_done")
        assert result.status == "COMPLETE"
        assert result.download_url == "https://example.com/pack.zip"

    @respx.mock
    def test_raises_on_failed(self):
        respx.get(f"{BASE_URL}/carrier/claim-pack/job_fail").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "jobId": "job_fail", "status": "FAILED", "tenantId": "tenant_xyz",
                    "createdAt": "2026-03-10T00:00:00Z", "completedAt": None,
                    "downloadUrl": None, "error": "Evidence generation failed",
                },
            },
        ))
        with pytest.raises(CarrierError) as exc_info:
            make_client().poll_claim_pack("job_fail")
        assert exc_info.value.code == "CLAIM_PACK_FAILED"

    @respx.mock
    def test_raises_timeout_when_stuck_running(self):
        respx.get(f"{BASE_URL}/carrier/claim-pack/job_slow").mock(return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {
                    "jobId": "job_slow", "status": "RUNNING", "tenantId": "tenant_xyz",
                    "createdAt": "2026-03-10T00:00:00Z", "completedAt": None,
                    "downloadUrl": None, "error": None,
                },
            },
        ))
        with pytest.raises(CarrierError) as exc_info:
            make_client().poll_claim_pack("job_slow", poll_interval_s=0.01, timeout_s=0.05)
        assert exc_info.value.code == "CLAIM_PACK_TIMEOUT"


# ─── Webhook signature verification ─────────────────────────────────────────

class TestWebhookVerification:
    def test_valid_signature(self):
        import hashlib, hmac as _hmac
        secret = "whsec_test_secret_123"
        payload = b'{"event":"alert.created","alertId":"alert_001"}'
        expected = _hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        sig = f"sha256={expected}"
        assert verify_webhook_signature(payload, sig, secret) is True

    def test_tampered_payload(self):
        import hashlib, hmac as _hmac
        secret = "whsec_test_secret_123"
        payload = b'{"event":"alert.created","alertId":"alert_001"}'
        expected = _hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        sig = f"sha256={expected}"
        tampered = b'{"event":"alert.created","alertId":"alert_002"}'
        assert verify_webhook_signature(tampered, sig, secret) is False

    def test_wrong_secret(self):
        import hashlib, hmac as _hmac
        secret = "whsec_test_secret_123"
        payload = b'{"event":"alert.created","alertId":"alert_001"}'
        expected = _hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        sig = f"sha256={expected}"
        assert verify_webhook_signature(payload, sig, "wrong_secret") is False

    def test_empty_inputs(self):
        assert verify_webhook_signature(b"", "sha256=abc", "secret") is False
        assert verify_webhook_signature(b"payload", "", "secret") is False
        assert verify_webhook_signature(b"payload", "sha256=abc", "") is False

    def test_string_payload(self):
        """verify_webhook_signature accepts both str and bytes payloads."""
        import hashlib, hmac as _hmac
        secret = "whsec_test"
        payload_str = '{"event":"test"}'
        expected = _hmac.new(secret.encode(), payload_str.encode(), hashlib.sha256).hexdigest()
        sig = f"sha256={expected}"
        assert verify_webhook_signature(payload_str, sig, secret) is True


# ─── Independent Evidence Verification ─────────────────────────────────────


# ─── get_active_policy ─────────────────────────────────────────────────────

class TestGetActivePolicy:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/active-policy").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "snapshotId": "snap_001",
                        "snapshotHash": "hash_abc",
                        "snapshotSignature": "sig_xyz",
                        "enforcementLevel": "HARD_KMS_GATEWAY",
                        "activatedAt": "2026-03-01T00:00:00Z",
                        "publishedAt": "2026-03-01T00:00:00Z",
                        "policyRules": [
                            {
                                "id": "deny_01",
                                "name": "Denylist",
                                "triggerType": "ADDRESS_FILTER",
                                "conditions": {},
                                "defenseAction": "BLOCK",
                                "isEnabled": True,
                            }
                        ],
                        "metadata": {},
                    },
                },
            )
        )

        result = make_client().get_active_policy("tenant_xyz")
        assert result.tenant_id == "tenant_xyz"
        assert result.enforcement_level == "HARD_KMS_GATEWAY"
        assert len(result.policy_rules) == 1
        assert result.policy_rules[0].trigger_type == "ADDRESS_FILTER"

    @respx.mock
    def test_404_unauthorized_tenant(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/active-policy").mock(
            return_value=httpx.Response(
                404,
                json={
                    "success": False,
                    "error": {"code": "TENANT_NOT_FOUND", "message": "Tenant not authorized"},
                },
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().get_active_policy("tenant_xyz")


# ─── get_policy_history ────────────────────────────────────────────────────

class TestGetPolicyHistory:
    @respx.mock
    def test_success_with_pagination(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/policy-history").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "versions": [
                            {
                                "snapshotId": "snap_002",
                                "snapshotHash": "hash_def",
                                "snapshotSignature": "sig_abc",
                                "enforcementLevel": "HARD_ENFORCE",
                                "activatedAt": "2026-03-05T00:00:00Z",
                                "deactivatedAt": None,
                                "publishedBy": "admin@acme.io",
                                "changeType": "PUBLISH",
                                "policyRuleCount": 3,
                            }
                        ],
                        "nextToken": "cursor_2",
                    },
                },
            )
        )

        result = make_client().get_policy_history("tenant_xyz")
        assert result.next_token == "cursor_2"
        assert len(result.versions) == 1
        assert result.versions[0].snapshot_id == "snap_002"
        assert result.versions[0].enforcement_level == "HARD_ENFORCE"


# ─── get_policy_at ─────────────────────────────────────────────────────────

class TestGetPolicyAt:
    @respx.mock
    def test_success(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/policy-at").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "snapshotId": "snap_001",
                        "snapshotHash": "hash_abc",
                        "snapshotSignature": None,
                        "enforcementLevel": "SOFT_ENFORCE",
                        "activatedAt": "2026-02-15T00:00:00Z",
                        "publishedAt": "2026-02-15T00:00:00Z",
                        "policyRules": [],
                        "metadata": {},
                    },
                },
            )
        )

        result = make_client().get_policy_at("tenant_xyz", timestamp="2026-02-20T00:00:00Z")
        assert result.snapshot_id == "snap_001"
        assert result.enforcement_level == "SOFT_ENFORCE"

    @respx.mock
    def test_404_no_policy_at_timestamp(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/policy-at").mock(
            return_value=httpx.Response(
                404,
                json={
                    "success": False,
                    "error": {"code": "POLICY_NOT_FOUND", "message": "No policy active at the given timestamp"},
                },
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().get_policy_at("tenant_xyz", timestamp="2020-01-01T00:00:00Z")


# ─── get_kms_inventory ────────────────────────────────────────────────────

class TestGetKmsInventory:
    @respx.mock
    def test_hard_kms_gateway_tenant(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/kms-inventory").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "adoptionStage": "HARD_KMS_GATEWAY",
                        "kmsKeyArn": "arn:aws:kms:us-east-1:123:key/abc",
                        "appIamRoleArn": "arn:aws:iam::123:role/app",
                        "hardEnforcementReady": True,
                        "kmsGatewayConfigured": True,
                        "enclaveAttestationConfigured": False,
                        "gcpConfidentialVmConfigured": False,
                        "lastIamVerification": {
                            "verifiedAt": "2026-03-10T00:00:00Z",
                            "appRoleHasSignPermission": False,
                            "gateRoleHasSignPermission": True,
                            "driftDetected": False,
                        },
                        "inventoryGeneratedAt": "2026-03-10T00:00:00Z",
                    },
                },
            )
        )

        result = make_client().get_kms_inventory("tenant_xyz")
        assert result.adoption_stage == "HARD_KMS_GATEWAY"
        assert result.kms_gateway_configured is True
        assert result.last_iam_verification is not None
        assert result.last_iam_verification.app_role_has_sign_permission is False
        assert result.last_iam_verification.gate_role_has_sign_permission is True
        assert result.last_iam_verification.drift_detected is False

    @respx.mock
    def test_shadow_tenant_null_iam_verification(self):
        respx.get(f"{BASE_URL}/carrier/tenants/tenant_xyz/kms-inventory").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "tenantId": "tenant_xyz",
                        "adoptionStage": "SHADOW",
                        "kmsKeyArn": None,
                        "appIamRoleArn": None,
                        "hardEnforcementReady": False,
                        "kmsGatewayConfigured": False,
                        "enclaveAttestationConfigured": False,
                        "gcpConfidentialVmConfigured": False,
                        "lastIamVerification": None,
                        "inventoryGeneratedAt": "2026-03-10T00:00:00Z",
                    },
                },
            )
        )

        result = make_client().get_kms_inventory("tenant_xyz")
        assert result.adoption_stage == "SHADOW"
        assert result.last_iam_verification is None


# ─── baseline policy ──────────────────────────────────────────────────────

class TestBaselinePolicy:
    @respx.mock
    def test_set_and_get_round_trip(self):
        respx.post(f"{BASE_URL}/carrier/baseline-policy").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "carrierId": "carrier_test",
                        "baselineHash": "bh_abc123",
                        "baseline": {
                            "requiredRules": [
                                {
                                    "ruleId": "deny_01",
                                    "description": "Denylist required",
                                    "triggerType": "ADDRESS_FILTER",
                                    "requiredConditions": {},
                                    "requiredActions": ["BLOCK"],
                                }
                            ],
                            "minimumEnforcementLevel": "HARD_ENFORCE",
                        },
                        "createdAt": "2026-03-10T00:00:00Z",
                        "updatedAt": "2026-03-10T00:00:00Z",
                    },
                },
            )
        )

        baseline_spec = BaselineSpec(
            required_rules=[
                BaselineRule(
                    rule_id="deny_01",
                    description="Denylist required",
                    trigger_type="ADDRESS_FILTER",
                    required_conditions={},
                    required_actions=["BLOCK"],
                )
            ],
            minimum_enforcement_level="HARD_ENFORCE",
        )
        result = make_client().set_baseline_policy(baseline_spec)
        assert result.carrier_id == "carrier_test"
        assert result.baseline_hash == "bh_abc123"
        assert result.baseline.minimum_enforcement_level == "HARD_ENFORCE"
        assert len(result.baseline.required_rules) == 1
        assert result.baseline.required_rules[0].trigger_type == "ADDRESS_FILTER"

    @respx.mock
    def test_get_404_not_set(self):
        respx.get(f"{BASE_URL}/carrier/baseline-policy").mock(
            return_value=httpx.Response(
                404,
                json={
                    "success": False,
                    "error": {"code": "BASELINE_NOT_FOUND", "message": "No baseline policy has been set"},
                },
            )
        )
        with pytest.raises(CarrierNotFoundError):
            make_client().get_baseline_policy()


# ─── simulate_transaction ─────────────────────────────────────────────────

class TestSimulateTransaction:
    @respx.mock
    def test_block_on_denylisted_address(self):
        respx.post(f"{BASE_URL}/carrier/tenants/tenant_xyz/simulate-transaction").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "decision": "BLOCK",
                        "reasonCodes": ["ADDRESS_DENYLISTED"],
                        "simulatedAt": "2026-03-10T12:00:00Z",
                        "snapshotHash": "hash_abc",
                        "enforcementLevel": "HARD_ENFORCE",
                        "isSimulation": True,
                        "matchedRules": [
                            {
                                "ruleId": "deny_01",
                                "ruleName": "Denylist",
                                "action": "BLOCK",
                                "triggerType": "ADDRESS_FILTER",
                            }
                        ],
                    },
                },
            )
        )

        result = make_client().simulate_transaction(
            "tenant_xyz",
            tx_intent={"toAddress": "0xBAD", "networkFamily": "EVM", "chainId": 1},
        )
        assert result.decision == "BLOCK"
        assert result.is_simulation is True
        assert len(result.matched_rules) == 1
        assert result.matched_rules[0].rule_id == "deny_01"

    @respx.mock
    def test_allow_on_compliant_tx(self):
        respx.post(f"{BASE_URL}/carrier/tenants/tenant_xyz/simulate-transaction").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "decision": "ALLOW",
                        "reasonCodes": [],
                        "simulatedAt": "2026-03-10T12:00:00Z",
                        "snapshotHash": "hash_abc",
                        "enforcementLevel": "HARD_ENFORCE",
                        "isSimulation": True,
                        "matchedRules": [],
                    },
                },
            )
        )

        result = make_client().simulate_transaction(
            "tenant_xyz",
            tx_intent={"toAddress": "0xGOOD", "networkFamily": "EVM", "chainId": 1},
        )
        assert result.decision == "ALLOW"
        assert len(result.matched_rules) == 0


# ─── verify_policy_compliance (pure function) ─────────────────────────────

class TestVerifyPolicyCompliance:
    def test_missing_rule_not_compliant(self):
        """Active policy lacks a required ADDRESS_FILTER rule."""
        active = ActivePolicyResponse(
            tenant_id="tenant_xyz",
            snapshot_id="snap_001",
            snapshot_hash="hash_abc",
            snapshot_signature=None,
            enforcement_level="HARD_ENFORCE",
            activated_at="2026-03-01T00:00:00Z",
            published_at="2026-03-01T00:00:00Z",
            policy_rules=[],  # no rules at all
            metadata={},
        )
        baseline = BaselineSpec(
            required_rules=[
                BaselineRule(
                    rule_id="deny_01",
                    description="Denylist required",
                    trigger_type="ADDRESS_FILTER",
                    required_conditions={},
                    required_actions=["BLOCK"],
                )
            ],
            minimum_enforcement_level="HARD_ENFORCE",
        )

        diff = verify_policy_compliance(active, baseline)
        assert diff.is_compliant is False
        assert len(diff.missing_rules) == 1
        assert diff.missing_rules[0].status == "MISSING"
        assert diff.missing_rules[0].trigger_type == "ADDRESS_FILTER"

    def test_weaker_enforcement_not_compliant(self):
        """Active enforcement is SHADOW, baseline requires HARD_ENFORCE."""
        active = ActivePolicyResponse(
            tenant_id="tenant_xyz",
            snapshot_id="snap_001",
            snapshot_hash="hash_abc",
            snapshot_signature=None,
            enforcement_level="SHADOW",
            activated_at="2026-03-01T00:00:00Z",
            published_at="2026-03-01T00:00:00Z",
            policy_rules=[
                PolicyRule(
                    id="deny_01",
                    name="Denylist",
                    trigger_type="ADDRESS_FILTER",
                    conditions={},
                    defense_action="BLOCK",
                    is_enabled=True,
                )
            ],
            metadata={},
        )
        baseline = BaselineSpec(
            required_rules=[
                BaselineRule(
                    rule_id="deny_01",
                    description="Denylist required",
                    trigger_type="ADDRESS_FILTER",
                    required_conditions={},
                    required_actions=["BLOCK"],
                )
            ],
            minimum_enforcement_level="HARD_ENFORCE",
        )

        diff = verify_policy_compliance(active, baseline)
        assert diff.is_compliant is False
        assert diff.enforcement_compliant is False
        assert diff.enforcement_level == "SHADOW"

    def test_all_satisfied_compliant(self):
        """Active policy meets all baseline requirements."""
        active = ActivePolicyResponse(
            tenant_id="tenant_xyz",
            snapshot_id="snap_001",
            snapshot_hash="hash_abc",
            snapshot_signature=None,
            enforcement_level="HARD_ENFORCE",
            activated_at="2026-03-01T00:00:00Z",
            published_at="2026-03-01T00:00:00Z",
            policy_rules=[
                PolicyRule(
                    id="deny_01",
                    name="Denylist",
                    trigger_type="ADDRESS_FILTER",
                    conditions={},
                    defense_action="BLOCK",
                    is_enabled=True,
                )
            ],
            metadata={},
        )
        baseline = BaselineSpec(
            required_rules=[
                BaselineRule(
                    rule_id="deny_01",
                    description="Denylist required",
                    trigger_type="ADDRESS_FILTER",
                    required_conditions={},
                    required_actions=["BLOCK"],
                )
            ],
            minimum_enforcement_level="HARD_ENFORCE",
        )

        diff = verify_policy_compliance(active, baseline)
        assert diff.is_compliant is True
        assert diff.enforcement_compliant is True
        assert len(diff.satisfied_rules) == 1
        assert len(diff.missing_rules) == 0
        assert len(diff.weaker_rules) == 0

    def test_weaker_action_status(self):
        """Active rule has LOG action, baseline requires BLOCK."""
        active = ActivePolicyResponse(
            tenant_id="tenant_xyz",
            snapshot_id="snap_001",
            snapshot_hash="hash_abc",
            snapshot_signature=None,
            enforcement_level="HARD_ENFORCE",
            activated_at="2026-03-01T00:00:00Z",
            published_at="2026-03-01T00:00:00Z",
            policy_rules=[
                PolicyRule(
                    id="deny_01",
                    name="Denylist",
                    trigger_type="ADDRESS_FILTER",
                    conditions={},
                    defense_action="LOG",
                    is_enabled=True,
                )
            ],
            metadata={},
        )
        baseline = BaselineSpec(
            required_rules=[
                BaselineRule(
                    rule_id="deny_01",
                    description="Denylist required",
                    trigger_type="ADDRESS_FILTER",
                    required_conditions={},
                    required_actions=["BLOCK"],
                )
            ],
            minimum_enforcement_level="HARD_ENFORCE",
        )

        diff = verify_policy_compliance(active, baseline)
        assert diff.is_compliant is False
        assert len(diff.weaker_rules) == 1
        assert diff.weaker_rules[0].status == "WEAKER"
        assert diff.weaker_rules[0].rule_id == "deny_01"


# ─── policy webhooks ──────────────────────────────────────────────────────

class TestPolicyWebhooks:
    @respx.mock
    def test_register_success(self):
        respx.post(f"{BASE_URL}/carrier/webhooks/policy-changes").mock(
            return_value=httpx.Response(
                201,
                json={
                    "success": True,
                    "data": {
                        "subscriptionId": "sub_abc",
                        "webhookUrl": "https://carrier.example.com/hooks/gate-policy",
                        "events": ["POLICY_CHANGED"],
                        "webhookSecret": "whsec_secret123",
                        "createdAt": "2026-03-10T00:00:00Z",
                    },
                },
            )
        )

        result = make_client().register_policy_change_webhook(
            webhook_url="https://carrier.example.com/hooks/gate-policy",
            events=["POLICY_CHANGED"],
        )
        assert result.subscription_id == "sub_abc"
        assert result.webhook_url == "https://carrier.example.com/hooks/gate-policy"
        assert result.webhook_secret == "whsec_secret123"
        assert result.events == ["POLICY_CHANGED"]

    @respx.mock
    def test_list_success(self):
        respx.get(f"{BASE_URL}/carrier/webhooks/policy-changes").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "subscriptions": [
                            {
                                "subscriptionId": "sub_abc",
                                "webhookUrl": "https://carrier.example.com/hooks/gate-policy",
                                "events": ["POLICY_CHANGED"],
                                "status": "ACTIVE",
                                "createdAt": "2026-03-10T00:00:00Z",
                            }
                        ],
                    },
                },
            )
        )

        result = make_client().list_policy_webhooks()
        assert len(result.subscriptions) == 1
        assert result.subscriptions[0].subscription_id == "sub_abc"
        assert result.subscriptions[0].status == "ACTIVE"
