"""
Shared pytest fixtures for the Carrier SDK test suite.
"""

import pytest
from gate_carrier_sdk import CarrierClient

BASE_URL = "https://api.gate.blockintelai.net/api/v1/gate"
API_KEY = "carrier_test_key_abc123"


@pytest.fixture
def client():
    """CarrierClient with max_retries=0 for deterministic test behaviour."""
    return CarrierClient(api_key=API_KEY, base_url=BASE_URL, carrier_id="carrier_test", max_retries=0)
