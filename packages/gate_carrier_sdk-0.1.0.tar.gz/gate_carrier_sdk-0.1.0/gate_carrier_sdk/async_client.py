"""
AsyncCarrierClient — Async SDK class for the BlockIntel Gate Carrier API.

For use with asyncio-based frameworks (FastAPI, aiohttp, etc.).

Usage::

    from gate_carrier_sdk import AsyncCarrierClient

    async with AsyncCarrierClient(
        api_key="carrier_abc123...",
        base_url="https://api.gate.blockintelai.net/api/v1/gate",
        carrier_id="carrier_xyz",
    ) as client:
        score = await client.get_risk_score("tenant_xyz")
        print(score.composite_score, score.risk_label)
"""

from __future__ import annotations

import asyncio
import time as _time
from typing import Any, AsyncIterator, Dict, List, Optional

from urllib.parse import quote

from .async_http import AsyncHttpClient
from .errors import CarrierError
from .types import (
    AcknowledgeAlertResponse,
    ActivePolicyResponse,
    BaselinePolicyResponse,
    BaselineSpec,
    BBRReportResponse,
    ClaimPackStatusResponse,
    ConvertTrialResponse,
    CreateBBRTestResponse,
    CreateTrialResponse,
    EvidenceBundleResponse,
    GenerateClaimPackResponse,
    GetAlertsResponse,
    KmsInventoryResponse,
    ListTrialsResponse,
    MaxLossEstimateResponse,
    PolicyHistoryResponse,
    PortfolioHealthResponse,
    PortfolioResponse,
    PortfolioSummaryResponse,
    RiskScoreResponse,
    SimulationResponse,
    TrialStatusResponse,
    TrialSummary,
    UnderwritingReportResponse,
    WebhookListResponse,
    WebhookRegistrationResponse,
)


class AsyncCarrierClient:
    """
    Async BlockIntel Gate Carrier SDK client.

    Safe for concurrent use with ``asyncio``.

    :param api_key: Carrier API key (format: ``carrier_<hex>``).
    :param base_url: Base URL for the Gate control plane.
    :param carrier_id: Carrier identifier.
    :param timeout_s: Request timeout in seconds. Default: 30.
    :param max_retries: Max retry attempts on transient failures. Default: 3.
    :param user_agent_suffix: Optional suffix for the User-Agent header.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        carrier_id: str,
        timeout_s: float = 30.0,
        max_retries: int = 3,
        user_agent_suffix: Optional[str] = None,
    ) -> None:
        self._carrier_id = carrier_id
        self._http = AsyncHttpClient(
            base_url=base_url,
            api_key=api_key,
            timeout_s=timeout_s,
            max_retries=max_retries,
            user_agent_suffix=user_agent_suffix,
        )

    async def close(self) -> None:
        await self._http.close()

    async def __aenter__(self) -> "AsyncCarrierClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ─── Trial management ────────────────────────────────────────────────────────

    async def create_underwriting_trial(
        self, prospect_name: str, contact_email: str, duration_days: int = 14,
    ) -> CreateTrialResponse:
        data = await self._http.post("/carrier/trials/create", json={
            "prospectName": prospect_name,
            "contactEmail": contact_email,
            "durationDays": duration_days,
        })
        return CreateTrialResponse.from_dict(data)

    async def get_trial_status(self, trial_id: str) -> TrialStatusResponse:
        data = await self._http.get(f"/carrier/trials/{quote(trial_id, safe='')}/status")
        return TrialStatusResponse.from_dict(data)

    async def list_trials(
        self, status: Optional[str] = None, next_token: Optional[str] = None, limit: Optional[int] = None,
    ) -> ListTrialsResponse:
        params: Dict[str, Any] = {}
        if status:
            params["status"] = status
        if next_token:
            params["nextToken"] = next_token
        if limit is not None:
            params["limit"] = limit
        data = await self._http.get("/carrier/trials", params=params or None)
        return ListTrialsResponse.from_dict(data)

    async def convert_trial(self, trial_id: str, policy_id: str) -> ConvertTrialResponse:
        data = await self._http.post(
            f"/carrier/trials/{quote(trial_id, safe='')}/convert",
            json={"policyId": policy_id},
        )
        return ConvertTrialResponse.from_dict(data)

    # ─── Portfolio ───────────────────────────────────────────────────────────────

    async def get_portfolio(self) -> PortfolioResponse:
        data = await self._http.get("/carrier/v2/portfolio")
        return PortfolioResponse.from_dict(data)

    async def get_portfolio_health(self) -> PortfolioHealthResponse:
        data = await self._http.get("/carrier/bbr/overview")
        return PortfolioHealthResponse.from_dict(data)

    # ─── BBR ─────────────────────────────────────────────────────────────────────

    async def create_bbr_test(
        self, tenant_id: str, start_at: Optional[str] = None,
        end_at: Optional[str] = None, bots: Optional[List[Dict[str, str]]] = None,
    ) -> CreateBBRTestResponse:
        payload: Dict[str, Any] = {"tenantId": tenant_id}
        if start_at:
            payload["startAt"] = start_at
        if end_at:
            payload["endAt"] = end_at
        if bots:
            payload["bots"] = bots
        data = await self._http.post("/carrier/bbr/create-test", json=payload)
        return CreateBBRTestResponse.from_dict(data)

    async def get_bbr_report(self, tenant_id: str) -> BBRReportResponse:
        data = await self._http.get(f"/carrier/bbr/{quote(tenant_id, safe='')}/report")
        return BBRReportResponse.from_dict(data)

    async def get_portfolio_summary(self) -> PortfolioSummaryResponse:
        data = await self._http.get("/carrier/bbr/portfolio-summary")
        return PortfolioSummaryResponse.from_dict(data)

    async def get_max_loss_estimate(self) -> MaxLossEstimateResponse:
        data = await self._http.get("/carrier/bbr/max-loss-estimate")
        return MaxLossEstimateResponse.from_dict(data)

    # ─── Alerts ──────────────────────────────────────────────────────────────────

    async def get_alerts(self, severity: Optional[str] = None) -> GetAlertsResponse:
        params: Dict[str, Any] = {}
        if severity:
            params["severity"] = severity
        data = await self._http.get("/carrier/alerts", params=params or None)
        return GetAlertsResponse.from_dict(data)

    async def acknowledge_alert(self, alert_id: str) -> AcknowledgeAlertResponse:
        data = await self._http.post(f"/carrier/alerts/{quote(alert_id, safe='')}/acknowledge")
        return AcknowledgeAlertResponse.from_dict(data)

    # ─── Evidence ────────────────────────────────────────────────────────────────

    async def generate_claim_pack(
        self, tenant_id: str, period_start: str, period_end: str, bbr_test_id: Optional[str] = None,
    ) -> GenerateClaimPackResponse:
        payload: Dict[str, Any] = {
            "tenantId": tenant_id, "periodStart": period_start, "periodEnd": period_end,
        }
        if bbr_test_id:
            payload["bbrTestId"] = bbr_test_id
        data = await self._http.post(
            f"/carrier/{quote(self._carrier_id, safe='')}/tenants/{quote(tenant_id, safe='')}/claim-pack",
            json=payload,
        )
        return GenerateClaimPackResponse.from_dict(data)

    async def get_claim_pack_status(self, job_id: str) -> ClaimPackStatusResponse:
        data = await self._http.get(f"/carrier/claim-pack/{quote(job_id, safe='')}")
        return ClaimPackStatusResponse.from_dict(data)

    async def get_evidence_bundle(self, tenant_id: str) -> EvidenceBundleResponse:
        data = await self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/evidence-bundle")
        return EvidenceBundleResponse.from_dict(data)

    # ─── Underwriting analytics ───────────────────────────────────────────────────

    async def get_underwriting_report(self, tenant_id: str) -> UnderwritingReportResponse:
        data = await self._http.get(f"/carrier/underwriting-report/{quote(tenant_id, safe='')}")
        return UnderwritingReportResponse.from_dict(data)

    async def get_risk_score(self, tenant_id: str) -> RiskScoreResponse:
        data = await self._http.get(f"/carrier/risk-score/{quote(tenant_id, safe='')}")
        return RiskScoreResponse.from_dict(data)

    # ─── Independent Evidence Verification ───────────────────────────────────

    async def get_active_policy(self, tenant_id: str) -> ActivePolicyResponse:
        data = await self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/active-policy")
        return ActivePolicyResponse.from_dict(data)

    async def get_policy_history(
        self, tenant_id: str, next_token: Optional[str] = None, limit: Optional[int] = None,
    ) -> PolicyHistoryResponse:
        params: Dict[str, Any] = {}
        if next_token:
            params["nextToken"] = next_token
        if limit is not None:
            params["limit"] = limit
        data = await self._http.get(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/policy-history",
            params=params or None,
        )
        return PolicyHistoryResponse.from_dict(data)

    async def get_policy_at(self, tenant_id: str, timestamp: str) -> ActivePolicyResponse:
        data = await self._http.get(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/policy-at",
            params={"timestamp": timestamp},
        )
        return ActivePolicyResponse.from_dict(data)

    async def get_kms_inventory(self, tenant_id: str) -> KmsInventoryResponse:
        data = await self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/kms-inventory")
        return KmsInventoryResponse.from_dict(data)

    async def set_baseline_policy(self, baseline: BaselineSpec) -> BaselinePolicyResponse:
        data = await self._http.post("/carrier/baseline-policy", json=baseline.to_dict())
        return BaselinePolicyResponse.from_dict(data)

    async def get_baseline_policy(self) -> BaselinePolicyResponse:
        data = await self._http.get("/carrier/baseline-policy")
        return BaselinePolicyResponse.from_dict(data)

    async def simulate_transaction(
        self, tenant_id: str, tx_intent: Optional[Dict[str, Any]] = None,
        signing_context: Optional[Dict[str, Any]] = None,
    ) -> SimulationResponse:
        payload: Dict[str, Any] = {}
        if tx_intent:
            payload["txIntent"] = tx_intent
        if signing_context:
            payload["signingContext"] = signing_context
        data = await self._http.post(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/simulate-transaction",
            json=payload,
        )
        return SimulationResponse.from_dict(data)

    async def register_policy_change_webhook(
        self, webhook_url: str, events: Optional[List[str]] = None,
    ) -> WebhookRegistrationResponse:
        payload: Dict[str, Any] = {"webhookUrl": webhook_url}
        if events:
            payload["events"] = events
        data = await self._http.post("/carrier/webhooks/policy-changes", json=payload)
        return WebhookRegistrationResponse.from_dict(data)

    async def list_policy_webhooks(self) -> WebhookListResponse:
        data = await self._http.get("/carrier/webhooks/policy-changes")
        return WebhookListResponse.from_dict(data)

    # ─── Convenience helpers ──────────────────────────────────────────────────────

    async def list_all_trials(
        self, status: Optional[str] = None, limit: Optional[int] = None,
    ) -> AsyncIterator[TrialSummary]:
        next_token: Optional[str] = None
        while True:
            page = await self.list_trials(status=status, next_token=next_token, limit=limit)
            for trial in page.trials:
                yield trial
            next_token = page.next_token
            if not next_token:
                break

    async def poll_claim_pack(
        self, job_id: str, poll_interval_s: float = 3.0, timeout_s: float = 600.0,
    ) -> ClaimPackStatusResponse:
        """Poll a claim pack job until completion or timeout."""
        deadline = _time.monotonic() + timeout_s
        while _time.monotonic() < deadline:
            result = await self.get_claim_pack_status(job_id)
            if result.status == "COMPLETE":
                return result
            if result.status == "FAILED":
                raise CarrierError(
                    result.error or f"Claim pack job {job_id} failed",
                    status_code=0, code="CLAIM_PACK_FAILED",
                )
            remaining = deadline - _time.monotonic()
            if remaining <= 0:
                break
            await asyncio.sleep(min(poll_interval_s, remaining))
        raise CarrierError(
            f"Claim pack job {job_id} timed out after {timeout_s}s",
            status_code=0, code="CLAIM_PACK_TIMEOUT",
        )
