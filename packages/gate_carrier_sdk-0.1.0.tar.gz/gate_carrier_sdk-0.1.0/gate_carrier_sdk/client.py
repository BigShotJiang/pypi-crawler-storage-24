"""
CarrierClient — Main SDK class for the BlockIntel Gate Carrier API.

Authentication: static X-Carrier-Api-Key header on every request.
No HMAC signing, no JWT, no heartbeats.

Usage::

    from gate_carrier_sdk import CarrierClient

    client = CarrierClient(
        api_key="carrier_abc123...",
        base_url="https://api.gate.blockintelai.net/api/v1/gate",
    )
    report = client.get_underwriting_report("tenant_xyz")
    print(report.composite_score)

Context manager::

    with CarrierClient(api_key="...", base_url="...") as client:
        trials = client.list_trials()
"""

from __future__ import annotations

import time
from typing import Any, Dict, Iterator, List, Optional

from urllib.parse import quote

from .errors import CarrierError
from .http import HttpClient
from .types import (
    AcknowledgeAlertResponse,
    ActivePolicyResponse,
    BaselinePolicyResponse,
    BaselineSpec,
    BBRReportResponse,
    ClaimPackStatusResponse,
    ConvertTrialResponse,
    CreateBBRTestResponse,
    CreateTrialResponse,
    EvidenceBundleResponse,
    GenerateClaimPackResponse,
    GetAlertsResponse,
    KmsInventoryResponse,
    ListTrialsResponse,
    MaxLossEstimateResponse,
    PolicyHistoryResponse,
    PortfolioHealthResponse,
    PortfolioResponse,
    PortfolioSummaryResponse,
    RiskScoreResponse,
    SimulationResponse,
    TrialStatusResponse,
    TrialSummary,
    UnderwritingReportResponse,
    WebhookListResponse,
    WebhookRegistrationResponse,
)


class CarrierClient:
    """
    BlockIntel Gate Carrier SDK client.

    :param api_key: Carrier API key (format: ``carrier_<hex>``).
    :param base_url: Base URL for the Gate control plane.
        Production: ``https://api.gate.blockintelai.net/api/v1/gate``
    :param carrier_id: Carrier identifier. Required for claim-pack endpoints
        whose URL paths are scoped to the carrier.
    :param timeout_s: Request timeout in seconds. Default: 30.
    :param max_retries: Max retry attempts on transient failures. Default: 3.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        carrier_id: str,
        timeout_s: float = 30.0,
        max_retries: int = 3,
        user_agent_suffix: Optional[str] = None,
    ) -> None:
        """
        :param api_key: Carrier API key (format: ``carrier_<hex>``).
        :param base_url: Base URL for the Gate control plane.
        :param carrier_id: Carrier identifier.
        :param timeout_s: Request timeout in seconds. Default: 30.
        :param max_retries: Max retry attempts on transient failures. Default: 3.
        :param user_agent_suffix: Optional suffix for the User-Agent header
            (e.g. ``"AcmeInsurance/1.0"``).

        .. warning::
            This client uses ``httpx.Client`` which is **not thread-safe**.
            Create one client per thread, or use :class:`AsyncCarrierClient`
            for concurrent async workflows.
        """
        self._carrier_id = carrier_id
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            timeout_s=timeout_s,
            max_retries=max_retries,
            user_agent_suffix=user_agent_suffix,
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "CarrierClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ─── Trial management ────────────────────────────────────────────────────────

    def create_underwriting_trial(
        self,
        prospect_name: str,
        contact_email: str,
        duration_days: int = 14,
    ) -> CreateTrialResponse:
        """
        Create a shadow-mode prospect tenant for underwriting evaluation.

        :param prospect_name: Display name for the prospect organisation.
        :param contact_email: Primary contact email.
        :param duration_days: Observation window (1–90 days). Default 14.
        :returns: :class:`CreateTrialResponse` with ``trial_id`` and ``tenant_id``.

        Rate limit: 10 trials per minute per carrier (burst).
        """
        data = self._http.post("/carrier/trials/create", json={
            "prospectName": prospect_name,
            "contactEmail": contact_email,
            "durationDays": duration_days,
        })
        return CreateTrialResponse.from_dict(data)

    def get_trial_status(self, trial_id: str) -> TrialStatusResponse:
        """
        Get detailed status for a specific trial, including observation progress.

        :param trial_id: Trial ID returned by :meth:`create_underwriting_trial`.
        :returns: :class:`TrialStatusResponse` with ``days_elapsed``, ``observation``, etc.
        """
        data = self._http.get(f"/carrier/trials/{quote(trial_id, safe='')}/status")
        return TrialStatusResponse.from_dict(data)

    def list_trials(
        self,
        status: Optional[str] = None,
        next_token: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> ListTrialsResponse:
        """
        List all trials for the authenticated carrier.

        :param status: Optional filter — one of OBSERVING, COMPLETED, CONVERTED, EXPIRED.
        :param next_token: Pagination cursor from a previous response.
        :param limit: Items per page (1–500). Default: 100.
            Note: when ``status`` is set, DynamoDB applies the filter after evaluating
            the page limit, so fewer than ``limit`` items may be returned even when more
            exist. Always consume ``next_token`` until it is ``None`` to retrieve all
            matching trials.
        :returns: :class:`ListTrialsResponse` with ``trials`` list, ``count``, and ``has_more``.
        """
        params: Dict[str, Any] = {}
        if status:
            params["status"] = status
        if next_token:
            params["nextToken"] = next_token
        if limit is not None:
            params["limit"] = limit
        data = self._http.get("/carrier/trials", params=params or None)
        return ListTrialsResponse.from_dict(data)

    def convert_trial(self, trial_id: str, policy_id: str) -> ConvertTrialResponse:
        """
        Convert a completed trial prospect to an insured tenant.

        :param trial_id: Trial ID to convert.
        :param policy_id: Insurance policy ID to associate with the tenant.
        :returns: :class:`ConvertTrialResponse` confirming conversion.
        """
        data = self._http.post(
            f"/carrier/trials/{quote(trial_id, safe='')}/convert",
            json={"policyId": policy_id},
        )
        return ConvertTrialResponse.from_dict(data)

    # ─── Portfolio ───────────────────────────────────────────────────────────────

    def get_portfolio(self) -> PortfolioResponse:
        """
        Full portfolio dashboard: risk summaries, metrics, and alerts.

        :returns: :class:`PortfolioResponse`.
        """
        data = self._http.get("/carrier/v2/portfolio")
        return PortfolioResponse.from_dict(data)

    def get_portfolio_health(self) -> PortfolioHealthResponse:
        """
        High-level portfolio health status.

        :returns: :class:`PortfolioHealthResponse`.
        """
        data = self._http.get("/carrier/bbr/overview")
        return PortfolioHealthResponse.from_dict(data)

    # ─── BBR ─────────────────────────────────────────────────────────────────────

    def create_bbr_test(
        self,
        tenant_id: str,
        start_at: Optional[str] = None,
        end_at: Optional[str] = None,
        bots: Optional[List[Dict[str, str]]] = None,
    ) -> CreateBBRTestResponse:
        """
        Create a bot blast radius test for an authorized tenant.

        :param tenant_id: Target tenant ID (must be in authorized portfolio).
        :param start_at: ISO 8601 start time (optional).
        :param end_at: ISO 8601 end time (optional).
        :param bots: List of ``{"signerId": "..."}`` dicts (optional).
        :returns: :class:`CreateBBRTestResponse` with ``test_id`` and ``quota_remaining``.

        Monthly quota: 10 tests/month per carrier.
        BBR test status lifecycle: ``OPEN`` → ``RUNNING`` → ``CLOSED`` | ``FAILED``.
        The initial status is always ``OPEN`` (not ``RUNNING``).
        """
        payload: Dict[str, Any] = {"tenantId": tenant_id}
        if start_at:
            payload["startAt"] = start_at
        if end_at:
            payload["endAt"] = end_at
        if bots:
            payload["bots"] = bots
        data = self._http.post("/carrier/bbr/create-test", json=payload)
        return CreateBBRTestResponse.from_dict(data)

    def get_bbr_report(self, tenant_id: str) -> BBRReportResponse:
        """
        Get the BBR report for a specific tenant.

        :param tenant_id: Target tenant ID.
        :returns: :class:`BBRReportResponse`.
        """
        data = self._http.get(f"/carrier/bbr/{quote(tenant_id, safe='')}/report")
        return BBRReportResponse.from_dict(data)

    def get_portfolio_summary(self) -> PortfolioSummaryResponse:
        """
        BBR metrics aggregated across all authorized tenants.

        :returns: :class:`PortfolioSummaryResponse`.
        """
        data = self._http.get("/carrier/bbr/portfolio-summary")
        return PortfolioSummaryResponse.from_dict(data)

    def get_max_loss_estimate(self) -> MaxLossEstimateResponse:
        """
        Portfolio max-loss estimate at p50/p90/p99 confidence levels.

        :returns: :class:`MaxLossEstimateResponse`.
        """
        data = self._http.get("/carrier/bbr/max-loss-estimate")
        return MaxLossEstimateResponse.from_dict(data)

    # ─── Alerts ──────────────────────────────────────────────────────────────────

    def get_alerts(self, severity: Optional[str] = None) -> GetAlertsResponse:
        """
        Alert history across the portfolio.

        :param severity: Optional filter — one of CRITICAL, HIGH, MEDIUM, LOW.
        :returns: :class:`GetAlertsResponse` with ``alerts`` list.
        """
        params: Dict[str, Any] = {}
        if severity:
            params["severity"] = severity
        data = self._http.get("/carrier/alerts", params=params or None)
        return GetAlertsResponse.from_dict(data)

    def acknowledge_alert(self, alert_id: str) -> AcknowledgeAlertResponse:
        """
        Mark an alert as reviewed/acknowledged.

        :param alert_id: Alert ID to acknowledge.
        :returns: :class:`AcknowledgeAlertResponse`.
        """
        data = self._http.post(f"/carrier/alerts/{quote(alert_id, safe='')}/acknowledge")
        return AcknowledgeAlertResponse.from_dict(data)

    # ─── Evidence ────────────────────────────────────────────────────────────────

    def generate_claim_pack(
        self,
        tenant_id: str,
        period_start: str,
        period_end: str,
        bbr_test_id: Optional[str] = None,
    ) -> GenerateClaimPackResponse:
        """
        Initiate async generation of a claim evidence pack.

        Poll :meth:`get_claim_pack_status` until ``status == "COMPLETE"``,
        or use :meth:`poll_claim_pack` for automatic polling.

        Rate limit: 5 claim packs per hour per carrier.
        Stale jobs (PENDING/RUNNING > 10 min) are auto-marked FAILED by the backend.

        :param tenant_id: Target tenant ID.
        :param period_start: ISO 8601 start date for evidence window.
        :param period_end: ISO 8601 end date for evidence window.
        :param bbr_test_id: Optional BBR test ID to include in the pack.
        :returns: :class:`GenerateClaimPackResponse` with ``job_id``.
        """
        payload: Dict[str, Any] = {
            "tenantId": tenant_id,
            "periodStart": period_start,
            "periodEnd": period_end,
        }
        if bbr_test_id:
            payload["bbrTestId"] = bbr_test_id
        data = self._http.post(
            f"/carrier/{quote(self._carrier_id, safe='')}/tenants/{quote(tenant_id, safe='')}/claim-pack",
            json=payload,
        )
        return GenerateClaimPackResponse.from_dict(data)

    def get_claim_pack_status(self, job_id: str) -> ClaimPackStatusResponse:
        """
        Check the status of a claim pack generation job.

        :param job_id: Job ID from :meth:`generate_claim_pack`.
        :returns: :class:`ClaimPackStatusResponse` with ``status`` and optional ``download_url``.
        """
        data = self._http.get(f"/carrier/claim-pack/{quote(job_id, safe='')}")
        return ClaimPackStatusResponse.from_dict(data)

    def get_evidence_bundle(self, tenant_id: str) -> EvidenceBundleResponse:
        """
        Get the raw evidence bundle for a tenant.

        :param tenant_id: Target tenant ID.
        :returns: :class:`EvidenceBundleResponse` with decisions, snapshots, and Merkle root.
        """
        data = self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/evidence-bundle")
        return EvidenceBundleResponse.from_dict(data)

    # ─── Underwriting analytics ───────────────────────────────────────────────────

    def get_underwriting_report(self, tenant_id: str) -> UnderwritingReportResponse:
        """
        Aggregated underwriting metrics for a tenant (30-day decisions, coverage, violations,
        active signers, current adoption stage and policy snapshot version).

        :param tenant_id: Target tenant ID (must be in authorized portfolio).
        :returns: :class:`UnderwritingReportResponse`.
        """
        data = self._http.get(f"/carrier/underwriting-report/{quote(tenant_id, safe='')}")
        return UnderwritingReportResponse.from_dict(data)

    def get_risk_score(self, tenant_id: str) -> RiskScoreResponse:
        """
        Composite risk score (0–100) with factor breakdown for a tenant.

        Higher score = lower risk (better protected tenant).

        :param tenant_id: Target tenant ID (must be in authorized portfolio).
        :returns: :class:`RiskScoreResponse` with ``composite_score``, ``risk_label``, and ``factors``.
        """
        data = self._http.get(f"/carrier/risk-score/{quote(tenant_id, safe='')}")
        return RiskScoreResponse.from_dict(data)

    # ─── Independent Evidence Verification ───────────────────────────────────

    def get_active_policy(self, tenant_id: str) -> ActivePolicyResponse:
        """Get the active policy for an authorized tenant."""
        data = self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/active-policy")
        return ActivePolicyResponse.from_dict(data)

    def get_policy_history(
        self,
        tenant_id: str,
        next_token: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> PolicyHistoryResponse:
        """Policy change history for an authorized tenant."""
        params: Dict[str, Any] = {}
        if next_token:
            params["nextToken"] = next_token
        if limit is not None:
            params["limit"] = limit
        data = self._http.get(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/policy-history",
            params=params or None,
        )
        return PolicyHistoryResponse.from_dict(data)

    def get_policy_at(self, tenant_id: str, timestamp: str) -> ActivePolicyResponse:
        """Get the policy that was active at a specific point in time."""
        data = self._http.get(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/policy-at",
            params={"timestamp": timestamp},
        )
        return ActivePolicyResponse.from_dict(data)

    def get_kms_inventory(self, tenant_id: str) -> KmsInventoryResponse:
        """KMS and IAM enforcement inventory for an authorized tenant."""
        data = self._http.get(f"/carrier/tenants/{quote(tenant_id, safe='')}/kms-inventory")
        return KmsInventoryResponse.from_dict(data)

    def set_baseline_policy(self, baseline: BaselineSpec) -> BaselinePolicyResponse:
        """Set the carrier's minimum policy baseline."""
        data = self._http.post("/carrier/baseline-policy", json=baseline.to_dict())
        return BaselinePolicyResponse.from_dict(data)

    def get_baseline_policy(self) -> BaselinePolicyResponse:
        """Get the carrier's current baseline policy specification."""
        data = self._http.get("/carrier/baseline-policy")
        return BaselinePolicyResponse.from_dict(data)

    def simulate_transaction(
        self,
        tenant_id: str,
        tx_intent: Optional[Dict[str, Any]] = None,
        signing_context: Optional[Dict[str, Any]] = None,
    ) -> SimulationResponse:
        """Simulate a transaction against a tenant's active policy."""
        payload: Dict[str, Any] = {}
        if tx_intent:
            payload["txIntent"] = tx_intent
        if signing_context:
            payload["signingContext"] = signing_context
        data = self._http.post(
            f"/carrier/tenants/{quote(tenant_id, safe='')}/simulate-transaction",
            json=payload,
        )
        return SimulationResponse.from_dict(data)

    def register_policy_change_webhook(
        self,
        webhook_url: str,
        events: Optional[List[str]] = None,
    ) -> WebhookRegistrationResponse:
        """Register a webhook to receive POLICY_CHANGED notifications."""
        payload: Dict[str, Any] = {"webhookUrl": webhook_url}
        if events:
            payload["events"] = events
        data = self._http.post("/carrier/webhooks/policy-changes", json=payload)
        return WebhookRegistrationResponse.from_dict(data)

    def list_policy_webhooks(self) -> WebhookListResponse:
        """List all policy-change webhook subscriptions."""
        data = self._http.get("/carrier/webhooks/policy-changes")
        return WebhookListResponse.from_dict(data)

    # ─── Convenience helpers ───────────────────────────────────────────────────

    def list_all_trials(
        self,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Iterator[TrialSummary]:
        """
        Auto-paginating generator for trials.

        Yields each :class:`TrialSummary` individually, automatically fetching
        the next page when the current page is exhausted.

        Example::

            for trial in client.list_all_trials("OBSERVING"):
                print(trial.trial_id, trial.decisions_observed)
        """
        next_token: Optional[str] = None
        while True:
            page = self.list_trials(status=status, next_token=next_token, limit=limit)
            yield from page.trials
            next_token = page.next_token
            if not next_token:
                break

    def poll_claim_pack(
        self,
        job_id: str,
        poll_interval_s: float = 3.0,
        timeout_s: float = 600.0,
    ) -> ClaimPackStatusResponse:
        """
        Poll a claim pack generation job until it reaches a terminal state.

        Returns the final :class:`ClaimPackStatusResponse` when status is ``COMPLETE``.
        Raises :class:`CarrierError` if the job fails or the timeout is exceeded.

        :param job_id: Job ID from :meth:`generate_claim_pack`.
        :param poll_interval_s: Seconds between polls. Default: 3.
        :param timeout_s: Maximum wait time in seconds. Default: 600 (10 min).
        """
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            result = self.get_claim_pack_status(job_id)
            if result.status == "COMPLETE":
                return result
            if result.status == "FAILED":
                raise CarrierError(
                    result.error or f"Claim pack job {job_id} failed",
                    status_code=0,
                    code="CLAIM_PACK_FAILED",
                )
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(poll_interval_s, remaining))
        raise CarrierError(
            f"Claim pack job {job_id} timed out after {timeout_s}s",
            status_code=0,
            code="CLAIM_PACK_TIMEOUT",
        )
