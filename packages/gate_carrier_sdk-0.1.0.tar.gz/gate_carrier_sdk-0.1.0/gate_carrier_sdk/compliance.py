"""
Client-side policy compliance verification.

Pure function — no API call. Compares a tenant's active policy against
the carrier's baseline specification to produce a compliance diff.
"""

from __future__ import annotations

from typing import List, Optional

from .types import (
    ActivePolicyResponse,
    BaselineRuleResult,
    BaselineSpec,
    PolicyComplianceDiff,
)

ENFORCEMENT_LADDER: List[str] = [
    "SHADOW",
    "SOFT_ENFORCE",
    "HARD_ENFORCE",
    "PROVENANCE",
    "HARD_KMS_GATEWAY",
    "HARD_KMS_ATTESTED_ENCLAVE",
    "HARD_GCP_CONFIDENTIAL_VM",
]


def _stage_index(stage: str) -> int:
    # HARD_KMS_ATTESTED is a deprecated alias for HARD_KMS_GATEWAY
    normalized = "HARD_KMS_GATEWAY" if stage == "HARD_KMS_ATTESTED" else stage
    try:
        return ENFORCEMENT_LADDER.index(normalized)
    except ValueError:
        return -1


def verify_policy_compliance(
    active_policy: ActivePolicyResponse,
    baseline: BaselineSpec,
) -> PolicyComplianceDiff:
    """
    Compare a tenant's active policy against a carrier's baseline specification.

    Pure function — no API calls, no side effects. Carriers can customise
    their baseline and run this check locally.

    :param active_policy: The tenant's current active policy (from ``get_active_policy``).
    :param baseline: The carrier's minimum policy baseline.
    :returns: A diff showing which rules are satisfied, missing, or weaker than required.
    """
    missing_rules: List[BaselineRuleResult] = []
    weaker_rules: List[BaselineRuleResult] = []
    satisfied_rules: List[BaselineRuleResult] = []

    # Check enforcement level
    enforcement_compliant = True
    if baseline.minimum_enforcement_level:
        current_idx = _stage_index(active_policy.enforcement_level)
        required_idx = _stage_index(baseline.minimum_enforcement_level)
        if required_idx >= 0 and (current_idx < 0 or current_idx < required_idx):
            enforcement_compliant = False

    # Check each required rule against active policy rules
    for required in baseline.required_rules:
        matches = [
            rule for rule in active_policy.policy_rules
            if rule.trigger_type == required.trigger_type and rule.is_enabled
        ]
        match = matches[0] if matches else None

        if match is None:
            missing_rules.append(BaselineRuleResult(
                rule_id=required.rule_id,
                description=required.description,
                trigger_type=required.trigger_type,
                status="MISSING",
                detail=f"No enabled rule with triggerType '{required.trigger_type}' found in active policy",
            ))
            continue

        # Check if the matched rule's action is one of the required actions
        action_satisfied = (
            len(required.required_actions) == 0
            or any(m.defense_action in required.required_actions for m in matches)
        )

        if not action_satisfied:
            weaker_rules.append(BaselineRuleResult(
                rule_id=required.rule_id,
                description=required.description,
                trigger_type=required.trigger_type,
                status="WEAKER",
                detail=f"Rule action '{match.defense_action}' does not satisfy required actions {required.required_actions}",
            ))
            continue

        satisfied_rules.append(BaselineRuleResult(
            rule_id=required.rule_id,
            description=required.description,
            trigger_type=required.trigger_type,
            status="SATISFIED",
        ))

    is_compliant = (
        enforcement_compliant
        and len(missing_rules) == 0
        and len(weaker_rules) == 0
    )

    return PolicyComplianceDiff(
        is_compliant=is_compliant,
        missing_rules=missing_rules,
        weaker_rules=weaker_rules,
        satisfied_rules=satisfied_rules,
        enforcement_level=active_policy.enforcement_level,
        minimum_enforcement_level=baseline.minimum_enforcement_level,
        enforcement_compliant=enforcement_compliant,
    )
