"""
gate-carrier-sdk — Python SDK for the BlockIntel Gate Carrier API.

Quick start::

    from gate_carrier_sdk import CarrierClient

    with CarrierClient(
        api_key="carrier_abc123...",
        base_url="https://api.gate.blockintelai.net/api/v1/gate",
        carrier_id="carrier_xyz",
    ) as client:
        score = client.get_risk_score("tenant_xyz")
        print(score.composite_score, score.risk_label)
"""

from .client import CarrierClient
from .async_client import AsyncCarrierClient
from .webhooks import verify_webhook_signature
from .compliance import verify_policy_compliance
from .errors import (
    CarrierAuthError,
    CarrierConflictError,
    CarrierError,
    CarrierNotFoundError,
    CarrierQuotaExceededError,
    CarrierServerError,
)
from .types import (
    AcknowledgeAlertResponse,
    ActivePolicyResponse,
    AggregateMetrics,
    AlertSummary,
    BaselinePolicyResponse,
    BaselineRule,
    BaselineRuleResult,
    BaselineSpec,
    BBRMetrics,
    BBRReportResponse,
    BBRTenantSummary,
    ClaimPackStatusResponse,
    ConvertTrialResponse,
    CreateBBRTestResponse,
    CreateTrialResponse,
    Decisions30d,
    EvidenceBundleResponse,
    GenerateClaimPackResponse,
    GetAlertsResponse,
    HealthTenantSummary,
    IamVerification,
    KmsInventoryResponse,
    ListTrialsResponse,
    MatchedRule,
    MaxLossEstimateResponse,
    PolicyComplianceDiff,
    PolicyHistoryResponse,
    PolicyRule,
    PolicyVersion,
    PortfolioHealthResponse,
    PortfolioResponse,
    PortfolioSummaryResponse,
    PortfolioTenant,
    QuotaStatus,
    RiskScoreFactor,
    RiskScoreFactors,
    RiskScoreResponse,
    SimulationResponse,
    TenantMaxLoss,
    TrialObservation,
    TrialStatusResponse,
    TrialSummary,
    UnderwritingReportResponse,
    WebhookListItem,
    WebhookListResponse,
    WebhookRegistrationResponse,
)

__version__ = "0.1.0"
__all__ = [
    "CarrierClient",
    "AsyncCarrierClient",
    "verify_webhook_signature",
    "verify_policy_compliance",
    # Errors
    "CarrierError",
    "CarrierAuthError",
    "CarrierConflictError",
    "CarrierNotFoundError",
    "CarrierQuotaExceededError",
    "CarrierServerError",
    # Types
    "CreateTrialResponse",
    "TrialSummary",
    "ListTrialsResponse",
    "TrialStatusResponse",
    "TrialObservation",
    "ConvertTrialResponse",
    "PortfolioResponse",
    "PortfolioTenant",
    "AggregateMetrics",
    "PortfolioHealthResponse",
    "HealthTenantSummary",
    "QuotaStatus",
    "CreateBBRTestResponse",
    "BBRReportResponse",
    "BBRMetrics",
    "BBRTenantSummary",
    "TenantMaxLoss",
    "PortfolioSummaryResponse",
    "MaxLossEstimateResponse",
    "AlertSummary",
    "GetAlertsResponse",
    "AcknowledgeAlertResponse",
    "GenerateClaimPackResponse",
    "ClaimPackStatusResponse",
    "EvidenceBundleResponse",
    "UnderwritingReportResponse",
    "Decisions30d",
    "RiskScoreFactor",
    "RiskScoreFactors",
    "RiskScoreResponse",
    # Independent Evidence Verification
    "ActivePolicyResponse",
    "PolicyRule",
    "PolicyVersion",
    "PolicyHistoryResponse",
    "IamVerification",
    "KmsInventoryResponse",
    "BaselineRule",
    "BaselineSpec",
    "BaselinePolicyResponse",
    "BaselineRuleResult",
    "PolicyComplianceDiff",
    "MatchedRule",
    "SimulationResponse",
    "WebhookRegistrationResponse",
    "WebhookListItem",
    "WebhookListResponse",
]
