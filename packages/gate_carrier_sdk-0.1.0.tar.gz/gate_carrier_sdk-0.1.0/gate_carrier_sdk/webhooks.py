"""
Webhook signature verification utility.

Verifies HMAC-SHA256 signatures on incoming Gate carrier webhook payloads.

Usage::

    from gate_carrier_sdk import verify_webhook_signature

    @app.route("/webhooks/gate", methods=["POST"])
    def handle_webhook():
        signature = request.headers.get("X-Gate-Webhook-Signature", "")
        if not verify_webhook_signature(request.data, signature, WEBHOOK_SECRET):
            return "Invalid signature", 401
        # Process event...
"""

from __future__ import annotations

import hashlib
import hmac


def verify_webhook_signature(
    payload: bytes | str,
    signature: str,
    secret: str,
) -> bool:
    """
    Verify an HMAC-SHA256 webhook signature.

    :param payload: Raw request body (bytes or str). Must be the raw body
        before any JSON parsing to ensure byte-exact match.
    :param signature: Value of the ``X-Gate-Webhook-Signature`` header.
        Expected format: ``sha256=<hex>``.
    :param secret: Webhook secret (returned once at subscription creation).
    :returns: ``True`` if the signature is valid, ``False`` otherwise.
    """
    if not payload or not signature or not secret:
        return False

    if isinstance(payload, str):
        payload = payload.encode("utf-8")

    expected = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    ).hexdigest()

    expected_sig = f"sha256={expected}"

    # Timing-safe comparison to prevent timing oracle attacks.
    return hmac.compare_digest(expected_sig, signature)
