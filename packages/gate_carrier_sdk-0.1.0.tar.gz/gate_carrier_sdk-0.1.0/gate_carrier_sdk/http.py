"""
HttpClient — httpx wrapper with retry and timeout for the Carrier SDK.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict, Optional

import httpx

from .errors import (
    CarrierAuthError,
    CarrierConflictError,
    CarrierError,
    CarrierNotFoundError,
    CarrierQuotaExceededError,
    CarrierServerError,
)

_RETRYABLE_STATUS_CODES = frozenset({500, 502, 503, 504})
_SDK_VERSION = "0.1.0"


class HttpClient:
    """
    Zero-configuration httpx client for the Gate Carrier API.

    - Static X-Carrier-Api-Key header on every request
    - Configurable timeout and retry with exponential backoff
    - Maps HTTP error codes to typed SDK exceptions
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout_s: float = 30.0,
        max_retries: int = 3,
        retry_delay_s: float = 0.5,
        user_agent_suffix: Optional[str] = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout_s = timeout_s
        self._max_retries = max_retries
        self._retry_delay_s = retry_delay_s
        ua = f"gate-carrier-sdk/{_SDK_VERSION}"
        if user_agent_suffix:
            ua = f"{ua} {user_agent_suffix}"
        self._client = httpx.Client(
            headers={
                "X-Carrier-Api-Key": api_key,
                "User-Agent": ua,
            },
            timeout=timeout_s,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        url = f"{self._base_url}{path}"

        attempt = 0
        while True:
            attempt += 1
            try:
                request_id = str(uuid.uuid4())
                response = self._client.request(
                    method, url, json=json, params=params,
                    headers={"X-Request-Id": request_id},
                )
            except httpx.TransportError as exc:
                # Only retry idempotent methods (GET) to avoid double-execution
                # of side-effecting operations (e.g. BBR quota decrement).
                if method == "GET" and attempt <= self._max_retries:
                    time.sleep(self._retry_delay_s * (2 ** (attempt - 1)))
                    continue
                raise CarrierError(str(exc), status_code=0, code="NETWORK_ERROR") from exc

            # Retry on transient server errors (not 429 — surface that directly).
            # Only retry idempotent methods (GET) to avoid double-execution of side effects.
            if method == "GET" and response.status_code in _RETRYABLE_STATUS_CODES and attempt <= self._max_retries:
                retry_after = response.headers.get("Retry-After")
                # Retry-After may be an integer seconds string or an HTTP-date string.
                # Fall back to exponential backoff if it is not a plain number.
                delay = self._retry_delay_s * (2 ** (attempt - 1))
                if retry_after:
                    try:
                        delay = float(retry_after)
                    except ValueError:
                        pass  # HTTP-date format — use exponential backoff
                time.sleep(delay)
                continue

            try:
                payload: Dict[str, Any] = response.json()
            except Exception:
                raise CarrierServerError(
                    f"Failed to parse response (HTTP {response.status_code})",
                    status_code=response.status_code,
                )

            if not response.is_success or not payload.get("success"):
                error = payload.get("error") or {}
                msg = error.get("message") or f"HTTP {response.status_code}"

                if response.status_code == 401:
                    raise CarrierAuthError(msg)
                if response.status_code == 404:
                    raise CarrierNotFoundError(msg)
                if response.status_code == 409:
                    raise CarrierConflictError(msg, code=error.get("code", "CONFLICT"))
                if response.status_code == 429:
                    raise CarrierQuotaExceededError(msg, reset_at=error.get("resetAt"))
                if response.status_code >= 500:
                    raise CarrierServerError(msg, status_code=response.status_code)
                raise CarrierError(msg, status_code=response.status_code, code=error.get("code", "UNKNOWN"))

            data = payload.get("data")
            if data is None:
                raise CarrierError(
                    "Response missing data field",
                    status_code=response.status_code,
                    code="MISSING_RESPONSE_DATA",
                )
            return data

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("GET", path, params=params)

    def post(self, path: str, json: Optional[Any] = None) -> Any:
        return self._request("POST", path, json=json)
