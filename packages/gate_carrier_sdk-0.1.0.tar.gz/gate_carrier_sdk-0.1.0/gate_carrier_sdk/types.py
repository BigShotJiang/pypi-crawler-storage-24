"""
Dataclass response types for the BlockIntel Gate Carrier SDK.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional


# ─── Shared ────────────────────────────────────────────────────────────────────

TrialStatus = Literal["OBSERVING", "COMPLETED", "CONVERTED", "EXPIRED"]
AlertSeverity = Literal["CRITICAL", "HIGH", "MEDIUM", "LOW"]
RiskLabel = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]


# ─── Trial endpoints ───────────────────────────────────────────────────────────

@dataclass
class CreateTrialResponse:
    trial_id: str
    tenant_id: str
    prospect_name: str
    contact_email: str
    status: str
    duration_days: int
    started_at: str
    expires_at: str
    adoption_stage: str
    message: str
    prospect_api_key: Optional[str] = None
    """API key for the trial tenant to authenticate Gate SDK calls.
    Shown once — store securely and share with the prospect.
    None on idempotent re-create if key cannot be recovered."""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "CreateTrialResponse":
        return cls(
            trial_id=d["trialId"],
            tenant_id=d["tenantId"],
            prospect_name=d["prospectName"],
            contact_email=d["contactEmail"],
            status=d["status"],
            duration_days=d["durationDays"],
            started_at=d["startedAt"],
            expires_at=d["expiresAt"],
            adoption_stage=d["adoptionStage"],
            message=d["message"],
            prospect_api_key=d.get("prospectApiKey"),
        )


@dataclass
class TrialSummary:
    trial_id: str
    tenant_id: str
    prospect_name: str
    contact_email: str
    status: str
    duration_days: int
    started_at: str
    expires_at: str
    decisions_observed: int
    would_block_count: int
    policy_id: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TrialSummary":
        return cls(
            trial_id=d["trialId"],
            tenant_id=d["tenantId"],
            prospect_name=d["prospectName"],
            contact_email=d["contactEmail"],
            status=d["status"],
            duration_days=d["durationDays"],
            started_at=d["startedAt"],
            expires_at=d["expiresAt"],
            decisions_observed=d["decisionsObserved"],
            would_block_count=d["wouldBlockCount"],
            policy_id=d.get("policyId"),
        )


@dataclass
class ListTrialsResponse:
    trials: List[TrialSummary]
    count: int
    has_more: bool
    next_token: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ListTrialsResponse":
        return cls(
            trials=[TrialSummary.from_dict(t) for t in d.get("trials", [])],
            count=d["count"],
            has_more=d.get("hasMore", False),
            next_token=d.get("nextToken"),
        )


@dataclass
class TrialObservation:
    decisions_observed: int
    would_block_count: int
    would_block_rate: float
    truncated: bool = False
    """True when the decision count was capped at 10K. The real count may be higher."""


@dataclass
class TrialStatusResponse:
    trial_id: str
    tenant_id: str
    prospect_name: str
    contact_email: str
    status: str
    duration_days: int
    days_elapsed: int
    days_remaining: int
    progress_percent: int
    started_at: str
    expires_at: str
    observation: TrialObservation
    policy_id: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TrialStatusResponse":
        obs = d.get("observation") or {}
        return cls(
            trial_id=d["trialId"],
            tenant_id=d["tenantId"],
            prospect_name=d["prospectName"],
            contact_email=d["contactEmail"],
            status=d["status"],
            duration_days=d["durationDays"],
            days_elapsed=d["daysElapsed"],
            days_remaining=d["daysRemaining"],
            progress_percent=d["progressPercent"],
            started_at=d["startedAt"],
            expires_at=d["expiresAt"],
            observation=TrialObservation(
                decisions_observed=obs.get("decisionsObserved", 0),
                would_block_count=obs.get("wouldBlockCount", 0),
                would_block_rate=obs.get("wouldBlockRate", 0.0),
                truncated=obs.get("truncated", False),
            ),
            policy_id=d.get("policyId"),
        )


@dataclass
class ConvertTrialResponse:
    trial_id: str
    tenant_id: str
    prospect_name: str
    status: str
    policy_id: str
    converted_at: str
    message: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConvertTrialResponse":
        return cls(
            trial_id=d["trialId"],
            tenant_id=d["tenantId"],
            prospect_name=d["prospectName"],
            status=d["status"],
            policy_id=d["policyId"],
            converted_at=d["convertedAt"],
            message=d["message"],
        )


# ─── Portfolio ─────────────────────────────────────────────────────────────────

@dataclass
class PortfolioTenant:
    tenant_id: str
    tenant_name: str
    adoption_stage: str
    last_pack_generated_at: Optional[str]
    attestation_coverage: float
    iam_hardened: Optional[bool]
    break_glass_active: bool
    overall_risk: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PortfolioTenant":
        return cls(
            tenant_id=d["tenantId"],
            tenant_name=d["tenantName"],
            adoption_stage=d["adoptionStage"],
            last_pack_generated_at=d.get("lastPackGeneratedAt"),
            attestation_coverage=d.get("attestationCoverage", 0),
            iam_hardened=d.get("iamHardened"),
            break_glass_active=d.get("breakGlassActive", False),
            overall_risk=d.get("overallRisk", "UNKNOWN"),
        )


@dataclass
class AggregateMetrics:
    total_tenants: int
    avg_attestation_coverage: float
    tenants_at_hard_kms: int
    tenants_with_drift: int


@dataclass
class PortfolioResponse:
    carrier_id: str
    carrier_name: str
    generated_at: str
    aggregate_metrics: AggregateMetrics
    total: int
    page: int
    page_size: int
    tenants: List[PortfolioTenant]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PortfolioResponse":
        carrier = d.get("carrier", {})
        portfolio = d.get("portfolio", {})
        agg = portfolio.get("aggregateMetrics", {})
        return cls(
            carrier_id=carrier.get("carrierId", ""),
            carrier_name=carrier.get("carrierName", ""),
            generated_at=portfolio.get("generatedAt", ""),
            aggregate_metrics=AggregateMetrics(
                total_tenants=agg.get("totalTenants", 0),
                avg_attestation_coverage=agg.get("avgAttestationCoverage", 0),
                tenants_at_hard_kms=agg.get("tenantsAtHardKms", 0),
                tenants_with_drift=agg.get("tenantsWithDrift", 0),
            ),
            total=portfolio.get("total", 0),
            page=portfolio.get("page", 1),
            page_size=portfolio.get("pageSize", 20),
            tenants=[PortfolioTenant.from_dict(t) for t in portfolio.get("tenants", [])],
        )


@dataclass
class QuotaStatus:
    used: int
    total: int
    remaining: int
    reset_at: str


@dataclass
class HealthTenantSummary:
    tenant_id: str
    latest_test_at: Optional[str]
    latest_test_status: Optional[str]
    blast_radius_summary: Optional[Dict[str, float]]
    test_count: int

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "HealthTenantSummary":
        return cls(
            tenant_id=d["tenantId"],
            latest_test_at=d.get("latestTestAt"),
            latest_test_status=d.get("latestTestStatus"),
            blast_radius_summary=d.get("blastRadiusSummary"),
            test_count=d.get("testCount", 0),
        )


@dataclass
class PortfolioHealthResponse:
    carrier_id: str
    carrier_name: str
    tenant_count: int
    tenants: List[HealthTenantSummary]
    portfolio_max_loss: Optional[Dict[str, Any]]
    quota_status: QuotaStatus

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PortfolioHealthResponse":
        carrier = d.get("carrier", {})
        portfolio = d.get("portfolio", {})
        quota = portfolio.get("quotaStatus", {})
        return cls(
            carrier_id=carrier.get("carrierId", ""),
            carrier_name=carrier.get("carrierName", ""),
            tenant_count=portfolio.get("tenantCount", 0),
            tenants=[HealthTenantSummary.from_dict(t) for t in portfolio.get("tenants", [])],
            portfolio_max_loss=portfolio.get("portfolioMaxLoss"),
            quota_status=QuotaStatus(
                used=quota.get("used", 0),
                total=quota.get("total", 0),
                remaining=quota.get("remaining", 0),
                reset_at=quota.get("resetAt", ""),
            ),
        )


# ─── BBR ───────────────────────────────────────────────────────────────────────

@dataclass
class CreateBBRTestResponse:
    test_id: str
    tenant_id: str
    status: str
    quota_remaining: int

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "CreateBBRTestResponse":
        return cls(
            test_id=d["testId"],
            tenant_id=d["tenantId"],
            status=d["status"],
            quota_remaining=d["quotaRemaining"],
        )


@dataclass
class BBRMetrics:
    """Blast radius metrics returned by BBR endpoints."""
    max_loss_24h_usd: float
    max_loss_10m_usd: float
    would_block_count: int
    would_step_up_count: int
    would_delay_count: int
    receipt_coverage_pct: float
    provenance_coverage_pct: float
    time_to_detection_sec: Optional[float]
    extra: Dict[str, Any]
    """Additional metrics not covered by typed fields."""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BBRMetrics":
        known_keys = {
            "maxLoss24hUsd", "maxLoss10mUsd", "wouldBlockCount",
            "wouldStepUpCount", "wouldDelayCount", "receiptCoveragePct",
            "provenanceCoveragePct", "timeToDetectionSec",
        }
        return cls(
            max_loss_24h_usd=d.get("maxLoss24hUsd", 0),
            max_loss_10m_usd=d.get("maxLoss10mUsd", 0),
            would_block_count=d.get("wouldBlockCount", 0),
            would_step_up_count=d.get("wouldStepUpCount", 0),
            would_delay_count=d.get("wouldDelayCount", 0),
            receipt_coverage_pct=d.get("receiptCoveragePct", 0),
            provenance_coverage_pct=d.get("provenanceCoveragePct", 0),
            time_to_detection_sec=d.get("timeToDetectionSec"),
            extra={k: v for k, v in d.items() if k not in known_keys},
        )


@dataclass
class BBRReportResponse:
    test_id: str
    tenant_id: str
    status: str
    start_at: str
    end_at: str
    metrics: Optional[BBRMetrics]
    file_count: int

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BBRReportResponse":
        raw_metrics = d.get("metrics")
        return cls(
            test_id=d["testId"],
            tenant_id=d["tenantId"],
            status=d["status"],
            start_at=d["startAt"],
            end_at=d["endAt"],
            metrics=BBRMetrics.from_dict(raw_metrics) if raw_metrics else None,
            file_count=d.get("fileCount", 0),
        )


@dataclass
class BBRTenantSummary:
    """Per-tenant BBR summary in portfolio responses."""
    tenant_id: str
    latest_test_at: Optional[str]
    latest_test_status: Optional[str]
    metrics: Optional[BBRMetrics]
    test_count: int

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BBRTenantSummary":
        raw_metrics = d.get("metrics")
        return cls(
            tenant_id=d["tenantId"],
            latest_test_at=d.get("latestTestAt"),
            latest_test_status=d.get("latestTestStatus"),
            metrics=BBRMetrics.from_dict(raw_metrics) if raw_metrics else None,
            test_count=d.get("testCount", 0),
        )


@dataclass
class TenantMaxLoss:
    """Per-tenant max loss breakdown."""
    tenant_id: str
    p99_loss_usd: float
    has_real_data: bool
    last_test_at: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TenantMaxLoss":
        return cls(
            tenant_id=d["tenantId"],
            p99_loss_usd=d.get("p99LossUSD", 0),
            has_real_data=d.get("hasRealData", False),
            last_test_at=d.get("lastTestAt"),
        )


@dataclass
class PortfolioSummaryResponse:
    tenants: List[BBRTenantSummary]
    top_risk_tenants: List[BBRTenantSummary]
    portfolio_max_loss: Optional["MaxLossEstimateResponse"]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PortfolioSummaryResponse":
        raw_max_loss = d.get("portfolioMaxLoss")
        return cls(
            tenants=[BBRTenantSummary.from_dict(t) for t in d.get("tenants", [])],
            top_risk_tenants=[BBRTenantSummary.from_dict(t) for t in d.get("topRiskTenants", [])],
            portfolio_max_loss=MaxLossEstimateResponse.from_dict(raw_max_loss) if raw_max_loss else None,
        )


@dataclass
class MaxLossEstimateResponse:
    p50_max_loss_usd: float
    p90_max_loss_usd: float
    p99_max_loss_usd: float
    total_uncorrelated_loss_usd: float
    correlation_factor: float
    top_concentration: Optional[Dict[str, Any]]
    per_tenant_breakdown: List[TenantMaxLoss]
    tenants_with_data: int
    tenants_without_data: int
    computed_at: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MaxLossEstimateResponse":
        return cls(
            p50_max_loss_usd=d.get("p50MaxLossUSD", 0),
            p90_max_loss_usd=d.get("p90MaxLossUSD", 0),
            p99_max_loss_usd=d.get("p99MaxLossUSD", 0),
            total_uncorrelated_loss_usd=d.get("totalUncorrelatedLossUSD", 0),
            correlation_factor=d.get("correlationFactor", 0),
            top_concentration=d.get("topConcentration"),
            per_tenant_breakdown=[TenantMaxLoss.from_dict(t) for t in d.get("perTenantBreakdown", [])],
            tenants_with_data=d.get("tenantsWithData", 0),
            tenants_without_data=d.get("tenantsWithoutData", 0),
            computed_at=d.get("computedAt", ""),
        )


# ─── Alerts ────────────────────────────────────────────────────────────────────

@dataclass
class AlertSummary:
    """Alert item from the carrier alerts endpoint."""
    alert_id: str
    tenant_id: str
    alert_type: str
    severity: str
    message: str
    created_at: str
    acknowledged_at: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AlertSummary":
        return cls(
            alert_id=d["alertId"],
            tenant_id=d["tenantId"],
            alert_type=d["alertType"],
            severity=d["severity"],
            message=d["message"],
            created_at=d["createdAt"],
            acknowledged_at=d.get("acknowledgedAt"),
        )


@dataclass
class GetAlertsResponse:
    """Response from GET /carrier/alerts.

    The backend returns the raw DynamoDB items as an array.
    """
    alerts: List[AlertSummary]

    @classmethod
    def from_dict(cls, d: Any) -> "GetAlertsResponse":
        # Backend returns raw CarrierAlert[] array as data
        items = d if isinstance(d, list) else d.get("alerts", [])
        return cls(
            alerts=[AlertSummary.from_dict(a) for a in items],
        )


@dataclass
class AcknowledgeAlertResponse:
    acknowledged: bool

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AcknowledgeAlertResponse":
        return cls(acknowledged=d["acknowledged"])


# ─── Evidence ──────────────────────────────────────────────────────────────────

@dataclass
class GenerateClaimPackResponse:
    job_id: str
    status: str
    poll_url: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GenerateClaimPackResponse":
        return cls(
            job_id=d["jobId"],
            status=d["status"],
            poll_url=d["pollUrl"],
        )


@dataclass
class ClaimPackStatusResponse:
    job_id: str
    status: str
    tenant_id: str
    created_at: str
    completed_at: Optional[str] = None
    download_url: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ClaimPackStatusResponse":
        return cls(
            job_id=d["jobId"],
            status=d["status"],
            tenant_id=d["tenantId"],
            created_at=d["createdAt"],
            completed_at=d.get("completedAt"),
            download_url=d.get("downloadUrl"),
            error=d.get("error"),
        )


@dataclass
class EvidenceBundleResponse:
    tenant_id: str
    generated_at: str
    decisions: List[Dict[str, Any]]
    snapshots: List[Dict[str, Any]]
    merkle_root: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EvidenceBundleResponse":
        return cls(
            tenant_id=d.get("tenantId", ""),
            generated_at=d.get("generatedAt", ""),
            decisions=d.get("decisions", []),
            snapshots=d.get("snapshots", []),
            merkle_root=d.get("merkleRoot"),
        )


# ─── Underwriting ──────────────────────────────────────────────────────────────

@dataclass
class Decisions30d:
    total: int
    allow: int
    block: int
    would_block: int
    step_up: int
    with_receipt_signature: int
    decisions_after_receipt_fix: int
    """Decisions evaluated after the receipt-signing fix (2026-03-02).
    Use as the denominator for attestation coverage to avoid counting
    pre-fix decisions that were never signed."""
    violation_rate: float
    attestation_coverage: float


@dataclass
class UnderwritingReportResponse:
    tenant_id: str
    tenant_name: str
    report_generated_at: str
    adoption_stage: str
    is_enabled: bool
    iam_enforced: bool
    decisions_30d: Decisions30d
    active_signers: int
    snapshot_version: Optional[str]
    policy_hash: Optional[str]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "UnderwritingReportResponse":
        dec = d.get("decisions30d", {})
        return cls(
            tenant_id=d["tenantId"],
            tenant_name=d["tenantName"],
            report_generated_at=d["reportGeneratedAt"],
            adoption_stage=d["adoptionStage"],
            is_enabled=d["isEnabled"],
            iam_enforced=d["iamEnforced"],
            decisions_30d=Decisions30d(
                total=dec.get("total", 0),
                allow=dec.get("allow", 0),
                block=dec.get("block", 0),
                would_block=dec.get("wouldBlock", 0),
                step_up=dec.get("stepUp", 0),
                with_receipt_signature=dec.get("withReceiptSignature", 0),
                decisions_after_receipt_fix=dec.get("decisionsAfterReceiptFix", 0),
                violation_rate=dec.get("violationRate", 0.0),
                attestation_coverage=dec.get("attestationCoverage", 0.0),
            ),
            active_signers=d.get("signers", {}).get("activeCount", 0),
            snapshot_version=d.get("snapshot", {}).get("version"),
            policy_hash=d.get("snapshot", {}).get("policyHash"),
        )


@dataclass
class RiskScoreFactor:
    weight: float
    raw_score: int
    contribution: int
    description: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RiskScoreFactor":
        return cls(
            weight=d["weight"],
            raw_score=d["rawScore"],
            contribution=d["contribution"],
            description=d["description"],
        )


@dataclass
class RiskScoreFactors:
    adoption_stage: RiskScoreFactor
    attestation_coverage: RiskScoreFactor
    would_block_rate: RiskScoreFactor
    blast_radius: RiskScoreFactor
    signer_diversity: RiskScoreFactor


@dataclass
class RiskScoreResponse:
    tenant_id: str
    tenant_name: str
    adoption_stage: str
    composite_score: int
    risk_label: str
    scored_at: str
    factors: RiskScoreFactors

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RiskScoreResponse":
        factors_raw = d.get("factors", {})
        _default_factor = {"weight": 0, "rawScore": 0, "contribution": 0, "description": "N/A"}
        return cls(
            tenant_id=d["tenantId"],
            tenant_name=d["tenantName"],
            adoption_stage=d["adoptionStage"],
            composite_score=d["compositeScore"],
            risk_label=d["riskLabel"],
            scored_at=d["scoredAt"],
            factors=RiskScoreFactors(
                adoption_stage=RiskScoreFactor.from_dict(factors_raw.get("adoptionStage", _default_factor)),
                attestation_coverage=RiskScoreFactor.from_dict(factors_raw.get("attestationCoverage", _default_factor)),
                would_block_rate=RiskScoreFactor.from_dict(factors_raw.get("wouldBlockRate", _default_factor)),
                blast_radius=RiskScoreFactor.from_dict(factors_raw.get("blastRadius", _default_factor)),
                signer_diversity=RiskScoreFactor.from_dict(factors_raw.get("signerDiversity", _default_factor)),
            ),
        )


# ─── Independent Evidence Verification ──────────────────────────────────────


@dataclass
class PolicyRule:
    id: str
    name: str
    trigger_type: str
    conditions: Dict[str, Any]
    defense_action: str
    is_enabled: bool

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PolicyRule":
        return cls(
            id=d["id"],
            name=d["name"],
            trigger_type=d["triggerType"],
            conditions=d.get("conditions", {}),
            defense_action=d["defenseAction"],
            is_enabled=d.get("isEnabled", True),
        )


@dataclass
class ActivePolicyResponse:
    tenant_id: str
    snapshot_id: str
    snapshot_hash: str
    snapshot_signature: Optional[str]
    enforcement_level: str
    activated_at: str
    published_at: str
    policy_rules: List[PolicyRule]
    metadata: Dict[str, Any]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ActivePolicyResponse":
        return cls(
            tenant_id=d["tenantId"],
            snapshot_id=d["snapshotId"],
            snapshot_hash=d["snapshotHash"],
            snapshot_signature=d.get("snapshotSignature"),
            enforcement_level=d["enforcementLevel"],
            activated_at=d["activatedAt"],
            published_at=d["publishedAt"],
            policy_rules=[PolicyRule.from_dict(r) for r in d.get("policyRules", [])],
            metadata=d.get("metadata", {}),
        )


@dataclass
class PolicyVersion:
    snapshot_id: str
    snapshot_hash: str
    snapshot_signature: Optional[str]
    enforcement_level: str
    activated_at: str
    deactivated_at: Optional[str]
    published_by: Optional[str]
    change_type: str
    policy_rule_count: int

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PolicyVersion":
        return cls(
            snapshot_id=d["snapshotId"],
            snapshot_hash=d["snapshotHash"],
            snapshot_signature=d.get("snapshotSignature"),
            enforcement_level=d["enforcementLevel"],
            activated_at=d["activatedAt"],
            deactivated_at=d.get("deactivatedAt"),
            published_by=d.get("publishedBy"),
            change_type=d.get("changeType", "PUBLISH"),
            policy_rule_count=d.get("policyRuleCount", 0),
        )


@dataclass
class PolicyHistoryResponse:
    tenant_id: str
    versions: List[PolicyVersion]
    next_token: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PolicyHistoryResponse":
        return cls(
            tenant_id=d["tenantId"],
            versions=[PolicyVersion.from_dict(v) for v in d.get("versions", [])],
            next_token=d.get("nextToken"),
        )


@dataclass
class IamVerification:
    verified_at: str
    app_role_has_sign_permission: bool
    gate_role_has_sign_permission: bool
    drift_detected: bool

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "IamVerification":
        return cls(
            verified_at=d["verifiedAt"],
            app_role_has_sign_permission=d["appRoleHasSignPermission"],
            gate_role_has_sign_permission=d["gateRoleHasSignPermission"],
            drift_detected=d["driftDetected"],
        )


@dataclass
class KmsInventoryResponse:
    tenant_id: str
    adoption_stage: str
    kms_key_arn: Optional[str]
    app_iam_role_arn: Optional[str]
    hard_enforcement_ready: bool
    kms_gateway_configured: bool
    enclave_attestation_configured: bool
    gcp_confidential_vm_configured: bool
    last_iam_verification: Optional[IamVerification]
    inventory_generated_at: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "KmsInventoryResponse":
        iam_raw = d.get("lastIamVerification")
        return cls(
            tenant_id=d["tenantId"],
            adoption_stage=d["adoptionStage"],
            kms_key_arn=d.get("kmsKeyArn"),
            app_iam_role_arn=d.get("appIamRoleArn"),
            hard_enforcement_ready=d.get("hardEnforcementReady", False),
            kms_gateway_configured=d.get("kmsGatewayConfigured", False),
            enclave_attestation_configured=d.get("enclaveAttestationConfigured", False),
            gcp_confidential_vm_configured=d.get("gcpConfidentialVmConfigured", False),
            last_iam_verification=IamVerification.from_dict(iam_raw) if iam_raw else None,
            inventory_generated_at=d.get("inventoryGeneratedAt", ""),
        )


@dataclass
class BaselineRule:
    rule_id: str
    description: str
    trigger_type: str
    required_conditions: Dict[str, Any]
    required_actions: List[str]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BaselineRule":
        return cls(
            rule_id=d["ruleId"],
            description=d["description"],
            trigger_type=d["triggerType"],
            required_conditions=d.get("requiredConditions", {}),
            required_actions=d.get("requiredActions", []),
        )


@dataclass
class BaselineSpec:
    required_rules: List[BaselineRule]
    minimum_enforcement_level: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BaselineSpec":
        return cls(
            required_rules=[BaselineRule.from_dict(r) for r in d.get("requiredRules", [])],
            minimum_enforcement_level=d.get("minimumEnforcementLevel"),
        )

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "requiredRules": [
                {
                    "ruleId": r.rule_id,
                    "description": r.description,
                    "triggerType": r.trigger_type,
                    "requiredConditions": r.required_conditions,
                    "requiredActions": r.required_actions,
                }
                for r in self.required_rules
            ],
        }
        if self.minimum_enforcement_level:
            result["minimumEnforcementLevel"] = self.minimum_enforcement_level
        return result


@dataclass
class BaselinePolicyResponse:
    carrier_id: str
    baseline_hash: str
    baseline: BaselineSpec
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BaselinePolicyResponse":
        return cls(
            carrier_id=d["carrierId"],
            baseline_hash=d["baselineHash"],
            baseline=BaselineSpec.from_dict(d["baseline"]),
            created_at=d["createdAt"],
            updated_at=d["updatedAt"],
        )


@dataclass
class BaselineRuleResult:
    rule_id: str
    description: str
    trigger_type: str
    status: str  # 'SATISFIED' | 'MISSING' | 'WEAKER'
    detail: Optional[str] = None


@dataclass
class PolicyComplianceDiff:
    is_compliant: bool
    missing_rules: List[BaselineRuleResult]
    weaker_rules: List[BaselineRuleResult]
    satisfied_rules: List[BaselineRuleResult]
    enforcement_level: str
    minimum_enforcement_level: Optional[str]
    enforcement_compliant: bool


@dataclass
class MatchedRule:
    rule_id: str
    rule_name: str
    action: str
    trigger_type: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MatchedRule":
        return cls(
            rule_id=d["ruleId"],
            rule_name=d["ruleName"],
            action=d["action"],
            trigger_type=d["triggerType"],
        )


@dataclass
class SimulationResponse:
    decision: str
    reason_codes: List[str]
    simulated_at: str
    snapshot_hash: str
    enforcement_level: str
    is_simulation: bool
    matched_rules: List[MatchedRule]
    rules_covered: Optional[int] = None
    rules_skipped: Optional[int] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SimulationResponse":
        return cls(
            decision=d["decision"],
            reason_codes=d.get("reasonCodes", []),
            simulated_at=d["simulatedAt"],
            snapshot_hash=d["snapshotHash"],
            enforcement_level=d["enforcementLevel"],
            is_simulation=d.get("isSimulation", True),
            matched_rules=[MatchedRule.from_dict(r) for r in d.get("matchedRules", [])],
            rules_covered=d.get("rulesCovered"),
            rules_skipped=d.get("rulesSkipped"),
        )


@dataclass
class WebhookRegistrationResponse:
    subscription_id: str
    webhook_url: str
    events: List[str]
    webhook_secret: str
    created_at: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WebhookRegistrationResponse":
        return cls(
            subscription_id=d["subscriptionId"],
            webhook_url=d["webhookUrl"],
            events=d.get("events", []),
            webhook_secret=d["webhookSecret"],
            created_at=d["createdAt"],
        )


@dataclass
class WebhookListItem:
    subscription_id: str
    webhook_url: str
    events: List[str]
    status: str
    created_at: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WebhookListItem":
        return cls(
            subscription_id=d["subscriptionId"],
            webhook_url=d["webhookUrl"],
            events=d.get("events", []),
            status=d["status"],
            created_at=d["createdAt"],
        )


@dataclass
class WebhookListResponse:
    subscriptions: List[WebhookListItem]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WebhookListResponse":
        return cls(
            subscriptions=[WebhookListItem.from_dict(s) for s in d.get("subscriptions", [])],
        )
