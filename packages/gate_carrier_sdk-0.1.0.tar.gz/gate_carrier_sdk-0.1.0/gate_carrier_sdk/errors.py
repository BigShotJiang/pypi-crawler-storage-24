"""
Error hierarchy for the BlockIntel Gate Carrier SDK.

All errors extend CarrierError so callers can catch either the base class
or a specific subclass::

    try:
        result = client.get_risk_score("tenant_xyz")
    except CarrierAuthError:
        print("Invalid API key")
    except CarrierError as e:
        print(f"API error: {e} (HTTP {e.status_code})")
"""

from __future__ import annotations


class CarrierError(Exception):
    """Base class for all Carrier SDK errors."""

    def __init__(self, message: str, status_code: int = 0, code: str = "CARRIER_ERROR") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code

    def __repr__(self) -> str:
        return f"{type(self).__name__}(message={str(self)!r}, status_code={self.status_code}, code={self.code!r})"


class CarrierAuthError(CarrierError):
    """401 — Invalid or missing X-Carrier-Api-Key."""

    def __init__(self, message: str = "Invalid or missing carrier API key") -> None:
        super().__init__(message, status_code=401, code="CARRIER_AUTH_ERROR")


class CarrierNotFoundError(CarrierError):
    """404 — Requested resource not found."""

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message, status_code=404, code="CARRIER_NOT_FOUND")


class CarrierConflictError(CarrierError):
    """409 — Conflict (e.g. trial already converted, trial expired, concurrent state change)."""

    def __init__(self, message: str = "Resource conflict", code: str = "CONFLICT") -> None:
        super().__init__(message, status_code=409, code=code)


class CarrierQuotaExceededError(CarrierError):
    """429 — Monthly quota exhausted."""

    def __init__(self, message: str = "Monthly quota exhausted", reset_at: str | None = None) -> None:
        super().__init__(message, status_code=429, code="CARRIER_QUOTA_EXCEEDED")
        self.reset_at = reset_at


class CarrierServerError(CarrierError):
    """5xx — Server-side error."""

    def __init__(self, message: str = "Internal server error", status_code: int = 500) -> None:
        super().__init__(message, status_code=status_code, code="CARRIER_SERVER_ERROR")
