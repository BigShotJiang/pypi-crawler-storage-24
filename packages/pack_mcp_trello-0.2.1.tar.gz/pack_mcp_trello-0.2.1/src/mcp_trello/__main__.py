"""Permite execução via python -m mcp_trello."""

from mcp_trello.server import run

run()
