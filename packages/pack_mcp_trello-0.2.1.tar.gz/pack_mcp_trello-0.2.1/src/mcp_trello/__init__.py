"""MCP Server para integração com a API REST do Trello."""
