"""Inicialização e execução do servidor MCP para Trello."""

from __future__ import annotations

import asyncio
import logging
import sys

from mcp.server import Server
from mcp.server.stdio import stdio_server

from mcp_trello.config import load_env
from mcp_trello.tools import register_tools
from mcp_trello.trello_client import TrelloClient

logger = logging.getLogger(__name__)


async def main() -> None:
    """Inicializa e executa o servidor MCP via stdio.

    Fluxo:
    1. load_env() → (api_key, token)
    2. TrelloClient(api_key, token)
    3. Server("mcp-trello")
    4. register_tools(app, client)
    5. stdio_server()
    """
    api_key, token = load_env()
    client = TrelloClient(api_key, token)
    app = Server("mcp-trello")
    register_tools(app, client)

    logger.info("Iniciando servidor MCP Trello via stdio")

    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def run() -> None:
    """Entry point síncrono. Fix de encoding UTF-8 no Windows."""
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")

    asyncio.run(main())
