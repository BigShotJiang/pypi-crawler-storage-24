"""Carregamento e validação de configuração do Trello."""

import os


def load_env() -> tuple[str, str]:
    """Carrega e valida variáveis de ambiente do Trello.

    Returns:
        Tupla (api_key, token).

    Raises:
        EnvironmentError: Se TRELLO_API_KEY ou TRELLO_TOKEN estiver ausente,
            vazia ou composta apenas de whitespace.
    """
    api_key = os.environ.get("TRELLO_API_KEY", "").strip()
    token = os.environ.get("TRELLO_TOKEN", "").strip()

    if not api_key:
        raise EnvironmentError(
            "Variável de ambiente TRELLO_API_KEY ausente, vazia ou apenas whitespace."
        )

    if not token:
        raise EnvironmentError(
            "Variável de ambiente TRELLO_TOKEN ausente, vazia ou apenas whitespace."
        )

    return api_key, token
