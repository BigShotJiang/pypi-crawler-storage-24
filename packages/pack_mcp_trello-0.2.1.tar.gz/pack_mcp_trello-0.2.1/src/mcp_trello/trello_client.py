"""Cliente HTTP para a API REST do Trello."""

from __future__ import annotations

from typing import Any

import requests


# ---------------------------------------------------------------------------
# Hierarquia de exceções
# ---------------------------------------------------------------------------


class TrelloError(Exception):
    """Erro base para operações do Trello."""


class TrelloConnectionError(TrelloError):
    """Falha de conexão com a API do Trello."""


class TrelloAuthError(TrelloError):
    """Falha de autenticação (HTTP 401/403)."""


class TrelloValidationError(TrelloError):
    """Erro de validação de campos."""


# ---------------------------------------------------------------------------
# Cliente
# ---------------------------------------------------------------------------


class TrelloClient:
    """Cliente HTTP que encapsula chamadas à API REST do Trello."""

    BASE_URL = "https://api.trello.com"

    def __init__(self, api_key: str, token: str) -> None:
        """Inicializa o cliente com credenciais de autenticação."""
        self._api_key = api_key
        self._token = token

    # -- request interno ----------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: int = 30,
    ) -> Any:
        """Executa request HTTP com autenticação automática.

        Injeta ``key`` e ``token`` nos query params de toda requisição.

        Raises:
            TrelloAuthError: HTTP 401 ou 403.
            TrelloConnectionError: Falha de rede ou timeout.
            TrelloError: Outros erros HTTP.
        """
        url = f"{self.BASE_URL}{path}"

        auth_params = {"key": self._api_key, "token": self._token}
        if params:
            auth_params.update(params)

        try:
            response = requests.request(
                method,
                url,
                json=json,
                params=auth_params,
                timeout=timeout,
            )
        except (requests.ConnectionError, requests.Timeout) as exc:
            raise TrelloConnectionError(str(exc)) from exc

        if response.status_code in (401, 403):
            raise TrelloAuthError(
                f"HTTP {response.status_code}: {response.text}"
            )

        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            raise TrelloError(
                f"HTTP {response.status_code}: {response.text}"
            ) from exc

        return response.json()

    # -- leitura -------------------------------------------------------------

    def list_boards(self) -> list[dict]:
        """Lista boards abertos do membro autenticado."""
        return self._request(
            "GET",
            "/1/members/me/boards",
            params={"fields": "id,name,shortUrl,closed", "filter": "open"},
        )

    def list_lists(self, board_id: str) -> list[dict]:
        """Lista listas abertas de um board."""
        return self._request(
            "GET",
            f"/1/boards/{board_id}/lists",
            params={"fields": "id,name,closed,pos", "filter": "open"},
        )

    def list_labels(self, board_id: str) -> list[dict]:
        """Lista labels de um board."""
        return self._request(
            "GET",
            f"/1/boards/{board_id}/labels",
            params={"fields": "id,name,color"},
        )

    def list_cards(self, list_id: str) -> list[dict]:
        """Lista cards de uma lista."""
        return self._request(
            "GET",
            f"/1/lists/{list_id}/cards",
            params={
                "fields": "id,name,desc,shortUrl,idList,idBoard,labels,cover,closed"
            },
        )

    def get_card(self, card_id: str) -> dict:
        """Obtém detalhes de um card."""
        return self._request(
            "GET",
            f"/1/cards/{card_id}",
            params={
                "fields": "id,name,desc,shortUrl,idList,idBoard,labels,cover,closed"
            },
        )


    # -- escrita -------------------------------------------------------------

    def create_card(
        self,
        id_list: str,
        name: str,
        desc: str = "",
        cover_color: str | None = None,
        cover_brightness: str = "dark",
        label_ids: list[str] | None = None,
        pos: str = "bottom",
    ) -> dict:
        """Cria card com capa e labels (operação composta).

        Fluxo:
        1. POST /1/cards — cria o card
        2. PUT /1/cards/{id} — aplica capa (se cover_color informado)
        3. POST /1/cards/{id}/idLabels — adiciona cada label

        Erros em capa/labels não abortam a operação.

        Returns:
            Dict com id, url, name, idList, labelsAdded, labelsRequested, errors.
        """
        # 1. Criar card
        card = self._request(
            "POST",
            "/1/cards",
            json={"idList": id_list, "name": name, "desc": desc, "pos": pos},
        )

        card_id = card["id"]
        errors: list[str] = []

        # 2. Capa
        if cover_color:
            try:
                self._request(
                    "PUT",
                    f"/1/cards/{card_id}",
                    json={
                        "cover": {
                            "color": cover_color,
                            "brightness": cover_brightness,
                            "size": "normal",
                        }
                    },
                )
            except TrelloError as exc:
                errors.append(f"cover: {exc}")

        # 3. Labels
        labels_added = 0
        labels_requested = len(label_ids) if label_ids else 0

        if label_ids:
            for label_id in label_ids:
                try:
                    self._request(
                        "POST",
                        f"/1/cards/{card_id}/idLabels",
                        json={"value": label_id},
                    )
                    labels_added += 1
                except TrelloError as exc:
                    errors.append(f"label {label_id}: {exc}")

        return {
            "id": card_id,
            "url": card.get("shortUrl", ""),
            "name": card["name"],
            "idList": card["idList"],
            "labelsAdded": labels_added,
            "labelsRequested": labels_requested,
            "errors": errors if errors else None,
        }

    def update_card(
        self,
        card_id: str,
        name: str | None = None,
        desc: str | None = None,
        id_list: str | None = None,
        cover_color: str | None = None,
        closed: bool | None = None,
    ) -> dict:
        """Atualiza campos de um card existente."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if desc is not None:
            body["desc"] = desc
        if id_list is not None:
            body["idList"] = id_list
        if cover_color is not None:
            body["cover"] = {
                "color": cover_color,
                "brightness": "dark",
                "size": "normal",
            }
        if closed is not None:
            body["closed"] = closed

        return self._request("PUT", f"/1/cards/{card_id}", json=body)

    def add_comment(self, card_id: str, text: str) -> dict:
        """Adiciona comentário a um card."""
        return self._request(
            "POST",
            f"/1/cards/{card_id}/actions/comments",
            json={"text": text},
        )

    def list_comments(self, card_id: str) -> list[dict]:
        """Lista comentários de um card."""
        actions = self._request(
            "GET",
            f"/1/cards/{card_id}/actions",
            params={"filter": "commentCard", "fields": "data,date,memberCreator"},
        )
        return [
            {
                "id": a["id"],
                "text": a.get("data", {}).get("text", ""),
                "date": a.get("date", ""),
                "author": a.get("memberCreator", {}).get("fullName", ""),
                "username": a.get("memberCreator", {}).get("username", ""),
            }
            for a in actions
        ]

    def get_card_actions(self, card_id: str) -> list[dict]:
        """Obtém histórico de ações de um card (movimentações, labels, etc.)."""
        actions = self._request(
            "GET",
            f"/1/cards/{card_id}/actions",
            params={
                "filter": "updateCard,addLabelToCard,removeLabelFromCard,moveCardToBoard,createCard",
                "fields": "data,date,type,memberCreator",
                "limit": "50",
            },
        )
        result = []
        for a in actions:
            entry: dict = {
                "id": a["id"],
                "type": a.get("type", ""),
                "date": a.get("date", ""),
                "author": a.get("memberCreator", {}).get("fullName", ""),
            }
            data = a.get("data", {})
            if "listBefore" in data and "listAfter" in data:
                entry["listBefore"] = data["listBefore"].get("name", "")
                entry["listAfter"] = data["listAfter"].get("name", "")
            if "label" in data:
                entry["label"] = data["label"].get("name", "")
            if "old" in data:
                entry["old"] = data["old"]
            result.append(entry)
        return result

    def list_card_members(self, card_id: str) -> list[dict]:
        """Lista membros atribuídos a um card."""
        return self._request(
            "GET",
            f"/1/cards/{card_id}/members",
            params={"fields": "id,fullName,username"},
        )

