"""Definição e registro de ferramentas MCP para o Trello."""

from __future__ import annotations

import json
from typing import Any

from mcp.server import Server
from mcp.types import TextContent, Tool

from mcp_trello.trello_client import (
    TrelloAuthError,
    TrelloClient,
    TrelloConnectionError,
    TrelloError,
    TrelloValidationError,
)

# ---------------------------------------------------------------------------
# Cores de capa válidas
# ---------------------------------------------------------------------------

VALID_COVER_COLORS = frozenset(
    {"yellow", "purple", "blue", "red", "green", "orange", "black", "sky", "pink", "lime"}
)

# ---------------------------------------------------------------------------
# Definições de ferramentas MCP
# ---------------------------------------------------------------------------

TOOLS: list[Tool] = [
    Tool(
        name="trello_list_boards",
        description="Lista boards abertos do membro autenticado no Trello.",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="trello_list_lists",
        description="Lista listas abertas de um board do Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "boardId": {
                    "type": "string",
                    "description": "ID do board do Trello.",
                },
            },
            "required": ["boardId"],
        },
    ),
    Tool(
        name="trello_list_labels",
        description="Lista labels de um board do Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "boardId": {
                    "type": "string",
                    "description": "ID do board do Trello.",
                },
            },
            "required": ["boardId"],
        },
    ),
    Tool(
        name="trello_list_cards",
        description="Lista cards de uma lista do Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "listId": {
                    "type": "string",
                    "description": "ID da lista do Trello.",
                },
            },
            "required": ["listId"],
        },
    ),
    Tool(
        name="trello_get_card",
        description="Obtém detalhes completos de um card do Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
            },
            "required": ["cardId"],
        },
    ),
    Tool(
        name="trello_create_card",
        description="Cria um card no Trello com capa e labels opcionais.",
        inputSchema={
            "type": "object",
            "properties": {
                "idList": {
                    "type": "string",
                    "description": "ID da lista onde o card será criado.",
                },
                "name": {
                    "type": "string",
                    "description": "Título do card.",
                },
                "desc": {
                    "type": "string",
                    "description": "Descrição do card.",
                },
                "coverColor": {
                    "type": "string",
                    "description": "Cor da capa do card.",
                    "enum": [
                        "yellow", "purple", "blue", "red", "green",
                        "orange", "black", "sky", "pink", "lime",
                    ],
                },
                "coverBrightness": {
                    "type": "string",
                    "description": "Brilho da capa do card.",
                    "enum": ["dark", "light"],
                },
                "labelIds": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Lista de IDs de labels para associar ao card.",
                },
                "pos": {
                    "type": "string",
                    "description": "Posição do card na lista.",
                    "enum": ["top", "bottom"],
                },
            },
            "required": ["idList", "name"],
        },
    ),
    Tool(
        name="trello_update_card",
        description="Atualiza campos de um card existente no Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
                "name": {
                    "type": "string",
                    "description": "Novo título do card.",
                },
                "desc": {
                    "type": "string",
                    "description": "Nova descrição do card.",
                },
                "idList": {
                    "type": "string",
                    "description": "ID da nova lista para mover o card.",
                },
                "coverColor": {
                    "type": "string",
                    "description": "Nova cor da capa do card.",
                    "enum": [
                        "yellow", "purple", "blue", "red", "green",
                        "orange", "black", "sky", "pink", "lime",
                    ],
                },
                "closed": {
                    "type": "boolean",
                    "description": "Se true, arquiva o card.",
                },
            },
            "required": ["cardId"],
        },
    ),
    Tool(
        name="trello_add_comment",
        description="Adiciona um comentário a um card do Trello.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
                "text": {
                    "type": "string",
                    "description": "Texto do comentário.",
                },
            },
            "required": ["cardId", "text"],
        },
    ),
    Tool(
        name="trello_list_comments",
        description="Lista todos os comentários de um card do Trello. Retorna texto, autor e data de cada comentário.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
            },
            "required": ["cardId"],
        },
    ),
    Tool(
        name="trello_get_card_actions",
        description="Obtém o histórico de ações de um card do Trello: movimentações entre listas, adição/remoção de labels, e outras alterações. Útil para investigar quanto tempo um card ficou em cada etapa.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
            },
            "required": ["cardId"],
        },
    ),
    Tool(
        name="trello_list_card_members",
        description="Lista os membros atribuídos a um card do Trello. Retorna nome completo e username de cada membro.",
        inputSchema={
            "type": "object",
            "properties": {
                "cardId": {
                    "type": "string",
                    "description": "ID do card do Trello.",
                },
            },
            "required": ["cardId"],
        },
    ),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _error_content(msg: str) -> list[TextContent]:
    """Retorna conteúdo de erro formatado para MCP."""
    return [TextContent(type="text", text=msg)]


def _success_content(data: Any) -> list[TextContent]:
    """Retorna conteúdo de sucesso como JSON formatado para MCP."""
    return [TextContent(type="text", text=json.dumps(data, ensure_ascii=False, indent=2))]


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


async def _handle_list_boards(client: TrelloClient) -> list[TextContent]:
    return _success_content(client.list_boards())


async def _handle_list_lists(client: TrelloClient, arguments: dict) -> list[TextContent]:
    board_id = arguments["boardId"]
    return _success_content(client.list_lists(board_id))


async def _handle_list_labels(client: TrelloClient, arguments: dict) -> list[TextContent]:
    board_id = arguments["boardId"]
    return _success_content(client.list_labels(board_id))


async def _handle_list_cards(client: TrelloClient, arguments: dict) -> list[TextContent]:
    list_id = arguments["listId"]
    return _success_content(client.list_cards(list_id))


async def _handle_get_card(client: TrelloClient, arguments: dict) -> list[TextContent]:
    card_id = arguments["cardId"]
    return _success_content(client.get_card(card_id))


async def _handle_create_card(client: TrelloClient, arguments: dict) -> list[TextContent]:
    cover_color = arguments.get("coverColor")
    if cover_color and cover_color not in VALID_COVER_COLORS:
        raise TrelloValidationError(
            f"coverColor inválido: '{cover_color}'. "
            f"Valores válidos: {sorted(VALID_COVER_COLORS)}"
        )

    result = client.create_card(
        id_list=arguments["idList"],
        name=arguments["name"],
        desc=arguments.get("desc", ""),
        cover_color=cover_color,
        cover_brightness=arguments.get("coverBrightness", "dark"),
        label_ids=arguments.get("labelIds"),
        pos=arguments.get("pos", "bottom"),
    )
    return _success_content(result)


async def _handle_update_card(client: TrelloClient, arguments: dict) -> list[TextContent]:
    result = client.update_card(
        card_id=arguments["cardId"],
        name=arguments.get("name"),
        desc=arguments.get("desc"),
        id_list=arguments.get("idList"),
        cover_color=arguments.get("coverColor"),
        closed=arguments.get("closed"),
    )
    return _success_content(result)


async def _handle_add_comment(client: TrelloClient, arguments: dict) -> list[TextContent]:
    card_id = arguments["cardId"]
    text = arguments["text"]
    result = client.add_comment(card_id, text)
    return _success_content(result)


async def _handle_list_comments(client: TrelloClient, arguments: dict) -> list[TextContent]:
    card_id = arguments["cardId"]
    return _success_content(client.list_comments(card_id))


async def _handle_get_card_actions(client: TrelloClient, arguments: dict) -> list[TextContent]:
    card_id = arguments["cardId"]
    return _success_content(client.get_card_actions(card_id))


async def _handle_list_card_members(client: TrelloClient, arguments: dict) -> list[TextContent]:
    card_id = arguments["cardId"]
    return _success_content(client.list_card_members(card_id))


# ---------------------------------------------------------------------------
# Registro no servidor MCP
# ---------------------------------------------------------------------------

_HANDLERS = {
    "trello_list_boards": _handle_list_boards,
    "trello_list_lists": _handle_list_lists,
    "trello_list_labels": _handle_list_labels,
    "trello_list_cards": _handle_list_cards,
    "trello_get_card": _handle_get_card,
    "trello_create_card": _handle_create_card,
    "trello_update_card": _handle_update_card,
    "trello_add_comment": _handle_add_comment,
    "trello_list_comments": _handle_list_comments,
    "trello_get_card_actions": _handle_get_card_actions,
    "trello_list_card_members": _handle_list_card_members,
}


def register_tools(app: Server, client: TrelloClient) -> None:
    """Registra handlers de ferramentas MCP no servidor."""

    @app.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    @app.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        handler = _HANDLERS.get(name)
        if handler is None:
            return _error_content(f"Ferramenta desconhecida: {name}")

        try:
            if name == "trello_list_boards":
                return await handler(client)
            return await handler(client, arguments)
        except TrelloAuthError as exc:
            return _error_content(f"Erro de autenticação: {exc}")
        except TrelloValidationError as exc:
            return _error_content(f"Erro de validação: {exc}")
        except TrelloConnectionError as exc:
            return _error_content(f"Erro de conexão: {exc}")
        except TrelloError as exc:
            return _error_content(f"Erro do Trello: {exc}")
