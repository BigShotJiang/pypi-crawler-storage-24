"""Testes unitários para o módulo server."""

from __future__ import annotations

import warnings
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mcp_trello.server import main, run


class TestMain:
    """Testes para a função main() — orquestração config → client → server → tools."""

    @pytest.fixture
    def _mocks(self):
        """Configura mocks para load_env, TrelloClient, Server, register_tools e stdio_server."""
        with (
            patch("mcp_trello.server.load_env") as mock_load_env,
            patch("mcp_trello.server.TrelloClient") as mock_client_cls,
            patch("mcp_trello.server.Server") as mock_server_cls,
            patch("mcp_trello.server.register_tools") as mock_register_tools,
            patch("mcp_trello.server.stdio_server") as mock_stdio_server,
        ):
            mock_load_env.return_value = ("fake-key", "fake-token")

            mock_client = MagicMock()
            mock_client_cls.return_value = mock_client

            mock_app = MagicMock()
            mock_app.run = AsyncMock()
            mock_app.create_initialization_options.return_value = {"opts": True}
            mock_server_cls.return_value = mock_app

            read_stream = MagicMock()
            write_stream = MagicMock()
            ctx = MagicMock()
            ctx.__aenter__ = AsyncMock(return_value=(read_stream, write_stream))
            ctx.__aexit__ = AsyncMock(return_value=False)
            mock_stdio_server.return_value = ctx

            yield {
                "load_env": mock_load_env,
                "TrelloClient": mock_client_cls,
                "client": mock_client,
                "Server": mock_server_cls,
                "app": mock_app,
                "register_tools": mock_register_tools,
                "stdio_server": mock_stdio_server,
                "read_stream": read_stream,
                "write_stream": write_stream,
            }

    async def test_main_calls_load_env(self, _mocks):
        """load_env é chamado para obter credenciais."""
        await main()
        _mocks["load_env"].assert_called_once()

    async def test_main_creates_trello_client_with_credentials(self, _mocks):
        """TrelloClient recebe as credenciais retornadas por load_env."""
        await main()
        _mocks["TrelloClient"].assert_called_once_with("fake-key", "fake-token")

    async def test_main_creates_server_with_name(self, _mocks):
        """Server é criado com o nome 'mcp-trello'."""
        await main()
        _mocks["Server"].assert_called_once_with("mcp-trello")

    async def test_main_calls_register_tools_with_app_and_client(self, _mocks):
        """register_tools é chamado com app e client."""
        await main()
        _mocks["register_tools"].assert_called_once_with(
            _mocks["app"], _mocks["client"]
        )

    async def test_main_runs_via_stdio_server(self, _mocks):
        """main() usa stdio_server como context manager e chama app.run."""
        await main()
        _mocks["stdio_server"].assert_called_once()
        _mocks["app"].run.assert_called_once_with(
            _mocks["read_stream"],
            _mocks["write_stream"],
            {"opts": True},
        )

    async def test_main_orchestration_order(self, _mocks):
        """Verifica a ordem: load_env → TrelloClient → Server → register_tools → stdio_server."""
        await main()

        # Todas as chamadas devem ter ocorrido
        _mocks["load_env"].assert_called_once()
        _mocks["TrelloClient"].assert_called_once()
        _mocks["Server"].assert_called_once()
        _mocks["register_tools"].assert_called_once()
        _mocks["stdio_server"].assert_called_once()
        _mocks["app"].run.assert_called_once()


class TestRun:
    """Testes para a função run() — entry point síncrono."""

    @pytest.mark.filterwarnings("ignore::RuntimeWarning")
    @patch("mcp_trello.server.main", new_callable=AsyncMock)
    @patch("mcp_trello.server.asyncio.run")
    def test_run_calls_asyncio_run(self, mock_asyncio_run, mock_main):
        """run() invoca asyncio.run com main()."""
        run()
        mock_asyncio_run.assert_called_once()

    @pytest.mark.filterwarnings("ignore::RuntimeWarning")
    @patch("mcp_trello.server.asyncio.run")
    @patch("mcp_trello.server.sys")
    def test_run_fixes_utf8_on_windows(self, mock_sys, mock_asyncio_run):
        """run() reconfigura stdout/stderr para UTF-8 no Windows."""
        mock_sys.platform = "win32"
        mock_sys.stdout = MagicMock()
        mock_sys.stderr = MagicMock()

        run()

        mock_sys.stdout.reconfigure.assert_called_once_with(encoding="utf-8")
        mock_sys.stderr.reconfigure.assert_called_once_with(encoding="utf-8")

    @pytest.mark.filterwarnings("ignore::RuntimeWarning")
    @patch("mcp_trello.server.asyncio.run")
    @patch("mcp_trello.server.sys")
    def test_run_skips_utf8_fix_on_non_windows(self, mock_sys, mock_asyncio_run):
        """run() não reconfigura encoding em plataformas não-Windows."""
        mock_sys.platform = "linux"
        mock_sys.stdout = MagicMock()
        mock_sys.stderr = MagicMock()

        run()

        mock_sys.stdout.reconfigure.assert_not_called()
        mock_sys.stderr.reconfigure.assert_not_called()
