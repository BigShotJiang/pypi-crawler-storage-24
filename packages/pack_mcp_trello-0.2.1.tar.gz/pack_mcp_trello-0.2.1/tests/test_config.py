"""Testes unitários e de propriedade para mcp_trello.config."""

import os

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from mcp_trello.config import load_env


# ---------------------------------------------------------------------------
# Testes unitários (2.2)
# ---------------------------------------------------------------------------


class TestLoadEnvUnit:
    """Testes unitários para load_env()."""

    def test_returns_tuple_when_both_present(self, monkeypatch):
        monkeypatch.setenv("TRELLO_API_KEY", "my-key")
        monkeypatch.setenv("TRELLO_TOKEN", "my-token")
        assert load_env() == ("my-key", "my-token")

    def test_strips_whitespace(self, monkeypatch):
        monkeypatch.setenv("TRELLO_API_KEY", "  key  ")
        monkeypatch.setenv("TRELLO_TOKEN", "  token  ")
        assert load_env() == ("key", "token")

    def test_raises_when_api_key_absent(self, monkeypatch):
        monkeypatch.delenv("TRELLO_API_KEY", raising=False)
        monkeypatch.setenv("TRELLO_TOKEN", "my-token")
        with pytest.raises(EnvironmentError, match="TRELLO_API_KEY"):
            load_env()

    def test_raises_when_token_absent(self, monkeypatch):
        monkeypatch.setenv("TRELLO_API_KEY", "my-key")
        monkeypatch.delenv("TRELLO_TOKEN", raising=False)
        with pytest.raises(EnvironmentError, match="TRELLO_TOKEN"):
            load_env()

    def test_raises_when_api_key_empty(self, monkeypatch):
        monkeypatch.setenv("TRELLO_API_KEY", "")
        monkeypatch.setenv("TRELLO_TOKEN", "my-token")
        with pytest.raises(EnvironmentError, match="TRELLO_API_KEY"):
            load_env()

    def test_raises_when_token_empty(self, monkeypatch):
        monkeypatch.setenv("TRELLO_API_KEY", "my-key")
        monkeypatch.setenv("TRELLO_TOKEN", "")
        with pytest.raises(EnvironmentError, match="TRELLO_TOKEN"):
            load_env()

    def test_raises_when_both_absent(self, monkeypatch):
        monkeypatch.delenv("TRELLO_API_KEY", raising=False)
        monkeypatch.delenv("TRELLO_TOKEN", raising=False)
        with pytest.raises(EnvironmentError):
            load_env()


# ---------------------------------------------------------------------------
# Testes de propriedade (2.3 e 2.4)
# ---------------------------------------------------------------------------

# Feature: pack-mcp-trello, Property 1: Round-trip de configuração
# **Validates: Requirements 1.1**


@settings(max_examples=100)
@given(
    api_key=st.text(
        alphabet=st.characters(blacklist_characters="\x00"),
        min_size=1,
    ).filter(lambda s: s.strip()),
    token=st.text(
        alphabet=st.characters(blacklist_characters="\x00"),
        min_size=1,
    ).filter(lambda s: s.strip()),
)
def test_property_roundtrip_config(api_key: str, token: str):
    """Para qualquer par de strings válidas (não-vazias, não-whitespace),
    load_env() retorna tupla com essas strings após strip."""
    old_key = os.environ.get("TRELLO_API_KEY")
    old_token = os.environ.get("TRELLO_TOKEN")
    try:
        os.environ["TRELLO_API_KEY"] = api_key
        os.environ["TRELLO_TOKEN"] = token
        result = load_env()
        assert result == (api_key.strip(), token.strip())
    finally:
        if old_key is None:
            os.environ.pop("TRELLO_API_KEY", None)
        else:
            os.environ["TRELLO_API_KEY"] = old_key
        if old_token is None:
            os.environ.pop("TRELLO_TOKEN", None)
        else:
            os.environ["TRELLO_TOKEN"] = old_token


# Feature: pack-mcp-trello, Property 2: Whitespace é inválido na configuração
# **Validates: Requirements 1.4**


@settings(max_examples=100)
@given(ws=st.from_regex(r"^\s+$"))
def test_property_whitespace_api_key_invalid(ws: str):
    """Para qualquer string composta inteiramente de whitespace definida como
    TRELLO_API_KEY, load_env() levanta EnvironmentError."""
    old_key = os.environ.get("TRELLO_API_KEY")
    old_token = os.environ.get("TRELLO_TOKEN")
    try:
        os.environ["TRELLO_API_KEY"] = ws
        os.environ["TRELLO_TOKEN"] = "valid-token"
        with pytest.raises(EnvironmentError, match="TRELLO_API_KEY"):
            load_env()
    finally:
        if old_key is None:
            os.environ.pop("TRELLO_API_KEY", None)
        else:
            os.environ["TRELLO_API_KEY"] = old_key
        if old_token is None:
            os.environ.pop("TRELLO_TOKEN", None)
        else:
            os.environ["TRELLO_TOKEN"] = old_token


@settings(max_examples=100)
@given(ws=st.from_regex(r"^\s+$"))
def test_property_whitespace_token_invalid(ws: str):
    """Para qualquer string composta inteiramente de whitespace definida como
    TRELLO_TOKEN, load_env() levanta EnvironmentError."""
    old_key = os.environ.get("TRELLO_API_KEY")
    old_token = os.environ.get("TRELLO_TOKEN")
    try:
        os.environ["TRELLO_API_KEY"] = "valid-key"
        os.environ["TRELLO_TOKEN"] = ws
        with pytest.raises(EnvironmentError, match="TRELLO_TOKEN"):
            load_env()
    finally:
        if old_key is None:
            os.environ.pop("TRELLO_API_KEY", None)
        else:
            os.environ["TRELLO_API_KEY"] = old_key
        if old_token is None:
            os.environ.pop("TRELLO_TOKEN", None)
        else:
            os.environ["TRELLO_TOKEN"] = old_token
