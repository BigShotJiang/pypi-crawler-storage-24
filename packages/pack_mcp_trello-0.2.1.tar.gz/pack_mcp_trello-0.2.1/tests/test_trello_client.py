"""Testes unitários e de propriedade para mcp_trello.trello_client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import requests
from hypothesis import given, settings
from hypothesis import strategies as st

from mcp_trello.trello_client import (
    TrelloAuthError,
    TrelloClient,
    TrelloConnectionError,
    TrelloError,
    TrelloValidationError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_response(status_code: int = 200, json_data=None, text: str = ""):
    """Cria um MagicMock simulando requests.Response."""
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_data if json_data is not None else {}
    if status_code >= 400:
        resp.raise_for_status.side_effect = requests.HTTPError(
            response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


def _make_client() -> TrelloClient:
    return TrelloClient(api_key="test-key", token="test-token")


# ===========================================================================
# 3.6 — Testes unitários
# ===========================================================================


class TestExceptionHierarchy:
    """Hierarquia isinstance das exceções."""

    def test_trello_error_is_exception(self):
        assert issubclass(TrelloError, Exception)

    def test_connection_error_is_trello_error(self):
        assert issubclass(TrelloConnectionError, TrelloError)

    def test_auth_error_is_trello_error(self):
        assert issubclass(TrelloAuthError, TrelloError)

    def test_validation_error_is_trello_error(self):
        assert issubclass(TrelloValidationError, TrelloError)

    def test_isinstance_chain(self):
        err = TrelloConnectionError("fail")
        assert isinstance(err, TrelloError)
        assert isinstance(err, Exception)


class TestRequestErrorHandling:
    """Testes de _request para mapeamento de erros HTTP."""

    @patch("mcp_trello.trello_client.requests.request")
    def test_http_401_raises_auth_error(self, mock_req):
        mock_req.return_value = _mock_response(401, text="Unauthorized")
        client = _make_client()
        with pytest.raises(TrelloAuthError, match="401"):
            client._request("GET", "/1/test")

    @patch("mcp_trello.trello_client.requests.request")
    def test_http_403_raises_auth_error(self, mock_req):
        mock_req.return_value = _mock_response(403, text="Forbidden")
        client = _make_client()
        with pytest.raises(TrelloAuthError, match="403"):
            client._request("GET", "/1/test")

    @patch("mcp_trello.trello_client.requests.request")
    def test_connection_error_raises_connection_error(self, mock_req):
        mock_req.side_effect = requests.ConnectionError("no route")
        client = _make_client()
        with pytest.raises(TrelloConnectionError, match="no route"):
            client._request("GET", "/1/test")

    @patch("mcp_trello.trello_client.requests.request")
    def test_timeout_raises_connection_error(self, mock_req):
        mock_req.side_effect = requests.Timeout("timed out")
        client = _make_client()
        with pytest.raises(TrelloConnectionError, match="timed out"):
            client._request("GET", "/1/test")

    @patch("mcp_trello.trello_client.requests.request")
    def test_http_500_raises_trello_error(self, mock_req):
        mock_req.return_value = _mock_response(500, text="Internal Server Error")
        client = _make_client()
        with pytest.raises(TrelloError, match="500"):
            client._request("GET", "/1/test")


class TestListBoards:
    @patch("mcp_trello.trello_client.requests.request")
    def test_path_and_params(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[{"id": "b1"}])
        client = _make_client()
        result = client.list_boards()

        mock_req.assert_called_once()
        args, kwargs = mock_req.call_args
        assert args[0] == "GET"
        assert args[1] == "https://api.trello.com/1/members/me/boards"
        assert kwargs["params"]["fields"] == "id,name,shortUrl,closed"
        assert kwargs["params"]["filter"] == "open"
        assert kwargs["params"]["key"] == "test-key"
        assert kwargs["params"]["token"] == "test-token"
        assert result == [{"id": "b1"}]


class TestListLists:
    @patch("mcp_trello.trello_client.requests.request")
    def test_path_and_params(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[{"id": "l1"}])
        client = _make_client()
        result = client.list_lists("board-123")

        args, kwargs = mock_req.call_args
        assert args[1] == "https://api.trello.com/1/boards/board-123/lists"
        assert kwargs["params"]["fields"] == "id,name,closed,pos"
        assert kwargs["params"]["filter"] == "open"
        assert result == [{"id": "l1"}]


class TestListLabels:
    @patch("mcp_trello.trello_client.requests.request")
    def test_path_and_params(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[{"id": "lb1"}])
        client = _make_client()
        result = client.list_labels("board-456")

        args, kwargs = mock_req.call_args
        assert args[1] == "https://api.trello.com/1/boards/board-456/labels"
        assert kwargs["params"]["fields"] == "id,name,color"
        assert result == [{"id": "lb1"}]


class TestGetCard:
    @patch("mcp_trello.trello_client.requests.request")
    def test_path_and_params(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data={"id": "c1"})
        client = _make_client()
        result = client.get_card("card-789")

        args, kwargs = mock_req.call_args
        assert args[1] == "https://api.trello.com/1/cards/card-789"
        assert "id,name,desc,shortUrl,idList,idBoard,labels,cover,closed" in kwargs["params"]["fields"]
        assert result == {"id": "c1"}


class TestCreateCard:
    """Testes para create_card (operação composta)."""

    def _card_response(self):
        return _mock_response(
            200,
            json_data={
                "id": "new-card-id",
                "name": "Test Card",
                "shortUrl": "https://trello.com/c/abc",
                "idList": "list-1",
            },
        )

    @patch("mcp_trello.trello_client.requests.request")
    def test_full_success(self, mock_req):
        """Card + capa + labels tudo OK."""
        mock_req.return_value = _mock_response(
            200,
            json_data={
                "id": "new-card-id",
                "name": "Test Card",
                "shortUrl": "https://trello.com/c/abc",
                "idList": "list-1",
            },
        )
        client = _make_client()
        result = client.create_card(
            id_list="list-1",
            name="Test Card",
            desc="desc",
            cover_color="blue",
            label_ids=["lbl-1", "lbl-2"],
        )

        assert result["id"] == "new-card-id"
        assert result["url"] == "https://trello.com/c/abc"
        assert result["name"] == "Test Card"
        assert result["idList"] == "list-1"
        assert result["labelsAdded"] == 2
        assert result["labelsRequested"] == 2
        assert result["errors"] is None

    @patch("mcp_trello.trello_client.requests.request")
    def test_cover_failure_continues(self, mock_req):
        """Falha na capa não aborta labels."""
        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # POST card — sucesso
                return _mock_response(
                    200,
                    json_data={
                        "id": "c1",
                        "name": "Card",
                        "shortUrl": "https://trello.com/c/x",
                        "idList": "l1",
                    },
                )
            if call_count == 2:
                # PUT cover — falha
                return _mock_response(400, text="bad cover")
            # POST labels — sucesso
            return _mock_response(200, json_data={})

        mock_req.side_effect = side_effect
        client = _make_client()
        result = client.create_card(
            id_list="l1",
            name="Card",
            cover_color="red",
            label_ids=["lbl-1"],
        )

        assert result["labelsAdded"] == 1
        assert result["errors"] is not None
        assert len(result["errors"]) == 1
        assert "cover" in result["errors"][0]

    @patch("mcp_trello.trello_client.requests.request")
    def test_label_failure_continues(self, mock_req):
        """Falha em uma label não aborta as demais."""
        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return _mock_response(
                    200,
                    json_data={
                        "id": "c1",
                        "name": "Card",
                        "shortUrl": "https://trello.com/c/x",
                        "idList": "l1",
                    },
                )
            if call_count == 2:
                # label 1 — falha
                return _mock_response(400, text="bad label")
            # label 2 — sucesso
            return _mock_response(200, json_data={})

        mock_req.side_effect = side_effect
        client = _make_client()
        result = client.create_card(
            id_list="l1",
            name="Card",
            label_ids=["lbl-bad", "lbl-ok"],
        )

        assert result["labelsAdded"] == 1
        assert result["labelsRequested"] == 2
        assert result["errors"] is not None
        assert any("lbl-bad" in e for e in result["errors"])

    @patch("mcp_trello.trello_client.requests.request")
    def test_errors_none_when_all_ok(self, mock_req):
        """errors=None quando todas as operações secundárias são bem-sucedidas."""
        mock_req.return_value = _mock_response(
            200,
            json_data={
                "id": "c1",
                "name": "Card",
                "shortUrl": "https://trello.com/c/x",
                "idList": "l1",
            },
        )
        client = _make_client()
        result = client.create_card(id_list="l1", name="Card")
        assert result["errors"] is None

    @patch("mcp_trello.trello_client.requests.request")
    def test_defaults_cover_brightness_and_pos(self, mock_req):
        """Verifica defaults de coverBrightness='dark' e pos='bottom'."""
        mock_req.return_value = _mock_response(
            200,
            json_data={
                "id": "c1",
                "name": "Card",
                "shortUrl": "https://trello.com/c/x",
                "idList": "l1",
            },
        )
        client = _make_client()
        client.create_card(
            id_list="l1", name="Card", cover_color="green"
        )

        # Primeira chamada: POST card com pos=bottom
        first_call = mock_req.call_args_list[0]
        assert first_call[1]["json"]["pos"] == "bottom"

        # Segunda chamada: PUT cover com brightness=dark
        second_call = mock_req.call_args_list[1]
        assert second_call[1]["json"]["cover"]["brightness"] == "dark"
        assert second_call[1]["json"]["cover"]["size"] == "normal"


# ===========================================================================
# 3.7 — Teste de propriedade P3
# ===========================================================================

# Feature: pack-mcp-trello, Property 3: Construção de requests com autenticação e base URL
# **Validates: Requirements 2.1, 2.2**


@settings(max_examples=100)
@given(
    method=st.sampled_from(["GET", "POST", "PUT", "DELETE", "PATCH"]),
    path=st.text(
        alphabet=st.characters(
            whitelist_categories=("L", "N"),
            whitelist_characters="/.-_",
        ),
        min_size=1,
        max_size=50,
    ).map(lambda p: "/" + p.lstrip("/")),
)
@patch("mcp_trello.trello_client.requests.request")
def test_property_request_auth_and_base_url(mock_req, method, path):
    """Para qualquer método HTTP e path, a URL começa com BASE_URL e
    os query params contêm key e token."""
    mock_req.return_value = _mock_response(200, json_data={})
    client = TrelloClient(api_key="k1", token="t1")
    client._request(method, path)

    mock_req.assert_called_once()
    args, kwargs = mock_req.call_args
    called_method, called_url = args
    assert called_method == method
    assert called_url.startswith("https://api.trello.com")
    assert kwargs["params"]["key"] == "k1"
    assert kwargs["params"]["token"] == "t1"


# ===========================================================================
# 3.8 — Teste de propriedade P4
# ===========================================================================

# Feature: pack-mcp-trello, Property 4: Mapeamento de erros HTTP não-auth
# **Validates: Requirements 3.6**

_non_auth_error_codes = st.one_of(
    st.just(400),
    st.just(402),
    st.integers(min_value=404, max_value=499),
    st.integers(min_value=500, max_value=599),
)


@settings(max_examples=100)
@given(
    status_code=_non_auth_error_codes,
    body=st.text(max_size=200),
)
@patch("mcp_trello.trello_client.requests.request")
def test_property_non_auth_http_errors(mock_req, status_code, body):
    """Para qualquer código HTTP 4xx/5xx diferente de 401 e 403,
    _request() levanta TrelloError com status code e body."""
    mock_req.return_value = _mock_response(status_code, text=body)
    client = _make_client()
    with pytest.raises(TrelloError, match=str(status_code)):
        client._request("GET", "/1/test")


# ===========================================================================
# 3.9 — Teste de propriedade P6
# ===========================================================================

# Feature: pack-mcp-trello, Property 6: Estrutura do resultado de create_card
# **Validates: Requirements 8.4**

EXPECTED_KEYS = {"id", "url", "name", "idList", "labelsAdded", "labelsRequested", "errors"}


@settings(max_examples=100)
@given(
    card_name=st.text(min_size=1, max_size=50),
    list_id=st.text(min_size=1, max_size=20),
    desc=st.text(max_size=100),
)
@patch("mcp_trello.trello_client.requests.request")
def test_property_create_card_result_structure(mock_req, card_name, list_id, desc):
    """Para qualquer criação bem-sucedida, o dict retornado contém as chaves esperadas."""
    mock_req.return_value = _mock_response(
        200,
        json_data={
            "id": "generated-id",
            "name": card_name,
            "shortUrl": "https://trello.com/c/x",
            "idList": list_id,
        },
    )
    client = _make_client()
    result = client.create_card(id_list=list_id, name=card_name, desc=desc)
    assert set(result.keys()) == EXPECTED_KEYS


# ===========================================================================
# 3.10 — Teste de propriedade P7
# ===========================================================================

# Feature: pack-mcp-trello, Property 7: Resiliência na adição de labels
# **Validates: Requirements 8.3, 8.6**


@settings(max_examples=100)
@given(
    label_ids=st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=("L", "N")),
            min_size=1,
            max_size=10,
        ),
        min_size=1,
        max_size=8,
    ),
    fail_mask=st.lists(st.booleans(), min_size=1, max_size=8),
)
@patch("mcp_trello.trello_client.requests.request")
def test_property_label_addition_resilience(mock_req, label_ids, fail_mask):
    """Para qualquer lista de label IDs com falhas aleatórias,
    create_card tenta todas, coleta erros parciais, e
    labelsAdded == labels que não falharam."""
    # Ajustar fail_mask para ter o mesmo tamanho que label_ids
    mask = (fail_mask * ((len(label_ids) // len(fail_mask)) + 1))[: len(label_ids)]

    call_idx = 0

    def side_effect(*args, **kwargs):
        nonlocal call_idx
        call_idx += 1
        if call_idx == 1:
            # POST card — sempre sucesso
            return _mock_response(
                200,
                json_data={
                    "id": "c1",
                    "name": "Card",
                    "shortUrl": "https://trello.com/c/x",
                    "idList": "l1",
                },
            )
        # POST label — sucesso ou falha conforme mask
        label_index = call_idx - 2
        if label_index < len(mask) and mask[label_index]:
            return _mock_response(400, text="label fail")
        return _mock_response(200, json_data={})

    mock_req.side_effect = side_effect
    client = _make_client()
    result = client.create_card(id_list="l1", name="Card", label_ids=label_ids)

    expected_failures = sum(1 for f in mask if f)
    expected_added = len(label_ids) - expected_failures

    assert result["labelsAdded"] == expected_added
    assert result["labelsRequested"] == len(label_ids)

    if expected_failures > 0:
        assert result["errors"] is not None
        assert len(result["errors"]) == expected_failures
    else:
        assert result["errors"] is None


# ===========================================================================
# Testes para list_comments, get_card_actions, list_card_members
# ===========================================================================


class TestListComments:
    """Testes para list_comments."""

    @patch("mcp_trello.trello_client.requests.request")
    def test_returns_formatted_comments(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[
            {
                "id": "act1",
                "data": {"text": "Aguardando retorno do cliente"},
                "date": "2025-06-10T14:00:00.000Z",
                "memberCreator": {"fullName": "João Silva", "username": "joaosilva"},
            },
            {
                "id": "act2",
                "data": {"text": "Paralisado por impedimento externo"},
                "date": "2025-07-01T10:00:00.000Z",
                "memberCreator": {"fullName": "Maria Souza", "username": "mariasouza"},
            },
        ])
        client = _make_client()
        result = client.list_comments("card123")

        assert len(result) == 2
        assert result[0]["id"] == "act1"
        assert result[0]["text"] == "Aguardando retorno do cliente"
        assert result[0]["author"] == "João Silva"
        assert result[0]["username"] == "joaosilva"
        assert result[1]["text"] == "Paralisado por impedimento externo"

    @patch("mcp_trello.trello_client.requests.request")
    def test_empty_comments(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[])
        client = _make_client()
        result = client.list_comments("card123")
        assert result == []

    @patch("mcp_trello.trello_client.requests.request")
    def test_uses_correct_endpoint(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[])
        client = _make_client()
        client.list_comments("c99")
        args, kwargs = mock_req.call_args
        assert "/1/cards/c99/actions" in args[1]
        assert kwargs["params"]["filter"] == "commentCard"


class TestGetCardActions:
    """Testes para get_card_actions."""

    @patch("mcp_trello.trello_client.requests.request")
    def test_returns_move_actions(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[
            {
                "id": "a1",
                "type": "updateCard",
                "date": "2025-08-01T12:00:00.000Z",
                "memberCreator": {"fullName": "Dev Team"},
                "data": {
                    "listBefore": {"name": "A fazer"},
                    "listAfter": {"name": "Programando"},
                },
            },
        ])
        client = _make_client()
        result = client.get_card_actions("card456")

        assert len(result) == 1
        assert result[0]["listBefore"] == "A fazer"
        assert result[0]["listAfter"] == "Programando"
        assert result[0]["type"] == "updateCard"

    @patch("mcp_trello.trello_client.requests.request")
    def test_returns_label_actions(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[
            {
                "id": "a2",
                "type": "addLabelToCard",
                "date": "2025-09-01T08:00:00.000Z",
                "memberCreator": {"fullName": "QA"},
                "data": {"label": {"name": "Paralisado"}},
            },
        ])
        client = _make_client()
        result = client.get_card_actions("card789")

        assert result[0]["label"] == "Paralisado"

    @patch("mcp_trello.trello_client.requests.request")
    def test_empty_actions(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[])
        client = _make_client()
        result = client.get_card_actions("card000")
        assert result == []


class TestListCardMembers:
    """Testes para list_card_members."""

    @patch("mcp_trello.trello_client.requests.request")
    def test_returns_members(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[
            {"id": "m1", "fullName": "João Silva", "username": "joaosilva"},
            {"id": "m2", "fullName": "Maria Souza", "username": "mariasouza"},
        ])
        client = _make_client()
        result = client.list_card_members("card123")

        assert len(result) == 2
        assert result[0]["fullName"] == "João Silva"
        assert result[1]["username"] == "mariasouza"

    @patch("mcp_trello.trello_client.requests.request")
    def test_empty_members(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[])
        client = _make_client()
        result = client.list_card_members("card123")
        assert result == []

    @patch("mcp_trello.trello_client.requests.request")
    def test_uses_correct_endpoint(self, mock_req):
        mock_req.return_value = _mock_response(200, json_data=[])
        client = _make_client()
        client.list_card_members("c55")
        args, kwargs = mock_req.call_args
        assert "/1/cards/c55/members" in args[1]
