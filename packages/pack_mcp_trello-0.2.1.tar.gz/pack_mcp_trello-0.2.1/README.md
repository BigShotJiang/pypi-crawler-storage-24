# pack-mcp-trello

MCP Server em Python para integração com a API REST do Trello, focado no fluxo de criação de cards de atendimento.

## Ferramentas MCP

| Ferramenta | Descrição |
|---|---|
| `trello_list_boards` | Lista boards abertos do membro autenticado |
| `trello_list_lists` | Lista listas abertas de um board |
| `trello_list_labels` | Lista labels de um board |
| `trello_list_cards` | Lista cards de uma lista |
| `trello_get_card` | Obtém detalhes de um card |
| `trello_create_card` | Cria card com capa e labels (operação composta) |
| `trello_update_card` | Atualiza campos de um card |
| `trello_add_comment` | Adiciona comentário a um card |

## Configuração

Obtenha suas credenciais em:
- **API Key**: https://trello.com/power-ups/admin
- **Token**: Use o link de autorização com sua API Key

## Configuração MCP

Adicione ao seu `mcp.json`:

```json
{
  "mcpServers": {
    "pack-mcp-trello": {
      "command": "uvx",
      "args": ["pack-mcp-trello"],
      "env": {
        "TRELLO_API_KEY": "sua_api_key",
        "TRELLO_TOKEN": "seu_token"
      }
    }
  }
}
```

## Testes

```bash
pytest
```
