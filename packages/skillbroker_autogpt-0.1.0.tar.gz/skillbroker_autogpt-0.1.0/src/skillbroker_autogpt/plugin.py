"""
AutoGPT Plugin for SkillBroker.

This plugin adds expert knowledge capabilities to AutoGPT agents
through the SkillBroker marketplace.
"""

import os
from typing import Any, Dict, List, Optional, TypedDict, TypeVar

from .client import SkillBrokerClient, SkillBrokerError

PromptGenerator = TypeVar("PromptGenerator")


class SkillBrokerPlugin:
    """
    AutoGPT plugin for accessing expert knowledge from SkillBroker.

    This plugin provides commands for:
    - Searching the skill marketplace
    - Invoking specific skills
    - Getting expert recommendations

    Installation:
        1. Clone this repo into your AutoGPT plugins directory
        2. Add SKILLBROKER_PLUGIN=True to your .env file
        3. Optionally add SKILLBROKER_API_KEY for authenticated requests

    Usage:
        AutoGPT will automatically have access to these commands:
        - skillbroker_search: Search for expert skills
        - skillbroker_invoke: Query a specific skill
        - skillbroker_expert: Auto-find and query the best skill
    """

    def __init__(self):
        self._name = "SkillBroker"
        self._version = "0.1.0"
        self._description = "Access expert knowledge from the SkillBroker marketplace"

        # Initialize client
        api_url = os.getenv("SKILLBROKER_API_URL")
        api_key = os.getenv("SKILLBROKER_API_KEY")
        self.client = SkillBrokerClient(api_url=api_url, api_key=api_key)

    @property
    def name(self) -> str:
        return self._name

    @property
    def version(self) -> str:
        return self._version

    @property
    def description(self) -> str:
        return self._description

    def can_handle_on_response(self) -> bool:
        return False

    def on_response(self, response: str, *args, **kwargs) -> str:
        return response

    def can_handle_post_prompt(self) -> bool:
        return True

    def post_prompt(self, prompt: PromptGenerator) -> PromptGenerator:
        """Add SkillBroker commands to the prompt."""
        prompt.add_command(
            "skillbroker_search",
            "Search the SkillBroker marketplace for expert skills",
            {"query": "<search_query>", "category": "<optional_category>"},
            self.search_skills,
        )
        prompt.add_command(
            "skillbroker_invoke",
            "Query a specific skill from SkillBroker",
            {"skill_id": "<skill_id>", "query": "<your_question>"},
            self.invoke_skill,
        )
        prompt.add_command(
            "skillbroker_expert",
            "Get expert knowledge - automatically finds the best skill for your question",
            {"query": "<your_question>"},
            self.ask_expert,
        )
        return prompt

    def can_handle_on_planning(self) -> bool:
        return False

    def on_planning(self, prompt: PromptGenerator, messages: List[Dict]) -> Optional[str]:
        return None

    def can_handle_post_planning(self) -> bool:
        return False

    def post_planning(self, response: str) -> str:
        return response

    def can_handle_pre_instruction(self) -> bool:
        return False

    def pre_instruction(self, messages: List[Dict]) -> List[Dict]:
        return messages

    def can_handle_on_instruction(self) -> bool:
        return False

    def on_instruction(self, messages: List[Dict]) -> Optional[str]:
        return None

    def can_handle_post_instruction(self) -> bool:
        return False

    def post_instruction(self, response: str) -> str:
        return response

    def can_handle_pre_command(self) -> bool:
        return False

    def pre_command(self, command_name: str, arguments: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
        return command_name, arguments

    def can_handle_post_command(self) -> bool:
        return False

    def post_command(self, command_name: str, response: str) -> str:
        return response

    def can_handle_chat_completion(
        self, messages: Dict[Any, Any], model: str, temperature: float, max_tokens: int
    ) -> bool:
        return False

    def handle_chat_completion(
        self, messages: List[Dict[Any, Any]], model: str, temperature: float, max_tokens: int
    ) -> str:
        return None

    def can_handle_text_embedding(self, text: str) -> bool:
        return False

    def handle_text_embedding(self, text: str) -> List[float]:
        return None

    def can_handle_user_input(self, user_input: str) -> bool:
        return False

    def user_input(self, user_input: str) -> str:
        return user_input

    def can_handle_report(self) -> bool:
        return False

    def report(self, message: str) -> None:
        pass

    # ============ SkillBroker Commands ============

    def search_skills(self, query: str, category: Optional[str] = None) -> str:
        """
        Search the SkillBroker marketplace for expert skills.

        Args:
            query: Search query to find relevant skills.
            category: Optional category filter.

        Returns:
            Formatted list of matching skills.
        """
        try:
            results = self.client.search(query=query, category=category, limit=5)

            if not results.skills:
                return "No skills found matching your query."

            output = f"Found {len(results.skills)} skills:\n\n"
            for skill in results.skills:
                output += f"- {skill.name} (ID: {skill.id})\n"
                output += f"  Category: {skill.category}\n"
                output += f"  {skill.description}\n\n"

            return output

        except SkillBrokerError as e:
            return f"Error searching skills: {str(e)}"

    def invoke_skill(self, skill_id: str, query: str) -> str:
        """
        Invoke a specific skill from SkillBroker.

        Args:
            skill_id: The ID of the skill to invoke.
            query: Your question or request.

        Returns:
            The skill's response.
        """
        try:
            response = self.client.invoke(skill_id, query)
            return response.response
        except SkillBrokerError as e:
            return f"Error invoking skill: {str(e)}"

    def ask_expert(self, query: str) -> str:
        """
        Get expert knowledge by automatically finding the best skill.

        Args:
            query: Your question or request.

        Returns:
            Expert response from the best matching skill.
        """
        try:
            # Try recommendations first
            try:
                recommendations = self.client.get_recommendations(query, limit=1)
                if recommendations:
                    skill = recommendations[0]
                    response = self.client.invoke(skill.id, query)
                    return f"[Expert: {skill.name}]\n\n{response.response}"
            except SkillBrokerError:
                pass

            # Fall back to search
            results = self.client.search(query=query, limit=1)
            if not results.skills:
                return "No relevant expert skills found for this question."

            skill = results.skills[0]
            response = self.client.invoke(skill.id, query)
            return f"[Expert: {skill.name}]\n\n{response.response}"

        except SkillBrokerError as e:
            return f"Error: {str(e)}"
