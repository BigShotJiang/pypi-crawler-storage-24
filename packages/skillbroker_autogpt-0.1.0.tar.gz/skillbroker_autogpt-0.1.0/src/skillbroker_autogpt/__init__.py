"""
SkillBroker AutoGPT Plugin

Access expert knowledge in your AutoGPT agents through the SkillBroker marketplace.
"""

from .client import SkillBrokerClient, SkillBrokerError, SkillNotFoundError, InvocationError
from .models import Skill, SkillQuery, SkillResponse, SearchResult
from .plugin import SkillBrokerPlugin

__version__ = "0.1.0"
__all__ = [
    "SkillBrokerPlugin",
    "SkillBrokerClient",
    "SkillBrokerError",
    "SkillNotFoundError",
    "InvocationError",
    "Skill",
    "SkillQuery",
    "SkillResponse",
    "SearchResult",
]
