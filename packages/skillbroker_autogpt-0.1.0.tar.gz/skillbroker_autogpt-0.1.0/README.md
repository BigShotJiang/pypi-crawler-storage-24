# SkillBroker AutoGPT Plugin

Add expert knowledge to your AutoGPT agents with [SkillBroker](https://skillbroker.io) - the marketplace where AI agents pay for human expertise.

## Installation

### Option 1: pip install

```bash
pip install skillbroker-autogpt
```

### Option 2: Clone into plugins directory

```bash
cd Auto-GPT/plugins
git clone https://github.com/skillbroker/skillbroker-autogpt.git
```

## Configuration

Add to your `.env` file:

```bash
# Enable the plugin
ALLOWLISTED_PLUGINS=skillbroker-autogpt

# Optional: API key for authenticated requests
SKILLBROKER_API_KEY=your-api-key

# Optional: Override the API URL
SKILLBROKER_API_URL=https://api.skillbroker.io
```

## Available Commands

Once installed, AutoGPT will have access to these commands:

### skillbroker_search

Search the SkillBroker marketplace for expert skills.

```
Command: skillbroker_search
Args: {"query": "tax advice", "category": "Finance"}
```

### skillbroker_invoke

Query a specific skill by ID.

```
Command: skillbroker_invoke
Args: {"skill_id": "freelancer-tax-advisor", "query": "Can I deduct my home office?"}
```

### skillbroker_expert

Automatically find and query the best skill for your question.

```
Command: skillbroker_expert
Args: {"query": "What's the best way to structure a holding company?"}
```

## Example Usage

When AutoGPT needs expert knowledge, it can use these commands:

```
Thinking: I need expert advice on tax deductions for freelancers.
I will use the skillbroker_expert command to get professional guidance.

Command: skillbroker_expert
Args: {"query": "What home office expenses can a freelancer deduct?"}

Result: [Expert: Freelancer Tax Advisor]

As a freelancer, you can deduct the following home office expenses:
1. Dedicated workspace - proportional rent/mortgage
2. Utilities - electricity, internet, heating
3. Office supplies and equipment
4. Business phone line
...
```

## Using the Client Directly

You can also use the SkillBroker client in your own AutoGPT plugins:

```python
from skillbroker_autogpt import SkillBrokerClient

client = SkillBrokerClient()

# Search for skills
results = client.search("machine learning")
for skill in results.skills:
    print(f"- {skill.name}: {skill.description}")

# Invoke a skill
response = client.invoke("skill-id", "Your question here")
print(response.response)
```

## Plugin Structure

```
skillbroker_autogpt/
├── src/skillbroker_autogpt/
│   ├── __init__.py      # Package exports
│   ├── plugin.py        # AutoGPT plugin class
│   ├── client.py        # SkillBroker API client
│   └── models.py        # Data models
├── pyproject.toml
└── README.md
```

## API Reference

### SkillBrokerPlugin

The main plugin class that integrates with AutoGPT.

**Commands:**
- `search_skills(query, category)` - Search for skills
- `invoke_skill(skill_id, query)` - Invoke a specific skill
- `ask_expert(query)` - Auto-find and invoke the best skill

### SkillBrokerClient

```python
client = SkillBrokerClient(api_url=None, api_key=None, timeout=30)

# Methods
client.search(query, category, limit) -> SearchResult
client.invoke(skill_id, query) -> SkillResponse
client.get_skill(skill_id) -> Skill
client.get_recommendations(task_description, limit) -> List[Skill]
```

## Support

- Documentation: https://skillbroker.io/docs
- API Reference: https://api.skillbroker.io/swagger
- Issues: https://github.com/skillbroker/skillbroker-autogpt/issues
- Email: contact@skillbroker.io

## License

MIT License - see LICENSE file for details.
