# SPDX-FileCopyrightText: 2025 - 2026 Rahil Miten Doshi, Friedrich-Alexander-Universität Erlangen-Nürnberg
# SPDX-License-Identifier: BSD-3-Clause

"""Configuration parsing and YAML key definitions."""

from .material_yaml_parser import MaterialYAMLParser, YAMLFileParser, BaseFileParser
from . import yaml_keys as _yk

# Re-export everything defined in yaml_keys.__all__
globals().update({k: getattr(_yk, k) for k in _yk.__all__})

__all__ = [
    "MaterialYAMLParser",
    "YAMLFileParser",
    "BaseFileParser",
    *_yk.__all__,
]
