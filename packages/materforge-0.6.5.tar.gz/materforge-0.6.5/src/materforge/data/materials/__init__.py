# SPDX-FileCopyrightText: 2025 - 2026 Rahil Miten Doshi, Friedrich-Alexander-Universität Erlangen-Nürnberg
# SPDX-License-Identifier: BSD-3-Clause

"""Material configuration files and data."""

# This module contains material configuration files organized by type:
# - alloys/: Alloy material configurations (e.g., 1.4301.yaml)
# - pure_metals/: Pure metal material configurations (e.g., Al/Al.yaml)

# Material configurations are loaded dynamically via YAML files
# rather than being imported as Python modules

__all__ = []

# Available material configurations:
# Alloys: 1.4301 (Stainless Steel 304L)
# Pure Metals: Al (Aluminum)
