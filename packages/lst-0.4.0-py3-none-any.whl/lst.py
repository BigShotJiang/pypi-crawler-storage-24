# -*- coding: utf-8 -*-

import logging

import requests
from monapy import Step
from bs4 import BeautifulSoup as bs
from bs4 import Tag


class Fetch(Step):
    def __init__(self, html_parser='html.parser'):
        self.logger = logging.getLogger(f'{__name__}.{self.__class__.__name__}')
        self.html_parser = html_parser

    def _get_url(self, url):
        resp = requests.get(url)
        tree = bs(resp.content, self.html_parser)
        return tree

    def _has_link(self, tag):
        return 'href' in tag.attrs and tag.attrs['href'].startswith('http')

    def _get_from_tag(self, tag):
        if tag.name == 'a' and self._has_link(tag):
            return [self._get_url(tag.attrs['href'])]

        return [
            self._get_url(a_tag)
            for a_tag in tag.select('a')
            if self._has_link(a_tag)
        ]

    def make(self, source, **kwargs):
        if isinstance(source, str):
            return [self._get_url(source)]
        elif isinstance(source, Tag):
            return self._get_from_tag(source)
        else:
            self.logger.warn(f'Unexpected source: {source}')


class Scan(Step):
    def __init__(self, selector):
        self.selector = selector

    def make(self, tree, **kwargs):
        return tree.select(self.selector)
