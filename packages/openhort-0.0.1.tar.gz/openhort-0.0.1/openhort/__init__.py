"""Keep your little agentlings under control — remote viewer and controller for Windows, macOS, and Linux"""

__version__ = "0.0.1"
