import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

from matplotlib.legend import Legend
from matplotlib.legend_handler import HandlerPatch
from matplotlib.patches import Arc
from matplotlib.axes import Axes
from typing import Any, Literal
from collections.abc import Sequence
from matplotlib.transforms import Bbox, IdentityTransform, TransformedBbox


# ___________________________________________________________________
#  Arc Plot


class _ArcLegendHandler(HandlerPatch):
    """Legend handler that draws an arc-shaped key for Arc artists."""

    def create_artists(
        self,
        legend,
        orig_handle,
        xdescent,
        ydescent,
        width,
        height,
        fontsize,
        trans,
    ):
        if not isinstance(orig_handle, Arc):
            return super().create_artists(
                legend, orig_handle, xdescent, ydescent, width, height, fontsize, trans
            )

        arc = Arc(
            (xdescent + width / 2.0, ydescent + height / 2.0),
            width * 0.9,
            height * 0.9,
            theta1=20,
            theta2=160,
            linewidth=orig_handle.get_linewidth(),
            linestyle=orig_handle.get_linestyle(),
            color=orig_handle.get_edgecolor(),
            alpha=orig_handle.get_alpha(),
        )
        arc.set_transform(trans)
        return [arc]


_ARC_LEGEND_HANDLER_REGISTERED = False


def _ensure_arc_legend_handler_registered() -> None:
    global _ARC_LEGEND_HANDLER_REGISTERED
    if _ARC_LEGEND_HANDLER_REGISTERED:
        return
    Legend.update_default_handler_map({Arc: _ArcLegendHandler()})
    _ARC_LEGEND_HANDLER_REGISTERED = True


def plot_angle(
    center: Sequence[float],
    point1: Sequence[float],
    point2: Sequence[float],
    text: str,
    ax: Axes | None = None,
    size: float = 75.0,
    unit: Literal[
        "points", "pixels", "axes width", "axes height", "axes min", "axes max"
    ] = "points",
    textposition: Literal["inside", "outside", "edge", "legend"] = "inside",
    color=None,
    text_kw: dict | None = None,
    **kwargs,
) -> float:
    r"""Draw and label the angle between two vectors.

    The angle is formed by the vectors ``center -> point1`` and
    ``center -> point2``. The visible arc is always circular in display space,
    and its diameter is controlled by ``size``/``unit``.

    This function is a thin wrapper around Matplotlib's angle-annotation
    approach: https://matplotlib.org/stable/gallery/text_labels_and_annotations/angle_annotation.html

    Note:
        Reversing ``point1`` and ``point2`` swaps the direction of the measured
        arc (useful to show the complementary/outer arc).

    Args:
        center: Arc center ``(x, y)`` in data coordinates.
        point1: First point ``(x, y)`` defining the first vector from ``center``.
        point2: Second point ``(x, y)`` defining the second vector from ``center``.
        text: Label drawn near the arc (for example ``"$\\theta$"``).

    Other Parameters:
        ax: Target axes. If ``None``, uses ``matplotlib.pyplot.gca()``.
        size: Arc diameter in the unit specified by ``unit``.
        unit: Unit used for ``size``. One of ``"points"``, ``"pixels"``,
            ``"axes width"``, ``"axes height"``, ``"axes min"``,
            or ``"axes max"``.
        textposition: Label placement relative to the arc:
            ``"inside"``, ``"outside"``, ``"edge"``, or ``"legend"``.
            Use ``"legend"`` to hide on-plot text and use ``text`` as the
            legend label of the arc.
        color: Shared default color for both the arc line and the text label.
            If omitted, both default to ``rcParams["text.color"]``. In either
            case, ``kwargs["color"]`` overrides only the arc, and
            ``text_kw["color"]`` overrides only the text.
        text_kw: Extra keyword arguments forwarded to the text annotation
            (e.g. ``fontsize``, ``fontweight``, ``color``).
        **kwargs: Additional keyword arguments forwarded to
            ``matplotlib.patches.Arc`` (e.g. ``linewidth``, ``linestyle``,
            ``alpha``, ``zorder``).

    Returns:
        float: The computed angle between the 2 vectors in degrees.

    .. minigallery:: sysplot.plot_angle
        :add-heading:
    """
    if ax is None:
        ax = plt.gca()
    if not isinstance(ax, Axes):
        raise TypeError(f"ax must be a matplotlib Axes, got {type(ax)}")
    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text)}")
    if textposition not in ("inside", "outside", "edge", "legend"):
        raise ValueError(
            f"textposition must be 'inside', 'outside', 'edge', or 'legend', got {textposition!r}"
        )
    if unit not in (
        "points",
        "pixels",
        "axes width",
        "axes height",
        "axes min",
        "axes max",
    ):
        raise ValueError(f"unit must be a valid size unit, got {unit!r}")
    if not np.isfinite(size) or size <= 0:
        raise ValueError(f"size must be a positive number, got {size!r}")

    annotation_text = "" if textposition == "legend" else text

    center_arr = np.asarray(center, dtype=float)
    point1_arr = np.asarray(point1, dtype=float)
    point2_arr = np.asarray(point2, dtype=float)
    if center_arr.shape != (2,) or point1_arr.shape != (2,) or point2_arr.shape != (2,):
        raise ValueError("center, point1, and point2 must be 2D points")
    if text_kw is not None and not isinstance(text_kw, dict):
        raise TypeError("text_kw must be a dict if provided")

    # normalize dicts
    text_kw = {} if text_kw is None else text_kw.copy()
    kwargs = kwargs.copy()

    default_color = color if color is not None else mpl.rcParams["text.color"]
    line_color = kwargs.pop("color", default_color)
    text_color = text_kw.pop("color", default_color)

    angle = _AngleAnnotation(
        center_arr,
        point1_arr,
        point2_arr,
        ax=ax,
        size=size,
        unit=unit,
        text=annotation_text,
        textposition=textposition,
        line_color=line_color,
        text_color=text_color,
        text_kw=text_kw,
        **kwargs,
    )

    if textposition == "legend":
        _ensure_arc_legend_handler_registered()
        angle.set_label(text)

    return (angle.theta2 - angle.theta1) % 360


class _AngleAnnotation(Arc):
    """Draws an arc between two vectors which appears circular in display space.

    https://matplotlib.org/stable/gallery/text_labels_and_annotations/angle_annotation.html
    """

    def __init__(
        self,
        xy,
        p1,
        p2,
        size: float = 75.0,
        unit="points",
        ax=None,
        text="",
        textposition: Literal["inside", "outside", "edge", "legend"] = "inside",
        line_color=None,
        text_color=None,
        text_kw=None,
        **kwargs,
    ):
        """Initialize the angle annotation.

        Parameters
        ----------
        xy, p1, p2 : tuple or array of two floats
            Center position and two points. Angle annotation is drawn between
            the two vectors connecting *p1* and *p2* with *xy*, respectively.
            Units are data coordinates.

        size : float
            Diameter of the angle annotation in units specified by *unit*.

        unit : str
            One of the following strings to specify the unit of *size*:

            * "pixels": pixels
            * "points": points, use points instead of pixels to not have a
              dependence on the DPI
            * "axes width", "axes height": relative units of Axes width, height
            * "axes min", "axes max": minimum or maximum of relative Axes
              width, height

        ax : `matplotlib.axes.Axes`
            The Axes to add the angle annotation to.

        text : str
            The text to mark the angle with.

        textposition : {"inside", "outside", "edge", "legend"}
            Whether to show the text in- or outside the arc. "edge" can be used
            for custom positions anchored at the arc's edge. Use "legend"
            to skip on-plot text placement.

        text_kw : dict
            Dictionary of arguments passed to the Annotation.

        **kwargs
            Further parameters are passed to `matplotlib.patches.Arc`. Use this
            to specify, color, linewidth etc. of the arc.
        """
        self.ax = ax or plt.gca()
        self._xydata = xy  # in data coordinates
        self.vec1 = p1
        self.vec2 = p2
        self.size = size
        self.unit = unit
        self.textposition = textposition

        if line_color is not None:
            kwargs["color"] = line_color

        super().__init__(
            self._xydata,
            size,
            size,
            angle=0.0,
            theta1=self.theta1,
            theta2=self.theta2,
            **kwargs,
        )

        self.set_transform(IdentityTransform())
        self.ax.add_patch(self)

        self.kw: dict[str, Any] = dict(
            ha="center",
            va="center",
            xycoords=IdentityTransform(),
            xytext=(0, 0),
            textcoords="offset points",
            annotation_clip=True,
        )

        self.kw.update(text_kw or {})
        if text_color is not None:
            self.kw["color"] = text_color

        self.text = self.ax.annotate(text, xy=self._center, **self.kw)

    def get_size(self):
        factor = 1.0
        if self.unit == "points":
            factor = self.ax.figure.dpi / 72.0
        elif self.unit[:4] == "axes":
            b = TransformedBbox(Bbox.unit(), self.ax.transAxes)
            dic = {
                "max": max(b.width, b.height),
                "min": min(b.width, b.height),
                "width": b.width,
                "height": b.height,
            }
            factor = dic[self.unit[5:]]
        return self.size * factor

    def set_size(self, size):
        self.size = size

    def get_center_in_pixels(self):
        """Return center in pixels."""
        return self.ax.transData.transform(self._xydata)

    def set_center(self, xy):
        """Set center in data coordinates."""
        self._xydata = xy

    def get_theta(self, vec):
        vec_in_pixels = self.ax.transData.transform(vec) - self._center
        return np.rad2deg(np.arctan2(vec_in_pixels[1], vec_in_pixels[0]))

    def get_theta1(self):
        return self.get_theta(self.vec1)

    def get_theta2(self):
        return self.get_theta(self.vec2)

    def set_theta(self, angle):
        pass

    # Redefine attributes of the Arc to always give values in pixel space
    _center = property(get_center_in_pixels, set_center)
    theta1 = property(get_theta1, set_theta)
    theta2 = property(get_theta2, set_theta)
    width = property(get_size, set_size)
    height = property(get_size, set_size)

    # The following two methods are needed to update the text position.
    def draw(self, renderer):
        self.update_text()
        super().draw(renderer)

    def update_text(self):
        if self.textposition == "legend":
            return

        c = self._center
        s = self.get_size()
        angle_span = (self.theta2 - self.theta1) % 360
        angle = np.deg2rad(self.theta1 + angle_span / 2)
        r = s / 2
        if self.textposition == "inside":
            r = s / np.interp(angle_span, [60, 90, 135, 180], [3.3, 3.5, 3.8, 4])
        self.text.xy = c + r * np.array([np.cos(angle), np.sin(angle)])
        if self.textposition == "outside":

            def R90(a, r, w, h):
                if a < np.arctan(h / 2 / (r + w / 2)):
                    return np.sqrt((r + w / 2) ** 2 + (np.tan(a) * (r + w / 2)) ** 2)
                else:
                    c = np.sqrt((w / 2) ** 2 + (h / 2) ** 2)
                    T = np.arcsin(c * np.cos(np.pi / 2 - a + np.arcsin(h / 2 / c)) / r)
                    xy = r * np.array([np.cos(a + T), np.sin(a + T)])
                    xy += np.array([w / 2, h / 2])
                    return np.sqrt(np.sum(xy**2))

            def R(a, r, w, h):
                aa = (a % (np.pi / 4)) * ((a % (np.pi / 2)) <= np.pi / 4) + (
                    np.pi / 4 - (a % (np.pi / 4))
                ) * ((a % (np.pi / 2)) >= np.pi / 4)
                return R90(aa, r, *[w, h][:: int(np.sign(np.cos(2 * a)))])

            bbox = self.text.get_window_extent()
            X = R(angle, r, bbox.width, bbox.height)
            trans = self.ax.figure.dpi_scale_trans.inverted()
            offs = trans.transform(((X - s / 2), 0))[0] * 72
            self.text.set_position(
                (float(offs * np.cos(angle)), float(offs * np.sin(angle)))
            )
