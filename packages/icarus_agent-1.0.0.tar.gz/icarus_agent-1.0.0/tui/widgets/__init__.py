"""Textual widgets for ICARUS.

Import directly from submodules, e.g.:

    ```python
    from icarus_tui.widgets.chat_input import ChatInput
    from icarus_tui.widgets.messages import AssistantMessage
    ```
"""
