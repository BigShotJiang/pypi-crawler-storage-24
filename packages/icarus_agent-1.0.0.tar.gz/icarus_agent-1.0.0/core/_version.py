"""ICARUS version constant."""

__version__ = "0.1.0"
