"""Skills module for ICARUS.

Skill discovery, loading, and metadata live here. CLI commands for
skill management (list/create/info/delete) live in ``icarus_cli``.
"""
