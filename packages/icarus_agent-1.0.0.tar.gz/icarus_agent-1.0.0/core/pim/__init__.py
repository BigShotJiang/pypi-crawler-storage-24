"""Personal Information Management — filesystem-backed PIM data layer.

Pure data operations for contacts (vCard), calendar (iCalendar VEVENT),
and tasks (iCalendar VTODO). No LLM or agent dependencies.
"""

from icarus.pim.calendar import create_event, delete_event, list_events, parse_event, update_event
from icarus.pim.contacts import (
    create_contact,
    parse_vcard,
    search_contacts,
    update_contact,
    write_vcard,
)
from icarus.pim.todos import complete_todo, compute_urgency, create_todo, list_todos, parse_todo

__all__ = [
    # Contacts
    "create_contact",
    "parse_vcard",
    "search_contacts",
    "update_contact",
    "write_vcard",
    # Calendar
    "create_event",
    "delete_event",
    "list_events",
    "parse_event",
    "update_event",
    # Todos
    "complete_todo",
    "compute_urgency",
    "create_todo",
    "list_todos",
    "parse_todo",
]
