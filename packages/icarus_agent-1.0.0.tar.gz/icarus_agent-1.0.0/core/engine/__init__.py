"""Icarus engine — transport-agnostic agent lifecycle and orchestration.

The engine owns agent creation, MCP management, checkpointer lifecycle,
and streaming coordination.  Transports (sidecar, HTTP server) wrap the
engine and handle I/O serialization.

The engine NEVER writes to stdout — that's the transport's job.
"""

from icarus.engine.engine import IcarusEngine

__all__ = ["IcarusEngine"]
