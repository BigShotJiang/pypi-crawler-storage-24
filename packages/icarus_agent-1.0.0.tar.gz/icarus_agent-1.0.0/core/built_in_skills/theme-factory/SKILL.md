---
name: theme-factory
description: Apply professional visual themes to artifacts — slides, documents, reports, HTML pages, and more. Includes 10 ready-made themes with color palettes and font pairings, or generate a custom theme on the fly.
---

# Theme Factory

A collection of professional themes for styling any visual artifact. Each theme pairs a cohesive color palette with complementary typography.

## How to Use

1. **Present the options**: List the 10 available themes with their descriptions
2. **Get a selection**: Ask which theme fits the artifact's purpose
3. **Apply**: Read the chosen theme file from `themes/` and apply its colors and fonts consistently

## Available Themes

1. **Volcanic Ash** — Bold contrast with dark neutrals and a hot accent
2. **Copper Ridge** — Warm metallic tones for grounded, confident work
3. **Nordic Slate** — Cool greys with icy blue highlights
4. **Sahara Dusk** — Sandy warmth fading into deep evening tones
5. **Jade Temple** — Rich greens with ivory and stone
6. **Neon District** — High-energy darks with vivid electric accents
7. **Parchment** — Timeless, book-like warmth with serif elegance
8. **Coral Reef** — Vibrant aquatic palette with tropical energy
9. **Iron Workshop** — Industrial strength with utilitarian clarity
10. **Lavender Field** — Soft, approachable purples with airy lightness

## Applying a Theme

Once selected:
1. Read the theme file from `themes/`
2. Use the specified colors and fonts throughout the artifact
3. Ensure contrast and readability across all elements
4. Keep the visual identity consistent on every page or section

## Custom Themes

If none of the preset themes suit the work, create a new one. Use any description or mood provided by the user to select appropriate colors and fonts. Name the theme to reflect its visual character. Present it for approval before applying.
