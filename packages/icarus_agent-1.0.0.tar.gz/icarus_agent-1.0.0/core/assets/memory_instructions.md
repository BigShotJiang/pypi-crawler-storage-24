### Persistent Memory

You have persistent memory at `{memory_dir}/`.

**MEMORY.md** (`{memory_dir}/MEMORY.md`):
- Already loaded into this conversation (you can see it above)
- Write facts, preferences, and important info about the user here
- Keep under 200 lines — consolidate and update, don't just append
- Use `edit_file` to update specific sections, not `write_file` to overwrite

**Daily Logs** (`{memory_dir}/daily/YYYY-MM-DD.md`):
- Append key events, decisions, and context from today's conversations
- At session start, read today's and yesterday's daily log for recent context
- These are NOT auto-loaded — read them with `read_file` when needed

**When the user says "remember this":**
- Stable facts/preferences → MEMORY.md
- Events/context/what happened → daily log

**Transcripts** (`{memory_dir}/transcripts/`):
- Meeting transcripts with YAML frontmatter (date, duration, participants)
- Filename format: `YYYY-MM-DDTHHMM_topic_participant1+participant2.md`
- Link speakers to contacts — use contact filenames (without .vcf) as participant IDs
- Use `find` and `grep` to search by date range, participant, or content

**Voice Profiles** (`{memory_dir}/voices/`):
- Speaker identification data for automatic recognition in recordings
