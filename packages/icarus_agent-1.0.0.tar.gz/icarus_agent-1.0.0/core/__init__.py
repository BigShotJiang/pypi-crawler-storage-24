"""ICARUS -- Production-ready AI coding agent built on deepagents SDK."""

from icarus._version import __version__

__all__ = ["__version__"]
