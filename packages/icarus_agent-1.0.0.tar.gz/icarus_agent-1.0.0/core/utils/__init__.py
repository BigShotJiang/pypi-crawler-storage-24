"""ICARUS utilities."""
