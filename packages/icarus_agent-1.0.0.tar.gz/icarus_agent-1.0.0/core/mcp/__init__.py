"""ICARUS MCP (Model Context Protocol) integration.

Loads MCP server configs from ~/.icarus/mcp.json and provides
persistent connections that stay alive for the agent session.
"""

from icarus.mcp.client import MCPManager
from icarus.mcp.config import (
    ServerEntry,
    add_server,
    list_servers,
    read_mcp_config,
    remove_server,
    toggle_server,
    update_server,
    write_mcp_config,
)

__all__ = [
    "MCPManager",
    "ServerEntry",
    "add_server",
    "list_servers",
    "read_mcp_config",
    "remove_server",
    "toggle_server",
    "update_server",
    "write_mcp_config",
]
