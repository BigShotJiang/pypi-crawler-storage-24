"""Configuration layer — model config and project settings."""
