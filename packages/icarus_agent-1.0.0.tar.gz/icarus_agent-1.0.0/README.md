# ICARUS

Production-ready AI coding agent built on deepagents SDK.

## Quick Start

```bash
pip install -e ".[dev]"
icarus              # Interactive TUI
icarus run "task"   # Headless mode
```

## Configuration

- `~/.icarus/config.toml` — Model providers and defaults
- `.env` — API keys and secrets
