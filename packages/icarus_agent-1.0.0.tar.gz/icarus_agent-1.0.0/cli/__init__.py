"""CLI client for ICARUS — argparse, headless mode, and skill commands."""
