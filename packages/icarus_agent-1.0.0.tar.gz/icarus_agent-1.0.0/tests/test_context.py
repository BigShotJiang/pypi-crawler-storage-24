"""Tests for UserContext."""

from pathlib import Path

from icarus.runtime.context import UserContext


def test_default_context():
    """UserContext.default() creates a valid context."""
    ctx = UserContext.default()

    assert ctx.username == "default"
    assert ctx.home_dir == Path.home()
    assert ctx.working_dir == Path.cwd()
    assert ctx.config_dir == Path.home() / ".icarus"
    assert ctx.memory_dir == Path.home() / ".icarus" / "memory"
    assert isinstance(ctx.skill_sources, list)
    assert len(ctx.skill_sources) >= 1  # At least built-in skills dir


def test_for_user_context():
    """UserContext.for_user() scopes to a Linux user."""
    ctx = UserContext.for_user("testuser")

    assert ctx.username == "testuser"
    assert ctx.home_dir == Path("/home/testuser")
    assert ctx.working_dir == Path("/home/testuser/workspace")
    assert ctx.config_dir == Path("/home/testuser/.icarus")
    assert ctx.memory_dir == Path("/home/testuser/.icarus/memory")


def test_context_is_frozen(user_context: UserContext):
    """UserContext is immutable (frozen dataclass)."""
    import dataclasses

    with __import__("pytest").raises(dataclasses.FrozenInstanceError):
        user_context.username = "other"  # type: ignore[misc]


def test_ensure_dirs(tmp_path: Path):
    """ensure_dirs creates necessary directories."""
    config_dir = tmp_path / ".icarus"
    ctx = UserContext(
        username="test",
        home_dir=tmp_path,
        working_dir=tmp_path / "work",
        config_dir=config_dir,
    )

    assert not config_dir.exists()
    ctx.ensure_dirs()
    assert config_dir.exists()
    assert (config_dir / "skills").exists()
    # Memory directories
    assert (config_dir / "memory").exists()
    assert (config_dir / "memory" / "daily").exists()
    assert (config_dir / "memory" / "snapshots").exists()
    assert (config_dir / "memory" / "transcripts").exists()
    assert (config_dir / "memory" / "voices").exists()
    # PIM directories (top-level, not under memory/)
    assert (config_dir / "contacts").exists()
    assert (config_dir / "calendar").exists()
    assert (config_dir / "todos").exists()


def test_skill_sources_include_builtin():
    """Skill sources always include the built-in skills directory."""
    ctx = UserContext.default()
    # First source should be the built-in skills dir (inside the package)
    assert len(ctx.skill_sources) >= 1
    assert "skills" in ctx.skill_sources[0]


def test_for_serve_user():
    ctx = UserContext.for_serve_user("alice-123", Path("/srv/icarus"))
    user_dir = Path("/srv/icarus/users/alice-123")
    assert ctx.username == "alice-123"
    assert ctx.home_dir == user_dir
    assert ctx.working_dir == user_dir
    assert ctx.config_dir == user_dir
    assert ctx.memory_dir == user_dir / "memory"
    assert ctx.contacts_dir == user_dir / "contacts"
    # Built-in skills must be included (not just user dir)
    builtin_dir = str(Path(__file__).parent.parent / "core" / "skills")
    assert builtin_dir in ctx.skill_sources, \
        f"Built-in skills missing from skill_sources: {ctx.skill_sources}"
    assert str(user_dir / "skills") in ctx.skill_sources


def test_memory_sources_with_agents_md(tmp_path: Path):
    """Memory sources include AGENTS.md when it exists."""
    config_dir = tmp_path / ".icarus"
    config_dir.mkdir()
    agents_md = config_dir / "AGENTS.md"
    agents_md.write_text("# Test Agent Memory")

    ctx = UserContext(
        username="test",
        home_dir=tmp_path,
        working_dir=tmp_path,
        config_dir=config_dir,
        memory_sources=[str(agents_md)],
    )

    assert str(agents_md) in ctx.memory_sources
