"""Tests for package dependency extras."""

from __future__ import annotations

from pathlib import Path

import tomllib


def _load_pyproject() -> dict:
    """Load pyproject.toml from repo root."""
    root = Path(__file__).parent.parent / "pyproject.toml"
    with open(root, "rb") as f:
        return tomllib.load(f)


class TestPackageExtras:
    """Verify dependency extras are correctly defined."""

    def test_pim_extra_exists(self):
        data = _load_pyproject()
        extras = data["project"]["optional-dependencies"]
        assert "pim" in extras
        pim_deps = [d.lower().split(">")[0].split("=")[0] for d in extras["pim"]]
        assert "vobject" in pim_deps
        assert "icalendar" in pim_deps
        assert "recurring-ical-events" in pim_deps

    def test_pim_not_in_base_deps(self):
        data = _load_pyproject()
        base_deps = [d.lower().split(">")[0].split("=")[0] for d in data["project"]["dependencies"]]
        assert "vobject" not in base_deps
        assert "icalendar" not in base_deps
        assert "recurring-ical-events" not in base_deps

    def test_built_in_skill_libs_extra_exists(self):
        data = _load_pyproject()
        extras = data["project"]["optional-dependencies"]
        assert "built-in-skill-libs" in extras
        deps = [d.lower().split(">")[0].split("=")[0] for d in extras["built-in-skill-libs"]]
        assert "pandas" in deps
        assert "openpyxl" in deps
        assert "python-docx" in deps
        assert "fpdf2" in deps

    def test_local_extra_exists(self):
        data = _load_pyproject()
        extras = data["project"]["optional-dependencies"]
        assert "local" in extras
        # local should pull langchain-openai (OpenAI-compatible protocol)
        deps = [d.lower() for d in extras["local"]]
        assert any("langchain-openai" in d for d in deps)

    def test_all_extra_includes_all_groups(self):
        data = _load_pyproject()
        extras = data["project"]["optional-dependencies"]
        all_str = " ".join(extras["all"]).lower()
        for group in ["pim", "built-in-skill-libs", "tui", "serve", "openai", "anthropic"]:
            assert group in all_str, f"[all] missing {group}"

    def test_pillow_in_base_deps(self):
        """pillow must be in base — core/utils/image_utils.py needs it."""
        data = _load_pyproject()
        base_deps = [d.lower().split(">")[0].split("=")[0] for d in data["project"]["dependencies"]]
        assert "pillow" in base_deps
