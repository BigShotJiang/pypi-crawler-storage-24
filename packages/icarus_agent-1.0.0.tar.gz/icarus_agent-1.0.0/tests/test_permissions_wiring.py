"""Integration test: agent creation respects folder permissions."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from icarus.config.permissions import PermissionConfig
from icarus.runtime.backend import PermissionedBackend


class TestPermissionsWiring:
    """Verify that PermissionedBackend is wired when config is selective."""

    def test_allow_all_does_not_wrap(self, tmp_path):
        """allow_all=True should produce raw backend, no wrapper."""
        config = PermissionConfig(allow_all=True, allowed_folders=[])
        assert config.allow_all is True

    def test_selective_wraps_backend(self, tmp_path):
        """allow_all=False should wrap backend in PermissionedBackend."""
        from unittest.mock import MagicMock
        inner = MagicMock()
        config = PermissionConfig(allow_all=False, allowed_folders=[tmp_path])
        wrapped = PermissionedBackend(inner=inner, config=config)
        assert isinstance(wrapped, PermissionedBackend)
        assert wrapped.inner is inner

    def test_system_prompt_includes_folders_when_selective(self):
        """get_system_prompt should include folder list when permissions active."""
        from icarus.runtime.agent import get_system_prompt
        config = PermissionConfig(
            allow_all=False,
            allowed_folders=[Path("/home/test/Documents"), Path("/home/test/projects")],
        )
        prompt = get_system_prompt(
            assistant_id="default",
            permissions_config=config,
        )
        assert "Workspace Access" in prompt
        assert "/home/test/Documents" in prompt
        assert "/home/test/projects" in prompt

    def test_system_prompt_omits_section_when_allow_all(self):
        """get_system_prompt should not include workspace section when allow_all."""
        from icarus.runtime.agent import get_system_prompt
        config = PermissionConfig(allow_all=True, allowed_folders=[])
        prompt = get_system_prompt(
            assistant_id="default",
            permissions_config=config,
        )
        assert "Workspace Access" not in prompt

    def test_system_prompt_omits_section_when_no_config(self):
        """get_system_prompt without permissions_config should not include section."""
        from icarus.runtime.agent import get_system_prompt
        prompt = get_system_prompt(assistant_id="default")
        assert "Workspace Access" not in prompt
