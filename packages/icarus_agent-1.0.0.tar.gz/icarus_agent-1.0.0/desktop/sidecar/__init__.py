"""Desktop sidecar — JSON bridge between Tauri shell and the agent engine."""
