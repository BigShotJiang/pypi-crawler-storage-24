"""Allow ``python -m icarus.sidecar`` invocation."""

from icarus.sidecar.main import main

main()
