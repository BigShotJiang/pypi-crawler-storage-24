from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol


@dataclass
class User:
    id: str                # UUID
    username: str
    email: str
    role: str              # admin / user / read-only / pending
    auth_provider: str     # local / oidc / saml / proxy


class AuthProvider(Protocol):
    """Protocol for pluggable auth backends."""
    def authenticate(self, **kwargs) -> User | None: ...
