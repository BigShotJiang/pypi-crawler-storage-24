"""Pluggable authentication for icarus serve."""
