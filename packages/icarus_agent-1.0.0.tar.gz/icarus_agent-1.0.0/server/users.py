"""Per-user directory provisioning."""
from __future__ import annotations

from pathlib import Path


def get_user_data_dir(server_dir: Path, user_id: str) -> Path:
    return server_dir / "users" / user_id


def provision_user_dir(server_dir: Path, user_id: str) -> Path:
    user_dir = get_user_data_dir(server_dir, user_id)
    user_dir.mkdir(parents=True, exist_ok=True)
    for subdir in ("memory", "contacts", "calendar", "skills"):
        (user_dir / subdir).mkdir(exist_ok=True)
    return user_dir
