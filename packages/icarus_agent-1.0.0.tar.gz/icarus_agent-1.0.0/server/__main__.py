"""Entry point for `python -m icarus_server`."""
from __future__ import annotations

import sys

try:
    import uvicorn
except ImportError:
    print("icarus serve requires the [serve] extra. Install with: pip install icarus[serve]")
    raise SystemExit(1)

from icarus_server.config import read_config


def main() -> None:
    config = read_config()
    if not config:
        print("No server.toml found. Run 'icarus setup' first.")
        sys.exit(1)

    from icarus_server.app import create_app

    app = create_app(config)
    uvicorn.run(app, host=config.bind, port=config.port, ws_per_message_deflate=False)


if __name__ == "__main__":
    main()
