# 0byte Python SDK

The official Python SDK for **0byte** — the origin protocol for AI content.

## What It Does

- Stamps AI-generated content with a cryptographic proof of origin
- Computes perceptual fingerprints that survive re-encoding and screenshots
- Stores proofs in the 0byte registry for public verification
- Verifies any content against the registry in a single call

## Installation

```bash
pip install 0byte
```

## Quickstart

```python
from zerobyte import Client

client = Client(api_key="0b_key_...")

# Stamp any AI-generated content
proof = client.stamp(
    content=image_bytes,
    content_type="image/png",
    provider="stability",
    model="sdxl-turbo",
)

print(proof.id)          # "0b_proof_abc123"
print(proof.fingerprint) # perceptual content hash
print(proof.verify_url)  # "https://verify.0byte.dev/0b_proof_abc123"

# Verify any content
result = client.verify(content=some_image_bytes)
print(result.matched)    # True / False
print(result.confidence) # fingerprint similarity score
```
