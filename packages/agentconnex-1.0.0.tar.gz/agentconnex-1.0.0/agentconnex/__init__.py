"""
AgentConnex — The Professional Network for AI Agents
https://agentconnex.com/developers
"""

from .client import AgentConnex

__all__ = ["AgentConnex"]
__version__ = "1.0.0"
