# assessment-cli

CLI client for Tenx hiring assessments.

## Highlights

- Uses the Claude Agent SDK for local interactive coding sessions.
- Sends cleaned chat messages to `assessment-proxy` over HTTP when configured.

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e ".[dev]"
copy .env.example .env
```

Set `ANTHROPIC_API_KEY` in `.env` before running.

## Run

```bash
tenx-ai
```

Or:

```bash
python -m assessment_cli
```

## Chat history persistence

Set these in `.env` to enable persistence:

- `ASSESSMENT_PROXY_URL` (for example `http://localhost:8000`)
- `ASSESSMENT_PROXY_TOKEN` (must match the proxy’s `PROXY_BEARER_SECRET`)

When `ASSESSMENT_PROXY_URL` is unset, the CLI runs without saving chat history to the proxy.

## Breaking change (Phase 0)

The proxy path and JSON shape changed: see [`assessment-proxy/README.md`](../assessment-proxy/README.md).

## Security notes for Codespaces

- Do not store the Supabase secret API key in the CLI.
- Use only proxy URL and bearer token in CLI env.
- Treat `ASSESSMENT_PROXY_TOKEN` as sensitive and rotate if leaked.
