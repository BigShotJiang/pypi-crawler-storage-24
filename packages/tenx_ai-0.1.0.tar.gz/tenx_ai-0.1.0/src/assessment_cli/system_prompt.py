"""Load bundled system prompt for ClaudeAgentOptions."""

from __future__ import annotations

from importlib.resources import files
from typing import Any


def load_system_prompt_text() -> str:
    return (
        files("assessment_cli.prompts")
        .joinpath("system_prompt.txt")
        .read_text(encoding="utf-8")
        .strip()
    )


def build_claude_agent_system_prompt() -> str | dict[str, Any] | None:
    """Preset claude_code plus bundled system prompt text."""
    text = load_system_prompt_text()
    if not text:
        return None
    # Field name is required by the Claude Agent SDK for preset supplemental instructions.
    return {"type": "preset", "preset": "claude_code", "append": text}
