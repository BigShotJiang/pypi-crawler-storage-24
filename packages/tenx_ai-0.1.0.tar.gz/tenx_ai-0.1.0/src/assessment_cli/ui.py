"""Rich-based terminal UI for prompts, banners, and streamed assistant output."""

from __future__ import annotations

import os
import sys
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.status import Status
from rich.table import Table
from rich.theme import Theme

try:
    from prompt_toolkit import PromptSession
except Exception:  # optional dependency
    PromptSession = None


CLI_THEME = Theme(
    {
        "title": "bold bright_cyan",
        "label": "bold bright_blue",
        "assistant": "bold cyan",
        "system": "bright_magenta",
        "success": "green",
        "error": "bold red",
        "meta": "dim",
        "prompt": "bold bright_blue",
        "hint": "dim",
    }
)


def _supports_color() -> bool:
    return (
        sys.stdout.isatty()
        and sys.stderr.isatty()
        and os.environ.get("NO_COLOR") is None
    )


def _usage_tokens(usage: dict[str, Any]) -> tuple[int | None, int | None]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        return input_tokens, output_tokens
    return None, None


class CLIUI:
    def __init__(self, *, model: str, proxy_url: str | None) -> None:
        self.model = model
        self.proxy_url = (proxy_url or "").strip()
        self.console = Console(
            theme=CLI_THEME,
            highlight=False,
            no_color=not _supports_color(),
            soft_wrap=False,
        )
        self._session = None
        if PromptSession is not None and sys.stdin.isatty():
            try:
                self._session = PromptSession()
            except Exception:
                self._session = None

    def show_banner(self) -> None:
        self.console.print(
            Panel(
                "Hi, I'm Tenx AI. I'm here to assist you during this assessment by answering "
                "questions, planning features, and writing code.\n\n"
                "[hint]Type /help for commands.[/hint]",
                title="[label]Tenx AI[/label]",
                border_style="label",
                expand=True,
                padding=(1, 2),
            )
        )

    def show_help(self) -> None:
        table = Table(title="Commands", title_style="label", show_header=True, header_style="label")
        table.add_column("Command", style="assistant", no_wrap=True)
        table.add_column("Description")
        table.add_row("/help", "Show this command list")
        table.add_row("/status", "Show active model and chat history API status")
        table.add_row("/meta", "Toggle per-message usage/timing footer")
        table.add_row("/clear", "Start a fresh Claude session")
        table.add_row("/exit or /quit", "Exit the CLI")
        table.add_row("\\ (line ending)", "Continue multiline input on next line")
        self.console.print(table)

    def show_status(self) -> None:
        state = "configured" if self.proxy_url else "not configured"
        self.console.print(
            f"[meta]Model:[/meta] {self.model}  "
            f"[meta]Chat history API:[/meta] {state}"
        )

    def show_session_reset(self) -> None:
        self.console.print("[success]Started a new session.[/success]")

    def show_meta_mode(self, enabled: bool) -> None:
        value = "ON" if enabled else "OFF"
        self.console.print(f"[system]Meta footer {value}.[/system]")

    def show_error(self, message: str) -> None:
        self.console.print(Panel(message, title="Error", border_style="error"))

    def rule_you(self) -> None:
        self.console.print(Rule("[label]You[/label]", style="label"))

    def rule_assistant(self) -> None:
        self.console.print(Rule("[assistant]Assistant[/assistant]", style="assistant"))

    def rule_end(self) -> None:
        self.console.print(Rule(style="meta"))

    def start_working(self) -> Status:
        status = self.console.status("[meta]Working...[/meta]", spinner="dots12")
        status.start()
        return status

    def stop_working(self, status: Status | None) -> None:
        if status is None:
            return
        try:
            status.stop()
        except Exception:
            pass

    def print_stream_text(self, text: str) -> None:
        self.console.print(text, end="", highlight=False, soft_wrap=True)

    def print_blank(self) -> None:
        self.console.print()

    def print_meta_footer(self, *, duration_ms: int, usage: dict[str, Any]) -> None:
        input_tokens, output_tokens = _usage_tokens(usage)
        if input_tokens is not None and output_tokens is not None:
            self.console.print(
                f"[meta]{duration_ms} ms | input {input_tokens} | output {output_tokens}[/meta]"
            )
            return
        self.console.print(f"[meta]{duration_ms} ms[/meta]")

    def _input_line(self, *, rich_prompt: str, plain_prompt: str) -> str:
        if self._session is not None:
            return self._session.prompt(plain_prompt)
        return self.console.input(rich_prompt)

    def read_prompt(self) -> str:
        line = self._input_line(
            rich_prompt="[prompt]> [/prompt]",
            plain_prompt="> ",
        ).rstrip()
        if not line:
            return ""

        prompt_lines = [line[:-1] if line.endswith("\\") else line]
        while line.endswith("\\"):
            line = self._input_line(
                rich_prompt="[prompt]... [/prompt]",
                plain_prompt="... ",
            ).rstrip()
            prompt_lines.append(line[:-1] if line.endswith("\\") else line)
        return "\n".join(prompt_lines).strip()

