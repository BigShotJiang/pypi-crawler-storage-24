import { test, expect } from "@playwright/test";

/**
 * Visual regression tests for quantecon-book-theme.
 *
 * These tests capture screenshots of key page types from the lecture site
 * and compare them against baseline snapshots to detect styling regressions.
 *
 * Note: Full-page screenshots are only tested for pages without matplotlib plots,
 * since plot rendering varies between CI runs. For pages with plots, we test
 * only the theme elements (header, sidebar) which are stable.
 */

// Pages to test - these represent different content types in lectures
// Pages with matplotlib figures should only test header/sidebar (stable theme elements)
const testPages = [
  { name: "homepage", path: "/index.html", hasPlots: false },
  { name: "intro", path: "/intro.html", hasPlots: false },
  { name: "getting-started", path: "/getting_started.html", hasPlots: true },
  { name: "python-by-example", path: "/python_by_example.html", hasPlots: true },
  { name: "numpy", path: "/numpy.html", hasPlots: true },
  { name: "matplotlib", path: "/matplotlib.html", hasPlots: true },
];

test.describe("Visual Regression Tests", () => {
  for (const page of testPages) {
    // Full page screenshots only for pages without dynamic content (matplotlib plots)
    // Pages with plots vary between CI runs, so we only test theme elements
    if (!page.hasPlots) {
      test(`${page.name} - full page screenshot`, async ({
        page: browserPage,
      }) => {
        await browserPage.goto(page.path);
        // Wait for fonts and images to load
        await browserPage.waitForLoadState("networkidle");
        // Wait a bit more for any CSS animations to complete
        await browserPage.waitForTimeout(500);

        await expect(browserPage).toHaveScreenshot(`${page.name}.png`, {
          fullPage: true,
        });
      });
    }

    test(`${page.name} - header region`, async ({ page: browserPage }) => {
      await browserPage.goto(page.path);
      await browserPage.waitForLoadState("networkidle");

      const header = browserPage.locator(".qe-page__header");
      if (await header.isVisible()) {
        await expect(header).toHaveScreenshot(`${page.name}-header.png`);
      }
    });

    test(`${page.name} - sidebar region`, async ({ page: browserPage }) => {
      await browserPage.goto(page.path);
      await browserPage.waitForLoadState("networkidle");

      const sidebar = browserPage.locator(".qe-sidebar");
      if (await sidebar.isVisible()) {
        await expect(sidebar).toHaveScreenshot(`${page.name}-sidebar.png`);
      }
    });
  }
});

test.describe("Theme Features", () => {
  test("dark mode toggle", async ({ page }) => {
    await page.goto("/index.html");
    await page.waitForLoadState("networkidle");

    // Click contrast/dark mode button
    const contrastBtn = page.locator(".btn__contrast");
    if (await contrastBtn.isVisible()) {
      await contrastBtn.click();
      await page.waitForTimeout(300); // Wait for transition

      await expect(page).toHaveScreenshot("dark-mode.png", {
        fullPage: true,
      });
    }
  });

  test("code block styling", async ({ page }) => {
    await page.goto("/python_by_example.html");
    await page.waitForLoadState("networkidle");

    const codeBlock = page.locator(".highlight").first();
    if (await codeBlock.isVisible()) {
      await expect(codeBlock).toHaveScreenshot("code-block.png");
    }
  });

  test("f-string interpolation styling", async ({ page, browserName }, testInfo) => {
    // Skip on mobile - viewport too narrow to meaningfully test f-string styling
    test.skip(testInfo.project.name === "mobile-chrome", "F-string test only relevant on desktop");

    // Test that f-string placeholders render without italics
    // Uses names.html which contains: print(f'the identity of local x is {id(x)}')
    await page.goto("/names.html");
    await page.waitForLoadState("networkidle");

    // Find a code block containing .si (String.Interpol) tokens
    const fstringBlock = page.locator(".highlight:has(.si)").first();
    if (await fstringBlock.isVisible()) {
      await expect(fstringBlock).toHaveScreenshot("fstring-interpolation.png");
    }
  });

  test("math equation rendering", async ({ page }) => {
    await page.goto("/numpy.html");
    await page.waitForLoadState("networkidle");

    // Wait for MathJax 3 to fully complete typesetting rather than using a
    // fixed timeout. MathJax.startup.promise resolves when all math on the
    // page has been rendered. This prevents flaky failures caused by
    // screenshots taken before MathJax finishes layout.
    await page.waitForFunction(() => {
      return (window as any).MathJax?.startup?.promise?.then(() => true) ?? false;
    }, { timeout: 10000 });
    // Extra settle time for fonts and final layout — MathJax font metrics
    // can shift slightly after the promise resolves
    await page.waitForTimeout(1000);

    const mathParagraph = page.locator("p:has(.MathJax)").first();
    if (await mathParagraph.isVisible()) {
      // MathJax font rendering varies across environments (Ubuntu CI vs macOS,
      // different font stacks, hinting differences). Use a ratio-based
      // tolerance so it scales with element size.
      await expect(mathParagraph).toHaveScreenshot("math-equation.png", {
        maxDiffPixelRatio: 0.15,
      });
    }
  });

  test("toolbar visibility", async ({ page }) => {
    await page.goto("/index.html");
    await page.waitForLoadState("networkidle");

    const toolbar = page.locator(".qe-toolbar");
    await expect(toolbar).toHaveScreenshot("toolbar.png");
  });
});

test.describe("Typography Styling", () => {
  test("bold text styling", async ({ page }) => {
    // names.html has rich bold content (7 <strong> elements)
    await page.goto("/names.html");
    await page.waitForLoadState("networkidle");

    // Capture a paragraph containing bold text for context
    const paragraph = page.locator(".qe-page__content p:has(strong)").first();
    await expect(paragraph).toHaveScreenshot("bold-text.png");
  });

  test("italic text styling", async ({ page }) => {
    // numpy.html has rich italic content (15 <em> elements)
    await page.goto("/numpy.html");
    await page.waitForLoadState("networkidle");

    const paragraph = page.locator(".qe-page__content p:has(em)").first();
    await expect(paragraph).toHaveScreenshot("italic-text.png");
  });

  test("bold text in dark mode", async ({ page }) => {
    await page.goto("/names.html");
    await page.waitForLoadState("networkidle");

    // Toggle dark mode
    const contrastBtn = page.locator(".btn__contrast");
    await contrastBtn.click();
    await page.waitForTimeout(300);

    const paragraph = page.locator(".qe-page__content p:has(strong)").first();
    await expect(paragraph).toHaveScreenshot("bold-text-dark.png");
  });

  test("italic text in dark mode", async ({ page }) => {
    await page.goto("/numpy.html");
    await page.waitForLoadState("networkidle");

    // Toggle dark mode
    const contrastBtn = page.locator(".btn__contrast");
    await contrastBtn.click();
    await page.waitForTimeout(300);

    const paragraph = page.locator(".qe-page__content p:has(em)").first();
    await expect(paragraph).toHaveScreenshot("italic-text-dark.png");
  });

  // Note: Definition list (<dl>) visual tests are not included because the
  // lecture-python-programming.myst site does not currently contain definition
  // lists, glossaries, or field-lists. When a page with <dl> content is added,
  // a corresponding visual test should be created here.
});
