"""
LLM backend abstraction.

Supports Claude CLI, Codex CLI, and their respective APIs.
Backend priority (auto-detected, or override with P2B_BACKEND):
  1. Claude CLI   (subscription, no API key)
  2. Codex CLI    (subscription, no API key)
  3. Anthropic API (ANTHROPIC_API_KEY)
  4. OpenAI API    (OPENAI_API_KEY)

Two operations:
  - structured(): prompt + system prompt + JSON schema → parsed dict
  - generate():   prompt + system prompt → raw text (C code)
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from prompt2bin.project import ModelConfig

BACKENDS = ("claude", "codex", "anthropic-api", "openai-api")

# Module-level model config, set by configure() from build.toml [model] section.
_model_config: ModelConfig | None = None


def configure(model_config: ModelConfig | None) -> None:
    """Set the active model config (from build.toml). Call before any LLM ops."""
    global _model_config
    _model_config = model_config


def _detect_backend() -> str:
    """Detect which LLM backend to use."""
    # build.toml [model] backend takes priority
    if _model_config and _model_config.backend:
        if _model_config.backend in BACKENDS:
            return _model_config.backend

    env = os.environ.get("P2B_BACKEND", "").lower()
    if env in BACKENDS:
        return env

    # CLIs first (no API key friction)
    if shutil.which("claude"):
        return "claude"
    if shutil.which("codex"):
        return "codex"

    # API keys as fallback
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic-api"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai-api"

    return "claude"  # will fail with a helpful message later


def _get_model(env_var: str, default: str) -> str:
    """Resolve model name: build.toml > env var > default."""
    if _model_config and _model_config.name:
        return _model_config.name
    return os.environ.get(env_var, default)


def _get_temperature() -> float | None:
    """Get temperature from build.toml [model] if set."""
    if _model_config and _model_config.temperature is not None:
        return _model_config.temperature
    return None


def get_backend() -> str:
    """Return the active backend name."""
    return _detect_backend()


def get_model_info() -> dict[str, str]:
    """Return a dict of active model settings for display."""
    info: dict[str, str] = {"backend": _detect_backend()}

    backend = info["backend"]
    if backend == "claude":
        info["model"] = _claude_model_arg()
    elif backend == "anthropic-api":
        info["model"] = _get_model("P2B_ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
    elif backend == "openai-api":
        info["model"] = _get_model("P2B_OPENAI_MODEL", "gpt-4o-mini")
    elif backend == "codex":
        info["model"] = "codex"

    if _model_config:
        if _model_config.reasoning:
            info["reasoning"] = _model_config.reasoning
        if _model_config.temperature is not None:
            info["temperature"] = str(_model_config.temperature)

    return info


# ── Claude CLI backend ──

def _claude_model_arg() -> str:
    """Resolve Claude CLI --model arg: build.toml > default."""
    if _model_config and _model_config.name:
        return _model_config.name
    return "haiku"


def _claude_structured(prompt: str, system_prompt: str, json_schema: str, timeout: int = 60) -> dict | None:
    """Call Claude CLI with --json-schema for structured output."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        return None

    try:
        result = subprocess.run(
            [
                claude_bin, "-p",
                "--output-format", "json",
                "--system-prompt", system_prompt,
                "--json-schema", json_schema,
                "--tools", "",
                "--model", _claude_model_arg(),
                prompt,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None

    if result.returncode != 0:
        return None

    try:
        response = json.loads(result.stdout)
        params = response.get("structured_output")
        if params and isinstance(params, dict):
            return params
        raw = response.get("result", "")
        if isinstance(raw, str):
            return json.loads(raw)
    except (json.JSONDecodeError, KeyError, TypeError):
        pass

    return None


def _claude_generate(prompt: str, system_prompt: str, timeout: int = 90) -> str | None:
    """Call Claude CLI for raw text generation."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        return None

    try:
        result = subprocess.run(
            [
                claude_bin, "-p",
                "--system-prompt", system_prompt,
                "--tools", "",
                "--model", _claude_model_arg(),
                prompt,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None

    if result.returncode != 0:
        return None

    return result.stdout


# ── Codex CLI backend ──

def _codex_with_instructions(system_prompt: str) -> tuple[str | None, str | None]:
    """
    Write system prompt to a temp file for Codex CLI's -c flag.
    Returns (codex_bin, instructions_path) or (None, None).
    """
    codex_bin = shutil.which("codex")
    if not codex_bin:
        return None, None

    f = tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False)
    f.write(system_prompt)
    f.close()
    return codex_bin, f.name


def _codex_structured(prompt: str, system_prompt: str, json_schema: str, timeout: int = 60) -> dict | None:
    """Call Codex CLI with --json for structured output."""
    codex_bin, instructions_path = _codex_with_instructions(system_prompt)
    if not codex_bin:
        return None

    full_prompt = (
        f"{prompt}\n\n"
        f"Respond with ONLY valid JSON matching this schema:\n{json_schema}"
    )

    try:
        result = subprocess.run(
            [
                codex_bin, "exec",
                "--json",
                "-c", f"model_instructions_file={instructions_path}",
                full_prompt,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    finally:
        os.unlink(instructions_path)

    if result.returncode != 0:
        return None

    # Codex --json outputs JSONL events. Find the last agent message.
    last_message = None
    for line in result.stdout.strip().split("\n"):
        try:
            event = json.loads(line)
            if event.get("type") == "item.completed":
                item = event.get("item", {})
                if item.get("type") == "message" and item.get("role") == "assistant":
                    for content in item.get("content", []):
                        if content.get("type") == "text":
                            last_message = content.get("text", "")
        except json.JSONDecodeError:
            continue

    if not last_message:
        last_message = result.stdout.strip()

    try:
        return json.loads(last_message)
    except json.JSONDecodeError:
        for line in last_message.split("\n"):
            line = line.strip()
            if line.startswith("{"):
                try:
                    return json.loads(line)
                except json.JSONDecodeError:
                    continue
    return None


def _codex_generate(prompt: str, system_prompt: str, timeout: int = 90) -> str | None:
    """Call Codex CLI for raw text generation."""
    codex_bin, instructions_path = _codex_with_instructions(system_prompt)
    if not codex_bin:
        return None

    try:
        result = subprocess.run(
            [
                codex_bin, "exec",
                "-c", f"model_instructions_file={instructions_path}",
                prompt,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    finally:
        os.unlink(instructions_path)

    if result.returncode != 0:
        return None

    return result.stdout


# ── Anthropic API backend ──

def _get_anthropic_client():
    """Get Anthropic client, importing lazily."""
    try:
        import anthropic
        return anthropic.Anthropic()
    except ImportError:
        print("  ✗ anthropic package not installed. Run: pip install anthropic")
        return None


def _anthropic_api_structured(prompt: str, system_prompt: str, json_schema: str, timeout: int = 60) -> dict | None:
    """Call Anthropic API with tool_use for structured output."""
    client = _get_anthropic_client()
    if not client:
        return None

    schema = json.loads(json_schema)
    model = _get_model("P2B_ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")

    kwargs: dict = dict(
        model=model,
        max_tokens=1024,
        system=system_prompt,
        tools=[{
            "name": "spec",
            "description": "Output the structured spec",
            "input_schema": schema,
        }],
        tool_choice={"type": "tool", "name": "spec"},
        messages=[{"role": "user", "content": prompt}],
    )
    temp = _get_temperature()
    if temp is not None:
        kwargs["temperature"] = temp

    try:
        response = client.messages.create(**kwargs)
        for block in response.content:
            if block.type == "tool_use" and block.name == "spec":
                return block.input
    except Exception as e:
        print(f"  ⚠ Anthropic API failed: {e}")

    return None


def _anthropic_api_generate(prompt: str, system_prompt: str, timeout: int = 90) -> str | None:
    """Call Anthropic API for raw text generation."""
    client = _get_anthropic_client()
    if not client:
        return None

    model = _get_model("P2B_ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")

    kwargs: dict = dict(
        model=model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": prompt}],
    )
    temp = _get_temperature()
    if temp is not None:
        kwargs["temperature"] = temp

    # Extended thinking for reasoning=high on supported models
    if _model_config and _model_config.reasoning == "high":
        kwargs["thinking"] = {"type": "enabled", "budget_tokens": 2048}
        kwargs.pop("temperature", None)  # thinking doesn't support temperature

    try:
        response = client.messages.create(**kwargs)
        return response.content[0].text
    except Exception as e:
        print(f"  ⚠ Anthropic API failed: {e}")
        return None


# ── OpenAI API backend ──

def _get_openai_client():
    """Get OpenAI client, importing lazily."""
    try:
        import openai
        return openai.OpenAI()
    except ImportError:
        print("  ✗ openai package not installed. Run: pip install openai")
        return None


def _openai_api_structured(prompt: str, system_prompt: str, json_schema: str, timeout: int = 60) -> dict | None:
    """Call OpenAI API with structured output (response_format)."""
    client = _get_openai_client()
    if not client:
        return None

    schema = json.loads(json_schema)
    model = _get_model("P2B_OPENAI_MODEL", "gpt-4o-mini")

    kwargs: dict = dict(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": "spec",
                "strict": True,
                "schema": schema,
            },
        },
        timeout=timeout,
    )
    temp = _get_temperature()
    if temp is not None:
        kwargs["temperature"] = temp

    # OpenAI reasoning models (o1, o3) use reasoning_effort
    if _model_config and _model_config.reasoning:
        kwargs["reasoning_effort"] = _model_config.reasoning

    try:
        response = client.chat.completions.create(**kwargs)
        content = response.choices[0].message.content
        return json.loads(content)
    except Exception as e:
        print(f"  ⚠ OpenAI API failed: {e}")
        return None


def _openai_api_generate(prompt: str, system_prompt: str, timeout: int = 90) -> str | None:
    """Call OpenAI API for raw text generation."""
    client = _get_openai_client()
    if not client:
        return None

    model = _get_model("P2B_OPENAI_MODEL", "gpt-4o-mini")

    kwargs: dict = dict(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        timeout=timeout,
    )
    temp = _get_temperature()
    if temp is not None:
        kwargs["temperature"] = temp

    if _model_config and _model_config.reasoning:
        kwargs["reasoning_effort"] = _model_config.reasoning

    try:
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content
    except Exception as e:
        print(f"  ⚠ OpenAI API failed: {e}")
        return None


# ── Public API ──

_DISPATCH = {
    "claude":        (_claude_structured,        _claude_generate),
    "codex":         (_codex_structured,         _codex_generate),
    "anthropic-api": (_anthropic_api_structured, _anthropic_api_generate),
    "openai-api":    (_openai_api_structured,    _openai_api_generate),
}


def structured(prompt: str, system_prompt: str, json_schema: str, timeout: int = 60) -> dict | None:
    """
    Translate a prompt into structured JSON using the configured LLM backend.

    Returns a parsed dict matching the schema, or None on failure.
    """
    backend = _detect_backend()
    fn = _DISPATCH[backend][0]
    return fn(prompt, system_prompt, json_schema, timeout)


def generate(prompt: str, system_prompt: str, timeout: int = 90) -> str | None:
    """
    Generate raw text (C code) using the configured LLM backend.

    Returns the generated text, or None on failure.
    """
    backend = _detect_backend()
    fn = _DISPATCH[backend][1]
    return fn(prompt, system_prompt, timeout)
