var searchData=
[
  ['1_3a_20simple_20minimal_20installation_20using_20pip_0',['Method 1: Simple minimal installation using PIP',['../index.html#autotoc_md5',1,'']]]
];
