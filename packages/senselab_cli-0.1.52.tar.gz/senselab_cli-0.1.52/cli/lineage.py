from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import signal
import sqlite3
import stat
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from cli.api import APIClient, APIError
from cli.auth import maybe_refresh_bearer_token
from cli.config import CLIConfig, load_config

LINEAGE_MARKER_START = "# >>> sense-cli lineage >>>"
LINEAGE_MARKER_END = "# <<< sense-cli lineage <<<"
LINEAGE_HOOK = "pre-push"
LINEAGE_HOOKS = ("pre-commit", "commit-msg", LINEAGE_HOOK)
LINEAGE_DIR = ".sense-cli/lineage"
LINEAGE_EVENTS_FILE = "events.jsonl"
LINEAGE_AUTH_STATE_FILE = "auth_state.json"
LINEAGE_SESSION_HINTS_FILE = "session_hints.json"
LINEAGE_CURSOR_HOOKS_FILE = "hooks.json"
LINEAGE_SESSIONS_DIR = ".sense-cli/sessions"
LINEAGE_CHECKPOINTS_DIR = ".sense-cli/checkpoints"
LINEAGE_CURRENT_SESSION_FILE = "current.json"
LINEAGE_DAEMON_PID_FILE = "daemon.pid"
LINEAGE_WATCH_DEFAULT_INTERVAL_SECONDS = 5
LINEAGE_AUTH_FAILURE_COOLDOWN_SECONDS = 300
CURSOR_TRANSCRIPTS_ROOT = Path.home() / ".cursor" / "projects"
CURSOR_HOOK_MAP: dict[str, str] = {
    "sessionStart": "session-start",
    "beforeSubmitPrompt": "before-submit-prompt",
    "afterFileEdit": "after-file-edit",
    "afterTabFileEdit": "after-tab-file-edit",
    "stop": "stop",
    "sessionEnd": "session-end",
    "subagentStart": "subagent-start",
    "subagentStop": "subagent-stop",
}


def resolve_repo_root(repo: str | None = None) -> Path:
    if repo:
        root = Path(repo).expanduser().resolve()
        if not (root / ".git").exists():
            raise ValueError(f"Not a git repository: {root}")
        return root

    result = _run_git(["git", "rev-parse", "--show-toplevel"])
    if result is None:
        raise ValueError("No git repository found. Run inside a repo or pass --repo.")
    return Path(result).resolve()


def lineage_dir(repo_root: Path) -> Path:
    return repo_root / LINEAGE_DIR


def lineage_events_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_EVENTS_FILE


def lineage_session_hints_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_SESSION_HINTS_FILE


def lineage_auth_state_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_AUTH_STATE_FILE


def lineage_daemon_pid_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_DAEMON_PID_FILE


def lineage_current_session_path(repo_root: Path) -> Path:
    return repo_root / LINEAGE_SESSIONS_DIR / LINEAGE_CURRENT_SESSION_FILE


def lineage_session_file_path(repo_root: Path, session_id: str) -> Path:
    safe = _safe_identifier(session_id)
    return repo_root / LINEAGE_SESSIONS_DIR / f"{safe}.json"


def lineage_checkpoint_file_path(repo_root: Path, checkpoint_id: str) -> Path:
    safe = _safe_identifier(checkpoint_id)
    return repo_root / LINEAGE_CHECKPOINTS_DIR / f"{safe}.json"


def hook_file_path(repo_root: Path, hook_name: str = LINEAGE_HOOK) -> Path:
    return repo_root / ".git" / "hooks" / hook_name


def build_hook_block(repo_root: Path, hook_name: str = LINEAGE_HOOK) -> str:
    quoted_repo = _shell_quote(str(repo_root))
    capture_cmd = f"sense-cli --quiet lineage capture --hook {hook_name} --repo {quoted_repo}"
    if hook_name == "commit-msg":
        capture_cmd += ' --commit-msg-file "$1"'
    lines = [
        LINEAGE_MARKER_START,
        'if command -v sense-cli >/dev/null 2>&1; then',
        f"  {capture_cmd} >/dev/null 2>&1 || true",
    ]
    if hook_name == LINEAGE_HOOK:
        lines.append(f"  sense-cli --quiet lineage sync --repo {quoted_repo} >/dev/null 2>&1 || true")
    lines.extend(
        [
        "fi",
        LINEAGE_MARKER_END,
        ]
    )
    return "\n".join(lines) + "\n"


def is_lineage_enabled(repo_root: Path) -> bool:
    return bool(installed_lineage_hooks(repo_root))


def installed_lineage_hooks(repo_root: Path) -> list[str]:
    installed: list[str] = []
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        if not hook_path.exists():
            continue
        content = hook_path.read_text(encoding="utf-8", errors="ignore")
        if LINEAGE_MARKER_START in content and LINEAGE_MARKER_END in content:
            installed.append(hook_name)
    return installed


def install_lineage_hook(repo_root: Path) -> None:
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        hook_path.parent.mkdir(parents=True, exist_ok=True)
        existing = hook_path.read_text(encoding="utf-8", errors="ignore") if hook_path.exists() else ""
        block = build_hook_block(repo_root, hook_name=hook_name)
        updated = _replace_marker_block(existing, block)

        if not updated.startswith("#!"):
            updated = "#!/usr/bin/env sh\nset -e\n\n" + updated

        hook_path.write_text(updated, encoding="utf-8")
        _ensure_executable(hook_path)

    lineage_dir(repo_root).mkdir(parents=True, exist_ok=True)
    events_path = lineage_events_path(repo_root)
    if not events_path.exists():
        events_path.write_text("", encoding="utf-8")
    (repo_root / LINEAGE_SESSIONS_DIR).mkdir(parents=True, exist_ok=True)
    (repo_root / LINEAGE_CHECKPOINTS_DIR).mkdir(parents=True, exist_ok=True)
    _install_cursor_lineage_hooks(repo_root)


def remove_lineage_hook(repo_root: Path) -> bool:
    removed_any = False
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        if not hook_path.exists():
            continue
        content = hook_path.read_text(encoding="utf-8", errors="ignore")
        updated, changed = _remove_marker_block(content)
        if not changed:
            continue
        # Keep custom hooks untouched; if empty shell remains, leave it valid.
        if not updated.strip():
            updated = "#!/usr/bin/env sh\nset -e\n"
        hook_path.write_text(updated, encoding="utf-8")
        _ensure_executable(hook_path)
        removed_any = True
    if _remove_cursor_lineage_hooks(repo_root):
        removed_any = True
    return removed_any


def read_lineage_daemon_pid(repo_root: Path) -> int | None:
    path = lineage_daemon_pid_path(repo_root)
    if not path.exists():
        return None
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore").strip()
        pid = int(raw)
        if pid <= 0:
            return None
        return pid
    except (OSError, ValueError):
        return None


def write_lineage_daemon_pid(repo_root: Path, pid: int) -> None:
    path = lineage_daemon_pid_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(int(pid)), encoding="utf-8")


def clear_lineage_daemon_pid(repo_root: Path) -> None:
    path = lineage_daemon_pid_path(repo_root)
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


def is_pid_running(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def stop_lineage_daemon(repo_root: Path, timeout_seconds: float = 2.0) -> bool:
    pid = read_lineage_daemon_pid(repo_root)
    if pid is None:
        clear_lineage_daemon_pid(repo_root)
        return False
    if not is_pid_running(pid):
        clear_lineage_daemon_pid(repo_root)
        return True
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        clear_lineage_daemon_pid(repo_root)
        return False
    deadline = time.time() + max(0.1, timeout_seconds)
    while time.time() < deadline:
        if not is_pid_running(pid):
            clear_lineage_daemon_pid(repo_root)
            return True
        time.sleep(0.1)
    clear_lineage_daemon_pid(repo_root)
    return False


def lineage_daemon_status(repo_root: Path) -> dict[str, Any]:
    pid = read_lineage_daemon_pid(repo_root)
    return {
        "pid": pid,
        "running": is_pid_running(pid),
    }


def start_lineage_daemon(
    *,
    repo_root: Path,
    project_guid: str | None = None,
    interval_seconds: int = LINEAGE_WATCH_DEFAULT_INTERVAL_SECONDS,
    runtime_env: str | None = None,
) -> dict[str, Any]:
    status = lineage_daemon_status(repo_root)
    if status["running"]:
        return status
    if status["pid"] and not status["running"]:
        clear_lineage_daemon_pid(repo_root)

    cmd = [
        sys.executable,
        "-m",
        "cli.main",
        "--env", str(runtime_env or "prod"),
        "--quiet",
        "lineage",
        "watch",
        "--repo",
        str(repo_root),
        "--interval",
        str(max(3, int(interval_seconds))),
    ]
    if project_guid:
        cmd.extend(["--project", str(project_guid)])

    process = subprocess.Popen(
        cmd,
        cwd=str(repo_root),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    write_lineage_daemon_pid(repo_root, process.pid)
    return lineage_daemon_status(repo_root)


def run_lineage_watch_loop(
    *,
    config: CLIConfig,
    repo_root: Path,
    project_guid: str | None = None,
    interval_seconds: int = LINEAGE_WATCH_DEFAULT_INTERVAL_SECONDS,
    runtime_env: str | None = None,
    once: bool = False,
) -> None:
    interval = max(3, int(interval_seconds))
    last_head = _run_git(["git", "rev-parse", "HEAD"], cwd=repo_root)
    last_branch = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root) or "unknown"
    last_worktree_fingerprint, _ = _working_tree_snapshot(repo_root)

    while True:
        # Single-watcher guard: if another watcher took over the pid file, exit.
        recorded_pid = read_lineage_daemon_pid(repo_root)
        if recorded_pid and recorded_pid != os.getpid():
            return
        try:
            current_head = _run_git(["git", "rev-parse", "HEAD"], cwd=repo_root)
            current_branch = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root) or "unknown"
            current_worktree_fingerprint, current_worktree_has_changes = _working_tree_snapshot(repo_root)
            head_or_branch_changed = current_head != last_head or current_branch != last_branch
            worktree_changed = current_worktree_fingerprint != last_worktree_fingerprint

            # Capture while users are still editing (before commit) when the tracked
            # worktree/index fingerprint changes and there are local changes to report.
            if head_or_branch_changed or (worktree_changed and current_worktree_has_changes):
                capture_event(repo_root=repo_root, hook_name="watcher")
                last_head = current_head
                last_branch = current_branch
                last_worktree_fingerprint = current_worktree_fingerprint
            elif worktree_changed:
                # Keep snapshot state in sync even when transitioning back to clean.
                last_worktree_fingerprint = current_worktree_fingerprint

            if pending_events_count(repo_root) > 0:
                try:
                    _sync_pending_events_with_fresh_auth(
                        initial_config=config,
                        repo_root=repo_root,
                        project_guid=project_guid,
                        runtime_env=runtime_env,
                    )
                except Exception:
                    # Best-effort background path: keep pending events for next iteration.
                    pass
        except Exception:
            pass

        if once:
            return
        time.sleep(interval)


def capture_event(
    repo_root: Path,
    hook_name: str = LINEAGE_HOOK,
    commit_msg_file: str | None = None,
    hook_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    repo_full_name = _infer_repo_full_name(repo_root)
    branch = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root) or "unknown"
    head_sha = _run_git(["git", "rev-parse", "HEAD"], cwd=repo_root)
    file_paths = _infer_changed_files(repo_root)
    commit_lineage = _infer_lineage_from_commit_metadata(
        repo_root=repo_root,
        head_sha=head_sha,
        commit_msg_file=commit_msg_file,
    )
    persisted_hints = _read_session_hints(repo_root)
    cursor_hints = _read_cursor_context_hints(repo_root)
    cursor_transcript_hints = _read_cursor_transcript_hints(repo_root)
    cursor_recent_commit_hints = _read_cursor_recent_commit_hints(
        repo_root=repo_root,
        repo_full_name=repo_full_name,
        branch=branch,
        head_sha=head_sha,
    )

    payload_hints = _extract_hook_payload_hints(hook_payload or {})
    tool = _detect_tool_from_env() or "unknown"
    provider = _first_env(
        [
            "SENSE_CLI_LINEAGE_PROVIDER",
            "SENSELAB_LLM_PROVIDER",
            "CURSOR_MODEL_PROVIDER",
            "CLAUDE_PROVIDER",
            "GEMINI_PROVIDER",
        ]
    )
    model = _first_env(
        [
            "SENSE_CLI_LINEAGE_MODEL",
            "SENSELAB_LLM_MODEL",
            "CURSOR_MODEL",
            "CURSOR_MODEL_NAME",
            "CLAUDE_MODEL",
            "GEMINI_MODEL",
            "OPENAI_MODEL",
        ]
    )
    session_id = _first_env(
        [
            "SENSE_CLI_LINEAGE_SESSION_ID",
            "CURSOR_SESSION_ID",
            "CLAUDE_SESSION_ID",
            "GEMINI_SESSION_ID",
        ]
    )
    if (tool == "unknown" or not tool) and cursor_hints.get("tool"):
        tool = str(cursor_hints.get("tool"))
    if (tool == "unknown" or not tool) and payload_hints.get("tool"):
        tool = str(payload_hints.get("tool"))
    if not provider and cursor_hints.get("provider"):
        provider = str(cursor_hints.get("provider"))
    if not provider and payload_hints.get("provider"):
        provider = str(payload_hints.get("provider"))
    if not model and cursor_hints.get("model"):
        model = str(cursor_hints.get("model"))
    if not model and payload_hints.get("model"):
        model = str(payload_hints.get("model"))
    if not session_id and cursor_hints.get("session_id"):
        session_id = str(cursor_hints.get("session_id"))
    if not session_id and payload_hints.get("session_id"):
        session_id = str(payload_hints.get("session_id"))
    if (tool == "unknown" or not tool) and cursor_transcript_hints.get("tool"):
        tool = str(cursor_transcript_hints.get("tool"))
    if not provider and cursor_transcript_hints.get("provider"):
        provider = str(cursor_transcript_hints.get("provider"))
    if not model and cursor_transcript_hints.get("model"):
        model = str(cursor_transcript_hints.get("model"))
    if not session_id and cursor_transcript_hints.get("session_id"):
        session_id = str(cursor_transcript_hints.get("session_id"))
    if not provider and cursor_recent_commit_hints.get("provider"):
        provider = str(cursor_recent_commit_hints.get("provider"))
    if not model and cursor_recent_commit_hints.get("model"):
        model = str(cursor_recent_commit_hints.get("model"))
    if not session_id and cursor_recent_commit_hints.get("session_id"):
        session_id = str(cursor_recent_commit_hints.get("session_id"))

    if (tool == "unknown" or not tool) and commit_lineage.get("tool"):
        tool = str(commit_lineage.get("tool"))
    if not provider and commit_lineage.get("provider"):
        provider = str(commit_lineage.get("provider"))
    if not model and commit_lineage.get("model"):
        model = str(commit_lineage.get("model"))
    if not session_id and commit_lineage.get("session_id"):
        session_id = str(commit_lineage.get("session_id"))
    if (tool == "unknown" or not tool) and persisted_hints.get("tool"):
        tool = str(persisted_hints.get("tool"))
    if not provider and persisted_hints.get("provider"):
        provider = str(persisted_hints.get("provider"))
    if not model and persisted_hints.get("model"):
        model = str(persisted_hints.get("model"))
    if not session_id and persisted_hints.get("session_id"):
        session_id = str(persisted_hints.get("session_id"))
    if (tool == "unknown" or not tool) and (repo_root / ".cursor").exists():
        tool = "cursor"

    if not session_id:
        session_id = _stable_session_id(repo_full_name=repo_full_name, branch=branch)

    # ── Enhanced metrics from Cursor's state.vscdb ──────────────────────────
    # cursor_recent_commit_hints already has lines_added/deleted and ai_percentage
    # pulled from aiCodeTracking.recentCommit. Map them to the standard fields.
    _raw_lines_added: int = int(cursor_recent_commit_hints.get("lines_added") or 0)
    _raw_lines_deleted: int = int(cursor_recent_commit_hints.get("lines_deleted") or 0)
    # Prefer composer+tab breakdown (more granular) when available.
    _composer_added: int = int(cursor_recent_commit_hints.get("composer_lines_added") or 0)
    _tab_added: int = int(cursor_recent_commit_hints.get("tab_lines_added") or 0)
    _composer_deleted: int = int(cursor_recent_commit_hints.get("composer_lines_deleted") or 0)
    _tab_deleted: int = int(cursor_recent_commit_hints.get("tab_lines_deleted") or 0)
    ai_lines_added: int | None = (_composer_added + _tab_added) or _raw_lines_added or None
    ai_lines_deleted: int | None = (_composer_deleted + _tab_deleted) or _raw_lines_deleted or None
    total_lines_changed: int | None = (
        ((ai_lines_added or 0) + (ai_lines_deleted or 0)) or None
    )
    try:
        ai_percentage: float | None = float(cursor_recent_commit_hints["ai_percentage"])
    except (KeyError, TypeError, ValueError):
        ai_percentage = None
    is_ai_commit: bool | None = (ai_percentage > 50.0) if ai_percentage is not None else None

    # ── Working time: session start → now ───────────────────────────────────
    # Guard against "left Cursor open for days" by treating a gap between the
    # last recorded activity and now as the start of a new session.
    working_time_seconds: int | None = None
    try:
        session_data = _read_json_file(lineage_current_session_path(repo_root))
        now_dt = datetime.now(UTC)
        started_raw = session_data.get("started_at")
        ended_raw = session_data.get("ended_at")
        if started_raw:
            started_dt = datetime.fromisoformat(str(started_raw).replace("Z", "+00:00"))
            # If there was recent prior activity, check whether this event is
            # part of the same continuous coding block.
            if ended_raw:
                last_dt = datetime.fromisoformat(str(ended_raw).replace("Z", "+00:00"))
                gap = (now_dt - last_dt).total_seconds()
                if gap > _SESSION_INACTIVITY_THRESHOLD_SECONDS:
                    # More than 2h since last activity → fresh session, reset start.
                    started_dt = now_dt
            working_time_seconds = max(0, int((now_dt - started_dt).total_seconds()))
    except Exception:
        working_time_seconds = None

    # ── user_guid: decode from stored JWT ───────────────────────────────────
    user_guid: str | None = None
    try:
        _cfg = load_config()
        _payload = _decode_jwt_payload(_cfg.token or "")
        if isinstance(_payload, dict):
            user_guid = (
                str(_payload.get("custom:user_guid") or _payload.get("user_guid") or "").strip() or None
            )
    except Exception:
        user_guid = None

    event = {
        "event_at": datetime.now(UTC).isoformat(),
        "hook": hook_name,
        "repository_full_name": repo_full_name,
        "branch": branch,
        "head_sha": head_sha,
        "tool": tool,
        "provider": provider,
        "model": model,
        "session_id": session_id,
        "file_paths": file_paths,
        # Enhanced virality metrics
        "ai_lines_added": ai_lines_added,
        "ai_lines_deleted": ai_lines_deleted,
        "total_lines_changed": total_lines_changed,
        "ai_percentage": ai_percentage,
        "is_ai_commit": is_ai_commit,
        "working_time_seconds": working_time_seconds,
        "user_guid": user_guid,
        "metadata": {
            "captured_by": hook_name,
            "commit_trailers": commit_lineage.get("trailers") or {},
            "hint_sources": {
                "hook_payload": bool(payload_hints),
                "cursor_context": bool(cursor_hints),
                "cursor_transcript": bool(cursor_transcript_hints),
                "cursor_recent_commit": bool(cursor_recent_commit_hints),
                "commit_trailers": bool(commit_lineage),
                "persisted_hints": bool(persisted_hints),
            },
            "hook_payload": payload_hints or None,
            "cursor_transcript": cursor_transcript_hints or None,
            "cursor_recent_commit": cursor_recent_commit_hints or None,
        },
    }
    _append_local_event(repo_root, event)
    _write_session_hints(
        repo_root,
        {
            "tool": tool,
            "provider": provider,
            "model": model,
            "session_id": session_id,
            "updated_at": datetime.now(UTC).isoformat(),
            "source_hook": hook_name,
        },
    )
    _update_local_session_ledger(repo_root=repo_root, event=event)
    _write_local_checkpoint(repo_root=repo_root, event=event)
    return event


def pending_events_count(repo_root: Path) -> int:
    return len(_read_events(repo_root))


def sync_events(
    *,
    config: CLIConfig,
    api: APIClient,
    repo_root: Path,
    project_guid: str | None,
    basic_token_name: str | None = None,
    basic_token_secret: str | None = None,
    batch_size: int = 100,
) -> tuple[int, int]:
    events = _read_events(repo_root)
    sessions = _read_local_sessions(repo_root)
    checkpoints = _read_local_checkpoints(repo_root)
    if not events:
        if sessions:
            api.ingest_cli_lineage_sessions(sessions=sessions, project_guid=project_guid)
        if checkpoints:
            api.ingest_cli_lineage_checkpoints(checkpoints=checkpoints, project_guid=project_guid)
        return 0, 0

    sent = 0
    remaining = list(events)
    while remaining:
        batch = remaining[:batch_size]
        if basic_token_name and basic_token_secret:
            api.ingest_cli_lineage_events_basic(
                token_name=basic_token_name,
                token_secret=basic_token_secret,
                events=batch,
                project_guid=project_guid,
            )
        else:
            api.ingest_cli_lineage_events(events=batch, project_guid=project_guid)
        sent += len(batch)
        remaining = remaining[batch_size:]

    if sessions:
        if basic_token_name and basic_token_secret:
            api.ingest_cli_lineage_sessions_basic(
                token_name=basic_token_name,
                token_secret=basic_token_secret,
                sessions=sessions,
                project_guid=project_guid,
            )
        else:
            api.ingest_cli_lineage_sessions(sessions=sessions, project_guid=project_guid)
    if checkpoints:
        if basic_token_name and basic_token_secret:
            api.ingest_cli_lineage_checkpoints_basic(
                token_name=basic_token_name,
                token_secret=basic_token_secret,
                checkpoints=checkpoints,
                project_guid=project_guid,
            )
        else:
            api.ingest_cli_lineage_checkpoints(checkpoints=checkpoints, project_guid=project_guid)

    _write_events(repo_root, [])
    return sent, len(remaining)


def _append_local_event(repo_root: Path, event: dict[str, Any]) -> None:
    target = lineage_events_path(repo_root)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=True))
        handle.write("\n")


def _read_events(repo_root: Path) -> list[dict[str, Any]]:
    path = lineage_events_path(repo_root)
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        raw = line.strip()
        if not raw:
            continue
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                events.append(parsed)
        except json.JSONDecodeError:
            continue
    return events


def _write_events(repo_root: Path, events: list[dict[str, Any]]) -> None:
    path = lineage_events_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = "\n".join(json.dumps(item, ensure_ascii=True) for item in events)
    if payload:
        payload += "\n"
    path.write_text(payload, encoding="utf-8")


def _read_session_hints(repo_root: Path) -> dict[str, Any]:
    path = lineage_session_hints_path(repo_root)
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _write_session_hints(repo_root: Path, hints: dict[str, Any]) -> None:
    path = lineage_session_hints_path(repo_root)
    existing = _read_session_hints(repo_root)
    merged = {
        **existing,
        **{key: value for key, value in hints.items() if value not in (None, "", "unknown")},
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(merged, ensure_ascii=True, sort_keys=True), encoding="utf-8")


_SESSION_INACTIVITY_THRESHOLD_SECONDS = 2 * 3600  # 2 hours with no events = new session


def _update_local_session_ledger(*, repo_root: Path, event: dict[str, Any]) -> None:
    session_id = str(event.get("session_id") or "").strip()
    repository_full_name = str(event.get("repository_full_name") or "").strip()
    if not session_id or not repository_full_name:
        return
    current_path = lineage_current_session_path(repo_root)
    session_path = lineage_session_file_path(repo_root, session_id)
    current = _read_json_file(current_path)
    now_iso = datetime.now(UTC).isoformat()
    now_dt = datetime.now(UTC)

    # If the persisted session belongs to a different session_id or a different
    # branch, don't carry over its started_at — it's a different working block.
    same_session = (
        current.get("session_id") == session_id
        and current.get("branch") == event.get("branch")
    )

    # Detect inactivity gaps: if the last recorded event was more than the
    # inactivity threshold ago, this is effectively a new coding session even
    # if the session_id is the same (e.g. Cursor was left open overnight).
    inactivity_gap = False
    if same_session and current.get("ended_at"):
        try:
            last_active = datetime.fromisoformat(
                str(current["ended_at"]).replace("Z", "+00:00")
            )
            gap = (now_dt - last_active).total_seconds()
            if gap > _SESSION_INACTIVITY_THRESHOLD_SECONDS:
                inactivity_gap = True
        except (ValueError, TypeError):
            inactivity_gap = True

    # A push is a natural session boundary: the next event after a push should
    # start a brand-new session so session time = first-edit → push.
    was_pushed = bool(current.get("session_pushed"))

    if same_session and not inactivity_gap and not was_pushed:
        started_at = current.get("started_at") or now_iso
    else:
        started_at = now_iso

    is_push_event = event.get("hook") == "pre-push"

    payload = {
        "session_id": session_id,
        "repository_full_name": repository_full_name,
        "branch": event.get("branch"),
        "base_sha": current.get("base_sha") if same_session and not inactivity_gap and not was_pushed else None,
        "head_sha": event.get("head_sha"),
        "tool": event.get("tool"),
        "provider": event.get("provider"),
        "model": event.get("model"),
        "started_at": started_at,
        "ended_at": now_iso,
        "event_at": event.get("event_at"),
        # Mark that a push happened; next event in this repo resets started_at.
        "session_pushed": is_push_event,
        "metadata": {
            "latest_hook": event.get("hook"),
            "changed_files_count": len(event.get("file_paths") or []),
        },
    }
    _write_json_file(current_path, payload)
    _write_json_file(session_path, payload)


def _write_local_checkpoint(*, repo_root: Path, event: dict[str, Any]) -> None:
    commit_sha = str(event.get("head_sha") or "").strip()
    if not commit_sha:
        return
    checkpoint_payload = {
        "event_at": event.get("event_at"),
        "repository_full_name": event.get("repository_full_name"),
        "branch": event.get("branch"),
        "session_id": event.get("session_id"),
        "commit_sha": commit_sha,
        "tool": event.get("tool"),
        "provider": event.get("provider"),
        "model": event.get("model"),
        "file_paths": event.get("file_paths") or [],
        "metadata": event.get("metadata") if isinstance(event.get("metadata"), dict) else {},
    }
    _write_json_file(
        lineage_checkpoint_file_path(repo_root, checkpoint_id=commit_sha),
        checkpoint_payload,
    )


def _read_local_sessions(repo_root: Path) -> list[dict[str, Any]]:
    root = repo_root / LINEAGE_SESSIONS_DIR
    if not root.exists():
        return []
    rows: list[dict[str, Any]] = []
    for path in root.glob("*.json"):
        if path.name == LINEAGE_CURRENT_SESSION_FILE:
            continue
        parsed = _read_json_file(path)
        if isinstance(parsed, dict) and parsed.get("repository_full_name") and parsed.get("session_id"):
            rows.append(parsed)
    return rows[:200]


def _read_local_checkpoints(repo_root: Path) -> list[dict[str, Any]]:
    root = repo_root / LINEAGE_CHECKPOINTS_DIR
    if not root.exists():
        return []
    rows: list[dict[str, Any]] = []
    for path in root.glob("*.json"):
        parsed = _read_json_file(path)
        if isinstance(parsed, dict) and parsed.get("repository_full_name") and parsed.get("commit_sha"):
            rows.append(parsed)
    return rows[:500]


def _read_json_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _write_json_file(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, sort_keys=True), encoding="utf-8")


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return cleaned[:128] or "unknown"


def _stable_session_id(*, repo_full_name: str | None, branch: str | None) -> str:
    seed = f"{repo_full_name or 'repo'}:{branch or 'branch'}"
    return _safe_identifier(seed)


def _replace_marker_block(content: str, block: str) -> str:
    pattern = re.compile(
        rf"{re.escape(LINEAGE_MARKER_START)}.*?{re.escape(LINEAGE_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    if pattern.search(content):
        return pattern.sub(block, content)

    updated = content
    if updated and not updated.endswith("\n"):
        updated += "\n"
    if updated and not updated.endswith("\n\n"):
        updated += "\n"
    return updated + block


def _remove_marker_block(content: str) -> tuple[str, bool]:
    pattern = re.compile(
        rf"\n?{re.escape(LINEAGE_MARKER_START)}.*?{re.escape(LINEAGE_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    updated, count = pattern.subn("\n", content)
    updated = re.sub(r"\n{3,}", "\n\n", updated)
    return updated, count > 0


def _ensure_executable(path: Path) -> None:
    current = path.stat().st_mode
    path.chmod(current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _run_git(command: list[str], cwd: Path | None = None) -> str | None:
    try:
        result = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            check=False,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _first_env(names: list[str]) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value and value.strip():
            return value.strip()
    return None


# Maps env var NAME → canonical tool name.
# Many tools set their env var to a truthy value like "1" or a path rather
# than the human-readable tool name.  We detect tool presence by which env var
# is *set*, not by its value.
_ENV_VAR_TO_TOOL: dict[str, str] = {
    "CURSOR_AGENT": "cursor",
    "CLAUDE_CODE": "claude-code",
    "GEMINI_CLI": "gemini",
}


def _detect_tool_from_env() -> str | None:
    """Return a canonical tool name by inspecting which env vars are present.

    Preference order:
    1. SENSE_CLI_LINEAGE_TOOL (explicit override, use its value directly)
    2. Known env-var-name → tool-name mappings  (value is usually "1" or a path)
    """
    override = os.getenv("SENSE_CLI_LINEAGE_TOOL")
    if override and override.strip():
        return override.strip().lower()
    for env_var, tool_name in _ENV_VAR_TO_TOOL.items():
        if os.getenv(env_var):
            return tool_name
    return None


def _infer_changed_files(repo_root: Path) -> list[str]:
    # Pre-push can include both staged and committed deltas; keep this lightweight.
    staged = _run_git(["git", "diff", "--name-only", "--cached"], cwd=repo_root) or ""
    unstaged = _run_git(["git", "diff", "--name-only"], cwd=repo_root) or ""
    untracked = _run_git(["git", "ls-files", "--others", "--exclude-standard"], cwd=repo_root) or ""
    names = set()
    for blob in (staged, unstaged, untracked):
        for line in blob.splitlines():
            candidate = line.strip()
            if candidate:
                names.add(candidate)
    return sorted(names)[:500]


def _resolve_watch_runtime_config(
    *,
    initial_config: CLIConfig,
    project_guid: str | None,
    runtime_env: str | None = None,
) -> tuple[CLIConfig, str | None]:
    runtime_config = load_config()

    env_base_urls = {
        "dev": "https://dev-backend-api.app.raia.live",
        "prod": "https://prod-backend-api.app.raia.live",
    }
    # Always resolve to an explicit env so a stale dev URL in config.json
    # never silently redirects background syncs to the wrong backend.
    env_name = str(runtime_env or "prod").strip().lower()
    if env_name in env_base_urls:
        runtime_config.base_url = env_base_urls[env_name]

    if not runtime_config.base_url:
        runtime_config.base_url = initial_config.base_url
    if not runtime_config.token:
        runtime_config.token = initial_config.token
    if not runtime_config.default_project_guid:
        runtime_config.default_project_guid = initial_config.default_project_guid

    resolved_project = str(
        project_guid or runtime_config.default_project_guid or initial_config.default_project_guid or ""
    ).strip() or None
    return runtime_config, resolved_project


def _token_fingerprint(token: str | None) -> str | None:
    cleaned = str(token or "").strip()
    if not cleaned:
        return None
    return hashlib.sha256(cleaned.encode("utf-8")).hexdigest()


def _decode_jwt_payload(token: str) -> dict[str, Any] | None:
    try:
        segments = str(token).split(".")
        if len(segments) != 3:
            return None
        payload_segment = segments[1]
        padded = payload_segment + "=" * ((4 - len(payload_segment) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8"))
        return decoded if isinstance(decoded, dict) else None
    except Exception:
        return None


def _token_expiration_epoch(token: str | None) -> int | None:
    payload = _decode_jwt_payload(str(token or ""))
    if not payload:
        return None
    raw_exp = payload.get("exp")
    try:
        exp_value = int(raw_exp)
    except (TypeError, ValueError):
        return None
    return exp_value if exp_value > 0 else None


def _is_token_expired(token: str | None, *, now_epoch: int | None = None, leeway_seconds: int = 30) -> bool:
    exp_epoch = _token_expiration_epoch(token)
    if exp_epoch is None:
        return False
    now_value = int(now_epoch if now_epoch is not None else time.time())
    return now_value >= (exp_epoch - max(0, int(leeway_seconds)))


def _load_lineage_auth_state(repo_root: Path) -> dict[str, Any]:
    path = lineage_auth_state_path(repo_root)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _save_lineage_auth_state(repo_root: Path, state: dict[str, Any]) -> None:
    path = lineage_auth_state_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=True, sort_keys=True), encoding="utf-8")


def _clear_lineage_auth_state(repo_root: Path) -> None:
    path = lineage_auth_state_path(repo_root)
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


def _is_auth_retry_paused_for_token(repo_root: Path, token: str | None, *, now_epoch: int | None = None) -> bool:
    fingerprint = _token_fingerprint(token)
    if not fingerprint:
        return False
    state = _load_lineage_auth_state(repo_root)
    if state.get("token_fingerprint") != fingerprint:
        return False
    try:
        pause_until = int(state.get("pause_until_epoch") or 0)
    except (TypeError, ValueError):
        return False
    now_value = int(now_epoch if now_epoch is not None else time.time())
    return pause_until > now_value


def _mark_auth_retry_paused(
    repo_root: Path,
    token: str | None,
    *,
    reason: str,
    now_epoch: int | None = None,
    cooldown_seconds: int = LINEAGE_AUTH_FAILURE_COOLDOWN_SECONDS,
) -> None:
    fingerprint = _token_fingerprint(token)
    if not fingerprint:
        return
    now_value = int(now_epoch if now_epoch is not None else time.time())
    state = _load_lineage_auth_state(repo_root)
    previous_failures = 0
    if state.get("token_fingerprint") == fingerprint:
        try:
            previous_failures = int(state.get("failure_count") or 0)
        except (TypeError, ValueError):
            previous_failures = 0
    pause_until = now_value + max(10, int(cooldown_seconds))
    _save_lineage_auth_state(
        repo_root,
        {
            "token_fingerprint": fingerprint,
            "reason": reason,
            "failure_count": previous_failures + 1,
            "last_failure_epoch": now_value,
            "pause_until_epoch": pause_until,
            "token_exp_epoch": _token_expiration_epoch(token),
        },
    )


def _sync_pending_events_with_fresh_auth(
    *,
    initial_config: CLIConfig,
    repo_root: Path,
    project_guid: str | None,
    runtime_env: str | None = None,
) -> None:
    runtime_config, resolved_project = _resolve_watch_runtime_config(
        initial_config=initial_config,
        project_guid=project_guid,
        runtime_env=runtime_env,
    )
    if pending_events_count(repo_root) <= 0:
        return
    runtime_config.token = maybe_refresh_bearer_token(runtime_config, force=False)
    basic_token_name, basic_token_secret = _lineage_basic_auth_credentials()
    has_basic_auth = bool(basic_token_name and basic_token_secret)
    has_bearer = bool(runtime_config.token)
    if not has_bearer and not has_basic_auth:
        return

    if not has_bearer and has_basic_auth:
        api = APIClient(
            base_url=runtime_config.base_url,
            token=runtime_config.token,
            token_refresher=lambda: maybe_refresh_bearer_token(runtime_config, force=True),
        )
        try:
            sync_events(
                config=runtime_config,
                api=api,
                repo_root=repo_root,
                project_guid=resolved_project,
                basic_token_name=basic_token_name,
                basic_token_secret=basic_token_secret,
                batch_size=100,
            )
        except APIError as exc:
            if exc.status_code == 400:
                # Project config mismatch — drop undeliverable events to stop the retry loop.
                _write_events(repo_root, [])
            else:
                raise
        _clear_lineage_auth_state(repo_root)
        return

    if _is_auth_retry_paused_for_token(repo_root, runtime_config.token):
        return
    if _is_token_expired(runtime_config.token):
        if has_basic_auth:
            api = APIClient(
                base_url=runtime_config.base_url,
                token=runtime_config.token,
                token_refresher=lambda: maybe_refresh_bearer_token(runtime_config, force=True),
            )
            sync_events(
                config=runtime_config,
                api=api,
                repo_root=repo_root,
                project_guid=resolved_project,
                basic_token_name=basic_token_name,
                basic_token_secret=basic_token_secret,
                batch_size=100,
            )
            _clear_lineage_auth_state(repo_root)
            return
        _mark_auth_retry_paused(
            repo_root,
            runtime_config.token,
            reason="token_expired_locally",
        )
        return

    api = APIClient(
        base_url=runtime_config.base_url,
        token=runtime_config.token,
        token_refresher=lambda: maybe_refresh_bearer_token(runtime_config, force=True),
    )
    try:
        sync_events(
            config=runtime_config,
            api=api,
            repo_root=repo_root,
            project_guid=resolved_project,
            batch_size=100,
        )
        _clear_lineage_auth_state(repo_root)
        return
    except APIError as exc:
        if exc.status_code not in {400, 401, 403}:
            raise
        if has_basic_auth:
            try:
                sync_events(
                    config=runtime_config,
                    api=api,
                    repo_root=repo_root,
                    project_guid=resolved_project,
                    basic_token_name=basic_token_name,
                    basic_token_secret=basic_token_secret,
                    batch_size=100,
                )
            except APIError as basic_exc:
                # 400 = project config mismatch (wrong project for this token). The
                # events cannot be delivered to any project with this auth combo — drop
                # them so the watcher doesn't loop forever on stale/misconfigured events.
                if basic_exc.status_code == 400:
                    _write_events(repo_root, [])
                else:
                    raise
            _clear_lineage_auth_state(repo_root)
            return

    previous_token = runtime_config.token
    refreshed_runtime_token = maybe_refresh_bearer_token(runtime_config, force=True)
    if refreshed_runtime_token and refreshed_runtime_token != previous_token:
        refreshed_api = APIClient(
            base_url=runtime_config.base_url,
            token=runtime_config.token,
            token_refresher=lambda: maybe_refresh_bearer_token(runtime_config, force=True),
        )
        try:
            sync_events(
                config=runtime_config,
                api=refreshed_api,
                repo_root=repo_root,
                project_guid=resolved_project,
                batch_size=100,
            )
            _clear_lineage_auth_state(repo_root)
            return
        except APIError as refresh_retry_exc:
            if refresh_retry_exc.status_code not in {401, 403}:
                raise
            if has_basic_auth:
                sync_events(
                    config=runtime_config,
                    api=refreshed_api,
                    repo_root=repo_root,
                    project_guid=resolved_project,
                    basic_token_name=basic_token_name,
                    basic_token_secret=basic_token_secret,
                    batch_size=100,
                )
                _clear_lineage_auth_state(repo_root)
                return

    refreshed_config, refreshed_project = _resolve_watch_runtime_config(
        initial_config=initial_config,
        project_guid=project_guid,
        runtime_env=runtime_env,
    )
    token_changed = bool(refreshed_config.token) and refreshed_config.token != runtime_config.token
    base_url_changed = refreshed_config.base_url != runtime_config.base_url
    if refreshed_config.token and (token_changed or base_url_changed):
        if _is_token_expired(refreshed_config.token):
            _mark_auth_retry_paused(
                repo_root,
                refreshed_config.token,
                reason="token_expired_after_refresh",
            )
            return
        refreshed_api = APIClient(
            base_url=refreshed_config.base_url,
            token=refreshed_config.token,
            token_refresher=lambda: maybe_refresh_bearer_token(refreshed_config, force=True),
        )
        try:
            sync_events(
                config=refreshed_config,
                api=refreshed_api,
                repo_root=repo_root,
                project_guid=refreshed_project,
                batch_size=100,
            )
            _clear_lineage_auth_state(repo_root)
            return
        except APIError as retry_exc:
            if retry_exc.status_code not in {401, 403}:
                raise
            if has_basic_auth:
                sync_events(
                    config=refreshed_config,
                    api=refreshed_api,
                    repo_root=repo_root,
                    project_guid=refreshed_project,
                    basic_token_name=basic_token_name,
                    basic_token_secret=basic_token_secret,
                    batch_size=100,
                )
                _clear_lineage_auth_state(repo_root)
                return
            _mark_auth_retry_paused(
                repo_root,
                refreshed_config.token,
                reason="unauthorized_after_refresh",
            )
            return

    if has_basic_auth:
        sync_events(
            config=runtime_config,
            api=api,
            repo_root=repo_root,
            project_guid=resolved_project,
            basic_token_name=basic_token_name,
            basic_token_secret=basic_token_secret,
            batch_size=100,
        )
        _clear_lineage_auth_state(repo_root)
        return

    _mark_auth_retry_paused(
        repo_root,
        runtime_config.token,
        reason="unauthorized_no_token_change",
    )
    return


def _lineage_basic_auth_credentials() -> tuple[str | None, str | None]:
    token_name = (
        os.getenv("LINEAGE_TOKEN_NAME")
        or os.getenv("SENSELAB_LINEAGE_TOKEN_NAME")
        or os.getenv("TOKEN_NAME")
        or ""
    ).strip()
    token_secret = (
        os.getenv("LINEAGE_TOKEN_SECRET")
        or os.getenv("SENSELAB_LINEAGE_TOKEN_SECRET")
        or os.getenv("TOKEN_SECRET")
        or ""
    ).strip()
    return (token_name or None, token_secret or None)


def _working_tree_snapshot(repo_root: Path) -> tuple[str, bool]:
    status = _run_git(
        ["git", "status", "--porcelain", "--untracked-files=all"],
        cwd=repo_root,
    )
    raw_status = status if isinstance(status, str) else ""
    digest = hashlib.sha256(raw_status.encode("utf-8")).hexdigest()
    return digest, bool(raw_status.strip())


def _infer_repo_full_name(repo_root: Path) -> str | None:
    remote = _run_git(["git", "config", "--get", "remote.origin.url"], cwd=repo_root)
    if not remote:
        return None
    remote = remote.strip()

    ssh_match = re.search(r"[:/]([^/:\s]+)/([^/\s]+?)(?:\.git)?$", remote)
    if ssh_match:
        return f"{ssh_match.group(1)}/{ssh_match.group(2)}"
    return None


def _read_cursor_context_hints(repo_root: Path) -> dict[str, Any]:
    cursor_dir = repo_root / ".cursor"
    if not cursor_dir.exists():
        return {}
    candidates = (
        cursor_dir / "session.json",
        cursor_dir / "agent-session.json",
        cursor_dir / "agent-state.json",
        cursor_dir / "metadata.json",
    )
    merged: dict[str, Any] = {}
    for candidate in candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            parsed = json.loads(candidate.read_text(encoding="utf-8", errors="ignore") or "{}")
        except json.JSONDecodeError:
            continue
        hints = _extract_lineage_hints_from_payload(parsed)
        for key in ("tool", "provider", "model", "session_id"):
            if not merged.get(key) and hints.get(key):
                merged[key] = hints[key]
    return merged


def _read_cursor_recent_commit_hints(
    *,
    repo_root: Path,
    repo_full_name: str | None,
    branch: str | None,
    head_sha: str | None,
) -> dict[str, Any]:
    state_db_env = os.getenv("CURSOR_STATE_VSCDB_PATH")
    state_db = (
        Path(state_db_env).expanduser()
        if state_db_env
        else Path.home() / "Library" / "Application Support" / "Cursor" / "User" / "globalStorage" / "state.vscdb"
    )
    if not state_db.exists():
        return {}

    try:
        with sqlite3.connect(str(state_db)) as conn:
            row = conn.execute(
                "SELECT value FROM ItemTable WHERE key = ? LIMIT 1",
                ("aiCodeTracking.recentCommit",),
            ).fetchone()
    except Exception:
        return {}

    if not row or not row[0]:
        return {}
    try:
        payload = json.loads(str(row[0]))
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}

    commit_hash = str(payload.get("commitHash") or "").strip() or None
    repo_name = str(payload.get("repoName") or "").strip() or None
    branch_name = str(payload.get("branchName") or "").strip() or None

    # Hard reject: data clearly belongs to a different repo — wrong project entirely.
    if repo_full_name and repo_name and repo_full_name != repo_name:
        return {}

    # Soft match: repo matches, branch matches → accept even without a commit hash
    # match.  Cursor writes aiCodeTracking.recentCommit *asynchronously* after a
    # commit, so the pre-push hook almost always fires before the write completes.
    # Requiring an exact hash match would therefore always return empty on push,
    # which is exactly when we want the data.
    repo_matches = not repo_full_name or not repo_name or repo_full_name == repo_name
    branch_matches = not branch or not branch_name or branch == branch_name
    hash_matches = not head_sha or not commit_hash or head_sha == commit_hash

    if not repo_matches:
        return {}

    # If we have a hash match, great.  If not, still use the data when the
    # repo+branch context makes it clear we're looking at the right project —
    # the mismatch is almost certainly a write-ordering race, not stale data
    # from a different session.
    if not hash_matches and not branch_matches:
        # Different branch AND different hash → genuinely stale, skip.
        return {}

    try:
        ai_percentage_value = float(str(payload.get("aiPercentage") or "").replace("%", "").strip())
    except (TypeError, ValueError):
        ai_percentage_value = None

    try:
        lines_added = int(payload.get("linesAdded") or 0)
    except (TypeError, ValueError):
        lines_added = 0
    try:
        lines_deleted = int(payload.get("linesDeleted") or 0)
    except (TypeError, ValueError):
        lines_deleted = 0

    hints: dict[str, Any] = {
        "tool": "cursor",
        "provider": "cursor",
        "model": _normalize_model_hint(
            str(
                payload.get("model")
                or payload.get("modelName")
                or payload.get("activeModel")
                or payload.get("currentModel")
                or ""
            ).strip()
        ),
        "session_id": str(payload.get("timestamp") or "").strip() or None,
        "repo_name": repo_name,
        "branch_name": branch_name,
        "commit_hash": commit_hash,
        "ai_percentage": ai_percentage_value,
        "lines_added": lines_added,
        "lines_deleted": lines_deleted,
        "composer_lines_added": payload.get("composerLinesAdded"),
        "composer_lines_deleted": payload.get("composerLinesDeleted"),
        "tab_lines_added": payload.get("tabLinesAdded"),
        "tab_lines_deleted": payload.get("tabLinesDeleted"),
    }
    return hints


def _normalize_model_hint(model: str | None) -> str | None:
    value = str(model or "").strip()
    if not value:
        return None
    lowered = value.lower()
    # Explicit junk / sentinel values
    if lowered in {
        "default", "unknown", "unknown-model", "none", "n/a", "na",
        # Cursor tab-completion model identifier — not an agentic LLM
        "tab", "cursor-tab",
        # Other non-model garbage
        "true", "false", "1", "0",
    }:
        return None
    # Very short values (1-2 chars) are almost certainly not model names
    if len(lowered) <= 2:
        return None
    return value


def _extract_hook_payload_hints(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict) or not payload:
        return {}
    hints = _extract_lineage_hints_from_payload(payload)
    model = _normalize_model_hint(hints.get("model"))
    session_id = (
        str(
            hints.get("session_id")
            or payload.get("conversation_id")
            or payload.get("session_id")
            or payload.get("generation_id")
            or ""
        ).strip()
        or None
    )
    tool = str(hints.get("tool") or "").strip().lower() or "cursor"
    provider = str(hints.get("provider") or tool).strip().lower() or tool
    return {
        "tool": tool,
        "provider": provider,
        "model": model,
        "session_id": session_id,
    }


def _cursor_project_dir_name(repo_root: Path) -> str:
    raw = str(repo_root).lstrip("/")
    return re.sub(r"[^A-Za-z0-9]", "-", raw)


def _read_cursor_transcript_hints(repo_root: Path) -> dict[str, Any]:
    custom = os.getenv("CURSOR_AGENT_TRANSCRIPTS_DIR")
    if custom:
        transcript_root = Path(custom).expanduser()
    else:
        transcript_root = CURSOR_TRANSCRIPTS_ROOT / _cursor_project_dir_name(repo_root) / "agent-transcripts"
    if not transcript_root.exists() or not transcript_root.is_dir():
        return {}

    try:
        candidates = sorted(
            [path for path in transcript_root.rglob("*.jsonl") if path.is_file()],
            key=lambda item: item.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return {}
    if not candidates:
        return {}

    for transcript_path in candidates[:30]:
        records = _read_jsonl_records(transcript_path, max_lines=200)
        if not records:
            continue
        for record in reversed(records):
            hints = _extract_lineage_hints_from_payload(record)
            model_hint = _normalize_model_hint(hints.get("model"))
            session_hint = str(hints.get("session_id") or "").strip() or None
            if model_hint:
                return {
                    "tool": str(hints.get("tool") or "cursor").strip() or "cursor",
                    "provider": str(hints.get("provider") or "cursor").strip() or "cursor",
                    "model": model_hint,
                    "session_id": session_hint,
                    "transcript_path": str(transcript_path),
                }
    return {}


def _read_jsonl_records(path: Path, max_lines: int = 200) -> list[dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return []
    rows: list[dict[str, Any]] = []
    for raw_line in lines[-max_lines:]:
        line = raw_line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        if isinstance(parsed, dict):
            rows.append(parsed)
    return rows


def _cursor_hooks_path(repo_root: Path) -> Path:
    return repo_root / ".cursor" / LINEAGE_CURSOR_HOOKS_FILE


_CURSOR_HOOKS_WITH_SYNC = frozenset({"stop", "session-end", "subagent-stop"})


def _cursor_capture_command(repo_root: Path, hook_name: str) -> str:
    cli_bin = _resolve_sense_cli_binary()
    # Cursor project hooks run from the project root, so --repo is unnecessary.
    # Avoid shell quoting edge cases in hook runners by relying on cwd resolution.
    capture = f"{cli_bin} --quiet lineage capture --hook cursor-{hook_name}"
    if hook_name in _CURSOR_HOOKS_WITH_SYNC:
        # After the agent finishes, fire a background sync so the dashboard
        # updates in near-real-time without waiting for the next daemon cycle.
        sync = f"{cli_bin} --quiet lineage sync"
        return f"{capture} && ({sync} &)"
    return capture


def _resolve_sense_cli_binary() -> str:
    override = str(os.getenv("SENSE_CLI_BIN") or "").strip()
    if override:
        candidate = Path(override).expanduser()
        if candidate.exists():
            return str(candidate)
        return override

    resolved = shutil.which("sense-cli")
    if resolved:
        return str(Path(resolved).expanduser())

    argv0 = str(sys.argv[0] or "").strip()
    if argv0:
        candidate = Path(argv0).expanduser()
        if candidate.exists() and "sense-cli" in candidate.name:
            return str(candidate)
    return "sense-cli"


def _install_cursor_lineage_hooks(repo_root: Path) -> bool:
    cursor_dir = repo_root / ".cursor"
    cursor_dir.mkdir(parents=True, exist_ok=True)
    hooks_path = _cursor_hooks_path(repo_root)
    payload: dict[str, Any] = {"version": 1, "hooks": {}}
    if hooks_path.exists():
        try:
            existing = json.loads(hooks_path.read_text(encoding="utf-8", errors="ignore") or "{}")
            if isinstance(existing, dict):
                payload = existing
        except (TypeError, ValueError, json.JSONDecodeError):
            payload = {"version": 1, "hooks": {}}
    if not isinstance(payload.get("hooks"), dict):
        payload["hooks"] = {}
    payload["version"] = int(payload.get("version") or 1)

    changed = False
    hooks_obj: dict[str, Any] = payload["hooks"]
    for cursor_key, hook_name in CURSOR_HOOK_MAP.items():
        entries = hooks_obj.get(cursor_key)
        if not isinstance(entries, list):
            entries = []
        command = _cursor_capture_command(repo_root, hook_name)
        filtered_entries = [
            item
            for item in entries
            if not _is_cursor_lineage_capture_command(item, hook_name)
        ]
        if len(filtered_entries) != len(entries):
            changed = True
        exists = any(
            isinstance(item, dict) and str(item.get("command") or "").strip() == command
            for item in filtered_entries
        )
        if not exists:
            filtered_entries.append({"command": command})
            changed = True
        hooks_obj[cursor_key] = filtered_entries

    if changed:
        hooks_path.parent.mkdir(parents=True, exist_ok=True)
        hooks_path.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return changed


def _remove_cursor_lineage_hooks(repo_root: Path) -> bool:
    hooks_path = _cursor_hooks_path(repo_root)
    if not hooks_path.exists():
        return False
    try:
        payload = json.loads(hooks_path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        return False
    if not isinstance(payload, dict) or not isinstance(payload.get("hooks"), dict):
        return False
    hooks_obj: dict[str, Any] = payload["hooks"]
    changed = False
    for cursor_key, hook_name in CURSOR_HOOK_MAP.items():
        entries = hooks_obj.get(cursor_key)
        if not isinstance(entries, list):
            continue
        filtered = [
            item
            for item in entries
            if not _is_cursor_lineage_capture_command(item, hook_name)
        ]
        if len(filtered) != len(entries):
            changed = True
        if filtered:
            hooks_obj[cursor_key] = filtered
        else:
            hooks_obj.pop(cursor_key, None)
    if not changed:
        return False
    hooks_path.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return True


def _is_cursor_lineage_capture_command(item: Any, hook_name: str) -> bool:
    if not isinstance(item, dict):
        return False
    command = str(item.get("command") or "").strip()
    if not command:
        return False
    expected_fragment = f"--hook cursor-{hook_name}"
    return (
        "lineage capture" in command
        and "sense-cli" in command
        and expected_fragment in command
    )


def _extract_lineage_hints_from_payload(payload: Any) -> dict[str, str]:
    hints: dict[str, str] = {}

    def _walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for raw_key, raw_val in value.items():
                key = str(raw_key).strip()
                lowered = key.lower()
                path = f"{key_path}.{lowered}" if key_path else lowered
                if isinstance(raw_val, str) and raw_val.strip():
                    val = raw_val.strip()
                    if lowered in {"tool", "agent", "client"} and not hints.get("tool"):
                        hints["tool"] = val
                    elif lowered in {"provider", "model_provider", "modelprovider"} and not hints.get("provider"):
                        hints["provider"] = val
                    elif lowered in {"model", "model_name", "modelname", "activemodel", "currentmodel"} and not hints.get("model"):
                        normalized_model = _normalize_model_hint(val)
                        if normalized_model:
                            hints["model"] = normalized_model
                    elif (
                        lowered in {"session_id", "sessionid", "conversation_id", "conversationid", "checkpoint_id"}
                        or "session" in path
                    ) and not hints.get("session_id"):
                        hints["session_id"] = val
                if isinstance(raw_val, (dict, list)):
                    _walk(raw_val, path)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, (dict, list)):
                    _walk(item, key_path)

    _walk(payload)
    if not hints.get("tool"):
        hints["tool"] = "cursor"
    return hints


def _infer_lineage_from_commit_metadata(
    *,
    repo_root: Path,
    head_sha: str | None,
    commit_msg_file: str | None,
) -> dict[str, Any]:
    message = _read_commit_message(
        repo_root=repo_root,
        head_sha=head_sha,
        commit_msg_file=commit_msg_file,
    )
    if not message:
        return {}
    trailers = _extract_commit_trailers(message)
    if not trailers:
        return {}
    return {
        "tool": trailers.get("ai_tool"),
        "provider": trailers.get("ai_provider"),
        "model": trailers.get("ai_model"),
        "session_id": trailers.get("ai_session_id"),
        "trailers": trailers,
    }


def _read_commit_message(
    *,
    repo_root: Path,
    head_sha: str | None,
    commit_msg_file: str | None,
) -> str | None:
    if commit_msg_file:
        candidate = Path(commit_msg_file)
        if not candidate.is_absolute():
            candidate = repo_root / candidate
        try:
            if candidate.exists():
                return candidate.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None
    commit_ref = head_sha or "HEAD"
    return _run_git(["git", "log", "-1", "--format=%B", commit_ref], cwd=repo_root)


def _extract_commit_trailers(message: str) -> dict[str, str]:
    if not message:
        return {}
    trailers: dict[str, str] = {}
    for raw_line in message.splitlines():
        line = raw_line.strip()
        if not line or ":" not in line:
            continue
        match = re.match(r"^([A-Za-z0-9][A-Za-z0-9 _-]{0,80}):\s*(.+)$", line)
        if not match:
            continue
        key = match.group(1).strip().lower().replace("_", "-").replace(" ", "-")
        value = match.group(2).strip()
        if not value:
            continue
        if key in {"ai-model", "x-ai-model", "llm-model", "model"}:
            trailers["ai_model"] = value
        elif key in {"ai-provider", "x-ai-provider", "llm-provider", "provider"}:
            trailers["ai_provider"] = value
        elif key in {"ai-tool", "x-ai-tool", "tool", "generated-by"}:
            trailers["ai_tool"] = value
        elif key in {"ai-session-id", "x-ai-session-id", "session-id", "ai-session"}:
            trailers["ai_session_id"] = value
    return trailers


def _shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\"'\"'") + "'"
