"""Core logic for `sense-cli review` — local AI code review.

Provides:
- .senselab.yml parsing
- Specialist resolution (layered: arg > name > yaml > server binding > project default)
- Git diff capture (staged / unstaged / since-branch / commit-range)
- Polling loop for backend review completion
- Output renderers: rich (default), plain, prompt-only, json
- Interactive --fix: apply suggested_fix patches
- `setup` subcommand: guided .senselab.yml creation
- `install-hook` / `uninstall-hook`: pre-commit / pre-push gate management
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import yaml

from cli.api import APIClient, APIError

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SENSELAB_YML_NAME = ".senselab.yml"
SENSELAB_SCHEMA_COMMENT = (
    "# yaml-language-server: $schema=https://api.raia.live/api/cli/schema/senselab.json\n"
)
_POLL_INITIAL_SLEEP = 2.0
_POLL_MAX_SLEEP = 8.0
_POLL_TIMEOUT = 300
_TERMINAL_STATUSES = {"COMPLETED", "FAILED", "TIMED_OUT"}
_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
_SEVERITY_COLORS = {
    "critical": "\033[1;31m",  # bold red
    "high": "\033[31m",  # red
    "medium": "\033[33m",  # yellow
    "low": "\033[36m",  # cyan
    "info": "\033[90m",  # gray
}
_RESET = "\033[0m"

# Marker block identifiers for hook injection
_REVIEW_HOOK_MARKER_START = "# >>> senselab-review >>>"
_REVIEW_HOOK_MARKER_END = "# <<< senselab-review <<<"


# ---------------------------------------------------------------------------
# .senselab.yml helpers
# ---------------------------------------------------------------------------


def find_senselab_yml(repo_root: Path | None = None) -> Path | None:
    """Search for .senselab.yml starting from repo_root (or cwd)."""
    start = repo_root or Path.cwd()
    candidate = start / SENSELAB_YML_NAME
    return candidate if candidate.exists() else None


def load_senselab_yml(path: Path) -> dict[str, Any]:
    """Parse .senselab.yml and return its content, defaulting to {}."""
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
        parsed = yaml.safe_load(content)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def get_review_config(yml_data: dict[str, Any]) -> dict[str, Any]:
    """Extract the review: block from parsed .senselab.yml."""
    return yml_data.get("review", {}) or {}


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------


def _run_git(args: list[str], cwd: Path | None = None) -> str | None:
    try:
        result = subprocess.run(
            args,
            cwd=str(cwd or Path.cwd()),
            capture_output=True,
            text=True,
            check=False,
        )
        return result.stdout.strip() or None
    except Exception:
        return None


def resolve_repo_root(path: str | None = None) -> Path:
    cwd = Path(path) if path else Path.cwd()
    top = _run_git(["git", "rev-parse", "--show-toplevel"], cwd=cwd)
    return Path(top) if top else cwd


def infer_repo_full_name(repo_root: Path) -> str | None:
    remote = _run_git(["git", "config", "--get", "remote.origin.url"], cwd=repo_root)
    if not remote:
        return None
    match = re.search(r"[:/]([^/:\s]+)/([^/\s]+?)(?:\.git)?$", remote.strip())
    return f"{match.group(1)}/{match.group(2)}" if match else None


def get_current_branch(repo_root: Path) -> str:
    return _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root) or "unknown"


def get_head_sha(repo_root: Path) -> str | None:
    return _run_git(["git", "rev-parse", "HEAD"], cwd=repo_root)


def capture_diff(
    scope: str,
    base_branch: str = "origin/main",
    repo_root: Path | None = None,
) -> tuple[str, list[str], int]:
    """Return (diff_text, changed_files, diff_lines).

    scope values: staged | unstaged | since-branch | commit-range
    base_branch: branch to diff against for since-branch scope
    """
    root = repo_root or Path.cwd()

    if scope == "staged":
        diff = _run_git(["git", "diff", "--cached"], cwd=root) or ""
        files_raw = _run_git(["git", "diff", "--cached", "--name-only"], cwd=root) or ""
    elif scope == "unstaged":
        diff = _run_git(["git", "diff"], cwd=root) or ""
        files_raw = _run_git(["git", "diff", "--name-only"], cwd=root) or ""
    else:
        # since-branch (default): diff current HEAD against base_branch
        merge_base = _run_git(["git", "merge-base", base_branch, "HEAD"], cwd=root)
        if not merge_base:
            diff = _run_git(["git", "diff", base_branch], cwd=root) or ""
            files_raw = _run_git(["git", "diff", "--name-only", base_branch], cwd=root) or ""
        else:
            diff = _run_git(["git", "diff", merge_base, "HEAD"], cwd=root) or ""
            files_raw = _run_git(["git", "diff", "--name-only", merge_base, "HEAD"], cwd=root) or ""

    changed_files = [f for f in (files_raw or "").splitlines() if f.strip()]
    diff_lines = len((diff or "").splitlines())
    return diff or "", changed_files, diff_lines


# ---------------------------------------------------------------------------
# Specialist resolution (CLI-side, using API)
# ---------------------------------------------------------------------------


def resolve_specialist(
    client: APIClient,
    project_guid: str,
    repo_full_name: str | None,
    yml_config: dict[str, Any],
    assistant_arg: str | None = None,
    specialist_guid_arg: str | None = None,
) -> dict[str, Any]:
    """Resolve the Review specialist using the layered resolution order.

    Order:
    1. --specialist GUID flag
    2. Positional ASSISTANT_NAME argument
    3. .senselab.yml review.assistant / review.assistant_guid
    4. Server-side binding (GitHubRepoBinding for this repo)
    5. Project-level default Review assistant
    """
    resolved_guid = specialist_guid_arg or yml_config.get("assistant_guid")
    resolved_name = assistant_arg or yml_config.get("assistant")

    data = client.resolve_review_specialist(
        project_guid=project_guid,
        repo_full_name=repo_full_name,
        assistant_name=resolved_name,
        assistant_guid=resolved_guid,
    )
    specialist = data.get("specialist")
    if not specialist:
        raise APIError(
            "No Review assistant found for this project. "
            "Create one at app.raia.live or run `sense-cli review setup`.",
            suggestion="Run `sense-cli review setup` to configure this repository.",
        )
    return specialist


# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------


def poll_review_run(
    client: APIClient,
    review_id: str,
    min_severity: str | None = None,
    quiet: bool = False,
    use_color: bool = True,
) -> dict[str, Any]:
    """Block until the review run reaches a terminal state, return final payload."""
    sleep = _POLL_INITIAL_SLEEP
    deadline = time.monotonic() + _POLL_TIMEOUT

    while True:
        data = client.get_review_status(review_id, min_severity=min_severity)
        status = data.get("status", "")
        if status in _TERMINAL_STATUSES:
            return data

        if time.monotonic() >= deadline:
            raise APIError(
                "Timed out waiting for review to complete.",
                suggestion="The backend may be busy. Try again in a moment.",
            )

        if not quiet:
            _print_spinner(f"Review running… (status: {status})", use_color=use_color)

        time.sleep(sleep)
        sleep = min(sleep * 1.5, _POLL_MAX_SLEEP)

    return data  # unreachable but appeases type checkers


def _print_spinner(msg: str, use_color: bool = True) -> None:
    frames = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
    idx = int(time.time() * 5) % len(frames)
    sys.stderr.write(f"\r{frames[idx]}  {msg}   ")
    sys.stderr.flush()


# ---------------------------------------------------------------------------
# Output renderers
# ---------------------------------------------------------------------------


def render_rich(run: dict[str, Any], use_color: bool = True) -> str:
    """Human-friendly coloured terminal output."""
    lines: list[str] = []
    status = run.get("status", "")
    repo = run.get("repository_full_name") or "—"
    branch = run.get("branch") or "—"
    findings = run.get("findings") or []

    _hr = "─" * 60
    lines.append(_hr)
    lines.append(f"  SenseLab Local Review  ·  {repo}  ·  {branch}")
    lines.append(_hr)

    if status == "FAILED":
        msg = run.get("status_message") or "Review failed."
        lines.append(f"  ✗  {msg}")
        return "\n".join(lines)

    total = run.get("finding_count_total") or 0
    critical = run.get("finding_count_critical") or 0
    high = run.get("finding_count_high") or 0
    medium = run.get("finding_count_medium") or 0
    low = run.get("finding_count_low") or 0

    if total == 0:
        lines.append("  ✓  No issues found — clean diff!")
        lines.append(_hr)
        return "\n".join(lines)

    lines.append(
        f"  Found {total} issue(s):  "
        f"critical={critical}  high={high}  medium={medium}  low={low}"
    )
    lines.append(_hr)

    for i, f in enumerate(findings, start=1):
        sev = f.get("severity", "info")
        col = _SEVERITY_COLORS.get(sev, "") if use_color else ""
        rst = _RESET if use_color else ""
        file_loc = f.get("file_path") or "—"
        if f.get("line"):
            file_loc = f"{file_loc}:{f['line']}"
        lines.append(
            f"\n  {i}. {col}[{sev.upper()}]{rst}  {f.get('title', '(untitled)')}"
        )
        lines.append(f"     {file_loc}")
        body = (f.get("body") or "").strip()
        if body:
            for bline in body.splitlines():
                lines.append(f"     {bline}")
        if f.get("suggested_fix"):
            lines.append(f"     {col}Suggested fix available (use --fix to apply){rst}")
        lines.append(f"     ID: {f.get('id', '')}")

    lines.append(_hr)
    return "\n".join(lines)


def render_plain(run: dict[str, Any]) -> str:
    """Machine-readable plain text — useful for piping to other tools."""
    lines: list[str] = []
    for f in run.get("findings") or []:
        file_loc = f.get("file_path") or "-"
        if f.get("line"):
            file_loc = f"{file_loc}:{f['line']}"
        lines.append(
            f"[{(f.get('severity') or 'info').upper()}] {f.get('title', '')} | {file_loc}"
        )
        body = (f.get("body") or "").strip()
        if body:
            lines.append(f"  {body}")
        if f.get("suggested_fix"):
            lines.append(f"  FIX:\n{f['suggested_fix']}")
        lines.append(f"  finding_id={f.get('id', '')}")
    if not lines:
        lines.append("No issues found.")
    return "\n".join(lines)


def render_prompt_only(run: dict[str, Any]) -> str:
    """Minimal token-efficient format for AI agent consumption."""
    findings = run.get("findings") or []
    if not findings:
        return "REVIEW_RESULT: no_issues"
    parts = ["REVIEW_RESULT: issues_found"]
    for f in findings:
        sev = (f.get("severity") or "info").upper()
        title = f.get("title") or ""
        fix_hint = " [FIX_AVAILABLE]" if f.get("suggested_fix") else ""
        parts.append(f"- [{sev}] {title}{fix_hint} id={f.get('id', '')}")
    return "\n".join(parts)


def render_json(run: dict[str, Any]) -> str:
    return json.dumps(run, indent=2)


# ---------------------------------------------------------------------------
# Patch application (--fix)
# ---------------------------------------------------------------------------


def apply_fixes_interactive(
    run: dict[str, Any],
    client: APIClient,
    repo_root: Path,
    use_color: bool = True,
) -> int:
    """Walk through findings that have suggested_fix and offer to apply each.

    Returns number of patches applied.
    """
    applied = 0
    findings = [f for f in (run.get("findings") or []) if f.get("suggested_fix")]
    if not findings:
        print("No suggested fixes available.")
        return 0

    for i, f in enumerate(findings, start=1):
        sev = (f.get("severity") or "info").upper()
        title = f.get("title") or "(untitled)"
        col = _SEVERITY_COLORS.get(f.get("severity", ""), "") if use_color else ""
        rst = _RESET if use_color else ""
        print(f"\n{i}/{len(findings)}  {col}[{sev}]{rst}  {title}")
        print(f"  File: {f.get('file_path') or '—'}")

        fix_patch = f["suggested_fix"]
        print("\n--- suggested fix ---")
        print(fix_patch)
        print("---")

        try:
            choice = input("Apply this fix? [y/n/q] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            break

        if choice == "q":
            break
        if choice == "y":
            success = _apply_patch(fix_patch, repo_root)
            action = "applied_fix" if success else "ignored"
            if success:
                print("  ✓  Patch applied.")
                applied += 1
            else:
                print("  ✗  Failed to apply patch. Skipping.")
            _try_record_action(client, f.get("id"), action)
        else:
            _try_record_action(client, f.get("id"), "dismissed")
            print("  Dismissed.")

    return applied


def _apply_patch(patch: str, repo_root: Path) -> bool:
    """Attempt to apply a unified diff patch via `git apply`."""
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".patch", delete=False, encoding="utf-8"
        ) as tmp:
            tmp.write(patch)
            tmp_path = tmp.name
        result = subprocess.run(
            ["git", "apply", "--check", tmp_path],
            cwd=str(repo_root),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return False
        subprocess.run(
            ["git", "apply", tmp_path],
            cwd=str(repo_root),
            check=True,
            capture_output=True,
        )
        return True
    except Exception:
        return False
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


def _try_record_action(client: APIClient, finding_id: str | None, action: str) -> None:
    if not finding_id:
        return
    try:
        client.record_finding_action(finding_id, action)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Git hook installation
# ---------------------------------------------------------------------------

_REVIEW_HOOK_BLOCK_TEMPLATE = """\
{start_marker}
# sense-cli review hook — do not edit manually
_REVIEW_SCOPE="{scope}"
_REVIEW_BLOCK_ON="{block_on}"
_HOOK_TYPE="{hook_type}"

if command -v sense-cli >/dev/null 2>&1; then
  sense-cli review \\
    --scope "$_REVIEW_SCOPE" \\
    --trigger-source "$_HOOK_TYPE" \\
    --block-on "$_REVIEW_BLOCK_ON" \\
    --quiet \\
    --exit-code 2>&1
  _rc=$?
  if [ "$_rc" -ne 0 ]; then
    echo "[senselab] Review found blocking issues (exit $_rc). Commit aborted." >&2
    exit "$_rc"
  fi
fi
{end_marker}
"""


def build_review_hook_block(hook_type: str, scope: str, block_on: str) -> str:
    return _REVIEW_HOOK_BLOCK_TEMPLATE.format(
        start_marker=_REVIEW_HOOK_MARKER_START,
        end_marker=_REVIEW_HOOK_MARKER_END,
        scope=scope,
        block_on=block_on,
        hook_type=hook_type,
    )


def _replace_review_marker_block(content: str, block: str) -> str:
    pattern = re.compile(
        rf"{re.escape(_REVIEW_HOOK_MARKER_START)}.*?{re.escape(_REVIEW_HOOK_MARKER_END)}",
        re.DOTALL,
    )
    if pattern.search(content):
        return pattern.sub(block.strip(), content)
    return content.rstrip() + "\n\n" + block.strip() + "\n"


def _remove_review_marker_block(content: str) -> tuple[str, bool]:
    pattern = re.compile(
        rf"\n?{re.escape(_REVIEW_HOOK_MARKER_START)}.*?{re.escape(_REVIEW_HOOK_MARKER_END)}\n?",
        re.DOTALL,
    )
    updated, count = pattern.subn("", content)
    return updated, count > 0


def install_review_hook(
    repo_root: Path,
    hook_type: str = "pre-commit",
    scope: str = "staged",
    block_on: str = "high",
) -> None:
    """Write the sense-cli review gate block into .git/hooks/<hook_type>."""
    hooks_dir = repo_root / ".git" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_path = hooks_dir / hook_type
    existing = hook_path.read_text(encoding="utf-8", errors="ignore") if hook_path.exists() else ""
    block = build_review_hook_block(hook_type=hook_type, scope=scope, block_on=block_on)
    updated = _replace_review_marker_block(existing, block)
    if not updated.startswith("#!"):
        updated = "#!/usr/bin/env sh\nset -e\n\n" + updated
    hook_path.write_text(updated, encoding="utf-8")
    hook_path.chmod(0o755)


def uninstall_review_hook(
    repo_root: Path,
    hook_type: str = "pre-commit",
) -> bool:
    """Remove the sense-cli review block from .git/hooks/<hook_type>."""
    hook_path = repo_root / ".git" / "hooks" / hook_type
    if not hook_path.exists():
        return False
    content = hook_path.read_text(encoding="utf-8", errors="ignore")
    updated, changed = _remove_review_marker_block(content)
    if not changed:
        return False
    if not updated.strip():
        updated = "#!/usr/bin/env sh\nset -e\n"
    hook_path.write_text(updated, encoding="utf-8")
    return True


# ---------------------------------------------------------------------------
# `sense-cli review setup` — interactive .senselab.yml wizard
# ---------------------------------------------------------------------------


def run_setup(
    client: APIClient,
    project_guid: str,
    repo_root: Path,
    use_color: bool = True,
) -> int:
    """Interactive wizard to create/update .senselab.yml."""
    print("\n  SenseLab Review Setup Wizard\n")

    yml_path = repo_root / SENSELAB_YML_NAME
    existing = load_senselab_yml(yml_path) if yml_path.exists() else {}
    rc = existing.get("review", {}) or {}

    # -- Fetch available Review assistants --
    try:
        data = client.resolve_review_specialist(
            project_guid=project_guid,
            repo_full_name=infer_repo_full_name(repo_root),
        )
        default_assistant = (data.get("specialist") or {}).get("name", "")
    except APIError:
        default_assistant = rc.get("assistant", "")

    print("  Enter your Review assistant name (press Enter to keep default):")
    print(f"  [current: {rc.get('assistant') or default_assistant or 'none'}]")
    assistant = input("  Assistant name: ").strip() or rc.get("assistant") or default_assistant

    print("\n  Severity threshold (critical/high/medium/low/info) [default: medium]:")
    severity = input("  Threshold: ").strip().lower() or rc.get("severity_threshold", "medium")
    if severity not in _SEVERITY_ORDER:
        severity = "medium"

    print("\n  Default diff scope (staged/unstaged/since-branch) [default: since-branch]:")
    scope = input("  Scope: ").strip().lower() or rc.get("scope", "since-branch")
    if scope not in ("staged", "unstaged", "since-branch"):
        scope = "since-branch"

    print("\n  Base branch for since-branch scope [default: origin/main]:")
    base_branch = input("  Base branch: ").strip() or rc.get("base_branch", "origin/main")

    print("\n  Enable pre-commit hook? (y/n) [default: n]:")
    pre_commit = (input("  ").strip().lower() or "n") == "y"
    block_on = "high"
    if pre_commit:
        print("  Block commit on severity (critical/high/medium) [default: high]:")
        block_on = input("  Block on: ").strip().lower() or "high"
        if block_on not in ("critical", "high", "medium", "low"):
            block_on = "high"

    print("\n  Enable pre-push hook? (y/n) [default: n]:")
    pre_push = (input("  ").strip().lower() or "n") == "y"
    push_block_on = "critical"
    if pre_push:
        print("  Block push on severity (critical/high) [default: critical]:")
        push_block_on = input("  Block on: ").strip().lower() or "critical"
        if push_block_on not in ("critical", "high", "medium", "low"):
            push_block_on = "critical"

    # Build YAML content
    review_block: dict[str, Any] = {
        "assistant": assistant,
        "severity_threshold": severity,
        "scope": scope,
        "base_branch": base_branch,
        "output": rc.get("output", "rich"),
    }
    if pre_commit or pre_push:
        hooks: dict[str, Any] = {}
        if pre_commit:
            hooks["pre_commit"] = {
                "enabled": True,
                "scope": "staged",
                "block_on": block_on,
            }
        if pre_push:
            hooks["pre_push"] = {
                "enabled": True,
                "scope": "since-branch",
                "block_on": push_block_on,
            }
        review_block["hooks"] = hooks

    config: dict[str, Any] = {"version": "1", "review": review_block}
    content = SENSELAB_SCHEMA_COMMENT + yaml.dump(config, default_flow_style=False, sort_keys=False)
    yml_path.write_text(content, encoding="utf-8")
    print(f"\n  ✓  Written to {yml_path}")

    # Install hooks
    if pre_commit:
        install_review_hook(repo_root, hook_type="pre-commit", scope="staged", block_on=block_on)
        print("  ✓  pre-commit hook installed.")
    if pre_push:
        install_review_hook(
            repo_root, hook_type="pre-push", scope="since-branch", block_on=push_block_on
        )
        print("  ✓  pre-push hook installed.")

    print("\n  Next step: commit .senselab.yml so your team uses the same settings.")
    return 0
