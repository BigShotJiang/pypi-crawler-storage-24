# Tests for importing MCK matrices into OpenIRF
# Covered functions:
# - add_MCK
# - __init__ (where applicable to MCK import)

import openirf
import numpy as np
import pytest

# Test Variables
M_test = np.array([[4, 2], [2, 4]])
K_test = np.array([[2, -1], [-1, 2]])
C_test = np.array([[1, -0.5], [-0.5, 1]])
M_test2 = np.array([[4, 2, 0], [2, 4, 0]])
K_test2 = np.array([[2, -1, 0], [-1, 2, 0]])
C_test2 = np.array([[1, -0.5, 0], [-0.5, 1, 0]])
M_test3 = np.array([[4, 2, 0], [2, 4, 2], [0, 2, 4]])
K_test3 = np.array([[2, -1, 0], [-1, 2, -1], [0, -1, 2]])
C_test3 = np.array([[1, -0.5, 0], [-0.5, 1, -0.5], [0, -0.5, 1]])
oned_matrix = np.array([1])
threed_matrix = np.array([[[1]]])


def test_MK_import_during_instantiation():
    IRF_ob = openirf.NumericalIRF(M=M_test, K=K_test)  # Create OpenIRF object instance
    assert np.array_equal(IRF_ob.M, M_test), "Matrix import: Importing mass matrix M failed."
    assert np.array_equal(IRF_ob.K, K_test), "Matrix import: Importing stiffness matrix K failed."


def test_MK_import_after_instantiation():
    IRF_ob = openirf.NumericalIRF()  # Create OpenIRF object instance
    IRF_ob.add_MCK(M=M_test, K=K_test)
    assert np.array_equal(IRF_ob.M, M_test), "Matrix import: Importing mass matrix M failed."
    assert np.array_equal(IRF_ob.K, K_test), "Matrix import: Importing stiffness matrix K failed."


def test_MCK_import_during_instantiation():
    IRF_ob = openirf.NumericalIRF(M=M_test, C=C_test, K=K_test)  # Create OpenIRF object instance
    assert np.array_equal(IRF_ob.M, M_test), "Matrix import: Importing mass matrix M failed."
    assert np.array_equal(IRF_ob.K, K_test), "Matrix import: Importing stiffness matrix K failed."
    assert np.array_equal(IRF_ob.C, C_test), "Matrix import: Importing stiffness matrix K failed."


def test_MCK_import_after_instantiation():
    IRF_ob = openirf.NumericalIRF()  # Create OpenIRF object instance
    IRF_ob.add_MCK(M=M_test, C=C_test, K=K_test)
    assert np.array_equal(IRF_ob.M, M_test), "Matrix import: Importing mass matrix M failed."
    assert np.array_equal(IRF_ob.K, K_test), "Matrix import: Importing stiffness matrix K failed."
    assert np.array_equal(IRF_ob.C, C_test), "Matrix import: Importing stiffness matrix K failed."


def test_rejection_of_only_M_or_K_during_instantiation():
    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.NumericalIRF(K=K_test)
    assert exc_info.value.args[0] == "No mass matrix M was provided."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.NumericalIRF(M=M_test)
    assert exc_info.value.args[0] == "No stiffness matrix K was provided."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_only_C_during_instantiation():
    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.NumericalIRF(C=C_test)
    assert exc_info.value.args[0] == "No mass matrix M and stiffness matrix K was provided."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_non_square_matrices_during_instantiation():
    with pytest.raises(Exception) as exc_info:  # K non-square
        IRF_ob = openirf.NumericalIRF(M=M_test, K=K_test2)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a square matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        IRF_ob = openirf.NumericalIRF(M=M_test2, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a square matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        IRF_ob = openirf.NumericalIRF(M=M_test, C=C_test2, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a square matrix."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_non_square_matrices_after_instantiation():
    IRF_ob = openirf.NumericalIRF()
    with pytest.raises(Exception) as exc_info:  # K non-square
        IRF_ob.add_MCK(M=M_test, K=K_test2)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a square matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        IRF_ob.add_MCK(M=M_test2, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a square matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        IRF_ob.add_MCK(M=M_test, C=C_test2, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a square matrix."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_non_2D_matrices_during_instantiation():
    # 1D array
    with pytest.raises(Exception) as exc_info:  # K non-square
        openirf.NumericalIRF(M=M_test, K=oned_matrix)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        openirf.NumericalIRF(M=oned_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        openirf.NumericalIRF(M=M_test, C=oned_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"
    # 3D array
    with pytest.raises(Exception) as exc_info:  # K non-square
        openirf.NumericalIRF(M=M_test, K=threed_matrix)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        openirf.NumericalIRF(M=threed_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        openirf.NumericalIRF(M=M_test, C=threed_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_non_2D_matrices_after_instantiation():
    IRF_ob = openirf.NumericalIRF()
    # 1D array
    with pytest.raises(Exception) as exc_info:  # K non-square
        IRF_ob.add_MCK(M=M_test, K=oned_matrix)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        IRF_ob.add_MCK(M=oned_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        IRF_ob.add_MCK(M=M_test, C=oned_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"
    # 3D array
    with pytest.raises(Exception) as exc_info:  # K non-square
        IRF_ob.add_MCK(M=M_test, K=threed_matrix)
    assert exc_info.value.args[0] == "Provided stiffness matrix K is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M non-square
        IRF_ob.add_MCK(M=threed_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C non-square
        IRF_ob.add_MCK(M=M_test, C=threed_matrix, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C is not a 2D matrix."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_misshaped_matrices_during_instantiation():
    with pytest.raises(Exception) as exc_info:  # K misshaped
        IRF_ob = openirf.NumericalIRF(M=M_test, K=K_test3)
    assert exc_info.value.args[0] == "Provided mass matrix M and stiffness matrix K have different size."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M misshaped
        IRF_ob = openirf.NumericalIRF(M=M_test3, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M and stiffness matrix K have different size."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C misshaped
        IRF_ob = openirf.NumericalIRF(M=M_test, C=C_test3, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C does not match the size of the mass matrix M and stiffness matrix K."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_misshaped_matrices_after_instantiation():
    IRF_ob = openirf.NumericalIRF()
    with pytest.raises(Exception) as exc_info:  # K misshaped
        IRF_ob.add_MCK(M=M_test, K=K_test3)
    assert exc_info.value.args[0] == "Provided mass matrix M and stiffness matrix K have different size."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # M misshaped
        IRF_ob.add_MCK(M=M_test3, K=K_test)
    assert exc_info.value.args[0] == "Provided mass matrix M and stiffness matrix K have different size."
    assert exc_info.type.__name__ == "Exception"

    with pytest.raises(Exception) as exc_info:  # C misshaped
        IRF_ob.add_MCK(M=M_test, C=C_test3, K=K_test)
    assert exc_info.value.args[0] == "Provided damping matrix C does not match the size of the mass matrix M and stiffness matrix K."
    assert exc_info.type.__name__ == "Exception"


def test_creation_dummy_C_during_instantiation():
    IRF_ob = openirf.NumericalIRF(M=M_test3, K=K_test3)  # Create OpenIRF object instance
    assert np.array_equal(IRF_ob.C, np.zeros_like(M_test3)), "Matrix import: No dummy damping matrix C was created."


def test_creation_dummy_C_after_instantiation():
    IRF_ob = openirf.NumericalIRF()  # Create OpenIRF object instance
    IRF_ob.add_MCK(M=M_test3, K=K_test3)
    assert np.array_equal(IRF_ob.C, np.zeros_like(M_test3)), "Matrix import: No dummy damping matrix C was created."
