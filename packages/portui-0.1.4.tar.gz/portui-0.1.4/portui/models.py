"""Data models for porTUI."""

from __future__ import annotations

import dataclasses


@dataclasses.dataclass(frozen=True)
class PortInfo:
    """Information about a listening port."""

    port: int
    ip: str
    protocol: str
    pid: int
    process_name: str
    username: str
    state: str
    cmdline: str
    ppid: int = 0  # Parent process ID for tree view
    create_time: float = 0.0  # Process creation time for PID-recycling guard
