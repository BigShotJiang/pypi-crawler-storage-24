"""Allow running porTUI as `python -m portui`."""

from portui.app import main

main()
