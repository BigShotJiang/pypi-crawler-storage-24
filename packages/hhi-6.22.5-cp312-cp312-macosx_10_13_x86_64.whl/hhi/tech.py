import sys
from functools import partial

import gdsfactory as gf
import kfactory as kf
from gdsfactory.cross_section import get_cross_sections
from gdsfactory.routing.route_bundle_sbend import route_bundle_sbend
from gdsfactory.technology import (
    LayerLevel,
    LayerMap,
    LayerStack,
    LayerViews,
    LogicalLayer,
)
from gdsfactory.typings import Layer

from hhi.config import PATH

nm = 1e-3


class LayerMapHHI(LayerMap):
    # GDSII Layer Description (design manual Table 11.1, in document order)
    FLOORPLAN: Layer = (7, 0)  # BB exclusion region + cleave-edge ±50 µm boundary
    WG: Layer = (12, 0)  # passive waveguides (E200, E600, E1700 all drawn here)
    E200: Layer = (13, 0)  # etch window around E200 waveguides (42 µm, 200 µm)
    E600: Layer = (16, 0)  # etch window around E600 waveguides (42 µm, 600 µm)
    E1700: Layer = (18, 0)  # etch window around E1700 waveguides (42 µm, 1700 µm)
    TEXT: Layer = (24, 0)  # on-chip text/logos only; forbidden on any other layer
    ISO: Layer = (51, 0)  # SiNx isolation below metal tracks; M1 + 2 µm each side
    M1: Layer = (52, 0)  # metal-routing line 1 (gold stripe); M2 + 2 µm each side
    M2: Layer = (54, 0)  # metal-routing line 2
    BB_outline: Layer = (55, 0)  # BB placement boundary (stripped at mask assembly)
    BB_parameter: Layer = (56, 0)  # BB parameter labels (stripped at mask assembly)
    BB_text: Layer = (59, 0)  # BB annotations/port markers (stripped at mask assembly)

    # Additional helper layers for design convenience
    PERIMETER: Layer = (9, 0)
    # (not explicitly mentioned in design manual, but used in the embedded RFconnect
    # templates to indicate permitted design space on these chips)

    # Further annotation layers (≥1000 recommended by HHI, they will remove them)
    BB_PIN: Layer = (1002, 0)  # BB pin markers for PDK tool connectivity
    PIN_LABEL: Layer = (1003, 0)  # port/pin labels for gdsfactory netlist extraction
    GS: Layer = (1004, 0)  # marker layer for GS pad cross-sections (routing only)

    # 3D derived layers — used by LayerStack for etch-zone boolean results.
    # GDSFactory+ requires these to be LayerEnum members (not raw tuples).
    # Each epitaxial split layer gets its own unique derived layer to avoid
    # the 3D viewer deduplicating layers that share the same GDS layer number.
    _3D_0: Layer = (200, 0)
    _3D_1: Layer = (200, 1)
    _3D_2: Layer = (200, 2)
    _3D_3: Layer = (200, 3)
    _3D_4: Layer = (200, 4)
    _3D_5: Layer = (200, 5)
    _3D_6: Layer = (200, 6)
    _3D_7: Layer = (200, 7)
    _3D_8: Layer = (200, 8)
    _3D_9: Layer = (200, 9)
    _3D_10: Layer = (200, 10)

    # gdsfactory generic-PDK aliases (map to physical layers above)
    MTOP: Layer = (54, 0)  # alias for M2 (gdsfactory generic top-metal name)
    LABEL_INSTANCE: Layer = (1003, 0)  # alias for PIN_LABEL (gdsfactory generic name)


class Tech:
    width_e200 = 2.0
    width_e600 = 2.1
    width_e1700 = 2.3
    width_m2 = 12
    width_m1 = 12 + 4

    # NOTE: min gaps from design manual Section 11.2 — relevant for DRC
    gap_iso = 10  # min ISO edge-to-edge
    gap_m1 = 14  # min M1 edge-to-edge (ISO gap 10 + 2µm)
    gap_m2 = 18  # min M2 edge-to-edge (ISO gap 10 + 4µm)
    gap_to_edge = 50  # min metal to chip edge


TECH = Tech()
LAYER = LayerMapHHI
gf.kcl.layers = LAYER
gf.kcl.infos = kf.LayerInfos(
    **{v.name: kf.kdb.LayerInfo(v.layer, v.datatype) for v in LAYER},  # type: ignore[attr-defined]
)


port_types_electrical = (
    "electrical",
    "electrical",
)
port_names_electrical = ("e1", "e2")
layer_label = LAYER.PIN_LABEL
layer_bbox = LAYER.BB_outline

################################################
# Cross-sections
################################################
xsection = gf.xsection
min_radius_metal = 370


# Optical routing
@xsection
def E200(width: float = TECH.width_e200) -> gf.CrossSection:
    s0 = gf.Section(layer=LAYER.WG, width=width, port_names=("o1", "o2"))
    return gf.CrossSection(
        sections=(s0, gf.Section(layer=LAYER.E200, width=40)),
        radius=10e3,
    )


@xsection
def E600(width: float = TECH.width_e600) -> gf.CrossSection:
    s0 = gf.Section(layer=LAYER.WG, width=width, port_names=("o1", "o2"))
    return gf.CrossSection(
        sections=(s0, gf.Section(layer=LAYER.E600, width=40)),
        radius_min=450,
        radius=500.0,
    )


@xsection
def E1700(width: float = TECH.width_e1700) -> gf.CrossSection:
    s0 = gf.Section(layer=LAYER.WG, width=width, port_names=("o1", "o2"))
    return gf.CrossSection(
        sections=(s0, gf.Section(layer=LAYER.E1700, width=40)),
        radius_min=250,
        radius=380.0,
    )


@xsection
def ACT(width: float = 2.1) -> gf.CrossSection:
    s0 = gf.Section(layer=LAYER.WG, width=width, port_names=("o1", "o2"))
    return gf.CrossSection(sections=(s0,))


@xsection
def FACET(width: float = 2.1) -> gf.CrossSection:
    s0 = gf.Section(layer=LAYER.WG, width=width, port_names=("o1", "o2"))
    return gf.CrossSection(sections=(s0,))


def xs_metal(
    section_width: float | tuple[float, ...] = TECH.width_m1,
    width: float | None = None,
    gap: float | None = None,
    radius: float = min_radius_metal,
    **kwargs,
) -> gf.CrossSection:
    """HHI metal tracks (shorthand). Adds isolation correctly.
    Please change if there is a more gdsfactoresque way to do this.
    Will use a signal track for ports. This is important to remember for rS tracks!

    Args:
        section_width: width(s) of the metal tracks
        width: This is just a dummy argument to avoid a BUG in gdsfactory8 with multi-section cross-sections
        gap: gap(s) between the metal tracks
        radius: bend radius
    """

    if not hasattr(section_width, "__iter__"):
        section_width = (section_width,)
    if not hasattr(gap, "__iter__"):
        gap = (gap,) if gap else (0,) * (len(section_width) - 1)

    # Calculate corresponding offsets from gap & section_width
    total_width = sum(section_width) + sum(gap) if gap else sum(section_width)
    offsets = [0]
    if len(section_width) > 1:
        offsets = [
            -(total_width / 2)
            + sum(section_width[:i])
            + sum(gap[:i])
            + section_width[i] / 2
            for i in range(len(section_width))
        ]

    sections = []
    # If GSG or GS or any other multi-track, add the underlying isolation layer first
    # -> needed in gdsfactory 8 to avoid a BUG

    # Create the metal sections
    for i, (w, offset) in enumerate(zip(section_width, offsets)):
        # Only give ports to the central track, or the first track if there are only 1 or 2 tracks
        port_names = (
            ("e1", "e2")
            if (offset == 0 or (len(section_width) == 2 and i == 1))
            else (None, None)
        )
        sections.extend(
            [
                gf.Section(
                    layer=LAYER.M1,
                    width=w,
                    offset=offset,
                    port_names=port_names,
                    port_types=("electrical", "electrical"),
                ),
                gf.Section(layer=LAYER.M2, width=w - 4, offset=offset),
            ]
        )

    sections.append(gf.Section(layer=LAYER.ISO, width=total_width + 4))
    return gf.CrossSection(sections=sections, radius=radius, **kwargs)


# Define the metal routing cross-sections
@xsection
def DC(
    width: float = TECH.width_m1, layer="M1", radius=10, **kwargs
) -> gf.CrossSection:
    """HHI metal tracks for DC routing.

    Args:
        width: width(s) of the metal tracks.
        layer: layer for the metal tracks.
        radius: bend radius.
        kwargs: additional cross-section parameters.

    """
    cladding_layers = ["M2", "ISO"]
    cladding_offsets = [-2, 2]
    return gf.cross_section.metal1(
        width=width,
        layer=layer,
        radius=radius,
        cladding_layers=cladding_layers,
        cladding_offsets=cladding_offsets,
        **kwargs,
    )


@xsection
def GS(
    width_metal: float = 150,
    gap: float = 24,
    radius=min_radius_metal,
    **kwargs,
) -> gf.CrossSection:
    """HHI metal tracks for GS routing. Adds isolation correctly.

    Args:
        section_width: width(s) of the metal tracks.
        width: width(s) of the metal tracks.
        gap: gap between the metal tracks.
        radius: bend radius.
        kwargs: ignored cross-section parameters.
    """
    kwargs.pop("width", None)
    sections = [
        gf.Section(
            layer=LAYER.GS,
            width=gap,
            port_names=port_names_electrical,
            port_types=port_types_electrical,
        )
    ]
    width = width_metal
    total_width = 2 * width + gap
    offsets = [
        -width / 2 - gap / 2,
        width / 2 + gap / 2,
    ]

    for offset in offsets:
        sections.extend(
            [
                gf.Section(
                    layer=LAYER.M1,
                    width=width,
                    offset=offset,
                ),
                gf.Section(layer=LAYER.M2, width=width - 4, offset=offset),
            ]
        )

    sections.append(gf.Section(layer=LAYER.ISO, width=total_width + 4))
    return gf.CrossSection(sections=sections, radius=radius, **kwargs)


@xsection
def GSG(
    section_width: tuple[float, ...] = (100, 60, 100),
    gap: tuple[float, ...] = (50, 50),
    radius: float = min_radius_metal,
    **kwargs,
) -> gf.CrossSection:
    """HHI metal tracks for GSG routing. Adds isolation correctly.

    Args:
        section_width: width(s) of the metal tracks.
        gap: gap(s) between the metal tracks.
        radius: bend radius.
        kwargs: additional cross-section parameters.
    """
    return xs_metal(section_width=section_width, gap=gap, radius=radius, **kwargs)


cross_sections = get_cross_sections(sys.modules[__name__])

################################################
# Routing functions
################################################

route_single_e200 = partial(gf.routing.route_single, cross_section="E200")
route_single_e600 = partial(gf.routing.route_single, cross_section="E600")
route_single_e1700 = partial(gf.routing.route_single, cross_section="E1700")
route_single_dc = partial(
    gf.routing.route_single, cross_section="DC", allow_width_mismatch=True
)
route_single_gs = partial(gf.routing.route_single, cross_section="GS")
route_single_gsg = partial(gf.routing.route_single, cross_section="GSG")

route_single_sbend_e200 = partial(gf.routing.route_single_sbend, cross_section="E200")
route_single_sbend_e600 = partial(gf.routing.route_single_sbend, cross_section="E600")
route_single_sbend_e1700 = partial(gf.routing.route_single_sbend, cross_section="E1700")
route_single_sbend_dc = partial(gf.routing.route_single_sbend, cross_section="DC")
route_single_sbend_gs = partial(gf.routing.route_single_sbend, cross_section="GS")
route_single_sbend_gsg = partial(gf.routing.route_single_sbend, cross_section="GSG")

route_bundle_e200 = partial(gf.routing.route_bundle, cross_section="E200")
route_bundle_e600 = partial(gf.routing.route_bundle, cross_section="E600")
route_bundle_e1700 = partial(gf.routing.route_bundle, cross_section="E1700")
route_bundle_dc = partial(
    gf.routing.route_bundle,
    cross_section="DC",
    auto_taper=False,
    router="optical",
    separation=30,
    bend="bend_circular_metal",
    allow_width_mismatch=True,
)
route_bundle_dc_corner = partial(
    gf.routing.route_bundle,
    cross_section="DC",
    router="optical",
    bend="wire_corner45",
    auto_taper=False,
    separation=30,
    allow_width_mismatch=True,
)
route_bundle_gsg = partial(
    gf.routing.route_bundle, cross_section="GSG", auto_taper=False, router="optical"
)

route_bundle_all_angle = partial(
    gf.routing.route_bundle_all_angle,
    cross_section="E200",
    separation=5,
    bend="bend_euler_all_angle",
    straight="straight_all_angle",
)


route_bundle_gs = partial(
    gf.routing.route_bundle,
    cross_section="GS",
    bend="bend_circular_metal",
    router="optical",
)

route_bundle_sbend_e200 = partial(
    route_bundle_sbend, cross_section="E200", bend_s="bend_s"
)
route_bundle_sbend_e600 = partial(
    route_bundle_sbend, cross_section="E600", bend_s="bend_s"
)
route_bundle_sbend_e1700 = partial(
    route_bundle_sbend, cross_section="E1700", bend_s="bend_s"
)
route_bundle_sbend_dc = partial(
    route_bundle_sbend,
    cross_section="DC",
    bend_s="bend_s",
    allow_width_mismatch=True,
    port_name="e1",
)
route_bundle_sbend_gs = partial(
    route_bundle_sbend,
    cross_section="GS",
    bend_s="bend_s",
    allow_width_mismatch=True,
    port_name="e1",
)
route_bundle_sbend_gsg = partial(
    route_bundle_sbend,
    cross_section="GSG",
    bend_s="bend_s",
    allow_width_mismatch=True,
    allow_layer_mismatch=True,
    port_name="e1",
)

routing_strategies = dict(
    route_bundle_e200=route_bundle_e200,
    route_bundle_e600=route_bundle_e600,
    route_bundle_e1700=route_bundle_e1700,
    route_bundle_dc=route_bundle_dc,
    route_bundle_gs=route_bundle_gs,
    route_bundle_gsg=route_bundle_gsg,
    route_bundle_sbend_e200=route_bundle_sbend_e200,
    route_bundle_sbend_e600=route_bundle_sbend_e600,
    route_bundle_sbend_e1700=route_bundle_sbend_e1700,
    route_bundle_sbend_dc=route_bundle_sbend_dc,
    route_bundle_sbend_gs=route_bundle_sbend_gs,
    route_bundle_sbend_gsg=route_bundle_sbend_gsg,
    route_single_dc=route_single_dc,
)


################################################
# LayerStack
################################################
LAYER_VIEWS = LayerViews(PATH.lyp_yaml)
constants = {
    "fiber_array_spacing": 127.0,
    "fiber_spacing": 50.0,
    "fiber_input_to_output_spacing": 200.0,
    "metal_spacing": 30.0,
    "pad_pitch": 150.0,
    "pad_size": (66, 66),
}


def get_layer_stack() -> LayerStack:
    """Returns HHI LayerStack with etch-zone booleans (matches hhi_external.lyd25).

    The epitaxial stack is split at etch-stop boundaries so each sub-layer
    gets the correct boolean polygon expression for its z-zone:
      - Below E1700 etch stop: full FLOORPLAN (substrate everywhere)
      - E1700 → E600 stop: FLOORPLAN minus E1700 valley
      - E600 → E200 stop: FLOORPLAN minus E1700+E600 valleys
      - Above E200 stop: waveguide stacks only (WG & etch-window intersections)
    """
    # Epitaxial layer thicknesses (µm) — design manual Chapter 10
    epi_layers = [
        ("InP_substrate", 10.0, "InP"),
        ("Q106_spc1", 0.1, "Q(1.06)"),
        ("InP_clad1", 0.7, "InP"),
        ("Q106_guid", 0.82, "Q(1.06)"),
        ("InP_clad2", 0.02, "InP"),
        ("Q106_spc2", 0.205, "Q(1.06)"),
        ("InP_clad3", 0.005, "InP"),
        ("SiNx", 0.05, "SiNx"),
    ]

    # Etch depths (µm) — design manual / lyd25
    dz_e200, dz_e600, dz_e1700 = 0.310, 0.650, 2.100

    # Underetch (µm → dbu; 1 dbu = 1 nm for default kfactory)
    ue_e1700_dbu, ue_e600_dbu = 150, 50  # 0.15 µm, 0.05 µm

    # Total epitaxial height and etch-stop z-positions
    total_h = sum(t for _, t, _ in epi_layers)
    z_e1700 = round(total_h - dz_e1700, 3)  # 9.8
    z_e600 = round(total_h - dz_e600, 3)  # 11.25
    z_e200 = round(total_h - dz_e200, 3)  # 11.59

    # --- Logical layers ---
    l_fp = LogicalLayer(layer=LAYER.FLOORPLAN)
    l_wg = LogicalLayer(layer=LAYER.WG)
    l_e200 = LogicalLayer(layer=LAYER.E200)
    l_e600 = LogicalLayer(layer=LAYER.E600)
    l_e1700 = LogicalLayer(layer=LAYER.E1700)

    # --- Derived boolean layers (matching lyd25 logic) ---
    # Waveguide stacks: WG.sized(-underetch) & etch_window
    e1700_stack = l_wg.sized(-ue_e1700_dbu) & l_e1700
    e600_stack = l_wg.sized(-ue_e600_dbu) & l_e600
    e200_stack = l_wg & l_e200  # no underetch for E200
    undefined_wgs = l_wg - l_e1700 - l_e600 - l_e200

    # Valleys: etch window minus waveguide stack (etched regions)
    e1700_valley = l_e1700 - e1700_stack
    e600_valley = l_e600 - e600_stack

    # Substrate = FLOORPLAN with holes filled (matching lyd25: input(7,0).holes + input(7,0)).
    # Die frames are ring polygons; morphological close (expand then shrink) fills the
    # inner holes to produce a solid substrate.  5 mm > half the smallest die dimension.
    substrate = (l_fp + l_fp).sized(5_000_000).sized(-5_000_000)

    # Zone polygon expressions (all DerivedLayer for correct derived_layer handling)
    zones = {
        1: substrate,  # full substrate below E1700 etch stop
        2: substrate - e1700_valley,  # etched where E1700 has no WG
        3: substrate - e1700_valley - e600_valley,
        4: e200_stack + e600_stack + e1700_stack + undefined_wgs,
    }

    # Pool of unique derived layers — one per epitaxial split entry.
    # Each must be a unique LayerEnum member for GDSFactory+ 3D viewer.
    _3d_pool = [getattr(LAYER, f"_3D_{i}") for i in range(11)]

    def zone_of(z: float) -> int:
        if z < z_e1700:
            return 1
        if z < z_e600:
            return 2
        if z < z_e200:
            return 3
        return 4

    # --- Split epitaxial layers at etch stops (same algorithm as lyd25) ---
    etch_stops = sorted([(z_e1700, "E1700"), (z_e600, "E600"), (z_e200, "E200")])
    splits: list[
        tuple[str, float, str, float]
    ] = []  # (name, thickness, material, zmin)
    z = 0.0
    for name, thickness, material in epi_layers:
        remaining = thickness
        for z_stop, es_name in etch_stops:
            if z < z_stop < round(z + remaining, 6):
                t0 = round(z_stop - z, 6)
                splits.append((f"{name}_{es_name}", t0, material, round(z, 6)))
                z = round(z + t0, 6)
                remaining = round(remaining - t0, 6)
        splits.append((name, remaining, material, round(z, 6)))
        z = round(z + remaining, 6)

    # --- Build LayerLevel entries ---
    layers = {}
    for i, (name, thickness, material, zmin) in enumerate(splits):
        zone = zone_of(zmin)
        layers[name] = LayerLevel(
            layer=zones[zone],
            thickness=thickness,
            zmin=zmin,
            material=material,
            mesh_order=i + 1,
            derived_layer=LogicalLayer(layer=_3d_pool[i]),
        )

    # --- Metal layers (start at E200 etch stop, matching lyd25) ---
    n = len(splits)
    layers["ISO"] = LayerLevel(
        layer=LogicalLayer(layer=LAYER.ISO),
        thickness=0.42,
        zmin=z_e200,
        material="SiNx",
        mesh_order=n + 1,
    )
    layers["M1"] = LayerLevel(
        layer=LogicalLayer(layer=LAYER.M1),
        thickness=0.5,
        zmin=z_e200 + 0.42,
        material="Au",
        mesh_order=n + 2,
    )
    layers["M2"] = LayerLevel(
        layer=LogicalLayer(layer=LAYER.M2),
        thickness=3.0,
        zmin=z_e200 + 0.92,
        material="Au",
        mesh_order=n + 3,
    )

    # --- Text (matching lyd25: zstart=E200 etch stop, height=1) ---
    layers["Text"] = LayerLevel(
        layer=LogicalLayer(layer=LAYER.TEXT),
        thickness=1.0,
        zmin=z_e200,
        material="Au",
        mesh_order=n + 4,
    )

    # --- BB outline (matching lyd25: zstart=E1700 etch stop, height=5.6) ---
    layers["BB_outline"] = LayerLevel(
        layer=LogicalLayer(layer=LAYER.BB_outline),
        thickness=5.6,
        zmin=z_e1700,
        material="Au",
        mesh_order=n + 5,
    )

    return LayerStack(layers=layers)


LAYER_STACK = get_layer_stack()


MATERIALS_INDEX = {  # this is a placeholder.
    # We have very accurate material models, but still unclear how to implement them here
    "InP": 3.167,
    "Q(1.06)": 3.258,
    "sin": 2.0,
}
