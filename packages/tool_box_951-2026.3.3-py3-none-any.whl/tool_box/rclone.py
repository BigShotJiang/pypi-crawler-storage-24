# coding:utf-8
import os
import re
import json
import shlex
import subprocess
from pathlib import Path

from loguru import logger


def parse_time_to_seconds(s: str) -> int:
    """
    将类似 '1h', '30min', '1d', '45s', '2w' 转换为秒数
    支持单位: s, sec, m, min, h, hour, d, day, w, week
    """
    if not s:
        raise ValueError("Empty time string")
    s = s.strip().lower()
    if s.isnumeric():
        return int(s)
    units = {
        "s": 1,
        "sec": 1,
        "secs": 1,
        "second": 1,
        "seconds": 1,
        "m": 60,
        "min": 60,
        "mins": 60,
        "minute": 60,
        "minutes": 60,
        "h": 3600,
        "hr": 3600,
        "hour": 3600,
        "hours": 3600,
        "d": 86400,
        "day": 86400,
        "days": 86400,
        "w": 604800,
        "week": 604800,
        "weeks": 604800,
    }
    m = re.match(r"^\s*(\d+(?:\.\d+)?)\s*([a-z]+)?\s*$", s)
    if not m:
        raise ValueError(f"Invalid time format: {s}")
    value = float(m.group(1))
    unit = m.group(2) or "s"  # 默认秒
    if unit not in units:
        raise ValueError(f"Unknown unit: {unit}")

    return int(value * units[unit])


def _get_default_ssh_config() -> str | None:
    """获取默认 SSH config 路径"""
    ssh_config = Path.home() / ".ssh" / "config"
    if ssh_config.exists():
        return str(ssh_config)
    return None


def rclone_flag_to_rsync(flag):
    if "=" not in flag:
        if flag in ["--copy-links", "--update"]:
            return flag
        raise Exception(f"not support flag: `{flag}`")
    opt, val = flag.split("=")
    if opt == "--filter":
        if "+ " in val:
            val = shlex.split(val.replace("+ ", ""))[0]
            return f"--include='{val}'"
        else:
            val = shlex.split(val.replace("- ", ""))[0]
            return f"--exclude='{val}'"
    if opt == "--bwlimit":
        val = shlex.split(val)[0]
        try:
            v = int(val)

        except Exception as e:
            raise e
        return f"--bwlimit={v}"
    if opt == "--exclude":
        val = shlex.split(val)[0]
        return f"--exclude='{val}'"
    if opt == "--transfers":
        return ""
    if opt == "--min-age":
        val = parse_time_to_seconds(val)
        return f"--min-age={val}"
    raise ValueError(f"not support flag: `{flag}`")


def rclone_to_rsync(
    rclone_cmd: list[str],
    ssh_config_path: str | None = None,
) -> list[str]:
    rsync_cmd = []
    for i in rclone_cmd:
        if i == "rclone":
            rsync_cmd.append("rsync")
            rsync_cmd.append("-aO")
            if ssh_config_path:
                rsync_cmd.append(f'-e "ssh -F {ssh_config_path}"')
            continue
        if i in ["copy", "move"]:
            continue
        if i.startswith("--"):
            rsync_cmd.append(rclone_flag_to_rsync(i))
        else:
            rsync_cmd.append(i)
    rync_cmd = [i for i in rsync_cmd if i.strip()]
    fix_cmd = []

    for i in rync_cmd:
        add_dir_flag = "--include='*/'"
        if i.startswith("--include") and add_dir_flag not in fix_cmd:
            fix_cmd.append(add_dir_flag)
            fix_cmd.append(i)
        else:
            fix_cmd.append(i)
    return fix_cmd


def _rclone_transfer_operation(
    cmd: list[str],
    source_path: str,
    target_path: str | None = None,
    flags: list[str] | None = None,
    verbose: bool = False,
    engine: str = "rclone",
    ssh_config_path: str | None = None,
) -> int:
    command = cmd.copy()
    command.append(source_path)
    if target_path is not None:
        command.append(target_path)
    if flags is not None:
        command += flags
    if engine == "rsync":
        effective_ssh_config = ssh_config_path or _get_default_ssh_config()
        command = rclone_to_rsync(command, ssh_config_path=effective_ssh_config)
    if verbose:
        logger.info("run {}", command)
    result = subprocess.run(
        " ".join(command),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        check=False,
        shell=True,
        executable="/bin/bash",
        env=os.environ,
        cwd=os.getcwd(),
    )
    if verbose and result.returncode != 0:
        logger.error(
            "run {} fail, code:{} reason:{}",
            " ".join(command),
            result.returncode,
            result.stderr.decode("utf-8"),
        )

    return result.returncode


def get_servers():
    command = ["rclone", "config", "dump"]
    result = subprocess.run(
        " ".join(command),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        env=os.environ,
        cwd=os.getcwd(),
        executable="/bin/bash",
        shell=True,
    )
    if result.returncode == 0:
        output = json.loads(result.stdout.decode("utf-8"))
        return list(output.keys())
    reason = result.stderr.decode("utf-8")
    logger.error("{}", reason)
    return None


def ls(source_path):
    command = ["rclone", "lsf", source_path]

    result = subprocess.run(
        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False
    )
    if result.returncode == 0:
        return sorted(result.stdout.decode("utf-8").splitlines())
    reason = result.stderr.decode("utf-8")
    if "directory not found" in reason:
        return []
    logger.error("{}", result.stderr.decode("utf-8"))
    return []


def lsd(source_path):
    """列出目录下的文件夹"""
    command = ["rclone", "lsd", source_path]

    result = subprocess.run(
        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False
    )
    if result.returncode == 0:
        ll = result.stdout.decode("utf-8").splitlines()
        ll[:] = [i.split()[-1] for i in ll]
        return sorted(ll)
    reason = result.stderr.decode("utf-8")
    if "directory not found" in reason:
        return []
    logger.error("{}", result.stderr.decode("utf-8"))
    return []


def move(source_path, target_path, flags=None, verbose=False):
    return _rclone_transfer_operation(
        ["rclone", "move"],
        source_path,
        target_path,
        flags,
        verbose=verbose,
    )


def copy(source_path, target_path, flags=None, verbose=False, engine="rclone"):
    return _rclone_transfer_operation(
        ["rclone", "copy"],
        source_path,
        target_path,
        flags,
        verbose=verbose,
        engine=engine,
    )


def sync(source_path, target_path, flags=None, verbose=False):
    """
    rclone sync source_path target_path
    """
    if os.path.isfile(source_path):
        logger.error("source_path must be directory, but input is {}", source_path)
        return None
    return _rclone_transfer_operation(
        ["rclone", "sync"], source_path, target_path, flags, verbose=verbose
    )


def _rclone_transfer_with_retry(
    cmd: list[str],
    source_path: str,
    target_path: str | None = None,
    flags: list[str] | None = None,
    verbose: bool = False,
    engine: str = "rclone",
    max_retries: int = 3,
    retry_delay: float = 1.0,
    ssh_config_path: str | None = None,
) -> int:
    last_error_output = ""
    last_return_code = -1
    last_command: list[str] = []
    import time

    for attempt in range(1, max_retries + 1):
        last_command = cmd.copy()
        last_command.append(source_path)
        if target_path is not None:
            last_command.append(target_path)
        if flags is not None:
            last_command += flags

        if engine == "rsync":
            effective_ssh_config = ssh_config_path or _get_default_ssh_config()
            last_command = rclone_to_rsync(
                last_command, ssh_config_path=effective_ssh_config
            )

        if verbose:
            logger.info(
                "run {} (attempt {}/{})", " ".join(last_command), attempt, max_retries
            )

        result = subprocess.run(
            " ".join(last_command),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            check=False,
            shell=True,
            executable="/bin/bash",
            env=os.environ,
            cwd=os.getcwd(),
        )

        last_return_code = result.returncode
        last_error_output = result.stderr.decode("utf-8") if result.stderr else ""

        if result.returncode == 0:
            if verbose:
                logger.info(
                    "operation succeeded on attempt {}/{}", attempt, max_retries
                )
            return 0

        if attempt < max_retries:
            if verbose:
                logger.info(
                    "attempt {}/{} failed, retrying in {}s...",
                    attempt,
                    max_retries,
                    retry_delay,
                )
            time.sleep(retry_delay)

    logger.error(
        "operation failed after {} attempts: {}", max_retries, " ".join(last_command)
    )
    logger.error("return code: {}, reason: {}", last_return_code, last_error_output)

    return last_return_code


def copy_with_retry(
    source_path: str,
    target_path: str,
    flags: list[str] | None = None,
    verbose: bool = False,
    max_retries: int = 3,
    retry_delay: float = 1.0,
    engine: str = "rclone",
    ssh_config_path: str | None = None,
) -> int:
    """
    带重试的copy操作，只有最终失败才打印ERROR日志

    Args:
        source_path: 源路径
        target_path: 目标路径
        flags: rclone参数列表
        verbose: 是否打印详细日志
        max_retries: 最大重试次数
        retry_delay: 重试间隔（秒）
        engine: "rclone" 或 "rsync"
        ssh_config_path: SSH配置文件路径

    Returns:
        0表示成功，非0表示失败
    """
    return _rclone_transfer_with_retry(
        ["rclone", "copy"],
        source_path,
        target_path,
        flags,
        verbose=verbose,
        engine=engine,
        max_retries=max_retries,
        retry_delay=retry_delay,
        ssh_config_path=ssh_config_path,
    )


def move_with_retry(
    source_path: str,
    target_path: str,
    flags: list[str] | None = None,
    verbose: bool = False,
    max_retries: int = 3,
    retry_delay: float = 1.0,
) -> int:
    """
    带重试的move操作，只有最终失败才打印ERROR日志

    Args:
        source_path: 源路径
        target_path: 目标路径
        flags: rclone参数列表
        verbose: 是否打印详细日志
        max_retries: 最大重试次数
        retry_delay: 重试间隔（秒）

    Returns:
        0表示成功，非0表示失败
    """
    return _rclone_transfer_with_retry(
        ["rclone", "move"],
        source_path,
        target_path,
        flags,
        verbose=verbose,
        max_retries=max_retries,
        retry_delay=retry_delay,
    )


def sync_with_retry(
    source_path: str,
    target_path: str,
    flags: list[str] | None = None,
    verbose: bool = False,
    max_retries: int = 3,
    retry_delay: float = 1.0,
    ssh_config_path: str | None = None,
) -> int | None:
    """
    带重试的sync操作，只有最终失败才打印ERROR日志

    Args:
        source_path: 源路径
        target_path: 目标路径
        flags: rclone参数列表
        verbose: 是否打印详细日志
        max_retries: 最大重试次数
        retry_delay: 重试间隔（秒）
        ssh_config_path: SSH配置文件路径

    Returns:
        0表示成功，非0表示失败，None表示源路径不是目录
    """
    if os.path.isfile(source_path):
        logger.error("source_path must be directory, but input is {}", source_path)
        return None
    return _rclone_transfer_with_retry(
        ["rclone", "sync"],
        source_path,
        target_path,
        flags,
        verbose=verbose,
        max_retries=max_retries,
        retry_delay=retry_delay,
        ssh_config_path=ssh_config_path,
    )
