# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GeOIpItem:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'policyid': 'str',
        'name': 'str',
        'geoip': 'str',
        'white': 'int',
        'status': 'int',
        'timestamp': 'int'
    }

    attribute_map = {
        'id': 'id',
        'policyid': 'policyid',
        'name': 'name',
        'geoip': 'geoip',
        'white': 'white',
        'status': 'status',
        'timestamp': 'timestamp'
    }

    def __init__(self, id=None, policyid=None, name=None, geoip=None, white=None, status=None, timestamp=None):
        r"""GeOIpItem

        The model defined in huaweicloud sdk

        :param id: 规则id
        :type id: str
        :param policyid: 策略id
        :type policyid: str
        :param name: 地理位置控制规则名称
        :type name: str
        :param geoip: 地理位置封禁区域
        :type geoip: str
        :param white: 防护动作：  - 0 拦截  - 1 放行  - 2 仅记录
        :type white: int
        :param status: **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及
        :type status: int
        :param timestamp: 创建规则时间戳
        :type timestamp: int
        """
        
        

        self._id = None
        self._policyid = None
        self._name = None
        self._geoip = None
        self._white = None
        self._status = None
        self._timestamp = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if policyid is not None:
            self.policyid = policyid
        if name is not None:
            self.name = name
        if geoip is not None:
            self.geoip = geoip
        if white is not None:
            self.white = white
        if status is not None:
            self.status = status
        if timestamp is not None:
            self.timestamp = timestamp

    @property
    def id(self):
        r"""Gets the id of this GeOIpItem.

        规则id

        :return: The id of this GeOIpItem.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this GeOIpItem.

        规则id

        :param id: The id of this GeOIpItem.
        :type id: str
        """
        self._id = id

    @property
    def policyid(self):
        r"""Gets the policyid of this GeOIpItem.

        策略id

        :return: The policyid of this GeOIpItem.
        :rtype: str
        """
        return self._policyid

    @policyid.setter
    def policyid(self, policyid):
        r"""Sets the policyid of this GeOIpItem.

        策略id

        :param policyid: The policyid of this GeOIpItem.
        :type policyid: str
        """
        self._policyid = policyid

    @property
    def name(self):
        r"""Gets the name of this GeOIpItem.

        地理位置控制规则名称

        :return: The name of this GeOIpItem.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this GeOIpItem.

        地理位置控制规则名称

        :param name: The name of this GeOIpItem.
        :type name: str
        """
        self._name = name

    @property
    def geoip(self):
        r"""Gets the geoip of this GeOIpItem.

        地理位置封禁区域

        :return: The geoip of this GeOIpItem.
        :rtype: str
        """
        return self._geoip

    @geoip.setter
    def geoip(self, geoip):
        r"""Sets the geoip of this GeOIpItem.

        地理位置封禁区域

        :param geoip: The geoip of this GeOIpItem.
        :type geoip: str
        """
        self._geoip = geoip

    @property
    def white(self):
        r"""Gets the white of this GeOIpItem.

        防护动作：  - 0 拦截  - 1 放行  - 2 仅记录

        :return: The white of this GeOIpItem.
        :rtype: int
        """
        return self._white

    @white.setter
    def white(self, white):
        r"""Sets the white of this GeOIpItem.

        防护动作：  - 0 拦截  - 1 放行  - 2 仅记录

        :param white: The white of this GeOIpItem.
        :type white: int
        """
        self._white = white

    @property
    def status(self):
        r"""Gets the status of this GeOIpItem.

        **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及

        :return: The status of this GeOIpItem.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this GeOIpItem.

        **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及

        :param status: The status of this GeOIpItem.
        :type status: int
        """
        self._status = status

    @property
    def timestamp(self):
        r"""Gets the timestamp of this GeOIpItem.

        创建规则时间戳

        :return: The timestamp of this GeOIpItem.
        :rtype: int
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        r"""Sets the timestamp of this GeOIpItem.

        创建规则时间戳

        :param timestamp: The timestamp of this GeOIpItem.
        :type timestamp: int
        """
        self._timestamp = timestamp

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GeOIpItem):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
