"""Tests for Anthropic ``client.messages.create()`` guard wrapper."""

from __future__ import annotations

import logging
import pytest

from tokenfence import guard, BudgetExceeded


# ---------------------------------------------------------------------------
# Mock Anthropic client
# ---------------------------------------------------------------------------


class _MockAnthropicUsage:
    def __init__(self, input_tokens: int, output_tokens: int) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _MockContentBlock:
    def __init__(self, text: str = "Hello!") -> None:
        self.type = "text"
        self.text = text


class _MockMessage:
    def __init__(
        self,
        model: str = "claude-3-5-sonnet-20241022",
        input_tokens: int = 100,
        output_tokens: int = 50,
    ) -> None:
        self.id = "msg_test123"
        self.type = "message"
        self.role = "assistant"
        self.model = model
        self.stop_reason = "end_turn"
        self.usage = _MockAnthropicUsage(input_tokens, output_tokens)
        self.content = [_MockContentBlock()]


class _MockMessages:
    """Mocks ``anthropic.Anthropic().messages``."""

    def __init__(self, model: str = "claude-3-5-sonnet-20241022") -> None:
        self._model = model
        self.last_kwargs: dict = {}

    def create(self, **kwargs) -> _MockMessage:
        self.last_kwargs = kwargs
        model = kwargs.get("model", self._model)
        return _MockMessage(model=model, input_tokens=100, output_tokens=50)


class _MockAnthropicClient:
    """Mocks ``anthropic.Anthropic()``."""

    def __init__(self) -> None:
        self.messages = _MockMessages()
        self.api_key = "test-key"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAnthropicCostTracking:
    def test_tracks_single_call(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$1.00")

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert guarded.tokenfence.calls == 1
        assert guarded.tokenfence.spent > 0

    def test_tracks_multiple_calls(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$5.00")

        for _ in range(5):
            guarded.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Hello"}],
            )

        assert guarded.tokenfence.calls == 5
        assert guarded.tokenfence.spent > 0

    def test_cost_calculation_correct(self):
        """Claude 3.5 Sonnet: $3/1M input, $15/1M output.
        100 input + 50 output = $0.0003 + $0.00075 = $0.00105"""
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$1.00")

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert abs(guarded.tokenfence.spent - 0.00105) < 0.00001


class TestAnthropicAutoDowngrade:
    def test_downgrades_at_threshold(self):
        client = _MockAnthropicClient()
        guarded = guard(
            client,
            budget="$0.005",
            fallback="claude-3-haiku-20240307",
            threshold=0.2,
        )

        # First call should exhaust threshold
        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        # Second call should be downgraded
        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello again"}],
        )

        # Check the last call used the fallback model
        assert client.messages.last_kwargs["model"] == "claude-3-haiku-20240307"

    def test_no_downgrade_without_fallback(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$0.001", threshold=0.5)

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello again"}],
        )

        # Should keep original model if no fallback set
        assert client.messages.last_kwargs["model"] == "claude-3-5-sonnet-20241022"

    def test_downgrade_logs_warning(self, caplog):
        client = _MockAnthropicClient()
        guarded = guard(
            client,
            budget="$0.005",
            fallback="claude-3-haiku-20240307",
            threshold=0.2,
        )

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        with caplog.at_level(logging.WARNING, logger="tokenfence"):
            guarded.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Hello again"}],
            )

        assert "downgrading" in caplog.text.lower()


class TestAnthropicKillSwitch:
    def test_on_limit_stop(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$0.0001", on_limit="stop")

        # Exhaust budget
        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        # This should be blocked
        response = guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello again"}],
        )

        assert response.id == "tokenfence-budget-exceeded"
        assert response.role == "assistant"
        assert len(response.content) == 1
        assert "Budget" in response.content[0].text
        assert response.content[0].type == "text"

    def test_on_limit_raise(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$0.0001", on_limit="raise")

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        with pytest.raises(BudgetExceeded):
            guarded.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Hello again"}],
            )

    def test_on_limit_warn(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$0.0001", on_limit="warn")

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        # Should still allow the call
        response = guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello again"}],
        )

        assert response.id == "msg_test123"


class TestAnthropicPassthrough:
    def test_non_messages_attributes_pass_through(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$1.00")

        assert guarded.api_key == "test-key"

    def test_tokenfence_reset(self):
        client = _MockAnthropicClient()
        guarded = guard(client, budget="$1.00")

        guarded.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert guarded.tokenfence.calls == 1
        guarded.tokenfence.reset()
        assert guarded.tokenfence.calls == 0
        assert guarded.tokenfence.spent == 0.0
