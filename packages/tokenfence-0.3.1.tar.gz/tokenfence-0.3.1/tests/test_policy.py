"""Tests for the AgentGuard Policy engine."""

import time
import pytest
from tokenfence.policy import Policy, PolicyResult, Decision, ToolDenied, AuditEntry


# ---------------------------------------------------------------------------
# Basic allow/deny
# ---------------------------------------------------------------------------

class TestBasicPolicy:
    def test_deny_by_default_when_no_rules(self):
        """Empty policy with default=deny blocks everything."""
        policy = Policy(default="deny")
        result = policy.check("read_database")
        assert result.denied
        assert "default: deny" in result.reason

    def test_allow_by_default_when_no_rules(self):
        """Empty policy with default=allow permits everything."""
        policy = Policy(default="allow")
        result = policy.check("read_database")
        assert result.allowed
        assert "default: allow" in result.reason

    def test_explicit_allow(self):
        policy = Policy(allow=["read_database", "generate_report"])
        result = policy.check("read_database")
        assert result.allowed
        assert result.matched_rule == "read_database"

    def test_not_in_allow_list_denied(self):
        policy = Policy(allow=["read_database"])
        result = policy.check("delete_table")
        assert result.denied
        assert "not in allow list" in result.reason

    def test_explicit_deny(self):
        policy = Policy(allow=["*"], deny=["delete_*"])
        result = policy.check("delete_users")
        assert result.denied
        assert result.matched_rule == "delete_*"

    def test_deny_takes_precedence_over_allow(self):
        """Deny rules always win, even if allow also matches."""
        policy = Policy(allow=["*"], deny=["delete_*"])
        result = policy.check("delete_users")
        assert result.denied

    def test_wildcard_allow(self):
        policy = Policy(allow=["read_*"])
        result = policy.check("read_database")
        assert result.allowed
        result = policy.check("write_database")
        assert result.denied

    def test_wildcard_deny(self):
        policy = Policy(allow=["*"], deny=["drop_*", "truncate_*"])
        assert policy.check("read_file").allowed
        assert policy.check("drop_table").denied
        assert policy.check("truncate_logs").denied


# ---------------------------------------------------------------------------
# Approval gates
# ---------------------------------------------------------------------------

class TestApprovalGates:
    def test_require_approval(self):
        policy = Policy(
            allow=["*"],
            require_approval=["send_email", "write_database"],
        )
        result = policy.check("send_email")
        assert result.needs_approval
        assert result.matched_rule == "send_email"

    def test_approval_callback_approve(self):
        policy = Policy(
            allow=["*"],
            require_approval=["send_*"],
            on_approval=lambda r: True,
        )
        result = policy.check("send_email")
        assert result.allowed
        assert "approved via callback" in result.reason

    def test_approval_callback_deny(self):
        policy = Policy(
            allow=["*"],
            require_approval=["send_*"],
            on_approval=lambda r: False,
        )
        result = policy.check("send_email")
        assert result.denied
        assert "approval denied" in result.reason

    def test_deny_beats_require_approval(self):
        """If a tool matches both deny and require_approval, deny wins."""
        policy = Policy(
            deny=["send_*"],
            require_approval=["send_email"],
        )
        result = policy.check("send_email")
        assert result.denied
        assert "denied by pattern" in result.reason


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------

class TestAuditLog:
    def test_audit_entries_created(self):
        policy = Policy(allow=["read_*"], audit=True)
        policy.check("read_file")
        policy.check("write_file")
        assert len(policy.audit_log) == 2

    def test_audit_entry_structure(self):
        policy = Policy(allow=["read_*"], audit=True)
        policy.check("read_file", context={"user": "test"})
        entry = policy.audit_log[0]
        assert entry.tool == "read_file"
        assert entry.decision == "allow"
        assert entry.context == {"user": "test"}
        assert entry.timestamp > 0

    def test_audit_to_dict(self):
        policy = Policy(allow=["read_*"], audit=True)
        policy.check("read_file")
        entry = policy.audit_log[0]
        d = entry.to_dict()
        assert "timestamp" in d
        assert d["tool"] == "read_file"
        assert d["decision"] == "allow"

    def test_audit_disabled(self):
        policy = Policy(allow=["read_*"], audit=False)
        policy.check("read_file")
        assert len(policy.audit_log) == 0

    def test_clear_audit(self):
        policy = Policy(allow=["read_*"], audit=True)
        policy.check("read_file")
        assert len(policy.audit_log) == 1
        policy.clear_audit()
        assert len(policy.audit_log) == 0


# ---------------------------------------------------------------------------
# Enforce (raises on deny)
# ---------------------------------------------------------------------------

class TestEnforce:
    def test_enforce_allowed(self):
        policy = Policy(allow=["read_*"])
        result = policy.enforce("read_file")
        assert result.allowed

    def test_enforce_denied_raises(self):
        policy = Policy(allow=["read_*"])
        with pytest.raises(ToolDenied) as exc_info:
            policy.enforce("delete_file")
        assert "delete_file" in str(exc_info.value)
        assert exc_info.value.tool == "delete_file"

    def test_enforce_needs_approval_does_not_raise(self):
        policy = Policy(allow=["*"], require_approval=["send_*"])
        result = policy.enforce("send_email")
        assert result.needs_approval


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------

class TestSerialization:
    def test_to_dict(self):
        policy = Policy(
            allow=["read_*"],
            deny=["delete_*"],
            require_approval=["send_*"],
            default="deny",
            name="test-policy",
        )
        d = policy.to_dict()
        assert d["name"] == "test-policy"
        assert d["allow"] == ["read_*"]
        assert d["deny"] == ["delete_*"]
        assert d["require_approval"] == ["send_*"]
        assert d["default"] == "deny"

    def test_from_dict_roundtrip(self):
        original = Policy(
            allow=["read_*", "list_*"],
            deny=["drop_*"],
            name="roundtrip",
        )
        d = original.to_dict()
        restored = Policy.from_dict(d)
        assert restored.to_dict() == d

    def test_from_dict_defaults(self):
        policy = Policy.from_dict({"allow": ["*"]})
        # allow=["*"] matches everything via fnmatch wildcard
        result = policy.check("anything")
        assert result.allowed


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_invalid_default_raises(self):
        with pytest.raises(Exception):
            Policy(default="maybe")

    def test_empty_tool_name(self):
        policy = Policy(allow=["*"])
        result = policy.check("")
        assert result.allowed

    def test_question_mark_wildcard(self):
        policy = Policy(allow=["read_?"])
        assert policy.check("read_a").allowed
        assert policy.check("read_ab").denied

    def test_on_deny_callback(self):
        denied_tools = []
        policy = Policy(
            allow=["read_*"],
            on_deny=lambda r: denied_tools.append(r.tool),
        )
        policy.check("delete_file")
        assert "delete_file" in denied_tools

    def test_repr(self):
        policy = Policy(allow=["read_*"], deny=["drop_*"], name="my-policy")
        r = repr(policy)
        assert "my-policy" in r
        assert "read_*" in r
        assert "drop_*" in r

    def test_policy_result_properties(self):
        r1 = PolicyResult(Decision.ALLOW, "test", "ok")
        assert r1.allowed and not r1.denied and not r1.needs_approval

        r2 = PolicyResult(Decision.DENY, "test", "no")
        assert not r2.allowed and r2.denied and not r2.needs_approval

        r3 = PolicyResult(Decision.REQUIRE_APPROVAL, "test", "check")
        assert not r3.allowed and not r3.denied and r3.needs_approval


# ---------------------------------------------------------------------------
# Real-world scenario: Meta AI Agent incident policy
# ---------------------------------------------------------------------------

class TestRealWorldScenarios:
    def test_database_safety_policy(self):
        """The exact policy from the Meta incident use case."""
        policy = Policy(
            allow=["read_database", "generate_report", "list_tables"],
            deny=["delete_*", "drop_*", "truncate_*", "alter_*"],
            require_approval=["write_database", "create_table"],
            name="database-safety",
        )

        # Safe reads — allowed
        assert policy.check("read_database").allowed
        assert policy.check("generate_report").allowed
        assert policy.check("list_tables").allowed

        # Destructive ops — denied
        assert policy.check("delete_users").denied
        assert policy.check("drop_table").denied
        assert policy.check("truncate_logs").denied
        assert policy.check("alter_schema").denied

        # Write ops — need approval
        assert policy.check("write_database").needs_approval
        assert policy.check("create_table").needs_approval

        # Unknown op — not in allow list, denied
        assert policy.check("exec_sql").denied

    def test_email_agent_policy(self):
        """Policy for an AI email assistant."""
        policy = Policy(
            allow=["read_email", "search_email", "draft_email", "list_folders"],
            deny=["delete_email_*", "forward_to_external"],
            require_approval=["send_email"],
            name="email-agent",
        )

        assert policy.check("read_email").allowed
        assert policy.check("draft_email").allowed
        assert policy.check("delete_email_permanent").denied
        assert policy.check("send_email").needs_approval
        assert policy.check("forward_to_external").denied
