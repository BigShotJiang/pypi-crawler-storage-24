"""Tests for async_guard — async client wrapping with budget enforcement."""

import asyncio
import pytest

from tokenfence import async_guard, BudgetExceeded, TokenFenceError


# ---------------------------------------------------------------------------
# Mock async clients
# ---------------------------------------------------------------------------

class _MockUsage:
    def __init__(self, prompt_tokens=10, completion_tokens=20):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _MockResponse:
    def __init__(self, content="Hello", model="gpt-4o", usage=None):
        self.model = model
        self.usage = usage or _MockUsage()
        self.choices = [type("C", (), {"message": type("M", (), {"content": content, "role": "assistant"})(), "index": 0, "finish_reason": "stop"})()]


class _MockAnthropicUsage:
    def __init__(self, input_tokens=10, output_tokens=20):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _MockAnthropicResponse:
    def __init__(self, text="Hello", model="claude-3-haiku-20240307", usage=None):
        self.model = model
        self.usage = usage or _MockAnthropicUsage()
        self.content = [type("B", (), {"type": "text", "text": text})()]
        self.role = "assistant"
        self.stop_reason = "end_turn"


class _MockAsyncCompletions:
    def __init__(self, response=None):
        self._response = response or _MockResponse()
        self.last_kwargs = None

    async def create(self, **kwargs):
        self.last_kwargs = kwargs
        return self._response


class _MockAsyncChat:
    def __init__(self, completions=None):
        self.completions = completions or _MockAsyncCompletions()


class _MockAsyncOpenAI:
    def __init__(self, chat=None):
        self.chat = chat or _MockAsyncChat()
        self.api_key = "test"


class _MockAsyncAnthropicMessages:
    def __init__(self, response=None):
        self._response = response or _MockAnthropicResponse()
        self.last_kwargs = None

    async def create(self, **kwargs):
        self.last_kwargs = kwargs
        return self._response


class _MockAsyncAnthropic:
    def __init__(self, messages=None):
        self.messages = messages or _MockAsyncAnthropicMessages()
        self.api_key = "test"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_openai():
    return _MockAsyncOpenAI()


@pytest.fixture
def mock_anthropic():
    return _MockAsyncAnthropic()


class TestAsyncGuardBasic:
    """Basic async guard functionality."""

    def test_returns_guarded_client(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$1.00")
        assert guarded.tokenfence is not None
        assert guarded.tokenfence.budget == 1.0

    def test_invalid_budget_raises(self, mock_openai):
        with pytest.raises(TokenFenceError):
            async_guard(mock_openai, budget="abc")

    def test_negative_budget_raises(self, mock_openai):
        with pytest.raises(TokenFenceError):
            async_guard(mock_openai, budget=-1)

    def test_invalid_on_limit_raises(self, mock_openai):
        with pytest.raises(TokenFenceError):
            async_guard(mock_openai, budget=1.0, on_limit="invalid")

    def test_invalid_threshold_raises(self, mock_openai):
        with pytest.raises(TokenFenceError):
            async_guard(mock_openai, budget=1.0, threshold=1.5)

    def test_passthrough_attributes(self, mock_openai):
        guarded = async_guard(mock_openai, budget=1.0)
        assert guarded.api_key == "test"


class TestAsyncGuardOpenAI:
    """Async OpenAI client integration."""

    @pytest.mark.asyncio
    async def test_basic_call_tracks_cost(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$10.00")
        resp = await guarded.chat.completions.create(model="gpt-4o", messages=[])
        assert resp.choices[0].message.content == "Hello"
        assert guarded.tokenfence.spent > 0
        assert guarded.tokenfence.calls == 1

    @pytest.mark.asyncio
    async def test_auto_downgrade(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$0.001", fallback="gpt-4o-mini", threshold=0.0)
        # threshold=0.0 means downgrade immediately
        await guarded.chat.completions.create(model="gpt-4o", messages=[])
        assert mock_openai.chat.completions.last_kwargs["model"] == "gpt-4o-mini"

    @pytest.mark.asyncio
    async def test_on_limit_stop(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$0.00001", on_limit="stop")
        # First call exhausts the tiny budget
        await guarded.chat.completions.create(model="gpt-4o", messages=[])
        # Second call should return synthetic response
        resp = await guarded.chat.completions.create(model="gpt-4o", messages=[])
        assert "Budget" in resp.choices[0].message.content
        assert "exceeded" in resp.choices[0].message.content

    @pytest.mark.asyncio
    async def test_on_limit_raise(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$0.00001", on_limit="raise")
        await guarded.chat.completions.create(model="gpt-4o", messages=[])
        with pytest.raises(BudgetExceeded):
            await guarded.chat.completions.create(model="gpt-4o", messages=[])

    @pytest.mark.asyncio
    async def test_on_limit_warn(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$0.00001", on_limit="warn")
        await guarded.chat.completions.create(model="gpt-4o", messages=[])
        # Should still make the call (warn only)
        resp = await guarded.chat.completions.create(model="gpt-4o", messages=[])
        assert resp.choices[0].message.content == "Hello"

    @pytest.mark.asyncio
    async def test_multiple_calls_accumulate(self, mock_openai):
        guarded = async_guard(mock_openai, budget="$100.00")
        for _ in range(5):
            await guarded.chat.completions.create(model="gpt-4o", messages=[])
        assert guarded.tokenfence.calls == 5
        assert guarded.tokenfence.spent > 0


class TestAsyncGuardAnthropic:
    """Async Anthropic client integration."""

    @pytest.mark.asyncio
    async def test_basic_call_tracks_cost(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget="$10.00")
        resp = await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        assert resp.content[0].text == "Hello"
        assert guarded.tokenfence.spent > 0
        assert guarded.tokenfence.calls == 1

    @pytest.mark.asyncio
    async def test_auto_downgrade(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget="$0.001", fallback="claude-3-haiku-20240307", threshold=0.0)
        await guarded.messages.create(model="claude-3-opus-20240229", messages=[], max_tokens=100)
        assert mock_anthropic.messages.last_kwargs["model"] == "claude-3-haiku-20240307"

    @pytest.mark.asyncio
    async def test_on_limit_stop(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget="$0.00001", on_limit="stop")
        await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        resp = await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        assert "Budget" in resp.content[0].text

    @pytest.mark.asyncio
    async def test_on_limit_raise(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget="$0.00001", on_limit="raise")
        await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        with pytest.raises(BudgetExceeded):
            await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)

    @pytest.mark.asyncio
    async def test_on_limit_warn(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget="$0.00001", on_limit="warn")
        await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        resp = await guarded.messages.create(model="claude-3-haiku-20240307", messages=[], max_tokens=100)
        assert resp.content[0].text == "Hello"

    @pytest.mark.asyncio
    async def test_passthrough_attributes(self, mock_anthropic):
        guarded = async_guard(mock_anthropic, budget=1.0)
        assert guarded.api_key == "test"
