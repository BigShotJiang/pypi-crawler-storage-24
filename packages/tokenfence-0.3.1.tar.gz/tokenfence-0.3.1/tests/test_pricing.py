"""Tests for tokenfence.pricing."""

import unittest

from tokenfence.pricing import MODEL_PRICES, calculate_cost, get_token_cost


class TestGetTokenCost(unittest.TestCase):
    def test_known_model(self):
        result = get_token_cost("gpt-4o")
        self.assertIsNotNone(result)
        input_cost, output_cost = result  # type: ignore[misc]
        self.assertAlmostEqual(input_cost, 2.50 / 1_000_000)
        self.assertAlmostEqual(output_cost, 10.00 / 1_000_000)

    def test_unknown_model(self):
        self.assertIsNone(get_token_cost("nonexistent-model"))

    def test_all_models_have_two_prices(self):
        for model, prices in MODEL_PRICES.items():
            self.assertEqual(len(prices), 2, f"{model} should have (input, output) tuple")
            self.assertGreater(prices[0], 0, f"{model} input price should be positive")
            self.assertGreater(prices[1], 0, f"{model} output price should be positive")


class TestCalculateCost(unittest.TestCase):
    def test_basic_calculation(self):
        # gpt-4o: $2.50/1M input, $10.00/1M output
        cost = calculate_cost("gpt-4o", input_tokens=1000, output_tokens=500)
        expected = 1000 * (2.50 / 1_000_000) + 500 * (10.00 / 1_000_000)
        self.assertAlmostEqual(cost, expected)

    def test_unknown_model_returns_zero(self):
        self.assertEqual(calculate_cost("unknown", 1000, 1000), 0.0)

    def test_zero_tokens(self):
        self.assertEqual(calculate_cost("gpt-4o", 0, 0), 0.0)

    def test_mini_cheaper_than_full(self):
        full = calculate_cost("gpt-4o", 1000, 1000)
        mini = calculate_cost("gpt-4o-mini", 1000, 1000)
        self.assertGreater(full, mini)


if __name__ == "__main__":
    unittest.main()
