"""Tests for tokenfence.tracker."""

import threading
import unittest

from tokenfence.tracker import CostTracker


class TestCostTracker(unittest.TestCase):
    def test_initial_state(self):
        t = CostTracker(budget=1.0)
        self.assertEqual(t.spent, 0.0)
        self.assertEqual(t.remaining, 1.0)
        self.assertEqual(t.calls, 0)
        self.assertAlmostEqual(t.usage_ratio, 0.0)
        self.assertFalse(t.should_downgrade)
        self.assertFalse(t.budget_exceeded)

    def test_record(self):
        t = CostTracker(budget=1.0)
        t.record(0.25)
        self.assertAlmostEqual(t.spent, 0.25)
        self.assertAlmostEqual(t.remaining, 0.75)
        self.assertEqual(t.calls, 1)

    def test_multiple_records(self):
        t = CostTracker(budget=1.0)
        t.record(0.3)
        t.record(0.3)
        t.record(0.3)
        self.assertAlmostEqual(t.spent, 0.9)
        self.assertEqual(t.calls, 3)

    def test_should_downgrade_at_threshold(self):
        t = CostTracker(budget=1.0, threshold=0.8)
        t.record(0.79)
        self.assertFalse(t.should_downgrade)
        t.record(0.01)
        self.assertTrue(t.should_downgrade)

    def test_budget_exceeded(self):
        t = CostTracker(budget=0.50)
        t.record(0.50)
        self.assertTrue(t.budget_exceeded)

    def test_remaining_never_negative(self):
        t = CostTracker(budget=0.10)
        t.record(0.20)
        self.assertEqual(t.remaining, 0.0)

    def test_reset(self):
        t = CostTracker(budget=1.0)
        t.record(0.5)
        t.record(0.3)
        t.reset()
        self.assertEqual(t.spent, 0.0)
        self.assertEqual(t.calls, 0)
        self.assertEqual(t.remaining, 1.0)

    def test_zero_budget(self):
        t = CostTracker(budget=0.0)
        self.assertAlmostEqual(t.usage_ratio, 1.0)
        self.assertTrue(t.budget_exceeded)

    def test_thread_safety(self):
        t = CostTracker(budget=100.0)
        n_threads = 10
        n_records = 1000

        def worker():
            for _ in range(n_records):
                t.record(0.001)

        threads = [threading.Thread(target=worker) for _ in range(n_threads)]
        for th in threads:
            th.start()
        for th in threads:
            th.join()

        self.assertEqual(t.calls, n_threads * n_records)
        self.assertAlmostEqual(t.spent, n_threads * n_records * 0.001, places=4)


if __name__ == "__main__":
    unittest.main()
