"""Tests for the TokenFence edition/freemium system."""

import logging
import importlib
import tokenfence._edition as edition_mod


def _fresh_state():
    """Create a clean _EditionState for each test."""
    return edition_mod._EditionState()


def test_default_edition_is_community():
    state = _fresh_state()
    assert state.edition == edition_mod.Edition.COMMUNITY


def test_set_pro_key():
    state = _fresh_state()
    state.set_api_key("tf_test_12345")
    assert state.edition == edition_mod.Edition.PRO


def test_set_enterprise_key():
    state = _fresh_state()
    state.set_api_key("tf_ent_test_12345")
    assert state.edition == edition_mod.Edition.ENTERPRISE


def test_nudge_at_50_calls(caplog):
    state = _fresh_state()
    with caplog.at_level(logging.INFO, logger="tokenfence"):
        for _ in range(50):
            state.record_call()
    assert "Community Edition" in caplog.text
    assert "tokenfence.dev/pricing" in caplog.text


def test_no_nudge_before_50_calls(caplog):
    state = _fresh_state()
    with caplog.at_level(logging.INFO, logger="tokenfence"):
        for _ in range(49):
            state.record_call()
    assert "Community Edition" not in caplog.text


def test_no_nudge_with_pro_key(caplog):
    state = _fresh_state()
    state.set_api_key("tf_test_key")
    with caplog.at_level(logging.INFO, logger="tokenfence"):
        for _ in range(200):
            state.record_call()
    # Should not see "Community Edition" nudge when on Pro
    assert "Community Edition" not in caplog.text


def test_nudge_repeats_at_intervals(caplog):
    state = _fresh_state()
    with caplog.at_level(logging.INFO, logger="tokenfence"):
        for _ in range(150):
            state.record_call()
    # First nudge at 50, second nudge at 150 (50 + 100)
    count = caplog.text.count("Community Edition")
    assert count == 2


def test_public_api():
    """Verify the public set_api_key and get_edition functions work."""
    import tokenfence
    assert hasattr(tokenfence, "set_api_key")
    assert hasattr(tokenfence, "get_edition")
    assert hasattr(tokenfence, "Edition")
    # get_edition should return an Edition enum value
    ed = tokenfence.get_edition()
    assert isinstance(ed, tokenfence.Edition)
