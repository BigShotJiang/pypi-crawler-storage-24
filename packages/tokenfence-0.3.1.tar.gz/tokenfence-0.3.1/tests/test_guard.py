"""Tests for tokenfence.guard."""

import logging
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock

from tokenfence import BudgetExceeded, TokenFenceError, guard


def _make_response(prompt_tokens: int = 100, completion_tokens: int = 50, model: str = "gpt-4o"):
    """Build a fake OpenAI ChatCompletion response."""
    usage = SimpleNamespace(prompt_tokens=prompt_tokens, completion_tokens=completion_tokens, total_tokens=prompt_tokens + completion_tokens)
    message = SimpleNamespace(role="assistant", content="Hello!")
    choice = SimpleNamespace(index=0, message=message, finish_reason="stop")
    return SimpleNamespace(id="chatcmpl-test", object="chat.completion", model=model, usage=usage, choices=[choice])


def _make_client(response=None):
    """Build a mock OpenAI client."""
    if response is None:
        response = _make_response()
    client = MagicMock()
    client.chat.completions.create.return_value = response
    return client


class TestGuardValidation(unittest.TestCase):
    def test_string_budget(self):
        c = guard(_make_client(), budget="$1.00")
        self.assertAlmostEqual(c.tokenfence.budget, 1.0)

    def test_float_budget(self):
        c = guard(_make_client(), budget=2.5)
        self.assertAlmostEqual(c.tokenfence.budget, 2.5)

    def test_invalid_budget_string(self):
        with self.assertRaises(TokenFenceError):
            guard(_make_client(), budget="free")

    def test_zero_budget(self):
        with self.assertRaises(TokenFenceError):
            guard(_make_client(), budget=0)

    def test_negative_budget(self):
        with self.assertRaises(TokenFenceError):
            guard(_make_client(), budget=-1)

    def test_invalid_on_limit(self):
        with self.assertRaises(TokenFenceError):
            guard(_make_client(), budget=1, on_limit="explode")  # type: ignore[arg-type]

    def test_invalid_threshold(self):
        with self.assertRaises(TokenFenceError):
            guard(_make_client(), budget=1, threshold=1.5)


class TestCostTracking(unittest.TestCase):
    def test_tracks_single_call(self):
        client = _make_client(_make_response(prompt_tokens=1000, completion_tokens=500))
        c = guard(client, budget="$10.00")
        c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertEqual(c.tokenfence.calls, 1)
        self.assertGreater(c.tokenfence.spent, 0)
        self.assertLess(c.tokenfence.spent, c.tokenfence.budget)

    def test_tracks_multiple_calls(self):
        client = _make_client(_make_response(prompt_tokens=100, completion_tokens=50))
        c = guard(client, budget="$10.00")

        for _ in range(5):
            c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertEqual(c.tokenfence.calls, 5)

    def test_unknown_model_zero_cost(self):
        client = _make_client(_make_response())
        c = guard(client, budget="$10.00")
        c.chat.completions.create(model="unknown-model", messages=[])

        self.assertEqual(c.tokenfence.calls, 1)
        self.assertAlmostEqual(c.tokenfence.spent, 0.0)

    def test_no_usage_on_response(self):
        response = SimpleNamespace(id="chatcmpl-test", choices=[])
        client = _make_client(response)
        c = guard(client, budget="$10.00")
        c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertEqual(c.tokenfence.calls, 1)
        self.assertAlmostEqual(c.tokenfence.spent, 0.0)


class TestAutoDowngrade(unittest.TestCase):
    def test_downgrades_at_threshold(self):
        client = _make_client()
        c = guard(client, budget="$0.01", fallback="gpt-4o-mini", threshold=0.8)

        # Manually push tracker past threshold
        c.tokenfence.record(0.009)  # 90% of $0.01

        c.chat.completions.create(model="gpt-4o", messages=[])

        # The underlying client should have been called with the fallback model
        call_kwargs = client.chat.completions.create.call_args
        self.assertEqual(call_kwargs.kwargs.get("model") or call_kwargs[1].get("model"), "gpt-4o-mini")

    def test_no_downgrade_below_threshold(self):
        client = _make_client()
        c = guard(client, budget="$10.00", fallback="gpt-4o-mini", threshold=0.8)

        c.chat.completions.create(model="gpt-4o", messages=[])

        call_kwargs = client.chat.completions.create.call_args
        self.assertEqual(call_kwargs.kwargs.get("model") or call_kwargs[1].get("model"), "gpt-4o")

    def test_no_downgrade_without_fallback(self):
        client = _make_client()
        c = guard(client, budget="$0.01", threshold=0.8)

        c.tokenfence.record(0.009)
        c.chat.completions.create(model="gpt-4o", messages=[])

        call_kwargs = client.chat.completions.create.call_args
        self.assertEqual(call_kwargs.kwargs.get("model") or call_kwargs[1].get("model"), "gpt-4o")

    def test_downgrade_logs_warning(self):
        client = _make_client()
        c = guard(client, budget="$0.01", fallback="gpt-4o-mini", threshold=0.8)
        c.tokenfence.record(0.009)

        with self.assertLogs("tokenfence", level="WARNING") as cm:
            c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertTrue(any("downgrading" in msg.lower() for msg in cm.output))


class TestKillSwitch(unittest.TestCase):
    def test_on_limit_stop(self):
        client = _make_client()
        c = guard(client, budget="$0.01", on_limit="stop")
        c.tokenfence.record(0.01)  # exhaust budget

        response = c.chat.completions.create(model="gpt-4o", messages=[])

        # Should NOT have called the real API
        client.chat.completions.create.assert_not_called()
        # Should return a synthetic response
        self.assertIn("TokenFence", response.choices[0].message.content)
        self.assertIn("exceeded", response.choices[0].message.content)

    def test_on_limit_raise(self):
        client = _make_client()
        c = guard(client, budget="$0.01", on_limit="raise")
        c.tokenfence.record(0.01)

        with self.assertRaises(BudgetExceeded) as ctx:
            c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertAlmostEqual(ctx.exception.budget, 0.01)
        client.chat.completions.create.assert_not_called()

    def test_on_limit_warn(self):
        client = _make_client()
        c = guard(client, budget="$0.01", on_limit="warn")
        c.tokenfence.record(0.01)

        with self.assertLogs("tokenfence", level="WARNING"):
            c.chat.completions.create(model="gpt-4o", messages=[])

        # Should still call the real API
        client.chat.completions.create.assert_called_once()


class TestPassthrough(unittest.TestCase):
    def test_non_chat_attributes_pass_through(self):
        client = _make_client()
        client.models = MagicMock()
        client.models.list.return_value = ["gpt-4o"]

        c = guard(client, budget="$1.00")
        result = c.models.list()
        self.assertEqual(result, ["gpt-4o"])

    def test_tokenfence_reset(self):
        client = _make_client()
        c = guard(client, budget="$1.00")
        c.chat.completions.create(model="gpt-4o", messages=[])

        self.assertGreater(c.tokenfence.calls, 0)
        c.tokenfence.reset()
        self.assertEqual(c.tokenfence.calls, 0)
        self.assertAlmostEqual(c.tokenfence.spent, 0.0)


if __name__ == "__main__":
    unittest.main()
