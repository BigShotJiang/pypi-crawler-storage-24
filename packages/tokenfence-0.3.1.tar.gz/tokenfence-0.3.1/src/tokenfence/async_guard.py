"""Async ``guard()`` function — wraps async OpenAI/Anthropic clients with cost controls."""

from __future__ import annotations

import logging
from typing import Any, Literal, Optional, Union

from .exceptions import BudgetExceeded, TokenFenceError
from .pricing import calculate_cost
from .tracker import CostTracker

logger = logging.getLogger("tokenfence")

OnLimit = Literal["stop", "warn", "raise"]


def _parse_budget(budget: Union[str, float, int]) -> float:
    """Convert a budget value like ``'$0.50'`` or ``0.50`` to a float."""
    if isinstance(budget, str):
        cleaned = budget.strip().lstrip("$").strip()
        try:
            return float(cleaned)
        except ValueError:
            raise TokenFenceError(f"Invalid budget string: {budget!r}") from None
    return float(budget)


def async_guard(
    client: Any,
    *,
    budget: Union[str, float, int],
    fallback: Optional[str] = None,
    on_limit: OnLimit = "stop",
    threshold: float = 0.8,
) -> Any:
    """Wrap an async OpenAI/Anthropic client with cost tracking and budget enforcement.

    This is the async counterpart to :func:`guard`. Use it with
    ``openai.AsyncOpenAI`` or ``anthropic.AsyncAnthropic`` clients.

    Args:
        client: An ``openai.AsyncOpenAI`` or ``anthropic.AsyncAnthropic`` client.
        budget: Maximum spend in USD — accepts ``'$0.50'`` or ``0.50``.
        fallback: Model name to downgrade to when the threshold is reached.
        on_limit: Behaviour when the budget is exhausted —
            ``'stop'`` returns a synthetic response,
            ``'warn'`` logs a warning and allows the call,
            ``'raise'`` raises :class:`BudgetExceeded`.
        threshold: Fraction of the budget (0.0–1.0) at which to start
            downgrading to the *fallback* model.

    Returns:
        A wrapped async client that is a drop-in replacement for the original.
    """
    if on_limit not in ("stop", "warn", "raise"):
        raise TokenFenceError(f"on_limit must be 'stop', 'warn', or 'raise', got {on_limit!r}")
    if not 0.0 <= threshold <= 1.0:
        raise TokenFenceError(f"threshold must be between 0.0 and 1.0, got {threshold!r}")

    parsed_budget = _parse_budget(budget)
    if parsed_budget <= 0:
        raise TokenFenceError(f"budget must be positive, got {parsed_budget}")

    tracker = CostTracker(budget=parsed_budget, threshold=threshold)

    return _AsyncGuardedClient(
        client=client,
        tracker=tracker,
        fallback=fallback,
        on_limit=on_limit,
    )


# ---------------------------------------------------------------------------
# Internal async proxy objects
# ---------------------------------------------------------------------------

class _AsyncGuardedClient:
    """Transparent proxy around an async OpenAI/Anthropic client."""

    def __init__(
        self,
        client: Any,
        tracker: CostTracker,
        fallback: Optional[str],
        on_limit: OnLimit,
    ) -> None:
        self._client = client
        self._tracker = tracker
        self._fallback = fallback
        self._on_limit = on_limit

    @property
    def tokenfence(self) -> CostTracker:
        return self._tracker

    @property
    def chat(self) -> "_AsyncGuardedChat":
        return _AsyncGuardedChat(self._client.chat, self._tracker, self._fallback, self._on_limit)

    @property
    def messages(self) -> "_AsyncGuardedAnthropicMessages":
        return _AsyncGuardedAnthropicMessages(self._client.messages, self._tracker, self._fallback, self._on_limit)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class _AsyncGuardedChat:
    """Proxy for ``client.chat``."""

    def __init__(self, chat: Any, tracker: CostTracker, fallback: Optional[str], on_limit: OnLimit) -> None:
        self._chat = chat
        self._tracker = tracker
        self._fallback = fallback
        self._on_limit = on_limit

    @property
    def completions(self) -> "_AsyncGuardedCompletions":
        return _AsyncGuardedCompletions(self._chat.completions, self._tracker, self._fallback, self._on_limit)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _AsyncGuardedCompletions:
    """Async proxy for ``client.chat.completions`` — intercepts ``create()``."""

    def __init__(self, completions: Any, tracker: CostTracker, fallback: Optional[str], on_limit: OnLimit) -> None:
        self._completions = completions
        self._tracker = tracker
        self._fallback = fallback
        self._on_limit = on_limit

    async def create(self, **kwargs: Any) -> Any:
        """Intercept ``chat.completions.create()`` with budget enforcement (async)."""
        tracker = self._tracker

        # --- Kill switch: budget already exhausted --------------------------
        if tracker.budget_exceeded:
            return await self._handle_limit(kwargs)

        # --- Auto-downgrade -------------------------------------------------
        original_model = kwargs.get("model")
        if tracker.should_downgrade and self._fallback and original_model != self._fallback:
            logger.warning(
                "TokenFence: spend $%.4f has reached %.0f%% of $%.4f budget — "
                "downgrading from %s to %s",
                tracker.spent,
                tracker.usage_ratio * 100,
                tracker.budget,
                original_model,
                self._fallback,
            )
            kwargs["model"] = self._fallback

        # --- Make the real async API call -----------------------------------
        response = await self._completions.create(**kwargs)

        # --- Track cost -----------------------------------------------------
        model_used = kwargs.get("model", original_model) or ""
        usage = getattr(response, "usage", None)
        if usage is not None:
            input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            output_tokens = getattr(usage, "completion_tokens", 0) or 0
            cost = calculate_cost(model_used, input_tokens, output_tokens)
            tracker.record(cost)
        else:
            tracker.record(0.0)

        return response

    async def _handle_limit(self, kwargs: dict[str, Any]) -> Any:
        tracker = self._tracker
        if self._on_limit == "raise":
            raise BudgetExceeded(budget=tracker.budget, spent=tracker.spent)

        if self._on_limit == "warn":
            logger.warning(
                "TokenFence: budget of $%.4f exhausted (spent $%.4f) — allowing call anyway",
                tracker.budget,
                tracker.spent,
            )
            return await self._completions.create(**kwargs)

        # on_limit == "stop"
        return _synthetic_response(tracker)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._completions, name)


class _AsyncGuardedAnthropicMessages:
    """Async proxy for Anthropic ``client.messages`` — intercepts ``create()``."""

    def __init__(self, messages: Any, tracker: CostTracker, fallback: Optional[str], on_limit: OnLimit) -> None:
        self._messages = messages
        self._tracker = tracker
        self._fallback = fallback
        self._on_limit = on_limit

    async def create(self, **kwargs: Any) -> Any:
        """Intercept ``messages.create()`` with budget enforcement (async)."""
        tracker = self._tracker

        if tracker.budget_exceeded:
            return await self._handle_limit(kwargs)

        original_model = kwargs.get("model")
        if tracker.should_downgrade and self._fallback and original_model != self._fallback:
            logger.warning(
                "TokenFence: spend $%.4f has reached %.0f%% of $%.4f budget — "
                "downgrading from %s to %s",
                tracker.spent,
                tracker.usage_ratio * 100,
                tracker.budget,
                original_model,
                self._fallback,
            )
            kwargs["model"] = self._fallback

        response = await self._messages.create(**kwargs)

        model_used = kwargs.get("model", original_model) or ""
        usage = getattr(response, "usage", None)
        if usage is not None:
            input_tokens = getattr(usage, "input_tokens", 0) or 0
            output_tokens = getattr(usage, "output_tokens", 0) or 0
            cost = calculate_cost(model_used, input_tokens, output_tokens)
            tracker.record(cost)
        else:
            tracker.record(0.0)

        return response

    async def _handle_limit(self, kwargs: dict[str, Any]) -> Any:
        tracker = self._tracker
        if self._on_limit == "raise":
            raise BudgetExceeded(budget=tracker.budget, spent=tracker.spent)

        if self._on_limit == "warn":
            logger.warning(
                "TokenFence: budget of $%.4f exhausted (spent $%.4f) — allowing call anyway",
                tracker.budget,
                tracker.spent,
            )
            return await self._messages.create(**kwargs)

        return _synthetic_anthropic_response(tracker)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._messages, name)


# ---------------------------------------------------------------------------
# Re-use synthetic response classes from guard module
# ---------------------------------------------------------------------------

from .guard import _synthetic_response, _synthetic_anthropic_response  # noqa: E402
