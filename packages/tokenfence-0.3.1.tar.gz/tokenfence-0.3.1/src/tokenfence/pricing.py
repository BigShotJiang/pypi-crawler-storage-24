"""Model pricing database.

Prices are stored per 1M tokens for readability, then converted to per-token
costs via :func:`get_token_cost`.
"""

from __future__ import annotations

from typing import Optional, Tuple

# {model_name: (input_price_per_1M, output_price_per_1M)}
MODEL_PRICES: dict[str, Tuple[float, float]] = {
    # GPT-4o family
    "gpt-4o":                   (2.50,  10.00),
    "gpt-4o-2024-11-20":        (2.50,  10.00),
    "gpt-4o-2024-08-06":        (2.50,  10.00),
    "gpt-4o-mini":              (0.15,   0.60),
    "gpt-4o-mini-2024-07-18":   (0.15,   0.60),
    # GPT-4 Turbo
    "gpt-4-turbo":              (10.00,  30.00),
    "gpt-4-turbo-2024-04-09":   (10.00,  30.00),
    # GPT-3.5 Turbo
    "gpt-3.5-turbo":            (0.50,   1.50),
    "gpt-3.5-turbo-0125":       (0.50,   1.50),
    # GPT-5.4 family
    "gpt-5.4":                  (3.00,  12.00),
    "gpt-5.4-mini":             (0.20,   0.80),
    "gpt-5.4-nano":             (0.05,   0.20),
    # o-series reasoning models
    "o1":                       (15.00,  60.00),
    "o1-2024-12-17":            (15.00,  60.00),
    "o1-mini":                  (3.00,   12.00),
    "o1-mini-2024-09-12":       (3.00,   12.00),
    "o3":                       (10.00,  40.00),
    "o3-mini":                  (1.10,   4.40),
    # --- Anthropic Claude ---
    "claude-opus-4-0520":       (15.00,  75.00),
    "claude-sonnet-4-0514":     (3.00,   15.00),
    "claude-3-7-sonnet-20250219": (3.00, 15.00),
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-3-5-sonnet-20240620": (3.00, 15.00),
    "claude-3-5-haiku-20241022": (0.80,  4.00),
    "claude-3-opus-20240229":   (15.00,  75.00),
    "claude-3-sonnet-20240229": (3.00,   15.00),
    "claude-3-haiku-20240307":  (0.25,   1.25),
    # --- Google Gemini ---
    "gemini-2.5-pro":           (1.25,  10.00),
    "gemini-2.5-flash":         (0.15,   0.60),
    "gemini-2.0-flash":         (0.10,   0.40),
    "gemini-1.5-pro":           (1.25,   5.00),
    "gemini-1.5-flash":         (0.075,  0.30),
    # --- DeepSeek ---
    "deepseek-chat":            (0.27,   1.10),
    "deepseek-reasoner":        (0.55,   2.19),
}

_PER_MILLION = 1_000_000.0


def get_token_cost(model: str) -> Optional[Tuple[float, float]]:
    """Return ``(input_cost_per_token, output_cost_per_token)`` for *model*.

    Returns ``None`` if the model is not in the pricing database.
    """
    entry = MODEL_PRICES.get(model)
    if entry is None:
        return None
    return (entry[0] / _PER_MILLION, entry[1] / _PER_MILLION)


def calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Calculate the USD cost for a single API call.

    Returns ``0.0`` if the model is unknown.
    """
    costs = get_token_cost(model)
    if costs is None:
        return 0.0
    input_cost, output_cost = costs
    return input_tokens * input_cost + output_tokens * output_cost
