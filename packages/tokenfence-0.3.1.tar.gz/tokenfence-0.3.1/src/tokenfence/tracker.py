"""Thread-safe cost tracker for a guarded client instance."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field


@dataclass
class CostTracker:
    """Accumulates per-call cost data for a single guarded client.

    All mutating methods are thread-safe.
    """

    budget: float
    threshold: float = 0.8
    _spent: float = field(default=0.0, init=False, repr=False)
    _calls: int = field(default=0, init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    # -- public read-only properties ------------------------------------------

    @property
    def spent(self) -> float:
        """Total USD spent so far."""
        with self._lock:
            return self._spent

    @property
    def remaining(self) -> float:
        """USD remaining before the budget is exhausted."""
        with self._lock:
            return max(0.0, self.budget - self._spent)

    @property
    def calls(self) -> int:
        """Number of tracked API calls."""
        with self._lock:
            return self._calls

    @property
    def usage_ratio(self) -> float:
        """Fraction of budget consumed (0.0 – 1.0+)."""
        if self.budget <= 0:
            return 1.0
        with self._lock:
            return self._spent / self.budget

    @property
    def should_downgrade(self) -> bool:
        """``True`` when spend has reached the threshold fraction of budget."""
        return self.usage_ratio >= self.threshold

    @property
    def budget_exceeded(self) -> bool:
        """``True`` when cumulative spend meets or exceeds the budget."""
        return self.usage_ratio >= 1.0

    # -- mutating methods -----------------------------------------------------

    def record(self, cost: float) -> None:
        """Record the cost of a single API call."""
        with self._lock:
            self._spent += cost
            self._calls += 1

    def reset(self) -> None:
        """Reset spend and call count to zero."""
        with self._lock:
            self._spent = 0.0
            self._calls = 0
