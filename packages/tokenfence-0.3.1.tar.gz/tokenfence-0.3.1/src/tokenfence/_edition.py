"""TokenFence edition management — Community (free) vs Pro vs Enterprise.

Community Edition is fully functional with a soft upgrade nudge after
a threshold of API calls.  Setting an API key unlocks Pro/Enterprise
features (dashboard sync, Slack/webhook alerts, multi-agent budget
pooling, priority support).

This module never blocks or degrades functionality — it only surfaces
awareness of the paid tier.
"""

from __future__ import annotations

import logging
import threading
from enum import Enum
from typing import Optional

logger = logging.getLogger("tokenfence")

_NUDGE_INTERVAL = 100  # show upgrade message every N calls after first trigger
_FIRST_NUDGE_AT = 50   # first nudge after this many tracked calls


class Edition(Enum):
    COMMUNITY = "community"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class _EditionState:
    """Singleton tracking the current edition and global call count."""

    def __init__(self) -> None:
        self._api_key: Optional[str] = None
        self._edition: Edition = Edition.COMMUNITY
        self._global_calls: int = 0
        self._last_nudge_at: int = 0
        self._lock = threading.Lock()

    @property
    def edition(self) -> Edition:
        return self._edition

    @property
    def api_key(self) -> Optional[str]:
        return self._api_key

    def set_api_key(self, key: str) -> None:
        """Activate a paid edition with an API key from tokenfence.dev."""
        self._api_key = key
        # For now, any valid key = Pro. Enterprise keys will have a prefix.
        if key.startswith("tf_ent_"):
            self._edition = Edition.ENTERPRISE
        elif key.startswith("tf_") or key:
            self._edition = Edition.PRO
        logger.info(
            "TokenFence %s Edition activated.",
            self._edition.value.title(),
        )

    def record_call(self) -> None:
        """Increment global call counter and maybe show upgrade nudge."""
        if self._edition != Edition.COMMUNITY:
            return

        with self._lock:
            self._global_calls += 1
            count = self._global_calls

        if count == _FIRST_NUDGE_AT:
            self._show_nudge(count)
        elif count > _FIRST_NUDGE_AT and (count - self._last_nudge_at) >= _NUDGE_INTERVAL:
            self._show_nudge(count)

    def _show_nudge(self, count: int) -> None:
        self._last_nudge_at = count
        logger.info(
            "\n"
            "  ╔══════════════════════════════════════════════════════╗\n"
            "  ║  TokenFence Community Edition — %d calls tracked     ║\n"
            "  ║                                                      ║\n"
            "  ║  Upgrade to Pro for:                                 ║\n"
            "  ║  • Real-time cost dashboard                          ║\n"
            "  ║  • Slack & webhook budget alerts                     ║\n"
            "  ║  • Multi-agent budget pooling                        ║\n"
            "  ║  • Priority support                                  ║\n"
            "  ║                                                      ║\n"
            "  ║  → tokenfence.dev/pricing                            ║\n"
            "  ╚══════════════════════════════════════════════════════╝",
            count,
        )


# Module-level singleton
_state = _EditionState()


def set_api_key(key: str) -> None:
    """Set your TokenFence API key to unlock Pro/Enterprise features.

    Get your key at https://tokenfence.dev/pricing

    Args:
        key: Your API key (starts with ``tf_`` for Pro, ``tf_ent_`` for Enterprise).
    """
    _state.set_api_key(key)


def get_edition() -> Edition:
    """Return the current TokenFence edition."""
    return _state.edition


def _record_call() -> None:
    """Internal: increment the global call counter."""
    _state.record_call()
