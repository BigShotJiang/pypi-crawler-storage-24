"""TokenFence exceptions."""


class TokenFenceError(Exception):
    """Base exception for all TokenFence errors."""


class BudgetExceeded(TokenFenceError):
    """Raised when the budget has been fully consumed and on_limit='raise'."""

    def __init__(self, budget: float, spent: float) -> None:
        self.budget = budget
        self.spent = spent
        super().__init__(
            f"Budget of ${budget:.4f} exceeded (spent ${spent:.4f})"
        )
