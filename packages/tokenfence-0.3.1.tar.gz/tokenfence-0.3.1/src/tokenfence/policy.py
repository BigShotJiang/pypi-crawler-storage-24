"""AgentGuard Policy engine — least-privilege enforcement for AI agents.

Define what tools agents can and cannot use, require human approval for
dangerous operations, and audit every decision.

Example::

    from tokenfence import Policy

    policy = Policy(
        allow=["read_database", "generate_report"],
        deny=["delete_*", "drop_*", "truncate_*"],
        require_approval=["write_database", "send_email"],
    )

    # Check if a tool call is permitted
    decision = policy.check("read_database")
    assert decision.allowed

    decision = policy.check("drop_table")
    assert not decision.allowed
    assert decision.reason == "denied by pattern: drop_*"
"""

from __future__ import annotations

import fnmatch
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Sequence

from .exceptions import TokenFenceError

logger = logging.getLogger("tokenfence.policy")


class Decision(Enum):
    """Result of a policy check."""
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


@dataclass(frozen=True)
class PolicyResult:
    """Outcome of a :meth:`Policy.check` call."""

    decision: Decision
    tool: str
    reason: str
    matched_rule: Optional[str] = None

    @property
    def allowed(self) -> bool:
        """``True`` if the tool call is permitted (no approval needed)."""
        return self.decision == Decision.ALLOW

    @property
    def denied(self) -> bool:
        """``True`` if the tool call was explicitly denied."""
        return self.decision == Decision.DENY

    @property
    def needs_approval(self) -> bool:
        """``True`` if the tool call requires human approval before proceeding."""
        return self.decision == Decision.REQUIRE_APPROVAL


@dataclass
class AuditEntry:
    """A single audit log entry."""

    timestamp: float
    tool: str
    decision: str
    reason: str
    matched_rule: Optional[str]
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "timestamp": self.timestamp,
            "tool": self.tool,
            "decision": self.decision,
            "reason": self.reason,
        }
        if self.matched_rule:
            d["matched_rule"] = self.matched_rule
        if self.context:
            d["context"] = self.context
        return d


class Policy:
    """Least-privilege policy for AI agent tool calls.

    Args:
        allow: List of tool name patterns that are explicitly permitted.
            Supports ``*`` and ``?`` wildcards (fnmatch style).
            If empty/None, all tools are allowed unless denied.
        deny: List of tool name patterns that are explicitly forbidden.
            Deny rules always take precedence over allow rules.
        require_approval: List of tool name patterns that need human
            approval before execution.
        default: Default decision when no rule matches — ``"allow"`` or
            ``"deny"``. Defaults to ``"deny"`` (deny-by-default is safer).
        audit: If ``True``, log all policy decisions to the audit trail.
        on_deny: Callback invoked when a tool call is denied. Receives
            the :class:`PolicyResult`.
        on_approval: Callback invoked when a tool call needs approval.
            Should return ``True`` to approve or ``False`` to deny.
            If not set, require_approval decisions remain as-is.
        name: Optional name for this policy (for logging/debugging).
    """

    def __init__(
        self,
        *,
        allow: Optional[Sequence[str]] = None,
        deny: Optional[Sequence[str]] = None,
        require_approval: Optional[Sequence[str]] = None,
        default: str = "deny",
        audit: bool = True,
        on_deny: Optional[Callable[[PolicyResult], None]] = None,
        on_approval: Optional[Callable[[PolicyResult], bool]] = None,
        name: Optional[str] = None,
    ) -> None:
        if default not in ("allow", "deny"):
            raise TokenFenceError(f"Policy default must be 'allow' or 'deny', got {default!r}")

        self._allow_patterns: List[str] = list(allow) if allow else []
        self._deny_patterns: List[str] = list(deny) if deny else []
        self._approval_patterns: List[str] = list(require_approval) if require_approval else []
        self._default = default
        self._audit_enabled = audit
        self._on_deny = on_deny
        self._on_approval = on_approval
        self._name = name or "default"
        self._audit_log: List[AuditEntry] = []

    @property
    def name(self) -> str:
        return self._name

    @property
    def audit_log(self) -> List[AuditEntry]:
        """Read-only view of the audit trail."""
        return list(self._audit_log)

    def check(self, tool: str, *, context: Optional[Dict[str, Any]] = None) -> PolicyResult:
        """Evaluate whether *tool* is allowed by this policy.

        Args:
            tool: The tool/function name the agent wants to call.
            context: Optional metadata dict attached to the audit entry.

        Returns:
            A :class:`PolicyResult` with the decision, reason, and matched rule.
        """
        ctx = context or {}

        # 1. Deny rules always win (explicit deny > everything)
        for pattern in self._deny_patterns:
            if fnmatch.fnmatch(tool, pattern):
                result = PolicyResult(
                    decision=Decision.DENY,
                    tool=tool,
                    reason=f"denied by pattern: {pattern}",
                    matched_rule=pattern,
                )
                self._record(result, ctx)
                return result

        # 2. Approval rules checked next
        for pattern in self._approval_patterns:
            if fnmatch.fnmatch(tool, pattern):
                result = PolicyResult(
                    decision=Decision.REQUIRE_APPROVAL,
                    tool=tool,
                    reason=f"requires approval per pattern: {pattern}",
                    matched_rule=pattern,
                )
                # If an approval callback is set, invoke it
                if self._on_approval:
                    approved = self._on_approval(result)
                    if approved:
                        result = PolicyResult(
                            decision=Decision.ALLOW,
                            tool=tool,
                            reason=f"approved via callback (pattern: {pattern})",
                            matched_rule=pattern,
                        )
                    else:
                        result = PolicyResult(
                            decision=Decision.DENY,
                            tool=tool,
                            reason=f"approval denied via callback (pattern: {pattern})",
                            matched_rule=pattern,
                        )
                self._record(result, ctx)
                return result

        # 3. Allow rules
        if self._allow_patterns:
            for pattern in self._allow_patterns:
                if fnmatch.fnmatch(tool, pattern):
                    result = PolicyResult(
                        decision=Decision.ALLOW,
                        tool=tool,
                        reason=f"allowed by pattern: {pattern}",
                        matched_rule=pattern,
                    )
                    self._record(result, ctx)
                    return result

            # If allow patterns exist but none matched → use default
            if self._default == "deny":
                result = PolicyResult(
                    decision=Decision.DENY,
                    tool=tool,
                    reason="not in allow list (default: deny)",
                )
            else:
                result = PolicyResult(
                    decision=Decision.ALLOW,
                    tool=tool,
                    reason="no matching rule (default: allow)",
                )
            self._record(result, ctx)
            return result

        # 4. No allow patterns defined — fall through to default
        if self._default == "allow":
            result = PolicyResult(
                decision=Decision.ALLOW,
                tool=tool,
                reason="no matching rule (default: allow)",
            )
        else:
            result = PolicyResult(
                decision=Decision.DENY,
                tool=tool,
                reason="no matching rule (default: deny)",
            )
        self._record(result, ctx)
        return result

    def enforce(self, tool: str, *, context: Optional[Dict[str, Any]] = None) -> PolicyResult:
        """Check *tool* and raise :class:`ToolDenied` if denied.

        This is a convenience wrapper around :meth:`check` that raises
        instead of returning a denied result.
        """
        result = self.check(tool, context=context)
        if result.denied:
            raise ToolDenied(tool=tool, reason=result.reason, matched_rule=result.matched_rule)
        return result

    def clear_audit(self) -> None:
        """Clear the audit log."""
        self._audit_log.clear()

    def _record(self, result: PolicyResult, context: Dict[str, Any]) -> None:
        """Record a decision in the audit log and invoke callbacks."""
        if self._audit_enabled:
            entry = AuditEntry(
                timestamp=time.time(),
                tool=result.tool,
                decision=result.decision.value,
                reason=result.reason,
                matched_rule=result.matched_rule,
                context=context,
            )
            self._audit_log.append(entry)
            logger.info(
                "TokenFence policy [%s]: %s → %s (%s)",
                self._name, result.tool, result.decision.value, result.reason,
            )

        if result.denied and self._on_deny:
            self._on_deny(result)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the policy rules to a dict (for version control / debugging)."""
        return {
            "name": self._name,
            "allow": self._allow_patterns,
            "deny": self._deny_patterns,
            "require_approval": self._approval_patterns,
            "default": self._default,
            "audit": self._audit_enabled,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Policy":
        """Construct a Policy from a dict (e.g., loaded from JSON/YAML config)."""
        return cls(
            allow=data.get("allow"),
            deny=data.get("deny"),
            require_approval=data.get("require_approval"),
            default=data.get("default", "deny"),
            audit=data.get("audit", True),
            name=data.get("name"),
        )

    def __repr__(self) -> str:
        return (
            f"Policy(name={self._name!r}, allow={self._allow_patterns}, "
            f"deny={self._deny_patterns}, require_approval={self._approval_patterns}, "
            f"default={self._default!r})"
        )


class ToolDenied(TokenFenceError):
    """Raised by :meth:`Policy.enforce` when a tool call is denied."""

    def __init__(self, tool: str, reason: str, matched_rule: Optional[str] = None) -> None:
        self.tool = tool
        self.reason = reason
        self.matched_rule = matched_rule
        super().__init__(f"Tool '{tool}' denied: {reason}")
