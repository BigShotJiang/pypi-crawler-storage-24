import os
import shutil
from pathlib import Path


class E2EScenariosManager:
    """Exports bundled YAML scenario files to a consumer-specified directory."""

    # Path to bundled e2e resources relative to this file
    _BUNDLED_SCENARIOS_DIR = Path(__file__).parent / "e2e" / "Scenarios"

    @staticmethod
    def export_scenarios(destination_dir, overwrite=False):
        """
        Copy all bundled scenario YAML files to *destination_dir*.

        Args:
            destination_dir (str | Path): Target directory. Created if it does not exist.
            overwrite (bool): If True, existing files are overwritten. Default is False.

        Returns:
            list[str]: Names of files that were exported.
        """
        src = E2EScenariosManager._BUNDLED_SCENARIOS_DIR
        if not src.is_dir():
            raise FileNotFoundError(f"Bundled scenarios directory not found: {src}")

        dest = Path(destination_dir)
        dest.mkdir(parents=True, exist_ok=True)

        exported = []
        for yaml_file in sorted(src.glob("*.yaml")):
            target = dest / yaml_file.name
            if target.exists() and not overwrite:
                print(f"[SKIP] {yaml_file.name} already exists (use overwrite=True to replace)")
                continue
            shutil.copy2(yaml_file, target)
            print(f"[OK  ] Exported {yaml_file.name} -> {target}")
            exported.append(yaml_file.name)

        return exported

    @staticmethod
    def list_bundled_scenarios():
        """Return a list of bundled scenario file names."""
        src = E2EScenariosManager._BUNDLED_SCENARIOS_DIR
        if not src.is_dir():
            return []
        return sorted(f.name for f in src.glob("*.yaml"))
