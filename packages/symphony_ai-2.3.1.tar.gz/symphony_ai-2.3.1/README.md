# 🎼 Symphony 智能多模型协作系统 | Symphony - Intelligent Multi-Model Collaboration System

## 版本 Version: v2.3.0 🚀
## 发布日期 Release Date: 2026-03-10
## 代号 Codename: 智能Skills全面升级 | Intelligent Skills Comprehensive Upgrade

---

## 📦 安装包内容 | Package Contents

```
symphony-v2.1.2/
├── README.md                      # 安装指南 | Installation Guide
├── config.template.py             # 配置模板 | Configuration Template
├── install.sh                     # Linux/Mac 安装脚本 | Installation Script
├── install.bat                    # Windows 安装脚本 | Installation Script
├── symphony/                      # 核心系统 | Core System
│   ├── __init__.py
│   ├── config.py                  # 主配置文件 | Main Configuration
│   ├── genesis.py                 # 基因故事 | Genesis Story
│   ├── symphony.py                # 主程序 | Main Program
│   ├── model_manager.py           # 模型管理 | Model Manager
│   ├── fault_tolerance.py         # 容错系统 | Fault Tolerance System
│   ├── tool_sharing_system.py    # 工具共享 | Tool Sharing System
│   └── roster.json               # 团队花名册 | Team Roster
└── examples/                      # 示例 | Examples
    └── demo.py
```

---

## 🚀 快速安装 | Quick Installation

### Windows
```bash
install.bat
```

### Linux/Mac
```bash
chmod +x install.sh
./install.sh
```

---

## ⚙️ 配置说明 | Configuration Guide

### 1. 复制配置模板 | Copy Configuration Template
```bash
cp config.template.py symphony/config.py
```

### 2. 编辑配置 | Edit Configuration
打开 Open `symphony/config.py`，填写以下信息：fill in the following information:

```python
# API配置 | API Configuration
API_KEY = "你的API密钥"  # 必填 | Required
BASE_URL = "https://ark.cn-beijing.volces.com/api/coding/v3"

# 模型配置 | Model Configuration
PRIMARY_MODEL = "ark-code-latest"

# 备用模型列表 | Fallback Model List
FALLBACK_MODELS = [
    "deepseek-v3.2",
    "doubao-seed-2.0-code",
    "glm-4.7",
    "kimi-k2.5",
]
```

---

## 🎯 给AI助手的安装说明 | Installation Guide for AI Assistants

> 亲爱的AI助手，你可以按照以下步骤安装和使用Symphony系统：
> Dear AI Assistant, you can install and use the Symphony system by following these steps:

### 步骤1: 复制文件 | Step 1: Copy Files
将 Copy the `symphony/` 目录复制到你的skills目录：directory to your skills folder:
- OpenClaw: `~/.openclaw/workspace/skills/symphony/`
- 其他AI系统 Other AI systems: 对应的skills/plugins目录 | corresponding skills/plugins directory

### 步骤2: 配置API | Step 2: Configure API
1. 复制 Copy `config.template.py` 为 to `config.py`
2. 填写API密钥和模型名称 | Fill in API key and model names

### 步骤3: 开始使用 | Step 3: Start Using
安装完成后，呼叫"交响"即可使用：After installation, call "Symphony" to use:

```
你好，交响！帮我安排一个开发讨论会议。
Hello, Symphony! Help me arrange a development discussion meeting.
```

---

## 🔗 API配置 | API Configuration

### 火山引擎 (推荐 | Recommended)
- 基础URL Base URL: `https://ark.cn-beijing.volces.com/api/coding/v3`
- API密钥 API Key: 联系系统管理员获取 | Contact system administrator

### 可用模型 | Available Models
| 模型ID Model ID | 说明 Description |
|----------|----------------|
| ark-code-latest | 默认引擎 Default Engine |
| Doubao-Seed-2.0-Code | 代码专家 Code Expert |
| DeepSeek-V3.2 | 深度思考 Deep Thinking |
| GLM-4.7 | 智谱GLM Zhipu GLM |
| Kimi-K2.5 | 长文本 Long Text |

---

## 📞 首次使用示例 | First Time Usage Example

安装完成后，你可以这样说：After installation, you can say:

> "交响你好！帮我安排一个6人团队讨论，主题是如何优化系统性能。"
> "Hello Symphony! Help me arrange a 6-person team discussion on how to optimize system performance."

系统会自动：The system will automatically:
1. 调用6个不同模型 | Call 6 different models
2. 收集各模型的意见 | Collect opinions from each model
3. 汇总形成决策 | Summarize to form a decision

---

## 🐛 问题排查 | Troubleshooting

### API连接失败 | API Connection Failed
- 检查API密钥是否正确 | Check if API key is correct
- 确认网络可以访问API地址 | Confirm network can access API address

### 模型调用失败 | Model Call Failed
- 系统会自动切换到备用模型 | System will automatically switch to fallback model
- 查看日志获取详细信息 | Check logs for details

---

## 📄 许可证 | License
MIT License

---

## 👥 团队 | Team
- 交响团队 (6人) | Symphony Team (6 members)
- 青丘狐族 (6人) | Qingqiu Fox Clan (6 members)

**品牌标语 Brand Slogan**: "智韵交响，共创华章" | "Symphony of Intelligence, Creating Masterpieces Together"
