#!/usr/bin/env python3
"""
TurboPython Compiler — Test Suite
===================================
Tests all compiler stages:
  1. Preprocessor (syntax transformation)
  2. Type checker (type resolution and validation)
  3. Ownership checker (move/borrow analysis)
  4. Code generator (C emission)
  5. End-to-end compilation (source -> .so)
  6. Runtime execution (ctypes call into compiled code)
"""

import ast
import ctypes
import os
import sys
import unittest

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from turbopython.preprocessor import preprocess
from turbopython.type_checker import (
    TypeChecker, TurboType, StructType, ArrayType, resolve_annotation
)
from turbopython.ownership import OwnershipChecker, OwnershipError, parse_ownership_mode
from turbopython.codegen import CCodeGenerator, compile_to_shared_lib
from turbopython.compiler import compile_module


# ============================================================
# Stage 1: Preprocessor Tests
# ============================================================

class TestPreprocessor(unittest.TestCase):
    """Test TurboPython -> valid Python transformations."""

    def test_struct_to_class(self):
        src = "struct Vec2:\n    x: float\n    y: float\n"
        result = preprocess(src)
        self.assertIn('class Vec2:', result.source)
        self.assertIn('__turbo_struct__', result.source)
        self.assertIn('Vec2', result.struct_names)

    def test_parallel_for(self):
        src = "parallel for i in range(100):\n    pass\n"
        result = preprocess(src)
        self.assertIn('for i in range(100):', result.source)
        self.assertNotIn('parallel', result.source)
        self.assertIn(1, result.parallel_lines)

    def test_const(self):
        src = "const MAX: int = 1024\n"
        result = preprocess(src)
        self.assertIn('MAX: int = 1024', result.source)
        self.assertIn('MAX', result.const_names)

    def test_spawn(self):
        src = "spawn worker(data)\n"
        result = preprocess(src)
        self.assertIn('worker(data)', result.source)
        self.assertNotIn('spawn', result.source)
        self.assertIn(1, result.spawn_lines)

    def test_ownership_owned(self):
        src = "def consume(data: owned list):\n    pass\n"
        result = preprocess(src)
        self.assertIn('def consume(data: list):', result.source)
        self.assertNotIn('owned', result.source)
        # Check ownership was recorded
        found = False
        for line, ann in result.ownership_annotations.items():
            if 'data' in ann and ann['data'] == 'owned':
                found = True
        self.assertTrue(found, "Ownership annotation for 'owned' not recorded")

    def test_ownership_ref(self):
        src = "def analyze(data: ref list):\n    pass\n"
        result = preprocess(src)
        self.assertIn('def analyze(data: list):', result.source)
        found = False
        for line, ann in result.ownership_annotations.items():
            if 'data' in ann and ann['data'] == 'ref':
                found = True
        self.assertTrue(found)

    def test_ownership_mut_ref(self):
        src = "def modify(data: mut ref list):\n    pass\n"
        result = preprocess(src)
        self.assertIn('def modify(data: list):', result.source)
        found = False
        for line, ann in result.ownership_annotations.items():
            if 'data' in ann and ann['data'] == 'mut ref':
                found = True
        self.assertTrue(found)

    def test_preserves_regular_python(self):
        src = "def foo(x: int) -> int:\n    return x + 1\n"
        result = preprocess(src)
        self.assertEqual(result.source, src)
        self.assertEqual(result.struct_names, set())
        self.assertEqual(result.parallel_lines, set())

    def test_indentation_preserved(self):
        src = "    parallel for i in range(10):\n        x = i\n"
        result = preprocess(src)
        self.assertIn('    for i in range(10):', result.source)

    def test_parseable_output(self):
        """Preprocessed output must be valid Python."""
        src = """
struct Vec3:
    x: float
    y: float
    z: float

@native
def length(v: Vec3) -> float:
    return (v.x ** 2 + v.y ** 2 + v.z ** 2) ** 0.5
"""
        result = preprocess(src)
        # This must not raise
        tree = ast.parse(result.source)
        self.assertIsNotNone(tree)


# ============================================================
# Stage 2: Type Checker Tests
# ============================================================

class TestTypeChecker(unittest.TestCase):

    def _check(self, src):
        pp = preprocess(src)
        tree = ast.parse(pp.source)
        checker = TypeChecker(pp.struct_names)
        errors = checker.check_module(tree)
        return checker, errors

    def test_struct_fields(self):
        checker, _ = self._check("""
struct Vec2:
    x: float
    y: float
""")
        self.assertIn('Vec2', checker.struct_defs)
        stype = checker.struct_defs['Vec2']
        self.assertEqual(len(stype.fields), 2)
        self.assertEqual(stype.fields[0], ('x', TurboType('float')))
        self.assertEqual(stype.fields[1], ('y', TurboType('float')))

    def test_function_signature(self):
        checker, _ = self._check("""
def add(a: int, b: int) -> int:
    return a + b
""")
        self.assertIn('add', checker.function_sigs)
        params, ret = checker.function_sigs['add']
        self.assertEqual(ret, TurboType('int'))
        self.assertEqual(params[0], ('a', TurboType('int')))
        self.assertEqual(params[1], ('b', TurboType('int')))

    def test_missing_annotation_warning(self):
        checker, errors = self._check("""
def foo(x):
    return x
""")
        # Should produce a warning about missing annotation
        msgs = [e.message for e in errors]
        self.assertTrue(any('no type annotation' in m for m in msgs))

    def test_struct_return_type(self):
        checker, _ = self._check("""
struct Point:
    x: float
    y: float

def origin() -> Point:
    return Point(0.0, 0.0)
""")
        _, ret = checker.function_sigs['origin']
        self.assertIsInstance(ret, StructType)
        self.assertEqual(ret.name, 'Point')

    def test_primitive_c_types(self):
        self.assertEqual(TurboType('int').c_type(), 'int64_t')
        self.assertEqual(TurboType('float').c_type(), 'double')
        self.assertEqual(TurboType('bool').c_type(), 'int')
        self.assertEqual(TurboType('None').c_type(), 'void')

    def test_array_type(self):
        pp = preprocess("x: array[float, 100] = []\n")
        tree = ast.parse(pp.source)
        # Manually resolve
        ann = tree.body[0].annotation
        atype = resolve_annotation(ann, set())
        self.assertIsInstance(atype, ArrayType)
        self.assertEqual(atype.element_type, TurboType('float'))
        self.assertEqual(atype.size, 100)


# ============================================================
# Stage 3: Ownership Checker Tests
# ============================================================

class TestOwnershipChecker(unittest.TestCase):

    def test_use_after_move_detected(self):
        """Manually construct a scenario where a variable is used after move."""
        from turbopython.ownership import VarState, OwnershipError
        state = VarState(name='x', alive=True)
        state.move()
        self.assertFalse(state.alive)
        with self.assertRaises(OwnershipError):
            state.borrow()

    def test_multiple_immutable_borrows_ok(self):
        from turbopython.ownership import VarState
        state = VarState(name='x', alive=True)
        state.borrow()
        state.borrow()
        self.assertEqual(state.ref_count, 2)

    def test_mut_borrow_exclusive(self):
        from turbopython.ownership import VarState, OwnershipError
        state = VarState(name='x', alive=True)
        state.borrow_mut()
        with self.assertRaises(OwnershipError):
            state.borrow()

    def test_mut_borrow_blocks_second_mut(self):
        from turbopython.ownership import VarState, OwnershipError
        state = VarState(name='x', alive=True)
        state.borrow_mut()
        with self.assertRaises(OwnershipError):
            state.borrow_mut()

    def test_borrow_blocks_mut(self):
        from turbopython.ownership import VarState, OwnershipError
        state = VarState(name='x', alive=True)
        state.borrow()
        with self.assertRaises(OwnershipError):
            state.borrow_mut()

    def test_release_then_mut_ok(self):
        from turbopython.ownership import VarState
        state = VarState(name='x', alive=True)
        state.borrow()
        state.release_borrow()
        state.borrow_mut()  # Should not raise
        self.assertTrue(state.mut_borrowed)


# ============================================================
# Stage 4: Code Generation Tests
# ============================================================

class TestCodeGeneration(unittest.TestCase):

    def _generate(self, src):
        pp = preprocess(src)
        tree = ast.parse(pp.source)
        checker = TypeChecker(pp.struct_names)
        checker.check_module(tree)
        gen = CCodeGenerator(checker, pp)
        return gen.generate(tree)

    def test_struct_emits_typedef(self):
        c = self._generate("""
struct Vec2:
    x: float
    y: float
""")
        self.assertIn('typedef struct {', c)
        self.assertIn('double x;', c)
        self.assertIn('double y;', c)
        self.assertIn('} Vec2;', c)

    def test_struct_constructor(self):
        c = self._generate("""
struct Vec2:
    x: float
    y: float
""")
        self.assertIn('Vec2 Vec2_new(', c)
        self.assertIn('return __result;', c)

    def test_native_function(self):
        c = self._generate("""
@native
def square(x: float) -> float:
    return x * x
""")
        self.assertIn('double square(double x)', c)
        self.assertIn('return (x * x);', c)

    def test_parallel_for_emits_pragma(self):
        c = self._generate("""
@native
def psum(n: int) -> int:
    total: int = 0
    parallel for i in range(n):
        total = total + i
    return total
""")
        self.assertIn('#pragma omp parallel for', c)
        self.assertIn('for (int64_t i = 0; i < n; i += 1)', c)

    def test_if_statement(self):
        c = self._generate("""
@native
def abs_val(x: float) -> float:
    if x < 0.0:
        return -1.0 * x
    return x
""")
        self.assertIn('if ((x < 0.0))', c)

    def test_math_pow(self):
        c = self._generate("""
@native
def sqrt(x: float) -> float:
    return x ** 0.5
""")
        self.assertIn('pow(x, 0.5)', c)

    def test_includes(self):
        c = self._generate("x: int = 1\n")
        self.assertIn('#include <stdio.h>', c)
        self.assertIn('#include <math.h>', c)
        self.assertIn('#include <omp.h>', c)


# ============================================================
# Stage 5: End-to-End Compilation Tests
# ============================================================

class TestEndToEnd(unittest.TestCase):

    def test_simple_function_compiles(self):
        result = compile_module("""
@native
def add_ints(a: int, b: int) -> int:
    return a + b
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")
        self.assertTrue(os.path.exists(result.so_path))

    def test_struct_compiles(self):
        result = compile_module("""
struct Point:
    x: float
    y: float

@native
def point_sum(p: Point) -> float:
    return p.x + p.y
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

    def test_parallel_compiles(self):
        result = compile_module("""
@native
def parallel_sum(n: int) -> int:
    total: int = 0
    parallel for i in range(n):
        total = total + i
    return total
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

    def test_mandelbrot_compiles(self):
        src = open(os.path.join(
            os.path.dirname(__file__), '..', 'examples', 'mandelbrot.tpy'
        )).read()
        result = compile_module(src)
        self.assertTrue(result.success, f"Errors: {result.errors}")

    def test_vectors_compiles(self):
        src = open(os.path.join(
            os.path.dirname(__file__), '..', 'examples', 'vectors.tpy'
        )).read()
        result = compile_module(src)
        self.assertTrue(result.success, f"Errors: {result.errors}")


# ============================================================
# Stage 6: Runtime Execution Tests
# ============================================================

class TestRuntime(unittest.TestCase):

    def test_call_add_ints(self):
        result = compile_module("""
@native
def add_ints(a: int, b: int) -> int:
    return a + b
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.add_ints.argtypes = [ctypes.c_int64, ctypes.c_int64]
        lib.add_ints.restype = ctypes.c_int64
        self.assertEqual(lib.add_ints(3, 4), 7)
        self.assertEqual(lib.add_ints(-10, 10), 0)
        self.assertEqual(lib.add_ints(1000000, 2000000), 3000000)

    def test_call_float_arithmetic(self):
        result = compile_module("""
@native
def hypotenuse(a: float, b: float) -> float:
    return (a * a + b * b) ** 0.5
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.hypotenuse.argtypes = [ctypes.c_double, ctypes.c_double]
        lib.hypotenuse.restype = ctypes.c_double
        self.assertAlmostEqual(lib.hypotenuse(3.0, 4.0), 5.0, places=10)
        self.assertAlmostEqual(lib.hypotenuse(1.0, 1.0), 2**0.5, places=10)

    def test_call_with_loop(self):
        result = compile_module("""
@native
def sum_range(n: int) -> int:
    total: int = 0
    for i in range(n):
        total = total + i
    return total
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.sum_range.argtypes = [ctypes.c_int64]
        lib.sum_range.restype = ctypes.c_int64
        self.assertEqual(lib.sum_range(10), 45)      # 0+1+...+9
        self.assertEqual(lib.sum_range(100), 4950)
        self.assertEqual(lib.sum_range(0), 0)

    def test_call_conditional(self):
        result = compile_module("""
@native
def clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.clamp.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_double]
        lib.clamp.restype = ctypes.c_double
        self.assertEqual(lib.clamp(5.0, 0.0, 10.0), 5.0)
        self.assertEqual(lib.clamp(-1.0, 0.0, 10.0), 0.0)
        self.assertEqual(lib.clamp(15.0, 0.0, 10.0), 10.0)

    def test_call_mandelbrot(self):
        result = compile_module("""
@native
def mandelbrot(cx: float, cy: float, max_iter: int) -> int:
    zx: float = 0.0
    zy: float = 0.0
    i: int = 0
    for i in range(max_iter):
        if zx * zx + zy * zy > 4.0:
            return i
        tx: float = zx * zx - zy * zy + cx
        zy = 2.0 * zx * zy + cy
        zx = tx
    return max_iter
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.mandelbrot.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_int64]
        lib.mandelbrot.restype = ctypes.c_int64

        # Origin is in the set
        self.assertEqual(lib.mandelbrot(0.0, 0.0, 100), 100)
        # Far outside escapes immediately
        self.assertEqual(lib.mandelbrot(10.0, 10.0, 100), 1)
        # Edge of set
        iters = lib.mandelbrot(-0.75, 0.1, 1000)
        self.assertGreater(iters, 10)

    def test_struct_function_call(self):
        result = compile_module("""
struct Vec3:
    x: float
    y: float
    z: float

@native
def vec3_dot(ax: float, ay: float, az: float, bx: float, by: float, bz: float) -> float:
    return ax * bx + ay * by + az * bz
""")
        self.assertTrue(result.success, f"Errors: {result.errors}")

        lib = ctypes.CDLL(result.so_path)
        lib.vec3_dot.argtypes = [ctypes.c_double] * 6
        lib.vec3_dot.restype = ctypes.c_double
        # (1,2,3) . (4,5,6) = 4+10+18 = 32
        self.assertAlmostEqual(
            lib.vec3_dot(1.0, 2.0, 3.0, 4.0, 5.0, 6.0), 32.0
        )


if __name__ == '__main__':
    unittest.main(verbosity=2)
