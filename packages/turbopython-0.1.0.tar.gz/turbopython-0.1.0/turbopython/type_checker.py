"""
TurboPython Type Checker
========================
Resolves type annotations, infers types for unannotated locals,
and validates type consistency at compile time.

Supports:
  - Primitive types: int, float, bool, str
  - Struct types (value types)
  - Generic containers: list[T], array[T, N]
  - Function signatures with full type resolution
  - Type inference for locals via assignment analysis
"""

import ast
from dataclasses import dataclass, field
from typing import Optional


# --- Type representation ---

@dataclass(frozen=True)
class TurboType:
    """Base type in the TurboPython type system."""
    name: str

    def c_type(self) -> str:
        C_MAP = {
            'int': 'int64_t',
            'int128': '__int128',
            'float': 'double',
            'bool': 'int',
            'str': 'const char*',
            'None': 'void',
        }
        return C_MAP.get(self.name, self.name)

    def is_primitive(self) -> bool:
        return self.name in ('int', 'int128', 'float', 'bool', 'str', 'None')

    def __repr__(self):
        return self.name


@dataclass(frozen=True)
class ArrayType(TurboType):
    """Fixed-size contiguous array: array[T, N]."""
    element_type: TurboType = field(default_factory=lambda: TurboType('int'))
    size: Optional[int] = None

    def c_type(self) -> str:
        return f'{self.element_type.c_type()}*'

    def __repr__(self):
        if self.size:
            return f'array[{self.element_type}, {self.size}]'
        return f'array[{self.element_type}]'


@dataclass(frozen=True)
class StructType(TurboType):
    """Struct (value type) with known field layout."""
    fields: tuple = ()  # tuple of (name, TurboType)

    def c_type(self) -> str:
        return self.name  # Use typedef name, not 'struct Name'

    def __repr__(self):
        return f'struct {self.name}'


# --- Type environment ---

class TypeEnv:
    """Type environment for a scope (function, module)."""

    def __init__(self, parent=None):
        self.parent = parent
        self.bindings: dict[str, TurboType] = {}

    def bind(self, name: str, typ: TurboType):
        self.bindings[name] = typ

    def lookup(self, name: str) -> Optional[TurboType]:
        if name in self.bindings:
            return self.bindings[name]
        if self.parent:
            return self.parent.lookup(name)
        return None


# --- Type resolution from AST annotations ---

def resolve_annotation(node, struct_names: set) -> TurboType:
    """Convert an AST annotation node to a TurboType."""
    if node is None:
        return TurboType('None')

    if isinstance(node, ast.Constant):
        if isinstance(node.value, str):
            return _resolve_name(node.value, struct_names)
        return TurboType(str(type(node.value).__name__))

    if isinstance(node, ast.Name):
        return _resolve_name(node.id, struct_names)

    if isinstance(node, ast.Subscript):
        # e.g. list[int], array[float, 1000]
        base = node.value
        if isinstance(base, ast.Name):
            if base.id == 'array':
                return _resolve_array_type(node, struct_names)
            elif base.id in ('list', 'List'):
                elem = _resolve_subscript_elem(node.slice, struct_names)
                return ArrayType(name='list', element_type=elem)
        return TurboType('object')

    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        # Union type T | U — for now, treat as object
        return TurboType('object')

    return TurboType('object')


def _resolve_name(name: str, struct_names: set) -> TurboType:
    if name in ('int', 'int128', 'float', 'bool', 'str', 'None'):
        return TurboType(name)
    if name in struct_names:
        return StructType(name=name)
    return TurboType(name)


def _resolve_subscript_elem(node, struct_names: set) -> TurboType:
    if isinstance(node, ast.Name):
        return _resolve_name(node.id, struct_names)
    if isinstance(node, ast.Tuple):
        if node.elts:
            return resolve_annotation(node.elts[0], struct_names)
    return resolve_annotation(node, struct_names)


def _resolve_array_type(node, struct_names: set) -> ArrayType:
    """Resolve array[T, N] subscript."""
    sl = node.slice
    if isinstance(sl, ast.Tuple) and len(sl.elts) == 2:
        elem = resolve_annotation(sl.elts[0], struct_names)
        size_node = sl.elts[1]
        size = None
        if isinstance(size_node, ast.Constant) and isinstance(size_node.value, int):
            size = size_node.value
        elif isinstance(size_node, ast.Name):
            size = None  # symbolic size, resolved later
        return ArrayType(name='array', element_type=elem, size=size)
    elem = resolve_annotation(sl, struct_names)
    return ArrayType(name='array', element_type=elem)


# --- Type checker ---

@dataclass
class TypeCheckError:
    line: int
    message: str


class TypeChecker:
    """
    Walk a TurboPython AST and resolve/check types.
    Populates a type environment for code generation.
    """

    def __init__(self, struct_names: set):
        self.struct_names = struct_names
        self.global_env = TypeEnv()
        self.struct_defs: dict[str, StructType] = {}
        self.function_sigs: dict[str, tuple] = {}  # name -> (params, return_type)
        self.errors: list[TypeCheckError] = []

    def check_module(self, tree: ast.Module) -> list[TypeCheckError]:
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name in self.struct_names:
                self._check_struct(node)
            elif isinstance(node, ast.FunctionDef):
                self._check_function(node)
            elif isinstance(node, ast.AnnAssign):
                self._check_global_assign(node)
        return self.errors

    def _check_struct(self, node: ast.ClassDef):
        fields = []
        for item in node.body:
            if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                if item.target.id == '__turbo_struct__':
                    continue
                ftype = resolve_annotation(item.annotation, self.struct_names)
                fields.append((item.target.id, ftype))
        stype = StructType(name=node.name, fields=tuple(fields))
        self.struct_defs[node.name] = stype
        self.global_env.bind(node.name, stype)

    def _check_function(self, node: ast.FunctionDef):
        params = []
        func_env = TypeEnv(parent=self.global_env)

        for arg in node.args.args:
            if arg.arg == 'self':
                params.append(('self', TurboType('self')))
                continue
            if arg.annotation:
                ptype = resolve_annotation(arg.annotation, self.struct_names)
            else:
                ptype = TurboType('object')
                self.errors.append(TypeCheckError(
                    node.lineno,
                    f"Parameter '{arg.arg}' in '{node.name}' has no type annotation "
                    f"(will use dynamic dispatch)"
                ))
            params.append((arg.arg, ptype))
            func_env.bind(arg.arg, ptype)

        ret_type = resolve_annotation(node.returns, self.struct_names)
        self.function_sigs[node.name] = (params, ret_type)
        self.global_env.bind(node.name, TurboType('function'))

        # Infer types for local assignments
        self._infer_locals(node.body, func_env)

    def _infer_locals(self, stmts, env: TypeEnv):
        for stmt in stmts:
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                vtype = resolve_annotation(stmt.annotation, self.struct_names)
                env.bind(stmt.target.id, vtype)
            elif isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if isinstance(target, ast.Name):
                        inferred = self._infer_expr_type(stmt.value, env)
                        env.bind(target.id, inferred)
            elif isinstance(stmt, (ast.For, ast.While)):
                self._infer_locals(stmt.body, env)
            elif isinstance(stmt, ast.If):
                self._infer_locals(stmt.body, env)
                self._infer_locals(stmt.orelse, env)

    def _infer_expr_type(self, node, env: TypeEnv) -> TurboType:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, int):
                return TurboType('int')
            if isinstance(node.value, float):
                return TurboType('float')
            if isinstance(node.value, str):
                return TurboType('str')
            if isinstance(node.value, bool):
                return TurboType('bool')
        if isinstance(node, ast.Name):
            t = env.lookup(node.id)
            return t if t else TurboType('object')
        if isinstance(node, ast.BinOp):
            lt = self._infer_expr_type(node.left, env)
            rt = self._infer_expr_type(node.right, env)
            if lt.name == 'float' or rt.name == 'float':
                return TurboType('float')
            if lt.name == 'int128' or rt.name == 'int128':
                if isinstance(node.op, ast.Div):
                    return TurboType('float')
                return TurboType('int128')
            if lt.name == 'int' and rt.name == 'int':
                if isinstance(node.op, ast.Div):
                    return TurboType('float')
                return TurboType('int')
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                fname = node.func.id
                if fname in self.struct_defs:
                    return self.struct_defs[fname]
                if fname in self.function_sigs:
                    return self.function_sigs[fname][1]
        return TurboType('object')

    def _check_global_assign(self, node: ast.AnnAssign):
        if isinstance(node.target, ast.Name):
            vtype = resolve_annotation(node.annotation, self.struct_names)
            self.global_env.bind(node.target.id, vtype)
