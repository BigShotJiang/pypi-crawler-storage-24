"""
TurboPython Compiler Driver
============================
Orchestrates the full compilation pipeline:

  1. Preprocess  — transform TurboPython syntax to parseable Python
  2. Parse       — use Python's ast module
  3. Type check  — resolve and verify all types
  4. Ownership   — verify borrow/move rules
  5. Code gen    — emit C source
  6. Compile     — GCC -> shared library (.so)
  7. Load        — ctypes FFI for calling from Python

Usage:
    from turbopython import compile_module, load_function

    lib = compile_module('''
    struct Vec2:
        x: float
        y: float

    @native
    def dot(a: Vec2, b: Vec2) -> float:
        return a.x * b.x + a.y * b.y
    ''')

    # Call the compiled function
    result = lib.call('dot', Vec2(1.0, 2.0), Vec2(3.0, 4.0))
"""

import ast
import ctypes
import os
import sys
from dataclasses import dataclass, field
from typing import Optional

from .preprocessor import preprocess, PreprocessResult
from .type_checker import TypeChecker, TurboType, StructType, ArrayType
from .ownership import OwnershipChecker, parse_ownership_mode
from .codegen import CCodeGenerator, compile_to_shared_lib, compile_to_executable


@dataclass
class CompileResult:
    """Result of compiling a TurboPython module."""
    success: bool
    c_source: str = ''
    so_path: str = ''
    exe_path: str = ''
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    preprocess_result: PreprocessResult = None
    ast_tree: ast.Module = None
    function_sigs: dict = field(default_factory=dict)   # name -> (params, ret_type)
    struct_defs: dict = field(default_factory=dict)     # name -> StructType

    def call(self, func_name: str, *args):
        """Call a compiled function via ctypes."""
        if not self.success:
            raise RuntimeError("Cannot call functions from a failed compilation")
        lib = ctypes.CDLL(self.so_path)
        func = getattr(lib, func_name)
        return func(*args)


def compile_module(
    source: str,
    output_dir: str = None,
    verbose: bool = False,
    executable: bool = False,
    entry_point: str = 'main',
    output_name: str = 'output',
) -> CompileResult:
    """
    Full compilation pipeline for a TurboPython source string.

    Args:
        source: TurboPython source code
        output_dir: Directory for output files (default: /tmp)
        verbose: Print intermediate results

    Returns:
        CompileResult with compiled library and metadata
    """
    result = CompileResult(success=False)

    if output_dir is None:
        import tempfile as _tf
        output_dir = _tf.mkdtemp(prefix='turbopython_build_')
    os.makedirs(output_dir, exist_ok=True)

    # --- Stage 1: Preprocess ---
    if verbose:
        print("=== Stage 1: Preprocessing ===")
    try:
        pp = preprocess(source)
        result.preprocess_result = pp
    except Exception as e:
        result.errors.append(f"Preprocessing failed: {e}")
        return result

    if verbose:
        print(f"  Structs: {pp.struct_names}")
        print(f"  Parallel lines: {pp.parallel_lines}")
        print(f"  Const names: {pp.const_names}")
        print(f"  Ownership annotations: {pp.ownership_annotations}")

    # --- Stage 2: Parse ---
    if verbose:
        print("\n=== Stage 2: Parsing ===")
    try:
        tree = ast.parse(pp.source)
        result.ast_tree = tree
    except SyntaxError as e:
        result.errors.append(f"Parse error: {e}")
        if verbose:
            print(f"  Preprocessed source:\n{pp.source}")
        return result

    if verbose:
        print(f"  AST nodes: {len(tree.body)}")

    # --- Stage 3: Type check ---
    if verbose:
        print("\n=== Stage 3: Type checking ===")
    checker = TypeChecker(pp.struct_names)
    type_errors = checker.check_module(tree)

    # Separate hard errors from warnings (missing annotations are warnings)
    for err in type_errors:
        if 'no type annotation' in err.message:
            result.warnings.append(err.message)
        else:
            result.errors.append(err.message)

    result.function_sigs = checker.function_sigs
    result.struct_defs = checker.struct_defs

    if verbose:
        print(f"  Struct defs: {list(checker.struct_defs.keys())}")
        print(f"  Function sigs: {list(checker.function_sigs.keys())}")
        for w in result.warnings:
            print(f"  Warning: {w}")

    # --- Stage 4: Ownership check ---
    if verbose:
        print("\n=== Stage 4: Ownership checking ===")
    own_checker = OwnershipChecker(pp.ownership_annotations)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            # Build param modes from annotations
            param_modes = {}
            for line, annotations in pp.ownership_annotations.items():
                for param, mode_str in annotations.items():
                    param_modes[param] = parse_ownership_mode(mode_str)

            own_result = own_checker.check_function(node, param_modes)
            result.errors.extend(own_result.errors)
            result.warnings.extend(own_result.warnings)

    if verbose:
        if not result.errors:
            print("  Ownership check passed")
        for e in result.errors:
            print(f"  Error: {e}")

    # --- Stage 5: Code generation ---
    if verbose:
        print("\n=== Stage 5: C code generation ===")
    try:
        gen = CCodeGenerator(checker, pp)
        c_source = gen.generate(tree)
        result.c_source = c_source
    except Exception as e:
        result.errors.append(f"Code generation failed: {e}")
        return result

    # Write C source
    c_path = os.path.join(output_dir, 'output.c')
    with open(c_path, 'w') as f:
        f.write(c_source)

    if verbose:
        print(f"  C source written to: {c_path}")
        print(f"  Lines: {len(c_source.splitlines())}")

    # --- Stage 6: Compile ---
    if verbose:
        print("\n=== Stage 6: GCC compilation ===")

    if executable:
        # Validate the entry point exists
        if entry_point not in checker.function_sigs:
            result.errors.append(
                f"Executable entry point '{entry_point}' not found. "
                f"Define a @native function named '{entry_point}' that returns int."
            )
            return result

        exe_path = os.path.join(output_dir, output_name)
        try:
            compile_to_executable(c_source, exe_path, entry_func=entry_point)
            result.exe_path = exe_path
            result.success = True
        except RuntimeError as e:
            result.errors.append(str(e))
            return result

        if verbose:
            print(f"  Executable: {exe_path}")
            print(f"  Size: {os.path.getsize(exe_path)} bytes")
    else:
        so_path = os.path.join(output_dir, 'output.so')
        try:
            compile_to_shared_lib(c_source, so_path)
            result.so_path = so_path
            result.success = True
        except RuntimeError as e:
            result.errors.append(str(e))
            return result

        if verbose:
            print(f"  Shared library: {so_path}")
            print(f"  Size: {os.path.getsize(so_path)} bytes")

    return result


def compile_file(
    path: str,
    output_dir: str = None,
    verbose: bool = False,
    executable: bool = False,
    entry_point: str = 'main',
) -> CompileResult:
    """Compile a .tpy file."""
    with open(path) as f:
        source = f.read()

    abs_path = os.path.abspath(path)
    stem = os.path.splitext(os.path.basename(abs_path))[0]

    # If -o looks like a file path (no trailing sep, has a non-directory name),
    # split it into dir + name; otherwise treat it purely as a directory.
    if output_dir is not None and executable and not os.path.isdir(output_dir):
        out_dir = os.path.dirname(output_dir) or os.path.dirname(abs_path)
        out_name = os.path.basename(output_dir)
    else:
        out_dir = output_dir if output_dir is not None else os.path.dirname(abs_path)
        out_name = stem

    return compile_module(source, out_dir, verbose, executable, entry_point, out_name)
