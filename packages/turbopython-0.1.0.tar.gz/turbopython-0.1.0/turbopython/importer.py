"""
TurboPython import hook
========================
Allows regular Python code to import .tpy modules transparently:

    from turbopython.importer import install
    install()

    import vectors          # finds vectors.tpy, compiles it, returns a module
    vectors.compute_total_distance(1000)

The compiled .so is cached alongside the .tpy file and reused on subsequent
imports as long as the .tpy is not newer than the .so.
"""

import ctypes
import importlib.abc
import importlib.machinery
import os
import sys
import types


# ---------------------------------------------------------------------------
# TurboType c_type string -> ctypes type
# ---------------------------------------------------------------------------

_C_TO_CTYPES = {
    'int64_t':      ctypes.c_int64,
    '__int128':     ctypes.c_int64,   # low 64 bits; best effort
    'double':       ctypes.c_double,
    'int':          ctypes.c_int,
    'void':         None,
    'const char*':  ctypes.c_char_p,
}


def _turbo_to_ctypes(c_type_str: str):
    """Map a C type string from TurboType.c_type() to a ctypes type."""
    return _C_TO_CTYPES.get(c_type_str, ctypes.c_void_p)


# ---------------------------------------------------------------------------
# Module wrapper — exposes compiled functions as Python callables
# ---------------------------------------------------------------------------

class TurboPythonModule(types.ModuleType):
    """
    A Python module backed by a compiled TurboPython .so.

    Functions are exposed as attributes with argtypes/restype set
    automatically from the compilation's type information.
    """

    def __init__(self, name: str, so_path: str, function_sigs: dict):
        super().__init__(name)
        self.__file__ = so_path
        self.__loader__ = None
        self._lib = ctypes.CDLL(so_path)
        self._sigs = function_sigs
        self._setup_functions()

    def _setup_functions(self):
        for fname, (params, ret_type) in self._sigs.items():
            try:
                fn = getattr(self._lib, fname)
            except AttributeError:
                continue  # not exported (e.g. @inline only)

            argtypes = []
            for pname, ptype in params:
                if pname == 'self':
                    continue
                ct = _turbo_to_ctypes(ptype.c_type())
                argtypes.append(ct if ct is not None else ctypes.c_void_p)

            fn.argtypes = argtypes
            fn.restype = _turbo_to_ctypes(ret_type.c_type())
            setattr(self, fname, fn)


# ---------------------------------------------------------------------------
# Finder + Loader
# ---------------------------------------------------------------------------

class TurboPythonLoader(importlib.abc.Loader):
    def __init__(self, tpy_path: str):
        self.tpy_path = tpy_path

    def create_module(self, spec):
        return None  # default semantics

    def exec_module(self, module):
        from turbopython.compiler import compile_file

        so_path = self.tpy_path.replace('.tpy', '.so')

        # Skip recompilation if .so is up to date
        if (os.path.exists(so_path)
                and os.path.getmtime(so_path) >= os.path.getmtime(self.tpy_path)):
            # Still need function_sigs — recompile metadata only via a fresh
            # compile_file so we get type info, but GCC won't re-run because
            # output already exists.  Simplest: just recompile; it's fast.
            pass

        result = compile_file(self.tpy_path)
        if not result.success:
            raise ImportError(
                f"TurboPython compilation of '{self.tpy_path}' failed:\n"
                + "\n".join(result.errors)
            )

        # Populate the module with compiled functions
        lib = ctypes.CDLL(result.so_path)
        for fname, (params, ret_type) in result.function_sigs.items():
            try:
                fn = getattr(lib, fname)
            except AttributeError:
                continue

            argtypes = []
            for pname, ptype in params:
                if pname == 'self':
                    continue
                ct = _turbo_to_ctypes(ptype.c_type())
                argtypes.append(ct if ct is not None else ctypes.c_void_p)

            fn.argtypes = argtypes
            fn.restype = _turbo_to_ctypes(ret_type.c_type())
            setattr(module, fname, fn)

        module.__file__ = result.so_path
        module.__tpy_result__ = result


class TurboPythonFinder(importlib.abc.MetaPathFinder):
    """
    Meta path finder that looks for <module_name>.tpy in sys.path directories.
    """

    def find_spec(self, fullname, path, target=None):
        # Only handle simple (non-package) module names
        module_name = fullname.split('.')[-1]
        search_dirs = path if path else sys.path

        for directory in search_dirs:
            if not isinstance(directory, str):
                continue
            candidate = os.path.join(directory, module_name + '.tpy')
            if os.path.isfile(candidate):
                loader = TurboPythonLoader(candidate)
                return importlib.machinery.ModuleSpec(
                    fullname,
                    loader,
                    origin=candidate,
                )
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_installed = False


def install():
    """
    Install the TurboPython import hook into sys.meta_path.

    Call this once at the start of your script to enable transparent
    import of .tpy files:

        from turbopython.importer import install
        install()
        import my_module   # my_module.tpy is compiled on first import
    """
    global _installed
    if not _installed:
        sys.meta_path.insert(0, TurboPythonFinder())
        _installed = True
