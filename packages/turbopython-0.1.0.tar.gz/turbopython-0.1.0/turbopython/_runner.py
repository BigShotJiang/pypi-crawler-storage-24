"""
tython runner — exposed as a package module so it can be registered as a
console_scripts entry point in pyproject.toml.

Behaviour is identical to the `tython` script at the repo root.
"""

import ctypes
import os
import sys

from turbopython.importer import install as _install_hook

_install_hook()


def _run_tpy(path: str) -> int:
    from turbopython.compiler import compile_file

    abs_path = os.path.abspath(path)
    sys.path.insert(0, os.path.dirname(abs_path))

    print(f"[tython] Compiling {path}...", end=" ", flush=True)
    result = compile_file(abs_path)

    if not result.success:
        print("FAILED")
        for e in result.errors:
            print(f"  error: {e}", file=sys.stderr)
        return 1

    print("done")

    if 'main' not in result.function_sigs:
        print(f"[tython] Compiled to: {result.so_path}")
        print(f"[tython] Exported functions:")
        for fname, (params, ret) in result.function_sigs.items():
            param_str = ", ".join(f"{n}: {t}" for n, t in params if n != "self")
            print(f"  {fname}({param_str}) -> {ret}")
        return 0

    lib = ctypes.CDLL(result.so_path)
    lib.main.argtypes = []
    lib.main.restype = ctypes.c_int64
    exit_code = int(lib.main())
    print(f"[tython] main() returned {exit_code}")
    return exit_code


def _run_py(path: str, argv_rest: list[str]) -> int:
    abs_path = os.path.abspath(path)
    sys.path.insert(0, os.path.dirname(abs_path))
    sys.argv = [abs_path] + argv_rest

    with open(abs_path) as f:
        source = f.read()

    code = compile(source, abs_path, 'exec')
    globs = {
        '__name__': '__main__',
        '__file__': abs_path,
        '__spec__': None,
    }
    exec(code, globs)
    return 0


def _run_command(cmd: str) -> int:
    code = compile(cmd, '<string>', 'exec')
    globs = {'__name__': '__main__', '__spec__': None}
    exec(code, globs)
    return 0


def main():
    args = sys.argv[1:]

    if not args:
        import code as _code
        print("tython REPL — TurboPython import hook active")
        print("  Import any .tpy file with: import <module>")
        _code.interact(local={'__name__': '__main__'})
        return

    if args[0] == '-c':
        if len(args) < 2:
            print("tython: -c requires an argument", file=sys.stderr)
            sys.exit(1)
        sys.exit(_run_command(args[1]))

    path = args[0]
    rest = args[1:]

    if path.endswith('.tpy'):
        sys.exit(_run_tpy(path))
    else:
        sys.exit(_run_py(path, rest))


if __name__ == '__main__':
    main()
