"""
TurboPython Preprocessor
========================
Transforms TurboPython-specific syntax into valid Python that the `ast` module
can parse, while preserving semantic markers for later compiler stages.

Transformations:
  struct Foo:        -> class Foo:  (with __turbo_struct__ = True marker)
  parallel for ...   -> for ...     (with # __turbo_parallel__ comment tracked)
  owned list[int]    -> list[int]   (ownership recorded in side table)
  ref list[int]      -> list[int]   (ditto)
  mut ref list[int]  -> list[int]   (ditto)
  const X: T = ...   -> X: T = ... (constness recorded in side table)
  spawn func(...)    -> func(...)   (spawn recorded in side table)
"""

import re
from dataclasses import dataclass, field


@dataclass
class PreprocessResult:
    """Result of preprocessing TurboPython source."""
    source: str                          # Valid Python source for ast.parse
    struct_names: set = field(default_factory=set)
    parallel_lines: set = field(default_factory=set)   # 1-indexed line numbers
    ownership_annotations: dict = field(default_factory=dict)  # line -> {param: mode}
    const_names: set = field(default_factory=set)
    spawn_lines: set = field(default_factory=set)


def preprocess(source: str) -> PreprocessResult:
    """Transform TurboPython source into parseable Python + metadata."""
    lines = source.split('\n')
    result = PreprocessResult(source='')
    out_lines = []

    for i, line in enumerate(lines, 1):
        stripped = line.lstrip()
        indent = line[:len(line) - len(stripped)]

        # --- struct -> class with marker ---
        m = re.match(r'^(\s*)struct\s+(\w+)(.*?):\s*$', line)
        if m:
            name = m.group(2)
            rest = m.group(3)  # e.g. generic params
            result.struct_names.add(name)
            out_lines.append(f'{indent}class {name}{rest}:')
            # Insert marker as first line of class body
            out_lines.append(f'{indent}    __turbo_struct__ = True')
            continue

        # --- const X: T = expr ---
        m = re.match(r'^(\s*)const\s+(\w+)\s*:\s*(.+?)\s*=\s*(.+)$', line)
        if m:
            name = m.group(2)
            type_ann = m.group(3)
            expr = m.group(4)
            result.const_names.add(name)
            out_lines.append(f'{indent}{name}: {type_ann} = {expr}')
            continue

        # --- parallel for -> for (record line) ---
        m = re.match(r'^(\s*)parallel\s+for\s+(.+)$', line)
        if m:
            result.parallel_lines.add(i)
            out_lines.append(f'{indent}for {m.group(2)}')
            continue

        # --- spawn func(...) -> func(...) ---
        m = re.match(r'^(\s*)spawn\s+(.+)$', line)
        if m:
            result.spawn_lines.add(i)
            out_lines.append(f'{indent}{m.group(2)}')
            continue

        # --- ownership annotations in function signatures ---
        # We handle these by stripping owned/ref/mut ref from type annotations
        # and recording them. This is done on the raw line.
        new_line, ownership = _extract_ownership(line, i)
        if ownership:
            result.ownership_annotations[i] = ownership
        out_lines.append(new_line)

    result.source = '\n'.join(out_lines)
    return result


def _extract_ownership(line: str, lineno: int):
    """Strip ownership qualifiers from a line and return (new_line, {param: mode})."""
    ownership = {}

    # Match patterns like:  param: owned Type  |  param: ref Type  |  param: mut ref Type
    def replace_ownership(m):
        param = m.group(1)
        mode = m.group(2).strip()
        type_name = m.group(3)
        ownership[param] = mode
        return f'{param}: {type_name}'

    new_line = re.sub(
        r'(\w+)\s*:\s*(owned|mut\s+ref|ref)\s+(\w[\w\[\], ]*)',
        replace_ownership,
        line
    )
    return new_line, ownership if ownership else None
