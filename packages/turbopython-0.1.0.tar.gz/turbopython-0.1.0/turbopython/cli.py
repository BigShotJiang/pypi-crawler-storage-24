#!/usr/bin/env python3
"""
TurboPython Compiler CLI
=========================
Usage:
    python -m turbopython.cli compile examples/mandelbrot.tpy
    python -m turbopython.cli compile examples/mandelbrot.tpy --verbose
    python -m turbopython.cli compile examples/hello.tpy --exe
    python -m turbopython.cli compile examples/hello.tpy --exe --entry run
    python -m turbopython.cli inspect examples/vectors.tpy
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from turbopython.compiler import compile_file, compile_module


def cmd_compile(args):
    result = compile_file(
        args.file,
        output_dir=args.output,
        verbose=args.verbose,
        executable=args.exe,
        entry_point=args.entry,
    )

    if result.warnings:
        for w in result.warnings:
            print(f"  warning: {w}")

    if result.success:
        print(f"\n✓ Compilation successful")
        if args.exe:
            print(f"  C source:   {result.exe_path}.c")
            print(f"  Executable: {result.exe_path}")
        else:
            print(f"  C source:   {result.so_path.replace('.so', '.c')}")
            print(f"  Shared lib: {result.so_path}")
    else:
        print(f"\n✗ Compilation failed")
        for e in result.errors:
            print(f"  error: {e}")
        sys.exit(1)


def cmd_inspect(args):
    """Show compilation stages without producing a .so."""
    with open(args.file) as f:
        source = f.read()

    from turbopython.preprocessor import preprocess
    from turbopython.type_checker import TypeChecker

    print("=== Source ===")
    print(source)

    pp = preprocess(source)
    print("\n=== Preprocessed (valid Python) ===")
    print(pp.source)

    print(f"\n=== Metadata ===")
    print(f"  Structs:      {pp.struct_names or '(none)'}")
    print(f"  Parallel:     lines {pp.parallel_lines or '(none)'}")
    print(f"  Constants:    {pp.const_names or '(none)'}")
    print(f"  Ownership:    {pp.ownership_annotations or '(none)'}")
    print(f"  Spawn:        lines {pp.spawn_lines or '(none)'}")

    import ast
    tree = ast.parse(pp.source)
    checker = TypeChecker(pp.struct_names)
    checker.check_module(tree)

    print(f"\n=== Type Information ===")
    for name, stype in checker.struct_defs.items():
        print(f"  struct {name}:")
        for fn, ft in stype.fields:
            print(f"    {fn}: {ft} -> C: {ft.c_type()}")

    for name, (params, ret) in checker.function_sigs.items():
        param_str = ', '.join(f'{n}: {t}' for n, t in params)
        print(f"  fn {name}({param_str}) -> {ret}  [C: {ret.c_type()}]")


def main():
    parser = argparse.ArgumentParser(
        prog='turbopython',
        description='TurboPython — a compiled Python dialect'
    )
    sub = parser.add_subparsers(dest='command')

    p_compile = sub.add_parser('compile', help='Compile a .tpy file')
    p_compile.add_argument('file', help='Source file (.tpy)')
    p_compile.add_argument('-o', '--output', help='Output directory')
    p_compile.add_argument('-v', '--verbose', action='store_true')
    p_compile.add_argument('--exe', action='store_true',
                           help='Produce a standalone executable instead of a shared library')
    p_compile.add_argument('--entry', default='main', metavar='FUNC',
                           help='Entry-point function name for --exe (default: main)')

    p_inspect = sub.add_parser('inspect', help='Inspect compilation stages')
    p_inspect.add_argument('file', help='Source file (.tpy)')

    args = parser.parse_args()
    if args.command == 'compile':
        cmd_compile(args)
    elif args.command == 'inspect':
        cmd_inspect(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
