"""
TurboPython Ownership Checker
==============================
Tracks ownership state of variables through control flow and enforces:
  1. After a move (owned), the source variable is invalidated.
  2. Multiple immutable borrows (ref) are allowed simultaneously.
  3. A mutable borrow (mut ref) is exclusive — no other borrows allowed.
  4. References cannot outlive the data they refer to.

This is a simplified, conservative checker — it rejects some valid programs
in exchange for guaranteed memory safety without runtime checks.
"""

import ast
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class OwnershipMode(Enum):
    OWNED = auto()      # Caller transfers ownership
    REF = auto()        # Immutable borrow
    MUT_REF = auto()    # Mutable borrow (exclusive)


@dataclass
class VarState:
    """Tracks the ownership state of a single variable."""
    name: str
    alive: bool = True
    ref_count: int = 0       # Active immutable borrows
    mut_borrowed: bool = False  # Currently mutably borrowed

    def move(self):
        self.alive = False

    def borrow(self):
        if not self.alive:
            raise OwnershipError(f"Cannot borrow '{self.name}': already moved")
        if self.mut_borrowed:
            raise OwnershipError(
                f"Cannot borrow '{self.name}': already mutably borrowed"
            )
        self.ref_count += 1

    def borrow_mut(self):
        if not self.alive:
            raise OwnershipError(f"Cannot mutably borrow '{self.name}': already moved")
        if self.ref_count > 0:
            raise OwnershipError(
                f"Cannot mutably borrow '{self.name}': "
                f"already has {self.ref_count} immutable borrow(s)"
            )
        if self.mut_borrowed:
            raise OwnershipError(
                f"Cannot mutably borrow '{self.name}': already mutably borrowed"
            )
        self.mut_borrowed = True

    def release_borrow(self):
        if self.ref_count > 0:
            self.ref_count -= 1

    def release_mut_borrow(self):
        self.mut_borrowed = False


class OwnershipError(Exception):
    def __init__(self, message, line=None):
        self.line = line
        super().__init__(message)


@dataclass
class OwnershipCheckResult:
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


class OwnershipChecker:
    """
    Walk function bodies and track ownership state of each variable.
    Uses the ownership_annotations from the preprocessor to know which
    parameters use which ownership mode.
    """

    def __init__(self, ownership_annotations: dict):
        """
        ownership_annotations: {line_number: {param_name: 'owned'|'ref'|'mut ref'}}
        """
        self.annotations = ownership_annotations
        self.errors = []
        self.warnings = []

    def check_function(self, node: ast.FunctionDef, param_modes: dict) -> OwnershipCheckResult:
        """
        Check a single function body.

        param_modes: {param_name: OwnershipMode}
        """
        result = OwnershipCheckResult()
        states: dict[str, VarState] = {}

        # Initialize parameter states
        for arg in node.args.args:
            name = arg.arg
            if name == 'self':
                continue
            states[name] = VarState(name=name, alive=True)

        # Walk the function body
        self._check_stmts(node.body, states, param_modes, result)

        return result

    def _check_stmts(self, stmts, states, param_modes, result):
        for stmt in stmts:
            self._check_stmt(stmt, states, param_modes, result)

    def _check_stmt(self, stmt, states, param_modes, result):
        if isinstance(stmt, ast.Assign):
            # Check RHS for use-after-move
            self._check_expr_use(stmt.value, states, result, stmt.lineno)
            # LHS creates a new owned variable
            for target in stmt.targets:
                if isinstance(target, ast.Name):
                    states[target.id] = VarState(name=target.id, alive=True)

        elif isinstance(stmt, ast.AnnAssign):
            if stmt.value:
                self._check_expr_use(stmt.value, states, result, stmt.lineno)
            if isinstance(stmt.target, ast.Name):
                states[stmt.target.id] = VarState(name=stmt.target.id, alive=True)

        elif isinstance(stmt, ast.Return):
            if stmt.value:
                self._check_expr_use(stmt.value, states, result, stmt.lineno)

        elif isinstance(stmt, ast.Expr):
            self._check_expr_use(stmt.value, states, result, stmt.lineno)

        elif isinstance(stmt, ast.For):
            self._check_expr_use(stmt.iter, states, result, stmt.lineno)
            if isinstance(stmt.target, ast.Name):
                states[stmt.target.id] = VarState(name=stmt.target.id, alive=True)
            self._check_stmts(stmt.body, states, param_modes, result)

        elif isinstance(stmt, ast.If):
            self._check_expr_use(stmt.test, states, result, stmt.lineno)
            self._check_stmts(stmt.body, states, param_modes, result)
            self._check_stmts(stmt.orelse, states, param_modes, result)

        elif isinstance(stmt, ast.While):
            self._check_expr_use(stmt.test, states, result, stmt.lineno)
            self._check_stmts(stmt.body, states, param_modes, result)

    def _check_expr_use(self, node, states, result, lineno):
        """Check that using an expression doesn't violate ownership."""
        if isinstance(node, ast.Name):
            name = node.id
            if name in states and not states[name].alive:
                result.errors.append(
                    f"Line {lineno}: Use of moved variable '{name}'"
                )

        elif isinstance(node, ast.Call):
            # Check function arguments against ownership modes
            if isinstance(node.func, ast.Name):
                for arg in node.args:
                    self._check_expr_use(arg, states, result, lineno)
                    # If arg is a Name and the call implies a move, mark it
                    if isinstance(arg, ast.Name) and arg.id in states:
                        # We'd need to look up the callee's param modes here
                        # For now, only explicit 'owned' params cause moves
                        pass
            for arg in node.args:
                self._check_expr_use(arg, states, result, lineno)

        elif isinstance(node, ast.BinOp):
            self._check_expr_use(node.left, states, result, lineno)
            self._check_expr_use(node.right, states, result, lineno)

        elif isinstance(node, ast.Compare):
            self._check_expr_use(node.left, states, result, lineno)
            for comp in node.comparators:
                self._check_expr_use(comp, states, result, lineno)

        elif isinstance(node, ast.Attribute):
            self._check_expr_use(node.value, states, result, lineno)

        elif isinstance(node, ast.Subscript):
            self._check_expr_use(node.value, states, result, lineno)
            self._check_expr_use(node.slice, states, result, lineno)


def parse_ownership_mode(mode_str: str) -> OwnershipMode:
    """Convert preprocessor ownership string to enum."""
    mode_str = mode_str.strip()
    if mode_str == 'owned':
        return OwnershipMode.OWNED
    elif mode_str == 'ref':
        return OwnershipMode.REF
    elif mode_str == 'mut ref':
        return OwnershipMode.MUT_REF
    raise ValueError(f"Unknown ownership mode: {mode_str}")
