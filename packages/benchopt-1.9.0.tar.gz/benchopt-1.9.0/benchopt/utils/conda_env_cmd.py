import os
import re
import sys
import warnings
from pathlib import Path

import benchopt

from .shell_cmd import _run_shell
from .shell_cmd import _run_shell_in_conda_env
from .misc import get_benchopt_requirement, NamedTemporaryFile

from ..config import DEBUG
from ..config import get_setting

SHELL = get_setting('shell')
CONDA_CMD = get_setting('conda_cmd')

# On windows, calling conda without call exit the cmd script:
# https://github.com/conda/conda/issues/12418
if sys.platform == 'win32' and not CONDA_CMD.lower().startswith('call'):
    CONDA_CMD = f"CALL {CONDA_CMD}"

DEFAULT_PYTHON_VERSION = '3.12'

# Yaml config file for benchopt env.
BENCHOPT_ENV = """
channels:
  - conda-forge
  - nodefaults
dependencies:
  - {python_spec}
  - numpy
  - cython
  - compilers
  - pip
  - pip:
    - {benchopt_requirement}
"""

EMPTY_ENV = """
channels:
  - conda-forge
  - nodefaults
dependencies:
  - {python_spec}
"""


def _python_version_conda_spec(version):
    """Convert a python_version attribute to a conda dependency string.

    Plain versions (e.g. '3.12') are mapped to conda syntax ``python=3.12``.
    Version specifiers (e.g. '>=3.12') are prepended with ``python``.
    """
    if re.match(r'^[><=!]', str(version)):
        return f"python{version}"
    return f"python={version}"


def _python_version_satisfies(env_version, required):
    """Check if `env_version` satisfies `required`.

    `required` may be an exact version string ('3.12') or
    a specifier ('>=3.12').
    """
    if re.match(r'^[><=!]', str(required)):
        from packaging.specifiers import SpecifierSet
        return env_version in SpecifierSet(required)
    return env_version.startswith(str(required))


def get_benchmark_python_version(benchmark):
    if benchmark is None:
        return DEFAULT_PYTHON_VERSION
    objective = benchmark.get_benchmark_objective()
    return getattr(objective, 'python_version', DEFAULT_PYTHON_VERSION)


def create_conda_env(
    env_name, benchmark=None, recreate=False, pytest=False,
    empty=False, quiet=False
):
    """Create a conda env with name env_name and install basic utilities.


    Parameters
    ----------
    env_name : str
        The name of the conda env that will be created.
    benchmark : benchopt.Benchmark (optional)
        The benchmark is used to get the python version to use in the env.
        If None, the default python version is used.
    recreate : bool (default: False)
        It the conda env exists and recreate is set to True, it will be
        overwritten with the new env. If it is False, the env will be untouched
    pytest : bool (default: False)
        If set to True, also install pytest in the newly created env.
    empty : bool (default: False)
        If set to True, simply create an empty env. This is mainly for testing
        purposes.
    quiet : bool (default: False)
        If True, silences the output of conda commands.
    """

    # Get a list of all conda envs
    _, existing_conda_envs = list_conda_envs()

    python_version = get_benchmark_python_version(benchmark)

    if env_name in existing_conda_envs and not recreate:
        print(
            f"Conda env {env_name} already exists. Checking setup ... ",
            end='', flush=True
        )
        env_info = get_env_info(env_name)
        env_version = env_info['version']
        env_is_editable = env_info['is_editable']
        if env_version is None:
            print()
            raise RuntimeError(
                f"`benchopt` is not installed in existing env '{env_name}'. "
                "This can lead to unexpected behavior. You can correct this "
                "by either using the --recreate option or installing benchopt "
                f"in conda env {env_name}."
            )
        if benchopt.__version__ != env_version and not env_is_editable:
            print()
            warnings.warn(
                f"The local version of benchopt ({benchopt.__version__}) and "
                f"the one in conda env ({env_version}) are different. "
                "This can lead to unexpected behavior. You can correct this "
                "by either using the --recreate option or fixing the version "
                f"of benchopt in conda env {env_name}."
            )

        if pytest and env_info["pytest_version"] is None:
            raise ModuleNotFoundError(
                f"pytest is not installed in conda env {env_name}.\n"
                f"Please run `conda install -n {env_name} pytest` to test the "
                "benchmark in this environment."
            )

        # Check that the python version is compatible with the one
        # required by the benchmark.
        if benchmark is not None:
            env_python_version = env_info['python_version'].strip().split()[-1]

            if not _python_version_satisfies(env_python_version,
                                             python_version):
                print()
                warnings.warn(
                    f"The python version in conda env ({env_python_version}) "
                    "is different from the one required by the benchmark "
                    f"({python_version}). You can correct this by either "
                    "using the --recreate option or fixing the python "
                    f"version in conda env {env_name}."
                )
        print("done")
        return

    benchopt_requirement, benchopt_editable = get_benchopt_requirement(pytest)

    python_spec = _python_version_conda_spec(python_version)
    benchopt_env = BENCHOPT_ENV.format(
        python_spec=python_spec,
        # Encode the path as a posix path to avoid issues with backslashes
        benchopt_requirement=benchopt_requirement.replace("\\", "/")
    )

    if recreate and env_name in existing_conda_envs:
        assert env_name != "base", "Cannot recreate base"
        print(
            f"Recreate is used, removing conda env '{env_name}'... ",
            end='', flush=True
        )
        delete_conda_env(env_name)
        print("done")

    if empty:
        benchopt_env = EMPTY_ENV.format(
            python_spec=python_spec
        )

    print(f"Creating conda env '{env_name}':... ", end='', flush=True)
    if DEBUG:
        print(f"\nconda env config:\n{'-' * 60}\n{benchopt_env}\n{'-' * 60}")
    env_yaml = NamedTemporaryFile(
        mode="w+", prefix='conda_env_', suffix='.yml'
    )
    env_yaml.write(f"name: {env_name}{benchopt_env}")
    env_yaml.flush()

    try:
        if not quiet:
            print()
        _run_shell(
            f"{CONDA_CMD} env create -yn {env_name} -f {env_yaml.name}",
            capture_stdout=quiet, raise_on_error=True
        )
        # the channels priorities cannot be set through the yaml file,
        # we need to do it at the env creation
        # see https://stackoverflow.com/questions/70098418/
        _run_shell_in_conda_env(
            f"{CONDA_CMD} config --env --prepend channels nodefaults " +
            "--prepend channels conda-forge", env_name,
            capture_stdout=quiet)
        if empty:
            return
        # Check that the correct version of benchopt is installed in the env
        env_info = get_env_info(env_name)
        env_version = env_info['version']
        env_editable = env_info['is_editable']
        error_msg = (
            f"Installed the wrong version of benchopt ({env_version}) in "
            f"conda env. This should be version: {benchopt.__version__}. There"
            " is something wrong the env creation mechanism. Please report "
            "this error to https://github.com/benchopt/benchopt"
        )
        assert ((benchopt_editable and env_editable)
                or env_version == benchopt.__version__), error_msg
    except RuntimeError:
        print("failed to create the environment.")
        raise
    else:
        if quiet:
            print("done")


def get_env_info(env_name):
    """Check that the version of benchopt installed in env_name is the same
    as the one running.
    """
    check_benchopt, output = _run_shell_in_conda_env(
        "benchopt --check-env",
        env_name=env_name, capture_stdout=True, return_output=True
    )

    if check_benchopt != 0:
        if DEBUG:
            print(output)
        return dict(version=None, is_editable=False, python_version=None)
    import json
    output = json.loads(output.strip().splitlines()[-1])
    return output


def delete_conda_env(env_name):
    """Delete a conda env with name env_name."""

    _run_shell(f"{CONDA_CMD} env remove -yn {env_name}",
               capture_stdout=True)


def get_env_file_from_requirements(packages):
    """Process the packages from requirements and create the install cmd.

    This detects the packages that need to be installed with pip and also
    the additional channels for conda packages.
    """
    # TODO: remove with benchopt 2.0
    # If ":" is present but not "::", warn that this is legacy syntax.
    has_legacy_colon = any(":" in pkg and "::" not in pkg for pkg in packages)
    if has_legacy_colon:
        warnings.warn(
            "The use of ':' to specify the channel of a dependency is "
            "deprecated. Please use '::' instead.", DeprecationWarning
        )
        packages = [pkg.replace(":", "::", 1) for pkg in packages]

    conda_packages = [pkg for pkg in packages if not pkg.startswith('pip::')]
    if conda_packages:
        channels = '\n  - '.join(sorted(set(
            pkg.rsplit('::', 1)[0]
            for pkg in conda_packages if '::' in pkg
        ).union({'conda-forge'})))
        channels = f"channels:\n  - {channels}\n" if channels else ""
        conda_packages = '\n  - '.join(sorted(set(
            pkg.rsplit('::', 1)[-1] for pkg in conda_packages
        )))
        env = f"{channels}dependencies:\n  - {conda_packages}"
    else:
        env = "dependencies:"

    pip_packages = '\n    - '.join(sorted(set(
        pkg.replace("pip::", "") for pkg in packages if pkg.startswith('pip::')
    )))
    if pip_packages:
        env += f"\n  - pip\n  - pip:\n    - {pip_packages}"

    return env


def install_in_conda_env(*packages, env_name=None, quiet=False):
    """Install the packages with conda in the given environment"""
    if len(packages) == 0:
        return

    env = get_env_file_from_requirements(packages)
    if DEBUG:
        print(f"\ninstalling env packages:\n{'-' * 60}\n{env}\n{'-' * 60}")

    # If installing in the current env, get its name.
    if env_name is None:
        env_name, _ = list_conda_envs()

    with NamedTemporaryFile(mode='w+', prefix='env_', suffix='.yml') as f:
        f.write(env)
        f.flush()
        cmd = (
            f"{CONDA_CMD} env update -n {env_name} -f {f.name}"
            f"{' -q' if quiet else ''}"
        )

        error_msg = (
            f"Failed to conda install packages {packages}\nError:{{output}}"
        )
        _run_shell_in_conda_env(
            cmd, env_name=env_name, raise_on_error=error_msg,
            capture_stdout=quiet
        )


def shell_install_in_conda_env(script, env_name=None, quiet=False):
    """Run a shell install script in the given environment"""

    cmd = f"{SHELL} {script} $CONDA_PREFIX"
    _run_shell_in_conda_env(cmd, env_name=env_name, capture_stdout=quiet,
                            raise_on_error=f"Failed to run script {script}\n"
                            "Error: {output}")


def list_conda_envs():
    """List all existing conda envs.

    Returns
    -------
    conda_envs : list of tuple (env_name, is_active)
        List of all conda envs in the system and whether they are the current
        env or not.
    """
    try:
        from conda.base.context import context
    except ImportError:
        context = get_conda_context()
        if context is None:
            # Not in an activated conda env, returns an empty list.
            return None, []

    def get_env_name(prefix):

        prefix = Path(prefix)
        is_active = prefix == Path(context.active_prefix)
        if prefix == Path(context.root_prefix):
            name = 'base'
        elif any(Path(envs_dir) == prefix.parent
                 for envs_dir in context.envs_dirs):
            name = prefix.name
        else:
            name = ''
        return name, is_active

    conda_prefixes = [context.root_prefix]
    for env_dir in context.envs_dirs:
        env_dir = Path(env_dir)
        if not env_dir.is_dir():
            continue
        for p in env_dir.glob('*'):
            if p.is_dir():
                conda_prefixes.append(p)

    all_envs = [get_env_name(prefix) for prefix in conda_prefixes]
    active_envs = [e[0] for e in all_envs if e[1]]
    all_envs = [e[0] for e in all_envs]

    if len(active_envs) == 0:
        return None, all_envs

    assert len(active_envs) == 1, "Multiple activated conda env?!."

    return active_envs[0], all_envs


def get_conda_context():
    import json
    from collections import namedtuple
    Context = namedtuple(
        'Context', ['active_prefix', 'root_prefix', 'envs_dirs']
    )

    exit_code, payload = _run_shell_in_conda_env(
        "conda config --show envs_dirs root_prefix --json", return_output=True
    )

    active_prefix = os.environ.get('CONDA_PREFIX', None)
    if exit_code != 0 or active_prefix is None:
        return None
    info = json.loads(payload)
    info['active_prefix'] = os.path.normpath(active_prefix)
    info['root_prefix'] = os.path.normpath(info['root_prefix'])
    info['envs_dirs'] = [os.path.normpath(env_dir) for env_dir
                         in info['envs_dirs']]
    return Context(**info)
