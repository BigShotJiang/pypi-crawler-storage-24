import time
import inspect
import pickle

from datetime import datetime

from joblib import hash

from .callback import _Callback
from .benchmark import Benchmark
from .utils.sys_info import get_sys_info
from .utils.pdb_helpers import exception_handler
from .utils.terminal_output import TerminalOutput
from .parallel_backends import parallel_run
from .parallel_backends import check_parallel_config
from .results import save_results


FAILURE_STATUS = ['diverged', 'error', 'interrupted']
SUCCESS_STATUS = ['done', 'max_runs', 'timeout']


class FailedRun(RuntimeError):
    """Exception raised when a solver run fails."""
    def __init__(self, status):
        super().__init__()
        self.status = status


def _seed_run(objective, dataset, solver, repetition, base_seed):
    seed_dict = {
        "base_seed": str(base_seed),
        "objective": str(objective),
        "dataset": str(dataset),
        "solver": str(solver),
        "repetition": str(repetition),
    }
    for klass in [objective, dataset, solver]:
        if klass is not None:
            klass.seed_dict = {
                **seed_dict,  # Copy to avoid border effects
                "class": klass.__class__.__name__.lower()
            }


##################################
# Time one run of a solver
##################################


def run_one_resolution(objective, solver, meta, stop_val):
    """Run one resolution of the solver.

    Parameters
    ----------
    objective : instance of BaseObjective
        The objective to minimize.
    solver : instance of BaseSolver
        The solver to use.
    meta : dict
        Metadata passed to store in Cost results.
        Contains objective, data, dimension, id_rep.
    stop_val : int | float
        Corresponds to stopping criterion, such as
        tol or max_iter for the solver. It depends
        on the sampling_strategy for the solver.

    Returns
    -------
    cost : dict
        Details on the run and the objective value obtained.
    """
    # check if the module caught a failed import
    if not solver.is_installed():
        raise ImportError(
            f"Failure during import in {solver.__module__}."
        )

    solver.pre_run_hook(stop_val)
    t_start = time.perf_counter()
    solver.run(stop_val)
    delta_t = time.perf_counter() - t_start
    result = solver.get_result()
    objective_list = objective(result)

    # Add system info in results
    info = get_sys_info()

    return [
        dict(**meta, stop_val=stop_val, time=delta_t, **objective_dict, **info)
        for objective_dict in objective_list
    ]


def run_one_to_cvg(benchmark, objective, solver, meta, stopping_criterion,
                   force=False, terminal=None, pdb=False):
    """Run all repetitions of the solver for a value of stopping criterion.

    Parameters
    ----------
    benchmark : benchopt.Benchmark object
        Object to represent the benchmark.
    objective : instance of BaseObjective
        The objective to minimize.
    solver : instance of BaseSolver
        The solver to use.
    meta : dict
        Metadata passed to store in Cost results.
        Contains objective, data, dimension.
    stopping_criterion : StoppingCriterion
        Object to check if we need to stop a solver.
    force : bool
        If force is set to True, ignore the cache and run the computations
        for the solver anyway. Else, use the cache if available.
    terminal : TerminalOutput or None
        Object to format string to display the progress of the solver.
    pdb : bool
        It pdb is set to True, open a debugger on error.

    Returns
    -------
    curve : list of Cost
        The cost obtained for all repetitions.
    status : 'done' | 'diverged' | 'timeout' | 'max_runs'
        The status on which the solver was stopped.
    """
    curve = []

    # Augment the metadata with final_results if necessary.
    has_save_final_results = (
        objective.save_final_results.__qualname__ !=
        "BaseObjective.save_final_results"
    )
    if has_save_final_results:
        final_results = benchmark.get_output_folder() / 'final_results'
        final_results /= f"{hash(meta)}.pkl"
        final_results.parent.mkdir(exist_ok=True, parents=True)
        meta["final_results"] = str(final_results)

    with exception_handler(terminal, pdb=pdb) as ctx:
        # The warm-up step called for each repetition bit only run once.
        solver._warm_up()

        if solver._solver_strategy == "callback":

            # If sampling_strategy is 'callback', only call once to get the
            # results up to convergence.
            callback = _Callback(
                objective, solver, meta, stopping_criterion
            )
            solver.pre_run_hook(callback)
            callback.start()
            solver.run(callback)
            curve, ctx.status = callback.get_results()
        else:

            # Create a Memory object to cache the computations in the benchmark
            # folder and handle cases where we force the run.
            run_one_resolution_cached = benchmark.cache(
                run_one_resolution, force
            )

            # compute initial value
            call_args = dict(objective=objective, solver=solver, meta=meta)

            stop = False
            stop_val = stopping_criterion.init_stop_val()
            while not stop:

                objective_list = run_one_resolution_cached(
                    stop_val=stop_val, **call_args
                )
                curve.extend(objective_list)

                # Check the stopping criterion and update rho if necessary.
                stop, ctx.status, stop_val = stopping_criterion.should_stop(
                    stop_val, curve
                )
        # Only run if save_final_results is defined in the objective.
        if has_save_final_results and ctx.status not in FAILURE_STATUS:
            to_save = objective.save_final_results(**solver.get_result())
            if to_save is not None:
                with open(meta["final_results"], 'wb') as f:
                    pickle.dump(to_save, f)
    if ctx.status in FAILURE_STATUS:
        raise FailedRun(ctx.status)
    return curve, ctx.status


def run_one_solver(benchmark, dataset, objective, solver, n_repetitions,
                   max_runs, timeout=None, force=False, collect=False,
                   terminal=None, pdb=False):
    """Run a benchmark for a given dataset, objective and solver.

    Parameters
    ----------
    benchmark : benchopt.Benchmark object
        Object to represent the benchmark.
    dataset : instance of BaseDataset
        The dataset used for this benchmark.
    objective : instance of BaseObjective
        The objective to minimize.
    solver : instance of BaseSolver
        The solver to use.
    n_repetitions : int
        The number of repetitions to run. Defaults to 1.
    max_runs : int
        The maximum number of solver runs to perform to estimate
        the convergence curve.
    timeout : float
        The maximum duration in seconds of the solver run.
    force : bool
        If force is set to True, ignore the cache and run the computations
        for the solver anyway. Else, use the cache if available.
    collect : bool
        If set to True, only collect the results that have been put in cache,
        and ignore the results that are not computed yet, default is False.
    terminal : TerminalOutput or None
        Object to format string to display the progress of the solver.
    pdb : bool
        It pdb is set to True, open a debugger on error.

    Returns
    -------
    run_statistics : list
        The benchmark results.
    """

    run_one_to_cvg_cached = benchmark.cache(
        run_one_to_cvg, ignore=['force', 'terminal', 'pdb'], collect=collect
    )
    if collect:
        _run_one_to_cvg_cached = run_one_to_cvg_cached

        def run_one_to_cvg_cached(**kwargs):
            res = _run_one_to_cvg_cached(**kwargs)
            return res if res is not None else ([], 'not run yet')

    states = []
    run_statistics = []

    # get sampling strategy
    # for plotting purpose consider 'callback' as 'iteration'
    sampling_strategy = solver._solver_strategy
    if sampling_strategy == 'callback':
        sampling_strategy = 'iteration'

    # get objective description
    # use `obj_` instead of `objective_` to avoid conflicts with
    # the name of metrics in Objective.compute
    obj_description = objective.__doc__ or ""

    _seed_run(
        objective=objective,
        dataset=dataset,
        solver=solver,
        repetition=0,
        base_seed=benchmark.seed
    )

    # Set objective and skip if necessary.
    skip, reason = objective.set_dataset(dataset)
    if skip:
        terminal.skip(reason, objective=True)
        return []

    if n_repetitions is None:
        if hasattr(objective, "cv"):
            n_repetitions = objective.cv.get_n_splits(
                **getattr(objective, "cv_metadata", {})
            )
        else:
            # we set 1 by default so that the solver run at least once
            n_repetitions = 1
        terminal.n_repetitions = n_repetitions

    for rep in range(n_repetitions):
        skip, reason = solver._set_objective(objective)
        if skip:
            terminal.skip(reason)
            return []

        terminal.set(rep=rep)

        # Get meta
        meta = {
            'base_seed': benchmark.seed,
            'objective_name': str(objective),
            'obj_description': obj_description,
            'solver_name': str(solver),
            'solver_description': inspect.cleandoc(solver.__doc__ or ""),
            'dataset_name': str(dataset),
            'idx_rep': rep,
            'sampling_strategy': sampling_strategy.capitalize(),
            'file_objective': objective._module_filename.name,
            **{f"p_obj_{k}": v for k, v in objective._parameters.items()},
            'file_solver': f"solvers/{solver._module_filename.name}",
            **{f"p_solver_{k}": v for k, v in solver._parameters.items()},
            'file_dataset': f"datasets/{dataset._module_filename.name}",
            **{f"p_dataset_{k}": v for k, v in dataset._parameters.items()},
        }

        stopping_criterion = solver._stopping_criterion.get_runner_instance(
            solver=solver,
            max_runs=max_runs,
            timeout=timeout / n_repetitions if timeout is not None else None,
            terminal=terminal,
        )

        args_run_one_to_cvg = dict(
            benchmark=benchmark, objective=objective, solver=solver, meta=meta,
            stopping_criterion=stopping_criterion, force=force,
            terminal=terminal, pdb=pdb
        )

        try:
            curve, status = run_one_to_cvg_cached(
                **args_run_one_to_cvg
            )
            run_statistics.extend(curve)
        except FailedRun as e:
            status = e.status

        # Handle the status for which we do not want to try other repetitions
        if status not in SUCCESS_STATUS:
            run_statistics = []
            break
        states.append(status)

        if rep < n_repetitions - 1:
            _seed_run(
                objective=objective,
                dataset=dataset,
                solver=solver,
                repetition=rep+1,
                base_seed=benchmark.seed
            )

            # Set objective and skip if necessary.
            skip, reason = objective.set_dataset(dataset)
            if skip:
                terminal.skip(reason, objective=True)
                return []

    else:
        if 'max_runs' in states:
            status = 'max_runs'
        elif 'timeout' in states:
            status = 'timeout'
        else:
            status = 'done'

    terminal.show_status(status=status)
    # Make sure to flush so the parallel output is properly display
    print(end='', flush=True)

    # refresh the solver warm up flag so that warm-up is done again
    # when calling the solver with another problem/dataset pair.
    solver._warmup_done = False

    if status == 'interrupted':
        raise SystemExit(1)
    return run_statistics


def _run_benchmark(benchmark, solvers=None, forced_solvers=None,
                   datasets=None, objectives=None, max_runs=10,
                   n_repetitions=1, timeout=100,
                   plot_result=True, display=True, html=True, collect=False,
                   output_file="None", parallel_config=None,
                   show_progress=True, pdb=False):
    """Run full benchmark.

    Parameters
    ----------
    benchmark : benchopt.Benchmark object
        Object to represent the benchmark.
    solvers : list | None
        List of solvers to include in the benchmark. If None
        all solvers available are run.
    forced_solvers : list | None
        List of solvers to include in the benchmark and for
        which one forces recomputation.
    datasets : list | None
        List of datasets to include. If None all available
        datasets are used.
    objectives : list | None
        Filters to select specific objective parameters. If None,
        all objective parameters are tested
    max_runs : int
        The maximum number of solver runs to perform to estimate
        the convergence curve.
    n_repetitions : int
        The number of repetitions to run. Defaults to 1.
    timeout : float
        The maximum duration in seconds of the solver run.
    parallel_config : dict | None
        If not None, launch the job in parallel. The provided config serves to
        set up parallelism using ``joblib.parallel_backend`` or ``submitit``.
        See :ref:`parallel_run` for detailed description.
    plot_result : bool
        If set to True (default), generate the result plot and save them in
        the benchmark directory.
    display : bool
        If set to True (default), open the result plots at the end of the run,
        otherwise, simply save them.
    html : bool
        If set to True (default), display the result plot in HTML, otherwise
        in matplotlib figures, default is True.
    collect : bool
        If set to True, only collect the results that have been put in cache,
        and ignore the results that are not computed yet, default is False.
    show_progress : bool
        If show_progress is set to True, display the progress of the benchmark.
    pdb : bool
        If pdb is set to True, open a debugger on error.
    output_file : str
        Filename for the parquet output. If given, the results will
        be stored at <BENCHMARK>/outputs/<filename>.parquet.

    Returns
    -------
    exit_code : int
        Exit code of the benchmark run. 0 if everything went fine,
        1 otherwise.
    output_file : Path
        Path to the output file where the results have been saved.
    """
    exit_code = 0
    terminal = TerminalOutput(n_repetitions, show_progress)
    terminal.set(verbose=True)

    # List all datasets, objective and solvers to run based on the filters
    # provided. Merge the solver_names and forced to run all necessary solvers.
    all_runs = benchmark._get_all_runs(
        solvers, forced_solvers, datasets, objectives,
        terminal=terminal
    )
    common_kwargs = dict(
        benchmark=benchmark, n_repetitions=n_repetitions, max_runs=max_runs,
        timeout=timeout, pdb=pdb, collect=collect
    )

    results = parallel_run(
        benchmark, run_one_solver, common_kwargs, all_runs,
        config=parallel_config, collect=collect
    )

    run_statistics = []
    for curve in results:
        run_statistics.extend(curve)

    import pandas as pd
    df = pd.DataFrame(run_statistics)
    if df.empty:
        terminal.savefile_status()
        return 1, None

    # Save output in parquet file in the benchmark folder
    output_dir = benchmark.get_output_folder()
    if output_file == "None":
        timestamp = datetime.now().strftime('%Y-%m-%d_%Hh%Mm%S')
        output_file = f'benchopt_run_{timestamp}.parquet'
    output_file = save_results(df, output_dir / output_file)

    if plot_result:
        try:
            from benchopt.plotting import plot_benchmark
            plot_benchmark(output_file, benchmark, html=html, display=display)
        except Exception as e:
            print(f"Failed to plot the benchmark results: {e}")
            exit_code = 1

    return exit_code, output_file


def run_benchmark(benchmark_path, solver_names=None, forced_solvers=(),
                  dataset_names=None, objective_filters=None, max_runs=10,
                  n_repetitions=1, timeout=None,
                  n_jobs=None, parallel_config=None,
                  plot_result=True, display=True, html=True,  collect=False,
                  show_progress=True, pdb=False, no_cache=False,
                  output_file="None"):
    """Run full benchmark.

    Parameters
    ----------
    benchmark : benchopt.Benchmark object
        Object to represent the benchmark.
    solver_names : list | None
        List of solver names to include in the benchmark. If None
        all solvers available are run.
    forced_solvers : list | None
        List of solvers to include in the benchmark and for
        which one forces recomputation.
    dataset_names : list | None
        List of dataset names to include. If None all available
        datasets are used.
    objective_filters : list | None
        Filters to select specific objective parameters. If None,
        all objective parameters are tested
    max_runs : int
        The maximum number of solver runs to perform to estimate
        the convergence curve.
    n_repetitions : int
        The number of repetitions to run. Defaults to 1.
    timeout : float
        The maximum duration in seconds of the solver run.
    n_jobs : int
        Maximal number of workers to use to run the benchmark in parallel.
    parallel_config : dict | None
        If not None, launch the job in parallel. The provided config serves to
        set up parallelism using ``joblib.parallel_backend`` or ``submitit``.
        See :ref:`parallel_run` for detailed description.
    plot_result : bool
        If set to True (default), generate the result plot and save them in
        the benchmark directory.
    display : bool
        If set to True (default), open the result plots at the end of the run,
        otherwise, simply save them.
    html : bool
        If set to True (default), display the result plot in HTML, otherwise
        in matplotlib figures, default is True.
    collect : bool
        If set to True, only collect the results that have been put in cache,
        and ignore the results that are not computed yet, default is False.
    show_progress : bool
        If show_progress is set to True, display the progress of the benchmark.
    pdb : bool
        If pdb is set to True, open a debugger on error.
    no_cache : bool
        If set to True, this deactivates the caching mechanism integrated in
        benchopt. Note that this makes the run less tolerant to errors, use it
        with caution.
    output_file : str
        Filename for the parquet output. If given, the results will
        be stored at <BENCHMARK>/outputs/<filename>.parquet.

    Returns
    -------
    exit_code : int
        Exit code of the benchmark run. 0 if everything went fine,
        1 otherwise.
    output_file : Path
        Path to the output file where the results have been saved.
    """
    benchmark = Benchmark(benchmark_path, no_cache=no_cache)
    if solver_names is None:
        solver_names = []
    solvers = benchmark.check_solver_patterns(
        solver_names + list(forced_solvers)
    )
    datasets = benchmark.check_dataset_patterns(dataset_names)
    objectives = benchmark.check_objective_filters(objective_filters)

    parallel_config = check_parallel_config(parallel_config, n_jobs)

    exit_code, output_file = _run_benchmark(
        benchmark=benchmark,
        solvers=solvers,
        forced_solvers=forced_solvers,
        datasets=datasets,
        objectives=objectives,
        max_runs=max_runs,
        n_repetitions=n_repetitions,
        timeout=timeout,
        plot_result=plot_result,
        display=display,
        html=html,
        collect=collect,
        show_progress=show_progress,
        parallel_config=parallel_config,
        pdb=pdb,
        output_file=output_file
    )
    if exit_code != 0:
        raise RuntimeError("Benchmark failed, check the terminal output.")
    return output_file
