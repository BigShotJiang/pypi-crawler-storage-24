"""Exceptions for the AgentTool SDK."""

from __future__ import annotations


class AgentToolError(Exception):
    """Base error for all AgentTool SDK operations.

    Attributes:
        message: Human-readable error description.
        hint: Actionable suggestion for fixing the error.
    """

    def __init__(self, message: str, *, hint: str | None = None) -> None:
        self.message = message
        self.hint = hint
        super().__init__(message)

    def __str__(self) -> str:
        if self.hint:
            return f"{self.message} (hint: {self.hint})"
        return self.message
