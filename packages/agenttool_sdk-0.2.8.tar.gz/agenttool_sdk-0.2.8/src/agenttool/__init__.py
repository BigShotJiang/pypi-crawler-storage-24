"""AgentTool SDK — memory, tools, verify, economy, and traces for AI agents."""

from .client import AgentTool
from .economy import EconomyClient, Escrow, Wallet
from .exceptions import AgentToolError
from .models import DocumentResult, ExecuteResult, Memory, ScrapeResult, SearchResult, UsageStats
from .traces import Trace, TraceChain, TraceSearchResult
from .verify import VerifyClient, VerifyResult

__all__ = [
    "AgentTool",
    "AgentToolError",
    "ExecuteResult",
    "Memory",
    "ScrapeResult",
    "SearchResult",
    "UsageStats",
    "Trace",
    "TraceChain",
    "TraceSearchResult",
]

__version__ = "0.2.1"
