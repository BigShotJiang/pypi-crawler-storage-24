"""Memory client for agent-memory API."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

import httpx

from .exceptions import AgentToolError
from .models import Memory, UsageStats

if TYPE_CHECKING:
    pass


class MemoryClient:
    """Client for the agent-memory API.

    Usage::

        at = AgentTool()
        at.memory.store("just a string")
        results = at.memory.search("what did I learn?")
    """

    def __init__(self, http: httpx.Client, base_url: str) -> None:
        self._http = http
        self._base = base_url.rstrip("/")

    def _url(self, path: str) -> str:
        return f"{self._base}{path}"

    def store(
        self,
        content: str,
        *,
        type: str = "semantic",
        agent_id: Optional[str] = None,
        key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        importance: float = 0.5,
    ) -> Memory:
        """Store a memory. Only ``content`` is required.

        Args:
            content: The memory content string.
            type: One of semantic, episodic, procedural, working.
            agent_id: Optional agent identifier.
            key: Optional dedup/lookup key.
            metadata: Arbitrary metadata dict.
            importance: 0.0–1.0 importance score.

        Returns:
            The created Memory object.
        """
        body: Dict[str, Any] = {"content": content, "type": type, "importance": importance}
        if agent_id is not None:
            body["agent_id"] = agent_id
        if key is not None:
            body["key"] = key
        if metadata is not None:
            body["metadata"] = metadata

        resp = self._http.post(self._url("/v1/memories"), json=body)
        self._check(resp)
        return Memory.from_dict(resp.json())

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        type: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> List[Memory]:
        """Semantic search over stored memories.

        Args:
            query: Natural-language search query.
            limit: Max results to return.
            type: Filter by memory type.
            agent_id: Filter by agent.

        Returns:
            List of matching Memory objects.
        """
        body: Dict[str, Any] = {"query": query, "limit": limit}
        if type is not None:
            body["type"] = type
        if agent_id is not None:
            body["agent_id"] = agent_id

        resp = self._http.post(self._url("/v1/memories/search"), json=body)
        self._check(resp)
        data = resp.json()
        results = data if isinstance(data, list) else data.get("results", [])
        return [Memory.from_dict(m) for m in results]

    def get(self, memory_id: str) -> Memory:
        """Retrieve a single memory by ID.

        Args:
            memory_id: The memory's unique identifier.

        Returns:
            The Memory object.
        """
        resp = self._http.get(self._url(f"/v1/memories/{memory_id}"))
        self._check(resp)
        return Memory.from_dict(resp.json())

    def usage(self) -> UsageStats:
        """Get usage statistics.

        Returns:
            UsageStats with current counters.
        """
        resp = self._http.get(self._url("/v1/usage"))
        self._check(resp)
        return UsageStats.from_dict(resp.json())

    def delete(self, memory_id: str) -> None:
        """Delete a memory by ID.

        Args:
            memory_id: The UUID of the memory to delete.

        Raises:
            :class:`AgentToolError`: If the memory is not found or the request fails.
        """
        resp = self._http.delete(self._url(f"/v1/memories/{memory_id}"))
        self._check(resp)

    def delete_by_key(self, key: str) -> None:
        """Delete all memories with a given key.

        Args:
            key: The key shared by the memories to delete.

        Raises:
            :class:`AgentToolError`: On API errors.
        """
        resp = self._http.delete(self._url("/v1/memories"), params={"key": key})
        self._check(resp)

    @staticmethod
    def _check(resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise AgentToolError(
                f"Memory API error ({resp.status_code}): {detail}",
                hint="Check your API key and request parameters.",
            )
