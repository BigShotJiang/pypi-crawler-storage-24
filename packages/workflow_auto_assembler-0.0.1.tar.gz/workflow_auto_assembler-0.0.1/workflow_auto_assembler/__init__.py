
"""
Workflow Auto Assembler (WAA) is an experimental schema-first workflow synthesis tool.
It uses an LLM to assemble simple executable workflows from a task description, target
input/output models, and a catalog of available typed tools.

WAA is built around a narrow idea: instead of asking the model to solve a task
directly, expose tools through explicit schemas and let the model construct a linear
workflow whose intermediate states can be validated and tested. The resulting workflow
is persisted as an explicit artifact with I/O mappings, which makes it inspectable,
re-runnable, and easier to validate than a transient agent trace.

### Why Workflow-Auto-Assembler?

WAA treats tool selection and wiring as a schema-matching problem. When the required
capabilities exist in the available tool catalog, the assembled workflow can behave
like a larger typed function composed from smaller typed functions.

This package should be read as experimental adaptive tooling rather than a claim of
general autonomous planning. Its strongest use case is simple linear workflow assembly
under explicit schema constraints, with runner-based validation used to check that the
assembled workflow satisfies the requested output contract.
"""
from .workflow_auto_assembler import *
__version__='0.0.1'