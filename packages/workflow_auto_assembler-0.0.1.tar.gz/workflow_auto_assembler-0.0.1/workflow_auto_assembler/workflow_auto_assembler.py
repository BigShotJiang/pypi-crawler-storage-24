"""
Workflow Auto Assembler (WAA) is an experimental schema-first workflow synthesis tool.
It uses an LLM to assemble simple executable workflows from a task description, target
input/output models, and a catalog of available typed tools.

WAA is built around a narrow idea: instead of asking the model to solve a task
directly, expose tools through explicit schemas and let the model construct a linear
workflow whose intermediate states can be validated and tested. The resulting workflow
is persisted as an explicit artifact with I/O mappings, which makes it inspectable,
re-runnable, and easier to validate than a transient agent trace.

### Why Workflow-Auto-Assembler?

WAA treats tool selection and wiring as a schema-matching problem. When the required
capabilities exist in the available tool catalog, the assembled workflow can behave
like a larger typed function composed from smaller typed functions.

This package should be read as experimental adaptive tooling rather than a claim of
general autonomous planning. Its strongest use case is simple linear workflow assembly
under explicit schema constraints, with runner-based validation used to check that the
assembled workflow satisfies the requested output contract.
"""

import attrs
import attrsx
import uuid
import json
from copy import deepcopy
from typing import Type, Optional, List, Dict, Callable
from pydantic import BaseModel, Field
import re
from typing import Any
import copy
from abc import ABC, abstractmethod
import traceback
from typing import List, Optional, Dict, Any, Type, Iterable, Callable
from pydantic import BaseModel, Field, create_model
import yaml
import os
import asyncio
import importlib
import importlib.metadata
import importlib.resources as pkg_resources
from typing import List, Optional, Dict, Any, Type
from enum import Enum
from typing import List, Optional, Dict, Any, Type, Iterable, get_origin, get_args, Union
from pydantic import BaseModel
from datetime import datetime
import logging
from typing import Optional, List, Dict, Any
import hashlib
import inspect
from typing import Type, get_type_hints, Optional, List, Any
from collections.abc import Callable
from pydantic import BaseModel, Field, SkipValidation
from typing import List, Optional, Dict, Any, get_args, get_origin, Type

__design_choices__ = {}

@attrsx.define()
class InputCollector:

    def _extract_leaf_paths(self, data: any, prefix: str = "") -> dict:
        """
        Recursively traverse a nested structure (dicts and lists) and return a dictionary
        mapping each leaf's full path to its value, but skipping any leaves whose key is "name".

        For example, given:
        {
        'name': 'get_weather',
        'args': {'city': 'Berlin'}
        }
        It returns:
        {
        "args.city": "Berlin"
        }
        
        For lists, the index is included in square brackets. For example:
        {
        'information': [
            {'title': 'Weather Forecast', 'content': 'source: get_weather.output.condition'}
        ]
        }
        Would yield:
        {
        "information[0].title": "Weather Forecast",
        "information[0].content": "source: get_weather.output.condition"
        }
        """
        leaves = {}
        
        if isinstance(data, dict):
            for key, value in data.items():
                # Skip the key if it is "name"
                if key == "name":
                    continue
                new_prefix = f"{prefix}.{key}" if prefix else key
                leaves.update(self._extract_leaf_paths(value, new_prefix))
        elif isinstance(data, list):
            for idx, item in enumerate(data):
                new_prefix = f"{prefix}[{idx}]"
                leaves.update(self._extract_leaf_paths(item, new_prefix))
        else:
            # If the final key is "name", skip adding it.
            if not prefix.endswith(".name") and prefix != "name":
                leaves[prefix] = data
            
        return leaves

    def _set_by_path(self, data: Any, path: str, value: Any) -> Any:
        """
        Return a modified copy of a nested structure (dicts/lists) given a path string.
        
        Path format uses:
        - dots for nested dict keys (e.g. "args.info")
        - [index] for list indices (e.g. "[2].args.information[1].content")
        """
        new_data = copy.deepcopy(data)
        parts = re.split(r'\.(?![^\[]*\])', path)  # split on dots not inside [ ]

        current = new_data
        parents = []   # keep track of parent containers + keys/indices

        for i, part in enumerate(parts):
            # --- Handle list indices that start the part ---
            while part.startswith('['):
                m = re.match(r'\[(\d+)\](.*)', part)
                if not m:
                    break
                idx, rest = int(m.group(1)), m.group(2)
                if not isinstance(current, list) or idx >= len(current):
                    return new_data  # invalid path → return unchanged
                parents.append((current, idx))
                current = current[idx]
                part = rest

            # --- If this is the last part → assign the value ---
            if i == len(parts) - 1:
                if part:  # dict key, maybe with list index
                    m = re.match(r'([^\[]+)(\[(\d+)\])?', part)
                    if not m:
                        return new_data
                    key = m.group(1)

                    if isinstance(current, dict):
                        if key not in current:
                            return new_data
                        if m.group(2):  # key[index]
                            idx = int(m.group(3))
                            if not isinstance(current[key], list) or idx >= len(current[key]):
                                return new_data
                            current[key][idx] = value
                        else:
                            current[key] = value
                    elif isinstance(current, list):
                        try:
                            idx = int(key)
                            if idx >= len(current):
                                return new_data
                            current[idx] = value
                        except ValueError:
                            return new_data
                else:
                    # No part left → replace the entire object
                    # e.g. path = "[0]" and we reached the end
                    parent, idx_or_key = parents[-1]
                    parent[idx_or_key] = value
            else:
                # --- Traverse deeper ---
                if part:
                    m = re.match(r'([^\[]+)(\[(\d+)\])?', part)
                    if not m:
                        return new_data
                    key = m.group(1)

                    if isinstance(current, dict):
                        if key not in current:
                            return new_data
                        current = current[key]
                        if m.group(2):  # key[index]
                            idx = int(m.group(3))
                            if not isinstance(current, list) or idx >= len(current):
                                return new_data
                            parents.append((current, idx))
                            current = current[idx]
                    elif isinstance(current, list):
                        try:
                            idx = int(key)
                            current = current[idx]
                        except (ValueError, IndexError):
                            return new_data
                else:
                    continue

        return new_data

    def _update_workflow_from_leaves(self, workflow: Any, leaf_paths: list, new_values: list) -> Any:
        """
        Update the workflow based on a list of leaf paths,
        and a list of new values. For each leaf path, if the corresponding decision is True, the leaf's value
        in the workflow is replaced with the new value.
        """
        for path, new_value in zip(leaf_paths, new_values):
            if new_value:
                workflow = self._set_by_path(workflow, path, new_value)
        return workflow

    def _classify_value(self, value: str) -> str:
        """
        Classify the input value as either 'reference' or 'literal' based on regex.
        If the value contains 'source:' or '.output.', it is classified as a reference.
        Otherwise, it is a literal.
        """
        # Pattern matches if "source:" or ".output." appears anywhere in the string.
        if (value is not None) and (re.search(r"(source:|\.output\.)", value)):
            return "reference"
        return "literal"

    def _get_new_leaf_with_old_key(self, mod_leaves, inputstr):

        new_vals = [olk for olk in list(mod_leaves.keys()) if inputstr in olk]
        new_val = ""
        if new_vals:
            new_val = new_vals[0]

        return new_val

    def fix_literal_values(self, planned_workflow : dict, adapted_workflow : dict):

        """
        Replaces inputs that suppose to be literal in llm adapted workflow
        based on planned workflow.
        """

        og_leaves = self._extract_leaf_paths(planned_workflow)
        for k,v in og_leaves.items():
            if v is not None:
                v = str(v)
            og_leaves[k] = v

        mod_leaves = self._extract_leaf_paths(adapted_workflow)
        for k,v in mod_leaves.items():
            if v is not None:
                v = str(v)
            mod_leaves[k] = v

        self.logger.debug(f"og_leaves : {og_leaves}")
        self.logger.debug(f"mod_leaves : {mod_leaves}")


        ic_results = [self._classify_value(value) for value in og_leaves.values()]

        self.logger.debug(f"ic_results : {ic_results}")

        new_values = [mod_leaves.get(self._get_new_leaf_with_old_key(
            mod_leaves = mod_leaves, inputstr = inputstr), None) if cl == 'reference' else og_leaves[inputstr] \
                for inputstr, cl, mv in zip(og_leaves, ic_results, mod_leaves)]

        self.logger.debug(f"new_values : {new_values}")

        if len(mod_leaves) > len(og_leaves):
            new_values += [None for _ in range(len(mod_leaves) - len(og_leaves))]

        leaf_paths = list(og_leaves.keys())

        cor_workflow = self._update_workflow_from_leaves(adapted_workflow, leaf_paths, new_values)

        return cor_workflow

@attrs.define(kw_only=True)
class OutputComparerMock(ABC):
    """Interface for comparing expected and actual outputs."""

    @abstractmethod
    def compare_models(
        self,
        expected: BaseModel,
        actual: BaseModel,
        *args,
        ignore_optional: bool = True,
        max_decimals: int | None = None,
        ignore_fields: Iterable[str] | None = None,
        ignore_types: Iterable[type] | None = None,
        **kwargs,
    ) -> list[str]:

        """
        Abstract method for comparing two outputs within pydantic models.
        """

        raise NotImplementedError

class FunctionCallOutput(BaseModel):
    """Output container for a single function execution."""

    output: Optional[BaseModel] = Field(default=None, description="Output of the function successful run.")
    error: Optional[BaseModel]  = Field(default=None, description="Error during function execution.")

    model_config = {
        "arbitrary_types_allowed": True
    }

class WorkflowItem(BaseModel):

    """
    Workflow item.
    """

    name : str = Field(description="Name of workflow step.")
    args : Optional[dict] = Field(description="Inputs for workflow step.")

    
class TestedWorkflow(BaseModel):
    """Results for a single workflow run."""

    workflow : List[WorkflowItem] = Field(description="Planned and tested workflow.")
    inputs : BaseModel = Field(description="Inputs for test run.")
    outputs : Dict[str, BaseModel] = Field(description="Outputs from test run.")
    error : Optional[BaseModel] = Field(default = None, description="Error that happened during last run/test.")

    model_config = {
        "arbitrary_types_allowed": True
    }

class TestedWorkflowBatch(BaseModel):
    """Batch results for multiple workflow runs."""

    workflow : List[WorkflowItem] = Field(description="Planned and tested workflow.")
    case_results : List[TestedWorkflow] = Field(description="Per-case workflow run results.")
    error : Optional[BaseModel] = Field(default = None, description="Aggregated error for all cases.")

    model_config = {
        "arbitrary_types_allowed": True
    }

@attrsx.define(handler_specs = {"output_comparer" : OutputComparerMock})
class WorkflowRunner:  # pylint: disable=not-callable
    """Runs and validates assembled workflows."""

    workflow_error_types = attrs.field()
    workflow_error: Callable[..., BaseModel] = attrs.field()

    
    available_functions: List[Any] = attrs.field(
        default=None,
        converter=lambda v: None if v is None else deepcopy(v),
    )

    available_callables: Dict[str, Callable] = attrs.field(
        default=None,
        converter=lambda v: None if v is None else dict(v),
    )

    def __attrs_post_init__(self):

        self._initialize_output_comparer_h()

    def _run_func(self, 
        func_name : str,
        func : callable, 
        inputs : Type[BaseModel]):

        error = None
        output = None
        try:
            output = func(inputs = inputs)
        except Exception as e:
            error_message = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            error_type = self.workflow_error_types.RUNNER
            error = self.workflow_error(
                error_message = error_message, 
                error_type = error_type,
                additional_info = {"ffunction" : func_name})

        return FunctionCallOutput(output = output, error = error)

    def _resolve_func_args(self, 
        outputs: Dict[str, BaseModel], 
        func_args: Any) -> Any:
        
        if isinstance(func_args, dict):
            return {k: self._resolve_func_args(outputs, v) for k, v in func_args.items()}
        
        if isinstance(func_args, list):
            return [self._resolve_func_args(outputs, v) for v in func_args]
        
        if isinstance(func_args, str) and ".output." in func_args:
            try:
                step_id, path = func_args.split(".output.", 1)
                obj = outputs[step_id]
                for attr in path.split("."):
                    obj = getattr(obj, attr)
                return obj
            except (KeyError, AttributeError, IndexError, TypeError, ValueError) as e:
                raise ValueError(f"Failed to resolve reference '{func_args}': {e}") from e
        
        return func_args

    def json_schema_to_base_model(self, schema: dict) -> Dict[str, BaseModel]:
        """Build Pydantic models from a JSON schema with $defs and $ref."""

        type_mapping = {
            "string": str,
            "number": float,
            "integer": int,
            "boolean": bool,
            "object": dict,
            "array": list,
        }

        defs = {}

        # build inline nested models
        for def_name, def_schema in schema.get("$defs", {}).items():
            fields = {}
            for name, prop in def_schema["properties"].items():
                py_type = type_mapping.get(prop.get("type", "string"), Any)
                default = ... if name in def_schema.get("required", []) else prop.get("default", None)
                if default is None and name not in def_schema.get("required", []):
                    py_type = Optional[py_type]

                fields[name] = (
                    py_type,
                    Field(default, title=prop.get("title"), description=prop.get("description"))
                )
            defs[def_name] = create_model(def_schema["title"], **fields)

        # now build the top-level model
        fields = {}
        for name, prop in schema["properties"].items():
            if "$ref" in prop.get("items", {}):  # array of nested objects
                ref_name = prop["items"]["$ref"].split("/")[-1]
                py_type = List[defs[ref_name]]
                default = ... if name in schema.get("required", []) else None
            else:
                py_type = type_mapping.get(prop.get("type", "string"), Any)
                default = ... if name in schema.get("required", []) else prop.get("default", None)
                if default is None and name not in schema.get("required", []):
                    py_type = Optional[py_type]

            fields[name] = (
                py_type,
                Field(default, title=prop.get("title"), description=prop.get("description"))
            )

        return create_model(schema["title"], **fields)

    def _run_single_case(self, 
        workflow : List[dict], 
        inputs : Type[BaseModel] = None,
        expected_outputs : Type[BaseModel] = None,
        compare_params : dict = None,
        available_functions : List[Any] = None,
        available_callables : Dict[str, callable] = None,
        output_model : Type[BaseModel] = None) -> TestedWorkflow:

        """
        Runs llm planned workflow with provided inputs for a single test case.
        """

        if available_functions is None:
            available_functions = self.available_functions

        if available_callables is None:
            available_callables = self.available_callables

        if available_functions is None:
            raise ValueError("Input available_functions cannot be None!")

        if available_callables is None:
            raise ValueError("Input available_callables : Dict[str, callable] cannot be None!")

        if output_model:
            available_callables["output_model"] = output_model

        if compare_params is None:
            compare_params = {}

        workflow = workflow.copy()

        outputs = {}

        if inputs : 
            outputs["0"] = inputs

        error = None
        
        for workflow_item in workflow:

            try:

                func_args = self._resolve_func_args(
                    outputs = outputs,
                    func_args = workflow_item["args"])

                if func_args is None:
                    func_args = {}

            except (KeyError, IndexError, TypeError, ValueError) as e:
                error_message = "".join(traceback.format_exception(type(e), e, e.__traceback__))
                error_type = self.workflow_error_types.INPUTS
                error = self.workflow_error(
                    error_message = error_message,
                    error_type = error_type,
                    additional_info = {
                            "step_id" : workflow_item["id"],
                            "error_messages" : [error_message]}
                    
                )
                break


            if workflow_item["name"] != "output_model":
                
                try:
                    func_item = [av for av in available_functions \
                        if av.func_id == workflow_item["func_id"]][0]
                except (IndexError, KeyError, TypeError, ValueError) as e:
                    error_message = "".join(traceback.format_exception(type(e), e, e.__traceback__))
                    error_type = self.workflow_error_types.PLANNING_HF
                    error = self.workflow_error(
                        error_message = error_message,
                        error_type = error_type
                    )
                    break

                try:
                    func_inputs = self.json_schema_to_base_model(func_item.input_schema_json)(**func_args)
                except (TypeError, ValueError) as e:
                    error_message = "".join(traceback.format_exception(type(e), e, e.__traceback__))
                    error_type = self.workflow_error_types.ADAPTOR_JSON
                    error = self.workflow_error(
                        error_message = None,
                        error_type = error_type,
                        additional_info = {
                            "step_id" : workflow_item["id"],
                            "error_messages" : [error_message]}
                    )
                    break

                output_struct = self._run_func(
                    func_name = workflow_item["name"],
                    func = available_callables[workflow_item["func_id"]],
                    inputs = func_inputs
                )
                
                if output_struct.error:
                        
                    error = output_struct.error
                    break
                
                output = output_struct.output


            else:
                try:
                    output = output_model(**func_args)
                except (TypeError, ValueError) as e:
                    error_message = "".join(traceback.format_exception(type(e), e, e.__traceback__))
                    error_type = self.workflow_error_types.OUTPUTS_FAILURE
                    error = self.workflow_error(
                        error_message = error_message,
                        error_type = error_type,
                        additional_info = {
                            "step_id" : workflow_item["id"],
                            "error_messages" : [error_message]}
                    )
                    break


            outputs[str(workflow_item["id"])] = output

        if expected_outputs is not None and error is None:

            differences = self.output_comparer_h.compare_models(
                expected = expected_outputs,
                actual = output,
                workflow = workflow,
                **compare_params
            )

            if differences:
                failing_step_ids = [
                    d.get("source_step_id")
                    for d in differences
                    if isinstance(d.get("source_step_id"), int) and d.get("source_step_id") >= 1
                ]
                step_id = failing_step_ids[0] if failing_step_ids else len(workflow)
                error_type = self.workflow_error_types.OUTPUTS_UNEXPECTED
                error = self.workflow_error(
                        error_message = "Actual outputs do not match expected!",
                        error_type = error_type,
                        additional_info = {
                            "step_id" : step_id,
                            "differences" : differences,
                            "failing_step_ids" : failing_step_ids}
                    )

        return TestedWorkflow(
            workflow = workflow, 
            inputs = inputs,
            outputs = outputs, 
            error = error)

    def run_workflow(self, 
        workflow : List[dict], 
        test_params : List[Dict[str, Type[BaseModel]]] = None,
        inputs : Type[BaseModel] = None,
        expected_outputs : Type[BaseModel] = None,
        compare_params : dict = None,
        available_functions : List[Any] = None,
        available_callables : Dict[str, callable] = None,
        output_model : Type[BaseModel] = None) -> TestedWorkflow | TestedWorkflowBatch:

        """
        Runs llm planned workflow with provided inputs.
        Returns TestedWorkflow for single-case or TestedWorkflowBatch for multi-case.
        """
        if test_params and (inputs is not None or expected_outputs is not None):
            raise ValueError("Provide either test_params or (inputs, expected_outputs), not both.")

        if test_params:
            case_results = []
            failed_cases = []
            differences_by_case = []
            failing_step_ids = []

            for idx, case in enumerate(test_params):
                case_result = self._run_single_case(
                    workflow = workflow,
                    inputs = case.get("inputs"),
                    expected_outputs = case.get("outputs"),
                    compare_params = compare_params,
                    available_functions = available_functions,
                    available_callables = available_callables,
                    output_model = output_model
                )

                case_results.append(case_result)
                if case_result.error is not None:
                    failed_cases.append(idx)
                    error_info = getattr(case_result.error, "additional_info", None)
                    if isinstance(error_info, dict):
                        differences = error_info.get("differences")
                        if differences:
                            differences_by_case.append({"case_id": idx, "differences": differences})
                        step_id = error_info.get("step_id")
                        if step_id is not None:
                            failing_step_ids.append(step_id)

            aggregated_error = None
            if failed_cases:
                error_types = []
                for case in case_results:
                    if case.error is not None:
                        error_types.append(getattr(case.error, "error_type", None))

                error_type = None
                if error_types:
                    error_type = error_types[0]
                    if any(et != error_type for et in error_types):
                        # Mixed failure modes across cases; collapse to a generic unexpected-outputs error.
                        error_type = self.workflow_error_types.OUTPUTS_UNEXPECTED
                else:
                    error_type = self.workflow_error_types.OUTPUTS_UNEXPECTED

                aggregated_error = self.workflow_error(
                    error_message = "One or more test cases failed.",
                    error_type = error_type,
                    additional_info = {
                        "failed_cases": failed_cases,
                        "differences_by_case": differences_by_case,
                        "failing_step_ids": failing_step_ids,
                        "error_types_by_case": error_types
                    }
                )

            return TestedWorkflowBatch(
                workflow = workflow,
                case_results = case_results,
                error = aggregated_error
            )

        return self._run_single_case(
            workflow = workflow,
            inputs = inputs,
            expected_outputs = expected_outputs,
            compare_params = compare_params,
            available_functions = available_functions,
            available_callables = available_callables,
            output_model = output_model
        )

class WorkflowCheckResponse(BaseModel):

    retries : int = Field(description = "Number of attempt it took to generate workflow.")
    init_messages : List[dict] = Field(default = None, description = "Initial messages for planning workflow.")
    errors : List[BaseModel] = Field(description = "Errors during planning.")
    include_input : bool = Field(description = "If input model is expected.")
    include_output : bool = Field(description = "If output model is expected.")
    workflow_possible : bool = Field(description = "If workflow is possible for a provided task and set of tools.")
    justification : str = Field(description = "Why it was determined that workflow is possible or not.")

    model_config = {
        "arbitrary_types_allowed": True
    }

@attrs.define(kw_only=True)
class LlmHandlerMock(ABC):

    @abstractmethod
    async def chat(self, messages: List[Dict[str, str]],  *args, **kwargs):

        """
        Abstract chat method for async chat method that passes messages to llm.
        """

        pass


@attrsx.define(handler_specs = {"llm" : LlmHandlerMock})
class WorkflowCheck:

    workflow_error_types = attrs.field()
    workflow_error = attrs.field()

    system_message : str = attrs.field(default=None)
    system_message_items : Dict[str, str] = attrs.field(default=None)
    debug_prompts : Dict[str, str] = attrs.field(default=None)
    check_prompt : str = attrs.field(default=None)
    check_prompt_items : Dict[str, str] = attrs.field(default=None)
    
    prompts_filepath : str = attrs.field(default=None)
    available_functions : list = attrs.field(default=None)

    n_checks : int = attrs.field(default=7)
    max_retry : int = attrs.field(default=5)

    """
    Checks if workflows are possible based on provided task and description
    """

    def __attrs_post_init__(self):

        self._assign_prompts()

    def _assign_prompts(self, 
        prompts_filepath : str = None,
        system_message : str = None, 
        system_message_items : Dict[str,str] = None,
        check_prompt_items : Dict[str, str] = None,
        debug_prompts : Dict[str, str] = None,
        check_prompt : str = None
        ):

        if prompts_filepath is None: 
            prompts_filepath = self.prompts_filepath

        wa_path = pkg_resources.files('workflow_auto_assembler')

        if 'artifacts' in os.listdir(wa_path):

            if prompts_filepath is None:

                with pkg_resources.path('workflow_auto_assembler.artifacts.prompts',
                'workflow_check.yml') as path:
                    prompts_filepath = path

            with open(prompts_filepath, 'r') as f:
                wp_prompts = yaml.safe_load(f)

        if system_message: 
            self.system_message = system_message
        else:
            self.system_message = wp_prompts['system_message']

        if system_message_items: 
            self.system_message_items = system_message_items
        else:
            self.system_message_items = wp_prompts.get("system_message_items", {})

        if check_prompt_items: 
            self.check_prompt_items = check_prompt_items
        else:
            self.check_prompt_items = wp_prompts.get("check_prompt_items", {})

        if debug_prompts: 
            self.debug_prompts = debug_prompts
        else:
            self.debug_prompts = wp_prompts['debug_prompts']

        if check_prompt: 
            self.check_prompt = check_prompt
        else:
            self.check_prompt = wp_prompts['check_prompt']


    def _read_json_output(self, output : str) -> list | dict | None:

        try:

            if "```json" in output:
                output = output.replace("```json", "").replace("```", "")

            function_calls = json.loads(output)
        except Exception as e:
            self.logger.error(f"Failed to extract json from {output}")
            return None

        return function_calls

    def _get_hafunctions(self, 
        function_calls : list, 
        available_functions : list,
        include_output : bool) -> tuple:

        hfunctions, afunctions = None, None

        if function_calls:

            afunctions = [afd.name for afd in available_functions]

            hfunctions = [fc['name'] for fc in function_calls if fc['name'] not in afunctions]

            if include_output:
                hfunctions = [hf for hf in hfunctions if hf != "output_model"]

        return hfunctions, afunctions 

    def _prep_init_messages(self,
        task_description : str, 
        available_functions : list, 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,):


        available_functions_json = json.dumps([
            {key:value for key,value in av.model_dump().items() \
                if key in ["name", "description", "input_schema_json", "output_schema_json"]} \
                    for av in available_functions])

        system_message_items = {
            "purpose_description" : "",
            "expected_output_schema" : "",
            "function_call_description" : ""
        }

        if self.system_message_items.get("purpose_description"):
            system_message_items["purpose_description"] = self.system_message_items.get("purpose_description")

        if self.system_message_items.get("expected_output_schema"):
            system_message_items["expected_output_schema"] = self.system_message_items.get("expected_output_schema")

        if self.system_message_items.get("function_call_description"):
            system_message_items["function_call_description"] = self.system_message_items.get("function_call_description").format(
                available_functions = available_functions_json)

        user_message_items = {
            "task_description" : task_description,
            "input_schema" : "",
            "output_schema" : ""}

        if input_model is not None and self.check_prompt_items.get("input_schema") is not None:
            user_message_items["input_schema"] = self.check_prompt_items["input_schema"].format(
                input_model_schema = input_model.model_json_schema())

        if output_model is not None and self.check_prompt_items.get("output_schema") is not None:
            user_message_items["output_schema"] = self.check_prompt_items["output_schema"].format(
                output_model_schema = output_model.model_json_schema())

        messages = [
        {"role": "system", "content": self.system_message.format(
            **system_message_items)},
        {"role": "user", "content": self.check_prompt.format(
            **user_message_items
        )}
        ]

        return messages

    def _check_llm_response(self, 
        llm_response : str, 
        available_functions : list,
        include_output : bool = False,
        init_error : Optional[Type[BaseModel]] = None):

        if init_error:
            return init_error

        function_calls = self._read_json_output(output=llm_response)

        if function_calls is None:
            return self.workflow_error(error_type = self.workflow_error_types.CHECK_JSON,
                additional_info = {"llm_response" : llm_response})

        
        return None

    async def _get_llm_response(self, messages, n_checks):

        tasks = [self.llm_h.chat(messages) for i in range(n_checks)]

        responses = await asyncio.gather(*tasks)


        llm_responses = [response.message.content for response in responses] 

        checked_workflow_items_v = [self._read_json_output(output=llm_response) for llm_response in llm_responses] 
        decisions = [checked_workflow_items["decision"] for checked_workflow_items in checked_workflow_items_v if checked_workflow_items is not None]
        llm_response_p = [llm_response for llm_response, decision in zip(llm_responses, decisions) if decision]
        if llm_response_p:
            llm_response = llm_response_p[0]
        else:
            llm_response = llm_responses[0]

        return llm_response

    async def check_workflow(
        self,
        task_description : str = None, 
        available_functions : list = None, 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        max_retry : Optional[int] = None,
        n_checks : Optional[int] = None,
        checked_workflow : Optional[WorkflowCheckResponse] = None) -> WorkflowCheckResponse:

        """
        Check viability of workflow from available functions given task description.

        Args:

            task_description (str): llm prompt that describes a task, achievable with available functions.
            available_functions (list): list of function items for llm to pick from with their input and output models.
            max_retry (Optional[int]): optional maximum number of allowed retries.
        """

        if max_retry is None:
            max_retry = self.max_retry

        if n_checks is None:
            n_checks = self.n_checks

        if available_functions is None:
            available_functions = self.available_functions

        if available_functions is None:
            raise ValueError("Input available_functions : list cannot be None!")

        if checked_workflow is None:

            self.logger.debug(f"Running initial check...")
        
            init_messages = self._prep_init_messages(
                available_functions = available_functions, 
                task_description = task_description, 
                input_model = input_model, 
                output_model = output_model
            )

            llm_response = await self._get_llm_response(messages = init_messages, n_checks = n_checks)

            retry_i = 0
            errors = []
            init_error = None
            include_input = input_model is not None
            include_output = output_model is not None
        
        else:
            init_messages = checked_workflow.init_messages
            llm_response = json.dumps({"justification" :  checked_workflow.justification,
                                       "decision" : checked_workflow.workflow_possible})
            retry_i = checked_workflow.retries
            errors = checked_workflow.errors
            init_error = errors[-1]
            include_input = checked_workflow.include_input
            include_output = checked_workflow.include_output
        
        retry_messages = init_messages

        while retry_i < max_retry:

            error = self._check_llm_response(
                init_error = init_error,
                llm_response = llm_response,
                include_output = include_output,
                available_functions = available_functions)

            if error is None:
                checked_workflow_items = self._read_json_output(output=llm_response)
                self.logger.debug(f"Decision from initial check is ready!")
                return WorkflowCheckResponse(
                    errors = errors,
                    retries = retry_i,
                    include_input = include_input,
                    include_output = include_output,
                    init_messages = init_messages,
                    workflow_possible = checked_workflow_items["decision"],
                    justification = checked_workflow_items["justification"],
                )

            retry_i += 1
            if init_error:
                init_error = None
            else:
                errors.append(error)

            self.logger.debug(f"Attempt: {retry_i}")

            if error.error_type is self.workflow_error_types.CHECK_JSON:
                llm_response = await self._get_llm_response(messages = retry_messages, n_checks = n_checks)
                continue

            if error.error_type is self.workflow_error_types.CHECK_INIT:
                break

            
        if retry_i == max_retry:
            self.logger.warning(f"Initial check ran out of retries!")
            return WorkflowCheckResponse(
                errors = errors,
                retries = retry_i,
                init_messages = init_messages,
                include_input = include_input,
                include_output = include_output,
                workflow_possible = None,
                justification = None
            )

class WorkflowPlannerResponse(BaseModel):

    retries : int = Field(description = "Number of attempt it took to generate workflow.")
    workflow : Optional[List[dict]] = Field(default = None, description = "Planned workflow.")
    init_messages : List[dict] = Field(default = None, description = "Initial messages for planning workflow.")
    additional_messages : List[dict] = Field(default = None, description = "Additional messages for planning workflow.")
    errors : List[BaseModel] = Field(description = "Errors during planning.")
    include_input : bool = Field(description = "If input model is expected.")
    include_output : bool = Field(description = "If output model is expected.")

    model_config = {
        "arbitrary_types_allowed": True
    }

@attrs.define(kw_only=True)
class LlmHandlerMock(ABC):

    @abstractmethod
    async def chat(self, messages: List[Dict[str, str]],  *args, **kwargs):

        """
        Abstract chat method for async chat method that passes messages to llm.
        """

        pass


@attrsx.define(handler_specs = {"llm" : LlmHandlerMock})
class WorkflowPlanner:

    workflow_error_types = attrs.field()
    workflow_error = attrs.field()

    system_message : str = attrs.field(default=None)
    system_message_items : Dict[str, str] = attrs.field(default=None)
    debug_prompts : Dict[str, str] = attrs.field(default=None)
    plan_prompt : str = attrs.field(default=None)
    plan_prompt_items : Dict[str, str] = attrs.field(default=None)
    
    prompts_filepath : str = attrs.field(default=None)
    available_functions: List[Any] = attrs.field(
        default=None,
        converter=lambda v: None if v is None else deepcopy(v),
    )

    max_retry : int = attrs.field(default=5)

    """
    Plans workflows
    """

    def __attrs_post_init__(self):

        self._assign_prompts()

    def _assign_prompts(self, 
        prompts_filepath : str = None,
        system_message : str = None, 
        system_message_items : Dict[str,str] = None,
        plan_prompt_items : Dict[str, str] = None,
        debug_prompts : Dict[str, str] = None,
        plan_prompt : str = None
        ):

        if prompts_filepath is None: 
            prompts_filepath = self.prompts_filepath

        wa_path = pkg_resources.files('workflow_auto_assembler')

        if 'artifacts' in os.listdir(wa_path):

            if prompts_filepath is None:

                with pkg_resources.path('workflow_auto_assembler.artifacts.prompts',
                'workflow_planner.yml') as path:
                    prompts_filepath = path

            with open(prompts_filepath, 'r', encoding="utf-8") as f:
                wp_prompts = yaml.safe_load(f)

        if system_message: 
            self.system_message = system_message
        else:
            self.system_message = wp_prompts['system_message']

        if system_message_items: 
            self.system_message_items = system_message_items
        else:
            self.system_message_items = wp_prompts.get("system_message_items", {})

        if plan_prompt_items: 
            self.plan_prompt_items = plan_prompt_items
        else:
            self.plan_prompt_items = wp_prompts.get("plan_prompt_items", {})

        if debug_prompts: 
            self.debug_prompts = debug_prompts
        else:
            self.debug_prompts = wp_prompts['debug_prompts']

        if plan_prompt: 
            self.plan_prompt = plan_prompt
        else:
            self.plan_prompt = wp_prompts['plan_prompt']


    def _read_json_output(self, output : str) -> list | dict | None:

        try:

            if "```json" in output:
                output = output.replace("```json", "").replace("```", "")

            function_calls = json.loads(output)
        except Exception as e:
            self.logger.error(f"Failed to extract json from {output}")
            return None

        return function_calls

    def _get_hafunctions(self, 
        function_calls : list, 
        available_functions : list,
        include_output : bool) -> tuple:

        hfunctions, afunctions = None, None

        if function_calls:

            afunctions = [afd.name for afd in available_functions]

            hfunctions = [fc.get('name')  for fc in function_calls if fc.get('name', "") not in afunctions]

            if [i for i in hfunctions if i is None]:
                self.logger.error(f"Function call is missing function name: {function_calls}")
            hfunctions = [i for i in hfunctions if i is not None]

            if include_output:
                hfunctions = [hf for hf in hfunctions if hf != "output_model"]

        return hfunctions, afunctions 

    def _prep_init_messages(self,
        task_description : str, 
        available_functions : list, 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,):


        available_functions_json = json.dumps([
            {key:value for key,value in av.model_dump().items() \
                if key in ["name", "description", "input_schema_json", "output_schema_json"]} \
                    for av in available_functions])

        system_message_items = {
            "purpose_description" : "",
            "expected_output_schema" : "",
            "function_call_description" : ""
        }

        if self.system_message_items.get("purpose_description"):
            system_message_items["purpose_description"] = self.system_message_items.get("purpose_description")

        if self.system_message_items.get("expected_output_schema"):
            system_message_items["expected_output_schema"] = self.system_message_items.get("expected_output_schema")

        if self.system_message_items.get("function_call_description"):
            system_message_items["function_call_description"] = self.system_message_items.get("function_call_description").format(
                available_functions = available_functions_json)

        user_message_items = {
            "task_description" : task_description,
            "input_schema" : "",
            "output_schema" : ""}

        if input_model is not None and self.plan_prompt_items.get("input_schema") is not None:
            user_message_items["input_schema"] = self.plan_prompt_items["input_schema"].format(
                input_model_schema = input_model.model_json_schema())

        if output_model is not None and self.plan_prompt_items.get("output_schema") is not None:
            user_message_items["output_schema"] = self.plan_prompt_items["output_schema"].format(
                output_model_schema = output_model.model_json_schema())

        messages = [
        {"role": "system", "content": self.system_message.format(
            **system_message_items)},
        {"role": "user", "content": self.plan_prompt.format(
            **user_message_items
        )}
        ]

        return messages

    def _check_llm_response(self, 
        llm_response : str, 
        available_functions : list,
        include_output : bool = False,
        init_error : Optional[Type[BaseModel]] = None):

        if init_error:
            return init_error

        function_calls = self._read_json_output(output=llm_response)

        if function_calls is None:
            return self.workflow_error(error_type = self.workflow_error_types.PLANNING_JSON,
                additional_info = {"llm_response" : llm_response})

        hfunctions, afunctions = self._get_hafunctions(
                function_calls = function_calls, 
                available_functions = available_functions,
                include_output = include_output)

        if hfunctions is None:
            return self.workflow_error(error_type = self.workflow_error_types.PLANNING_JSON,
                additional_info = {"llm_response" : llm_response})

        if not ((function_calls is not None) and ((hfunctions is None) or (hfunctions == []))):
            return self.workflow_error(error_type = self.workflow_error_types.PLANNING_HF,
                additional_info = {"llm_response" : llm_response})

        if include_output:
            if "output_model" not in [fc["name"] for fc in function_calls]:
                return self.workflow_error(error_type = self.workflow_error_types.PLANNING_MISSOUTPUT,
                additional_info = {"llm_response" : llm_response})
            output_steps = [fc for fc in function_calls if fc.get("name") == "output_model"]
            for step in output_steps:
                args = step.get("args")
                if not isinstance(args, dict) or len(args) == 0:
                    return self.workflow_error(
                        error_type = self.workflow_error_types.PLANNING_OUTPUT_MODEL,
                        additional_info = {
                            "llm_response": llm_response,
                            "reason": "output_model_missing_args"
                        }
                    )

        return None


    async def generate_workflow(
        self,
        task_description : str = None, 
        available_functions : list = None, 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        max_retry : Optional[int] = None,
        planned_workflow : Optional[WorkflowPlannerResponse] = None) -> WorkflowPlannerResponse:

        """
        Generates initial workflow from available functions given task description.

        Args:

            task_description (str): llm prompt that describes a task, achievable with available functions.
            available_functions (list): list of function items for llm to pick from with their input and output models.
            max_retry (Optional[int]): optional maximum number of allowed retries.
        """

        if max_retry is None:
            max_retry = self.max_retry

        if available_functions is None:
            available_functions = self.available_functions

        if available_functions is None:
            raise ValueError("Input available_functions : list cannot be None!")

        if planned_workflow is None:
        
            init_messages = self._prep_init_messages(
                available_functions = available_functions, 
                task_description = task_description, 
                input_model = input_model, 
                output_model = output_model
            )

            response = await self.llm_h.chat(init_messages)
            llm_response = response.message.content
            additional_messages = [{'role' : 'assistant', "content" : llm_response}]

            retry_i = 0
            errors = []
            init_error = None
            include_input = input_model is not None
            include_output = output_model is not None
        
        else:
            init_messages = planned_workflow.init_messages
            additional_messages = planned_workflow.additional_messages
            llm_response = json.dumps(planned_workflow.workflow)
            retry_i = planned_workflow.retries
            errors = planned_workflow.errors
            if len(errors) == 0:
                self.logger.error("Planner recieved `planned_workflow` input for retry that doesn not contain any errors!")
                return planned_workflow
            init_error = errors[-1]
            include_input = planned_workflow.include_input
            include_output = planned_workflow.include_output

        while retry_i < max_retry:

            error = self._check_llm_response(
                init_error = init_error,
                llm_response = llm_response,
                include_output = include_output,
                available_functions = available_functions)

            if error is None:
                planned_workflow = self._read_json_output(output=llm_response)
                return WorkflowPlannerResponse(
                    errors = errors,
                    workflow = planned_workflow,
                    retries = retry_i,
                    include_input = include_input,
                    include_output = include_output,
                    init_messages = init_messages,
                    additional_messages = additional_messages
                )

            retry_i += 1
            if init_error:
                init_error = None
            else:
                errors.append(error)

            self.logger.debug(f"Reset caused by {error.error_type.name} type error!")
            self.logger.debug(f"Attempt: {retry_i}")

            if error.error_type is self.workflow_error_types.PLANNING_JSON:

                retry_messages = init_messages
                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages[-1] = {"role" : "assistant", "content" : llm_response}
                continue

            if error.error_type is self.workflow_error_types.PLANNING_MISSOUTPUT:
                
                additional_messages += [
                    {"role": "user", "content": self.debug_prompts["mo"].format(
                        output_model_schema = output_model.model_json_schema()
                    )}
                ]
                retry_messages = init_messages + additional_messages 

                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                continue

            if error.error_type is self.workflow_error_types.PLANNING_OUTPUT_MODEL:

                additional_messages += [
                    {"role": "user", "content": self.debug_prompts["om"].format(
                        output_model_schema = output_model.model_json_schema()
                    )}
                ]
                retry_messages = init_messages + additional_messages 

                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                continue

            if error.error_type is self.workflow_error_types.PLANNING_HF:

                function_calls = self._read_json_output(output=llm_response)

                hfunctions, afunctions = self._get_hafunctions(
                        function_calls = function_calls, 
                        available_functions = available_functions,
                        include_output = include_output)

                additional_messages += [
                    {"role": "user", "content": self.debug_prompts["hf"].format(
                        hfunctions = "\n -".join([h for h in hfunctions]),
                        afunctions = "\n -".join([a for a in afunctions]))}
                ]

                retry_messages = init_messages + additional_messages

                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                continue

            if error.error_type is self.workflow_error_types.RUNNER:

                function_calls = self._read_json_output(output=llm_response)

                _, afunctions = self._get_hafunctions(
                        function_calls = function_calls, 
                        available_functions = available_functions,
                        include_output = include_output)

                ffunction = error.additional_info.get("ffunction")

                additional_messages += [
                    {"role": "user", "content": self.debug_prompts["alt"].format(
                        ffunction = ffunction,
                        afunctions = "\n -".join([a for a in afunctions if a != ffunction]))}
                ]

                retry_messages = init_messages + additional_messages

                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                continue

            if error.error_type is self.workflow_error_types.PLANNING_RESET:

                differences = error.additional_info.get("differences")
                failing_paths = error.additional_info.get("failing_paths")
                failing_sources = None
                if differences:
                    try:
                        failing_sources = sorted({d.get("source_step_id") for d in differences if isinstance(d, dict) and d.get("source_step_id")})
                    except Exception:
                        failing_sources = None
                if failing_paths:
                    failing_summary = "Unsatisfied output fields: " + ", ".join(failing_paths)
                    if differences:
                        differences = [failing_summary] + list(differences)
                    else:
                        differences = [failing_summary]
                if failing_sources:
                    source_summary = "Source steps that produced mismatches: " + ", ".join([str(s) for s in failing_sources])
                    if differences:
                        differences = [source_summary] + list(differences)
                    else:
                        differences = [source_summary]

                formatted_differences = "\n -".join(
                    [json.dumps(d) if isinstance(d, dict) else str(d) for d in (differences or ["(no differences provided)"])]
                )
                additional_messages += [
                    {"role": "user", "content": self.debug_prompts["unexpected"].format(
                        differences = formatted_differences
                    )}
                ]

                retry_messages = init_messages + additional_messages

                debug_response = await self.llm_h.chat(retry_messages)
                llm_response = debug_response.message.content
                additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                continue

        if retry_i == max_retry:
            return WorkflowPlannerResponse(
                errors = errors,
                workflow = None,
                retries = retry_i,
                init_messages = init_messages,
                additional_messages = additional_messages,
                include_input = include_input,
                include_output = include_output,
            )

@attrsx.define()
class OutputComparer:
    ignore_optional: bool = attrs.field(
        default=True
    )
    max_decimals: int | None = attrs.field(
        default=None
    )

    ignore_fields: set[str] = attrs.field(
        factory=set,
        converter=set,
    )

    ignore_types: set[type] = attrs.field(
        factory=set,
        converter=set,
    )

    def compare_models(
        self,
        expected: BaseModel,
        actual: BaseModel,
        workflow : List[dict] = None,
        *,
        ignore_optional: bool | None = None,
        max_decimals: int | None = None,
        ignore_fields: Iterable[str] | None = None,
        ignore_types: Iterable[type] | None = None,
    ) -> list[Dict[str, Any]]:
        """
        Compare two Pydantic models and return a list of diff dictionaries.

        Each diff entry has the shape:

            {
                "path": str,              # field path, e.g. "a.b[0]['c']"
                "diff_type": str,         # one of:
                                         #   "value_mismatch"
                                         #   "length_mismatch"
                                         #   "missing_in_expected"
                                         #   "missing_in_actual"
                "expected": Any,          # expected value (or length, or None if missing)
                "actual": Any,            # actual value (or length, or None if missing)
            }

        Options:

        - ignore_optional:
            If True, Optional[...] fields are skipped when either side is None.
            If None, use the instance's ignore_optional.
        - max_decimals:
            If set, floats are rounded to this many decimal places before comparing.
            If None, use the instance's max_decimals.
        - ignore_fields:
            Iterable of field *paths* or simple names to ignore, e.g.:
                {"created_at", "inner.secret"}.
            If None, use the instance's ignore_fields.
        - ignore_types:
            Iterable of Python types (based on field annotations) to ignore, e.g.:
                {datetime, UUID, YourCustomModel}.
            Optional[...] is unwrapped before checking.
            If None, use the instance's ignore_types.
        """
        # Compute effective config (instance defaults overridden by call-level args)
        eff_ignore_optional = self.ignore_optional if ignore_optional is None else ignore_optional
        eff_max_decimals = self.max_decimals if max_decimals is None else max_decimals
        eff_ignore_fields = self.ignore_fields if ignore_fields is None else set(ignore_fields)
        eff_ignore_types = self.ignore_types if ignore_types is None else set(ignore_types)

        # Temporarily override self.* so internals can just read from self
        old_ignore_optional = self.ignore_optional
        old_max_decimals = self.max_decimals
        old_ignore_fields = self.ignore_fields
        old_ignore_types = self.ignore_types

        self.ignore_optional = eff_ignore_optional
        self.max_decimals = eff_max_decimals
        self.ignore_fields = eff_ignore_fields
        self.ignore_types = eff_ignore_types

        try:
            diffs: list[Dict[str, Any]] = []
            self._compare_models(expected, actual, "", diffs)

            if workflow:
                diffs = [{**d, 
                "output" : workflow[len(workflow)-1]['args'][self._get_source_key(d["path"])],
                "source_step_id" : self._get_step_id_for_path(path = self._get_source_key(d["path"]), workflow = workflow), 
                "source" : self.classify_diff_item(path = d["path"], workflow = workflow)} for d in diffs]
            return diffs
        finally:
            # Restore instance state
            self.ignore_optional = old_ignore_optional
            self.max_decimals = old_max_decimals
            self.ignore_fields = old_ignore_fields
            self.ignore_types = old_ignore_types

    # ---------- helpers for classifying diff ----------

    
    def classify_diff_item(self, workflow, path):

        output_source, output_source_loc = self._get_source_from_path(workflow=workflow, path=path)

        output_source_c = self._classify_source(output_source = output_source)

        label = self._process_cs(output_source = output_source_c, app = output_source_loc)

        return label

    def _get_step_id_for_path(self,workflow, path):

        output = workflow[len(workflow)-1]['args'][path]

        step_id = -1

        if isinstance(output, list) or isinstance(output, dict):
            return step_id

        splits = output.split(".")
        if len(splits) > 1:
            step_id = int(splits[0])

            return step_id


    def _classify_source_item(self, output_source : str):

        if output_source.startswith("0.output"):
            return "user_input"

        if ".output." in output_source:
            return "function_output"

        return "llm_input"

    def _classify_source(self, output_source):

        if isinstance(output_source, list):
            return [self._classify_source(output_source=osi) for osi in output_source]

        if isinstance(output_source, dict):
            return {k : self._classify_source(output_source=v) for k,v in output_source.items()}

        if isinstance(output_source, str):
            return self._classify_source_item(output_source = output_source)

    def _process_cs(self, output_source, app):

        if app:

            apps = app.split(".")

            for a in apps:

                if "[" in a:
                    output_source = output_source[int(a.replace("[", "").replace("]", ""))] 
                elif "." in a:
                    output_source = output_source[a.replace(".", "")] 
                else:
                    output_source = output_source[a] 

        return output_source

    def _get_dir_source_from_path(self, workflow, path):

        split_conds = ["[", "."]

        for split_cond in split_conds:

            fields = path.split(split_cond)
            if len(fields) > 1:
                app = fields[1:]
                if split_cond in ["["]:
                    return split_cond + split_cond.join(app)
                return split_cond.join(app)

        return None

    def _get_source_from_path(self, workflow, path):

        field = self._get_source_key(path = path)

        app = self._get_dir_source_from_path(workflow = workflow, path = path)

        return workflow[-1]['args'][field] , app

    def _get_source_key(self, path):

        fields = path.split("[")

        if len(fields) == 1:
            fields = path.split(".")

        field = fields[0]

        return field

    # ---------- helpers for diff collection ----------

    @staticmethod
    def _is_optional_type(t) -> bool:
        return get_origin(t) is Union and type(None) in get_args(t)

    @staticmethod
    def _base_type_for_ignore(t):
        if get_origin(t) is Union:
            args = [a for a in get_args(t) if a is not type(None)]
            if args:
                return args[0]
        return t

    def _get_field_types(self, model: BaseModel):
        cls = model.__class__

        if hasattr(cls, "model_fields"):  # Pydantic v2
            return {name: f.annotation for name, f in cls.model_fields.items()}

        if hasattr(cls, "__fields__"):    # Pydantic v1
            return {name: f.outer_type_ for name, f in cls.__fields__.items()}

        return cls.__annotations__

    def _should_ignore_path(self, path: str) -> bool:
        if path in self.ignore_fields:
            return True

        last = path.split(".")[-1]
        if last in self.ignore_fields:
            return True

        return False

    def _should_ignore_type(self, f_type) -> bool:
        if not self.ignore_types:
            return False

        base = self._base_type_for_ignore(f_type)

        for t in self.ignore_types:
            try:
                if isinstance(base, type) and isinstance(t, type):
                    if base is t or issubclass(base, t):
                        return True
            except TypeError:
                # in case base or t are not class-like
                pass

            if base == t:
                return True

        return False

    def _add_diff(
        self,
        diffs: list[Dict[str, Any]],
        *,
        path: str,
        diff_type: str,
        expected: Any,
        actual: Any,
    ) -> None:
        diffs.append(
            {
                "path": path,
                "diff_type": diff_type,
                "expected": expected,
                "actual": actual,
            }
        )

    def _compare_scalar(self, left, right, path: str , diffs: list[Dict[str, Any]]):
        # Handle numeric rounding if configured
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            if self.max_decimals is not None:
                left = round(float(left), self.max_decimals)
                right = round(float(right), self.max_decimals)

        if left != right:
            self._add_diff(
                diffs,
                path=path,
                diff_type="value_mismatch",
                expected=left,
                actual=right,
            )

    def _compare_values(self, left, right, path: str, diffs: list[Dict[str, Any]]):
        # Nested models
        if isinstance(left, BaseModel) and isinstance(right, BaseModel):
            self._compare_models(left, right, path, diffs)
            return

        # Sequences
        if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
            if len(left) != len(right):
                self._add_diff(
                    diffs,
                    path=path,
                    diff_type="length_mismatch",
                    expected=len(left),
                    actual=len(right),
                )
            for i, (l_item, r_item) in enumerate(zip(left, right)):
                self._compare_values(l_item, r_item, f"{path}[{i}]", diffs)
            return

        # Dicts
        if isinstance(left, dict) and isinstance(right, dict):
            keys = set(left) | set(right)
            for k in keys:
                kp = f"{path}[{k!r}]"
                if k not in left:
                    # missing on expected
                    self._add_diff(
                        diffs,
                        path=kp,
                        diff_type="missing_in_expected",
                        expected=None,
                        actual=right.get(k),
                    )
                elif k not in right:
                    # missing on actual
                    self._add_diff(
                        diffs,
                        path=kp,
                        diff_type="missing_in_actual",
                        expected=left.get(k),
                        actual=None,
                    )
                else:
                    self._compare_values(left[k], right[k], kp, diffs)
            return

        # Fallback scalar comparison
        self._compare_scalar(left, right, path, diffs)

    def _compare_models(
        self,
        expected: BaseModel,
        actual: BaseModel,
        base_path: str,
        diffs: list[Dict[str, Any]],
    ):
        field_types = self._get_field_types(expected)

        for name, f_type in field_types.items():
            path = f"{base_path}.{name}" if base_path else name

            if self._should_ignore_path(path):
                continue
            if self._should_ignore_type(f_type):
                continue

            left = getattr(expected, name)
            try:
                right = getattr(actual, name)
            except AttributeError:
                # field missing on actual model
                self._add_diff(
                    diffs,
                    path=path,
                    diff_type="missing_in_actual",
                    expected=left,
                    actual=None,
                )
                continue

            if self.ignore_optional and self._is_optional_type(f_type):
                if left is None or right is None:
                    # skip Optional[...] comparisons where one side is None
                    continue

            self._compare_values(left, right, path, diffs)

#! import openai
#! import ollama

  

class LlmHandlerBaseResponse(BaseModel):
    """
    Follows Ollama BaseGenerateResponse model
    """

    model: Optional[str] = Field(default = None, description ='Model used to generate response.')
    created_at: Optional[str] = Field(default = None, description ='Time when the request was created.')
    total_duration: Optional[int] = Field(default = None, description ='Total duration in nanoseconds.')

    def as_dict(self) -> dict:
        """Return a dict representation of the response."""
        if hasattr(self, "model_dump"):
            return self.model_dump()
        return self.dict()

    def as_json(self) -> str:
        """Return a JSON string representation of the response."""
        if hasattr(self, "model_dump_json"):
            return self.model_dump_json()
        return self.json()

class LlmMessage(BaseModel):
    """
    Chat message based on Ollama.
    """

    role: str = Field(description="Assumed role of the message. Response messages has role 'assistant' or 'tool'.")
    content: Optional[str] = Field(
        default=None,
        description="Content of the message. Response messages contains message fragments when streaming.",
    )
    thinking: Optional[str] = Field(
        default=None,
        description="Thinking content. Only present when thinking is enabled.",
    )

    def as_dict(self) -> dict:
        """Return a dict representation of the message."""
        if hasattr(self, "model_dump"):
            return self.model_dump()
        return self.dict()

    def as_json(self) -> str:
        """Return a JSON string representation of the message."""
        if hasattr(self, "model_dump_json"):
            return self.model_dump_json()
        return self.json()


class LlmHandlerChatOutput(LlmHandlerBaseResponse):

    """
    Follows Ollama ChatResponse model
    """

    message: Optional[LlmMessage] = Field(default = None, description ='Response message.')
    def as_dict(self) -> dict:
        """Return a dict representation of the chat output."""
        if hasattr(self, "model_dump"):
            return self.model_dump()
        return self.dict()

    def as_json(self) -> str:
        """Return a JSON string representation of the chat output."""
        if hasattr(self, "model_dump_json"):
            return self.model_dump_json()
        return self.json()


@attrsx.define
class OllamaHandlerAsync():
    """
    Extended OllamaHandlerAsync supporting chat with optional function calling.
    """

    connection_string: Optional[str] = attrs.field(default=None)
    model_name: Optional[str] = attrs.field(default=None)

    model = attrs.field(default=None)

    kwargs: Dict[str, Any] = attrs.field(factory=dict)

    def __attrs_post_init__(self):

        self._initialize_ollama()

    def _initialize_ollama(self):

        try:
            AsyncClient = importlib.import_module("ollama").AsyncClient
        except ImportError as e:
            raise ImportError("Failed to import ollama!") from e

        if self.model is None:
            self.model = AsyncClient(
                host = self.connection_string,
                **dict(self.kwargs),
            )


    async def chat(self, 
                   messages: List[Dict[str, str]], 
                   model_name: Optional[str] = None) -> LlmHandlerChatOutput:
        """
        Core chat method for Ollama .
        """

        params = {
            "model": model_name or self.model_name,
            "messages": messages,
        }
        if self.kwargs:
            params.update(dict(self.kwargs))


        response = await self.model.chat(**params)
        self.logger.debug(f"Tokens used: {response.get('usage', {}).get('total_tokens', 0)}")


        return LlmHandlerChatOutput(
            model = response.model,
            created_at = response.created_at,
            total_duration = response.total_duration,
            message = LlmMessage(
                role = response.message.role,
                content = response.message.content
            )
        )

    def get_client(self):
        """Return the underlying Ollama client instance."""
        return self.model
            

    


@attrsx.define
class OpenAIHandlerAsync:
    """
    OpenAIHandlerAsync – Async client for OpenAI models with native function calling (tools).
    """

    connection_string: Optional[str] = attrs.field(default=None)  # Optional for Azure OpenAI
    model_name: Optional[str] = attrs.field(default="gpt-4-turbo")  # Default OpenAI model
    api_key: Optional[str] = attrs.field(default=None)  # OpenAI API Key

    model = attrs.field(default=None)
    
    kwargs: Dict[str, Any] = attrs.field(factory=dict)  # Additional passthrough options

    def __attrs_post_init__(self):
        self._initialize_openai()

    def _initialize_openai(self):

        try:
            openai = importlib.import_module("openai")
        except ImportError as e:
            raise ImportError("Failed to import openai!") from e

        self.model = openai

        if self.api_key:
            self.model.api_key = self.api_key
        if self.connection_string:
            self.model.api_base = self.connection_string  # Support for Azure endpoint

    async def chat(self, 
                   messages: List[Dict[str, str]], 
                   model_name: Optional[str] = None) -> LlmHandlerChatOutput:
        """
        Core chat method for OpenAI.
        """

        params = {
            "model": model_name or self.model_name,
            "messages": messages,
        }
        if self.kwargs:
            params.update(dict(self.kwargs))

        exec_start = datetime.now()
        response = await self.model.ChatCompletion.acreate(**params)
        self.logger.debug(f"Tokens used: {response['usage']['total_tokens']}")
        

        return LlmHandlerChatOutput(
            model = response["model"],
            created_at = response["created"],
            total_duration = datetime.now() - exec_start,
            message = LlmMessage(
                role = response["choices"][0].message.role,
                content = response["choices"][0].message.content,
            )

        )

    def get_client(self):
        """Return the underlying OpenAI client instance."""
        return self.model


@attrsx.define
class LlmHandler:
    """
    General llm handler, connects to different llm apis.
    """

    llm_h_type : str = attrs.field()
    llm_h_params: Dict[str, Any] = attrs.field(factory=dict)
    
    llm_h_class = attrs.field(default = None)
    llm_h = attrs.field(default = None)
    _id_counter = 0


    def __attrs_post_init__(self):

        if self.llm_h_type == "ollama":
            self.llm_h_class = OllamaHandlerAsync
        if self.llm_h_type == "openai":
            self.llm_h_class = OpenAIHandlerAsync

        self._initialize_llm_h()

    def _initialize_llm_h(self):

        if self.llm_h is None:
            params = dict(self.llm_h_params) if self.llm_h_params else {}
            self.llm_h = self.llm_h_class(**params)

    @classmethod
    def _gen_id(cls) -> int:
        cls._id_counter += 1
        return cls._id_counter


    async def chat(self, 
                   messages: List[Dict[str, str]], 
                   model_name: Optional[str] = None) -> LlmHandlerChatOutput:
        """
        Core chat method.
        """
        uid = self._gen_id()
        input_messages = [LlmMessage(**d) for d in messages]
        self.logger.debug(f"-> {uid}", 
            save_vars = ["input_messages"])
        try:

            response = await self.llm_h.chat(
                messages = messages,
                model_name = model_name)

        except (RuntimeError, ValueError, TypeError) as e:
            response = None
            self.logger.error(f"LLM Handler Error: {e}")

        self.logger.debug(f"<- {uid}", 
            save_vars = ["response.message"],
            actions = [
                {
                    "name" : "langfuse.log_trace",
                    "params" : {
                        "input" : input_messages,
                        "output" : response.message
                    }
                }
            ]
        )

        return response

    def get_backend(self):
        """Return the initialized LLM backend handler."""
        return self.llm_h

class LlmFunctionItemInput(BaseModel):

    """
    Function suitable for llm use.
    """

    func: SkipValidation[Callable[..., Any]]
    input_model: Optional[Type[BaseModel]] = Field(
        default=None,
        description="Optional input model for function, if cannot be derived from func definition.",
    )
    output_model: Optional[Type[BaseModel]] = Field(
        default=None,
        description="Optional output model for function, if cannot be derived from func definition.",
    )

    model_config = {
        "arbitrary_types_allowed": True
    }

class LlmFunctionItem(BaseModel):

    """
    Function suitable for llm use.
    """

    func_id : str
    name : str
    description : str
    input_schema_json : dict
    output_schema_json : dict

class WorkflowErrorType(Enum):
    """Known workflow error categories."""

    CHECK_JSON = "check_json"
    PLANNING_JSON = "planning_json"
    PLANNING_MISSOUTPUT = "planning_missoutput"
    PLANNING_OUTPUT_MODEL = "planning_output_model"
    PLANNING_HF = "planning_hf"
    PLANNING_RESET = "planning_reset"
    ADAPTOR_JSON = "adaptor_json"
    RUNNER = "runner"
    INPUTS = "inputs"
    OUTPUTS_FAILURE = "outputs_failure"
    OUTPUTS_UNEXPECTED = "outputs_unexpected"

class WorkflowError(BaseModel):
    """Structured error for planning/adaptation/run steps."""

    error_message: Optional[str] = Field(default=None, description = "Error message if function call fails.")
    error_type: Optional[WorkflowErrorType] = Field(default=None, description = "Error type of failed call.")
    additional_info: Optional[dict] = Field(default={}, description = "Optional additional info for the error.")

    model_config = {
        "arbitrary_types_allowed": True
    }

def _hash_string_sha256(input_string: str) -> str:
    """Return SHA-256 hash hex digest for a string."""
    return hashlib.sha256(input_string.encode()).hexdigest()

def make_uid(d: dict) -> str:
    """Return a stable SHA-256 uid for a dictionary."""
    input_string = json.dumps(d)

    return _hash_string_sha256(input_string)

def create_function_item(
    func: callable,
    input_model: Type[BaseModel] = None,
    output_model: Type[BaseModel] = None,
) -> dict:
    """
    Constructs a structured function item that includes:
      - function name (extracted from the actual function's __name__)
      - function description (extracted from the function's __doc__)
      - JSON schema for the input model
      - JSON schema for the output model

    Parameters:
      func: The actual function (callable) object.
      input_model: The Pydantic model class representing the function's input schema.
      output_model: The Pydantic model class representing the function's output schema.

    Returns:
      LlmFunctionItem with:
        - "func_id" : unique id of the function
        - "name": the function's name.
        - "description": the function's description (docstring).
        - "input_schema_json": the JSON schema (as a dict) for the input model.
        - "output_schema_json": the JSON schema (as a dict) for the output model.
    """

    if input_model is None or output_model is None:
        hints = get_type_hints(func)

    if input_model is None:
        input_model = hints.get("inputs")

    if output_model is None:
        output_model = hints.get("return")

    llm_func_item = {
        "name": func.__name__,
        "description": func.__doc__.strip() if func.__doc__ else "",
        "input_schema_json": input_model.model_json_schema(),
        "output_schema_json": output_model.model_json_schema(),
    }

    return LlmFunctionItem(
        func_id=make_uid(d={**llm_func_item, "code": inspect.getsource(func)}),
        **llm_func_item
    )

def _fill_hints(fi):
    """Fill missing input/output models using function type hints."""
    hints = get_type_hints(fi.func)
    fi.input_model = fi.input_model or hints.get("inputs")
    fi.output_model = fi.output_model or hints.get("return")
    return fi

def create_avc_items(functions : List[LlmFunctionItemInput]):

    """
    Creates available functions and callables for Workflow Auto Assembler.
    """

    functions_after_hints = [_fill_hints(fi) for fi in functions]

    llm_func_items = [
        {
            "name": fi.func.__name__,
            "description": fi.func.__doc__.strip() if fi.func.__doc__ else "",
            "input_schema_json": fi.input_model.model_json_schema(),
            "output_schema_json": fi.output_model.model_json_schema(),
            "code": inspect.getsource(fi.func),
        }
        for fi in functions_after_hints
    ]

    available_functions = [
        LlmFunctionItem(
            func_id=make_uid(d=llm_func_item),
            **{k: v for k, v in llm_func_item.items() if k != "code"}
        )
        for llm_func_item in llm_func_items
    ]

    available_callables = {
        make_uid(d=llm_func_item): fi.func
        for llm_func_item, fi in zip(llm_func_items, functions)
    }

    return {
        "available_functions": available_functions,
        "available_callables": available_callables,
    }

@attrs.define(kw_only=True)
class LlmHandlerMock(ABC):

    @abstractmethod
    async def chat(self, messages: List[Dict[str, str]],  *args, **kwargs):

        """
        Abstract chat method for async chat method that passes messages to llm.
        """

        pass

@attrs.define(kw_only=True)
class InputCollectorMock(ABC):

    @abstractmethod
    def fix_literal_values(self, planned_workflow : dict, adapted_workflow : dict,  *args, **kwargs):

        """
        Abstract method for fixing literal values in adapted workflow if necessary.
        """

        pass

class WorkflowAdaptorStep(BaseModel):

    step_id : int = Field(description = "Step id.")
    func_name : str = Field(description = "Function name used in the step.")
    retries : int = Field(description = "Number of attempt it took to generate workflow.")
    init_messages : List[dict] = Field(default = None, description = "Initial messages for adapting workflow.")
    additional_messages : List[dict] = Field(default = None, description = "Additional messages for planning workflow.")
    errors : List[BaseModel] = Field(description = "Errors during planning.")
    adapted_schema : Optional[dict] = Field(default = None, description = "Planned workflow.")
    state_schema: Optional[dict] = Field(default = None, description = "Schema of steps before this one in the workflow.")
    target_schema : Optional[dict] = Field(default = None,description = "Target schema from available functions.")

    model_config = {
        "arbitrary_types_allowed": True
    }

class WorkflowAdaptorResponse(BaseModel):

    total_retries : int = Field(description = "Number of attempt it took to adapt workflow.")
    planned_workflow : Optional[List[dict]] = Field(default = None, description = "Planned workflow.")
    workflow : Optional[List[dict]] = Field(default = None, description = "Adapted workflow.")
    all_errors : List[BaseModel] = Field(description = "Errors during planning.")
    steps : List[WorkflowAdaptorStep] = Field(description = "Steps it took to adapt workflow.")
    include_input : bool = Field(description = "If input model is expected.")
    include_output : bool = Field(description = "If output model is expected.")

    model_config = {
        "arbitrary_types_allowed": True
    }

@attrsx.define(handler_specs = {"llm" : LlmHandlerMock, "input_collector" : InputCollectorMock})
class WorkflowAdaptor:

    workflow_error_types = attrs.field()
    workflow_error = attrs.field()

    system_message : str = attrs.field(default=None)
    system_message_items : Dict[str, str] = attrs.field(default=None)
    debug_prompts : Dict[str,str] = attrs.field(default=None)
    adapt_prompt : str = attrs.field(default=None)
    
    prompts_filepath : str = attrs.field(default=None)
    available_functions : List[Any] = attrs.field(default=None)
    llm_function_item_class = attrs.field(default=None)

    max_retry : int = attrs.field(default=5)

    """
    Adapts initially planned workflows
    """

    def __attrs_post_init__(self):

        self._assign_prompts()
        self._initialize_input_collector_h()

    def _assign_prompts(self, 
        prompts_filepath : str = None,
        system_message : str = None, 
        system_message_items : Dict[str,str] = None,
        debug_prompts : Dict[str,str] = None,
        adapt_prompt : str = None
        ):

        if prompts_filepath is None: 
            prompts_filepath = self.prompts_filepath

        wa_path = pkg_resources.files('workflow_auto_assembler')

        if 'artifacts' in os.listdir(wa_path):

            if prompts_filepath is None:

                with pkg_resources.path('workflow_auto_assembler.artifacts.prompts',
                'workflow_adaptor.yml') as path:
                    prompts_filepath = path

            with open(prompts_filepath, 'r') as f:
                wa_prompts = yaml.safe_load(f)


        if system_message: 
            self.system_message = system_message
        else:
            self.system_message = wa_prompts['system_message']

        if system_message_items:
            self.system_message_items = system_message_items
        else:
            self.system_message_items = wa_prompts.get("system_message_items", {})

        if debug_prompts: 
            self.debug_prompts = debug_prompts
        else:
            self.debug_prompts = wa_prompts['debug_prompts']

        if adapt_prompt: 
            self.adapt_prompt = adapt_prompt
        else:
            self.adapt_prompt = wa_prompts['adapt_prompt']

    def _read_json_output(self, output : str) -> list | dict | None:

        try:

            if "```json" in output:
                output = output.replace("```json", "").replace("```", "")

            function_calls = json.loads(output)
        except Exception as e:
            self.logger.error(f"Failed to extract json from {output}")
            self.logger.error(f"Problem with JSON: {e}")
            return None

        return function_calls

    def _make_current_state_schema(self, 
        workflow : list, 
        available_functions : List[Any], 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        func_name : str = None):

        base_state_schema = {}

        if input_model:
            base_state_schema['input_model'] = input_model.model_json_schema()

        if func_name is None:

            current_state_schema = {wd['name'] : [ad.output_schema_json \
                for ad in available_functions \
                    if ad.name == wd['name']][0] for wd in workflow}

            base_state_schema.update(current_state_schema)

            if output_model:
                base_state_schema['output_model']: output_model.model_json_schema()

            return base_state_schema
        else:
            current_state_schema = {}

            for step in workflow:

                if step['name'] == "input_model":
                    continue

                if step['name'] != func_name:
                    current_state_schema[step['name']] = [ad.output_schema_json \
                        for ad in available_functions \
                            if ad.name == step['name']][0]
                else:
                    break

            base_state_schema.update(current_state_schema)

            if output_model:
                base_state_schema['output_model']: output_model.model_json_schema()

            return base_state_schema

    def _resolve_ref(self, schema: Dict[str, Any], defs: Dict[str, Any]) -> Dict[str, Any]:
        """
        If the schema contains a $ref, resolve it using the provided defs dictionary.
        This function assumes that $ref is of the form "#/$defs/SomeDefinition".
        """
        if "$ref" in schema:
            ref = schema["$ref"]
            parts = ref.split("/")
            if len(parts) >= 3 and parts[1] == "$defs":
                ref_key = parts[2]
                if ref_key in defs:
                    # Recursively resolve in case the referenced definition has further $ref
                    return self._resolve_ref(defs[ref_key], defs)
        return schema

    def _check_reference(self, 
        reference: str, 
        target_field_schema: Dict[str, Any], 
        state: Dict[str, Dict[str, Any]], 
        id_func_mapping : Dict[str, str],
        current_function: str) -> List[str]:
        """
        Validate that a reference string is valid.
        
        A valid reference must have the exact format:
        <function_name>.output.<field_name>
        
        Additionally, the reference should not point to the output of the same function (self-reference).
        
        This function resolves the target_field_schema if it contains a $ref.
        
        Returns a list of error messages. If the list is empty, the reference is valid.
        """
        reference_errors = []
        
        # Extra check: disallow prefixes like "source:" or "string:".
        if reference.startswith("source:") or reference.startswith("string:"):
            reference_errors.append(f"Reference '{reference}' should not include a prefix like 'source:' or 'string:'.")
            return reference_errors

        pattern = r"^(?P<func_id>[^.]+)\.output\.(?P<field_name>[^.]+)$"
        match = re.fullmatch(pattern, reference)
        
        if not match:
            reference_errors.append(f"Invalid reference format: {reference}")
            return reference_errors
        
        func_name = id_func_mapping.get(match.group("func_id"), "")
        field_name = match.group("field_name")
        
        if func_name == current_function:
            reference_errors.append(f"Invalid self-reference: Function '{current_function}' should not reference its own output.")
            return reference_errors
        
        if func_name not in state:
            reference_errors.append(f"Function '{func_name}' not found in state for reference {reference}.")
            return reference_errors
        
        output_schema = state[func_name]
        properties = output_schema.get("properties", {})
        if field_name not in properties:
            reference_errors.append(f"Field '{field_name}' not found in output schema of '{func_name}' for reference {reference}.")
            return reference_errors
        
        source_type = properties[field_name].get("type")
        # Resolve any $ref in the target field schema
        target_field_schema = self._resolve_ref(target_field_schema, target_field_schema.get("$defs", {}))
        target_type = target_field_schema.get("type")
        if source_type != target_type:
            reference_errors.append(f"Type mismatch in reference '{reference}': expected target type '{target_type}', got source type '{source_type}'.")
            return reference_errors
        
        return reference_errors

    def _check_complex_mapping(self, 
        mapping: Any, 
        target_schema: Dict[str, Any],
        state: Dict[str, Dict[str, Any]], 
        id_func_mapping : Dict[str,str],
        current_function: str) -> List[str]:
        """
        Recursively validate a mapping object against the target JSON schema (which may include $ref)
        and available state.
        
        Parameters:
        mapping: The mapping object (literal, reference string, dict, or list).
        target_schema: The JSON schema (as produced by .model_json_schema()).
        state: A dictionary mapping function names to their output JSON schemas.
        current_function: The name of the current function (to check for self-references).
        
        Returns:
        A list of error messages. An empty list indicates the mapping is valid.
        """
        defs = target_schema.get("$defs", {})
        # Resolve $ref in the current schema node, if any.
        schema = self._resolve_ref(target_schema, defs)

        def _check(mapping: Any, schema: Dict[str, Any]) -> List[str]:
            # Resolve references in this schema node
            schema = self._resolve_ref(schema, defs)
            errors: List[str] = []
            
            if isinstance(mapping, str):
                # If the string contains '.output.', it is expected to be a reference.
                if ".output." in mapping:
                    errors.extend(self._check_reference(
                        reference = mapping, 
                        target_field_schema = schema, 
                        state = state,
                        id_func_mapping = id_func_mapping,
                        current_function = current_function))
                    return errors
                else:
                    # For a literal value, we can (optionally) enforce that the schema type is string.
                    if schema.get("type") == "string":
                        return []
                    # Otherwise, if literal value is provided where an object is expected, it's an error.
                    errors.append(f"Expected an object mapping (or valid reference), but got literal '{mapping}'.")
                    return errors

            if isinstance(mapping, dict):
                # If the schema expects a literal string but we got a dict, that's an error.
                if schema.get("type") == "string":
                    errors.append(f"Expected a literal string, but got an object: {mapping}")
                    return errors
                if schema.get("type") != "object":
                    errors.append("Expected an object mapping, but target schema is not an object.")
                    return errors
                target_properties = schema.get("properties", {})
                # Check required keys
                required_keys = schema.get("required", [])
                for req_key in required_keys:
                    if req_key not in mapping:
                        errors.append(f"Missing required key '{req_key}' in mapping.")
                for key, value in mapping.items():
                    if key not in target_properties:
                        errors.append(f"Key '{key}' not found in target schema properties.")
                        continue
                    child_errors = _check(value, target_properties[key])
                    if child_errors:
                        errors.extend(child_errors)
                        errors.append(f"Mapping for key '{key}' is invalid.")
                return errors

            if isinstance(mapping, list):
                if schema.get("type") != "array":
                    errors.append("Expected an array mapping, but target schema is not an array.")
                    return errors
                item_schema = schema.get("items")
                for idx, item in enumerate(mapping):
                    child_errors = _check(item, item_schema)
                    if child_errors:
                        errors.extend(child_errors)
                        errors.append(f"Mapping for array item at index {idx} is invalid.")
                return errors

            errors.append(f"Unexpected mapping type: {type(mapping)}")
            return errors

        return _check(mapping, schema)


    def _prep_init_messages(self,
        func_name : str, 
        workflow : dict,
        workflow_current_state_schema : dict,
        available_functions : list,
        id_func_mapping : Dict[str,str],):

        selected_function_input_schema, selected_function_input_schema_pyd = [
                (af.input_schema_json, self.json_schema_to_base_model(af.input_schema_json)) for af in available_functions if af.name == func_name][0]

        system_message_items = {
                "purpose_description" : "",
                "generated_workflow" : "",
                "workflow_current_state" : "",
                "expected_output_schema" : ""
            }

        if self.system_message_items.get("purpose_description"):
            system_message_items["purpose_description"] = self.system_message_items.get("purpose_description")

        if self.system_message_items.get("generated_workflow"):
            system_message_items["generated_workflow"] = self.system_message_items.get("generated_workflow").format(
                raw_workflow = json.dumps(workflow))

        if self.system_message_items.get("workflow_current_state"):
            system_message_items["workflow_current_state"] = self.system_message_items.get("workflow_current_state").format(
                workflow_current_state = json.dumps(workflow_current_state_schema))

        if self.system_message_items.get("expected_output_schema"):
            system_message_items["expected_output_schema"] = self.system_message_items.get("expected_output_schema")

        adapt_message_items = {
            "selected_function_name" : func_name,
            "selected_function_input_schema" : json.dumps(selected_function_input_schema)
        }

        messages = [
            {"role": "system", "content": self.system_message.format(
                **system_message_items)},
            {"role": "user", "content": self.adapt_prompt.format(
                **adapt_message_items)}
        ]

        return messages, selected_function_input_schema

    def _check_llm_response(self,
        llm_response : str, 
        step_id : str,
        target_schema : dict, 
        state : dict, 
        id_func_mapping : Dict[str,str],
        current_function : str,
        init_error : Optional[Type[BaseModel]] = None):

        if init_error:
            return init_error

        function_calls = self._read_json_output(output=llm_response)

        if function_calls is None:
            return self.workflow_error(
                error_type = self.workflow_error_types.ADAPTOR_JSON,
                additional_info = {
                    "step_id" : step_id,
                    "error_messages" : ['Provided output is not json!']})

        if isinstance(function_calls, list):
            matched = None
            for item in function_calls:
                if not isinstance(item, dict):
                    continue
                item_id = item.get("id")
                if item_id is not None and str(item_id) == str(step_id):
                    matched = item
                    break
                if item.get("name") == current_function:
                    matched = item
            if matched is None or not isinstance(matched.get("args"), dict):
                return self.workflow_error(
                    error_type = self.workflow_error_types.ADAPTOR_JSON,
                    additional_info = {
                        "step_id" : step_id,
                        "error_messages" : ["Provided output is a workflow list but no matching step args were found."]})
            function_calls = matched.get("args")

        # Reject null or empty mappings when required fields exist.
        required_fields = target_schema.get("required", []) if isinstance(target_schema, dict) else []
        if required_fields:
            if function_calls is None:
                return self.workflow_error(
                    error_type = self.workflow_error_types.ADAPTOR_JSON,
                    additional_info = {
                        "step_id" : step_id,
                        "error_messages" : ["Mapping is null but required fields exist: " + ", ".join(required_fields)]
                    }
                )
            if isinstance(function_calls, dict):
                missing = [f for f in required_fields if f not in function_calls]
                if missing:
                    return self.workflow_error(
                        error_type = self.workflow_error_types.ADAPTOR_JSON,
                        additional_info = {
                            "step_id" : step_id,
                            "error_messages" : ["Missing required fields: " + ", ".join(missing)]
                        }
                    )

        try:
            mapping_errors = self._check_complex_mapping(
                mapping = function_calls, 
                target_schema = target_schema, 
                state = state, 
                id_func_mapping = id_func_mapping,
                current_function=current_function)

            if mapping_errors:
                return self.workflow_error(
                    error_type = self.workflow_error_types.ADAPTOR_JSON,
                    additional_info = {
                        "step_id" : step_id,
                        "error_messages" : [erm for erm in mapping_errors]})

        except Exception as e:
            return self.workflow_error(
                error_type = self.workflow_error_types.ADAPTOR_JSON,
                additional_info = {
                    "step_id" : step_id,
                    "error_messages" : [str(e)]})

        return None

    async def _adapt_func(self,
        func_name : str = None, 
        step_id : str = None,
        workflow : dict = None,
        workflow_current_state_schema : dict = None,
        available_functions : list = None,
        id_func_mapping : Dict[str,str] = None,
        adapted_step = None,
        max_retry : int = 5):
        
        if workflow_current_state_schema != {}:
                
            if adapted_step is None :

                workflow = workflow.copy()

                init_messages, target_schema = self._prep_init_messages(
                    func_name = func_name, 
                    workflow = workflow,
                    workflow_current_state_schema = workflow_current_state_schema,
                    available_functions = available_functions,
                    id_func_mapping = id_func_mapping
                )
                
                retry_i = 0
                not_json_output = True
                errors = []
                init_error = None

                response = await self.llm_h.chat(init_messages)
                llm_response = response.message.content
                additional_messages = [{'role' : 'assistant', "content" : llm_response}]
            else:
                step_id = adapted_step.step_id
                init_messages = adapted_step.init_messages
                additional_messages = adapted_step.additional_messages
                llm_response = json.dumps(additional_messages[-1].get("content", {}))
                retry_i = adapted_step.retries
                errors = adapted_step.errors
                init_error = errors[-1]
                target_schema = adapted_step.target_schema
                func_name = adapted_step.func_name


            while retry_i < max_retry:

                error = self._check_llm_response(
                    llm_response=llm_response,
                    step_id=step_id, 
                    target_schema = target_schema,
                    state=workflow_current_state_schema,
                    id_func_mapping=id_func_mapping,
                    current_function=func_name,
                    init_error=init_error)

                if error is None:
                    adapted_schema = self._read_json_output(output=llm_response)
                    if isinstance(adapted_schema, list):
                        matched = None
                        for item in adapted_schema:
                            if not isinstance(item, dict):
                                continue
                            item_id = item.get("id")
                            if item_id is not None and str(item_id) == str(step_id):
                                matched = item
                                break
                            if item.get("name") == func_name:
                                matched = item
                        if matched and isinstance(matched.get("args"), dict):
                            adapted_schema = matched.get("args")
                    return WorkflowAdaptorStep(
                        step_id = step_id,
                        func_name = func_name,
                        errors = errors,
                        adapted_schema = adapted_schema,
                        state_schema = workflow_current_state_schema,
                        target_schema = target_schema,
                        retries = retry_i,
                        init_messages = init_messages,
                        additional_messages = additional_messages
                    )

                retry_i += 1
                if init_error:
                    init_error = None
                else:
                    errors.append(error)

                self.logger.debug(f"Reset caused by {error.error_type.name} type error!",
                    label = error.error_type.name)
                self.logger.debug(f"Attempt for {func_name}: {retry_i}")

                if error.error_type in [self.workflow_error_types.OUTPUTS_FAILURE, self.workflow_error_types.ADAPTOR_JSON]:

                    error_messages = []
                    if error.additional_info and isinstance(error.additional_info, dict):
                        error_messages = error.additional_info.get("error_messages") or []
                    if not isinstance(error_messages, list):
                        error_messages = [str(error_messages)]
                    if not error_messages:
                        error_messages = [str(error)]
                    mapping_errors = "\n ".join(iter(error_messages))

                    additional_messages += [
                        # {"role": "assistant", "content": llm_response},
                        {"role": "user", "content": self.debug_prompts["mapping"].format(
                    mapping_errors = mapping_errors)}
                    ]
                    retry_messages = init_messages + additional_messages 

                    debug_response = await self.llm_h.chat(retry_messages)
                    llm_response = debug_response.message.content
                    additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                    continue

                if error.error_type is self.workflow_error_types.OUTPUTS_UNEXPECTED:

                    differences = error.additional_info.get("differences", [])

                    if differences:

                        difference_errors = json.dumps(differences)

                        additional_messages += [
                            # {"role": "assistant", "content": llm_response},
                            {"role": "user", "content": self.debug_prompts["unexpected"].format(
                        differences = difference_errors)}
                        ]
                        retry_messages = init_messages + additional_messages 

                        debug_response = await self.llm_h.chat(retry_messages)
                        llm_response = debug_response.message.content
                        additional_messages += [{'role' : 'assistant', "content" : llm_response}]
                        continue
            
        else:
            return WorkflowAdaptorStep(
                step_id = step_id,
                func_name = func_name,
                errors = [],
                adapted_schema = workflow[0]['args'],
                state_schema = workflow_current_state_schema,
                retries = 0,
                target_schema = {},
                init_messages = []
            )


        
        return WorkflowAdaptorStep(
            step_id = step_id,
            func_name = func_name,
            errors = errors,
            adapted_schema = None,
            state_schema = None,
            retries = retry_i,
            target_schema = target_schema,
            init_messages = init_messages,
            additional_messages = additional_messages
        )

    def _hash_string_sha256(self, input_string: str) -> str:
        return hashlib.sha256(input_string.encode()).hexdigest()

    def _make_uid(self, d: dict) -> str:

        input_string = json.dumps(d)

        return self._hash_string_sha256(input_string)
    
    def _mod_inputs_for_output_model(self, 
        workflow : List[dict],
        output_model : Type[BaseModel],
        available_functions : List[Any],
        ):

        workflow_s = workflow
        available_functions_t = available_functions
        if output_model:
            workflow_s += [{'id': len(workflow) + 1 , 'name': 'output_model'}]
            output_item = {
                "name" : "output_model", 
                "description" : "Schema to which relevant workflow outputs should be connected to.",
                "input_schema_json" : output_model.model_json_schema(),
                "output_schema_json" : output_model.model_json_schema(),
            }
            item_class = self.llm_function_item_class
            if item_class is None and available_functions:
                item_class = type(available_functions[0])
            if item_class is None:
                raise ValueError("llm_function_item_class is required to add output_model.")
            available_functions_t += [item_class(
                func_id = self._make_uid(d = output_item),
                **output_item
                )]

        return workflow_s, available_functions_t


    def _add_fcall_ids(self, 
            workflow: dict,
            input_model : Type[BaseModel] = None,
            output_model : Type[BaseModel] = None) -> dict:

        wf_base = []
        id_func_mapping_base = {"0" : "input_model"}

        if input_model:
            wf_base.append({"id" : 0, "name" : "input_model"})

        wf = wf_base + [{"id" : idx + 1, **d} for idx, d in enumerate(workflow)]
        id_func_mapping_u = {str(idx + 1) : d['name'] for idx, d in enumerate(workflow)}
        id_func_mapping_base.update(id_func_mapping_u)

        # if output_model:
        #     id_func_mapping_base.update({str(len(wf)) : "output_model"})
        #     wf.append({"id" : len(wf), "name" : "output_model"})

        return wf, id_func_mapping_base

    def json_schema_to_base_model(self, schema: dict) -> Dict[str, BaseModel]:
        """Build Pydantic models from a JSON schema with $defs and $ref."""

        type_mapping = {
            "string": str,
            "number": float,
            "integer": int,
            "boolean": bool,
            "object": dict,
            "array": list,
        }

        defs = {}

        # build inline nested models
        for def_name, def_schema in schema.get("$defs", {}).items():
            fields = {}
            for name, prop in def_schema["properties"].items():
                py_type = type_mapping.get(prop.get("type", "string"), Any)
                default = ... if name in def_schema.get("required", []) else prop.get("default", None)
                if default is None and name not in def_schema.get("required", []):
                    py_type = Optional[py_type]

                fields[name] = (
                    py_type,
                    Field(default, title=prop.get("title"), description=prop.get("description"))
                )
            defs[def_name] = create_model(def_schema["title"], **fields)

        # now build the top-level model
        fields = {}
        for name, prop in schema["properties"].items():
            if "$ref" in prop.get("items", {}):  # array of nested objects
                ref_name = prop["items"]["$ref"].split("/")[-1]
                py_type = List[defs[ref_name]]
                default = ... if name in schema.get("required", []) else None
            else:
                py_type = type_mapping.get(prop.get("type", "string"), Any)
                default = ... if name in schema.get("required", []) else prop.get("default", None)
                if default is None and name not in schema.get("required", []):
                    py_type = Optional[py_type]

            fields[name] = (
                py_type,
                Field(default, title=prop.get("title"), description=prop.get("description"))
            )

        return create_model(schema["title"], **fields)

    async def _adapt_steps(self, 
        workflow : List[dict],
        available_functions : List[Any],
        input_model : Type[BaseModel],
        output_model : Type[BaseModel],
        max_retry : Optional[int]):

        include_input = False
        include_output = False
        if input_model:
            include_input = True
        if output_model:
            include_output = True

        id_workflow, id_func_mapping = self._add_fcall_ids(
                workflow=workflow,
                input_model=input_model,
                output_model=output_model)

        workflow_s, available_functions_t = self._mod_inputs_for_output_model(
            workflow=workflow,
            available_functions=available_functions,
            output_model=output_model
        )
            
        workflow_current_state_schema = {step['name'] : self._make_current_state_schema(
            workflow = id_workflow, 
            available_functions = available_functions, 
            input_model = input_model,
            output_model=output_model,
            func_name = step['name']
        ) for step in workflow_s}

        self.logger.debug("Adapting all steps!")

        # Create a list of tasks for each workflow step using adapt_func.
        adapt_tasks = [self._adapt_func(
            step_id = step["id"],
            func_name = step['name'],
            workflow = id_workflow,
            workflow_current_state_schema = workflow_current_state_schema[step['name']],
            available_functions = available_functions_t,
            id_func_mapping = id_func_mapping,
            max_retry = max_retry) for step in id_workflow if step["name"] != "input_model"]
        
        # Wait for all tasks to complete and gather their results.
        adapted_steps = await asyncio.gather(*adapt_tasks)

        self.logger.debug("All steps were initially adapted!")


        adapted_workflow = [{
            "id" : adapted_step.step_id, 
            "func_id" : [av.func_id for av in available_functions_t if av.name == adapted_step.func_name][0],
            'name' : adapted_step.func_name, 
            'args': adapted_step.adapted_schema} \
        for adapted_step in adapted_steps]

        adapted_fixed_workflow = self.input_collector_h.fix_literal_values(workflow, adapted_workflow)

        return WorkflowAdaptorResponse(
            total_retries = sum([adapted_step.retries for adapted_step in adapted_steps]),
            planned_workflow = id_workflow,
            workflow = adapted_fixed_workflow,
            all_errors = [err for adapted_step in adapted_steps for err in adapted_step.errors],
            steps = adapted_steps,
            include_input = include_input,
            include_output = include_output
        )

    async def _reset_step_based_on_error(self, 
        error,
        adapted_workflow : Optional[WorkflowAdaptorResponse],
        max_retry : Optional[int]
        ):


        self.logger.debug(f"Reset caused by {error.error_type.name} type error!",
            label = error.error_type.name)

        # For OUTPUTS_UNEXPECTED, prefer re-adapting output_model mapping first.
        if error.error_type is self.workflow_error_types.OUTPUTS_UNEXPECTED:
            output_steps = [step for step in adapted_workflow.workflow if step.get("name") == "output_model"]
            if output_steps:
                retried_step_id = output_steps[-1].get("id")
            else:
                retried_step_id = None
        else:
            retried_step_id = None

        if retried_step_id is None and adapted_workflow.all_errors and adapted_workflow.all_errors[-1].additional_info:
            retried_step_id = adapted_workflow.all_errors[-1].additional_info.get("step_id")
            if retried_step_id is None:
                retried_step_ids = adapted_workflow.all_errors[-1].additional_info.get("failing_step_ids")
                if retried_step_ids:
                    retried_step_id = retried_step_ids[0]

        if retried_step_id is None:
            raise ValueError("Cannot reset step: missing step_id in error additional_info.")
        retried_step = [step for step in adapted_workflow.workflow if step["id"] == retried_step_id][0]
        retried_step_obj = [step_obj for step_obj in adapted_workflow.steps if step_obj.step_id == retried_step_id][0]

        id_func_mapping = {}

        if adapted_workflow.include_input:
            id_func_mapping["0"] = "input_model"
        
        id_func_mapping_u = {str(step_obj.step_id) : step_obj.func_name for step_obj in adapted_workflow.steps}
        id_func_mapping.update(id_func_mapping_u)

        retried_step_obj.errors.append(error)

        reset_step = await self._adapt_func(
            id_func_mapping = id_func_mapping,
            workflow_current_state_schema = retried_step_obj.state_schema,
            adapted_step = retried_step_obj,
            max_retry = max_retry)

        adapted_workflow.total_retries += reset_step.retries
        adapted_workflow.all_errors += reset_step.errors

        reset_step.errors = retried_step_obj.errors + reset_step.errors
        reset_step.retries += retried_step_obj.retries
        
        adapted_workflow.steps = [reset_step \
            if step.step_id == retried_step_id else step \
            for step in adapted_workflow.steps]

        adapted_workflow.workflow = [{
            'id': wstep['id'], 
            'func_id' : wstep['func_id'],
            'name' : wstep['name'], 
            'args' : reset_step.adapted_schema} if wstep['id'] == retried_step_id else wstep \
            for wstep in adapted_workflow.workflow]

        return adapted_workflow
    
    async def adapt_workflow(
        self,
        workflow : List[dict] = None,
        available_functions : List[Any] = None,
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        max_retry : Optional[int] = None,
        adapted_workflow : Optional[WorkflowAdaptorResponse] = None):

        """
        Adapts input and output models of planned workflow.
        """

        if max_retry is None:
            max_retry = self.max_retry

        if available_functions is None:
            available_functions = self.available_functions

        if available_functions is None:
            raise ValueError("Input available_functions cannot be None!")

        if adapted_workflow is None and workflow is None:
            self.logger.warning("No workflow was provided to adapt!")
            return None

        if adapted_workflow is None and workflow:

            workflow = workflow.copy()

            adapted_workflow = await self._adapt_steps(
                workflow=workflow,
                input_model=input_model,
                output_model=output_model,
                available_functions=available_functions,
                max_retry=max_retry
            )

            return adapted_workflow

        else:

            if adapted_workflow.all_errors:

                adapted_workflow = await self._reset_step_based_on_error(
                    error = adapted_workflow.all_errors[-1],
                    adapted_workflow = adapted_workflow,
                    max_retry = max_retry
                )

            return adapted_workflow

__package_metadata__ = {
    "author": "Kyrylo Mordan",
    "author_email": "parachute.repo@gmail.com",
    "description": "Experimental schema-first workflow synthesis tool for assembling simple typed workflows from existing functions.",
}

class PlanningStepsResp(BaseModel):
    planner : Optional[WorkflowPlannerResponse] = Field(default = None, description = "Planning steps of workflow creation.")
    planner_iters : Optional[List[WorkflowPlannerResponse]] = Field(default = [], description = "Snapshot of planning steps of workflow creation at each reset.")
    adaptor : Optional[WorkflowAdaptorResponse] = Field(default = None, description = "Adapting steps of workflow creation.")
    adaptor_iters : Optional[List[WorkflowAdaptorResponse]] = Field(default = [], description = "Snapshot of adapting steps of workflow creation at each reset.")
    tester : Optional[TestedWorkflow | TestedWorkflowBatch] = Field(default = None, description = "Testing step of workflow creation.") 
    planner_rerun_needed : Optional[bool] = Field(default = True, description = "Indicates if planner needs reset during retry.")
    adaptor_rerun_needed : Optional[bool] = Field(default = True, description = "Indicates if adaptor needs reset during retry.")
    testing_errors : Optional[List[WorkflowError]] = Field(default = [], description = "Errors during testing workflow.")
    test_retries : int = Field(default = 0, description = "Retries completed during planning and testing loop.")

class WorkflowDescription(BaseModel):
    task_description : Optional[str] = Field(default = None, description="Description of the workflow.")
    input_model_json : Optional[dict] = Field(default = None, description="Input model for workflow.")
    output_model_json : Optional[dict] = Field(default = None, description="Output model for workflow.")

class AssembledWorkflow(BaseModel):
    id : str = Field(description = "Unique id for task based on hash of inputs")
    input_id : str = Field(description = "Unique id for task inputs based on hash of inputs")
    init_check : Optional[WorkflowCheckResponse] = Field(default = None, description = "Initial check.")
    planning : Optional[PlanningStepsResp] = Field(default = PlanningStepsResp(), description = "Responses from planning steps.")
    workflow_possible : Optional[bool] = Field(default = None, description = "Indicates if workflow could be planned given provided tools.")
    workflow_completed : Optional[bool] = Field(default = False, description = "Indicates if workflow was completed in the preset amount of retries.")
    workflow : Optional[dict] = Field(default = None, description = "Planned and tested workflow.")
    description : Optional[WorkflowDescription] = Field(default = WorkflowDescription(), description = "Workflow description.")
    loops : Optional[int] = Field(default = 1, description = "Retries completed during planning and testing loop.")

@attrsx.define(handler_specs = {
        #"shouter" : Shouter,
        "llm_handler" : LlmHandler,
        "check" : WorkflowCheck,
        "planner" : WorkflowPlanner,
        "adaptor" : WorkflowAdaptor,
        "runner" : WorkflowRunner,
        "input_collector" : InputCollector,
        "output_comparer" : OutputComparer
    },
    logger_chaining={
        #'loggerLvl' : True
        'logger' : True
        })
class WorkflowAutoAssembler:

    workflow_error_types = attrs.field(default=WorkflowErrorType)
    workflow_error = attrs.field(default=WorkflowError)

    available_functions: List[LlmFunctionItem] = attrs.field(
        default=None,
        converter=lambda v: None if v is None else deepcopy(v),
    )
    available_callables: Dict[str, Callable] = attrs.field(
        default=None,
        converter=lambda v: None if v is None else dict(v),
    )

    max_output_unexpected : int = attrs.field(default=3)
    max_retry : int = attrs.field(default=10)
    reset_loops : int = attrs.field(default=2)

    def __attrs_post_init__(self):

        self._initialize_input_collector_h()
        
        self._initialize_output_comparer_h()
        self._initialize_llm_handler_h()
        self._initialize_planner_h(uparams = {
            "llm_h" : self.llm_handler_h,
            "available_functions" : self.available_functions,
            "workflow_error_types" : self.workflow_error_types,
            "workflow_error" : self.workflow_error,
            "max_retry" : self.max_retry
        })
        self._initialize_adaptor_h(uparams = {
            "llm_h" : self.llm_handler_h,
            "input_collector_h" : self.input_collector_h,
            "available_functions" : self.available_functions,
            "llm_function_item_class" : LlmFunctionItem,
            "workflow_error_types" : self.workflow_error_types,
            "workflow_error" : self.workflow_error,
            "max_retry" : self.max_retry
        })
        self._initialize_runner_h(uparams = {
            "output_comparer_h" : self.output_comparer_h,
            "available_functions" : self.available_functions,
            "available_callables" : self.available_callables,
            "workflow_error_types" : self.workflow_error_types,
            "workflow_error" : self.workflow_error,
        })
        self._initialize_check_h(uparams = {
            "llm_h" : self.llm_handler_h,
            "available_functions" : self.available_functions,
            "workflow_error_types" : self.workflow_error_types,
            "workflow_error" : self.workflow_error,
            "max_retry" : self.max_retry
        })

    def _update_reset_logic(self, wa_resp : AssembledWorkflow):

        tester_error = None
        if wa_resp.planning.tester is not None:
            tester_error = wa_resp.planning.tester.error

        if tester_error is None:
            wa_resp.planning.planner_rerun_needed = False
            wa_resp.planning.adaptor_rerun_needed = False
            wa_resp.workflow_completed = True
            self.logger.debug(f"Workflow completed after {wa_resp.planning.test_retries + 1} planning loops!")

            return wa_resp

        self.logger.debug(f"Updating reset logic based on error: {tester_error}",
                          label = tester_error.error_type.name,
                          save_vars = ["wa_resp.planning.tester.error"])

        if tester_error.additional_info and isinstance(tester_error.additional_info, dict):
            if "differences_by_case" in tester_error.additional_info and "differences" not in tester_error.additional_info:
                flat_differences = []
                for case_diff in tester_error.additional_info.get("differences_by_case", []):
                    case_id = case_diff.get("case_id")
                    for diff in case_diff.get("differences", []):
                        diff_item = dict(diff)
                        diff_item["case_id"] = case_id
                        flat_differences.append(diff_item)
                tester_error.additional_info["differences"] = flat_differences

        wa_resp.planning.planner_iters.append(wa_resp.planning.planner)
        wa_resp.planning.adaptor_iters.append(wa_resp.planning.adaptor)

        if tester_error.error_type is WorkflowErrorType.RUNNER:
            wa_resp.planning.planner.errors.append(tester_error)

            wa_resp.planning.planner_rerun_needed = True
            wa_resp.planning.adaptor_rerun_needed = True
            wa_resp.planning.adaptor = None

        if tester_error.error_type is WorkflowErrorType.PLANNING_HF:
            wa_resp.planning.planner.errors.append(tester_error)

            wa_resp.planning.planner_rerun_needed = True
            wa_resp.planning.adaptor_rerun_needed = True
            wa_resp.planning.adaptor = None

        if tester_error.error_type is WorkflowErrorType.OUTPUTS_UNEXPECTED:

            n_output_unexpected = len([err for err in wa_resp.planning.testing_errors if err is WorkflowErrorType.OUTPUTS_UNEXPECTED])
            n_planning_reset = len([err for err in wa_resp.planning.testing_errors if err is WorkflowErrorType.PLANNING_RESET])

            n_prev_output_unexpected = 0
            if n_planning_reset > 0:
                n_prev_output_unexpected = n_output_unexpected%n_planning_reset

            failed_cases = []
            if tester_error.additional_info and isinstance(tester_error.additional_info, dict):
                failed_cases = tester_error.additional_info.get("failed_cases", [])


            if n_prev_output_unexpected < self.max_output_unexpected:

                # If the same output fields keep failing, escalate to planner reset sooner.
                if tester_error.additional_info and isinstance(tester_error.additional_info, dict):
                    differences = tester_error.additional_info.get("differences", [])
                    if differences:
                        failing_paths = sorted({d.get("path") for d in differences if d.get("path")})
                        tester_error.additional_info["failing_paths"] = failing_paths

                        prev_paths = set()
                        for err in reversed(wa_resp.planning.testing_errors):
                            if getattr(err, "error_type", None) is WorkflowErrorType.OUTPUTS_UNEXPECTED:
                                prev_paths.update(err.additional_info.get("failing_paths", []))
                        if prev_paths and set(failing_paths) & prev_paths:
                            tester_error.error_type = WorkflowErrorType.PLANNING_RESET
                            wa_resp.planning.planner.errors.append(tester_error)
                            wa_resp.planning.planner_rerun_needed = True
                            wa_resp.planning.adaptor_rerun_needed = True
                            wa_resp.planning.adaptor = None
                            wa_resp.planning.testing_errors.append(tester_error)
                            wa_resp.planning.tester.error = None
                            return wa_resp

                wa_resp.planning.adaptor.all_errors.append(tester_error)

                wa_resp.planning.planner_rerun_needed = False
                wa_resp.planning.adaptor_rerun_needed = True
            else:
                if tester_error.additional_info and isinstance(tester_error.additional_info, dict):
                    differences = tester_error.additional_info.get("differences", [])
                    if differences:
                        failing_paths = sorted({d.get("path") for d in differences if d.get("path")})
                        tester_error.additional_info["failing_paths"] = failing_paths

                tester_error.error_type = WorkflowErrorType.PLANNING_RESET
                wa_resp.planning.planner.errors.append(tester_error)

                wa_resp.planning.planner_rerun_needed = True
                wa_resp.planning.adaptor_rerun_needed = True
                wa_resp.planning.adaptor = None

        if tester_error.error_type is WorkflowErrorType.OUTPUTS_FAILURE:
            wa_resp.planning.adaptor.all_errors.append(tester_error)

            wa_resp.planning.planner_rerun_needed = False
            wa_resp.planning.adaptor_rerun_needed = True

        if tester_error.error_type is WorkflowErrorType.ADAPTOR_JSON:
            wa_resp.planning.adaptor.all_errors.append(tester_error)

            wa_resp.planning.planner_rerun_needed = False
            wa_resp.planning.adaptor_rerun_needed = True

        wa_resp.planning.testing_errors.append(tester_error)
        wa_resp.planning.tester.error = None

        return wa_resp

    def _init_wa_obj(self, 
        task_description : str,
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        loops : int = 1,
        init_check : Optional[WorkflowCheckResponse] = None,
        ):

        return AssembledWorkflow(
            id = uuid.uuid4().hex,
            input_id = make_uid(d = {
                "task_description" : task_description,
                "input_model" : input_model.model_json_schema() if input_model else "",
                "output_model" : output_model.model_json_schema() if output_model else ""
                }),
            init_check = init_check,
            description = WorkflowDescription(
                task_description = task_description,
                input_model_json = input_model.model_json_schema() if input_model else None,
                output_model_json = output_model.model_json_schema() if output_model else None
            ),
            loops = loops
        )

    async def plan_workflow(
        self,
        task_description : str, 
        test_params : List[Dict[str, Type[BaseModel]]] = None, 
        compare_params : dict = None,
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        available_functions : List[LlmFunctionItem] = None,
        available_callables : Dict[str, callable] = None,
        max_retry : Optional[int] = None,
        reset_loops : Optional[int] = None):

        """
        Uses LLM to plans workflow based on provided tools and description.
        """

        if max_retry is None:
            max_retry = self.max_retry
        
        if reset_loops is None:
            reset_loops = self.reset_loops

        wa_resp = self._init_wa_obj(
            task_description = task_description,
            input_model = input_model,
            output_model = output_model
        )

        self.logger.debug(f"Starting workflow planning ...", label = "START")

        while wa_resp.planning.test_retries in range(max_retry):

            if wa_resp.workflow_possible is None:

                wa_resp.init_check = await self.check_h.check_workflow(
                    task_description = task_description,
                    input_model = input_model,
                    output_model = output_model,
                    available_functions = available_functions,
                    max_retry = max_retry,
                    checked_workflow = wa_resp.init_check
                )
                wa_resp.workflow_possible = wa_resp.init_check.workflow_possible

                if wa_resp.workflow_possible is None:
                    continue

                if wa_resp.workflow_possible is False:
                    self.logger.warning(f"Workflow planning is not possible!")
                    wa_resp.planning.planner_rerun_needed = False
                    wa_resp.planning.adaptor_rerun_needed = False
                    wa_resp.workflow_completed = False
                    break


            if wa_resp.planning.planner_rerun_needed:

                wa_resp.planning.planner = await self.planner_h.generate_workflow(
                    task_description = task_description,
                    input_model = input_model,
                    output_model = output_model,
                    available_functions = available_functions,
                    max_retry = max_retry,
                    planned_workflow = wa_resp.planning.planner)

            if wa_resp.planning.adaptor_rerun_needed:

                wa_resp.planning.adaptor = await self.adaptor_h.adapt_workflow(
                    workflow=wa_resp.planning.planner.workflow, 
                    input_model = input_model,
                    output_model = output_model,
                    available_functions = available_functions,
                    max_retry = max_retry,
                    adapted_workflow = wa_resp.planning.adaptor
                )

            if wa_resp.init_check.workflow_possible \
                and test_params is not None \
                    and wa_resp.planning.adaptor is not None:

                wa_resp.planning.tester = self.runner_h.run_workflow(
                    workflow = wa_resp.planning.adaptor.workflow, 
                    test_params = test_params,
                    compare_params = compare_params,
                    output_model = output_model,
                    available_functions = available_functions,
                    available_callables = available_callables
                    )
                if task_description:
                    wa_resp.description.task_description = task_description
                
            wa_resp = self._update_reset_logic(
                wa_resp = wa_resp
            )

            if wa_resp.workflow_completed:
                break

            wa_resp.planning.test_retries += 1
            if wa_resp.planning.tester and wa_resp.planning.tester.error:
                self.logger.warning(
                    f"Planning loop failed with {wa_resp.planning.tester.error.error_type} during testing. Attempts left {max_retry - wa_resp.planning.test_retries} !")

            if wa_resp.planning.test_retries == (max(max_retry,1)-1):
                
                if reset_loops > 0:
                
                    self.logger.warning(
                        f"Planning failed to converge, reseting!")
                    reset_loops = reset_loops - 1
                    prev_check = wa_resp.init_check
                    wa_resp = self._init_wa_obj(
                        task_description = task_description,
                        input_model = input_model,
                        output_model = output_model,
                        loops = wa_resp.loops + 1,
                        init_check = prev_check,
                    )


        if wa_resp.init_check.workflow_possible and wa_resp.planning.adaptor:  
            wa_resp.workflow = wa_resp.planning.adaptor.workflow

        if wa_resp.workflow_completed:
            self.logger.debug("Workflow completed.", label = "COMPLETED")
        else:
            self.logger.warning("Workflow failed to converge.", label = "FAILED")

        return wa_resp

    async def run_workflow(
        self,
        workflow_object : AssembledWorkflow,
        task_description : str = None, 
        run_inputs : Type[BaseModel] = None, 
        input_model : Type[BaseModel] = None,
        output_model : Type[BaseModel] = None,
        available_functions : List[LlmFunctionItem] = None,
        available_callables : Dict[str, callable] = None,
        max_retry : Optional[int] = None,
        reset_loops : Optional[int] = None):

        """
        Uses LLM to plans workflow based on provided tools and description.
        """

        if max_retry is None:
            max_retry = self.max_retry

        if reset_loops is None:
            reset_loops = self.reset_loops

        wa_resp = workflow_object.copy()
  
        if input_model is None:
            input_model = self.runner_h.json_schema_to_base_model(
                workflow_object.description.input_model_json)
        if output_model is None:
            output_model = self.runner_h.json_schema_to_base_model(
                workflow_object.description.output_model_json)

        while wa_resp.planning.test_retries in range(max_retry):

            if wa_resp.planning.planner_rerun_needed:

                wa_resp.planning.planner = await self.planner_h.generate_workflow(
                    task_description = task_description,
                    input_model = input_model,
                    output_model = output_model,
                    available_functions = available_functions,
                    max_retry = max_retry,
                    planned_workflow = wa_resp.planning.planner
                )

            if wa_resp.planning.adaptor_rerun_needed:

                wa_resp.planning.adaptor = await self.adaptor_h.adapt_workflow(
                    workflow=wa_resp.planning.planner.workflow, 
                    input_model = input_model,
                    output_model = output_model,
                    available_functions = available_functions,
                    max_retry = max_retry,
                    adapted_workflow = wa_resp.planning.adaptor
                )

            if run_inputs:

                wa_resp.planning.tester = self.runner_h.run_workflow(
                    workflow = wa_resp.planning.adaptor.workflow, 
                    inputs = run_inputs,
                    output_model = output_model,
                    available_functions = available_functions,
                    available_callables = available_callables
                    )
                if task_description:
                    wa_resp.description.task_description = task_description
                else:
                    task_description = wa_resp.description.task_description
                

            wa_resp = self._update_reset_logic(
                wa_resp = wa_resp
            )

            if wa_resp.workflow_completed:
                break

            wa_resp.planning.test_retries += 1

            self.logger.warning(
                f"Planning loop failed with {wa_resp.planning.tester.error.error_type} during testing. Attempts left {max_retry - wa_resp.planning.test_retries} !")

            if wa_resp.planning.test_retries == (max(max_retry,1)-1):
                
                if reset_loops > 0:
                
                    self.logger.warning(
                        f"Planning failed to converge, reseting!")
                    reset_loops = reset_loops - 1
                    prev_check = wa_resp.init_check
                    wa_resp = self._init_wa_obj(
                        task_description = task_description,
                        input_model = input_model,
                        output_model = output_model,
                        loops = wa_resp.loops + 1,
                        init_check = prev_check,
                    )
            
        wa_resp.workflow = wa_resp.planning.adaptor.workflow

        return wa_resp.planning.tester.outputs[str(len(wa_resp.planning.tester.outputs)-1)]