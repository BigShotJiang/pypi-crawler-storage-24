from setuptools import setup

import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))
path_to_readme = os.path.join(here, "README.md")

long_description = """# Workflow auto assembler

Workflow Auto Assembler (WAA) is an experimental schema-first workflow synthesis tool.
It uses an LLM to assemble simple executable workflows from a task description, target
input/output models, and a catalog of available typed tools.

WAA is built around a narrow idea: instead of asking the model to solve a task
directly, expose tools through explicit schemas and let the model construct a linear
workflow whose intermediate states can be validated and tested. The resulting workflow
is persisted as an explicit artifact with I/O mappings, which makes it inspectable,
re-runnable, and easier to validate than a transient agent trace.

### Why Workflow-Auto-Assembler?

WAA treats tool selection and wiring as a schema-matching problem. When the required
capabilities exist in the available tool catalog, the assembled workflow can behave
like a larger typed function composed from smaller typed functions.

This package should be read as experimental adaptive tooling rather than a claim of
general autonomous planning. Its strongest use case is simple linear workflow assembly
under explicit schema constraints, with runner-based validation used to check that the
assembled workflow satisfies the requested output contract.

"""

if os.path.exists(path_to_readme):
  with codecs.open(path_to_readme, encoding="utf-8") as fh:
      long_description += fh.read()

setup(
    name="workflow_auto_assembler",
    packages=["workflow_auto_assembler"],
    install_requires=['attrsx', 'pydantic', 'pyyaml', 'attrs'],
    classifiers=['Development Status :: 3 - Alpha'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Kyrylo Mordan",
    author_email="parachute.repo@gmail.com",
    description="Experimental schema-first workflow synthesis tool for assembling simple typed workflows from existing functions.",
    keywords=['aa-paa-tool'],
    version="0.0.1",
    extras_require = {'openai': ['openai'], 'ollama': ['ollama'], 'all': ['openai', 'ollama']},

    license = "apache-2.0",
    include_package_data = True,
    package_data = {'workflow_auto_assembler': ['mkdocs/**/*', 'artifacts/.paa.tracking/git/**/*', 'artifacts/.paa.tracking/git_repo/**/*', 'artifacts/research_notes_template.md', 'artifacts/prompts/**/*', 'artifacts/test_results/**/*', 'artifacts/examples/**/*', '.paa.tracking/version_logs.csv', '.paa.tracking/release_notes.md', '.paa.tracking/lsts_package_versions.yml', '.paa.tracking/package_mapping.json', '.paa.tracking/package_licenses.json', '.paa.tracking/.drawio', '.paa.tracking/extra_docs/**/*', '.paa.tracking/.paa.config', '.paa.tracking/git/**/*', '.paa.tracking/git_repo/**/*', '.paa.tracking/python_modules/workflow_auto_assembler.py', '.paa.tracking/python_modules/components/input_collector.py', '.paa.tracking/python_modules/components/workflow_runner.py', '.paa.tracking/python_modules/components/workflow_check.py', '.paa.tracking/python_modules/components/workflow_planner.py', '.paa.tracking/python_modules/components/output_comparer.py', '.paa.tracking/python_modules/components/llm_handler.py', '.paa.tracking/python_modules/components/wa_general_models.py', '.paa.tracking/python_modules/components/workflow_adaptor.py', '.paa.tracking/.paa.version']} ,
    license_files = ["LICENSE", "NOTICE"],
    )
