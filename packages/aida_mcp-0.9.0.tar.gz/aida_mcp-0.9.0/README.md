# AIDA MCP

AIDA (AI Developer Assistant) is an MCP server that gives your AI coding assistant repository-specific rules, automated validation, and Git workflow guardrails — across any MCP-compatible tool.

Instead of maintaining separate prompt files for each tool (`.cursorrules`, `CLAUDE.md`, `copilot-instructions.md`), you configure behavior once in `.aida/` and every assistant picks it up.

## Why AIDA

**Context engineering, automated.** AIDA doesn't dump a flat file into the context window. It dynamically selects only the rules relevant to the current task using hybrid scoring (lexical + semantic). Session memory tracks what the AI already received — subsequent calls return only deltas. Your context stays lean even as your rule library grows.

**Validation before commit.** Rules can only suggest — LLMs still hallucinate. AIDA routes changed files to the right linters, formatters, and tests automatically, before commit. The AI gets filtered feedback and can self-correct on the spot.

**Git workflow guardrails.** Enforces commit message format, required metadata (risk level, ticket reference), and PR templates. Handles PR review threads. Your team's conventions are enforced, not just documented.

**Works with every MCP-compatible tool.** Cursor, Claude Code, OpenAI Codex, JetBrains AI Chat, and Junie. One configuration, every assistant.

## Install

```bash
uv tool install aida-mcp    # recommended
pip install aida-mcp         # alternative
```

Requires Python 3.12+ (< 3.15) and an MCP-compatible AI tool.

## Quick Start

### Your repo already has `.aida/` configured

Install `aida-mcp` and reload your AI tool. The MCP wiring in the repo connects your assistant to AIDA automatically.

### Setting up a new repo

```bash
cd /path/to/your/repo
aida-mcp init
```

This creates:
- `.aida/` — rules, validation config, git policy, templates
- MCP wiring files (`.mcp.json`, `.cursor/mcp.json`, etc.)

Commit the result and reload your AI tool.

## What gets configured

All configuration lives in `.aida/` and is version-controlled:

| File | Purpose |
|------|---------|
| `rules/` | Project-specific rules in `.mdc` format |
| `rules_selection.yaml` | Enable/disable embedded profiles (Python, Kotlin, Spring Boot, GitHub workflows, etc.) |
| `change_domains.yaml` | Map file paths to logical domains (e.g., `services/**/*.py` -> `python_service`) |
| `validation_policy.yaml` | Route domains to validation pipelines |
| `validation_registry.yaml` | Define validation commands, working dirs, timeouts |
| `git_policy.yaml` | Commit/PR policies — subject length, required trailers, templates |
| `templates/` | Commit message and PR body templates |
| `preferences.yaml` | Team defaults for validation and commit behavior |

## Developer preferences

Developers can override team defaults in `.aida/preferences.local.yaml` (gitignored):

```yaml
preferences:
  validation:
    pre_commit: ask      # auto | ask | disabled
  commit:
    mode: ask            # auto | ask | disabled
```

## Native mode (no MCP server)

For teams not yet running MCP, export rules as static files:

```bash
aida-mcp rules export
```

This writes self-contained rule files for each tool (`.claude/CLAUDE.md`, `.cursor/rules/aida.mdc`, etc.). Re-run after config changes. `aida-mcp doctor` warns when exports are stale.

## CLI reference

| Command | Purpose |
|---------|---------|
| `aida-mcp init` | Bootstrap AIDA in a repository |
| `aida-mcp doctor` | Check repository health (`--auto-fix` to repair) |
| `aida-mcp migrate` | Upgrade from older AIDA layout |
| `aida-mcp validate --scope pre_commit` | Run validation on changed files |
| `aida-mcp commit --type feat --title "..."` | Policy-compliant commit |
| `aida-mcp rules export` | Export static native rule files |
| `aida-mcp install-mcp --target claude` | Install/refresh MCP wiring for a specific tool |

### JetBrains / Junie setup

These require global MCP installation:

```bash
aida-mcp install-mcp --global --target jetbrains
aida-mcp install-mcp --global --target junie
```

## Feedback

We'd love to hear how AIDA works for your team. If something is missing, broken, or could be better — let us know on our [Slack community](https://www.gooddata.com/slack).
