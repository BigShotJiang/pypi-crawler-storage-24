# AIDA MCP Workflow

## Every task
Call `get_rules` at task start. Follow returned rules.

## Before commit
Call `validate_command` to plan validation, then run the returned CLI command.

## Commit and PR
Only when the user explicitly asks. Do not call `get_rules` for commit/push-only intent.
Use `commit_command` for commits. Use `pr_command` for PRs. Do not run git or gh commands directly.
If a tool returns `needs_more_input`, infer the missing values from the current changes and retry.
If a tool returns `confirmation_required`, show the command to the user and wait for approval.
