# Copyright (C) 2026 GoodData Corporation

"""CLI handlers for the ``aida-mcp rules`` command group."""

from __future__ import annotations

import argparse
from pathlib import Path

from aida_mcp.server.native_export import ALL_TOOL_NAMES, export_native_rules


def rules_export_cmd(args: argparse.Namespace) -> None:
    workspace_root = Path(args.workspace_root).resolve() if args.workspace_root else Path.cwd()
    raw_tools: list[str] | None = args.tool
    if raw_tools and "all" in raw_tools:
        raw_tools = None  # None means all tools
    tools = raw_tools or list(ALL_TOOL_NAMES)

    result = export_native_rules(workspace_root=workspace_root, tools=tools)

    for f in result.wrote_files:
        print(f"[aida-mcp][rules][export] wrote {f}")
    print(f"[aida-mcp][rules][export] manifest: {result.manifest_path}")
    print(f"[aida-mcp][rules][export] Done. Exported native rules for {len(result.wrote_files)} tool(s).")
