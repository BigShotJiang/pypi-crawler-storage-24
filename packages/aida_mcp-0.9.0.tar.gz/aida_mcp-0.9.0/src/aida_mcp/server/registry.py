# Copyright (C) 2026 GoodData Corporation

"""Explicit MCP tool registration (Option A).

We keep tool registration explicit to avoid "import for side effects" surprises
that can lead to a running server with 0 tools registered.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import aida_mcp.server.tools_commit as tools_commit
import aida_mcp.server.tools_github as tools_github
import aida_mcp.server.tools_pr as tools_pr
import aida_mcp.server.tools_pr_review as tools_pr_review
import aida_mcp.server.tools_rules as tools_rules
import aida_mcp.server.tools_validation as tools_validation

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


_REGISTERED_SENTINEL = "_aida_tools_registered"


def register_all(mcp: FastMCP) -> None:
    """Register all MCP tools on the given FastMCP instance."""
    if getattr(mcp, _REGISTERED_SENTINEL, False):
        return
    tools_commit.register(mcp)
    tools_github.register(mcp)
    tools_pr.register(mcp)
    tools_pr_review.register(mcp)
    tools_rules.register(mcp)
    tools_validation.register(mcp)
    setattr(mcp, _REGISTERED_SENTINEL, True)
