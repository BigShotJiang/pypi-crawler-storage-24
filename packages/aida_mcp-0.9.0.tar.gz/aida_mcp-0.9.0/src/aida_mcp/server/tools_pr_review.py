# Copyright (C) 2026 GoodData Corporation

"""PR review MCP tools: list threads, reply, resolve."""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated

from pydantic import Field

from aida_mcp.server.app_instance import Context
from aida_mcp.tools.github.comments import (
    list_review_threads,
    reply_to_review_comment,
    resolve_review_thread,
)

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(mcp: FastMCP) -> None:
    """Register PR review tools."""
    mcp.tool()(pr_comments)
    mcp.tool()(pr_reply)
    mcp.tool()(pr_resolve)


async def pr_comments(
    repo: Annotated[str, Field(description="Repository in 'owner/repo' format.")],
    pr_number: Annotated[int, Field(description="Pull request number.")],
    include_resolved: Annotated[
        bool,
        Field(description="Include resolved threads. Default: only unresolved."),
    ] = False,
    since: Annotated[
        str | None,
        Field(
            description=(
                "ISO 8601 timestamp. Only return threads with activity after this time. "
                "Use this to find new comments since your last check."
            )
        ),
    ] = None,
    limit: Annotated[int, Field(description="Max threads to return.")] = 50,
    *,
    ctx: Context,
) -> object:
    """List PR review threads with comments, file paths, and resolution state.

    Returns all review threads in one call with pagination handled internally.
    Each thread includes: path, line, resolved state, and full comment history.
    """
    await ctx.info("🧵 Listing PR review threads…")
    return await list_review_threads(
        repo=repo,
        pr_number=pr_number,
        limit=limit,
        include_resolved=include_resolved,
        since=since,
    )


async def pr_reply(
    comment_url: Annotated[
        str,
        Field(description="Review comment URL ending with #discussion_r<ID>."),
    ],
    body: Annotated[str, Field(description="Reply text.")],
    *,
    ctx: Context,
) -> object:
    """Reply to a PR review thread.

    Posts a threaded reply to the specified review comment.
    The reply is prefixed with **AI:** automatically.
    Does NOT resolve the thread — use pr_resolve separately if needed.
    """
    if not comment_url:
        raise ValueError("comment_url is required.")
    if not body:
        raise ValueError("body is required.")
    await ctx.info("💬 Replying to review comment…")
    return await reply_to_review_comment(comment_url=comment_url, body=body)


async def pr_resolve(
    comment_url: Annotated[
        str,
        Field(description="Review comment URL ending with #discussion_r<ID>."),
    ],
    *,
    ctx: Context,
) -> object:
    """Resolve a PR review thread.

    Only resolve threads when the user explicitly asks you to.
    Do not resolve threads proactively — let the reviewer resolve them.
    """
    if not comment_url:
        raise ValueError("comment_url is required.")
    await ctx.info("✅ Resolving review thread…")
    return await resolve_review_thread(comment_url=comment_url)
