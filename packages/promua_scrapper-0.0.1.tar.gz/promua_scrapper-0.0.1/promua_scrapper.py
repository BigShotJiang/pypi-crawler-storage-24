import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin


class PromOnePageTracker:
    def __init__(self, user_agent="Mozilla/5.0"):
        self.headers = {"User-Agent": user_agent}

    def _get_data(self, block, selector, attr=None, transform=None):
        element = block.select_one(selector)
        if not element: return None
        value = element.get(attr) if attr else element.get_text(" ", strip=True)
        if transform and value:
            try:
                return transform(value)
            except:
                return None
        return value

    def parse_page(self, html, base_url):
        soup = BeautifulSoup(html, "html.parser")
        rows = []

        for block in soup.select('div[data-qaid="product_block"]'):
            image_el = block.select_one('[data-qaid="image_link"]')
            image_url = image_el.get("src") if image_el else None

            rows.append({
                "title": self._get_data(block, '[data-qaid="product_name"]'),
                "price": self._get_data(block, '[data-qaid="product_price"]', 'data-qaprice', float),
                "old_price": self._get_data(block, '[data-qaid="old_price"]', 'data-qaprice', float),
                "rating":
                    self._get_data(block, '[data-qaid="product_rating"]', 'data-qarating', float),
                "url": urljoin(base_url, block.select_one('a[data-qaid="product_link"]')['href'])
                if block.select_one('a[data-qaid="product_link"]') else None,
                "company": self._get_data(block, '[data-qaid="company_name"]'),
                "image_url": image_url,
            })
        return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)

    def run(self, url, filename="prom.csv"):
        res = requests.get(url, headers=self.headers)
        df = self.parse_page(res.text, url)
        if not df.empty: df.to_csv(filename, index=False, encoding="utf-8")
        return df
