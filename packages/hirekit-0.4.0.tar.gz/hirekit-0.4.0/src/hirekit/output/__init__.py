"""Output renderers for HireKit."""
