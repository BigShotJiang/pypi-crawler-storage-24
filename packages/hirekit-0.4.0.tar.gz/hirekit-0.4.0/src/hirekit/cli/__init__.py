"""CLI commands for HireKit."""
