import re
import sys
import pickle
import os
import requests as reqs
from olsync.olclient import OverleafClient

def debug_ids(project_id):
    cookie_path = ".olauth"
    if not os.path.isfile(cookie_path):
        print("Error: .olauth not found")
        return

    with open(cookie_path, 'rb') as f:
        store = pickle.load(f)

    client = OverleafClient(store["cookie"], store["csrf"])
    
    urls = [
        f"https://www.overleaf.com/project/{project_id}",
        f"https://www.overleaf.com/project/{project_id}/editor"
    ]
    
    print(f"Project ID: {project_id}")
    
    for url in urls:
        print(f"\nFetching {url}...")
        r = reqs.get(url, cookies=client._cookie, headers=client._headers)
        if r.status_code != 200:
            print(f"Failed to fetch {url}: {r.status_code}")
            continue
            
        ids = re.findall(r'[a-f0-9]{24}', r.text)
        unique_ids = sorted(list(set(ids)))
        
        print(f"Found {len(ids)} ID-like strings ({len(unique_ids)} unique):")
        for i in unique_ids:
            overlap = 0
            for c1, c2 in zip(project_id, i):
                if c1 == c2: overlap += 1
                else: break
            
            suffix = ""
            if i == project_id:
                suffix = " (PROJECT ID)"
            elif overlap >= 20:
                suffix = f" (STRONG CANDIDATE, overlap {overlap})"
                
            print(f"  {i}{suffix}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python debug_ids.py <project_id>")
    else:
        debug_ids(sys.argv[1])
