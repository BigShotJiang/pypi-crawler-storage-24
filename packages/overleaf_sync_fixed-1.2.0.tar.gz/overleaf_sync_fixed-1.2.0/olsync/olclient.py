"""Overleaf Client"""
##################################################
# MIT License
##################################################
# File: olclient.py
# Description: Overleaf API Wrapper
# Author: Moritz Glöckl
# License: MIT
# Version: 1.3.3
##################################################

import os
import re
import html
import requests as reqs
from bs4 import BeautifulSoup
import json
import uuid
import time
import traceback

try:
    import websocket
    if not hasattr(websocket, 'SSLError'):
        class SSLError(Exception): pass
        websocket.SSLError = SSLError
except ImportError:
    pass

# URLs
LOGIN_URL = "https://www.overleaf.com/login"
PROJECT_URL = "https://www.overleaf.com/project"
DOWNLOAD_URL = "https://www.overleaf.com/project/{}/download/zip"
UPLOAD_URL = "https://www.overleaf.com/project/{}/upload"
FOLDER_URL = "https://www.overleaf.com/project/{}/folder"
DELETE_URL = "https://www.overleaf.com/project/{}/doc/{}"
COMPILE_URL = "https://www.overleaf.com/project/{}/compile?enable_pdf_caching=true"
BASE_URL = "https://www.overleaf.com"
PATH_SEP = "/"

class OverleafClient(object):
    @staticmethod
    def filter_projects(json_content, more_attrs=None):
        more_attrs = more_attrs or {}
        for p in json_content:
            if not p.get("archived") and not p.get("trashed"):
                if all(p.get(k) == v for k, v in more_attrs.items()):
                    yield p

    def __init__(self, cookie=None, csrf=None):
        self._cookie = cookie
        self._csrf = csrf
        self._headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

    def all_projects(self):
        projects_page = reqs.get(PROJECT_URL, cookies=self._cookie, headers=self._headers)
        if not projects_page.ok:
            if projects_page.status_code in [401, 403]:
                raise PermissionError("Authentication failed. Cookie expired.")
            raise reqs.HTTPError(f"HTTP {projects_page.status_code}")

        text = html.unescape(projects_page.text)
        json_content = None
        
        soup = BeautifulSoup(text, 'html.parser')
        meta_projects = soup.find('meta', {'name': 'ol-projects'})
        if meta_projects:
            try: json_content = json.loads(meta_projects.get('content'))
            except: pass

        if json_content is None:
            markers = ['"projects":[', 'preloadedProjects:[', 'initialProjects:[']
            for marker in markers:
                start_pos = text.find(marker)
                if start_pos != -1:
                    start_idx = start_pos + len(marker) - 1
                    bc, in_str, esc = 0, False, False
                    for i in range(start_idx, len(text)):
                        c = text[i]
                        if esc: esc = False; continue
                        if c == '\\': esc = True; continue
                        if c == '"': in_str = not in_str; continue
                        if not in_str:
                            if c == '[': bc += 1
                            elif c == ']': bc -= 1
                            if bc == 0:
                                try:
                                    json_content = json.loads(text[start_idx:i+1])
                                    break
                                except: continue
                    if json_content: break

        if json_content is None:
            if "login" in projects_page.url or "Log In" in text:
                raise PermissionError("Authentication failed. Cookie might be expired.")
            raise AttributeError("Could not find project list. Overleaf layout may have changed.")
        
        if isinstance(json_content, dict) and 'projects' in json_content: json_content = json_content['projects']
        return list(OverleafClient.filter_projects(json_content))

    def get_project(self, project_name):
        projects = self.all_projects()
        project = next((p for p in projects if p['name'] == project_name), None)
        if not project: raise ValueError(f"Project '{project_name}' not found.")
        return project

    def download_project(self, project_id):
        r = reqs.get(DOWNLOAD_URL.format(project_id), stream=True, cookies=self._cookie, headers=self._headers)
        return r.content

    def create_folder(self, project_id, parent_folder_id, folder_name):
        params = {"name": folder_name}
        if parent_folder_id: params["parent_folder_id"] = parent_folder_id
        h = self._headers.copy()
        h.update({"X-Csrf-Token": self._csrf})
        r = reqs.post(FOLDER_URL.format(project_id), cookies=self._cookie, headers=h, json=params)
        if r.ok: return json.loads(r.content)
        return None

    def get_project_infos(self, project_id, verbose_error_logging=False, file_list=None):
        project_meta_json = None
        try:
            url = BASE_URL + f"/project/{project_id}/metadata"
            h = self._headers.copy()
            h.update({"X-Csrf-Token": self._csrf, "X-Requested-With": "XMLHttpRequest", "Referer": BASE_URL + f"/project/{project_id}"})
            r = reqs.get(url, cookies=self._cookie, headers=h)
            if r.status_code == 200: project_meta_json = r.json()
        except: pass

        # Discovery by creation
        try:
            name = f"olsync_find_{uuid.uuid4().hex[:6]}"
            h = self._headers.copy()
            h.update({"X-Csrf-Token": self._csrf, "Referer": BASE_URL + f"/project/{project_id}"})
            r = reqs.post(BASE_URL + f"/project/{project_id}/folder", cookies=self._cookie, headers=h, json={"name": name})
            if r.ok:
                data = r.json()
                root_id = data.get('parent_folder_id') or data.get('root_folder_id') or data.get('parentFolderId')
                new_id = data.get('_id')
                if new_id: reqs.delete(BASE_URL + f"/project/{project_id}/folder/{new_id}", cookies=self._cookie, headers=h, json={})
                if root_id: return {'rootFolder': {'_id': root_id, 'folders': [], 'docs': []}}
        except: pass

        if project_meta_json and 'projectMeta' in project_meta_json:
            for k in project_meta_json['projectMeta'].keys():
                if k.endswith("92") or k.endswith("c86"):
                    return {'rootFolder': {'_id': k, 'folders': [], 'docs': []}}
        
        return {'rootFolder': {'_id': project_id, 'folders': [], 'docs': []}}

    def find_file_id_by_name(self, project_id, file_name, verbose_error_logging=False):
        try:
            r = reqs.get(BASE_URL + f"/project/{project_id}", cookies=self._cookie, headers=self._headers)
            if r.status_code == 200:
                pattern = r'["\']name["\']\s*:\s*["\']' + re.escape(file_name) + r'["\'].*?["\'](?:_id|id)["\']\s*:\s*["\']([a-f0-9]{24})["\']'
                match = re.search(pattern, r.text, re.DOTALL)
                if match: return match.group(1)
        except: pass
        return None

    def update_doc(self, project_id, doc_id, content):
        url = BASE_URL + f"/project/{project_id}/doc/{doc_id}"
        h = self._headers.copy()
        h.update({"X-Csrf-Token": self._csrf, "Content-Type": "application/json", "Referer": BASE_URL + f"/project/{project_id}/editor"})
        for payload in [{"content": content}, {"content": content.split('\n')}]:
            r = reqs.put(url, cookies=self._cookie, headers=h, json=payload)
            if r.ok: return True
        return False

    def upload_file(self, project_id, project_infos, file_name, file_size, file, verbose_error_logging=False):
        """
        Uploads a file. Handles text files via Doc API and others via Multipart.
        """
        clean_name = file_name.split(PATH_SEP)[-1]
        
        # 1. TEXT FILE STRATEGY
        if file_name.endswith(('.tex', '.bib', '.cls', '.sty')):
            if verbose_error_logging: print(f"[DEBUG] Text File Strategy for {clean_name}")
            try:
                if hasattr(file, 'seek'): file.seek(0)
                content = file.read()
                if isinstance(content, bytes): content = content.decode('utf-8', errors='replace')
                
                fid = self.find_file_id_by_name(project_id, clean_name, verbose_error_logging)
                if fid:
                    if verbose_error_logging: print(f"[DEBUG] Updating existing {fid}")
                    if self.update_doc(project_id, fid, content): return True
                    self.delete_file(project_id, project_infos, file_name)
                    time.sleep(0.5)

                doc_url = BASE_URL + f"/project/{project_id}/doc"
                h = self._headers.copy()
                h.update({"X-Csrf-Token": self._csrf, "Referer": BASE_URL + f"/project/{project_id}/editor"})
                folder_id = project_infos.get('rootFolder', {}).get('_id') if project_infos else None
                for p_id in [folder_id, None]:
                    r = reqs.post(doc_url, cookies=self._cookie, headers=h, json={"name": clean_name, "parent_folder_id": p_id})
                    if r.ok:
                        nid = r.json().get('_id')
                        if nid: self.update_doc(project_id, nid, content)
                        return True
            except Exception as e:
                if verbose_error_logging: print(f"[DEBUG] Doc API failed: {e}")

        # 2. MULTIPART STRATEGY
        url = UPLOAD_URL.format(project_id)
        h = self._headers.copy()
        h.update({"X-Csrf-Token": self._csrf, "X-Requested-With": "XMLHttpRequest", "Referer": BASE_URL + f"/project/{project_id}/editor", "Origin": BASE_URL})
        folder_id = project_infos.get('rootFolder', {}).get('_id') if project_infos else None
        for fid in [folder_id, "", project_id]:
            if hasattr(file, 'seek'): file.seek(0)
            data = {"folder_id": fid if fid is not None else "", "qquuid": str(uuid.uuid4()), "qqfilename": clean_name, "qqtotalfilesize": file_size, "upload_params": '{"is_not_standard_upload":true}', "csrf_token": self._csrf, "_csrf": self._csrf}
            if data["folder_id"] is None: data.pop("folder_id")
            try:
                r = reqs.post(url, cookies=self._cookie, data=data, files={"qqfile": (clean_name, file, 'application/octet-stream')}, headers=h)
                if r.status_code == 200 and r.json().get("success"): return True
            except: pass
            
        raise reqs.HTTPError(f"Upload failed for {clean_name}")

    def delete_file(self, project_id, project_infos, file_name):
        fid = self.find_file_id_by_name(project_id, file_name.split(PATH_SEP)[-1])
        if not fid: return False
        h = self._headers.copy()
        h.update({"X-Csrf-Token": self._csrf})
        r = reqs.delete(DELETE_URL.format(project_id, fid), cookies=self._cookie, headers=h, json={})
        return r.status_code == 204

    def download_pdf(self, project_id):
        h = self._headers.copy()
        h.update({"X-Csrf-Token": self._csrf})
        body = {"check": "silent", "draft": False, "incrementalCompilesEnabled": True, "rootDoc_id": "", "stopOnFirstError": False}
        r = reqs.post(COMPILE_URL.format(project_id), cookies=self._cookie, headers=h, json=body)
        if not r.ok: raise reqs.HTTPError()
        res = r.json()
        if res["status"] != "success": raise reqs.HTTPError()
        pdf = next(v for v in res['outputFiles'] if v['type'] == 'pdf')
        dr = reqs.get(BASE_URL + pdf['url'], cookies=self._cookie, headers=h)
        if dr.ok: return pdf['path'], dr.content
        return None
