# Overleaf Sync (Fixed)

A robust two-way synchronization tool for Overleaf projects, updated to support the latest Overleaf web interface (2024+).

## Features
- **Two-way Sync**: Seamlessly sync changes between local computer and Overleaf.
- **Robust Uploads**: Specialized strategy for `.tex`, `.bib`, `.cls`, and `.sty` files to ensure 100% content delivery.
- **No Premium Required**: Works with free Overleaf accounts; no Git or Dropbox subscription needed.
- **Conflict Awareness**: Intelligent sync logic that prioritizes local changes and warns about potential conflicts.

## Installation

### From PyPI (Recommended)
```bash
pip install overleaf-sync-fixed
```

### From Source
```bash
git clone https://github.com/lawrencee/overleaf-sync-fixed
cd overleaf-sync-fixed
pip install .
```

## Usage

### 1. Login
Authenticate using your `overleaf_session2` cookie.
```bash
ols login
```
*Note: Get the cookie from Browser DevTools -> Application -> Cookies -> `overleaf_session2`.*

### 2. List Projects
```bash
ols list
```

### 3. Download & Sync
Download a project to the current directory:
```bash
ols download "Your Project Name"
```

Once in the project directory, run two-way sync:
```bash
ols
```

---
**Disclaimer**: This tool is not affiliated with Overleaf. Use at your own risk.
