# Overleaf 同步工具 (修复版)

一个稳健的 Overleaf 项目双向同步工具，已更新以支持最新的 Overleaf 界面（2024+）。

## 特性
- **双向同步**: 在本地计算机和 Overleaf 之间无缝同步更改。
- **稳健上传**: 针对 `.tex`, `.bib`, `.cls` 和 `.sty` 文件采用专门的上传策略，确保内容准确送达。
- **无需高级版**: 适用于免费 Overleaf 账户；无需 Git 或 Dropbox 订阅。
- **冲突处理**: 智能同步逻辑，优先处理本地更改并对潜在冲突发出警告。

## 安装方式

### 通过 PyPI 安装 (推荐)
```bash
pip install overleaf-sync-fixed
```

### 从源码安装
```bash
git clone https://github.com/lawrencee/overleaf-sync-fixed
cd overleaf-sync-fixed
pip install .
```

## 使用方法

### 1. 登录
使用 `overleaf_session2` cookie 进行身份验证。
```bash
ols login
```
*提示：从浏览器开发者工具 (F12) -> Application -> Cookies -> 获取 `overleaf_session2` 的值。*

### 2. 列出项目
```bash
ols list
```

### 3. 下载与同步
将项目下载到当前目录：
```bash
ols download "你的项目名称"
```

在项目目录中，运行双向同步：
```bash
ols
```

---
**免责声明**: 本工具与 Overleaf 官方无关。请自行承担使用风险。
