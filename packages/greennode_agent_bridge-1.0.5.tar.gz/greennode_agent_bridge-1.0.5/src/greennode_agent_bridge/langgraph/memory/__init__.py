"""LangGraph Memory adaptor for GreenNode AgentBase.

This module provides checkpoint saver and store implementations for LangGraph
using GreenNode AgentBase Memory.
"""

from typing import Any

# Store the import error for later use
_import_error: ImportError | None = None

# Conditional imports for optional dependencies
try:
    from greennode_agent_bridge.langgraph.memory.events import AgentBaseMemoryEvents
    from greennode_agent_bridge.langgraph.memory.records import AgentBaseMemoryRecords

    langgraph_available = True
except ImportError as e:
    # Store the error for later use
    _import_error = e
    langgraph_available = False

    # If dependencies are not available, provide helpful error message
    def _missing_langgraph_dependencies_error(*args: Any, **kwargs: Any) -> Any:
        raise ImportError(
            "LangGraph functionality requires optional dependencies. "
            "Install them with: pip install 'greennode-agent-bridge[langgraph]'"
        ) from _import_error

    # Create placeholder classes that raise helpful error
    AgentBaseMemoryEvents: type[Any] = _missing_langgraph_dependencies_error  # type: ignore[assignment,no-redef]
    AgentBaseMemoryRecords: type[Any] = _missing_langgraph_dependencies_error  # type: ignore[assignment,no-redef]

__all__ = [
    "AgentBaseMemoryEvents",
    "AgentBaseMemoryRecords",
    "langgraph_available",
]
