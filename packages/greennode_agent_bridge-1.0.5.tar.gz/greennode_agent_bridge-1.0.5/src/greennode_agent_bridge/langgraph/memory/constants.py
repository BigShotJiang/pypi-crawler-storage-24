"""Constants and exceptions for AgentBase Memory Checkpoint Saver."""

EMPTY_CHANNEL_VALUE = "_empty"


class AgentBaseMemoryError(Exception):
    """Base exception for AgentBase Memory errors."""

    pass


class EventDecodingError(AgentBaseMemoryError):
    """Raised when event decoding fails."""

    pass


class InvalidConfigError(AgentBaseMemoryError):
    """Raised when configuration is invalid."""

    pass


class EventNotFoundError(AgentBaseMemoryError):
    """Raised when expected event is not found."""

    pass
