"""AgentBase History Provider for Microsoft Agent Framework."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Sequence
from typing import Any, ClassVar

from agent_framework import BaseHistoryProvider, Message
from greennode_agentbase.memory import MemoryClient
from greennode_agentbase.memory.models import EventCreateRequest, EventPayload

from greennode_agent_bridge.agent_framework.memory.helpers import (
    convert_af_message_to_event_payload,
    get_chat_history_sync,
)

logger = logging.getLogger(__name__)


class AgentBaseHistoryProvider(BaseHistoryProvider):
    """History provider that persists Agent Framework messages to GreenNode AgentBase Memory."""

    DEFAULT_SOURCE_ID: ClassVar[str] = "greennode"

    def __init__(
        self,
        source_id: str = DEFAULT_SOURCE_ID,
        *,
        key_prefix: str = "chat_messages",
        gn_memory_id: str = "default",
        actor_id: str | None = None,
        limit: int | None = None,
        max_messages: int | None = None,
        load_messages: bool = True,
        store_inputs: bool = True,
        store_outputs: bool = True,
        store_context_messages: bool = False,
        store_context_from: set[str] | None = None,
        memory_client: MemoryClient | None = None,
    ) -> None:
        super().__init__(
            source_id=source_id or self.DEFAULT_SOURCE_ID,
            load_messages=load_messages,
            store_inputs=store_inputs,
            store_context_messages=store_context_messages,
            store_context_from=store_context_from,
            store_outputs=store_outputs,
        )
        self.gn_memory_id = gn_memory_id
        self.key_prefix = key_prefix
        self.max_messages = max_messages
        self.limit = limit
        self.actor_id = actor_id
        self._memory_client = memory_client or MemoryClient()

    async def get_messages(
        self,
        session_id: str | None,
        limit: int | None = None,
        **kwargs: Any,
    ) -> list[Message]:

        logger.info(f"Getting messages for session: {session_id}")
        if session_id is None:
            return []
        loop = asyncio.get_event_loop()
        messages = await loop.run_in_executor(
            None,
            lambda: get_chat_history_sync(
                memory_client=self._memory_client,
                memory_id=self.gn_memory_id,
                session_id=session_id,
                actor_id=self.actor_id,
                limit=limit or self.limit,
                max_results=self.max_messages,
            ),
        )
        messages.reverse()

        return messages

    async def save_messages(
        self,
        session_id: str | None,
        messages: Sequence[Message],
        **kwargs: Any,
    ) -> None:
        """Persist messages to AgentBase Memory using create_event."""
        loop = asyncio.get_event_loop()
        memory_client = self._memory_client
        gn_memory_id = self.gn_memory_id
        actor_id = self.actor_id

        try:

            def _save_all() -> None:

                logger.info(f"Saving messages for session: {session_id}")

                for msg in messages:
                    payload: EventPayload = convert_af_message_to_event_payload(msg)
                    request = EventCreateRequest(payload=payload, eventTimestamp=None)
                    memory_client.create_event(
                        id=gn_memory_id,
                        actorId=actor_id,
                        sessionId=session_id,
                        request=request,
                    )

            await loop.run_in_executor(None, _save_all)
        except Exception as e:
            logger.error(f"Error saving messages: {e}")
