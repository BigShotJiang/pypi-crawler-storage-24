"""Agent Framework Memory adaptor for GreenNode AgentBase.

This module provides history provider implementation for Microsoft Agent Framework
using GreenNode AgentBase Memory.
"""

from typing import Any

_import_error: ImportError | None = None

try:
    from greennode_agent_bridge.agent_framework.memory.provider import (
        AgentBaseHistoryProvider,
    )

    agent_framework_available = True
except ImportError as e:
    _import_error = e
    agent_framework_available = False

    def _missing_agent_framework_dependencies_error(*args: Any, **kwargs: Any) -> Any:
        raise ImportError(
            "Agent Framework functionality requires optional dependencies. "
            "Install them with: pip install 'greennode-agent-bridge[agent-framework]'"
        ) from _import_error

    AgentBaseHistoryProvider: type[Any] = _missing_agent_framework_dependencies_error  # type: ignore[assignment,no-redef]

__all__ = [
    "AgentBaseHistoryProvider",
    "agent_framework_available",
]
