"""Agent Framework adaptor for GreenNode AgentBase.

This package provides adaptors for Microsoft Agent Framework to work with
GreenNode AgentBase Memory.
"""

try:
    from greennode_agent_bridge.agent_framework.memory import (
        AgentBaseHistoryProvider,
        agent_framework_available,
    )

    __all__ = [
        "AgentBaseHistoryProvider",
        "agent_framework_available",
    ]
except ImportError:
    __all__ = []
