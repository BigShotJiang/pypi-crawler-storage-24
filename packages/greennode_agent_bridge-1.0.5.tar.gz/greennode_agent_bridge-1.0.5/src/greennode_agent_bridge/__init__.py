"""GreenNode Agent Bridge - Connect agent frameworks with GreenNode AgentBase.

This package provides adaptors for various agent frameworks (LangGraph, CrewAI, etc.)
to work with GreenNode AgentBase Memory and Runtime services.
"""

__version__ = "0.1.0"

# Conditional imports for optional dependencies
__all__: list[str] = []

# LangGraph
try:
    from greennode_agent_bridge.langgraph.memory import (
        AgentBaseMemoryEvents,
        AgentBaseMemoryRecords,
    )

    __all__.extend(["AgentBaseMemoryEvents", "AgentBaseMemoryRecords"])
except ImportError as e:
    _langgraph_import_error = e

    def _missing_langgraph_dependencies_error(*args, **kwargs):
        raise ImportError(
            "LangGraph functionality requires optional dependencies. "
            "Install them with: pip install 'greennode-agent-bridge[langgraph]'"
        ) from _langgraph_import_error

    AgentBaseMemoryEvents = _missing_langgraph_dependencies_error  # type: ignore[assignment]
    AgentBaseMemoryRecords = _missing_langgraph_dependencies_error  # type: ignore[assignment]

# Agent Framework
try:
    from greennode_agent_bridge.agent_framework.memory import (
        AgentBaseHistoryProvider,
    )

    __all__.append("AgentBaseHistoryProvider")
except ImportError as e:
    _agent_framework_import_error = e

    def _missing_agent_framework_dependencies_error(*args, **kwargs):
        raise ImportError(
            "Agent Framework functionality requires optional dependencies. "
            "Install them with: pip install 'greennode-agent-bridge[agent-framework]'"
        ) from _agent_framework_import_error

    AgentBaseHistoryProvider = _missing_agent_framework_dependencies_error  # type: ignore[assignment]
