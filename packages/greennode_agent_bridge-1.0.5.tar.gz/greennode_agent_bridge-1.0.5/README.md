# GreenNode Agent Bridge

A bridge package for connecting multiple agent frameworks (LangGraph, CrewAI, Microsoft Agent Framework, etc.) with [GreenNode AgentBase](https://github.com/vngcloud/greennode-agentbase). Use your preferred agent framework while persisting state and memory in AgentBase Memory and Runtime services.

## Features

- **Framework adaptors** – Integrate agent frameworks with GreenNode AgentBase Memory and Runtime.
- **Optional extras** – Install only the frameworks you use; extras are isolated so installing one does not pull in others.
- **LangGraph support** – First-class support for LangGraph with:
  - **AgentBaseMemoryEvents** – A `BaseCheckpointSaver` that persists LangGraph checkpoints as events in AgentBase Memory.
  - **AgentBaseMemoryRecords** – A `BaseStore` that saves chat messages as conversational events and retrieves memories via semantic search (embedding and processing run in AgentBase Memory).

## Requirements

- Python 3.10+
- [GreenNode AgentBase](https://github.com/vngcloud/greennode-agentbase) (core dependency)

## Installation

**Base package** (AgentBase only; no framework adaptors):

```bash
pip install greennode-agent-bridge
```

**With LangGraph support**:

```bash
pip install "greennode-agent-bridge[langgraph]"
```

Other extras (e.g. CrewAI) may be added in future releases. Installing one extra does not install packages from other extras.

## Usage

### LangGraph checkpoint and store

When the `[langgraph]` extra is installed, you can use AgentBase Memory as a checkpoint saver and as a store for conversation and memory:

```python
from greennode_agent_bridge import AgentBaseMemoryEvents, AgentBaseMemoryRecords

# Checkpoint saver for LangGraph (persists graph state to AgentBase Memory)
checkpointer = AgentBaseMemoryEvents(
    memory_id="your-memory-id",
    # optional: memory_client=client,
)

# Store for chat messages and semantic memory (saves events, retrieves via AgentBase)
store = AgentBaseMemoryRecords(
    memory_id="your-memory-id",
)

# Use with your LangGraph graph
# graph = ... .compile(checkpointer=checkpointer)
# app with store for memory operations
```

Configure `memory_id` (and optionally credentials/client) according to your [AgentBase Memory](https://github.com/vngcloud/greennode-agentbase) setup.

### Without optional dependencies

If you import LangGraph types without installing the `[langgraph]` extra, the package raises an error that tells you to install `greennode-agent-bridge[langgraph]`.

## Development

- **Lint/format:** [Ruff](https://docs.astral.sh/ruff/)
- **Type checking:** [mypy](https://mypy-lang.org/)
- **Tests:** [pytest](https://pytest.org/)

With [uv](https://docs.astral.sh/uv/):

```bash
uv sync --group dev --group build
uv run ruff check src
uv run pytest
```

## License

Apache-2.0. See [LICENSE](LICENSE) for details.

## Links

- [Homepage](https://github.com/vngcloud/greennode-agent-bridge)
- [Bug tracker](https://github.com/vngcloud/greennode-agent-bridge/issues)
- [GreenNode AgentBase](https://github.com/vngcloud/greennode-agentbase)
