import setuptools

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setuptools.setup(
    name="xsdk",
    version="1.0.2",
    author="HenryWuu",
    author_email="henrywuu@qq.com",
    description="Python通用开发工具包",
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.9",
    install_requires=[
        "arrow>=0.15",
        "requests>=2.27",
    ],
    extras_require={
        "mysql": [
            "PyMySQL>=1.0",
            "mysql-connector-python>=8.0",
            "DBUtils>=3.0",
        ],
        "redis": [
            "redis>=3.0",
        ],
        "excel": [
            "openpyxl>=3.1",
            "xlrd>=2.0",
            "pandas>=2.0",
        ],
        "chart": [
            "matplotlib>=3.5",
        ],
        "cos": [
            "cos-python-sdk-v5>=1.9",
        ],
        "spider": [
            "beautifulsoup4>=4.10",
        ],
        "all": [
            "PyMySQL>=1.0",
            "mysql-connector-python>=8.0",
            "DBUtils>=3.0",
            "redis>=3.0",
            "openpyxl>=3.1",
            "xlrd>=2.0",
            "pandas>=2.0",
            "matplotlib>=3.5",
            "cos-python-sdk-v5>=1.9",
            "beautifulsoup4>=4.10",
        ],
    },
)
