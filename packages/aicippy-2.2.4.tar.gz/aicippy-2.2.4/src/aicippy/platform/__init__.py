"""
AiVibe universal platform integration for AiCippy.

Provides HTTP clients for the centralized platform API (api.aivibe.cloud)
and app-specific API (api.aicippy.com). All tenant/plan/credit management
via platform API, persistent data in PostgreSQL at db.aivibe.cloud.
"""

from __future__ import annotations

from aicippy.platform.app_client import AppClient
from aicippy.platform.client import PlatformClient, get_platform_client, reset_platform_client
from aicippy.platform.models import PlatformSession, TenantInfo, TenantRole, TenantStatus
from aicippy.platform.tenant_context import TenantContext

__all__ = [
    "AppClient",
    "PlatformClient",
    "PlatformSession",
    "get_platform_client",
    "reset_platform_client",
    "TenantContext",
    "TenantInfo",
    "TenantRole",
    "TenantStatus",
]
