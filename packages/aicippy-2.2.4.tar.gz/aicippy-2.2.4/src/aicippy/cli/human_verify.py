"""
Human Verification Module for AiCippy CLI.

Prevents automated/robot access by:
- Detecting automation environments (CI/CD, scripts, non-TTY)
- Presenting random puzzle questions requiring human judgment
- Timing-based detection of automated responses
"""

from __future__ import annotations

import os
import random
import sys
import time
from dataclasses import dataclass
from typing import Final

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.text import Text

from aicippy.cli.themes import (
    BRAND_ACCENT,
    BRAND_ERROR,
    BRAND_INFO,
    BRAND_SUCCESS,
    BRAND_WARNING,
)
from aicippy.utils.logging import get_logger

logger = get_logger(__name__)

# Minimum response time in seconds (humans need time to read and respond)
MIN_HUMAN_RESPONSE_TIME: Final[float] = 1.5

# Maximum response time (to prevent timeout-based bypasses)
MAX_RESPONSE_TIME: Final[float] = 60.0


@dataclass
class VerificationResult:
    """Result of human verification."""

    is_human: bool
    reason: str
    response_time: float = 0.0
    automation_detected: bool = False


# Puzzle questions with correct answers (True = Yes, False = No)
# These require human judgment and common sense
PUZZLE_QUESTIONS: Final[list[tuple[str, bool]]] = [
    # Simple logic puzzles
    ("Is the sky typically blue during a clear day?", True),
    ("Can fish naturally fly through the air?", False),
    ("Is water wet?", True),
    ("Do birds have four legs?", False),
    ("Is ice cold to touch?", True),
    ("Can humans breathe underwater without equipment?", False),
    ("Does the sun rise in the east?", True),
    ("Is a circle a type of square?", False),
    ("Do trees have leaves or needles?", True),
    ("Can you see in complete darkness?", False),
    ("Is 2 + 2 equal to 4?", True),
    ("Is 10 greater than 100?", False),
    ("Is half of 20 equal to 10?", True),
    ("Is 7 an even number?", False),
    ("Is zero a positive number?", False),
    # Common knowledge
    ("Is coffee typically served hot?", True),
    ("Do penguins live in the Sahara Desert?", False),
    ("Is English a language?", True),
    ("Can you hear sounds in outer space?", False),
    ("Is pizza a type of food?", True),
    ("Do cars run on water?", False),
    ("Is the Earth round?", True),
    ("Is water made of hydrogen and oxygen?", True),
    # Reverse psychology / tricky
    ("Is this question asking for a 'Yes' or 'No' answer?", True),
    ("Does the Earth orbit the Sun?", True),
    ("Is ice colder than boiling water?", True),
    ("Do humans need oxygen to survive?", True),
    ("Is silence a type of sound?", False),
    # Time/context aware
    ("Are you currently using a computer or device?", True),
    ("Is this a CLI (command-line interface) tool?", True),
    ("Are you a human being?", True),
]

# Environment variables that indicate automation
AUTOMATION_ENV_VARS: Final[list[str]] = [
    "CI",
    "CONTINUOUS_INTEGRATION",
    "BUILD_NUMBER",
    "BUILD_ID",
    "JENKINS_URL",
    "TRAVIS",
    "CIRCLECI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "BITBUCKET_BUILD_NUMBER",
    "AUTOMATED",
    "AUTOMATION",
    "BOT",
    "ROBOT",
    "HEADLESS",
    "PUPPETEER",
    "SELENIUM",
    "PLAYWRIGHT",
    "CYPRESS",
    "TF_BUILD",  # Azure DevOps
    "TEAMCITY_VERSION",
    "BUILDKITE",
    "DRONE",
    "CODEBUILD_BUILD_ID",  # AWS CodeBuild
]


def is_tty() -> bool:
    """Check if running in an interactive terminal."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def detect_automation_environment() -> tuple[bool, str]:
    """
    Detect if running in an automated/CI environment.

    All automation checks disabled — always returns no automation.

    Returns:
        Tuple of (is_automated, reason). Always (False, "No automation detected").
    """
    return False, "No automation detected"


def get_random_puzzle() -> tuple[str, bool]:
    """Get a random puzzle question and its correct answer."""
    return random.choice(PUZZLE_QUESTIONS)  # noqa: S311 -- not used for security/cryptography


def verify_human_response(
    _question: str,
    correct_answer: bool,
    user_answer: bool,
    response_time: float,
) -> VerificationResult:
    """
    Verify if the response appears to be from a human.

    Args:
        question: The puzzle question asked.
        correct_answer: The correct answer.
        user_answer: The user's answer.
        response_time: Time taken to respond in seconds.

    Returns:
        VerificationResult with verification status.
    """
    # Check if answer is correct
    if user_answer != correct_answer:
        return VerificationResult(
            is_human=False,
            reason="Incorrect answer to verification question",
            response_time=response_time,
        )

    # Check response time - too fast indicates automation
    if response_time < MIN_HUMAN_RESPONSE_TIME:
        return VerificationResult(
            is_human=False,
            reason=f"Response too fast ({response_time:.2f}s) - possible automation",
            response_time=response_time,
            automation_detected=True,
        )

    # Check response time - too slow might indicate script with delays
    if response_time > MAX_RESPONSE_TIME:
        return VerificationResult(
            is_human=False,
            reason=f"Response timed out ({response_time:.2f}s)",
            response_time=response_time,
        )

    return VerificationResult(
        is_human=True,
        reason="Human verification passed",
        response_time=response_time,
    )


class HumanVerifier:
    """
    Verifies human users and blocks automated access.

    Features:
    - Environment-based automation detection
    - Random puzzle questions
    - Response timing analysis
    - Configurable retry limits
    """

    def __init__(
        self,
        console: Console | None = None,
        max_attempts: int = 3,
        skip_env_check: bool = False,
    ) -> None:
        """
        Initialize human verifier.

        Args:
            console: Rich console for output.
            max_attempts: Maximum verification attempts.
            skip_env_check: Skip environment automation check.
        """
        self.console = console or Console()
        self.max_attempts = max_attempts
        self.skip_env_check = skip_env_check
        self._verified = False
        self._verification_result: VerificationResult | None = None

    @property
    def is_verified(self) -> bool:
        """Check if user has been verified as human."""
        return self._verified

    def check_automation(self) -> VerificationResult | None:
        """No automation checks — always returns None."""
        return None

    def verify(self, force: bool = False) -> VerificationResult:
        """
        Perform human verification.

        All verification disabled — always returns verified.

        Args:
            force: Force verification even if already verified.

        Returns:
            VerificationResult always indicating human verified.
        """
        self._verified = True
        return VerificationResult(
            is_human=True,
            reason="Verification disabled — unrestricted access",
        )

    def _perform_verification_attempt(self, attempt: int) -> VerificationResult:
        """Verification disabled — returns pass-through."""
        return VerificationResult(is_human=True, reason="Verification disabled")


    def _show_automation_blocked(self, *args: object, **kwargs: object) -> None:
        """Verification disabled — no-op."""


    def _show_verification_success(self, *args: object, **kwargs: object) -> None:
        """Verification disabled — no-op."""


    def _show_verification_failure(
        self,
        result: VerificationResult,
        attempts_remaining: int,
    ) -> None:
        """Show failure message with retry option."""
        self.console.print(
            Panel(
                Text(
                    f"✗ Verification failed: {result.reason}\n\n"
                    f"Attempts remaining: {attempts_remaining}\n"
                    f"Please try again.",
                    style=BRAND_WARNING,
                ),
                border_style=BRAND_WARNING,
            )
        )

    def _show_final_failure(self, *args: object, **kwargs: object) -> None:
        """Verification disabled — no-op."""


def require_human_verification(
    console: Console | None = None,
    max_attempts: int = 3,
) -> bool:
    """
    Convenience function to require human verification.

    All verification disabled — always returns True.

    Args:
        console: Rich console for output.
        max_attempts: Maximum verification attempts.

    Returns:
        Always True.
    """
    return True


def is_likely_automated() -> bool:
    """
    Quick check if running in an automated environment.

    All checks disabled — always returns False.

    Returns:
        Always False.
    """
    return False
