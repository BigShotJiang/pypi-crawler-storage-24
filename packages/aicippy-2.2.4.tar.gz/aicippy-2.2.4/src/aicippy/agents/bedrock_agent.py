"""
Bedrock Agent client for AiCippy.

Invokes the odin Bedrock Agent via invoke_agent API with streaming support.
All AI responses flow through the Bedrock Agent (not raw invoke_model).
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Final

import boto3
from botocore.config import Config

from aicippy.config import get_settings
from aicippy.utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)

# Bedrock Agent IDs — odin supervisor agent
ODIN_AGENT_ID: Final[str] = "CACLS9AC1J"
ODIN_AGENT_ALIAS_ID: Final[str] = "Y32URLZGJE"  # prod alias

# Timeouts
# No timeout limits — let the agent complete fully
AGENT_READ_TIMEOUT: Final[int] = 900
AGENT_CONNECT_TIMEOUT: Final[int] = 30


def _clean_agent_response(text: str) -> str:
    """Strip tool call artifacts leaked by the Bedrock agent orchestration.

    Removes patterns like:
    - AgentCommunication__sendMessage(recipient="User", content="...")
    - get__codeinterpreteraction__execute(...)
    - ", "recipient": "User"}}
    - </sources> tags
    - Trailing ") or "}) artifacts
    """
    import re

    # Remove AgentCommunication__sendMessage wrapper
    text = re.sub(
        r'AgentCommunication__sendMessage\s*\(\s*recipient\s*=\s*"User"\s*,\s*content\s*=\s*"',
        "",
        text,
    )

    # Remove tool call references like get__codeinterpreteraction__execute
    text = re.sub(r'get__\w+__\w+\s*\([^)]*\)', "", text)
    text = re.sub(
        r'(I will call the|To get the final answer, I will call the)\s+`?\w+__\w+`?\s+(function|tool)[^.]*\.',
        "",
        text,
    )

    # Remove trailing JSON artifacts from tool calls
    text = re.sub(r',\s*"recipient"\s*:\s*"User"\s*\}\s*\}?\s*$', "", text)

    # Remove </sources> tags
    text = re.sub(r'</sources>\s*', "", text)

    # Remove trailing ") or "}) from tool call closures
    text = re.sub(r'"\s*\)\s*$', "", text)
    text = re.sub(r'"\s*\}\s*\)\s*$', "", text)

    return text.strip()


class BedrockAgentClient:
    """Client for invoking odin Bedrock Agent with streaming."""

    def __init__(
        self,
        agent_id: str | None = None,
        agent_alias_id: str | None = None,
        session_id: str | None = None,
    ) -> None:
        settings = get_settings()
        self._agent_id = agent_id or settings.bedrock_agent_id
        self._agent_alias_id = agent_alias_id or settings.bedrock_agent_alias_id
        self._session_id = session_id or self._generate_session_id()
        self._client: Any = None

    @staticmethod
    def _generate_session_id() -> str:
        import uuid
        return str(uuid.uuid4())[:12]

    def _get_client(self) -> Any:
        if self._client is None:
            settings = get_settings()
            config = Config(
                read_timeout=AGENT_READ_TIMEOUT,
                connect_timeout=AGENT_CONNECT_TIMEOUT,
                retries={"max_attempts": 2, "mode": "adaptive"},
            )
            session_kwargs: dict[str, Any] = {
                "region_name": settings.aws_region,
            }
            if settings.aws_profile:
                session_kwargs["profile_name"] = settings.aws_profile

            session = boto3.Session(**session_kwargs)
            self._client = session.client("bedrock-agent-runtime", config=config)
        return self._client

    async def invoke(
        self,
        input_text: str,
        on_token: Callable[[str], None] | None = None,
    ) -> str:
        """Invoke the odin agent and stream response tokens.

        Args:
            input_text: User message to send to the agent.
            on_token: Callback for each streamed text chunk.

        Returns:
            Complete response text.
        """
        import asyncio

        client = self._get_client()

        def _invoke_sync() -> str:
            response = client.invoke_agent(
                agentId=self._agent_id,
                agentAliasId=self._agent_alias_id,
                sessionId=self._session_id,
                inputText=input_text,
                sessionState={
                    "promptSessionAttributes": {
                        "max_output_tokens": "8192",
                        "response_style": "complete_and_detailed",
                    },
                },
            )

            # Buffer chunks and clean tool call artifacts before emitting
            full_response = ""
            _buffer = ""
            _tool_prefix_seen = False

            for event in response.get("completion", []):
                if "chunk" in event:
                    chunk_bytes = event["chunk"].get("bytes", b"")
                    if chunk_bytes:
                        text = chunk_bytes.decode("utf-8")
                        _buffer += text

                        # Detect and strip tool call prefix at start of response
                        if not _tool_prefix_seen:
                            import re as _re
                            # Check if buffer contains the full tool call prefix
                            if 'content="' in _buffer:
                                _buffer = _re.sub(
                                    r'^.*?AgentCommunication__sendMessage\s*\(\s*recipient\s*=\s*"User"\s*,\s*content\s*=\s*"',
                                    "",
                                    _buffer,
                                    count=1,
                                )
                                _tool_prefix_seen = True
                            elif len(_buffer) > 200:
                                # No tool prefix found — emit as-is
                                _tool_prefix_seen = True

                            # Don't emit yet if we haven't resolved the prefix
                            if not _tool_prefix_seen:
                                continue

                        # Emit the buffered/cleaned text
                        to_emit = _buffer
                        _buffer = ""
                        full_response += to_emit
                        if on_token and to_emit:
                            on_token(to_emit)

            # Flush remaining buffer
            if _buffer:
                full_response += _buffer
                if on_token and _buffer:
                    on_token(_buffer)

            # Final cleanup of the complete response
            full_response = _clean_agent_response(full_response)
            return full_response

        # Run blocking boto3 call in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _invoke_sync)

    def close(self) -> None:
        """Close the client."""
        self._client = None

    @property
    def session_id(self) -> str:
        return self._session_id
