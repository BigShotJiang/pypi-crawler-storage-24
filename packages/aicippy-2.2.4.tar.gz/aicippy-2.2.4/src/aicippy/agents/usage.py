"""
Token usage tracking for AiCippy.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class AgentUsageStat:
    """Usage statistics for a single agent."""

    agent_type: str
    model: str
    total_tokens: int


@dataclass(slots=True)
class UsageStats:
    """Token usage statistics."""

    session_input: int = 0
    session_output: int = 0
    today_input: int = 0
    today_output: int = 0
    month_input: int = 0
    month_output: int = 0
    per_agent: list[AgentUsageStat] = field(default_factory=list)

    @property
    def session_total(self) -> int:
        """Total session tokens."""
        return self.session_input + self.session_output

    @property
    def today_total(self) -> int:
        """Total tokens today."""
        return self.today_input + self.today_output

    @property
    def month_total(self) -> int:
        """Total tokens this month."""
        return self.month_input + self.month_output


async def get_usage_stats() -> UsageStats:
    """Retrieve token usage statistics from the platform API.

    Returns zero-value stats when the platform API is unreachable.
    """
    from aicippy.utils.logging import get_logger

    logger = get_logger(__name__)

    try:
        from aicippy.platform.client import get_platform_client

        client = get_platform_client()
        data = await client.get_usage()
        per_agent = [
            AgentUsageStat(
                agent_type=a.get("agent_type", "unknown"),
                model=a.get("model", "unknown"),
                total_tokens=a.get("total_tokens", 0),
            )
            for a in data.get("per_agent", [])
        ]
        return UsageStats(
            session_input=data.get("session_input", 0),
            session_output=data.get("session_output", 0),
            today_input=data.get("today_input", 0),
            today_output=data.get("today_output", 0),
            month_input=data.get("month_input", 0),
            month_output=data.get("month_output", 0),
            per_agent=per_agent,
        )
    except Exception as exc:
        logger.debug("usage_stats_fallback_local", reason=str(exc))
        return UsageStats()
