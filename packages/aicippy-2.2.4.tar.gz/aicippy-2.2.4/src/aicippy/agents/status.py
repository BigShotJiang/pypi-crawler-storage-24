"""
Agent status tracking for AiCippy.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class AgentInfo:
    """Information about a single agent."""

    id: str
    type: str
    status: str
    progress: int
    message: str = ""


@dataclass(slots=True)
class StatusInfo:
    """Overall status information."""

    session_id: str | None = None
    connected: bool = False
    active_agents: int = 0
    total_tokens: int = 0
    agents: list[AgentInfo] = field(default_factory=list)


async def get_agent_status() -> StatusInfo:
    """Retrieve current agent status from the platform API.

    Returns local session state when the platform API is unreachable.
    """
    from aicippy.utils.logging import get_logger

    logger = get_logger(__name__)

    try:
        from aicippy.platform.client import get_platform_client

        client = get_platform_client()
        data = await client.get_status()
        agents = [
            AgentInfo(
                id=a.get("id", ""),
                type=a.get("type", "unknown"),
                status=a.get("status", "idle"),
                progress=a.get("progress", 0),
                message=a.get("message", ""),
            )
            for a in data.get("agents", [])
        ]
        return StatusInfo(
            session_id=data.get("session_id"),
            connected=data.get("connected", False),
            active_agents=data.get("active_agents", 0),
            total_tokens=data.get("total_tokens", 0),
            agents=agents,
        )
    except Exception as exc:
        logger.debug("agent_status_fallback_local", reason=str(exc))
        return StatusInfo()
