import os
from typing import Any

import requests

from ... import auth


class ApiError(Exception):
    pass


class Client:
    _class_reasoner = None

    def __init__(
        self,
        reasoner: str | None = None,
        api_key: str | None = None,
        scheme: str | None = None,
        host: str | None = None,
        api_version: str | None = None,
        direct: bool | None = None,
    ):
        self._reasoner = reasoner or self._class_reasoner
        if self._reasoner is None:
            raise ValueError("Please provide a reasoner")
        self._direct = (
            direct
            if direct is not None
            else os.getenv("IMANDRA_REASONER_DIRECT", "0").lower()
            in {"1", "true", "yes"}
        )
        self._config = auth.Config(
            api_key=api_key, scheme=scheme, host=host, api_version=api_version
        )

    def eval(self, input: str, config: str | None = None) -> Any:
        headers = self._config.get_headers()
        base_url = self._config.get_url(direct=self._direct)
        url = (
            f"{base_url}/eval"
            if self._direct
            else f"{base_url}/reasoners/{self._reasoner}/eval"
        )

        json = {"input": input}
        if config:
            json["config"] = config

        response = requests.post(url, headers=headers, json=json)

        if response.status_code != 200:
            raise ApiError(response)

        # Check if response is binary (zip file)
        content_type = response.headers.get("content-type", "")
        if "application/zip" in content_type:
            # Return both content and headers so we can extract filename
            return {"content": response.content, "headers": response.headers}

        return response.json()


try:
    from aiohttp import ClientSession

    class AsyncClient:
        _class_reasoner = None

        def __init__(
            self,
            session: ClientSession,
            reasoner: str | None = None,
            api_key: str | None = None,
            scheme: str | None = None,
            host: str | None = None,
            api_version: str | None = None,
            direct: bool | None = None,
        ):
            self._session = session
            self._reasoner = reasoner or self._class_reasoner
            if self._reasoner is None:
                raise ValueError("Please provide a reasoner")

            # this is for making requests to reasoners spun up locally with
            # run.sh in iu-reasoners
            self._direct = (
                direct
                if direct is not None
                else os.getenv("IMANDRA_REASONER_DIRECT", "0").lower()
                in {"1", "true", "yes"}
            )

            self._config = auth.Config(
                api_key=api_key, scheme=scheme, host=host, api_version=api_version
            )

        async def eval(self, input: str, config: str | None = None):
            headers = self._config.get_headers()
            base_url = self._config.get_url(direct=self._direct)
            url = (
                f"{base_url}/eval"
                if self._direct
                else f"{base_url}/reasoners/{self._reasoner}/eval"
            )

            json = {"input": input}
            if config:
                json["config"] = config

            async with await self._session.post(
                url=url, json=json, headers=headers
            ) as resp:
                if resp.status != 200:
                    raise ApiError(resp)

                # Check if response is binary (zip file)
                content_type = resp.headers.get("content-type", "")
                if "application/zip" in content_type:
                    # Return both content and headers so we can extract filename
                    content = await resp.read()
                    return {"content": content, "headers": resp.headers}

                return await resp.json(content_type=None)
except ImportError:
    pass
