from argparse import ArgumentParser
from typing import Protocol


class SubParsers(Protocol):
    def add_parser(self, name: str) -> ArgumentParser: ...
