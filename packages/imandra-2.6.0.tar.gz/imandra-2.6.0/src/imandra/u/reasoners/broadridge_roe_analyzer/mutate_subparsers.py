import base64
import os
import re
from typing import Protocol, runtime_checkable

from ..subparsers import SubParsers


@runtime_checkable
class Gettable(Protocol):
    def get(self, key: str, default: str) -> str: ...


def f(parser_reasoners_subparsers: SubParsers):
    parser_br_roe = parser_reasoners_subparsers.add_parser("broadridge_roe_analyzer")

    # this is just a type hint for the arguments added to argparse
    # make sure to keep them in sync!
    class Args(Protocol):
        zip_file: str

    parser_br_roe.add_argument("zip_file", help="Path to ZIP file to analyze")

    def call_broadridge_roe_analyzer(args: Args):
        from . import broadridge_roe_analyzer

        client = broadridge_roe_analyzer.Client()

        # Read ZIP file and base64-encode it for the reasoner API
        if args.zip_file:
            try:
                with open(args.zip_file, "rb") as f:
                    zip_bytes = f.read()
                encoded_input = base64.b64encode(zip_bytes).decode("ascii")
            except FileNotFoundError:
                print(f"Error: ZIP file not found: {args.zip_file}")
                return
            except Exception as e:
                print(f"Error reading ZIP file: {e}")
                return
        else:
            print("Error: ZIP file path is required.")
            return

        # Allow direct /eval mode for local servers by honoring IMANDRA_REASONER_DIRECT.
        result = client.eval(input=encoded_input)

        # Handle binary (zip file) response
        if (
            isinstance(result, dict)
            and "content" in result
            and "headers" in result
            and isinstance(result["headers"], Gettable)
            and isinstance(result["content"], bytes)
        ):
            content = result["content"]
            headers: Gettable = result["headers"]  # pyright: ignore[reportUnknownVariableType]

            # Extract filename from Content-Disposition header
            content_disposition = headers.get("Content-Disposition", "")
            filename = None
            if content_disposition:
                # Parse filename from header like: attachment; filename="output.zip"
                match = re.search(r'filename="?([^"]+)"?', content_disposition)
                if match:
                    filename = match.group(1)

            # Fallback to generated filename if not found in header
            if not filename:
                input_basename = (
                    os.path.splitext(os.path.basename(args.zip_file))[0]
                    if args.zip_file
                    else "output"
                )
                filename = f"{input_basename}_result.zip"

            with open(filename, "wb") as f:
                f.write(content)
            print(f"Results saved to: {filename}")
        else:
            print(result)  # pyright: ignore[reportUnknownArgumentType]

    parser_br_roe.set_defaults(run=call_broadridge_roe_analyzer)
