from argparse import Namespace

from .broadridge_roe_analyzer import (
    mutate_subparsers as add_broadridge_roe_analyzer_subparsers,
)
from .subparsers import SubParsers


def mutate_subparsers(subparsers: SubParsers) -> None:
    parser_reasoners = subparsers.add_parser("reasoners")

    def show_help(_: Namespace) -> None:
        parser_reasoners.print_help()

    parser_reasoners.set_defaults(run=show_help)

    parser_reasoners_subparsers = parser_reasoners.add_subparsers()
    add_broadridge_roe_analyzer_subparsers.f(parser_reasoners_subparsers)
    return
