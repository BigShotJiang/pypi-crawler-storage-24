# fabric-notebook-compliance

Best practices compliance checker for Microsoft Fabric notebooks.

## Installation

```bash
pip install fabric-notebook-compliance
```

## Quick Start

```python
from fabric_notebook_compliance import check_compliance

# Check all notebooks in a workspace
results = check_compliance(workspace_id="your-workspace-guid")
results.summary()

# Get pandas DataFrame
df = results.to_dataframe()

# Post to Teams
results.post_to_teams("https://your-webhook-url")
```

## Usage

```python
# Check single notebook
results = check_compliance(workspace_id="...", notebook_name="MyNotebook")

# Check specific folders
results = check_compliance(workspace_id="...", folder_filter=["FACT_ARR", "DIM_TSIOU"])
```

## Compliance Checks (9 total)

| Check | Description |
|-------|-------------|
| Markdown First | First cell should be markdown |
| Purpose | Document notebook purpose |
| Input Params | Document inputs |
| Output Tables | Document outputs |
| Change History | Version tracking |
| Imports Grouped | All imports at top |
| Snake Case | Use snake_case naming |
| Minimal Expensive Ops | Limit collect(), toPandas() |
| No Hardcoding | No hardcoded values |

## Requirements

- Must run inside Microsoft Fabric notebook
- Workspace access to notebooks being checked

## License

MIT
