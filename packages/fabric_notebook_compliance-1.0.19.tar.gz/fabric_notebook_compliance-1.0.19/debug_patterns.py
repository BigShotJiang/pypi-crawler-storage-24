import re

# Test individual patterns against specific test cases
test_cases = [
    (".filter(col(\"count\") != 0)", r'\.filter\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*!=\s*-?\d+\s*\)', "filter_col_neq_numeric"),
    (".where(trim(lower(col(\"region\"))) == \"east\")", r'\.where\s*\(\s*trim\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "where_trim_lower_col_eq_string"),
    (".when(col(\"type\") == \"N/A\", -1)", r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*[\'"][^\'"]+[\'"][^)]*\)', "when_col_eq_string"),
    (".when(col(\"priority\") == 1, \"High\")", r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*-?\d+[^)]*\)', "when_col_eq_numeric"),
    ('.isin(["v1", "v2"])', r'\.isin\s*\(\s*\[\s*[\'"][^\'"]+[\'"](?:\s*,\s*[\'"][^\'"]+[\'"])*\s*\]', "isin_string_list"),
    ('.isin([1, 2, 3])', r'\.isin\s*\(\s*\[\s*-?\d+(?:\s*,\s*-?\d+)*\s*\]', "isin_numeric_list"),
    ('.isin("a", "b")', r'\.isin\s*\(\s*[\'"][^\'"]+[\'"](?:\s*,\s*[\'"][^\'"]+[\'"])*\s*\)', "isin_string_args"),
    ('.isin(10, 20)', r'\.isin\s*\(\s*-?\d+(?:\s*,\s*-?\d+)*\s*\)', "isin_numeric_args"),
    ('col("region").isin(["US"])', r'col\s*\([\'"][^\'"]+[\'"]\s*\)\.isin\s*\([^)]+\)', "col_isin_general"),    
    ('lower(col("c")).isin(["usa"])', r'lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\.isin\s*\([^)]+\)', "lower_col_isin"),
]

print("Testing individual patterns:\n")
for test_str, pattern, name in test_cases:
    try:
        compiled = re.compile(pattern, re.IGNORECASE)
        match = compiled.search(test_str)
        status = "MATCH" if match else "NO MATCH"
        matched_text = match.group()[:50] if match else ""
        print(f"{status:8} | {name:30} | {test_str[:40]}")
        if match:
            print(f"         | Matched: {matched_text}")
    except re.error as e:
        print(f"ERROR    | {name:30} | Regex error: {e}")
