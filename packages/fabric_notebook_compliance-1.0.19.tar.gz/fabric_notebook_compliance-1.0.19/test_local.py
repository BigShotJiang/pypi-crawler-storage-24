"""Test the package locally."""
import re

# Test patterns directly
test_cases = [
    ("df.filter(col('status') == 'active')", "filter"),
    ("df.where(F.col('year') == '2024')", "where"),
    (".isin(['A', 'B', 'C'])", "isin"),
    ("lit('hardcoded')", "lit"),
    ("12345678-1234-1234-1234-123456789abc", "GUID"),
]

# Test with raw patterns
patterns = [
    (r"\.filter\s*\([^)]*==\s*['\"][^'\"]+['\"]", "filter"),
    (r"\.where\s*\([^)]*==\s*['\"][^'\"]+['\"]", "where"),
    (r"\.isin\s*\(\s*\[[^\]]*['\"][^'\"]+['\"]", "isin"),
    (r"lit\s*\(\s*['\"][^'\"]+['\"]\s*\)", "lit"),
    (r"['\"][0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}['\"]", "GUID"),
]

print("Testing patterns locally:\n")

for code, name in test_cases:
    print(f"Code: {code}")
    for pattern, pname in patterns:
        try:
            compiled = re.compile(pattern, re.IGNORECASE)
            match = compiled.search(code)
            if match:
                print(f"  ✅ Matched by {pname}: {match.group()}")
        except Exception as e:
            print(f"  ❌ Error in {pname}: {e}")
    print()

# Test the actual package
print("\n" + "="*50)
print("Testing package import:")
print("="*50)
try:
    from fabric_notebook_compliance.patterns import COMPILED_PATTERNS
    print(f"Loaded {len(COMPILED_PATTERNS)} patterns")
    
    test_code = """
df.filter(col('status') == 'active')
df.where(F.col('year') == '2024')
values = ['A', 'B', 'C']
df.filter(col('type').isin(['X', 'Y']))
workspace_id = '12345678-1234-1234-1234-123456789abc'
lit('hardcoded_value')
"""
    from fabric_notebook_compliance.checker import check_hardcoded_values
    result = check_hardcoded_values(test_code)
    print(f"\nHardcoding check result:")
    print(f"  Found: {result['count']} issues")
    for f in result['findings']:
        print(f"  - {f}")
except Exception as e:
    print(f"Error: {e}")
