"""Hardcoding detection patterns."""
import re

HARDCODING_PATTERNS = [
    # .filter(col("status") == "Active"), .where(F.col("type") == "Partner")
    (r'\.(?:filter|where)\s*\([^)]*(?:col|F\.col)\s*\([^)]+\)\s*==\s*[\'"][^\'"]+[\'"]', "spark_filter_eq"),
    
    # .filter("status = 'Active'"), .where("type = 'Partner'")
    (r'\.(?:filter|where)\s*\(\s*[\'"][^\'\"]*=\s*[\'"][^\'"]+[\'"][^\'\"]*[\'"]', "spark_filter_sql"),
    
 # ==================== SPARK SQL PATTERNS ====================
    # SQL WHERE clauses: spark.sql("SELECT * FROM table WHERE status = 'Active'")
    (r'spark\.sql\s*\([^)]*WHERE[^)]*=\s*[\'"][^\'"]+[\'"]', "spark_sql_where_hardcoded"),
    
    # SQL WHERE with IN clause: spark.sql("SELECT * FROM table WHERE col IN ('a','b')")
    (r'spark\.sql\s*\([^)]*WHERE[^)]*IN\s*\([^)]*[\'"][^\'"]+[\'"]', "spark_sql_where_in_hardcoded"),
    
    # ==================== .filter() PATTERNS ====================
    # .filter(col("x") == "value")
    (r'\.filter\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "filter_col_eq_string"),
    
    # .filter(col("x") == 123)
    (r'\.filter\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*-?\d+\s*\)', "filter_col_eq_numeric"),
    
    # .filter(col("x") != "value")
    (r'\.filter\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*!=\s*[\'"][^\'"]+[\'"]', "filter_col_neq_string"),
    
    # .filter(col("x") != 123)
    (r'\.filter\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*!=\s*-?\d+\s*\)', "filter_col_neq_numeric"),
    
    # .filter(lower(col("x")) == "value")
    (r'\.filter\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "filter_lower_col_eq_string"),
    
    # .filter(trim(col("x")) == "value")
    (r'\.filter\s*\(\s*trim\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "filter_trim_col_eq_string"),
    
    # .filter(lower(trim(col("x"))) == "value")
    (r'\.filter\s*\(\s*lower\s*\(\s*trim\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "filter_lower_trim_col_eq_string"),
    
    # .filter(trim(lower(col("x"))) == "value")
    (r'\.filter\s*\(\s*trim\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "filter_trim_lower_col_eq_string"),
    
    # .filter("column == 'value'") - SQL string expression
    (r'\.filter\s*\(\s*[\'"][^\'"]+==[^"\']*[\'"][^\'"]+[\'"][^"\']*[\'"]\s*\)', "filter_sql_string_eq"),
    
    # .filter(col("x").isin(["value1", "value2"])) - with hardcoded values
    (r'\.filter\s*\(\s*(?:col|F\.col)\s*\([^)]+\)\.isin\s*\([^)]*[\'"][^\'"]+[\'"][^)]*\)\s*\)', "filter_with_isin"),
    
    # ==================== .where() PATTERNS ====================
    # .where(col("x") == "value")
    (r'\.where\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "where_col_eq_string"),
    
    # .where(col("x") == 123)
    (r'\.where\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*-?\d+\s*\)', "where_col_eq_numeric"),
    
    # .where(lower(col("x")) == "value")
    (r'\.where\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "where_lower_col_eq_string"),
    
    # .where(trim(lower(col("x"))) == "value")
    (r'\.where\s*\(\s*trim\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "where_trim_lower_col_eq_string"),
    
    # .where("column == 'value'") - SQL string expression
    (r'\.where\s*\(\s*[\'"][^\'"]+==[^"\']*[\'"][^\'"]+[\'"]', "where_sql_string_eq"),
    
    # ==================== .when() CONDITIONAL PATTERNS ====================
    # .when(col("x") == "value", result)
    (r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*[\'"][^\'"]+[\'"][^)]*\)', "when_col_eq_string"),
    
    # .when(col("x") == 123, result)
    (r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*==\s*-?\d+[^)]*\)', "when_col_eq_numeric"),
    
    # .when(col("x") != "value", result)
    (r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*!=\s*[\'"][^\'"]+[\'"][^)]*\)', "when_col_neq_string"),
    
    # .when(lower(col("x")) == "value", result)
    (r'\.when\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "when_lower_col_eq_string"),
    
    # .when(lower(trim(col("x"))) == "value", result)
    (r'\.when\s*\(\s*lower\s*\(\s*trim\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "when_lower_trim_col_eq_string"),
    
    # .when(trim(lower(col("x"))) == "value", result)
    (r'\.when\s*\(\s*trim\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\s*\)\s*==\s*[\'"][^\'"]+[\'"]', "when_trim_lower_col_eq_string"),
    
    # .when(col("x").isin(["value1", "value2"]), result) - with hardcoded values
    (r'\.when\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\.isin\s*\([^)]*[\'"][^\'"]+[\'"][^)]*\)', "when_col_isin"),
    
    # .when(lower(col("x")).isin(["value1"]), result) - with hardcoded values
    (r'\.when\s*\(\s*lower\s*\(\s*col\s*\([\'"][^\'"]+[\'"]\s*\)\s*\)\.isin\s*\([^)]*[\'"][^\'"]+[\'"][^)]*\)', "when_lower_col_isin"),
    
    # ==================== .isin() PATTERNS ====================
    # .isin(['value1', 'value2'])
    (r'\.isin\s*\(\s*\[\s*[\'"][^\'"]+[\'"](?:\s*,\s*[\'"][^\'"]+[\'"])*\s*\]', "isin_string_list"),
    
    # .isin([1, 2, 3])
    (r'\.isin\s*\(\s*\[\s*-?\d+(?:\s*,\s*-?\d+)*\s*\]', "isin_numeric_list"),
    
    # .isin('value1', 'value2') without brackets
    (r'\.isin\s*\(\s*[\'"][^\'"]+[\'"](?:\s*,\s*[\'"][^\'"]+[\'"])*\s*\)', "isin_string_args"),
    
    # .isin(1, 2, 3) without brackets
    (r'\.isin\s*\(\s*-?\d+(?:\s*,\s*-?\d+)*\s*\)', "isin_numeric_args"),
    
    # col("x").isin("value1", "value2") - with hardcoded string values
    (r'col\s*\([\'"][^\'"]+[\'"]\s*\)\.isin\s*\([^)]*[\'"][^\'"]+[\'"][^)]*\)', "col_isin_hardcoded"),
]

COMPILED_PATTERNS = []
for p, d in HARDCODING_PATTERNS:
    try:
        COMPILED_PATTERNS.append((re.compile(p, re.IGNORECASE), d))
    except re.error:
        pass
