from src.fabric_notebook_compliance.checker import check_hardcoded_values

test_code = """
# SPARK SQL
spark.sql("SELECT * FROM table WHERE status = 'Active'")
spark.sql("SELECT * FROM table WHERE col IN ('a','b','c')")

# FILTER patterns
.filter(col("status") == "Active")
.filter(col("count") == 123)
.filter(col("status") != "Inactive")
.filter(col("count") != 0)
.filter(lower(col("name")) == "john")
.filter(trim(col("code")) == "ABC")
.filter(lower(trim(col("field"))) == "test")
.filter(trim(lower(col("field"))) == "test2")
.filter("status == 'Active'")
.filter(col("RelativeYear").isin("CY", "CY-1", "CY-2"))

# WHERE patterns
.where(col("Type") == "ACR")
.where(col("id") == 999)
.where(lower(col("category")) == "sales")
.where(trim(lower(col("region"))) == "east")
.where("flag == 'Y'")

# WHEN patterns
.when(col("type") == "N/A", -1)
.when(col("type") == "NonP", 2)
.when(col("priority") == 1, "High")
.when(col("status") != "Closed", "Open")
.when(lower(col("type")) == "premium", 100)
.when(lower(trim(col("class"))) == "vip", 200)
.when(trim(lower(col("tier"))) == "gold", 300)
.when(col("cat").isin(["A", "B"]), "Grp")
.when(lower(col("seg")).isin(["ret"]), "Known")

# ISIN patterns
.isin(["v1", "v2"])
.isin([1, 2, 3])
.isin("a", "b")
.isin(10, 20)
col("region").isin(["US"])
lower(col("c")).isin(["usa"])
"""

r = check_hardcoded_values(test_code)
print(f"Found {r['count']} raw, {len(r['findings'])} unique:\n")
for i, f in enumerate(r['findings'], 1):
    print(f"{i:2}. {f[:85]}")

# Check which test lines weren't matched
print("\n--- UNMATCHED TEST CASES ---")
test_lines = [l.strip() for l in test_code.split('\n') if l.strip() and not l.strip().startswith('#')]
matched_snippets = [f.split(': ', 1)[1][:30] if ': ' in f else '' for f in r['findings']]
for line in test_lines:
    found = any(s in line for s in matched_snippets if s)
    if not found:
        print(f"  NOT MATCHED: {line[:80]}")
