from src.fabric_notebook_compliance.checker import check_hardcoded_values

test_code = """
# ===== SPARK SQL PATTERNS =====
spark.sql("SELECT * FROM table WHERE status = 'Active'")
spark.sql("SELECT * FROM table WHERE col IN ('a','b','c')")

# ===== .filter() PATTERNS =====
.filter(col("status") == "Active")
.filter(col("count") == 123)
.filter(col("status") != "Inactive")
.filter(col("count") != 0)
.filter(lower(col("name")) == "john")
.filter(trim(col("code")) == "ABC")
.filter(lower(trim(col("field"))) == "test")
.filter(trim(lower(col("field"))) == "test2")
.filter("status == 'Active'")
.filter(col("RelativeYear").isin("CY", "CY-1", "CY-2"))

# ===== .where() PATTERNS =====
.where(col("Type") == "ACR")
.where(col("id") == 999)
.where(lower(col("category")) == "sales")
.where(trim(lower(col("region"))) == "east")
.where("flag == 'Y'")

# ===== .when() CONDITIONAL PATTERNS =====
.when(col("F.AzureAdjustmentType") == "N/A", -1)
.when(col("F.AzureAdjustmentType") == "Non-payment", 2)
.when(col("priority") == 1, "High")
.when(col("status") != "Closed", "Open")
.when(lower(col("type")) == "premium", 100)
.when(lower(trim(col("class"))) == "vip", 200)
.when(trim(lower(col("tier"))) == "gold", 300)
.when(col("category").isin(["A", "B"]), "Group1")
.when(lower(col("segment")).isin(["retail", "corp"]), "Known")

# ===== .isin() PATTERNS =====
.isin(['value1', 'value2', 'value3'])
.isin([1, 2, 3, 4])
.isin('a', 'b', 'c')
.isin(10, 20, 30)
col("region").isin(['US', 'EU'])
lower(col("country")).isin(['usa', 'canada'])
"""

print("Testing all patterns...\n")
result = check_hardcoded_values(test_code)

print(f"Found {result['count']} unique hardcoded values:\n")
for f in result['findings']:
    print(f"  - {f}")
