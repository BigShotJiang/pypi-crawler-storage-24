"""
Setup wizard package.
"""
