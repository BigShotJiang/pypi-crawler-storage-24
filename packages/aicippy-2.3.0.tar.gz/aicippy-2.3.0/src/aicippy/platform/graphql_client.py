"""
GraphQL client for the AiVibe universal platform API (api.aivibe.cloud).

This client replaces the former REST client and interacts with the AppSync
GraphQL endpoint for all platform-related operations, including tenant
lookup, plan validation, and credit management.
"""

from __future__ import annotations

import logging
from typing import Any, ClassVar

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from aicippy.auth.keychain import KeychainStorage
from aicippy.config import get_settings
from aicippy.errors import AiCippyError, PlatformApiError

# Module-level logger
logger = logging.getLogger(__name__)

# --- GraphQL Queries and Mutations ---

# Fetches the user's active subscription for a specific product.
# Replaces the old `validate_plan` REST endpoint.
GET_ACTIVE_SUBSCRIPTION_QUERY = """
query GetActiveSubscription($productId: ID!) {
  activeSubscription(productId: $productId) {
    id
    status
    plan {
      id
      planCode
      planName
      features
    }
  }
}
"""

# Fetches the user's credit wallet for a specific product.
# Replaces the old `get_credits` REST endpoint.
GET_CREDIT_WALLET_QUERY = """
query GetCreditWallet($productId: ID!) {
  creditWallet(productId: $productId) {
    id
    balance
    currency
  }
}
"""

# Deducts credits from the user's wallet.
# Replaces the old `deduct_credits` REST endpoint.
USE_CREDITS_MUTATION = """
mutation UseCredits($input: UseCreditsInput!) {
  useCredits(input: $input) {
    id
    balance
  }
}
"""

# Tracks a generic analytics event.
# Replaces the old `report_usage` REST endpoint.
TRACK_ANALYTICS_EVENT_MUTATION = """
mutation TrackAnalyticsEvent($input: TrackEventInput!) {
  trackAnalyticsEvent(input: $input) {
    id
  }
}
"""


class GraphQLClient:
    """
    An asynchronous GraphQL client for the AiVibe Platform API.

    This client handles communication with the AppSync endpoint, including
    authentication, request execution, and error handling with retries.
    """

    _DEFAULT_HEADERS: ClassVar[dict[str, str]] = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    def __init__(self, token: str | None = None, api_url: str | None = None) -> None:
        """
        Initializes the GraphQL client.

        Args:
            token: The JWT authentication token. If not provided, it will be
                   loaded from the keychain.
            api_url: The platform API URL. If not provided, it's loaded from
                     settings.
        """
        settings = get_settings()
        self._api_url = api_url or settings.platform_api_url
        self._product_id = "aicippy"  # Assuming 'aicippy' is the product ID

        self._keychain = KeychainStorage()
        self._token = token or self._keychain.get_access_token()

        if not self._token:
            raise PlatformApiError(
                "Authentication token not found. Please log in first."
            )

        self._headers = self._DEFAULT_HEADERS.copy()
        self._headers["Authorization"] = f"Bearer {self._token}"

        self._http_client = httpx.AsyncClient(
            headers=self._headers,
            timeout=30.0,
        )
        logger.debug("GraphQLClient initialized for %s", self._api_url)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.NetworkError, httpx.TimeoutException)),
        reraise=True,
    )
    async def _execute_graphql(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Executes a GraphQL query or mutation.

        Args:
            query: The GraphQL query or mutation string.
            variables: A dictionary of variables for the operation.

        Returns:
            The JSON response data from the API.

        Raises:
            PlatformApiError: If the API returns an error or a non-200 status code.
        """
        payload = {"query": query, "variables": variables or {}}
        try:
            response = await self._http_client.post(self._api_url, json=payload)
            response.raise_for_status()

            response_json = response.json()
            if "errors" in response_json:
                error_details = response_json["errors"][0]
                msg = f"GraphQL API error: {error_details.get('message', 'Unknown error')}"
                logger.error(msg, extra={"error": error_details})
                raise PlatformApiError(msg)

            return response_json.get("data", {})

        except httpx.HTTPStatusError as e:
            msg = f"Platform API request failed: {e.response.status_code} {e.response.reason_phrase}"
            logger.error(msg, extra={"response_text": e.response.text})
            raise PlatformApiError(msg) from e
        except (httpx.NetworkError, httpx.TimeoutException) as e:
            msg = f"Platform API network error: {e}"
            logger.error(msg)
            raise PlatformApiError(msg) from e
        except Exception as e:
            msg = f"An unexpected error occurred during GraphQL execution: {e}"
            logger.exception(msg)
            raise AiCippyError(msg) from e

    async def validate_plan(self) -> dict[str, Any]:
        """
        Validates the user's current subscription plan.

        Returns:
            A dictionary containing the active subscription details.

        Raises:
            PlatformApiError: If the user has no active subscription or the API fails.
        """
        logger.debug("Validating plan for product ID: %s", self._product_id)
        variables = {"productId": self._product_id}
        data = await self._execute_graphql(GET_ACTIVE_SUBSCRIPTION_QUERY, variables)

        subscription = data.get("activeSubscription")
        if not subscription or subscription.get("status") != "ACTIVE":
            raise PlatformApiError("No active subscription found for this product.")

        return subscription

    async def get_credits(self) -> dict[str, Any]:
        """
        Fetches the user's current credit balance.

        Returns:
            A dictionary containing the credit wallet details.
        """
        logger.debug("Fetching credit wallet for product ID: %s", self._product_id)
        variables = {"productId": self._product_id}
        data = await self._execute_graphql(GET_CREDIT_WALLET_QUERY, variables)

        wallet = data.get("creditWallet")
        if not wallet:
            # Depending on business logic, we might want to create a wallet
            # or raise an error. For now, we raise.
            raise PlatformApiError("Credit wallet not found for this user.")

        return wallet

    async def deduct_credits(self, amount: int = 1) -> dict[str, Any]:
        """
        Deducts a specified number of credits from the user's wallet.

        Args:
            amount: The number of credits to deduct.

        Returns:
            The updated credit wallet information.
        """
        logger.debug("Deducting %d credits for product ID: %s", amount, self._product_id)
        variables = {
            "input": {
                "productId": self._product_id,
                "amount": amount,
                "description": "Usage from AiCippy CLI",
            }
        }
        data = await self._execute_graphql(USE_CREDITS_MUTATION, variables)
        return data.get("useCredits", {})

    async def report_usage(self, usage_data: dict[str, Any]) -> None:
        """
        Reports token usage and other analytics events.

        Args:
            usage_data: A dictionary of properties to include in the event.
        """
        logger.debug("Reporting usage event with data: %s", usage_data)
        variables = {
            "input": {
                "eventName": "cli_usage",
                "eventCategory": "ai_operation",
                "properties": usage_data,
            }
        }
        await self._execute_graphql(TRACK_ANALYTICS_EVENT_MUTATION, variables)

    async def close(self) -> None:
        """Closes the underlying HTTP client."""
        await self._http_client.aclose()
        logger.debug("GraphQLClient closed.")

    async def __aenter__(self) -> GraphQLClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        await self.close()

# Singleton instance management (similar to the old client)
_graphql_client_instance: GraphQLClient | None = None

def get_platform_client() -> GraphQLClient:
    """
    Get or create the module-level GraphQLClient singleton.
    This function acts as a factory and provides a single instance of the
    client throughout the application's lifecycle.
    """
    global _graphql_client_instance
    if _graphql_client_instance is None:
        try:
            _graphql_client_instance = GraphQLClient()
        except AiCippyError as e:
            logger.error("Failed to initialize GraphQLClient: %s", e)
            raise
    return _graphql_client_instance

def reset_platform_client() -> None:
    """
    Reset the module-level GraphQLClient singleton.
    This is useful for re-authentication or in testing scenarios.
    """
    global _graphql_client_instance
    _graphql_client_instance = None
    logger.debug("GraphQLClient instance has been reset.")
