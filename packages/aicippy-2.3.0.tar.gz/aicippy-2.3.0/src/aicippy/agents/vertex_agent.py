"""
Vertex AI Agent client for AiCippy.

Invokes a Gemini model on Vertex AI with streaming support.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aicippy.config import get_settings
from aicippy.utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

    import vertexai.generative_models as gen_models

logger = get_logger(__name__)


class VertexAgentClient:
    """Client for invoking Gemini on Vertex AI with streaming."""

    def __init__(self, model_id: str, session_id: str | None = None) -> None:
        settings = get_settings()
        self._project_id = settings.gcp_project_id
        self._region = settings.gcp_region
        self._model_id = model_id
        self._session_id = session_id or self._generate_session_id()
        self._model: gen_models.GenerativeModel | None = None

    @staticmethod
    def _generate_session_id() -> str:
        import uuid
        return str(uuid.uuid4())[:12]

    def _get_model(self) -> gen_models.GenerativeModel:
        if self._model is None:
            import vertexai
            from vertexai.generative_models import GenerativeModel

            vertexai.init(project=self._project_id, location=self._region)
            self._model = GenerativeModel(self._model_id)
        return self._model

    async def invoke(
        self,
        input_text: str,
        on_token: Callable[[str], None] | None = None,
    ) -> str:
        """Invoke the Gemini model and stream response tokens.

        Args:
            input_text: User message to send to the model.
            on_token: Callback for each streamed text chunk.

        Returns:
            Complete response text.
        """
        import asyncio

        model = self._get_model()

        def _invoke_sync() -> str:
            response = model.generate_content(input_text, stream=True)
            full_response = ""
            for chunk in response:
                if chunk.text:
                    full_response += chunk.text
                    if on_token:
                        on_token(chunk.text)
            return full_response

        # Run blocking SDK call in thread pool
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _invoke_sync)

    def close(self) -> None:
        """Close the client."""
        self._model = None

    @property
    def session_id(self) -> str:
        return self._session_id
