"""
Navigation menu configuration for NetBox SSL plugin.
"""

from netbox.plugins import PluginMenu, PluginMenuButton, PluginMenuItem

menu = PluginMenu(
    label="SSL Certificates",
    groups=(
        (
            "Certificates",
            (
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificate_list",
                    link_text="Certificates",
                    permissions=["netbox_ssl.view_certificate"],
                    buttons=(
                        PluginMenuButton(
                            link="plugins:netbox_ssl:certificate_add",
                            title="Add",
                            icon_class="mdi mdi-plus-thick",
                            permissions=["netbox_ssl.add_certificate"],
                        ),
                    ),
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificate_import",
                    link_text="Import Certificate",
                    permissions=["netbox_ssl.add_certificate"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificate_bulk_import",
                    link_text="Bulk Import (CSV/JSON)",
                    permissions=["netbox_ssl.add_certificate"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificateassignment_list",
                    link_text="Assignments",
                    permissions=["netbox_ssl.view_certificateassignment"],
                    buttons=(
                        PluginMenuButton(
                            link="plugins:netbox_ssl:certificateassignment_add",
                            title="Add",
                            icon_class="mdi mdi-plus-thick",
                            permissions=["netbox_ssl.add_certificateassignment"],
                        ),
                    ),
                ),
            ),
        ),
        (
            "Requests",
            (
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificatesigningrequest_list",
                    link_text="CSRs",
                    permissions=["netbox_ssl.view_certificatesigningrequest"],
                    buttons=(
                        PluginMenuButton(
                            link="plugins:netbox_ssl:certificatesigningrequest_add",
                            title="Add",
                            icon_class="mdi mdi-plus-thick",
                            permissions=["netbox_ssl.add_certificatesigningrequest"],
                        ),
                    ),
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:csr_import",
                    link_text="Import CSR",
                    permissions=["netbox_ssl.add_certificatesigningrequest"],
                ),
            ),
        ),
        (
            "Management",
            (
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificateauthority_list",
                    link_text="Certificate Authorities",
                    permissions=["netbox_ssl.view_certificateauthority"],
                    buttons=(
                        PluginMenuButton(
                            link="plugins:netbox_ssl:certificateauthority_add",
                            title="Add",
                            icon_class="mdi mdi-plus-thick",
                            permissions=["netbox_ssl.add_certificateauthority"],
                        ),
                    ),
                ),
            ),
        ),
        (
            "Insights",
            (
                PluginMenuItem(
                    link="plugins:netbox_ssl:analytics_dashboard",
                    link_text="Analytics Dashboard",
                    permissions=["netbox_ssl.view_certificate"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:compliance_report",
                    link_text="Compliance Report",
                    permissions=["netbox_ssl.view_certificate"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_ssl:certificate_map",
                    link_text="Certificate Map",
                    permissions=["netbox_ssl.view_certificate"],
                ),
            ),
        ),
    ),
    icon_class="mdi mdi-certificate",
)
