# React TypeScript SPA Example

Minimalna jednostronicowa aplikacja React (TypeScript) uruchamiana przez Markpact.

## Uruchomienie

```bash
markpact examples/react-typescript-spa/README.md
```

---

```json markpact:file path=package.json
{
  "name": "markpact-react-ts-spa",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/react": "^18.3.12",
    "@types/react-dom": "^18.3.1",
    "@vitejs/plugin-react": "^4.3.4",
    "typescript": "^5.7.2",
    "vite": "^6.0.7"
  }
}
```

```json markpact:file path=tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

```json markpact:file path=tsconfig.node.json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true,
    "strict": true
  },
  "include": ["vite.config.ts"]
}
```

```typescript markpact:file path=vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: Number(process.env.MARKPACT_PORT) || 3000,
    host: true,
  },
})
```

```tsx markpact:file path=src/main.tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

```tsx markpact:file path=src/App.tsx
import { useState } from 'react'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div style={{ padding: '2rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1>React + TypeScript SPA</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(c => c + 1)}>Increment</button>
      <button onClick={() => setCount(c => c - 1)} style={{ marginLeft: '0.5rem' }}>Decrement</button>
    </div>
  )
}

export default App
```

```html markpact:file path=index.html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>React TypeScript SPA</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

```bash markpact:run
# Ensure pnpm is in PATH
export PATH="${PNPM_HOME:-$HOME/.local/share/pnpm}:$PATH"
echo "PATH contains pnpm: $(command -v pnpm || echo 'not found')" > /tmp/pnpm_debug.log
# Prefer pnpm, fallback to npm, then yarn
if command -v pnpm >/dev/null 2>&1; then
  echo "Using pnpm" >> /tmp/pnpm_debug.log
  pnpm install && pnpm dev
elif command -v npm >/dev/null 2>&1; then
  echo "Using npm" >> /tmp/pnpm_debug.log
  npm install && npm run dev
elif command -v yarn >/dev/null 2>&1; then
  echo "Using yarn" >> /tmp/pnpm_debug.log
  yarn install && yarn dev
else
  echo "Error: No package manager found. Install pnpm, npm, or yarn." >> /tmp/pnpm_debug.log
  exit 1
fi
```

```text markpact:test http
GET / EXPECT 200
```
