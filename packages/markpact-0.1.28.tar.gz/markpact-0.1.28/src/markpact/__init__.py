"""Markpact – Executable Markdown Runtime"""

__version__ = "0.1.28"

from .converter import convert_markdown_to_markpact, ConversionResult
from .packer import pack_directory, PackResult, print_pack_report
from .parser import Block, parse_blocks
from .runner import run_cmd, ensure_venv
from .sandbox import Sandbox, find_free_port
from .syncer import (
    sync_readme, SyncResult, print_sync_report, list_tracked_paths, find_untracked_files,
    create_backup, list_backups, restore_backup,
)

# Optional LLM generator (requires litellm)
try:
    from .generator import generate_contract, GeneratorConfig, EXAMPLE_PROMPTS
    _HAS_LLM = True
except ImportError:
    _HAS_LLM = False
    generate_contract = None
    GeneratorConfig = None
    EXAMPLE_PROMPTS = {}

__all__ = [
    "Block",
    "parse_blocks",
    "run_cmd",
    "ensure_venv",
    "Sandbox",
    "find_free_port",
    "convert_markdown_to_markpact",
    "ConversionResult",
    "pack_directory",
    "PackResult",
    "print_pack_report",
    "sync_readme",
    "SyncResult",
    "print_sync_report",
    "list_tracked_paths",
    "find_untracked_files",
    "create_backup",
    "list_backups",
    "restore_backup",
    "generate_contract",
    "GeneratorConfig",
    "EXAMPLE_PROMPTS",
    "__version__",
]
