from __future__ import annotations

import functools
import logging
import mimetypes
import os
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Generator, Literal, TypedDict

import httpx

logger = logging.getLogger("manage_ai_sdk")

_DEFAULT_TIMEOUT = 10
_UPLOAD_TIMEOUT = 120
_ANALYTICS_SCHEMA_VERSION = 1

AnalyticsEventName = Literal[
    "user_logged_in",
    "automation_opened",
    "session_started",
    "question_asked",
    "answer_returned",
    "cta_clicked",
    "session_resolved",
    "session_unresolved",
    "session_ended",
]


class AnalyticsEvent(TypedDict, total=False):
    event_name: AnalyticsEventName
    schema_version: int
    actor_user_id: str
    session_id: str
    project_id: str
    channel: str
    question_id: str
    answer_id: str
    question_text_raw: str
    answer_text_raw: str
    question_category: str
    answer_source: str
    event_at: str
    event_props: dict[str, Any]


class ManageAI:
    """Low-level client for the Manage AI webhook API."""

    def __init__(
        self,
        url: str | None = None,
        api_key: str | None = None,
        timeout: int = _DEFAULT_TIMEOUT,
    ) -> None:
        self.url = (url or os.environ.get("MANAGE_AI_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("MANAGE_AI_KEY", "")
        self.timeout = timeout

        if not self.url:
            raise ValueError(
                "Manage AI URL not set. Pass url= or set MANAGE_AI_URL env var."
            )
        if not self.api_key:
            raise ValueError(
                "Manage AI API key not set. Pass api_key= or set MANAGE_AI_KEY env var."
            )

    def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            resp = httpx.post(
                f"{self.url}/api/v1/webhooks/runs",
                json=payload,
                headers={"X-API-Key": self.api_key},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            logger.warning("Failed to report to Manage AI: %s", exc)
            return {}

    def _post_event(self, automation_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            resp = httpx.post(
                f"{self.url}/api/v1/webhooks/events",
                json={"automation_id": automation_id, **payload},
                headers={"X-API-Key": self.api_key},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            logger.warning("Failed to send analytics event to Manage AI: %s", exc)
            return {}

    def start_run(
        self,
        automation_id: str,
        trigger: dict[str, Any] | None = None,
    ) -> str | None:
        """Report a run as started. Returns the run_id or None on failure."""
        result = self._post({
            "automation_id": automation_id,
            "status": "started",
            "trigger_event": trigger,
        })
        return result.get("run_id")

    def complete_run(
        self,
        automation_id: str,
        run_id: str | None,
        output: dict[str, Any] | None = None,
        duration_ms: int | None = None,
    ) -> None:
        """Report a run as completed successfully."""
        self._post({
            "automation_id": automation_id,
            "status": "success",
            "run_id": run_id,
            "output_event": output,
            "duration_ms": duration_ms,
        })

    def fail_run(
        self,
        automation_id: str,
        run_id: str | None,
        error: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        """Report a run as failed."""
        self._post({
            "automation_id": automation_id,
            "status": "failure",
            "run_id": run_id,
            "error_message": error,
            "duration_ms": duration_ms,
        })

    def track_event(
        self,
        automation_id: str,
        event_name: AnalyticsEventName,
        *,
        actor_user_id: str | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
        channel: str | None = None,
        question_id: str | None = None,
        answer_id: str | None = None,
        question_text_raw: str | None = None,
        answer_text_raw: str | None = None,
        question_category: str | None = None,
        answer_source: str | None = None,
        event_at: str | None = None,
        event_props: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send one canonical analytics event for automation dashboards."""
        payload: dict[str, Any] = {
            "event_name": event_name,
            "schema_version": _ANALYTICS_SCHEMA_VERSION,
            "event_at": event_at or datetime.now(timezone.utc).isoformat(),
        }
        optional_fields = {
            "actor_user_id": actor_user_id,
            "session_id": session_id,
            "project_id": project_id,
            "channel": channel,
            "question_id": question_id,
            "answer_id": answer_id,
            "question_text_raw": question_text_raw,
            "answer_text_raw": answer_text_raw,
            "question_category": question_category,
            "answer_source": answer_source,
            "event_props": event_props,
        }
        for key, value in optional_fields.items():
            if value is not None:
                payload[key] = value
        return self._post_event(automation_id, payload)

    def track_events(self, automation_id: str, events: list[AnalyticsEvent]) -> list[dict[str, Any]]:
        """Send multiple analytics events serially; returns each server response."""
        results: list[dict[str, Any]] = []
        for event in events:
            event_name = event.get("event_name")
            if not event_name:
                logger.warning("Skipping analytics event without event_name")
                continue
            payload = {
                **event,
                "schema_version": event.get("schema_version", _ANALYTICS_SCHEMA_VERSION),
                "event_at": event.get("event_at", datetime.now(timezone.utc).isoformat()),
            }
            results.append(self._post_event(automation_id, payload))
        return results

    def upload_file(self, automation_id: str, file_path: str) -> dict[str, Any]:
        """Upload a file to the dashboard. Returns metadata dict with url, filename, etc."""
        p = Path(file_path)
        if not p.is_file():
            logger.warning("Attachment not found, skipping: %s", file_path)
            return {}
        content_type = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        try:
            with open(p, "rb") as f:
                resp = httpx.post(
                    f"{self.url}/api/v1/webhooks/runs/upload",
                    files={"file": (p.name, f, content_type)},
                    data={"automation_id": automation_id},
                    headers={"X-API-Key": self.api_key},
                    timeout=_UPLOAD_TIMEOUT,
                )
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            logger.warning("Failed to upload attachment %s: %s", file_path, exc)
            return {}


def _upload_attachments(
    client: ManageAI,
    automation_id: str,
    paths: list[str],
) -> list[dict[str, Any]]:
    results = []
    for path in paths:
        meta = client.upload_file(automation_id, path)
        if meta:
            results.append(meta)
    return results


class _RunContext:
    """Context object available inside track_run / @automation."""

    def __init__(self) -> None:
        self.output: dict[str, Any] | None = None
        self.trigger: dict[str, Any] | None = None


@contextmanager
def track_run(
    automation_id: str,
    *,
    url: str | None = None,
    api_key: str | None = None,
    trigger: dict[str, Any] | None = None,
    attachments: list[str] | None = None,
) -> Generator[_RunContext, None, None]:
    """Context manager that reports a run lifecycle to the dashboard.

    Usage::

        with track_run("automation-id", attachments=["report.xlsx"]) as run:
            result = do_stuff()
            run.output = {"data": result}
    """
    client = ManageAI(url=url, api_key=api_key)
    ctx = _RunContext()
    ctx.trigger = trigger

    start = time.monotonic()
    run_id = client.start_run(automation_id, trigger=trigger)

    try:
        yield ctx
        elapsed = int((time.monotonic() - start) * 1000)

        output = ctx.output or {}
        if attachments:
            uploaded = _upload_attachments(client, automation_id, attachments)
            if uploaded:
                output = {**output, "attachments": uploaded}

        client.complete_run(
            automation_id, run_id, output=output or None, duration_ms=elapsed
        )
    except Exception:
        elapsed = int((time.monotonic() - start) * 1000)
        client.fail_run(
            automation_id,
            run_id,
            error=traceback.format_exc(),
            duration_ms=elapsed,
        )
        raise


def automation(
    automation_id: str,
    *,
    url: str | None = None,
    api_key: str | None = None,
    trigger: dict[str, Any] | None = None,
    attachments: list[str] | None = None,
) -> Callable:
    """Decorator that wraps a function with run tracking.

    Usage::

        @automation("automation-id", attachments=["output/report.xlsx"])
        def my_job():
            return {"sent": 5}
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with track_run(
                automation_id,
                url=url,
                api_key=api_key,
                trigger=trigger,
                attachments=attachments,
            ) as run:
                result = fn(*args, **kwargs)
                if isinstance(result, dict):
                    run.output = result
                elif result is not None:
                    run.output = {"result": result}
                return result

        return wrapper

    return decorator
