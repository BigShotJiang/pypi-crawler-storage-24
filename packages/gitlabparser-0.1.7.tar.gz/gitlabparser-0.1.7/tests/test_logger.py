import pytest
import os
import tempfile
import logging
import time
from GitlabParser import Logger

class TestLogger:
    def setup_method(self):
        """Сброс состояния перед каждым тестом"""
        Logger._instance = None
        Logger._current_logger = None

    def test_logger_singleton(self):
        """Тест синглтона - всегда один экземпляр"""
        logger1 = Logger()
        logger2 = Logger()
        assert logger1 is logger2

    def test_logger_default_filename(self):
        """Тест формирования имени файла по умолчанию"""
        logger = Logger()
        # В тестах имя файла будет содержать 'test_logger', а не 'GitlabParser'
        assert logger.log_file_default.endswith('.log')
        assert '_2026_' in logger.log_file_default  # Проверяем формат даты

    def test_get_logger_without_file(self):
        """Тест создания логгера без файла (только консоль)"""
        logger_instance = Logger()
        logger = logger_instance.get_logger(log_file="")
        
        assert logger is not None
        assert isinstance(logger, logging.Logger)
        
        # Проверяем, что нет файлового обработчика
        file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
        assert len(file_handlers) == 0

    def test_get_current_logger(self):
        """Тест получения текущего логгера"""
        logger_instance = Logger()
        created_logger = logger_instance.get_logger(log_file="")
        
        current = Logger.get_current_logger()
        assert current is created_logger

    def test_logger_verbose_format(self):
        """Тест verbose формата логов"""
        logger_instance = Logger()
        logger = logger_instance.get_logger(log_file="", verbose=True)
        
        # Проверяем, что формат содержит Debug информацию
        assert logger is not None

    def test_logger_writes_messages(self, caplog):
        """Тест записи сообщений"""
        logger_instance = Logger()
        logger = logger_instance.get_logger(log_file="")
        
        with caplog.at_level(logging.INFO):
            test_message = "Test log message"
            logger.info(test_message)
            
            # Проверяем, что сообщение появилось в логах
            assert test_message in caplog.text

    def test_logger_critical_exit(self):
        """Тест, что critical не вызывает exit (это делает Find)"""
        logger_instance = Logger()
        logger = logger_instance.get_logger(log_file="")
        
        # Просто проверяем, что метод существует и не падает
        logger.critical("Test critical message")
        assert True

    def test_logger_multiple_calls_same_logger(self):
        """Тест, что повторные вызовы get_logger возвращают тот же логгер"""
        logger_instance = Logger()
        logger1 = logger_instance.get_logger(log_file="test1.log")
        
        # Второй вызов с другим параметром - должен вернуть существующий логгер
        logger2 = logger_instance.get_logger(log_file="test2.log")
        
        assert logger1 is logger2  # Должны быть одним объектом

    def test_logger_different_instances_same_logger(self):
        """Тест, что разные экземпляры Logger возвращают один логгер"""
        logger_instance1 = Logger()
        logger_instance2 = Logger()  # Это тот же синглтон
        
        logger1 = logger_instance1.get_logger(log_file="")
        logger2 = logger_instance2.get_logger(log_file="")
        
        assert logger1 is logger2
