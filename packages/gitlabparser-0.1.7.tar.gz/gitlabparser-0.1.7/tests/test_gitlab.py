import pytest
from unittest.mock import Mock, patch, MagicMock
from GitlabParser import Find

class TestFind:
    def test_find_initialization(self):
        """Тест инициализации Find"""
        finder = Find(gitlab_token="fake_token")
        assert finder.gitlab_token == "fake_token"
        assert finder.headers == {'PRIVATE-TOKEN': 'fake_token'}

    @patch('GitlabParser.gitlab.Find.session')
    def test_find_all_groups_error(self, mock_session):
        """Тест обработки ошибки при запросе групп"""
        # Мокаем ответ с ошибкой 401
        mock_response = Mock()
        mock_response.status_code = 401
        mock_session.get.return_value = mock_response

        finder = Find(gitlab_token="fake_token")
        
        with pytest.raises(SystemExit):  # Ожидаем exit(1)
            finder.find_all_groups(group_ids=[1])

    @patch('GitlabParser.gitlab.Find.session')
    def test_find_all_groups_success(self, mock_session):
        """Тест успешного получения групп"""
        # Мокаем успешный ответ для первого запроса (get_groups_info)
        mock_response1 = Mock()
        mock_response1.status_code = 200
        mock_response1.json.return_value = {"id": 1, "name": "test"}  # Один словарь
        
        # Мокаем успешный ответ для рекурсивного запроса (subgroups)
        mock_response2 = Mock()
        mock_response2.status_code = 200
        mock_response2.json.return_value = []  # Пустой список для выхода из цикла
        
        # Настраиваем последовательность ответов
        mock_session.get.side_effect = [mock_response1, mock_response2]

        finder = Find(gitlab_token="fake_token")
        # Патчим max_workers=1 для упрощения
        finder.max_workers = 1
        
        groups = finder.find_all_groups(group_ids=[1], recursive=False)  # Отключаем рекурсию для простоты
        
        assert len(groups) == 1
        assert groups[0]['id'] == 1
        assert groups[0]['name'] == 'test'
