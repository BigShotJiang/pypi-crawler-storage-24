[![CI Status]][workflow] [![PyPi Release]][pypi] [![Read the Docs]][rtdocs]

[CI Status]: https://img.shields.io/github/actions/workflow/status/juntyr/numcodecs-rs/ci.yml?branch=main
[workflow]: https://github.com/juntyr/numcodecs-rs/actions/workflows/ci.yml?query=branch%3Amain

[PyPi Release]: https://img.shields.io/pypi/v/numcodecs-wasm-lc.svg
[pypi]: https://pypi.python.org/pypi/numcodecs-wasm-lc

[Read the Docs]: https://img.shields.io/readthedocs/numcodecs-wasm?label=readthedocs
[rtdocs]: https://numcodecs-wasm.readthedocs.io/en/stable/api/numcodecs_wasm_lc/

# numcodecs-wasm-lc

[`numcodecs`] compression for the [`numcodecs-lc`] codec compiled to WebAssembly.

[`numcodecs`]: https://numcodecs.readthedocs.io/en/stable/
[`numcodecs-lc`]: https://docs.rs/numcodecs-lc/

## License

Licensed under the Mozilla Public License, Version 2.0 ([LICENSE](LICENSE) or https://www.mozilla.org/en-US/MPL/2.0/).

## Funding

The `numcodecs-wasm-lc` package has been developed as part of [ESiWACE3](https://www.esiwace.eu), the third phase of the Centre of Excellence in Simulation of Weather and Climate in Europe.

Funded by the European Union. This work has received funding from the European High Performance Computing Joint Undertaking (JU) under grant agreement No 101093054.
