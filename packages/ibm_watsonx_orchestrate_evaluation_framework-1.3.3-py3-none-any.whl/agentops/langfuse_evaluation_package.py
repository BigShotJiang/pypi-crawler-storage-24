import inspect
import os
import uuid
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, List, Mapping, Optional

from rich.console import Console
from rich.tree import Tree

import agentops.metrics as metric_pkg
from agentops.arg_configs import TestConfig
from agentops.collection.collection_base import CollectionBase
from agentops.extractors import Extractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.operator.operator_base import OperatorBase
from agentops.otel_parser import parser as otel_parser
from agentops.persistence.disk import DiskPersistence
from agentops.persistence.persistence_base import PersistenceBase
from agentops.service_provider.provider import Provider
from agentops.stats import Average
from agentops.type import DatasetModel, ExtendedMessage
from agentops.utils.arize_utils import build_arize_experiment_id
from agentops.utils.experiment_results import ExperimentResult
from agentops.utils.rich_utils import RichLogger
from agentops.utils.telemetry_platform import TelemetryPlatform

CLIENT = None

logger = RichLogger(__name__)

MAX_WORKERS = int(os.environ.get("MAX_EVAL_WORKERS", "5").strip())
TEST_CASE_EVALUATION_TIMEOUT_SECONDS = int(
    os.environ.get("TEST_CASE_EVALUATION_TIMEOUT_SECONDS", "60").strip()
)


def load_metrics(
    config: TestConfig, metrics: list[str], llm_client: Provider
) -> list[Evaluation]:
    """
    Load metric evaluator instances using their name. If the name can not be resolved from the metrics package, it will be skipped.

    Args:
        config: Test configuration for set up.
        metrics: List of metric names to load

    Returns:
        A list of initialized evaluator instances.
    """
    evaluators = []
    logger.info(f"Loading following metrics {metrics}")
    operator_configs = config.operator_configs
    # edge case where operator_configs is explicitly set to None
    if operator_configs is None:
        operator_configs = {}

    for metric in metrics:
        try:
            metric_cls = getattr(metric_pkg, metric)
        except AttributeError:
            logger.error(
                f"Unknown metric: {metric}. Please validate metrics name."
            )
            continue

        signature = inspect.signature(metric_cls.__init__)
        metric_kwargs = {"llm_client": llm_client}
        if cfg := operator_configs.get(metric):
            metric_kwargs.update(
                {k: v for k, v in cfg.items() if k in signature.parameters}
            )

        evaluators.append(metric_cls(**metric_kwargs))
    return evaluators


class EvaluationRunner:
    def __init__(
        self,
        evaluation_name: str,
        metrics: List[Evaluation],
        output_dir=None,
        experiment_results: Optional[
            Any
        ] = None,  # TODO : Remove this arg once the optimisation changes are stable
        session_ids: List[str] = None,
        test_cases: Optional[List[DatasetModel]] = None,
        collection: Optional[CollectionBase] = None,
        messages=None,
        exporters: Optional[List[PersistenceBase]] = None,
        n_runs: int = 1,
    ):
        """
        Note:
            - If `output_dir` and `DiskPersistence` are both provided, then `output_dir` is ignored.
            - `test_cases` take priority over `collection`.
            -  Use `collection` if your dataset is stored in Langfuse.

        """
        self.evaluation_name = evaluation_name
        self.experiment_id = str(uuid.uuid4())

        logger.info(f"Using {MAX_WORKERS} workers for evaluation")
        self.executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)

        if exporters:
            disk_persistence_present = any(
                isinstance(exporter, DiskPersistence) for exporter in exporters
            )
            if disk_persistence_present:
                logger.warning(
                    "DiskPersistence is already present in the exporters list. Ignoring value of `output_dir`."
                )
            else:
                exporters.append(DiskPersistence(output_dir=output_dir))

        elif exporters == []:
            pass
        else:
            exporters = [DiskPersistence(output_dir=output_dir)]

        if exporters:
            self.output_dir = next(
                filter(lambda x: isinstance(x, DiskPersistence), exporters)
            ).output_dir
        else:
            self.output_dir = None

        self.test_cases: List[DatasetModel] = []
        self.experiment_results = experiment_results
        self.session_ids = session_ids

        if test_cases:
            self.test_cases = test_cases
        elif collection:
            for item in collection.get_data_items():
                data_model = collection._process_item(item)
                for _ in range(n_runs):
                    self.test_cases.append(data_model)

        dataset_summary_version = DatasetModel.consistent_summary_version(
            self.test_cases
        )
        logger.info(f"Dataset summary version: {dataset_summary_version}")

        self.is_referenceless = False if self.test_cases else True

        self.telemetry_platform = TelemetryPlatform()
        self.messages = None
        if messages:
            self.messages = messages
        # initialize telemetry platform specific variables
        if self.telemetry_platform.is_disabled:
            # No telemetry platform - messages must be provided directly
            if self.session_ids is None and experiment_results:
                self.session_ids = [
                    entry.output for entry in experiment_results.item_results
                ]

        elif self.telemetry_platform.is_langfuse:
            # TODO: Remove the below line once optimistion changes are in place
            if self.session_ids is None and experiment_results:
                self.session_ids = [
                    entry.output for entry in experiment_results.item_results
                ]
            # TODO: REFACTOR FOR LANGFUSE TO USE IN MEMORY EXPORTER
            if not self.messages and self.session_ids:
                self.messages = [
                    otel_parser.poll_messages(id) for id in self.session_ids
                ]

        elif self.telemetry_platform.is_arize:
            # TODO: Remove the below line once optimistion changes are in place
            if self.session_ids is None:
                self.session_ids = experiment_results["result"].tolist()
            self.experiment_id = build_arize_experiment_id(
                self.collection.dataset_id
            )

        # Arize/Langfuse, Disk, in the future we can have S3, etc.
        self.exporters = exporters

        self.metrics = metrics
        self.schedule = self._scheduler(
            metrics=self.metrics, output_dir=self.output_dir
        )

        logger.info(
            f":heavy_check_mark: Evaluation loop initialized with name, [bold]{self.evaluation_name}[/bold], and experiment id, [italic]{self.experiment_id}[/italic]"
        )

    @staticmethod
    def _extract_extended_messages(
        evaluation_results: List[Mapping[str, List[EvaluatorData]]]
    ) -> List[List[ExtendedMessage]]:
        extended_messages = []
        for evaluation_result in evaluation_results:
            for test_case_name, metrics in evaluation_result.items():
                for metric in metrics:
                    if metric.eval_name == "is_success":
                        extended_messages.append(
                            {
                                test_case_name: metric.metadata.get(
                                    "tagged_messages"
                                )
                            }
                        )
        return extended_messages

    @classmethod
    def _gather(cls, user_metrics):
        """Extract all the `operators` for the provided metrics.

        Here `operators` means either an evaluator or extractor.
        A `metric` may depend on another `extractor` or `evaluator`.

        User-provided (top-level) operators are treated as authoritative.
        When a dependency is encountered that shares a class name with a
        user-provided operator, the user-provided instance is kept and the
        internally-declared default is discarded.  This lets users override
        the configuration of any transitive dependency by passing their own
        instance to the evaluation runner.

        Return:
        - We return a mapping between the operator and the object.
        For example:
        {
            "Journey Success": journey_success,
            "Expected Tool Extractor": expected_tool_call_extractor
        }
        """

        op_mapping = {}
        for m in user_metrics:
            op_mapping[OperatorBase.key(m)] = m

        queue = list(user_metrics)
        seen = set(op_mapping.keys())

        while queue:
            node = queue.pop()
            for dep in node.dependencies:
                dep_hash = OperatorBase.key(dep)
                if dep_hash not in seen:
                    seen.add(dep_hash)
                    op_mapping[dep_hash] = dep
                    queue.append(dep)
                else:
                    # A user override (or an earlier default) exists.
                    # Still walk *its* dependencies so nothing is missed.
                    resolved = op_mapping[dep_hash]
                    for sub_dep in resolved.dependencies:
                        if OperatorBase.key(sub_dep) not in seen:
                            queue.append(sub_dep)

        return op_mapping

    @classmethod
    def _scheduler(cls, metrics, output_dir: Path = None):
        op_mapping = cls._gather(user_metrics=list(metrics))

        eval_dag = defaultdict(list)
        in_degree = defaultdict(int)
        for op in op_mapping.values():
            for dependency in op.dependencies:
                eval_dag[OperatorBase.key(dependency)].append(
                    OperatorBase.key(op)
                )
                in_degree[OperatorBase.key(op)] += 1

            if OperatorBase.key(op) not in in_degree:
                in_degree[OperatorBase.key(op)] = 0

        ordering = []
        queue = deque(
            [op for op, num_deps in in_degree.items() if num_deps == 0]
        )

        while queue:
            op = queue.popleft()
            ordering.append(op)

            for operator in eval_dag[op]:
                in_degree[operator] -= 1
                if in_degree[operator] == 0:
                    queue.append(operator)

        ordering = {op: op_mapping.get(op) for op in ordering}

        tree = Tree("Evaluation Order", guide_style="bold bright_blue")
        for name in ordering.keys():
            tree.add(name)

        # save the evaluation order along with the configs to a debug file
        if output_dir:
            debug_folder = output_dir / "debug"
            debug_folder.mkdir(parents=True, exist_ok=True)
            with open(
                debug_folder / "evaluation_order.txt", "w", encoding="utf-8"
            ) as f:
                console = Console(file=f)
                console.print(tree)

        return ordering

    def _evaluate(self, test_case_name, ground_truth, messages):
        context = {"extractor": {}, "metric": {}}
        metadata = {}

        try:
            for operator in self.schedule.values():
                if isinstance(operator, Extractor):
                    operator.extract(
                        messages=messages,
                        ground_truth=ground_truth,
                        metadata=metadata,
                        extracted_context=context,
                    )

                if isinstance(operator, Evaluation):
                    operator.evaluate(
                        messages,
                        ground_truth,
                        metadata=metadata,
                        extracted_context=context,
                    )

            metrics = context.get("metric")
            metric_results = defaultdict(list)

            for outputs in metrics.values():
                for metric_result in outputs.values():
                    metric_results[test_case_name].append(metric_result)

            return metric_results

        except Exception as e:
            logger.error(
                f'Error calculating metrics for test case session "{test_case_name}"',
                e,
            )
            return {}

    def evaluate(self):
        metadata = {}
        total_metrics = []

        if self.is_referenceless:
            evaluation_items = self.messages
        else:
            evaluation_items = self.test_cases

        futures = []
        for idx, item in enumerate(evaluation_items):
            ground_truth = None if self.is_referenceless else item
            test_case_name = self.test_cases[idx].dataset_name
            messages = self.messages[idx]
            future = (
                idx,
                self.test_cases[idx].dataset_name,
                self.executor.submit(
                    self._evaluate,
                    test_case_name,
                    ground_truth,
                    messages,
                ),
            )
            futures.append(future)

        for idx, test_case_name, future in futures:
            try:
                result = future.result(
                    timeout=TEST_CASE_EVALUATION_TIMEOUT_SECONDS
                )
                total_metrics.append(result if result is not None else {})
            except TimeoutError:
                logger.error(
                    f"{test_case_name} timed out and did not finish in {TEST_CASE_EVALUATION_TIMEOUT_SECONDS}."
                )
                total_metrics.append({})
            except Exception as e:
                logger.error(
                    f"Evaluation failed for test case {test_case_name}: {e}"
                )
                total_metrics.append({})

        average = Average()
        aggregate_metrics = average(total_metrics)

        for exporter in self.exporters:
            exporter.persist(
                evaluation_results=total_metrics,
                experiment_results=self.experiment_results,
                session_ids=self.session_ids,
                test_cases=self.test_cases,
                messages=self.messages,
                experiment_id=self.experiment_id,
                metadata=metadata,
            )
            exporter.persist_aggregated_metrics(
                evaluation_results=total_metrics,
                aggregated_metrics=aggregate_metrics,
            )

        return ExperimentResult(
            experiment_name=self.evaluation_name,
            experiment_id=self.experiment_id,
            metrics=total_metrics,
            session_ids=self.session_ids,
            aggregate_metrics=aggregate_metrics,
            extended_messages=self._extract_extended_messages(total_metrics),
        )
