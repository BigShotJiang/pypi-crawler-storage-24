import hashlib
import json
import os
import time
import warnings
from datetime import datetime
from typing import Dict, List, Optional

import rich
from jsonargparse import CLI

from agentops import __file__
from agentops.arg_configs import (
    ChatRecordingConfig,
    ProviderConfig,
    StoryGenerationConfig,
)
from agentops.generators import StoryGenerationLLM
from agentops.prompt.template_render import StoryGenerationTemplateRenderer
from agentops.record.data_annotator import DataAnnotator
from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
from agentops.service_provider import get_provider
from agentops.type import ContentType, Message
from agentops.utils.utils import is_saas_url
from agentops.wxo_client import WXOClient, get_wxo_client

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

root_dir = os.path.dirname(__file__)


def get_recent_runs(wxo_client: WXOClient, limit: int = 20):
    if is_saas_url(wxo_client.service_url):
        # TO-DO: this is not validated after the v1 prefix change
        # need additional validation
        path = "v1/orchestrate/runs"
    else:
        path = "v1/orchestrate/runs"

    meta_resp = wxo_client.get(path, params={"limit": 1, "offset": 0}).json()
    total = meta_resp.get("total", 0)

    if total == 0:
        return []

    # fetch the most recent runs
    offset_for_latest = max(total - limit, 0)
    resp = wxo_client.get(
        path, params={"limit": limit, "offset": offset_for_latest}
    ).json()

    runs = []
    if isinstance(resp, dict):
        runs = resp.get("data", [])

    runs.sort(
        key=lambda x: (
            datetime.strptime(x["completed_at"], "%Y-%m-%dT%H:%M:%S.%fZ")
            if x.get("completed_at")
            else datetime.min
        ),
        reverse=True,
    )

    return runs


def generate_story(
    annotated_data: dict,
    story_config: Optional[StoryGenerationConfig] = None,
    provider_config: Optional[ProviderConfig] = None,
):
    _story_config = story_config or StoryGenerationConfig()
    _provider_conf = provider_config or ProviderConfig()

    provider = get_provider(
        config=_provider_conf, **_provider_conf.provider_params
    )

    story_generator: StoryGenerationLLM = StoryGenerationLLM(
        provider=provider,
        template=StoryGenerationTemplateRenderer(_story_config.prompt_config),
    )
    response = story_generator.generate(annotated_data)
    return response


def _safe_json_parse(value, max_depth=5, current_depth=0):
    """Recursively parse JSON strings, including nested JSON within objects.

    Args:
        value: The value to parse (string, dict, list, or other)
        max_depth: Maximum recursion depth to prevent infinite loops
        current_depth: Current recursion depth (internal use)

    Returns:
        Parsed JSON object with all nested JSON strings converted to objects
    """
    # Prevent infinite recursion
    if current_depth >= max_depth:
        return value

    # If it's a string, try to parse it as JSON
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            # Recursively parse the result in case it contains more JSON strings
            return _safe_json_parse(parsed, max_depth, current_depth + 1)
        except (json.JSONDecodeError, TypeError):
            return value

    # If it's a dict, recursively parse all values
    elif isinstance(value, dict):
        return {
            key: _safe_json_parse(val, max_depth, current_depth + 1)
            for key, val in value.items()
        }

    # If it's a list, recursively parse all elements
    elif isinstance(value, list):
        return [
            _safe_json_parse(item, max_depth, current_depth + 1)
            for item in value
        ]

    # For other types (int, float, bool, None), return as-is
    else:
        return value


def extract_tool_interactions(messages: List[Message]) -> List[Dict]:
    """Extract tool calls and their corresponding responses from messages.

    Returns a list of tool interaction objects with structure:
    {
        "tool_call_id": str,
        "tool_name": str,
        "tool_args": dict,
        "tool_response": dict or str,  # Parsed as JSON if possible
        "success": bool  # based on error detection
    }
    """
    interactions = []
    tool_calls_map = {}  # Map tool_call_id to call details
    tool_responses = []  # Store responses to match later

    for idx, message in enumerate(messages):
        if message.type == ContentType.tool_call:
            try:
                # Handle both string and dict content
                if isinstance(message.content, str):
                    content = json.loads(message.content)
                else:
                    content = message.content

                call_id = content.get("tool_call_id") or content.get("id")

                if call_id:
                    tool_calls_map[call_id] = {
                        "tool_call_id": call_id,
                        "tool_name": content.get("name"),
                        "tool_args": content.get("args", {}),
                        "message_index": idx,
                        "tool_response": None,
                        "success": None,
                    }
            except (json.JSONDecodeError, AttributeError, TypeError) as e:
                rich.print(
                    f"[yellow]WARNING:[/yellow] Failed to parse tool call at index {idx}: {e}"
                )
                continue

        elif message.type == ContentType.tool_response:
            try:
                # Handle both string and dict content
                if isinstance(message.content, str):
                    content = json.loads(message.content)
                else:
                    content = message.content

                # Store response for later matching
                tool_responses.append(
                    {"content": content, "message_index": idx}
                )
            except (json.JSONDecodeError, AttributeError, TypeError) as e:
                rich.print(
                    f"[yellow]WARNING:[/yellow] Failed to parse tool response at index {idx}: {e}"
                )
                continue

    # Match tool responses to tool calls
    # Strategy: match by tool_call_id if available, otherwise match by order
    for response_data in tool_responses:
        content = response_data["content"]
        call_id = content.get("tool_call_id") or content.get("id")

        if call_id and call_id in tool_calls_map:
            # Direct match by ID
            response_text = content.get(
                "output", content.get("content", content.get("result", ""))
            )
            tool_calls_map[call_id]["tool_response"] = _safe_json_parse(
                response_text
            )
            tool_calls_map[call_id]["success"] = (
                not DataAnnotator._is_error_in_message(str(response_text))
            )
        else:
            # Try to match by order: find the nearest preceding tool call without a response
            response_idx = response_data["message_index"]
            for call_id in reversed(list(tool_calls_map.keys())):
                call_data = tool_calls_map[call_id]
                if (
                    call_data["message_index"] < response_idx
                    and call_data["tool_response"] is None
                ):
                    # Match this response to this call
                    response_text = content.get(
                        "output",
                        content.get("content", content.get("result", "")),
                    )
                    call_data["tool_response"] = _safe_json_parse(response_text)
                    call_data["success"] = (
                        not DataAnnotator._is_error_in_message(
                            str(response_text)
                        )
                    )
                    break

    # Convert to ordered list
    interactions = list(tool_calls_map.values())
    interactions.sort(key=lambda x: x["message_index"])

    # Clean up temporary fields
    for interaction in interactions:
        interaction.pop("message_index", None)

    return interactions


def annotate_messages(
    agent_name: Optional[str],
    messages: List[Message],
    chat_recording_config: ChatRecordingConfig,
):
    annotator: DataAnnotator = DataAnnotator(
        messages=messages,
        keywords_generation_config=chat_recording_config.keywords_generation_config,
        summary_generation_config=chat_recording_config.summary_generation_config,
        provider_config=chat_recording_config.provider_config,
    )
    annotated_data = annotator.generate()
    if agent_name is not None:
        annotated_data["agent"] = agent_name

    annotated_data["story"] = generate_story(
        annotated_data=annotated_data,
        story_config=chat_recording_config.story_generation_config,
        provider_config=chat_recording_config.provider_config,
    )

    return annotated_data


def has_messages_changed(
    thread_id: str,
    messages: List[Message],
    previous_hashes: Dict[str, str],
) -> bool:
    # serialize just the message content
    payload = [msg.model_dump() for msg in messages]
    sig = json.dumps(payload, sort_keys=True, default=str)
    h = hashlib.sha256(sig.encode()).hexdigest()

    if previous_hashes.get(thread_id) != h:
        previous_hashes[thread_id] = h
        return True
    return False


def _record(config: ChatRecordingConfig, bad_threads: set):
    """Record chats in background mode"""
    start_time = datetime.utcnow()
    processed_threads = set()
    previous_input_hash: dict[str, str] = {}

    if config.token is None:
        from agentops.service_instance import tenant_setup

        token, _, _ = tenant_setup(config.service_url, config.tenant_name)
        config.token = token
    wxo_client = get_wxo_client(
        config.service_url, config.tenant_name, config.token
    )
    inference_backend = WXORuntimeAdapter(wxo_client=wxo_client)

    # Ensure output directory exists
    os.makedirs(config.output_dir, exist_ok=True)

    retry_count = 0
    while retry_count < config.max_retries:
        thread_id = None
        try:
            recent_runs = get_recent_runs(wxo_client)
            seen_threads = set()
            # Process only new runs that started after our recording began
            for run in recent_runs:
                thread_id = run.get("thread_id")
                if (thread_id in bad_threads) or (thread_id in seen_threads):
                    continue
                seen_threads.add(thread_id)
                started_at = run.get("started_at")

                if not thread_id or not started_at:
                    continue

                try:
                    started_time = datetime.strptime(
                        started_at, "%Y-%m-%dT%H:%M:%S.%fZ"
                    )
                    if started_time > start_time:
                        if thread_id not in processed_threads:
                            rich.print(
                                f"\n[green]INFO:[/green] New recording started at {started_at}"
                            )
                            rich.print(
                                f"[green]INFO:[/green] Annotations saved to: {os.path.join(config.output_dir, f'{thread_id}_annotated_data.json')}"
                            )
                            rich.print(
                                f"[green]INFO:[/green] Tool interactions saved to: {os.path.join(config.output_dir, f'{thread_id}_tool_calls_and_responses.json')}"
                            )
                        processed_threads.add(thread_id)

                        try:
                            messages = inference_backend.get_messages(thread_id)

                            if not has_messages_changed(
                                thread_id, messages, previous_input_hash
                            ):
                                continue

                            try:
                                agent_name = os.environ.get(
                                    "AGENT_NAME"
                                ) or inference_backend.get_agent_name_from_thread_id(
                                    thread_id
                                )
                            except Exception as e:
                                rich.print(
                                    f"[yellow]WARNING:[/yellow] Failure getting agent name for thread_id {thread_id}: {e}"
                                )
                                raise

                            if agent_name is None:
                                rich.print(
                                    f"[yellow]WARNING:[/yellow] No agent name found for thread_id {thread_id}. Skipping ..."
                                )
                                continue

                            # Extract tool interactions separately
                            tool_interactions = extract_tool_interactions(
                                messages
                            )

                            annotated_data = annotate_messages(
                                agent_name,
                                messages,
                                config,
                            )

                            # Add thread_id to both data structures
                            annotated_data["thread_id"] = thread_id

                            # Check if any tool has binary input (file upload)
                            has_file_upload = False
                            if hasattr(
                                inference_backend, "tool_has_binary_input"
                            ):
                                for interaction in tool_interactions:
                                    tool_name = interaction.get("tool_name")
                                    if tool_name:
                                        try:
                                            if inference_backend.tool_has_binary_input(
                                                tool_name
                                            ):
                                                has_file_upload = True
                                                break
                                        except Exception as e:
                                            rich.print(
                                                f"[yellow]WARNING:[/yellow] Failed to check binary input for tool {tool_name}: {e}"
                                            )

                            # Add hardcoded file_upload field if file upload detected
                            if has_file_upload:
                                annotated_data["file_upload"] = {
                                    "file_path": "path/to/file.pdf",
                                    "file_id": str(
                                        hash(thread_id) % 1000
                                    ).zfill(3),
                                    "content_type": "application/pdf",
                                }

                            tool_interactions_data = {
                                "thread_id": thread_id,
                                "tool_interactions": tool_interactions,
                            }

                            # Save annotated data with thread_id prefix
                            annotation_filename = os.path.join(
                                config.output_dir,
                                f"{thread_id}_annotated_data.json",
                            )
                            with open(annotation_filename, "w") as f:
                                json.dump(annotated_data, f, indent=4)

                            # Save tool interactions with thread_id prefix
                            tool_calls_filename = os.path.join(
                                config.output_dir,
                                f"{thread_id}_tool_calls_and_responses.json",
                            )
                            with open(tool_calls_filename, "w") as f:
                                json.dump(tool_interactions_data, f, indent=4)
                        except Exception as e:
                            rich.print(
                                f"[yellow]WARNING:[/yellow] Failed to process thread {thread_id}: {e}"
                            )
                            raise
                except (ValueError, TypeError) as e:
                    rich.print(
                        f"[yellow]WARNING:[/yellow] Invalid timestamp for thread {thread_id}: {e}"
                    )
                    raise

            retry_count = 0
            time.sleep(2)

        except KeyboardInterrupt:
            rich.print("\n[yellow]Recording stopped by user[/yellow]")
            break

        except Exception as e:
            if thread_id is None:
                rich.print(f"[red]ERROR:[/red] {e}")
                break

            time.sleep(1)
            retry_count += 1
            if retry_count >= config.max_retries:
                rich.print(
                    f"[red]ERROR:[/red] Maximum retries reached. Skipping thread {thread_id}"
                )
                bad_threads.add(thread_id)
                _record(config, bad_threads)


def record_chats(config: ChatRecordingConfig):
    rich.print(
        f"[green]INFO:[/green] Chat recording started. Press Ctrl+C to stop."
    )
    bad_threads = set()
    _record(config, bad_threads)


if __name__ == "__main__":
    record_chats(CLI(ChatRecordingConfig, as_positional=False))
