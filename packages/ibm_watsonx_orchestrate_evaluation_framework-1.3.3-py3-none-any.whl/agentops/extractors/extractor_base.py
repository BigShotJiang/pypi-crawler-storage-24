from abc import ABC, abstractmethod
from typing import Any, Dict, List, Mapping, Optional

from agentops.operator.operator_base import OperatorBase
from agentops.service_provider.provider import Provider
from agentops.type import Message, OrchestrateDataset


class Extractor(ABC, OperatorBase):
    def __init__(self, llm_client: Optional[Provider] = None):
        super().__init__(llm_client)

    def extract(
        self,
        messages: List[Message],
        ground_truth: Optional[OrchestrateDataset] = None,
        extracted_context: Mapping[str, Any] = {},
        **kwargs,
    ) -> Any:
        """
        Public extraction method that applies context updates.

        This method is called by the framework and handles the decorator logic.
        Subclasses should implement do_extract() instead.

        Args:
            messages: agent and user conversational messages (includes tool calls)
            ground_truth: ground truth data
            extracted_context: dictionary containing data derived from the messages
            **kwargs: additional keyword arguments

        Returns:
            Extracted data
        """
        results = self.do_extract(
            messages=messages,
            ground_truth=ground_truth,
            extracted_context=extracted_context,
            **kwargs,
        )
        OperatorBase.update_context(self, results, extracted_context)
        return results

    @abstractmethod
    def do_extract(
        self,
        messages: List[Message],
        ground_truth: Optional[OrchestrateDataset] = None,
        **kwargs,
    ) -> Any:
        """
        Extraction implementation to be overridden by subclasses.

        This method contains the actual extraction logic.
        The update_context function is called automatically by the extract() method.

        Args:
            messages: agent and user conversational messages (includes tool calls)
            ground_truth: ground truth data
            extracted_context: dictionary containing data derived from the messages
            **kwargs: additional keyword arguments

        Returns:
            Extracted data
        """
        raise NotImplementedError
