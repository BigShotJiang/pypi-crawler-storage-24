import json
import os
from pathlib import Path

from jsonargparse import CLI
from tqdm import tqdm

from agentops.arg_configs import EvalDataAnalyzeMode, EvalDataAnalyzerConfig
from agentops.prompt.template_render import JinjaTemplateRenderer
from agentops.scheduler import discover_tests
from agentops.service_provider import get_provider
from agentops.type import ChatCompletions, DatasetModel
from agentops.utils.rich_utils import RichLogger

QUALITY_EVAL_TEMPLATE_PATH = "src/agentops/prompt/eval_data_quality.jinja2"
COMPLEXITY_EVAL_TEMPLATE_PATH = (
    "src/agentops/prompt/eval_data_complexity.jinja2"
)


class EvalDataAnalyzer:
    def __init__(self, config: EvalDataAnalyzerConfig):
        self.config = config
        self.logger = RichLogger(__name__)
        self.provider = get_provider(config.provider_config)

        self.quality_template = JinjaTemplateRenderer(
            QUALITY_EVAL_TEMPLATE_PATH
        )
        self.complexity_template = JinjaTemplateRenderer(
            COMPLEXITY_EVAL_TEMPLATE_PATH
        )

    def analyze(
        self, eval_data: DatasetModel, mode: EvalDataAnalyzeMode
    ) -> str:
        if not isinstance(mode, EvalDataAnalyzeMode):
            self.logger.warn(f"Analysis mode {mode} not supported.")
            return

        story = eval_data.story
        starting_sentence = eval_data.starting_sentence
        tools = []
        text_goal = (
            None  # NOTE handle cases where there might be multiple text goals
        )
        for goal in eval_data.goal_details:
            if goal.tool_name:
                tools.append(goal)
            else:
                text_goal = goal

        if mode == EvalDataAnalyzeMode.quality:
            prompt = self.quality_template.render(
                story=story,
                starting_sentence=starting_sentence,
                tools=tools,
                response=text_goal.response,
                keywords=text_goal.keywords,
            )
        elif mode == EvalDataAnalyzeMode.complexity:
            prompt = self.complexity_template.render(
                story=story, starting_sentence=starting_sentence, tools=tools
            )

        result: ChatCompletions = self.provider.chat(prompt)
        result_str = result.choices[0].message.content
        return result_str

    def _compile_report(self, results: dict[str, str]) -> str:
        mode = self.config.mode
        report = f"# {mode} report\n"
        for test_name, result in results.items():
            report += f"## {test_name}\n"
            if mode == EvalDataAnalyzeMode.quality:
                report += f"{result}\n\n"
            else:
                report += f"Score: {result}\n\n"

        return report

    def run(self):

        # Load test cases
        test_files = discover_tests(self.config.test_paths)
        results = {}

        self.logger.info(
            f"Running analysis on {len(test_files)} test cases. Mode selected: {self.config.mode}"
        )
        for test_file in tqdm(test_files, desc="Progress"):
            try:
                with open(test_file, "r") as f:
                    evaluation_data = DatasetModel.model_validate(json.load(f))
            except Exception as e:
                err_msg = f"Error loading the test case: {test_file} {e}"
                self.logger.error(err_msg)

            # run analysis based on mode
            results[Path(test_file).stem] = self.analyze(
                evaluation_data, mode=self.config.mode
            )

        # write as a human readable report
        report = self._compile_report(results)
        os.makedirs(self.config.output_dir, exist_ok=True)
        self.logger.info(
            f"Writing results to {self.config.output_dir}/{self.config.mode}_report.md"
        )

        with open(
            os.path.join(
                self.config.output_dir, f"{self.config.mode}_report.md"
            ),
            "w",
        ) as fp:
            fp.write(report)
        # write as a json
        with open(
            os.path.join(
                self.config.output_dir, f"{self.config.mode}_report.json"
            ),
            "w",
        ) as fp:
            json.dump(results, fp, indent=4)


def main(config: EvalDataAnalyzerConfig):
    analyzer = EvalDataAnalyzer(config)
    analyzer.run()


if __name__ == "__main__":
    main(CLI(EvalDataAnalyzerConfig, as_positional=False))
