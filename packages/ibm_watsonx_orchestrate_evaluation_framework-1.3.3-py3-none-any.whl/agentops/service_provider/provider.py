import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Sequence

from agentops.singleton import ThreadSafeSingletonABCMeta
from agentops.type import ChatCompletions


class Provider(ABC, metaclass=ThreadSafeSingletonABCMeta):
    def __init__(
        self,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def chat(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        raise NotImplementedError("Not implemented")

    @abstractmethod
    def encode(self, sentences: List[str]) -> List[list]:
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement encode()."
        )

    def query(self, sentence: str) -> ChatCompletions:
        messages = []
        if self.system_prompt is not None:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.append({"role": "user", "content": sentence})
        return self.chat(messages)
