import json

from agentops.otel_parser.common import dfs_
from agentops.type import ContentType, Function, Message, ToolCall


def parse_observations(observation_tree, dfs_observations=None):
    """
    Parse observations from an observation tree.

    When there are multiple root nodes (e.g., multiple LangGraph conversation turns
    within a single Arize experiment trace), we process each root separately to
    capture input messages from each turn.
    """
    messages = []

    # Process each root (conversation turn) separately
    for root in observation_tree:
        root_messages = _parse_single_tree(root)
        messages.extend(root_messages)

    return messages


def _parse_single_tree(root_node):
    """Parse a single tree rooted at root_node."""

    messages = []
    seen_message_ids = set()  # Track seen messages to avoid duplicates

    # DFS traversal of just this root's subtree
    dfs_observations = dfs_([root_node])

    for obs in dfs_observations:
        if obs.obs.type == "GENERATION":
            # Get input messages for every generation (includes user messages)
            input_messages = _get_input_message(obs, seen_message_ids)
            messages.extend(input_messages)

            parent = obs.parent
            if parent and parent.obs.type == "CHAIN":
                output = parent.obs.output

                # Handle both formats:
                # 1. {"messages": [msg1, msg2, ...]} - standard format
                # 2. {content, tool_calls, ...} - direct message format
                if isinstance(output, dict) and "messages" in output:
                    msg = output["messages"][0]
                elif isinstance(output, dict) and "content" in output:
                    # Direct message format
                    msg = output
                else:
                    continue

                msg_id = _get_message_id(msg)
                if msg_id and msg_id in seen_message_ids:
                    continue

                if msg_id:
                    seen_message_ids.add(msg_id)

                content = msg.get("content") or ""
                msg_type = ContentType.text
                tool_calls = msg.get("tool_calls") or None
                if tool_calls is not None and len(tool_calls) > 0:
                    msg_type = ContentType.tool_call
                    tool_calls = [_to_tool_call(tc) for tc in tool_calls]
                messages.append(
                    Message(
                        role="assistant",
                        content=content,
                        tool_calls=tool_calls,
                        type=msg_type,
                    )
                )
        elif obs.obs.type == "TOOL":
            parent_node = obs.parent
            if parent_node and parent_node.obs.type == "CHAIN":
                output = parent_node.obs.output

                # Handle both formats
                if isinstance(output, dict) and "messages" in output:
                    tool_responses = output["messages"]
                elif isinstance(output, dict) and "content" in output:
                    # Direct message format
                    tool_responses = [output]
                else:
                    continue
                for tool_response in tool_responses:
                    msg_id = tool_response.get("tool_call_id")
                    if msg_id and msg_id in seen_message_ids:
                        continue
                    if msg_id:
                        seen_message_ids.add(msg_id)
                    messages.append(
                        Message(
                            role="tool",
                            content=tool_response.get("content", ""),
                            tool_call_id=tool_response.get("tool_call_id"),
                            type=ContentType.tool_response,
                        )
                    )
    return messages


def _get_message_id(msg):
    """Get a unique identifier for a message to detect duplicates."""
    if msg.get("id"):
        return msg["id"]
    # Fall back to content + type as identifier
    return f"{msg.get('type', '')}:{msg.get('content', '')}"


def _get_input_message(obs_node, seen_message_ids=None):
    """Get input messages from a generation node, filtering out already seen messages."""
    if seen_message_ids is None:
        seen_message_ids = set()

    ret = []
    parent = obs_node.parent
    if parent and parent.obs.type == "CHAIN":
        for msg in parent.obs.input["messages"]:
            msg_id = _get_message_id(msg)
            if msg_id and msg_id in seen_message_ids:
                continue
            if msg_id:
                seen_message_ids.add(msg_id)

            if msg["type"] == "system":
                ret.append(
                    Message(
                        role="system",
                        content=msg["content"],
                        type=ContentType.text,
                    )
                )
            elif msg["type"] == "human":
                ret.append(
                    Message(
                        role="user",
                        content=msg["content"],
                        type=ContentType.text,
                    )
                )
            elif msg["type"] == "tool":
                ret.append(
                    Message(
                        role="tool",
                        content=msg["content"],
                        tool_call_id=msg["tool_call_id"],
                        type=ContentType.tool_response,
                    )
                )
            elif msg["type"] == "ai":
                content = msg["content"] or ""
                tool_calls = msg["tool_calls"] or None
                msg_type = ContentType.text
                if tool_calls is not None:
                    msg_type = ContentType.tool_call
                    tool_calls = [_to_tool_call(tc) for tc in tool_calls]
                ret.append(
                    Message(
                        role="assistant",
                        content=content,
                        tool_calls=tool_calls,
                        type=msg_type,
                    )
                )
    return ret


def _to_tool_call(tool_call):
    return ToolCall(
        id=tool_call["id"],
        type="function",  # ToolCall expects literal 'function'
        function=_to_function(tool_call),
    )


def _to_function(func):
    return Function(name=func["name"], arguments=json.dumps(func["args"]))
