from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import yaml
from jsonargparse import CLI

from agentops.arg_configs import TagDataAnalyzerConfig
from agentops.scheduler import build_tag_mapping
from agentops.utils.rich_utils import RichLogger
from agentops.utils.utils import create_table, load_summary_csv

logger = RichLogger(__name__)


def load_config(results_dir: str) -> Dict:
    """Load config.yml and extract test_paths and tags.

    Args:
        results_dir: Directory containing config.yml

    Returns:
        Dictionary containing the configuration
    """
    config_path = Path(results_dir) / "config.yml"
    if not config_path.exists():
        raise FileNotFoundError(f"config.yml not found in {results_dir}")

    logger.info(f"Loading config from {config_path}")
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def group_by_tag(
    df: pd.DataFrame, tag_to_test_names: Dict[str, List[str]]
) -> Dict[str, pd.DataFrame]:
    """Group CSV data by tags.

    Args:
        df: DataFrame with test metrics
        tag_to_test_names: Mapping from tags to test names

    Returns:
        Dictionary mapping tag names to filtered DataFrames
    """
    tag_dataframes = {}

    for tag, test_names in tag_to_test_names.items():
        tag_df = df[df["dataset_name"].isin(test_names)]

        if not tag_df.empty:
            tag_dataframes[tag] = tag_df
            logger.info(f"Tag '{tag}': {len(tag_df)} tests")
        else:
            logger.warn(f"Tag '{tag}': No matching tests found in CSV")

    return tag_dataframes


def calculate_statistics(tag_df: pd.DataFrame, tag: str) -> Dict[str, Any]:
    """Calculate average statistics for a tag.

    Args:
        tag_df: DataFrame with metrics for tests in this tag
        tag: Tag name

    Returns:
        Dictionary with averaged metrics
    """
    # Get numeric columns only
    numeric_cols = tag_df.select_dtypes(include=["number"]).columns

    # Calculate means as a Series, then convert to dict
    means_series: pd.Series = tag_df[numeric_cols].mean()  # type: ignore
    stats: Dict[str, Any] = means_series.to_dict()

    # Round to 2 decimal places for readability
    stats = {
        k: round(v, 2) if isinstance(v, float) else v for k, v in stats.items()
    }

    # Add identifier
    stats["dataset_name"] = f"{tag} (Average)"

    return stats


def display_results(tag_dataframes: Dict[str, pd.DataFrame]):
    """Display results as Rich tables.

    Args:
        tag_dataframes: Dictionary mapping tags to DataFrames
    """
    for tag, tag_df in tag_dataframes.items():
        # Calculate statistics
        stats = calculate_statistics(tag_df, tag)

        # Prepare rows for display
        rows = tag_df.to_dict("records")
        rows.append(stats)

        # Create and display table
        table = create_table(rows, title=f"Tag: {tag} ({len(tag_df)} tests)")

        if table:
            table.print()
            print()  # Add spacing between tables


def analyze_tag_data(
    results_dir: str, display_tables: bool = True
) -> Dict[str, pd.DataFrame]:
    """
    Analyze metrics grouped by tags discovered in test files.

    This function loads test configuration and metrics, discovers all tags
    present in the test files, groups metrics by those tags, and displays
    the results.

    Args:
        results_dir: Directory containing both summary_metrics.csv and config.yml
        display_tables: Whether to display Rich tables in console (default: True)

    Returns:
        Dictionary mapping tag names to DataFrames with their metrics.
        Returns empty dict if no data found or errors occur.

    Example:
        >>> tag_dfs = analyze_tag_data(
        ...     results_dir="/path/to/results",
        ...     display_tables=True
        ... )
        >>> for tag, df in tag_dfs.items():
        ...     print(f"{tag}: {len(df)} tests")
    """
    # Validate results directory
    results_path = Path(results_dir)
    if not results_path.exists():
        logger.error(f"Results directory does not exist: {results_dir}")
        return {}

    # Load config
    try:
        run_config = load_config(results_dir)
    except FileNotFoundError as e:
        logger.error(str(e))
        return {}

    test_paths = run_config.get("test_paths", [])

    if not test_paths:
        logger.error("No test_paths found in config.yml")
        return {}

    logger.info(f"Loaded {len(test_paths)} test paths from config")

    # Build tag mappings by discovering all tags in test files
    # prefix_dir resolves relative paths to absolute paths
    tag_to_test_names = build_tag_mapping(
        test_paths,
        filter_tags=None,  # Discover all tags
        return_stems=True,  # Return test names (stems) for CSV matching
        prefix_dir=results_path,  # Resolve relative paths
    )

    if not tag_to_test_names:
        logger.warn("No tags found in test files")
        return {}

    logger.info(
        f"Found {len(tag_to_test_names)} tags: {list(tag_to_test_names.keys())}"
    )

    # Load CSV
    try:
        df = load_summary_csv(results_dir)
    except FileNotFoundError as e:
        logger.error(str(e))
        return {}

    logger.info(f"Loaded {len(df)} test results from CSV")

    # Group by tag
    tag_dataframes = group_by_tag(df, tag_to_test_names)

    if not tag_dataframes:
        logger.warn("No matching data found for any tags")
        return {}

    # Display results
    if display_tables:
        logger.info("Displaying results by tag:")
        print()  # Add spacing
        display_results(tag_dataframes)

    return tag_dataframes


def main(config: TagDataAnalyzerConfig):
    """Main entry point for tag data analysis CLI.

    Args:
        config: Configuration for the analyzer
    """
    analyze_tag_data(
        results_dir=config.results_dir, display_tables=config.display_tables
    )


if __name__ == "__main__":
    main(CLI(TagDataAnalyzerConfig, as_positional=False))
