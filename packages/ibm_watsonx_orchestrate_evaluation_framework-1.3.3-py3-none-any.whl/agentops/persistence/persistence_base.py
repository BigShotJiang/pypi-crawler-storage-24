from abc import ABC, abstractmethod
from typing import Any, List, Mapping, Optional

from agentops.metrics.metrics import EvaluatorData
from agentops.stats import Result
from agentops.type import DatasetModel, Message


class PersistenceBase(ABC):
    @abstractmethod
    def persist(
        self,
        test_cases: List[DatasetModel],
        messages: List[List[Message]],
        evaluation_results: List[Mapping[str, List[EvaluatorData]]],
        experiment_results: Optional[
            Any
        ] = None,  # TODO: Remove this arg once the changes are in place
        session_ids: Optional[List[str]] = None,
        experiment_id: str = None,
        **kwargs,
    ):
        pass

    def persist_aggregated_metrics(
        self,
        evaluation_results: List[Mapping[str, List[EvaluatorData]]],
        aggregated_metrics: Result,
        **kwargs,
    ):
        # Not implemented for ArizePersistence because Arize automatically aggregates metrics.
        pass

    def clean(self):
        pass
