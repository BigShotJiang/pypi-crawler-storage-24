from pathlib import Path
from typing import Any, List, Mapping, Optional

import pandas as pd

from agentops.metrics.metrics import EvaluatorData
from agentops.persistence.persistence_base import PersistenceBase
from agentops.stats import Result
from agentops.type import DatasetModel, Message
from agentops.utils import json_dump
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)

DEFAULT_OUTPUT_DIR = "evaluation_results_output"


class DiskPersistence(PersistenceBase):
    def __init__(self, output_dir: str = DEFAULT_OUTPUT_DIR):
        if output_dir == DEFAULT_OUTPUT_DIR:
            logger.info(
                f"Evaluation results will be saved to {DEFAULT_OUTPUT_DIR}"
            )
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        ## set up directories
        self.messages_path = self.output_dir / "messages"
        self.messages_path.mkdir(parents=True, exist_ok=True)

        self.knowledge_base_metrics_path = (
            self.output_dir / "knowledge_base_metrics"
        )
        self.knowledge_base_metrics_path.mkdir(parents=True, exist_ok=True)

    def persist(
        self,
        test_cases: List[DatasetModel],
        messages: List[List[Message]],
        evaluation_results: List[Mapping[str, List[EvaluatorData]]],
        experiment_results: Optional[
            Any
        ] = None,  # TODO: Remove this arg once the changes are in place
        session_ids: Optional[List[str]] = None,
        experiment_id: str = None,
        **kwargs,
    ):
        summary_metrics = []

        for idx, test_case in enumerate(test_cases):
            test_case_name = test_case.dataset_name
            test_case_messages = messages[idx]
            test_case_evaluation_results = evaluation_results[idx].get(
                test_case_name
            )

            journey_success_result = [
                eval
                for eval in test_case_evaluation_results
                if eval.eval_name == "is_success"
            ][0]
            tagged_messages = journey_success_result.metadata.get(
                "tagged_messages"
            )
            tagged_messages = [
                message.model_dump() for message in tagged_messages
            ]
            # save messages
            test_case_messages = [
                message.model_dump() for message in test_case_messages
            ]
            json_dump(
                self.messages_path / f"{test_case_name}.messages.json",
                test_case_messages,
            )
            json_dump(
                self.messages_path / f"{test_case_name}.messages.analyze.json",
                tagged_messages,
            )

            # save metadata
            test_session_id = session_ids[idx]
            json_dump(
                self.output_dir / f"{test_case_name}.metadata.json",
                {"thread_id": test_session_id},
            )

            # save messages
            metrics = {
                result.eval_name: result.value
                for result in test_case_evaluation_results
            }
            metrics["dataset_name"] = test_case_name
            summary_metrics.append(metrics)
            json_dump(
                self.messages_path / f"{test_case_name}.metrics.json", metrics
            )

        df = pd.DataFrame(summary_metrics)
        df.to_csv(self.output_dir / "summary_metrics.csv", index=False)

    def persist_aggregated_metrics(self, aggregated_metrics: Result, **kwargs):
        json_dump(
            self.output_dir / "average_metrics.json", aggregated_metrics.overall
        )

    def clean(self):
        pass
