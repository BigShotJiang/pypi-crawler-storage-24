from abc import ABCMeta
from threading import Lock, RLock
from typing import Any, Dict, Tuple

from pydantic import BaseModel


class InstancesCacheKey(BaseModel):
    class_name: str
    hashed_args: str
    hashed_kwargs: str

    def __str__(self) -> str:
        return f"{self.class_name}|{self.hashed_args}|{self.hashed_kwargs}"


class ThreadSafeSingleton(type):
    _instantiation_lock = RLock()
    _instances = {}

    def __call__(cls, *args, **kwargs):
        key_str: str = str(cls.get_key(cls.__name__, args, kwargs))
        if key_str not in cls._instances:
            with cls._instantiation_lock:
                if key_str not in cls._instances:
                    cls._instances[key_str] = super().__call__(*args, **kwargs)
        return cls._instances[key_str]

    @staticmethod
    def get_key(
        class_name: str, args: Tuple[Any, ...], kwargs: Dict[str, Any]
    ) -> InstancesCacheKey:

        args_str = str(args) if args else "noargs"
        kwargs_str = str(sorted(kwargs.items())) if kwargs else "nokwargs"

        return InstancesCacheKey(
            class_name=class_name,
            hashed_args=args_str,
            hashed_kwargs=kwargs_str,
        )

    @staticmethod
    def get_instance(cls, *args, **kwargs):
        key_str: str = str(cls.get_key(cls.__name__, args, kwargs))
        return cls._instances.get(key_str)


class ThreadSafeSingletonABCMeta(ABCMeta, ThreadSafeSingleton):
    pass
