import json
from typing import List

from langchain_core.messages import AIMessage, ToolMessage
from langgraph.graph.state import CompiledStateGraph

from agentops.runtime_adapter.runtime_adapter import RuntimeAdapter
from agentops.type import (
    ContentType,
    Function,
    Message,
    RuntimeResponse,
    ToolCall,
)


class LanggraphRuntimeAdapter(RuntimeAdapter):
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent

    def _convert_langchain_messages(
        self, lc_messages: list, skip_first_user: bool = True
    ) -> List[Message]:
        """Convert LangChain messages to agentops Message format."""
        messages = []
        start_idx = 1 if skip_first_user else 0

        for lc_msg in lc_messages[start_idx:]:
            if isinstance(lc_msg, AIMessage):
                if lc_msg.tool_calls:
                    # AI message with tool calls
                    tool_calls = [
                        ToolCall(
                            id=tc["id"],
                            function=Function(
                                name=tc["name"],
                                arguments=json.dumps(tc["args"]),
                            ),
                        )
                        for tc in lc_msg.tool_calls
                    ]
                    messages.append(
                        Message(
                            role="assistant",
                            content=lc_msg.content or "",
                            type=ContentType.tool_call,
                            tool_calls=tool_calls,
                        )
                    )
                else:
                    # Regular AI text response
                    messages.append(
                        Message(
                            role="assistant",
                            content=lc_msg.content,
                            type=ContentType.text,
                        )
                    )
            elif isinstance(lc_msg, ToolMessage):
                # Tool response
                messages.append(
                    Message(
                        role="tool",
                        content=lc_msg.content,
                        type=ContentType.tool_response,
                        tool_call_id=lc_msg.tool_call_id,
                    )
                )

        return messages

    def run(
        self,
        user_message: Message,
        context: dict,
        thread_id=None,
    ) -> RuntimeResponse:

        message_json = user_message.model_dump()
        messages = {"messages": [message_json]}
        response = self.agent.invoke(
            messages, config={"configurable": {"thread_id": thread_id}}
        )

        # Convert all intermediate messages (tool calls, tool responses, etc.)
        converted_messages = self._convert_langchain_messages(
            response["messages"], skip_first_user=True
        )

        return RuntimeResponse(messages=converted_messages, thread_id=thread_id)
