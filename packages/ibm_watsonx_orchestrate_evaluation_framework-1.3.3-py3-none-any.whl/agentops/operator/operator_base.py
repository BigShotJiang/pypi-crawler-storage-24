from collections.abc import Iterable
from enum import StrEnum
from typing import Any, Mapping, Optional

from agentops.service_provider.provider import Provider
from agentops.singleton import ThreadSafeSingletonABCMeta
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)


class OperatorTypes(StrEnum):
    extractor = "Extractor"
    evaluator = "Evaluation"


def get_operator_type(operator):
    class_name = operator.__class__.__name__

    # import here to avoid circular import
    from agentops.extractors.extractor_base import Extractor
    from agentops.metrics.evaluations import Evaluation

    if isinstance(operator, Extractor):
        return "extractor"
    if isinstance(operator, Evaluation):
        return "metric"

    raise TypeError(
        f"`{class_name}` must inherit from either `Evaluation` or `Extractor`"
    )


class OperatorBase(metaclass=ThreadSafeSingletonABCMeta):
    def __init__(self, llm_client: Optional[Provider] = None):
        self._dependencies = []
        self.llm_client = llm_client

    @property
    def dependencies(self):
        return self._dependencies

    @dependencies.setter
    def dependencies(self, d):
        self._dependencies = d

    @property
    def llm_client(self) -> Any:
        """Access client, require it if used."""
        if self._llm_client is None:
            raise RuntimeError(
                f"{self.__class__.__name__} requires a client, but none was provided"
            )
        return self._llm_client

    @llm_client.setter
    def llm_client(self, llm_client: Provider):
        self._llm_client = llm_client

    @classmethod
    def update_context(
        cls, obj, results, extracted_context: Mapping[str, Any] = None
    ):
        operator_type = get_operator_type(obj)
        obj_key = OperatorBase.key(obj)

        if not isinstance(results, list):
            results = [results]

        if operator_type not in extracted_context:
            extracted_context[operator_type] = {}

        results_dict = {}
        for result in results:
            if operator_type == "extractor":
                results_dict[result.field_name] = result
            elif operator_type == "metric":
                results_dict[result.eval_name] = result

        extracted_context[operator_type].update({obj_key: results_dict})

    @staticmethod
    def key(obj):
        # this function is used to generate a key for the operator
        # the key is then used to retrieve the operator from the extracted context
        # remove _dependencies since it is not needed to differentiate between operators
        instance_dict = {
            k: v for k, v in obj.__dict__.items() if k != "_dependencies"
        }
        _key = f"{obj.__class__.__name__}|{sorted(instance_dict.items())}"

        return _key
