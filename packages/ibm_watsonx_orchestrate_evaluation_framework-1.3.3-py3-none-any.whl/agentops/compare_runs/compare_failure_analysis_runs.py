from pathlib import Path

from agentops.utils.utils import read_json_file


def load_failure_dicts(
    ref_failure_dict_path: Path, exp_failure_dict_path: Path
) -> tuple[dict, dict]:
    """Load Failure Dictionaries

    Args:
        ref_failure_dict_path (Path): path for reference benchmark failure dictionary
        exp_failure_dict_path (Path): path for experiment benchmark failure dictionary

    Returns:
        tuple[dict, dict]: the failure dictionaries as a tuple
    """
    if ref_failure_dict_path.is_file() and exp_failure_dict_path.is_file():
        ref_failure_dict = read_json_file(ref_failure_dict_path)
        exp_failure_dict = read_json_file(exp_failure_dict_path)
        return ref_failure_dict, exp_failure_dict
    else:
        return {}, {}


def diff_reason_for_failure_in_benchmark(
    ref_failure_dict: dict, exp_failure_dict: dict
) -> dict:
    """generate data to check the difference between occurrence of a failure reason in 2 benchmarks

    Args:
        ref_failure_dict (dict): reference benchmark failure dict
        exp_failure_dict (dict): experiment benchmark failure dict

    Returns:
        dict: dict of {reason : Difference in occurrence}
    """
    reason_diff_dict = {}
    for k, v in exp_failure_dict["reason_tool_map"].items():
        diff = len(v) - len(
            ref_failure_dict["reason_tool_map"][k]
            if k in ref_failure_dict["reason_tool_map"]
            else []
        )
        if diff:
            reason_diff_dict[k] = diff
            if k == "runtime error":
                exp_runtime_disambiguated = [
                    inst
                    for inst in v
                    if inst["reason"] != "No error details present"
                ]
                ref_runtime_disambiguated = [
                    inst
                    for inst in ref_failure_dict["reason_tool_map"][k]
                    if inst["reason"] != "No error details present"
                ]
                reason_diff_dict["runtime error disambiguated"] = len(
                    exp_runtime_disambiguated
                ) - len(ref_runtime_disambiguated)

    return reason_diff_dict


def diff_tool_failures_in_experiment(
    ref_failure_dict: dict, exp_failure_dict: dict
) -> dict:
    """Find a dict of tools and their respective tests that failed in experiment but not in the reference benchmark

    Args:
        ref_failure_dict (dict): reference benchmark failure dict
        exp_failure_dict (dict): experiment benchmark failure dict

    Returns:
        dict: dict of {tool_name : [test_names]}
    """
    tool_dict = {
        k: set(
            [
                test["test_name"]
                for test in exp_failure_dict["tool_reason_map"][k]
            ]
        )
        for k in set(exp_failure_dict["tool_reason_map"])
        - set(ref_failure_dict["tool_reason_map"])
    }
    return tool_dict


def check_regression_in_exp_tools(
    ref_failure_dict: dict, exp_failure_dict: dict
) -> dict:
    """Function to find how much did a tool regress/improve between two benchmarks

    Args:
        ref_failure_dict (_type_): reference benchmark failure
        exp_failure_dict (_type_): experiment benchmark failure

    Returns:
        dict: dict of {tool_name : change_count}
    """
    regression_dict = {}
    for key, val in exp_failure_dict["tool_reason_map"].items():
        if key in ref_failure_dict["tool_reason_map"].keys():
            # Disambiguate the runtime errors to weed out the unnecessary ones
            val = [
                reason
                for reason in val
                if reason["reason"] != "No error details present"
            ]
            ref_vals = [
                reason
                for reason in ref_failure_dict["tool_reason_map"][key]
                if reason["reason"] != "No error details present"
            ]
            diff = len(val) - len(ref_vals)
            if diff != 0:
                regression_dict[key] = len(val) - len(ref_vals)
    return regression_dict


def show_tests_affected_by_changes_in_tools(
    ref_failure_dict: dict, exp_failure_dict: dict
) -> dict:
    """Find the specific tests affected when a tool fails in both experiment and reference benchmark

    Args:
        ref_failure_dict (dict): _description_
        exp_failure_dict (dict): _description_

    Returns:
        dict: _description_
    """
    diff_dict = {}
    for key, val in exp_failure_dict["tool_reason_map"].items():
        if key in ref_failure_dict["tool_reason_map"].keys():
            # Disambiguate the runtime errors to weed out the unnecessary ones
            ref_tool_fails = [
                reason
                for reason in ref_failure_dict["tool_reason_map"][key]
                if reason["reason"] != "No error details present"
            ]
            exp_vals = [
                reason
                for reason in val
                if reason["reason"] != "No error details present"
            ]
            test_names_exp = set([t["test_name"] for t in exp_vals])
            test_names_ref = set([t["test_name"] for t in ref_tool_fails])
            diff_set = test_names_exp - test_names_ref
            if diff_set:
                diff_dict[key] = diff_set
    return diff_dict
