import subprocess
import sys
from pathlib import Path

import pandas as pd
from jsonargparse import CLI
from rich.console import Console

from agentops.arg_configs import CompareRunsConfig
from agentops.compare_runs.compare_failure_analysis_runs import (
    check_regression_in_exp_tools,
    diff_reason_for_failure_in_benchmark,
    diff_tool_failures_in_experiment,
    load_failure_dicts,
    show_tests_affected_by_changes_in_tools,
)
from agentops.compare_runs.diff import DiffResults
from agentops.compare_runs.model import SummaryMetricsDF
from agentops.utils.utils import (
    create_table,
    create_table_from_dict_with_key_as_rows,
)

console = Console()


def main(config: CompareRunsConfig):
    """Main function to compare two run result files."""
    # Extract values from config
    ref_dir = Path(config.reference_benchmark_location)
    exp_dir = Path(config.experiment_benchmark_location)
    reference_file = ref_dir / "summary_metrics.csv"
    experiment_file = exp_dir / "summary_metrics.csv"

    try:
        # Create evaluation results directly from files
        result1 = SummaryMetricsDF.from_csv(reference_file)
        result2 = SummaryMetricsDF.from_csv(experiment_file)

        # Create diff results
        diff_results = DiffResults(result1, result2)

        # Get and print summary statistics table
        summary_stats_table = diff_results.get_summary_statistics_table()
        tmp_table = create_table(
            summary_stats_table, title="Summary Statistics"
        )
        if tmp_table:
            tmp_table.print()

        # Get and print non-overlapping test cases
        only_in_ref, only_in_exp = diff_results.get_non_overlapping_test_cases()
        print(f"\nTest cases only in reference: {len(only_in_ref)}")
        if only_in_ref:
            print(only_in_ref)
        print(f"\nTest cases only in experiment: {len(only_in_exp)}")
        if only_in_exp:
            print(only_in_exp)

        # Get and print column statistics table
        column_stats_table = (
            diff_results.get_overlapping_summary_metrics_table()
        )
        tmp_table = create_table(column_stats_table, title="Average Values")
        if tmp_table:
            tmp_table.print()

        diffs_tables: dict[str, pd.DataFrame] = {}
        # Print all column differences
        for column_name, display_name in [
            ("text_match", "Text Match"),
            ("is_success", "Is Success"),
        ]:
            diffs_table = diff_results.get_column_differences(column_name)
            if not diffs_table.empty:
                tmp_table = create_table(
                    diffs_table, title=f"{display_name} Differences"
                )
                if tmp_table:
                    tmp_table.print()
                diffs_tables[column_name] = diffs_table
            else:
                print(f"\n{display_name} Differences")
                print(
                    f"No differences found - all overlapping test cases have matching {column_name} values"
                )

        # Generate failure report if requested
        if config.generate_failure_report:
            print("\n" + "=" * 80)
            print("Generating Failure Analysis Reports...")
            print("=" * 80 + "\n")

            # Run analyze_run for both reference and experiment directories
            for dir_path, dir_name in [
                (ref_dir, "Reference"),
                (exp_dir, "Experiment"),
            ]:
                print(
                    f"\nGenerating failure analysis for {dir_name} directory..."
                )
                analyze_cmd = [
                    sys.executable,
                    "-m",
                    "agentops.analyze_run",
                    "--data_path",
                    str(dir_path),
                    "--generate_report",
                    "True",
                ]

                try:
                    subprocess.run(
                        analyze_cmd, check=True, capture_output=True, text=True
                    )
                    print(
                        f"{dir_name} failure analysis report generated successfully!"
                    )
                except subprocess.CalledProcessError as e:
                    print(f"Error generating {dir_name} failure report: {e}")
                    if e.stderr:
                        print(f"Error details: {e.stderr}")

        ref_dict, exp_dict = load_failure_dicts(
            ref_dir / "failure_dict.json",
            exp_dir / "failure_dict.json",
        )
        if ref_dict and exp_dict:
            create_table_from_dict_with_key_as_rows(
                title="Reasons for Failure",
                caption="Difference in count of failures (Experiment - Reference)",
                columns=["Reason", "Change"],
                data=diff_reason_for_failure_in_benchmark(
                    ref_failure_dict=ref_dict, exp_failure_dict=exp_dict
                ),
            )
            create_table_from_dict_with_key_as_rows(
                title="New Tool Failures",
                caption="Tools that did not fail in Reference benchmark and the tests impacted",
                columns=["Tool Name", "Test Names"],
                data=diff_tool_failures_in_experiment(
                    ref_failure_dict=ref_dict, exp_failure_dict=exp_dict
                ),
            )
            create_table_from_dict_with_key_as_rows(
                title="Tool Regression/Improvement",
                caption="Change in tool failure counted as (Experiment - Reference)",
                columns=["Tool Name", "Change"],
                data=check_regression_in_exp_tools(
                    ref_failure_dict=ref_dict, exp_failure_dict=exp_dict
                ),
            )
            create_table_from_dict_with_key_as_rows(
                title="Tests impacted by change in Tool behavior",
                caption="Tools that failed in both experiment and reference benchmark and impacted tests",
                columns=["Tool Name", "Test Names"],
                data=show_tests_affected_by_changes_in_tools(
                    ref_failure_dict=ref_dict, exp_failure_dict=exp_dict
                ),
            )
        else:
            print(
                f"\n NO Failure Analysis Results to compare, set `generate_failure_report` to True in the config/command to generate the report or generate it for each benchmark by following the steps in the Failure Analysis Report section of the docs before running the comparison"
            )

        ## write each table to a csv in a specified folder
        if config.csv_output_dir:
            csv_output_dir = Path(config.csv_output_dir)
            csv_output_dir.mkdir(parents=True, exist_ok=True)

            summary_stats_table.to_csv(
                csv_output_dir / "summary_statistics.csv", index=False
            )
            column_stats_table.to_csv(
                csv_output_dir / "average_values.csv", index=False
            )
            # Saves all diffs_table
            for name, table in diffs_tables.items():
                table.to_csv(
                    csv_output_dir / f"diff_results_{name}.csv", index=False
                )

            print(f"\nCSV files written to {csv_output_dir}/")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    args = CLI(CompareRunsConfig, as_positional=False)
    sys.exit(main(args))

# Made with Bob
