import os
from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, computed_field


class Platform(StrEnum):
    LANGFUSE = "langfuse"
    ARIZE = "arize"
    NONE = "none"


class TelemetryPlatform(BaseModel):
    @computed_field
    @property
    def platform(self) -> Optional[str]:
        platform = os.getenv("TELEMETRY_PLATFORM")
        if platform is None or platform.lower() == "none":
            return None
        if platform not in Platform._value2member_map_:
            raise ValueError(
                f"Invalid platform: {platform}. The supported platforms are: {list(Platform)}"
            )

        return platform

    @computed_field
    @property
    def is_disabled(self) -> bool:
        return self.platform is None

    @computed_field
    @property
    def is_langfuse(self) -> bool:
        return self.platform == Platform.LANGFUSE

    @computed_field
    @property
    def is_arize(self) -> bool:
        return self.platform == Platform.ARIZE
