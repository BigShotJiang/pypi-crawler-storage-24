from typing import Any, List, Mapping, Optional, Union

from pydantic import BaseModel
from rich import box
from rich.console import Console
from rich.table import Table

from agentops.stats import Result
from agentops.type import ExtendedMessage


class ExperimentResult(BaseModel):
    experiment_name: str
    experiment_id: str
    metrics: list
    session_ids: Optional[List[str]] = None
    aggregate_metrics: Result
    extended_messages: Union[
        List[Mapping[str, List[ExtendedMessage]]], None
    ] = None

    def print_metrics(self, display: List[str] = []):
        # the same metrics are computed for each run
        console = Console()

        metric_names = self.aggregate_metrics.overall.keys()
        if display:
            metric_names = filter(lambda x: x in display, metric_names)

        table = Table(
            title="Evaluation Results",
            box=box.ROUNDED,
            show_lines=True,
        )
        table.add_column("Datasets", style="bold cyan", no_wrap=False)

        for metric_name in metric_names:
            table.add_column(metric_name, justify="center", no_wrap=False)

        for (
            dataset_name,
            averaged_scores,
        ) in self.aggregate_metrics.per_dataset.items():
            row = [dataset_name]
            for metric_name in metric_names:
                row.append(str(averaged_scores.get(metric_name, "")))
            table.add_row(*row)

        console.print(table)
