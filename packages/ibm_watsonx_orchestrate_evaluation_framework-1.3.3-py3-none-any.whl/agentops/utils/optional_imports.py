"""Utilities for optional dependency imports."""

import importlib.util
from typing import Any

LANGFUSE_INSTALL_MSG = (
    "Langfuse is not installed. Install it with: "
    "pip install ibm-watsonx-orchestrate-evaluation-framework[langfuse]"
)


def is_langfuse_available() -> bool:
    """Check if langfuse is installed."""
    return importlib.util.find_spec("langfuse") is not None


def require_langfuse() -> None:
    """Raise ImportError if langfuse is not installed."""
    if not is_langfuse_available():
        raise ImportError(LANGFUSE_INSTALL_MSG)


class LazyLangfuseImport:
    """Lazy import wrapper for langfuse modules.

    Delays import until attribute access, allowing modules to be
    imported without langfuse installed as long as langfuse
    functionality is not used.
    """

    def __init__(self, module_path: str):
        self._module_path = module_path
        self._module = None

    def _load_module(self):
        if self._module is None:
            require_langfuse()
            self._module = importlib.import_module(self._module_path)
        return self._module

    def __getattr__(self, name: str) -> Any:
        module = self._load_module()
        return getattr(module, name)


def get_langfuse_client():
    """Get the langfuse client, raising ImportError if not installed."""
    require_langfuse()
    from langfuse import get_client

    return get_client()


def get_langfuse_class():
    """Get the Langfuse class, raising ImportError if not installed."""
    require_langfuse()
    from langfuse import Langfuse

    return Langfuse
