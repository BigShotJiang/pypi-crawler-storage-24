from typing import Any, Mapping, Optional

from agentops.utils.telemetry_platform import TelemetryPlatform


def Collection(
    name: str,
    description: str = "",
    metadata: Mapping[str, str] = {},
    client: Optional[Any] = None,
):
    telemetry_platform = TelemetryPlatform()
    if telemetry_platform.is_disabled:
        return None
    elif telemetry_platform.is_langfuse:
        from agentops.collection.langfuse_collection import LangfuseCollection

        return LangfuseCollection(name, description, metadata, client)
    elif telemetry_platform.is_arize:
        from agentops.collection.arize_collection import ArizeCollection

        return ArizeCollection(name, description, metadata, client)
    else:
        raise ValueError(
            f"Invalid telemetry platform: {telemetry_platform.platform}"
        )
