import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, List, Mapping, Optional, Union

from agentops.type import CollectionModel, DatasetModel
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)


class CollectionBase(ABC):
    def __init__(
        self,
        name: str,
        description: str = "",
        metadata: Mapping[str, str] = {},
        client: Optional[Any] = None,
    ):
        self.name = name
        self.description = description
        self.metadata = metadata
        self.client = client

    @property
    def dataset_id(self) -> str:
        return ""

    @abstractmethod
    def _process_item(self, item: Mapping[str, Any]) -> DatasetModel:
        pass

    def _filter_available_datasets(
        self, collection: CollectionModel, overwrite: bool = False
    ) -> List[int]:
        available_datasets = [
            self._process_item(item) for item in self.get_data_items()
        ]
        indices_to_upload = []
        for idx, dataset in enumerate(collection.datasets):
            if (not overwrite) and dataset in available_datasets:
                logger.info(
                    f"[g]Skipping upload! Dataset already available in collection '{collection.collection_name}'"
                )
                continue
            indices_to_upload.append(idx)
        return indices_to_upload

    def _read_dataset(self, paths: Union[str, List[str]]) -> CollectionModel:
        datasets = []
        if isinstance(paths, str):
            paths = [paths]

        for path in paths:
            with open(path, encoding="utf-8") as f:
                dataset = json.load(f)
                dataset_name = Path(path).stem
                dataset = DatasetModel(
                    dataset_name=dataset_name,
                    starting_sentence=dataset.get("starting_sentence", ""),
                    story=dataset.get("story", ""),
                    goals=dataset.get("goals"),
                    goal_details=dataset.get("goal_details"),
                    agent=dataset.get("agent"),
                    runtime_context=dataset.get("runtime_context"),
                    file_upload=dataset.get("file_upload"),
                    attack_data=dataset.get("attack_data", None),
                    agents_list_or_path=dataset.get(
                        "agents_list_or_path", None
                    ),
                )
                datasets.append(dataset)

        collection = CollectionModel(
            collection_name=self.name,
            collection_description=self.description,
            datasets=datasets,
            metadata=self.metadata,
        )

        return collection

    @abstractmethod
    def get_dataset(self):
        pass

    @abstractmethod
    def get_data_items(self):
        pass

    @abstractmethod
    def upload(self, paths: Union[str, List[str]], overwrite: bool = False):
        pass

    @abstractmethod
    def delete_item(self, item_id: str):
        pass

    @abstractmethod
    def delete_all_items(self):
        pass
