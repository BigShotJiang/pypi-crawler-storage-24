from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData


class DummyMetric(Evaluation):
    def do_evaluate(
        self,
        messages,
        ground_truth=None,
        metadata=None,
        **kwargs,
    ):
        return EvaluatorData(
            eval_name="dummy_metric",
            value=True,
            metadata=metadata,
            data_type="BOOLEAN",
        )


if __name__ == "__main__":
    metric = DummyMetric()

    import rich

    rich.print(metric.evaluate(messages=[], ground_truth=[]))
