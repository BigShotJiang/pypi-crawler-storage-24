"""Example: Coding Agent - A specialized agent for code tasks."""

from agenai.agent import SpecializedAgent, AgentConfig, HookRegistry, HookEvent, on_tool_end
from agenai.agent.tools.base import Tool, ToolResult
from agenai.agent.tools.read_file import ReadFileTool
from agenai.agent.tools.write_file import WriteFileTool
from agenai.agent.tools.run_command import RunCommandTool


class CodingAgent(SpecializedAgent):
    """Agent specialized for coding tasks."""

    name = "coding"
    description = "Writes, modifies, and debugs code"

    def get_system_prompt(self) -> str:
        return """You are an expert software engineer.

Your capabilities:
- Read existing code files
- Write new code or modify existing code
- Run shell commands to test code
- Debug issues

Guidelines:
- Write clean, well-documented code
- Follow best practices for the language
- Test your changes when possible
- Explain your changes clearly

When given a coding task:
1. First understand the existing code (if any)
2. Plan your approach
3. Implement changes
4. Test if possible
5. Explain what you did"""

    def get_tools(self) -> list[Tool]:
        return [
            ReadFileTool(),
            WriteFileTool(),
            RunCommandTool(),
        ]


# Example with hooks for observability
if __name__ == "__main__":
    import os

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("Set ANTHROPIC_API_KEY environment variable")
        exit(1)

    # Create hooks for logging
    hooks = HookRegistry()

    @hooks.on(HookEvent.TOOL_START)
    def log_tool_start(data):
        print(f"  -> Calling tool: {data.tool_name}")

    @hooks.on(HookEvent.TOOL_END)
    def log_tool_end(data):
        status = "OK" if data.tool_result and data.tool_result.success else "FAILED"
        print(f"  <- Tool {data.tool_name}: {status}")

    @hooks.on(HookEvent.STEP_END)
    def log_step(data):
        print(f"  Step {data.step_number} completed")

    # Create agent with hooks
    agent = CodingAgent(
        config=AgentConfig(
            model="claude-sonnet-4-6",
            max_steps=15,
        ),
        hooks=hooks,
    )

    result = agent.run("Create a simple Python function that calculates fibonacci numbers")

    if result.success:
        print("\n=== Result ===")
        print(result.output)
    else:
        print(f"Error: {result.error}")
