"""Example: Research Agent - A specialized agent for web research."""

from agenai.agent import SpecializedAgent, AgentConfig, AgentContext, AgentResult
from agenai.agent.tools.base import Tool, ToolResult
from agenai.agent.tools.http_request import HttpRequestTool


class WebSearchTool(Tool):
    """Simulated web search tool (replace with real implementation)."""

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Search the web for information on a topic."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                }
            },
            "required": ["query"],
        }

    def execute(self, query: str) -> ToolResult:
        # In production, this would call a real search API
        return ToolResult.ok(
            f"Search results for '{query}':\n"
            "1. [Example Result 1] - Summary of first result\n"
            "2. [Example Result 2] - Summary of second result\n"
            "3. [Example Result 3] - Summary of third result"
        )


class ResearchAgent(SpecializedAgent):
    """Agent specialized for researching topics."""

    name = "research"
    description = "Researches topics using web search and provides summaries"

    def get_system_prompt(self) -> str:
        return """You are a research assistant specialized in finding and synthesizing information.

Your process:
1. Break down the research question into searchable queries
2. Use web_search to find relevant information
3. Synthesize findings into a clear, cited summary

Guidelines:
- Always cite your sources
- Distinguish between facts and opinions
- Note any conflicting information
- Be concise but thorough"""

    def get_tools(self) -> list[Tool]:
        return [
            WebSearchTool(),
            HttpRequestTool(),
        ]

    def on_start(self, context: AgentContext) -> None:
        print(f"[Research Agent] Starting research: {context.user_input[:50]}...")

    def on_complete(self, result: AgentResult) -> None:
        if result.success:
            print(f"[Research Agent] Completed with {len(result.steps)} steps")
        else:
            print(f"[Research Agent] Failed: {result.error}")


# Example usage
if __name__ == "__main__":
    import os

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("Set ANTHROPIC_API_KEY environment variable")
        exit(1)

    agent = ResearchAgent(
        config=AgentConfig(
            model="claude-sonnet-4-6",
            max_steps=10,
        )
    )

    result = agent.run("What are the latest developments in AI agents?")

    if result.success:
        print("\n=== Research Results ===")
        print(result.output)
    else:
        print(f"Error: {result.error}")
