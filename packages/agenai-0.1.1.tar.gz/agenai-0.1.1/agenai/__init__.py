"""Agenai - A modular, extensible AI agent system."""

from agenai.agent.core import Agent
from agenai.agent.config import AgentConfig

__version__ = "0.1.0"
__all__ = ["Agent", "AgentConfig"]
