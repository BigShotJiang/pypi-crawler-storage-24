"""Specialized agents built on the agenai framework."""

from agenai.agents.teaching_assistant import TeachingAssistantAgent

__all__ = [
    "TeachingAssistantAgent",
]
