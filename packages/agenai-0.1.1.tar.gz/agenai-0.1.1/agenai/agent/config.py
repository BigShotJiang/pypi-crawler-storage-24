"""Agent configuration."""

from pathlib import Path
from pydantic import BaseModel, Field


class AgentConfig(BaseModel):
    """Configuration for an AI agent."""

    model: str = Field(
        default="claude-sonnet-4-6",
        description="Model identifier (e.g., 'claude-sonnet-4-6', 'claude-opus-4-6')",
    )
    system_prompt: str = Field(
        default="You are a helpful AI assistant.",
        description="System prompt defining agent persona and instructions",
    )
    max_steps: int = Field(
        default=20,
        ge=1,
        le=100,
        description="Maximum number of agent loop iterations (safety limit)",
    )
    max_tokens: int = Field(
        default=4096,
        ge=1,
        description="Maximum tokens per LLM response",
    )
    temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Sampling temperature (0.0 = deterministic, 1.0 = creative)",
    )
    tools: list[str] = Field(
        default_factory=list,
        description="List of enabled tool names",
    )

    @classmethod
    def from_file(cls, path: Path) -> "AgentConfig":
        """Load configuration from a JSON file."""
        import json

        with open(path) as f:
            data = json.load(f)
        return cls(**data)

    def with_system_prompt_from_file(self, path: Path) -> "AgentConfig":
        """Return a new config with system prompt loaded from a file."""
        with open(path) as f:
            prompt = f.read()
        return self.model_copy(update={"system_prompt": prompt})
