"""Agent module - Core agent components."""

from agenai.agent.config import AgentConfig
from agenai.agent.context import AgentContext
from agenai.agent.core import Agent, AgentResult, StepResult, StepType
from agenai.agent.async_core import AsyncAgent, StreamChunk
from agenai.agent.hooks import (
    Hook,
    HookData,
    HookEvent,
    HookRegistry,
    FunctionHook,
    on_tool_start,
    on_tool_end,
    on_step,
    on_error,
)
from agenai.agent.llm import LLMProvider, AnthropicProvider, LLMResponse, ToolCall
from agenai.agent.llm_ollama import OllamaProvider
from agenai.agent.memory import ConversationMemory, Message, MessageRole
from agenai.agent.retry import RetryConfig, RetryError, with_retry, Retrier
from agenai.agent.specialized import SpecializedAgent, ChainedAgent, RouterAgent

__all__ = [
    # Core
    "Agent",
    "AsyncAgent",
    "AgentConfig",
    "AgentContext",
    "AgentResult",
    "StepResult",
    "StepType",
    "StreamChunk",
    # LLM
    "LLMProvider",
    "AnthropicProvider",
    "OllamaProvider",
    "LLMResponse",
    "ToolCall",
    # Memory
    "ConversationMemory",
    "Message",
    "MessageRole",
    # Hooks
    "Hook",
    "HookData",
    "HookEvent",
    "HookRegistry",
    "FunctionHook",
    "on_tool_start",
    "on_tool_end",
    "on_step",
    "on_error",
    # Retry
    "RetryConfig",
    "RetryError",
    "with_retry",
    "Retrier",
    # Specialized
    "SpecializedAgent",
    "ChainedAgent",
    "RouterAgent",
]
