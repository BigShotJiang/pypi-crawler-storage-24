"""CLI for running the Agenai server."""

import argparse


def main():
    """Run the Agenai server."""
    parser = argparse.ArgumentParser(description="Run the Agenai web server")
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development",
    )

    args = parser.parse_args()

    try:
        import uvicorn
    except ImportError:
        print("Error: uvicorn not installed.")
        print("Install server dependencies: pip install -e '.[server]'")
        return 1

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    Agenai Server                             ║
╠══════════════════════════════════════════════════════════════╣
║  Web UI:    http://{args.host}:{args.port}                          ║
║  API Docs:  http://{args.host}:{args.port}/docs                     ║
║  Health:    http://{args.host}:{args.port}/health                   ║
╠══════════════════════════════════════════════════════════════╣
║  Make sure Ollama is running: ollama serve                   ║
║  Pull a model: ollama pull llama3.1                          ║
╚══════════════════════════════════════════════════════════════╝
""")

    uvicorn.run(
        "agenai.server.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
