"""Tests for agenai."""
