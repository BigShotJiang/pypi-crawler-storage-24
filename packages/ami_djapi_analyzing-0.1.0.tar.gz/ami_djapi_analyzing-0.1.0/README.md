# ami-djAPI-analyzing

Lightweight **ami-djAPI-analyzing** for analyzing SQL queries, request performance, and detecting common database issues like **N+1 queries, duplicate queries, slow queries, and missing indexes**.

It provides detailed profiling information directly in the response headers and API responses.

---

# Features

• Capture all SQL queries executed during a request  
• Detect **N+1 queries automatically**  
• Detect **duplicate queries**  
• Detect **slow SQL queries**  
• Detect **potential missing indexes**  
• Analyze **database time vs total response time**  
• **Performance score system (A–F grading)**  
• Track **request history**  
• Capture **memory usage**  
• Generate **EXPLAIN plans for slow queries**  
• Optional **step-by-step view execution profiler**  
• Encrypted performance payload in response headers  

---

# Installation

```bash
pip install ami-djAPI-analyzing