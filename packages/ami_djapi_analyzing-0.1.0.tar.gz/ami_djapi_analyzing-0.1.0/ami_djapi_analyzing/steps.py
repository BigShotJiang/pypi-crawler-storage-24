import functools
import sys
import time
import linecache
import os


class StepProfiler:

    def __init__(self, target_file=None, max_steps=2000):
        self.target_file = target_file
        self.max_steps = max_steps
        self.steps = []
        self.start_time = None
        self._original_trace = None

    def _trace(self, frame, event, arg):

        try:
            if event != "line":
                return self._trace

            filename = os.path.basename(frame.f_code.co_filename)

            # Only track API file
            if filename != self.target_file:
                return self._trace

            if len(self.steps) >= self.max_steps:
                return self._trace

            lineno = frame.f_lineno
            func_name = frame.f_code.co_name
            code_line = linecache.getline(frame.f_code.co_filename, lineno).strip()

            step = {
                "file": filename,
                "function": func_name,
                "line_no": lineno,
                "code": code_line,
                "time_from_start": round(time.time() - self.start_time, 6),
            }

            self.steps.append(step)

        except Exception:
            pass

        return self._trace

    def start(self):
        self.steps = []
        self.start_time = time.time()
        self._original_trace = sys.gettrace()
        sys.settrace(self._trace)

    def stop(self):
        sys.settrace(self._original_trace)
        return self.steps
    
def human_readable_time(seconds: float) -> str:

    if seconds <= 0:
        return "0 ms"

    if seconds < 0.001:
        return f"{round(seconds * 1_000_000, 2)} (Microseconds)"

    elif seconds < 1:
        return f"{round(seconds * 1000, 3)} ms (Milliseconds)"

    else:
        return f"{round(seconds, 3)} s (Seconds)"

def format_steps(steps):
    formatted = []
    prev_time = None

    for i, step in enumerate(steps, start=1):

        current_time = step.get("time_from_start", 0)

        if prev_time is None:
            step_time = 0
        else:
            step_time = current_time - prev_time

        prev_time = current_time

        formatted.append({
            "step": i,
            "file": step.get("file"),
            "function": step.get("function"),
            "line_no": step.get("line_no"),
            "code": step.get("code"),
            "execution_time": human_readable_time(step_time)
        })

    return formatted


def with_steps(view_func):

    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):

        view_file = os.path.basename(view_func.__code__.co_filename)

        profiler = StepProfiler(target_file=view_file)
        

        profiler.start()

        try:
            response = view_func(*args, **kwargs)
        finally:
            steps = profiler.stop()

        formatted_steps = format_steps(steps)

        if hasattr(response, "data") and isinstance(response.data, dict):

            response.data["profiler"] = {
                "total_steps": len(formatted_steps),
                "steps": formatted_steps,
            }

        return response

    return wrapper