import time
import traceback
import re
from django.db import connections
from django.conf import settings
import os
import base64
import json
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def detect_model_from_sql(sql):
    match = re.search(r'FROM\s+"?([\w_]+)"?', sql, re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def get_raw_sql(sql, params):
    """
    Return exact SQL executed by DB using cursor.mogrify()
    """
    try:
        from django.db import connection

        with connection.cursor() as cursor:
            raw_sql = cursor.mogrify(sql, params)

            if isinstance(raw_sql, bytes):
                raw_sql = raw_sql.decode("utf-8")

            return raw_sql

    except Exception:
        return sql


class QueryCaptureWrapper:

    def __init__(self):
        self.queries = []

    def _stack_trace(self):

        if not settings.DEBUG:
            return []

        stack = traceback.extract_stack()[:-3]

        return [
            {
                "file": frame.filename,
                "line": frame.lineno,
                "function": frame.name,
            }
            for frame in stack[-6:]
        ]

    def explain_query(self, sql, params):

        if not sql.lower().startswith("select"):
            return []

        try:
            with connections["default"].cursor() as cursor:
                cursor.execute(f"EXPLAIN {sql}", params or [])
                plan = cursor.fetchall()
                return [str(p) for p in plan]
        except Exception:
            return []

    def __call__(self, execute, sql, params, many, context):

        start = time.perf_counter()

        try:
            return execute(sql, params, many, context)

        finally:

            duration = time.perf_counter() - start
            model = detect_model_from_sql(sql)

            raw_sql = get_raw_sql(sql, params)

            query_data = {
                "sql": raw_sql,
                "params": params,
                "time": round(duration, 6),
                "model": model,
                "many": many,
                "stack_trace": self._stack_trace(),
            }

            if duration > 0.05:
                query_data["explain_plan"] = self.explain_query(sql, params)

            self.queries.append(query_data)


def generate_key() -> bytes:
    """Generate a 32-byte AES key"""
    return AESGCM.generate_key(bit_length=256)

def encrypt_data(data: dict, key: bytes) -> str:
    """Encrypt JSON-serializable dict and return base64 string"""
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)  # 12-byte nonce
    plaintext = json.dumps(data, default=str).encode("utf-8")
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    return base64.b64encode(nonce + ciphertext).decode("utf-8")

def decrypt_data(encrypted_b64: str, key_b64: str) -> dict:
    """Decrypt base64 string back to dict"""
    key = base64.b64decode(key_b64)
    raw = base64.b64decode(encrypted_b64)
    nonce, ciphertext = raw[:12], raw[12:]
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return json.loads(plaintext)
