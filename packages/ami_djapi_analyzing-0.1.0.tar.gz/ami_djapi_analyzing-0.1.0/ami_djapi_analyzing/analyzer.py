import re
from collections import defaultdict


SLOW_QUERY_THRESHOLD = 0.05


def normalize_sql(sql: str):
    """
    Normalize SQL to detect duplicates.
    """
    sql = re.sub(r"\s+", " ", sql)
    sql = re.sub(r"=\s*[\d']+", "= ?", sql)
    return sql.strip().lower()


def detect_duplicate_queries(queries):

    counter = defaultdict(list)

    for q in queries:
        key = normalize_sql(q["sql"])
        counter[key].append(q)

    duplicates = []

    for key, items in counter.items():
        if len(items) > 1:
            duplicates.append({
                "query": key,
                "count": len(items),
                "total_time": sum(q["time"] for q in items)
            })

    return duplicates


def detect_n_plus_one(queries):

    grouped = defaultdict(list)

    for q in queries:
        model = q.get("model")
        if model:
            grouped[model].append(q)

    n_plus_one = []

    for model, items in grouped.items():
        if len(items) > 5:
            n_plus_one.append({
                "model": model,
                "count": len(items),
                "suggestion": "Consider using select_related or prefetch_related"
            })

    return n_plus_one


def detect_slow_queries(queries):

    return [
        q for q in queries
        if q["time"] > SLOW_QUERY_THRESHOLD
    ]


def detect_missing_indexes(queries):

    problems = []

    for q in queries:

        sql = q["sql"].lower()

        if "where" in sql and "id" not in sql:
            problems.append({
                "sql": q["sql"],
                "reason": "Possible missing index on filtered column"
            })

    return problems


def build_suggestions(n_plus_one, duplicates, slow_queries, index_problems):

    suggestions = []

    if n_plus_one:
        suggestions.append(
            "Detected potential N+1 queries. Use select_related or prefetch_related."
        )

    if duplicates:
        suggestions.append(
            "Duplicate queries detected. Consider caching or query optimization."
        )

    if slow_queries:
        suggestions.append(
            "Slow queries detected. Add indexes or optimize joins."
        )

    if index_problems:
        suggestions.append(
            "Queries filtering non-indexed columns detected."
        )

    return suggestions


def analyze_queries(queries, response_time):

    duplicate_queries = detect_duplicate_queries(queries)

    n_plus_one = detect_n_plus_one(queries)

    slow_queries = detect_slow_queries(queries)

    index_problems = detect_missing_indexes(queries)

    suggestions = build_suggestions(
        n_plus_one,
        duplicate_queries,
        slow_queries,
        index_problems
    )

    total_db_time = round(sum(q["time"] for q in queries), 4)

    return {

        "query_count": len(queries),

        "total_db_time": total_db_time,

        "duplicate_details": duplicate_queries,
        "duplicate_query_count": len(duplicate_queries),

        "n_plus_one_details": n_plus_one,
        "n_plus_one_count": len(n_plus_one),

        "slow_queries": slow_queries,
        "slow_query_count": len(slow_queries),

        "missing_index_warnings": index_problems,

        "optimization_suggestions": suggestions,

        "is_slow_endpoint": response_time > 1.0,
    }