def calculate_score(analysis):

    score = 100

    if analysis["query_count"] > 20:
        score -= 25
    elif analysis["query_count"] > 10:
        score -= 10

    if analysis["total_db_time"] > 1.0:
        score -= 20
    elif analysis["total_db_time"] > 0.5:
        score -= 10

    if analysis["n_plus_one_count"] > 0:
        score -= 20

    if analysis["duplicate_query_count"] > 0:
        score -= 10

    if analysis["is_slow_endpoint"]:
        score -= 20

    score = max(score, 0)

    return {
        "score": score,
        "grade": grade_from_score(score),
    }


def grade_from_score(score):

    if score >= 90:
        return "A"
    elif score >= 75:
        return "B"
    elif score >= 60:
        return "C"
    elif score >= 40:
        return "D"
    else:
        return "F"