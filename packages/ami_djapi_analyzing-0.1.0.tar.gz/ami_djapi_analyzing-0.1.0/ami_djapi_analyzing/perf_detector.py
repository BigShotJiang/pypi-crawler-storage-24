# perf.py

import re
from collections import defaultdict, Counter


def detect_n_plus_one(queries, threshold=5):
    """
    Detect repeated similar queries (N+1).
    Normalizes numeric values.
    """

    normalized = defaultdict(list)

    for q in queries:
        sql = q["sql"]

        # Normalize numbers to detect pattern
        normalized_sql = re.sub(r"\b\d+\b", "?", sql)

        normalized[normalized_sql].append(sql)

    warnings = [
        {
            "query_sample": key[:120],
            "count": len(val)
        }
        for key, val in normalized.items()
        if len(val) >= threshold
    ]

    return warnings


def detect_duplicate_queries(queries):
    """
    Detect exact duplicate SQL queries.
    """

    sql_list = [q["sql"] for q in queries]
    counter = Counter(sql_list)

    duplicates = [
        {
            "query_sample": sql[:120],
            "count": count
        }
        for sql, count in counter.items()
        if count > 1
    ]

    return duplicates