import time
import tracemalloc
from collections import deque
from django.db import connections
from django.conf import settings

from .analyzer import analyze_queries
from .scorer import calculate_score
from .sql_collector import QueryCaptureWrapper, generate_key, encrypt_data
import base64


REQUEST_HISTORY = deque(maxlen=50)

class PerformanceMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        wrapper = QueryCaptureWrapper()
        tracemalloc.start()
        start_time = time.perf_counter()

        # SQL Capture
        with connections["default"].execute_wrapper(wrapper):
            response = self.get_response(request)

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        total_response_time = round(time.perf_counter() - start_time, 4)
        queries = wrapper.queries

        analysis = analyze_queries(queries, total_response_time)
        score_data = calculate_score(analysis)

        slow_queries = sorted(queries, key=lambda q: q["time"], reverse=True)[:5]

        memory_data = {
            "current_memory_bytes": current,
            "peak_memory_bytes": peak
        }
        

        REQUEST_HISTORY.append({
            "path": request.path,
            "method": request.method,
            "response_time": total_response_time,
            "query_count": analysis["query_count"],
        })
        history = list(REQUEST_HISTORY)

        # Build agent payload
        agent_payload = {
            "summary": {
                "query_count": analysis["query_count"],
                "db_time": analysis["total_db_time"],
                "response_time": total_response_time,
                "score": score_data["score"],
                "grade": score_data["grade"],
            },
            "sql_queries": queries,
            "top_slow_queries": slow_queries,
            "sql_analysis": {
                "duplicate_queries": analysis["duplicate_details"],
                "n_plus_one_queries": analysis["n_plus_one_details"],
                "slow_query_count": analysis["slow_query_count"],
                "is_slow_endpoint": analysis["is_slow_endpoint"],
            },
            "memory_usage": memory_data,
            "request_history": history,
            
        }

        # Encrypt agent payload
        key = generate_key()
        encrypted_payload = encrypt_data(agent_payload, key)
        response["agent_encrypted"] = encrypted_payload
        response["X-Encryption-Key"] = base64.b64encode(key).decode("utf-8")
        response["X-Debug-Mode"] = str(settings.DEBUG)
        response["X-Profiler-Enabled"] = "True"

        return response