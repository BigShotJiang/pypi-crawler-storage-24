"""Core environment engine components."""
