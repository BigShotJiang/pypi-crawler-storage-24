"""Overcooked cooperative cooking environment."""

# isort: skip_file
from cogrid.envs.overcooked import (
    overcooked_grid_objects,  # noqa: F401 -- triggers @register_object_type (must load before features)
    features,  # noqa: F401 -- triggers @register_feature_type
)
