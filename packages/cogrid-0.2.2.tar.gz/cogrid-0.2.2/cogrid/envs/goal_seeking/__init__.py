"""Goal-seeking environment."""
