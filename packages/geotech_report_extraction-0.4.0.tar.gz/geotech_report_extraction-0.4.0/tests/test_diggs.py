"""Tests for DIGGS XML serialization."""

from datetime import date

from lxml import etree

from geotech_report_extraction.diggs.serializer import (
    DIGGS_GEO_NS,
    to_diggs_xml,
    to_diggs_etree,
)
from geotech_report_extraction.lab_tests import (
    AtterbergResult,
    ConsolidationResult,
    GrainSizeResult,
    LabTestResult,
    LabTestType,
    MoistureDensityResult,
    StrengthTestResult,
    XYDataPoint,
    XYSeries,
)
from geotech_report_extraction.models import (
    Borehole,
    BoreholeLog,
    Consistency,
    DrillingDetails,
    MoistureCondition,
    Project,
    RelativeDensity,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)

DIGGS_NS = "http://diggsml.org/schemas/2.6"
GML_NS = "http://www.opengis.net/gml/3.2"
GEO_NS = DIGGS_GEO_NS


def _make_sample_log() -> BoreholeLog:
    """Create a sample BoreholeLog for testing."""
    return BoreholeLog(
        project=Project(
            name="Test Bridge Foundation",
            number="P-2024-001",
            client="State DOT",
            location="Springfield, IL",
            report_date=date(2024, 3, 15),
            firm="Langan Engineering",
        ),
        boreholes=[
            Borehole(
                boring_id="B-1",
                depth_ft=50.0,
                elevation_ft=125.5,
                latitude=40.7128,
                longitude=-74.0060,
                date_started=date(2024, 1, 15),
                date_completed=date(2024, 1, 16),
                drilling=DrillingDetails(
                    method="Hollow Stem Auger",
                    hammer_type="Automatic",
                    hammer_weight_lb=140.0,
                    hammer_drop_in=30.0,
                    borehole_diameter_in=4.25,
                    rig_type="CME-75",
                    driller="Smith",
                    logged_by="Jones",
                ),
                samples=[
                    Sample(
                        sample_number="S-1",
                        sample_type=SampleType.SPLIT_SPOON,
                        depth_top_ft=5.0,
                        depth_bottom_ft=6.5,
                        recovery_in=12.0,
                        recovery_pct=80.0,
                        spt=SPTBlowCounts(
                            first_6in=3,
                            second_6in=5,
                            third_6in=7,
                            n_value=12,
                        ),
                        water_content_pct=22.5,
                        liquid_limit=35,
                        plastic_limit=18,
                        plasticity_index=17,
                        fines_pct=62.0,
                    ),
                    Sample(
                        sample_number="S-2",
                        sample_type=SampleType.SHELBY_TUBE,
                        depth_top_ft=15.0,
                        depth_bottom_ft=17.0,
                        recovery_in=22.0,
                        dry_unit_weight_pcf=105.3,
                        qu_psf=2400.0,
                    ),
                ],
                soil_layers=[
                    SoilLayer(
                        depth_top_ft=0.0,
                        depth_bottom_ft=10.0,
                        description="FILL: brown, moist, medium dense SAND with gravel",
                        uscs_classification=USCSClassification.SP,
                        color="brown",
                        moisture=MoistureCondition.MOIST,
                        relative_density=RelativeDensity.MEDIUM_DENSE,
                    ),
                    SoilLayer(
                        depth_top_ft=10.0,
                        depth_bottom_ft=30.0,
                        description="Gray, moist, stiff CLAY",
                        uscs_classification=USCSClassification.CL,
                        color="gray",
                        moisture=MoistureCondition.MOIST,
                        consistency=Consistency.STIFF,
                    ),
                ],
                water_levels=[
                    WaterLevelObservation(
                        depth_ft=12.0,
                        is_during_drilling=True,
                        notes="Encountered during drilling",
                    ),
                    WaterLevelObservation(
                        depth_ft=8.5,
                        date_observed=date(2024, 1, 16),
                        is_stabilized=True,
                    ),
                ],
            ),
        ],
        source_file="test_report.pdf",
    )


def _make_consolidation_test() -> LabTestResult:
    """Create a consolidation lab test result."""
    return LabTestResult(
        test_type=LabTestType.CONSOLIDATION,
        page_number=15,
        boring_id="B-1",
        sample_depth_ft=20.0,
        consolidation=ConsolidationResult(
            boring_id="B-1",
            sample_depth_ft=20.0,
            soil_description="Gray silty CLAY (CL)",
            initial_void_ratio=0.85,
            preconsolidation_pressure_tsf=2.5,
            compression_index_cc=0.28,
            recompression_index_cr=0.04,
            swell_index_cs=0.03,
            coefficient_of_consolidation_cv=0.005,
            e_log_p_curve=XYSeries(
                label="Loading",
                points=[
                    XYDataPoint(x=0.125, y=0.850),
                    XYDataPoint(x=0.25, y=0.848),
                    XYDataPoint(x=0.5, y=0.840),
                    XYDataPoint(x=1.0, y=0.820),
                    XYDataPoint(x=2.0, y=0.780),
                    XYDataPoint(x=4.0, y=0.700),
                    XYDataPoint(x=8.0, y=0.600),
                ],
            ),
        ),
    )


def _make_grain_size_test() -> LabTestResult:
    """Create a grain size lab test result."""
    return LabTestResult(
        test_type=LabTestType.GRAIN_SIZE,
        page_number=18,
        boring_id="B-1",
        sample_depth_ft=5.0,
        grain_size=GrainSizeResult(
            boring_id="B-1",
            sample_depth_ft=5.0,
            soil_description="Brown SAND with silt",
            d10_mm=0.08,
            d30_mm=0.25,
            d50_mm=0.50,
            d60_mm=0.80,
            cu=10.0,
            cc=0.98,
            percent_gravel=5.0,
            percent_sand=72.0,
            percent_fines=23.0,
            gradation_curve=XYSeries(
                label="B-1 @ 5ft",
                points=[
                    XYDataPoint(x=0.001, y=5.0),
                    XYDataPoint(x=0.01, y=12.0),
                    XYDataPoint(x=0.075, y=23.0),
                    XYDataPoint(x=0.425, y=45.0),
                    XYDataPoint(x=2.0, y=85.0),
                    XYDataPoint(x=4.75, y=95.0),
                    XYDataPoint(x=19.0, y=100.0),
                ],
            ),
        ),
    )


def _make_atterberg_test() -> LabTestResult:
    """Create an Atterberg limits lab test result."""
    return LabTestResult(
        test_type=LabTestType.ATTERBERG_LIMITS,
        page_number=20,
        boring_id="B-1",
        sample_depth_ft=15.0,
        atterberg=AtterbergResult(
            boring_id="B-1",
            sample_depth_ft=15.0,
            soil_description="Gray CLAY (CL)",
            liquid_limit=42,
            plastic_limit=20,
            plasticity_index=22,
            natural_moisture_pct=28.5,
            uscs_classification="CL",
            flow_curve=XYSeries(
                label="Flow curve",
                points=[
                    XYDataPoint(x=15, y=44.2),
                    XYDataPoint(x=20, y=43.0),
                    XYDataPoint(x=25, y=42.0),
                    XYDataPoint(x=30, y=41.1),
                    XYDataPoint(x=35, y=40.3),
                ],
            ),
        ),
    )


def _make_triaxial_uu_test() -> LabTestResult:
    """Create a UU triaxial lab test result."""
    return LabTestResult(
        test_type=LabTestType.TRIAXIAL_UU,
        page_number=22,
        boring_id="B-1",
        sample_depth_ft=20.0,
        strength=StrengthTestResult(
            boring_id="B-1",
            sample_depth_ft=20.0,
            soil_description="Gray silty CLAY (CL)",
            test_type="UU",
            confining_pressure_psf=2000.0,
            peak_deviator_stress_psf=3200.0,
            undrained_shear_strength_psf=1600.0,
            friction_angle_deg=0.0,
            cohesion_psf=1600.0,
            strain_at_failure_pct=5.2,
            stress_strain_curve=XYSeries(
                label="Stress-strain",
                points=[
                    XYDataPoint(x=0.0, y=0.0),
                    XYDataPoint(x=1.0, y=1200.0),
                    XYDataPoint(x=2.0, y=2400.0),
                    XYDataPoint(x=3.0, y=3000.0),
                    XYDataPoint(x=5.2, y=3200.0),
                    XYDataPoint(x=8.0, y=3100.0),
                ],
            ),
        ),
    )


def _make_triaxial_cu_test() -> LabTestResult:
    """Create a CU triaxial lab test result."""
    return LabTestResult(
        test_type=LabTestType.TRIAXIAL_CU,
        page_number=24,
        boring_id="B-2",
        sample_depth_ft=25.0,
        strength=StrengthTestResult(
            boring_id="B-2",
            sample_depth_ft=25.0,
            test_type="CU",
            confining_pressure_psf=3000.0,
            friction_angle_deg=28.0,
            cohesion_psf=200.0,
        ),
    )


def _make_uc_test() -> LabTestResult:
    """Create an unconfined compression lab test result."""
    return LabTestResult(
        test_type=LabTestType.UNCONFINED_COMPRESSION,
        page_number=26,
        boring_id="B-1",
        sample_depth_ft=15.0,
        strength=StrengthTestResult(
            boring_id="B-1",
            sample_depth_ft=15.0,
            soil_description="Gray CLAY",
            test_type="UC",
            peak_deviator_stress_psf=2400.0,
            undrained_shear_strength_psf=1200.0,
            strain_at_failure_pct=4.5,
            stress_strain_curve=XYSeries(
                label="UC",
                points=[
                    XYDataPoint(x=0.0, y=0.0),
                    XYDataPoint(x=1.0, y=800.0),
                    XYDataPoint(x=2.5, y=1800.0),
                    XYDataPoint(x=4.5, y=2400.0),
                    XYDataPoint(x=6.0, y=2200.0),
                ],
            ),
        ),
    )


def _make_direct_shear_test() -> LabTestResult:
    """Create a direct shear lab test result."""
    return LabTestResult(
        test_type=LabTestType.DIRECT_SHEAR,
        page_number=28,
        boring_id="B-1",
        sample_depth_ft=8.0,
        strength=StrengthTestResult(
            boring_id="B-1",
            sample_depth_ft=8.0,
            test_type="DS",
            confining_pressure_psf=1000.0,
            friction_angle_deg=32.0,
            cohesion_psf=50.0,
            stress_strain_curve=XYSeries(
                label="Shear",
                points=[
                    XYDataPoint(x=0.0, y=0.0),
                    XYDataPoint(x=0.01, y=200.0),
                    XYDataPoint(x=0.03, y=450.0),
                    XYDataPoint(x=0.05, y=520.0),
                ],
            ),
        ),
    )


def _make_proctor_test() -> LabTestResult:
    """Create a moisture-density (Proctor) lab test result."""
    return LabTestResult(
        test_type=LabTestType.MOISTURE_DENSITY,
        page_number=30,
        boring_id="B-1",
        sample_depth_ft=5.0,
        moisture_density=MoistureDensityResult(
            boring_id="B-1",
            sample_depth_ft=5.0,
            soil_description="Brown clayey SAND (SC)",
            test_method="Standard Proctor",
            optimum_moisture_pct=14.2,
            max_dry_density_pcf=118.5,
            compaction_curve=XYSeries(
                label="Compaction",
                points=[
                    XYDataPoint(x=8.0, y=108.0),
                    XYDataPoint(x=10.0, y=113.0),
                    XYDataPoint(x=12.0, y=116.5),
                    XYDataPoint(x=14.2, y=118.5),
                    XYDataPoint(x=16.0, y=117.0),
                    XYDataPoint(x=18.0, y=114.0),
                ],
            ),
        ),
    )


def _make_full_log() -> BoreholeLog:
    """Create a complete BoreholeLog with lab tests."""
    log = _make_sample_log()
    log.lab_tests = [
        _make_consolidation_test(),
        _make_grain_size_test(),
        _make_atterberg_test(),
        _make_triaxial_uu_test(),
        _make_uc_test(),
        _make_direct_shear_test(),
        _make_proctor_test(),
    ]
    return log


# =========================================================================
# Helper for XPath queries with namespaces
# =========================================================================

def _find(root, xpath):
    """Find elements using namespace-aware xpath."""
    return root.findall(xpath)


def _find_text(root, xpath):
    """Find element text."""
    el = root.find(xpath)
    return el.text if el is not None else None


# =========================================================================
# Original tests (preserved)
# =========================================================================


class TestDiggsXmlSerialization:
    def test_to_diggs_xml_returns_string(self):
        log = _make_sample_log()
        xml_str = to_diggs_xml(log)
        assert isinstance(xml_str, str)
        assert xml_str.startswith("<?xml")

    def test_xml_is_valid(self):
        log = _make_sample_log()
        xml_str = to_diggs_xml(log)
        root = etree.fromstring(xml_str.encode("utf-8"))
        assert root.tag == f"{{{DIGGS_NS}}}Diggs"

    def test_project_info(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        projects = root.findall(f".//{{{DIGGS_NS}}}Project")
        assert len(projects) == 1
        name = projects[0].find(f"{{{GML_NS}}}name")
        assert name is not None
        assert name.text == "Test Bridge Foundation"

    def test_borehole_present(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        boreholes = root.findall(f".//{{{DIGGS_NS}}}Borehole")
        assert len(boreholes) == 1
        name = boreholes[0].find(f"{{{GML_NS}}}name")
        assert name.text == "B-1"

    def test_borehole_depth(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        depth = root.find(f".//{{{DIGGS_NS}}}loggedLength")
        assert depth is not None
        assert depth.text == "50.0"
        assert depth.get("uom") == "ft"

    def test_sample_present(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        activities = root.findall(f".//{{{DIGGS_NS}}}SamplingActivity")
        assert len(activities) == 2  # Two samples now

    def test_spt_result(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        spt_results = root.findall(f".//{{{DIGGS_NS}}}SPTResult")
        assert len(spt_results) == 1
        n_val = spt_results[0].find(f"{{{DIGGS_NS}}}nValue")
        assert n_val is not None
        assert n_val.text == "12"

    def test_lithology_interval(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        intervals = root.findall(f".//{{{DIGGS_NS}}}LithologyInterval")
        assert len(intervals) == 2  # Two layers now
        desc = intervals[0].find(f"{{{DIGGS_NS}}}description")
        assert "FILL" in desc.text

    def test_water_level(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        wl = root.findall(f".//{{{DIGGS_NS}}}WaterLevelObservation")
        assert len(wl) == 2  # Two water levels now
        depth = wl[1].find(f"{{{DIGGS_NS}}}waterDepth")
        assert depth.text == "8.5"

    def test_location_coordinates(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        pos = root.find(f".//{{{GML_NS}}}pos")
        assert pos is not None
        assert "40.7128" in pos.text
        assert "-74.006" in pos.text

    def test_empty_log(self):
        log = BoreholeLog()
        xml_str = to_diggs_xml(log)
        root = etree.fromstring(xml_str.encode("utf-8"))
        assert root.tag == f"{{{DIGGS_NS}}}Diggs"

    def test_multiple_boreholes(self):
        log = BoreholeLog(
            boreholes=[
                Borehole(boring_id="B-1", depth_ft=30.0),
                Borehole(boring_id="B-2", depth_ft=45.0),
                Borehole(boring_id="B-3", depth_ft=60.0),
            ],
        )
        root = to_diggs_etree(log)
        boreholes = root.findall(f".//{{{DIGGS_NS}}}Borehole")
        assert len(boreholes) == 3


# =========================================================================
# Extended borehole data tests
# =========================================================================


class TestDiggsExtendedBoreholeData:
    """Tests for extended borehole data serialization."""

    def test_project_location_and_date(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        project = root.find(f".//{{{DIGGS_NS}}}Project")
        loc = project.find(f"{{{DIGGS_NS}}}projectLocation")
        assert loc is not None
        assert loc.text == "Springfield, IL"
        report_date = project.find(f"{{{DIGGS_NS}}}reportDate")
        assert report_date is not None
        assert report_date.text == "2024-03-15"

    def test_drilling_details_extended(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        da = root.find(f".//{{{DIGGS_NS}}}DrillingActivity")
        assert da is not None
        hw = da.find(f"{{{DIGGS_NS}}}hammerWeight")
        assert hw is not None
        assert hw.text == "140.0"
        assert hw.get("uom") == "lb"
        hd = da.find(f"{{{DIGGS_NS}}}hammerDrop")
        assert hd.text == "30.0"
        assert hd.get("uom") == "in"
        bd = da.find(f"{{{DIGGS_NS}}}boreholeDiameter")
        assert bd.text == "4.25"

    def test_soil_layer_consistency(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        intervals = root.findall(f".//{{{DIGGS_NS}}}LithologyInterval")
        # Second layer has consistency
        consist = intervals[1].find(f"{{{DIGGS_NS}}}consistency")
        assert consist is not None
        assert consist.text == "stiff"

    def test_soil_layer_relative_density(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        intervals = root.findall(f".//{{{DIGGS_NS}}}LithologyInterval")
        # First layer has relative density
        rd = intervals[0].find(f"{{{DIGGS_NS}}}relativeDensity")
        assert rd is not None
        assert rd.text == "medium dense"

    def test_water_level_observation_type(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        wls = root.findall(f".//{{{DIGGS_NS}}}WaterLevelObservation")
        # First is during drilling
        ot1 = wls[0].find(f"{{{DIGGS_NS}}}observationType")
        assert ot1 is not None
        assert ot1.text == "during_drilling"
        # Second is stabilized
        ot2 = wls[1].find(f"{{{DIGGS_NS}}}observationType")
        assert ot2 is not None
        assert ot2.text == "stabilized"

    def test_sample_recovery_percent(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        acts = root.findall(f".//{{{DIGGS_NS}}}SamplingActivity")
        rec = acts[0].find(f"{{{DIGGS_NS}}}recoveryPercent")
        assert rec is not None
        assert rec.text == "80.0"

    def test_document_info(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        di = root.find(f".//{{{DIGGS_NS}}}DocumentInformation")
        assert di is not None
        sf = di.find(f"{{{DIGGS_NS}}}sourceFile")
        assert sf is not None
        assert sf.text == "test_report.pdf"

    def test_borehole_project_ref(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        bh = root.find(f".//{{{DIGGS_NS}}}Borehole")
        pref = bh.find(f"{{{DIGGS_NS}}}projectRef")
        assert pref is not None
        assert "#P-2024-001" in pref.get(f"{{{XLINK_NS}}}href")


# =========================================================================
# Sample-level lab properties tests
# =========================================================================

XLINK_NS = "http://www.w3.org/1999/xlink"


class TestDiggsSampleLabProperties:
    """Tests for sample-level lab data (water content, Atterberg, etc.)."""

    def test_sample_water_content(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        # Find the lab properties test for S-1
        lab_props = [t for t in tests if "labprops" in t.get(f"{{{GML_NS}}}id", "")]
        assert len(lab_props) >= 1
        # Check result has water content
        dv = lab_props[0].find(f".//{{{DIGGS_NS}}}dataValues")
        assert dv is not None
        assert "22.5" in dv.text

    def test_sample_atterberg_limits(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        lab_props = [t for t in tests if "labprops" in t.get(f"{{{GML_NS}}}id", "")]
        assert len(lab_props) >= 1
        # S-1 has LL, PL, PI
        props = lab_props[0].findall(f".//{{{DIGGS_NS}}}Property")
        prop_names = [p.find(f"{{{DIGGS_NS}}}propertyName").text for p in props]
        assert "LL" in prop_names
        assert "PL" in prop_names
        assert "PI" in prop_names

    def test_sample_qu(self):
        log = _make_sample_log()
        root = to_diggs_etree(log)
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        lab_props = [t for t in tests if "labprops" in t.get(f"{{{GML_NS}}}id", "")]
        # S-2 has qu and dry unit weight
        s2_props = lab_props[1]
        dv = s2_props.find(f".//{{{DIGGS_NS}}}dataValues")
        assert "2400.0" in dv.text
        assert "105.3" in dv.text

    def test_sample_no_lab_data(self):
        """Sample with no lab properties should not generate a Test element."""
        log = BoreholeLog(
            boreholes=[
                Borehole(
                    boring_id="B-1",
                    depth_ft=20.0,
                    samples=[
                        Sample(
                            depth_top_ft=5.0,
                            depth_bottom_ft=6.5,
                        ),
                    ],
                ),
            ],
        )
        root = to_diggs_etree(log)
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        lab_props = [t for t in tests if "labprops" in t.get(f"{{{GML_NS}}}id", "")]
        assert len(lab_props) == 0


# =========================================================================
# Consolidation test serialization
# =========================================================================


class TestDiggsConsolidation:
    """Tests for consolidation test DIGGS serialization."""

    def test_consolidation_test_present(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        non_lab = [t for t in tests if "labprops" not in t.get(f"{{{GML_NS}}}id", "")]
        assert len(non_lab) == 1
        name = non_lab[0].find(f"{{{GML_NS}}}name")
        assert "Consolidation" in name.text

    def test_consolidation_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}ConsolidationTest")
        assert len(procs) == 1

    def test_consolidation_astm_method(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D2435" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)

    def test_consolidation_trial_data(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        trials = root.findall(f".//{{{GEO_NS}}}ConsolidationTrial")
        assert len(trials) == 7  # 7 data points
        # First trial
        stress = trials[0].find(f"{{{GEO_NS}}}loadingStress")
        assert stress.text == "0.125"
        assert stress.get("uom") == "tsf"
        vr = trials[0].find(f"{{{GEO_NS}}}voidRatio")
        assert vr.text == "0.85"

    def test_consolidation_derived_params(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        dv = root.find(f".//{{{DIGGS_NS}}}dataValues")
        assert dv is not None
        values = dv.text.split(",")
        # Should have: e0, Pc, Cc, Cr, Cs, cv
        assert len(values) == 6
        assert "0.85" in values   # initial void ratio
        assert "2.5" in values    # Pc
        assert "0.28" in values   # Cc
        assert "0.04" in values   # Cr

    def test_consolidation_specimen(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        specimen = root.find(f".//{{{DIGGS_NS}}}SoilSpecimen")
        assert specimen is not None
        desc = specimen.find(f"{{{DIGGS_NS}}}soilDescription")
        assert desc is not None
        assert "Gray silty CLAY" in desc.text

    def test_consolidation_borehole_ref(self):
        log = BoreholeLog(lab_tests=[_make_consolidation_test()])
        root = to_diggs_etree(log)
        test = root.find(f".//{{{DIGGS_NS}}}Test")
        sf_ref = test.find(f"{{{DIGGS_NS}}}samplingFeatureRef")
        assert sf_ref is not None
        assert "#B-1" in sf_ref.get(f"{{{XLINK_NS}}}href")


# =========================================================================
# Grain size test serialization
# =========================================================================


class TestDiggsGrainSize:
    """Tests for grain size test DIGGS serialization."""

    def test_grain_size_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_grain_size_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}ParticleSizeTest")
        assert len(procs) == 1

    def test_grain_size_sieve_data(self):
        log = BoreholeLog(lab_tests=[_make_grain_size_test()])
        root = to_diggs_etree(log)
        gradings = root.findall(f".//{{{GEO_NS}}}Grading")
        assert len(gradings) == 7
        # Check first grading point
        size = gradings[0].find(f"{{{GEO_NS}}}particleSize")
        assert size.text == "0.001"
        assert size.get("uom") == "mm"
        pct = gradings[0].find(f"{{{GEO_NS}}}percentPassing")
        assert pct.text == "5.0"
        assert pct.get("uom") == "%"

    def test_grain_size_derived_params(self):
        log = BoreholeLog(lab_tests=[_make_grain_size_test()])
        root = to_diggs_etree(log)
        props = root.findall(f".//{{{DIGGS_NS}}}Property")
        prop_names = [p.find(f"{{{DIGGS_NS}}}propertyName").text for p in props]
        assert "D10" in prop_names
        assert "D60" in prop_names
        assert "Percent Fines" in prop_names

    def test_grain_size_astm_method(self):
        log = BoreholeLog(lab_tests=[_make_grain_size_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D6913" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Atterberg limits test serialization
# =========================================================================


class TestDiggsAtterberg:
    """Tests for Atterberg limits test DIGGS serialization."""

    def test_atterberg_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_atterberg_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}AtterbergLimitsTest")
        assert len(procs) == 1

    def test_atterberg_casagrande_trials(self):
        log = BoreholeLog(lab_tests=[_make_atterberg_test()])
        root = to_diggs_etree(log)
        trials = root.findall(f".//{{{GEO_NS}}}CasagrandeTrial")
        assert len(trials) == 5
        bc = trials[0].find(f"{{{GEO_NS}}}blowCount")
        assert bc.text == "15"
        wc = trials[0].find(f"{{{GEO_NS}}}waterContent")
        assert wc.text == "44.2"
        assert wc.get("uom") == "%"

    def test_atterberg_derived_params(self):
        log = BoreholeLog(lab_tests=[_make_atterberg_test()])
        root = to_diggs_etree(log)
        dv = root.find(f".//{{{DIGGS_NS}}}dataValues")
        assert dv is not None
        # Should contain LL=42, PL=20, PI=22, wn=28.5, USCS=CL
        assert "42" in dv.text
        assert "20" in dv.text
        assert "22" in dv.text

    def test_atterberg_astm_d4318(self):
        log = BoreholeLog(lab_tests=[_make_atterberg_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D4318" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Triaxial test serialization
# =========================================================================


class TestDiggsTriaxial:
    """Tests for triaxial test DIGGS serialization."""

    def test_triaxial_uu_procedure(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}TriaxialTest")
        assert len(procs) == 1

    def test_triaxial_uu_type(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        tt = root.find(f".//{{{GEO_NS}}}triaxialTestType")
        assert tt is not None
        assert tt.text == "UU"

    def test_triaxial_cu_type(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_cu_test()])
        root = to_diggs_etree(log)
        tt = root.find(f".//{{{GEO_NS}}}triaxialTestType")
        assert tt.text == "CU"

    def test_triaxial_cell_pressure(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        cp = root.find(f".//{{{GEO_NS}}}cellPressure")
        assert cp is not None
        assert cp.text == "2000.0"
        assert cp.get("uom") == "psf"

    def test_triaxial_shearing_increments(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        incs = root.findall(f".//{{{GEO_NS}}}TriaxialShearingIncrement")
        assert len(incs) == 6
        strain = incs[0].find(f"{{{GEO_NS}}}axialStrain")
        assert strain.text == "0.0"
        assert strain.get("uom") == "%"
        dev = incs[0].find(f"{{{GEO_NS}}}deviatorStress")
        assert dev.text == "0.0"

    def test_triaxial_derived_params(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        props = root.findall(f".//{{{DIGGS_NS}}}Property")
        prop_names = [p.find(f"{{{DIGGS_NS}}}propertyName").text for p in props]
        assert "Undrained Shear Strength" in prop_names
        assert "Friction Angle" in prop_names
        assert "Cohesion" in prop_names

    def test_triaxial_uu_astm_d2850(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D2850" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)

    def test_triaxial_cu_astm_d4767(self):
        log = BoreholeLog(lab_tests=[_make_triaxial_cu_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D4767" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Unconfined compression test serialization
# =========================================================================


class TestDiggsUnconfinedCompression:
    """Tests for UC test DIGGS serialization."""

    def test_uc_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_uc_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}UnconfinedCompressiveStrengthTest")
        assert len(procs) == 1

    def test_uc_compression_increments(self):
        log = BoreholeLog(lab_tests=[_make_uc_test()])
        root = to_diggs_etree(log)
        incs = root.findall(f".//{{{GEO_NS}}}CompressionIncrement")
        assert len(incs) == 5
        strain = incs[2].find(f"{{{GEO_NS}}}totalStrain")
        assert strain.text == "2.5"
        stress = incs[2].find(f"{{{GEO_NS}}}stress")
        assert stress.text == "1800.0"

    def test_uc_strain_at_failure(self):
        log = BoreholeLog(lab_tests=[_make_uc_test()])
        root = to_diggs_etree(log)
        saf = root.find(f".//{{{GEO_NS}}}axialStrainAtFailure")
        assert saf is not None
        assert saf.text == "4.5"
        assert saf.get("uom") == "%"

    def test_uc_astm_d2166(self):
        log = BoreholeLog(lab_tests=[_make_uc_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D2166" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Direct shear test serialization
# =========================================================================


class TestDiggsDirectShear:
    """Tests for direct shear test DIGGS serialization."""

    def test_direct_shear_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_direct_shear_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}DirectShearTest")
        assert len(procs) == 1

    def test_direct_shear_normal_stress(self):
        log = BoreholeLog(lab_tests=[_make_direct_shear_test()])
        root = to_diggs_etree(log)
        ns = root.find(f".//{{{GEO_NS}}}normalStressApplied")
        assert ns is not None
        assert ns.text == "1000.0"
        assert ns.get("uom") == "psf"

    def test_direct_shear_increments(self):
        log = BoreholeLog(lab_tests=[_make_direct_shear_test()])
        root = to_diggs_etree(log)
        incs = root.findall(f".//{{{GEO_NS}}}DirectShearTestIncrement")
        assert len(incs) == 4
        disp = incs[1].find(f"{{{GEO_NS}}}horizontalDisplacement")
        assert disp.text == "0.01"
        shear = incs[1].find(f"{{{GEO_NS}}}shearStress")
        assert shear.text == "200.0"

    def test_direct_shear_astm_d3080(self):
        log = BoreholeLog(lab_tests=[_make_direct_shear_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D3080" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Moisture-density (Proctor) test serialization
# =========================================================================


class TestDiggsProctor:
    """Tests for moisture-density / Proctor test DIGGS serialization."""

    def test_compaction_procedure_element(self):
        log = BoreholeLog(lab_tests=[_make_proctor_test()])
        root = to_diggs_etree(log)
        procs = root.findall(f".//{{{GEO_NS}}}LabCompactionTest")
        assert len(procs) == 1

    def test_compaction_trial_data(self):
        log = BoreholeLog(lab_tests=[_make_proctor_test()])
        root = to_diggs_etree(log)
        trials = root.findall(f".//{{{GEO_NS}}}LabCompactionTestTrial")
        assert len(trials) == 6
        mc = trials[3].find(f"{{{GEO_NS}}}moistureContent")
        assert mc.text == "14.2"
        assert mc.get("uom") == "%"
        dd = trials[3].find(f"{{{GEO_NS}}}dryDensity")
        assert dd.text == "118.5"
        assert dd.get("uom") == "pcf"

    def test_compaction_derived_params(self):
        log = BoreholeLog(lab_tests=[_make_proctor_test()])
        root = to_diggs_etree(log)
        dv = root.find(f".//{{{DIGGS_NS}}}dataValues")
        assert dv is not None
        assert "14.2" in dv.text  # OMC
        assert "118.5" in dv.text  # MDD

    def test_compaction_astm_method(self):
        log = BoreholeLog(lab_tests=[_make_proctor_test()])
        root = to_diggs_etree(log)
        specs = root.findall(f".//{{{DIGGS_NS}}}Specification")
        assert any("D698" in (s.find(f"{{{GML_NS}}}name").text or "")
                    for s in specs)


# =========================================================================
# Full document integration tests
# =========================================================================


class TestDiggsFullDocument:
    """Integration tests with a complete document including all data types."""

    def test_full_document_parses(self):
        log = _make_full_log()
        xml_str = to_diggs_xml(log)
        root = etree.fromstring(xml_str.encode("utf-8"))
        assert root.tag == f"{{{DIGGS_NS}}}Diggs"

    def test_full_document_measurement_count(self):
        log = _make_full_log()
        root = to_diggs_etree(log)
        measurements = root.findall(f"{{{DIGGS_NS}}}measurement")
        # 1 SPT + 2 sample lab props + 2 water levels + 7 lab tests = 12
        assert len(measurements) == 12

    def test_full_document_all_procedure_types(self):
        log = _make_full_log()
        root = to_diggs_etree(log)
        # Check each procedure type exists
        assert len(root.findall(f".//{{{GEO_NS}}}ConsolidationTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}ParticleSizeTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}AtterbergLimitsTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}TriaxialTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}UnconfinedCompressiveStrengthTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}DirectShearTest")) == 1
        assert len(root.findall(f".//{{{GEO_NS}}}LabCompactionTest")) == 1

    def test_full_document_all_gml_ids_unique(self):
        log = _make_full_log()
        root = to_diggs_etree(log)
        ids = set()
        for el in root.iter():
            gml_id = el.get(f"{{{GML_NS}}}id")
            if gml_id:
                assert gml_id not in ids, f"Duplicate gml:id: {gml_id}"
                ids.add(gml_id)

    def test_full_document_xml_round_trip(self):
        log = _make_full_log()
        xml_str = to_diggs_xml(log)
        # Parse back and re-serialize
        root = etree.fromstring(xml_str.encode("utf-8"))
        xml_str2 = etree.tostring(
            root, pretty_print=True, xml_declaration=True, encoding="UTF-8",
        ).decode("utf-8")
        # Both should parse identically
        root2 = etree.fromstring(xml_str2.encode("utf-8"))
        assert root.tag == root2.tag

    def test_no_lab_tests_still_works(self):
        log = _make_sample_log()
        assert log.lab_tests == []
        root = to_diggs_etree(log)
        # Only SPT + sample lab prop measurements
        measurements = root.findall(f"{{{DIGGS_NS}}}measurement")
        assert len(measurements) >= 1  # At least SPT

    def test_lab_test_with_no_curve_data(self):
        """Lab test with only derived params and no curve data."""
        lab = LabTestResult(
            test_type=LabTestType.ATTERBERG_LIMITS,
            boring_id="B-3",
            sample_depth_ft=10.0,
            atterberg=AtterbergResult(
                liquid_limit=30,
                plastic_limit=15,
                plasticity_index=15,
            ),
        )
        log = BoreholeLog(lab_tests=[lab])
        root = to_diggs_etree(log)
        # Should still produce procedure element
        procs = root.findall(f".//{{{GEO_NS}}}AtterbergLimitsTest")
        assert len(procs) == 1
        # But no Casagrande trials
        trials = root.findall(f".//{{{GEO_NS}}}CasagrandeTrial")
        assert len(trials) == 0

    def test_lab_test_unknown_type_fallback(self):
        """Unknown test type should use generic procedure element."""
        lab = LabTestResult(
            test_type="some_unknown_test",
            boring_id="B-1",
            sample_depth_ft=5.0,
            raw_plot_data={"foo": "bar"},
        )
        log = BoreholeLog(lab_tests=[lab])
        root = to_diggs_etree(log)
        # Should still create a measurement element
        tests = root.findall(f".//{{{DIGGS_NS}}}Test")
        non_lab = [t for t in tests if "labprops" not in t.get(f"{{{GML_NS}}}id", "")]
        assert len(non_lab) == 1
        # Uses generic procedure
        procs = root.findall(f".//{{{GEO_NS}}}LaboratoryTestProcedure")
        assert len(procs) == 1

    def test_zero_friction_angle_serialized(self):
        """Friction angle of 0 (UU test) should still be serialized."""
        log = BoreholeLog(lab_tests=[_make_triaxial_uu_test()])
        root = to_diggs_etree(log)
        dv = root.find(f".//{{{DIGGS_NS}}}dataValues")
        values = dv.text.split(",")
        # phi=0.0 should be present (not dropped as falsy)
        assert "0.0" in values
