"""Palantir Foundry transform for boring log identification and extraction.

This module provides Foundry-compatible functions that process Azure Document
Intelligence (DI) JSON exports and produce structured boring log datasets.

Designed to work with a Pipeline Builder preprocessing step that flattens
DI JSON files into a per-page tabular dataset. The transform then applies
the XGBoost classifier and boring log parsers to identify and extract data.

Architecture:
    1. Pipeline Builder: DI JSON files → flat per-page dataset
       (columns: source_file, page_number, page_text, page_width, page_height,
        word_count, has_tables)
    2. This transform: per-page dataset → boring log inventory dataset
       Uses groupBy("source_file").applyInPandas() for per-report processing.

Usage in Foundry Code Repository:
    from geotech_report_extraction.foundry import (
        identify_boring_logs,
        extract_boring_log_data,
    )
"""

from __future__ import annotations

import logging
import re
from datetime import date
from typing import Optional

import pandas as pd

from geotech_report_extraction.di_reader import _detect_firm, _extract_boring_id
from geotech_report_extraction.ml_classifier import classify_page
from geotech_report_extraction.ml_features import FEATURE_NAMES, extract_features
from geotech_report_extraction.models import Borehole
from geotech_report_extraction.parsers.registry import get_di_parser
from geotech_report_extraction.pdf_parser import (
    PageContent,
    PDFContent,
    group_boring_log_pages,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema definitions for Foundry output datasets
# ---------------------------------------------------------------------------

# Schema for the boring log inventory (Stage 1 output)
INVENTORY_COLUMNS = [
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation (e.g., B-01, LB-1)
    "firm",              # str: engineering firm (schnabel, langan)
    "start_page",        # int: first PDF page of this boring log
    "end_page",          # int: last PDF page of this boring log
    "num_pages",         # int: total pages for this boring
    "avg_confidence",    # float: mean ML confidence across pages
    "min_confidence",    # float: lowest ML confidence across pages
]

# Schema for full extraction (Stage 2 output)
EXTRACTION_COLUMNS = [
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation
    "firm",              # str: engineering firm
    "start_page",        # int: first PDF page
    "end_page",          # int: last PDF page
    "num_pages",         # int: total pages
    "avg_confidence",    # float: mean ML confidence
    "min_confidence",    # float: lowest ML confidence
    "total_depth_ft",    # float: total boring depth in feet
    "elevation_ft",      # float: ground surface elevation
    "date_started",      # str: date drilling started (ISO format or None)
    "date_completed",    # str: date drilling completed (ISO format or None)
    "num_samples",       # int: number of samples extracted
    "num_soil_layers",   # int: number of soil layers identified
    "num_water_levels",  # int: number of water level observations
    "project_name",      # str: project name from report header
    "project_number",    # str: project number
    "project_location",  # str: project location
    "extraction_warnings",  # str: semicolon-separated warnings
]


# ---------------------------------------------------------------------------
# Page reconstruction from flattened Pipeline Builder data
# ---------------------------------------------------------------------------

def _reconstruct_page(row: pd.Series) -> PageContent:
    """Reconstruct a PageContent object from a flattened Pipeline Builder row.

    Expected columns: page_number, page_text, page_width, page_height,
                      word_count, has_tables
    """
    page_text = row.get("page_text") or ""

    pc = PageContent(
        page_number=int(row["page_number"]),
        text=page_text,
        words=[{"text": "w"}] * int(row.get("word_count", 0)),
        lines=[],
        width=float(row.get("page_width", 612.0)) * 72.0,  # inches to points
        height=float(row.get("page_height", 792.0)) * 72.0,
    )

    # Tag DI table detection
    pc._di_has_tables = bool(row.get("has_tables", False))

    return pc


def _classify_and_tag_pages(
    pages: list[PageContent],
) -> list[PageContent]:
    """Run the ML classifier on each page and set boring IDs."""
    for pc in pages:
        pc.is_boring_log, pc.classification_score = classify_page(pc)
        if pc.is_boring_log:
            pc.boring_id = _extract_boring_id(pc.text)
    return pages


def _is_test_pit_group(boring_id: str, group_pages: list[PageContent]) -> bool:
    """Check if a boring log group is actually a test pit.

    Matches by boring ID pattern (TP-X, LTP-X) or by page title
    (LOG OF TEST PIT, TEST PIT LOG).
    """
    if re.match(r"(?i)^L?TP-?\d", boring_id):
        return True
    header = (group_pages[0].text or "")[:300]
    return bool(re.search(
        r"(?i)\bLOG\s+OF\s+TEST\s+PIT\b|\bTEST\s+PIT\s+LOG\b", header
    ))


# ---------------------------------------------------------------------------
# Core processing functions (used by both Foundry transforms and standalone)
# ---------------------------------------------------------------------------

def process_report_inventory(pdf: pd.DataFrame) -> pd.DataFrame:
    """Process all pages from a single report into a boring log inventory.

    This is the applyInPandas function for the inventory transform.

    Args:
        pdf: Pandas DataFrame with all pages from one report.
             Expected columns: source_file, page_number, page_text,
             page_width, page_height, word_count, has_tables

    Returns:
        DataFrame with one row per boring log group (INVENTORY_COLUMNS).
    """
    if pdf.empty:
        return pd.DataFrame(columns=INVENTORY_COLUMNS)

    source_file = pdf["source_file"].iloc[0]

    # Reconstruct PageContent objects
    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    # Classify pages
    _classify_and_tag_pages(pages)

    # Build PDFContent and detect firm
    pdf_content = PDFContent(file_path=source_file)
    pdf_content.pages = pages
    pdf_content.total_pages = len(pages)

    for p in pages[:5]:
        firm = _detect_firm(p.text)
        if firm:
            pdf_content.detected_firm = firm
            break
    if pdf_content.detected_firm is None:
        for p in pdf_content.boring_log_pages[:3]:
            firm = _detect_firm(p.text)
            if firm:
                pdf_content.detected_firm = firm
                break

    # Group boring log pages
    groups = group_boring_log_pages(pdf_content)

    # Build output rows
    results = []
    for boring_id, group_pages in groups.items():
        if _is_test_pit_group(boring_id, group_pages):
            continue
        results.append({
            "source_file": source_file,
            "boring_id": boring_id,
            "firm": pdf_content.detected_firm or "unknown",
            "start_page": group_pages[0].page_number,
            "end_page": group_pages[-1].page_number,
            "num_pages": len(group_pages),
            "avg_confidence": (
                sum(p.classification_score for p in group_pages)
                / len(group_pages)
            ),
            "min_confidence": min(
                p.classification_score for p in group_pages
            ),
        })

    if not results:
        return pd.DataFrame(columns=INVENTORY_COLUMNS)

    return pd.DataFrame(results, columns=INVENTORY_COLUMNS)


def process_report_extraction(pdf: pd.DataFrame) -> pd.DataFrame:
    """Process all pages from a single report with full data extraction.

    This is the applyInPandas function for the extraction transform.
    Runs the firm-specific parser on each boring group to extract
    samples, soil layers, water levels, etc.

    Args:
        pdf: Pandas DataFrame with all pages from one report.

    Returns:
        DataFrame with one row per boring (EXTRACTION_COLUMNS).
    """
    if pdf.empty:
        return pd.DataFrame(columns=EXTRACTION_COLUMNS)

    source_file = pdf["source_file"].iloc[0]

    # Reconstruct and classify pages
    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    _classify_and_tag_pages(pages)

    # Build PDFContent
    pdf_content = PDFContent(file_path=source_file)
    pdf_content.pages = pages
    pdf_content.total_pages = len(pages)

    for p in pages[:5]:
        firm = _detect_firm(p.text)
        if firm:
            pdf_content.detected_firm = firm
            break
    if pdf_content.detected_firm is None:
        for p in pdf_content.boring_log_pages[:3]:
            firm = _detect_firm(p.text)
            if firm:
                pdf_content.detected_firm = firm
                break

    # Get firm-specific parser
    parser = get_di_parser(pdf_content.detected_firm)
    project = parser.parse_project_info(pdf_content)

    # Group and extract
    groups = group_boring_log_pages(pdf_content)
    all_warnings: list[str] = []
    results = []

    for boring_id, group_pages in groups.items():
        # Skip test pits
        if _is_test_pit_group(boring_id, group_pages):
            all_warnings.append(f"Skipped test pit {boring_id}")
            continue

        avg_conf = sum(p.classification_score for p in group_pages) / len(group_pages)
        min_conf = min(p.classification_score for p in group_pages)

        row_data = {
            "source_file": source_file,
            "boring_id": boring_id,
            "firm": pdf_content.detected_firm or "unknown",
            "start_page": group_pages[0].page_number,
            "end_page": group_pages[-1].page_number,
            "num_pages": len(group_pages),
            "avg_confidence": avg_conf,
            "min_confidence": min_conf,
            "total_depth_ft": None,
            "elevation_ft": None,
            "date_started": None,
            "date_completed": None,
            "num_samples": 0,
            "num_soil_layers": 0,
            "num_water_levels": 0,
            "project_name": project.name,
            "project_number": project.number,
            "project_location": project.location,
            "extraction_warnings": "",
        }

        try:
            borehole: Borehole = parser.parse_boring_log(group_pages)

            row_data["total_depth_ft"] = borehole.depth_ft
            row_data["elevation_ft"] = borehole.elevation_ft
            row_data["date_started"] = (
                borehole.date_started.isoformat()
                if borehole.date_started else None
            )
            row_data["date_completed"] = (
                borehole.date_completed.isoformat()
                if borehole.date_completed else None
            )
            row_data["num_samples"] = len(borehole.samples)
            row_data["num_soil_layers"] = len(borehole.soil_layers)
            row_data["num_water_levels"] = len(borehole.water_levels)

            if not borehole.samples:
                all_warnings.append(
                    f"{boring_id}: 0 samples extracted"
                )

        except Exception as e:
            all_warnings.append(f"{boring_id}: parse error: {e}")

        row_data["extraction_warnings"] = "; ".join(all_warnings)
        results.append(row_data)

    if not results:
        return pd.DataFrame(columns=EXTRACTION_COLUMNS)

    return pd.DataFrame(results, columns=EXTRACTION_COLUMNS)


# ---------------------------------------------------------------------------
# Standalone entry point (for testing outside Foundry)
# ---------------------------------------------------------------------------

def process_di_json_to_inventory(
    di_json_path: str,
    file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a single DI JSON file and return a boring log inventory DataFrame.

    This is a convenience function for local testing. In Foundry, the
    Pipeline Builder flattening step replaces this — the transform
    receives pre-flattened page data.

    Args:
        di_json_path: Path to the Azure DI JSON file.
        file_label: Optional label for the source file.

    Returns:
        Pandas DataFrame with INVENTORY_COLUMNS.
    """
    from geotech_report_extraction.di_reader import read_di_json

    pdf_content = read_di_json(di_json_path, file_label=file_label)
    label = file_label or di_json_path

    # Build a flat DataFrame matching Pipeline Builder output
    rows = []
    for page in pdf_content.pages:
        rows.append({
            "source_file": label,
            "page_number": page.page_number,
            "page_text": page.text,
            "page_width": page.width / 72.0,  # points back to inches
            "page_height": page.height / 72.0,
            "word_count": len(page.words),
            "has_tables": getattr(page, '_di_has_tables', False),
        })

    pages_df = pd.DataFrame(rows)
    return process_report_inventory(pages_df)


def process_di_json_to_extraction(
    di_json_path: str,
    file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a single DI JSON file and return full extraction DataFrame.

    Convenience function for local testing.
    """
    from geotech_report_extraction.di_reader import read_di_json

    pdf_content = read_di_json(di_json_path, file_label=file_label)
    label = file_label or di_json_path

    rows = []
    for page in pdf_content.pages:
        rows.append({
            "source_file": label,
            "page_number": page.page_number,
            "page_text": page.text,
            "page_width": page.width / 72.0,
            "page_height": page.height / 72.0,
            "word_count": len(page.words),
            "has_tables": getattr(page, '_di_has_tables', False),
        })

    pages_df = pd.DataFrame(rows)
    return process_report_extraction(pages_df)
