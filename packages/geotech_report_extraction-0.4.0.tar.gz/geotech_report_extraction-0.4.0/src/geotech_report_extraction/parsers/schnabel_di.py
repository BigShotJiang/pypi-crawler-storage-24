"""Schnabel Engineering boring log parser for DI JSON data.

Purpose-built for the Schnabel OBO/DOS embassy geotech report format,
which uses a consistent gINT template across all their reports. This
parser works directly with Azure Document Intelligence word positions
rather than relying on the generic column detection.

The Schnabel OBO boring log layout (measured from actual DI data):
  DEPTH (m/ft)      | x: 0.03 - 0.10   (left margin)
  DESCRIPTION       | x: 0.10 - 0.37   (soil descriptions)
  USCS SYMBOL       | x: 0.37 - 0.43   (CH, ML, CL, SM, etc.)
  ELEVATION         | x: 0.43 - 0.52   (ground elevation)
  STRATUM ID        | x: 0.52 - 0.57   (A, B, C, etc.)
  WL / SAMPLE NO    | x: 0.57 - 0.63   (sample numbers 1, 2, 3...)
  BLOW COUNTS       | x: 0.63 - 0.72   (e.g., 2+4+6, 11+10+11)
  N VALUE / ATTERBERG| x: 0.72 - 1.0   (graph area)

Notes:
- These reports use METERS for depth (not feet)
- Blow counts use "+" separator (not "-")
- gINT watermark text appears rotated along the left edge
- Multi-page borings have "continued on next page" / "(continued)"
"""

from __future__ import annotations

import re
from typing import Optional

from geotech_report_extraction.models import (
    Borehole,
    DrillingDetails,
    MoistureCondition,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)
from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.pdf_parser import PageContent, PDFContent
from geotech_report_extraction.models import Project


# Default column boundaries as fractions of page width (Santo Domingo era).
# These are used as fallback when dynamic column detection fails.
_DEFAULT_COLUMNS = {
    "depth":        (0.03, 0.10),
    "description":  (0.10, 0.37),
    "uscs":         (0.37, 0.43),
    "elevation":    (0.43, 0.52),
    "stratum":      (0.52, 0.57),
    "sample_no":    (0.57, 0.63),
    "blow_counts":  (0.63, 0.72),
    "n_value_area": (0.72, 1.0),
}

# Footer area is bottom 10% of page
FOOTER_Y_FRAC = 0.90

# Column header keywords used to detect end of header area
_COLUMN_HEADER_KEYWORDS = {"depth", "data", "sampling", "blows/ft.", "blows/ft", "n", "value"}

# Column header label patterns for dynamic detection.
# Maps a canonical column name -> set of lowercase header label words.
# We look for these words in the header area to find column x-positions.
_COLUMN_HEADER_LABELS: dict[str, set[str]] = {
    "depth":       {"depth", "(m)", "(ft)"},
    "description": {"strata", "description"},
    "uscs":        {"symbol"},
    "elevation":   {"elev.", "elev"},
    "stratum":     {"stra-", "stratum", "tum"},
    "sample_no":   {"wl"},
    "blow_counts": {"sampling"},
    "n_value_area": {"value", "value,", "blows/ft.", "blows/ft"},
}

# gINT watermark text that appears rotated on the left edge.
# These are generic patterns that match across all Schnabel reports.
_GINT_WATERMARK_PATTERNS = [
    re.compile(r"(?i)TEST\s+BORING\s+LOG"),
    re.compile(r"(?i)SCHNABEL"),
    re.compile(r"(?i)GAITHERSBURG"),
    re.compile(r"(?i)\.GPJ\b"),
    re.compile(r"(?i)\.GDT\b"),
]

# General watermark patterns — words at far left that are clearly not depth values.
# Matches: dates (12/28/06), file extensions (SCHNABEL.GDT), and all-caps words (4+ letters)
# that are not valid depth numbers.
_GINT_WATERMARK_GENERAL = re.compile(
    r"(?i)^(?:\d{1,2}/\d{1,2}/\d{2,4}|[A-Z]{2,}\.(?:GPJ|GDT)|[A-Z]{4,})$"
)

# Blow count pattern: "2+4+6", "11+10+11", "8+9+11"
_BLOW_COUNT_RE = re.compile(r"^(\d{1,3})\s*\+\s*(\d{1,3})\s*\+\s*(\d{1,3})$")

# Meters-to-feet conversion
METERS_TO_FEET = 3.28084


class SchnabelDIParser(BaseBoringLogParser):
    """Parser for Schnabel OBO boring logs from DI JSON data."""

    firm_name = "Schnabel Engineering"

    def __init__(self, unit: str = "auto"):
        """
        Args:
            unit: Depth unit in the boring logs. "m" for meters, "ft" for feet,
                  "auto" to detect from page content.
        """
        self._unit = unit

    def parse_project_info(self, pdf_content: PDFContent) -> Project:
        """Extract project info from Schnabel report pages.

        Schnabel OBO reports have a cover letter on page 1 with a Subject line
        containing the full project name, contract number in parentheses, and
        the addressee is the client. Boring log headers also have structured
        fields (Contract Number, Project).
        """
        project = Project(firm=self.firm_name)

        # --- Strategy 1: Extract from cover letter Subject line ---
        # Formats seen across eras:
        #   "(Our 06230116)"              — Santo Domingo 2006
        #   "(Our\nReference No. 07230121)" — Antananarivo 2007
        #   "(Schnabel Reference 22230051.000)" — Banjul 2023
        #   "Schnabel Reference No. 22230051.000" — Banjul cover page
        for page in pdf_content.pages[:5]:
            if page.is_boring_log:
                continue
            text = page.text

            # Contract/project number — multiple patterns by era
            if project.number is None:
                # "(Our 06230116)" or "(Our Reference No. 07230121)"
                m = re.search(
                    r"\(Our\s+(?:Reference\s*No\.?\s*)?(\d[\w.]+)\)",
                    text, re.DOTALL,
                )
                if not m:
                    # "(Schnabel Reference 22230051.000)"
                    m = re.search(
                        r"\(Schnabel\s+Reference\s+(\d[\w.]+)\)", text
                    )
                if not m:
                    # "Schnabel Reference No. 22230051.000" (cover page)
                    m = re.search(
                        r"(?i)Schnabel\s+Reference\s+No\.?\s+(\d[\w.]+)", text
                    )
                if not m:
                    # "Contract No. 07230121"
                    m = re.search(
                        r"(?i)Contract\s*(?:No\.?|Number)\s*:?\s*(\d[\w.]+)", text
                    )
                if m:
                    num = m.group(1).strip().rstrip(".")
                    # Strip trailing ".000" from Schnabel reference numbers
                    num = re.sub(r"\.0+$", "", num)
                    project.number = num

            # Subject line: captures up to any parenthetical or max 200 chars
            if project.name is None:
                m = re.search(
                    r"(?i)Subject:\s*(.+?)(?:\(Our|\(Schnabel|\(Contract|\(Reference|OBO\s+Project|Project\s+No\.|\d{2}D\d{4})",
                    text, re.DOTALL,
                )
                if m:
                    name = re.sub(r"\s+", " ", m.group(1)).strip().rstrip(",")
                    # Cap at 200 chars to avoid runaway capture
                    if len(name) > 200:
                        name = name[:200].rsplit(",", 1)[0].strip()
                    if name and len(name) > 5:
                        project.name = name

            # Client from addressee (line after "Dear Mr./Ms." or before "Subject:")
            if project.client is None:
                m = re.search(
                    r"(?:Mr\.|Ms\.|Mrs\.)\s+.+?\n(.+?)(?:\n.*?){0,2}Subject:",
                    text, re.DOTALL,
                )
                if m:
                    client = m.group(1).strip()
                    for line in client.split("\n"):
                        line = line.strip()
                        if line and len(line) > 3 and not line[0].islower():
                            project.client = line
                            break

            # Location from Subject line (after report type, typically city/country)
            if project.location is None and project.name:
                parts = project.name.split(",")
                if len(parts) >= 3:
                    project.location = ", ".join(
                        p.strip() for p in parts[-2:]
                    ).strip()

        # --- Strategy 2: Boring log headers (Contract Number, Project) ---
        for page in pdf_content.boring_log_pages[:3]:
            text = page.text
            if project.number is None:
                m = re.search(r"(?i)contract\s*(?:no\.?|number)\s*:?\s*(\S+)", text)
                if m:
                    project.number = m.group(1).strip()
            if project.name is None:
                m = re.search(r"(?i)project\s*:\s*(.+?)(?:\n|$)", text)
                if m:
                    name = m.group(1).strip()
                    if name and len(name) > 2 and name.upper() not in {
                        "SYMBOL", "DESCRIPTION", "DATA", "BORING"
                    }:
                        project.name = name

        return project

    def parse_boring_log(self, pages: list[PageContent]) -> Borehole:
        """Parse a Schnabel OBO boring log from one or more pages."""
        if not pages:
            raise ValueError("No pages provided")

        first_page = pages[0]
        boring_id = first_page.boring_id or "UNKNOWN"

        # Detect unit from page content
        unit = self._detect_unit(first_page) if self._unit == "auto" else self._unit

        # Parse header
        header = self._parse_header(first_page)

        all_samples: list[Sample] = []
        all_layers: list[SoilLayer] = []
        all_water: list[WaterLevelObservation] = []

        next_sample_number = 1  # Tracks across pages for multi-page borings
        for page in pages:
            samples, layers = self._parse_data_area(
                page, unit, start_sample_number=next_sample_number,
            )
            all_samples.extend(samples)
            all_layers.extend(layers)
            water = self._parse_water_levels(page, unit)
            all_water.extend(water)
            # Continue numbering on the next page
            if samples:
                last_num = samples[-1].sample_number
                if last_num and last_num.isdigit():
                    next_sample_number = int(last_num) + 1

        # Convert total depth
        total_depth = header.get("depth")
        if total_depth and unit == "m":
            total_depth *= METERS_TO_FEET
        if total_depth is None:
            total_depth = self._infer_total_depth(all_samples)

        # Convert elevation
        elevation = header.get("elevation")
        if elevation and unit == "m":
            elevation *= METERS_TO_FEET

        return Borehole(
            boring_id=boring_id,
            depth_ft=total_depth or 0.0,
            elevation_ft=elevation,
            latitude=header.get("latitude"),
            longitude=header.get("longitude"),
            date_started=self.parse_date(header.get("date_started", "")),
            date_completed=self.parse_date(header.get("date_completed", "")),
            drilling=DrillingDetails(
                method=header.get("drill_method"),
                rig_type=header.get("rig_type"),
                hammer_type=header.get("hammer_type"),
                driller=header.get("driller"),
                logged_by=header.get("logged_by"),
            ),
            samples=all_samples,
            soil_layers=all_layers,
            water_levels=all_water,
        )

    def _detect_unit(self, page: PageContent) -> str:
        """Detect whether depths are in meters or feet."""
        text = page.text.lower()
        # Check for explicit unit indicators
        if re.search(r"\bdepth\s*\(m\)", text):
            return "m"
        if re.search(r"\bdepth\s*\(ft\)", text):
            return "ft"
        if "(meters)" in text or "(metres)" in text:
            return "m"
        if "(feet)" in text:
            return "ft"
        # Check elevation unit
        if re.search(r"elevation.*\(meters?\)", text, re.IGNORECASE):
            return "m"
        # Default to meters for international OBO projects
        return "m"

    def _parse_header(self, page: PageContent) -> dict:
        """Extract header fields from first page of boring log."""
        header: dict = {}
        text = page.text

        # Only look at words in the header area
        header_end = self._detect_header_end(page)
        header_words = [w for w in page.words if w["top"] < header_end]
        header_text_parts = [w["text"] for w in sorted(header_words, key=lambda w: (w["top"], w["x0"]))]

        # Total depth
        m = re.search(r"(?i)(?:total\s+)?depth\s*(?:of\s+boring)?\s*:?\s*([\d.]+)", text)
        if m:
            header["depth"] = float(m.group(1))

        # Elevation
        m = re.search(r"(?i)(?:ground\s+)?(?:surface\s+)?elev(?:ation)?\s*:?\s*([\d.]+)\+?\s*(?:\(meters?\))?", text)
        if m:
            header["elevation"] = float(m.group(1))

        # Dates
        m = re.search(r"(?i)date[s]?\s*started\s*:?\s*(\S+)", text)
        if m:
            header["date_started"] = m.group(1)
        m = re.search(r"(?i)(?:finished|completed)\s*:?\s*(\S+)", text)
        if m:
            header["date_completed"] = m.group(1)

        # Drilling method
        m = re.search(r"(?i)drilling\s+method\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["drill_method"] = m.group(1).strip()

        # Drilling equipment
        m = re.search(r"(?i)drilling\s+equipment\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["rig_type"] = m.group(1).strip()

        # Hammer type
        m = re.search(r"(?i)hammer\s*(?:type)?\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["hammer_type"] = m.group(1).strip()

        # Boring contractor/driller
        m = re.search(r"(?i)(?:boring\s+)?(?:contractor|driller)\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["driller"] = m.group(1).strip()

        # SEI Representative / Logged by
        m = re.search(r"(?i)(?:SEI\s+)?representative\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["logged_by"] = m.group(1).strip()

        return header

    @staticmethod
    def _detect_header_end(page: PageContent) -> float:
        """Detect the y-position where the header ends and data begins.

        Looks for column header keywords (DEPTH, DATA, SAMPLING, etc.) and
        returns a y-position just below the last one. This adapts to both
        first pages (large header with boring info) and continuation pages
        (small header with just column labels).
        """
        max_header_y = 0.0
        for w in page.words:
            if w["text"].strip().lower() in _COLUMN_HEADER_KEYWORDS:
                if w["top"] < page.height * 0.40:  # sanity cap at 40%
                    max_header_y = max(max_header_y, w["top"])

        if max_header_y > 0:
            return max_header_y + 8.0  # ~8pt margin below last header word

        # Fallback: 17% of page height (works for continuation pages)
        return page.height * 0.17

    @staticmethod
    def _detect_columns(page: PageContent) -> dict[str, tuple[float, float]]:
        """Dynamically detect column boundaries from header labels.

        Scans the column header row (just above the data area) for label words
        (DEPTH, STRATA, DESCRIPTION, SYMBOL, SAMPLING, etc.) and uses their
        x-positions to define column boundaries.

        Only considers words in the column header band (y between 55% and
        100% of the header end position) to avoid false matches from
        project info fields higher up in the header.

        Falls back to defaults if detection fails.
        Returns column boundaries as fractions of page width.
        """
        width = page.width

        # Find the header end first
        header_end = SchnabelDIParser._detect_header_end(page)

        # The column header labels live in the bottom portion of the header.
        # For first pages, the header is large (boring info + column labels).
        # For continuation pages, it's mostly just column labels.
        # Look in the bottom 40% of the header area.
        col_header_y_min = header_end * 0.55
        col_header_y_max = header_end

        # Collect x-positions for each column label found in header row
        col_centers: dict[str, list[float]] = {k: [] for k in _COLUMN_HEADER_LABELS}

        for w in page.words:
            y = w["top"]
            if y < col_header_y_min or y > col_header_y_max:
                continue
            word_lower = w["text"].strip().lower()
            x_center = ((w["x0"] + w["x1"]) / 2) / width

            for col_name, labels in _COLUMN_HEADER_LABELS.items():
                if word_lower in labels:
                    col_centers[col_name].append(x_center)

        # For depth, pick the leftmost match (avoid "SAMPLING DEPTH" which is rightward)
        if col_centers["depth"]:
            col_centers["depth"] = [min(col_centers["depth"])]

        # Compute representative x for each detected column
        detected: dict[str, float] = {}
        for col_name, positions in col_centers.items():
            if positions:
                detected[col_name] = sum(positions) / len(positions)

        # Need at least 3 columns detected for reliable layout
        if len(detected) < 3:
            return _DEFAULT_COLUMNS

        # Build column boundaries from detected centers.
        sorted_detected = sorted(
            [(name, x) for name, x in detected.items()],
            key=lambda t: t[1]
        )

        # The canonical column order (left to right)
        col_order = ["depth", "description", "uscs", "elevation",
                     "stratum", "sample_no", "blow_counts", "n_value_area"]

        # Merge detected positions with defaults for undetected columns.
        # For undetected columns, estimate position relative to detected neighbors.
        all_positions: dict[str, float] = {}
        for name in col_order:
            if name in detected:
                all_positions[name] = detected[name]

        # For missing columns between detected ones, interpolate position
        # using the canonical order as a guide.
        detected_in_order = [(name, all_positions[name]) for name in col_order
                             if name in all_positions]
        for i, name in enumerate(col_order):
            if name in all_positions:
                continue
            # Find nearest detected neighbors in order
            left_neighbor = None
            right_neighbor = None
            for j in range(i - 1, -1, -1):
                if col_order[j] in all_positions:
                    left_neighbor = (j, all_positions[col_order[j]])
                    break
            for j in range(i + 1, len(col_order)):
                if col_order[j] in all_positions:
                    right_neighbor = (j, all_positions[col_order[j]])
                    break

            if left_neighbor and right_neighbor:
                # Interpolate
                li, lx = left_neighbor
                ri, rx = right_neighbor
                frac = (i - li) / (ri - li)
                all_positions[name] = lx + frac * (rx - lx)
            elif left_neighbor:
                # Extrapolate right using default spacing
                all_positions[name] = left_neighbor[1] + 0.06
            elif right_neighbor:
                all_positions[name] = right_neighbor[1] - 0.06
            else:
                all_positions[name] = _DEFAULT_COLUMNS[name][0]

        # Build boundaries from sorted positions
        sorted_cols = [(name, all_positions[name]) for name in col_order
                       if name in all_positions]
        sorted_cols.sort(key=lambda t: t[1])

        columns: dict[str, tuple[float, float]] = {}
        for i, (name, x) in enumerate(sorted_cols):
            if i == 0:
                left = max(0.0, x - 0.04)
            else:
                left = (sorted_cols[i - 1][1] + x) / 2

            if i == len(sorted_cols) - 1:
                right = 1.0
            else:
                right = (x + sorted_cols[i + 1][1]) / 2

            columns[name] = (left, right)

        return columns

    def _filter_data_words(self, page: PageContent) -> list[dict]:
        """Filter page words to data area only, excluding watermarks."""
        width = page.width
        height = page.height
        header_end = self._detect_header_end(page)
        data_words = []
        for w in page.words:
            if w["top"] < header_end or w["top"] > height * FOOTER_Y_FRAC:
                continue
            # Skip gINT watermark text (rotated along left edge, x < 0.06)
            x_frac = w["x0"] / width
            if x_frac < 0.06:
                if any(p.search(w["text"]) for p in _GINT_WATERMARK_PATTERNS):
                    continue
                if _GINT_WATERMARK_GENERAL.match(w["text"]):
                    continue
                if x_frac < 0.03 and not re.match(r"^-?\d+\.?\d*$", w["text"].strip()):
                    continue
            data_words.append(w)
        return data_words

    def _classify_row_words(
        self, row_words: list[dict], width: float,
        columns: dict[str, tuple[float, float]] | None = None,
    ) -> dict[str, list[str]]:
        """Classify words in a row into columns based on x-position."""
        cols = columns or _DEFAULT_COLUMNS
        row_data: dict[str, list[str]] = {col: [] for col in cols}
        for w in row_words:
            x_center = ((w["x0"] + w["x1"]) / 2) / width
            text = w["text"].strip()
            if not text:
                continue
            for col_name, (x_min, x_max) in cols.items():
                if x_min <= x_center <= x_max:
                    row_data[col_name].append(text)
                    break
        return row_data

    def _build_depth_scale(
        self, rows: dict[float, list[dict]], width: float,
        columns: dict[str, tuple[float, float]] | None = None,
    ) -> list[tuple[float, float]]:
        """Build depth calibration points: list of (y_position, depth_value).

        Boring logs have depth markers at soil layer transitions. By collecting
        all (y, depth) pairs, we can linearly interpolate the depth for any
        row based on its y-position on the page.
        """
        points: list[tuple[float, float]] = []
        for y_pos, row_words in sorted(rows.items()):
            row_data = self._classify_row_words(row_words, width, columns)
            # Try each word in the depth column individually — watermark
            # words may be mixed in with real depth values at the same row.
            for word in row_data["depth"]:
                depth = self._parse_numeric(word)
                if depth is not None:
                    points.append((y_pos, depth))
                    break
        return points

    def _interpolate_depth(
        self, y: float, scale_points: list[tuple[float, float]]
    ) -> Optional[float]:
        """Interpolate depth at y-position using linear depth scale.

        Uses the calibration points (y, depth) to map any y-position to a depth.
        Extrapolates linearly outside the known range using the nearest two points.
        """
        if not scale_points:
            return None
        if len(scale_points) == 1:
            return scale_points[0][1]

        # Sort by y
        pts = sorted(scale_points)

        # Extrapolate above first point
        if y <= pts[0][0]:
            y0, d0 = pts[0]
            y1, d1 = pts[1]
            if y1 == y0:
                return d0
            rate = (d1 - d0) / (y1 - y0)
            return d0 + rate * (y - y0)

        # Extrapolate below last point
        if y >= pts[-1][0]:
            y0, d0 = pts[-2]
            y1, d1 = pts[-1]
            if y1 == y0:
                return d1
            rate = (d1 - d0) / (y1 - y0)
            return d1 + rate * (y - y1)

        # Interpolate between bracketing points
        for i in range(len(pts) - 1):
            y0, d0 = pts[i]
            y1, d1 = pts[i + 1]
            if y0 <= y <= y1:
                if y1 == y0:
                    return d0
                frac = (y - y0) / (y1 - y0)
                return d0 + frac * (d1 - d0)

        return None

    def _parse_data_area(
        self, page: PageContent, unit: str,
        start_sample_number: int = 1,
    ) -> tuple[list[Sample], list[SoilLayer]]:
        """Extract samples and soil layers from the data area of a boring log page.

        Uses depth scale calibration: first collects depth markers from the depth
        column, then interpolates the depth for every row based on y-position.
        This is essential because boring logs only show depth values at soil layer
        transitions, not at every sample row.
        """
        samples: list[Sample] = []
        layers: list[SoilLayer] = []

        if not page.words:
            return samples, layers

        width = page.width
        columns = self._detect_columns(page)
        data_words = self._filter_data_words(page)

        # Group words into rows by y-position
        rows = self._group_words_by_row(data_words, tolerance=5.0)

        # PASS 1: Build depth scale from depth column markers
        scale_points = self._build_depth_scale(rows, width, columns)

        # PASS 2: Build a map of y-position -> sample number from anchors.
        # These are explicit numbers visible in the sample_no column.
        anchor_at_y: dict[float, int] = {}
        for y_pos, row_words in sorted(rows.items()):
            row_data = self._classify_row_words(row_words, width, columns)
            sample_no_text = " ".join(row_data["sample_no"])
            sample_no = self._clean_sample_no(sample_no_text)
            if sample_no and sample_no.isdigit():
                num = int(sample_no)
                # Only accept anchors >= start_sample_number (avoids
                # noise from other columns or continuation markers)
                if num >= start_sample_number:
                    anchor_at_y[y_pos] = num

        # PASS 3: Process each row using interpolated depths
        current_desc_lines: list[str] = []
        current_layer_start: Optional[float] = None
        next_sample_number = start_sample_number  # Sequential counter

        for y_pos, row_words in sorted(rows.items()):
            row_data = self._classify_row_words(row_words, width, columns)

            # Interpolate depth from y-position
            depth = self._interpolate_depth(y_pos, scale_points)

            # Extract row contents
            blow_text = " ".join(row_data["blow_counts"])
            spt = self._parse_blow_counts_plus(blow_text)

            sample_no_text = " ".join(row_data["sample_no"])
            sample_no = self._clean_sample_no(sample_no_text)

            desc_text = " ".join(row_data["description"])
            uscs_text = " ".join(row_data["uscs"])

            # Build samples from rows with blow counts
            if spt is not None and depth is not None:
                depth_ft = depth * METERS_TO_FEET if unit == "m" else depth
                interval = 1.5 if unit == "ft" else (0.45 * METERS_TO_FEET)

                # Determine sample number: sequential, corrected by anchors.
                # Check if any anchor is near this blow count row (within 50pt
                # above). If found, it overrides the sequential counter —
                # useful when samples are skipped (e.g., grab samples between
                # SPTs that we don't extract).
                anchor_num: Optional[int] = None
                for a_y, a_num in sorted(anchor_at_y.items()):
                    if a_y > y_pos + 10.0:
                        break  # Past this row — stop looking
                    if abs(a_y - y_pos) <= 50.0 and a_num >= next_sample_number:
                        anchor_num = a_num
                        del anchor_at_y[a_y]
                        break

                if anchor_num is not None:
                    next_sample_number = anchor_num
                matched_sample_no = str(next_sample_number)
                next_sample_number += 1

                samples.append(Sample(
                    sample_number=matched_sample_no,
                    sample_type=SampleType.SPLIT_SPOON,
                    depth_top_ft=round(depth_ft, 1),
                    depth_bottom_ft=round(depth_ft + interval, 1),
                    spt=spt,
                ))

            # Build soil layers from description text
            if desc_text and not self._is_header_text(desc_text):
                if self._is_new_layer_description(desc_text):
                    # Save previous layer
                    if current_desc_lines and current_layer_start is not None:
                        layer_end = depth
                        layer = self._build_soil_layer(
                            current_layer_start, layer_end,
                            current_desc_lines, unit
                        )
                        if layer:
                            layers.append(layer)
                    current_desc_lines = [desc_text]
                    if uscs_text:
                        current_desc_lines.append(f"({uscs_text})")
                    current_layer_start = depth
                else:
                    current_desc_lines.append(desc_text)

        # Don't forget last layer
        if current_desc_lines and current_layer_start is not None:
            # Use the last scale point depth as layer bottom
            last_depth = scale_points[-1][1] if scale_points else None
            layer = self._build_soil_layer(
                current_layer_start, last_depth, current_desc_lines, unit
            )
            if layer:
                layers.append(layer)

        return samples, layers

    def _parse_water_levels(self, page: PageContent, unit: str) -> list[WaterLevelObservation]:
        """Extract groundwater observations from the header area."""
        water_levels: list[WaterLevelObservation] = []
        text = page.text

        # Look for "DRY" or specific water depth values in the groundwater table
        patterns = [
            r"(?i)(?:ground)?water\s*(?:level|encountered|observed)\s*(?:at)?\s*([\d.]+)\s*(?:m|ft|feet)?",
            r"(?i)water\s*(?:table|surface)\s*(?:at)?\s*([\d.]+)",
            r"(?i)seepage\s*(?:at|@)\s*([\d.]+)",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, text):
                depth_val = float(match.group(1))
                if unit == "m":
                    depth_val *= METERS_TO_FEET

                is_during = bool(re.search(r"(?i)during\s+drilling|while\s+drilling", text))
                is_stabilized = bool(re.search(r"(?i)stabili[sz]ed|24\s*(?:hr|hour)", text))

                water_levels.append(WaterLevelObservation(
                    depth_ft=depth_val,
                    is_during_drilling=is_during,
                    is_stabilized=is_stabilized,
                ))

        return water_levels

    def _group_words_by_row(
        self, words: list[dict], tolerance: float = 5.0
    ) -> dict[float, list[dict]]:
        """Group words sharing approximately the same y-position."""
        rows: dict[float, list[dict]] = {}
        for word in sorted(words, key=lambda w: w["top"]):
            y = word["top"]
            matched = False
            for row_y in list(rows.keys()):
                if abs(y - row_y) <= tolerance:
                    rows[row_y].append(word)
                    matched = True
                    break
            if not matched:
                rows[y] = [word]
        return rows

    @staticmethod
    def _parse_numeric(text: str) -> Optional[float]:
        """Parse a numeric value from text."""
        if not text:
            return None
        text = text.strip()
        m = re.match(r"^-?(\d+\.?\d*)$", text)
        if m:
            return float(m.group(1))
        return None

    @staticmethod
    def _parse_blow_counts_plus(text: str) -> Optional[SPTBlowCounts]:
        """Parse SPT blow counts in plus-separated format: '2+4+6'."""
        if not text:
            return None
        text = text.strip()

        # Check for refusal
        refusal = bool(re.search(r"(?i)ref|50/\d|WOH|WOR", text))

        m = _BLOW_COUNT_RE.match(text)
        if m:
            b1, b2, b3 = int(m.group(1)), int(m.group(2)), int(m.group(3))
            n_value = b2 + b3
            return SPTBlowCounts(
                first_6in=b1,
                second_6in=b2,
                third_6in=b3,
                n_value=n_value,
                refusal=refusal or n_value >= 50,
            )

        # Also handle dash-separated format
        m2 = re.match(r"^(\d{1,3})\s*[-/]\s*(\d{1,3})\s*[-/]\s*(\d{1,3})$", text)
        if m2:
            b1, b2, b3 = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
            n_value = b2 + b3
            return SPTBlowCounts(
                first_6in=b1,
                second_6in=b2,
                third_6in=b3,
                n_value=n_value,
                refusal=refusal or n_value >= 50,
            )

        # Single N-value
        m3 = re.match(r"^(\d{1,3})$", text)
        if m3 and refusal:
            return SPTBlowCounts(n_value=int(m3.group(1)), refusal=True)

        if refusal:
            return SPTBlowCounts(refusal=True)

        return None

    @staticmethod
    def _clean_sample_no(text: str) -> Optional[str]:
        """Clean up sample number text."""
        if not text:
            return None
        text = text.strip()
        # Filter out header words
        if text.lower() in {"depth", "data", "sample", "no", "no.", "wl", "-"}:
            return None
        # Filter out the "- 8" format (continuation markers)
        if text.startswith("-"):
            return None
        return text if text else None

    @staticmethod
    def _is_header_text(text: str) -> bool:
        """Check if text is a column header."""
        headers = {
            "depth", "sample", "type", "blow", "recovery", "description",
            "classification", "material", "count", "n-value", "spt",
            "number", "remarks", "graphic", "log", "elev", "boring",
            "strata", "symbol", "stratum", "sampling", "data",
            "continued", "next", "page", "unconfined", "compressive",
            "strength", "kg/cm2", "pl", "mc", "ll", "value", "blows/ft.",
            "n",
        }
        return text.strip().lower() in headers

    @staticmethod
    def _is_new_layer_description(text: str) -> bool:
        """Heuristic: does this text start a new soil layer?"""
        soil_keywords = [
            "SAND", "CLAY", "SILT", "GRAVEL", "FILL", "TOPSOIL",
            "PEAT", "LOAM", "TILL", "ROCK", "SHALE", "SANDSTONE",
            "LIMESTONE", "GRANITE", "GNEISS", "SCHIST", "BASALT",
            "MUDSTONE", "SILTSTONE", "WEATHERED", "DECOMPOSED",
            "ORGANIC", "COBBLES", "BOULDERS", "BEDROCK", "RESIDUUM",
            "FAT CLAY", "LEAN CLAY", "SILTY", "SANDY", "CLAYEY",
            "TOPSOIL", "ASPHALT", "CONCRETE", "AGGREGATE",
        ]
        text_upper = text.strip().upper()
        return any(text_upper.startswith(kw) for kw in soil_keywords)

    def _build_soil_layer(
        self,
        depth_top: float,
        depth_bottom: Optional[float],
        desc_lines: list[str],
        unit: str,
    ) -> Optional[SoilLayer]:
        """Build a SoilLayer from accumulated description lines."""
        description = " ".join(desc_lines).strip()
        if not description:
            return None

        # Convert depths
        if unit == "m":
            top_ft = depth_top * METERS_TO_FEET
            bottom_ft = depth_bottom * METERS_TO_FEET if depth_bottom is not None else None
        else:
            top_ft = depth_top
            bottom_ft = depth_bottom

        # Extract USCS from description or parenthetical
        uscs = None
        for cls in USCSClassification:
            if re.search(rf"\b{cls.value}\b", description):
                uscs = cls
                break

        # Extract color
        color = None
        color_match = re.search(
            r"(?i)\b(brown|gray|grey|tan|red|orange|yellow|black|white|dark|light)\b"
            r"(?:\s+(?:brown|gray|grey|tan|red|orange|to)\b)*",
            description,
        )
        if color_match:
            color = color_match.group(0).strip().lower()

        # Extract moisture
        moisture = None
        for mc in MoistureCondition:
            if re.search(rf"(?i)\b{mc.value}\b", description):
                moisture = mc
                break

        return SoilLayer(
            depth_top_ft=top_ft,
            depth_bottom_ft=bottom_ft,
            description=description,
            uscs_classification=uscs,
            color=color,
            moisture=moisture,
        )

    @staticmethod
    def _infer_total_depth(samples: list[Sample]) -> float:
        """Infer total boring depth from deepest sample."""
        if not samples:
            return 0.0
        return max(s.depth_bottom_ft for s in samples)
