"""Base parser interface for boring log extraction.

Each geotechnical firm uses a slightly different boring log template.
Firm-specific parsers extend BaseBoringLogParser to handle the particular
layout, column positions, and naming conventions of each template.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from datetime import date
from typing import Optional

from geotech_report_extraction.models import (
    Borehole,
    BoreholeLog,
    DrillingDetails,
    Project,
    Sample,
    SoilLayer,
    SPTBlowCounts,
    WaterLevelObservation,
)
from geotech_report_extraction.pdf_parser import PageContent, PDFContent


class BaseBoringLogParser(ABC):
    """Abstract base class for firm-specific boring log parsers.

    Subclasses implement the template-specific extraction logic for
    a particular firm's boring log format.
    """

    firm_name: str = "Unknown"

    @abstractmethod
    def parse_boring_log(
        self, pages: list[PageContent]
    ) -> Borehole:
        """Parse boring log data from one or more pages for a single boring.

        Args:
            pages: List of PageContent objects for this boring
                   (may be multiple pages for deep borings).

        Returns:
            A Borehole model with extracted data.
        """
        ...

    def parse_project_info(self, pdf_content: PDFContent) -> Project:
        """Extract project-level metadata from the report.

        Default implementation scans boring log pages for common header fields.
        Override for firm-specific header layouts.
        """
        project = Project(firm=self.firm_name)

        # Look at boring log pages for project info
        for page in pdf_content.boring_log_pages:
            text = page.text
            if project.name is None:
                project.name = self._extract_field(
                    text,
                    [r"(?i)project\s*:?\s*(.+?)(?:\n|$)",
                     r"(?i)project\s+name\s*:?\s*(.+?)(?:\n|$)"],
                )
            if project.number is None:
                project.number = self._extract_field(
                    text,
                    [r"(?i)project\s*(?:no\.?|number|#)\s*:?\s*(\S+)",
                     r"(?i)job\s*(?:no\.?|number|#)\s*:?\s*(\S+)"],
                )
            if project.client is None:
                project.client = self._extract_field(
                    text,
                    [r"(?i)client\s*:?\s*(.+?)(?:\n|$)",
                     r"(?i)prepared\s+for\s*:?\s*(.+?)(?:\n|$)"],
                )
            if project.location is None:
                project.location = self._extract_field(
                    text,
                    [r"(?i)(?:site|project)\s+location\s*:?\s*(.+?)(?:\n|$)",
                     r"(?i)location\s*:?\s*(.+?)(?:\n|$)"],
                )
            # Stop if we have enough info
            if all([project.name, project.number]):
                break

        return project

    def _extract_field(
        self, text: str, patterns: list[str]
    ) -> Optional[str]:
        """Try multiple regex patterns to extract a field value."""
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                value = match.group(1).strip()
                if value:
                    return value
        return None

    @staticmethod
    def parse_date(text: str) -> Optional[date]:
        """Try to parse a date string in common US formats."""
        date_patterns = [
            (r"(\d{1,2})/(\d{1,2})/(\d{4})", "%m/%d/%Y"),
            (r"(\d{1,2})/(\d{1,2})/(\d{2})", "%m/%d/%y"),
            (r"(\d{1,2})-(\d{1,2})-(\d{4})", "%m-%d-%Y"),
        ]
        for pattern, fmt in date_patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    from datetime import datetime
                    return datetime.strptime(match.group(0), fmt).date()
                except ValueError:
                    continue
        return None

    @staticmethod
    def parse_blow_counts(text: str) -> Optional[SPTBlowCounts]:
        """Parse SPT blow count strings like '5-8-12' or '5/8/12'."""
        text = text.strip()
        if not text:
            return None

        # Check for refusal indicators
        refusal = False
        if re.search(r"(?i)ref|50/\d|WOH|WOR", text):
            refusal = True

        # Parse blow counts in format like "5-8-12", "5/8/12", or "5+8+12"
        # Also handles four-part format "2+4+6+7" (seating blow + 3 increments)
        four_part = re.match(
            r"(\d+)\s*[-/+]\s*(\d+)\s*[-/+]\s*(\d+)\s*[-/+]\s*(\d+)", text
        )
        if four_part:
            # Four-part: first is seating, then 3 increments for N-value
            b1 = int(four_part.group(1))
            b2 = int(four_part.group(2))
            b3 = int(four_part.group(3))
            b4 = int(four_part.group(4))
            n_value = b3 + b4
            return SPTBlowCounts(
                first_6in=b2,
                second_6in=b3,
                third_6in=b4,
                n_value=n_value,
                refusal=refusal or n_value >= 50,
            )

        match = re.match(r"(\d+)\s*[-/+]\s*(\d+)\s*[-/+]\s*(\d+)", text)
        if match:
            b1, b2, b3 = int(match.group(1)), int(match.group(2)), int(match.group(3))
            n_value = b2 + b3
            return SPTBlowCounts(
                first_6in=b1,
                second_6in=b2,
                third_6in=b3,
                n_value=n_value,
                refusal=refusal or n_value >= 50,
            )

        # Try just an N-value (single number)
        match = re.match(r"(\d+)", text)
        if match:
            n = int(match.group(1))
            return SPTBlowCounts(n_value=n, refusal=refusal or n >= 50)

        if refusal:
            return SPTBlowCounts(refusal=True)

        return None

    @staticmethod
    def parse_depth(text: str) -> Optional[float]:
        """Parse a depth value from text, handling common formats."""
        if not text:
            return None
        text = text.strip().rstrip("'\"")
        match = re.search(r"(\d+\.?\d*|\.\d+)", text)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                return None
        return None
