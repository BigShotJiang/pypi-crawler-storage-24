"""Page classifiers for geotechnical reports.

Provides classifiers at three levels:

1. **BoringLogClassifier** (binary) — is this page a boring log? Returns
   (is_boring_log, confidence). Used by the extraction pipeline.

2. **PageTypeClassifier** (multi-class, 15 classes) — XGBoost text-feature
   classifier. Returns the predicted class name and per-class probabilities.

3. **HybridPageClassifier** — combines XGBoost with Claude vision API for
   pages where XGBoost confidence is low or the page type is inherently
   visual (test_location_plan, figure, field_photos, subsurface_profile,
   cover_page). Requires ``anthropic`` and ``pymupdf`` extras.

All classifiers fall back gracefully if dependencies are missing.
"""

from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Optional

from geotech_report_extraction.ml_features import FEATURE_NAMES, extract_features, get_feature_names
from geotech_report_extraction.pdf_parser import PageContent

logger = logging.getLogger(__name__)

# Default model locations — bundled inside the package as package data
_PACKAGE_DATA_DIR = Path(__file__).parent / "data"
_DEFAULT_BINARY_MODEL_PATH = _PACKAGE_DATA_DIR / "boring_log_classifier.json"
_DEFAULT_MULTICLASS_MODEL_PATH = _PACKAGE_DATA_DIR / "page_type_classifier.json"
_DEFAULT_MULTICLASS_CLASSES_PATH = _PACKAGE_DATA_DIR / "page_type_classes.txt"


# ---------------------------------------------------------------------------
# Binary classifier (boring log vs not)
# ---------------------------------------------------------------------------

class BoringLogClassifier:
    """XGBoost-based boring log page classifier with confidence scores."""

    def __init__(
        self,
        model_path: Optional[Path] = None,
        threshold: float = 0.5,
    ):
        self.threshold = threshold
        self._model = None
        self._model_path = model_path or _DEFAULT_BINARY_MODEL_PATH
        self._load_attempted = False

    def _ensure_model(self) -> bool:
        """Lazily load the model on first use."""
        if self._model is not None:
            return True
        if self._load_attempted:
            return False

        self._load_attempted = True

        try:
            import xgboost as xgb
        except ImportError:
            logger.warning("xgboost not installed; using heuristic classifier")
            return False

        if not self._model_path.exists():
            logger.warning(
                "Model file not found at %s; using heuristic classifier",
                self._model_path,
            )
            return False

        try:
            self._model = xgb.XGBClassifier()
            self._model.load_model(str(self._model_path))
            logger.info("Loaded boring log classifier from %s", self._model_path)
            return True
        except Exception as e:
            logger.warning("Failed to load model: %s; using heuristic", e)
            self._model = None
            return False

    def classify(
        self,
        page: PageContent,
        total_pages: int = 0,
        page_index: int = -1,
    ) -> tuple[bool, float]:
        """Classify a single page.

        Returns:
            (is_boring_log, confidence) where confidence is the predicted
            probability from XGBoost [0.0, 1.0], or the heuristic score
            if the ML model is unavailable.
        """
        if not self._ensure_model():
            # Try multi-class model as fallback before heuristic
            mc = get_page_type_classifier()
            if mc._ensure_model():
                cls, probs = mc.classify(
                    page, total_pages=total_pages, page_index=page_index
                )
                boring_prob = probs.get("boring_log", 0.0)
                return boring_prob >= self.threshold, boring_prob
            return self._heuristic_classify(page)

        features = extract_features(page, total_pages=total_pages, page_index=page_index)
        fnames = get_feature_names()
        feature_vector = [[features.get(name, 0.0) for name in fnames]]

        import numpy as np
        prob = self._model.predict_proba(np.array(feature_vector))[0, 1]

        return prob >= self.threshold, float(prob)

    @staticmethod
    def _heuristic_classify(page: PageContent) -> tuple[bool, float]:
        """Fallback heuristic classifier (from di_reader.py)."""
        from geotech_report_extraction.di_reader import _classify_boring_log_page
        return _classify_boring_log_page(page)


# ---------------------------------------------------------------------------
# Multi-class page type classifier (15 classes)
# ---------------------------------------------------------------------------

class PageTypeClassifier:
    """XGBoost multi-class page type classifier.

    Classifies pages into 15 types: appendix_cover_page, boring_log,
    calculation, cover_letter, cover_page, field_photos, figure,
    informational_appendix, lab_testing, main_report_narrative, other,
    subsurface_profile, table_of_contents, test_location_plan, test_pit_log.
    """

    def __init__(
        self,
        model_path: Optional[Path] = None,
        classes_path: Optional[Path] = None,
    ):
        self._model = None
        self._model_path = model_path or _DEFAULT_MULTICLASS_MODEL_PATH
        self._classes_path = classes_path or _DEFAULT_MULTICLASS_CLASSES_PATH
        self._class_names: list[str] = []
        self._load_attempted = False

    def _ensure_model(self) -> bool:
        """Lazily load the model and class names on first use."""
        if self._model is not None:
            return True
        if self._load_attempted:
            return False

        self._load_attempted = True

        try:
            import xgboost as xgb
        except ImportError:
            logger.warning("xgboost not installed; page type classifier unavailable")
            return False

        if not self._model_path.exists():
            logger.warning(
                "Multi-class model not found at %s", self._model_path
            )
            return False

        if not self._classes_path.exists():
            logger.warning(
                "Class names file not found at %s", self._classes_path
            )
            return False

        try:
            self._class_names = [
                line.strip()
                for line in self._classes_path.read_text().strip().split("\n")
                if line.strip()
            ]

            self._model = xgb.XGBClassifier()
            self._model.load_model(str(self._model_path))
            logger.info(
                "Loaded page type classifier (%d classes) from %s",
                len(self._class_names), self._model_path,
            )
            return True
        except Exception as e:
            logger.warning("Failed to load multi-class model: %s", e)
            self._model = None
            self._class_names = []
            return False

    @property
    def class_names(self) -> list[str]:
        """Return the list of class names (empty if model not loaded)."""
        self._ensure_model()
        return list(self._class_names)

    def classify(
        self,
        page: PageContent,
        total_pages: int = 0,
        page_index: int = -1,
    ) -> tuple[str, dict[str, float]]:
        """Classify a page into one of 15 types.

        Args:
            page: The page to classify.
            total_pages: Total pages in the document (for positional features).
            page_index: 0-based index of this page (for positional features).

        Returns:
            (predicted_class, probabilities) where predicted_class is the
            class name string and probabilities is a dict mapping each
            class name to its predicted probability.
            Returns ("unknown", {}) if the model is unavailable.
        """
        if not self._ensure_model():
            return "unknown", {}

        features = extract_features(page, total_pages=total_pages, page_index=page_index)
        fnames = get_feature_names()
        feature_vector = [[features.get(name, 0.0) for name in fnames]]

        import numpy as np
        probs = self._model.predict_proba(np.array(feature_vector))[0]

        prob_dict = {
            name: float(p) for name, p in zip(self._class_names, probs)
        }
        predicted_idx = int(probs.argmax())
        predicted_class = self._class_names[predicted_idx]

        return predicted_class, prob_dict

    def classify_pages(
        self,
        pages: list[PageContent],
    ) -> list[tuple[str, dict[str, float]]]:
        """Classify all pages in a document, using positional features.

        Args:
            pages: List of pages sorted by page number.

        Returns:
            List of (predicted_class, probabilities) tuples.
        """
        total = len(pages)
        results = []
        for i, page in enumerate(pages):
            results.append(self.classify(page, total_pages=total, page_index=i))
        return results


# ---------------------------------------------------------------------------
# Hybrid classifier (XGBoost + Claude vision)
# ---------------------------------------------------------------------------

# Page types that are inherently visual — XGBoost can't reliably classify
# these from text features alone.
_VISUAL_CLASSES = frozenset({
    "test_location_plan", "figure", "field_photos",
    "subsurface_profile", "cover_page",
})

# Classes where vision provides net positive corrections when XGB predicts them.
# Based on LORO hybrid eval per-class win/loss analysis.
_VISION_BENEFICIAL_PREDS = frozenset({
    "other",                  # +11 net: vision often corrects "other" to the right class
    "lab_testing",            # +3 net
    "informational_appendix",
})

_VISION_SYSTEM_PROMPT = """\
You are a geotechnical engineering document classifier. Given a page image \
from a geotechnical report, classify it into exactly one of these 15 types:

- boring_log: Standard boring log form with columns for depth, soil description, \
blow counts, sample types. Usually has a firm header and boring ID.
- test_pit_log: Test pit excavation log. Similar to boring log but for \
shallow hand/machine-dug pits.
- lab_testing: Laboratory test results — sieve analysis, Atterberg limits, \
moisture content, triaxial, consolidation. Often has ASTM references.
- calculation: Engineering calculations — bearing capacity, settlement, \
lateral earth pressure, pile design, slope stability. May be hand-written \
or software output.
- main_report_narrative: Prose text describing site conditions, findings, \
recommendations. The main body of the report.
- field_photos: Photographs from the site — core boxes, test pits, site views.
- figure: Engineering drawings, cross-sections, detail sketches, drainage plans.
- cover_page: Title/cover page with project name, firm logo, date. Minimal text.
- cover_letter: Transmittal letter with salutation, body text, signature block.
- appendix_cover_page: Divider page for an appendix section (e.g., "Appendix A").
- informational_appendix: Reference material, general notes, standard specs.
- table_of_contents: TOC or list of figures/tables/appendices.
- subsurface_profile: Cross-sectional view showing soil/rock layers with \
boring locations plotted along a line.
- test_location_plan: Site plan/map showing boring and test pit locations. \
Usually has a north arrow, scale, and location IDs.
- other: Anything that doesn't fit the above categories.

Respond with ONLY a JSON object: {"class": "<class_name>", "confidence": <0.0-1.0>}
"""


class HybridPageClassifier:
    """Combines XGBoost text classification with Claude vision for visual pages.

    Strategy:
    1. Run XGBoost on all pages (fast, free).
    2. For pages where XGBoost confidence < threshold OR the predicted class
       is a visual type, send the page image to Claude for a second opinion.
    3. Use the higher-confidence prediction, with a preference for Claude
       on visual classes.

    Requires: ``anthropic`` and ``pymupdf`` packages.
    """

    def __init__(
        self,
        xgb_confidence_threshold: float = 0.70,
        vision_model: str = "claude-haiku-4-5",
        api_key: Optional[str] = None,
    ):
        self._xgb_threshold = xgb_confidence_threshold
        self._vision_model = vision_model
        self._api_key = api_key
        self._anthropic_client = None
        self._xgb = get_page_type_classifier()

    def _get_client(self):
        """Lazily initialize Anthropic client."""
        if self._anthropic_client is None:
            try:
                import anthropic
                self._anthropic_client = anthropic.Anthropic(
                    api_key=self._api_key
                ) if self._api_key else anthropic.Anthropic()
            except ImportError:
                logger.warning("anthropic package not installed; vision classification unavailable")
                return None
        return self._anthropic_client

    def _render_page_image(self, pdf_path: str, page_number: int) -> Optional[str]:
        """Render a PDF page to a base64-encoded PNG."""
        try:
            import fitz  # pymupdf
        except ImportError:
            logger.warning("pymupdf not installed; cannot render page images")
            return None

        try:
            doc = fitz.open(pdf_path)
            # page_number is 1-based in our data
            page = doc[page_number - 1]
            # Try 150 DPI first, fall back to lower if image too large
            for dpi in (150, 100, 72):
                pix = page.get_pixmap(dpi=dpi)
                img_bytes = pix.tobytes("png")
                if len(img_bytes) <= 4_500_000:  # Stay under 5MB limit
                    break
            doc.close()
            if len(img_bytes) > 4_500_000:
                logger.warning("Page %d image too large even at 72 DPI", page_number)
                return None
            return base64.standard_b64encode(img_bytes).decode("utf-8")
        except Exception as e:
            logger.warning("Failed to render page %d: %s", page_number, e)
            return None

    def _vision_classify(self, image_b64: str) -> tuple[str, float]:
        """Send a page image to Claude for classification."""
        client = self._get_client()
        if client is None:
            return "unknown", 0.0

        try:
            response = client.messages.create(
                model=self._vision_model,
                max_tokens=100,
                system=_VISION_SYSTEM_PROMPT,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Classify this page.",
                        },
                    ],
                }],
            )

            text = response.content[0].text.strip()
            # Parse JSON response
            # Handle cases where model wraps in markdown code block
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
                text = text.strip()

            result = json.loads(text)
            cls = result.get("class", "unknown")
            conf = float(result.get("confidence", 0.0))

            # Validate class name
            valid_classes = self._xgb.class_names
            if valid_classes and cls not in valid_classes:
                logger.warning("Vision returned unknown class '%s'", cls)
                return "unknown", 0.0

            return cls, conf

        except Exception as e:
            logger.warning("Vision classification failed: %s", e)
            return "unknown", 0.0

    def classify_page(
        self,
        page: PageContent,
        pdf_path: Optional[str] = None,
        total_pages: int = 0,
        page_index: int = -1,
    ) -> tuple[str, dict[str, float], str]:
        """Classify a single page using hybrid XGBoost + vision approach.

        Args:
            page: PageContent to classify.
            pdf_path: Path to source PDF (needed for vision rendering).
            total_pages: Total pages in document.
            page_index: 0-based page index.

        Returns:
            (predicted_class, probabilities, method) where method is
            "xgboost", "vision", or "hybrid".
        """
        # Step 1: XGBoost classification
        xgb_class, xgb_probs = self._xgb.classify(
            page, total_pages=total_pages, page_index=page_index
        )
        xgb_conf = max(xgb_probs.values()) if xgb_probs else 0.0

        # Step 2: Decide if we need vision
        # Call vision when:
        # - XGBoost confidence is very low (< threshold)
        # - XGBoost predicts a visual class with moderate confidence (< 0.90)
        # - XGBoost predicts a class where vision provides net benefit (< 0.85)
        needs_vision = (
            pdf_path is not None
            and (
                xgb_conf < self._xgb_threshold
                or (xgb_class in _VISUAL_CLASSES and xgb_conf < 0.90)
                or (xgb_class in _VISION_BENEFICIAL_PREDS and xgb_conf < 0.85)
            )
        )

        if not needs_vision:
            return xgb_class, xgb_probs, "xgboost"

        # Step 3: Render and classify with vision
        image_b64 = self._render_page_image(pdf_path, page.page_number)
        if image_b64 is None:
            return xgb_class, xgb_probs, "xgboost"

        vision_class, vision_conf = self._vision_classify(image_b64)
        if vision_class == "unknown":
            return xgb_class, xgb_probs, "xgboost"

        # Step 4: Combine results using per-class trust calibration
        if vision_class in _VISUAL_CLASSES:
            # Vision is authoritative for visual classes
            final_class = vision_class
            method = "vision"
        elif xgb_class in _VISUAL_CLASSES and vision_class not in _VISUAL_CLASSES:
            # XGBoost said visual but vision says text — trust vision
            final_class = vision_class
            method = "vision"
        elif xgb_class in _VISION_BENEFICIAL_PREDS and vision_conf > 0.5:
            # When XGB predicts "other"/"lab_testing"/"informational_appendix",
            # vision often corrects to the right class
            final_class = vision_class
            method = "hybrid"
        elif vision_conf > xgb_conf + 0.15:
            # For other text classes, only trust vision if much more confident
            final_class = vision_class
            method = "hybrid"
        else:
            final_class = xgb_class
            method = "xgboost"

        # Merge probability dicts (keep XGBoost probs, override predicted class)
        merged_probs = dict(xgb_probs)
        merged_probs[f"_vision_class"] = 0.0  # placeholder
        merged_probs[f"_vision_conf"] = vision_conf
        merged_probs[f"_xgb_conf"] = xgb_conf

        logger.debug(
            "Hybrid: xgb=%s(%.2f) vision=%s(%.2f) -> %s (%s)",
            xgb_class, xgb_conf, vision_class, vision_conf, final_class, method,
        )

        return final_class, merged_probs, method

    def classify_pages(
        self,
        pages: list[PageContent],
        pdf_path: Optional[str] = None,
    ) -> list[tuple[str, dict[str, float], str]]:
        """Classify all pages with hybrid approach.

        Args:
            pages: List of pages sorted by page number.
            pdf_path: Path to source PDF for vision rendering.

        Returns:
            List of (predicted_class, probabilities, method) tuples.
        """
        total = len(pages)
        results = []
        vision_count = 0
        for i, page in enumerate(pages):
            cls, probs, method = self.classify_page(
                page, pdf_path=pdf_path, total_pages=total, page_index=i
            )
            results.append((cls, probs, method))
            if method in ("vision", "hybrid"):
                vision_count += 1

        if vision_count > 0:
            logger.info(
                "Hybrid classification: %d/%d pages used vision (%d XGBoost-only)",
                vision_count, total, total - vision_count,
            )

        return results


# ---------------------------------------------------------------------------
# Module-level singletons and convenience functions
# ---------------------------------------------------------------------------

_default_binary_classifier: Optional[BoringLogClassifier] = None
_default_page_type_classifier: Optional[PageTypeClassifier] = None


def get_classifier(threshold: float = 0.85) -> BoringLogClassifier:
    """Get the default binary boring log classifier singleton."""
    global _default_binary_classifier
    if _default_binary_classifier is None or _default_binary_classifier.threshold != threshold:
        _default_binary_classifier = BoringLogClassifier(threshold=threshold)
    return _default_binary_classifier


def get_page_type_classifier() -> PageTypeClassifier:
    """Get the default multi-class page type classifier singleton."""
    global _default_page_type_classifier
    if _default_page_type_classifier is None:
        _default_page_type_classifier = PageTypeClassifier()
    return _default_page_type_classifier


def classify_page(page: PageContent, threshold: float = 0.85) -> tuple[bool, float]:
    """Classify a single page as boring log or not (binary).

    The default threshold of 0.85 provides a clean separation between
    boring log pages (typically >=0.96) and non-boring pages (typically <=0.69)
    based on validation across Schnabel and Langan reports.

    Convenience function for use in the pipeline.
    """
    return get_classifier(threshold).classify(page)


def classify_page_type(
    page: PageContent,
    total_pages: int = 0,
    page_index: int = -1,
) -> tuple[str, dict[str, float]]:
    """Classify a page into one of 15 types (multi-class).

    Convenience function for use in the pipeline.
    """
    return get_page_type_classifier().classify(
        page, total_pages=total_pages, page_index=page_index
    )


def get_hybrid_classifier(
    xgb_confidence_threshold: float = 0.70,
    vision_model: str = "claude-haiku-4-5",
    api_key: Optional[str] = None,
) -> HybridPageClassifier:
    """Create a hybrid XGBoost + Claude vision classifier.

    Uses XGBoost for text-heavy pages and Claude vision for visual pages
    (test_location_plan, figure, field_photos, subsurface_profile, cover_page)
    or when XGBoost confidence is below threshold.

    Args:
        xgb_confidence_threshold: Send to vision if XGBoost confidence is
            below this value. Default 0.70.
        vision_model: Claude model for vision classification.
            Default claude-haiku-4-5 (fast, cheap). Use claude-sonnet-4-6
            for higher accuracy.
        api_key: Anthropic API key. If None, reads from ANTHROPIC_API_KEY env var.
    """
    return HybridPageClassifier(
        xgb_confidence_threshold=xgb_confidence_threshold,
        vision_model=vision_model,
        api_key=api_key,
    )
