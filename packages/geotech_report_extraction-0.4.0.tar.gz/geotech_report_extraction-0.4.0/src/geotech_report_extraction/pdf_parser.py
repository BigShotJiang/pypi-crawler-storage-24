"""PDF reading and boring log page identification.

Uses PyMuPDF (fitz) for text and layout extraction from geotechnical report PDFs.
PyMuPDF provides better font handling and spatial data than pdfplumber.

Page classification uses a multi-signal scoring approach combining structural
features (drawing objects, text layout) with content analysis (soil terms,
blow counts, sample types) and negative signals (lab tests, TOC, narrative).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    import fitz  # PyMuPDF — optional, not needed for DI JSON path
except ImportError:
    fitz = None


# Patterns that identify boring log TITLES (strong positive signal)
_BORING_LOG_TITLE_PATTERNS = [
    re.compile(r"(?i)\bboring\s+log\b"),
    re.compile(r"(?i)\blog\s+of\s+(?:test\s+)?boring\b"),
    re.compile(r"(?i)\brecord\s+of\s+bor(?:ing|ehole)\b"),
    re.compile(r"(?i)\bsubsurface\s+exploration\s+log\b"),
    re.compile(r"(?i)\bborehole\s+log\b"),
    re.compile(r"(?i)\blog\s+of\s+test\s+pit\b"),
]

# Pattern to extract boring ID from log header.
# Order matters: most-specific contextual patterns first, standalone last.
BORING_ID_PATTERNS = [
    # "BORING LOG NO. BN-3" or "Boring No.: B-1" — captures any alphanumeric ID
    re.compile(
        r"(?i)boring\s*(?:log\s*)?(?:no\.?|number|#|id)\s*:?\s*"
        r"([A-Za-z]*-?\d+[A-Za-z]?)"
    ),
    re.compile(r"(?i)borehole\s*(?:no\.?|number|#|id)?\s*:?\s*((?:BH|GB)-?\d+[A-Za-z]?)"),
    re.compile(r"(?i)test\s+boring\s*(?:no\.?|number|#)?\s*:?\s*(\S+)"),
    # LOG OF TEST PIT LDCP-1 (hand auger logs) — ID must look like a boring ID, not a filename
    re.compile(r"(?i)(?:log\s+of\s+)?test\s+pit\s+([A-Za-z]+-\d+[A-Za-z]?)"),
    # Standalone patterns for common boring ID prefixes
    re.compile(r"\b(BN-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(BH-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(TB-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(GB-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(GC-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(BOR-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(LB-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(HA-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(LDCP-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(DCP-\d+[A-Za-z]?)\b"),
    re.compile(r"\b(TP-\d+[A-Za-z]?)\b"),
    # Langan gINT format: "C-B-BOR-01" → extract "BOR-01"
    re.compile(r"\bC-B-(BOR-\d+[A-Za-z]?)\b"),
    # Generic B- pattern last (can match drill rig numbers, so filtered in _extract_boring_id)
    re.compile(r"\b(B-\d+[A-Za-z]?)\b"),
]

# Hard disqualifiers — these ONLY appear as page titles on non-boring-log pages.
_HARD_DISQUALIFIERS = [
    re.compile(r"(?i)\bTABLE\s+OF\s+CONTENTS\b"),
    re.compile(r"(?i)\bGENERAL\s+(?:NOTES|QUALIFICATIONS)\b"),
    re.compile(r"(?i)\bSTANDARD\s+BORING\s+LOG\s+PROCEDURES\b"),
    re.compile(r"(?i)UNIFIED\s+SOIL\s+CLASSIFICATION\s+SYSTEM\b"),
    re.compile(r"(?i)\bDESCRIPTION\s+OF\s+ROCK\s+PROPERTIES\b"),
    re.compile(r"(?i)\bSITE\s+COEFFICIENTS?\b"),
    re.compile(r"(?i)\bSPECTRAL\s+RESPONSE\b"),
    re.compile(r"(?i)\bSOIL\s+CLASSIFICATION\s+(?:SYSTEM|CHART)\b"),
]

# Soft disqualifiers — these sometimes appear as column headers on real boring logs,
# so they only disqualify pages that LACK strong test data signals.
_SOFT_DISQUALIFIERS = [
    re.compile(r"(?i)\bATTERBERG\s+LIMITS?\s+RESULTS?\b"),
    re.compile(r"(?i)\bGRAIN\s+SIZE\s+DISTRIBUTION\b"),
    re.compile(r"(?i)\bSIEVE\s+ANALYSIS\b"),
    re.compile(r"(?i)\bSWELL\s+CONSOLIDATION\s+TEST\b"),
    re.compile(r"(?i)\bEXPANSION\s+INDEX\s+(?:TEST|OF\s+SOILS)\b"),
    re.compile(r"(?i)\bTRIAXIAL\s+(?:TEST|COMPRESSION)\b"),
    re.compile(r"(?i)\bDIRECT\s+SHEAR\s+TEST\b"),
    re.compile(r"(?i)\b(?:SHAFT|PILE)\s+CAPACITY\b"),
    re.compile(r"(?i)\bAXIAL\s+LOAD\b"),
    re.compile(r"(?i)\bPRESSUREMETER\s+(?:DATA|PROCEDURES|RESULTS)\b"),
    re.compile(r"(?i)\bVANE\s+SHEAR\s+RESULTS\b"),
    re.compile(r"(?i)\bCONE\s+PENETRATION\s+TEST\b"),
    re.compile(r"(?i)\bCPT\s+DATA\b"),
    re.compile(r"(?i)\bLIQUID\s+LIMIT\b.*\bPLASTICITY\s+INDEX\b"),
    re.compile(r"(?i)\bPLASTICITY\s+(?:INDEX|CHART)\b"),
]

# Soil type keywords found in boring log descriptions
_SOIL_KEYWORDS = {
    "SAND", "CLAY", "SILT", "GRAVEL", "FILL", "TOPSOIL", "PEAT", "LOAM",
    "TILL", "ROCK", "SHALE", "SANDSTONE", "LIMESTONE", "MUDSTONE",
    "SILTSTONE", "BEDROCK", "COBBLES", "BOULDERS", "LEAN CLAY",
    "FAT CLAY", "SANDY", "CLAYEY", "SILTY",
}


@dataclass
class PageContent:
    """Extracted content from a single PDF page."""
    page_number: int
    text: str
    words: list[dict] = field(default_factory=list)
    lines: list[dict] = field(default_factory=list)
    tables: list[list[list[Optional[str]]]] = field(default_factory=list)
    width: float = 0.0
    height: float = 0.0
    is_boring_log: bool = False
    boring_id: Optional[str] = None
    classification_score: float = 0.0
    image_count: int = 0


@dataclass
class PDFContent:
    """Complete extracted content from a geotechnical report PDF."""
    file_path: str
    pages: list[PageContent] = field(default_factory=list)
    total_pages: int = 0
    detected_firm: Optional[str] = None

    @property
    def boring_log_pages(self) -> list[PageContent]:
        return [p for p in self.pages if p.is_boring_log]


def _text_is_garbled(text: str) -> bool:
    """Check if extracted text is mostly unprintable (encoded font issue)."""
    if not text or len(text) < 20:
        return False
    printable = sum(1 for c in text if c.isprintable() or c in "\n\t ")
    return printable / len(text) < 0.5


def _ocr_page(page: fitz.Page) -> tuple[str, list[dict]]:
    """OCR a page using Tesseract, returning (text, words).

    Renders the page to an image and runs Tesseract OCR to extract
    both plain text and word-level bounding boxes.
    """
    try:
        import pytesseract
        from PIL import Image
        import io
    except ImportError:
        return "", []

    # Render page at 200 DPI for good OCR quality
    pix = page.get_pixmap(dpi=200)
    img_bytes = pix.tobytes("png")
    img = Image.open(io.BytesIO(img_bytes))

    # Get plain text
    text = pytesseract.image_to_string(img)

    # Get word-level data with bounding boxes
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)

    # Scale factor: OCR coordinates are in image pixels at 200 DPI,
    # but page coordinates are in PDF points (72 DPI)
    scale = 72.0 / 200.0

    words = []
    for i in range(len(data["text"])):
        word_text = data["text"][i].strip()
        conf = data["conf"][i]
        if not word_text or conf < 30:  # skip low-confidence noise
            continue
        words.append({
            "text": word_text,
            "x0": data["left"][i] * scale,
            "top": data["top"][i] * scale,
            "x1": (data["left"][i] + data["width"][i]) * scale,
            "bottom": (data["top"][i] + data["height"][i]) * scale,
        })

    return text, words


def _extract_page(page: fitz.Page, page_number: int) -> PageContent:
    """Extract all content from a single PDF page using PyMuPDF.

    Falls back to OCR when the native text extraction returns garbled
    data (common with PDFs using custom font encodings).
    """
    text = page.get_text() or ""

    # Extract words with spatial positions: (x0, y0, x1, y1, text, block, line, word)
    raw_words = page.get_text("words") or []
    words = [
        {
            "text": w[4],
            "x0": w[0],
            "top": w[1],
            "x1": w[2],
            "bottom": w[3],
        }
        for w in raw_words
    ]

    # Fallback to OCR if text is garbled (custom font encoding)
    used_ocr = False
    if _text_is_garbled(text):
        ocr_text, ocr_words = _ocr_page(page)
        if ocr_text and len(ocr_text) > 20:
            text = ocr_text
            words = ocr_words
            used_ocr = True

    # Extract drawing objects (lines, rects) for structural analysis
    drawings = page.get_drawings()
    lines = []
    for d in drawings:
        for item in d.get("items", []):
            op = item[0]
            if op == "l":  # line
                p1, p2 = item[1], item[2]
                lines.append({
                    "x0": p1.x, "y0": p1.y,
                    "x1": p2.x, "y1": p2.y,
                })
            elif op == "re":  # rectangle
                rect = item[1]
                lines.append({
                    "x0": rect.x0, "y0": rect.y0,
                    "x1": rect.x1, "y1": rect.y1,
                })

    # Count embedded images (raster plan pages have large images)
    image_count = len(page.get_images(full=False))

    rect = page.rect
    pc = PageContent(
        page_number=page_number,
        text=text,
        words=words,
        lines=lines,
        width=float(rect.width),
        height=float(rect.height),
        image_count=image_count,
    )

    # Classify page
    pc.is_boring_log, pc.classification_score = _classify_boring_log_page(pc)
    if pc.is_boring_log:
        pc.boring_id = _extract_boring_id(text)

    return pc


def _count_blow_counts(text: str) -> int:
    """Count SPT blow count patterns, matching per-line only.

    Uses dash-separated and plus-separated three-part patterns (e.g.
    "5-8-12", "4+6+7") and N-value patterns (e.g. "N=15"). Slash-separated
    patterns like "2/13/15" are excluded because they are almost always
    dates in geotech reports. Cross-line matching is avoided to prevent
    chart axis values (e.g. "-10\\n-8\\n-6") from being counted.
    """
    count = 0
    for line in text.split("\n"):
        # N-value patterns: "N=15", "N: 20"
        count += len(re.findall(r"\bN\s*[=:]\s*\d+", line))

        # Three-part dash or plus separated blow counts: "5-8-12", "4+6+7"
        # Also matches four-part: "2+4+6+7" (seating + 3 increments)
        for m in re.finditer(
            r"\b(\d{1,2})\s*[-+]\s*(\d{1,2})\s*[-+]\s*(\d{1,3})"
            r"(?:\s*[-+]\s*\d{1,3})?\b", line
        ):
            # Skip if preceded by date context on same line
            before = line[: m.start()]
            if re.search(r"(?i)\bdate[ds]?\b", before):
                continue
            count += 1
    return count


def _classify_boring_log_page(page: PageContent) -> tuple[bool, float]:
    """Classify whether a page is a boring log using multiple signals.

    Uses a three-phase approach:
    1. Hard disqualifiers — instantly reject clearly non-boring-log pages
    2. Required data signals — boring logs MUST have sample/test data
    3. Confidence scoring — combine structural + content signals

    Returns:
        (is_boring_log, confidence_score)
    """
    text = page.text or ""
    text_upper = text.upper()

    # Very short or empty pages are never boring logs
    if len(text.strip()) < 30:
        return False, -5.0

    # --- PHASE 1: HARD DISQUALIFIERS ---

    # Note: drawing object counts are NOT used as a disqualifier.
    # Langan and other firms' gINT-generated boring logs routinely have
    # 10,000-80,000+ drawing objects from detailed graphical templates.

    for pattern in _HARD_DISQUALIFIERS:
        if pattern.search(text):
            return False, -3.0

    # Appendix divider pages
    if re.search(r"(?i)APPENDIX\s+[A-Z0-9]", text) and len(text.strip()) < 300:
        return False, -3.0

    # Soil classification reference charts list almost all USCS codes
    unique_uscs = len(set(re.findall(
        r"\b(GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)\b", text
    )))
    if unique_uscs >= 10:
        return False, -3.0

    # Pages with many distinct boring IDs are typically site plans or
    # boring location maps, not individual boring logs.
    boring_id_matches = set(re.findall(
        r"\b(?:B|BH|BN|TB|GB|GC|BOR|LB|HA|TP|DCP|LDCP|MDCP|WDCP"
        r"|CS|CPT|FP|MW|WB|SB|SS)-\d+[A-Za-z]?\b", text
    ))
    if len(boring_id_matches) > 5:
        return False, -3.0

    # Heavy narrative text
    text_lines = text.split("\n")
    long_lines = sum(1 for line in text_lines if len(line) > 80)
    if long_lines >= 8:
        return False, -2.0

    # --- PHASE 2: DATA SIGNAL DETECTION ---

    # Blow count patterns: "3-5-7", "N=15"
    # Matched per-line to avoid cross-line false positives from chart axis values.
    # Only dash-separated patterns count (slash-separated are almost always dates).
    blow_count_matches = _count_blow_counts(text)

    # Sample type markers
    sample_type_matches = len(re.findall(
        r"\bSS\b|\bST\b|\bAU\b|\bRC\b|\bNX\b|\bHQ\b|\bGRAB\b|\bSPT\b", text
    ))

    soil_hits = sum(1 for kw in _SOIL_KEYWORDS if kw in text_upper)

    # USCS classification codes (e.g. CL, SM, SP-SM)
    uscs_matches = len(re.findall(
        r"\b(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)"
        r"(?:\s*[-/]\s*(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT))?\b",
        text,
    ))

    has_continuation = bool(
        re.search(r"(?i)\(continued\)", text) and soil_hits >= 1
    )

    has_title = any(p.search(text) for p in _BORING_LOG_TITLE_PATTERNS)
    # Title near top of page (first 300 chars) is a much stronger signal
    # than a mid-text reference like "see the attached boring log".
    has_title_at_top = any(
        p.search(text[:300]) for p in _BORING_LOG_TITLE_PATTERNS
    )

    has_strong_data = blow_count_matches >= 2 or (
        blow_count_matches >= 1 and sample_type_matches >= 1
    )
    has_some_data = (
        blow_count_matches >= 1
        or sample_type_matches >= 2
        or has_continuation
        or (has_title_at_top and soil_hits >= 2)
        or (uscs_matches >= 3 and soil_hits >= 2)
    )

    # Soft disqualifiers only apply when page lacks strong data
    if not has_strong_data:
        for pattern in _SOFT_DISQUALIFIERS:
            if pattern.search(text):
                return False, -1.0

    if not has_some_data:
        return False, 0.0

    # --- PHASE 3: CONFIDENCE SCORING ---
    score = 0.0

    # Structural: drawing objects (column rules, depth ticks, borders)
    drawing_count = len(page.lines)
    if drawing_count >= 200:
        score += 2.0
    elif drawing_count >= 50:
        score += 1.0

    # Text layout: many short lines = tabular data
    if text_lines:
        avg_line_len = sum(len(line) for line in text_lines) / len(text_lines)
        short_lines = sum(1 for line in text_lines if 0 < len(line) <= 25)
        if avg_line_len < 25 and short_lines >= 15:
            score += 1.5

    # Boring log title
    if has_title:
        score += 2.0

    # Blow counts
    if blow_count_matches >= 3:
        score += 2.5
    elif blow_count_matches >= 1:
        score += 1.0

    # Sample types
    if sample_type_matches >= 3:
        score += 1.5
    elif sample_type_matches >= 1:
        score += 0.5

    # Soil descriptions
    if soil_hits >= 3:
        score += 1.5
    elif soil_hits >= 1:
        score += 0.5

    # USCS codes with soil context
    if uscs_matches >= 1 and soil_hits >= 1:
        score += 1.0

    # Depth column values
    depth_matches = len(re.findall(
        r"(?:^|\s)(\d{1,2}(?:\.[05])?)\s*$", text, re.MULTILINE
    ))
    if depth_matches >= 3:
        score += 1.0

    if has_continuation:
        score += 2.0

    if re.search(r"(?i)\brecov(?:ery)?\b", text) and blow_count_matches >= 1:
        score += 0.5

    if long_lines >= 4:
        score -= 1.5

    return score >= 3.0, score


def _is_boring_log_page(text: str) -> bool:
    """Simple text-based check for boring log title indicators."""
    for pattern in _BORING_LOG_TITLE_PATTERNS:
        if pattern.search(text):
            return True
    return False


def _extract_boring_id(text: str) -> Optional[str]:
    """Extract the boring ID from page text.

    Searches with contextual patterns first (e.g. "BORING LOG NO. BN-3"),
    falling back to standalone ID patterns. For the generic B- pattern,
    matches preceded by "Drill Rig" are skipped.
    """
    for pattern in BORING_ID_PATTERNS:
        for match in pattern.finditer(text):
            boring_id = match.group(1).strip()
            # Skip generic B- matches that are drill rig IDs
            before = text[max(0, match.start() - 30): match.start()]
            if re.search(r"(?i)drill\s+rig", before):
                continue
            # Skip false positives from location/plan page text
            if boring_id.upper() in {"LOCATION", "LOCATIONS", "PLAN", "MAP"}:
                continue
            return boring_id
    return None


def _detect_firm(text: str) -> Optional[str]:
    """Detect the geotechnical firm from report text."""
    text_lower = text.lower()
    if "schnabel" in text_lower:
        return "schnabel"
    if "langan" in text_lower:
        return "langan"
    if "terracon" in text_lower:
        return "terracon"
    if "geoengineers" in text_lower:
        return "geoengineers"
    return None


def read_pdf(file_path: str | Path) -> PDFContent:
    """Read a geotechnical report PDF and extract all content.

    Uses PyMuPDF for text extraction (better font handling than pdfplumber)
    and spatial layout data (word positions, drawing objects).

    Requires the 'pdf' optional dependency: pip install geotech-report-extraction[pdf]

    Args:
        file_path: Path to the PDF file.

    Returns:
        PDFContent with all pages extracted and classified.
    """
    if fitz is None:
        raise ImportError(
            "PyMuPDF (fitz) is required for PDF reading. "
            "Install with: pip install geotech-report-extraction[pdf]"
        )
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"PDF not found: {file_path}")
    if not file_path.suffix.lower() == ".pdf":
        raise ValueError(f"Expected a PDF file, got: {file_path.suffix}")

    content = PDFContent(file_path=str(file_path))

    doc = fitz.open(file_path)
    try:
        content.total_pages = len(doc)

        # Check first few pages for firm detection
        for page in doc[:5]:
            page_text = page.get_text() or ""
            firm = _detect_firm(page_text)
            if firm:
                content.detected_firm = firm
                break

        # Extract all pages
        for i, page in enumerate(doc):
            page_content = _extract_page(page, page_number=i + 1)
            content.pages.append(page_content)

            if content.detected_firm is None and page_content.is_boring_log:
                firm = _detect_firm(page_content.text)
                if firm:
                    content.detected_firm = firm
    finally:
        doc.close()

    return content


def group_boring_log_pages(pdf_content: PDFContent) -> dict[str, list[PageContent]]:
    """Group boring log pages by boring ID.

    Multi-page boring logs (common for deep borings) are grouped together.
    Consecutive boring log pages without an explicit ID inherit the most
    recent boring ID.

    Returns:
        Dict mapping boring_id -> list of pages for that boring.
    """
    groups: dict[str, list[PageContent]] = {}
    current_id: Optional[str] = None
    last_page_num: int = 0

    for page in pdf_content.boring_log_pages:
        if page.boring_id:
            current_id = page.boring_id
        elif current_id is None:
            current_id = f"UNKNOWN-p{page.page_number}"
        elif page.page_number - last_page_num > 3:
            # Large gap in page numbers without a new boring ID likely
            # means we've moved to a different section (e.g., OCR pages
            # from a different appendix). Reset to avoid polluting the
            # previous boring's data.
            current_id = f"UNKNOWN-p{page.page_number}"

        if current_id not in groups:
            groups[current_id] = []
        groups[current_id].append(page)
        last_page_num = page.page_number

    return groups
