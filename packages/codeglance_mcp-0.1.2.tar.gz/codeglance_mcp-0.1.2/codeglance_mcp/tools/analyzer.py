"""Repository analysis tools following MCP best practices."""

import asyncio
from pathlib import Path
from typing import Dict, Tuple
import logging

from codeglance_mcp.utils.async_helpers import (
    clone_repository_async,
    get_directory_structure_async,
    read_file_async,
    write_file_async,
)
from codeglance_mcp.utils.file_discovery import discover_repository_files
from codeglance_mcp.utils.gemini_client import gemini_client
from codeglance_mcp.utils.cache import cache
from codeglance_mcp.config import config

logger = logging.getLogger(__name__)


class RepositoryAnalyzer:
    """Repository analyzer with intelligent file discovery."""

    async def clone_repository(self, repo_url: str, working_directory: str = ".") -> tuple[bool, str, str]:
        """Clone repository and return success, message, and local path."""
        try:
            repo_name = repo_url.removesuffix('.git').rstrip('/').split('/')[-1]
            local_path = Path(working_directory) / repo_name

            success, message = await clone_repository_async(repo_url, local_path)
            return success, message, str(local_path)

        except Exception as e:
            logger.error(f"Error in clone_repository: {e}")
            return False, str(e), ""

    async def discover_and_read_files(self, repo_path: Path) -> Tuple[Dict[str, str], Dict]:
        """Discover and read repository files using intelligent crawling.

        Returns:
            (file_contents, metadata) with repo stats and selected file info.
        """
        return await discover_repository_files(
            repo_path,
            char_budget=config.max_total_chars,
            scan_limit=config.import_scan_limit,
        )

    async def load_prompt_template(self, template_name: str) -> str:
        """Load prompt template asynchronously with caching."""
        cache_key = f"prompt_template:{template_name}"

        async def load_template():
            prompt_file = config.prompts_dir / f"{template_name}.md"
            content = await read_file_async(prompt_file, max_size=50000)
            return content or f"Prompt template '{template_name}.md' not found."

        return await cache.get_or_set(cache_key, load_template)

    async def create_analysis_prompt(self, template_name: str, repo_path: Path) -> str:
        """Create analysis prompt with full repository context."""
        try:
            # Load template, directory structure, and discovered files concurrently
            template_task = self.load_prompt_template(template_name)
            structure_task = get_directory_structure_async(repo_path)
            discovery_task = self.discover_and_read_files(repo_path)

            template, structure, (file_contents, metadata) = await asyncio.gather(
                template_task, structure_task, discovery_task
            )

            # Replace placeholder
            prompt = template.replace("[REPOSITORY_PATH]", str(repo_path))

            # Add repository metadata
            languages = metadata.get("languages", {})
            lang_str = ", ".join(f"{lang} ({count} files)" for lang, count in languages.items())

            prompt += f"\n\n## Repository Metadata\n"
            prompt += f"- **Size:** {metadata.get('repo_size', 'unknown')} ({metadata.get('total_files', 0)} total files)\n"
            prompt += f"- **Files analyzed:** {metadata.get('files_analyzed', 0)}\n"
            prompt += f"- **Languages:** {lang_str or 'unknown'}\n"

            # Add directory structure
            prompt += f"\n\n## Repository Structure:\n```\n{structure}\n```\n"

            # Add file contents with paths and categories
            prompt += f"\n\n## Source Files ({len(file_contents)} files analyzed):\n"

            for filepath, content in file_contents.items():
                # Find category for this file
                cat = "source"
                for sel in metadata.get("selected_files", []):
                    if sel["path"] == filepath:
                        cat = sel["category"]
                        break
                prompt += f"\n### {filepath} [{cat}]:\n```\n{content}\n```\n"

            return prompt

        except Exception as e:
            logger.error(f"Error creating analysis prompt: {e}")
            return f"Error creating prompt: {str(e)}"

    async def generate_analysis(self, template_name: str, repo_path: Path, output_file: Path) -> tuple[bool, str]:
        """Generate analysis using Gemini and save to file."""
        max_retries = 2
        retry_delay = 5

        for attempt in range(max_retries + 1):
            try:
                cache_key = cache.cache_key("analysis", template_name, str(repo_path))

                async def generate():
                    prompt = await self.create_analysis_prompt(template_name, repo_path)
                    success, result = await gemini_client.generate_content_async(prompt)
                    return success, result

                success, content = await cache.get_or_set(cache_key, generate)

                if success:
                    write_success = await write_file_async(output_file, content)
                    if write_success:
                        return True, f"Analysis saved to {output_file}"
                    else:
                        return False, f"Failed to write analysis to {output_file}"
                else:
                    if attempt < max_retries:
                        logger.warning(f"Analysis attempt {attempt + 1} failed for {template_name}: {content}. Retrying...")
                        await asyncio.sleep(retry_delay)
                        continue
                    return False, content

            except Exception as e:
                if attempt < max_retries:
                    logger.warning(f"Analysis attempt {attempt + 1} failed for {template_name}: {e}. Retrying...")
                    await asyncio.sleep(retry_delay)
                    continue
                logger.error(f"Error generating analysis after {max_retries + 1} attempts: {e}")
                return False, str(e)


# Global analyzer instance
analyzer = RepositoryAnalyzer()
