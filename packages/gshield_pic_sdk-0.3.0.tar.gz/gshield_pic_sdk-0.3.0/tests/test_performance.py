# -*- coding: utf-8 -*-
"""性能测试：验证 client 复用、并发执行、预处理共享的优化效果。"""
import os
import time
from gshield_pic_sdk import GshieldPicClient

# 测试配置
TRITON_URL = os.environ.get("GSHIELD_TRITON_URL", "100.100.30.185:8501")
TEST_IMAGE = os.environ.get("TEST_IMAGE", "/work/jawy/models/dataset/cartoon/test/images/1_mp4-0688_jpg.rf.26936fc880afbd0a804f0ec8db6ad5d7.jpg")

if not os.path.exists(TEST_IMAGE):
    print(f"⚠️  测试图片不存在: {TEST_IMAGE}")
    print("请设置环境变量 TEST_IMAGE 指向有效的图片路径")
    exit(1)


def test_infer_client_reuse():
    """测试 infer() 方法的 client 复用：多次调用应该复用同一个 client"""
    print("\n" + "=" * 60)
    print("测试 1: infer() 方法的 client 复用")
    print("=" * 60)
    
    client = GshieldPicClient(triton_url=TRITON_URL)
    
    # 第一次调用（创建 client）
    start = time.time()
    result1 = client.grpc.infer("fire", TEST_IMAGE)
    time1 = time.time() - start
    print(f"第一次调用（创建 client）: {time1:.3f}s, 结果: {result1}")
    
    # 后续调用（复用 client）
    times = []
    for i in range(5):
        start = time.time()
        result = client.grpc.infer("fire", TEST_IMAGE)
        elapsed = time.time() - start
        times.append(elapsed)
        print(f"第 {i+2} 次调用（复用 client）: {elapsed:.3f}s, 结果: {result}")
    
    avg_time = sum(times) / len(times)
    print(f"\n✅ 平均耗时（复用 client）: {avg_time:.3f}s")
    print(f"   首次调用耗时: {time1:.3f}s")
    if time1 > avg_time * 1.5:
        print(f"   ✅ 性能提升明显：首次调用包含 client 创建开销")
    else:
        print(f"   ⚠️  性能提升不明显，可能需要检查 client 复用逻辑")


def test_infer_all_concurrency():
    """测试 infer_all() 方法的并发执行和预处理共享"""
    print("\n" + "=" * 60)
    print("测试 2: infer_all() 方法的并发执行和预处理共享")
    print("=" * 60)
    
    client = GshieldPicClient(triton_url=TRITON_URL)
    
    # 测试 infer_all() 性能
    print("执行 infer_all()（并发执行，共享预处理）...")
    start = time.time()
    results = client.grpc.infer_all(TEST_IMAGE)
    elapsed = time.time() - start
    
    print(f"\n✅ infer_all() 总耗时: {elapsed:.3f}s")
    print(f"   处理了 {len(results)} 个 mode")
    print(f"   平均每个 mode: {elapsed/len(results):.3f}s")
    
    # 显示部分结果
    print("\n部分结果示例:")
    for i, (mode, label) in enumerate(list(results.items())[:5]):
        print(f"  {mode}: {label}")
    if len(results) > 5:
        print(f"  ... 还有 {len(results) - 5} 个 mode")
    
    # 对比：串行执行（模拟旧版本）
    print("\n对比：模拟串行执行（旧版本行为）...")
    modes_all = client.grpc._config.get("modes_all", [])
    serial_start = time.time()
    serial_results = {}
    for mode in modes_all[:5]:  # 只测试前5个，避免耗时过长
        try:
            label = client.grpc.infer(mode, TEST_IMAGE)
            serial_results[mode] = label
        except Exception as e:
            serial_results[mode] = "normal"
    serial_elapsed = time.time() - serial_start
    
    print(f"串行执行 5 个 mode 耗时: {serial_elapsed:.3f}s")
    print(f"并发执行 {len(results)} 个 mode 耗时: {elapsed:.3f}s")
    
    if len(results) > 5:
        estimated_serial = serial_elapsed * (len(results) / 5)
        speedup = estimated_serial / elapsed
        print(f"\n估算串行执行 {len(results)} 个 mode: {estimated_serial:.3f}s")
        print(f"✅ 并发加速比: {speedup:.2f}x")


def test_preprocessing_shared():
    """测试预处理是否只执行一次"""
    print("\n" + "=" * 60)
    print("测试 3: 验证预处理只执行一次（通过时间对比）")
    print("=" * 60)
    
    client = GshieldPicClient(triton_url=TRITON_URL)
    
    # 单次 infer 的耗时（包含预处理）
    start = time.time()
    client.grpc.infer("fire", TEST_IMAGE)
    single_infer_time = time.time() - start
    
    # infer_all 的耗时（应该只预处理一次）
    start = time.time()
    results = client.grpc.infer_all(TEST_IMAGE)
    infer_all_time = time.time() - start
    
    modes_count = len(results)
    estimated_serial_time = single_infer_time * modes_count
    
    print(f"单次 infer() 耗时（包含预处理）: {single_infer_time:.3f}s")
    print(f"infer_all() 耗时（{modes_count} 个 mode）: {infer_all_time:.3f}s")
    print(f"估算串行执行耗时: {estimated_serial_time:.3f}s")
    
    if infer_all_time < estimated_serial_time * 0.7:
        print(f"✅ 预处理共享生效：实际耗时远小于串行估算")
        print(f"   性能提升: {(1 - infer_all_time/estimated_serial_time)*100:.1f}%")
    else:
        print(f"⚠️  预处理可能未共享，或并发效果不明显")


if __name__ == "__main__":
    print("=" * 60)
    print("GshieldPicSDK 性能测试")
    print("=" * 60)
    print(f"Triton URL: {TRITON_URL}")
    print(f"测试图片: {TEST_IMAGE}")
    
    try:
        test_infer_client_reuse()
        test_infer_all_concurrency()
        test_preprocessing_shared()
        
        print("\n" + "=" * 60)
        print("✅ 所有测试完成")
        print("=" * 60)
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
