# -*- coding: utf-8 -*-
"""Triton gRPC 推理客户端，封装 infer(mode, image) / infer_all(image)。"""
import concurrent.futures
import os
import tempfile
from typing import Dict, Optional, Union

import numpy as np
import tritonclient.grpc as grpcclient

from gshield_pic_sdk._image import to_rgb_ndarray
from gshield_pic_sdk.exceptions import GshieldConnectionError, GshieldInferError, GshieldValueError
from gshield_pic_sdk.grpc_config import get_grpc_config, MODES_ALL
from gshield_pic_sdk.grpc.inference import (
    preprocess_image_raw,
    preprocess_numpy,
    run_task_with_client,
)

ImageInput = Union[str, bytes, np.ndarray]


def _default_label_dir() -> str:
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    labels = os.path.join(pkg_dir, "labels")
    return labels if os.path.isdir(labels) else ""


class GrpcInferClient:
    """Triton gRPC 推理：按 mode 调用，支持 path/bytes/ndarray。"""

    def __init__(
        self,
        triton_url: str,
        label_dir: Optional[str] = None,
        grpc_config: Optional[Dict] = None,
        timeout: int = 30,
    ):
        self.triton_url = triton_url
        self.label_dir = label_dir or _default_label_dir()
        if not self.label_dir or not os.path.isdir(self.label_dir):
            raise GshieldValueError(
                "label_dir must be provided and point to a directory with label .txt files"
            )
        self._config = grpc_config or get_grpc_config()
        self.timeout = timeout
        # 复用 client，避免每次 infer 都创建新连接
        self._client = None

    def _ensure_path(self, image: ImageInput) -> str:
        """将 image 转为本地路径，供内部 inference 使用。"""
        if isinstance(image, str) and os.path.isfile(image):
            return image
        rgb = to_rgb_ndarray(image)
        # 写入临时文件（inference 里 preprocess_image_raw 和 infer_flag 需要路径读图）
        fd, path = tempfile.mkstemp(suffix=".jpg")
        try:
            import cv2
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            ok, buf = cv2.imencode(".jpg", bgr)
            if not ok:
                raise GshieldValueError("failed to encode image")
            os.write(fd, buf.tobytes())
        finally:
            os.close(fd)
        return path

    def _get_client(self):
        """获取或创建复用的 Triton client。"""
        if self._client is None:
            try:
                self._client = grpcclient.InferenceServerClient(url=self.triton_url)
                if not self._client.is_server_live():
                    raise GshieldConnectionError(f"Triton server not live: {self.triton_url}")
            except Exception as e:
                raise GshieldConnectionError(f"Triton connection failed: {e}") from e
        return self._client

    def infer(self, mode: str, image: ImageInput) -> str:
        """
        单模型推理。
        :param mode: 模型名（与 grpc_config 一致，如 fire, politics, porn, flag）
        :param image: 路径、bytes 或 ndarray
        :return: summary_label 字符串
        """
        modes_list = self._config.get("modes_list", [])
        if mode != "all" and mode not in modes_list:
            raise GshieldValueError(f"unknown mode: {mode}, supported: {modes_list}")
        path = self._ensure_path(image)
        try:
            raw = preprocess_image_raw(path)
            input_224 = preprocess_numpy(raw, target_size=(224, 224))
            input_640 = preprocess_numpy(raw, target_size=(640, 640))
        except Exception as e:
            raise GshieldInferError(f"preprocess failed: {e}") from e
        created_temp = not (isinstance(image, str) and os.path.isfile(image))
        temp_path = path if created_temp else None
        client = self._get_client()
        try:
            summary_label, _ = run_task_with_client(
                client,
                mode,
                path,
                input_224,
                input_640,
                self.label_dir,
                self._config["label_map"],
                self._config["data_types"],
            )
            return summary_label
        except Exception as e:
            raise GshieldInferError(f"infer failed: {e}") from e
        finally:
            if temp_path and os.path.isfile(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    def infer_all(self, image: ImageInput) -> Dict[str, str]:
        """
        对 MODES_ALL 中每个 mode 并发调用 infer，返回 {mode: label}。
        预处理只做一次，然后并发执行所有模型推理。
        注意：由于 tritonclient.grpc.InferenceServerClient 不是线程安全的，
        每个并发任务会创建独立的 client（client 对象是轻量级的，内部会复用 channels）。
        """
        modes_all = self._config.get("modes_all", MODES_ALL)
        
        # 全局预处理（只做一次）
        path = self._ensure_path(image)
        created_temp = not (isinstance(image, str) and os.path.isfile(image))
        temp_path = path if created_temp else None
        
        try:
            raw = preprocess_image_raw(path)
            input_224 = preprocess_numpy(raw, target_size=(224, 224))
            input_640 = preprocess_numpy(raw, target_size=(640, 640))
        except Exception as e:
            if temp_path and os.path.isfile(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass
            raise GshieldInferError(f"preprocess failed: {e}") from e
        
        # 并发执行所有 mode
        # 注意：每个任务创建独立的 client 以保证线程安全（client 对象轻量级，内部复用 channels）
        def _run_task_with_new_client(mode):
            """为每个任务创建独立的 client 以保证线程安全"""
            try:
                client = grpcclient.InferenceServerClient(url=self.triton_url)
                if not client.is_server_live():
                    raise GshieldConnectionError(f"Triton server not live: {self.triton_url}")
                summary_label, _ = run_task_with_client(
                    client,
                    mode,
                    path,
                    input_224,
                    input_640,
                    self.label_dir,
                    self._config["label_map"],
                    self._config["data_types"],
                )
                return mode, summary_label
            except Exception as e:
                return mode, "normal"
        
        result = {}
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(modes_all)) as executor:
                future_to_mode = {
                    executor.submit(_run_task_with_new_client, mode): mode
                    for mode in modes_all
                }
                for future in concurrent.futures.as_completed(future_to_mode):
                    mode = future_to_mode[future]
                    try:
                        _, summary_label = future.result()
                        result[mode] = summary_label
                    except Exception as e:
                        result[mode] = "normal"
        finally:
            # 清理临时文件
            if temp_path and os.path.isfile(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass
        
        return result
