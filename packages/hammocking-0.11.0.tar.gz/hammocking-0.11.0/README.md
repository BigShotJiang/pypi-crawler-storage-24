# Hammocking

<p align="center">
  <a href="https://github.com/avengineers/hammocking/actions/workflows/ci.yml?query=branch%3Adevelop">
    <img src="https://img.shields.io/github/actions/workflow/status/avengineers/hammocking/ci.yml?branch=develop&label=CI&logo=github&style=flat-square" alt="CI Status" >
  </a>
  <a href="https://spl-core.readthedocs.io">
    <img src="https://img.shields.io/readthedocs/spl-core.svg?logo=read-the-docs&logoColor=fff&style=flat-square" alt="Documentation Status">
  </a>
  <a href="https://codecov.io/gh/avengineers/hammocking">
    <img src="https://img.shields.io/codecov/c/github/avengineers/hammocking.svg?logo=codecov&logoColor=fff&style=flat-square" alt="Test coverage percentage">
  </a>
</p>
<p align="center">
  <a href="https://python-poetry.org/">
    <img src="https://img.shields.io/badge/packaging-poetry-299bd7?style=flat-square&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAASCAYAAABrXO8xAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJJSURBVHgBfZLPa1NBEMe/s7tNXoxW1KJQKaUHkXhQvHgW6UHQQ09CBS/6V3hKc/AP8CqCrUcpmop3Cx48eDB4yEECjVQrlZb80CRN8t6OM/teagVxYZi38+Yz853dJbzoMV3MM8cJUcLMSUKIE8AzQ2PieZzFxEJOHMOgMQQ+dUgSAckNXhapU/NMhDSWLs1B24A8sO1xrN4NECkcAC9ASkiIJc6k5TRiUDPhnyMMdhKc+Zx19l6SgyeW76BEONY9exVQMzKExGKwwPsCzza7KGSSWRWEQhyEaDXp6ZHEr416ygbiKYOd7TEWvvcQIeusHYMJGhTwF9y7sGnSwaWyFAiyoxzqW0PM/RjghPxF2pWReAowTEXnDh0xgcLs8l2YQmOrj3N7ByiqEoH0cARs4u78WgAVkoEDIDoOi3AkcLOHU60RIg5wC4ZuTC7FaHKQm8Hq1fQuSOBvX/sodmNJSB5geaF5CPIkUeecdMxieoRO5jz9bheL6/tXjrwCyX/UYBUcjCaWHljx1xiX6z9xEjkYAzbGVnB8pvLmyXm9ep+W8CmsSHQQY77Zx1zboxAV0w7ybMhQmfqdmmw3nEp1I0Z+FGO6M8LZdoyZnuzzBdjISicKRnpxzI9fPb+0oYXsNdyi+d3h9bm9MWYHFtPeIZfLwzmFDKy1ai3p+PDls1Llz4yyFpferxjnyjJDSEy9CaCx5m2cJPerq6Xm34eTrZt3PqxYO1XOwDYZrFlH1fWnpU38Y9HRze3lj0vOujZcXKuuXm3jP+s3KbZVra7y2EAAAAAASUVORK5CYII=" alt="Poetry">
  </a>
  <a href="https://github.com/astral-sh/ruff">
    <img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json" alt="ruff">
  </a>
  <a href="https://github.com/pre-commit/pre-commit">
    <img src="https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=flat-square" alt="pre-commit">
  </a>
</p>
<p align="center">
  <a href="https://pypi.org/project/spl-core/">
    <img src="https://img.shields.io/pypi/v/spl-core.svg?logo=python&logoColor=fff&style=flat-square" alt="PyPI Version">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/spl-core.svg?style=flat-square&logo=python&amp;logoColor=fff" alt="Supported Python versions">
  <img src="https://img.shields.io/pypi/l/spl-core.svg?style=flat-square" alt="License">
</p>

Automatic mocking tool for C

## Installation and Building

### On Windows

#### Install Dependencies
```powershell
.\build.ps1 -install
```

#### Build
```powershell
.\build.ps1
```

### On Linux/macOS

#### Quick Start
```bash

# Using build script
./build.sh          # Normal build
./build.sh --clean  # Clean build
./build.sh --install # Install only
```

#### Prerequisites
- Python 3.10+ (Python 3.13 recommended)
- Poetry (will be auto-installed)
- For running integration tests: clang/llvm, cmake, ninja-build

#### What the Build Does
-   Pre-Commit checks and linting
-   Execution of all tests
-   Building documentation

### Using DevPod (Containerized Development)

You can use [DevPod](https://devpod.sh/) to spin up a fully configured development container.

#### Prerequisites
- [Podman](https://podman.io/) or [Docker](https://www.docker.com/) installed

#### Setup
```bash
# Install DevPod CLI
curl -L -o devpod "https://github.com/loft-sh/devpod/releases/latest/download/devpod-linux-amd64" \
    && sudo install -c -m 0755 devpod /usr/local/bin \
    && rm -f devpod

# Add and select the Docker provider (use Podman or Docker)
devpod provider add docker --option DOCKER_PATH=$(which podman)
devpod provider use docker

# Start the development container
devpod up .
```

The container comes pre-configured with Python 3.13, Poetry, clang/llvm, cmake, and ninja-build.
