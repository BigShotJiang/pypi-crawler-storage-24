import subprocess
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory


REPO_ROOT = Path(__file__).resolve().parents[1]


class JZipCLITests(unittest.TestCase):
    def _run_cli(self, *args, input_text=None):
        return subprocess.run(
            [sys.executable, "-m", "jzip", *args],
            cwd=REPO_ROOT,
            input=input_text,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_encode_then_decode_from_argument(self):
        content = b"\x00\xffhello-cli-bytes"
        with TemporaryDirectory() as temp_dir:
            source_file = Path(temp_dir) / "source.bin"
            restored_file = Path(temp_dir) / "restored.bin"
            source_file.write_bytes(content)

            encode_result = self._run_cli("encode", str(source_file))
            self.assertEqual(encode_result.returncode, 0, encode_result.stderr)

            gzip_b64 = encode_result.stdout.strip()
            decode_result = self._run_cli("decode", str(restored_file), "--input", gzip_b64)
            self.assertEqual(decode_result.returncode, 0, decode_result.stderr)
            self.assertEqual(restored_file.read_bytes(), content)

    def test_encode_to_file_then_decode_from_stdin(self):
        content = b"stdin decode flow"
        with TemporaryDirectory() as temp_dir:
            source_file = Path(temp_dir) / "source.txt"
            encoded_file = Path(temp_dir) / "encoded.txt"
            restored_file = Path(temp_dir) / "restored.txt"
            source_file.write_bytes(content)

            encode_result = self._run_cli(
                "encode",
                str(source_file),
                "--output",
                str(encoded_file),
            )
            self.assertEqual(encode_result.returncode, 0, encode_result.stderr)
            self.assertTrue(encoded_file.exists())

            decode_result = self._run_cli(
                "decode",
                str(restored_file),
                input_text=encoded_file.read_text(encoding="ascii"),
            )
            self.assertEqual(decode_result.returncode, 0, decode_result.stderr)
            self.assertEqual(restored_file.read_bytes(), content)

    def test_decode_empty_input_fails(self):
        with TemporaryDirectory() as temp_dir:
            restored_file = Path(temp_dir) / "restored.txt"
            decode_result = self._run_cli("decode", str(restored_file), input_text="")
            self.assertNotEqual(decode_result.returncode, 0)
            self.assertIn("empty", decode_result.stderr.lower())

    def test_decode_from_input_file(self):
        content = b"input-file decode"
        with TemporaryDirectory() as temp_dir:
            source_file = Path(temp_dir) / "source.bin"
            encoded_file = Path(temp_dir) / "encoded.b64"
            restored_file = Path(temp_dir) / "restored.bin"
            source_file.write_bytes(content)

            encode_result = self._run_cli(
                "encode",
                str(source_file),
                "--output",
                str(encoded_file),
            )
            self.assertEqual(encode_result.returncode, 0, encode_result.stderr)

            decode_result = self._run_cli(
                "decode",
                str(restored_file),
                "--input-file",
                str(encoded_file),
            )
            self.assertEqual(decode_result.returncode, 0, decode_result.stderr)
            self.assertEqual(restored_file.read_bytes(), content)


if __name__ == "__main__":
    unittest.main()
