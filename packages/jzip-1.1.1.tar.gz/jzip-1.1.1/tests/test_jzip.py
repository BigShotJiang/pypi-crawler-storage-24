import base64
import gzip
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from jzip import (
    InvalidBase64Error,
    InvalidGzipContentError,
    compress_file_to_base64,
    decode_gzip_base64_to_bytes,
    decode_gzip_base64_to_plain_base64,
    decode_gzip_base64_to_text,
    write_to_original_file,
)


class JZipTests(unittest.TestCase):
    def test_text_file_round_trip(self):
        content = "hello jzip\nunicode: नमस्ते"
        with TemporaryDirectory() as temp_dir:
            original_file = Path(temp_dir) / "sample.txt"
            output_file = Path(temp_dir) / "restored.txt"
            original_file.write_text(content, encoding="utf-8")

            gzip_b64 = compress_file_to_base64(original_file)
            write_to_original_file(gzip_b64, output_file)

            self.assertEqual(output_file.read_text(encoding="utf-8"), content)

    def test_binary_file_round_trip(self):
        content = bytes([0, 159, 255, 13, 10, 0, 88, 42, 1, 2, 3])
        with TemporaryDirectory() as temp_dir:
            original_file = Path(temp_dir) / "sample.bin"
            output_file = Path(temp_dir) / "restored.bin"
            original_file.write_bytes(content)

            gzip_b64 = compress_file_to_base64(original_file)
            write_to_original_file(gzip_b64, output_file)

            self.assertEqual(output_file.read_bytes(), content)

    def test_decode_gzip_base64_to_plain_base64(self):
        content = b"plain bytes payload"
        gzip_b64 = base64.b64encode(gzip.compress(content)).decode("ascii")
        plain_b64 = decode_gzip_base64_to_plain_base64(gzip_b64)
        self.assertEqual(base64.b64decode(plain_b64), content)

    def test_decode_gzip_base64_to_text(self):
        content = "The quick brown fox jumps over the lazy dog"
        gzip_b64 = base64.b64encode(gzip.compress(content.encode("utf-8"))).decode("ascii")
        self.assertEqual(decode_gzip_base64_to_text(gzip_b64), content)

    def test_invalid_base64_raises(self):
        with self.assertRaises(InvalidBase64Error):
            decode_gzip_base64_to_bytes("%%%%not-base64%%%%")

    def test_invalid_gzip_raises(self):
        not_gzip_b64 = base64.b64encode(b"not-gzip").decode("ascii")
        with self.assertRaises(InvalidGzipContentError):
            decode_gzip_base64_to_bytes(not_gzip_b64)


if __name__ == "__main__":
    unittest.main()
