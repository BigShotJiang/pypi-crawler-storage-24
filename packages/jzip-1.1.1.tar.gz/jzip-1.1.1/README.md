# JZip

[![CI](https://github.com/iammrj/JZip/actions/workflows/ci.yml/badge.svg)](https://github.com/iammrj/JZip/actions/workflows/ci.yml)
[![Publish to PyPI](https://github.com/iammrj/JZip/actions/workflows/publish.yml/badge.svg)](https://github.com/iammrj/JZip/actions/workflows/publish.yml)
[![PyPI version](https://img.shields.io/pypi/v/jzip.svg)](https://pypi.org/project/jzip/)

Utilities to work with gzip-compressed base64 content.

## Features

- Decode `gzip(base64)` to raw bytes
- Decode `gzip(base64)` to plain text
- Convert `gzip(base64)` to plain base64
- Compress any file (text or binary) into `gzip(base64)`
- Restore original files from `gzip(base64)` safely
- CLI support: `jzip encode` and `jzip decode`
- Strict validation with clear errors for invalid base64/gzip input

## Installation

```bash
pip install jzip
```

## Usage

### Compress file to gzip base64

```python
from jzip import compress_file_to_base64

gzip_b64 = compress_file_to_base64("sample.pdf")
print(gzip_b64)
```

### Restore original file from gzip base64

```python
from jzip import write_to_original_file

write_to_original_file(gzip_b64, "sample.pdf")
```

### Decode gzip base64 to bytes/text/plain base64

```python
from jzip import (
    decode_gzip_base64_to_bytes,
    decode_gzip_base64_to_text,
    decode_gzip_base64_to_plain_base64,
)

raw_bytes = decode_gzip_base64_to_bytes(gzip_b64)
text = decode_gzip_base64_to_text(gzip_b64, encoding="utf-8")
plain_b64 = decode_gzip_base64_to_plain_base64(gzip_b64)
```

## CLI

### Encode a file

```bash
jzip encode ./sample.pdf > sample.gzip.b64
```

### Decode from an argument

```bash
jzip decode ./restored.pdf --input "$(cat sample.gzip.b64)"
```

### Decode from stdin

```bash
cat sample.gzip.b64 | jzip decode ./restored.pdf
```

### Decode from a file containing base64

```bash
jzip decode ./restored.pdf --input-file ./sample.gzip.b64
```

## Automated Release

Pushes of version tags trigger:

- tests
- package build
- publish to PyPI (`skip-existing` enabled)

Configure GitHub secret `PYPI_API_TOKEN` in repository settings for publishing.

Release flow:

1. Bump version in `pyproject.toml` and `jzip/__init__.py`.
2. Commit and push to `main`.
3. Create and push tag `vX.Y.Z` (must match `pyproject.toml` version).
