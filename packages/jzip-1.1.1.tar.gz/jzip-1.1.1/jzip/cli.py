import argparse
import sys
from pathlib import Path
from typing import Optional

from . import JZipError, compress_file_to_base64, write_to_original_file


def _normalize_base64(content: str) -> str:
    # Allow multiline/whitespace-separated base64 inputs.
    return "".join(content.split())


def _resolve_decode_input(input_value: Optional[str], input_file: Optional[str]) -> str:
    if input_value is not None:
        return _normalize_base64(input_value)

    if input_file is not None:
        file_content = Path(input_file).read_text(encoding="ascii")
        return _normalize_base64(file_content)

    if sys.stdin.isatty():
        raise ValueError("Provide --input, --input-file, or pipe gzip base64 content via stdin.")

    return _normalize_base64(sys.stdin.read())


def _write_output_text(content: str, output_file: Optional[str]) -> None:
    if output_file:
        Path(output_file).write_text(content, encoding="ascii")
        return

    sys.stdout.write(content)
    if not content.endswith("\n"):
        sys.stdout.write("\n")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jzip", description="Encode/decode gzip base64 files.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    encode_parser = subparsers.add_parser("encode", help="Compress a file to gzip(base64).")
    encode_parser.add_argument("source_file", help="Path to the source file.")
    encode_parser.add_argument(
        "-o",
        "--output",
        dest="output_file",
        help="Optional path to write gzip(base64) output. Defaults to stdout.",
    )

    decode_parser = subparsers.add_parser("decode", help="Restore original file from gzip(base64).")
    decode_parser.add_argument("target_file", help="Path to write restored file bytes.")
    decode_parser.add_argument(
        "--input",
        dest="input_value",
        help="gzip(base64) content as a direct argument.",
    )
    decode_parser.add_argument(
        "--input-file",
        dest="input_file",
        help="Path to a text file containing gzip(base64) content.",
    )

    return parser


def main(argv=None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "encode":
            encoded = compress_file_to_base64(args.source_file)
            _write_output_text(encoded, args.output_file)
            return 0

        decoded_input = _resolve_decode_input(args.input_value, args.input_file)
        if not decoded_input:
            raise ValueError("Input gzip base64 content is empty.")
        write_to_original_file(decoded_input, args.target_file)
        return 0
    except (JZipError, FileNotFoundError, OSError, TypeError, ValueError, UnicodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
