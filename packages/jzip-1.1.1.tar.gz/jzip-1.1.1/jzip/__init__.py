import base64
import binascii
import gzip
from pathlib import Path
from typing import Union

default_encoding = "UTF-8"
__version__ = "1.1.1"

__all__ = [
    "__version__",
    "JZipError",
    "InvalidBase64Error",
    "InvalidGzipContentError",
    "decode_gzip_base64_to_plain_base64",
    "decode_gzip_base64_to_bytes",
    "decode_gzip_base64_to_text",
    "write_to_original_file",
    "compress_file_to_base64",
]


class JZipError(ValueError):
    """Base exception for JZip errors."""


class InvalidBase64Error(JZipError):
    """Raised when the input is not valid base64 content."""


class InvalidGzipContentError(JZipError):
    """Raised when base64-decoded bytes are not valid gzip content."""


def _ensure_bytes(value: Union[str, bytes], parameter_name: str) -> bytes:
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode("ascii")
    raise TypeError(f"{parameter_name} must be str or bytes, got {type(value).__name__}")


def decode_gzip_base64_to_bytes(gz_content: Union[str, bytes]) -> bytes:
    """
    Decode base64-encoded gzip content and return the original bytes.

    Args:
    - gz_content (str | bytes): Base64 encoded gzip-compressed content.

    Returns:
    - bytes: Decompressed original bytes.
    """
    gz_content_bytes = _ensure_bytes(gz_content, "gz_content")
    try:
        binary_data = base64.b64decode(gz_content_bytes, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise InvalidBase64Error("Input must be valid base64-encoded gzip content.") from exc

    try:
        return gzip.decompress(binary_data)
    except OSError as exc:
        raise InvalidGzipContentError("Base64 content is valid but not valid gzip data.") from exc


def decode_gzip_base64_to_text(
    gz_content: Union[str, bytes],
    encoding: str = default_encoding,
    errors: str = "strict",
) -> str:
    """
    Decode base64-encoded gzip content and return text using the given encoding.
    """
    return decode_gzip_base64_to_bytes(gz_content).decode(encoding, errors=errors)


def decode_gzip_base64_to_plain_base64(
    gz_content: Union[str, bytes],
    encoding: str = default_encoding,
) -> str:
    """
    Convert base64 encoded gzip-compressed content to base64 encoded plain content.

    Args:
    - gz_content (str | bytes): Base64 encoded gzip-compressed content.
    - encoding (str, optional): String encoding used for the base64 output.

    Returns:
    - str: Base64 encoded representation of the uncompressed content.
    """
    decompressed_content = decode_gzip_base64_to_bytes(gz_content)
    return base64.b64encode(decompressed_content).decode(encoding)


def write_to_original_file(
    gz_content: Union[str, bytes],
    file_name: Union[str, Path],
    encoding: str = default_encoding,
) -> None:
    """
    Uncompress base64-encoded gzip content and write exact bytes to file.

    Args:
    - gz_content (str | bytes): The base64-encoded gzip compressed content.
    - file_name (str | Path): The path where the decompressed content will be written.
    - encoding (str, optional): Kept for backwards compatibility.
    """
    del encoding  # Kept for backwards compatibility with previous function signature.
    decompressed_content = decode_gzip_base64_to_bytes(gz_content)
    Path(file_name).write_bytes(decompressed_content)


def compress_file_to_base64(
    file_name: Union[str, Path],
    encoding: str = default_encoding,
) -> str:
    """
    Compress a file to gzip format and return its base64 representation.

    Args:
    - file_name (str | Path): The path of the file to compress.
    - encoding (str, optional): String encoding used for the base64 output.

    Returns:
    - str: The base64-encoded representation of the compressed file.
    """
    file_content = Path(file_name).read_bytes()
    compressed_content = gzip.compress(file_content)
    return base64.b64encode(compressed_content).decode(encoding)
