"""Unit tests for promptosaurus."""
