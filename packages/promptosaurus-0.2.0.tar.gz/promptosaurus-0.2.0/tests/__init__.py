"""Test suite for promptosaurus."""
