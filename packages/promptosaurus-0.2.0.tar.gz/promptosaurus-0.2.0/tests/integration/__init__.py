"""Integration tests for promptosaurus."""
