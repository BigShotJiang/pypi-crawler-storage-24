"""Security tests for promptosaurus."""
