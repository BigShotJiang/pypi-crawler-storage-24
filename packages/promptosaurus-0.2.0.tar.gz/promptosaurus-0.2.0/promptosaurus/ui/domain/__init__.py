"""UI domain models."""
