from ....platforms import Architecture, Byteorder
from .machdef import PandaMachineDef


class MIPS64MachineDef(PandaMachineDef):
    arch = Architecture.MIPS64

    # We don't need this

    # I'm going to define all the ones we are making possible as of now
    # I need to submit a PR to change to X86 32 bit and to includ eflags
    def __init__(self):
        self._registers = {
            "at": "at",
            "1": "at",
            "v0": "v0",
            "2": "v0",
            "v1": "v1",
            "3": "v1",
            "a0": "a0",
            "4": "a0",
            "a1": "a1",
            "5": "a1",
            "a2": "a2",
            "6": "a2",
            "a3": "a3",
            "7": "a3",
            "a4": "a4",
            "8": "a4",
            "a5": "a5",
            "9": "a5",
            "a6": "a6",
            "10": "a6",
            "a7": "a7",
            "11": "a7",
            "t0": "t0",
            "12": "t0",
            "t1": "t1",
            "13": "t1",
            "t2": "t2",
            "14": "t2",
            "t3": "t3",
            "15": "t3",
            "t8": "t8",
            "24": "t8",
            "t9": "t9",
            "25": "t9",
            "s0": "s0",
            "16": "s0",
            "s1": "s1",
            "17": "s1",
            "s2": "s2",
            "18": "s2",
            "s3": "s3",
            "19": "s3",
            "s4": "s4",
            "20": "s4",
            "s5": "s5",
            "21": "s5",
            "s6": "s6",
            "22": "s6",
            "s7": "s7",
            "23": "s7",
            "s8": "s8",
            "fp": "s8",
            "30": "s8",
            "k0": "k0",
            "26": "k0",
            "k1": "k1",
            "27": "k1",
            "zero": "zero",
            "0": "zero",
            "gp": "gp",
            "28": "gp",
            "sp": "sp",
            "29": "sp",
            "ra": "ra",
            "31": "ra",
            "pc": "pc",
            "f0": None,
            "f1": None,
            "f2": None,
            "f3": None,
            "f4": None,
            "f5": None,
            "f6": None,
            "f7": None,
            "f8": None,
            "f9": None,
            "f10": None,
            "f11": None,
            "f12": None,
            "f13": None,
            "f14": None,
            "f15": None,
            "f16": None,
            "f17": None,
            "f18": None,
            "f19": None,
            "f20": None,
            "f21": None,
            "f22": None,
            "f23": None,
            "f24": None,
            "f25": None,
            "f26": None,
            "f27": None,
            "f28": None,
            "f29": None,
            "f30": None,
            "f31": None,
            "fir": None,
            "fcsr": None,
            "fexr": None,
            "fenr": None,
            "fccr": None,
            "ac0": None,
            "lo0": None,
            "hi0": None,
            "ac1": None,
            "lo1": None,
            "hi1": None,
            "ac2": None,
            "lo2": None,
            "hi2": None,
            "ac3": None,
            "lo3": None,
            "hi3": None,
        }


class MIPS64BEMachineDef(MIPS64MachineDef):
    byteorder = Byteorder.BIG
    panda_arch = "mips64"
    machine = "malta"
    cpu = "MIPS64R2-generic"


class MIPS64ELMachineDef(MIPS64MachineDef):
    byteorder = Byteorder.LITTLE
    panda_arch = "mips64el"
    machine = "malta"
    cpu = "MIPS64R2-generic"
