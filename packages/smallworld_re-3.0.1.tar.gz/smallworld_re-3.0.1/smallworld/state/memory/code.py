import typing

import claripy

from ... import emulators, exceptions
from ...platforms import Platform
from ..state import BytesValue, SymbolicValue, Value
from . import memory


class Executable(memory.RawMemory):
    """An execuable piece of code."""

    entrypoint: typing.Optional[int] = None
    """Entry point address.

    Note:
        This is not used by Emulators - but is available for reference from
        file parsing, if supported.
    """

    def apply(self, emulator: emulators.Emulator) -> None:
        # Program images are sparse, and can cover huge swaths of the address space.
        # Memory.apply() needs to allocate the entire region for stack/heap operations.
        # Doing that with an ELF core dump that occupies the entire address space
        # will lead to sadness.
        for offset, value in self.items():
            emulator.map_memory(self.address + offset, value.get_size())
            if value.get_content() is not None:
                self._write_content(emulator, self.address + offset, value)
            if value.get_type() is not None:
                emulator.write_memory_type(
                    self.address + offset, value.get_size(), value.get_type()
                )
            if value.get_label() is not None:
                print(
                    f"Writing label for [{self.address + offset:x} - {self.address + offset + value.get_size():x}]"
                )
                emulator.write_memory_label(
                    self.address + offset, value.get_size(), value.get_label()
                )

    def extract(self, emulator: emulators.Emulator) -> None:
        # This is the mirror problem of apply.
        # Memory.extract() will extract the entire contiguous region.
        # Doing that with an ELF core dump that occupies the entire address space
        # will lead to sadness.
        value: Value
        items = list(self.items())
        for offset, value in items:
            try:
                data = emulator.read_memory(self.address + offset, value.get_size())
                value = BytesValue(
                    data, f"Extracted memory from {self.address + offset:x}"
                )
            except exceptions.SymbolicValueError:
                expr = emulator.read_memory_symbolic(
                    self.address + offset, value.get_size()
                )
                value = SymbolicValue(
                    value.get_size(),
                    expr,
                    None,
                    f"Extracted memory from {self.address + offset:x}",
                )
            self[offset] = value

    def _write_content(self, emulator: emulators.Emulator, address: int, value: Value):
        if isinstance(value.get_content(), claripy.ast.bv.BV):
            raise NotImplementedError(
                "Absolutely not.  Get your symbolic code out of here."
            )
        emulator.write_code(address, value.to_bytes())

    @classmethod
    def from_elf(
        cls,
        file: typing.BinaryIO,
        address: typing.Optional[int] = None,
        platform: typing.Optional[Platform] = None,
        ignore_platform: bool = False,
        page_size: int = 0x1000,
    ):
        """Load an ELF executable from an open file-like object.

        Arguments:
            file: The open file-like object from which to read.
            address: The address where this executable should be loaded.
            platform: Optional platform for header verification
            ignore_platform: Skip platform ID and verification
            page_size: Page size in bytes

        Returns:
            An Executable parsed from the given ELF file-like object.
        """
        # NOTE: there's a circular dependency between elf.py and code.py
        # This is the accepted fix.
        from .elf import ElfExecutable

        return ElfExecutable(
            file,
            user_base=address,
            platform=platform,
            ignore_platform=ignore_platform,
            page_size=page_size,
        )

    @classmethod
    def from_elf_core(
        cls,
        file: typing.BinaryIO,
        address: typing.Optional[int] = None,
        platform: typing.Optional[Platform] = None,
        ignore_platform: bool = False,
    ):
        """
        Load an ELF core dump (ET_CORE) from an open file-like object.

        Arguments:
            file: The open file-like object from which to read.
            address: The address where this core dump should be loaded.
            platform: Optional platform for header verification
            ignore_platform: Skip platform ID and verification

        Returns:
            An Executable (specifically ElfCoreFile) parsed from the given core dump.
        """
        from .elf import ElfCoreFile

        return ElfCoreFile(
            file, user_base=address, platform=platform, ignore_platform=ignore_platform
        )

    @classmethod
    def from_pe(
        cls,
        file: typing.BinaryIO,
        address: typing.Optional[int] = None,
        platform: typing.Optional[Platform] = None,
        ignore_platform: bool = False,
    ):
        """Load an PE executable from an open file-like object.

        Arguments:
            file: The open file-like object from which to read.
            address: The address where this executable should be loaded.

        Returns:
            An Executable parsed from the given PE file-like object.
        """
        from .pe import PEExecutable

        return PEExecutable(
            file, user_base=address, platform=platform, ignore_platform=ignore_platform
        )

    @classmethod
    def from_vxworks(
        cls,
        file: typing.BinaryIO,
        address: typing.Optional[int] = None,
        platform: typing.Optional[Platform] = None,
        ignore_platform: bool = False,
    ):
        """Load a VXWorks executable from a firmware capture.
        Arguments:
            file: The open file-like object from which to read.
            address: The address where this executable should be loaded.
        Returns:
            An Executable parsed from the given VXWorks image.
        """
        from .vxworks import VXWorksImage

        return VXWorksImage(
            file, user_base=address, platform=platform, ignore_platform=ignore_platform
        )

    @classmethod
    def from_bndb(
        cls,
        path: str,
        address: typing.Optional[int] = None,
        platform: typing.Optional[Platform] = None,
        ignore_platform: bool = False,
    ):
        """Load an executable from a Binary Ninja database (.bndb) or any
        file that Binary Ninja can open.

        Arguments:
            path: Filesystem path to a ``.bndb`` file (or raw binary /
                  ELF / PE / Mach-O / etc.).
            address: Optional base address override.  When *None* the base
                     recorded in the BinaryView is used.
            platform: Optional platform; when given the detected platform
                      is verified against it.
            ignore_platform: Skip platform identification and verification.

        Returns:
            An Executable parsed from the given Binary Ninja database.
        """
        from .binjadatabase import BinjaDatabase

        return BinjaDatabase(
            path, user_base=address, platform=platform, ignore_platform=ignore_platform
        )


__all__ = ["Executable"]
