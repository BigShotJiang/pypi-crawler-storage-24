import os
log = int(os.getenv("LOCALADAPT_LOG_LVL", "0")) == 1
from .base_adapter import BaseAdapter, Value
from dataclasses import dataclass
if log: print("Importing PyTorch...")
import torch
if log: print("Importing transformers...")
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer
import threading


@dataclass
class LLM:
    model_path: str
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


class LLMAdapter(BaseAdapter):
    def __init__(self):
        self.model = None
        self.tokenizer = None

    def supports(self, request):
        return request.get("type") == "llm"

    def register_model(self, **kwargs) -> LLM:
        return LLM(**kwargs)

    def load(self, model: LLM):
        if log: print(f"Loading model from {model.model_path} to {model.device}...")
        self.tokenizer = AutoTokenizer.from_pretrained(model.model_path)
        self.model = AutoModelForCausalLM.from_pretrained(
            model.model_path
        ).to(model.device)

        if log:
            print(f"Model {model.model_path} loaded")
            print(f"You can now run it on {model.device}")

    def unload(self):
        if log: print(f"Unloading model {self.model.name_or_path}...")
        if self.model:
            del self.model
            self.model = None

        if self.tokenizer:
            del self.tokenizer
            self.tokenizer = None

        torch.cuda.empty_cache()
        return super().unload()

    def run(self, request: dict) -> Value:
        if not self.model or not self.tokenizer:
            raise ValueError("You have to load a model first!")

        max_new_tokens = request.get("max_length", 100)
        stream = request.get("stream", False)
        do_sample = request.get("do_sample", True)
        temperature = request.get("temperature", 1.0)

        result = Value(text="")

        messages = request.get("history", []).copy()

        if log: print("Applying chat template...")

        inputs = self.tokenizer.apply_chat_template(
            messages,
            return_tensors="pt",
            add_generation_prompt=True
        ).to(self.model.device)
        repetition_penalty = request.get("repetition_penalty", 1.1)

        if stream:
            if log: print("Creating Stream...")
            streamer = TextIteratorStreamer(
                self.tokenizer,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False
            )

            def generate():
                with torch.no_grad():
                    top_p = request.get("top_p", 0.9)
                    self.model.generate(
                        **inputs,
                        max_new_tokens=max_new_tokens,
                        do_sample=do_sample,
                        temperature=temperature,
                        eos_token_id=self.tokenizer.eos_token_id,
                        pad_token_id=self.tokenizer.eos_token_id,
                        streamer=streamer,
                        top_p=top_p,
                        repetition_penalty=repetition_penalty,
                    )

            threading.Thread(target=generate, daemon=True).start()

            def stream_output():
                for text in streamer:
                    result.text += text
                result.done = True

            threading.Thread(target=stream_output, daemon=True).start()

            return result

        else:
            with torch.no_grad():
                output_ids = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=do_sample,
                    temperature=temperature,
                    eos_token_id=self.tokenizer.eos_token_id,
                    pad_token_id=self.tokenizer.eos_token_id,
                    repetition_penalty=repetition_penalty,
                )

            input_length = inputs["input_ids"].shape[1]
            new_tokens = output_ids[0][input_length:]

            result.text = self.tokenizer.decode(
                new_tokens,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False
            )
            result.done = True

            return result
