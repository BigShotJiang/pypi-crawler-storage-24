"""Git integration services."""
