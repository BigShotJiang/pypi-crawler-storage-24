"""Validation pipeline package."""
