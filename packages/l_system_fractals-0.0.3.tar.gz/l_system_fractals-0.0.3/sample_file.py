from l_system_fractals import *

# FractalPlant(5).draw_turtle((0, -500), instant=True, end_turtle=False, make_colorful=True, color_func=lambda: (0, random.randint(100, 255), 0))
# KochCurve(5).draw_turtle((-500, -200), end_turtle=False, make_colorful=True, instant=True)
# SierpinskiTriangle(5, start_angle=180).draw_turtle((-400, -100), end_turtle=False, instant=True, make_colorful=True)
# SierpinskiArrowheadCurve(5).draw_turtle((0, 0), end_turtle=False, instant=True, make_colorful=True)
DragonCurve(10).draw_turtle((350, 350), instant=True, make_colorful=True)