# L-System Fractals

Implementation of [L-System Fractals](https://en.wikipedia.org/wiki/L-system). This package draws fractals in turtle.

## Sample Generations

![Sample Colorful Fractal Plant](https://gootyboy.github.io/project_details/l-system-fractals/sample_fractal_plant.png)
![Sample Colorful Koch Curve](https://gootyboy.github.io/project_details/l-system-fractals/sample_koch_curve.png)
![Sample Colorful Sierpinski Triangle](https://gootyboy.github.io/project_details/l-system-fractals/sample_sierpinski_triangle.png)
![Sample Colorful Sierpinski Arrowhead Curve](https://gootyboy.github.io/project_details/l-system-fractals/sample_sierpinski_arrowhead_curve.png)
![Sample Colorful Dragon Curve](https://gootyboy.github.io/project_details/l-system-fractals/sample_dragon_curve.png)

---

## Table of Contents
- Installation
- Why Use l-system?
- Usage
- Versions
- Coming Soon

---

## Installation
```
pip install l-system-fractals
```

---

## Why Use l-system-fractals?

This package includes an base LSystem class with default subclasses for common l-system fractals:
- Fractal plant
- Koch curve
- Sierpinski triangle
- Sierpinski arrowhead curve
- Dragon curve

---

## Usage

### Example 1

Drawing custom L-Systems using the LSystem Class

```python
from l_system_fractals import *

my_l_system = LSystem(
    iterations=5,
    start="X",
    rules=[("X", "-F+X"), ("F", "-F-[X+F]+F")],
    variable_rules=[("F", DRAW_FORWARD), ("X", MOVE_FORWARD)],
    constant_rules=[("-", TURN_RIGHT), ("+", TURN_LEFT), ("[", SAVE_POS_AND_ANGLE), ("]", GO_TO_POS_ANGLE_AND_RESET_THEM)],
    angle=30,
    scale=2,
    thickness=2,
    start_angle=10
)

my_l_system.draw_turtle(pos=(0, 0), speed=0, end_turtle=True, instant=False, make_colorful=True, color_density=10)
```

### Example 2

Drawing custom L-Systems using subclass of LSystem Class

```python
from l_system_fractals import *

class MyLSystem(LSystem):
    def __init__(self):
        super().__init__(
        iterations=5,
        start="X",
        rules=[("X", "-F+X"), ("F", "-F-[X+F]+F")],
        variable_rules=[("F", DRAW_FORWARD), ("X", MOVE_FORWARD)],
        constant_rules=[("-", TURN_RIGHT), ("+", TURN_LEFT), ("[", SAVE_POS_AND_ANGLE), ("]", GO_TO_POS_ANGLE_AND_RESET_THEM)],
        angle=30,
        scale=2,
        thickness=2,
        start_angle=10
        )

my_l_system = MyLSystem()

my_l_system.draw_turtle(pos=(0, 0), speed=0, end_turtle=True, instant=False, make_colorful=True, color_density=10)
```

## Example 3

Drawing L-System using pre-made classes

```python
from l_system_fractals import *

my_l_system = FractalPlant(iterations=6, start = "X", scale = 3, thickness = 1, start_angle = 0)

my_l_system.draw_turtle(pos=(0, -300), speed=0, end_turtle=True, instant=False, make_colorful=True, color_density=10)
```

---

## Versions

Version 0.0.1: Main code for l-system added.
Version 0.0.2: README fixed.
**(Latest) Version 0.0.3:** rename project name.

---

## Coming Soon

Version 0.0.4: Add support for drawing L-Systems on a specific pen given by the user instead of creating a new pen.
