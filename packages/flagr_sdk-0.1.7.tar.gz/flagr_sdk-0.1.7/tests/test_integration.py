"""Integration tests — spins up the Go API in dev mode, tests the SDK end-to-end.
Run: pytest tests/test_integration.py  (requires Go + Postgres + Redis running locally)
"""

import os
import subprocess
import time
import threading
import urllib.request
import urllib.error
import json
import pytest
from openfeature import api
from openfeature.evaluation_context import EvaluationContext
from flagr.provider import FlagrProvider

API_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "api"))
DB_URL = os.environ.get("TEST_DATABASE_URL", "postgres://featureflags:featureflags@localhost:5432/featureflags?sslmode=disable")
REDIS_URL = os.environ.get("TEST_REDIS_URL", "redis://localhost:6379")
PORT = os.environ.get("SDK_TEST_PORT", "18081")
BASE_URL = f"http://localhost:{PORT}"


def wait_ready(url: str, timeout: float = 15.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"{url}/health", timeout=1)
            return
        except Exception:
            time.sleep(0.2)
    raise RuntimeError("API server did not become ready in time")


def mgmt(method: str, path: str, body=None):
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=data,
        method=method,
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer dev-token",
            "X-Dev-Org": "sdk-python-test-org",
        },
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


@pytest.fixture(scope="module")
def api_server():
    env = {**os.environ, "PORT": PORT, "DATABASE_URL": DB_URL, "REDIS_URL": REDIS_URL, "CLERK_SECRET_KEY": ""}
    go_exec = os.environ.get("GO_EXEC", "/opt/homebrew/bin/go")
    proc = subprocess.Popen(
        [go_exec, "run", "./cmd/server"],
        cwd=API_DIR,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    wait_ready(BASE_URL)
    yield BASE_URL
    proc.terminate()
    proc.wait()


@pytest.fixture(scope="module")
def fixtures(api_server):
    slug = f"sdk-py-{int(time.time())}"
    project = mgmt("POST", "/api/v1/projects", {"name": "SDK Python Test", "slug": slug})
    env = mgmt("POST", f"/api/v1/projects/{project['id']}/environments", {"name": "prod", "slug": "prod"})
    flag = mgmt("POST", f"/api/v1/projects/{project['id']}/flags", {"name": "py-flag", "key": "py-flag"})
    return project, env, flag


def patch(fixtures, state: str, enabled_list=None):
    project, env, flag = fixtures
    mgmt("PATCH", f"/api/v1/projects/{project['id']}/flags/{flag['id']}/environments/{env['id']}",
         {"state": state, "enabled_list": enabled_list or []})
    time.sleep(0.1)  # let SSE propagate


def test_enabled_flag(api_server, fixtures):
    _, env, _ = fixtures
    provider = FlagrProvider(sdk_key=env["sdk_key"], base_url=api_server)
    api.set_provider(provider)
    client = api.get_client()

    patch(fixtures, "enabled")
    assert client.get_boolean_value("py-flag", False, EvaluationContext(targeting_key="any")) is True
    api.shutdown()


def test_disabled_flag(api_server, fixtures):
    _, env, _ = fixtures
    provider = FlagrProvider(sdk_key=env["sdk_key"], base_url=api_server)
    api.set_provider(provider)
    client = api.get_client()

    patch(fixtures, "disabled")
    assert client.get_boolean_value("py-flag", True, EvaluationContext(targeting_key="any")) is False
    api.shutdown()


def test_partially_enabled(api_server, fixtures):
    _, env, _ = fixtures
    provider = FlagrProvider(sdk_key=env["sdk_key"], base_url=api_server)
    api.set_provider(provider)
    client = api.get_client()

    patch(fixtures, "partially_enabled", ["allowed-tenant"])
    assert client.get_boolean_value("py-flag", False, EvaluationContext(targeting_key="allowed-tenant")) is True
    assert client.get_boolean_value("py-flag", True, EvaluationContext(targeting_key="other-tenant")) is False
    api.shutdown()
