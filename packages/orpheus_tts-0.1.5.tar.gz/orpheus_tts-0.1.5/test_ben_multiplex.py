#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "httpx",
#     "numpy",
#     "websockets",
# ]
# ///
"""
TTS Benchmark Client - Tests TTS endpoints with sustained concurrency.

Supports four modes (all return raw PCM):
- local: Calls local gateway /tts endpoint (HTTP streaming)
- websocket: Calls local gateway /ws/tts endpoint (WebSocket streaming, lowest latency)
- direct: Calls per-LLM Baseten deployments directly
- gateway: Calls Canopy gateway API

Usage:
    python test_tts.py --mode local -n 10
    python test_tts.py --mode websocket -n 10
    python test_tts.py --mode direct -n 10
    python test_tts.py --mode gateway -n 10
"""

import asyncio
import argparse
import heapq
import json
import random
import secrets
import struct
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import httpx
import numpy as np
import os
import sys

try:
    import websockets
except ImportError:
    websockets = None


# =============================================================================
# Constants
# =============================================================================

SAMPLE_RATE = 48000  # Server outputs 48kHz PCM

# When --use-streaming, cap total_ms for Total/RTF stats so one slow stream doesn't blow p99/max
STREAMING_RTF_CAP_MS = 90_000  # 90s

# Endpoint URLs
# REMOTE_GATEWAY_URL = "https://api.canopylabs.ai/v1/audio/speech"

# REMOTE_GATEWAY_MODEL = "canopylabs/orpheus-v1-english/colin"

# # Direct Baseten deployment URL (single deployment serves all voices)
# DIRECT_BASETEN_URL = "https://model-yqvjkrjq.api.baseten.co/deployment/3yd0gvk/predict"

# LOCAL_GATEWAY_URL = "http://localhost:8003"
# LOCAL_GATEWAY_URL = "http://195.242.13.0:8003"
# LOCAL_GATEWAY_URL = "model-wommpdzq.api.baseten.co/environments/production/websocket"
# LOCAL_GATEWAY_URL = "136.117.51.119:8000"
LOCAL_GATEWAY_URL = "asdjfasdf"
# LOCAL_GATEWAY_URL = "https://model-wommpdzq.api.baseten.co/deployment/qjdk21p/websocket/predict"
# LOCAL_GATEWAY_URL = "https://model-wommpdzq.api.baseten.co/deployment/qjdk21p"
# LLM to voices mapping
LLM_VOICES = [
    {
        "llm": "llm1",
        "voices": ["colin", "hannah_hayes", "lionel", "elisabeth_rudolph"]
        # "voices": ["colin", "hannah_hayes"]
        # "voices": ["colin", "hannah_hayes"]
        # "voices": ["colin"]
        # "voices": ["antoine","dawn","max","anna"]
    },
    # {
    #     "llm": "llm2",
    #     "voices": ["austin_vanfleet", "josh", "daniel_smith", "chris_arias"]
    # },
    # {
    #     "llm": "llm3",
    #     "voices": ["sarah_partridge", "garan_patrick", "josh_musgrove", "artsitha", "dan_amerman"]
    # },
    # {
    #     "llm": "llm4",
    #     "voices": ["troy", "autumn", "diana"]
    # },
]

# Build voice to LLM mapping
VOICE_TO_LLM = {}
for llm_config in LLM_VOICES:
    for voice in llm_config["voices"]:
        VOICE_TO_LLM[voice] = llm_config["llm"]

ALL_VOICES = list(VOICE_TO_LLM.keys())

# Test prompts
PROMPTS = [
    # "So I've been thinking about this a lot lately, and I mean a lot, like staying up until three in the morning staring at the ceiling kind of thinking. It's about my job, which— okay, look, I know everyone complains about their job, that's like the universal human experience or whatever, but this is different. I've been at this company for seven years now. Seven years! That's longer than most marriages last these days, which is kind of depressing when you think about it. And for the first few years, it was great, you know? I was learning things, I was growing, I felt like I was actually contributing something meaningful."
    "Hello, this is a test of the text to speech system.",
    "The quick brown fox jumps over the lazy dog near the riverbank. A ripple in the water adds some suspense.",
    "Welcome to our audio streaming service. Discover new content, genres, and personalized recommendations.",
    "Artificial intelligence is changing how we interact with technology, driving smarter automation and better interfaces.",
    "The weather today is sunny with a chance of rain, so consider bringing an umbrella. Gentle breezes are expected.",
    "Subscribe to our channel for updates. Get notifications about new content and features in audio technology.",
    "Creativity knows no bounds. Imagination leads to innovation and transforms challenges into opportunities.",
    "Consistency and dedication lead to success. Keep improving even when progress is slow or obstacles appear.",
    "Music evokes emotion and brings people together, crossing language and cultural barriers to unite audiences.",
    "Thank you for listening and supporting us. Your feedback helps us improve and inspires us to create more.",
]


# =============================================================================
# Utility Functions
# =============================================================================

def get_api_key(mode: str) -> str | None:
    """Get the appropriate API key for the given mode."""
    if mode == "local":
        return None
    elif mode == "direct":
        key = os.getenv('BASETEN_API_KEY')
        if not key:
            print("ERROR: BASETEN_API_KEY environment variable not set")
            print("  export BASETEN_API_KEY=your_api_key")
            sys.exit(1)
        return key
    elif mode == "gateway":
        key = os.getenv('CANOPY_GATEWAY_API_KEY')
        if not key:
            print("ERROR: CANOPY_GATEWAY_API_KEY environment variable not set")
            print("  export CANOPY_GATEWAY_API_KEY=your_api_key")
            sys.exit(1)
        return key
    return None


def make_unique_prompt(prompt: str) -> str:
    # return prompt
    """Add random prefix to make prompt unique (avoids caching)."""
    rand_chars = ''.join(secrets.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(3))
    return f"{rand_chars}_{prompt}"


def save_wav(audio: np.ndarray, filepath: str, sample_rate: int = SAMPLE_RATE):
    """Save audio as WAV file."""
    import wave
    audio = np.clip(audio, -1.0, 1.0)
    audio_int16 = (audio * 32767).astype(np.int16)
    with wave.open(filepath, 'w') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(audio_int16.tobytes())


def avg(lst: List[float]) -> float:
    return sum(lst) / len(lst) if lst else 0


def percentile(lst: List[float], p: float) -> float:
    if not lst:
        return 0
    sorted_lst = sorted(lst)
    k = (len(sorted_lst) - 1) * (p / 100)
    f = int(k)
    c = f + 1 if f + 1 < len(sorted_lst) else f
    return sorted_lst[f] + (sorted_lst[c] - sorted_lst[f]) * (k - f)


def generate_transcript_deltas(
    prompt: str,
    min_updates: int = 5,
    max_updates: int = 15,
) -> List[str]:
    """
    Split a full prompt into 5–15 sequential partial updates (deltas) to mimic
    incremental transcription. Does NOT add punctuation; the server accumulates
    deltas and only feeds the LLM when it sees a complete sentence (ending in .!?).
    """
    words = prompt.strip().split()
    if not words:
        return []
    n = random.randint(min_updates, max_updates)
    n = max(1, min(n, len(words)))
    # Assign words to n buckets in strict order (no random moves - preserves word order)
    deltas: List[List[str]] = [[] for _ in range(n)]
    for i, w in enumerate(words):
        bucket = int((i / len(words)) * n) if n > 0 else 0
        bucket = min(bucket, n - 1)
        deltas[bucket].append(w)
    result: List[str] = []
    for group in deltas:
        s = " ".join(group)
        if s:
            result.append(s)
    return result if result else [prompt]


# =============================================================================
# Stream TTS Audio (raw PCM)
# =============================================================================

async def stream_tts(
    client: httpx.AsyncClient,
    url: str,
    prompt: str,
    voice: str,
    stream_id: int,
    api_key: str | None,
    mode: str,
) -> Tuple[np.ndarray, dict]:
    """
    Stream audio from TTS endpoint. Returns raw PCM (int16, 44100 Hz, mono).
    """
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Api-Key {api_key}"

    request_body = {
        "prompt": prompt,
        "voice": voice,
        "max_tokens": 3000,
        "temperature": 1.0,
        "repetition_penalty": 1.1,
    }

    if mode == "gateway":
        request_body["model"] = REMOTE_GATEWAY_MODEL

    stats = {
        "voice": voice,
        # Client-side timing
        "client_ttfa_ms": None,
        # Server-side timing breakdown
        "server_prefill_ms": None,
        "server_decode_ready_ms": None,  # When enough tokens accumulated
        "server_token_accum_ms": None,   # Time from prefill to decode-ready (LLM token generation)
        "server_first_audio_ms": None,
        "server_tensor_ms": None,
        "server_batch_wait_ms": None,
        "server_gpu_ms": None,
        "server_cpu_ms": None,
        "server_batch_size": None,
        "gateway_send_ms": None,
        "gateway_ttfa_ms": None,
        "gateway_net_proc_ms": None,
        # Overall
        "total_ms": 0,
        "audio_duration_s": 0,
        "total_bytes": 0,
        "worker_id": None,
        "success": False,
    }

    audio_chunks = []
    request_start = time.perf_counter()
    first_audio_received = False
    timing_parsed = False  # Track if we've parsed the timing JSON

    try:
        # Use format=timed to get server timing (for local/direct modes)
        request_url = url
        if mode in ("local", "direct"):
            request_url = f"{url}?format=timed"
        
        async with client.stream("POST", request_url, headers=headers, json=request_body) as response:
            stats["worker_id"] = response.headers.get("X-Worker-Id")

            if response.status_code != 200:
                error_text = await response.aread()
                print(f"Stream {stream_id} [{voice}]: Error {response.status_code} - {error_text[:100]}")
                stats["total_ms"] = (time.perf_counter() - request_start) * 1000
                return np.array([], dtype=np.float32), stats

            buffer = b""
            async for chunk in response.aiter_bytes():
                if chunk:
                    # For timed format, first line is JSON timing
                    if mode in ("local", "direct") and not timing_parsed:
                        buffer += chunk
                        if b"\n" in buffer:
                            json_line, remainder = buffer.split(b"\n", 1)
                            try:
                                timing_data = json.loads(json_line.decode("utf-8"))
                                stats["server_prefill_ms"] = timing_data.get("prefill_ms")
                                stats["server_decode_ready_ms"] = timing_data.get("decode_ready_ms")
                                stats["server_token_accum_ms"] = timing_data.get("token_accum_ms")
                                stats["server_first_audio_ms"] = timing_data.get("first_audio_ms")
                                stats["server_tensor_ms"] = timing_data.get("tensor_ms")
                                stats["server_batch_wait_ms"] = timing_data.get("batch_wait_ms")
                                stats["server_gpu_ms"] = timing_data.get("gpu_ms")
                                stats["server_cpu_ms"] = timing_data.get("cpu_ms")
                                stats["server_batch_size"] = timing_data.get("batch_size")
                                stats["gateway_send_ms"] = timing_data.get("gateway_send_ms")
                                stats["gateway_ttfa_ms"] = timing_data.get("gateway_ttfa_ms")
                                stats["gateway_net_proc_ms"] = timing_data.get("gateway_net_proc_ms")
                            except (json.JSONDecodeError, UnicodeDecodeError):
                                # If parsing fails, treat entire buffer as audio
                                remainder = buffer
                            timing_parsed = True
                            if remainder:
                                chunk = remainder
                            else:
                                continue
                        else:
                            continue
                    
                    if not first_audio_received:
                        stats["client_ttfa_ms"] = (time.perf_counter() - request_start) * 1000
                        first_audio_received = True
                        worker = stats["worker_id"] or "?"
                        prefill = stats.get("server_prefill_ms") or 0
                        srv_ttfa = stats.get("server_first_audio_ms") or 0
                        gpu = stats.get("server_gpu_ms") or 0
                        print(f"Stream {stream_id} [{voice}→{worker}]: cliTTFA={stats['client_ttfa_ms']:.1f}ms, prefill={prefill:.1f}ms, gpu={gpu:.1f}ms, srvTTFA={srv_ttfa:.1f}ms")
                    audio_chunks.append(chunk)

        stats["total_ms"] = (time.perf_counter() - request_start) * 1000

        if audio_chunks:
            pcm_bytes = b"".join(audio_chunks)
            # Truncate to even number of bytes (int16 = 2 bytes per sample)
            if len(pcm_bytes) % 2 != 0:
                pcm_bytes = pcm_bytes[:-1]
            if len(pcm_bytes) == 0:
                return np.array([], dtype=np.float32), stats
            audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
            audio = audio_int16.astype(np.float32) / 32768.0
            stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
            stats["total_bytes"] = len(pcm_bytes)
            stats["success"] = True
            print(f"Stream {stream_id} [{voice}]: Finished | {stats['audio_duration_s']:.2f}s audio | {stats['total_ms']:.0f}ms total")
            return audio, stats

        return np.array([], dtype=np.float32), stats

    except httpx.HTTPError as e:
        stats["total_ms"] = (time.perf_counter() - request_start) * 1000
        print(f"Stream {stream_id} [{voice}]: Connection error - {e}")
        return np.array([], dtype=np.float32), stats


# =============================================================================
# Multiplexed WebSocket Client
# =============================================================================

class MultiplexedWebSocketClient:
    """
    Client that handles multiple concurrent TTS requests over a single WebSocket.
    
    Protocol:
    - Send: {"request_id": "uuid", "prompt": "...", "voice": "..."}
    - Receive binary: [4-byte request_id BE] + [PCM audio]
    - Receive JSON: {"request_id": 123, "done": true, "timing": {...}}
    """
    
    def __init__(self, ws_url: str, additional_headers: dict[str, str] | None = None):
        self.ws_url = ws_url
        self.additional_headers = additional_headers
        self.ws = None
        
        # Track active requests
        self._request_id_counter = 0
        self._active_requests: Dict[str, dict] = {}  # client_request_id -> stats dict
        self._audio_buffers: Dict[str, List[bytes]] = {}
        self._completion_events: Dict[str, asyncio.Event] = {}
        self._server_id_to_client_id: Dict[int, str] = {}  # server_request_id -> client_request_id
        self._client_id_to_server_id: Dict[str, int] = {}  # client_request_id -> server_request_id
        
        # Synchronization
        # Note: No send lock needed - WebSocket sends are safe to call concurrently
        # from different tasks in asyncio. The websockets library handles serialization.
        self._receiver_task = None
        
        # Interleaved send: priority queue (delta_index, stream_id) and sender task
        self._send_heap: List[Tuple[int, int, str, str, dict, bool, dict]] = []
        self._send_lock = asyncio.Lock()
        self._send_event = asyncio.Event()
        self._sender_task = None
        
        # Connection state
        self._connected = False

        # Feature flag inferred from URL (keeps benchmark CLI simple)
        self._use_streaming_endpoint = "/ws/tts/multiplex/streaming" in ws_url
    
    async def connect(self):
        """Establish WebSocket connection."""
        try:
            connect_kwargs = dict(
                max_size=16 * 1024 * 1024,
                ping_interval=30,
                ping_timeout=10,
                open_timeout=60.0,
                close_timeout=10.0,
            )
            # websockets renamed this parameter across versions.
            try:
                self.ws = await websockets.connect(
                    self.ws_url,
                    additional_headers=self.additional_headers,
                    **connect_kwargs,
                )
            except TypeError:
                self.ws = await websockets.connect(
                    self.ws_url,
                    extra_headers=self.additional_headers,
                    **connect_kwargs,
                )
            self._connected = True
            
            # Start receiver loop and interleaved sender loop
            self._receiver_task = asyncio.create_task(self._receive_loop())
            self._sender_task = asyncio.create_task(self._sender_loop())
        except Exception as e:
            self._connected = False
            raise
    
    async def close(self):
        """Close the connection."""
        self._connected = False
        if self._sender_task:
            self._sender_task.cancel()
            try:
                await self._sender_task
            except asyncio.CancelledError:
                pass
            self._sender_task = None
        if self._receiver_task:
            self._receiver_task.cancel()
            try:
                await self._receiver_task
            except asyncio.CancelledError:
                pass
            self._receiver_task = None
        
        if self.ws:
            await self.ws.close()
        
        self._connected = False
    
    async def _sender_loop(self):
        """
        Drain the priority send heap in (delta_index, stream_id) order so that
        all streams' first deltas are sent before any second deltas (interleaved first deltas).
        """
        try:
            while self._connected and self.ws:
                await self._send_event.wait()
                async with self._send_lock:
                    if not self._send_heap:
                        self._send_event.clear()
                        continue
                    # Heap key is (delta_index, stream_id); payload and refs follow
                    item = heapq.heappop(self._send_heap)
                    if self._send_heap:
                        self._send_event.set()
                # Send outside the lock so receive loop and other sessions can progress
                delta_index, stream_id, payload_str, request_id, stats_ref, is_first, stream_stats_ref = item
                try:
                    await self.ws.send(payload_str)
                except Exception:
                    break
                now = time.perf_counter()
                stats_ref["send_complete_time"] = now
                if is_first and stream_stats_ref is not None:
                    req_start = stream_stats_ref.get("request_start")
                    if req_start is not None:
                        stream_stats_ref["client_send_time_ms"] = (now - req_start) * 1000
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
    
    async def _receive_loop(self):
        """Demultiplex incoming messages to the correct request handlers."""
        try:
            async for message in self.ws:
                if isinstance(message, bytes):
                    # Extract server_request_id from first 4 bytes
                    if len(message) < 4:
                        continue
                    
                    server_request_id = struct.unpack('>I', message[:4])[0]
                    audio_bytes = message[4:]
                    
                    # Primary path: strict server->client mapping from "accepted" message
                    request_id = self._server_id_to_client_id.get(server_request_id)
                    if request_id is None:
                        # Backward-compatible fallback for older servers with no accepted message
                        for rid, stats in self._active_requests.items():
                            if stats.get("total_bytes", 0) == 0:
                                request_id = rid
                                self._server_id_to_client_id[server_request_id] = rid
                                self._client_id_to_server_id[rid] = server_request_id
                                break
                        if request_id is None:
                            continue
                    
                    if request_id in self._active_requests:
                        stats = self._active_requests[request_id]
                        
                        # Track first audio time
                        if stats.get("first_audio_received") is None:
                            stats["first_audio_received"] = True
                            first_audio_time = time.perf_counter()
                            stats["client_ttfa_ms"] = (first_audio_time - stats["request_start"]) * 1000
                            
                            # Calculate network + processing time (from send to first audio)
                            if stats.get("send_complete_time"):
                                stats["client_network_processing_ms"] = (first_audio_time - stats["send_complete_time"]) * 1000
                        
                        # Accumulate audio
                        if request_id not in self._audio_buffers:
                            self._audio_buffers[request_id] = []
                        self._audio_buffers[request_id].append(audio_bytes)
                        stats["total_bytes"] = stats.get("total_bytes", 0) + len(audio_bytes)
                
                else:
                    # Text/JSON message
                    try:
                        data = json.loads(message)
                        message_type = data.get("type")
                        server_request_id = data.get("server_request_id")
                        client_request_id = data.get("client_request_id")

                        # Backward compatibility with old schema where request_id is server int
                        if server_request_id is None and isinstance(data.get("request_id"), int):
                            server_request_id = data.get("request_id")

                        if message_type == "accepted":
                            if server_request_id is not None and client_request_id is not None:
                                client_request_id = str(client_request_id)
                                self._server_id_to_client_id[int(server_request_id)] = client_request_id
                                self._client_id_to_server_id[client_request_id] = int(server_request_id)
                            continue

                        # Resolve client request_id
                        request_id = None
                        if client_request_id is not None:
                            cid = str(client_request_id)
                            if cid in self._active_requests:
                                request_id = cid
                        if request_id is None and server_request_id is not None:
                            request_id = self._server_id_to_client_id.get(int(server_request_id))
                        if request_id is None and isinstance(data.get("request_id"), str):
                            rid = data.get("request_id")
                            if rid in self._active_requests:
                                request_id = rid
                        if request_id is None and server_request_id is not None:
                            # Fallback heuristic for legacy servers
                            for rid in self._active_requests.keys():
                                if rid not in self._server_id_to_client_id.values():
                                    request_id = rid
                                    self._server_id_to_client_id[int(server_request_id)] = rid
                                    self._client_id_to_server_id[rid] = int(server_request_id)
                                    break
                        if request_id is None:
                            continue
                        
                        if data.get("done"):
                            # Request completed
                            if request_id in self._active_requests:
                                stats = self._active_requests[request_id]
                                stats["total_ms"] = (time.perf_counter() - stats["request_start"]) * 1000
                                stats["success"] = True
                                
                                # Extract server timing
                                timing = data.get("timing", {})
                                stats["server_prefill_ms"] = timing.get("prefill_ms")
                                stats["server_decode_ready_ms"] = timing.get("decode_ready_ms")
                                stats["server_token_accum_ms"] = timing.get("token_accum_ms")
                                stats["server_first_audio_ms"] = timing.get("first_audio_ms")
                                stats["server_first_audio_ready_ms"] = timing.get("first_audio_ready_ms")
                                stats["server_first_audio_enqueued_ms"] = timing.get("first_audio_enqueued_ms")
                                stats["server_first_audio_sent_ms"] = timing.get("first_audio_sent_ms")
                                stats["server_outbound_delay_ms"] = timing.get("outbound_delay_ms")
                                stats["server_tensor_ms"] = timing.get("tensor_ms")
                                stats["server_batch_wait_ms"] = timing.get("batch_wait_ms")
                                stats["server_gpu_ms"] = timing.get("gpu_ms")
                                stats["server_cpu_ms"] = timing.get("cpu_ms")
                                stats["server_batch_size"] = timing.get("batch_size")
                                stats["gateway_send_ms"] = timing.get("gateway_send_ms")
                                stats["gateway_ttfa_ms"] = timing.get("gateway_ttfa_ms")
                                stats["gateway_net_proc_ms"] = timing.get("gateway_net_proc_ms")
                            
                            # Signal completion
                            if request_id in self._completion_events:
                                self._completion_events[request_id].set()
                        
                        elif data.get("error"):
                            # Request failed
                            if request_id in self._active_requests:
                                stats = self._active_requests[request_id]
                                stats["error"] = data.get("error")
                                stats["success"] = False
                            
                            if request_id in self._completion_events:
                                self._completion_events[request_id].set()
                    
                    except json.JSONDecodeError:
                        pass
        
        except websockets.exceptions.ConnectionClosed:
            # Signal all pending requests as failed
            for request_id, event in self._completion_events.items():
                if not event.is_set():
                    if request_id in self._active_requests:
                        self._active_requests[request_id]["error"] = "Connection closed"
                        self._active_requests[request_id]["success"] = False
                    event.set()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            # Signal all pending requests as failed
            for request_id, event in self._completion_events.items():
                if not event.is_set():
                    if request_id in self._active_requests:
                        self._active_requests[request_id]["error"] = f"Receiver error: {e}"
                        self._active_requests[request_id]["success"] = False
                    event.set()
    
    async def submit_request(self, prompt: str, voice: str, stream_id: int, request_start_time: float) -> Tuple[np.ndarray, dict]:
        """
        Submit a TTS request and wait for completion.
        
        request_start_time: When timing should start (after WebSocket acquisition).
                          This includes send lock wait time, which is part of the latency
                          when multiple requests share a connection.
        
        Returns (audio_array, stats_dict).
        """
        # Assign request ID
        self._request_id_counter += 1
        request_id = f"req_{self._request_id_counter}"
        
        # Create stats
        stats = {
            "voice": voice,
            "client_ttfa_ms": None,
            "client_send_time_ms": None,  # Time from WS acquisition to after send
            "client_network_processing_ms": None,  # Time from send to first audio (network + server)
            "server_prefill_ms": None,
            "server_decode_ready_ms": None,
            "server_token_accum_ms": None,
            "server_first_audio_ms": None,
            "server_first_audio_ready_ms": None,
            "server_first_audio_enqueued_ms": None,
            "server_first_audio_sent_ms": None,
            "server_tensor_ms": None,
            "server_batch_wait_ms": None,
            "server_gpu_ms": None,
            "server_cpu_ms": None,
            "server_batch_size": None,
            "gateway_send_ms": None,
            "gateway_ttfa_ms": None,
            "gateway_net_proc_ms": None,
            "total_ms": 0,
            "audio_duration_s": 0,
            "total_bytes": 0,
            "worker_id": "ws",
            "success": False,
            "request_start": request_start_time,  # Use the passed start time
            "send_complete_time": None,  # When request was sent
            "first_audio_received": None,
        }
        
        completion_event = asyncio.Event()
        
        self._active_requests[request_id] = stats
        self._completion_events[request_id] = completion_event
        self._audio_buffers[request_id] = []
        
        try:
            # Send request
            request_data = {
                "request_id": request_id,
                "prompt": prompt,
                "voice": voice,
                "max_tokens": 3000,
                "temperature": 1.0,
                "repetition_penalty": 1.1,
            }

            # Optional: session-based streaming inference endpoint
            if self._use_streaming_endpoint:
                request_data["stream_id"] = request_id
                request_data["stream_action"] = "start"
            
            # Send request (no lock needed - concurrent sends are safe with websockets library)
            await self.ws.send(json.dumps(request_data))
            
            # Record send completion time
            stats["send_complete_time"] = time.perf_counter()
            stats["client_send_time_ms"] = (stats["send_complete_time"] - request_start_time) * 1000
            
            # Wait for completion with timeout
            try:
                await asyncio.wait_for(completion_event.wait(), timeout=60.0)
            except asyncio.TimeoutError:
                stats["error"] = "Timeout waiting for completion"
                stats["success"] = False
                print(f"Stream {stream_id} [{voice}]: Request timed out after 60s")
            
            # Convert audio bytes to numpy array
            audio = np.array([], dtype=np.float32)
            if request_id in self._audio_buffers and self._audio_buffers[request_id]:
                pcm_bytes = b"".join(self._audio_buffers[request_id])
                # Truncate to even number of bytes (int16 = 2 bytes per sample)
                if len(pcm_bytes) % 2 != 0:
                    pcm_bytes = pcm_bytes[:-1]
                if len(pcm_bytes) > 0:
                    audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
                    audio = audio_int16.astype(np.float32) / 32768.0
                    stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
                    stats["total_bytes"] = len(pcm_bytes)
            
            if stats.get("success") and len(audio) > 0:
                if stats.get("client_ttfa_ms") is not None:
                    send_time = stats.get("client_send_time_ms") or 0
                    net_proc = stats.get("client_network_processing_ms") or 0
                    print(f"Stream {stream_id} [{voice}->ws]: cliTTFA={stats['client_ttfa_ms']:.1f}ms (send={send_time:.1f}ms, net+proc={net_proc:.1f}ms)")
            
            return audio, stats
        
        finally:
            # Cleanup
            self._active_requests.pop(request_id, None)
            self._completion_events.pop(request_id, None)
            self._audio_buffers.pop(request_id, None)
            # Clean up server ID mapping
            for server_id, client_id in list(self._server_id_to_client_id.items()):
                if client_id == request_id:
                    self._server_id_to_client_id.pop(server_id, None)
            self._client_id_to_server_id.pop(request_id, None)

    async def submit_streaming_session(
        self,
        deltas: List[str],
        voice: str,
        stream_id: int,
        request_start_time: float,
        chunk_mode: Optional[str] = None,
        timeout_sec: float = 0,
    ) -> Tuple[np.ndarray, dict]:
        """
        Submit a logical stream as multiple incremental updates (start → continue → end+flush).
        Each update has its own request_id; server uses shared stream_id for session state.
        Returns one (audio, stats) per stream: TTFA from first update, total time to last done,
        server timing from first update, audio = concatenation of all update audio.
        timeout_sec: wait timeout for all deltas; 0 = use scaled formula max(60, 30+6*num_deltas).
        """
        # if not self._use_streaming_endpoint:
        #     raise RuntimeError("submit_streaming_session requires streaming endpoint URL")
        if not deltas:
            empty = np.array([], dtype=np.float32)
            return empty, {"success": False, "error": "empty deltas", "voice": voice}

        stream_id_str = str(stream_id)
        all_pcm: List[bytes] = []
        stream_stats = {
            "voice": voice,
            "client_ttfa_ms": None,
            "client_send_time_ms": None,
            "client_network_processing_ms": None,
            "server_prefill_ms": None,
            "server_decode_ready_ms": None,
            "server_token_accum_ms": None,
            "server_first_audio_ms": None,
            "server_first_audio_ready_ms": None,
            "server_first_audio_enqueued_ms": None,
            "server_first_audio_sent_ms": None,
            "server_tensor_ms": None,
            "server_batch_wait_ms": None,
            "server_gpu_ms": None,
            "server_cpu_ms": None,
            "server_batch_size": None,
            "gateway_send_ms": None,
            "gateway_ttfa_ms": None,
            "gateway_net_proc_ms": None,
            "total_ms": 0,
            "audio_duration_s": 0,
            "total_bytes": 0,
            "worker_id": "ws",
            "success": False,
            "request_start": request_start_time,
        }

        # 1. Register all requests for this stream up front (ordered list for send/assemble order)
        stream_request_ids: List[str] = []
        for idx, text in enumerate(deltas):
            self._request_id_counter += 1
            request_id = f"req_{self._request_id_counter}"
            completion_event = asyncio.Event()
            stats = {
                "voice": voice,
                "request_start": request_start_time,
                "client_ttfa_ms": None,
                "first_audio_received": None,
                "send_complete_time": None,
                "success": False,
            }
            self._active_requests[request_id] = stats
            self._completion_events[request_id] = completion_event
            self._audio_buffers[request_id] = []
            stream_request_ids.append(request_id)

        try:
            # 2. Send all deltas without awaiting "done" between sends
            for idx, text in enumerate(deltas):
                request_id = stream_request_ids[idx]
                is_first = idx == 0
                is_last = idx == len(deltas) - 1
                action = "start" if is_first else ("end" if is_last else "continue")
                request_data = {
                    "request_id": request_id,
                    "prompt": text,
                    "voice": voice,
                    "max_tokens": 3000,
                    "temperature": 1.0,
                    "repetition_penalty": 1.1,
                    "stream_id": stream_id_str,
                    "stream_action": action,
                }
                if is_last:
                    request_data["flush"] = True
                if chunk_mode is not None:
                    request_data["chunk_mode"] = chunk_mode
                await self.ws.send(json.dumps(request_data))
                stats = self._active_requests[request_id]
                stats["send_complete_time"] = time.perf_counter()
                if is_first:
                    stream_stats["client_send_time_ms"] = (stats["send_complete_time"] - request_start_time) * 1000

            # 3. Wait for all requests in this stream to complete
            wait_timeout = timeout_sec if timeout_sec > 0 else max(60.0, 30.0 + 6.0 * len(stream_request_ids))
            try:
                await asyncio.wait_for(
                    asyncio.gather(*[self._completion_events[rid].wait() for rid in stream_request_ids]),
                    timeout=wait_timeout,
                )
            except asyncio.TimeoutError:
                stream_stats["error"] = "Timeout waiting for completion"
                stream_stats["success"] = False

            # 4. Build all_pcm in request order (first delta ... last delta)
            for request_id in stream_request_ids:
                if request_id in self._audio_buffers and self._audio_buffers[request_id]:
                    all_pcm.append(b"".join(self._audio_buffers[request_id]))

            # 5. Compute stream-level stats
            # Client TTFA: min of client_ttfa_ms among requests that received first audio
            for rid in stream_request_ids:
                s = self._active_requests.get(rid)
                if s and s.get("first_audio_received") and s.get("client_ttfa_ms") is not None:
                    ttfa = s["client_ttfa_ms"]
                    if stream_stats["client_ttfa_ms"] is None or ttfa < stream_stats["client_ttfa_ms"]:
                        stream_stats["client_ttfa_ms"] = ttfa
            if stream_stats["client_ttfa_ms"] is not None:
                send_ms = stream_stats.get("client_send_time_ms") or 0
                stream_stats["client_network_processing_ms"] = stream_stats["client_ttfa_ms"] - send_ms
            # Server timing from the request that produced first audio (has real timing; first request often has timing: {})
            for rid in stream_request_ids:
                s = self._active_requests.get(rid)
                if s and s.get("first_audio_received") and s.get("server_first_audio_ms") is not None:
                    stream_stats["server_prefill_ms"] = s.get("server_prefill_ms")
                    stream_stats["server_decode_ready_ms"] = s.get("server_decode_ready_ms")
                    stream_stats["server_token_accum_ms"] = s.get("server_token_accum_ms")
                    stream_stats["server_first_audio_ms"] = s.get("server_first_audio_ms")
                    stream_stats["server_first_audio_ready_ms"] = s.get("server_first_audio_ready_ms")
                    stream_stats["server_first_audio_enqueued_ms"] = s.get("server_first_audio_enqueued_ms")
                    stream_stats["server_first_audio_sent_ms"] = s.get("server_first_audio_sent_ms")
                    stream_stats["server_outbound_delay_ms"] = s.get("server_outbound_delay_ms")
                    stream_stats["server_tensor_ms"] = s.get("server_tensor_ms")
                    stream_stats["server_batch_wait_ms"] = s.get("server_batch_wait_ms")
                    stream_stats["server_gpu_ms"] = s.get("server_gpu_ms")
                    stream_stats["server_cpu_ms"] = s.get("server_cpu_ms")
                    stream_stats["server_batch_size"] = s.get("server_batch_size")
                    stream_stats["gateway_send_ms"] = s.get("gateway_send_ms")
                    stream_stats["gateway_ttfa_ms"] = s.get("gateway_ttfa_ms")
                    stream_stats["gateway_net_proc_ms"] = s.get("gateway_net_proc_ms")
                    break
            for rid in stream_request_ids:
                if self._active_requests.get(rid, {}).get("success"):
                    stream_stats["success"] = True
                    break
            stream_stats["total_ms"] = (time.perf_counter() - request_start_time) * 1000
        finally:
            # 6. Clean up all stream requests
            for request_id in stream_request_ids:
                self._active_requests.pop(request_id, None)
                self._completion_events.pop(request_id, None)
                self._audio_buffers.pop(request_id, None)
                for sid, cid in list(self._server_id_to_client_id.items()):
                    if cid == request_id:
                        self._server_id_to_client_id.pop(sid, None)
                self._client_id_to_server_id.pop(request_id, None)

        # Build single audio array and final stream stats
        audio = np.array([], dtype=np.float32)
        if all_pcm:
            pcm_bytes = b"".join(all_pcm)
            if len(pcm_bytes) % 2 != 0:
                pcm_bytes = pcm_bytes[:-1]
            if len(pcm_bytes) > 0:
                audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
                audio = audio_int16.astype(np.float32) / 32768.0
                stream_stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
                stream_stats["total_bytes"] = len(pcm_bytes)

        if stream_stats.get("success") and len(audio) > 0 and stream_stats.get("client_ttfa_ms") is not None:
            send_time = stream_stats.get("client_send_time_ms") or 0
            net_proc = stream_stats.get("client_network_processing_ms") or 0
            print(
                f"Stream {stream_id} [{voice}->ws]: cliTTFA={stream_stats['client_ttfa_ms']:.1f}ms "
                f"(send={send_time:.1f}ms, net+proc={net_proc:.1f}ms)"
            )
        return audio, stream_stats

    async def submit_streaming_session_interleaved(
        self,
        deltas: List[str],
        voice: str,
        stream_id: int,
        request_start_time: float,
        chunk_mode: Optional[str] = None,
        timeout_sec: float = 0,
    ) -> Tuple[np.ndarray, dict]:
        """
        Same as submit_streaming_session but enqueues deltas to the connection's
        priority send queue so that (delta_index, stream_id) order sends all streams'
        first deltas before any second deltas. chunk_mode is included in each request.
        """
        # if not self._use_streaming_endpoint:
        #     raise RuntimeError("submit_streaming_session_interleaved requires streaming endpoint URL")
        if not deltas:
            empty = np.array([], dtype=np.float32)
            return empty, {"success": False, "error": "empty deltas", "voice": voice}

        stream_id_str = str(stream_id)
        all_pcm: List[bytes] = []
        stream_stats = {
            "voice": voice,
            "client_ttfa_ms": None,
            "client_send_time_ms": None,
            "client_network_processing_ms": None,
            "server_prefill_ms": None,
            "server_decode_ready_ms": None,
            "server_token_accum_ms": None,
            "server_first_audio_ms": None,
            "server_first_audio_ready_ms": None,
            "server_first_audio_enqueued_ms": None,
            "server_first_audio_sent_ms": None,
            "server_tensor_ms": None,
            "server_batch_wait_ms": None,
            "server_gpu_ms": None,
            "server_cpu_ms": None,
            "server_batch_size": None,
            "gateway_send_ms": None,
            "gateway_ttfa_ms": None,
            "gateway_net_proc_ms": None,
            "total_ms": 0,
            "audio_duration_s": 0,
            "total_bytes": 0,
            "worker_id": "ws",
            "success": False,
            "request_start": request_start_time,
        }

        # 1. Register all requests for this stream up front (ordered list for send/assemble order)
        stream_request_ids: List[str] = []
        for idx, text in enumerate(deltas):
            self._request_id_counter += 1
            request_id = f"req_{self._request_id_counter}"
            completion_event = asyncio.Event()
            stats = {
                "voice": voice,
                "request_start": request_start_time,
                "client_ttfa_ms": None,
                "first_audio_received": None,
                "send_complete_time": None,
                "success": False,
            }
            self._active_requests[request_id] = stats
            self._completion_events[request_id] = completion_event
            self._audio_buffers[request_id] = []
            stream_request_ids.append(request_id)

        try:
            # 2. Enqueue all deltas to the priority send heap (delta_index, stream_id) for interleaving
            async with self._send_lock:
                for idx, text in enumerate(deltas):
                    request_id = stream_request_ids[idx]
                    is_first = idx == 0
                    is_last = idx == len(deltas) - 1
                    action = "start" if is_first else ("end" if is_last else "continue")
                    request_data = {
                        "request_id": request_id,
                        "prompt": text,
                        "voice": voice,
                        "max_tokens": 3000,
                        "temperature": 1.0,
                        "repetition_penalty": 1.1,
                        "stream_id": stream_id_str,
                        "stream_action": action,
                    }
                    if is_last:
                        request_data["flush"] = True
                    if chunk_mode is not None:
                        request_data["chunk_mode"] = chunk_mode
                    payload_str = json.dumps(request_data)
                    stats = self._active_requests[request_id]
                    # Heap key (delta_index, stream_id) so all index-0 then all index-1, etc.
                    heapq.heappush(
                        self._send_heap,
                        (idx, stream_id, payload_str, request_id, stats, is_first, stream_stats),
                    )
                self._send_event.set()

            # 3. Wait for all requests in this stream to complete
            wait_timeout = timeout_sec if timeout_sec > 0 else max(60.0, 30.0 + 6.0 * len(stream_request_ids))
            try:
                await asyncio.wait_for(
                    asyncio.gather(*[self._completion_events[rid].wait() for rid in stream_request_ids]),
                    timeout=wait_timeout,
                )
            except asyncio.TimeoutError:
                stream_stats["error"] = "Timeout waiting for completion"
                stream_stats["success"] = False

            # 4. Build all_pcm in request order (first delta ... last delta)
            for request_id in stream_request_ids:
                if request_id in self._audio_buffers and self._audio_buffers[request_id]:
                    all_pcm.append(b"".join(self._audio_buffers[request_id]))

            # 5. Compute stream-level stats (same as submit_streaming_session)
            for rid in stream_request_ids:
                s = self._active_requests.get(rid)
                if s and s.get("first_audio_received") and s.get("client_ttfa_ms") is not None:
                    ttfa = s["client_ttfa_ms"]
                    if stream_stats["client_ttfa_ms"] is None or ttfa < stream_stats["client_ttfa_ms"]:
                        stream_stats["client_ttfa_ms"] = ttfa
            if stream_stats["client_ttfa_ms"] is not None:
                send_ms = stream_stats.get("client_send_time_ms") or 0
                stream_stats["client_network_processing_ms"] = stream_stats["client_ttfa_ms"] - send_ms
            for rid in stream_request_ids:
                s = self._active_requests.get(rid)
                if s and s.get("first_audio_received") and s.get("server_first_audio_ms") is not None:
                    stream_stats["server_prefill_ms"] = s.get("server_prefill_ms")
                    stream_stats["server_decode_ready_ms"] = s.get("server_decode_ready_ms")
                    stream_stats["server_token_accum_ms"] = s.get("server_token_accum_ms")
                    stream_stats["server_first_audio_ms"] = s.get("server_first_audio_ms")
                    stream_stats["server_first_audio_ready_ms"] = s.get("server_first_audio_ready_ms")
                    stream_stats["server_first_audio_enqueued_ms"] = s.get("server_first_audio_enqueued_ms")
                    stream_stats["server_first_audio_sent_ms"] = s.get("server_first_audio_sent_ms")
                    stream_stats["server_outbound_delay_ms"] = s.get("server_outbound_delay_ms")
                    stream_stats["server_tensor_ms"] = s.get("server_tensor_ms")
                    stream_stats["server_batch_wait_ms"] = s.get("server_batch_wait_ms")
                    stream_stats["server_gpu_ms"] = s.get("server_gpu_ms")
                    stream_stats["server_cpu_ms"] = s.get("server_cpu_ms")
                    stream_stats["server_batch_size"] = s.get("server_batch_size")
                    stream_stats["gateway_send_ms"] = s.get("gateway_send_ms")
                    stream_stats["gateway_ttfa_ms"] = s.get("gateway_ttfa_ms")
                    stream_stats["gateway_net_proc_ms"] = s.get("gateway_net_proc_ms")
                    break
            for rid in stream_request_ids:
                if self._active_requests.get(rid, {}).get("success"):
                    stream_stats["success"] = True
                    break
            stream_stats["total_ms"] = (time.perf_counter() - request_start_time) * 1000
        finally:
            # 6. Clean up all stream requests
            for request_id in stream_request_ids:
                self._active_requests.pop(request_id, None)
                self._completion_events.pop(request_id, None)
                self._audio_buffers.pop(request_id, None)
                for sid, cid in list(self._server_id_to_client_id.items()):
                    if cid == request_id:
                        self._server_id_to_client_id.pop(sid, None)
                self._client_id_to_server_id.pop(request_id, None)

        # Build single audio array and final stream stats
        audio = np.array([], dtype=np.float32)
        if all_pcm:
            pcm_bytes = b"".join(all_pcm)
            if len(pcm_bytes) % 2 != 0:
                pcm_bytes = pcm_bytes[:-1]
            if len(pcm_bytes) > 0:
                audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
                audio = audio_int16.astype(np.float32) / 32768.0
                stream_stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
                stream_stats["total_bytes"] = len(pcm_bytes)

        if stream_stats.get("success") and len(audio) > 0 and stream_stats.get("client_ttfa_ms") is not None:
            send_time = stream_stats.get("client_send_time_ms") or 0
            net_proc = stream_stats.get("client_network_processing_ms") or 0
            print(
                f"Stream {stream_id} [{voice}->ws]: cliTTFA={stream_stats['client_ttfa_ms']:.1f}ms "
                f"(send={send_time:.1f}ms, net+proc={net_proc:.1f}ms)"
            )
        return audio, stream_stats


# =============================================================================
# WebSocket Connection Pool
# =============================================================================

class WebSocketPool:
    """
    Pool of pre-established multiplexed WebSocket connections for low-latency benchmarking.
    Each connection can handle multiple concurrent requests via reference counting.
    Connections are opened upfront to exclude handshake time from measurements.
    """
    
    def __init__(self, ws_url: str, pool_size: int, additional_headers: dict[str, str] | None = None):
        self.ws_url = ws_url
        self.pool_size = pool_size
        self.additional_headers = additional_headers
        self._clients: List[MultiplexedWebSocketClient] = []
        self._ref_counts: Dict[MultiplexedWebSocketClient, int] = {}
        self._lock = asyncio.Lock()
        self._active_target = 10  # Start with one shared socket
        self._send_times_ms = deque(maxlen=64)
        self._high_send_ms = 25.0
        self._low_send_ms = 8.0
    
    async def initialize(self):
        """Pre-establish all WebSocket connections."""
        if websockets is None:
            raise ImportError("websockets package required for WebSocket mode. Install with: pip install websockets")
        
        print(f"Pre-establishing {self.pool_size} multiplexed WebSocket connections...")
        
        # Create connections in parallel for faster startup
        async def create_connection(idx: int):
            try:
                client = MultiplexedWebSocketClient(self.ws_url, additional_headers=self.additional_headers)
                await client.connect()
                return client
            except Exception as e:
                print(f"  Connection {idx} failed: {e}")
                return None
        
        tasks = [create_connection(i) for i in range(self.pool_size)]
        clients = await asyncio.gather(*tasks)
        
        successful = 0
        async with self._lock:
            for client in clients:
                if client is not None:
                    self._clients.append(client)
                    self._ref_counts[client] = 0
                    successful += 1
            if successful > 0:
                self._active_target = 1
        
        print(f"  {successful}/{self.pool_size} connections established")
        if successful == 0:
            raise RuntimeError("Failed to establish any WebSocket connections")
    
    async def acquire(self) -> MultiplexedWebSocketClient:
        """
        Get a connection from the active subset of the pool.
        Starts with one socket and scales active sockets only when contention is high.
        """
        async with self._lock:
            if not self._clients:
                raise RuntimeError("No connections available in pool")

            # Remove dead connections
            for client in list(self._clients):
                if not client._connected:
                    self._clients.remove(client)
                    self._ref_counts.pop(client, None)

            if not self._clients:
                raise RuntimeError("No connections available in pool")

            self._active_target = max(1, min(self._active_target, len(self._clients)))
            active_clients = self._clients[:self._active_target]
            client = min(active_clients, key=lambda c: self._ref_counts.get(c, 0))
            self._ref_counts[client] = self._ref_counts.get(client, 0) + 1
            return client

    async def observe_request(self, stats: dict):
        """
        Adapt the active socket count from measured send contention.
        Keeps socket usage minimal by default, adds sockets only under pressure.
        """
        send_ms = stats.get("client_send_time_ms")
        if send_ms is None:
            return

        async with self._lock:
            self._send_times_ms.append(float(send_ms))
            if len(self._send_times_ms) < 8:
                return

            avg_send = sum(self._send_times_ms) / len(self._send_times_ms)
            max_target = len(self._clients)
            if max_target == 0:
                return

            if avg_send > self._high_send_ms and self._active_target < max_target:
                self._active_target += 1
                print(f"WS pool scale up: active sockets {self._active_target}/{max_target} (avg send {avg_send:.1f}ms)")
            elif avg_send < self._low_send_ms and self._active_target > 1:
                # Scale down only if extra sockets are idle.
                can_scale_down = True
                for client in self._clients[self._active_target - 1:]:
                    if self._ref_counts.get(client, 0) > 0:
                        can_scale_down = False
                        break
                if can_scale_down:
                    self._active_target -= 1
                    print(f"WS pool scale down: active sockets {self._active_target}/{max_target} (avg send {avg_send:.1f}ms)")
    
    async def release(self, client: MultiplexedWebSocketClient):
        """
        Release a connection reference. The connection remains in the pool
        and can be reused by other requests.
        """
        async with self._lock:
            if client in self._ref_counts:
                self._ref_counts[client] = max(0, self._ref_counts[client] - 1)
                # If connection is dead, remove it
                if not client._connected:
                    if client in self._clients:
                        self._clients.remove(client)
                    self._ref_counts.pop(client, None)
    
    async def close_all(self):
        """Close all connections in the pool."""
        async with self._lock:
            for client in self._clients:
                try:
                    await client.close()
                except Exception:
                    pass
            self._clients.clear()
            self._ref_counts.clear()


# =============================================================================
# WebSocket TTS Streaming
# =============================================================================

async def stream_tts_websocket(
    ws_pool: WebSocketPool,
    prompt: str,
    voice: str,
    stream_id: int,
    use_streaming: bool = False,
    chunk_mode: Optional[str] = None,
    streaming_timeout_sec: float = 0,
    interleave_first_deltas: bool = True,
) -> Tuple[np.ndarray, dict]:
    """
    Stream audio from multiplexed TTS WebSocket endpoint using a pre-established connection.
    Returns raw PCM (int16, 48000 Hz, mono).

    When use_streaming is True, the prompt is split into 5–15 incremental deltas and sent
    as a streaming session (start → continue → end+flush); one (audio, stats) per logical stream.
    If interleave_first_deltas is True, deltas are enqueued so all streams' first deltas are sent
    before any second deltas (improves Cli Net+Proc when multiple streams share a connection).
    Timing starts AFTER acquiring connection (excludes handshake, includes send lock wait).
    streaming_timeout_sec: when use_streaming, timeout for whole stream; 0 = scaled (30+6*num_deltas).
    """
    client = None

    try:
        # Acquire pre-established multiplexed connection from pool
        client = await ws_pool.acquire()

        # Start timing RIGHT AFTER acquiring WebSocket (not after send lock)
        request_start_time = time.perf_counter()

        if use_streaming:
            deltas = generate_transcript_deltas(prompt)
            if interleave_first_deltas:
                audio, stats = await client.submit_streaming_session_interleaved(
                    deltas, voice, stream_id, request_start_time,
                    chunk_mode=chunk_mode,
                    timeout_sec=streaming_timeout_sec,
                )
            else:
                audio, stats = await client.submit_streaming_session(
                    deltas, voice, stream_id, request_start_time,
                    chunk_mode=chunk_mode,
                    timeout_sec=streaming_timeout_sec,
                )
        else:
            audio, stats = await client.submit_request(prompt, voice, stream_id, request_start_time)
        await ws_pool.observe_request(stats)
        
        # Print final timing if successful
        if stats.get("success") and len(audio) > 0:
            prefill = stats.get("server_prefill_ms") or 0
            srv_ttfa = stats.get("server_first_audio_sent_ms") or stats.get("server_first_audio_ms") or 0
            gpu = stats.get("server_gpu_ms") or 0
            outbound = stats.get("server_outbound_delay_ms")
            outbound_str = f", srvOutbound={outbound:.1f}ms" if outbound is not None else ""
            print(f"Stream {stream_id} [{voice}]: Finished | {stats.get('audio_duration_s', 0):.2f}s audio | {stats.get('total_ms', 0):.0f}ms total | prefill={prefill:.1f}ms, gpu={gpu:.1f}ms, srvTTFA={srv_ttfa:.1f}ms{outbound_str}")
        
        return audio, stats
        
    except Exception as e:
        stats = {
            "voice": voice,
            "client_ttfa_ms": None,
            "total_ms": 0,
            "audio_duration_s": 0,
            "total_bytes": 0,
            "worker_id": "ws",
            "success": False,
            "error": str(e),
        }
        print(f"Stream {stream_id} [{voice}]: WebSocket error - {e}")
        return np.array([], dtype=np.float32), stats
    finally:
        # Return connection to pool
        if client is not None:
            await ws_pool.release(client)


# =============================================================================
# Health Check
# =============================================================================

async def check_health(client: httpx.AsyncClient, base_url: str) -> Tuple[bool, Optional[List[str]]]:
    """Check if server is healthy and get voice list."""
    health_url = base_url.rstrip("/") + "/health"
    try:
        response = await client.get(health_url, timeout=10.0)
        if response.status_code == 200:
            data = response.json()
            voices = data.get("voices", [])
            return True, voices
    except Exception as e:
        print(f"Health check failed: {e}")
    return False, None


# =============================================================================
# Main
# =============================================================================

async def main():
    parser = argparse.ArgumentParser(
        description="TTS Benchmark - test local, websocket, direct Baseten, or Canopy gateway",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Modes:
    local     - Local gateway /tts endpoint (HTTP streaming)
    websocket - Local gateway /ws/tts endpoint (WebSocket streaming, lowest latency)
    direct    - Per-LLM Baseten deployments directly
    gateway   - Canopy gateway API

Examples:
    python test_ben.py --mode local -n 10
    python test_ben.py --mode websocket -n 10 --ws-pool-size 32
    python test_ben.py --mode websocket -n 100 -c 16 --ws-pool-size 8
    python test_ben.py --mode direct -n 10 -c 4
    python test_ben.py --mode gateway -n 100 -c 8
        """
    )
    parser.add_argument("--mode", type=str, required=True, choices=["local", "websocket", "direct", "gateway"])
    parser.add_argument("-n", "--total", type=int, default=10, help="Total requests (default: 10)")
    parser.add_argument("-c", "--concurrency", type=int, default=4, help="Concurrent requests PER LLM (default: 4)")
    parser.add_argument("-s", "--stagger", type=float, default=10.0, help="Delay between requests in ms (default: 10)")
    parser.add_argument("-p", "--prompt", type=str, default=None, help="Custom prompt")
    parser.add_argument("-o", "--output-dir", type=str, default="./tts_benchmark_audio")
    parser.add_argument("--voice", type=str, default=None, help="Specific voice (default: round-robin across LLMs)")
    parser.add_argument("--local-url", type=str, default=LOCAL_GATEWAY_URL)
    parser.add_argument("--no-save", action="store_true")
    parser.add_argument("-l", "--llms", type=str, default=None, help="Comma-separated LLM numbers to target (e.g., '1,3' for llm1 and llm3)")
    parser.add_argument("--ws-pool-size", type=int, default=64, help="Number of WebSocket connections in pool (default: 64, only for websocket mode)")
    parser.add_argument("--streaming-timeout", type=int, default=90, help="Number of WebSocket connections in pool (default: 64, only for websocket mode)")
    parser.add_argument(
        "--use-streaming",
        action="store_true",
        help="(websocket mode) Use /ws/tts/multiplex/streaming for session-based streaming inference",
    )
    parser.add_argument(
        "--chunk-mode",
        type=str,
        default=None,
        choices=["single", "hybrid_1_then_2"],
        help="(websocket streaming only) Chunking strategy: single (one sentence at a time) or hybrid_1_then_2 (first sentence, then pairs); default server default",
    )
    parser.add_argument(
        "--no-interleave-first-deltas",
        action="store_true",
        help="(websocket streaming only) Disable interleaving first deltas across streams; use for A/B comparison",
    )
    args = parser.parse_args()

    if args.chunk_mode is not None and not args.use_streaming:
        parser.error("--chunk-mode requires --use-streaming")

    # Validate API key early
    api_key = get_api_key(args.mode)

    output_dir = Path(args.output_dir)
    if not args.no_save:
        output_dir.mkdir(exist_ok=True)

    # Filter LLMs if specified
    if args.llms:
        llm_nums = [int(x.strip()) for x in args.llms.split(",")]
        target_llm_names = {f"llm{n}" for n in llm_nums}
        filtered_llm_voices = [llm for llm in LLM_VOICES if llm["llm"] in target_llm_names]
        if not filtered_llm_voices:
            print(f"ERROR: No valid LLMs found for '{args.llms}'")
            print(f"Available: {[llm['llm'] for llm in LLM_VOICES]}")
            sys.exit(1)
    else:
        filtered_llm_voices = LLM_VOICES

    num_llms = len(filtered_llm_voices)
    max_concurrent = args.concurrency * num_llms

    # Validate websockets package for websocket mode
    if args.mode == "websocket" and websockets is None:
        print("ERROR: websockets package required for WebSocket mode")
        print("  pip install websockets")
        sys.exit(1)

    print("=" * 80)
    print("TTS BENCHMARK")
    print("=" * 80)
    print(f"Mode: {args.mode}")
    if args.mode == "local":
        print(f"Gateway URL: {args.local_url}/tts")
    elif args.mode == "websocket":
        ws_url = args.local_url.replace("http://", "ws://").replace("https://", "wss://")
        ws_path = "/ws/tts/multiplex/streaming" if args.use_streaming else "/ws/tts/multiplex"
        print(f"WebSocket URL: {ws_url}{ws_path}")
        print(f"WebSocket pool size: {args.ws_pool_size}")
        if args.use_streaming and args.chunk_mode is not None:
            print(f"Chunk mode: {args.chunk_mode}")
        if args.use_streaming and args.streaming_timeout > 0:
            print(f"Streaming timeout: {args.streaming_timeout}s (fixed)")
        elif args.use_streaming:
            print(f"Streaming timeout: scaled (30 + 6*num_deltas)s")
        print(f"Note: Using multiplexed endpoint (multiple requests per connection)")
        print(f"Note: Timing excludes WebSocket handshake (starts after sending request)")
    elif args.mode == "direct":
        print(f"Per-LLM Baseten endpoints ({num_llms} LLMs)")
        print(f"API Key: BASETEN_API_KEY ({api_key[:8]}...)")
    else:
        print(f"Gateway URL: {REMOTE_GATEWAY_URL}")
        print(f"API Key: CANOPY_GATEWAY_API_KEY ({api_key[:8]}...)")
    print(f"Total requests: {args.total}")
    print(f"Concurrent per LLM: {args.concurrency}")
    print(f"Max simultaneous: {max_concurrent}")
    print(f"Stagger: {args.stagger}ms")
    print("-" * 80)

    # High connection limits with httpx
    limits = httpx.Limits(
        max_keepalive_connections=200,
        max_connections=500,
        keepalive_expiry=60.0,
    )

    timeout = httpx.Timeout(
        timeout=300.0,
        connect=10.0,
        read=120.0,
    )

    async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
        # Health check for local and websocket modes
        if args.mode in ("local", "websocket"):
            print("Checking server health...")
            healthy, available_voices = await check_health(client, args.local_url)
            if healthy:
                print(f"Server is healthy, voices: {available_voices}")
            else:
                print("Health check failed (continuing anyway)")

        # Show LLM mapping
        print(f"\nLLM to endpoint mapping:")
        for llm_config in filtered_llm_voices:
            print(f"  {llm_config['llm']}: {llm_config['voices']}")
        print("-" * 80)

        # Create per-LLM semaphores (key difference from broken version!)
        llm_semaphores = {llm["llm"]: asyncio.Semaphore(args.concurrency) for llm in filtered_llm_voices}
        llm_to_voices = {llm["llm"]: llm["voices"] for llm in filtered_llm_voices}
        llm_names = list(llm_to_voices.keys())

        # For WebSocket mode: create connection pool BEFORE timing starts
        ws_pool = None
        if args.mode == "websocket":
            ws_path = "/ws/tts/multiplex/streaming" if args.use_streaming else "/ws/tts/multiplex"
            ws_path = ""
            ws_url = args.local_url.replace("http://", "ws://").replace("https://", "wss://") + ws_path
            print("here now")
            print(ws_url)
            # Each connection can handle multiple concurrent requests via multiplexing
            pool_size = args.ws_pool_size
            ws_url = "wss://model-wommpdzq.api.baseten.co/environments/production/websocket"
            # ws_url = "ws://34.133.213.99:8000/ws" # local gateway
            # ws_url = "ws://34.27.105.165:8000/ws"
            ws_pool = WebSocketPool(
                ws_url,
                pool_size=pool_size,
                additional_headers={"Authorization": "Api-Key w1DGCrwq.ORqYd44RSHMpdepQxQhVT9fIaUPfc8Gv"},
            )
            await ws_pool.initialize()
            if args.use_streaming:
                # ws_pool._active_target = max(1, min(pool_size, max_concurrent ))
                ws_pool._active_target = 1
                print(f"Streaming: active target set to {ws_pool._active_target} (max simultaneous)")
            print(f"Multiplexed WebSocket pool ready with {pool_size} pre-established connections")
            print("-" * 80)

        results = []
        results_lock = asyncio.Lock()
        completed_count = [0]
        start_time = time.perf_counter()

        async def run_request(stream_id: int, llm_name: str, stagger_delay_ms: float):
            """Run request with per-LLM semaphore control."""
            if stagger_delay_ms > 0:
                await asyncio.sleep(stagger_delay_ms / 1000)

            voice = args.voice if args.voice else random.choice(llm_to_voices[llm_name])

            # Use per-LLM semaphore
            async with llm_semaphores[llm_name]:
                prompt = args.prompt if args.prompt else make_unique_prompt(PROMPTS[stream_id % len(PROMPTS)])
                
                if args.mode == "websocket":
                    # WebSocket mode - use pre-established connection pool
                    result = await stream_tts_websocket(
                        ws_pool, prompt, voice, stream_id,
                        use_streaming=args.use_streaming,
                        chunk_mode=args.chunk_mode,
                        streaming_timeout_sec=args.streaming_timeout,
                        interleave_first_deltas=not args.no_interleave_first_deltas,
                    )
                else:
                    # HTTP modes (local, direct, gateway)
                    if args.mode == "local":
                        endpoint_url = f"{args.local_url}/tts"
                    elif args.mode == "direct":
                        endpoint_url = DIRECT_BASETEN_URL
                    else:  # gateway
                        endpoint_url = REMOTE_GATEWAY_URL
                    
                    result = await stream_tts(client, endpoint_url, prompt, voice, stream_id, api_key, args.mode)

                async with results_lock:
                    results.append(result)
                    completed_count[0] += 1
                    elapsed = time.perf_counter() - start_time
                    print(f"  [{completed_count[0]}/{args.total}] completed in {elapsed:.1f}s")

                return result

        # Distribute requests round-robin across LLMs
        tasks = []
        for i in range(args.total):
            llm_name = llm_names[i % num_llms]
            stagger_delay = i * args.stagger
            tasks.append(run_request(i, llm_name, stagger_delay))

        # Show distribution
        print(f"\nRequest distribution ({args.total} total):")
        dist = defaultdict(int)
        for i in range(args.total):
            dist[llm_names[i % num_llms]] += 1
        for llm_name in sorted(dist.keys()):
            print(f"  {llm_name}: {dist[llm_name]} requests")
        print()

        print(f"Starting {args.total} requests...")
        print()

        try:
            await asyncio.gather(*tasks)
        finally:
            # Clean up WebSocket pool
            if ws_pool:
                await ws_pool.close_all()

        total_time = time.perf_counter() - start_time
        print()
        print(f"All {args.total} requests completed in {total_time:.1f}s")
        print(f"Throughput: {args.total / total_time:.2f} requests/sec")

    # Process results
    print("-" * 80)
    all_stats = []

    for i, (audio, stats) in enumerate(results):
        all_stats.append(stats)
        if len(audio) > 0 and not args.no_save:
            voice = stats.get("voice", "unknown")
            worker = stats.get("worker_id", "unknown") or "unknown"
            filepath = output_dir / f"{args.mode}_{voice}_{worker}_{i}.wav"
            save_wav(audio, str(filepath))
            print(f"Saved: {filepath} ({stats.get('audio_duration_s', 0):.2f}s)")
        elif len(audio) == 0:
            print(f"Stream {i} [{stats.get('voice', '?')}]: No audio received")

    # Statistics
    print()
    print("=" * 80)
    print("PER-VOICE STATISTICS")
    print("=" * 80)

    voice_stats = defaultdict(list)
    for stats in all_stats:
        voice_stats[stats.get("voice", "unknown")].append(stats)

    for voice in sorted(voice_stats.keys()):
        stats_list = voice_stats[voice]
        successful = [s for s in stats_list if s.get("success")]
        print(f"\nVoice: {voice} ({len(successful)}/{len(stats_list)} successful)")
        print("-" * 60)
        workers = set(s.get("worker_id") for s in stats_list if s.get("worker_id"))
        if workers:
            print(f"  Worker(s): {', '.join(str(w) for w in workers)}")
        client_ttfas = [s.get("client_ttfa_ms") for s in successful if s.get("client_ttfa_ms")]
        client_send_times = [s.get("client_send_time_ms") for s in successful if s.get("client_send_time_ms")]
        client_network_processing = [s.get("client_network_processing_ms") for s in successful if s.get("client_network_processing_ms")]
        server_prefills = [s.get("server_prefill_ms") for s in successful if s.get("server_prefill_ms")]
        server_gpus = [s.get("server_gpu_ms") for s in successful if s.get("server_gpu_ms")]
        server_ttfas = [s.get("server_first_audio_ms") for s in successful if s.get("server_first_audio_ms")]
        gateway_send_times = [s.get("gateway_send_ms") for s in successful if s.get("gateway_send_ms") is not None]
        gateway_ttfas = [s.get("gateway_ttfa_ms") for s in successful if s.get("gateway_ttfa_ms") is not None]
        gateway_network_processing = [s.get("gateway_net_proc_ms") for s in successful if s.get("gateway_net_proc_ms") is not None]
        server_outbound_delays = [s.get("server_outbound_delay_ms") for s in successful if s.get("server_outbound_delay_ms") is not None]
        totals = [s.get("total_ms") for s in successful if s.get("total_ms")]
        durations = [s.get("audio_duration_s") for s in successful if s.get("audio_duration_s")]
        if client_ttfas:
            print(f"  Client TTFA:  {avg(client_ttfas):>7.1f}ms avg ({min(client_ttfas):>6.1f} - {max(client_ttfas):>6.1f}ms)")
        if client_send_times:
            print(f"  Cli Send:     {avg(client_send_times):>7.1f}ms avg ({min(client_send_times):>6.1f} - {max(client_send_times):>6.1f}ms)")
        if client_network_processing:
            print(f"  Cli Net+Proc: {avg(client_network_processing):>7.1f}ms avg ({min(client_network_processing):>6.1f} - {max(client_network_processing):>6.1f}ms)")
        if server_prefills:
            print(f"  Srv Prefill:  {avg(server_prefills):>7.1f}ms avg ({min(server_prefills):>6.1f} - {max(server_prefills):>6.1f}ms)")
        if server_gpus:
            print(f"  Srv GPU:      {avg(server_gpus):>7.1f}ms avg ({min(server_gpus):>6.1f} - {max(server_gpus):>6.1f}ms)")
        if server_ttfas:
            print(f"  Srv TTFA:     {avg(server_ttfas):>7.1f}ms avg ({min(server_ttfas):>6.1f} - {max(server_ttfas):>6.1f}ms)")
        if gateway_send_times:
            print(f"  Gateway Send: {avg(gateway_send_times):>7.1f}ms avg ({min(gateway_send_times):>6.1f} - {max(gateway_send_times):>6.1f}ms)")
        if gateway_ttfas:
            print(f"  Gateway TTFA: {avg(gateway_ttfas):>7.1f}ms avg ({min(gateway_ttfas):>6.1f} - {max(gateway_ttfas):>6.1f}ms)")
        if gateway_network_processing:
            print(f"  Gate Net+Proc: {avg(gateway_network_processing):>7.1f}ms avg ({min(gateway_network_processing):>6.1f} - {max(gateway_network_processing):>6.1f}ms)")
        if server_outbound_delays:
            print(f"  Srv Outbound: {avg(server_outbound_delays):>7.1f}ms avg ({min(server_outbound_delays):>6.1f} - {max(server_outbound_delays):>6.1f}ms)")
        if totals:
            print(f"  Total:        {avg(totals):>7.1f}ms avg ({min(totals):>6.1f} - {max(totals):>6.1f}ms)")
        if durations:
            print(f"  Audio:        {avg(durations):>7.2f}s  avg ({min(durations):>6.2f} - {max(durations):>6.2f}s)")
            rtfs = [(s.get("total_ms", 0) / 1000) / s.get("audio_duration_s", 1)
                    for s in successful if s.get("audio_duration_s", 0) > 0]
            if rtfs:
                print(f"  RTF:          {avg(rtfs):>7.2f}x  avg ({min(rtfs):>6.2f} - {max(rtfs):>6.2f}x)")

    # Overall
    print()
    print("=" * 180)
    print("OVERALL TIMING ANALYSIS")
    print("=" * 180)
    print()
    print(f"{'#':>3} {'Voice':>15} {'Wkr':>4} {'cliTTFA':>8} {'Prefill':>8} {'TokAcc':>8} {'Tensor':>7} {'Batch':>7} {'GPU':>7} {'CPU':>6} {'srvTTFA':>8} {'Total':>8} {'Audio':>6} {'RTF':>5} {'BS':>3}")
    print("-" * 180)

    all_client_ttfa = []
    all_client_send_time = []
    all_client_network_processing = []
    all_server_prefill = []
    all_server_token_accum = []
    all_server_tensor = []
    all_server_batch_wait = []
    all_server_gpu = []
    all_server_cpu = []
    all_server_ttfa = []
    all_gateway_send_time = []
    all_gateway_ttfa = []
    all_gateway_network_processing = []
    all_server_outbound_delay = []
    all_totals = []
    all_rtfs = []
    all_durations = []

    for i, stats in enumerate(all_stats):
        voice = stats.get("voice", "?")[:15]
        worker = (stats.get("worker_id") or "?")[:4]
        client_ttfa = stats.get("client_ttfa_ms") or 0
        server_prefill = stats.get("server_prefill_ms") or 0
        server_token_accum = stats.get("server_token_accum_ms") or 0
        server_tensor = stats.get("server_tensor_ms") or 0
        server_batch_wait = stats.get("server_batch_wait_ms") or 0
        server_gpu = stats.get("server_gpu_ms") or 0
        server_cpu = stats.get("server_cpu_ms") or 0
        server_ttfa = stats.get("server_first_audio_ms") or 0
        batch_size = stats.get("server_batch_size") or 0
        total = stats.get("total_ms") or 0
        if args.use_streaming and total > STREAMING_RTF_CAP_MS:
            total = STREAMING_RTF_CAP_MS  # cap so one slow stream doesn't blow Total/RTF stats
        audio_duration = stats.get("audio_duration_s") or 0
        rtf = (total / 1000) / audio_duration if audio_duration > 0 else 0

        if stats.get("success"):
            all_client_ttfa.append(client_ttfa)
            client_send_time = stats.get("client_send_time_ms")
            if client_send_time: all_client_send_time.append(client_send_time)
            client_net_proc = stats.get("client_network_processing_ms")
            if client_net_proc: all_client_network_processing.append(client_net_proc)
            if server_prefill > 0: all_server_prefill.append(server_prefill)
            if server_token_accum > 0: all_server_token_accum.append(server_token_accum)
            if server_tensor > 0: all_server_tensor.append(server_tensor)
            if server_batch_wait > 0: all_server_batch_wait.append(server_batch_wait)
            if server_gpu > 0: all_server_gpu.append(server_gpu)
            if server_cpu > 0: all_server_cpu.append(server_cpu)
            if server_ttfa > 0: all_server_ttfa.append(server_ttfa)
            gateway_send = stats.get("gateway_send_ms")
            if gateway_send is not None: all_gateway_send_time.append(gateway_send)
            gateway_ttfa = stats.get("gateway_ttfa_ms")
            if gateway_ttfa is not None: all_gateway_ttfa.append(gateway_ttfa)
            gateway_net_proc = stats.get("gateway_net_proc_ms")
            if gateway_net_proc is not None: all_gateway_network_processing.append(gateway_net_proc)
            server_outbound = stats.get("server_outbound_delay_ms")
            if server_outbound is not None: all_server_outbound_delay.append(server_outbound)
            all_totals.append(total)
            all_durations.append(audio_duration)
            if audio_duration > 0:
                all_rtfs.append(rtf)
            print(f"{i:>3} {voice:>15} {worker:>4} {client_ttfa:>7.1f}ms {server_prefill:>7.1f}ms {server_token_accum:>7.1f}ms {server_tensor:>6.1f}ms {server_batch_wait:>6.1f}ms {server_gpu:>6.1f}ms {server_cpu:>5.1f}ms {server_ttfa:>7.1f}ms {total:>7.0f}ms {audio_duration:>5.2f}s {rtf:>4.2f}x {batch_size:>3}")
        else:
            print(f"{i:>3} {voice:>15} {worker:>4} {'FAILED':<130}")

    print()
    print("=" * 180)
    print("AGGREGATE SUMMARY")
    print("=" * 180)
    print()
    print(f"  Test parameters: n={args.total}, concurrency={args.concurrency}/LLM ({args.concurrency * num_llms} global), stagger={args.stagger}ms")
    if args.use_streaming:
        print(f"  (Streaming: Total/RTF capped at {STREAMING_RTF_CAP_MS/1000:.0f}s for aggregate stats)")
    print()

    successful = sum(1 for s in all_stats if s.get("success"))
    print(f"  Requests:       {successful}/{len(all_stats)} successful")
    print()

    if all_client_ttfa:
        print(f"  {'Metric':<14} {'Avg':>10} {'Min':>10} {'p50':>10} {'p90':>10} {'p95':>10} {'p99':>10} {'Max':>10}")
        print(f"  {'-'*14} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10}")
        print(f"  {'Client TTFA':<14} {avg(all_client_ttfa):>9.1f}ms {min(all_client_ttfa):>9.1f}ms {percentile(all_client_ttfa, 50):>9.1f}ms {percentile(all_client_ttfa, 90):>9.1f}ms {percentile(all_client_ttfa, 95):>9.1f}ms {percentile(all_client_ttfa, 99):>9.1f}ms {max(all_client_ttfa):>9.1f}ms")
        if all_client_send_time:
            print(f"  {'Cli Send':<14} {avg(all_client_send_time):>9.1f}ms {min(all_client_send_time):>9.1f}ms {percentile(all_client_send_time, 50):>9.1f}ms {percentile(all_client_send_time, 90):>9.1f}ms {percentile(all_client_send_time, 95):>9.1f}ms {percentile(all_client_send_time, 99):>9.1f}ms {max(all_client_send_time):>9.1f}ms")
        if all_client_network_processing:
            print(f"  {'Cli Net+Proc':<14} {avg(all_client_network_processing):>9.1f}ms {min(all_client_network_processing):>9.1f}ms {percentile(all_client_network_processing, 50):>9.1f}ms {percentile(all_client_network_processing, 90):>9.1f}ms {percentile(all_client_network_processing, 95):>9.1f}ms {percentile(all_client_network_processing, 99):>9.1f}ms {max(all_client_network_processing):>9.1f}ms")
        if all_server_prefill:
            print(f"  {'Srv Prefill':<14} {avg(all_server_prefill):>9.1f}ms {min(all_server_prefill):>9.1f}ms {percentile(all_server_prefill, 50):>9.1f}ms {percentile(all_server_prefill, 90):>9.1f}ms {percentile(all_server_prefill, 95):>9.1f}ms {percentile(all_server_prefill, 99):>9.1f}ms {max(all_server_prefill):>9.1f}ms")
        if all_server_token_accum:
            print(f"  {'Srv TokAccum':<14} {avg(all_server_token_accum):>9.1f}ms {min(all_server_token_accum):>9.1f}ms {percentile(all_server_token_accum, 50):>9.1f}ms {percentile(all_server_token_accum, 90):>9.1f}ms {percentile(all_server_token_accum, 95):>9.1f}ms {percentile(all_server_token_accum, 99):>9.1f}ms {max(all_server_token_accum):>9.1f}ms")
        if all_server_tensor:
            print(f"  {'Srv Tensor':<14} {avg(all_server_tensor):>9.1f}ms {min(all_server_tensor):>9.1f}ms {percentile(all_server_tensor, 50):>9.1f}ms {percentile(all_server_tensor, 90):>9.1f}ms {percentile(all_server_tensor, 95):>9.1f}ms {percentile(all_server_tensor, 99):>9.1f}ms {max(all_server_tensor):>9.1f}ms")
        if all_server_batch_wait:
            print(f"  {'Srv BatchWait':<14} {avg(all_server_batch_wait):>9.1f}ms {min(all_server_batch_wait):>9.1f}ms {percentile(all_server_batch_wait, 50):>9.1f}ms {percentile(all_server_batch_wait, 90):>9.1f}ms {percentile(all_server_batch_wait, 95):>9.1f}ms {percentile(all_server_batch_wait, 99):>9.1f}ms {max(all_server_batch_wait):>9.1f}ms")
        if all_server_gpu:
            print(f"  {'Srv GPU':<14} {avg(all_server_gpu):>9.1f}ms {min(all_server_gpu):>9.1f}ms {percentile(all_server_gpu, 50):>9.1f}ms {percentile(all_server_gpu, 90):>9.1f}ms {percentile(all_server_gpu, 95):>9.1f}ms {percentile(all_server_gpu, 99):>9.1f}ms {max(all_server_gpu):>9.1f}ms")
        if all_server_cpu:
            print(f"  {'Srv CPU':<14} {avg(all_server_cpu):>9.1f}ms {min(all_server_cpu):>9.1f}ms {percentile(all_server_cpu, 50):>9.1f}ms {percentile(all_server_cpu, 90):>9.1f}ms {percentile(all_server_cpu, 95):>9.1f}ms {percentile(all_server_cpu, 99):>9.1f}ms {max(all_server_cpu):>9.1f}ms")
        if all_server_ttfa:
            print(f"  {'Srv TTFA':<14} {avg(all_server_ttfa):>9.1f}ms {min(all_server_ttfa):>9.1f}ms {percentile(all_server_ttfa, 50):>9.1f}ms {percentile(all_server_ttfa, 90):>9.1f}ms {percentile(all_server_ttfa, 95):>9.1f}ms {percentile(all_server_ttfa, 99):>9.1f}ms {max(all_server_ttfa):>9.1f}ms")
        if all_gateway_send_time:
            print(f"  {'Gateway Send':<14} {avg(all_gateway_send_time):>9.1f}ms {min(all_gateway_send_time):>9.1f}ms {percentile(all_gateway_send_time, 50):>9.1f}ms {percentile(all_gateway_send_time, 90):>9.1f}ms {percentile(all_gateway_send_time, 95):>9.1f}ms {percentile(all_gateway_send_time, 99):>9.1f}ms {max(all_gateway_send_time):>9.1f}ms")
        if all_gateway_ttfa:
            print(f"  {'Gateway TTFA':<14} {avg(all_gateway_ttfa):>9.1f}ms {min(all_gateway_ttfa):>9.1f}ms {percentile(all_gateway_ttfa, 50):>9.1f}ms {percentile(all_gateway_ttfa, 90):>9.1f}ms {percentile(all_gateway_ttfa, 95):>9.1f}ms {percentile(all_gateway_ttfa, 99):>9.1f}ms {max(all_gateway_ttfa):>9.1f}ms")
        if all_gateway_network_processing:
            print(f"  {'Gate Net+Proc':<14} {avg(all_gateway_network_processing):>9.1f}ms {min(all_gateway_network_processing):>9.1f}ms {percentile(all_gateway_network_processing, 50):>9.1f}ms {percentile(all_gateway_network_processing, 90):>9.1f}ms {percentile(all_gateway_network_processing, 95):>9.1f}ms {percentile(all_gateway_network_processing, 99):>9.1f}ms {max(all_gateway_network_processing):>9.1f}ms")
        if all_server_outbound_delay:
            print(f"  {'Srv Outbound':<14} {avg(all_server_outbound_delay):>9.1f}ms {min(all_server_outbound_delay):>9.1f}ms {percentile(all_server_outbound_delay, 50):>9.1f}ms {percentile(all_server_outbound_delay, 90):>9.1f}ms {percentile(all_server_outbound_delay, 95):>9.1f}ms {percentile(all_server_outbound_delay, 99):>9.1f}ms {max(all_server_outbound_delay):>9.1f}ms")
        print(f"  {'Total':<14} {avg(all_totals):>9.0f}ms {min(all_totals):>9.0f}ms {percentile(all_totals, 50):>9.0f}ms {percentile(all_totals, 90):>9.0f}ms {percentile(all_totals, 95):>9.0f}ms {percentile(all_totals, 99):>9.0f}ms {max(all_totals):>9.0f}ms")
        print(f"  {'Audio':<14} {avg(all_durations):>9.2f}s  {min(all_durations):>9.2f}s  {percentile(all_durations, 50):>9.2f}s  {percentile(all_durations, 90):>9.2f}s  {percentile(all_durations, 95):>9.2f}s  {percentile(all_durations, 99):>9.2f}s  {max(all_durations):>9.2f}s ")
        if all_rtfs:
            print(f"  {'RTF':<14} {avg(all_rtfs):>9.2f}x  {min(all_rtfs):>9.2f}x  {percentile(all_rtfs, 50):>9.2f}x  {percentile(all_rtfs, 90):>9.2f}x  {percentile(all_rtfs, 95):>9.2f}x  {percentile(all_rtfs, 99):>9.2f}x  {max(all_rtfs):>9.2f}x ")

    print()
    print("Done!")


if __name__ == "__main__":
    asyncio.run(main())