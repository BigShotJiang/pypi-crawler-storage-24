import argparse
import os
import time
import wave

from orpheus_tts import OrpheusClient


DEFAULT_TEXT = (
    "Hello world! Test. This is a test of the Orpheus TTS system. This is the first ever truely multilingual model [laugh]"
    # "This is the first ever truely multilingual model [laugh]"
)
# DEFAULT_WS_URL = "ws://34.27.105.165:8000/ws" # for each customer there is a different one
DEFAULT_WS_URL = "wss://YOUR_WEBSOCKET_URL"

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simple Orpheus TTS smoke test")
    parser.add_argument("-v", "--voice", type=str, default="troy", help="Voice name (default: troy)")
    parser.add_argument("--text", type=str, default=DEFAULT_TEXT, help="Text to synthesize")
    parser.add_argument(
        "--provider",
        type=str,
        required=True,
        help="Voice provider to use, for example: PROVIDER_NAME",
    )
    parser.add_argument(
        "--ws-url",
        type=str,
        default=os.getenv("ORPHEUS_TTS_MULTIPLEX_WS_URL", DEFAULT_WS_URL),
        help=f"Multiplex websocket URL (default: {DEFAULT_WS_URL})",
    )
    parser.add_argument("--api-key", type=str, default=os.getenv("ORPHEUS_TTS_API_KEY"))
    parser.add_argument("--output", type=str, default="output.wav", help="Output WAV path")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    client = OrpheusClient(api_key=args.api_key, provider=args.provider)
    client.connect(
        ws_url=args.ws_url,
        websocket_count=1,  # when ws_url is set: single websocket, multiplex many requests
    )

    time.sleep(1)  # Brief pause to ensure connection is stable

    chunks = []
    start_time = time.perf_counter()
    ttfa_ms = None
    print(f"Streaming audio with voice={args.voice!r}...")
    for i, chunk in enumerate(client.stream(args.text, voice=args.voice)):
        if i == 0:
            ttfa_ms = (time.perf_counter() - start_time) * 1000
            print(f"Time To First Audio (TTFA): {ttfa_ms:.1f}ms")
        chunks.append(chunk)

    total_time = (time.perf_counter() - start_time) * 1000
    client.close()

    # Save as WAV
    audio_data = b"".join(chunks)
    with wave.open(args.output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(48000)
        wav.writeframes(audio_data)

    audio_duration = len(audio_data) / 2 / 48000  # int16 = 2 bytes, 48kHz
    print(f"\nSaved {len(audio_data)} bytes to {args.output} ({audio_duration:.2f}s audio)")
    print(f"Total streaming time: {total_time:.1f}ms")
    if ttfa_ms is not None:
        print(f"Time To First Audio (TTFA): {ttfa_ms:.1f}ms")


if __name__ == "__main__":
    main()
