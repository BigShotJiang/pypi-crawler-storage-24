import argparse
import os
import sys
import time
import wave

from orpheus_tts import OrpheusClient


DEFAULT_TEXT = "Hello, this is a test of the text to speech system built by canopylabs [laugh]. This is the first ever truely multilingual model [laugh]. This is such a really really funny message and it's really really long as well. This. Works. [cough]"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Orpheus TTS smoke test using voice-based connect()"
    )
    parser.add_argument(
        "-v",
        "--voice",
        type=str,
        default="josh",
        help="Voice name used both for connect() and stream() (default: josh)",
    )
    parser.add_argument("--text", type=str, default=DEFAULT_TEXT, help="Text to synthesize")
    parser.add_argument(
        "--websocket-count",
        type=int,
        default=1,
        help="Number of multiplex websockets to pre-connect (default: 1)",
    )
    parser.add_argument("--api-key", type=str, default=os.getenv("ORPHEUS_TTS_API_KEY"))
    parser.add_argument(
        "--provider",
        type=str,
        required=True,
        help="Voice provider to use, for example: PROVIDER_NAME",
    )
    parser.add_argument("--output", type=str, default="output_by_voice.wav", help="Output WAV path")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    client = OrpheusClient(
        api_key=args.api_key,
        provider=args.provider,
    )
    client.connect(
        voice=args.voice,
        websocket_count=args.websocket_count,
    )

    time.sleep(1)  # Brief pause to ensure connection is stable

    chunks = []
    start_time = time.perf_counter()
    ttfa_ms = None
    print(f"Streaming audio with voice={args.voice!r}...")
    for i, chunk in enumerate(client.stream(args.text, voice=args.voice)):
        if i == 0:
            ttfa_ms = (time.perf_counter() - start_time) * 1000
            print(f"Time To First Audio (TTFA): {ttfa_ms:.1f}ms")
        chunks.append(chunk)

    total_time = (time.perf_counter() - start_time) * 1000
    client.close()

    audio_data = b"".join(chunks)
    with wave.open(args.output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(48000)
        wav.writeframes(audio_data)

    audio_duration = len(audio_data) / 2 / 48000  # int16 = 2 bytes, 48kHz
    print(f"\nSaved {len(audio_data)} bytes to {args.output} ({audio_duration:.2f}s audio)")
    print(f"Total streaming time: {total_time:.1f}ms")
    if ttfa_ms is not None:
        print(f"Time To First Audio (TTFA): {ttfa_ms:.1f}ms")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
