"""Orpheus TTS Python SDK - Stream high-quality speech from the Orpheus model."""

from orpheus_tts.client import OrpheusClient
from orpheus_tts.exceptions import OrpheusError, AuthenticationError

# Voices are loaded dynamically from client/provider config at runtime.
VOICES = []

__all__ = ["OrpheusClient", "OrpheusError", "AuthenticationError", "VOICES"]
__version__ = "0.1.5"

