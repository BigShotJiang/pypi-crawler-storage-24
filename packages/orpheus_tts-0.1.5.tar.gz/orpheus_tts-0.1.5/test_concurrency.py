import argparse
import time
import asyncio
import wave
import os
import random
import string
from orpheus_tts import OrpheusClient

PROMPTS = [
    "Hello world! This is a test of the Orpheus TTS system.",
    "The quick brown fox jumps over the lazy dog near the riverbank.",
    "Scientists discovered a new species of butterfly in the Amazon rainforest.",
    "She walked through the garden, admiring the colorful flowers blooming everywhere.",
    "The old clock tower chimed twelve times at midnight during the storm.",
    "A gentle breeze carried the scent of fresh pine through the mountain valley.",
    "The chef prepared an exquisite meal using ingredients from the local market.",
    "Children laughed and played in the park while their parents watched nearby.",
    "The ancient library contained thousands of books from centuries past.",
    "Musicians gathered in the square to perform traditional folk songs at sunset.",
]
OUTPUT_DIR = "output_concurrency"


def get_unique_prompt():
    """Get a random prompt with random letters added to prevent LLM caching."""
    prefix = ''.join(random.choices(string.ascii_lowercase, k=random.randint(2, 4)))
    suffix = ''.join(random.choices(string.ascii_lowercase, k=random.randint(2, 4)))
    prompt = random.choice(PROMPTS)
    return f"{prefix}{prompt}{suffix}"


async def aenumerate(aiterable):
    """Async enumerate helper."""
    i = 0
    async for item in aiterable:
        yield i, item
        i += 1


def print_results(results, total_time, num_requests):
    """Print formatted results table."""
    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    print(f"{'#':>3} {'TTFA':>10} {'Total':>10} {'Audio':>8}")
    print("-" * 35)

    ttfas = []
    totals = []
    for r in sorted(results, key=lambda x: x["idx"]):
        audio_s = r["bytes"] / 2 / 48000
        print(f"{r['idx']:>3} {r['ttfa_ms']:>9.1f}ms {r['total_ms']:>9.1f}ms {audio_s:>7.2f}s")
        if r["ttfa_ms"]:
            ttfas.append(r["ttfa_ms"])
        totals.append(r["total_ms"])

    print("-" * 35)
    if ttfas:
        print(f"Avg TTFA: {sum(ttfas)/len(ttfas):.1f}ms (min: {min(ttfas):.1f}, max: {max(ttfas):.1f})")
    print(f"Avg Total: {sum(totals)/len(totals):.1f}ms")
    print(f"Wall clock: {total_time:.2f}s for {num_requests} requests")
    print(f"Throughput: {num_requests / total_time:.2f} requests/sec")


def save_audio(results):
    """Save audio results to WAV files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"\nSaving audio files to {OUTPUT_DIR}/...")
    for r in results:
        filepath = os.path.join(OUTPUT_DIR, f"request_{r['idx']:03d}.wav")
        with wave.open(filepath, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)  # 16-bit
            wf.setframerate(48000)
            wf.writeframes(r["audio"])
    print(f"Saved {len(results)} audio files.")


# ── Async concurrency test ─────────────────────────────────

async def test_async_concurrency(num_requests: int, stagger_ms: float, pool_size: int):
    """Test concurrent async requests using the shared connection pool."""
    print("=" * 60)
    print(f"ASYNC CONCURRENCY TEST")
    print(f"  Requests: {num_requests}, Stagger: {stagger_ms}ms, Pool: {pool_size}")
    print("=" * 60)

    client = OrpheusClient()

    print(f"Pre-establishing {pool_size} connections per endpoint...")
    pool_start = time.perf_counter()
    client.connect(pool_size=pool_size)
    pool_time = (time.perf_counter() - pool_start) * 1000
    print(f"Pool ready in {pool_time:.0f}ms")
    print("-" * 60)

    ongoing = [0]

    async def single_request(idx: int, delay_ms: float):
        if delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000)

        ongoing[0] += 1
        print(f"  Request {idx}: Started (ongoing: {ongoing[0]})")

        start = time.perf_counter()
        ttfa = None
        audio_chunks = []

        text = get_unique_prompt()
        async for i, chunk in aenumerate(client.stream_async(text, voice="josh")):
            if i == 0:
                ttfa = (time.perf_counter() - start) * 1000
                print(f"  Request {idx}: TTFA = {ttfa:.1f}ms (ongoing: {ongoing[0]})")
            audio_chunks.append(chunk)

        ongoing[0] -= 1
        total = (time.perf_counter() - start) * 1000
        audio_data = b"".join(audio_chunks)
        print(f"  Request {idx}: Done ({total:.0f}ms total, ongoing: {ongoing[0]})")
        return {"idx": idx, "ttfa_ms": ttfa, "total_ms": total, "bytes": len(audio_data), "audio": audio_data}

    print(f"Launching {num_requests} requests...")
    start = time.perf_counter()

    tasks = [single_request(i, i * stagger_ms) for i in range(num_requests)]
    results = await asyncio.gather(*tasks)

    total_time = time.perf_counter() - start
    client.close()

    print_results(results, total_time, num_requests)
    save_audio(results)


# ── Sync sequential test ────────────────────────────────────

def test_sync_sequential(num_requests: int):
    """Test sequential sync requests using the shared connection pool."""
    print("\n" + "=" * 60)
    print(f"SYNC SEQUENTIAL TEST ({num_requests} requests, reusing pool)")
    print("=" * 60)

    client = OrpheusClient()
    client.connect()

    results = []

    print(f"Running {num_requests} sequential requests...")
    overall_start = time.perf_counter()

    for idx in range(num_requests):
        start = time.perf_counter()
        ttfa = None
        audio_chunks = []

        text = get_unique_prompt()
        for i, chunk in enumerate(client.stream(text, voice="josh")):
            if i == 0:
                ttfa = (time.perf_counter() - start) * 1000
                print(f"  Request {idx}: TTFA = {ttfa:.1f}ms")
            audio_chunks.append(chunk)

        total = (time.perf_counter() - start) * 1000
        audio_data = b"".join(audio_chunks)
        results.append({"idx": idx, "ttfa_ms": ttfa, "total_ms": total, "bytes": len(audio_data), "audio": audio_data})

    total_time = time.perf_counter() - overall_start
    client.close()

    print_results(results, total_time, num_requests)
    save_audio(results)


# ── Entry point ─────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test Orpheus TTS concurrency")
    parser.add_argument("-n", "--num", type=int, default=10, help="Number of requests (default: 10)")
    parser.add_argument("-s", "--stagger", type=float, default=100, help="Stagger between requests in ms (default: 100)")
    parser.add_argument("-p", "--pool", type=int, default=64, help="Connection pool size per endpoint (default: 64)")
    parser.add_argument("--sync", action="store_true", help="Run sync sequential test instead of async")
    args = parser.parse_args()

    if args.sync:
        test_sync_sequential(args.num)
    else:
        asyncio.run(test_async_concurrency(args.num, args.stagger, args.pool))
