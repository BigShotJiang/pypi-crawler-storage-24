import os
import tushare as ts
import pandas as pd
from dotenv import load_dotenv
from .stock_lookup import get_ts_code
from .technical_analysis import TechnicalAnalysis, get_llm_snapshot

def apply_qfq(df_daily: pd.DataFrame, df_adj: pd.DataFrame) -> pd.DataFrame:
    """
    将原始日线数据转换为前复权价格
    
    Args:
        df_daily: pro.daily() 返回的原始日线数据
        df_adj: pro.adj_factor() 返回的复权因子数据
    
    Returns:
        前复权后的 DataFrame，open/high/low/close 已替换为前复权价格
    """
    df = pd.merge(df_daily, df_adj[['trade_date', 'adj_factor']], on='trade_date', how='left')
    df = df.sort_values('trade_date').reset_index(drop=True)
    
    latest_adj = df['adj_factor'].iloc[-1]
    for col in ['open', 'high', 'low', 'close']:
        df[col] = df[col] * df['adj_factor'] / latest_adj
    
    return df.sort_values('trade_date', ascending=False).reset_index(drop=True)


def main():
    load_dotenv()
    token = os.getenv("TUSHARE_TOKEN")
    ts.set_token(token)  # 设置全局 token

    pro = ts.pro_api()

    #ts_code = get_ts_code("中芯国际")
    ts_code = '000001.SZ'
    df_daily = pro.daily(ts_code=ts_code, limit = 200)
    df_adj = pro.adj_factor(ts_code=ts_code, trade_date='')

    df = apply_qfq(df_daily, df_adj)

    ta = TechnicalAnalysis(df)
    res = ta.get_all_indicators()
    ta2 = TechnicalAnalysis(df_daily)
    res2 = ta2.get_all_indicators()
    print(get_llm_snapshot(res))
    print(get_llm_snapshot(res2))

if __name__ == "__main__":
    main()