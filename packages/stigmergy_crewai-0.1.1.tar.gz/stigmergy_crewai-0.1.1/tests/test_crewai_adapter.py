"""Tests for CrewAI adapter — mocks CrewAI to test scheduling logic."""

import sys
from types import ModuleType
from unittest.mock import MagicMock
from dataclasses import dataclass, field

# Mock crewai before importing adapter
_mock_crewai = ModuleType("crewai")


@dataclass
class _MockAgent:
    role: str
    goal: str = ""
    llm: str = ""

    def __hash__(self):
        return hash(self.role)

    def __eq__(self, other):
        return isinstance(other, _MockAgent) and self.role == other.role


@dataclass
class _MockTask:
    description: str
    expected_output: str = ""
    agent: _MockAgent | None = None
    context: list | None = None


class _MockProcess:
    sequential = "sequential"
    hierarchical = "hierarchical"


class _MockCrew:
    def __init__(self, agents, tasks, process, verbose=False, **kwargs):
        self.agents = agents
        self.tasks = tasks
        self.process = process
        self.verbose = verbose

    def kickoff(self):
        return {t.description: "done" for t in self.tasks}


_mock_crewai.Agent = _MockAgent
_mock_crewai.Task = _MockTask
_mock_crewai.Crew = _MockCrew
_mock_crewai.Process = _MockProcess

sys.modules["crewai"] = _mock_crewai

from stigmergy_crewai import StigmergyManager


def test_single_task_order():
    researcher = _MockAgent(role="researcher", goal="Find info")
    manager = StigmergyManager()
    manager.add_task("research", agent=researcher, description="Research AI",
                     expected_output="Report", priority=0.8)

    assert manager.task_order == ["research"]


def test_dependency_ordering():
    researcher = _MockAgent(role="researcher")
    writer = _MockAgent(role="writer")

    manager = StigmergyManager()
    manager.add_task("research", agent=researcher, description="Research",
                     priority=0.8)
    manager.add_task("write", agent=writer, description="Write",
                     priority=0.9, deps=["research"])

    order = manager.task_order
    assert order.index("research") < order.index("write")


def test_three_task_chain():
    r = _MockAgent(role="researcher")
    w = _MockAgent(role="writer")
    e = _MockAgent(role="editor")

    manager = StigmergyManager()
    manager.add_task("research", agent=r, description="Research", priority=0.8)
    manager.add_task("write", agent=w, description="Write", priority=0.6, deps=["research"])
    manager.add_task("edit", agent=e, description="Edit", priority=0.5, deps=["write"])

    order = manager.task_order
    assert order == ["research", "write", "edit"]


def test_parallel_tasks_ordered_by_priority():
    a = _MockAgent(role="agent_a")
    b = _MockAgent(role="agent_b")

    manager = StigmergyManager()
    manager.add_task("low", agent=a, description="Low priority", priority=0.3)
    manager.add_task("high", agent=b, description="High priority", priority=0.9)

    order = manager.task_order
    assert order.index("high") < order.index("low")


def test_build_crew_returns_crew():
    researcher = _MockAgent(role="researcher")
    manager = StigmergyManager()
    manager.add_task("research", agent=researcher, description="Research",
                     priority=0.8)

    crew = manager.build_crew(verbose=True)
    assert isinstance(crew, _MockCrew)
    assert crew.verbose is True
    assert len(crew.tasks) == 1
    assert researcher in crew.agents


def test_build_crew_correct_task_order():
    r = _MockAgent(role="researcher")
    w = _MockAgent(role="writer")

    manager = StigmergyManager()
    manager.add_task("research", agent=r, description="Research", priority=0.8)
    manager.add_task("write", agent=w, description="Write", priority=0.6, deps=["research"])

    crew = manager.build_crew()
    descriptions = [t.description for t in crew.tasks]
    assert descriptions == ["Research", "Write"]


def test_metrics():
    r = _MockAgent(role="researcher")
    manager = StigmergyManager()
    manager.add_task("research", agent=r, description="Research", priority=0.8)

    metrics = manager.metrics
    assert metrics.pending_tasks >= 0
