# stigmergy-crewai

**Optimal task ordering for [CrewAI](https://github.com/crewAIInc/crewAI) crews.** Declare tasks with priorities and dependencies, and stigmergy computes the best execution order using pressure signals. No manual ordering required.

5 lines to integrate. Works with your existing CrewAI agents.

## Install

```bash
pip install stigmergy-crewai
```

## Usage

```python
from crewai import Agent
from stigmergy_crewai import StigmergyManager

# Create CrewAI agents
researcher = Agent(role="researcher", goal="Find information", llm=llm)
writer = Agent(role="writer", goal="Write content", llm=llm)
editor = Agent(role="editor", goal="Edit content", llm=llm)

# Create stigmergy manager with tasks and dependencies
manager = StigmergyManager(wake_threshold=0.4)
manager.add_task("research", agent=researcher, description="Research AI trends",
                 expected_output="Key findings", priority=0.8)
manager.add_task("write", agent=writer, description="Write article",
                 expected_output="Draft article", priority=0.6, deps=["research"])
manager.add_task("edit", agent=editor, description="Edit the draft",
                 expected_output="Final article", priority=0.5, deps=["write"])

# Preview execution order
print(manager.task_order)  # ['research', 'write', 'edit']

# Build and run
crew = manager.build_crew(verbose=True)
result = crew.kickoff()
```

## How It Works

Since CrewAI's `Process` enum is not extensible, the `StigmergyManager`:
1. Accepts tasks with priorities and dependency graphs
2. Uses pressure signals to resolve optimal execution order
3. Deposits completion signals that propagate to dependent tasks
4. Builds a CrewAI `Crew` with tasks in the resolved order
5. Uses CrewAI's `context` parameter to pass outputs between dependent tasks

## Limitations

- Cannot parallelize tasks (CrewAI sequential process limitation)
- Cannot dynamically inject tasks mid-execution
- Task ordering is resolved at `build_crew()` time, not runtime

For full dynamic scheduling, use the core `stigmergy` library directly.

## License

MIT
