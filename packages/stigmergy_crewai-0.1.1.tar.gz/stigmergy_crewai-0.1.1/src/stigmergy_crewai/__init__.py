"""Stigmergy pressure-field scheduling adapter for CrewAI.

CrewAI doesn't support custom Process types, so this adapter works
through the hierarchical process with a stigmergy-aware manager agent.
The manager uses pressure signals instead of LLM calls to decide
which crew member works next.

Usage:
    from stigmergy_crewai import StigmergyManager

    manager = StigmergyManager(wake_threshold=0.4)
    manager.add_task("research", agent=researcher, priority=0.8)
    manager.add_task("review", agent=reviewer, deps=["research"])

    crew = manager.build_crew(verbose=True)
    result = crew.kickoff()
"""

from stigmergy_crewai.adapter import StigmergyManager

__all__ = ["StigmergyManager"]
