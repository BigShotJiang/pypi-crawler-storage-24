"""CrewAI adapter: pressure-field scheduling for CrewAI crews.

Uses StigmergyScheduler internally for dependency resolution and
pressure-based task ordering. Since CrewAI's Process enum is not
extensible, the adapter computes optimal task ordering at build time
using the pressure field, then constructs a sequential Crew.

For fully dynamic runtime scheduling, use StigmergyScheduler directly.
"""

from __future__ import annotations

import asyncio
from typing import Any

from stigmergy import StigmergyScheduler, TaskSpec, SchedulerMetrics

try:
    from crewai import Agent, Crew, Task, Process
except ImportError as e:
    raise ImportError(
        "crewai is required: pip install stigmergy-crewai"
    ) from e


class StigmergyManager:
    """Pressure-field task manager for CrewAI crews.

    Wraps CrewAI's sequential process with stigmergy-based task ordering.
    Tasks are topologically sorted by dependencies and ranked by pressure
    signals to determine optimal execution order.

    Note: CrewAI runs tasks sequentially. For parallel dispatch with
    dynamic scheduling, use ``StigmergyScheduler`` directly.

    Example::

        from crewai import Agent
        from stigmergy_crewai import StigmergyManager

        researcher = Agent(role="researcher", goal="Find information", llm=llm)
        writer = Agent(role="writer", goal="Write content", llm=llm)

        manager = StigmergyManager()
        manager.add_task(
            "research", agent=researcher,
            description="Research AI trends",
            expected_output="Key findings report",
            priority=0.8,
        )
        manager.add_task(
            "write", agent=writer,
            description="Write article from research",
            expected_output="Draft article",
            priority=0.6, deps=["research"],
        )

        crew = manager.build_crew()
        result = crew.kickoff()
    """

    def __init__(
        self,
        wake_threshold: float = 0.4,
        decay_half_life: float = 300.0,
        evaporation_threshold: float = 0.01,
    ):
        self._scheduler = StigmergyScheduler(
            tick_interval=0.01,
            wake_threshold=wake_threshold,
            decay_half_life=decay_half_life,
            evaporation_threshold=evaporation_threshold,
        )
        self._crewai_tasks: dict[str, Task] = {}
        self._crewai_agents: dict[str, Agent] = {}
        self._task_deps: dict[str, list[str]] = {}

    def add_task(
        self,
        task_id: str,
        agent: Agent,
        description: str,
        expected_output: str = "",
        priority: float = 0.5,
        deps: list[str] | None = None,
    ) -> None:
        """Add a task with stigmergy scheduling metadata.

        Args:
            task_id: Unique identifier for dependency tracking.
            agent: CrewAI Agent to execute this task.
            description: Task description (passed to the agent).
            expected_output: Expected output description for CrewAI.
            priority: Signal intensity (0.0-1.0).
            deps: Task IDs that must complete before this one.
        """
        dep_list = deps or []

        # Create CrewAI Task with context from dependencies
        dep_tasks = [self._crewai_tasks[d] for d in dep_list if d in self._crewai_tasks]
        crewai_task = Task(
            description=description,
            expected_output=expected_output or f"Completed: {description}",
            agent=agent,
            context=dep_tasks if dep_tasks else None,
        )

        self._crewai_tasks[task_id] = crewai_task
        self._crewai_agents[task_id] = agent
        self._task_deps[task_id] = dep_list

        # Register with scheduler for pressure computation
        spec = TaskSpec(
            id=task_id,
            description=description,
            agent_id=agent.role,
            priority=priority,
            dependencies=dep_list,
        )
        self._run_async(self._scheduler.add_task(spec))

    def build_crew(self, verbose: bool = False, **crew_kwargs: Any) -> Crew:
        """Build a CrewAI Crew with tasks ordered by pressure-field scheduling.

        Tasks are topologically sorted by dependencies, then ranked by
        descending pressure within each dependency tier.

        Args:
            verbose: Whether to enable verbose logging.
            **crew_kwargs: Additional kwargs passed to Crew().

        Returns:
            A configured CrewAI Crew ready for kickoff().
        """
        ordered_ids = self._resolve_order()
        ordered_crewai_tasks = [self._crewai_tasks[tid] for tid in ordered_ids]
        agents = list({self._crewai_agents[tid] for tid in ordered_ids})

        return Crew(
            agents=agents,
            tasks=ordered_crewai_tasks,
            process=Process.sequential,
            verbose=verbose,
            **crew_kwargs,
        )

    def _resolve_order(self) -> list[str]:
        """Topological sort by dependencies, breaking ties by pressure."""
        completed: set[str] = set()
        ordered: list[str] = []
        remaining = set(self._scheduler._tasks.keys())

        while remaining:
            # Find tasks whose deps are all satisfied
            available = [
                tid for tid in remaining
                if all(d in completed for d in self._task_deps.get(tid, []))
            ]
            if not available:
                # Deadlock: add remaining in priority order
                available = sorted(remaining, key=lambda tid: -self._scheduler._tasks[tid].priority)

            # Rank by pressure
            pressures = {}
            for tid in available:
                task = self._scheduler._tasks[tid]
                p = self._run_async(self._scheduler.field.read_pressure(task.agent_id))
                pressures[tid] = p + task.priority

            available.sort(key=lambda tid: -pressures.get(tid, 0))

            best = available[0]
            ordered.append(best)
            completed.add(best)
            remaining.discard(best)

            # Deposit completion signal to influence downstream pressure
            task = self._scheduler._tasks[best]
            self._run_async(self._scheduler.field.deposit(
                agent_id=task.agent_id,
                signal_type="task_complete",
                intensity=0.6,
                metadata={"task_id": best},
            ))

        return ordered

    @property
    def task_order(self) -> list[str]:
        """Preview the resolved task execution order."""
        return self._resolve_order()

    @property
    def metrics(self) -> SchedulerMetrics:
        """Current scheduling metrics."""
        return self._scheduler.get_metrics()

    @staticmethod
    def _run_async(coro: Any) -> Any:
        """Run an async coroutine from sync context without breaking existing loops."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(lambda: asyncio.run(coro)).result()
        else:
            return asyncio.run(coro)
