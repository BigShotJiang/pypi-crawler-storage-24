# Changelog

## 2026-03-11 — Scoring, Report, Backtest & Risk Defect Fixes

**Reference**: Real-world simulation testing (test_a vs test_b) revealed 4 defects causing misleading results.

### Fixed

- **Defect 1 (CRITICAL): Composite score no longer renormalizes missing dimensions** — `scoring.py`
  - Previously: `compute_composite()` skipped `None` dimensions and divided by the sum of available weights only. With only momentum (25) + technical (30), GARP weights (0.35) got renormalized to 1.0, producing composite = 27 — flagging MSFT as "SELL_CANDIDATE".
  - Fix: Missing dimensions default to 50 (neutral) instead of being skipped. All 5 weights always sum to 1.0. MSFT now scores 42 ("WATCH") instead of 27.
  - Added `defaulted_dimensions` list and `coverage` field (e.g. "2/5") to score output.
  - Applied to both `core/scoring.py` (MCP) and `scripts/scoring_engine.py` (standalone).

- **Defect 2: Report now shows dimension data provenance** — `pipeline.py`, `orchestrator.py`
  - Previously: Scorecard showed `--` for missing values but composite was calculated from only available ones. Users couldn't tell why a composite was low.
  - Fix: Each dimension score shows a superscript suffix: ᴬ (auto-scored), ᴹ (manual override), ᴰ (defaulted to 50). Added Coverage column and explanatory legend.
  - Standalone scoring engine writes `scores_meta.json` alongside CSV for orchestrator report.

- **Defect 3: Backtest supports score-based position selection** — `backtest.py`
  - Previously: `run_backtest()` always ranked by 3-month price momentum. The `entry.min_score` config was unused. Backtest validated a pure momentum strategy, not the GARP scoring strategy.
  - Fix: Added `scores` and `ranking_mode` parameters. When `ranking_mode="score"`, initial allocation uses composite scores and honors `entry.min_score` threshold. Subsequent rebalances use momentum (scores can't be recomputed mid-backtest without financials).
  - Pipeline automatically passes scoring results to backtest stage.

- **Defect 4: Risk analysis includes candidate tickers in correlation** — `risk.py`
  - Previously: `analyze_risk()` only computed correlation for current holdings. When evaluating a swap (sell MSFT, buy AVGO), users couldn't see how AVGO correlates with remaining holdings.
  - Fix: Added `candidates` parameter. Returns both `correlation_matrix` (holdings only, backward compatible) and `correlation_with_candidates` (expanded). Concentration checks still only apply to holdings.
  - Pipeline passes candidate tickers to risk stage. Report shows expanded correlation matrix with candidates in bold.

### Files Changed

| File | Defects | Changes |
|------|---------|---------|
| `src/portfolio_rotation/core/scoring.py` | #1 | Default 50 for None dims, `defaulted_dimensions` + `coverage` output |
| `src/portfolio_rotation/core/pipeline.py` | #2, #3, #4 | Report provenance, pass scores to backtest, pass candidates to risk |
| `src/portfolio_rotation/core/risk.py` | #4 | `candidates` param, expanded correlation matrix |
| `src/portfolio_rotation/core/backtest.py` | #3 | `scores`/`ranking_mode` params, `min_score` filtering |
| `src/portfolio_rotation/server.py` | #3, #4 | Expose new params on `run_backtest` and `analyze_risk` tools |
| `scripts/scoring_engine.py` | #1, #2 | Same scoring fix + `scores_meta.json` output |
| `scripts/orchestrator.py` | #2 | Report reads provenance metadata, shows suffixes |

---

## 2026-03-08 — Risk & Backtest Bug Fixes

**Reference**: `docs/bug-report-2026-03-08.md`

### Fixed

- **BUG-001 (CRITICAL): HHI now includes cash weight** — `risk.py:analyze_concentration()`
  - Previously: HHI calculated only over active positions, ignoring unallocated cash.
  - Example: Portfolio [AAPL 20%, MSFT 15%, JPM 10%] reported HHI=0.0725 (effective 13.8 positions) instead of correct HHI=0.375 (effective 2.7 positions).
  - Fix: Compute `cash_weight = max(1.0 - sum(active_weights), 0)` and include it in HHI sum-of-squares.
  - Also added `cash_weight` field to concentration output for transparency.

- **BUG-002 (CRITICAL): Sortino ratio downside deviation corrected** — `backtest.py:run_backtest()`
  - Previously: Downside std used only negative-return days in both numerator and denominator: `sqrt(sum(r² for neg days) / len(neg days))`. This made Sortino ≈ Sharpe even for positively-skewed strategies.
  - Fix: Apply `min(r, 0)²` across ALL trading days and divide by total count: `sqrt(sum(min(r,0)² for all days) / (N-1))`. This is the standard Sortino downside deviation.
  - Expected result: Sortino should now be meaningfully higher than Sharpe for strategies with positive skew.

### Improved

- **ISSUE-003: Portfolio volatility transparency** — `risk.py:analyze_risk()`
  - Added `portfolio_volatility_method`, `invested_weight`, and `volatility_method` fields to risk output.
  - Documents that weights may sum to < 1.0 (cash dampening) and that daily×√252 annualization is used.
  - No calculation change — behavior was technically correct but undocumented.

### Files Changed

| File | Lines | Change |
|------|-------|--------|
| `src/portfolio_rotation/core/risk.py` | 38-48, 117-135 | HHI cash inclusion + volatility metadata |
| `src/portfolio_rotation/core/backtest.py` | 206-209 | Sortino downside deviation fix |
| `docs/bug-report-2026-03-08.md` | new | Full bug report with reproduction steps |
