"""Configuration for the portfolio rotation MCP server."""

import os
from dataclasses import dataclass, field


@dataclass
class RotatorConfig:
    """Runtime configuration for the rotation analysis pipeline."""

    api_key: str = ""
    data_dir: str = ""
    style: str = "garp"
    benchmark: str = "SPY"

    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.environ.get("FINANCIAL_DATASETS_API_KEY", "")
        if not self.data_dir:
            self.data_dir = os.environ.get(
                "PORTFOLIO_ROTATION_DATA_DIR",
                os.path.join(os.getcwd(), "data"),
            )


# Singleton config, lazily initialized from env vars
_config: RotatorConfig | None = None


def get_config() -> RotatorConfig:
    global _config
    if _config is None:
        _config = RotatorConfig()
    return _config
