"""
Portfolio Rotation MCP Server.

11 tools for portfolio rotation analysis: fetch data, score tickers,
analyze risk, compare swaps, backtest strategies, stress test, and more.

Works with any MCP client: Claude Desktop, ChatGPT, Gemini, LangChain,
Cursor, Windsurf, VS Code, Ollama clients, etc.
"""

import json
import logging
import sys

from mcp.server.fastmcp import FastMCP

from .core import (
    attribution,
    backtest,
    data_fetch,
    ff_factors,
    pipeline,
    risk,
    scoring,
    stress,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("portfolio-rotation-mcp")

mcp = FastMCP("portfolio-rotation")


# ── Tool 1: Fetch Prices ─────────────────────────────────────────────

@mcp.tool()
async def fetch_prices(
    tickers: str,
    start_date: str,
    end_date: str,
    source: str = "",
) -> str:
    """Fetch historical daily OHLCV prices for given tickers.

    Uses financial-datasets API with automatic yfinance fallback.
    Set FINANCIAL_DATASETS_API_KEY env var for API access.
    Set PORTFOLIO_ROTATION_SOURCE env var to change the default source.

    Args:
        tickers: Comma-separated ticker symbols (e.g. "AAPL,MSFT,NVDA,SPY").
        start_date: Start date in YYYY-MM-DD format (e.g. "2023-01-01").
        end_date: End date in YYYY-MM-DD format (e.g. "2026-03-05").
        source: Data source -- "auto" (API first, yfinance fallback), "api",
            "financial-datasets" (same as "api"), or "yfinance".
            If empty, reads PORTFOLIO_ROTATION_SOURCE env var (default: "auto").

    Returns:
        JSON with price records: [{date, ticker, open, high, low, close, volume}, ...].
    """
    ticker_list = [t.strip() for t in tickers.split(",") if t.strip()]
    rows = data_fetch.fetch_prices(ticker_list, start_date, end_date, source)
    return json.dumps({
        "count": len(rows),
        "tickers": sorted(set(r["ticker"] for r in rows)),
        "date_range": f"{rows[0]['date']} to {rows[-1]['date']}" if rows else "no data",
        "prices": rows,
    }, default=str)


# ── Tool 2: Fetch Financials ─────────────────────────────────────────

@mcp.tool()
async def fetch_financials(
    tickers: str,
    stmt_type: str = "all",
    period: str = "annual",
    limit: int = 5,
) -> str:
    """Fetch financial statements (income, balance sheet, cashflow) from the API.

    Requires FINANCIAL_DATASETS_API_KEY env var.

    Args:
        tickers: Comma-separated ticker symbols (e.g. "AAPL,MSFT").
        stmt_type: Statement type -- "income", "balance", "cashflow", or "all".
        period: "annual" or "quarterly".
        limit: Number of periods per ticker (default 5).

    Returns:
        JSON with financial statement records.
    """
    ticker_list = [t.strip() for t in tickers.split(",") if t.strip()]
    rows = data_fetch.fetch_financials(ticker_list, stmt_type, period, limit)
    return json.dumps({"count": len(rows), "statements": rows}, default=str)


# ── Tool 3: Fetch Fama-French Factors ────────────────────────────────

@mcp.tool()
async def fetch_ff_factors(start_date: str = "2020-01-01") -> str:
    """Download Fama-French 5-factor + momentum daily data.

    Data is freely available from Kenneth French's Data Library.
    Used for factor decomposition in stress testing.

    Args:
        start_date: Filter to dates on or after this date (default "2020-01-01").

    Returns:
        JSON with factor records: [{date, MKT-RF, SMB, HML, RMW, CMA, MOM, RF}, ...].
        All values are decimals (not percent).
    """
    rows = ff_factors.fetch_ff_factors(start_date)
    return json.dumps({
        "count": len(rows),
        "date_range": f"{rows[0]['date']} to {rows[-1]['date']}" if rows else "no data",
        "factors": rows,
    }, default=str)


# ── Tool 4: Score Tickers ────────────────────────────────────────────

@mcp.tool()
async def score_tickers(
    tickers: str,
    prices_json: str,
    benchmark: str = "SPY",
    financials_json: str = "",
    overrides_json: str = "",
    holdings: str = "",
    style: str = "garp",
) -> str:
    """Score tickers across 5 dimensions for rotation analysis.

    Dimensions (0-100 each):
    - Thesis Integrity (manual via overrides)
    - Valuation Attractiveness (auto with financials, or manual)
    - Fundamental Momentum (auto from prices + financials)
    - Catalyst Proximity (manual via overrides)
    - Technical Trend (auto from prices: MA crossovers, RSI, relative strength)

    Args:
        tickers: Comma-separated tickers to score (e.g. "AAPL,MSFT,NVDA,META").
        prices_json: JSON string of price data from fetch_prices (the "prices" array).
        benchmark: Benchmark ticker for relative strength (default "SPY").
        financials_json: Optional JSON string of financials from fetch_financials.
        overrides_json: Optional JSON string of manual overrides, e.g.
            '{"AAPL": {"thesis": 75, "catalyst": 60}, "MSFT": {"thesis": 70}}'.
        holdings: Comma-separated current holding tickers for action labeling.
        style: Investment style -- "garp", "value", "growth", "momentum", or "event_driven".

    Returns:
        JSON with scored tickers: [{ticker, thesis, valuation, momentum, catalyst,
        technical, composite, action, style, auto_dimensions, manual_dimensions}, ...].
    """
    ticker_list = [t.strip() for t in tickers.split(",") if t.strip()]
    holding_set = set(t.strip() for t in holdings.split(",") if t.strip())

    # Parse prices into scoring format
    raw_prices = json.loads(prices_json) if prices_json else []
    from collections import defaultdict
    prices_dict: dict[str, list[dict]] = defaultdict(list)
    for r in raw_prices:
        prices_dict[r["ticker"]].append({
            "date": r["date"],
            "close": float(r["close"]),
            "high": float(r.get("high", r["close"])),
            "low": float(r.get("low", r["close"])),
            "volume": int(float(r.get("volume", 0))),
        })
    for t in prices_dict:
        prices_dict[t].sort(key=lambda r: r["date"])

    # Parse financials
    financials_dict: dict[str, list[dict]] = defaultdict(list)
    if financials_json:
        raw_fin = json.loads(financials_json)
        for r in raw_fin:
            ticker = r.get("_ticker", r.get("ticker", ""))
            if ticker:
                financials_dict[ticker].append(r)

    # Parse overrides
    overrides_dict = json.loads(overrides_json) if overrides_json else {}

    results = scoring.score_tickers(
        tickers=ticker_list,
        prices=dict(prices_dict),
        benchmark=benchmark,
        financials=dict(financials_dict) if financials_dict else None,
        overrides=overrides_dict if overrides_dict else None,
        holdings=holding_set if holding_set else None,
        style=style,
    )
    return json.dumps(results, default=str)


# ── Tool 5: Analyze Risk ─────────────────────────────────────────────

@mcp.tool()
async def analyze_risk(
    portfolio_json: str,
    period: str = "1y",
    corr_threshold: float = 0.85,
    candidates: str = "",
) -> str:
    """Analyze portfolio risk: concentration, correlation, volatility.

    Checks position concentration (>10% single stock), sector concentration
    (>30% single sector), pairwise correlation, and portfolio volatility.
    Optionally includes candidate tickers in correlation matrix to see how
    they correlate with existing holdings before executing swaps.

    Args:
        portfolio_json: JSON array of holdings, e.g.
            '[{"ticker": "AAPL", "weight": 0.20, "sector": "Technology"}, ...]'.
        period: History period for correlation/volatility calculation (default "1y").
            Uses yfinance period format: "1y", "2y", "6mo", etc.
        corr_threshold: Flag pairs with correlation above this (default 0.85).
        candidates: Optional comma-separated candidate tickers to include in
            correlation analysis (e.g. "META,AVGO"). These are included in the
            correlation matrix but not in concentration/weight checks.

    Returns:
        JSON with concentration analysis, correlation matrix (holdings only and
        with candidates if provided), portfolio volatility, risk flags, and
        overall risk level (LOW/MEDIUM/HIGH).
    """
    holdings = json.loads(portfolio_json)
    candidate_list = [t.strip() for t in candidates.split(",") if t.strip()] if candidates else None
    result = risk.analyze_risk(holdings, period, corr_threshold, candidates=candidate_list)
    return json.dumps(result, default=str)


# ── Tool 6: Compare Swaps ────────────────────────────────────────────

@mcp.tool()
async def compare_swaps(
    scores_json: str,
    holdings: str,
    candidates: str,
    threshold: int = 15,
) -> str:
    """Generate pairwise swap recommendations from scored tickers.

    Compares each holding against each candidate. Recommends a swap when
    the candidate's composite score exceeds the holding's score by >= threshold.

    Args:
        scores_json: JSON array of score dicts from score_tickers tool.
        holdings: Comma-separated current holding tickers.
        candidates: Comma-separated candidate tickers.
        threshold: Minimum score delta to recommend a swap (default 15).

    Returns:
        JSON with swap recommendations and full scorecard ranking.
    """
    scores_list = json.loads(scores_json)
    scores_map = {s["ticker"]: s for s in scores_list}
    holding_list = [t.strip() for t in holdings.split(",") if t.strip()]
    candidate_list = [t.strip() for t in candidates.split(",") if t.strip()]

    hold_scores = [(t, scores_map.get(t, {}).get("composite")) for t in holding_list]
    buy_scores = [(t, scores_map.get(t, {}).get("composite")) for t in candidate_list]

    hold_scores.sort(key=lambda x: x[1] or 999)
    buy_scores.sort(key=lambda x: -(x[1] or 0))

    swaps = []
    for hold_ticker, hold_score in hold_scores:
        if hold_score is None:
            continue
        for buy_ticker, buy_score in buy_scores:
            if buy_score is None:
                continue
            delta = buy_score - hold_score
            if delta >= threshold:
                swaps.append({
                    "sell": hold_ticker,
                    "sell_score": hold_score,
                    "buy": buy_ticker,
                    "buy_score": buy_score,
                    "delta": delta,
                })

    all_ranked = sorted(scores_list, key=lambda x: x.get("composite") or 0, reverse=True)
    scorecard = [{
        "ticker": s["ticker"],
        "composite": s.get("composite"),
        "action": s.get("action"),
        "is_holding": s["ticker"] in set(holding_list),
    } for s in all_ranked]

    return json.dumps({"swaps": swaps, "scorecard": scorecard}, default=str)


# ── Tool 7: Run Backtest ─────────────────────────────────────────────

@mcp.tool()
async def run_backtest(
    prices_json: str,
    strategy_json: str = "",
    benchmark: str = "SPY",
    cost_bps: int = 10,
    scores_json: str = "",
    ranking_mode: str = "momentum",
) -> str:
    """Backtest a rotation strategy on historical price data.

    Uses price momentum ranking by default. Simulates monthly rebalancing
    with trailing stops and transaction costs.

    Args:
        prices_json: JSON of price data from fetch_prices (the "prices" array).
        strategy_json: Optional JSON strategy config, e.g.
            '{"rebalance": "monthly", "max_positions": 5, "sizing": "equal_weight",
              "entry": {"min_score": 60}, "exit": {"trailing_stop": 0.15}}'.
            If empty, uses sensible defaults.
        benchmark: Benchmark ticker (default "SPY").
        cost_bps: Transaction cost in basis points (default 10).
        scores_json: Optional JSON of score results from score_tickers tool.
            When provided with ranking_mode="score", uses composite scores
            for initial allocation instead of price momentum.
        ranking_mode: "momentum" (default, rank by 3M price return) or "score"
            (rank by composite scores for initial allocation). When "score",
            the entry.min_score threshold from strategy is honored.
            Note: subsequent rebalances use momentum since scores can't be
            recomputed mid-backtest without financials at each date.

    Returns:
        JSON with metrics (total_return, CAGR, Sharpe, Sortino, max_drawdown,
        win_rate), equity_curve, trade_log, and monthly_returns.
    """
    from collections import defaultdict

    raw_prices = json.loads(prices_json) if prices_json else []
    prices_dict: dict[str, dict[str, float]] = defaultdict(dict)
    for r in raw_prices:
        prices_dict[r["date"]][r["ticker"]] = float(r["close"])
    prices_sorted = dict(sorted(prices_dict.items()))

    strategy = json.loads(strategy_json) if strategy_json else {
        "rebalance": "monthly",
        "max_positions": 5,
        "sizing": "equal_weight",
        "entry": {"min_score": 60},
        "exit": {"trailing_stop": 0.15, "min_score": 40},
    }

    # Parse scores into {ticker: composite_score}
    bt_scores = None
    if scores_json and ranking_mode == "score":
        raw_scores = json.loads(scores_json)
        bt_scores = {
            s["ticker"]: s["composite"]
            for s in raw_scores
            if isinstance(s, dict) and s.get("composite") is not None
        }

    result = backtest.run_backtest(
        prices_sorted, strategy, benchmark, cost_bps,
        scores=bt_scores, ranking_mode=ranking_mode,
    )
    return json.dumps(result, default=str)


# ── Tool 8: Stress Test ──────────────────────────────────────────────

@mcp.tool()
async def stress_test(
    portfolio_json: str,
    prices_json: str,
    factor_data_json: str = "",
    benchmark: str = "SPY",
    run_scenarios: bool = True,
    run_shocks: bool = True,
    run_factors: bool = True,
    run_montecarlo: bool = True,
    n_simulations: int = 10000,
) -> str:
    """Run comprehensive portfolio stress tests.

    Includes: historical scenario replay (GFC, COVID, etc.), hypothetical
    rate/equity/sector shocks, Fama-French factor decomposition, and
    Monte Carlo simulation.

    Args:
        portfolio_json: JSON array of holdings, e.g.
            '[{"ticker": "AAPL", "weight": 0.20, "sector": "Technology"}, ...]'.
        prices_json: JSON of price data from fetch_prices (the "prices" array).
        factor_data_json: Optional JSON of Fama-French factors from fetch_ff_factors.
        benchmark: Benchmark ticker (default "SPY").
        run_scenarios: Run historical scenario replay (default True).
        run_shocks: Run hypothetical shocks (default True).
        run_factors: Run Fama-French factor decomposition (default True).
        run_montecarlo: Run Monte Carlo simulation (default True).
        n_simulations: Number of Monte Carlo simulations (default 10000).

    Returns:
        JSON with scenario results, shock estimates, factor betas/alpha,
        Monte Carlo VaR/CVaR, risk flags, and overall risk level.
    """
    from collections import defaultdict

    holdings = json.loads(portfolio_json)

    raw_prices = json.loads(prices_json) if prices_json else []
    prices_dict: dict[str, dict[str, float]] = defaultdict(dict)
    for r in raw_prices:
        prices_dict[r["date"]][r["ticker"]] = float(r["close"])
    prices_sorted = dict(sorted(prices_dict.items()))

    factor_data = None
    if factor_data_json:
        raw_factors = json.loads(factor_data_json)
        factor_data = {}
        for row in raw_factors:
            date = row.pop("date")
            factor_data[date] = {k: float(v) for k, v in row.items()}

    result = stress.run_stress_test(
        holdings=holdings,
        prices=prices_sorted,
        factor_data=factor_data,
        benchmark=benchmark,
        run_scenarios=run_scenarios,
        run_shocks=run_shocks,
        run_factors=run_factors,
        run_montecarlo=run_montecarlo,
        n_simulations=n_simulations,
    )
    return json.dumps(result, default=str)


# ── Tool 9: Compute Attribution ──────────────────────────────────────

@mcp.tool()
async def compute_attribution(
    trades_json: str,
    prices_json: str,
    benchmark: str = "SPY",
) -> str:
    """Analyze trade attribution and rotation effectiveness.

    Matches BUY/SELL trades into round-trips, computes swap alpha
    (what the replaced stock did), benchmark-relative returns,
    and pattern analysis with calibration recommendations.

    Args:
        trades_json: JSON array of trades, e.g.
            '[{"date": "2025-01-15", "action": "BUY", "ticker": "NVDA",
              "shares": 50, "price": 120.00, "score": 75, "replaced": "INTC"}, ...]'.
        prices_json: JSON of price data from fetch_prices (the "prices" array).
        benchmark: Benchmark ticker (default "SPY").

    Returns:
        JSON with round_trips (per-trade attribution, swap alpha) and
        patterns (win rate, avg return, score-return correlation, recommendations).
    """
    from collections import defaultdict

    trades = json.loads(trades_json)

    raw_prices = json.loads(prices_json) if prices_json else []
    prices_dict: dict[str, dict[str, float]] = defaultdict(dict)
    for r in raw_prices:
        prices_dict[r["date"]][r["ticker"]] = float(r["close"])
    prices_sorted = dict(sorted(prices_dict.items()))

    result = attribution.compute_attribution(trades, prices_sorted, benchmark)
    return json.dumps(result, default=str)


# ── Tool 10: Run Pipeline ────────────────────────────────────────────

@mcp.tool()
async def run_pipeline(
    portfolio_json: str,
    candidates: str,
    style: str = "garp",
    overrides_json: str = "",
    benchmark: str = "SPY",
    stages: str = "all",
    skip_refresh: bool = False,
    start_date: str = "",
    end_date: str = "",
    source: str = "",
) -> str:
    """Run the full 6-stage rotation analysis pipeline.

    Stages: refresh (fetch prices) -> score (5-dimension scoring) ->
    risk (concentration/correlation) -> compare (swap recommendations) ->
    backtest (historical simulation) -> report (markdown summary).

    This is the main entry point for a complete rotation analysis.

    Args:
        portfolio_json: JSON array of current holdings, e.g.
            '[{"ticker": "AAPL", "weight": 0.20, "sector": "Technology"},
              {"ticker": "MSFT", "weight": 0.15, "sector": "Technology"}, ...]'.
        candidates: Comma-separated candidate tickers to evaluate (e.g. "META,AVGO,LLY").
        style: Investment style -- "garp" (default), "value", "growth", "momentum", "event_driven".
        overrides_json: Optional JSON of manual score overrides, e.g.
            '{"AAPL": {"thesis": 75, "catalyst": 60}}'.
        benchmark: Benchmark ticker (default "SPY").
        stages: Comma-separated stages or "all" (default "all").
        skip_refresh: Skip data fetching, use cached data (default False).
        start_date: Price data start date YYYY-MM-DD (default: 3 years ago).
        end_date: Price data end date YYYY-MM-DD (default: today).
        source: Data source for price fetching -- "auto" (API first, yfinance fallback),
            "api", "financial-datasets" (same as "api"), or "yfinance".
            If empty, reads PORTFOLIO_ROTATION_SOURCE env var (default: "auto").

    Returns:
        JSON with complete pipeline results: scores, swap recommendations,
        risk analysis, backtest metrics, and markdown report.
    """
    holdings = json.loads(portfolio_json)
    candidate_list = [t.strip() for t in candidates.split(",") if t.strip()]
    overrides = json.loads(overrides_json) if overrides_json else None
    stage_list = None if stages == "all" else [s.strip() for s in stages.split(",")]

    result = pipeline.run_pipeline(
        holdings=holdings,
        candidates=candidate_list,
        style=style,
        overrides=overrides,
        benchmark=benchmark,
        stages=stage_list,
        skip_refresh=skip_refresh,
        start_date=start_date or None,
        end_date=end_date or None,
        source=source,
    )
    return json.dumps(result, default=str)


# ── Tool 11: Get Skill ───────────────────────────────────────────────

@mcp.tool()
async def get_skill(name: str = "") -> str:
    """Get domain knowledge for portfolio rotation analysis.

    Returns detailed methodology, decision rules, scoring criteria, and
    interpretation guidelines. Call this BEFORE using other tools to
    understand how to interpret their outputs correctly.

    Available skills:
    - "scoring-framework": 5-dimension scoring system (0-100), criteria
      matrices, decision thresholds, auto vs manual dimensions
    - "swap-methodology": Swap decision rules, delta thresholds, ranking
      logic, edge cases, post-swap monitoring
    - "risk-management": Concentration limits, correlation checks,
      volatility thresholds, risk level classification
    - "style-presets": GARP/value/growth/momentum/event-driven weight
      matrices and when to use each style
    - "rotation-pipeline": 6-stage pipeline orchestration, stage
      dependencies, partial run options

    Args:
        name: Skill name to retrieve. Use "" or "all" to list available
            skills with brief descriptions.

    Returns:
        Markdown content with the requested domain knowledge, or a list
        of available skills if no name is provided.
    """
    from .skills import get_skill_content, get_skill_names

    if not name or name == "all":
        names = get_skill_names()
        descriptions = {
            "scoring-framework": "5-dimension scoring (0-100), criteria matrices, decision thresholds",
            "swap-methodology": "Swap decision rules, delta >= 15 threshold, ranking, edge cases",
            "risk-management": "Concentration limits, correlation checks, volatility, risk levels",
            "style-presets": "GARP/value/growth/momentum/event-driven weight matrices",
            "rotation-pipeline": "6-stage pipeline orchestration and dependencies",
        }
        lines = ["Available skills:\n"]
        for n in names:
            desc = descriptions.get(n, "")
            lines.append(f"- **{n}**: {desc}")
        lines.append("\nCall get_skill(name=\"<skill-name>\") to retrieve full content.")
        return "\n".join(lines)

    content = get_skill_content(name)
    if content is None:
        available = ", ".join(get_skill_names())
        return f"Unknown skill: '{name}'. Available skills: {available}"
    return content


# ── Entry point ──────────────────────────────────────────────────────

def main():
    logger.info("Starting Portfolio Rotation MCP Server...")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
