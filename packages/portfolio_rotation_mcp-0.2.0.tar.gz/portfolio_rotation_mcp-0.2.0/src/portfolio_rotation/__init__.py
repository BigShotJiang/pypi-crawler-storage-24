"""Portfolio Rotation MCP Server -- 5-dimension scoring, risk analysis, backtesting."""

__version__ = "0.2.0"
