"""
Orchestrate the full rotation strategy pipeline.
Chains: refresh -> score -> risk -> compare -> backtest -> report.
"""

from collections import defaultdict
from datetime import datetime, timedelta

from . import data_fetch, scoring, risk, backtest


ALL_STAGES = ["refresh", "score", "risk", "compare", "backtest", "report"]


def _prices_list_to_scoring_format(rows: list[dict]) -> dict[str, list[dict]]:
    """Convert flat price rows to {ticker: [{date, close, high, low, volume}, ...]}."""
    data: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        data[r["ticker"]].append({
            "date": r["date"],
            "close": float(r["close"]),
            "high": float(r.get("high", r["close"])),
            "low": float(r.get("low", r["close"])),
            "volume": int(float(r.get("volume", 0))),
        })
    for t in data:
        data[t].sort(key=lambda r: r["date"])
    return dict(data)


def _prices_list_to_backtest_format(rows: list[dict]) -> dict[str, dict[str, float]]:
    """Convert flat price rows to {date: {ticker: price}}."""
    prices: dict[str, dict[str, float]] = defaultdict(dict)
    for r in rows:
        prices[r["date"]][r["ticker"]] = float(r["close"])
    return dict(sorted(prices.items()))


def _financials_list_to_dict(rows: list[dict]) -> dict[str, list[dict]]:
    """Convert flat financials list to {ticker: [statements...]}."""
    data: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        ticker = r.get("_ticker", r.get("ticker", ""))
        if ticker:
            data[ticker].append(r)
    return dict(data)


def run_pipeline(
    holdings: list[dict],
    candidates: list[str],
    style: str = "garp",
    overrides: dict[str, dict] | None = None,
    benchmark: str = "SPY",
    stages: list[str] | None = None,
    skip_refresh: bool = False,
    start_date: str | None = None,
    end_date: str | None = None,
    strategy: dict | None = None,
    source: str = "",
) -> dict:
    """
    Run the full rotation analysis pipeline.

    Args:
        holdings: List of {ticker, weight, sector}.
        candidates: List of candidate tickers to evaluate.
        style: Investment style (garp, value, growth, momentum, event_driven).
        overrides: Optional manual score overrides {ticker: {dimension: score}}.
        benchmark: Benchmark ticker.
        stages: Which stages to run (default: all).
        skip_refresh: If True, skip data fetching (use empty prices).
        start_date: Price data start date (default: 3 years ago).
        end_date: Price data end date (default: today).
        strategy: Backtest strategy config dict.
        source: Data source for prices -- "auto", "api", "financial-datasets", "yfinance",
            or "" (use env var).

    Returns:
        Complete pipeline results dict with scores, swaps, risk, backtest, report.
    """
    stages = stages or ALL_STAGES
    end_date = end_date or datetime.now().strftime("%Y-%m-%d")
    start_date = start_date or (datetime.now() - timedelta(days=365 * 3)).strftime("%Y-%m-%d")

    all_tickers = sorted(set([h["ticker"] for h in holdings] + candidates + [benchmark]))
    holding_tickers = set(h["ticker"] for h in holdings)

    result: dict = {
        "holdings": holdings,
        "candidates": candidates,
        "style": style,
        "stages_run": [],
        "stages_failed": [],
    }

    price_rows: list[dict] = []

    # Stage 1: Refresh
    if "refresh" in stages and not skip_refresh:
        try:
            price_rows = data_fetch.fetch_prices(all_tickers, start_date, end_date, source)
            result["refresh"] = {"status": "ok", "rows": len(price_rows)}
            result["stages_run"].append("refresh")
        except Exception as e:
            result["refresh"] = {"status": "error", "error": str(e)}
            result["stages_failed"].append("refresh")

    prices_scoring = _prices_list_to_scoring_format(price_rows) if price_rows else {}
    prices_backtest = _prices_list_to_backtest_format(price_rows) if price_rows else {}

    # Stage 2: Score
    scores_list = []
    if "score" in stages:
        try:
            score_tickers = sorted(set([h["ticker"] for h in holdings] + candidates))
            scores_list = scoring.score_tickers(
                tickers=score_tickers,
                prices=prices_scoring,
                benchmark=benchmark,
                overrides=overrides,
                holdings=holding_tickers,
                style=style,
            )
            result["scores"] = scores_list
            result["stages_run"].append("score")
        except Exception as e:
            result["scores"] = {"error": str(e)}
            result["stages_failed"].append("score")

    # Stage 3: Risk (include candidates in correlation matrix)
    if "risk" in stages:
        try:
            risk_result = risk.analyze_risk(holdings, candidates=candidates)
            result["risk"] = risk_result
            result["stages_run"].append("risk")
        except Exception as e:
            result["risk"] = {"error": str(e)}
            result["stages_failed"].append("risk")

    # Stage 4: Compare (swap recommendations)
    if "compare" in stages and scores_list:
        try:
            scores_map = {s["ticker"]: s for s in scores_list}
            hold_scores = [(h["ticker"], scores_map.get(h["ticker"], {}).get("composite"))
                           for h in holdings]
            buy_scores = [(c, scores_map.get(c, {}).get("composite")) for c in candidates]

            hold_scores.sort(key=lambda x: x[1] or 999)
            buy_scores.sort(key=lambda x: -(x[1] or 0))

            swaps = []
            for hold_ticker, hold_score in hold_scores:
                if hold_score is None:
                    continue
                for buy_ticker, buy_score in buy_scores:
                    if buy_score is None:
                        continue
                    delta = buy_score - hold_score
                    if delta >= 15:
                        swaps.append({
                            "sell": hold_ticker,
                            "sell_score": hold_score,
                            "buy": buy_ticker,
                            "buy_score": buy_score,
                            "delta": delta,
                        })

            result["swaps"] = swaps
            result["stages_run"].append("compare")
        except Exception as e:
            result["swaps"] = {"error": str(e)}
            result["stages_failed"].append("compare")

    # Stage 5: Backtest (use composite scores when available)
    if "backtest" in stages and prices_backtest:
        try:
            bt_strategy = strategy or {
                "rebalance": "monthly",
                "max_positions": 5,
                "sizing": "equal_weight",
                "entry": {"min_score": 60},
                "exit": {"trailing_stop": 0.15, "min_score": 40},
            }
            # Pass composite scores for score-based initial allocation
            bt_scores = {}
            bt_ranking_mode = "momentum"
            if scores_list:
                bt_scores = {
                    s["ticker"]: s["composite"]
                    for s in scores_list
                    if isinstance(s, dict) and s.get("composite") is not None
                }
                if bt_scores:
                    bt_ranking_mode = "score"

            bt_result = backtest.run_backtest(
                prices_backtest, bt_strategy, benchmark,
                scores=bt_scores if bt_scores else None,
                ranking_mode=bt_ranking_mode,
            )
            result["backtest"] = bt_result
            result["stages_run"].append("backtest")
        except Exception as e:
            result["backtest"] = {"error": str(e)}
            result["stages_failed"].append("backtest")

    # Stage 6: Report
    if "report" in stages:
        try:
            report_lines = _generate_report(result, style)
            result["report"] = report_lines
            result["stages_run"].append("report")
        except Exception as e:
            result["report"] = {"error": str(e)}
            result["stages_failed"].append("report")

    return result


def _generate_report(result: dict, style: str) -> str:
    """Generate markdown summary report from pipeline results."""
    lines = []
    lines.append("# Portfolio Rotation Report")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"Style: {style}")
    lines.append("")

    # Scores
    scores = result.get("scores")
    if isinstance(scores, list) and scores:
        lines.append("## Scorecard")
        lines.append("")
        lines.append("| Ticker | Thesis | Valuation | Momentum | Catalyst | Technical | **Composite** | Coverage | Action |")
        lines.append("|--------|--------|-----------|----------|----------|-----------|---------------|----------|--------|")
        for s in sorted(scores, key=lambda x: x.get("composite") or 0, reverse=True):
            auto = set(s.get("auto_dimensions", []))
            manual = set(s.get("manual_dimensions", []))
            defaulted = set(s.get("defaulted_dimensions", []))
            def cell(dim):
                v = s.get(dim)
                if v is None:
                    return "--"
                if dim in manual:
                    return f"{v}\u1d39"  # superscript M
                elif dim in defaulted:
                    return f"{v}\u1d30"  # superscript D
                else:
                    return f"{v}\u1d2c"  # superscript A
            coverage = s.get("coverage", "?/5")
            lines.append(
                f"| {s['ticker']} | {cell('thesis')} | {cell('valuation')} | "
                f"{cell('momentum')} | {cell('catalyst')} | {cell('technical')} | "
                f"**{s.get('composite', '--')}** | {coverage} | {s.get('action', '')} |"
            )
        lines.append("")
        lines.append("ᴬ = auto-scored, ᴹ = manual override, ᴰ = defaulted (neutral 50)")
        lines.append("")
        has_defaulted = any(s.get("defaulted_dimensions") for s in scores)
        if has_defaulted:
            lines.append("> **Note**: Dimensions marked ᴰ used a neutral default of 50. "
                         "Provide manual overrides for thesis and catalyst to improve accuracy.")
            lines.append("")

    # Swaps
    swaps = result.get("swaps")
    if isinstance(swaps, list):
        lines.append("## Swap Recommendations")
        lines.append("")
        if swaps:
            lines.append("| Sell | Hold Score | Buy | Buy Score | Delta |")
            lines.append("|------|-----------|-----|-----------|-------|")
            for s in swaps:
                lines.append(f"| {s['sell']} | {s['sell_score']:.0f} | {s['buy']} | {s['buy_score']:.0f} | +{s['delta']:.0f} |")
        else:
            lines.append("No swaps meet the threshold (delta >= 15). Portfolio holds.")
        lines.append("")

    # Risk
    risk_data = result.get("risk")
    if isinstance(risk_data, dict) and "concentration" in risk_data:
        lines.append("## Risk Summary")
        lines.append("")
        lines.append(f"- **Portfolio Volatility**: {risk_data.get('portfolio_volatility', 'N/A')}")
        lines.append(f"- **HHI Concentration**: {risk_data['concentration']['hhi']}")
        lines.append(f"- **Effective Positions**: {risk_data['concentration']['effective_positions']}")
        lines.append(f"- **Risk Level**: {risk_data.get('risk_level', 'N/A')}")
        for flag in risk_data.get("all_flags", []):
            lines.append(f"- WARNING: {flag}")
        lines.append("")

        # Show expanded correlation matrix if candidates were included
        corr_with_cand = risk_data.get("correlation_with_candidates")
        if corr_with_cand:
            cand_set = set(risk_data.get("candidates", []))
            corr_tickers = sorted(corr_with_cand.keys())
            lines.append("### Correlation Matrix (Holdings + Candidates)")
            lines.append("")
            header = "| | " + " | ".join(
                f"**{t}**" if t in cand_set else t for t in corr_tickers
            ) + " |"
            lines.append(header)
            lines.append("|" + "---|" * (len(corr_tickers) + 1))
            for t1 in corr_tickers:
                label = f"**{t1}**" if t1 in cand_set else t1
                cells = []
                for t2 in corr_tickers:
                    val = corr_with_cand.get(t1, {}).get(t2, 0)
                    cells.append(f"{val:.2f}" if isinstance(val, (int, float)) else str(val))
                lines.append(f"| {label} | " + " | ".join(cells) + " |")
            lines.append("")
            lines.append("*Candidate tickers shown in **bold**.*")
            lines.append("")

    # Backtest
    bt = result.get("backtest")
    if isinstance(bt, dict) and "metrics" in bt:
        m = bt["metrics"]
        lines.append("## Backtest Results")
        lines.append("")
        lines.append("| Metric | Strategy | Benchmark |")
        lines.append("|--------|----------|-----------|")
        lines.append(f"| Total Return | {m['total_return_pct']}% | {m['benchmark_return_pct']}% |")
        lines.append(f"| CAGR | {m['cagr_pct']}% | -- |")
        lines.append(f"| Sharpe | {m['sharpe_ratio']} | -- |")
        lines.append(f"| Max Drawdown | {m['max_drawdown_pct']}% | -- |")
        lines.append(f"| Win Rate | {m['win_rate_pct']}% | -- |")
        lines.append("")

    lines.append("---")
    lines.append("*This is a decision-support tool, not investment advice.*")

    return "\n".join(lines)
