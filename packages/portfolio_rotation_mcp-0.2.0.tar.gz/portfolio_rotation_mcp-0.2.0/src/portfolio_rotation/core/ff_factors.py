"""
Fama-French factor data downloader.
Downloads 5-factor + momentum daily data from Kenneth French's Data Library.
"""

import io
import zipfile

import httpx

FF5_URL = "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_5_Factors_2x3_daily_CSV.zip"
MOM_URL = "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Momentum_Factor_daily_CSV.zip"


def _download_and_extract(url: str) -> str | None:
    """Download a zip file and return the CSV content as string."""
    r = httpx.get(url, timeout=60.0, follow_redirects=True)
    r.raise_for_status()
    z = zipfile.ZipFile(io.BytesIO(r.content))
    csv_names = [n for n in z.namelist() if n.lower().endswith(".csv")]
    if not csv_names:
        return None
    return z.read(csv_names[0]).decode("utf-8", errors="replace")


def _parse_ff5(text: str) -> dict[str, dict[str, float]]:
    """Parse the FF 5-factor daily CSV."""
    factors: dict[str, dict[str, float]] = {}
    in_data = False

    for line in text.splitlines():
        line = line.strip()
        if not line:
            if in_data:
                break
            continue

        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 6 and parts[0].isdigit() and len(parts[0]) == 8:
            in_data = True
            date_str = parts[0]
            date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"
            try:
                factors[date] = {
                    "MKT-RF": float(parts[1]) / 100,
                    "SMB": float(parts[2]) / 100,
                    "HML": float(parts[3]) / 100,
                    "RMW": float(parts[4]) / 100,
                    "CMA": float(parts[5]) / 100,
                    "RF": float(parts[6]) / 100 if len(parts) > 6 else 0.0,
                }
            except (ValueError, IndexError):
                continue

    return factors


def _parse_momentum(text: str) -> dict[str, float]:
    """Parse the momentum factor daily CSV."""
    factors: dict[str, float] = {}
    in_data = False

    for line in text.splitlines():
        line = line.strip()
        if not line:
            if in_data:
                break
            continue

        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 2 and parts[0].isdigit() and len(parts[0]) == 8:
            in_data = True
            date_str = parts[0]
            date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"
            try:
                factors[date] = float(parts[1]) / 100
            except (ValueError, IndexError):
                continue

    return factors


def fetch_ff_factors(start_date: str = "2000-01-01") -> list[dict]:
    """
    Download Fama-French 5-factor + momentum daily data.

    Args:
        start_date: Filter to dates on or after this date (YYYY-MM-DD).

    Returns:
        List of dicts with keys: date, MKT-RF, SMB, HML, RMW, CMA, MOM, RF.
        All values are decimals (not percent).
    """
    ff5_text = _download_and_extract(FF5_URL)
    mom_text = _download_and_extract(MOM_URL)

    if not ff5_text:
        return []

    ff5 = _parse_ff5(ff5_text)
    mom = _parse_momentum(mom_text) if mom_text else {}

    rows = []
    for date in sorted(ff5.keys()):
        if date < start_date:
            continue
        row = {"date": date}
        row.update(ff5[date])
        row["MOM"] = mom.get(date, 0.0)
        rows.append(row)

    return rows
