"""
Portfolio risk analytics: correlation, concentration, volatility.
"""

import math
from collections import defaultdict


def analyze_concentration(holdings: list[dict]) -> dict:
    """
    Analyze sector and position concentration.

    Args:
        holdings: List of {ticker, weight, sector}.

    Returns:
        Dict with sector_weights, position_weights, hhi, effective_positions, flags.
    """
    sector_weights: dict[str, float] = defaultdict(float)
    position_weights: dict[str, float] = {}
    flags = []

    for h in holdings:
        ticker = h.get("ticker", "UNKNOWN")
        weight = float(h.get("weight", 0))
        sector = h.get("sector", "Unknown")
        position_weights[ticker] = weight
        sector_weights[sector] += weight

    for ticker, w in position_weights.items():
        if w > 0.10:
            flags.append(f"CONCENTRATION: {ticker} weight {w:.1%} exceeds 10% cap")

    for sector, w in sector_weights.items():
        if w > 0.30:
            flags.append(f"SECTOR: {sector} weight {w:.1%} exceeds 30% cap")

    # Include unallocated cash in HHI to reflect true concentration.
    # A portfolio with 55% cash is highly concentrated — ignoring cash
    # would severely understate HHI (e.g. 0.0725 vs correct 0.375).
    total_active_weight = sum(position_weights.values())
    cash_weight = max(1.0 - total_active_weight, 0.0)
    all_weights = list(position_weights.values())
    if cash_weight > 0.001:
        all_weights.append(cash_weight)
    hhi = sum(w ** 2 for w in all_weights)
    effective_positions = 1 / hhi if hhi > 0 else 0

    return {
        "sector_weights": dict(sector_weights),
        "position_weights": position_weights,
        "cash_weight": round(cash_weight, 4),
        "hhi": round(hhi, 4),
        "effective_positions": round(effective_positions, 1),
        "flags": flags,
    }


def find_high_correlations(corr_matrix: dict, threshold: float = 0.85) -> list[dict]:
    """Find pairs with correlation above threshold."""
    pairs = []
    tickers = list(corr_matrix.keys())
    for i, t1 in enumerate(tickers):
        for j, t2 in enumerate(tickers):
            if j > i:
                corr_val = corr_matrix[t1].get(t2, 0)
                if abs(corr_val) > threshold:
                    pairs.append({
                        "pair": f"{t1}/{t2}",
                        "correlation": corr_val,
                        "flag": "HIGH" if corr_val > threshold else "INVERSE",
                    })
    return pairs


def analyze_risk(
    holdings: list[dict],
    period: str = "1y",
    corr_threshold: float = 0.85,
    candidates: list[str] | None = None,
) -> dict:
    """
    Full portfolio risk analysis: concentration, correlation, volatility.

    Args:
        holdings: List of {ticker, weight, sector}.
        period: History period for yfinance (e.g., '1y', '2y').
        corr_threshold: Threshold for flagging high correlations.
        candidates: Optional candidate tickers to include in correlation matrix
            (but not in concentration/weight checks since they're not yet held).

    Returns:
        Dict with concentration, correlation_matrix, correlation_with_candidates,
        high_correlations, portfolio_volatility, ticker_volatilities, all_flags, risk_level.
    """
    tickers = [h["ticker"] for h in holdings]
    weights = {h["ticker"]: float(h["weight"]) for h in holdings}
    candidates = candidates or []
    # All tickers for correlation: holdings + candidates (deduplicated)
    all_corr_tickers = sorted(set(tickers + candidates))

    result: dict = {
        "portfolio": "current",
        "tickers": tickers,
        "weights": weights,
    }
    if candidates:
        result["candidates"] = candidates

    result["concentration"] = analyze_concentration(holdings)

    # Try to compute correlation and volatility with yfinance + numpy
    try:
        import yfinance as yf
        import numpy as np
        import warnings
        warnings.filterwarnings("ignore")

        data = yf.download(all_corr_tickers, period=period, progress=False)
        if not data.empty:
            if hasattr(data.columns, "levels") and len(data.columns.levels) > 1:
                prices = data["Close"] if "Close" in data.columns.get_level_values(0) else data["Adj Close"]
            else:
                prices = data[["Close"]].rename(columns={"Close": all_corr_tickers[0]}) if len(all_corr_tickers) == 1 else data["Close"]

            returns = prices.pct_change().dropna()

            # Holdings-only correlation matrix (backward compatible)
            holding_cols = [t for t in tickers if t in returns.columns]
            if holding_cols:
                corr = returns[holding_cols].corr().to_dict()
                result["correlation_matrix"] = corr
                result["high_correlations"] = find_high_correlations(corr, corr_threshold)

            # Expanded correlation matrix including candidates
            if candidates:
                all_cols = [t for t in all_corr_tickers if t in returns.columns]
                if all_cols:
                    corr_full = returns[all_cols].corr().to_dict()
                    result["correlation_with_candidates"] = corr_full
                    result["high_correlations_with_candidates"] = find_high_correlations(corr_full, corr_threshold)

            # Portfolio volatility (holdings only)
            available = [t for t in tickers if t in returns.columns]
            if available:
                w_arr = np.array([weights[t] for t in available])
                total_weight = float(w_arr.sum())
                cov_matrix = returns[available].cov() * 252
                port_var = float(w_arr @ cov_matrix.values @ w_arr)
                result["portfolio_volatility"] = round(math.sqrt(port_var), 4)
                result["portfolio_volatility_method"] = "daily_returns_annualized"
                result["invested_weight"] = round(total_weight, 4)

            # Per-ticker volatility (all tickers including candidates)
            ticker_vols = {}
            for t in all_corr_tickers:
                if t in returns.columns:
                    ticker_vols[t] = round(float(returns[t].std() * math.sqrt(252)), 4)
            result["ticker_volatilities"] = ticker_vols
            result["volatility_method"] = "daily_std_annualized_sqrt252"
    except ImportError:
        result["data_error"] = "yfinance or numpy not installed"
    except Exception as e:
        result["data_error"] = str(e)

    # Summary flags
    all_flags = result["concentration"].get("flags", [])
    if "high_correlations" in result:
        for pair in result["high_correlations"]:
            all_flags.append(f"CORRELATION: {pair['pair']} = {pair['correlation']:.2f}")
    result["all_flags"] = all_flags
    result["risk_level"] = "HIGH" if len(all_flags) > 2 else ("MEDIUM" if all_flags else "LOW")

    return result
