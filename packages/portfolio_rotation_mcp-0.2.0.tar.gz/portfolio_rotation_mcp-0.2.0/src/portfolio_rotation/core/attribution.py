"""
Trade attribution and rotation effectiveness analysis.
"""

import math
from datetime import datetime


def pair_trades(trades: list[dict]) -> list[dict]:
    """Match BUY and SELL trades into round-trips."""
    open_positions: dict[str, list[dict]] = {}
    round_trips = []

    for trade in sorted(trades, key=lambda t: t["date"]):
        if trade["action"] == "BUY":
            if trade["ticker"] not in open_positions:
                open_positions[trade["ticker"]] = []
            open_positions[trade["ticker"]].append(trade)
        elif trade["action"] == "SELL":
            if trade["ticker"] in open_positions and open_positions[trade["ticker"]]:
                buy = open_positions[trade["ticker"]].pop(0)
                round_trips.append({
                    "ticker": trade["ticker"],
                    "entry_date": buy["date"],
                    "entry_price": buy["price"],
                    "exit_date": trade["date"],
                    "exit_price": trade["price"],
                    "shares": min(buy["shares"], trade["shares"]),
                    "entry_score": buy.get("score"),
                    "replaced_ticker": buy.get("replaced"),
                    "return_pct": (trade["price"] / buy["price"] - 1) * 100,
                    "pnl": (trade["price"] - buy["price"]) * min(buy["shares"], trade["shares"]),
                    "holding_days": (datetime.strptime(trade["date"], "%Y-%m-%d") -
                                     datetime.strptime(buy["date"], "%Y-%m-%d")).days,
                })

    for ticker, buys in open_positions.items():
        for buy in buys:
            round_trips.append({
                "ticker": ticker,
                "entry_date": buy["date"],
                "entry_price": buy["price"],
                "exit_date": "OPEN",
                "exit_price": None,
                "shares": buy["shares"],
                "entry_score": buy.get("score"),
                "replaced_ticker": buy.get("replaced"),
                "return_pct": None,
                "pnl": None,
                "holding_days": None,
            })

    return round_trips


def compute_swap_alpha(
    round_trips: list[dict], prices: dict[str, dict[str, float]]
) -> list[dict]:
    """For each swap, compute what the replaced stock did after the swap."""
    for trip in round_trips:
        if trip["replaced_ticker"] and trip["exit_date"] != "OPEN":
            replaced = trip["replaced_ticker"]
            replaced_entry = prices.get(trip["entry_date"], {}).get(replaced)
            replaced_exit = prices.get(trip["exit_date"], {}).get(replaced)

            if replaced_entry and replaced_exit and replaced_entry > 0:
                replaced_return = (replaced_exit / replaced_entry - 1) * 100
                trip["replaced_return_pct"] = round(replaced_return, 2)
                trip["swap_alpha_pct"] = round(trip["return_pct"] - replaced_return, 2)
            else:
                trip["replaced_return_pct"] = None
                trip["swap_alpha_pct"] = None
        else:
            trip["replaced_return_pct"] = None
            trip["swap_alpha_pct"] = None

    return round_trips


def compute_benchmark_relative(
    round_trips: list[dict],
    prices: dict[str, dict[str, float]],
    benchmark: str = "SPY",
) -> list[dict]:
    """Add benchmark-relative return for each trade."""
    for trip in round_trips:
        if trip["exit_date"] != "OPEN":
            bench_entry = prices.get(trip["entry_date"], {}).get(benchmark)
            bench_exit = prices.get(trip["exit_date"], {}).get(benchmark)

            if bench_entry and bench_exit and bench_entry > 0:
                bench_return = (bench_exit / bench_entry - 1) * 100
                trip["benchmark_return_pct"] = round(bench_return, 2)
                trip["vs_benchmark_pct"] = round(trip["return_pct"] - bench_return, 2)
            else:
                trip["benchmark_return_pct"] = None
                trip["vs_benchmark_pct"] = None

    return round_trips


def _generate_recommendations(completed, swaps, score_corr):
    recs = []
    if swaps:
        swap_win_rate = sum(1 for s in swaps if s["swap_alpha_pct"] > 0) / len(swaps)
        if swap_win_rate < 0.5:
            recs.append("Swap win rate below 50% -- consider raising minimum score delta threshold from 15 to 20+")
        if swap_win_rate > 0.65:
            recs.append("Strong swap alpha -- current scoring calibration is working well")

    if score_corr is not None:
        if score_corr > 0.3:
            recs.append(f"Score-return correlation = {score_corr} (positive) -- scoring model has predictive value")
        elif score_corr < 0.1:
            recs.append(f"Score-return correlation = {score_corr} (weak) -- consider recalibrating scoring weights")

    short_trades = [t for t in completed if t["holding_days"] and t["holding_days"] < 30]
    if short_trades:
        avg_short = sum(t["return_pct"] for t in short_trades) / len(short_trades)
        if avg_short < 0:
            recs.append(f"Short-term trades (<30 days) averaging {avg_short:.1f}% -- consider minimum holding period of 30+ days")

    if not recs:
        recs.append("Insufficient data for strong recommendations -- continue tracking")

    return recs


def analyze_patterns(round_trips: list[dict]) -> dict:
    """Identify patterns across completed trades."""
    completed = [t for t in round_trips if t["exit_date"] != "OPEN" and t["return_pct"] is not None]

    if not completed:
        return {"note": "No completed trades to analyze"}

    returns = [t["return_pct"] for t in completed]
    wins = [t for t in completed if t["return_pct"] > 0]
    losses = [t for t in completed if t["return_pct"] <= 0]

    swaps = [t for t in completed if t["swap_alpha_pct"] is not None]
    positive_swaps = [t for t in swaps if t["swap_alpha_pct"] > 0]

    scored_trades = [t for t in completed if t.get("entry_score") is not None]
    score_correlation = None
    if len(scored_trades) >= 5:
        scores = [t["entry_score"] for t in scored_trades]
        rets = [t["return_pct"] for t in scored_trades]
        mean_s = sum(scores) / len(scores)
        mean_r = sum(rets) / len(rets)
        cov = sum((s - mean_s) * (r - mean_r) for s, r in zip(scores, rets)) / (len(scores) - 1)
        std_s = math.sqrt(sum((s - mean_s) ** 2 for s in scores) / (len(scores) - 1))
        std_r = math.sqrt(sum((r - mean_r) ** 2 for r in rets) / (len(rets) - 1))
        if std_s > 0 and std_r > 0:
            score_correlation = round(cov / (std_s * std_r), 3)

    short_holds = [t for t in completed if t["holding_days"] and t["holding_days"] < 30]
    medium_holds = [t for t in completed if t["holding_days"] and 30 <= t["holding_days"] <= 90]
    long_holds = [t for t in completed if t["holding_days"] and t["holding_days"] > 90]

    def avg_return(trades):
        if not trades:
            return None
        return round(sum(t["return_pct"] for t in trades) / len(trades), 2)

    return {
        "total_trades": len(completed),
        "win_rate_pct": round(len(wins) / len(completed) * 100, 1),
        "avg_return_pct": round(sum(returns) / len(returns), 2),
        "median_return_pct": round(sorted(returns)[len(returns) // 2], 2),
        "best_trade": max(returns),
        "worst_trade": min(returns),
        "total_swaps": len(swaps),
        "swap_win_rate_pct": round(len(positive_swaps) / len(swaps) * 100, 1) if swaps else None,
        "avg_swap_alpha_pct": round(sum(t["swap_alpha_pct"] for t in swaps) / len(swaps), 2) if swaps else None,
        "score_return_correlation": score_correlation,
        "holding_period_analysis": {
            "short_term_avg_return": avg_return(short_holds),
            "medium_term_avg_return": avg_return(medium_holds),
            "long_term_avg_return": avg_return(long_holds),
        },
        "recommendations": _generate_recommendations(completed, swaps, score_correlation),
    }


def compute_attribution(
    trades: list[dict],
    prices: dict[str, dict[str, float]],
    benchmark: str = "SPY",
) -> dict:
    """
    Full trade attribution analysis.

    Args:
        trades: List of trade dicts with keys: date, action (BUY/SELL), ticker,
                shares, price, score (optional), replaced (optional ticker).
        prices: {date: {ticker: price}}.
        benchmark: Benchmark ticker.

    Returns:
        Dict with round_trips and patterns.
    """
    round_trips = pair_trades(trades)
    round_trips = compute_swap_alpha(round_trips, prices)
    round_trips = compute_benchmark_relative(round_trips, prices, benchmark)
    patterns = analyze_patterns(round_trips)

    return {
        "round_trips": [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in t.items()} for t in round_trips],
        "patterns": patterns,
    }
