"""
Scoring engine: 5-dimension scoring for portfolio rotation.

Auto-scored: Technical Trend, Fundamental Momentum, Valuation (with financials).
Manual via overrides: Thesis Integrity, Catalyst Proximity.
"""

from collections import defaultdict

# Style-specific weights
STYLE_WEIGHTS = {
    "garp":         {"thesis": 0.25, "valuation": 0.25, "momentum": 0.20, "catalyst": 0.15, "technical": 0.15},
    "value":        {"thesis": 0.20, "valuation": 0.35, "momentum": 0.15, "catalyst": 0.15, "technical": 0.15},
    "growth":       {"thesis": 0.25, "valuation": 0.15, "momentum": 0.30, "catalyst": 0.20, "technical": 0.10},
    "momentum":     {"thesis": 0.10, "valuation": 0.10, "momentum": 0.30, "catalyst": 0.20, "technical": 0.30},
    "event_driven": {"thesis": 0.15, "valuation": 0.20, "momentum": 0.15, "catalyst": 0.35, "technical": 0.15},
}


# -- helpers --

def compute_sma(closes: list[float], period: int) -> float | None:
    if len(closes) < period:
        return None
    return sum(closes[-period:]) / period


def compute_rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) < period + 1:
        return None
    gains, losses = [], []
    for i in range(-period, 0):
        change = closes[i] - closes[i - 1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def compute_relative_strength(
    ticker_closes: list[float], bench_closes: list[float], period: int = 63
) -> float | None:
    if len(ticker_closes) < period or len(bench_closes) < period:
        return None
    ticker_ret = ticker_closes[-1] / ticker_closes[-period] - 1
    bench_ret = bench_closes[-1] / bench_closes[-period] - 1
    return ticker_ret - bench_ret


# -- dimension scorers --

def score_technical(ticker_data: list[dict], bench_data: list[dict]) -> int:
    """Score Technical Trend (0-100) from price data."""
    if len(ticker_data) < 200:
        return 50

    closes = [d["close"] for d in ticker_data]
    bench_closes = [d["close"] for d in bench_data] if bench_data else None
    current = closes[-1]

    sma50 = compute_sma(closes, 50)
    sma200 = compute_sma(closes, 200)
    rsi = compute_rsi(closes, 14)

    score = 50

    if sma50 and sma200:
        if current > sma50 and current > sma200:
            score += 25
            if sma50 > sma200:
                score += 5
        elif current > sma200:
            score += 10
        elif current < sma200:
            score -= 15
            if current < sma50:
                score -= 10

    if rsi is not None:
        if 50 <= rsi <= 70:
            score += 15
        elif 40 <= rsi < 50:
            score += 5
        elif rsi > 70:
            score -= 5
        elif rsi < 30:
            score -= 10

    if bench_closes and len(bench_closes) >= 63:
        rs_3m = compute_relative_strength(closes, bench_closes, 63)
        if rs_3m is not None:
            if rs_3m > 0.10:
                score += 15
            elif rs_3m > 0.05:
                score += 10
            elif rs_3m > 0:
                score += 5
            elif rs_3m < -0.10:
                score -= 10
            elif rs_3m < -0.05:
                score -= 5

    return max(0, min(100, score))


def score_momentum_from_prices(ticker_data: list[dict], bench_data: list[dict]) -> int:
    """Estimate momentum score from price action."""
    if len(ticker_data) < 126:
        return 50

    closes = [d["close"] for d in ticker_data]
    ret_3m = closes[-1] / closes[-63] - 1 if len(closes) >= 63 else 0
    ret_6m = closes[-1] / closes[-126] - 1 if len(closes) >= 126 else 0
    ret_1m = closes[-1] / closes[-21] - 1 if len(closes) >= 21 else 0

    score = 50

    if ret_3m > 0.20:
        score += 25
    elif ret_3m > 0.10:
        score += 15
    elif ret_3m > 0.05:
        score += 8
    elif ret_3m < -0.10:
        score -= 15
    elif ret_3m < -0.05:
        score -= 8

    if ret_1m > 0 and ret_3m > 0 and ret_1m > ret_3m / 3:
        score += 10
    elif ret_1m < 0 and ret_3m > 0:
        score -= 5

    if ret_6m > 0.15 and ret_3m > 0:
        score += 10
    elif ret_6m < -0.10:
        score -= 10

    return max(0, min(100, score))


def score_momentum_with_financials(
    ticker: str, financials: list[dict], price_score: int
) -> int:
    """Enhance momentum score with financial statement data when available."""
    stmts = [s for s in financials if s.get("_statement_type") == "income"]
    if len(stmts) < 2:
        return price_score

    stmts.sort(key=lambda s: s.get("period_end_date", ""), reverse=True)

    try:
        rev_latest = float(stmts[0].get("revenue", 0))
        rev_prior = float(stmts[1].get("revenue", 0))
        if rev_prior > 0:
            rev_growth = rev_latest / rev_prior - 1
            growth_score = 50
            if rev_growth > 0.20:
                growth_score = 85
            elif rev_growth > 0.10:
                growth_score = 70
            elif rev_growth > 0.05:
                growth_score = 60
            elif rev_growth < -0.05:
                growth_score = 30
            elif rev_growth < -0.10:
                growth_score = 20
            return round(price_score * 0.6 + growth_score * 0.4)
    except (ValueError, TypeError):
        pass

    return price_score


def score_valuation(
    ticker: str,
    financials: list[dict],
    current_price: float,
    peer_valuations: dict[str, float] | None = None,
) -> int | None:
    """Score valuation attractiveness. Requires financials data."""
    if not financials:
        return None

    income = [s for s in financials if s.get("_statement_type") == "income"]
    if not income:
        return None

    income.sort(key=lambda s: s.get("period_end_date", ""), reverse=True)
    latest = income[0]

    try:
        eps = float(
            latest.get("earnings_per_share", 0)
            or latest.get("earnings_per_share_diluted", 0)
            or latest.get("earnings_per_share_basic", 0)
            or 0
        )
        shares = float(
            latest.get("weighted_average_shares", 0)
            or latest.get("weighted_average_shares_diluted", 0)
            or latest.get("weighted_average_shares_outstanding", 0)
            or 0
        )

        if eps == 0 and shares > 0:
            net_income = float(latest.get("net_income", 0) or 0)
            eps = net_income / shares if net_income else 0

        pe_ratio = current_price / eps if eps > 0 else None
    except (ValueError, TypeError):
        pe_ratio = None

    score = 50
    if pe_ratio is not None:
        if pe_ratio < 12:
            score = 85
        elif pe_ratio < 18:
            score = 70
        elif pe_ratio < 25:
            score = 55
        elif pe_ratio < 35:
            score = 40
        else:
            score = 25

    if peer_valuations and pe_ratio is not None:
        all_pes = [v for v in peer_valuations.values() if v is not None]
        all_pes.append(pe_ratio)
        all_pes.sort()
        rank = all_pes.index(pe_ratio)
        percentile = rank / max(len(all_pes) - 1, 1)
        peer_score = round((1 - percentile) * 80 + 10)
        score = round(score * 0.4 + peer_score * 0.6)

    return max(0, min(100, score))


def compute_composite(scores: dict, style: str = "garp") -> int | None:
    """Compute weighted composite score.

    Missing dimensions default to 50 (neutral) instead of being skipped,
    so that the composite always reflects all 5 weights. This prevents
    inflated/deflated scores when only 2-3 dimensions have real data.
    """
    weights = STYLE_WEIGHTS.get(style, STYLE_WEIGHTS["garp"])
    total = 0
    for dim, weight in weights.items():
        value = scores.get(dim) if scores.get(dim) is not None else 50
        total += value * weight
    return round(total)


def get_action(score: int | None, is_holding: bool = True) -> str:
    """Map composite score to action recommendation."""
    if score is None:
        return "INSUFFICIENT_DATA"
    if score >= 70:
        return "STRONG_HOLD" if is_holding else "STRONG_BUY"
    elif score >= 60:
        return "HOLD" if is_holding else "BUY_CANDIDATE"
    elif score >= 40:
        return "WATCH" if is_holding else "WATCHLIST"
    elif score >= 20:
        return "SELL_CANDIDATE" if is_holding else "AVOID"
    else:
        return "URGENT_SELL" if is_holding else "AVOID"


# -- main scoring entry point --

def score_tickers(
    tickers: list[str],
    prices: dict[str, list[dict]],
    benchmark: str = "SPY",
    financials: dict[str, list[dict]] | None = None,
    overrides: dict[str, dict] | None = None,
    holdings: set[str] | None = None,
    style: str = "garp",
) -> list[dict]:
    """
    Score a list of tickers across 5 dimensions.

    Args:
        tickers: Tickers to score.
        prices: {ticker: [{date, close, high, low, volume}, ...]} sorted by date.
        benchmark: Benchmark ticker key in prices.
        financials: Optional {ticker: [{field: value, ...}, ...]} for valuation scoring.
        overrides: Optional {ticker: {dimension: score}} for manual overrides.
        holdings: Set of current holding tickers (for action labeling).
        style: Investing style (garp, value, growth, momentum, event_driven).

    Returns:
        List of score dicts with keys: ticker, thesis, valuation, momentum,
        catalyst, technical, composite, action, style, auto_dimensions, manual_dimensions.
    """
    financials = financials or {}
    overrides = overrides or {}
    holdings = holdings or set()
    bench_data = prices.get(benchmark, [])

    # Pre-compute PE ratios for peer comparison
    pe_ratios: dict[str, float] = {}
    for ticker in tickers:
        if ticker in financials and ticker in prices and prices[ticker]:
            current_price = prices[ticker][-1]["close"]
            income = [s for s in financials[ticker] if s.get("_statement_type") == "income"]
            if income:
                income.sort(key=lambda s: s.get("period_end_date", ""), reverse=True)
                latest = income[0]
                try:
                    eps = float(
                        latest.get("earnings_per_share", 0)
                        or latest.get("earnings_per_share_diluted", 0)
                        or 0
                    )
                    if eps > 0:
                        pe_ratios[ticker] = round(current_price / eps, 1)
                except (ValueError, TypeError):
                    pass

    results = []

    for ticker in tickers:
        ticker_data = prices.get(ticker, [])
        ticker_overrides = overrides.get(ticker, {})
        scores: dict[str, int | None] = {}

        # Technical Trend
        if "technical" in ticker_overrides:
            scores["technical"] = ticker_overrides["technical"]
        elif ticker_data:
            scores["technical"] = score_technical(ticker_data, bench_data)
        else:
            scores["technical"] = None

        # Fundamental Momentum
        if "momentum" in ticker_overrides:
            scores["momentum"] = ticker_overrides["momentum"]
        elif ticker_data:
            price_mom = score_momentum_from_prices(ticker_data, bench_data)
            if ticker in financials:
                scores["momentum"] = score_momentum_with_financials(
                    ticker, financials[ticker], price_mom
                )
            else:
                scores["momentum"] = price_mom
        else:
            scores["momentum"] = None

        # Valuation
        if "valuation" in ticker_overrides:
            scores["valuation"] = ticker_overrides["valuation"]
        elif ticker in financials and ticker_data:
            current_price = ticker_data[-1]["close"]
            peer_pes = {t: v for t, v in pe_ratios.items() if t != ticker}
            scores["valuation"] = score_valuation(
                ticker, financials[ticker], current_price, peer_pes
            )
        else:
            scores["valuation"] = None

        # Thesis Integrity -- manual only
        scores["thesis"] = ticker_overrides.get("thesis")

        # Catalyst Proximity -- manual only
        scores["catalyst"] = ticker_overrides.get("catalyst")

        # Composite
        composite = compute_composite(scores, style)
        is_holding = ticker in holdings if holdings else True
        action = get_action(composite, is_holding)

        # Track provenance of each dimension
        auto_dims = []
        manual_dims = []
        defaulted_dims = []
        for dim in ["thesis", "valuation", "momentum", "catalyst", "technical"]:
            if scores[dim] is not None:
                if dim in ticker_overrides:
                    manual_dims.append(dim)
                else:
                    auto_dims.append(dim)
            else:
                defaulted_dims.append(dim)

        # For output, show effective score (50 for defaulted) alongside raw
        effective_scores = {}
        for dim in ["thesis", "valuation", "momentum", "catalyst", "technical"]:
            effective_scores[dim] = scores[dim] if scores[dim] is not None else 50

        result = {
            "ticker": ticker,
            "thesis": effective_scores["thesis"],
            "valuation": effective_scores["valuation"],
            "momentum": effective_scores["momentum"],
            "catalyst": effective_scores["catalyst"],
            "technical": effective_scores["technical"],
            "composite": composite,
            "action": action,
            "style": style,
            "auto_dimensions": auto_dims,
            "manual_dimensions": manual_dims,
            "defaulted_dimensions": defaulted_dims,
            "coverage": f"{5 - len(defaulted_dims)}/5",
        }

        results.append(result)

    return results
