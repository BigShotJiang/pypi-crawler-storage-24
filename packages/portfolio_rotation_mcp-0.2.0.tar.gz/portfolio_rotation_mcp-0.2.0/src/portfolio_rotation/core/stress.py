"""
Portfolio stress testing: scenario replay, hypothetical shocks, factor decomposition, Monte Carlo.
"""

import math
import random
from collections import defaultdict


SCENARIOS = {
    "GFC": {"start": "2008-09-01", "end": "2009-03-09", "description": "Global Financial Crisis"},
    "COVID": {"start": "2020-02-19", "end": "2020-03-23", "description": "COVID-19 Crash"},
    "Tech_Wreck": {"start": "2000-03-10", "end": "2002-10-09", "description": "Dot-Com Bust"},
    "Rate_Shock_2022": {"start": "2022-01-03", "end": "2022-10-12", "description": "Fed Hiking Cycle"},
    "Taper_Tantrum": {"start": "2013-05-22", "end": "2013-06-24", "description": "Taper Tantrum"},
    "Volmageddon": {"start": "2018-01-26", "end": "2018-02-08", "description": "VIX Spike Feb 2018"},
    "China_Deval": {"start": "2015-08-10", "end": "2015-08-25", "description": "China Devaluation"},
}

RATE_SENSITIVITY = {
    "Technology": -0.025, "Communication Services": -0.02,
    "Consumer Discretionary": -0.02, "Healthcare": -0.015,
    "Industrials": -0.015, "Consumer Staples": -0.01,
    "Financials": 0.01, "Energy": -0.005,
    "Materials": -0.01, "Utilities": -0.035,
    "Real Estate": -0.04, "Unknown": -0.02,
}


def _compute_returns(
    prices: dict[str, dict[str, float]], tickers: list[str]
) -> tuple[dict[str, list[float]], list[str]]:
    """Compute daily returns for each ticker."""
    dates = sorted(prices.keys())
    returns: dict[str, list[float]] = defaultdict(list)
    return_dates = []

    for i in range(1, len(dates)):
        d0, d1 = dates[i - 1], dates[i]
        day_returns = {}
        valid = False
        for t in tickers:
            p0 = prices.get(d0, {}).get(t)
            p1 = prices.get(d1, {}).get(t)
            if p0 and p1 and p0 > 0:
                day_returns[t] = p1 / p0 - 1
                valid = True
        if valid:
            for t in tickers:
                returns[t].append(day_returns.get(t, 0))
            return_dates.append(d1)

    return dict(returns), return_dates


def scenario_replay(
    holdings: list[dict],
    prices: dict[str, dict[str, float]],
    benchmark: str = "SPY",
) -> dict:
    """Replay portfolio through historical crisis scenarios."""
    results = {}
    tickers = [h["ticker"] for h in holdings]
    weights = {h["ticker"]: h["weight"] for h in holdings}
    dates = sorted(prices.keys())

    for name, scenario in SCENARIOS.items():
        start, end = scenario["start"], scenario["end"]

        avail_start = None
        avail_end = None
        for d in dates:
            if d >= start and avail_start is None:
                avail_start = d
            if d <= end:
                avail_end = d

        if not avail_start or not avail_end or avail_start >= avail_end:
            results[name] = {"status": "no_data", "description": scenario["description"]}
            continue

        port_return = 0
        ticker_returns = {}
        for t in tickers:
            p_start = prices.get(avail_start, {}).get(t)
            p_end = prices.get(avail_end, {}).get(t)
            if p_start and p_end and p_start > 0:
                ret = p_end / p_start - 1
                ticker_returns[t] = round(ret * 100, 2)
                port_return += weights.get(t, 0) * ret

        bench_return = None
        b_start = prices.get(avail_start, {}).get(benchmark)
        b_end = prices.get(avail_end, {}).get(benchmark)
        if b_start and b_end and b_start > 0:
            bench_return = round((b_end / b_start - 1) * 100, 2)

        period_dates = [d for d in dates if avail_start <= d <= avail_end]
        peak = 1.0
        max_dd = 0
        worst_day = 0
        cumulative = 1.0

        for d in period_dates:
            day_ret = 0
            for t in tickers:
                p = prices.get(d, {}).get(t)
                prev_d_idx = period_dates.index(d) - 1
                if prev_d_idx >= 0:
                    prev_d = period_dates[prev_d_idx]
                    p_prev = prices.get(prev_d, {}).get(t)
                    if p and p_prev and p_prev > 0:
                        day_ret += weights.get(t, 0) * (p / p_prev - 1)

            cumulative *= (1 + day_ret)
            if cumulative > peak:
                peak = cumulative
            dd = (peak - cumulative) / peak
            if dd > max_dd:
                max_dd = dd
            if abs(day_ret) > abs(worst_day):
                worst_day = day_ret

        results[name] = {
            "description": scenario["description"],
            "period": f"{avail_start} to {avail_end}",
            "portfolio_return_pct": round(port_return * 100, 2),
            "benchmark_return_pct": bench_return,
            "excess_return_pct": round(port_return * 100 - (bench_return or 0), 2) if bench_return else None,
            "max_drawdown_pct": round(max_dd * 100, 2),
            "worst_single_day_pct": round(worst_day * 100, 2),
            "ticker_returns": ticker_returns,
        }

    return results


def hypothetical_shocks(holdings: list[dict]) -> dict:
    """Estimate impact of hypothetical market shocks."""
    sector_weights: dict[str, float] = defaultdict(float)
    for h in holdings:
        sector_weights[h.get("sector", "Unknown")] += float(h["weight"])

    results = {}

    for bps in [50, 100, 200]:
        impact = 0
        for sector, weight in sector_weights.items():
            sensitivity = RATE_SENSITIVITY.get(sector, -0.02)
            impact += weight * sensitivity * (bps / 100)
        results[f"rates_up_{bps}bp"] = {
            "shock": f"+{bps}bp across curve",
            "estimated_portfolio_impact_pct": round(impact * 100, 2),
        }
        results[f"rates_down_{bps}bp"] = {
            "shock": f"-{bps}bp across curve",
            "estimated_portfolio_impact_pct": round(-impact * 100, 2),
        }

    for pct in [10, 20, 30]:
        results[f"equity_down_{pct}pct"] = {
            "shock": f"-{pct}% broad equity market",
            "estimated_portfolio_impact_pct": -pct,
        }

    for sector, weight in sector_weights.items():
        if weight > 0.05:
            results[f"sector_shock_{sector}"] = {
                "shock": f"-20% in {sector}",
                "portfolio_weight_in_sector_pct": round(weight * 100, 1),
                "estimated_portfolio_impact_pct": round(-0.20 * weight * 100, 2),
            }

    return results


def factor_decomposition(
    holdings: list[dict],
    returns: dict[str, list[float]],
    return_dates: list[str],
    factor_data: dict[str, dict[str, float]],
) -> dict:
    """Decompose portfolio returns into Fama-French factors."""
    tickers = [h["ticker"] for h in holdings]
    weights = {h["ticker"]: h["weight"] for h in holdings}

    port_returns = []
    factor_dates = []

    for i, date in enumerate(return_dates):
        port_ret = sum(weights.get(t, 0) * returns.get(t, [0] * len(return_dates))[i] for t in tickers)
        if date in factor_data:
            port_returns.append(port_ret)
            factor_dates.append(date)

    if len(port_returns) < 60:
        return {"error": "Insufficient overlapping data. Need 60+ days of both price and factor data."}

    factor_names = [k for k in factor_data[factor_dates[0]].keys() if k != "RF"]
    n = len(port_returns)
    rf_values = [factor_data[d].get("RF", 0) for d in factor_dates]
    excess_returns = [port_returns[i] - rf_values[i] for i in range(n)]
    factor_matrix = {f: [factor_data[d].get(f, 0) for d in factor_dates] for f in factor_names}

    mean_excess = sum(excess_returns) / n
    betas: dict[str, float] = {}

    for f_name in factor_names:
        f_vals = factor_matrix[f_name]
        mean_f = sum(f_vals) / n
        cov = sum((excess_returns[i] - mean_excess) * (f_vals[i] - mean_f) for i in range(n)) / (n - 1)
        var_f = sum((f_vals[i] - mean_f) ** 2 for i in range(n)) / (n - 1)
        betas[f_name] = round(cov / var_f, 4) if var_f > 0 else 0

    total_var = sum((r - mean_excess) ** 2 for r in excess_returns) / (n - 1)
    if total_var > 0:
        predicted = [sum(betas.get(f, 0) * factor_matrix[f][i] for f in factor_names) for i in range(n)]
        residuals = [excess_returns[i] - predicted[i] for i in range(n)]
        residual_var = sum(r ** 2 for r in residuals) / (n - 1)
        r_squared = round(1 - residual_var / total_var, 4)
    else:
        r_squared = 0

    alpha_daily = mean_excess - sum(betas.get(f, 0) * sum(factor_matrix[f]) / n for f in factor_names)
    alpha_annual = round(alpha_daily * 252 * 100, 2)

    flags = []
    if abs(betas.get("MKT-RF", 1) - 1) > 0.3:
        flags.append(f"Market beta = {betas.get('MKT-RF', 'N/A')} -- significantly different from 1.0")
    for f in ["SMB", "HML", "MOM", "RMW", "CMA"]:
        if f in betas and abs(betas[f]) > 0.5:
            direction = "positive" if betas[f] > 0 else "negative"
            flags.append(f"Strong {direction} {f} exposure ({betas[f]}) -- potential unintended factor bet")

    return {
        "factor_betas": betas,
        "annualized_alpha_pct": alpha_annual,
        "r_squared": r_squared,
        "idiosyncratic_risk_pct": round((1 - r_squared) * 100, 1),
        "observations": n,
        "flags": flags,
    }


def monte_carlo(
    returns: dict[str, list[float]],
    return_dates: list[str],
    holdings: list[dict],
    n_sims: int = 10000,
    horizon_days: int = 252,
) -> dict:
    """Run Monte Carlo simulation by bootstrapping historical returns."""
    tickers = [h["ticker"] for h in holdings]
    weights = {h["ticker"]: h["weight"] for h in holdings}

    n_days = len(return_dates)
    port_daily = []
    for i in range(n_days):
        day_ret = sum(weights.get(t, 0) * returns.get(t, [0] * n_days)[i] for t in tickers)
        port_daily.append(day_ret)

    if len(port_daily) < 60:
        return {"error": "Insufficient data for Monte Carlo. Need 60+ daily returns."}

    random.seed(42)
    final_values = []

    for _ in range(n_sims):
        cumulative = 1.0
        for _ in range(horizon_days):
            idx = random.randint(0, len(port_daily) - 1)
            cumulative *= (1 + port_daily[idx])
        final_values.append(cumulative)

    final_values.sort()

    def percentile(data, pct):
        idx = int(len(data) * pct / 100)
        return data[min(idx, len(data) - 1)]

    median_return = (percentile(final_values, 50) - 1) * 100
    var_95 = (1 - percentile(final_values, 5)) * 100
    var_99 = (1 - percentile(final_values, 1)) * 100
    worst_5pct = final_values[:int(n_sims * 0.05)]
    cvar_95 = (1 - (sum(worst_5pct) / len(worst_5pct))) * 100 if worst_5pct else var_95
    prob_20_dd = sum(1 for v in final_values if v < 0.80) / n_sims * 100

    return {
        "simulations": n_sims,
        "horizon_days": horizon_days,
        "median_return_pct": round(median_return, 2),
        "mean_return_pct": round((sum(final_values) / n_sims - 1) * 100, 2),
        "var_95_pct": round(var_95, 2),
        "var_99_pct": round(var_99, 2),
        "cvar_95_pct": round(cvar_95, 2),
        "probability_20pct_drawdown": round(prob_20_dd, 1),
        "best_case_pct": round((final_values[-1] - 1) * 100, 2),
        "worst_case_pct": round((final_values[0] - 1) * 100, 2),
        "confidence_interval_90": {
            "low_pct": round((percentile(final_values, 5) - 1) * 100, 2),
            "high_pct": round((percentile(final_values, 95) - 1) * 100, 2),
        },
    }


def run_stress_test(
    holdings: list[dict],
    prices: dict[str, dict[str, float]],
    factor_data: dict[str, dict[str, float]] | None = None,
    benchmark: str = "SPY",
    run_scenarios: bool = True,
    run_shocks: bool = True,
    run_factors: bool = True,
    run_montecarlo: bool = True,
    n_simulations: int = 10000,
) -> dict:
    """
    Full portfolio stress test.

    Args:
        holdings: List of {ticker, weight, sector}.
        prices: {date: {ticker: price}}.
        factor_data: Optional {date: {factor: value}} for Fama-French decomposition.
        benchmark: Benchmark ticker.
        run_scenarios: Run historical scenario replay.
        run_shocks: Run hypothetical shocks.
        run_factors: Run factor decomposition (needs factor_data).
        run_montecarlo: Run Monte Carlo simulation.
        n_simulations: Number of Monte Carlo simulations.

    Returns:
        Comprehensive stress test results dict.
    """
    tickers = [h["ticker"] for h in holdings]
    result: dict = {
        "portfolio": [{"ticker": h["ticker"], "weight": h["weight"], "sector": h.get("sector", "Unknown")} for h in holdings],
    }

    if run_scenarios:
        result["historical_scenarios"] = scenario_replay(holdings, prices, benchmark)

    if run_shocks:
        result["hypothetical_shocks"] = hypothetical_shocks(holdings)

    returns_data, return_dates = _compute_returns(prices, tickers + [benchmark])

    if run_factors:
        if factor_data:
            result["factor_decomposition"] = factor_decomposition(
                holdings, returns_data, return_dates, factor_data
            )
        else:
            result["factor_decomposition"] = {"error": "No factor data provided."}

    if run_montecarlo:
        result["monte_carlo"] = monte_carlo(
            returns_data, return_dates, holdings, n_simulations
        )

    # Risk flags
    flags = []
    if "historical_scenarios" in result:
        for name, s in result["historical_scenarios"].items():
            if isinstance(s, dict) and s.get("portfolio_return_pct") is not None:
                if s["portfolio_return_pct"] < -30:
                    flags.append(f"CRITICAL: {name} scenario loss = {s['portfolio_return_pct']}%")
                elif s["portfolio_return_pct"] < -15:
                    flags.append(f"WARNING: {name} scenario loss = {s['portfolio_return_pct']}%")

    if "factor_decomposition" in result and "flags" in result.get("factor_decomposition", {}):
        flags.extend(result["factor_decomposition"]["flags"])

    if "monte_carlo" in result and result["monte_carlo"].get("probability_20pct_drawdown", 0) > 15:
        flags.append(f"Monte Carlo: {result['monte_carlo']['probability_20pct_drawdown']}% chance of >20% drawdown")

    result["risk_flags"] = flags
    result["overall_risk_level"] = (
        "CRITICAL" if any("CRITICAL" in f for f in flags) else
        "HIGH" if len(flags) > 3 else
        "MEDIUM" if len(flags) > 0 else
        "LOW"
    )

    return result
