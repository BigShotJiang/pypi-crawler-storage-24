"""
Backtest engine for portfolio rotation strategies.
"""

import math
from collections import defaultdict
from datetime import datetime


def get_rebalance_dates(dates: list[str], frequency: str) -> list[str]:
    """Return dates on which to rebalance."""
    if frequency == "daily":
        return dates
    elif frequency == "weekly":
        result = []
        for i, d in enumerate(dates):
            dt = datetime.strptime(d, "%Y-%m-%d")
            if i == 0 or dt.weekday() == 0:
                result.append(d)
        return result
    elif frequency == "monthly":
        result = []
        prev_month = None
        for d in dates:
            month = d[:7]
            if month != prev_month:
                result.append(d)
                prev_month = month
        return result
    elif frequency == "quarterly":
        result = []
        prev_q = None
        for d in dates:
            dt = datetime.strptime(d, "%Y-%m-%d")
            q = (dt.month - 1) // 3
            qkey = f"{dt.year}-Q{q}"
            if qkey != prev_q:
                result.append(d)
                prev_q = qkey
        return result
    return dates


def run_backtest(
    prices: dict[str, dict[str, float]],
    strategy: dict,
    benchmark_ticker: str = "SPY",
    cost_bps: int = 10,
    scores: dict[str, float] | None = None,
    ranking_mode: str = "momentum",
) -> dict:
    """
    Run a backtest simulation on historical price data.

    Args:
        prices: {date: {ticker: price}} sorted by date.
        strategy: Strategy config dict with keys: rebalance, max_positions, sizing,
                  entry (min_score), exit (trailing_stop, min_score).
        benchmark_ticker: Benchmark ticker for comparison.
        cost_bps: Transaction cost in basis points.
        scores: Optional {ticker: composite_score} for score-based ranking.
            Used when ranking_mode="score".
        ranking_mode: "momentum" (default, rank by 3M price return) or "score"
            (rank by composite scores for initial allocation, momentum for ongoing
            rebalancing since scores can't be recomputed mid-backtest).

    Returns:
        Dict with metrics, equity_curve, benchmark_curve, trade_log, monthly_returns.
    """
    dates = sorted(prices.keys())
    if len(dates) < 20:
        return {"error": "Insufficient data. Need at least 20 trading days."}

    rebalance_freq = strategy.get("rebalance", "monthly")
    max_pos = strategy.get("max_positions", 10)
    sizing = strategy.get("sizing", "equal_weight")
    trailing_stop = strategy.get("exit", {}).get("trailing_stop", 0.15)
    min_score = strategy.get("entry", {}).get("min_score", 0)
    cost_pct = cost_bps / 10000.0
    scores = scores or {}

    rebalance_dates = set(get_rebalance_dates(dates, rebalance_freq))

    portfolio: dict[str, dict] = {}
    cash = 1000000.0
    initial_value = cash
    equity_curve = []
    trade_log = []
    monthly_returns: dict[str, dict] = {}
    prev_value = initial_value

    for date in dates:
        day_prices = prices[date]

        for ticker in list(portfolio.keys()):
            if ticker in day_prices:
                portfolio[ticker]["high_price"] = max(
                    portfolio[ticker]["high_price"], day_prices[ticker]
                )

        for ticker in list(portfolio.keys()):
            if ticker in day_prices:
                high = portfolio[ticker]["high_price"]
                current = day_prices[ticker]
                if high > 0 and (high - current) / high > trailing_stop:
                    proceeds = portfolio[ticker]["shares"] * current
                    cost = proceeds * cost_pct
                    cash += proceeds - cost
                    trade_log.append({
                        "date": date, "action": "SELL", "ticker": ticker,
                        "price": current, "shares": portfolio[ticker]["shares"],
                        "reason": "trailing_stop",
                        "pnl": (current - portfolio[ticker]["entry_price"]) * portfolio[ticker]["shares"] - cost,
                        "return_pct": (current / portfolio[ticker]["entry_price"] - 1) * 100,
                    })
                    del portfolio[ticker]

        if date in rebalance_dates:
            available_tickers = sorted(day_prices.keys())
            if benchmark_ticker in available_tickers:
                available_tickers.remove(benchmark_ticker)

            # Use score-based ranking on first rebalance when scores provided,
            # fall back to momentum for subsequent rebalances (scores can't be
            # recomputed mid-backtest without financials at each date).
            use_scores = (ranking_mode == "score" and scores
                          and date == sorted(rebalance_dates)[0])

            scored = []
            for ticker in available_tickers:
                if ticker in day_prices and day_prices[ticker] > 0:
                    if use_scores and ticker in scores:
                        # Filter by min_score threshold
                        if scores[ticker] >= min_score:
                            scored.append((ticker, scores[ticker]))
                    else:
                        idx = dates.index(date)
                        lookback_idx = max(0, idx - 63)
                        lookback_date = dates[lookback_idx]
                        if ticker in prices.get(lookback_date, {}):
                            ret = (day_prices[ticker] / prices[lookback_date][ticker] - 1) * 100
                            scored.append((ticker, ret))

            scored.sort(key=lambda x: x[1], reverse=True)
            target_tickers = [t for t, s in scored[:max_pos]]

            for ticker in list(portfolio.keys()):
                if ticker not in target_tickers and ticker in day_prices:
                    proceeds = portfolio[ticker]["shares"] * day_prices[ticker]
                    cost = proceeds * cost_pct
                    cash += proceeds - cost
                    trade_log.append({
                        "date": date, "action": "SELL", "ticker": ticker,
                        "price": day_prices[ticker], "shares": portfolio[ticker]["shares"],
                        "reason": "rebalance_out",
                        "pnl": (day_prices[ticker] - portfolio[ticker]["entry_price"]) * portfolio[ticker]["shares"] - cost,
                        "return_pct": (day_prices[ticker] / portfolio[ticker]["entry_price"] - 1) * 100,
                    })
                    del portfolio[ticker]

            new_buys = [t for t in target_tickers if t not in portfolio]
            if new_buys and cash > 0:
                per_position = cash / max(len(new_buys), 1) if sizing == "equal_weight" else cash / max_pos
                for ticker in new_buys:
                    if ticker in day_prices and day_prices[ticker] > 0:
                        shares = int(per_position / day_prices[ticker])
                        if shares > 0:
                            cost_total = shares * day_prices[ticker]
                            fee = cost_total * cost_pct
                            cash -= (cost_total + fee)
                            portfolio[ticker] = {
                                "shares": shares,
                                "entry_price": day_prices[ticker],
                                "entry_date": date,
                                "high_price": day_prices[ticker],
                            }
                            trade_log.append({
                                "date": date, "action": "BUY", "ticker": ticker,
                                "price": day_prices[ticker], "shares": shares,
                                "reason": "rebalance_in",
                            })

        port_value = cash
        for ticker, pos in portfolio.items():
            if ticker in day_prices:
                port_value += pos["shares"] * day_prices[ticker]

        equity_curve.append({"date": date, "value": round(port_value, 2)})

        month = date[:7]
        if month not in monthly_returns:
            monthly_returns[month] = {"start": prev_value}
        monthly_returns[month]["end"] = port_value
        if date == dates[-1] or (dates.index(date) + 1 < len(dates) and dates[dates.index(date) + 1][:7] != month):
            start = monthly_returns[month]["start"]
            monthly_returns[month]["return"] = round((port_value / start - 1) * 100, 2) if start > 0 else 0
            if dates.index(date) + 1 < len(dates):
                next_month = dates[dates.index(date) + 1][:7]
                if next_month not in monthly_returns:
                    monthly_returns[next_month] = {"start": port_value}
        prev_value = port_value

    # Benchmark
    benchmark_curve = []
    bench_start = None
    for date in dates:
        if benchmark_ticker in prices[date]:
            if bench_start is None:
                bench_start = prices[date][benchmark_ticker]
            bench_val = initial_value * (prices[date][benchmark_ticker] / bench_start)
            benchmark_curve.append({"date": date, "value": round(bench_val, 2)})

    # Metrics
    final_value = equity_curve[-1]["value"] if equity_curve else initial_value
    total_return = (final_value / initial_value - 1) * 100
    years = len(dates) / 252.0
    cagr = ((final_value / initial_value) ** (1 / years) - 1) * 100 if years > 0 else 0

    daily_returns = []
    for i in range(1, len(equity_curve)):
        prev = equity_curve[i - 1]["value"]
        curr = equity_curve[i]["value"]
        if prev > 0:
            daily_returns.append(curr / prev - 1)

    avg_ret = sum(daily_returns) / len(daily_returns) if daily_returns else 0
    std_ret = math.sqrt(sum((r - avg_ret) ** 2 for r in daily_returns) / max(len(daily_returns) - 1, 1))
    # Sortino downside deviation: apply min(r, 0) across ALL days, divide by
    # total count. Previous code only used negative-return days in both
    # numerator and denominator, making Sortino ≈ Sharpe for skewed strategies.
    downside_sq_sum = sum(min(r, 0) ** 2 for r in daily_returns)
    downside_std = math.sqrt(downside_sq_sum / max(len(daily_returns) - 1, 1)) if daily_returns else 0.001

    rf_daily = 0.04 / 252
    sharpe = ((avg_ret - rf_daily) / std_ret) * math.sqrt(252) if std_ret > 0 else 0
    sortino = ((avg_ret - rf_daily) / downside_std) * math.sqrt(252) if downside_std > 0 else 0

    peak = equity_curve[0]["value"] if equity_curve else initial_value
    max_dd = 0
    max_dd_start = equity_curve[0]["date"] if equity_curve else ""
    max_dd_end = max_dd_start
    current_dd_start = max_dd_start

    for point in equity_curve:
        if point["value"] > peak:
            peak = point["value"]
            current_dd_start = point["date"]
        dd = (peak - point["value"]) / peak
        if dd > max_dd:
            max_dd = dd
            max_dd_start = current_dd_start
            max_dd_end = point["date"]

    sells = [t for t in trade_log if t["action"] == "SELL"]
    wins = [t for t in sells if t.get("pnl", 0) > 0]
    losses = [t for t in sells if t.get("pnl", 0) <= 0]
    win_rate = len(wins) / len(sells) * 100 if sells else 0
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
    avg_loss = abs(sum(t["pnl"] for t in losses) / len(losses)) if losses else 0.01
    turnover = len(sells) / max(years, 0.01) / max_pos * 100

    bench_return = 0
    if benchmark_curve:
        bench_return = (benchmark_curve[-1]["value"] / initial_value - 1) * 100

    metrics = {
        "total_return_pct": round(total_return, 2),
        "cagr_pct": round(cagr, 2),
        "sharpe_ratio": round(sharpe, 2),
        "sortino_ratio": round(sortino, 2),
        "max_drawdown_pct": round(max_dd * 100, 2),
        "max_drawdown_period": f"{max_dd_start} to {max_dd_end}",
        "win_rate_pct": round(win_rate, 1),
        "avg_win_loss_ratio": round(avg_win / avg_loss, 2) if avg_loss > 0 else 0,
        "total_trades": len(trade_log),
        "annual_turnover_pct": round(turnover, 1),
        "benchmark_return_pct": round(bench_return, 2),
        "excess_return_pct": round(total_return - bench_return, 2),
        "years": round(years, 1),
    }

    return {
        "metrics": metrics,
        "ranking_mode": ranking_mode,
        "equity_curve": equity_curve[::5] if len(equity_curve) > 200 else equity_curve,
        "benchmark_curve": benchmark_curve[::5] if len(benchmark_curve) > 200 else benchmark_curve,
        "trade_log": trade_log,
        "monthly_returns": {k: v.get("return", 0) for k, v in monthly_returns.items() if "return" in v},
    }
