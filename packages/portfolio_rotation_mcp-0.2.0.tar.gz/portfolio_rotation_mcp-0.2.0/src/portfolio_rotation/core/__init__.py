"""Core computation modules for portfolio rotation analysis."""
