"""
Data fetching: prices and financial statements.
Uses financial-datasets API with yfinance as automatic fallback.
"""

import os
import time

import httpx

API_BASE = "https://api.financialdatasets.ai"


def _get_api_key() -> str:
    return os.environ.get("FINANCIAL_DATASETS_API_KEY", "")


def fetch_prices_api(
    tickers: list[str], start_date: str, end_date: str, api_key: str
) -> tuple[list[dict], list[str]]:
    """Fetch from financial-datasets API. Returns (rows, failed_tickers)."""
    headers = {"X-API-KEY": api_key}
    all_rows = []
    failed = []

    for ticker in tickers:
        try:
            r = httpx.get(
                f"{API_BASE}/prices/",
                params={
                    "ticker": ticker,
                    "interval": "day",
                    "interval_multiplier": 1,
                    "start_date": start_date,
                    "end_date": end_date,
                },
                headers=headers,
                timeout=30.0,
            )
            r.raise_for_status()
            prices = r.json().get("prices", [])
            for p in prices:
                all_rows.append({
                    "date": str(p["time"])[:10],
                    "ticker": ticker,
                    "open": p.get("open"),
                    "high": p.get("high"),
                    "low": p.get("low"),
                    "close": p.get("close"),
                    "volume": p.get("volume"),
                })
        except httpx.HTTPStatusError:
            failed.append(ticker)
        except Exception:
            failed.append(ticker)
        time.sleep(0.3)

    return all_rows, failed


def fetch_prices_yfinance(
    tickers: list[str], start_date: str, end_date: str
) -> list[dict]:
    """Fetch from yfinance. Returns list of price dicts."""
    try:
        import yfinance as yf
    except ImportError:
        return []

    import warnings
    warnings.filterwarnings("ignore")

    all_rows = []
    for ticker in tickers:
        try:
            df = yf.download(ticker, start=start_date, end=end_date, progress=False)
            if df.empty:
                continue
            if hasattr(df.columns, "levels") and len(df.columns.levels) > 1:
                df.columns = df.columns.droplevel(1)
            for idx, row in df.iterrows():
                date_str = str(idx.date()) if hasattr(idx, "date") else str(idx)[:10]
                all_rows.append({
                    "date": date_str,
                    "ticker": ticker,
                    "open": round(float(row.get("Open", 0)), 2),
                    "high": round(float(row.get("High", 0)), 2),
                    "low": round(float(row.get("Low", 0)), 2),
                    "close": round(float(row.get("Close", 0)), 2),
                    "volume": int(row.get("Volume", 0)),
                })
        except Exception:
            continue

    return all_rows


def _get_default_source() -> str:
    return os.environ.get("PORTFOLIO_ROTATION_SOURCE", "auto")


def fetch_prices(
    tickers: list[str],
    start_date: str,
    end_date: str,
    source: str = "",
) -> list[dict]:
    """
    Fetch historical daily OHLCV prices.

    Args:
        tickers: List of ticker symbols.
        start_date: Start date YYYY-MM-DD.
        end_date: End date YYYY-MM-DD.
        source: 'auto' (API first, yfinance fallback), 'api', 'financial-datasets'
            (same as 'api'), or 'yfinance'.
            If empty, reads PORTFOLIO_ROTATION_SOURCE env var (default: 'auto').

    Returns:
        List of price dicts with keys: date, ticker, open, high, low, close, volume.
    """
    if not source:
        source = _get_default_source()

    all_rows: list[dict] = []

    if source in ("auto", "api", "financial-datasets"):
        api_key = _get_api_key()
        if api_key:
            rows, failed = fetch_prices_api(tickers, start_date, end_date, api_key)
            all_rows.extend(rows)
            if failed and source == "auto":
                all_rows.extend(fetch_prices_yfinance(failed, start_date, end_date))
        elif source == "auto":
            all_rows.extend(fetch_prices_yfinance(tickers, start_date, end_date))
    else:
        all_rows.extend(fetch_prices_yfinance(tickers, start_date, end_date))

    all_rows.sort(key=lambda r: (r["date"], r["ticker"]))
    return all_rows


def fetch_financials(
    tickers: list[str],
    stmt_type: str = "all",
    period: str = "annual",
    limit: int = 5,
) -> list[dict]:
    """
    Fetch financial statements from financial-datasets API.

    Args:
        tickers: List of ticker symbols.
        stmt_type: 'income', 'balance', 'cashflow', or 'all'.
        period: 'annual' or 'quarterly'.
        limit: Number of periods to fetch per ticker.

    Returns:
        List of statement dicts with _ticker and _statement_type metadata fields.
    """
    api_key = _get_api_key()
    if not api_key:
        return []

    headers = {"X-API-KEY": api_key}
    endpoints = {
        "income": ("income-statements", "income_statements"),
        "balance": ("balance-sheets", "balance_sheets"),
        "cashflow": ("cash-flow-statements", "cash_flow_statements"),
    }

    types_to_fetch = list(endpoints.keys()) if stmt_type == "all" else [stmt_type]
    all_rows = []

    for stype in types_to_fetch:
        url_part, json_key = endpoints[stype]
        for ticker in tickers:
            try:
                r = httpx.get(
                    f"{API_BASE}/financials/{url_part}/",
                    params={"ticker": ticker, "period": period, "limit": limit},
                    headers=headers,
                    timeout=30.0,
                )
                r.raise_for_status()
                stmts = r.json().get(json_key, [])
                for s in stmts:
                    s["_ticker"] = ticker
                    s["_statement_type"] = stype
                    all_rows.append(s)
            except Exception:
                continue
            time.sleep(0.3)

    return all_rows
