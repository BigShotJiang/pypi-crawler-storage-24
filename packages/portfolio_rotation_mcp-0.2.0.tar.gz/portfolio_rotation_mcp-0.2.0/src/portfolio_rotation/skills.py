"""
Embedded domain knowledge (skills) for portfolio rotation analysis.

These are the same skills used in the Claude Cowork FSP plugin,
adapted for direct access via the get_skill MCP tool so that any
AI agent (DeepSeek, GPT, Gemini, Llama, etc.) can retrieve the
domain knowledge needed to interpret tool outputs correctly.
"""

SKILLS: dict[str, str] = {}

# ── Scoring Framework ────────────────────────────────────────────────

SKILLS["scoring-framework"] = """\
# Scoring Framework

Unified 5-dimension scoring system (0-100) for portfolio rotation decisions.

## Overview

Every ticker — holding or candidate — gets scored on the same 5-dimension \
framework. Each dimension produces a 0-100 score. A style-weighted composite \
determines Hold/Buy/Sell actions.

## Five Dimensions

### 1. Thesis Integrity (default GARP weight: 25%)

Evaluate whether the original investment thesis pillars remain intact.

| Score | Criteria |
|-------|----------|
| 80-100 | All pillars confirmed by recent data; thesis strengthening |
| 60-79 | Most pillars intact; minor concerns but core thesis holds |
| 40-59 | Mixed signals; 1-2 pillars weakening; thesis under pressure |
| 20-39 | Multiple pillars broken; thesis materially impaired |
| 0-19 | Thesis invalidated; original rationale no longer applies |

Scoring mode: Manual via overrides_json. Defaults to 50 if not provided.

### 2. Valuation Attractiveness (default GARP weight: 25%)

Percentile rank of the stock's valuation vs comparable peers.

| Score | Criteria |
|-------|----------|
| 80-100 | Trading at 25th percentile or below on primary metric |
| 60-79 | Below median valuation; modest discount to peers |
| 40-59 | At or near median; fairly valued |
| 20-39 | Above median; premium without clear justification |
| 0-19 | At or above 75th percentile; extreme premium |

Scoring mode: Auto-scored when financial statements are provided (P/E peer \
ranking). Can also be set manually via overrides_json.

### 3. Fundamental Momentum (default GARP weight: 20%)

Recent trajectory of earnings, revenue, and price momentum.

| Score | Criteria |
|-------|----------|
| 80-100 | Beat estimates last 2+ quarters; estimates revising up |
| 60-79 | Beat last quarter; estimates stable or slightly up |
| 40-59 | In-line results; estimates flat |
| 20-39 | Missed last quarter; estimates revising down |
| 0-19 | Multiple misses; significant negative revisions |

Scoring mode: Auto-scored from price data (3/6/12-month returns, trend \
consistency) and financial statements (revenue growth rate, margin trajectory).

### 4. Catalyst Proximity (default GARP weight: 15%)

Upcoming events that could drive re-rating within 1-6 months.

| Score | Criteria |
|-------|----------|
| 80-100 | High-impact catalyst within 1 month |
| 60-79 | Meaningful catalyst within 1-3 months |
| 40-59 | Catalyst identified but 3-6 months away |
| 20-39 | No clear catalyst in next 6 months |
| 0-19 | Negative catalyst approaching |

Scoring mode: Manual via overrides_json. Defaults to 50 if not provided.

### 5. Technical Trend (default GARP weight: 15%)

Price action and momentum indicators as confirmation signals.

| Score | Criteria |
|-------|----------|
| 80-100 | Price above 50 & 200 DMA; RSI 50-70; outperforming benchmark |
| 60-79 | Above 200 DMA; mixed short-term signals |
| 40-59 | Between 50 and 200 DMA; neutral momentum |
| 20-39 | Below 200 DMA; RSI <40; underperforming |
| 0-19 | Below both DMAs with downtrend; RSI <30 or >80 |

Scoring mode: Fully auto-scored from price data (MA crossovers, RSI, \
relative strength vs benchmark).

## Composite Score

Composite = Weighted sum of all 5 dimensions.

Default GARP: (Thesis x 0.25) + (Valuation x 0.25) + (Momentum x 0.20) \
+ (Catalyst x 0.15) + (Technical x 0.15)

Use get_skill("style-presets") for other style weights.

## Decision Thresholds

| Composite Score | Hold Action | Buy Action |
|----------------|------------|------------|
| 70-100 | Strong Hold / Add | Strong Buy candidate |
| 60-69 | Hold | Buy candidate |
| 40-59 | Watch / Review | Watchlist only |
| 20-39 | Sell Candidate | Avoid |
| 0-19 | Urgent Sell | Avoid |

## Auto vs Manual Dimensions

| Dimension | Auto-Scored? | Data Required | Manual Override |
|-----------|-------------|---------------|----------------|
| Thesis Integrity | No | Qualitative judgment | overrides_json: {"AAPL": {"thesis": 75}} |
| Valuation | Yes (with financials) | Financial statements | overrides_json: {"AAPL": {"valuation": 60}} |
| Fundamental Momentum | Yes | Price data + optional financials | overrides_json |
| Catalyst Proximity | No | Event knowledge | overrides_json: {"AAPL": {"catalyst": 80}} |
| Technical Trend | Yes | Price data | overrides_json |

When manual dimensions have no override, they default to 50 (neutral). \
Providing overrides sharpens the signal.

## MCP Tool Workflow

1. Fetch data: call fetch_prices, optionally fetch_financials
2. Score: call score_tickers with prices, financials, overrides, style
3. Interpret: apply decision thresholds above; present 5-dimension breakdown

## Output Format

Present scores as a table:

```
ROTATION SCORECARD
Ticker | Thesis | Valuation | Momentum | Catalyst | Technical | Composite | Action
AAPL   |   70   |    65     |    72    |    60    |    68     |   67.5    | Hold
META   |   75   |    80     |    78    |    85    |    74     |   78.4    | Strong Buy
```

Always show which dimensions were auto-scored vs manually provided vs defaulted.
"""

# ── Swap Methodology ─────────────────────────────────────────────────

SKILLS["swap-methodology"] = """\
# Swap Methodology

Decision framework for portfolio rotation swaps.

## Core Rule

Recommend a swap when: Candidate Buy Score - Holding Hold Score >= 15 points.

This threshold prevents excessive turnover from marginal differences while \
capturing meaningful upgrades. The 15-point gap is calibrated for GARP; \
aggressive styles may use 10, conservative styles may use 20.

## Comparison Logic

### Step 1: Score Both Sides

Score all holdings and all candidates on the same 5 dimensions with the \
same style weights. Use get_skill("scoring-framework") for methodology.

### Step 2: Pairwise Delta Analysis

For each (holding, candidate) pair: Delta = Candidate Composite - Holding Composite

| Delta | Recommendation |
|-------|---------------|
| >= 25 | Strong Swap — high conviction replacement |
| 15-24 | Swap — candidate meaningfully better |
| 5-14 | Monitor — candidate better but not enough to justify costs |
| -4 to 4 | No action — essentially equivalent |
| <= -5 | Keep holding — current position is stronger |

### Step 3: Rank Swaps

When multiple swaps are recommended:
1. Sort by delta (highest first)
2. Check for conflicts (same candidate replacing multiple holdings) — pick \
the highest-delta pairing
3. Check portfolio-level impact via analyze_risk to verify the swap doesn't \
create concentration violations

### Step 4: Present Recommendations

```
SWAP RECOMMENDATIONS
Sell      | Score | Buy       | Score | Delta | Conviction
INTC (48) |  48   | AVGO (76) |  76   |  +28  | Strong Swap
XOM (52)  |  52   | LLY (70)  |  70   |  +18  | Swap
```

For each recommended swap, show:
- Dimension-level comparison (which dimensions drive the delta)
- Key risk: what could go wrong with the swap
- Tax consideration: if selling at a gain, note the tax drag

## Post-Swap Monitoring

After executing a swap:
1. Record the trade — date, tickers, prices, scores at time of swap
2. Track both legs — monitor the bought stock AND what the sold stock does
3. Compute swap alpha — use compute_attribution tool to measure:
   - Did the bought stock outperform?
   - Did the sold stock underperform (confirming the sell)?
   - Net alpha = bought return - sold return
4. Calibrate — if swap alpha is consistently negative, review threshold and weights

## Edge Cases

- Score tie (delta near 0): Default to holding — transaction costs and tax drag
- Multiple candidates above threshold: Pick highest composite, not highest delta
- Holding score below 20: Sell regardless, even without a candidate (capital preservation)
- All candidates below 40: Do not buy — park in cash or benchmark ETF
- Sector concentration: Do not swap into a position that would breach the 30% sector limit

## MCP Tool Workflow

1. Call score_tickers for all holdings and candidates
2. Call compare_swaps with scores, holdings list, candidates list, threshold
3. If swaps recommended, call analyze_risk to verify post-swap portfolio risk
4. Present results using the format above
"""

# ── Risk Management ──────────────────────────────────────────────────

SKILLS["risk-management"] = """\
# Risk Management

Portfolio risk analysis rules for rotation decisions.

## Risk Rules

### Position Concentration

| Condition | Flag Level | Action |
|-----------|-----------|--------|
| Single position > 10% of portfolio | WARNING | Consider trimming or not adding |
| Single position > 15% of portfolio | HIGH | Trim to below 10% |
| Single position > 20% of portfolio | CRITICAL | Immediate trim required |

### Sector Concentration

| Condition | Flag Level | Action |
|-----------|-----------|--------|
| Single sector > 30% of portfolio | WARNING | Diversify next rotation |
| Single sector > 40% of portfolio | HIGH | Prioritize cross-sector swaps |
| Single sector > 50% of portfolio | CRITICAL | Halt same-sector additions |

### Pairwise Correlation

| Condition | Flag Level | Action |
|-----------|-----------|--------|
| Pair correlation > 0.85 | WARNING | Note redundancy; prefer uncorrelated candidate |
| Pair correlation > 0.90 | HIGH | Consider consolidating |
| 3+ positions correlated > 0.85 | CRITICAL | Cluster risk; diversify urgently |

### Portfolio Volatility

| Condition | Flag Level |
|-----------|-----------|
| Annualized vol < 15% | LOW — conservative portfolio |
| Annualized vol 15-25% | MEDIUM — moderate risk |
| Annualized vol > 25% | HIGH — elevated risk; consider defensive positions |

## Overall Risk Level

Aggregate risk level is the highest flag across all checks:

| Level | Meaning |
|-------|---------|
| LOW | All checks pass; no flags |
| MEDIUM | 1-2 warnings but no high/critical flags |
| HIGH | Any high or critical flag present |

## Applying Risk to Rotation Decisions

Before executing any recommended swap:
1. Simulate the post-swap portfolio (new weights)
2. Re-run risk checks on the simulated portfolio
3. If the swap would CREATE a new high/critical flag → do not execute
4. If the swap would RESOLVE an existing flag → additional positive signal

## MCP Tool Workflow

1. Call analyze_risk with portfolio_json (holdings with ticker, weight, sector)
2. Review risk flags and overall risk level
3. Cross-reference with swap recommendations from compare_swaps
4. Present risk dashboard:

```
RISK DASHBOARD
Overall Risk Level: MEDIUM

Position Concentration:
  AAPL: 12.5% WARNING (>10% limit)

Sector Concentration:
  Technology: 35.2% WARNING (>30% limit)

Correlation Flags:
  AAPL-MSFT: 0.87 WARNING (>0.85 threshold)

Portfolio Volatility: 18.3% (MEDIUM)
```

## Important Notes

- Risk rules are guidelines, not hard stops — context matters
- Always present risk flags alongside swap recommendations
- Correlation is computed on daily returns over the specified period (default 1 year)
"""

# ── Style Presets ────────────────────────────────────────────────────

SKILLS["style-presets"] = """\
# Style Presets

Investment style weight configurations for the 5-dimension scoring framework.

## Weight Matrix

| Style | Thesis | Valuation | Momentum | Catalyst | Technical | Best For |
|-------|--------|-----------|----------|----------|-----------|----------|
| GARP | 25% | 25% | 20% | 15% | 15% | Balanced growth-at-reasonable-price |
| Value | 20% | 35% | 15% | 15% | 15% | Deep value, mean reversion |
| Growth | 25% | 15% | 30% | 20% | 10% | High-growth, disruptors |
| Momentum | 10% | 10% | 30% | 20% | 30% | Trend following, relative strength |
| Event-Driven | 15% | 20% | 15% | 35% | 15% | Catalysts, special situations |

## Style Descriptions

### GARP (Default)
Growth at a Reasonable Price. Balanced across all dimensions.
- Core equity portfolio management
- Long-term holding with regular rotation review
- Equal weight on thesis quality and valuation discipline

### Value
Heavy emphasis on valuation attractiveness. Accepts lower momentum.
- Contrarian investors, mean-reversion strategies
- Valuation at 35% — favors cheap stocks even if momentum is weak

### Growth
Prioritizes fundamental momentum and upcoming catalysts.
- Technology and innovation-focused portfolios
- Momentum at 30% — favors accelerating earnings and revenue

### Momentum
Pure price-driven. Heavily weights what's working now.
- Systematic trend-following, relative strength strategies
- Momentum + Technical = 60% of the score. High turnover expected.

### Event-Driven
Catalyst proximity dominates. Seeks asymmetric payoffs.
- Special situations (M&A, spinoffs, restructuring), earnings plays
- Catalyst at 35% — rotates heavily around event calendars

## Choosing a Style

- Default to GARP if no preference stated
- Value: user mentions "cheap", "undervalued", "margin of safety", "contrarian"
- Growth: user mentions "high growth", "disruptor", "secular trend"
- Momentum: user mentions "trend following", "what's working", "relative strength"
- Event-driven: user mentions "catalyst", "earnings play", "special situation"

## Applying Styles

Pass the style name to score_tickers and run_pipeline via the style parameter:

score_tickers(tickers="AAPL,META", ..., style="value")
run_pipeline(portfolio_json=..., candidates="META,AVGO", style="momentum")
"""

# ── Rotation Pipeline ────────────────────────────────────────────────

SKILLS["rotation-pipeline"] = """\
# Rotation Pipeline

Full 6-stage portfolio rotation analysis pipeline.

## Pipeline Stages

refresh -> score -> risk -> compare -> backtest -> report

### Stage 1: Refresh (Data Fetch)
- Tool: fetch_prices (tickers, start_date, end_date)
- Also: fetch_financials if valuation scoring is desired
- Skip: set skip_refresh=true to use cached data

### Stage 2: Score (5-Dimension Scoring)
- Tool: score_tickers
- See get_skill("scoring-framework") for methodology
- Inputs: prices, optional financials, optional overrides, style preset
- Output: per-ticker scorecard with 5 dimensions + composite

### Stage 3: Risk (Portfolio Risk Check)
- Tool: analyze_risk
- See get_skill("risk-management") for rules
- Checks: position >10%, sector >30%, correlation >0.85, volatility
- Output: risk flags, risk level (LOW/MEDIUM/HIGH)

### Stage 4: Compare (Swap Recommendations)
- Tool: compare_swaps
- See get_skill("swap-methodology") for decision logic
- Inputs: scores, holdings, candidates, threshold (default 15)
- Output: ranked swap recommendations with deltas

### Stage 5: Backtest (Historical Simulation)
- Tool: run_backtest
- Inputs: prices, strategy config
- Output: total return, CAGR, Sharpe, Sortino, max drawdown, win rate

### Stage 6: Report (Markdown Summary)
- Combines all stages into a comprehensive rotation report

## Running the Pipeline

### Full Pipeline (Default)
Call run_pipeline with:
- portfolio_json: current holdings array
- candidates: comma-separated candidate tickers
- style: investment style (default "garp")
- overrides_json: optional manual score overrides
- stages: "all" (default)

### Partial Pipeline
Run specific stages: stages="score,compare" or stages="risk"

### Pipeline Dependencies

| Stage | Requires |
|-------|----------|
| refresh | — |
| score | refresh (or cached prices) |
| risk | portfolio data |
| compare | score |
| backtest | refresh (or cached prices) |
| report | all previous stages |

## Output

Present key findings:
1. Scorecard — all tickers ranked by composite score
2. Swap recommendations — any swaps above threshold
3. Risk flags — concentration or correlation violations
4. Backtest summary — strategy performance vs benchmark
5. Action items — execute swaps, monitor, or add overrides
"""


def get_skill_names() -> list[str]:
    """Return sorted list of available skill names."""
    return sorted(SKILLS.keys())


def get_skill_content(name: str) -> str | None:
    """Return skill content by name, or None if not found."""
    return SKILLS.get(name)
