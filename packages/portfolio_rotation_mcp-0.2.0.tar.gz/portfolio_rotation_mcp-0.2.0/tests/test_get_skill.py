"""
Comprehensive tests for the get_skill MCP tool and skills module.

Tests:
1. Skills module: content integrity, all 5 skills present, no empty content
2. get_skill tool: list mode, retrieval, unknown name handling
3. Content quality: key concepts present in each skill
4. Integration: tool returns match module content exactly
"""

import asyncio
import json
import sys
import os

# Add src to path for direct import
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from portfolio_rotation.skills import SKILLS, get_skill_content, get_skill_names
from portfolio_rotation.server import get_skill


def run(coro):
    """Helper to run async functions in tests."""
    return asyncio.get_event_loop().run_until_complete(coro)


# ── 1. Skills Module Tests ───────────────────────────────────────────

EXPECTED_SKILLS = [
    "scoring-framework",
    "swap-methodology",
    "risk-management",
    "style-presets",
    "rotation-pipeline",
]


def test_all_skills_present():
    """All 5 expected skills exist."""
    names = get_skill_names()
    for skill in EXPECTED_SKILLS:
        assert skill in names, f"Missing skill: {skill}"
    print(f"  PASS: all {len(EXPECTED_SKILLS)} skills present")


def test_no_extra_skills():
    """No unexpected skills snuck in."""
    names = get_skill_names()
    for name in names:
        assert name in EXPECTED_SKILLS, f"Unexpected skill: {name}"
    print(f"  PASS: no extra skills (count={len(names)})")


def test_no_empty_content():
    """Every skill has non-empty content."""
    for name in EXPECTED_SKILLS:
        content = get_skill_content(name)
        assert content is not None, f"Skill '{name}' returned None"
        assert len(content.strip()) > 100, f"Skill '{name}' content too short ({len(content)} chars)"
    print("  PASS: all skills have substantial content")


def test_get_skill_names_sorted():
    """get_skill_names returns sorted list."""
    names = get_skill_names()
    assert names == sorted(names), "Skill names not sorted"
    print("  PASS: skill names are sorted")


def test_unknown_skill_returns_none():
    """get_skill_content returns None for unknown name."""
    result = get_skill_content("nonexistent-skill")
    assert result is None, "Expected None for unknown skill"
    print("  PASS: unknown skill returns None")


# ── 2. get_skill Tool Tests ──────────────────────────────────────────

def test_tool_list_mode_empty_string():
    """get_skill('') returns list of available skills."""
    result = run(get_skill(name=""))
    assert "Available skills:" in result
    for name in EXPECTED_SKILLS:
        assert name in result, f"Skill '{name}' not in list output"
    print("  PASS: list mode (empty string) shows all skills")


def test_tool_list_mode_all():
    """get_skill('all') returns list of available skills."""
    result = run(get_skill(name="all"))
    assert "Available skills:" in result
    for name in EXPECTED_SKILLS:
        assert name in result
    print("  PASS: list mode ('all') shows all skills")


def test_tool_retrieve_each_skill():
    """get_skill returns content for each valid skill name."""
    for name in EXPECTED_SKILLS:
        result = run(get_skill(name=name))
        assert len(result) > 100, f"Skill '{name}' returned too little content"
        assert "Unknown skill" not in result, f"Skill '{name}' returned error"
    print(f"  PASS: all {len(EXPECTED_SKILLS)} skills retrievable via tool")


def test_tool_unknown_name():
    """get_skill with unknown name returns helpful error."""
    result = run(get_skill(name="does-not-exist"))
    assert "Unknown skill" in result
    assert "does-not-exist" in result
    # Should list available alternatives
    for name in EXPECTED_SKILLS:
        assert name in result, f"Available skill '{name}' not mentioned in error"
    print("  PASS: unknown name returns error with available list")


def test_tool_matches_module():
    """Tool output matches module content exactly."""
    for name in EXPECTED_SKILLS:
        tool_result = run(get_skill(name=name))
        module_result = get_skill_content(name)
        assert tool_result == module_result, f"Mismatch for skill '{name}'"
    print("  PASS: tool output matches module content for all skills")


# ── 3. Content Quality Tests ─────────────────────────────────────────

def test_scoring_framework_content():
    """scoring-framework contains key concepts."""
    content = get_skill_content("scoring-framework")
    required = [
        "Thesis Integrity",
        "Valuation Attractiveness",
        "Fundamental Momentum",
        "Catalyst Proximity",
        "Technical Trend",
        "Composite",
        "0-100",
        "GARP",
        "overrides_json",
        "Decision Thresholds",
        "Strong Hold",
        "Strong Buy",
        "Sell Candidate",
        "score_tickers",
        "fetch_prices",
    ]
    for term in required:
        assert term in content, f"scoring-framework missing: '{term}'"
    print(f"  PASS: scoring-framework has all {len(required)} key concepts")


def test_swap_methodology_content():
    """swap-methodology contains key concepts."""
    content = get_skill_content("swap-methodology")
    required = [
        ">= 15",
        "Delta",
        "Strong Swap",
        "Monitor",
        "compare_swaps",
        "analyze_risk",
        "Post-Swap Monitoring",
        "swap alpha",
        "compute_attribution",
        "Edge Cases",
        "30% sector limit",
    ]
    for term in required:
        assert term in content, f"swap-methodology missing: '{term}'"
    print(f"  PASS: swap-methodology has all {len(required)} key concepts")


def test_risk_management_content():
    """risk-management contains key concepts."""
    content = get_skill_content("risk-management")
    required = [
        "10%",
        "30%",
        "0.85",
        "WARNING",
        "HIGH",
        "CRITICAL",
        "LOW",
        "MEDIUM",
        "Volatility",
        "Correlation",
        "analyze_risk",
        "RISK DASHBOARD",
    ]
    for term in required:
        assert term in content, f"risk-management missing: '{term}'"
    print(f"  PASS: risk-management has all {len(required)} key concepts")


def test_style_presets_content():
    """style-presets contains all 5 styles with weights."""
    content = get_skill_content("style-presets")
    styles = ["GARP", "Value", "Growth", "Momentum", "Event-Driven"]
    for style in styles:
        assert style in content, f"style-presets missing style: '{style}'"
    # Check weight percentages are present
    assert "25%" in content  # GARP thesis/valuation
    assert "35%" in content  # Value valuation / Event catalyst
    assert "30%" in content  # Growth/Momentum momentum
    assert "score_tickers" in content
    assert "run_pipeline" in content
    print(f"  PASS: style-presets has all {len(styles)} styles with weights")


def test_rotation_pipeline_content():
    """rotation-pipeline contains all 6 stages."""
    content = get_skill_content("rotation-pipeline")
    stages = ["refresh", "score", "risk", "compare", "backtest", "report"]
    for stage in stages:
        assert stage.lower() in content.lower(), f"rotation-pipeline missing stage: '{stage}'"
    required = [
        "fetch_prices",
        "score_tickers",
        "analyze_risk",
        "compare_swaps",
        "run_backtest",
        "run_pipeline",
    ]
    for term in required:
        assert term in content, f"rotation-pipeline missing tool ref: '{term}'"
    print(f"  PASS: rotation-pipeline has all {len(stages)} stages and tool refs")


# ── 4. Cross-Reference Tests ─────────────────────────────────────────

def test_skills_reference_each_other():
    """Skills correctly reference other skills via get_skill()."""
    scoring = get_skill_content("scoring-framework")
    assert "style-presets" in scoring, "scoring-framework should reference style-presets"

    swap = get_skill_content("swap-methodology")
    assert "scoring-framework" in swap, "swap-methodology should reference scoring-framework"

    pipeline = get_skill_content("rotation-pipeline")
    assert "scoring-framework" in pipeline, "rotation-pipeline should reference scoring-framework"
    assert "risk-management" in pipeline, "rotation-pipeline should reference risk-management"
    assert "swap-methodology" in pipeline, "rotation-pipeline should reference swap-methodology"
    print("  PASS: cross-references between skills are correct")


def test_no_cowork_references():
    """Skills should NOT contain Cowork-specific references."""
    cowork_patterns = [
        'skill: "thesis-tracker"',
        'skill: "catalyst-calendar"',
        'skill: "comps-analysis"',
        'skill: "dcf-model"',
        "equity-research plugin",
        "financial-analysis plugin",
        "FSP",
        "Cowork",
    ]
    for name in EXPECTED_SKILLS:
        content = get_skill_content(name)
        for pattern in cowork_patterns:
            assert pattern not in content, (
                f"Skill '{name}' contains Cowork-specific reference: '{pattern}'"
            )
    print(f"  PASS: no Cowork-specific references in any skill")


# ── Run All Tests ────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        # Module tests
        ("Skills module: all present", test_all_skills_present),
        ("Skills module: no extras", test_no_extra_skills),
        ("Skills module: no empty content", test_no_empty_content),
        ("Skills module: sorted names", test_get_skill_names_sorted),
        ("Skills module: unknown returns None", test_unknown_skill_returns_none),
        # Tool tests
        ("Tool: list mode (empty)", test_tool_list_mode_empty_string),
        ("Tool: list mode (all)", test_tool_list_mode_all),
        ("Tool: retrieve each skill", test_tool_retrieve_each_skill),
        ("Tool: unknown name error", test_tool_unknown_name),
        ("Tool: matches module", test_tool_matches_module),
        # Content quality
        ("Content: scoring-framework", test_scoring_framework_content),
        ("Content: swap-methodology", test_swap_methodology_content),
        ("Content: risk-management", test_risk_management_content),
        ("Content: style-presets", test_style_presets_content),
        ("Content: rotation-pipeline", test_rotation_pipeline_content),
        # Cross-references
        ("Cross-ref: skills reference each other", test_skills_reference_each_other),
        ("Cross-ref: no Cowork references", test_no_cowork_references),
    ]

    passed = 0
    failed = 0
    for label, fn in tests:
        try:
            fn()
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {label} — {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {label} — {type(e).__name__}: {e}")
            failed += 1

    print(f"\n{'='*60}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed == 0:
        print("All tests passed!")
    else:
        sys.exit(1)
