# Bug Report — 2026-03-08

**Source**: Cross-validation of MCP pipeline output against independent Financial Datasets API verification.
**Test Case**: Portfolio AAPL 20%, MSFT 15%, JPM 10% (55% cash), candidates META/AVGO, GARP style.

---

## BUG-001: HHI Excludes Cash Position (CRITICAL)

**File**: `src/portfolio_rotation/core/risk.py`, line 38
**Function**: `analyze_concentration()`

**Problem**: HHI (Herfindahl-Hirschman Index) is calculated only over active positions, ignoring the unallocated cash weight. For a portfolio with 55% cash:

```python
# Current (wrong):
hhi = sum(w ** 2 for w in position_weights.values())
# = 0.20² + 0.15² + 0.10² = 0.0725

# Correct:
# Include cash as (1 - sum_of_weights)
# = 0.20² + 0.15² + 0.10² + 0.55² = 0.375
```

**Impact**: HHI understated by 5.2x (0.0725 vs 0.375). Effective positions inflated from 2.7 to 13.8. Concentration risk is severely underestimated when portfolios hold significant cash.

---

## BUG-002: Sortino Ratio Calculation Wrong (CRITICAL)

**File**: `src/portfolio_rotation/core/backtest.py`, lines 208-209
**Function**: `run_backtest()`

**Problem**: Two errors in the Sortino denominator:

1. **Wrong population**: Uses only negative-return days (`[r for r in daily_returns if r < 0]`) instead of applying `min(r, 0)` across ALL days.
2. **Wrong denominator count**: Divides by `len(downside_returns)` (count of negative days only) instead of `len(daily_returns)` (total trading days).

```python
# Current (wrong):
downside_returns = [r for r in daily_returns if r < 0]
downside_std = math.sqrt(sum(r ** 2 for r in downside_returns) / max(len(downside_returns) - 1, 1))

# Correct:
downside_std = math.sqrt(sum(min(r, 0) ** 2 for r in daily_returns) / max(len(daily_returns) - 1, 1))
```

**Impact**: Sortino (1.32) ≈ Sharpe (1.30) for a strategy with 66.7% win rate and 2.54x win/loss ratio. A positively-skewed strategy should have Sortino significantly higher than Sharpe. The bug makes downside risk appear equal to total risk.

---

## BUG-003: Portfolio Volatility Ignores Cash Weight (MEDIUM)

**File**: `src/portfolio_rotation/core/risk.py`, lines 119-122
**Function**: `analyze_risk()`

**Problem**: Portfolio volatility uses raw position weights (summing to 0.45) without accounting for the 55% cash (zero-volatility). The weights are not normalized, and cash is not included as a zero-variance asset.

```python
# Current:
w_arr = np.array([weights[t] for t in available])
# = [0.20, 0.15, 0.10]  (sum = 0.45, not 1.0)

cov_matrix = returns[available].cov() * 252
port_var = w_arr @ cov_matrix.values @ w_arr
```

The quadratic form w'Σw with weights summing to 0.45 implicitly treats the portfolio as 45% invested. This is mathematically correct for the invested portion, but the result (10.59%) represents the total portfolio volatility only if cash truly has zero correlation. This is actually correct behavior but is not documented.

**Impact**: The volatility number is technically correct but misleading without disclosure that it already accounts for 55% cash dampening.

---

## ISSUE-004: Per-Ticker Volatility Method Difference (LOW)

**File**: `src/portfolio_rotation/core/risk.py`, line 128

**Problem**: Per-ticker annualized volatility uses daily returns × √252, which is standard but typically yields higher values than monthly returns × √12. Report shows AAPL 32.4% vs independent verification of ~20.1%.

**Root cause**: Not a bug per se — daily data captures intraday noise that monthly smooths out. However, the methodology is not disclosed in the report output.

---

## ISSUE-005: Composite Score Formula Not Disclosed (LOW)

**File**: `src/portfolio_rotation/core/scoring.py`, lines 243-254

**Problem**: Composite score uses normalized weighted average (re-normalized when dimensions are missing), not a simple average. When only 2 of 5 dimensions are available, GARP weights (momentum=20%, technical=15%) are renormalized to (57%:43%). This is correct but the report says nothing about the formula.

---

## Reproduction

```bash
# Run pipeline that triggers all bugs
cd /path/to/project
./rotate.sh --candidates META,AVGO
# Then compare data/rotation_report.md against independent API verification
```
