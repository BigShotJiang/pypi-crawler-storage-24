# Rotation Scoring Framework

Unified 0-100 scoring system for both Hold Score (current positions) and Buy Score (candidates).

## Five Dimensions

### 1. Thesis Integrity (25% GARP weight)

Evaluate whether the original investment thesis pillars remain intact.

| Score | Criteria |
|-------|----------|
| 80-100 | All pillars confirmed by recent data; thesis strengthening |
| 60-79 | Most pillars intact; minor concerns but core thesis holds |
| 40-59 | Mixed signals; 1-2 pillars weakening; thesis under pressure |
| 20-39 | Multiple pillars broken; thesis materially impaired |
| 0-19 | Thesis invalidated; original rationale no longer applies |

### 2. Valuation Attractiveness (25% GARP weight)

Percentile rank of the stock's valuation vs comparable peers.

| Score | Criteria |
|-------|----------|
| 80-100 | Trading at 25th percentile or below on primary metric |
| 60-79 | Below median valuation; modest discount to peers |
| 40-59 | At or near median; fairly valued |
| 20-39 | Above median; premium without clear justification |
| 0-19 | At or above 75th percentile; extreme premium |

### 3. Fundamental Momentum (20% GARP weight)

Recent trajectory of earnings, revenue, and estimates.

| Score | Criteria |
|-------|----------|
| 80-100 | Beat estimates last 2+ quarters; estimates revising up |
| 60-79 | Beat last quarter; estimates stable or slightly up |
| 40-59 | In-line results; estimates flat |
| 20-39 | Missed last quarter; estimates revising down |
| 0-19 | Multiple misses; significant negative revisions |

### 4. Catalyst Proximity (15% GARP weight)

Upcoming events that could drive re-rating within 1-6 months.

| Score | Criteria |
|-------|----------|
| 80-100 | High-impact catalyst within 1 month |
| 60-79 | Meaningful catalyst within 1-3 months |
| 40-59 | Catalyst identified but 3-6 months away |
| 20-39 | No clear catalyst in next 6 months |
| 0-19 | Negative catalyst approaching |

### 5. Technical Trend (15% GARP weight)

Price action and momentum indicators as confirmation signals.

| Score | Criteria |
|-------|----------|
| 80-100 | Price above 50 & 200 DMA; RSI 50-70; outperforming benchmark |
| 60-79 | Above 200 DMA; mixed short-term signals |
| 40-59 | Between 50 and 200 DMA; neutral momentum |
| 20-39 | Below 200 DMA; RSI <40; underperforming |
| 0-19 | Below both DMAs with downtrend; RSI <30 or >80 |

## Composite Score = Weighted Sum

Default GARP: (Thesis x 0.25) + (Valuation x 0.25) + (Momentum x 0.20) + (Catalyst x 0.15) + (Technical x 0.15)

## Decision Thresholds

| Score | Hold Action | Buy Action |
|-------|------------|------------|
| 70-100 | Strong Hold / Add | Strong Buy candidate |
| 60-69 | Hold | Buy candidate |
| 40-59 | Watch / Review | Watchlist only |
| 20-39 | Sell Candidate | Avoid |
| 0-19 | Urgent Sell | Avoid |

**Swap threshold**: Recommend swap when Buy Score - Hold Score >= 15.

## Style-Specific Weights

| Style | Thesis | Valuation | Momentum | Catalyst | Technical |
|-------|--------|-----------|----------|----------|-----------|
| Value | 20% | 35% | 15% | 15% | 15% |
| Growth | 25% | 15% | 30% | 20% | 10% |
| GARP | 25% | 25% | 20% | 15% | 15% |
| Momentum | 10% | 10% | 30% | 20% | 30% |
| Event-driven | 15% | 20% | 15% | 35% | 15% |
