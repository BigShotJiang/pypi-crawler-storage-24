from calculate_server import main
main()