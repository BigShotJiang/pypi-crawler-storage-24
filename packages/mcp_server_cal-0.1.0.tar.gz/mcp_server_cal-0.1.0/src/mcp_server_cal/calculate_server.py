from mcp.server.fastmcp import FastMCP

# 创建FastMCP实例
mcp = FastMCP("calculate_server")

# 定义一个负责计算的函数,通过 @mcp.tool() 装饰器注册为 MCP 服务器的工具，使其能够被客户端调用。
@mcp.tool()
def calculate(a: int, b: int, operator: str) -> None | int | float:
    """
    计算a和b的运算结果
    :param a: 第一个数
    :param b: 第二个数
    :param operator: 运算符，支持+、-、*、/
    :return: 运算结果, 如果运算符不合法，则返回None
    """

    if not isinstance(a, int) or not isinstance(b, int):
        raise ValueError("参数类型不合法")

    if operator not in ['+', '-', '*', '/']:
        raise ValueError("运算符不合法")

    if operator == "+":
        return a + b
    elif operator == "-":
        return a - b
    elif operator == "*":
        return a * b
    elif operator == "/":
        if b == 0:
            raise ValueError("除数不能为0")
        return a / b

def main():
    mcp.run(transport="stdio")

if __name__ == '__main__':
    # 调用 mcp.run(transport='stdio') 启动 MCP 服务器，采用标准 I/O 通信方式，等待客户端调用。
    mcp.run(transport="stdio")