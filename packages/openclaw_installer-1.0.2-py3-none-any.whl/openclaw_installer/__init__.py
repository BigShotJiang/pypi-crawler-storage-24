"""OpenClaw Installer - Zero-config setup for OpenClaw AI assistant."""

__version__ = "1.0.1"
__all__ = ["Config", "Installer", "auto_login"]

# Import auto_login for convenient access
try:
    from .automation.auto_login import auto_login
except ImportError:
    auto_login = None  # Automation module may not be available
