"""Test data for Hunter Douglas PowerRise Platinum protocol.

Contains sample protocol responses extracted from the smali code and
Lua implementation for use in unit tests.
"""

# Sample banner line received on connection.
# The hub prefixes all responses with the connection number (e.g. "3 ").
BANNER_LINE = "3 HunterDouglas Shade Controller\r\n"
BANNER_LINE_BARE = "HunterDouglas Shade Controller\r\n"

# Sample $dat response - a realistic full data dump
SAMPLE_DAT_RESPONSE: list[str] = [
    "$LEDl128-",
    "$firm00-0018",
    "$MAC0x000B3C6065A3-",
    "$upd00-",
    "$ct-------My Home",
    "$cr00-01--------Living Room",
    "$cr01-02--------Bedroom",
    "$cr02-01--------Kitchen",
    "$cs00-00-00---Living Room Left",
    "$cs01-00-00---Living Room Right",
    "$cs02-01-00---Bedroom Shade",
    "$cs03-02-00---Kitchen Blind",
    "$cm00-----Morning",
    "$cm01-----Evening",
    "$cm02-----All Open",
    "$cp00-04-200-",
    "$cp01-04-128-",
    "$cp02-04-000-",
    "$cp03-07-180-",
    "$cq00-00-01-",
    "$cq00-01-01-",
    "$cq01-02-01-",
    "$cq01-03-01-",
    "$cq02-00-00-",
    "$cx00-00-04-200-",
    "$cx01-01-04-000-",
    "$ca00-07-30-31-01-",
    "$ca01-22-00-62-01-",
    "$upd01-",
]

# Minimal $dat response for simple tests
MINIMAL_DAT_RESPONSE = [
    "$LEDl64-",
    "$firm00-0020-",
    "$upd00-",
    "$ct-------Test House",
    "$cr00-01--------Room A",
    "$cs00-00-00---Shade A",
    "$cp00-04-128-",
    "$cm00-----Scene A",
    "$upd01-",
]

# Same as SAMPLE_DAT_RESPONSE but with connection-number prefix "3 " on every
# line, as the hub would actually send them when this is the third connection.
# Used to verify that the transport strips the prefix before handing lines to
# parsers (and that parsers are robust even if they receive prefixed lines).
PREFIXED_DAT_RESPONSE = [f"3 {line}" for line in SAMPLE_DAT_RESPONSE]

# Response to shade position command
SHADE_POSITION_RESPONSE = [
    "$done",
]

# Response to release command
SHADE_RELEASE_RESPONSE = [
    "$act00-00-",
]

# Response to scene invoke
SCENE_INVOKE_RESPONSE = [
    "$act00-00-",
]

# Response to dummy/ping command
PING_RESPONSE = [
    "$ack",
]

# Error response
ERROR_RESPONSE = [
    "$error03-",
]

# Room line variations
ROOM_LINES = [
    ("$cr00-01--------Living Room", 0, 1, "Living Room"),
    ("$cr01-02--------Bedroom", 1, 2, "Bedroom"),
    ("$cr09-03--------Den", 9, 3, "Den"),
]

# Shade line variations
SHADE_LINES = [
    ("$cs00-00-00---Left Shade", 0, 0, 0, "Left Shade"),
    ("$cs01-00-01---Right Shade", 1, 0, 1, "Right Shade"),
    ("$cs05-02-00---Kitchen Shade", 5, 2, 0, "Kitchen Shade"),
]

# Scene line variations
SCENE_LINES = [
    ("$cm00-----All Open", 0, "All Open"),
    ("$cm01-----Goodnight", 1, "Goodnight"),
    ("$cm09-----Movie Mode", 9, "Movie Mode"),
]

# Shade position line variations.
# Tuples: (line, shade_id, feature_code, wire_value)
# feature_code 4 → updates shade.position
# feature_code 6 → updates shade.tilt_position
SHADE_POSITION_LINES = [
    ("$cp00-04-255-", 0, 4, 255),   # Fully open (primary)
    ("$cp01-04-000-", 1, 4, 0),     # Fully closed (primary)
    ("$cp02-04-128-", 2, 4, 128),   # Half open (primary)
    ("$cp03-07-180-", 3, 7, 180),   # Tilt update
]

# Scene link line variations
SCENE_LINK_LINES = [
    ("$cq00-01-01-", 0, 1, True),   # Scene 0, shade 1, linked
    ("$cq00-02-00-", 0, 2, False),  # Scene 0, shade 2, not linked
]
