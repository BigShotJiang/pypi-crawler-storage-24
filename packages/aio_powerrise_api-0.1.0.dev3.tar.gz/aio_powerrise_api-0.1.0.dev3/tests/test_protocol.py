"""Tests for aiopowerrise.protocol."""

import pytest

from aiopowerrise.exceptions import HunterDouglasError
from aiopowerrise.models import (
    House,
    Room,
    Scene,
    Shade,
)
from aiopowerrise.protocol import (
    _find_error_type,
    _is_end_sentinel,
    _parse_firmware,
    _parse_led_brightness,
    _parse_scene_link,
    _parse_scene_room_position,
    _parse_shade_position,
    _parse_title,
    get_command_line,
    parse_all_data,
    parse_room,
    parse_scene,
    parse_shade,
    parse_timed_event,
)
from tests.test_data import (
    MINIMAL_DAT_RESPONSE,
    PREFIXED_DAT_RESPONSE,
    ROOM_LINES,
    SAMPLE_DAT_RESPONSE,
    SCENE_LINES,
    SCENE_LINK_LINES,
    SHADE_LINES,
    SHADE_POSITION_LINES,
)


# ---------------------------------------------------------------------------
# parse_room
# ---------------------------------------------------------------------------


class TestParseRoom:
    @pytest.mark.parametrize(
        ("line", "expected_id", "expected_brand", "expected_name"),
        ROOM_LINES,
    )
    def test_parse_room(
        self,
        line: str,
        expected_id: int,
        expected_brand: int,
        expected_name: str,
    ) -> None:
        room = parse_room(line)
        assert room is not None
        assert room.id == expected_id
        assert room.brand_index == expected_brand
        assert room.name == expected_name

    def test_parse_room_none_on_bad_data(self) -> None:
        assert parse_room("") is None

    def test_parse_room_short_line(self) -> None:
        room = parse_room("$cr00-01-")
        assert room is not None
        assert room.id == 0
        assert room.name == ""


# ---------------------------------------------------------------------------
# parse_shade
# ---------------------------------------------------------------------------


class TestParseShade:
    @pytest.mark.parametrize(
        ("line", "expected_id", "expected_room", "expected_group", "expected_name"),
        SHADE_LINES,
    )
    def test_parse_shade(
        self,
        line: str,
        expected_id: int,
        expected_room: int,
        expected_group: int,
        expected_name: str,
    ) -> None:
        shade = parse_shade(line, [])
        assert shade is not None
        assert shade.id == expected_id
        assert shade.room_id == expected_room
        assert shade.name == expected_name

    def test_parse_shade_none_on_bad_data(self) -> None:
        assert parse_shade("", []) is None


# ---------------------------------------------------------------------------
# parse_scene
# ---------------------------------------------------------------------------


class TestParseScene:
    @pytest.mark.parametrize(
        ("line", "expected_id", "expected_name"),
        SCENE_LINES,
    )
    def test_parse_scene(
        self, line: str, expected_id: int, expected_name: str
    ) -> None:
        scene = parse_scene(line)
        assert scene is not None
        assert scene.id == expected_id
        assert scene.name == expected_name

    def test_parse_scene_none_on_empty(self) -> None:
        assert parse_scene("") is None

    def test_parse_scene_none_on_whitespace(self) -> None:
        assert parse_scene("   ") is None


# ---------------------------------------------------------------------------
# parse_timed_event
# ---------------------------------------------------------------------------


class TestParseTimedEvent:
    def test_basic_timed_event(self) -> None:
        event = parse_timed_event("$ca00-07-30-31-01-", [])
        assert event is not None
        assert event.scene_index == 0
        assert event.hour == 7
        assert event.minute == 30
        assert event.day_bits == 31
        assert event.enabled is True

    def test_disabled_event(self) -> None:
        event = parse_timed_event("$ca01-22-00-62-00-", [])
        assert event is not None
        assert event.enabled is False

    def test_bad_data_returns_none(self) -> None:
        assert parse_timed_event("", []) is None


# ---------------------------------------------------------------------------
# _parse_shade_position
# ---------------------------------------------------------------------------


class TestParseShadePosition:
    @pytest.mark.parametrize(
        ("line", "shade_id", "feature_code", "wire_value"),
        SHADE_POSITION_LINES,
    )
    def test_parse_shade_position(
        self, line: str, shade_id: int, feature_code: int, wire_value: int
    ) -> None:
        shades = [Shade(id=shade_id)]
        _parse_shade_position(line, shades)
        if feature_code in (7, 19):  # tilt / reverse-tilt
            assert shades[0].tilt_position == wire_value
            assert shades[0].position == 0  # primary unchanged
        else:
            assert shades[0].position == wire_value
            assert shades[0].tilt_position == 0  # tilt unchanged

    def test_tilt_zeros_position(self) -> None:
        """A tilt $cp line must zero shade.position (hardware closes shade first)."""
        shade = Shade(id=3, position=200)
        _parse_shade_position("$cp03-07-180-", [shade])
        assert shade.position == 0           # zeroed — shade is now closed
        assert shade.tilt_position == 180    # tilt stored
        assert shade.tilt_command == 7       # forward command recorded

    def test_tilt_reverse_command_stored(self) -> None:
        """A cmd-19 $cp line must store tilt_command=19."""
        shade = Shade(id=3, position=0)
        _parse_shade_position("$cp03-19-128-", [shade])
        assert shade.tilt_position == 128
        assert shade.tilt_command == 19      # reverse command recorded

    def test_position_clears_tilt(self) -> None:
        """A primary $cp line must zero shade.tilt_position (shade is moving)."""
        shade = Shade(id=0, position=0, tilt_position=128, tilt_command=19)
        _parse_shade_position("$cp00-04-255-", [shade])
        assert shade.position == 255         # primary updated
        assert shade.tilt_position == 0      # tilt cleared
        assert shade.tilt_command == 7       # reset to forward default

    def test_no_matching_shade(self) -> None:
        """If shade ID doesn't match, nothing happens."""
        shades = [Shade(id=99)]
        _parse_shade_position("$cp00-04-200-", shades)
        assert shades[0].position == 0  # unchanged

    def test_bad_data(self) -> None:
        """Bad data should not raise, just log warning."""
        shades = [Shade(id=0)]
        _parse_shade_position("garbage", shades)
        assert shades[0].position == 0  # unchanged


# ---------------------------------------------------------------------------
# _parse_scene_link
# ---------------------------------------------------------------------------


class TestParseSceneLink:
    def test_linked(self) -> None:
        shades = [Shade(id=1)]
        scenes = [Scene(id=0)]
        link = _parse_scene_link("$cq00-01-01-", shades, scenes)
        assert link is not None
        assert link.shade_id == 1
        assert link.is_linked is True
        assert len(scenes[0].links) == 1

    def test_not_linked(self) -> None:
        shades = [Shade(id=2)]
        scenes = [Scene(id=0)]
        link = _parse_scene_link("$cq00-02-00-", shades, scenes)
        assert link is not None
        assert link.is_linked is False
        # Not-linked entries shouldn't be added to scene
        assert len(scenes[0].links) == 0


# ---------------------------------------------------------------------------
# _parse_scene_room_position
# ---------------------------------------------------------------------------


class TestParseSceneRoomPosition:
    def test_basic(self) -> None:
        scenes = [Scene(id=0)]
        rooms = [Room(id=1)]
        _parse_scene_room_position("$cx00-01-04-128-", scenes, rooms)
        assert len(scenes[0].room_positions) == 1
        srp = scenes[0].room_positions[0]
        assert srp.room_id == 1
        assert srp.scene_index == 0
        assert srp.command == "04"
        assert srp.position == 128


# ---------------------------------------------------------------------------
# _parse_title
# ---------------------------------------------------------------------------


class TestParseTitle:
    def test_basic_title(self) -> None:
        assert _parse_title("$ct-------My Home") == "My Home"

    def test_title_with_extra_dashes(self) -> None:
        name = _parse_title("$ct-------Fancy House Name")
        assert name == "Fancy House Name"

    def test_short_title(self) -> None:
        name = _parse_title("$ct-------X")
        assert name == "X"


# ---------------------------------------------------------------------------
# _parse_led_brightness
# ---------------------------------------------------------------------------


class TestParseLedBrightness:
    def test_full_brightness(self) -> None:
        assert _parse_led_brightness("$LEDl255-") == 255

    def test_zero_brightness(self) -> None:
        assert _parse_led_brightness("$LEDl0-") == 0

    def test_mid_brightness(self) -> None:
        assert _parse_led_brightness("$LEDl128-") == 128


# ---------------------------------------------------------------------------
# _parse_firmware
# ---------------------------------------------------------------------------


class TestParseFirmware:
    def test_firmware_version(self) -> None:
        assert _parse_firmware("$firm00-0018-") == 18

    def test_firmware_version_higher(self) -> None:
        assert _parse_firmware("$firm00-0020-") == 20


# ---------------------------------------------------------------------------
# _is_end_sentinel
# ---------------------------------------------------------------------------


class TestIsEndSentinel:
    def test_done(self) -> None:
        assert _is_end_sentinel("$done") is True

    def test_upd01(self) -> None:
        assert _is_end_sentinel("$upd01-") is True

    def test_act(self) -> None:
        assert _is_end_sentinel("$act00-00-") is True

    def test_error(self) -> None:
        assert _is_end_sentinel("$error03-") is True

    def test_not_sentinel(self) -> None:
        assert _is_end_sentinel("$cr00-01--------Room") is False


# ---------------------------------------------------------------------------
# _find_error_type
# ---------------------------------------------------------------------------


class TestFindErrorType:
    def test_error_03(self) -> None:
        assert _find_error_type("$error03-") == "03"

    def test_error_01(self) -> None:
        assert _find_error_type("$error01-") == "01"

    def test_unknown_defaults_to_00(self) -> None:
        assert _find_error_type("$errorXX-") == "00"


# ---------------------------------------------------------------------------
# get_command_line
# ---------------------------------------------------------------------------


class TestGetCommandLine:
    def test_find_command(self) -> None:
        lines = ["$ack", "$cr00-01--------Room", "$done"]
        result = get_command_line(lines, "$cr")
        assert result is not None
        assert "$cr" in result

    def test_not_found(self) -> None:
        lines = ["$ack", "$done"]
        result = get_command_line(lines, "$NOTFOUND")
        assert result is None

    def test_raises_on_error(self) -> None:
        lines = ["$error03-"]
        with pytest.raises(HunterDouglasError) as exc_info:
            get_command_line(lines, "$cr")
        assert exc_info.value.error_code == "03"


# ---------------------------------------------------------------------------
# parse_all_data  –  full integration
# ---------------------------------------------------------------------------


class TestParseAllData:
    def test_minimal_response(self) -> None:
        house = parse_all_data(MINIMAL_DAT_RESPONSE)
        assert isinstance(house, House)
        assert house.name == "Test House"
        assert len(house.rooms) == 1
        assert len(house.shades) == 1
        assert len(house.scenes) == 1
        assert house.bridge.firmware_version == 20
        assert house.bridge.led_brightness_bits == 64

    def test_full_response(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert house.name == "My Home"
        assert len(house.rooms) == 3
        assert len(house.shades) == 4
        assert len(house.scenes) == 3
        assert house.bridge.firmware_version == 18
        assert house.bridge.led_brightness_bits == 128

    def test_rooms_populated(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert 0 in house.rooms
        assert 1 in house.rooms
        assert 2 in house.rooms
        assert house.rooms[0].name == "Living Room"
        assert house.rooms[1].name == "Bedroom"
        assert house.rooms[2].name == "Kitchen"

    def test_shades_populated(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert 0 in house.shades
        assert 1 in house.shades
        assert 2 in house.shades
        assert 3 in house.shades

    def test_shade_positions(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert house.shades[0].position == 200
        assert house.shades[1].position == 128
        assert house.shades[2].position == 0
        # Shade 3's $cp line has feature 07 (tilt) → goes to tilt_position
        assert house.shades[3].position == 0
        assert house.shades[3].tilt_position == 180

    def test_shade_room_association(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        # Shades 0 and 1 belong to room 0
        assert 0 in house.rooms[0].shades
        assert 1 in house.rooms[0].shades
        # Shade 2 belongs to room 1
        assert 2 in house.rooms[1].shades
        # Shade 3 belongs to room 2
        assert 3 in house.rooms[2].shades

    def test_scenes_populated(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert house.scenes[0].name == "Morning"
        assert house.scenes[1].name == "Evening"
        assert house.scenes[2].name == "All Open"

    def test_scene_links(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        # Scene 0 should have 2 linked shades (0, 1)
        scene0_links = house.scenes[0].links
        linked_ids = {lnk.shade_id for lnk in scene0_links if lnk.is_linked}
        assert 0 in linked_ids
        assert 1 in linked_ids

    def test_timed_events(self) -> None:
        house = parse_all_data(SAMPLE_DAT_RESPONSE)
        assert len(house.timed_events) == 2
        assert house.timed_events[0].hour == 7
        assert house.timed_events[0].minute == 30
        assert house.timed_events[1].hour == 22

    def test_supports_tilt_stamped_from_room(self) -> None:
        """Shades inherit supports_tilt and supports_tilt_reverse from their room."""
        # brand 10 = Silhouette (tilt, no reverse), brand 6 = Luminette (tilt + reverse)
        lines = [
            "$ct-------Test House",
            "$upd00-",
            "$cr00-10--------Silhouette Room",   # brand 10 → tilt only
            "$cr01-06--------Luminette Room",    # brand  6 → tilt + reverse
            "$cr02-01--------Roller Room",       # brand  1 → no tilt
            "$cs00-00-00---Silhouette Shade",    # room 0
            "$cs01-01-00---Luminette Shade",     # room 1
            "$cs02-02-00---Roller Shade",        # room 2
            "$upd01-",
        ]
        house = parse_all_data(lines)
        assert house.shades[0].supports_tilt is True
        assert house.shades[0].supports_tilt_reverse is False
        assert house.shades[1].supports_tilt is True
        assert house.shades[1].supports_tilt_reverse is True
        assert house.shades[2].supports_tilt is False
        assert house.shades[2].supports_tilt_reverse is False

    def test_empty_response(self) -> None:
        house = parse_all_data([])
        assert isinstance(house, House)
        assert house.name == ""
        assert len(house.rooms) == 0

    def test_blank_lines_skipped(self) -> None:
        lines = ["", "  ", "$LEDl64-", "$firm00-0020-", "$upd00-", "$ct-------Test", "$upd01-"]
        house = parse_all_data(lines)
        assert house.name == "Test"


# ---------------------------------------------------------------------------
# Connection-number prefix robustness
# ---------------------------------------------------------------------------


class TestConnectionNumberPrefix:
    """Verify parsers are robust to the hub's connection-number prefix.

    The hub prepends ``"N "`` (connection number + space) to every response
    line.  The transport layer strips this before passing lines downstream,
    but the parsers themselves must also tolerate prefixed lines as a
    belt-and-suspenders measure (e.g. during banner reads or if the strip
    ever regresses).
    """

    def test_parse_room_with_prefix(self) -> None:
        room = parse_room("3 $cr01-02--------Bedroom")
        assert room is not None
        assert room.id == 1
        assert room.brand_index == 2
        assert room.name == "Bedroom"

    def test_parse_shade_with_prefix(self) -> None:
        shade = parse_shade("3 $cs02-01-00---Bedroom Shade", [])
        assert shade is not None
        assert shade.id == 2
        assert shade.room_id == 1

    def test_parse_scene_with_prefix(self) -> None:
        scene = parse_scene("3 $cm01-----Evening")
        assert scene is not None
        assert scene.id == 1
        assert scene.name == "Evening"

    def test_parse_shade_position_with_prefix(self) -> None:
        shade = Shade(id=1)
        _parse_shade_position("3 $cp01-04-128-", [shade])
        assert shade.position == 128

    def test_parse_all_data_with_prefixed_lines(self) -> None:
        """parse_all_data produces correct results with connection-number-prefixed lines.

        The transport strips the prefix before handing lines to parsers, but
        the parsers use rfind() so they are correct regardless.
        """
        house = parse_all_data(PREFIXED_DAT_RESPONSE)
        assert house.name == "My Home"
        assert len(house.rooms) == 3
        assert len(house.shades) == 4
        assert len(house.scenes) == 3
        assert house.bridge.firmware_version == 18


# ---------------------------------------------------------------------------
# MAC address parsing
# ---------------------------------------------------------------------------


class TestParseMac:
    """Tests for _parse_mac."""

    def test_parse_mac_with_0x_prefix(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("$MAC0x000B3C6065A3-") == "00:0B:3C:60:65:A3"

    def test_parse_mac_with_connection_number_prefix(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("3 $MAC0x000B3C6065A3-") == "00:0B:3C:60:65:A3"

    def test_parse_mac_without_0x_prefix(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("$MAC000B3C6065A3-") == "00:0B:3C:60:65:A3"

    def test_parse_mac_lowercase_normalised_to_upper(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("$MAC0x000b3c6065a3-") == "00:0B:3C:60:65:A3"

    def test_parse_mac_invalid_returns_none(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("$ct-----My House") is None

    def test_parse_mac_short_hex_returns_none(self) -> None:
        from aiopowerrise.protocol import _parse_mac
        assert _parse_mac("$MAC0x000B3C-") is None

    def test_parse_all_data_populates_mac(self) -> None:
        from aiopowerrise.protocol import parse_all_data
        lines = [
            "$MAC0x000B3C6065A3-",
            "$upd01-",
        ]
        house = parse_all_data(lines)
        assert house.bridge.mac_address == "00:0B:3C:60:65:A3"
