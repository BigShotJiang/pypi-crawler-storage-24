"""Data models for Hunter Douglas PowerRise Platinum."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from aiopowerrise.const import (
    BRAND_INDEXES_WITH_SECONDARY,
    BRAND_INDEXES_WITH_TILT,
    BRAND_INDEXES_WITH_TILT_REVERSE,
    BRAND_MAP,
    BRAND_SHADE_TYPE_MAP,
    MAX_POSITION,
    MIN_POSITION,
    SHADE_TYPE_DUAL_SLIDERS,
    SHADE_TYPE_SLAT,
    SHADE_TYPE_TOP_BAR_DOWN,
    SHADE_TYPE_VANE,
    WIRE_MAX_POSITION,
)


@dataclass
class ShadePosition:
    """Shade position as percentages (0-100).

    Mirrors the ShadePosition dataclass in aio-powerview-api.
    primary = main shade position (0=closed, 100=open)
    secondary = top-down rail or overlapped shade
    tilt = vane tilt angle
    """

    primary: int | None = None
    secondary: int | None = None
    tilt: int | None = None

    @staticmethod
    def from_wire(position: int) -> int:
        """Convert a wire position (0-255) to percentage (0-100)."""
        return round(position * MAX_POSITION / WIRE_MAX_POSITION)

    @staticmethod
    def to_wire(percent: int) -> int:
        """Convert a percentage (0-100) to wire position (0-255)."""
        clamped = max(MIN_POSITION, min(MAX_POSITION, percent))
        return round(clamped * WIRE_MAX_POSITION / MAX_POSITION)


@dataclass
class Bridge:
    """Represents the PowerRise bridge/hub hardware."""

    firmware_version: int | None = None
    led_brightness_bits: int | None = None
    mac_address: str | None = None

    @property
    def led_brightness_percentage(self) -> float:
        """Return LED brightness as a percentage (0.0-1.0)."""
        if self.led_brightness_bits is None or self.led_brightness_bits <= 0:
            return 0.0
        return self.led_brightness_bits / WIRE_MAX_POSITION


@dataclass
class Room:
    """Represents a room in the system."""

    id: int = 0
    name: str = ""
    brand_index: int = 0
    shades: list[int] = field(default_factory=list)  # shade IDs

    # ------------------------------------------------------------------
    # Brand / product-type helpers 
    # ------------------------------------------------------------------

    @property
    def brand_name(self) -> str:
        """Return the human-readable product name for this room's shade type.

        Falls back to "Unknown" for unrecognised brand indexes.
        """
        return BRAND_MAP.get(self.brand_index, "Unknown")

    @property
    def shade_type(self) -> int:
        """Return the shade-type classification code (SHADE_TYPE_* constant).

        Values:
          1500 – BOTTOM_BAR_UP   (standard roller / honeycomb)
          1600 – TOP_BAR_DOWN    (top-down only)
          1700 – DUAL_SLIDERS    (top-down/bottom-up)
          1800 – SLAT            (Luminette – horizontal vanes, supports tilt)
          1900 – VANE            (Pirouette / Silhouette – vanes, supports tilt)
          0    – unknown / not mapped
        """
        return BRAND_SHADE_TYPE_MAP.get(self.brand_index, 0)

    @property
    def supports_tilt(self) -> bool:
        """Return True if shades in this room support vane/tilt control.

        True for Pirouette (9), Silhouette (10, 21), and Luminette (6, 8).
        These are the VANE and SLAT shade types.
        """
        return self.brand_index in BRAND_INDEXES_WITH_TILT

    @property
    def supports_tilt_reverse(self) -> bool:
        """Return True if shades in this room support bidirectional / reverse tilt.

        True for Luminette Privacy (6) and Luminette Dual (8) — SLAT types.
        These shades split the 0-100% logical tilt range into two halves:
          0-50%   → cmd 07 (forward vane rotation, wire 0→255)
          50-100% → cmd 19 (reverse vane rotation, wire 0→255)
        """
        return self.brand_index in BRAND_INDEXES_WITH_TILT_REVERSE

    @property
    def supports_secondary_position(self) -> bool:
        """Return True if shades in this room have a secondary (top-down) rail.

        True for DuoLite (2), Top-Down (3), Vignette TDBU (13),
        and Provenance TDBU (25).
        """
        return self.brand_index in BRAND_INDEXES_WITH_SECONDARY

    @property
    def is_top_down(self) -> bool:
        """Return True if the primary movement is top-down (e.g. Duette Skylift-style)."""
        return self.shade_type == SHADE_TYPE_TOP_BAR_DOWN

    @property
    def is_dual_action(self) -> bool:
        """Return True if the shade has independently operable top and bottom rails."""
        return self.shade_type == SHADE_TYPE_DUAL_SLIDERS

    @property
    def raw_data(self) -> dict[str, Any]:
        """Return raw data dict for API compatibility."""
        return {
            "id": self.id,
            "name": self.name,
            "brandIndex": self.brand_index,
            "brandName": self.brand_name,
            "shadeType": self.shade_type,
            "supportsTilt": self.supports_tilt,
            "supportsTiltReverse": self.supports_tilt_reverse,
            "supportsSecondaryPosition": self.supports_secondary_position,
        }


@dataclass
class Shade:
    """Represents an individual shade.

    Position state is stored as two independent wire values:
    - ``position``      – main shade position (feature 04), wire 0-255.
    - ``tilt_position`` – vane tilt position  (feature 07/19), wire 0-255.

    They are set independently when ``$cp`` responses arrive so that a
    tilt update never overwrites the shade's primary position, and vice
    versa.  The parser zeros ``position`` when a tilt update arrives
    (hardware closes the shade first) and zeros ``tilt_position`` when a
    primary-move update arrives.  ``supports_tilt`` and
    ``supports_tilt_reverse`` are stamped onto the shade from its room's
    brand_index after the full data parse.

    For Luminette (``supports_tilt_reverse=True``) the logical 0-100%
    tilt range is split across two wire commands:
      * 0-50%   → cmd 07 (forward), wire 0-255
      * 50-100% → cmd 19 (reverse), wire 0-255
    ``tilt_command`` records which command was last received so that
    ``tilt_percent`` can reconstruct the correct logical value.
    """

    id: int = 0
    name: str = ""
    room_id: int = 0
    group_number: int = 0
    position: int = 0  # Wire position 0-255 for feature 04 (main shade)
    tilt_position: int = 0  # Wire position 0-255 for feature 07/19 (vane/slat tilt)
    tilt_command: int = 7  # Last tilt command received: 7=forward, 19=reverse
    supports_tilt: bool = False  # Set from room brand_index after parsing
    supports_tilt_reverse: bool = False  # Set from room brand_index after parsing

    # ------------------------------------------------------------------
    # Primary (shade) position helpers
    # ------------------------------------------------------------------

    @property
    def position_percent(self) -> int:
        """Return primary shade position as a percentage (0=closed, 100=open)."""
        return ShadePosition.from_wire(self.position)

    @position_percent.setter
    def position_percent(self, value: int) -> None:
        """Set primary position from a percentage (0-100)."""
        self.position = ShadePosition.to_wire(value)

    # ------------------------------------------------------------------
    # Tilt position helpers
    # ------------------------------------------------------------------

    @property
    def tilt_percent(self) -> int:
        """Return tilt as a logical percentage (0-100).

        For standard tilt shades (Pirouette, Silhouette):
          wire 0 → 0%, wire 255 → 100%  (cmd 07 only)

        For bidirectional tilt shades (Luminette):
          The logical range is split into two halves:
            cmd 19 (reverse):  wire 0-255 maps to logical  0-50%
              (wire 0 = closed = 0%, wire 255 = open = 50%)
            cmd 07 (forward):  wire 0-255 maps to logical 50-100%
              (wire 255 = open = 50%, wire 0 = closed = 100%)
        """
        if self.supports_tilt_reverse:
            if self.tilt_command == 7:
                # Forward half: wire 255→50%, wire 0→100%
                return 50 + round((255 - self.tilt_position) * 50 / 255)
            else:
                # Reverse half: wire 0→0%, wire 255→50%
                return round(self.tilt_position * 50 / 255)
        return ShadePosition.from_wire(self.tilt_position)

    @tilt_percent.setter
    def tilt_percent(self, value: int) -> None:
        """Set tilt from a logical percentage (0-100).

        For bidirectional shades this also updates ``tilt_command``
        to reflect which half of the range is being used.
        """
        clamped = max(0, min(100, value))
        if self.supports_tilt_reverse:
            if clamped <= 50:
                self.tilt_command = 19
                self.tilt_position = round(clamped * 255 / 50)
            else:
                self.tilt_command = 7
                self.tilt_position = round((100 - clamped) * 255 / 50)
        else:
            self.tilt_position = ShadePosition.to_wire(clamped)

    # ------------------------------------------------------------------
    # Command side-effect helpers
    # ------------------------------------------------------------------

    def apply_move(self, position_percent: int) -> None:
        """Update state as if a primary-move command was sent.

        Moving the main shade to any position releases the tilt (the vanes
        return to flat when the shade raises or lowers).
        """
        self.position_percent = position_percent
        self.tilt_position = 0

    def apply_tilt(self, tilt_percent: int) -> None:
        """Update state as if a tilt command was sent.

        Tilt is only physically possible when the shade is closed, so the
        hardware drives position to 0 before rotating the vanes.
        """
        self.position = 0
        self.tilt_percent = tilt_percent

    # ------------------------------------------------------------------
    # Combined position view
    # ------------------------------------------------------------------

    @property
    def current_position(self) -> ShadePosition:
        """Return a :class:`ShadePosition` snapshot of the shade's current state.

        * ``primary`` – main shade position percentage (0=closed, 100=open).
        * ``tilt``    – tilt percentage, or ``None`` when the shade does not
                        support tilt.  For tilt-capable shades ``tilt`` is
                        always an integer: ``0`` when flat/unknown, up to
                        ``100`` when fully open/rotated.

        The parser already ensures that a tilt update zeroes ``position``
        and a primary-move update zeroes ``tilt_position``, so the two
        fields are always mutually exclusive in practice.

        Compatible with the aio-powerview-api ``ShadePosition`` interface.
        """
        tilt: int | None = self.tilt_percent if self.supports_tilt else None
        primary = self.position_percent
        return ShadePosition(primary=primary, tilt=tilt)

    # ------------------------------------------------------------------
    # Convenience state checks
    # ------------------------------------------------------------------

    @property
    def is_open(self) -> bool:
        """Return True if the shade is fully open (primary position 100%)."""
        return self.position_percent >= MAX_POSITION

    @property
    def is_closed(self) -> bool:
        """Return True if the shade is fully closed (primary position 0%).

        A shade with an active tilt is always considered closed because
        tilt is only physically possible in the closed position.
        """
        return self.position_percent <= MIN_POSITION or self.tilt_position > 0

    @property
    def raw_data(self) -> dict[str, Any]:
        """Return raw data dict for API compatibility."""
        pos = self.current_position
        return {
            "id": self.id,
            "name": self.name,
            "roomId": self.room_id,
            "groupNumber": self.group_number,
            "position": self.position,
            "tiltPosition": self.tilt_position,
            "positionPercent": pos.primary,
            "tiltPercent": pos.tilt,
        }


@dataclass
class SceneLink:
    """Links a shade to a scene."""

    shade_id: int = 0
    is_linked: bool = False


@dataclass
class SceneRoomPosition:
    """Position of a room within a scene."""

    room_id: int = 0
    scene_index: int = 0
    command: str = ""
    position: int = 0


@dataclass
class Scene:
    """Represents a scene."""

    id: int = 0
    name: str = ""
    links: list[SceneLink] = field(default_factory=list)
    room_positions: list[SceneRoomPosition] = field(default_factory=list)

    @property
    def raw_data(self) -> dict[str, Any]:
        """Return raw data dict for API compatibility."""
        return {
            "id": self.id,
            "name": self.name,
        }


@dataclass
class TimedEvent:
    """Represents a scheduled/timed event."""

    scene_index: int = 0
    hour: int = 0
    minute: int = 0
    day_bits: int = 0
    enabled: bool = False


@dataclass
class House:
    """Represents all data from the hub.

    This is the top-level container returned by get_data().
    """

    name: str = ""
    bridge: Bridge = field(default_factory=Bridge)
    rooms: dict[int, Room] = field(default_factory=dict)
    shades: dict[int, Shade] = field(default_factory=dict)
    scenes: dict[int, Scene] = field(default_factory=dict)
    timed_events: list[TimedEvent] = field(default_factory=list)
