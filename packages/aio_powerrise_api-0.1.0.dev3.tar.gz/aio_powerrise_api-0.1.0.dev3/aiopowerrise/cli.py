"""Command-line interface for Hunter Douglas PowerRise Platinum.

Provides a simple CLI for testing and debugging hub communication.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import logging
import sys
from typing import Any


def main() -> None:
    """Main entry point for the CLI."""
    # Global parser with options. We'll use a two-pass parse so these
    # options are recognized whether they appear before or after the
    # subcommand. Keep as a parent for help text on the main parser.
    global_parser = argparse.ArgumentParser(add_help=False)
    global_parser.add_argument(
        "--host",
        help="Hub IP address or hostname",
    )
    global_parser.add_argument(
        "--port",
        type=int,
        default=522,
        help="Hub port (default: 522)",
    )
    global_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )

    # Main parser includes the global parser only for help display. We
    # will parse global args separately so their position is flexible.
    parser = argparse.ArgumentParser(
        prog="powerrise-cli",
        description="Hunter Douglas PowerRise Platinum CLI",
        parents=[global_parser],
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # discover
    discover_parser = subparsers.add_parser("discover", help="Discover hubs on network")
    discover_parser.add_argument(
        "--timeout",
        type=float,
        default=1.0,
        help="Discovery timeout in seconds (default: 1.0)",
    )

    # get-data
    subparsers.add_parser("get-data", help="Get all data from hub")

    # shades
    subparsers.add_parser("shades", help="List all shades")

    # rooms
    subparsers.add_parser("rooms", help="List all rooms")

    # scenes
    subparsers.add_parser("scenes", help="List all scenes")

    # move-shade
    move_parser = subparsers.add_parser("move-shade", help="Move a shade")
    move_parser.add_argument("--id", type=int, required=True, help="Shade ID")
    move_parser.add_argument(
        "--position", type=int, required=True, help="Target position (0-100)"
    )

    # open-shade
    open_parser = subparsers.add_parser("open-shade", help="Open a shade")
    open_parser.add_argument("--id", type=int, required=True, help="Shade ID")

    # close-shade
    close_parser = subparsers.add_parser("close-shade", help="Close a shade")
    close_parser.add_argument("--id", type=int, required=True, help="Shade ID")

    # stop-shade
    stop_parser = subparsers.add_parser("stop-shade", help="Stop a shade")
    stop_parser.add_argument("--id", type=int, required=True, help="Shade ID")

    # tilt-shade
    tilt_parser = subparsers.add_parser("tilt-shade", help="Tilt a shade")
    tilt_parser.add_argument("--id", type=int, required=True, help="Shade ID")
    tilt_parser.add_argument(
        "--position", type=int, required=True, help="Tilt position (0-100)"
    )

    # activate-scene
    scene_parser = subparsers.add_parser("activate-scene", help="Activate a scene")
    scene_parser.add_argument("--id", type=int, required=True, help="Scene ID")

    # ping
    subparsers.add_parser("ping", help="Ping the hub")

    # raw
    raw_parser = subparsers.add_parser("raw", help="Send a raw command")
    raw_parser.add_argument("raw_command", help="Raw command string (e.g. '$dat')")
    raw_parser.add_argument(
        "--sentinel", default=None, help="Response sentinel to wait for"
    )

    # listen
    listen_parser = subparsers.add_parser(
        "listen",
        help="Stay connected and print live updates pushed by the hub",
    )
    listen_parser.add_argument(
        "--timeout",
        type=float,
        default=0.0,
        help="Stop after N seconds (0 = run forever until Ctrl-C)",
    )
    listen_parser.add_argument(
        "--json",
        action="store_true",
        dest="output_json",
        help="Emit updates as JSON lines",
    )

    # Two-pass parse: first parse global args (from the full argv) so they
    # are recognized whether they appear before or after the subcommand.
    # Then parse the full arguments to get subcommand-specific values and
    # merge the global values into the final namespace.
    import sys as _sys

    # Parse global args from sys.argv (but don't exit on -h here).
    global_ns, _ = global_parser.parse_known_args(_sys.argv[1:])

    # Now parse the full set (this will handle subcommands and their args).
    args = parser.parse_args()

    # If the global parser picked up values (e.g. when provided before the
    # subcommand), copy them into args when absent.
    for name in ('host', 'port', 'debug'):
        if getattr(args, name, None) is None:
            setattr(args, name, getattr(global_ns, name, None))

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Set up logging
    level = logging.DEBUG if args.debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    try:
        asyncio.run(_run(args))
    except KeyboardInterrupt:
        pass  # Ctrl-C during listen — already handled inside _cmd_listen


async def _run(args: argparse.Namespace) -> None:
    """Run the CLI command."""
    if args.command == "discover":
        await _cmd_discover(args)
        return

    if not args.host:
        print("Error: --host is required for this command", file=sys.stderr)
        sys.exit(1)

    from aiopowerrise.hub import Hub

    hub = Hub(args.host, args.port)

    try:
        await hub.connect()

        if args.command == "get-data":
            await _cmd_get_data(hub)
        elif args.command == "shades":
            await _cmd_shades(hub)
        elif args.command == "rooms":
            await _cmd_rooms(hub)
        elif args.command == "scenes":
            await _cmd_scenes(hub)
        elif args.command == "move-shade":
            await _cmd_move_shade(hub, args.id, args.position)
        elif args.command == "open-shade":
            await _cmd_open_shade(hub, args.id)
        elif args.command == "close-shade":
            await _cmd_close_shade(hub, args.id)
        elif args.command == "stop-shade":
            await _cmd_stop_shade(hub, args.id)
        elif args.command == "tilt-shade":
            await _cmd_tilt_shade(hub, args.id, args.position)
        elif args.command == "activate-scene":
            await _cmd_activate_scene(hub, args.id)
        elif args.command == "ping":
            await _cmd_ping(hub)
        elif args.command == "raw":
            await _cmd_raw(hub, args.raw_command, args.sentinel)
        elif args.command == "listen":
            await _cmd_listen(hub, args.timeout, getattr(args, "output_json", False))
        else:
            print(f"Unknown command: {args.command}", file=sys.stderr)
            sys.exit(1)
    except KeyboardInterrupt:
        pass  # clean Ctrl-C exit from listen
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        await hub.close()


async def _cmd_discover(args: argparse.Namespace) -> None:
    """Discover hubs."""
    from aiopowerrise.discovery import discover_hubs

    print("Searching for PowerRise Platinum hubs...")
    hubs = await discover_hubs(timeout=args.timeout)
    if hubs:
        print(f"Found {len(hubs)} hub(s):")
        for ip in hubs:
            print(f"  {ip}")
    else:
        print("No hubs found.")


async def _cmd_get_data(hub: Any) -> None:
    """Get and display all data."""
    house = await hub.get_data()
    print(f"House: {house.name}")
    print(f"Bridge firmware: {house.bridge.firmware_version}")
    print(f"Bridge MAC: {house.bridge.mac_address or 'unknown'}")
    print(f"LED brightness: {house.bridge.led_brightness_bits}")
    print(f"Rooms: {len(house.rooms)}")
    print(f"Shades: {len(house.shades)}")
    print(f"Scenes: {len(house.scenes)}")
    print()

    if house.rooms:
        print("=== Rooms ===")
        for room_id, room in sorted(house.rooms.items()):
            print(f"  [{room_id:02d}] {room.name} (brand={room.brand_index})")

    if house.shades:
        print("\n=== Shades ===")
        for shade_id, shade in sorted(house.shades.items()):
            pos = shade.current_position
            tilt_str = f" tilt={pos.tilt}%" if pos.tilt is not None else ""
            print(
                f"  [{shade_id:02d}] {shade.name} "
                f"room={shade.room_id} pos={pos.primary}%{tilt_str} "
                f"(wire={shade.position} tilt_wire={shade.tilt_position})"
            )

    if house.scenes:
        print("\n=== Scenes ===")
        for scene_id, scene in sorted(house.scenes.items()):
            links_str = ", ".join(
                f"shade {lnk.shade_id}" for lnk in scene.links if lnk.is_linked
            )
            print(f"  [{scene_id:02d}] {scene.name} links=[{links_str}]")

    if house.timed_events:
        print("\n=== Timed Events ===")
        for event in house.timed_events:
            enabled = "ON" if event.enabled else "OFF"
            print(
                f"  Scene {event.scene_index} at {event.hour:02d}:{event.minute:02d} "
                f"days=0b{event.day_bits:07b} [{enabled}]"
            )


async def _cmd_shades(hub: Any) -> None:
    """List shades."""
    house = hub.house or await hub.get_data()
    if not house.shades:
        print("No shades found.")
        return
    for shade_id, shade in sorted(house.shades.items()):
        pos = shade.position_percent
        state = "open" if shade.is_open else ("closed" if shade.is_closed else "partial")
        print(f"[{shade_id:02d}] {shade.name:20s} pos={pos:3d}% ({state}) room={shade.room_id}")


async def _cmd_rooms(hub: Any) -> None:
    """List rooms."""
    house = hub.house or await hub.get_data()
    if not house.rooms:
        print("No rooms found.")
        return
    for room_id, room in sorted(house.rooms.items()):
        shade_count = len(room.shades)
        print(f"[{room_id:02d}] {room.name:20s} brand={room.brand_index} shades={shade_count}")


async def _cmd_scenes(hub: Any) -> None:
    """List scenes."""
    house = hub.house or await hub.get_data()
    if not house.scenes:
        print("No scenes found.")
        return
    for scene_id, scene in sorted(house.scenes.items()):
        print(f"[{scene_id:02d}] {scene.name}")


async def _cmd_move_shade(hub: Any, shade_id: int, position: int) -> None:
    """Move a shade."""
    await hub.shades.move(shade_id, position)
    print(f"Shade {shade_id} moved to {position}%")


async def _cmd_open_shade(hub: Any, shade_id: int) -> None:
    """Open a shade."""
    await hub.shades.open(shade_id)
    print(f"Shade {shade_id} opened")


async def _cmd_close_shade(hub: Any, shade_id: int) -> None:
    """Close a shade."""
    await hub.shades.close(shade_id)
    print(f"Shade {shade_id} closed")


async def _cmd_stop_shade(hub: Any, shade_id: int) -> None:
    """Stop a shade."""
    await hub.shades.stop(shade_id)
    print(f"Shade {shade_id} stopped")


async def _cmd_tilt_shade(hub: Any, shade_id: int, position: int) -> None:
    """Tilt a shade."""
    await hub.shades.tilt(shade_id, position)
    print(f"Shade {shade_id} tilted to {position}%")


async def _cmd_activate_scene(hub: Any, scene_id: int) -> None:
    """Activate a scene."""
    await hub.scenes.activate(scene_id)
    print(f"Scene {scene_id} activated")


async def _cmd_ping(hub: Any) -> None:
    """Ping the hub."""
    result = await hub.ping()
    print(f"Ping: {'OK' if result else 'FAILED'}")


async def _cmd_raw(hub: Any, command: str, sentinel: str | None) -> None:
    """Send a raw command."""
    lines = await hub._transport.send_command(command, sentinel=sentinel, timeout=10.0)
    for line in lines:
        print(line)


async def _cmd_listen(hub: Any, timeout: float, output_json: bool) -> None:
    """Stay connected and print live updates from the hub."""
    import asyncio
    import datetime

    # State was already fetched by hub.connect(); use the cached house.
    print("Fetching initial state…", flush=True)
    house = hub.house or await hub.get_data()
    print(
        f"Connected. Listening for updates "
        f"({'forever' if not timeout else f'{timeout}s'}). "
        f"Press Ctrl-C to stop.\n",
        flush=True,
    )

    def _on_update(event_type: str, data: Any) -> None:
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        if output_json:
            import json as _json
            payload: dict[str, Any] = {"time": ts, "event": event_type}
            if hasattr(data, "raw_data"):
                payload["data"] = data.raw_data
            else:
                payload["data"] = str(data)
            print(_json.dumps(payload), flush=True)
        else:
            if event_type == "shade":
                tilt_str = (
                    f" tilt={data.tilt_percent:3d}% (tilt_wire={data.tilt_position})"
                    if data.supports_tilt
                    else ""
                )
                print(
                    f"[{ts}] shade update  [{data.id:02d}] {data.name:20s} "
                    f"pos={data.position_percent:3d}% (wire={data.position}){tilt_str}",
                    flush=True,
                )
            elif event_type == "room":
                print(f"[{ts}] room update   [{data.id:02d}] {data.name}", flush=True)
            else:
                print(f"[{ts}] {event_type:12s} {data}", flush=True)

    remove = hub.add_listener(_on_update)
    hub.start_listening()

    try:
        if timeout:
            await asyncio.sleep(timeout)
        else:
            # Wait until SIGINT (Ctrl-C) fires — install a signal handler that
            # sets a simple asyncio.Event so the coroutine wakes cleanly.
            import signal

            loop = asyncio.get_running_loop()
            stop_event = asyncio.Event()

            def _handle_sigint(*_: object) -> None:
                loop.call_soon_threadsafe(stop_event.set)

            try:
                loop.add_signal_handler(signal.SIGINT, _handle_sigint)
                await stop_event.wait()
            except NotImplementedError:
                # Windows: loop.add_signal_handler not supported
                try:
                    while not stop_event.is_set():
                        await asyncio.sleep(0.5)
                except asyncio.CancelledError:
                    pass
            finally:
                with contextlib.suppress(Exception):
                    loop.remove_signal_handler(signal.SIGINT)
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    finally:
        remove()
        hub.stop_listening()
        print("\nListener stopped.", flush=True)


if __name__ == "__main__":
    main()
