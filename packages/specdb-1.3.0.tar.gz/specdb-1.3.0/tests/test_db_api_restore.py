"""按主题拆分后的 DB API 恢复能力测试。"""

import db_api_test_base as support
from db_api_test_base import *


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()

class DBApiRestoreTestCase(DBApiTestBase):
    def test_ops_change_logs_list(self):
        table_name = self._table_name("loglist")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "a"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "b"}, "query": {"name": "a"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=10&offset=0")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertIn("items", body["data"])
        self.assertGreaterEqual(len(body["data"]["items"]), 2)
        self.assertIn("T", body["data"]["items"][0]["changed_at"])

        self._drop_table(table_name)

    def test_ops_restore_from_update_log(self):
        table_name = self._table_name("restore")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(len(body["data"]["items"]), 1)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id]},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["restored_logs"], 1)

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "v1"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)

        self._drop_table(table_name)

    def test_ops_restore_returns_relationship_risk_summary(self):
        table_name = self._table_name("restore_rel")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "author_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            },
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"author_id": 1, "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["relationship_risks"]["depends_on_tables"], ["users"])
        self.assertEqual(body["data"]["relationship_risks"]["referenced_by_tables"], [])
        self.assertTrue(
            any(
                "depends on related tables: users" in item
                for item in body["data"]["relationship_risks"]["warnings"]
            )
        )

    def test_ops_restore_from_logs_rejects_table_without_primary_key(self):
        table_name = self._table_name("restore_no_pk")
        with app.app_context():
            db.session.execute(db.text(f"CREATE TABLE {table_name} (name VARCHAR(255) NOT NULL)"))
            db.session.commit()
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [1]},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_restore_from_update_log_with_primary_key_change(self):
        table_name = self._table_name("restore_pk")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"id": 1, "name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"id": 2, "name": "v2"}, "query": {"id": 1}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id]},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["restored_logs"], 1)

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(body["data"]["items"], [{"id": 1, "name": "v1"}])

        self._drop_table(table_name)

    def test_ops_restore_dry_run_keeps_data_unchanged(self):
        table_name = self._table_name("restore_dry")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["dry_run"])
        self.assertEqual(body["data"]["restored_logs"], 1)

        # 这是 dry run，数据应仍保持为 v2。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "v2"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self._drop_table(table_name)

    def test_ops_restore_by_batch_id(self):
        table_name = self._table_name("restore_batch")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 7,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        batch_id = body["data"]["items"][0]["batch_id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "batch_id": batch_id},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["restored_logs"], 1)

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "v1"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self._drop_table(table_name)

    def test_ops_restore_without_preview_details_omits_preview_fields(self):
        table_name = self._table_name("restore_no_preview")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertNotIn("preview", body["data"])
        self.assertNotIn("preview_truncated", body["data"])
        self.assertNotIn("preview_limit", body["data"])

    def test_ops_restore_respects_max_restore_rows(self):
        table_name = self._table_name("restore_limit")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        for value in ("v1", "v2"):
            self._post(
                "/api/db/data",
                {
                    "spec": {
                        "action": "data.insert",
                        "table": table_name,
                        "payload": {"data": {"name": value}},
                        "options": {},
                    }
                },
            )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=insert&limit=10")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_ids = [item["id"] for item in body["data"]["items"]]
        self.assertGreaterEqual(len(log_ids), 2)

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": log_ids[:2], "max_restore_rows": 1},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")
        self.assertEqual(body["error"]["details"]["selected_logs"], 2)
        self.assertEqual(body["error"]["details"]["max_restore_rows"], 1)
        self._drop_table(table_name)

    def test_ops_change_logs_table_missing_uses_ops_error_code(self):
        resp = self.client.get("/api/db/ops/change-logs")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_change_logs_rejects_invalid_table_name(self):
        resp = self.client.get("/api/db/ops/change-logs?table=bad-table!")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_restore_by_time_window_with_preview(self):
        table_name = self._table_name("restore_time")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        changed_at = body["data"]["items"][0]["changed_at"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {
                "table": table_name,
                "from_changed_at": changed_at,
                "to_changed_at": changed_at,
                "dry_run": True,
                "preview_details": True,
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["dry_run"])
        self.assertIsInstance(body["data"]["preview"], list)
        self.assertGreaterEqual(len(body["data"]["preview"]), 1)
        self.assertIn("row_key", body["data"]["preview"][0])
        self._drop_table(table_name)

    def test_ops_restore_preview_is_truncated_when_response_limit_is_hit(self):
        table_name = self._table_name("restore_preview_limit")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v3"}, "query": {"name": "v2"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=10")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_ids = [item["id"] for item in body["data"]["items"]]
        self.assertGreaterEqual(len(log_ids), 3)

        with patch.object(ops_db_routes_module, "_MAX_RESTORE_PREVIEW_ITEMS", 1):
            resp, body = self._post(
                "/api/db/ops/restore-from-logs",
                {
                    "table": table_name,
                    "log_ids": log_ids[:3],
                    "dry_run": True,
                    "preview_details": True,
                    "max_restore_rows": 10,
                },
            )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(len(body["data"]["preview"]), 1)
        self.assertTrue(body["data"]["preview_truncated"])
        self.assertEqual(body["data"]["preview_limit"], 1)
        self._drop_table(table_name)

    def test_ops_restore_rejects_invalid_time_window_order(self):
        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {
                "table": "users",
                "from_changed_at": "2026-03-08T00:00:00+00:00",
                "to_changed_at": "2026-03-07T00:00:00+00:00",
                "dry_run": True,
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_restore_missing_table_uses_not_found(self):
        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": "missing_restore_table", "log_ids": [1]},
        )
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_ops_restore_runtime_table_load_failure_uses_query_failed(self):
        table_name = self._table_name("restore_load_fail")
        self._define_table(table_name)
        try:
            with patch("specdb.ops.restore_routes._load_runtime_table", side_effect=RuntimeError("reflect boom")):
                resp, body = self._post(
                    "/api/db/ops/restore-from-logs",
                    {"table": table_name, "log_ids": [1]},
                )
            self.assertEqual(resp.status_code, 500)
            self.assertFalse(body["success"])
            self.assertEqual(body["error"]["code"], "DB_OPS_QUERY_FAILED")
        finally:
            self._drop_table(table_name)

    def test_ops_restore_without_change_log_table_uses_not_found(self):
        table_name = self._table_name("restore_no_logs")
        self._define_table(table_name)
        try:
            with app.app_context():
                db.session.execute(db.text("DROP TABLE IF EXISTS db_change_log"))
                db.session.commit()
            resp, body = self._post(
                "/api/db/ops/restore-from-logs",
                {"table": table_name, "log_ids": [1]},
            )
            self.assertEqual(resp.status_code, 404)
            self.assertFalse(body["success"])
            self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")
        finally:
            with app.app_context():
                db_executor_module._INTERNAL_METADATA.create_all(
                    bind=db.engine,
                    tables=[db_executor_module._TABLE_OPTIONS, db_executor_module._CHANGE_LOG],
                    checkfirst=True,
                )
            self._drop_table(table_name)

    def test_ops_restore_rejects_invalid_table_name_and_selector_size(self):
        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": "bad-table!", "log_ids": [1], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": "users", "log_ids": list(range(1, 1002)), "dry_run": True},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": "users", "batch_id": "bad batch id", "dry_run": True},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_restore_writes_audit_log(self):
        table_name = self._table_name("restore_audit")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True, "operator": "ops_admin", "node": "api-01"},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["audit_context"]["scope_key"], "db")
        self.assertEqual(body["data"]["audit_context"]["operator"], "ops_admin")
        self.assertEqual(body["data"]["audit_context"]["node"], "api-01")

        with app.app_context():
            rows = (
                db.session.execute(
                    db.text(
                        "SELECT table_name, selector_json, restored_logs, requested_logs, dry_run, operator, node, "
                        "scope_key, context_json, result_json "
                        "FROM db_ops_restore_audit WHERE table_name = :table_name ORDER BY id DESC LIMIT 1"
                    ),
                    {"table_name": table_name},
                )
                .mappings()
                .all()
            )
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["table_name"], table_name)
        self.assertEqual(row["restored_logs"], 1)
        self.assertEqual(row["requested_logs"], 1)
        self.assertEqual(row["dry_run"], 1)
        self.assertEqual(row["operator"], "ops_admin")
        self.assertEqual(row["node"], "api-01")
        self.assertEqual(row["scope_key"], "db")
        selector = json.loads(row["selector_json"])
        self.assertEqual(selector["type"], "log_ids")
        self.assertEqual(selector["log_ids"], [log_id])
        context = json.loads(row["context_json"])
        self.assertEqual(context["scope_key"], "db")
        self.assertEqual(context["operator"], "ops_admin")
        self.assertEqual(context["node"], "api-01")
        self.assertTrue(context["dry_run"])
        result = json.loads(row["result_json"])
        self.assertEqual(result["table"], table_name)
        self.assertEqual(result["restored_logs"], 1)
        self.assertEqual(result["requested_logs"], 1)
        self._drop_table(table_name)

    def test_ops_restore_audit_write_failure_rolls_back_non_dry_run_restore(self):
        table_name = self._table_name("restore_audit_fail")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        with patch("specdb.ops.restore_routes.insert_restore_audit", side_effect=RuntimeError("audit boom")):
            resp, body = self._post(
                "/api/db/ops/restore-from-logs",
                {"table": table_name, "log_ids": [log_id], "dry_run": False},
            )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_RESTORE_FAILED")

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"][0]["name"], "v2")
        self._drop_table(table_name)

    def test_ops_restore_audits_query_endpoint(self):
        table_name = self._table_name("restore_audits_q")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        log_id = resp.get_json()["data"]["items"][0]["id"]
        self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True, "operator": "ops_q", "node": "api-01"},
        )

        resp = self.client.get(f"/api/db/ops/restore-audits?table={table_name}&operator=ops_q&limit=10&offset=0")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertGreaterEqual(len(body["data"]["items"]), 1)
        item = body["data"]["items"][0]
        self.assertEqual(item["table_name"], table_name)
        self.assertEqual(item["operator"], "ops_q")
        self.assertEqual(item["dry_run"], 1)
        self.assertIn("selector", item)
        self.assertEqual(item["context"]["scope_key"], "db")
        self.assertEqual(item["context"]["operator"], "ops_q")
        self.assertEqual(item["context"]["node"], "api-01")
        self.assertTrue(item["context"]["dry_run"])
        self.assertEqual(item["result"]["table"], table_name)
        self.assertEqual(item["result"]["restored_logs"], 1)
        self.assertEqual(item["result"]["requested_logs"], 1)
        self.assertTrue(str(item["created_at"]).endswith("+00:00"))
        self._drop_table(table_name)

    def test_ops_restore_audits_query_rejects_corrupted_context_json(self):
        table_name = self._table_name("restore_audits_corrupt")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        log_id = resp.get_json()["data"]["items"][0]["id"]
        self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )

        with app.app_context():
            db.session.execute(
                db.text("UPDATE db_ops_restore_audit SET context_json = :context_json WHERE table_name = :table_name"),
                {"context_json": "{bad-json", "table_name": table_name},
            )
            db.session.commit()

        resp = self.client.get(f"/api/db/ops/restore-audits?table={table_name}&limit=10&offset=0")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_QUERY_FAILED")

    def test_ops_restore_audits_cleanup(self):
        table_name = self._table_name("restore_audits_clean")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        log_id = resp.get_json()["data"]["items"][0]["id"]
        self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )

        with app.app_context():
            db.session.execute(
                db.text("UPDATE db_ops_restore_audit SET created_at = :old WHERE table_name = :table_name"),
                {"old": "2000-01-01 00:00:00", "table_name": table_name},
            )
            db.session.commit()

        resp, body = self._post("/api/db/ops/restore-audits/cleanup", {"dry_run": True, "retention_days": 1})
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertGreaterEqual(body["data"]["affected_rows"], 1)

        resp, body = self._post("/api/db/ops/restore-audits/cleanup", {"dry_run": False, "retention_days": 1})
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertGreaterEqual(body["data"]["affected_rows"], 1)

        resp = self.client.get(f"/api/db/ops/restore-audits?table={table_name}&limit=10&offset=0")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(body["data"]["items"]), 0)
        self._drop_table(table_name)

    def test_ops_restore_audits_rejects_invalid_time_window_order(self):
        resp = self.client.get(
            "/api/db/ops/restore-audits?table=users&from_created_at=2026-03-08T00:00:00+00:00&to_created_at=2026-03-07T00:00:00+00:00"
        )
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_restore_audits_rejects_invalid_table_name(self):
        resp = self.client.get("/api/db/ops/restore-audits?table=bad-table!")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_restore_from_logs_after_drop_column_ignores_removed_fields(self):
        table_name = self._table_name("restore_after_drop")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                            "email": {"type": "str", "nullable": True},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1", "email": "v1@example.com"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2", "email": "v2@example.com"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"drop": ["email"]},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id]},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "v1"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn("email", [c["key"] for c in body["data"]["columns"]])

        self._drop_table(table_name)

    def test_restore_from_logs_rejects_corrupted_relationship_metadata(self):
        table_name = self._table_name("restore_rel_corrupt")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "owner_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            },
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        with self.app.app_context():
            db.session.execute(
                db_executor_module._TABLE_OPTIONS.update()
                .where(db_executor_module._TABLE_OPTIONS.c.table_name == table_name)
                .values(relations_json="{bad-json")
            )
            db.session.commit()

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {
                "table": table_name,
                "from_changed_at": "2020-01-01T00:00:00+00:00",
                "to_changed_at": "2030-01-01T00:00:00+00:00",
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_RESTORE_FAILED")
