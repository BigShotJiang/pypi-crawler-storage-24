"""后端 DB API 测试的共享基类与辅助方法。"""

import unittest
import uuid
import sys
import time
import json
import os
import threading
from datetime import date, datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from unittest.mock import patch
from pathlib import Path

from flask import Flask
from sqlalchemy import Column, Date, MetaData, Numeric, Table, inspect as sa_inspect, select
from sqlalchemy.exc import IntegrityError

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from app import create_app
from config import resolve_config
from specdb import db_executor as db_executor_module
from specdb.ops import blueprint as ops_db_routes_module
import specdb.ops.compact_engine as ops_compact_engine_module
import specdb.ops.job_runtime as ops_job_runtime_module
import specdb.ops.job_state as ops_job_state_module
import specdb.ops_archive_store as ops_archive_store_module
from specdb.db_runtime import db
from specdb.db_module import DBModuleOptions, configure_db_module, init_db_module, shutdown_db_module
from specdb.ops_archive_store import get_archive, get_archive_item_count
from specdb.ops.blueprint import create_db_blueprint
from specdb import ops_jobs_store

app: Flask | None = None

class DBApiTestBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        cls._sqlite_path = sqlite_dir / f"test_db_api_{uuid.uuid4().hex}.sqlite3"

        class _TestConfig:
            SQLALCHEMY_DATABASE_URI = f"sqlite:///{cls._sqlite_path.as_posix()}"
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            TESTING = True

        global app
        app = create_app(config_object=_TestConfig)
        cls.app = app
        cls.client = cls.app.test_client()

    @classmethod
    def tearDownClass(cls):
        shutdown_db_module(cls.app, wait=True)
        with cls.app.app_context():
            db.session.remove()
            db.engine.dispose()
        if cls._sqlite_path.exists():
            cls._sqlite_path.unlink()

    def _table_name(self, prefix: str = "mvp_test") -> str:
        return f"{prefix}_{uuid.uuid4().hex[:10]}"

    def _track_app(self, app_obj: Flask) -> Flask:
        app_obj.config["TESTING"] = True

        def _cleanup() -> None:
            try:
                shutdown_db_module(app_obj, wait=True)
            except Exception:
                pass
            try:
                with app_obj.app_context():
                    db.session.remove()
                    db.engine.dispose()
            except Exception:
                pass

        self.addCleanup(_cleanup)
        return app_obj

    def _post(self, path: str, payload: dict):
        resp = self.client.post(path, json=payload)
        return resp, resp.get_json()

    def _wait_for_job_state(self, job_id: str, expected_state: str, timeout_sec: float = 2.0):
        deadline = time.time() + timeout_sec
        last_state = None
        while time.time() < deadline:
            resp = self.client.get(f"/api/db/ops/jobs/{job_id}")
            body = resp.get_json()
            self.assertEqual(resp.status_code, 200)
            self.assertTrue(body["success"])
            last_state = body["data"]["state"]
            if last_state == expected_state:
                return body["data"]
            time.sleep(0.05)
        self.fail(f"job {job_id} did not reach state={expected_state}, last_state={last_state}")

    def _define_table(self, table_name: str):
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "indexes": [
                            {
                                "name": f"idx_{table_name}_name",
                                "keys": ["name"],
                                "unique": False,
                            }
                        ],
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

    def _drop_table(self, table_name: str):
        self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": True},
                    "options": {},
                }
            },
        )

    @staticmethod
    def _ensure_jobs_table_in_app_context(app_obj: Flask) -> None:
        with app_obj.app_context():
            ops_jobs_store.ensure_ops_jobs_table()

    @staticmethod
    def _ensure_internal_tables_in_app_context(app_obj: Flask) -> None:
        with app_obj.app_context():
            db_executor_module.ensure_internal_tables()
