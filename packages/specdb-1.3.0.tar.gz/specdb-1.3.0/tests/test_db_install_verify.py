import db_api_test_base as support
from db_api_test_base import *

from specdb.db_executor import init_database
from specdb.install import install_seed, install_suite, verify_installation


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()


class DBInstallVerifyTestCase(DBApiTestBase):
    def setUp(self):
        super().setUp()
        for table_name in ("users", "rbac_roles"):
            self.addCleanup(lambda name=table_name: self._drop_table(name))

    def test_verify_installation_checks_expected_tables_and_seed(self):
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "super_admin", "role_name": "Super Admin", "status": "active"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            install_suite(client, "admin_basic_suite_v1", include_templates=["user_standard_v2", "rbac_role_v1"])
            install_seed(client, bundle)
            result = verify_installation(
                client,
                expected_tables=["users", "rbac_roles"],
                expected_seed_checks={"rbac_roles": [{"role_key": "super_admin"}]},
            )

        self.assertTrue(result["success"], result)
        self.assertEqual(result["data"]["missing_tables"], [])
        self.assertEqual(result["data"]["missing_seed_checks"], [])

    def test_verify_installation_checks_expected_suite(self):
        with app.app_context():
            client = init_database()
            install_suite(client, "admin_basic_suite_v1", include_templates=["user_standard_v2", "rbac_role_v1"])
            result = verify_installation(client, expected_suite="admin_basic_suite_v1")

        self.assertFalse(result["success"], result)
        self.assertIn("rbac_pages", result["data"]["missing_tables"])

    def test_verify_installation_reports_missing_seed(self):
        with app.app_context():
            client = init_database()
            install_suite(client, "admin_basic_suite_v1", include_templates=["rbac_role_v1"])
            result = verify_installation(
                client,
                expected_tables=["rbac_roles"],
                expected_seed_checks={"rbac_roles": [{"role_key": "super_admin"}]},
            )

        self.assertFalse(result["success"], result)
        self.assertEqual(result["data"]["missing_tables"], [])
        self.assertEqual(result["data"]["missing_seed_checks"][0]["table"], "rbac_roles")


if __name__ == "__main__":
    unittest.main()
