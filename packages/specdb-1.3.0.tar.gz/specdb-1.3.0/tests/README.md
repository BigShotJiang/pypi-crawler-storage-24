# 后端测试目录说明

后端测试按行为领域拆分：

- `db_api_test_base.py`：共享应用夹具、辅助方法和公共导入
- `test_db_api_app.py`：应用工厂、配置、鉴权、blueprint、OpenAPI 覆盖
- `test_db_api_data.py`：CRUD、Schema、备份、历史查询覆盖
- `test_db_api_restore.py`：change log 恢复与恢复审计覆盖
- `test_db_api_ops.py`：compact 任务、重试、幂等、多 scope ops 覆盖
- `test_db_api_postgres.py`：PostgreSQL 集成测试覆盖
- `test_db_templates.py`：模板库函数、模板规则、模板兼容入口覆盖
- `test_admin_basic_suite_example.py`：推荐后台模板组初始化样例回归

新增测试时，优先放到最贴近行为领域的文件中；如果一个特性跨多个领域，优先把公共辅助逻辑放进 `db_api_test_base.py`，具体断言仍放在对应主题文件里。

统一开发与测试入口文档：

- `docs/modules/backend/database/specdb开发与测试手册.md`

目标是让开发者或 Codex 在不阅读核心实现代码的情况下，也能建立足够上下文来补充当前测试目录里的用例。
