import unittest
from unittest.mock import patch

from specdb import (
    build_define_spec as root_build_define_spec,
    get_template as root_get_template,
    get_template_rules as root_get_template_rules,
    get_template_suite as root_get_template_suite,
    get_template_suite_install_plan as root_get_template_suite_install_plan,
    get_template_suite_seed_sets as root_get_template_suite_seed_sets,
    install_schema as root_install_schema,
    install_seed as root_install_seed,
    install_suite as root_install_suite,
    list_templates as root_list_templates,
    list_template_suites as root_list_template_suites,
    reset_dev_database as root_reset_dev_database,
    validate_template_overrides as root_validate_template_overrides,
    validate_template_suite_seed_sets as root_validate_template_suite_seed_sets,
    verify_installation as root_verify_installation,
)
from specdb.db_templates import (
    assert_template_libraries_valid,
    build_define_spec,
    get_template,
    get_template_rules,
    get_template_suite,
    get_template_suite_install_plan,
    get_template_suite_seed_sets,
    list_templates,
    list_template_suites,
    validate_template_overrides,
    validate_template_libraries,
    validate_template_suite_seed_sets,
    validate_template_suite_seed_bundle,
)
from specdb.db_templates import template_registry
from specdb.db_templates.template_library import get_template_suite_seed_sets as shim_get_template_suite_seed_sets


class TemplateLibraryTestCase(unittest.TestCase):
    def test_root_package_exports_template_helpers(self):
        self.assertEqual(root_list_templates()[0]["template_key"], "user_standard_v2")
        self.assertEqual(root_get_template("rbac_page_v1")["table"], "rbac_pages")
        self.assertEqual(root_get_template_rules("content_article_v1")["template_version"], "v1")
        self.assertEqual(root_build_define_spec("site_setting_v1")["table"], "site_settings")
        self.assertEqual(root_list_template_suites()[0]["suite_key"], "admin_basic_suite_v1")
        self.assertEqual(root_get_template_suite("admin_basic_suite_v1")["version"], "v1")
        self.assertEqual(root_get_template_suite_install_plan("admin_basic_suite_v1")["suite_key"], "admin_basic_suite_v1")
        self.assertIn("roles", root_get_template_suite_seed_sets("admin_basic_suite_v1"))
        self.assertEqual(root_validate_template_suite_seed_sets("admin_basic_suite_v1", {})["errors"], [])
        self.assertEqual(root_validate_template_overrides("user_standard_v2", {"schema": {"bio": {"length": 240}}}), [])
        self.assertTrue(callable(root_install_schema))
        self.assertTrue(callable(root_install_suite))
        self.assertTrue(callable(root_install_seed))
        self.assertTrue(callable(root_reset_dev_database))
        self.assertTrue(callable(root_verify_installation))

    def test_validate_template_libraries_returns_no_errors(self):
        self.assertEqual(validate_template_libraries(), [])
        self.assertIsNone(assert_template_libraries_valid())

    def test_list_templates_returns_recommended_template_first(self):
        templates = list_templates()

        self.assertGreaterEqual(len(templates), 10)
        self.assertEqual(templates[0]["template_key"], "user_standard_v2")
        self.assertTrue(templates[0]["recommended"])
        self.assertEqual(templates[0]["stability"], "stable")
        self.assertEqual(templates[0]["category"], "identity")
        self.assertIn("mfa", templates[0]["scenarios"])

        legacy = next(item for item in templates if item["template_key"] == "user_standard_v1")
        self.assertFalse(legacy["recommended"])
        self.assertFalse(legacy["has_rules"])
        self.assertEqual(legacy["stability"], "legacy")

        rbac_page = next(item for item in templates if item["template_key"] == "rbac_page_v1")
        self.assertEqual(rbac_page["category"], "access-control")
        self.assertTrue(rbac_page["has_rules"])

        article = next(item for item in templates if item["template_key"] == "content_article_v1")
        self.assertEqual(article["category"], "content")
        self.assertIn("article", article["scenarios"])

        site_setting = next(item for item in templates if item["template_key"] == "site_setting_v1")
        self.assertEqual(site_setting["category"], "site-support")
        self.assertTrue(site_setting["has_rules"])

    def test_get_template_returns_deep_copy_with_metadata(self):
        template = get_template("user_standard_v2")
        self.assertIsNotNone(template)
        self.assertEqual(template["stability"], "stable")
        self.assertIn("password_hash", template["sensitive_fields"])

        template["payload"]["schema"]["username"]["length"] = 999
        template_again = get_template("user_standard_v2")
        self.assertEqual(template_again["payload"]["schema"]["username"]["length"], 50)

    def test_get_template_rules_exposes_template_and_rule_versions(self):
        rules = get_template_rules("user_standard_v2")

        self.assertIsNotNone(rules)
        self.assertEqual(rules["version"], "v1")
        self.assertEqual(rules["template_version"], "v2")
        self.assertIn("password", rules["virtual_properties"])
        self.assertIn("password", rules["create"]["required"])

    def test_build_define_spec_returns_payload_copy(self):
        spec = build_define_spec("user_standard_v2")
        self.assertIsNotNone(spec)
        self.assertEqual(spec["action"], "table.define")
        self.assertEqual(spec["table"], "users")

        spec["payload"]["schema"]["email"]["length"] = 999
        spec_again = build_define_spec("user_standard_v2")
        self.assertEqual(spec_again["payload"]["schema"]["email"]["length"], 120)

    def test_build_define_spec_accepts_safe_template_overrides(self):
        spec = build_define_spec("user_standard_v2", overrides={"schema": {"bio": {"length": 240}}})

        self.assertIsNotNone(spec)
        self.assertEqual(spec["payload"]["schema"]["bio"]["length"], 240)
        self.assertEqual(get_template("user_standard_v2")["payload"]["schema"]["bio"]["length"], 500)

    def test_rbac_page_access_template_contains_page_level_capabilities(self):
        template = get_template("rbac_role_page_access_v1")

        self.assertIsNotNone(template)
        schema = template["payload"]["schema"]
        self.assertIn("can_view", schema)
        self.assertIn("can_create", schema)
        self.assertIn("can_update", schema)
        self.assertIn("can_delete", schema)

        index_names = {item["name"] for item in template["payload"]["indexes"]}
        self.assertIn("uk_rbac_role_page_access_role_page", index_names)
        self.assertEqual(schema["role_id"]["relation"]["target_table"], "rbac_roles")
        self.assertEqual(schema["page_id"]["relation"]["target_table"], "rbac_pages")

    def test_content_article_rules_match_expected_editorial_contract(self):
        rules = get_template_rules("content_article_v1")

        self.assertIsNotNone(rules)
        self.assertEqual(rules["template_version"], "v1")
        self.assertEqual(rules["create"]["required"], ["title", "slug", "content"])
        self.assertEqual(
            rules["create"]["properties"]["status"]["enum"],
            ["draft", "published", "archived"],
        )

    def test_site_setting_define_spec_points_to_site_settings_table(self):
        spec = build_define_spec("site_setting_v1")

        self.assertIsNotNone(spec)
        self.assertEqual(spec["action"], "table.define")
        self.assertEqual(spec["table"], "site_settings")
        self.assertIn("setting_key", spec["payload"]["schema"])

    def test_list_template_suites_returns_recommended_suite_first(self):
        suites = list_template_suites()

        self.assertEqual(len(suites), 1)
        suite = suites[0]
        self.assertEqual(suite["suite_key"], "admin_basic_suite_v1")
        self.assertTrue(suite["recommended"])
        self.assertEqual(suite["stability"], "stable")
        self.assertIn("user_standard_v2", suite["template_keys"])
        self.assertIn("rbac_role_v1", suite["template_keys"])
        self.assertEqual(suite["recommended_template_order"][0], "user_standard_v2")
        self.assertTrue(suite["has_seed_contract"])
        self.assertIn("roles", suite["seed_set_keys"])
        self.assertFalse(suite["has_relation_cycles"])

    def test_get_template_suite_returns_deep_copy(self):
        suite = get_template_suite("admin_basic_suite_v1")

        self.assertIsNotNone(suite)
        self.assertEqual(suite["version"], "v1")
        self.assertIn("content_article_v1", suite["template_keys"])
        self.assertIn("recommended_table_order", suite)
        self.assertIn("content_categories", suite["recommended_table_order"])

        suite["template_keys"].append("fake_template")
        suite_again = get_template_suite("admin_basic_suite_v1")
        self.assertNotIn("fake_template", suite_again["template_keys"])

    def test_get_template_suite_install_plan_returns_dependency_order(self):
        plan = get_template_suite_install_plan("admin_basic_suite_v1")

        self.assertIsNotNone(plan)
        self.assertEqual(plan["suite_key"], "admin_basic_suite_v1")
        self.assertLess(
            plan["recommended_template_order"].index("user_standard_v2"),
            plan["recommended_template_order"].index("rbac_user_role_v1"),
        )
        self.assertLess(
            plan["recommended_template_order"].index("content_category_v1"),
            plan["recommended_template_order"].index("content_article_v1"),
        )
        self.assertLess(
            plan["recommended_template_order"].index("content_article_v1"),
            plan["recommended_template_order"].index("content_article_tag_v1"),
        )
        self.assertEqual(plan["dependencies"]["content_articles"], ["content_categories", "users"])
        self.assertFalse(plan["has_relation_cycles"])

    def test_get_template_suite_seed_sets_returns_deep_copy(self):
        seed_sets = get_template_suite_seed_sets("admin_basic_suite_v1")

        self.assertIsNotNone(seed_sets)
        self.assertIn("roles", seed_sets)
        self.assertEqual(seed_sets["roles"]["identity_field"], "role_key")

        seed_sets["roles"]["identity_field"] = "changed"
        seed_sets_again = get_template_suite_seed_sets("admin_basic_suite_v1")
        self.assertEqual(seed_sets_again["roles"]["identity_field"], "role_key")
        self.assertIn("roles", shim_get_template_suite_seed_sets("admin_basic_suite_v1"))

    def test_validate_template_suite_seed_sets_reports_missing_references(self):
        result = validate_template_suite_seed_sets(
            "admin_basic_suite_v1",
            {
                "users": [
                    {"username": "admin", "email": "admin@example.com", "password_hash": "hash"},
                ],
                "roles": [
                    {"role_key": "super_admin", "role_name": "Super Admin"},
                ],
                "user_roles": [
                    {"user_ref": "admin", "role_ref": "missing_role"},
                ],
                "unexpected_set": [
                    {"foo": "bar"},
                ],
            },
        )

        self.assertEqual(result["warnings"], ["unknown seed set ignored: unexpected_set"])
        self.assertTrue(
            any("user_roles[0]" in error and "missing_role" in error for error in result["errors"]),
            result,
        )
        compat_result = validate_template_suite_seed_bundle("admin_basic_suite_v1", {"roles": []})
        self.assertEqual(compat_result["errors"], [])

    def test_validate_template_suite_seed_sets_rejects_duplicate_identity_values(self):
        result = validate_template_suite_seed_sets(
            "admin_basic_suite_v1",
            {
                "roles": [
                    {"role_key": "super_admin", "role_name": "Super Admin"},
                    {"role_key": "super_admin", "role_name": "Duplicate Super Admin"},
                ],
            },
        )

        self.assertTrue(
            any("duplicates identity role_key='super_admin'" in error for error in result["errors"]),
            result,
        )

    def test_validate_template_overrides_rejects_relation_breaking_changes(self):
        errors = validate_template_overrides("rbac_user_role_v1", {"schema": {"user_id": {"relation": None}}})

        self.assertTrue(
            any("relation-protected field user_id" in error for error in errors),
            errors,
        )
        with self.assertRaises(ValueError):
            build_define_spec("rbac_user_role_v1", overrides={"schema": {"user_id": {"relation": None}}})

    def test_validate_template_overrides_rejects_non_relation_schema_shape_changes(self):
        errors = validate_template_overrides("user_standard_v2", {"schema": {"username": {"type": "text"}}})

        self.assertTrue(any("unsupported keys: type" in error for error in errors), errors)
        with self.assertRaises(ValueError):
            build_define_spec("user_standard_v2", overrides={"schema": {"username": {"type": "text"}}})

    def test_validate_template_libraries_rejects_invalid_suite_and_rule_drift(self):
        bad_suite = {
            "suite_key": "broken_suite",
            "suite_name": "Broken Suite",
            "version": "v1",
            "description": "broken",
            "stability": "stable",
            "scenarios": ["admin-console"],
            "template_keys": ["content_article_v1", "content_category_v1"],
            "seed_sets": {
                "articles": {
                    "template_key": "content_article_v1",
                    "table": "content_articles",
                    "identity_field": "missing_identity",
                    "required_fields": ["title", "slug", "content"],
                    "references": {"author_ref": {"seed_set": "users", "identity_field": "username"}},
                }
            },
        }
        bad_rules = {
            "template_key": "user_standard_v2",
            "version": "v1",
            "template_version": "v2",
            "virtual_properties": ["password"],
            "create": {
                "required": ["username"],
                "properties": {"username": {"type": "integer"}},
                "forbidden": ["username"],
                "cross_rules": [],
            },
            "update": {
                "required": [],
                "properties": {},
                "forbidden": [],
                "cross_rules": [],
            },
        }

        with patch.dict(template_registry.TEMPLATE_SUITE_LIBRARY, {"broken_suite": bad_suite}, clear=False):
            with patch.dict(template_registry.RULE_LIBRARY, {"user_standard_v2": bad_rules}, clear=False):
                errors = validate_template_libraries()

        self.assertTrue(
            any("broken_suite" in error and "order violates relation dependency" in error for error in errors),
            errors,
        )
        self.assertTrue(
            any("broken_suite" in error and "references unknown seed set" in error for error in errors),
            errors,
        )
        self.assertTrue(
            any("broken_suite" in error and "identity_field references unknown field" in error for error in errors),
            errors,
        )
        self.assertTrue(
            any("user_standard_v2.create required/forbidden overlap" in error for error in errors),
            errors,
        )
        self.assertTrue(
            any("user_standard_v2.create.username type" in error for error in errors),
            errors,
        )


if __name__ == "__main__":
    unittest.main()
