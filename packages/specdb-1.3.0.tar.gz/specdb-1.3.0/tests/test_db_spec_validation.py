import unittest

from specdb.executor.errors import DBExecuteError
from specdb.executor.spec_validation import validate_execute_spec


class ExecuteSpecValidationTestCase(unittest.TestCase):
    def test_table_define_requires_non_empty_schema(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "table.define",
                    "table": "users",
                    "payload": {"schema": {}},
                    "options": {},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_table_alter_modify_rejects_unknown_key(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "table.alter",
                    "table": "users",
                    "payload": {"modify": {"name": {"unknown_flag": True}}},
                    "options": {},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_table_alter_modify_accepts_second_phase_unique_key(self):
        action, options = validate_execute_spec(
            {
                "action": "table.alter",
                "table": "users",
                "payload": {"modify": {"name": {"unique": True, "index": False}}},
                "options": {},
            }
        )
        self.assertEqual(action, "table.alter")
        self.assertEqual(options, {})

    def test_table_alter_modify_rejects_non_bool_unique_key(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "table.alter",
                    "table": "users",
                    "payload": {"modify": {"name": {"unique": "yes"}}},
                    "options": {},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_data_select_requires_boolean_include_total(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "data.select",
                    "table": "users",
                    "payload": {"query": {}},
                    "options": {"include_total": "yes"},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_data_history_rejects_entity_id_and_query_together(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "data.history",
                    "table": "users",
                    "payload": {"entity_id": "ent-1", "query": {"biz_id": "u001"}},
                    "options": {},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_data_update_rejects_non_bool_allow_full_table(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "data.update",
                    "table": "users",
                    "payload": {"data": {"name": "Tom"}},
                    "options": {"allow_full_table": 1},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")

    def test_data_delete_requires_query_without_allow_full_table(self):
        with self.assertRaises(DBExecuteError) as ctx:
            validate_execute_spec(
                {
                    "action": "data.delete",
                    "table": "users",
                    "payload": {},
                    "options": {},
                }
            )
        self.assertEqual(ctx.exception.code, "DB_SCHEMA_ERROR")


if __name__ == "__main__":
    unittest.main()
