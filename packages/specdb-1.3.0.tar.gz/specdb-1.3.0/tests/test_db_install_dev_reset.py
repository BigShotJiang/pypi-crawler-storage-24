import uuid
from pathlib import Path
from unittest.mock import patch

from flask import Flask

import db_api_test_base as support
from db_api_test_base import *
from specdb.db_executor import init_database
from specdb.db_module import DBModuleOptions, init_db_module, shutdown_db_module
from specdb.db_runtime import db
from specdb.install import install_seed, install_suite, reset_dev_database


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()


class DBInstallDevResetTestCase(DBApiTestBase):
    def test_reset_dev_database_requires_confirm_flag(self):
        with app.app_context():
            result = reset_dev_database(init_database(), confirm_dev=False)

        self.assertFalse(result["success"], result)
        self.assertEqual(result["error"]["code"], "DB_INSTALL_RESET_NOT_CONFIRMED")

    def test_reset_dev_database_rejects_non_dev_environment(self):
        sqlite_path = (Path(__file__).resolve().parents[1] / ".tmp" / "tests" / f"prod_reset_{uuid.uuid4().hex}.sqlite3").resolve()
        sqlite_path.parent.mkdir(parents=True, exist_ok=True)
        app_obj = Flask(__name__)
        app_obj.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_obj.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_obj.config["TESTING"] = False
        app_obj.config["DEBUG"] = False
        app_obj.config["FLASK_DEBUG"] = False
        app_obj.config["APP_ENV"] = "production"
        init_db_module(
            app_obj,
            options=DBModuleOptions(enable_ops_routes=False, enable_restore_routes=False),
        )
        self.addCleanup(lambda: shutdown_db_module(app_obj, wait=True))
        self.addCleanup(lambda: sqlite_path.unlink(missing_ok=True))

        with app_obj.app_context():
            result = reset_dev_database(init_database(), confirm_dev=True)
            db.session.remove()
            db.engine.dispose()

        self.assertFalse(result["success"], result)
        self.assertEqual(result["error"]["code"], "DB_INSTALL_RESET_FORBIDDEN")

    def test_reset_dev_database_can_reinstall_suite_and_seed(self):
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "super_admin", "role_name": "Super Admin", "status": "active"}],
                }
            }
        }
        for table_name in ("rbac_roles", "users"):
            self.addCleanup(lambda name=table_name: self._drop_table(name))

        with app.app_context():
            client = init_database()
            install_suite(client, "admin_basic_suite_v1", include_templates=["user_standard_v2", "rbac_role_v1"])
            install_seed(client, bundle)
            result = reset_dev_database(
                client,
                confirm_dev=True,
                reinstall_suite="admin_basic_suite_v1",
                reinstall_seed=bundle,
            )
            listed = client.execute({"action": "table.list", "payload": {}, "options": {}})
            roles = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "super_admin"}},
                    "options": {"include_total": True},
                }
            )

        self.assertTrue(result["success"], result)
        self.assertIn("rbac_roles", result["data"]["dropped_tables"])
        self.assertTrue(result["data"]["reinstalled_suite"]["success"])
        self.assertTrue(result["data"]["seed_result"]["success"])
        self.assertIn("rbac_roles", listed["data"])
        self.assertEqual(roles["data"]["total"], 1)

    def test_reset_dev_database_skips_seed_when_suite_reinstall_fails(self):
        with app.app_context():
            client = init_database()
            with patch(
                "specdb.install.dev_reset.install_suite",
                return_value={"success": False, "data": {}, "error": {"code": "DB_INSTALL_SUITE_FAILED"}},
            ) as mocked_suite:
                with patch("specdb.install.dev_reset.install_seed") as mocked_seed:
                    result = reset_dev_database(
                        client,
                        confirm_dev=True,
                        reinstall_suite="admin_basic_suite_v1",
                        reinstall_seed={"tables": {"rbac_roles": {"key_fields": ["role_key"], "rows": []}}},
                    )

        self.assertFalse(result["success"], result)
        self.assertIsNone(result["data"]["seed_result"])
        self.assertIn("skipped seed reinstall because suite reinstall failed", result["data"]["warnings"])
        mocked_suite.assert_called_once()
        mocked_seed.assert_not_called()

    def test_reset_dev_database_warns_when_cycle_forces_reverse_drop_order(self):
        with app.app_context():
            client = init_database()
            with patch("specdb.install.dev_reset._dependency_order_for_drop", return_value=([], True)):
                result = reset_dev_database(client, confirm_dev=True)

        self.assertTrue(result["success"], result)
        self.assertIn(
            "dependency cycle detected during reset; falling back to reverse listed drop order",
            result["data"]["warnings"],
        )


if __name__ == "__main__":
    unittest.main()
