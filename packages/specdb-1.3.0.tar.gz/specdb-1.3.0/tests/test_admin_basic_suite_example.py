import importlib.util
import shutil
import unittest
import uuid
from pathlib import Path

from flask import Flask
from specdb.db_runtime import db


def _load_example_module():
    module_path = Path(__file__).resolve().parents[1] / "examples" / "admin_basic_suite_init.py"
    spec = importlib.util.spec_from_file_location("admin_basic_suite_init_example", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load example module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AdminBasicSuiteExampleTestCase(unittest.TestCase):
    def setUp(self):
        self.example = _load_example_module()
        temp_root = Path(__file__).resolve().parents[1] / ".tmp" / "examples"
        temp_root.mkdir(parents=True, exist_ok=True)
        self.tempdir = temp_root / f"admin-basic-suite-{uuid.uuid4().hex}"
        self.tempdir.mkdir(parents=True, exist_ok=True)
        self.db_path = (self.tempdir / "admin_basic_suite.sqlite3").resolve()
        self.app = Flask(__name__)
        self.app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{self.db_path.as_posix()}"
        self.app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        self.example.init_db_module(
            self.app,
            options=self.example.DBModuleOptions(
                db_url_prefix="/api/db",
                blueprint_name="db",
                enable_ops_routes=False,
                enable_restore_routes=False,
            ),
        )
        self.client = None

    def tearDown(self):
        self.example.shutdown_db_module(self.app, wait=True)
        with self.app.app_context():
            db.session.remove()
            db.engine.dispose()
        shutil.rmtree(self.tempdir, ignore_errors=True)

    def _execute(self, spec: dict) -> dict:
        with self.app.app_context():
            if self.client is None:
                self.client = self.example.init_database()
            result = self.client.execute(spec)
        self.assertTrue(result["success"], result)
        return result["data"]

    def _select_one(self, table: str, query: dict) -> dict:
        data = self._execute(
            {
                "action": "data.select",
                "table": table,
                "payload": {"query": query},
                "options": {"include_total": True},
            }
        )
        self.assertEqual(data["total"], 1)
        self.assertEqual(len(data["items"]), 1)
        return data["items"][0]

    def test_example_initializes_tables_and_seed_relationships(self):
        with self.app.app_context():
            self.client = self.example.init_database()
            self.example.define_tables(self.client)
            self.example.seed_sample_data(self.client)

        tables = self._execute({"action": "table.list", "payload": {}, "options": {}})
        for table_name in (
            "users",
            "rbac_roles",
            "rbac_pages",
            "rbac_permissions",
            "rbac_user_roles",
            "rbac_role_page_access",
            "rbac_role_permissions",
            "content_articles",
            "site_settings",
        ):
            self.assertIn(table_name, tables)

        admin_user = self._select_one("users", {"username": "admin"})
        self.assertEqual(admin_user["email"], "admin@example.com")
        self.assertEqual(admin_user["password_algo"], "bcrypt")
        self.assertFalse(admin_user["mfa_enabled"])

        super_admin = self._select_one("rbac_roles", {"role_key": "super_admin"})
        dashboard_page = self._select_one("rbac_pages", {"page_key": "dashboard"})
        article_write = self._select_one("rbac_permissions", {"permission_key": "article.write"})

        user_role_binding = self._select_one(
            "rbac_user_roles",
            {"user_id": admin_user["id"], "role_id": super_admin["id"]},
        )
        self.assertEqual(user_role_binding["role_id"], super_admin["id"])

        page_access = self._select_one(
            "rbac_role_page_access",
            {"role_id": super_admin["id"], "page_id": dashboard_page["id"]},
        )
        self.assertTrue(page_access["can_view"])
        self.assertTrue(page_access["can_create"])
        self.assertTrue(page_access["can_update"])
        self.assertTrue(page_access["can_delete"])

        permission_binding = self._select_one(
            "rbac_role_permissions",
            {"role_id": super_admin["id"], "permission_id": article_write["id"]},
        )
        self.assertEqual(permission_binding["permission_id"], article_write["id"])

        site_name = self._select_one("site_settings", {"setting_key": "site.name"})
        self.assertEqual(site_name["setting_value"], "SpecDB Admin Demo")


if __name__ == "__main__":
    unittest.main()
