"""按主题拆分后的 DB API ops 流程测试。"""

import db_api_test_base as support
from db_api_test_base import *


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()

class DBApiOpsTestCase(DBApiTestBase):
    def test_execute_compact_once_dry_run_does_not_rollback_read_batches(self):
        table_name = self._table_name("compact_direct")
        self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7},
                    },
                }
            },
        )
        self._post(
            "/api/db/data",
            {"spec": {"action": "data.insert", "table": table_name, "payload": {"data": {"name": "dry-run"}}}},
        )

        with self.app.app_context():
            with patch.object(db.session, "rollback", wraps=db.session.rollback) as rollback_mock:
                compacted_rows, history_rows, table_stats, metrics = ops_compact_engine_module._execute_compact_once(
                    dry_run=True,
                    targets=[table_name],
                    compact_before_dt=datetime(2999, 1, 1, tzinfo=timezone.utc),
                    batch_size=100,
                )
        self.assertGreaterEqual(compacted_rows, 0)
        self.assertEqual(history_rows, 0)
        self.assertEqual(metrics["deleted_rows"], 0)
        self.assertFalse(metrics["archive_persisted"])
        rollback_mock.assert_not_called()

    def test_ops_endpoint_placeholder_and_job_query(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["job_id"], job_id)
        self.assertIn(body["data"]["state"], {"pending", "snapshot_done", "compact_done", "verified"})

        data = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(data["job_id"], job_id)
        self.assertIsNotNone(data["snapshot_id"])
        self.assertIn("request", data)
        self.assertEqual(data["request"]["request_id"], job_id)
        self.assertTrue(str(data["created_at"]).endswith("+00:00"))
        self.assertTrue(str(data["updated_at"]).endswith("+00:00"))

    def test_ops_endpoint_is_idempotent_by_request_id(self):
        users_table = self._table_name("users")
        self._define_table(users_table)
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        first_resp, first_body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": [users_table]},
        )
        second_resp, second_body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": [users_table]},
        )

        self.assertEqual(first_resp.status_code, 202)
        self.assertEqual(second_resp.status_code, 202)
        self.assertTrue(first_body["success"])
        self.assertTrue(second_body["success"])
        self.assertIn(first_body["data"]["state"], {"pending", "snapshot_done", "compact_done", "verified"})
        self.assertIn(second_body["data"]["state"], {"pending", "snapshot_done", "compact_done", "verified"})
        self.assertEqual(first_body["data"]["job_id"], job_id)
        self.assertEqual(second_body["data"]["job_id"], job_id)

        data = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(data["job_id"], job_id)
        self.assertEqual(data["request"]["targets"], [users_table])
        self.assertTrue(bool(data["request"]["dry_run"]))
        self._drop_table(users_table)

    def test_ops_endpoint_rejects_request_id_payload_conflicts(self):
        users_table = self._table_name("users")
        orders_table = self._table_name("orders")
        self._define_table(users_table)
        self._define_table(orders_table)
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        first_resp, first_body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": [users_table]},
        )
        second_resp, second_body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": False, "targets": [orders_table]},
        )

        self.assertEqual(first_resp.status_code, 202)
        self.assertTrue(first_body["success"])
        self.assertEqual(second_resp.status_code, 409)
        self.assertFalse(second_body["success"])
        self.assertEqual(second_body["error"]["code"], "DB_OPS_CONFLICT")

        data = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(data["request"]["targets"], [users_table])
        self.assertTrue(bool(data["request"]["dry_run"]))
        self._drop_table(users_table)
        self._drop_table(orders_table)

    def test_ops_snapshot_and_compact_isolates_archive_request_per_scope(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_scope_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        app_scope = Flask("db_scope_isolation")
        app_scope.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_scope.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_scope.config["TESTING"] = True
        init_db_module(
            app_scope,
            options=DBModuleOptions(register_blueprint=False),
        )

        def _cleanup_scope_app():
            shutdown_db_module(app_scope, wait=True)
            with app_scope.app_context():
                db.session.remove()
                db.engine.dispose()
            if sqlite_path.exists():
                sqlite_path.unlink()

        self.addCleanup(_cleanup_scope_app)

        with app_scope.app_context():
            ops_jobs_store.create_pending_job(
                "scope-job-a",
                {
                    "request_id": "scope-job-a",
                    "dry_run": False,
                    "targets": [],
                    "archive": {"enabled": True, "mode": "internal"},
                    "strategy": {},
                    "_scope_key": "scope_a",
                },
            )
            ops_jobs_store.create_pending_job(
                "scope-job-b",
                {
                    "request_id": "scope-job-b",
                    "dry_run": False,
                    "targets": [],
                    "archive": {"enabled": True, "mode": "external"},
                    "strategy": {},
                    "_scope_key": "scope_b",
                },
            )

        seen: dict[str, dict[str, object] | None] = {}
        enter_barrier = threading.Barrier(2)
        exit_barrier = threading.Barrier(2)

        def fake_execute_compact_once(*, dry_run, targets, compact_before_dt, batch_size, scope_key=None, heartbeat=None):
            enter_barrier.wait(timeout=2.0)
            state = ops_db_routes_module._get_ops_state(ops_db_routes_module.current_app, scope_key)
            active_archive_request = state.get("active_archive_request")
            seen[str(scope_key)] = dict(active_archive_request) if isinstance(active_archive_request, dict) else None
            exit_barrier.wait(timeout=2.0)
            return (
                0,
                0,
                [],
                {
                    "batch_size": int(batch_size),
                    "batches": 0,
                    "deleted_rows": 0,
                    "avg_batch_ms": 0,
                    "max_batch_ms": 0,
                    "log_batches": 0,
                    "history_batches": 0,
                    "log_deleted_rows": 0,
                    "history_deleted_rows": 0,
                    "archive_rows": 0,
                },
            )

        with patch.object(ops_compact_engine_module, "_execute_compact_once", side_effect=fake_execute_compact_once):
            with app_scope.app_context():
                owner_id = ops_db_routes_module._resolve_ops_instance_id(app_scope)
                ops_jobs_store.claim_job_execution("scope-job-a", owner_id=owner_id, lease_seconds=300)
                ops_jobs_store.claim_job_execution("scope-job-b", owner_id=owner_id, lease_seconds=300)
            thread_a = threading.Thread(
                target=ops_db_routes_module._run_snapshot_and_compact_job,
                args=(app_scope, "scope-job-a", "scope_a"),
                name="scope_a",
            )
            thread_b = threading.Thread(
                target=ops_db_routes_module._run_snapshot_and_compact_job,
                args=(app_scope, "scope-job-b", "scope_b"),
                name="scope_b",
            )
            thread_a.start()
            thread_b.start()
            thread_a.join(timeout=5.0)
            thread_b.join(timeout=5.0)

        self.assertFalse(thread_a.is_alive())
        self.assertFalse(thread_b.is_alive())
        self.assertEqual(seen["scope_a"]["mode"], "internal")
        self.assertEqual(seen["scope_b"]["mode"], "external")

        with app_scope.app_context():
            self.assertEqual(ops_jobs_store.get_job("scope-job-a")["state"], "verified")
            self.assertEqual(ops_jobs_store.get_job("scope-job-b")["state"], "verified")

    def test_ops_job_query_rejects_invalid_job_id_and_uses_not_found_for_missing(self):
        resp = self.client.get("/api/db/ops/jobs/bad job id")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

        resp = self.client.get("/api/db/ops/jobs/missing-job-001")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_ops_snapshot_and_compact_dry_run_keeps_logs(self):
        table_name = self._table_name("compact_dry")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        before = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertGreaterEqual(len(before), 2)

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {
                "request_id": job_id,
                "dry_run": True,
                "targets": [table_name],
                "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                "operator": "tester_a",
                "node": "node_local",
            },
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        job_data = self._wait_for_job_state(job_id, "verified")
        self.assertIn("summary", job_data)
        self.assertTrue(job_data["summary"]["dry_run"])
        self.assertGreaterEqual(job_data["summary"]["log_rows_compacted"], 2)
        self.assertGreaterEqual(job_data["summary"]["duration_ms"], 0)
        self.assertGreaterEqual(job_data["summary"]["tables"], 1)
        self.assertIsInstance(job_data["summary"]["table_stats"], list)
        self.assertEqual(job_data["summary"]["table_stats"][0]["table"], table_name)
        self.assertGreaterEqual(job_data["summary"]["table_stats"][0]["log_rows"], 2)
        self.assertEqual(job_data["summary"]["operator"], "tester_a")
        self.assertEqual(job_data["summary"]["node"], "node_local")
        self.assertIsNone(job_data["summary"]["failed_stage"])
        self.assertEqual(job_data["summary"]["retry_count"], 0)
        self.assertEqual(job_data["summary"]["max_retries"], 1)
        self.assertIsNone(job_data["summary"]["error_code"])
        self.assertIsNone(job_data["summary"]["last_error_at"])
        self.assertIsNone(job_data["summary"]["last_error"])
        self.assertIn("context", job_data["summary"])
        self.assertEqual(job_data["summary"]["context"]["request_id"], job_id)
        self.assertEqual(job_data["summary"]["context"]["scope_key"], "db")
        self.assertEqual(job_data["summary"]["context"]["operator"], "tester_a")
        self.assertEqual(job_data["summary"]["context"]["node"], "node_local")
        self.assertEqual(job_data["summary"]["context"]["targets"], [table_name])
        self.assertIn("compact_metrics", job_data["summary"])
        self.assertEqual(job_data["summary"]["compact_metrics"]["batches"], 0)
        self.assertEqual(job_data["summary"]["compact_metrics"]["deleted_rows"], 0)

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertEqual(len(after), len(before))
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_compacts_logs(self):
        table_name = self._table_name("compact_real")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        before = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertGreaterEqual(len(before), 2)

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {
                "request_id": job_id,
                "dry_run": False,
                "targets": [table_name],
                "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                "operator": "tester_b",
                "node": "node_local",
            },
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        job_data = self._wait_for_job_state(job_id, "verified")
        self.assertIn("summary", job_data)
        self.assertFalse(job_data["summary"]["dry_run"])
        self.assertGreaterEqual(job_data["summary"]["log_rows_compacted"], 2)
        self.assertGreaterEqual(job_data["summary"]["duration_ms"], 0)
        self.assertGreaterEqual(job_data["summary"]["tables"], 1)
        self.assertIsInstance(job_data["summary"]["table_stats"], list)
        self.assertEqual(job_data["summary"]["table_stats"][0]["table"], table_name)
        self.assertGreaterEqual(job_data["summary"]["table_stats"][0]["log_rows"], 2)
        self.assertEqual(job_data["summary"]["operator"], "tester_b")
        self.assertEqual(job_data["summary"]["node"], "node_local")
        self.assertIsNone(job_data["summary"]["failed_stage"])
        self.assertEqual(job_data["summary"]["retry_count"], 0)
        self.assertEqual(job_data["summary"]["max_retries"], 1)
        self.assertIsNone(job_data["summary"]["error_code"])
        self.assertIsNone(job_data["summary"]["last_error_at"])
        self.assertIsNone(job_data["summary"]["last_error"])
        self.assertIn("context", job_data["summary"])
        self.assertEqual(job_data["summary"]["context"]["request_id"], job_id)
        self.assertEqual(job_data["summary"]["context"]["scope_key"], "db")
        self.assertEqual(job_data["summary"]["context"]["operator"], "tester_b")
        self.assertEqual(job_data["summary"]["context"]["node"], "node_local")
        self.assertEqual(job_data["summary"]["context"]["targets"], [table_name])
        self.assertIn("compact_metrics", job_data["summary"])
        self.assertGreaterEqual(job_data["summary"]["compact_metrics"]["batches"], 1)
        self.assertGreaterEqual(job_data["summary"]["compact_metrics"]["deleted_rows"], 2)
        self.assertGreaterEqual(job_data["summary"]["compact_metrics"]["max_batch_ms"], 0)

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertEqual(len(after), 0)
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_archives_logs(self):
        table_name = self._table_name("compact_archive")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {
                "request_id": job_id,
                "dry_run": False,
                "targets": [table_name],
                "archive": {"enabled": True, "mode": "internal"},
                "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
            },
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        job_data = self._wait_for_job_state(job_id, "verified")
        summary = job_data["summary"]
        self.assertTrue(summary["archive_enabled"])
        self.assertEqual(summary["archive_mode"], "internal")
        self.assertIsNotNone(summary["archive_id"])
        self.assertGreaterEqual(summary["archived_rows"], 2)
        self.assertGreaterEqual(summary["log_rows_compacted"], 2)
        with app.app_context():
            archive = get_archive(summary["archive_id"])
            self.assertIsNotNone(archive)
            self.assertEqual(archive["item_count"], summary["archived_rows"])
            self.assertEqual(get_archive_item_count(summary["archive_id"]), summary["archived_rows"])

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertEqual(len(after), 0)
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_failure_cleans_empty_archive(self):
        table_name = self._table_name("compact_archive_fail")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        real_append_archive_items = ops_archive_store_module.append_archive_items

        def flaky_append_archive_items(*args, **kwargs):
            real_append_archive_items(*args, **kwargs)
            raise RuntimeError("archive write boom")

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0
        try:
            with patch("specdb.ops_archive_store.append_archive_items", side_effect=flaky_append_archive_items):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": False,
                        "targets": [table_name],
                        "archive": {"enabled": True, "mode": "internal"},
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                job_data = self._wait_for_job_state(job_id, "failed")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        summary = job_data["summary"]
        self.assertTrue(summary["archive_enabled"])
        self.assertIsNone(summary["archive_id"])
        self.assertEqual(summary["archived_rows"], 0)
        with app.app_context():
            self.assertEqual(summary["compact_metrics"]["archive_rows"], 0)

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertGreaterEqual(len(after), 2)
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_reports_archive_cleanup_failure(self):
        table_name = self._table_name("compact_archive_cleanup_fail")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        real_append_archive_items = ops_archive_store_module.append_archive_items
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0

        def flaky_append_archive_items(*args, **kwargs):
            real_append_archive_items(*args, **kwargs)
            raise RuntimeError("archive write boom")

        try:
            with patch("specdb.ops_archive_store.append_archive_items", side_effect=flaky_append_archive_items):
                with patch("specdb.ops_archive_store.delete_archive", side_effect=RuntimeError("cleanup boom")):
                    resp, body = self._post(
                        "/api/db/ops/snapshot-and-compact",
                        {
                            "request_id": f"ops-{uuid.uuid4().hex[:8]}",
                            "dry_run": False,
                            "targets": [table_name],
                            "archive": {"enabled": True, "mode": "internal"},
                            "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                        },
                    )
                    self.assertEqual(resp.status_code, 202)
                    self.assertTrue(body["success"])
                    job_data = self._wait_for_job_state(body["data"]["job_id"], "failed")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        self.assertIn("archive cleanup failed", job_data["summary"]["last_error"])
        self.assertIn("cleanup boom", job_data["summary"]["last_error"])
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_failure_preserves_partial_progress(self):
        table_name = self._table_name("compact_archive_partial_fail")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        for name in ("v1", "v2", "v3"):
            self._post(
                "/api/db/data",
                {
                    "spec": {
                        "action": "data.insert",
                        "table": table_name,
                        "payload": {"data": {"name": name}},
                        "options": {},
                    }
                },
            )

        call_count = {"value": 0}
        real_append_archive_items = ops_archive_store_module.append_archive_items

        def flaky_append_archive_items(*args, **kwargs):
            call_count["value"] += 1
            result = real_append_archive_items(*args, **kwargs)
            if call_count["value"] >= 2:
                raise RuntimeError("archive write boom after first batch")
            return result

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        old_batch_size = app.config.get("OPS_COMPACT_BATCH_SIZE", 5000)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0
        app.config["OPS_COMPACT_BATCH_SIZE"] = 1
        try:
            with patch("specdb.ops_archive_store.append_archive_items", side_effect=flaky_append_archive_items):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": False,
                        "targets": [table_name],
                        "archive": {"enabled": True, "mode": "internal"},
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                job_data = self._wait_for_job_state(job_id, "failed")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry
            app.config["OPS_COMPACT_BATCH_SIZE"] = old_batch_size

        summary = job_data["summary"]
        self.assertTrue(summary["archive_enabled"])
        self.assertIsNotNone(summary["archive_id"])
        self.assertEqual(summary["archived_rows"], 1)
        self.assertEqual(summary["log_rows_compacted"], 1)
        self.assertEqual(summary["rows_compacted_total"], 1)
        self.assertEqual(summary["compact_metrics"]["archive_rows"], 1)
        self.assertEqual(summary["compact_metrics"]["log_deleted_rows"], 1)
        self.assertEqual(summary["tables"], 1)
        self.assertEqual(summary["table_stats"], [{"table": table_name, "log_rows": 1, "history_rows": 0}])
        with app.app_context():
            archive = get_archive(summary["archive_id"])
            self.assertIsNotNone(archive)
            self.assertEqual(archive["item_count"], 1)
            self.assertEqual(get_archive_item_count(summary["archive_id"]), 1)

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertGreaterEqual(len(after), 2)
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_retry_success_keeps_cumulative_archive_count(self):
        table_name = self._table_name("compact_retry_archive")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        for name in ("v1", "v2", "v3"):
            self._post(
                "/api/db/data",
                {
                    "spec": {
                        "action": "data.insert",
                        "table": table_name,
                        "payload": {"data": {"name": name}},
                        "options": {},
                    }
                },
            )

        call_count = {"value": 0}
        real_append_archive_items = ops_archive_store_module.append_archive_items

        def flaky_append_archive_items(*args, **kwargs):
            call_count["value"] += 1
            result = real_append_archive_items(*args, **kwargs)
            if call_count["value"] == 2:
                raise RuntimeError("archive write boom on retry boundary")
            return result

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        old_batch_size = app.config.get("OPS_COMPACT_BATCH_SIZE", 5000)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 1
        app.config["OPS_COMPACT_BATCH_SIZE"] = 1
        try:
            with patch("specdb.ops_archive_store.append_archive_items", side_effect=flaky_append_archive_items):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": False,
                        "targets": [table_name],
                        "archive": {"enabled": True, "mode": "internal"},
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                job_data = self._wait_for_job_state(job_id, "verified")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry
            app.config["OPS_COMPACT_BATCH_SIZE"] = old_batch_size

        summary = job_data["summary"]
        self.assertEqual(summary["retry_count"], 1)
        self.assertIsNotNone(summary["archive_id"])
        self.assertEqual(summary["archived_rows"], 3)
        self.assertEqual(summary["log_rows_compacted"], 3)
        with app.app_context():
            archive = get_archive(summary["archive_id"])
            self.assertIsNotNone(archive)
            self.assertEqual(archive["item_count"], 3)
            self.assertEqual(get_archive_item_count(summary["archive_id"]), 3)

        after = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=200").get_json()["data"]["items"]
        self.assertEqual(len(after), 0)
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_compacts_append_only_history(self):
        table_name = self._table_name("compact_history")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "append_only_versioned", "retention_days": 30}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "u001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v3"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {
                "request_id": job_id,
                "dry_run": False,
                "targets": [table_name],
                "archive": {"enabled": True, "mode": "internal"},
                "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
            },
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        job_data = self._wait_for_job_state(job_id, "verified")
        summary = job_data["summary"]
        self.assertEqual(summary["log_rows_compacted"], 0)
        self.assertEqual(summary["history_rows_compacted"], 2)
        self.assertEqual(summary["rows_compacted_total"], 2)
        self.assertEqual(summary["archived_rows"], 2)
        self.assertIsNotNone(summary["archive_id"])
        with app.app_context():
            archive = get_archive(summary["archive_id"])
            self.assertIsNotNone(archive)
            self.assertEqual(archive["item_count"], 2)

        with app.app_context():
            rows = (
                db.session.execute(
                    db.text(
                        f"SELECT name, __wt_version, __wt_is_current FROM {table_name} ORDER BY __wt_row_id ASC"
                    )
                )
                .mappings()
                .all()
            )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "v3")
        self.assertEqual(int(rows[0]["__wt_version"]), 3)
        self.assertTrue(bool(rows[0]["__wt_is_current"]))

        self._drop_table(table_name)

    def test_ops_job_not_found(self):
        resp = self.client.get("/api/db/ops/jobs/not_exists_job")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_multi_scope_archive_ids_remain_unique_for_shared_request_id(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_scope_archive_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        app_multi = Flask("db_multi_scope_archive")
        app_multi.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_multi.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_multi.config["TESTING"] = True
        init_db_module(
            app_multi,
            options=DBModuleOptions(register_blueprint=False, init_tables=True),
        )
        app_multi.register_blueprint(create_db_blueprint(name="dba", url_prefix="/a/db"))
        app_multi.register_blueprint(create_db_blueprint(name="dbb", url_prefix="/b/db"))
        client = app_multi.test_client()

        def _cleanup_multi_scope_archive():
            shutdown_db_module(app_multi, wait=True)
            with app_multi.app_context():
                db.session.remove()
                db.engine.dispose()
            if sqlite_path.exists():
                sqlite_path.unlink()

        self.addCleanup(_cleanup_multi_scope_archive)

        def _wait_job(path_prefix: str, job_id: str, expected_state: str, timeout_sec: float = 3.0) -> dict:
            deadline = time.time() + timeout_sec
            last_state = None
            while time.time() < deadline:
                resp = client.get(f"{path_prefix}/ops/jobs/{job_id}")
                body = resp.get_json()
                self.assertEqual(resp.status_code, 200)
                last_state = body["data"]["state"]
                if last_state == expected_state:
                    return body["data"]
                time.sleep(0.05)
            self.fail(f"{path_prefix} job {job_id} did not reach {expected_state}, last_state={last_state}")

        fixed_now = datetime(2026, 3, 7, 12, 0, 0, 123456, tzinfo=timezone.utc)

        class _FrozenDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                if tz is None:
                    return fixed_now.replace(tzinfo=None)
                return fixed_now.astimezone(tz)

        fixed_run_uuid = uuid.UUID("12345678-1234-5678-1234-567812345678")
        shared_job_id = f"ops-{uuid.uuid4().hex[:8]}"
        payload = {
            "request_id": shared_job_id,
            "dry_run": False,
            "targets": [],
            "archive": {"enabled": True, "mode": "internal"},
        }

        with patch("specdb.ops.jobs_support.datetime", _FrozenDatetime):
            with patch("specdb.ops.jobs_support.uuid.uuid4", return_value=fixed_run_uuid):
                resp = client.post("/a/db/ops/snapshot-and-compact", json=payload)
                self.assertEqual(resp.status_code, 202)
                resp = client.post("/b/db/ops/snapshot-and-compact", json=payload)
                self.assertEqual(resp.status_code, 202)

                job_a = _wait_job("/a/db", shared_job_id, "verified")
                job_b = _wait_job("/b/db", shared_job_id, "verified")

        self.assertIsNotNone(job_a["snapshot_id"])
        self.assertIsNotNone(job_b["snapshot_id"])
        self.assertNotEqual(job_a["snapshot_id"], job_b["snapshot_id"])
        self.assertIsNotNone(job_a["summary"]["archive_id"])
        self.assertIsNotNone(job_b["summary"]["archive_id"])
        self.assertNotEqual(job_a["summary"]["archive_id"], job_b["summary"]["archive_id"])

    def test_shutdown_db_module_closes_executors(self):
        app_shutdown = Flask("db_shutdown_test")
        app_shutdown.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_shutdown.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_shutdown.config["TESTING"] = True
        init_db_module(
            app_shutdown,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/s/db",
                blueprint_name="dbs",
            ),
        )
        client = app_shutdown.test_client()

        # 先触发一次异步 ops 路径，确保 executor 和状态已创建。
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp = client.post(
            "/s/db/ops/snapshot-and-compact",
            json={"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)

        # 等待任务完成，避免 shutdown 时出现竞态。
        deadline = time.time() + 2.0
        while time.time() < deadline:
            jr = client.get(f"/s/db/ops/jobs/{job_id}")
            jb = jr.get_json()
            if jr.status_code == 200 and jb["data"]["state"] in {"verified", "failed"}:
                break
            time.sleep(0.05)

        shutdown_db_module(app_shutdown, wait=True)
        states = app_shutdown.extensions["db_module"]["ops_states"]
        self.assertEqual(states, {})

        next_job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp = client.post(
            "/s/db/ops/snapshot-and-compact",
            json={"request_id": next_job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)
        deadline = time.time() + 2.0
        while time.time() < deadline:
            jr = client.get(f"/s/db/ops/jobs/{next_job_id}")
            jb = jr.get_json()
            if jr.status_code == 200 and jb["data"]["state"] == "verified":
                break
            time.sleep(0.05)
        else:
            self.fail("job did not recover after shutdown")

    def test_configured_instance_id_remains_unique_per_process(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_shared_owner_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        apps: list[Flask] = []

        def _build_app(name: str) -> Flask:
            app_obj = Flask(name)
            app_obj.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
            app_obj.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
            app_obj.config["DB_MODULE_INSTANCE_ID"] = "shared-owner"
            app_obj.config["TESTING"] = True
            init_db_module(
                app_obj,
                options=DBModuleOptions(
                    register_blueprint=True,
                    init_tables=True,
                    db_url_prefix=f"/{name}/db",
                    blueprint_name="dbs",
                ),
            )
            apps.append(app_obj)
            return app_obj

        def _cleanup_apps():
            for app_obj in reversed(apps):
                shutdown_db_module(app_obj, wait=True)
                with app_obj.app_context():
                    db.session.remove()
                    db.engine.dispose()
            if sqlite_path.exists():
                sqlite_path.unlink()

        self.addCleanup(_cleanup_apps)

        app_a = _build_app("db_shared_owner_a")
        app_b = _build_app("db_shared_owner_b")

        owner_a = ops_db_routes_module._resolve_ops_instance_id(app_a)
        owner_b = ops_db_routes_module._resolve_ops_instance_id(app_b)
        self.assertNotEqual(owner_a, owner_b)
        self.assertTrue(owner_a.startswith("shared-owner:"))
        self.assertTrue(owner_b.startswith("shared-owner:"))

        with app_a.app_context():
            ops_jobs_store.create_pending_job(
                "shared-owner-job",
                {
                    "request_id": "shared-owner-job",
                    "dry_run": True,
                    "targets": [],
                    "strategy": {},
                    "_scope_key": "dbs",
                },
                scope_key="dbs",
            )

        calls: list[dict[str, str | None]] = []

        def fake_worker(app_obj, job_id, scope_key=None, owner_id=None):
            calls.append(
                {
                    "app": app_obj.name,
                    "job_id": job_id,
                    "scope_key": scope_key,
                    "owner_id": owner_id,
                }
            )

        with patch.object(ops_job_runtime_module, "_run_snapshot_and_compact_job", side_effect=fake_worker):
            with app_a.app_context():
                first = ops_db_routes_module._submit_ops_job_if_needed(
                    "shared-owner-job",
                    app_obj=app_a,
                    scope_key="dbs",
                )
            with app_b.app_context():
                second = ops_db_routes_module._submit_ops_job_if_needed(
                    "shared-owner-job",
                    app_obj=app_b,
                    scope_key="dbs",
                )

        self.assertTrue(first)
        self.assertFalse(second)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["owner_id"], owner_a)

    def test_active_ops_job_is_not_failed_by_second_instance_startup(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_multi_instance_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        release = threading.Event()
        blocked = threading.Event()

        def _cleanup_app(target_app: Flask | None):
            if target_app is None:
                return
            shutdown_db_module(target_app, wait=True)
            with target_app.app_context():
                db.session.remove()
                db.engine.dispose()

        app_primary = Flask("db_multi_instance_primary")
        app_primary.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_primary.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_primary.config["OPS_JOB_LEASE_SECONDS"] = 300
        app_primary.config["TESTING"] = True
        init_db_module(
            app_primary,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/m/db",
                blueprint_name="dbm",
            ),
        )
        client_primary = app_primary.test_client()
        app_secondary: Flask | None = None

        try:
            def _blocked_execute_compact_once(*, dry_run, targets, compact_before_dt, batch_size, scope_key=None, heartbeat=None):
                if heartbeat is not None:
                    heartbeat()
                blocked.set()
                self.assertTrue(release.wait(timeout=5.0))
                if heartbeat is not None:
                    heartbeat()
                return (
                    0,
                    0,
                    [],
                    {
                        "batch_size": int(batch_size),
                        "batches": 0,
                        "deleted_rows": 0,
                        "avg_batch_ms": 0,
                        "max_batch_ms": 0,
                        "log_batches": 0,
                        "history_batches": 0,
                        "log_deleted_rows": 0,
                        "history_deleted_rows": 0,
                        "archive_rows": 0,
                    },
                )

            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=_blocked_execute_compact_once):
                job_id = f"ops-{uuid.uuid4().hex[:8]}"
                resp = client_primary.post(
                    "/m/db/ops/snapshot-and-compact",
                    json={"request_id": job_id, "dry_run": True, "targets": []},
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(blocked.wait(timeout=2.0))

                app_secondary = Flask("db_multi_instance_secondary")
                app_secondary.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
                app_secondary.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
                app_secondary.config["OPS_JOB_LEASE_SECONDS"] = 300
                app_secondary.config["TESTING"] = True
                init_db_module(
                    app_secondary,
                    options=DBModuleOptions(
                        register_blueprint=True,
                        init_tables=True,
                        db_url_prefix="/m/db",
                        blueprint_name="dbm",
                    ),
                )
                client_secondary = app_secondary.test_client()

                job_body = client_secondary.get(f"/m/db/ops/jobs/{job_id}").get_json()["data"]
                self.assertIn(job_body["state"], {"pending", "snapshot_done", "compact_done"})
                self.assertIsNone(job_body["error_code"])

                release.set()

            deadline = time.time() + 3.0
            while time.time() < deadline:
                body = client_primary.get(f"/m/db/ops/jobs/{job_id}").get_json()["data"]
                if body["state"] == "verified":
                    break
                time.sleep(0.05)
            else:
                self.fail("active job did not finish after secondary startup")
        finally:
            release.set()
            _cleanup_app(app_secondary)
            _cleanup_app(app_primary)
            if sqlite_path.exists():
                sqlite_path.unlink()

    def test_job_lookup_does_not_fail_active_job_after_lease_gap(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_lookup_gap_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        app_lookup = Flask("db_lookup_gap")
        app_lookup.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_lookup.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_lookup.config["TESTING"] = True
        init_db_module(
            app_lookup,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/g/db",
                blueprint_name="dbg",
            ),
        )
        client = app_lookup.test_client()
        release = threading.Event()
        entered = threading.Event()

        def _cleanup_lookup_app():
            release.set()
            shutdown_db_module(app_lookup, wait=True)
            with app_lookup.app_context():
                db.session.remove()
                db.engine.dispose()
            if sqlite_path.exists():
                sqlite_path.unlink()

        self.addCleanup(_cleanup_lookup_app)

        def _blocked_execute_compact_once(*, dry_run, targets, compact_before_dt, batch_size, scope_key=None, heartbeat=None):
            entered.set()
            self.assertTrue(release.wait(timeout=5.0))
            return (
                0,
                0,
                [],
                {
                    "batch_size": int(batch_size),
                    "batches": 0,
                    "deleted_rows": 0,
                    "avg_batch_ms": 0,
                    "max_batch_ms": 0,
                    "log_batches": 0,
                    "history_batches": 0,
                    "log_deleted_rows": 0,
                    "history_deleted_rows": 0,
                    "archive_rows": 0,
                },
            )

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with patch("specdb.ops.job_state._ops_job_lease_seconds", return_value=1):
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=_blocked_execute_compact_once):
                resp = client.post(
                    "/g/db/ops/snapshot-and-compact",
                    json={"request_id": job_id, "dry_run": True, "targets": []},
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(entered.wait(timeout=2.0))
                time.sleep(1.2)

                job_body = client.get(f"/g/db/ops/jobs/{job_id}").get_json()["data"]
                self.assertIn(job_body["state"], {"pending", "snapshot_done", "compact_done"})
                self.assertIsNone(job_body["error_code"])

                release.set()

            deadline = time.time() + 3.0
            while time.time() < deadline:
                body = client.get(f"/g/db/ops/jobs/{job_id}").get_json()["data"]
                if body["state"] == "verified":
                    break
                time.sleep(0.05)
            else:
                self.fail("job lookup path should not fail active job after lease gap")

    def test_stale_worker_cannot_overwrite_recovered_job_state(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_stale_worker_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        app_stale = Flask("db_stale_worker")
        app_stale.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_stale.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_stale.config["OPS_JOB_LEASE_SECONDS"] = 300
        app_stale.config["TESTING"] = True
        init_db_module(
            app_stale,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/x/db",
                blueprint_name="dbx",
            ),
        )
        client = app_stale.test_client()

        release = threading.Event()
        entered = threading.Event()

        def _blocked_execute_compact_once(*, dry_run, targets, compact_before_dt, batch_size, scope_key=None, heartbeat=None):
            if heartbeat is not None:
                heartbeat()
            entered.set()
            self.assertTrue(release.wait(timeout=5.0))
            return (
                0,
                0,
                [],
                {
                    "batch_size": int(batch_size),
                    "batches": 0,
                    "deleted_rows": 0,
                    "avg_batch_ms": 0,
                    "max_batch_ms": 0,
                    "log_batches": 0,
                    "history_batches": 0,
                    "log_deleted_rows": 0,
                    "history_deleted_rows": 0,
                    "archive_rows": 0,
                },
            )

        try:
            job_id = f"ops-{uuid.uuid4().hex[:8]}"
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=_blocked_execute_compact_once):
                resp = client.post(
                    "/x/db/ops/snapshot-and-compact",
                    json={"request_id": job_id, "dry_run": True, "targets": []},
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(entered.wait(timeout=2.0))

                with app_stale.app_context():
                    recoverable = ops_jobs_store.get_recoverable_job(job_id, scope_key="dbx")
                    self.assertIsNotNone(recoverable)
                    claimed = ops_db_routes_module._mark_ops_job_failed(
                        job_id,
                        scope_key="dbx",
                        error_code="DB_OPS_RECOVERY_REQUIRED",
                        failed_stage="test_takeover",
                        last_error="simulated stale takeover",
                        expected_owner_id=recoverable.get("owner_id"),
                        expected_states=(str(recoverable["state"]),),
                        expected_lease_expires_at=recoverable.get("lease_expires_at"),
                    )
                    self.assertTrue(claimed)

                failed_job = client.get(f"/x/db/ops/jobs/{job_id}").get_json()["data"]
                self.assertEqual(failed_job["state"], "failed")
                self.assertEqual(failed_job["error_code"], "DB_OPS_RECOVERY_REQUIRED")
                self.assertEqual(failed_job["summary"]["failed_stage"], "test_takeover")

                release.set()

            deadline = time.time() + 3.0
            while time.time() < deadline:
                final_job = client.get(f"/x/db/ops/jobs/{job_id}").get_json()["data"]
                if final_job["state"] == "failed":
                    self.assertEqual(final_job["error_code"], "DB_OPS_RECOVERY_REQUIRED")
                    self.assertEqual(final_job["summary"]["failed_stage"], "test_takeover")
                    break
                time.sleep(0.05)
            else:
                self.fail("stale worker overwrote recovered failure state")
        finally:
            release.set()
            shutdown_db_module(app_stale, wait=True)
            with app_stale.app_context():
                db.session.remove()
                db.engine.dispose()
            if sqlite_path.exists():
                sqlite_path.unlink()

    def test_retry_cannot_duplicate_archive_side_effects_from_stale_worker(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_retry_archive_guard_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        release = threading.Event()
        entered = threading.Event()
        retry_result: dict[str, object] = {}

        def _cleanup_app(target_app: Flask | None):
            if target_app is None:
                return
            shutdown_db_module(target_app, wait=True)
            with target_app.app_context():
                db.session.remove()
                db.engine.dispose()

        app_primary = Flask("db_retry_archive_primary")
        app_primary.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_primary.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_primary.config["TESTING"] = True
        init_db_module(
            app_primary,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/x/db",
                blueprint_name="dbx",
            ),
        )
        client_primary = app_primary.test_client()

        app_secondary = Flask("db_retry_archive_secondary")
        app_secondary.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_secondary.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_secondary.config["TESTING"] = True
        init_db_module(
            app_secondary,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/x/db",
                blueprint_name="dbx",
            ),
        )

        try:
            table_name = f"retry_archive_guard_{uuid.uuid4().hex[:10]}"
            resp = client_primary.post(
                "/x/db/table",
                json={
                    "spec": {
                        "action": "table.define",
                        "table": table_name,
                        "payload": {
                            "schema": {
                                "id": {"type": "int", "primary": True, "auto_increment": True},
                                "name": {"type": "str", "nullable": False},
                            },
                            "module_options": {
                                "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                            },
                        },
                        "options": {},
                    }
                },
            )
            self.assertEqual(resp.status_code, 200)
            client_primary.post(
                "/x/db/data",
                json={
                    "spec": {
                        "action": "data.insert",
                        "table": table_name,
                        "payload": {"data": {"name": "v1"}},
                        "options": {},
                    }
                },
            )
            client_primary.post(
                "/x/db/data",
                json={
                    "spec": {
                        "action": "data.update",
                        "table": table_name,
                        "payload": {"query": {"id": 1}, "data": {"name": "v2"}},
                        "options": {},
                    }
                },
            )

            real_append_archive_items = ops_archive_store_module.append_archive_items

            def blocking_append_archive_items(*args, **kwargs):
                if not entered.is_set():
                    entered.set()
                    self.assertTrue(release.wait(timeout=5.0))
                return real_append_archive_items(*args, **kwargs)

            def _call_retry():
                client_secondary = app_secondary.test_client()
                retry_resp = client_secondary.post(f"/x/db/ops/jobs/{job_id}/retry", json={})
                retry_result["status_code"] = retry_resp.status_code
                retry_result["body"] = retry_resp.get_json() if retry_resp.is_json else retry_resp.get_data(as_text=True)

            job_id = f"ops-{uuid.uuid4().hex[:8]}"
            with patch("specdb.ops.job_state._ops_job_lease_seconds", return_value=1):
                with patch("specdb.ops_archive_store.append_archive_items", side_effect=blocking_append_archive_items):
                    resp = client_primary.post(
                        "/x/db/ops/snapshot-and-compact",
                        json={
                            "request_id": job_id,
                            "dry_run": False,
                            "targets": [table_name],
                            "archive": {"enabled": True, "mode": "internal"},
                        },
                    )
                    self.assertEqual(resp.status_code, 202)
                    self.assertTrue(entered.wait(timeout=2.0))
                    time.sleep(1.2)

                    retry_thread = threading.Thread(target=_call_retry, name="retry-side-effect-guard")
                    retry_thread.start()
                    time.sleep(0.2)
                    release.set()
                    retry_thread.join(timeout=5.0)
                    self.assertFalse(retry_thread.is_alive())

            deadline = time.time() + 5.0
            final_job = None
            while time.time() < deadline:
                job_resp = client_primary.get(f"/x/db/ops/jobs/{job_id}")
                final_job = job_resp.get_json()["data"]
                if final_job["state"] == "verified":
                    break
                time.sleep(0.05)
            else:
                self.fail("job did not finish after guarded retry attempt")

            self.assertEqual(retry_result["status_code"], 409)
            self.assertEqual(retry_result["body"]["error"]["code"], "DB_OPS_CONFLICT")
            self.assertIsNotNone(final_job["summary"]["archive_id"])

            with app_primary.app_context():
                archive_rows = db.session.execute(
                    db.text("SELECT archive_id, item_count FROM db_ops_archives ORDER BY created_at ASC")
                ).mappings().all()
                self.assertEqual(len(archive_rows), 1)
                archive_id = str(archive_rows[0]["archive_id"])
                self.assertEqual(final_job["summary"]["archive_id"], archive_id)
                self.assertEqual(int(archive_rows[0]["item_count"] or 0), 2)
                self.assertEqual(get_archive_item_count(archive_id), 2)
                remaining_logs = int(db.session.execute(db.text("SELECT count(*) FROM db_change_log")).scalar() or 0)
                self.assertEqual(remaining_logs, 0)
        finally:
            release.set()
            _cleanup_app(app_secondary)
            _cleanup_app(app_primary)
            if sqlite_path.exists():
                sqlite_path.unlink()

    def test_ops_submit_failure_marks_job_failed_and_returns_json(self):
        app_submit = Flask("db_submit_failure")
        app_submit.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_submit.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_submit.config["TESTING"] = True
        init_db_module(
            app_submit,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/f/db",
                blueprint_name="dbf",
            ),
        )
        client = app_submit.test_client()

        class _BrokenExecutor:
            def submit(self, *args, **kwargs):
                raise RuntimeError("executor unavailable")

        with app_submit.app_context():
            state = ops_db_routes_module._get_ops_state(app_submit, "dbf")
            state["executor"] = _BrokenExecutor()

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp = client.post(
            "/f/db/ops/snapshot-and-compact",
            json={"request_id": job_id, "dry_run": True, "targets": []},
        )
        body = resp.get_json()
        self.assertEqual(resp.status_code, 503)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_SUBMIT_FAILED")

        job = client.get(f"/f/db/ops/jobs/{job_id}").get_json()["data"]
        self.assertEqual(job["state"], "failed")
        self.assertEqual(job["error_code"], "DB_OPS_SUBMIT_FAILED")
        self.assertEqual(job["summary"]["failed_stage"], "submit")

    def test_ops_retry_submit_failure_marks_job_failed_and_returns_json(self):
        app_submit = Flask("db_retry_submit_failure")
        app_submit.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_submit.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_submit.config["TESTING"] = True
        init_db_module(
            app_submit,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/f/db",
                blueprint_name="dbf",
            ),
        )
        client = app_submit.test_client()

        class _BrokenExecutor:
            def submit(self, *args, **kwargs):
                raise RuntimeError("executor unavailable")

        with app_submit.app_context():
            state = ops_db_routes_module._get_ops_state(app_submit, "dbf")
            state["executor"] = _BrokenExecutor()

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        create_resp = client.post(
            "/f/db/ops/snapshot-and-compact",
            json={"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(create_resp.status_code, 503)

        retry_resp = client.post(f"/f/db/ops/jobs/{job_id}/retry", json={})
        retry_body = retry_resp.get_json()
        self.assertEqual(retry_resp.status_code, 503)
        self.assertFalse(retry_body["success"])
        self.assertEqual(retry_body["error"]["code"], "DB_OPS_SUBMIT_FAILED")

        job = client.get(f"/f/db/ops/jobs/{job_id}").get_json()["data"]
        self.assertEqual(job["state"], "failed")
        self.assertEqual(job["error_code"], "DB_OPS_SUBMIT_FAILED")
        self.assertEqual(job["summary"]["failed_stage"], "submit")

    def test_incomplete_ops_jobs_are_failed_on_startup_and_can_retry(self):
        sqlite_dir = BASE_DIR / ".tmp" / "tests"
        sqlite_dir.mkdir(parents=True, exist_ok=True)
        sqlite_path = sqlite_dir / f"ops_recovery_{uuid.uuid4().hex}.sqlite3"
        if sqlite_path.exists():
            sqlite_path.unlink()

        app_before = Flask("db_recovery_before")
        app_before.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_before.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_before.config["TESTING"] = True
        init_db_module(
            app_before,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/r/db",
                blueprint_name="dbr",
            ),
        )
        recovery_jobs = [
            ("ops-recovery-pending", "pending", None),
            ("ops-recovery-snapshot", "snapshot_done", "snapshot-startup"),
            ("ops-recovery-compact", "compact_done", "snapshot-compact"),
        ]
        with app_before.app_context():
            for job_id, state, snapshot_id in recovery_jobs:
                ops_jobs_store.create_pending_job(
                    job_id,
                    {
                        "request_id": job_id,
                        "dry_run": True,
                        "targets": [],
                        "archive": {"enabled": False, "mode": "internal"},
                        "strategy": {},
                        "_scope_key": "dbr",
                    },
                )
                if state in {"snapshot_done", "compact_done"}:
                    ops_jobs_store.update_job_state(
                        job_id,
                        "snapshot_done",
                        snapshot_id=snapshot_id,
                        error_code=None,
                    )
                if state == "compact_done":
                    ops_jobs_store.update_job_state(
                        job_id,
                        "compact_done",
                        snapshot_id=snapshot_id,
                        error_code=None,
                    )
        shutdown_db_module(app_before, wait=True)
        with app_before.app_context():
            db.session.remove()
            db.engine.dispose()

        app_after = Flask("db_recovery_after")
        app_after.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{sqlite_path.as_posix()}"
        app_after.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_after.config["TESTING"] = True
        init_db_module(
            app_after,
            options=DBModuleOptions(
                register_blueprint=True,
                init_tables=True,
                db_url_prefix="/r/db",
                blueprint_name="dbr",
            ),
        )
        client = app_after.test_client()

        for job_id, previous_state, _ in recovery_jobs:
            resp = client.get(f"/r/db/ops/jobs/{job_id}")
            body = resp.get_json()
            self.assertEqual(resp.status_code, 200)
            self.assertEqual(body["data"]["state"], "failed")
            self.assertEqual(body["data"]["error_code"], "DB_OPS_RECOVERY_REQUIRED")
            self.assertEqual(body["data"]["summary"]["failed_stage"], "startup_recovery")
            self.assertIn(previous_state, body["data"]["summary"]["last_error"])
            self.assertEqual(body["data"]["summary"]["context"]["request_id"], job_id)
            self.assertEqual(body["data"]["summary"]["context"]["scope_key"], "dbr")

        for job_id, _, _ in recovery_jobs:
            resp = client.post(f"/r/db/ops/jobs/{job_id}/retry", json={})
            body = resp.get_json()
            self.assertEqual(resp.status_code, 202)
            self.assertTrue(body["success"])
            deadline = time.time() + 2.0
            while time.time() < deadline:
                retry_resp = client.get(f"/r/db/ops/jobs/{job_id}")
                retry_body = retry_resp.get_json()
                if retry_resp.status_code == 200 and retry_body["data"]["state"] == "verified":
                    break
                time.sleep(0.05)
            else:
                self.fail(f"recovered job did not reach verified: {job_id}")

        shutdown_db_module(app_after, wait=True)
        with app_after.app_context():
            db.session.remove()
            db.engine.dispose()
        if sqlite_path.exists():
            sqlite_path.unlink()

    def test_ops_retry_failed_job(self):
        table_name = self._table_name("retry_failed")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0
        try:
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=RuntimeError("compact boom")):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": True,
                        "targets": [table_name],
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                data = self._wait_for_job_state(job_id, "failed")
                self.assertEqual(data["state"], "failed")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        resp = self.client.post(f"/api/db/ops/jobs/{job_id}/retry", json={})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["job_id"], job_id)
        self.assertEqual(body["data"]["state"], "pending")

        data = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(data["state"], "verified")
        self._drop_table(table_name)

    def test_ops_retry_non_failed_job_conflict(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        self._wait_for_job_state(job_id, "verified")

        resp = self.client.post(f"/api/db/ops/jobs/{job_id}/retry", json={})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 409)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_CONFLICT")

    def test_ops_retry_rejects_unexpected_request_fields(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        self._wait_for_job_state(job_id, "verified")

        retry_resp = self.client.post(f"/api/db/ops/jobs/{job_id}/retry", json={"force": True})
        retry_body = retry_resp.get_json()
        self.assertEqual(retry_resp.status_code, 400)
        self.assertFalse(retry_body["success"])
        self.assertEqual(retry_body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_retry_failed_job_clears_previous_summary(self):
        table_name = self._table_name("retry_summary_clear")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0
        try:
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=RuntimeError("compact boom")):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": True,
                        "targets": [table_name],
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                data = self._wait_for_job_state(job_id, "failed")
                self.assertIn("summary", data)
                self.assertEqual(data["summary"]["error_code"], "DB_OPS_SNAPSHOT_COMPACT_ERROR")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        with app.app_context():
            retried = ops_jobs_store.retry_failed_job(job_id)
            self.assertIsNotNone(retried)
            self.assertEqual(retried["state"], "pending")
            current = ops_jobs_store.get_job(job_id)
            self.assertIsNotNone(current)
            self.assertNotIn("summary", current)

        self._drop_table(table_name)

    def test_store_rejects_corrupted_job_summary_json(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with app.app_context():
            created = ops_jobs_store.create_pending_job(
                job_id,
                {
                    "request_id": job_id,
                    "dry_run": True,
                    "targets": [],
                    "archive": {"enabled": False, "mode": "internal"},
                    "strategy": {},
                    "_scope_key": "db",
                },
                scope_key="db",
            )
            self.assertEqual(created["state"], "pending")
            ops_jobs_store.update_job_summary(job_id, {"ok": True}, scope_key="db")
            internal_job_id = ops_jobs_store.resolve_job_storage_id(job_id, scope_key="db")
            db.session.execute(
                db.text("UPDATE db_ops_job_results SET summary_json = :summary_json WHERE job_id = :job_id"),
                {"summary_json": "{bad-json", "job_id": internal_job_id},
            )
            db.session.commit()

            with self.assertRaises(RuntimeError) as ctx:
                ops_jobs_store.get_job(job_id, scope_key="db")
        self.assertIn("summary_json", str(ctx.exception))

    def test_store_rejects_corrupted_job_request_json(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with app.app_context():
            created = ops_jobs_store.create_pending_job(
                job_id,
                {
                    "request_id": job_id,
                    "dry_run": True,
                    "targets": [],
                    "archive": {"enabled": False, "mode": "internal"},
                    "strategy": {},
                    "_scope_key": "db",
                },
                scope_key="db",
            )
            self.assertEqual(created["state"], "pending")
            internal_job_id = ops_jobs_store.resolve_job_storage_id(job_id, scope_key="db")
            db.session.execute(
                db.text("UPDATE db_ops_jobs SET request_json = :request_json WHERE job_id = :job_id"),
                {"request_json": "{bad-json", "job_id": internal_job_id},
            )
            db.session.commit()

            with self.assertRaises(RuntimeError) as ctx:
                ops_jobs_store.get_job(job_id, scope_key="db")
        self.assertIn("request_json", str(ctx.exception))

    def test_archive_store_rejects_corrupted_metadata_json(self):
        archive_id = f"archive-{uuid.uuid4().hex[:8]}"
        with app.app_context():
            ops_archive_store_module.create_archive(
                archive_id,
                job_id="job-1",
                request_id="request-1",
                snapshot_id=None,
                metadata={"mode": "internal"},
            )
            db.session.execute(
                db.text("UPDATE db_ops_archives SET metadata_json = :metadata_json WHERE archive_id = :archive_id"),
                {"metadata_json": "{bad-json", "archive_id": archive_id},
            )
            db.session.commit()

            with self.assertRaises(RuntimeError) as ctx:
                get_archive(archive_id)
        self.assertIn("metadata_json", str(ctx.exception))

    def test_create_pending_job_preserves_integrity_error_cause_when_insert_fails(self):
        class _BeginContext:
            def __init__(self, conn):
                self._conn = conn

            def __enter__(self):
                return self._conn

            def __exit__(self, exc_type, exc, tb):
                return False

        class _InsertConn:
            def __init__(self, error):
                self._error = error

            def execute(self, *args, **kwargs):
                raise self._error

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        integrity_error = IntegrityError("INSERT INTO db_ops_jobs", {}, RuntimeError("db insert boom"))
        with app.app_context():
            ops_jobs_store.ensure_ops_jobs_table()
            with patch("specdb.ops_jobs_store._load_job_row", return_value=None):
                with patch.object(
                    ops_jobs_store.db.engine,
                    "begin",
                    return_value=_BeginContext(_InsertConn(integrity_error)),
                ):
                    with self.assertRaises(RuntimeError) as ctx:
                        ops_jobs_store.create_pending_job(
                            job_id,
                            {
                                "request_id": job_id,
                                "dry_run": True,
                                "targets": [],
                                "archive": {"enabled": False, "mode": "internal"},
                                "strategy": {},
                                "_scope_key": "db",
                            },
                            scope_key="db",
                        )
        self.assertEqual(str(ctx.exception), f"failed to create pending job: {job_id}")
        self.assertIs(ctx.exception.__cause__, integrity_error)

    def test_store_rejects_illegal_ops_job_state_transitions(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with app.app_context():
            created = ops_jobs_store.create_pending_job(
                job_id,
                {
                    "request_id": job_id,
                    "dry_run": True,
                    "targets": [],
                    "archive": {"enabled": False, "mode": "internal"},
                    "strategy": {},
                    "_scope_key": "db",
                },
                scope_key="db",
            )
            self.assertEqual(created["state"], "pending")

            illegal_verified = ops_jobs_store.update_job_state(job_id, "verified", scope_key="db")
            self.assertIsNone(illegal_verified)
            self.assertEqual(ops_jobs_store.get_job(job_id, scope_key="db")["state"], "pending")

            snapshot = ops_jobs_store.update_job_state(
                job_id,
                "snapshot_done",
                scope_key="db",
                snapshot_id="snapshot-1",
            )
            self.assertIsNotNone(snapshot)
            self.assertEqual(snapshot["state"], "snapshot_done")

            illegal_pending = ops_jobs_store.update_job_state(job_id, "pending", scope_key="db")
            self.assertIsNone(illegal_pending)
            self.assertEqual(ops_jobs_store.get_job(job_id, scope_key="db")["state"], "snapshot_done")

            compact_done = ops_jobs_store.update_job_state(
                job_id,
                "compact_done",
                scope_key="db",
                snapshot_id="snapshot-1",
            )
            self.assertIsNotNone(compact_done)
            self.assertEqual(compact_done["state"], "compact_done")

            verified = ops_jobs_store.update_job_state_with_summary(
                job_id,
                scope_key="db",
                state="verified",
                snapshot_id="snapshot-1",
                summary={"ok": True},
                owner_id=None,
                lease_expires_at=None,
            )
            self.assertIsNotNone(verified)
            self.assertEqual(verified["state"], "verified")

            illegal_failed = ops_jobs_store.update_job_state_with_summary(
                job_id,
                scope_key="db",
                state="failed",
                error_code="DB_OPS_SNAPSHOT_COMPACT_ERROR",
                owner_id=None,
                lease_expires_at=None,
                summary={"failed_stage": "compact", "last_error": "should be rejected"},
            )
            self.assertIsNone(illegal_failed)
            current = ops_jobs_store.get_job(job_id, scope_key="db")
            self.assertEqual(current["state"], "verified")
            self.assertTrue(current["summary"]["ok"])
            self.assertEqual(current["summary"]["context"]["request_id"], job_id)
            self.assertEqual(current["summary"]["context"]["scope_key"], "db")

    def test_store_only_allows_retry_helper_to_return_failed_job_to_pending(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with app.app_context():
            created = ops_jobs_store.create_pending_job(
                job_id,
                {
                    "request_id": job_id,
                    "dry_run": True,
                    "targets": [],
                    "archive": {"enabled": False, "mode": "internal"},
                    "strategy": {},
                    "_scope_key": "db",
                },
                scope_key="db",
            )
            self.assertEqual(created["state"], "pending")

            failed = ops_jobs_store.update_job_state_with_summary(
                job_id,
                scope_key="db",
                state="failed",
                error_code="DB_OPS_SNAPSHOT_COMPACT_ERROR",
                owner_id=None,
                lease_expires_at=None,
                summary={"failed_stage": "compact", "last_error": "boom"},
            )
            self.assertIsNotNone(failed)
            self.assertEqual(failed["state"], "failed")

            direct_pending = ops_jobs_store.update_job_state(job_id, "pending", scope_key="db")
            self.assertIsNone(direct_pending)
            self.assertEqual(ops_jobs_store.get_job(job_id, scope_key="db")["state"], "failed")

            retried = ops_jobs_store.retry_failed_job(job_id, scope_key="db")
            self.assertIsNotNone(retried)
            self.assertEqual(retried["state"], "pending")

            current = ops_jobs_store.get_job(job_id, scope_key="db")
            self.assertEqual(current["state"], "pending")
            self.assertNotIn("summary", current)

    def test_ops_retry_rejects_invalid_job_id_and_uses_not_found_for_missing(self):
        resp = self.client.post("/api/db/ops/jobs/bad job id/retry", json={})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

        resp = self.client.post("/api/db/ops/jobs/missing-job-001/retry", json={})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_ops_snapshot_and_compact_invalid_operator(self):
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "operator": ""},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_snapshot_and_compact_rejects_invalid_request_id(self):
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": "bad id with spaces", "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

    def test_ops_snapshot_and_compact_normalizes_and_validates_targets(self):
        users_table = self._table_name("users")
        orders_table = self._table_name("orders")
        self._define_table(users_table)
        self._define_table(orders_table)
        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": [f" {users_table} ", users_table, orders_table]},
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])
        data = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(data["request"]["targets"], [users_table, orders_table])

        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": f"ops-{uuid.uuid4().hex[:8]}", "dry_run": True, "targets": ["bad-target!"]},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")

        resp, body = self._post(
            "/api/db/ops/snapshot-and-compact",
            {"request_id": f"ops-{uuid.uuid4().hex[:8]}", "dry_run": True, "targets": ["missing_table"]},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_REQUEST_INVALID")
        self.assertEqual(body["error"]["details"]["missing_targets"], ["missing_table"])

        self._drop_table(users_table)
        self._drop_table(orders_table)

    def test_ops_snapshot_and_compact_retries_once_on_compact_failure(self):
        from sqlalchemy import inspect as sa_inspect

        table_name = self._table_name("compact_retry")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        call_counter = {"n": 0}

        def flaky_inspect(engine):
            call_counter["n"] += 1
            if call_counter["n"] == 1:
                raise RuntimeError("temporary compact failure")
            return sa_inspect(engine)

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        with patch("specdb.ops.compact_engine.inspect", new=flaky_inspect):
            resp, body = self._post(
                "/api/db/ops/snapshot-and-compact",
                {
                    "request_id": job_id,
                    "dry_run": True,
                    "targets": [table_name],
                    "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                },
            )
            self.assertEqual(resp.status_code, 202)
            self.assertTrue(body["success"])
            data = self._wait_for_job_state(job_id, "verified")

        self.assertEqual(data["summary"]["retry_count"], 1)
        self.assertEqual(data["summary"]["max_retries"], 1)
        self.assertIsNone(data["summary"]["error_code"])
        self.assertIsNone(data["summary"]["last_error"])
        self.assertIsNone(data["summary"]["failed_stage"])
        self._drop_table(table_name)

    def test_ops_snapshot_and_compact_fails_when_retries_exhausted(self):
        table_name = self._table_name("compact_fail")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app.config["OPS_COMPACT_MAX_RETRIES"] = 0
        try:
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=RuntimeError("compact boom")):
                resp, body = self._post(
                    "/api/db/ops/snapshot-and-compact",
                    {
                        "request_id": job_id,
                        "dry_run": True,
                        "targets": [table_name],
                        "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
                    },
                )
                self.assertEqual(resp.status_code, 202)
                self.assertTrue(body["success"])
                data = self._wait_for_job_state(job_id, "failed")
        finally:
            app.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        self.assertEqual(data["summary"]["retry_count"], 0)
        self.assertEqual(data["summary"]["max_retries"], 0)
        self.assertEqual(data["summary"]["error_code"], "DB_OPS_SNAPSHOT_COMPACT_ERROR")
        self.assertEqual(data["summary"]["failed_stage"], "compact")
        self.assertIn("compact boom", data["summary"]["last_error"])
        self.assertIsNotNone(data["summary"]["last_error_at"])
        self._drop_table(table_name)
