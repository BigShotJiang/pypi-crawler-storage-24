"""按主题拆分后的 DB API 数据层测试。"""

import db_api_test_base as support
from db_api_test_base import *


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()

class DBApiDataTestCase(DBApiTestBase):
    def test_table_actions_and_data_crud(self):
        table_name = self._table_name("users")
        self._define_table(table_name)

        # 验证 table.list 动作。
        resp, body = self._post(
            "/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}}
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIn(table_name, body["data"])

        # 验证 table.describe 动作。
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        col_keys = [c["key"] for c in body["data"]["columns"]]
        self.assertIn("id", col_keys)
        self.assertIn("name", col_keys)

        # 验证 data.insert 动作。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "Tom"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["affected_rows"], 1)

        # 验证 data.select，include_total=true。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name$like": "T%"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIn("total", body["data"])
        self.assertGreaterEqual(body["data"]["total"], 1)

        # 验证 data.select，include_total=false 时 total 应为可选或省略。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "Tom"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn("total", body["data"])

        # 验证 data.update 动作。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "Tom2"}, "query": {"name": "Tom"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertGreaterEqual(body["data"]["affected_rows"], 1)

        # 验证 data.delete 动作。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": table_name,
                    "payload": {"query": {"name": "Tom2"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertGreaterEqual(body["data"]["affected_rows"], 1)

        self._drop_table(table_name)

    def test_table_list_hides_internal_tables(self):
        table_name = self._table_name("visible")
        self._define_table(table_name)

        resp, body = self._post(
            "/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}}
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertIn(table_name, body["data"])
        self.assertNotIn("db_table_options", body["data"])
        self.assertNotIn("db_change_log", body["data"])

        self._drop_table(table_name)

    def test_public_routes_reject_internal_table_access(self):
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": "db_table_options",
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": "db_change_log",
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_datetime_fields_accept_iso8601_strings(self):
        table_name = self._table_name("dt")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True},
                            "scheduled_at": {"type": "datetime", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"id": 1, "scheduled_at": "2026-03-07T09:00:00+00:00"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"id": 1}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["items"][0]["scheduled_at"], "2026-03-07T09:00:00")

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {
                        "data": {"scheduled_at": "2026-03-07T10:30:00Z"},
                        "query": {"id": 1},
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"id": 1}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"][0]["scheduled_at"], "2026-03-07T10:30:00")

        with app.app_context():
            table = Table(table_name, MetaData(), autoload_with=db.engine)
            stored = db.session.execute(
                select(table.c["scheduled_at"]).where(table.c["id"] == 1)
            ).scalar_one()
        self.assertIsNotNone(stored)
        self.assertEqual(stored.isoformat(), "2026-03-07T10:30:00")

        self._drop_table(table_name)

    def test_table_define_defaults_are_applied_on_insert(self):
        table_name = self._table_name("defaults")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                            "status": {"type": "str", "nullable": False, "default": "draft"},
                            "enabled": {"type": "bool", "nullable": False, "default": True},
                            "priority": {"type": "int", "nullable": False, "default": 5},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "hello"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        inserted_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"id": inserted_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        item = body["data"]["items"][0]
        self.assertEqual(item["status"], "draft")
        self.assertTrue(item["enabled"])
        self.assertEqual(item["priority"], 5)

        self._drop_table(table_name)

    def test_data_select_serializes_external_decimal_and_date_columns(self):
        table_name = self._table_name("ext_types")
        with app.app_context():
            table = Table(
                table_name,
                MetaData(),
                Column("amount", Numeric(10, 2), primary_key=True),
                Column("settled_on", Date, nullable=False),
            )
            table.create(bind=db.engine)
            db.session.execute(
                table.insert().values(amount=Decimal("1.50"), settled_on=date(2026, 3, 7))
            )
            db.session.commit()

        try:
            resp, body = self._post(
                "/api/db/data",
                {
                    "spec": {
                        "action": "data.select",
                        "table": table_name,
                        "payload": {"query": {}},
                        "options": {},
                    }
                },
            )
            self.assertEqual(resp.status_code, 200)
            self.assertTrue(body["success"])
            self.assertEqual(body["data"]["items"], [{"amount": "1.50", "settled_on": "2026-03-07"}])
        finally:
            with app.app_context():
                table = Table(table_name, MetaData(), autoload_with=db.engine)
                table.drop(bind=db.engine, checkfirst=True)

    def test_data_insert_returns_full_composite_primary_key(self):
        table_name = self._table_name("composite_pk")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "tenant_id": {"type": "int", "primary": True},
                            "user_id": {"type": "int", "primary": True},
                            "name": {"type": "str", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"tenant_id": 10, "user_id": 20, "name": "Tom"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertIsNone(body["data"]["inserted_id"])
        self.assertEqual(body["data"]["inserted_primary_key"], {"tenant_id": 10, "user_id": 20})

        self._drop_table(table_name)

    def test_table_alter_add_and_drop_columns(self):
        table_name = self._table_name("alter")
        self._define_table(table_name)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "add": {
                            "email": {"type": "str", "nullable": True, "default": "unknown@example.com"}
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["added_columns"], ["email"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        col_keys = [c["key"] for c in body["data"]["columns"]]
        self.assertIn("email", col_keys)

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "Tom", "email": "tom@example.com"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"drop": ["email"]},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["dropped_columns"], ["email"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        col_keys = [c["key"] for c in body["data"]["columns"]]
        self.assertNotIn("email", col_keys)

        self._drop_table(table_name)

    def test_table_alter_modify_updates_nullable_and_default(self):
        table_name = self._table_name("alter_modify")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "title": {"type": "str", "nullable": True, "length": 64},
                            "status": {"type": "str", "nullable": False, "length": 32},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"nullable": False, "type": "text"},
                            "status": {"default": "draft"},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertCountEqual(body["data"]["modified_columns"], ["title", "status"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        columns = {item["key"]: item for item in body["data"]["columns"]}
        self.assertFalse(columns["title"]["nullable"])
        self.assertIn("TEXT", columns["title"]["type"].upper())

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"status": "manual"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")
        self.assertEqual(body["error"]["details"], {"table": table_name})

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "hello"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        inserted_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"id": inserted_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"][0]["status"], "draft")

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"modify": {"status": {"default": {"drop": True}}}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "needs status"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")

        self._drop_table(table_name)

    def test_table_describe_returns_stable_column_contract(self):
        table_name = self._table_name("describe_contract")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "slug": {"type": "str", "nullable": False, "length": 64, "unique": True},
                            "status": {"type": "str", "nullable": False, "default": "draft"},
                            "enabled": {"type": "bool", "nullable": False, "default": True},
                        },
                        "indexes": [{"name": f"idx_{table_name}_status", "keys": ["status"], "unique": False}],
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 15}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["dialect"], "sqlite")
        self.assertEqual(body["data"]["change_tracking"]["strategy"], "update_with_compact_log")
        self.assertEqual(body["data"]["change_tracking"]["retention_days"], 15)
        columns = {item["key"]: item for item in body["data"]["columns"]}
        self.assertEqual(columns["status"]["default"], "draft")
        self.assertTrue(columns["status"]["has_default"])
        self.assertTrue(columns["status"]["indexed"])
        self.assertFalse(columns["status"]["unique"])
        self.assertEqual(columns["enabled"]["default"], True)
        self.assertTrue(columns["enabled"]["has_default"])
        self.assertTrue(columns["slug"]["unique"])
        self.assertFalse(columns["slug"]["contract_locked"])

    def test_table_alter_modify_updates_length_and_single_column_indexes(self):
        table_name = self._table_name("alter_modify_index")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "title": {"type": "str", "nullable": False, "length": 32},
                            "slug": {"type": "str", "nullable": False, "length": 32},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"length": 128, "index": True},
                            "slug": {"unique": True},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertCountEqual(body["data"]["modified_columns"], ["title", "slug"])

        with app.app_context():
            inspector = sa_inspect(db.engine)
            columns = {item["name"]: item for item in inspector.get_columns(table_name)}
            indexes = inspector.get_indexes(table_name)
            unique_constraints = inspector.get_unique_constraints(table_name)
        self.assertEqual(getattr(columns["title"]["type"], "length", None), 128)
        self.assertTrue(any(item["column_names"] == ["title"] and not item.get("unique", False) for item in indexes))
        self.assertTrue(any(item["column_names"] == ["slug"] for item in unique_constraints + indexes if item.get("unique", True)))

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "first", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "second", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"index": False},
                            "slug": {"unique": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "third", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with app.app_context():
            inspector = sa_inspect(db.engine)
            indexes = inspector.get_indexes(table_name)
            unique_constraints = inspector.get_unique_constraints(table_name)
        self.assertFalse(any(item["column_names"] == ["title"] and not item.get("unique", False) for item in indexes))
        self.assertFalse(any(item["column_names"] == ["slug"] for item in unique_constraints))
        self.assertFalse(any(item["column_names"] == ["slug"] and item.get("unique", False) for item in indexes))

        self._drop_table(table_name)

    def test_table_alter_modify_rejects_primary_key_column(self):
        table_name = self._table_name("alter_modify_pk")
        self._define_table(table_name)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"modify": {"id": {"nullable": False}}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 501)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_ACTION_NOT_SUPPORTED")

        self._drop_table(table_name)

    def test_table_alter_modify_rejects_append_only_tables(self):
        table_name = self._table_name("alter_append")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "title": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "append_only_versioned", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"modify": {"title": {"type": "text"}}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 501)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_ACTION_NOT_SUPPORTED")

        self._drop_table(table_name)

    def test_table_alter_rejects_drop_primary_key_column(self):
        table_name = self._table_name("alter_pk")
        self._define_table(table_name)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"drop": ["id"]},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        self._drop_table(table_name)

    def test_table_define_and_backup_preserve_relationship_metadata(self):
        source_table = self._table_name("rel_src")
        target_table = self._table_name("rel_dst")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": source_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "author_id": {
                                "type": "int",
                                "nullable": False,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "restrict",
                                    "on_update": "restrict",
                                },
                            },
                            "title": {"type": "str", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["relations_recorded"], ["author_id"])
        self.addCleanup(lambda: self._drop_table(source_table))
        self.addCleanup(lambda: self._drop_table(target_table))

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": source_table,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        relation = body["data"]["relations"]["author_id"]
        self.assertEqual(relation["target_table"], "users")
        self.assertEqual(relation["target_column"], "id")
        self.assertEqual(relation["kind"], "many_to_one")
        self.assertEqual(body["data"]["relation_summary"]["depends_on_tables"], ["users"])
        self.assertEqual(body["data"]["relation_summary"]["referenced_by_tables"], [])
        self.assertEqual(body["data"]["relation_summary"]["recommended_prerequisite_tables"], [])
        self.assertIn(source_table, body["data"]["recommended_table_order"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.backup",
                    "table": source_table,
                    "payload": {"target_table": target_table},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["copied_relationship_metadata"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": target_table,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIn("author_id", body["data"]["relations"])
        self.assertEqual(body["data"]["relations"]["author_id"]["target_table"], "users")

    def test_table_alter_add_and_drop_updates_relationship_metadata(self):
        table_name = self._table_name("rel_alter")
        self._define_table(table_name)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "add": {
                            "owner_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            }
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["relations_recorded"], ["owner_id"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIn("owner_id", body["data"]["relations"])
        self.assertEqual(body["data"]["relations"]["owner_id"]["on_delete"], "set_null")
        self.assertEqual(body["data"]["relation_summary"]["depends_on_tables"], ["users"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"drop": ["owner_id"]},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["relations_recorded"], [])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["relations"], {})
        self.assertEqual(body["data"]["relation_summary"]["depends_on_tables"], [])

        self._drop_table(table_name)

    def test_table_describe_rejects_corrupted_relationship_metadata(self):
        table_name = self._table_name("rel_corrupt")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "owner_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            },
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        with self.app.app_context():
            db.session.execute(
                db_executor_module._TABLE_OPTIONS.update()
                .where(db_executor_module._TABLE_OPTIONS.c.table_name == table_name)
                .values(relations_json="{bad-json")
            )
            db.session.commit()

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_TABLE_OP_ERROR")

    def test_table_backup_rejects_corrupted_relationship_options_metadata(self):
        source_table = self._table_name("rel_opt_src")
        target_table = self._table_name("rel_opt_dst")
        self._define_table(source_table)
        self.addCleanup(lambda: self._drop_table(source_table))
        self.addCleanup(lambda: self._drop_table(target_table))

        with self.app.app_context():
            db.session.execute(
                db_executor_module._TABLE_OPTIONS.update()
                .where(db_executor_module._TABLE_OPTIONS.c.table_name == source_table)
                .values(relationship_options_json="{bad-json")
            )
            db.session.commit()

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.backup",
                    "table": source_table,
                    "payload": {"target_table": target_table},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_TABLE_OP_ERROR")

    def test_table_define_rejects_invalid_relationship_metadata(self):
        table_name = self._table_name("rel_invalid")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "author_id": {
                                "type": "int",
                                "nullable": False,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "invalid",
                                },
                            },
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_table_define_rejects_postgres_foreign_keys_on_sqlite(self):
        table_name = self._table_name("rel_pg_fk_sqlite")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "author_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": "users",
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            },
                        },
                        "module_options": {
                            "relationships": {"postgres_foreign_keys": True},
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 501)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_ACTION_NOT_SUPPORTED")

    def test_table_define_rolls_back_created_table_when_table_options_write_fails(self):
        table_name = self._table_name("define_atomic")

        with patch("specdb.executor.table_define.upsert_table_options", side_effect=RuntimeError("boom-options")):
            resp, body = self._post(
                "/api/db/table",
                {
                    "spec": {
                        "action": "table.define",
                        "table": table_name,
                        "payload": {
                            "schema": {
                                "id": {"type": "int", "primary": True, "auto_increment": True},
                                "name": {"type": "str", "nullable": False},
                            }
                        },
                        "options": {},
                    }
                },
            )

        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_TABLE_OP_ERROR")

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.list",
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn(table_name, body["data"])

    def test_update_with_compact_log_requires_primary_key(self):
        table_name = self._table_name("strategy_nopk")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_strategy_update_with_compact_log_writes_change_log(self):
        table_name = self._table_name("strategy")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": table_name,
                    "payload": {"query": {"name": "v2"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with app.app_context():
            rows = (
                db.session.execute(
                    db.text(
                        "SELECT op, before_json, after_json FROM db_change_log WHERE table_name = :table_name ORDER BY id ASC"
                    ),
                    {"table_name": table_name},
                )
                .mappings()
                .all()
            )

        ops = [row["op"] for row in rows]
        self.assertIn("insert", ops)
        self.assertIn("update", ops)
        self.assertIn("delete", ops)

        update_rows = [row for row in rows if row["op"] == "update"]
        self.assertTrue(update_rows)
        update_row = update_rows[0]
        before = json.loads(update_row["before_json"])
        after = json.loads(update_row["after_json"])
        self.assertEqual(before["name"], "v1")
        self.assertEqual(after["name"], "v2")

        self._drop_table(table_name)

    def test_update_with_compact_log_insert_log_uses_effective_default_values(self):
        table_name = self._table_name("strategy_defaults")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                            "status": {"type": "str", "nullable": False, "default": "draft"},
                            "enabled": {"type": "bool", "nullable": False, "default": True},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "update_with_compact_log",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with app.app_context():
            row = (
                db.session.execute(
                    db.text(
                        "SELECT after_json FROM db_change_log WHERE table_name = :table_name AND op = 'insert' ORDER BY id DESC LIMIT 1"
                    ),
                    {"table_name": table_name},
                )
                .mappings()
                .first()
            )
        self.assertIsNotNone(row)
        after = json.loads(row["after_json"])
        self.assertEqual(after["status"], "draft")
        self.assertTrue(after["enabled"])

        self._drop_table(table_name)

    def test_strategy_append_only_versioned_writes_versions(self):
        table_name = self._table_name("append_only")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "u001", "name": "x"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "y"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["affected_rows"], 1)

        # history 应返回当前匹配实体的全部版本。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}, "version_order": "asc"},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(len(body["data"]["items"]), 1)
        versions = body["data"]["items"][0]["versions"]
        self.assertEqual(len(versions), 2)
        self.assertEqual(versions[0]["_history"]["op"], "insert")
        self.assertEqual(versions[1]["_history"]["op"], "update")
        self.assertEqual(versions[1]["name"], "y")

        # select 只应返回当前未删除版本，并隐藏内部字段。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(body["data"]["items"][0]["name"], "y")
        self.assertNotIn("__wt_version", body["data"]["items"][0])

        # delete 应写入墓碑记录，并让默认 select 隐藏已删除实体。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["affected_rows"], 1)

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 0)

        # include_deleted=true 时，仍应能通过当前墓碑行查到完整版本历史。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}, "include_deleted": True, "version_order": "asc"},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        versions = body["data"]["items"][0]["versions"]
        self.assertEqual(len(versions), 3)
        self.assertEqual(versions[-1]["_history"]["op"], "delete")
        self.assertTrue(bool(versions[-1]["_history"]["is_deleted"]))

        with app.app_context():
            rows = (
                db.session.execute(
                    db.text(
                        "SELECT __wt_version, __wt_is_current, __wt_is_deleted, __wt_op FROM "
                        + table_name
                        + " ORDER BY __wt_row_id ASC"
                    )
                )
                .mappings()
                .all()
            )
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[-1]["__wt_is_current"], 1)
        self.assertEqual(rows[-1]["__wt_is_deleted"], 1)
        self.assertEqual(rows[-1]["__wt_op"], "delete")

        self._drop_table(table_name)

    def test_append_only_versioned_enforces_internal_uniqueness(self):
        table_name = self._table_name("append_guard")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "u001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with app.app_context():
            table = Table(table_name, MetaData(), autoload_with=db.engine)
            inspector = sa_inspect(db.engine)
            index_names = {item["name"] for item in inspector.get_indexes(table_name)}
            unique_constraint_names = {item["name"] for item in inspector.get_unique_constraints(table_name)}
            current_row = db.session.execute(
                select(table).where(table.c["biz_id"] == "u001")
            ).mappings().one()

            self.assertIn(f"{table_name}_ux_ent_cur", index_names)
            self.assertIn(f"{table_name}_idx_ent_cur", index_names)
            self.assertIn(f"{table_name}_idx_ent_ver", index_names)
            self.assertIn(f"{table_name}_uq_ent_ver", unique_constraint_names)

            duplicate_version_row = {
                "biz_id": "u001",
                "name": "dup-version",
                "__wt_entity_id": current_row["__wt_entity_id"],
                "__wt_version": 1,
                "__wt_is_current": False,
                "__wt_is_deleted": False,
                "__wt_op": "update",
                "__wt_changed_at": datetime.now(timezone.utc),
            }
            with self.assertRaises(IntegrityError):
                db.session.execute(table.insert().values(**duplicate_version_row))
                db.session.commit()
            db.session.rollback()

            duplicate_current_row = {
                "biz_id": "u001",
                "name": "dup-current",
                "__wt_entity_id": current_row["__wt_entity_id"],
                "__wt_version": 2,
                "__wt_is_current": True,
                "__wt_is_deleted": False,
                "__wt_op": "update",
                "__wt_changed_at": datetime.now(timezone.utc),
            }
            with self.assertRaises(IntegrityError):
                db.session.execute(table.insert().values(**duplicate_current_row))
                db.session.commit()
            db.session.rollback()

        self._drop_table(table_name)

    def test_append_only_history_supports_entity_id_selector(self):
        table_name = self._table_name("append_entity")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "u001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )

        with app.app_context():
            entity_id = db.session.execute(
                db.text(
                    f"SELECT __wt_entity_id FROM {table_name} WHERE biz_id = :biz_id ORDER BY __wt_version DESC LIMIT 1"
                ),
                {"biz_id": "u001"},
            ).scalar_one()

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"entity_id": entity_id, "version_order": "asc"},
                    "options": {"include_total": True, "limit": 20, "offset": 0},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(len(body["data"]["items"]), 1)
        self.assertEqual(body["data"]["items"][0]["entity_id"], entity_id)
        versions = body["data"]["items"][0]["versions"]
        self.assertEqual(len(versions), 2)
        self.assertEqual(versions[0]["name"], "v1")
        self.assertEqual(versions[1]["name"], "v2")

        self._drop_table(table_name)

    def test_append_only_history_rejects_entity_id_and_query_together(self):
        table_name = self._table_name("append_entity_invalid")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"entity_id": "abc", "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        self._drop_table(table_name)

    def test_append_only_history_returns_empty_for_missing_entity_id(self):
        table_name = self._table_name("append_entity_missing")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"entity_id": "missing-entity"},
                    "options": {"include_total": True, "limit": 20, "offset": 0},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 0)
        self.assertEqual(body["data"]["items"], [])

        self._drop_table(table_name)

    def test_append_only_history_supports_version_pagination(self):
        table_name = self._table_name("append_history_page")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "u001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v3"}, "query": {"biz_id": "u001"}},
                    "options": {},
                }
            },
        )

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}, "version_order": "asc"},
                    "options": {"include_total": True, "limit": 20, "offset": 0, "version_limit": 1, "version_offset": 1},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(len(body["data"]["items"]), 1)
        item = body["data"]["items"][0]
        self.assertEqual(item["versions_total"], 3)
        self.assertEqual(item["version_limit"], 1)
        self.assertEqual(item["version_offset"], 1)
        self.assertEqual(len(item["versions"]), 1)
        self.assertEqual(item["versions"][0]["name"], "v2")

        self._drop_table(table_name)

    def test_append_only_history_validates_version_pagination_options(self):
        table_name = self._table_name("append_history_page_invalid")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {
                                "strategy": "append_only_versioned",
                                "retention_days": 30,
                            }
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "u001"}},
                    "options": {"version_limit": 0},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        self._drop_table(table_name)

    def test_invalid_module_options_returns_schema_error(self):
        table_name = self._table_name("invalid_mod")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {"id": {"type": "int", "primary": True, "auto_increment": True}},
                        "module_options": {"unknown_key": True},
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_invalid_relationship_module_options_returns_schema_error(self):
        table_name = self._table_name("invalid_rel_mod")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {"id": {"type": "int", "primary": True, "auto_increment": True}},
                        "module_options": {"relationships": {"postgres_foreign_keys": "yes"}},
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_reserved_prefix_field_name_rejected(self):
        table_name = self._table_name("reserved")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "__wt_custom": {"type": "str", "nullable": True},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

    def test_invalid_order_by_returns_schema_error(self):
        table_name = self._table_name("orderby")
        self._define_table(table_name)
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {}},
                    "options": {"order_by": ["unknown_col:asc"]},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")
        self._drop_table(table_name)

    def test_write_without_query_requires_allow_full_table(self):
        table_name = self._table_name("writeguard")
        self._define_table(table_name)
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "A"}},
                    "options": {},
                }
            },
        )

        # update 缺少 query 时应失败。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "B"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        # delete 缺少 query 时应失败。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        # allow_full_table=true 时应允许执行。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "C"}},
                    "options": {"allow_full_table": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        self._drop_table(table_name)

    def test_route_domain_mismatch_returns_schema_error(self):
        table_name = self._table_name("domain")
        self._define_table(table_name)

        # table 路由收到 data 动作时应报错。
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        # data 路由收到 table 动作时应报错。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "table.list",
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(body["error"]["code"], "DB_SCHEMA_ERROR")

        self._drop_table(table_name)

    def test_drop_nonexistent_table_with_if_exists(self):
        table_name = self._table_name("missing")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": True},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": False},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_TABLE_OP_ERROR")

    def test_backup_target_table_already_exists(self):
        source_table = self._table_name("backup_src")
        target_table = self._table_name("backup_dst")
        self._define_table(source_table)
        self._define_table(target_table)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.backup",
                    "table": source_table,
                    "payload": {"target_table": target_table},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_TABLE_OP_ERROR")

        self._drop_table(source_table)
        self._drop_table(target_table)

    def test_table_backup_copies_schema_data_and_tracking_options(self):
        source_table = self._table_name("backup_full_src")
        target_table = self._table_name("backup_full_dst")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": source_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "indexes": [{"name": f"idx_{source_table}_name", "keys": ["name"], "unique": False}],
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 30}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(source_table))
        self.addCleanup(lambda: self._drop_table(target_table))

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": source_table,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.backup",
                    "table": source_table,
                    "payload": {"target_table": target_table},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["copied_schema"])
        self.assertTrue(body["data"]["copied_indexes"])
        self.assertTrue(body["data"]["copied_data"])
        self.assertTrue(body["data"]["copied_tracking_options"])
        self.assertEqual(body["data"]["source_contract"]["dialect"], "sqlite")
        self.assertEqual(body["data"]["source_contract"]["change_tracking"]["strategy"], "update_with_compact_log")
        self.assertEqual(body["data"]["source_contract"]["change_tracking"]["retention_days"], 30)
        self.assertEqual(body["data"]["source_contract"]["relationship_options"], {"postgres_foreign_keys": False})
        self.assertEqual(body["data"]["source_contract"]["relation_keys"], [])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": target_table,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        column_names = {item["key"] for item in body["data"]["columns"]}
        self.assertEqual(column_names, {"id", "name"})

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": target_table,
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(body["data"]["items"][0]["name"], "v1")

        with app.app_context():
            strategy_row = (
                db.session.execute(
                    db.text(
                        "SELECT change_tracking_strategy, retention_days FROM db_table_options WHERE table_name = :table_name"
                    ),
                    {"table_name": target_table},
                )
                .mappings()
                .first()
            )
        self.assertIsNotNone(strategy_row)
        self.assertEqual(strategy_row["change_tracking_strategy"], "update_with_compact_log")
        self.assertEqual(strategy_row["retention_days"], 30)

    def test_table_drop_clears_change_logs_and_restore_audits_for_same_name_rebuild(self):
        table_name = self._table_name("drop_cleanup")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=1")
        log_body = resp.get_json()
        log_id = log_body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/api/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": False},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["cleanup"]["change_logs_cleared"])
        self.assertTrue(body["data"]["cleanup"]["restore_audits_cleared"])

        self._define_table(table_name)

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&limit=20")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"], [])

    def test_table_drop_reuses_existing_connection_for_tracking_cleanup(self):
        import specdb.executor.table_introspection as table_introspection

        table_name = self._table_name("drop_conn")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        with patch("specdb.executor.table_introspection.delete_table_options", wraps=table_introspection.delete_table_options) as mocked:
            resp, body = self._post(
                "/api/db/table",
                {
                    "spec": {
                        "action": "table.drop",
                        "table": table_name,
                        "payload": {"if_exists": False},
                        "options": {},
                    }
                },
            )

        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        mocked.assert_called_once()
        self.assertEqual(mocked.call_args.args[0], table_name)
        self.assertIsNotNone(mocked.call_args.kwargs.get("conn"))

    def test_table_alter_reuses_existing_connection_for_tracking_lookup(self):
        import specdb.executor.table_alter as table_alter

        table_name = self._table_name("alter_conn")
        self._define_table(table_name)
        self.addCleanup(lambda: self._drop_table(table_name))

        with patch("specdb.executor.table_alter.get_table_tracking_options", wraps=table_alter.get_table_tracking_options) as mocked:
            resp, body = self._post(
                "/api/db/table",
                {
                    "spec": {
                        "action": "table.alter",
                        "table": table_name,
                        "payload": {
                            "add": {
                                "email": {"type": "str", "nullable": True},
                            }
                        },
                        "options": {},
                    }
                },
            )

        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertGreaterEqual(mocked.call_count, 1)
        self.assertTrue(any(call.kwargs.get("conn") is not None for call in mocked.call_args_list))

        resp = self.client.get(f"/api/db/ops/restore-audits?table={table_name}&limit=20")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"], [])

    def test_duplicate_insert_rolls_back_and_maps_query_error(self):
        table_name = self._table_name("rollback")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False, "unique": True},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        # 第一次插入应成功。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        # 第二次插入重复值，应返回 DB_QUERY_ERROR。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")

        # 校验最终只保留一行数据。
        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "dup"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)

        self._drop_table(table_name)
