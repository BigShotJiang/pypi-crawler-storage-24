import db_api_test_base as support
from db_api_test_base import *
from pathlib import Path

from specdb import install_seed_file as root_install_seed_file, load_seed_bundle as root_load_seed_bundle
from specdb.db_executor import init_database
from specdb.install import install_seed, install_seed_file, install_suite, load_seed_bundle


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()


class DBSeedInstallTestCase(DBApiTestBase):
    def setUp(self):
        super().setUp()
        for table_name in ("rbac_roles", "rbac_permissions", "rbac_role_permissions"):
            self.addCleanup(lambda name=table_name: self._drop_table(name))

    def _write_seed_file(self, suffix: str, content: str) -> Path:
        seed_dir = support.BASE_DIR / ".tmp" / "tests"
        seed_dir.mkdir(parents=True, exist_ok=True)
        path = seed_dir / f"seed_bundle_{uuid.uuid4().hex}{suffix}"
        path.write_text(content, encoding="utf-8")
        self.addCleanup(lambda target=path: target.unlink(missing_ok=True))
        return path

    def _install_rbac_subset(self):
        with app.app_context():
            result = install_suite(
                init_database(),
                "admin_basic_suite_v1",
                include_templates=["rbac_role_v1", "rbac_permission_v1", "rbac_role_permission_v1"],
            )
        self.assertTrue(result["success"], result)

    def test_install_seed_updates_allowed_fields_by_default(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "update_allowed_fields",
                    "allowed_update_fields": ["role_name", "description", "status"],
                    "rows": [{"role_key": "editor", "role_name": "Editor", "status": "active"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            first = install_seed(client, bundle)
            second = install_seed(
                client,
                {
                    "tables": {
                        "rbac_roles": {
                            "key_fields": ["role_key"],
                            "mode": "update_allowed_fields",
                            "allowed_update_fields": ["role_name", "description", "status"],
                            "rows": [{"role_key": "editor", "role_name": "Content Editor", "status": "disabled"}],
                        }
                    }
                },
            )
            selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "editor"}},
                    "options": {"include_total": True},
                }
            )

        self.assertTrue(first["success"], first)
        self.assertTrue(second["success"], second)
        self.assertEqual(first["data"]["tables"]["rbac_roles"]["inserted"], 1)
        self.assertEqual(second["data"]["tables"]["rbac_roles"]["updated"], 1)
        item = selected["data"]["items"][0]
        self.assertEqual(item["role_name"], "Content Editor")
        self.assertEqual(item["status"], "disabled")

    def test_install_seed_supports_skip_if_exists(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "viewer", "role_name": "Viewer", "status": "active"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            first = install_seed(client, bundle)
            second = install_seed(
                client,
                {
                    "tables": {
                        "rbac_roles": {
                            "key_fields": ["role_key"],
                            "mode": "skip_if_exists",
                            "rows": [{"role_key": "viewer", "role_name": "Ignored Name", "status": "disabled"}],
                        }
                    }
                },
            )

        self.assertTrue(first["success"], first)
        self.assertTrue(second["success"], second)
        self.assertEqual(second["data"]["tables"]["rbac_roles"]["skipped"], 1)

    def test_install_seed_applies_default_mode_to_tables_without_explicit_mode(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "rows": [{"role_key": "default_skip", "role_name": "Default Skip", "status": "active"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            first = install_seed(client, bundle, default_mode="skip_if_exists")
            second = install_seed(client, bundle, default_mode="skip_if_exists")

        self.assertTrue(first["success"], first)
        self.assertTrue(second["success"], second)
        self.assertEqual(first["data"]["tables"]["rbac_roles"]["inserted"], 1)
        self.assertEqual(second["data"]["tables"]["rbac_roles"]["skipped"], 1)

    def test_install_seed_supports_fail_on_conflict(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "fail_on_conflict",
                    "rows": [{"role_key": "ops", "role_name": "Ops", "status": "active"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            first = install_seed(client, bundle)
            second = install_seed(client, bundle)

        self.assertTrue(first["success"], first)
        self.assertFalse(second["success"], second)
        self.assertIn("already exists", second["data"]["failed"][0]["error"])

    def test_install_seed_resolves_reference_rows_by_business_keys(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "super_admin", "role_name": "Super Admin", "status": "active"}],
                },
                "rbac_permissions": {
                    "key_fields": ["permission_key"],
                    "mode": "skip_if_exists",
                    "rows": [
                        {
                            "permission_key": "article.write",
                            "permission_name": "Article Write",
                            "resource_type": "api",
                            "resource_key": "article",
                            "module": "content",
                            "action": "write",
                        }
                    ],
                },
                "rbac_role_permissions": {
                    "key_fields": ["role_key_ref", "permission_key_ref"],
                    "mode": "skip_if_exists",
                    "references": {
                        "role_id": {
                            "table": "rbac_roles",
                            "target_key_fields": ["role_key"],
                            "source_from": ["role_key_ref"],
                        },
                        "permission_id": {
                            "table": "rbac_permissions",
                            "target_key_fields": ["permission_key"],
                            "source_from": ["permission_key_ref"],
                        },
                    },
                    "rows": [{"role_key_ref": "super_admin", "permission_key_ref": "article.write"}],
                },
            }
        }

        with app.app_context():
            client = init_database()
            result = install_seed(client, bundle)
            selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_role_permissions",
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            )

        self.assertTrue(result["success"], result)
        self.assertEqual(result["data"]["tables"]["rbac_role_permissions"]["inserted"], 1)
        self.assertEqual(selected["data"]["total"], 1)
        item = selected["data"]["items"][0]
        self.assertIsInstance(item["role_id"], int)
        self.assertIsInstance(item["permission_id"], int)

    def test_install_seed_rejects_invalid_allowed_update_fields(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "update_allowed_fields",
                    "allowed_update_fields": ["role_key", "role_name"],
                    "rows": [{"role_key": "bad", "role_name": "Bad"}],
                }
            }
        }

        with app.app_context():
            result = install_seed(init_database(), bundle)

        self.assertFalse(result["success"], result)
        self.assertTrue(
            any("allowed_update_fields overlaps protected fields" in item["error"] for item in result["data"]["failed"]),
            result,
        )

    def test_install_seed_non_strict_skips_invalid_table_seed_without_executing_rows(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "bad-mode",
                    "rows": [{"role_key": "bad_mode_role", "role_name": "Bad Mode"}],
                },
                "rbac_permissions": {
                    "key_fields": ["permission_key"],
                    "mode": "skip_if_exists",
                    "rows": [
                        {
                            "permission_key": "seed.valid",
                            "permission_name": "Seed Valid",
                            "resource_type": "api",
                            "resource_key": "seed",
                            "module": "seed",
                            "action": "read",
                        }
                    ],
                },
            }
        }

        with app.app_context():
            client = init_database()
            result = install_seed(client, bundle, strict=False)
            roles = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "bad_mode_role"}},
                    "options": {"include_total": True},
                }
            )
            permissions = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_permissions",
                    "payload": {"query": {"permission_key": "seed.valid"}},
                    "options": {"include_total": True},
                }
            )

        self.assertFalse(result["success"], result)
        self.assertEqual(roles["data"]["total"], 0)
        self.assertEqual(permissions["data"]["total"], 1)
        self.assertTrue(any(item["table"] == "rbac_roles" and "unsupported mode" in item["error"] for item in result["data"]["failed"]))

    def test_install_seed_failed_entries_use_stable_dict_shape(self):
        bundle = {
            "tables": {
                "": {
                    "key_fields": ["role_key"],
                    "rows": [],
                }
            }
        }

        with app.app_context():
            result = install_seed(init_database(), bundle, strict=True)

        self.assertFalse(result["success"], result)
        self.assertEqual(result["data"]["failed"][0]["table"], "<invalid-table-key>")
        self.assertIn("non-empty string", result["data"]["failed"][0]["error"])

    def test_install_seed_strict_mode_rejects_missing_reference(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "rollback_role", "role_name": "Rollback Role", "status": "active"}],
                },
                "rbac_permissions": {
                    "key_fields": ["permission_key"],
                    "mode": "skip_if_exists",
                    "rows": [
                        {
                            "permission_key": "seed.rollback",
                            "permission_name": "Seed Rollback",
                            "resource_type": "api",
                            "resource_key": "seed.rollback",
                            "module": "seed",
                            "action": "read",
                        }
                    ],
                },
                "rbac_role_permissions": {
                    "key_fields": ["role_key_ref", "permission_key_ref"],
                    "mode": "skip_if_exists",
                    "references": {
                        "role_id": {
                            "table": "rbac_roles",
                            "target_key_fields": ["role_key"],
                            "source_from": ["role_key_ref"],
                        },
                        "permission_id": {
                            "table": "rbac_permissions",
                            "target_key_fields": ["permission_key"],
                            "source_from": ["permission_key_ref"],
                        },
                    },
                    "rows": [{"role_key_ref": "missing", "permission_key_ref": "missing"}],
                }
            }
        }

        with app.app_context():
            client = init_database()
            result = install_seed(client, bundle, strict=True)
            role_selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "rollback_role"}},
                    "options": {"include_total": True},
                }
            )
            permission_selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_permissions",
                    "payload": {"query": {"permission_key": "seed.rollback"}},
                    "options": {"include_total": True},
                }
            )

        self.assertFalse(result["success"], result)
        self.assertIn("could not resolve", result["data"]["failed"][0]["error"])
        self.assertEqual(role_selected["data"]["total"], 0)
        self.assertEqual(permission_selected["data"]["total"], 0)
        self.assertIn("rolled back applied seed changes after strict failure", result["data"]["warnings"])

    def test_install_seed_atomic_resolves_references_within_single_transaction(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "atomic_admin", "role_name": "Atomic Admin", "status": "active"}],
                },
                "rbac_permissions": {
                    "key_fields": ["permission_key"],
                    "mode": "skip_if_exists",
                    "rows": [
                        {
                            "permission_key": "atomic.permission",
                            "permission_name": "Atomic Permission",
                            "resource_type": "api",
                            "resource_key": "atomic.permission",
                            "module": "seed",
                            "action": "read",
                        }
                    ],
                },
                "rbac_role_permissions": {
                    "key_fields": ["role_key_ref", "permission_key_ref"],
                    "mode": "skip_if_exists",
                    "references": {
                        "role_id": {
                            "table": "rbac_roles",
                            "target_key_fields": ["role_key"],
                            "source_from": ["role_key_ref"],
                        },
                        "permission_id": {
                            "table": "rbac_permissions",
                            "target_key_fields": ["permission_key"],
                            "source_from": ["permission_key_ref"],
                        },
                    },
                    "rows": [{"role_key_ref": "atomic_admin", "permission_key_ref": "atomic.permission"}],
                },
            }
        }

        with app.app_context():
            client = init_database()
            result = install_seed(client, bundle, atomic=True)
            selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_role_permissions",
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            )

        self.assertTrue(result["success"], result)
        self.assertEqual(result["data"]["tables"]["rbac_role_permissions"]["inserted"], 1)
        self.assertEqual(selected["data"]["total"], 1)

    def test_install_seed_atomic_rolls_back_all_rows_on_failure(self):
        self._install_rbac_subset()
        bundle = {
            "tables": {
                "rbac_roles": {
                    "key_fields": ["role_key"],
                    "mode": "skip_if_exists",
                    "rows": [{"role_key": "atomic_rollback_role", "role_name": "Atomic Rollback", "status": "active"}],
                },
                "rbac_permissions": {
                    "key_fields": ["permission_key"],
                    "mode": "skip_if_exists",
                    "rows": [
                        {
                            "permission_key": "atomic.rollback",
                            "permission_name": "Atomic Rollback",
                            "resource_type": "api",
                            "resource_key": "atomic.rollback",
                            "module": "seed",
                            "action": "read",
                        }
                    ],
                },
                "rbac_role_permissions": {
                    "key_fields": ["role_key_ref", "permission_key_ref"],
                    "mode": "skip_if_exists",
                    "references": {
                        "role_id": {
                            "table": "rbac_roles",
                            "target_key_fields": ["role_key"],
                            "source_from": ["role_key_ref"],
                        },
                        "permission_id": {
                            "table": "rbac_permissions",
                            "target_key_fields": ["permission_key"],
                            "source_from": ["permission_key_ref"],
                        },
                    },
                    "rows": [{"role_key_ref": "missing_atomic", "permission_key_ref": "missing_atomic"}],
                },
            }
        }

        with app.app_context():
            client = init_database()
            result = install_seed(client, bundle, strict=True, atomic=True)
            role_selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "atomic_rollback_role"}},
                    "options": {"include_total": True},
                }
            )
            permission_selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_permissions",
                    "payload": {"query": {"permission_key": "atomic.rollback"}},
                    "options": {"include_total": True},
                }
            )

        self.assertFalse(result["success"], result)
        self.assertEqual(result["data"]["tables"]["rbac_roles"]["inserted"], 0)
        self.assertEqual(result["data"]["tables"]["rbac_permissions"]["inserted"], 0)
        self.assertIn("rolled back atomic seed transaction after failure", result["data"]["warnings"])
        self.assertEqual(role_selected["data"]["total"], 0)
        self.assertEqual(permission_selected["data"]["total"], 0)

    def test_load_seed_bundle_supports_json_and_yaml_files(self):
        json_path = self._write_seed_file(
            ".json",
            '{"tables":{"rbac_roles":{"key_fields":["role_key"],"mode":"skip_if_exists","rows":[{"role_key":"json_admin","role_name":"JSON Admin"}]}}}',
        )
        yaml_path = self._write_seed_file(
            ".yaml",
            "tables:\n"
            "  rbac_roles:\n"
            "    key_fields: [role_key]\n"
            "    mode: skip_if_exists\n"
            "    rows:\n"
            "      - role_key: yaml_admin\n"
            "        role_name: YAML Admin\n",
        )

        json_bundle = load_seed_bundle(json_path)
        yaml_bundle = root_load_seed_bundle(yaml_path)

        self.assertEqual(json_bundle["tables"]["rbac_roles"]["rows"][0]["role_key"], "json_admin")
        self.assertEqual(yaml_bundle["tables"]["rbac_roles"]["rows"][0]["role_key"], "yaml_admin")

    def test_install_seed_file_supports_yaml_bundle(self):
        self._install_rbac_subset()
        yaml_path = self._write_seed_file(
            ".yml",
            "tables:\n"
            "  rbac_roles:\n"
            "    key_fields: [role_key]\n"
            "    mode: update_allowed_fields\n"
            "    allowed_update_fields: [role_name, status]\n"
            "    rows:\n"
            "      - role_key: yaml_editor\n"
            "        role_name: YAML Editor\n"
            "        status: active\n",
        )

        with app.app_context():
            client = init_database()
            result = install_seed_file(client, yaml_path)
            second = root_install_seed_file(client, yaml_path)
            selected = client.execute(
                {
                    "action": "data.select",
                    "table": "rbac_roles",
                    "payload": {"query": {"role_key": "yaml_editor"}},
                    "options": {"include_total": True},
                }
            )

        self.assertTrue(result["success"], result)
        self.assertTrue(second["success"], second)
        self.assertEqual(result["data"]["tables"]["rbac_roles"]["inserted"], 1)
        self.assertEqual(second["data"]["tables"]["rbac_roles"]["updated"], 1)
        self.assertEqual(selected["data"]["items"][0]["role_name"], "YAML Editor")

    def test_load_seed_bundle_rejects_unsupported_suffix_and_non_object_payload(self):
        txt_path = self._write_seed_file(".txt", "{}")
        json_list_path = self._write_seed_file(".json", '["not-a-dict"]')

        with self.assertRaises(ValueError):
            load_seed_bundle(txt_path)
        with self.assertRaises(ValueError):
            load_seed_bundle(json_list_path)


if __name__ == "__main__":
    unittest.main()
