"""按主题拆分后的 DB API 应用层测试。"""

import db_api_test_base as support
from db_api_test_base import *


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()

class DBApiAppTestCase(DBApiTestBase):
    def test_tracking_table_ensure_uses_app_context_cache(self):
        import specdb.executor.change_tracking as change_tracking

        with self.app.app_context():
            with patch("specdb.executor.change_tracking.ensure_internal_tables") as mocked:
                change_tracking.ensure_tracking_tables()
                change_tracking.ensure_tracking_tables()
        self.assertEqual(mocked.call_count, 1)

    def test_tracking_strategy_uses_app_context_cache(self):
        import specdb.executor.change_tracking as change_tracking

        table_name = self._table_name("tracking_cache")
        self._define_table(table_name)
        self.addCleanup(lambda: self._drop_table(table_name))

        with self.app.app_context():
            change_tracking.ensure_tracking_tables()
            with patch.object(db.engine, "begin", wraps=db.engine.begin) as mocked_begin:
                self.assertEqual(change_tracking.get_table_tracking_strategy(table_name), "none")
                self.assertEqual(change_tracking.get_table_tracking_strategy(table_name), "none")
        self.assertEqual(mocked_begin.call_count, 1)

    def test_tracking_strategy_can_reuse_session_without_engine_begin(self):
        import specdb.executor.change_tracking as change_tracking

        table_name = self._table_name("tracking_session")
        self._define_table(table_name)
        self.addCleanup(lambda: self._drop_table(table_name))

        with self.app.app_context():
            change_tracking.ensure_tracking_tables()
            with patch.object(db.engine, "begin", side_effect=AssertionError("engine.begin should not be used")):
                self.assertEqual(
                    change_tracking.get_table_tracking_strategy(table_name, session=db.session),
                    "none",
                )

    def test_create_app_factory_with_custom_config(self):
        class _TConfig:
            SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            TESTING = True

        custom_app = self._track_app(create_app(config_object=_TConfig))
        client = custom_app.test_client()
        resp = client.get("/api/health")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["status"], "ok")

    def test_resolve_config_defaults_to_safe_production_when_app_env_missing(self):
        with patch.dict(os.environ, {"DATABASE_URL": "sqlite:///:memory:"}, clear=False):
            os.environ.pop("APP_ENV", None)
            os.environ.pop("DB_MODULE_ENABLE_OPS_ROUTES", None)
            os.environ.pop("DB_MODULE_ENABLE_RESTORE_ROUTES", None)
            os.environ.pop("DB_MODULE_REQUIRE_OPS_AUTH", None)
            os.environ.pop("CORS_ORIGINS", None)
            config_object = resolve_config()

        self.assertEqual(config_object.SQLALCHEMY_DATABASE_URI, "sqlite:///:memory:")
        self.assertFalse(config_object.DB_MODULE_ENABLE_OPS_ROUTES)
        self.assertFalse(config_object.DB_MODULE_ENABLE_RESTORE_ROUTES)
        self.assertTrue(config_object.DB_MODULE_REQUIRE_OPS_AUTH)
        self.assertEqual(config_object.CORS_ORIGINS, "")

    def test_create_app_factory_starts_with_production_defaults(self):
        with patch.dict(
            os.environ,
            {
                "APP_ENV": "production",
                "DATABASE_URL": "sqlite:///:memory:",
            },
            clear=False,
        ):
            os.environ.pop("DB_MODULE_ENABLE_OPS_ROUTES", None)
            os.environ.pop("DB_MODULE_ENABLE_RESTORE_ROUTES", None)
            os.environ.pop("DB_MODULE_REQUIRE_OPS_AUTH", None)
            os.environ.pop("CORS_ORIGINS", None)
            custom_app = self._track_app(create_app())
        client = custom_app.test_client()

        resp = client.get("/api/health")
        self.assertEqual(resp.status_code, 200)

        resp = client.get("/api/db/templates")
        self.assertEqual(resp.status_code, 200)

        resp = client.post("/api/db/ops/snapshot-and-compact", json={"request_id": "ops-defaults"})
        self.assertEqual(resp.status_code, 404)

    def test_create_app_factory_requires_database_url_in_production(self):
        with patch.dict(os.environ, {"APP_ENV": "production"}, clear=False):
            os.environ.pop("DATABASE_URL", None)
            with self.assertRaisesRegex(ValueError, "SQLALCHEMY_DATABASE_URI must be non-empty"):
                create_app()

    def test_create_app_factory_can_disable_cors(self):
        class _TConfig:
            SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            CORS_ORIGINS = ""
            TESTING = True

        custom_app = self._track_app(create_app(config_object=_TConfig))
        client = custom_app.test_client()
        resp = client.get("/api/health", headers={"Origin": "http://example.com"})
        self.assertEqual(resp.status_code, 200)
        self.assertIsNone(resp.headers.get("Access-Control-Allow-Origin"))

    def test_create_app_factory_applies_cors_to_custom_db_prefix(self):
        class _TConfig:
            SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            DB_MODULE_URL_PREFIX = "/cfgapp/db"
            DB_MODULE_BLUEPRINT_NAME = "db_cfgapp"
            CORS_ORIGINS = "http://example.com"
            TESTING = True

        custom_app = self._track_app(create_app(config_object=_TConfig))
        client = custom_app.test_client()
        resp = client.get("/cfgapp/db/templates", headers={"Origin": "http://example.com"})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.headers.get("Access-Control-Allow-Origin"), "http://example.com")

    def test_create_app_factory_applies_db_module_config(self):
        class _TConfig:
            SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            DB_MODULE_URL_PREFIX = "/cfgapp/db"
            DB_MODULE_BLUEPRINT_NAME = "db_cfgapp"
            TESTING = True

        custom_app = self._track_app(create_app(config_object=_TConfig))
        client = custom_app.test_client()
        resp = client.get("/cfgapp/db/templates")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        # 配置了自定义前缀后，旧默认前缀不应继续存在。
        resp = client.get("/api/db/templates")
        self.assertEqual(resp.status_code, 404)

    def test_db_module_options_from_app_config(self):
        app_cfg = self._track_app(Flask("db_cfg_test"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_URL_PREFIX"] = "/cfg/db"
        app_cfg.config["DB_MODULE_BLUEPRINT_NAME"] = "dbcfg"
        init_db_module(app_cfg)
        client = app_cfg.test_client()
        resp = client.get("/cfg/db/templates")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

    def test_db_module_kwargs_can_override_config_back_to_defaults(self):
        app_cfg = self._track_app(Flask("db_cfg_override_defaults"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_URL_PREFIX"] = "/cfg/db"
        app_cfg.config["DB_MODULE_BLUEPRINT_NAME"] = "dbcfg"
        init_db_module(app_cfg, db_url_prefix="/api/db", blueprint_name="db")
        client = app_cfg.test_client()

        resp = client.get("/api/db/templates")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        resp = client.get("/cfg/db/templates")
        self.assertEqual(resp.status_code, 404)

    def test_init_db_module_can_register_multiple_blueprints_on_same_app(self):
        app_cfg = self._track_app(Flask("db_cfg_multi_init"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        init_db_module(
            app_cfg,
            options=DBModuleOptions(
                db_url_prefix="/a/db",
                blueprint_name="dba",
                register_blueprint=True,
                init_tables=True,
            ),
        )
        init_db_module(
            app_cfg,
            options=DBModuleOptions(
                db_url_prefix="/b/db",
                blueprint_name="dbb",
                register_blueprint=True,
                init_tables=True,
            ),
        )

        client = app_cfg.test_client()
        self.assertEqual(client.get("/a/db/templates").status_code, 200)
        self.assertEqual(client.get("/b/db/templates").status_code, 200)

    def test_db_module_options_from_app_config_accepts_bool_strings(self):
        app_cfg = self._track_app(Flask("db_cfg_bool_string"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_ENABLE_OPS_ROUTES"] = "false"
        app_cfg.config["DB_MODULE_ENABLE_RESTORE_ROUTES"] = "false"
        init_db_module(app_cfg)
        client = app_cfg.test_client()

        # 字符串配置也应正确关闭 ops 路由。
        resp = client.get("/api/db/ops/jobs/not_exists")
        self.assertEqual(resp.status_code, 404)
        # 模板路由默认仍应保持开启。
        resp = client.get("/api/db/templates")
        self.assertEqual(resp.status_code, 200)

    def test_ops_jobs_table_ensure_is_thread_safe(self):
        app_ts = self._track_app(Flask("db_ops_jobs_ensure_ts"))
        app_ts.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_ts.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(
            app_ts,
            options=DBModuleOptions(register_blueprint=False, init_tables=False),
        )

        call_count = {"n": 0}
        original_create_all = ops_jobs_store._metadata.create_all

        def wrapped_create_all(*args, **kwargs):
            call_count["n"] += 1
            time.sleep(0.05)
            return original_create_all(*args, **kwargs)

        with patch.object(ops_jobs_store._metadata, "create_all", side_effect=wrapped_create_all):
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = [executor.submit(self._ensure_jobs_table_in_app_context, app_ts) for _ in range(4)]
                for future in futures:
                    future.result()

        self.assertIn(call_count["n"], {0, 1})

    def test_internal_tables_ensure_is_thread_safe(self):
        app_ts = self._track_app(Flask("db_internal_ensure_ts"))
        app_ts.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_ts.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(
            app_ts,
            options=DBModuleOptions(register_blueprint=False, init_tables=False),
        )

        call_count = {"n": 0}
        original_create_all = db_executor_module._INTERNAL_METADATA.create_all

        def wrapped_create_all(*args, **kwargs):
            call_count["n"] += 1
            time.sleep(0.05)
            return original_create_all(*args, **kwargs)

        with patch.object(db_executor_module._INTERNAL_METADATA, "create_all", side_effect=wrapped_create_all):
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = [executor.submit(self._ensure_internal_tables_in_app_context, app_ts) for _ in range(4)]
                for future in futures:
                    future.result()

        self.assertIn(call_count["n"], {0, 1})

    def test_internal_tables_are_recreated_after_manual_drop(self):
        table_name = self._table_name("guard_recreate")
        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        with app.app_context():
            db.session.execute(db.text("DROP TABLE db_change_log"))
            db.session.commit()

        resp, body = self._post(
            "/api/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp = self.client.get(f"/api/db/ops/change-logs?table={table_name}&op=update&limit=10")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(body["data"]["items"]), 1)

    def test_db_module_options_validation_error(self):
        app_cfg = self._track_app(Flask("db_cfg_invalid"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_URL_PREFIX"] = "invalid-prefix"
        with self.assertRaises(ValueError):
            init_db_module(app_cfg)

        with self.assertRaises(ValueError):
            DBModuleOptions(enable_ops_routes=False, enable_restore_routes=True).validate()

    def test_db_module_can_require_ops_auth_callback(self):
        app_cfg = self._track_app(Flask("db_cfg_require_ops_auth"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_REQUIRE_OPS_AUTH"] = True

        with self.assertRaises(ValueError):
            init_db_module(app_cfg)

        init_db_module(
            app_cfg,
            options=DBModuleOptions(
                ops_auth_callback=lambda req: True,
            ),
        )
        client = app_cfg.test_client()
        resp = client.get("/api/db/templates")
        self.assertEqual(resp.status_code, 200)

    def test_db_module_requires_ops_auth_by_default_outside_testing(self):
        app_cfg = Flask("db_cfg_default_ops_auth")
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["APP_ENV"] = "production"

        with self.assertRaisesRegex(
            ValueError,
            "DB module ops routes require auth callback when DB_MODULE_REQUIRE_OPS_AUTH=true",
        ):
            init_db_module(app_cfg)

    def test_db_module_requires_ops_auth_when_env_is_unspecified_outside_testing(self):
        app_cfg = Flask("db_cfg_default_ops_auth_missing_env")
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        with self.assertRaisesRegex(
            ValueError,
            "DB module ops routes require auth callback when DB_MODULE_REQUIRE_OPS_AUTH=true",
        ):
            init_db_module(app_cfg)

    def test_missing_ops_auth_warning_is_scoped_per_app(self):
        import specdb.ops_security as ops_security

        app_a = Flask("db_warning_scope_a")
        app_a.testing = False
        app_a.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_a.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_a.config["DB_MODULE_REQUIRE_OPS_AUTH"] = False

        app_b = Flask("db_warning_scope_b")
        app_b.testing = False
        app_b.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_b.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_b.config["DB_MODULE_REQUIRE_OPS_AUTH"] = False

        with patch.object(app_a.logger, "warning") as warning_a, patch.object(app_b.logger, "warning") as warning_b:
            ops_security.validate_ops_blueprint_security(
                app_a,
                enable_ops_routes=True,
                ops_auth_callback=None,
            )
            ops_security.validate_ops_blueprint_security(
                app_a,
                enable_ops_routes=True,
                ops_auth_callback=None,
            )
            ops_security.validate_ops_blueprint_security(
                app_b,
                enable_ops_routes=True,
                ops_auth_callback=None,
            )

        self.assertEqual(warning_a.call_count, 1)
        self.assertEqual(warning_b.call_count, 1)

    def test_db_module_can_disable_ops_routes(self):
        app_no_ops = self._track_app(Flask("db_no_ops"))
        app_no_ops.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_no_ops.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(
            app_no_ops,
            options=DBModuleOptions(
                db_url_prefix="/noops/db",
                blueprint_name="db_noops",
                enable_ops_routes=False,
                enable_templates_routes=True,
                enable_restore_routes=False,
            ),
        )
        client = app_no_ops.test_client()
        resp = client.get("/noops/db/ops/jobs/not_exists")
        self.assertEqual(resp.status_code, 404)
        resp = client.get("/noops/db/templates")
        self.assertEqual(resp.status_code, 200)

    def test_db_module_can_disable_templates_and_restore_routes(self):
        app_flags = self._track_app(Flask("db_route_flags"))
        app_flags.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_flags.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(
            app_flags,
            options=DBModuleOptions(
                db_url_prefix="/flags/db",
                blueprint_name="db_flags",
                enable_ops_routes=True,
                enable_templates_routes=False,
                enable_restore_routes=False,
            ),
        )
        client = app_flags.test_client()
        resp = client.get("/flags/db/templates")
        self.assertEqual(resp.status_code, 404)
        resp = client.post("/flags/db/ops/snapshot-and-compact", json={"request_id": f"ops-{uuid.uuid4().hex[:6]}"})
        self.assertEqual(resp.status_code, 202)
        resp = client.post("/flags/db/ops/restore-from-logs", json={"table": "users", "log_ids": [1]})
        self.assertEqual(resp.status_code, 404)

    def test_openapi_endpoint_contains_core_paths(self):
        resp = self.client.get("/api/db/openapi")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        spec = body["data"]
        self.assertEqual(spec["openapi"], "3.0.3")
        self.assertIn("/api/db/table", spec["paths"])
        self.assertIn("/api/db/data", spec["paths"])
        self.assertIn("/api/db/ops/snapshot-and-compact", spec["paths"])
        self.assertIn("components", spec)
        self.assertIn("schemas", spec["components"])
        self.assertIn("ApiSuccess", spec["components"]["schemas"])
        self.assertIn("ApiError", spec["components"]["schemas"])

    def test_openapi_respects_route_flags(self):
        app_flags = self._track_app(Flask("db_openapi_flags"))
        app_flags.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_flags.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(
            app_flags,
            options=DBModuleOptions(
                db_url_prefix="/openapi/db",
                blueprint_name="db_openapi",
                enable_ops_routes=False,
                enable_templates_routes=False,
                enable_restore_routes=False,
            ),
        )
        client = app_flags.test_client()
        resp = client.get("/openapi/db/openapi")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        paths = body["data"]["paths"]
        self.assertIn("/openapi/db/table", paths)
        self.assertIn("/openapi/db/data", paths)
        self.assertNotIn("/openapi/db/ops/snapshot-and-compact", paths)
        self.assertNotIn("/openapi/db/templates", paths)

    def test_openapi_yaml_endpoint(self):
        resp = self.client.get("/api/db/openapi.yaml")
        text = resp.get_data(as_text=True)
        self.assertEqual(resp.status_code, 200)
        self.assertIn("openapi: \"3.0.3\"", text)
        self.assertIn("/api/db/table:", text)
        self.assertIn("components:", text)
        self.assertIn("data: {}", text)

    def test_template_endpoints(self):
        for path in (
            "/api/db/templates",
            "/api/db/templates/user_standard_v2",
            "/api/db/templates/user_standard_v2/define-spec",
            "/api/db/templates/user_standard_v2/rules",
        ):
            resp = self.client.get(path)
            body = resp.get_json()
            self.assertEqual(resp.status_code, 200, path)
            self.assertTrue(body["success"], path)

    def test_ops_auth_callback_can_block_ops_routes(self):
        def deny_ops(req):
            _ = req
            return (False, "blocked by test callback", 403)

        configure_db_module(app, ops_auth_callback=deny_ops)
        try:
            resp = self.client.get("/api/db/ops/jobs/not_exists_job")
            body = resp.get_json()
            self.assertEqual(resp.status_code, 403)
            self.assertFalse(body["success"])
            self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

            # ops 鉴权回调不应阻塞非 ops 路由。
            resp, body = self._post("/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}})
            self.assertEqual(resp.status_code, 200)
            self.assertTrue(body["success"])
        finally:
            configure_db_module(app, ops_auth_callback=None)

    def test_configure_db_module_cannot_disable_required_ops_auth_at_runtime(self):
        app_cfg = self._track_app(Flask("db_cfg_require_ops_auth_runtime"))
        app_cfg.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_cfg.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_cfg.config["DB_MODULE_REQUIRE_OPS_AUTH"] = True

        def deny_ops(_req):
            return (False, "blocked-runtime", 403)

        init_db_module(app_cfg, db_url_prefix="/secure/db", blueprint_name="db_secure", ops_auth_callback=deny_ops)

        def _cleanup_app():
            shutdown_db_module(app_cfg, wait=True)
            with app_cfg.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_app)

        client = app_cfg.test_client()
        resp = client.get("/secure/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

        with self.assertRaisesRegex(
            ValueError,
            "DB module ops routes require auth callback when DB_MODULE_REQUIRE_OPS_AUTH=true",
        ):
            configure_db_module(app_cfg, ops_auth_callback=None)

        resp = client.get("/secure/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

    def test_ops_auth_callback_exceptions_return_json_error(self):
        app_boom = self._track_app(Flask("db_ops_auth_exception"))
        app_boom.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_boom.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(app_boom, db_url_prefix="/boom/db", blueprint_name="db_boom")

        def boom_auth(_req):
            raise RuntimeError("boom-auth")

        configure_db_module(app_boom, ops_auth_callback=boom_auth)

        def _cleanup_app():
            shutdown_db_module(app_boom, wait=True)
            with app_boom.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_app)

        client = app_boom.test_client()
        resp = client.post("/boom/db/ops/snapshot-and-compact", json={"request_id": f"ops-{uuid.uuid4().hex[:8]}"})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 500)
        self.assertTrue(resp.is_json)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_AUTH_CALLBACK_FAILED")
        self.assertIn("boom-auth", body["error"]["details"]["error"])

    def test_configure_db_module_current_app_scope_does_not_leak_across_apps(self):
        app_a = self._track_app(Flask("db_configure_scope_a"))
        app_a.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_a.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        app_b = self._track_app(Flask("db_configure_scope_b"))
        app_b.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_b.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        init_db_module(app_a, db_url_prefix="/a/db", blueprint_name="dba", ops_auth_callback=None)
        init_db_module(app_b, db_url_prefix="/b/db", blueprint_name="dbb", ops_auth_callback=None)

        def _cleanup_app(target_app: Flask):
            shutdown_db_module(target_app, wait=True)
            with target_app.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(lambda: _cleanup_app(app_a))
        self.addCleanup(lambda: _cleanup_app(app_b))

        def deny_ops(_req):
            return (False, "denied-current-app", 403)

        with app_a.app_context():
            configure_db_module(ops_auth_callback=deny_ops)

        with self.assertRaisesRegex(ValueError, "configure_db_module requires app or an active app context"):
            configure_db_module(ops_auth_callback=deny_ops)

        client_a = app_a.test_client()
        client_b = app_b.test_client()

        resp = client_a.get("/a/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

        resp = client_b.get("/b/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_custom_prefix_containing_ops_does_not_gate_non_ops_routes(self):
        app_prefix = self._track_app(Flask("db_ops_prefix_safe"))
        app_prefix.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_prefix.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        def deny_ops(_req):
            return (False, "ops-only", 403)

        init_db_module(
            app_prefix,
            db_url_prefix="/api/opsdb",
            blueprint_name="db_ops_prefix",
            ops_auth_callback=deny_ops,
        )

        def _cleanup_app():
            shutdown_db_module(app_prefix, wait=True)
            with app_prefix.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_app)

        client = app_prefix.test_client()
        resp = client.post("/api/opsdb/table", json={"spec": {"action": "table.list", "payload": {}, "options": {}}})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp = client.get("/api/opsdb/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

    def test_configure_db_module_defaults_to_registered_custom_blueprint_scope(self):
        app_custom = self._track_app(Flask("db_custom_scope_runtime"))
        app_custom.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_custom.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(app_custom, db_url_prefix="/x/db", blueprint_name="xdb", ops_auth_callback=None)

        def deny_ops(_req):
            return (False, "blocked-custom-scope", 403)

        configure_db_module(app_custom, ops_auth_callback=deny_ops)

        def _cleanup_app():
            shutdown_db_module(app_custom, wait=True)
            with app_custom.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_app)

        client = app_custom.test_client()
        resp = client.get("/x/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

    def test_db_module_custom_url_prefix(self):
        custom_app = self._track_app(Flask("custom_prefix_test"))
        custom_app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        custom_app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        init_db_module(custom_app, db_url_prefix="/custom/db")
        client = custom_app.test_client()

        resp = client.get("/custom/db/templates")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        # 这个 app 上不应再暴露默认前缀。
        resp = client.get("/api/db/templates")
        self.assertEqual(resp.status_code, 404)

    def test_db_module_ops_auth_is_isolated_per_app(self):
        app_a = self._track_app(Flask("db_app_a"))
        app_a.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_a.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        app_b = self._track_app(Flask("db_app_b"))
        app_b.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_b.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        def deny_all(_req):
            return (False, "denied-a", 403)

        init_db_module(app_a, db_url_prefix="/a/db", ops_auth_callback=deny_all)
        init_db_module(app_b, db_url_prefix="/b/db", ops_auth_callback=None)

        client_a = app_a.test_client()
        client_b = app_b.test_client()

        resp_a = client_a.get("/a/db/ops/jobs/not_exists")
        body_a = resp_a.get_json()
        self.assertEqual(resp_a.status_code, 403)
        self.assertFalse(body_a["success"])
        self.assertEqual(body_a["error"]["code"], "DB_OPS_FORBIDDEN")

        resp_b = client_b.get("/b/db/ops/jobs/not_exists")
        body_b = resp_b.get_json()
        self.assertEqual(resp_b.status_code, 404)
        self.assertFalse(body_b["success"])
        self.assertEqual(body_b["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_db_blueprint_factory_isolated_within_same_app(self):
        app_multi = self._track_app(Flask("db_multi_bp"))
        app_multi.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_multi.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        init_db_module(
            app_multi,
            options=DBModuleOptions(register_blueprint=False, init_tables=True),
        )

        def deny_ops(_req):
            return (False, "denied-by-a", 403)

        app_multi.register_blueprint(create_db_blueprint(name="dba", url_prefix="/a/db", ops_auth_callback=deny_ops))
        app_multi.register_blueprint(create_db_blueprint(name="dbb", url_prefix="/b/db", ops_auth_callback=None))
        client = app_multi.test_client()

        resp = client.get("/a/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 403)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_FORBIDDEN")

        resp = client.get("/b/db/ops/jobs/not_exists")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

    def test_db_blueprint_factory_honors_required_ops_auth(self):
        app_factory = self._track_app(Flask("db_factory_auth_required"))
        app_factory.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_factory.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
        app_factory.config["DB_MODULE_REQUIRE_OPS_AUTH"] = True

        init_db_module(
            app_factory,
            options=DBModuleOptions(
                register_blueprint=False,
                init_tables=True,
                enable_ops_routes=False,
                enable_restore_routes=False,
            ),
        )

        def _cleanup_factory_app():
            shutdown_db_module(app_factory, wait=True)
            with app_factory.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_factory_app)

        with self.assertRaisesRegex(
            ValueError,
            "DB module ops routes require auth callback when DB_MODULE_REQUIRE_OPS_AUTH=true",
        ):
            app_factory.register_blueprint(create_db_blueprint(name="dbf", url_prefix="/f/db", ops_auth_callback=None))

    def test_db_blueprint_factory_isolates_ops_jobs_per_scope(self):
        app_multi = self._track_app(Flask("db_multi_bp_jobs"))
        app_multi.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
        app_multi.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

        def _cleanup_multi_app():
            shutdown_db_module(app_multi, wait=True)
            with app_multi.app_context():
                db.session.remove()
                db.engine.dispose()

        self.addCleanup(_cleanup_multi_app)

        init_db_module(
            app_multi,
            options=DBModuleOptions(register_blueprint=False, init_tables=True),
        )
        app_multi.register_blueprint(create_db_blueprint(name="dba", url_prefix="/a/db"))
        app_multi.register_blueprint(create_db_blueprint(name="dbb", url_prefix="/b/db"))
        client = app_multi.test_client()

        def _wait_job(path_prefix: str, job_id: str, expected_state: str, timeout_sec: float = 2.0) -> dict:
            deadline = time.time() + timeout_sec
            last_state = None
            while time.time() < deadline:
                resp = client.get(f"{path_prefix}/ops/jobs/{job_id}")
                body = resp.get_json()
                self.assertEqual(resp.status_code, 200)
                last_state = body["data"]["state"]
                if last_state == expected_state:
                    return body["data"]
                time.sleep(0.05)
            self.fail(f"{path_prefix} job {job_id} did not reach {expected_state}, last_state={last_state}")

        shared_job_id = f"ops-{uuid.uuid4().hex[:8]}"
        resp = client.post("/a/db/ops/snapshot-and-compact", json={"request_id": shared_job_id, "dry_run": True, "targets": []})
        self.assertEqual(resp.status_code, 202)
        job_a = _wait_job("/a/db", shared_job_id, "verified")
        self.assertTrue(bool(job_a["request"]["dry_run"]))

        resp = client.get(f"/b/db/ops/jobs/{shared_job_id}")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")

        resp = client.post("/b/db/ops/snapshot-and-compact", json={"request_id": shared_job_id, "dry_run": False, "targets": []})
        self.assertEqual(resp.status_code, 202)
        job_b = _wait_job("/b/db", shared_job_id, "verified")
        self.assertFalse(bool(job_b["request"]["dry_run"]))

        job_a_again = client.get(f"/a/db/ops/jobs/{shared_job_id}").get_json()["data"]
        job_b_again = client.get(f"/b/db/ops/jobs/{shared_job_id}").get_json()["data"]
        self.assertTrue(bool(job_a_again["request"]["dry_run"]))
        self.assertFalse(bool(job_b_again["request"]["dry_run"]))

        failing_job_id = f"ops-{uuid.uuid4().hex[:8]}"
        old_retry = app_multi.config.get("OPS_COMPACT_MAX_RETRIES", 1)
        app_multi.config["OPS_COMPACT_MAX_RETRIES"] = 0
        try:
            with patch("specdb.ops.compact_engine._execute_compact_once", side_effect=RuntimeError("compact boom")):
                resp = client.post(
                    "/a/db/ops/snapshot-and-compact",
                    json={"request_id": failing_job_id, "dry_run": True, "targets": []},
                )
                self.assertEqual(resp.status_code, 202)
                failed_job = _wait_job("/a/db", failing_job_id, "failed")
                self.assertEqual(failed_job["error_code"], "DB_OPS_SNAPSHOT_COMPACT_ERROR")
        finally:
            app_multi.config["OPS_COMPACT_MAX_RETRIES"] = old_retry

        resp = client.post(f"/b/db/ops/jobs/{failing_job_id}/retry", json={})
        body = resp.get_json()
        self.assertEqual(resp.status_code, 404)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_OPS_NOT_FOUND")
