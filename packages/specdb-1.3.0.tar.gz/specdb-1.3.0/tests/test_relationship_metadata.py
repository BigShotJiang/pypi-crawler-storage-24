import unittest

from specdb.executor.relationship_metadata import build_table_dependency_plan, summarize_table_relationships


class RelationshipMetadataPlanningTestCase(unittest.TestCase):
    def test_build_table_dependency_plan_prefers_prerequisites(self):
        relations_by_table = {
            "comments": {
                "post_id": {
                    "target_table": "posts",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
                "author_id": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
            },
            "posts": {
                "author_id": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                }
            },
            "users": {},
        }

        plan = build_table_dependency_plan(
            relations_by_table,
            preferred_order=["comments", "posts", "users"],
        )

        self.assertEqual(plan["table_order"], ["users", "posts", "comments"])
        self.assertEqual(plan["dependencies"]["comments"], ["posts", "users"])
        self.assertEqual(plan["dependents"]["users"], ["comments", "posts"])
        self.assertFalse(plan["has_cycles"])

    def test_summarize_table_relationships_reports_reverse_dependencies_and_warnings(self):
        relations_by_table = {
            "users": {},
            "posts": {
                "author_id": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
                "editor_id": {
                    "target_table": "staff_profiles",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
            },
            "comments": {
                "post_id": {
                    "target_table": "posts",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                }
            },
        }

        summary = summarize_table_relationships("posts", relations_by_table=relations_by_table)

        self.assertEqual(summary["depends_on_tables"], ["staff_profiles", "users"])
        self.assertEqual(summary["referenced_by_tables"], ["comments"])
        self.assertEqual(summary["recommended_prerequisite_tables"], ["users"])
        self.assertEqual(summary["external_dependencies"], ["staff_profiles"])
        self.assertFalse(summary["has_relation_cycle"])
        self.assertTrue(any("referenced by other tables" in item for item in summary["warnings"]))
        self.assertTrue(any("outside current metadata scope" in item for item in summary["warnings"]))


if __name__ == "__main__":
    unittest.main()
