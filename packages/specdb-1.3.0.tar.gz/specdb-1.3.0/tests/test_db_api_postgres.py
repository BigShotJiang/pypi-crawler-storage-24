import os
import sys
import time
import unittest
import uuid
from pathlib import Path

from flask import Flask
from dotenv import load_dotenv
from sqlalchemy import inspect as sa_inspect

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from specdb.db_module import DBModuleOptions, init_db_module
from specdb.db_runtime import db


def _load_local_dotenv() -> None:
    for dotenv_path in (BASE_DIR.parent / ".env", BASE_DIR / ".env"):
        if dotenv_path.exists():
            load_dotenv(dotenv_path=dotenv_path, override=False)


def _looks_like_postgres_url(value: str | None) -> bool:
    if not value:
        return False
    normalized = value.strip().lower()
    return normalized.startswith("postgresql") or normalized.startswith("postgres://")


def _resolve_pg_database_url() -> str:
    _load_local_dotenv()
    direct_url = os.getenv("DATABASE_URL_PG", "").strip()
    if _looks_like_postgres_url(direct_url):
        return direct_url
    fallback_url = os.getenv("DATABASE_URL", "").strip()
    if _looks_like_postgres_url(fallback_url):
        return fallback_url
    return ""


def _pg_enabled() -> bool:
    database_url = _resolve_pg_database_url()
    run_pg_tests = os.getenv("RUN_PG_TESTS")
    if run_pg_tests is None:
        return bool(database_url)
    return run_pg_tests.strip().lower() in {"1", "true", "yes", "on"} and bool(database_url)


@unittest.skipUnless(_pg_enabled(), "PostgreSQL integration tests are disabled")
class DBApiPostgresIntegrationTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        database_url = _resolve_pg_database_url()

        class _PGConfig:
            SQLALCHEMY_DATABASE_URI = database_url
            SQLALCHEMY_TRACK_MODIFICATIONS = False
            TESTING = True

        cls.app = Flask("db_pg_integration")
        cls.app.config.from_object(_PGConfig)
        init_db_module(
            cls.app,
            options=DBModuleOptions(
                db_url_prefix="/pg/db",
                blueprint_name="db_pg",
                enable_ops_routes=True,
                enable_templates_routes=True,
                enable_restore_routes=True,
            ),
        )
        cls.client = cls.app.test_client()

    def _table_name(self, prefix: str) -> str:
        return f"{prefix}_{uuid.uuid4().hex[:10]}"

    def _post(self, path: str, payload: dict):
        resp = self.client.post(path, json=payload)
        return resp, resp.get_json()

    def _wait_for_job_state(self, job_id: str, expected_state: str, timeout_sec: float = 3.0):
        deadline = time.time() + timeout_sec
        last_state = None
        while time.time() < deadline:
            resp = self.client.get(f"/pg/db/ops/jobs/{job_id}")
            body = resp.get_json()
            self.assertEqual(resp.status_code, 200)
            self.assertTrue(body["success"])
            last_state = body["data"]["state"]
            if last_state == expected_state:
                return body["data"]
            time.sleep(0.05)
        self.fail(f"job {job_id} did not reach state={expected_state}, last_state={last_state}")

    def _drop_table(self, table_name: str):
        self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": True},
                    "options": {},
                }
            },
        )

    def test_postgres_append_only_history(self):
        table_name = self._table_name("pg_append")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "append_only_versioned", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "pg001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "pg001"}, "data": {"name": "v2"}},
                    "options": {},
                }
            },
        )

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.history",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "pg001"}, "version_order": "asc"},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)
        versions = body["data"]["items"][0]["versions"]
        self.assertEqual(len(versions), 2)
        self.assertEqual(versions[0]["_history"]["op"], "insert")
        self.assertEqual(versions[1]["_history"]["op"], "update")

    def test_postgres_table_alter_add_and_drop_columns(self):
        table_name = self._table_name("pg_alter")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"add": {"email": {"type": "str", "nullable": True}}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {"drop": ["email"]},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

    def test_postgres_table_define_can_create_real_foreign_key(self):
        parent_table = self._table_name("pg_parent")
        child_table = self._table_name("pg_child")
        self.addCleanup(lambda: self._drop_table(child_table))
        self.addCleanup(lambda: self._drop_table(parent_table))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": parent_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": child_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "author_id": {
                                "type": "int",
                                "nullable": True,
                                "relation": {
                                    "target_table": parent_table,
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "set_null",
                                    "on_update": "restrict",
                                },
                            },
                            "title": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "relationships": {"postgres_foreign_keys": True},
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["postgres_foreign_keys"])

        with self.app.app_context():
            foreign_keys = sa_inspect(db.engine).get_foreign_keys(child_table)
        self.assertEqual(len(foreign_keys), 1)
        self.assertEqual(foreign_keys[0]["referred_table"], parent_table)
        self.assertEqual(foreign_keys[0]["constrained_columns"], ["author_id"])
        self.assertEqual(foreign_keys[0]["referred_columns"], ["id"])
        self.assertEqual(foreign_keys[0].get("options", {}).get("ondelete"), "SET NULL")

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": parent_table,
                    "payload": {"data": {"name": "parent"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        parent_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": child_table,
                    "payload": {"data": {"author_id": parent_id, "title": "hello"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        child_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": parent_table,
                    "payload": {"query": {"id": parent_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": child_table,
                    "payload": {"query": {"id": child_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertIsNone(body["data"]["items"][0]["author_id"])

    def test_postgres_table_alter_add_can_create_real_foreign_key(self):
        parent_table = self._table_name("pg_fk_parent")
        child_table = self._table_name("pg_fk_child")
        self.addCleanup(lambda: self._drop_table(child_table))
        self.addCleanup(lambda: self._drop_table(parent_table))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": parent_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": child_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "title": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "relationships": {"postgres_foreign_keys": True},
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": child_table,
                    "payload": {
                        "add": {
                            "parent_id": {
                                "type": "int",
                                "nullable": False,
                                "relation": {
                                    "target_table": parent_table,
                                    "target_column": "id",
                                    "kind": "many_to_one",
                                    "on_delete": "cascade",
                                    "on_update": "restrict",
                                },
                            }
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["postgres_foreign_keys"])

        with self.app.app_context():
            foreign_keys = sa_inspect(db.engine).get_foreign_keys(child_table)
        self.assertEqual(len(foreign_keys), 1)
        self.assertEqual(foreign_keys[0]["constrained_columns"], ["parent_id"])
        self.assertEqual(foreign_keys[0]["referred_table"], parent_table)
        self.assertEqual(foreign_keys[0].get("options", {}).get("ondelete"), "CASCADE")

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": parent_table,
                    "payload": {"data": {"name": "parent"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        parent_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": child_table,
                    "payload": {"data": {"parent_id": parent_id, "title": "child"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.delete",
                    "table": parent_table,
                    "payload": {"query": {"id": parent_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": child_table,
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 0)

    def test_postgres_table_alter_modify_columns(self):
        table_name = self._table_name("pg_modify")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "title": {"type": "str", "nullable": True, "length": 64},
                            "status": {"type": "str", "nullable": False, "length": 32},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"nullable": False, "type": "text"},
                            "status": {"default": "draft"},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertCountEqual(body["data"]["modified_columns"], ["title", "status"])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "pg title"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        inserted_id = body["data"]["inserted_id"]

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"id": inserted_id}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["items"][0]["status"], "draft")

    def test_postgres_table_describe_returns_stable_column_contract(self):
        table_name = self._table_name("pg_describe_contract")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "slug": {"type": "str", "nullable": False, "length": 64, "unique": True},
                            "status": {"type": "str", "nullable": False, "default": "draft"},
                            "enabled": {"type": "bool", "nullable": False, "default": True},
                        },
                        "indexes": [{"name": f"idx_{table_name}_status", "keys": ["status"], "unique": False}],
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 15}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": table_name,
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["dialect"], "postgresql")
        self.assertEqual(body["data"]["change_tracking"]["strategy"], "update_with_compact_log")
        self.assertEqual(body["data"]["change_tracking"]["retention_days"], 15)
        columns = {item["key"]: item for item in body["data"]["columns"]}
        self.assertEqual(columns["status"]["default"], "draft")
        self.assertTrue(columns["status"]["has_default"])
        self.assertTrue(columns["status"]["indexed"])
        self.assertFalse(columns["status"]["unique"])
        self.assertEqual(columns["enabled"]["default"], True)
        self.assertTrue(columns["enabled"]["has_default"])
        self.assertTrue(columns["slug"]["unique"])
        self.assertFalse(columns["slug"]["contract_locked"])

    def test_postgres_table_alter_modify_updates_length_and_single_column_indexes(self):
        table_name = self._table_name("pg_modify_index")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "title": {"type": "str", "nullable": False, "length": 32},
                            "slug": {"type": "str", "nullable": False, "length": 32},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"length": 128, "index": True},
                            "slug": {"unique": True},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with self.app.app_context():
            inspector = sa_inspect(db.engine)
            columns = {item["name"]: item for item in inspector.get_columns(table_name)}
            indexes = inspector.get_indexes(table_name)
            unique_constraints = inspector.get_unique_constraints(table_name)
        self.assertEqual(getattr(columns["title"]["type"], "length", None), 128)
        self.assertTrue(any(item["column_names"] == ["title"] and not item.get("unique", False) for item in indexes))
        self.assertTrue(any(item["column_names"] == ["slug"] for item in unique_constraints + indexes if item.get("unique", True)))

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "first", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "second", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.alter",
                    "table": table_name,
                    "payload": {
                        "modify": {
                            "title": {"index": False},
                            "slug": {"unique": False},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"title": "third", "slug": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        with self.app.app_context():
            inspector = sa_inspect(db.engine)
            indexes = inspector.get_indexes(table_name)
            unique_constraints = inspector.get_unique_constraints(table_name)
        self.assertFalse(any(item["column_names"] == ["title"] and not item.get("unique", False) for item in indexes))
        self.assertFalse(any(item["column_names"] == ["slug"] for item in unique_constraints))
        self.assertFalse(any(item["column_names"] == ["slug"] and item.get("unique", False) for item in indexes))

    def test_postgres_update_with_compact_log_restore_roundtrip(self):
        table_name = self._table_name("pg_restore")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"data": {"name": "v2"}, "query": {"name": "v1"}},
                    "options": {},
                }
            },
        )

        resp = self.client.get(f"/pg/db/ops/change-logs?table={table_name}&op=update&limit=1")
        body = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        log_id = body["data"]["items"][0]["id"]

        resp, body = self._post(
            "/pg/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": True},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["restored_logs"], 1)
        self.assertTrue(body["data"]["dry_run"])

        resp, body = self._post(
            "/pg/db/ops/restore-from-logs",
            {"table": table_name, "log_ids": [log_id], "dry_run": False},
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["restored_logs"], 1)
        self.assertFalse(body["data"]["dry_run"])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "v1"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)

    def test_postgres_table_backup_copies_schema_data_and_tracking_options(self):
        source_table = self._table_name("pg_backup_src")
        target_table = self._table_name("pg_backup_dst")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": source_table,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False},
                        },
                        "indexes": [{"name": f"idx_{source_table}_name", "keys": ["name"], "unique": False}],
                        "module_options": {
                            "change_tracking": {"strategy": "update_with_compact_log", "retention_days": 30}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(source_table))
        self.addCleanup(lambda: self._drop_table(target_table))

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": source_table,
                    "payload": {"data": {"name": "v1"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)

        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.backup",
                    "table": source_table,
                    "payload": {"target_table": target_table},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertTrue(body["data"]["copied_schema"])
        self.assertTrue(body["data"]["copied_indexes"])
        self.assertTrue(body["data"]["copied_data"])
        self.assertTrue(body["data"]["copied_tracking_options"])
        self.assertEqual(body["data"]["source_contract"]["dialect"], "postgresql")
        self.assertEqual(body["data"]["source_contract"]["change_tracking"]["strategy"], "update_with_compact_log")
        self.assertEqual(body["data"]["source_contract"]["change_tracking"]["retention_days"], 30)
        self.assertEqual(body["data"]["source_contract"]["relationship_options"], {"postgres_foreign_keys": False})
        self.assertEqual(body["data"]["source_contract"]["relation_keys"], [])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": target_table,
                    "payload": {"query": {}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(body["data"]["total"], 1)
        self.assertEqual(body["data"]["items"][0]["name"], "v1")

        with self.app.app_context():
            strategy_row = (
                db.session.execute(
                    db.text(
                        "SELECT change_tracking_strategy, retention_days FROM db_table_options WHERE table_name = :table_name"
                    ),
                    {"table_name": target_table},
                )
                .mappings()
                .first()
            )
        self.assertIsNotNone(strategy_row)
        self.assertEqual(strategy_row["change_tracking_strategy"], "update_with_compact_log")
        self.assertEqual(strategy_row["retention_days"], 30)

    def test_postgres_duplicate_insert_rolls_back_and_maps_query_error(self):
        table_name = self._table_name("pg_dup")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "id": {"type": "int", "primary": True, "auto_increment": True},
                            "name": {"type": "str", "nullable": False, "unique": True},
                        }
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"name": "dup"}},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 500)
        self.assertFalse(body["success"])
        self.assertEqual(body["error"]["code"], "DB_QUERY_ERROR")

        resp, body = self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": {"name": "dup"}},
                    "options": {"include_total": True},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.assertEqual(body["data"]["total"], 1)

    def test_postgres_snapshot_compact_dry_run(self):
        job_id = f"pg-ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/pg/db/ops/snapshot-and-compact",
            {"request_id": job_id, "dry_run": True, "targets": []},
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])

        job_body = self._wait_for_job_state(job_id, "verified")
        self.assertEqual(job_body["state"], "verified")

    def test_postgres_snapshot_compact_compacts_append_only_history(self):
        table_name = self._table_name("pg_hist_compact")
        resp, body = self._post(
            "/pg/db/table",
            {
                "spec": {
                    "action": "table.define",
                    "table": table_name,
                    "payload": {
                        "schema": {
                            "biz_id": {"type": "str", "nullable": False},
                            "name": {"type": "str", "nullable": False},
                        },
                        "module_options": {
                            "change_tracking": {"strategy": "append_only_versioned", "retention_days": 7}
                        },
                    },
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(body["success"])
        self.addCleanup(lambda: self._drop_table(table_name))

        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.insert",
                    "table": table_name,
                    "payload": {"data": {"biz_id": "pg001", "name": "v1"}},
                    "options": {},
                }
            },
        )
        self._post(
            "/pg/db/data",
            {
                "spec": {
                    "action": "data.update",
                    "table": table_name,
                    "payload": {"query": {"biz_id": "pg001"}, "data": {"name": "v2"}},
                    "options": {},
                }
            },
        )

        job_id = f"pg-ops-{uuid.uuid4().hex[:8]}"
        resp, body = self._post(
            "/pg/db/ops/snapshot-and-compact",
            {
                "request_id": job_id,
                "dry_run": False,
                "targets": [table_name],
                "archive": {"enabled": True, "mode": "internal"},
                "strategy": {"mode": "auto", "compact_before": "2999-01-01T00:00:00Z"},
            },
        )
        self.assertEqual(resp.status_code, 202)
        self.assertTrue(body["success"])

        job_resp = self.client.get(f"/pg/db/ops/jobs/{job_id}")
        self.assertEqual(job_resp.status_code, 200)
        job_body = job_resp.get_json()
        self.assertTrue(job_body["success"])
