import db_api_test_base as support
from db_api_test_base import *

from specdb.db_executor import init_database
from specdb.install import install_schema, install_suite


class _SharedAppProxy:
    def __getattr__(self, name):
        target = support.app
        if target is None:
            raise AttributeError(f"test app is not initialized: {name}")
        return getattr(target, name)


app = _SharedAppProxy()


class DBInstallTestCase(DBApiTestBase):
    def test_install_schema_installs_multiple_define_specs(self):
        user_table = self._table_name("install_users")
        role_table = self._table_name("install_roles")
        self.addCleanup(lambda: self._drop_table(user_table))
        self.addCleanup(lambda: self._drop_table(role_table))

        define_specs = [
            {
                "action": "table.define",
                "table": user_table,
                "payload": {
                    "schema": {
                        "id": {"type": "int", "primary": True, "auto_increment": True},
                        "username": {"type": "str", "nullable": False},
                    }
                },
                "options": {},
            },
            {
                "action": "table.define",
                "table": role_table,
                "payload": {
                    "schema": {
                        "id": {"type": "int", "primary": True, "auto_increment": True},
                        "role_key": {"type": "str", "nullable": False, "unique": True},
                    }
                },
                "options": {},
            },
        ]

        with app.app_context():
            result = install_schema(init_database(), define_specs)

        self.assertTrue(result["success"], result)
        self.assertCountEqual(result["data"]["installed"], [user_table, role_table])
        self.assertEqual(result["data"]["skipped"], [])
        self.assertEqual(result["data"]["failed"], [])

    def test_install_schema_validates_all_specs_before_any_execution(self):
        user_table = self._table_name("install_precheck_users")
        self.addCleanup(lambda: self._drop_table(user_table))

        define_specs = [
            {
                "action": "table.define",
                "table": user_table,
                "payload": {
                    "schema": {
                        "id": {"type": "int", "primary": True, "auto_increment": True},
                        "username": {"type": "str", "nullable": False},
                    }
                },
                "options": {},
            },
            {
                "action": "data.insert",
                "table": "bad_spec",
                "payload": {},
                "options": {},
            },
        ]

        with app.app_context():
            result = install_schema(init_database(), define_specs)

        self.assertFalse(result["success"], result)
        self.assertTrue(any(item["table"] == "bad_spec" for item in result["data"]["failed"]))

        resp, body = self._post("/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}})
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn(user_table, body["data"])

    def test_install_suite_installs_admin_basic_suite_and_returns_seed_sets(self):
        tracked_tables = [
            "users",
            "rbac_roles",
            "rbac_pages",
            "rbac_permissions",
            "rbac_user_roles",
            "rbac_role_page_access",
            "rbac_role_permissions",
            "content_categories",
            "content_tags",
            "content_articles",
            "content_article_tags",
            "site_settings",
            "media_assets",
        ]
        for table_name in tracked_tables:
            self.addCleanup(lambda name=table_name: self._drop_table(name))

        with app.app_context():
            result = install_suite(init_database(), "admin_basic_suite_v1")

        self.assertTrue(result["success"], result)
        self.assertEqual(result["data"]["suite_key"], "admin_basic_suite_v1")
        self.assertEqual(result["data"]["selected_templates"][0]["template_key"], "user_standard_v2")
        self.assertIn("roles", result["data"]["recommended_seed_sets"])
        self.assertIn("role_permissions", result["data"]["recommended_seed_sets"])
        self.assertFalse(result["data"]["has_relation_cycles"])
        installed_tables = {item["table"] for item in result["data"]["installed_templates"]}
        self.assertIn("users", installed_tables)
        self.assertIn("rbac_role_permissions", installed_tables)

        resp, body = self._post("/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}})
        self.assertEqual(resp.status_code, 200)
        for table_name in ("users", "rbac_roles", "content_articles", "site_settings"):
            self.assertIn(table_name, body["data"])

    def test_install_suite_supports_include_and_exclude_filters(self):
        for table_name in ("rbac_roles", "rbac_pages"):
            self.addCleanup(lambda name=table_name: self._drop_table(name))

        with app.app_context():
            result = install_suite(
                init_database(),
                "admin_basic_suite_v1",
                include_templates=["rbac_role_v1", "rbac_page_v1", "user_standard_v2"],
                exclude_templates=["user_standard_v2"],
            )

        self.assertTrue(result["success"], result)
        selected = [item["template_key"] for item in result["data"]["selected_templates"]]
        self.assertEqual(selected, ["rbac_role_v1", "rbac_page_v1"])
        installed_tables = {item["table"] for item in result["data"]["installed_templates"]}
        self.assertEqual(installed_tables, {"rbac_roles", "rbac_pages"})
        self.assertEqual(result["data"]["recommended_template_order"], ["rbac_role_v1", "rbac_page_v1"])
        self.assertEqual(result["data"]["recommended_table_order"], ["rbac_roles", "rbac_pages"])
        self.assertEqual(result["data"]["recommended_seed_sets"], ["pages", "roles"])
        self.assertEqual(result["data"]["dependencies"], {"rbac_roles": [], "rbac_pages": []})
        self.assertFalse(result["data"]["has_relation_cycles"])

        resp, body = self._post("/api/db/table", {"spec": {"action": "table.list", "payload": {}, "options": {}}})
        self.assertEqual(resp.status_code, 200)
        self.assertIn("rbac_roles", body["data"])
        self.assertIn("rbac_pages", body["data"])
        self.assertNotIn("users", body["data"])

    def test_install_suite_accepts_safe_template_overrides(self):
        self.addCleanup(lambda: self._drop_table("users"))

        with app.app_context():
            result = install_suite(
                init_database(),
                "admin_basic_suite_v1",
                include_templates=["user_standard_v2"],
                template_overrides={"user_standard_v2": {"schema": {"bio": {"length": 240}}}},
            )

        self.assertTrue(result["success"], result)

        resp, body = self._post(
            "/api/db/table",
            {
                "spec": {
                    "action": "table.describe",
                    "table": "users",
                    "payload": {},
                    "options": {},
                }
            },
        )
        self.assertEqual(resp.status_code, 200)
        columns = {item["key"]: item for item in body["data"]["columns"]}
        self.assertEqual(columns["bio"]["type"], "VARCHAR(240)")

    def test_install_suite_rejects_invalid_template_override(self):
        with app.app_context():
            with self.assertRaises(ValueError):
                install_suite(
                    init_database(),
                    "admin_basic_suite_v1",
                    include_templates=["user_standard_v2"],
                    template_overrides={"user_standard_v2": {"schema": {"username": {"type": "text"}}}},
                )


if __name__ == "__main__":
    unittest.main()
