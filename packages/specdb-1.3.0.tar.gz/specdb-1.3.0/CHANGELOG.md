# 变更记录

## 1.3.0 - 2026-03-10

- 把 `specdb` 主包补齐为更完整的可落地数据库模块，新增正式安装层 `specdb.install`。
- 正式提供 `install_schema`、`install_suite`、`install_seed`、`install_seed_file`、`load_seed_bundle`、`reset_dev_database`、`verify_installation`。
- 补齐 JSON / YAML seed loader，并把 seed 安装的幂等、失败返回结构与 suite seed-set 校验收口为稳定契约。
- 新增 `install_seed(..., atomic=True)`，让单次 seed 安装可以在单事务中完成查询、引用解析和写入。
- 收紧默认 `ops` 鉴权策略：未声明环境的非测试 app 默认要求 `ops_auth_callback`。
- 继续统一 tracking helper 的事务边界，补齐 `delete_table_options(conn)` 并让 `table.drop` / `table.alter` 复用既有连接。
- 冻结主包稳定入口范围，明确 `specdb`、`specdb.install`、`specdb.db_templates` 的正式承诺边界。
- 加固 `verify_package.py`，把安装层 helper 和模板 helper 纳入本地 wheel 安装验收。

## 1.2.0 - 2026-03-09

- 补齐 `table.alter.modify` 第二阶段稳定支持，覆盖单字段 `index`、单字段 `unique` 和字符串族 `length` 调整。
- 让 `relation` 元数据真正进入建表顺序推导、suite 初始化顺序推导与 `restore-from-logs` 风险摘要链路。
- 新增 PostgreSQL-only、显式 opt-in 的真实外键支持，覆盖 `table.define` 与 `table.alter add`。
- 继续硬化 `ops` 链路，统一 job summary / restore audit 结构，并收紧 retry 请求边界。
- 补齐模板与 suite 的关系治理，新增 seed bundle 校验、受控 override 校验和 suite 安装顺序计划。
- 收紧执行器跨数据库契约，稳定暴露 `table.describe` 列级 contract 信息与 `table.backup.source_contract`。
- 完成一轮核心代码结构收口，拆分 `table_actions`、`ops_jobs_store`、`job_runtime`、`restore_routes`，提升后续维护和冻结稳定性。
- 修复打包配置，改为自动发现 `specdb*` 子包，确保 `executor/` 与 `ops/` 子包进入 `wheel` 与 `sdist`。
- 收紧构建与验收脚本的临时目录策略，改为使用唯一临时工作目录，避免残留 `package_tmp/verify_tmp` 阻塞发布链路。

## 1.1.0 - 2026-03-09

- 补齐 `table.alter.modify` 第一阶段稳定支持，覆盖 `nullable`、字面量 `default` 与受限字符串族 `type/length` 变更。
- 新增统一执行前校验层，将一批 `table.*` / `data.*` 结构错误前移到数据库执行前暴露。
- 将 PostgreSQL 集成回归提升为正式核心回归矩阵，覆盖 `table.alter`、`append_only_versioned`、`restore-from-logs`、`snapshot-and-compact` 等关键链路。
- 在 `table.define` / `table.alter add` / `table.describe` / `table.backup` 中落地字段级 `relation` 元数据。
- 强化 `ops` 任务生命周期状态机，收紧非法状态跳转和 retry 边界。
- 补齐模板 suite 治理与 rules/schema 一致性校验，新增 `list_template_suites()` / `get_template_suite()` 对外入口。
- 修复 `backend/scripts/run_tests.py` 的导入路径基线，使全量回归 discover 稳定通过。

## 1.0.0 - 2026-03-08

- 将当前 `specdb` 后端核心确认为第一个稳定版发布基线。
- 加固了 production 默认值、DB 模块初始化路径以及 ops 鉴权约束。
- 完成了多 scope 的 ops 隔离、带租约的任务恢复、归档副作用保护以及重试一致性修复。
- 统一了 SQLite 与 PostgreSQL 下 API 序列化、恢复和 ops 错误契约。
- 补充了 `1.0.0` 里程碑发布说明，并同步稳定性评估状态。

## 0.2.0 - 2026-03-07

- 新增本地 `.env` 自动加载，并保留显式环境变量优先级。
- 打通前端 API 访问、Vite 代理、lint、build 和最小 CRUD 演示流程。
- 增加后端测试、前端 lint/build、发布包构建校验的 CI 检查。
- 增加本地 PostgreSQL 校验、兼容性修复以及跨数据库差异说明。
- 为 `append_only_versioned` 新增按 `entity_id` 的历史查询和实体/版本分页能力。
- 增加 `specdb` 本地打包与隔离安装校验脚本。

## 模板

- Added:
- Changed:
- Fixed:
- Docs:
