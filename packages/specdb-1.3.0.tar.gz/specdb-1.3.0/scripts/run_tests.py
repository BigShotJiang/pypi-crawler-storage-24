"""后端一键测试运行入口。"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

from dotenv import load_dotenv


def _load_local_dotenv(base_dir: Path) -> None:
    root_dir = base_dir.parent
    for dotenv_path in (root_dir / ".env", base_dir / ".env"):
        if dotenv_path.exists():
            load_dotenv(dotenv_path=dotenv_path, override=False)


def _looks_like_postgres_url(value: str | None) -> bool:
    if not value:
        return False
    normalized = value.strip().lower()
    return normalized.startswith("postgresql") or normalized.startswith("postgres://")


def main() -> int:
    base_dir = Path(__file__).resolve().parents[1]
    _load_local_dotenv(base_dir)
    base_dir_str = str(base_dir)
    if base_dir_str not in sys.path:
        sys.path.insert(0, base_dir_str)

    if not os.getenv("DATABASE_URL_PG"):
        database_url = os.getenv("DATABASE_URL", "")
        if _looks_like_postgres_url(database_url):
            os.environ["DATABASE_URL_PG"] = database_url

    tests_dir = base_dir / "tests"
    suite = unittest.defaultTestLoader.discover(str(tests_dir), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
