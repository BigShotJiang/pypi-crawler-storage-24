"""校验构建后的 wheel 能否在隔离虚拟环境中安装并导入。"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import tomllib
import venv


def _python_path(venv_dir: Path) -> Path:
    if sys.platform.startswith("win"):
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = str(raw).strip().lower()
    if value in {"1", "true", "yes", "on"}:
        return True
    if value in {"0", "false", "no", "off"}:
        return False
    return default


def _load_project_version(base_dir: Path) -> str:
    pyproject_data = tomllib.loads((base_dir / "pyproject.toml").read_text(encoding="utf-8"))
    return str(pyproject_data["project"]["version"])


def _resolve_dist_dir(base_dir: Path) -> Path:
    override = os.getenv("SPECDB_PACKAGE_DIST_DIR", "").strip()
    if not override:
        return base_dir / "package_dist"
    candidate = Path(override)
    if not candidate.is_absolute():
        candidate = base_dir / candidate
    return candidate


def _resolve_tmp_parent_dir(base_dir: Path) -> Path:
    override = os.getenv("SPECDB_VERIFY_TMP_ROOT", "").strip()
    if not override:
        return base_dir / ".tmp"
    candidate = Path(override)
    if not candidate.is_absolute():
        candidate = base_dir / candidate
    return candidate


def main() -> int:
    base_dir = Path(__file__).resolve().parents[1]
    dist_dir = _resolve_dist_dir(base_dir)
    expected_version = _load_project_version(base_dir)
    wheel = next(dist_dir.glob("specdb-*.whl"), None)
    if wheel is None:
        raise FileNotFoundError(f"wheel not found in {dist_dir}; run scripts/build_package.py first")

    tmp_parent_dir = _resolve_tmp_parent_dir(base_dir)
    tmp_parent_dir.mkdir(parents=True, exist_ok=True)
    verify_dir = Path(tempfile.mkdtemp(prefix="verify-venv-", dir=tmp_parent_dir))
    tmp_root = Path(tempfile.mkdtemp(prefix="verify-tmp-", dir=tmp_parent_dir))

    allow_system_site_packages = _env_bool("VERIFY_ALLOW_SYSTEM_SITE_PACKAGES", False)
    original_tmp = os.environ.get("TMP")
    original_temp = os.environ.get("TEMP")
    child_env = os.environ.copy()
    try:
        child_env["TMP"] = str(tmp_root)
        child_env["TEMP"] = str(tmp_root)
        os.environ["TMP"] = str(tmp_root)
        os.environ["TEMP"] = str(tmp_root)
        venv.create(
            verify_dir,
            with_pip=True,
            clear=True,
            system_site_packages=allow_system_site_packages,
        )
        python_bin = _python_path(verify_dir)

        install_cmd = [str(python_bin), "-m", "pip", "install"]
        if allow_system_site_packages:
            install_cmd.append("--no-deps")
        install_cmd.append(str(wheel))
        subprocess.run(
            install_cmd,
            cwd=base_dir,
            check=True,
            env=child_env,
        )
        subprocess.run(
            [
                str(python_bin),
                "-c",
                (
                    "import importlib.metadata as md; "
                    "import specdb; "
                    "import specdb.install as install_mod; "
                    "import specdb.db_templates as template_mod; "
                    "from specdb.db_module import init_db_module; "
                    "from specdb import "
                    "install_schema, install_suite, install_seed, verify_installation, "
                    "list_templates, get_template_suite_install_plan, get_template_suite_seed_sets; "
                    f"expected = {expected_version!r}; "
                    "actual = md.version('specdb'); "
                    "assert actual == expected, f'expected {expected}, got {actual}'; "
                    "assert callable(init_db_module); "
                    "assert callable(install_schema); "
                    "assert callable(install_suite); "
                    "assert callable(install_seed); "
                    "assert callable(verify_installation); "
                    "assert callable(list_templates); "
                    "assert callable(get_template_suite_install_plan); "
                    "assert callable(get_template_suite_seed_sets); "
                    "assert callable(install_mod.install_seed_file); "
                    "assert callable(install_mod.load_seed_bundle); "
                    "assert callable(template_mod.get_template); "
                    "assert callable(template_mod.validate_template_suite_seed_sets); "
                    "print('verify-ok'); "
                    "print(actual); "
                    "print(hasattr(specdb, '__all__')); "
                    "print(callable(init_db_module)); "
                    "print(callable(install_schema)); "
                    "print(callable(template_mod.get_template))"
                ),
            ],
            cwd=base_dir,
            check=True,
            env=child_env,
        )
        print("verify-mode=relaxed" if allow_system_site_packages else "verify-mode=strict")
        return 0
    finally:
        if original_tmp is None:
            os.environ.pop("TMP", None)
        else:
            os.environ["TMP"] = original_tmp
        if original_temp is None:
            os.environ.pop("TEMP", None)
        else:
            os.environ["TEMP"] = original_temp
        shutil.rmtree(tmp_root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
