"""在无网络环境下为 specdb 构建 wheel 和 sdist。"""

from __future__ import annotations

import io
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
import tomllib


def _load_project_metadata(base_dir: Path) -> dict[str, object]:
    pyproject_data = tomllib.loads((base_dir / "pyproject.toml").read_text(encoding="utf-8"))
    return dict(pyproject_data["project"])


def _load_project_version(base_dir: Path) -> str:
    return str(_load_project_metadata(base_dir)["version"])


def _cleanup_dist_temp_dirs(dist_dir: Path) -> None:
    if not dist_dir.exists():
        return
    for path in dist_dir.iterdir():
        if path.is_dir() and path.name.startswith(".tmp-"):
            shutil.rmtree(path, ignore_errors=True)


def _validate_changelog_contains_version(base_dir: Path, version: str) -> None:
    changelog_text = (base_dir / "CHANGELOG.md").read_text(encoding="utf-8")
    version_header = f"## {version}"
    if version_header not in changelog_text:
        raise RuntimeError(f"{version_header!r} not found in CHANGELOG.md")


def _resolve_dist_dir(base_dir: Path) -> Path:
    override = os.getenv("SPECDB_PACKAGE_DIST_DIR", "").strip()
    if not override:
        return base_dir / "package_dist"
    candidate = Path(override)
    if not candidate.is_absolute():
        candidate = base_dir / candidate
    return candidate


def _resolve_tmp_parent_dir(base_dir: Path) -> Path:
    override = os.getenv("SPECDB_PACKAGE_TMP_ROOT", "").strip()
    if not override:
        return base_dir / ".tmp"
    candidate = Path(override)
    if not candidate.is_absolute():
        candidate = base_dir / candidate
    return candidate


def _iter_sdist_sources(base_dir: Path) -> list[Path]:
    source_patterns = [
        "README.md",
        "CHANGELOG.md",
        "MANIFEST.in",
        "pyproject.toml",
        "specdb/**/*.py",
        "specdb/**/py.typed",
        "tests/**/*.py",
        "tests/**/*.md",
        "examples/**/*.py",
        "examples/**/*.md",
        "docs/**/*.md",
        "scripts/**/*.py",
    ]
    collected: set[Path] = set()
    for pattern in source_patterns:
        for path in base_dir.glob(pattern):
            if path.is_file():
                collected.add(path)
    return sorted(collected, key=lambda item: item.relative_to(base_dir).as_posix())


def _build_pkg_info(base_dir: Path, metadata: dict[str, object]) -> bytes:
    lines = [
        "Metadata-Version: 2.4",
        f"Name: {metadata['name']}",
        f"Version: {metadata['version']}",
    ]

    description = str(metadata.get("description", "")).strip()
    if description:
        lines.append(f"Summary: {description}")

    requires_python = str(metadata.get("requires-python", "")).strip()
    if requires_python:
        lines.append(f"Requires-Python: {requires_python}")

    readme_value = metadata.get("readme")
    body = ""
    if isinstance(readme_value, str) and readme_value:
        lines.append("Description-Content-Type: text/markdown")
        body = (base_dir / readme_value).read_text(encoding="utf-8")

    for requirement in metadata.get("dependencies", []) or []:
        lines.append(f"Requires-Dist: {requirement}")

    return ("\n".join(lines) + "\n\n" + body).encode("utf-8")


def _build_sdist(base_dir: Path, dist_dir: Path, version: str) -> str:
    sdist_name = f"specdb-{version}.tar.gz"
    sdist_path = dist_dir / sdist_name
    archive_root = f"specdb-{version}"
    metadata = _load_project_metadata(base_dir)
    pkg_info_bytes = _build_pkg_info(base_dir, metadata)
    with tarfile.open(sdist_path, "w:gz") as tar:
        pkg_info = tarfile.TarInfo(f"{archive_root}/PKG-INFO")
        pkg_info.size = len(pkg_info_bytes)
        tar.addfile(pkg_info, fileobj=io.BytesIO(pkg_info_bytes))
        for source_path in _iter_sdist_sources(base_dir):
            arcname = f"{archive_root}/{source_path.relative_to(base_dir).as_posix()}"
            tar.add(source_path, arcname=arcname)
    return sdist_name


def main() -> int:
    base_dir = Path(__file__).resolve().parents[1]
    dist_dir = _resolve_dist_dir(base_dir)
    tmp_parent_dir = _resolve_tmp_parent_dir(base_dir)
    version = _load_project_version(base_dir)
    _validate_changelog_contains_version(base_dir, version)
    if dist_dir.exists():
        shutil.rmtree(dist_dir, ignore_errors=True)
    dist_dir.mkdir(parents=True, exist_ok=True)
    tmp_parent_dir.mkdir(parents=True, exist_ok=True)
    tmp_root = Path(tempfile.mkdtemp(prefix="package-build-", dir=tmp_parent_dir))
    _cleanup_dist_temp_dirs(dist_dir)

    original_cwd = Path.cwd()
    original_tmp = os.environ.get("TMP")
    original_temp = os.environ.get("TEMP")
    os.chdir(base_dir)
    try:
        os.environ["TMP"] = str(tmp_root)
        os.environ["TEMP"] = str(tmp_root)
        sdist_name = _build_sdist(base_dir, dist_dir, version)
        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "wheel",
                ".",
                "--no-deps",
                "--no-build-isolation",
                "-w",
                str(dist_dir),
            ],
            check=True,
            cwd=base_dir,
            env=os.environ.copy(),
        )
        wheel_name = next(dist_dir.glob("specdb-*.whl")).name
    finally:
        os.chdir(original_cwd)
        if original_tmp is None:
            os.environ.pop("TMP", None)
        else:
            os.environ["TMP"] = original_tmp
        if original_temp is None:
            os.environ.pop("TEMP", None)
        else:
            os.environ["TEMP"] = original_temp
        shutil.rmtree(tmp_root, ignore_errors=True)
        _cleanup_dist_temp_dirs(dist_dir)

    expected_sdist = f"specdb-{version}.tar.gz"
    if sdist_name != expected_sdist:
        raise RuntimeError(f"unexpected sdist artifact: expected {expected_sdist}, got {sdist_name}")
    if not wheel_name.startswith(f"specdb-{version}-") or not wheel_name.endswith(".whl"):
        raise RuntimeError(f"unexpected wheel artifact: {wheel_name}")

    artifacts = sorted(path.name for path in dist_dir.iterdir() if path.is_file()) if dist_dir.exists() else []
    if artifacts != sorted([sdist_name, wheel_name]):
        raise RuntimeError(f"unexpected artifact set: {artifacts}")
    print("build-ok")
    print(dist_dir)
    print(sdist_name)
    print(wheel_name)
    for artifact in artifacts:
        print(artifact)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
