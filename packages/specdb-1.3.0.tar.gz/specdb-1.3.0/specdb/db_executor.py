﻿"""Backward-compatible executor entrypoint."""

from __future__ import annotations

from specdb.executor.client import DatabaseClient, init_database
from specdb.executor.errors import DBExecuteError, error_payload, success_payload
from specdb.executor.internal_tables import (
    _CHANGE_LOG,
    _INTERNAL_METADATA,
    _TABLE_OPTIONS,
    delete_change_logs_for_table,
    ensure_internal_tables,
    is_internal_table_name,
    list_public_table_names,
    list_table_tracking_strategies,
)

__all__ = [
    "DBExecuteError",
    "DatabaseClient",
    "_CHANGE_LOG",
    "_INTERNAL_METADATA",
    "_TABLE_OPTIONS",
    "delete_change_logs_for_table",
    "ensure_internal_tables",
    "error_payload",
    "init_database",
    "is_internal_table_name",
    "list_public_table_names",
    "list_table_tracking_strategies",
    "success_payload",
]
