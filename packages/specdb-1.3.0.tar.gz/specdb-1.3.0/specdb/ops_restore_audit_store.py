﻿"""`restore-from-logs` 操作使用的持久化审计存储。"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Boolean, Column, DateTime, Integer, MetaData, String, Table, Text, and_, func, inspect, select, text

from specdb.db_init_guard import EngineInitGuard
from specdb.db_runtime import db
from specdb.ops.store_common import (
    _decode_json_object_strict,
    _normalize_datetime_value,
    _normalize_ops_context,
)

_metadata = MetaData()
_restore_audit_table = Table(
    "db_ops_restore_audit",
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("table_name", String(128), nullable=False),
    Column("selector_json", Text, nullable=False),
    Column("restored_logs", Integer, nullable=False),
    Column("requested_logs", Integer, nullable=False),
    Column("dry_run", Boolean, nullable=False),
    Column("operator", String(128), nullable=True),
    Column("node", String(128), nullable=True),
    Column("scope_key", String(128), nullable=True),
    Column("context_json", Text, nullable=True),
    Column("result_json", Text, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
)
_init_guard = EngineInitGuard()


def _quote_identifier(engine: Any, identifier: str) -> str:
    return engine.dialect.identifier_preparer.quote_identifier(identifier)


def _ensure_optional_restore_audit_columns(engine: Any) -> None:
    inspector = inspect(engine)
    column_names = {str(item.get("name")) for item in inspector.get_columns(_restore_audit_table.name)}
    missing_columns: list[str] = []
    for column_name in ("scope_key", "context_json", "result_json"):
        if column_name not in column_names:
            missing_columns.append(column_name)
    if not missing_columns:
        return
    table_name = _quote_identifier(engine, _restore_audit_table.name)
    statements: list[str] = []
    if "scope_key" in missing_columns:
        statements.append(
            f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'scope_key')} {String(128).compile(dialect=engine.dialect)}"
        )
    if "context_json" in missing_columns:
        statements.append(
            f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'context_json')} {Text().compile(dialect=engine.dialect)}"
        )
    if "result_json" in missing_columns:
        statements.append(
            f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'result_json')} {Text().compile(dialect=engine.dialect)}"
        )
    with engine.begin() as conn:
        for statement in statements:
            conn.execute(text(statement))


def _serialize_restore_audit_row(row: dict[str, Any]) -> dict[str, Any]:
    data = dict(row)
    data["created_at"] = _normalize_datetime_value(data.get("created_at"))
    row_id = data.get("id")
    data["selector"] = _decode_json_object_strict(
        data.pop("selector_json", None),
        field_name="selector_json",
        entity_name="restore_audit",
        entity_id=row_id,
    )
    context_json = data.pop("context_json", None)
    context = _decode_json_object_strict(
        context_json,
        field_name="context_json",
        entity_name="restore_audit",
        entity_id=row_id,
    ) if context_json is not None else _normalize_ops_context(
        scope_key=data.get("scope_key"),
        dry_run=data.get("dry_run", False),
        operator=data.get("operator"),
        node=data.get("node"),
    )
    data["context"] = context
    result_json = data.pop("result_json", None)
    result = _decode_json_object_strict(
        result_json,
        field_name="result_json",
        entity_name="restore_audit",
        entity_id=row_id,
    ) if result_json is not None else {
        "table": data.get("table_name"),
        "restored_logs": int(data.get("restored_logs") or 0),
        "requested_logs": int(data.get("requested_logs") or 0),
    }
    data["result"] = result
    return data


def ensure_restore_audit_table() -> None:
    engine = db.engine

    def _initializer() -> None:
        _metadata.create_all(bind=engine, tables=[_restore_audit_table], checkfirst=True)
        _ensure_optional_restore_audit_columns(engine)

    def _is_initialized() -> bool:
        if not inspect(engine).has_table(_restore_audit_table.name):
            return False
        column_names = {str(item.get("name")) for item in inspect(engine).get_columns(_restore_audit_table.name)}
        return {"scope_key", "context_json", "result_json"}.issubset(column_names)

    _init_guard.ensure(engine, _initializer, is_initialized=_is_initialized)


def insert_restore_audit(
    *,
    table_name: str,
    selector: dict[str, Any],
    restored_logs: int,
    requested_logs: int,
    dry_run: bool,
    operator: str | None,
    node: str | None,
    scope_key: str | None,
    relationship_risks: dict[str, Any] | None = None,
    conn: Any | None = None,
) -> None:
    ensure_restore_audit_table()
    now = datetime.now(timezone.utc)
    context_payload = _normalize_ops_context(
        scope_key=scope_key,
        dry_run=dry_run,
        operator=operator,
        node=node,
    )
    result_payload: dict[str, Any] = {
        "table": table_name,
        "restored_logs": int(restored_logs),
        "requested_logs": int(requested_logs),
    }
    if isinstance(relationship_risks, dict):
        result_payload["relationship_risks"] = relationship_risks
    values = _restore_audit_table.insert().values(
        table_name=table_name,
        selector_json=json.dumps(selector, ensure_ascii=False),
        restored_logs=int(restored_logs),
        requested_logs=int(requested_logs),
        dry_run=bool(dry_run),
        operator=operator,
        node=node,
        scope_key=scope_key,
        context_json=json.dumps(context_payload, ensure_ascii=False),
        result_json=json.dumps(result_payload, ensure_ascii=False),
        created_at=now,
    )
    if conn is not None:
        conn.execute(values)
        return
    with db.engine.begin() as local_conn:
        local_conn.execute(
            values
        )


def list_restore_audits(
    *,
    table_name: str | None,
    operator: str | None,
    node: str | None,
    dry_run: bool | None,
    from_created_at: datetime | None,
    to_created_at: datetime | None,
    limit: int,
    offset: int,
) -> list[dict[str, Any]]:
    ensure_restore_audit_table()
    filters: list[Any] = []
    if table_name:
        filters.append(_restore_audit_table.c.table_name == table_name)
    if operator:
        filters.append(_restore_audit_table.c.operator == operator)
    if node:
        filters.append(_restore_audit_table.c.node == node)
    if dry_run is not None:
        filters.append(_restore_audit_table.c.dry_run.is_(dry_run))
    if from_created_at is not None:
        filters.append(_restore_audit_table.c.created_at >= from_created_at)
    if to_created_at is not None:
        filters.append(_restore_audit_table.c.created_at <= to_created_at)

    stmt = select(_restore_audit_table).order_by(_restore_audit_table.c.id.desc()).limit(limit).offset(offset)
    if filters:
        stmt = stmt.where(and_(*filters))

    with db.engine.begin() as conn:
        rows = conn.execute(stmt).mappings().all()

    return [_serialize_restore_audit_row(dict(row)) for row in rows]


def cleanup_restore_audits(*, older_than: datetime, dry_run: bool) -> int:
    ensure_restore_audit_table()
    with db.engine.begin() as conn:
        count_stmt = select(func.count()).select_from(_restore_audit_table).where(_restore_audit_table.c.created_at < older_than)
        count = int(conn.execute(count_stmt).scalar() or 0)
        if not dry_run and count > 0:
            conn.execute(_restore_audit_table.delete().where(_restore_audit_table.c.created_at < older_than))
    return count


def delete_restore_audits_for_table(table_name: str, *, conn: Any | None = None) -> int:
    ensure_restore_audit_table()
    delete_stmt = _restore_audit_table.delete().where(_restore_audit_table.c.table_name == table_name)
    if conn is not None:
        result = conn.execute(delete_stmt)
        return int(result.rowcount or 0)
    with db.engine.begin() as local_conn:
        result = local_conn.execute(delete_stmt)
    return int(result.rowcount or 0)

