﻿"""specdb：基于 schema/spec 的通用数据库模块。"""

from specdb.db_module import (
    DBModuleOptions,
    configure_db_module,
    init_db_module,
    init_db_module_tables,
    shutdown_db_module,
)
from specdb.db_templates import (
    assert_template_libraries_valid,
    build_define_spec,
    get_template,
    get_template_rules,
    get_template_suite,
    get_template_suite_install_plan,
    get_template_suite_seed_sets,
    list_templates,
    list_template_suites,
    validate_template_overrides,
    validate_template_suite_seed_sets,
    validate_template_libraries,
)
from specdb.install import (
    install_schema,
    install_seed,
    install_seed_file,
    install_suite,
    load_seed_bundle,
    reset_dev_database,
    verify_installation,
)

__all__ = [
    "DBModuleOptions",
    "configure_db_module",
    "init_db_module",
    "init_db_module_tables",
    "shutdown_db_module",
    "list_templates",
    "get_template",
    "build_define_spec",
    "get_template_rules",
    "list_template_suites",
    "get_template_suite",
    "get_template_suite_install_plan",
    "get_template_suite_seed_sets",
    "validate_template_suite_seed_sets",
    "validate_template_overrides",
    "validate_template_libraries",
    "assert_template_libraries_valid",
    "install_schema",
    "install_suite",
    "install_seed",
    "load_seed_bundle",
    "install_seed_file",
    "reset_dev_database",
    "verify_installation",
]



