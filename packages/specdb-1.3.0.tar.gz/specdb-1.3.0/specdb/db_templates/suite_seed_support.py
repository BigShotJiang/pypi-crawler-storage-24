"""Support helpers for template-suite seed-set validation."""

from __future__ import annotations

from typing import Any


def validate_suite_seed_sets(suite_key: str, suite: dict[str, Any], suite_seed_sets: dict[str, Any]) -> dict[str, list[str]]:
    if not isinstance(suite_seed_sets, dict):
        return {"errors": ["suite seed sets must be dict"], "warnings": []}

    errors: list[str] = []
    warnings: list[str] = []
    seed_sets = suite.get("seed_sets", {})
    if not isinstance(seed_sets, dict):
        return {"errors": [f"template suite {suite_key} has invalid seed_sets"], "warnings": []}

    identities: dict[str, set[str]] = {}
    for seed_set_key, seed_spec in seed_sets.items():
        entries = suite_seed_sets.get(seed_set_key, [])
        if entries is None:
            entries = []
        if not isinstance(entries, list):
            errors.append(f"seed set {seed_set_key} must be list")
            continue
        identity_field = seed_spec.get("identity_field")
        required_fields = seed_spec.get("required_fields", [])
        references = seed_spec.get("references", {})
        collected_identities: set[str] = set()
        seen_identities: dict[str, int] = {}
        for index, entry in enumerate(entries):
            if not isinstance(entry, dict):
                errors.append(f"seed set {seed_set_key}[{index}] must be dict")
                continue
            for field_name in required_fields:
                value = entry.get(field_name)
                if value is None or (isinstance(value, str) and not value.strip()):
                    errors.append(f"seed set {seed_set_key}[{index}] missing required field: {field_name}")
            if isinstance(identity_field, str):
                identity_value = entry.get(identity_field)
                if identity_value is None or (isinstance(identity_value, str) and not identity_value.strip()):
                    errors.append(f"seed set {seed_set_key}[{index}] missing identity field: {identity_field}")
                else:
                    normalized_identity = identity_value if isinstance(identity_value, str) else str(identity_value)
                    prior_index = seen_identities.get(normalized_identity)
                    if prior_index is not None:
                        errors.append(
                            f"seed set {seed_set_key}[{index}] duplicates identity "
                            f"{identity_field}={normalized_identity!r} from entry {prior_index}"
                        )
                    else:
                        seen_identities[normalized_identity] = index
                    collected_identities.add(normalized_identity)
            if isinstance(references, dict):
                for reference_field in references:
                    if reference_field not in required_fields and entry.get(reference_field) is None:
                        continue
        identities[seed_set_key] = collected_identities

    for provided_seed_set in suite_seed_sets:
        if provided_seed_set not in seed_sets:
            warnings.append(f"unknown seed set ignored: {provided_seed_set}")

    for seed_set_key, seed_spec in seed_sets.items():
        entries = suite_seed_sets.get(seed_set_key, [])
        if not isinstance(entries, list):
            continue
        references = seed_spec.get("references", {})
        if not isinstance(references, dict):
            continue
        for index, entry in enumerate(entries):
            if not isinstance(entry, dict):
                continue
            for reference_field, reference_spec in references.items():
                reference_value = entry.get(reference_field)
                if reference_value is None or (isinstance(reference_value, str) and not reference_value.strip()):
                    continue
                target_seed_set = reference_spec.get("seed_set")
                target_identities = identities.get(target_seed_set, set())
                normalized_reference = reference_value if isinstance(reference_value, str) else str(reference_value)
                if normalized_reference not in target_identities:
                    errors.append(
                        f"seed set {seed_set_key}[{index}] missing referenced item: "
                        f"{reference_field} -> {target_seed_set}.{reference_spec.get('identity_field')}"
                        f"={normalized_reference}"
                    )

    return {"errors": errors, "warnings": warnings}
