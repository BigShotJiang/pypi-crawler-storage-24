"""Central registry for specdb template definitions and rules."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from specdb.db_templates.content_templates import CONTENT_RULE_LIBRARY, CONTENT_TEMPLATE_LIBRARY
from specdb.db_templates.identity_templates import IDENTITY_RULE_LIBRARY, IDENTITY_TEMPLATE_LIBRARY
from specdb.db_templates.registry_support import (
    apply_template_overrides as _apply_template_overrides_impl,
    build_template_suite_plan as _build_template_suite_plan_impl,
    validate_rules as _validate_rules_impl,
    validate_template_item as _validate_template_item_impl,
    validate_template_overrides as _validate_template_overrides_impl,
    validate_template_suite as _validate_template_suite_impl,
)
from specdb.db_templates.rbac_templates import RBAC_RULE_LIBRARY, RBAC_TEMPLATE_LIBRARY
from specdb.db_templates.site_templates import SITE_RULE_LIBRARY, SITE_TEMPLATE_LIBRARY
from specdb.db_templates.suite_seed_support import validate_suite_seed_sets

TEMPLATE_RECOMMENDED_KEY = "user_standard_v2"
TEMPLATE_SUITE_RECOMMENDED_KEY = "admin_basic_suite_v1"
_ALLOWED_SUMMARY_KEYS = (
    "template_key",
    "template_name",
    "version",
    "table",
    "description",
    "category",
    "stability",
    "scenarios",
)

TEMPLATE_LIBRARY = {
    **IDENTITY_TEMPLATE_LIBRARY,
    **RBAC_TEMPLATE_LIBRARY,
    **CONTENT_TEMPLATE_LIBRARY,
    **SITE_TEMPLATE_LIBRARY,
}

RULE_LIBRARY = {
    **IDENTITY_RULE_LIBRARY,
    **RBAC_RULE_LIBRARY,
    **CONTENT_RULE_LIBRARY,
    **SITE_RULE_LIBRARY,
}

TEMPLATE_SUITE_LIBRARY = {
    "admin_basic_suite_v1": {
        "suite_key": "admin_basic_suite_v1",
        "suite_name": "Admin Basic Suite v1",
        "version": "v1",
        "description": "Recommended baseline template suite for a small to medium website admin backend.",
        "stability": "stable",
        "scenarios": ["admin-console", "rbac", "content", "site-settings"],
        "template_keys": [
            "user_standard_v2",
            "rbac_role_v1",
            "rbac_page_v1",
            "rbac_permission_v1",
            "content_category_v1",
            "content_tag_v1",
            "site_setting_v1",
            "media_asset_v1",
            "content_article_v1",
            "rbac_user_role_v1",
            "rbac_role_page_access_v1",
            "rbac_role_permission_v1",
            "content_article_tag_v1",
        ],
        "seed_sets": {
            "users": {
                "template_key": "user_standard_v2",
                "table": "users",
                "identity_field": "username",
                "required_fields": ["username", "email", "password_hash"],
            },
            "roles": {
                "template_key": "rbac_role_v1",
                "table": "rbac_roles",
                "identity_field": "role_key",
                "required_fields": ["role_key", "role_name"],
            },
            "pages": {
                "template_key": "rbac_page_v1",
                "table": "rbac_pages",
                "identity_field": "page_key",
                "required_fields": ["page_key", "page_name", "route_path"],
            },
            "permissions": {
                "template_key": "rbac_permission_v1",
                "table": "rbac_permissions",
                "identity_field": "permission_key",
                "required_fields": ["permission_key", "permission_name", "resource_type", "resource_key", "module", "action"],
            },
            "categories": {
                "template_key": "content_category_v1",
                "table": "content_categories",
                "identity_field": "category_key",
                "required_fields": ["category_key", "category_name", "slug"],
            },
            "tags": {
                "template_key": "content_tag_v1",
                "table": "content_tags",
                "identity_field": "tag_key",
                "required_fields": ["tag_key", "tag_name", "slug"],
            },
            "articles": {
                "template_key": "content_article_v1",
                "table": "content_articles",
                "identity_field": "slug",
                "required_fields": ["title", "slug", "content"],
                "references": {
                    "author_ref": {"seed_set": "users", "identity_field": "username"},
                    "category_ref": {"seed_set": "categories", "identity_field": "category_key"},
                },
            },
            "site_settings": {
                "template_key": "site_setting_v1",
                "table": "site_settings",
                "identity_field": "setting_key",
                "required_fields": ["setting_key", "setting_name"],
            },
            "media_assets": {
                "template_key": "media_asset_v1",
                "table": "media_assets",
                "identity_field": "object_key",
                "required_fields": ["object_key", "file_name"],
                "references": {
                    "uploaded_by_user_ref": {"seed_set": "users", "identity_field": "username"},
                },
            },
            "user_roles": {
                "template_key": "rbac_user_role_v1",
                "table": "rbac_user_roles",
                "required_fields": ["user_ref", "role_ref"],
                "references": {
                    "user_ref": {"seed_set": "users", "identity_field": "username"},
                    "role_ref": {"seed_set": "roles", "identity_field": "role_key"},
                },
            },
            "role_page_access": {
                "template_key": "rbac_role_page_access_v1",
                "table": "rbac_role_page_access",
                "required_fields": ["role_ref", "page_ref"],
                "references": {
                    "role_ref": {"seed_set": "roles", "identity_field": "role_key"},
                    "page_ref": {"seed_set": "pages", "identity_field": "page_key"},
                },
            },
            "role_permissions": {
                "template_key": "rbac_role_permission_v1",
                "table": "rbac_role_permissions",
                "required_fields": ["role_ref", "permission_ref"],
                "references": {
                    "role_ref": {"seed_set": "roles", "identity_field": "role_key"},
                    "permission_ref": {"seed_set": "permissions", "identity_field": "permission_key"},
                },
            },
            "article_tags": {
                "template_key": "content_article_tag_v1",
                "table": "content_article_tags",
                "required_fields": ["article_ref", "tag_ref"],
                "references": {
                    "article_ref": {"seed_set": "articles", "identity_field": "slug"},
                    "tag_ref": {"seed_set": "tags", "identity_field": "tag_key"},
                },
            },
        },
    }
}


def _template_sort_key(item: dict) -> tuple[int, str]:
    return (0 if item["template_key"] == TEMPLATE_RECOMMENDED_KEY else 1, item["template_key"])


def _build_template_summary(item: dict) -> dict:
    summary = {}
    for key in _ALLOWED_SUMMARY_KEYS:
        if key in item:
            summary[key] = deepcopy(item[key])
    summary["recommended"] = item["template_key"] == TEMPLATE_RECOMMENDED_KEY
    summary["has_rules"] = item["template_key"] in RULE_LIBRARY
    return summary


def _build_template_suite_summary(item: dict) -> dict:
    plan = _build_template_suite_plan(item)
    return {
        "suite_key": item["suite_key"],
        "suite_name": item["suite_name"],
        "version": item["version"],
        "description": item["description"],
        "stability": item["stability"],
        "scenarios": deepcopy(item["scenarios"]),
        "template_keys": deepcopy(item["template_keys"]),
        "recommended_template_order": plan["recommended_template_order"],
        "recommended_table_order": plan["recommended_table_order"],
        "has_relation_cycles": plan["has_relation_cycles"],
        "seed_set_keys": sorted(item.get("seed_sets", {}).keys()),
        "has_seed_contract": bool(item.get("seed_sets")),
        "recommended": item["suite_key"] == TEMPLATE_SUITE_RECOMMENDED_KEY,
    }


def _validate_template(item: dict) -> list[str]:
    return _validate_template_item_impl(item)


def _validate_rules(template_key: str, rules: dict) -> list[str]:
    return _validate_rules_impl(template_key, rules, TEMPLATE_LIBRARY)


def _validate_template_suite(item: dict) -> list[str]:
    return _validate_template_suite_impl(item, TEMPLATE_LIBRARY)


def _build_template_suite_plan(item: dict) -> dict:
    return _build_template_suite_plan_impl(item, template_library=TEMPLATE_LIBRARY)


def validate_template_libraries() -> list[str]:
    """Validate template and rule consistency."""
    errors: list[str] = []

    if TEMPLATE_RECOMMENDED_KEY not in TEMPLATE_LIBRARY:
        errors.append(f"recommended template missing: {TEMPLATE_RECOMMENDED_KEY}")

    for item in TEMPLATE_LIBRARY.values():
        errors.extend(_validate_template(item))

    for template_key, rules in RULE_LIBRARY.items():
        if not isinstance(rules, dict):
            errors.append(f"rules {template_key} must be dict")
            continue
        errors.extend(_validate_rules(template_key, rules))

    if TEMPLATE_SUITE_RECOMMENDED_KEY not in TEMPLATE_SUITE_LIBRARY:
        errors.append(f"recommended template suite missing: {TEMPLATE_SUITE_RECOMMENDED_KEY}")

    for item in TEMPLATE_SUITE_LIBRARY.values():
        errors.extend(_validate_template_suite(item))

    return errors


def validate_template_suite_seed_sets(suite_key: str, suite_seed_sets: dict[str, Any]) -> dict[str, list[str]]:
    suite = TEMPLATE_SUITE_LIBRARY.get(suite_key)
    if suite is None:
        return {"errors": [f"template suite not found: {suite_key}"], "warnings": []}
    return validate_suite_seed_sets(suite_key, suite, suite_seed_sets)


def validate_template_suite_seed_bundle(suite_key: str, seed_bundle: dict[str, Any]) -> dict[str, list[str]]:
    """Compatibility alias for historical naming; use validate_template_suite_seed_sets()."""
    return validate_template_suite_seed_sets(suite_key, seed_bundle)


def validate_template_overrides(template_key: str, overrides: dict[str, Any]) -> list[str]:
    return _validate_template_overrides_impl(template_key, overrides, TEMPLATE_LIBRARY)


def _apply_template_overrides(template_key: str, payload: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    return _apply_template_overrides_impl(template_key, payload, overrides, template_library=TEMPLATE_LIBRARY)


def assert_template_libraries_valid() -> None:
    """Fail fast during import when the registry drifts."""
    errors = validate_template_libraries()
    if errors:
        raise ValueError("invalid template library: " + "; ".join(errors))


def list_templates() -> list[dict]:
    """Return template summaries."""
    return [_build_template_summary(item) for item in sorted(TEMPLATE_LIBRARY.values(), key=_template_sort_key)]


def list_template_suites() -> list[dict]:
    """Return template suite summaries."""
    items = sorted(
        TEMPLATE_SUITE_LIBRARY.values(),
        key=lambda item: (0 if item["suite_key"] == TEMPLATE_SUITE_RECOMMENDED_KEY else 1, item["suite_key"]),
    )
    return [_build_template_suite_summary(item) for item in items]


def get_template(template_key: str) -> dict | None:
    """Return a deep copy of a full template item."""
    item = TEMPLATE_LIBRARY.get(template_key)
    if item is None:
        return None
    return deepcopy(item)


def get_template_rules(template_key: str) -> dict | None:
    """Return a deep copy of template rules."""
    item = RULE_LIBRARY.get(template_key)
    if item is None:
        return None
    return deepcopy(item)


def get_template_suite(suite_key: str) -> dict | None:
    """Return a deep copy of a full template suite item."""
    item = TEMPLATE_SUITE_LIBRARY.get(suite_key)
    if item is None:
        return None
    copied = deepcopy(item)
    copied.update(_build_template_suite_plan(item))
    return copied


def get_template_suite_install_plan(suite_key: str) -> dict | None:
    """Return suite installation order and dependency details."""
    item = TEMPLATE_SUITE_LIBRARY.get(suite_key)
    if item is None:
        return None
    plan = _build_template_suite_plan(item)
    return {
        "suite_key": item["suite_key"],
        "suite_name": item["suite_name"],
        **deepcopy(plan),
    }


def get_template_suite_seed_sets(suite_key: str) -> dict[str, Any] | None:
    """Return a deep copy of the declared seed-set contract for a suite."""
    item = TEMPLATE_SUITE_LIBRARY.get(suite_key)
    if item is None:
        return None
    seed_sets = item.get("seed_sets", {})
    if not isinstance(seed_sets, dict):
        return None
    return deepcopy(seed_sets)


def build_define_spec(template_key: str, overrides: dict[str, Any] | None = None) -> dict | None:
    """Convert a template to a table.define spec."""
    item = get_template(template_key)
    if item is None:
        return None
    payload = item["payload"]
    if overrides:
        payload = _apply_template_overrides(template_key, payload, overrides)
    return {
        "action": "table.define",
        "table": item["table"],
        "payload": payload,
    }


assert_template_libraries_valid()
