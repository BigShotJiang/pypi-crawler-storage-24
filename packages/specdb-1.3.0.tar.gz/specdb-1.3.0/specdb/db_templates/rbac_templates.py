from __future__ import annotations

from specdb.db_templates._shared import auto_increment_primary_key, build_rules, timestamp_fields

RBAC_ROLE_V1 = {
    "template_key": "rbac_role_v1",
    "template_name": "RBAC 角色表",
    "version": "v1",
    "table": "rbac_roles",
    "description": "定义后台系统中的角色，如 super_admin、editor、operator。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "role-management"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "role_key": {"type": "str", "nullable": False, "unique": True, "length": 64},
            "role_name": {"type": "str", "nullable": False, "length": 80},
            "description": {"type": "str", "nullable": True, "length": 255},
            "status": {"type": "str", "nullable": False, "length": 20, "default": "active"},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_rbac_roles_role_key", "keys": ["role_key"], "unique": True},
            {"name": "idx_rbac_roles_status", "keys": ["status"], "unique": False},
            {"name": "idx_rbac_roles_created_at", "keys": ["created_at"], "unique": False},
        ],
    },
}

RBAC_PAGE_V1 = {
    "template_key": "rbac_page_v1",
    "template_name": "RBAC 页面表",
    "version": "v1",
    "table": "rbac_pages",
    "description": "定义后台页面节点，用于角色可访问页面控制。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "page-access"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "page_key": {"type": "str", "nullable": False, "unique": True, "length": 64},
            "page_name": {"type": "str", "nullable": False, "length": 80},
            "route_path": {"type": "str", "nullable": False, "unique": True, "length": 255},
            "parent_page_key": {
                "type": "str",
                "nullable": True,
                "length": 64,
                "relation": {
                    "target_table": "rbac_pages",
                    "target_column": "page_key",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "cascade",
                },
            },
            "icon": {"type": "str", "nullable": True, "length": 64},
            "sort_order": {"type": "int", "nullable": False, "default": 0},
            "status": {"type": "str", "nullable": False, "length": 20, "default": "active"},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_rbac_pages_page_key", "keys": ["page_key"], "unique": True},
            {"name": "uk_rbac_pages_route_path", "keys": ["route_path"], "unique": True},
            {"name": "idx_rbac_pages_parent_page_key", "keys": ["parent_page_key"], "unique": False},
            {"name": "idx_rbac_pages_status", "keys": ["status"], "unique": False},
            {"name": "idx_rbac_pages_sort_order", "keys": ["sort_order"], "unique": False},
        ],
    },
}

RBAC_PERMISSION_V1 = {
    "template_key": "rbac_permission_v1",
    "template_name": "RBAC 权限点表",
    "version": "v1",
    "table": "rbac_permissions",
    "description": "定义接口、按钮或资源级权限点。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "permission-management"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "permission_key": {"type": "str", "nullable": False, "unique": True, "length": 80},
            "permission_name": {"type": "str", "nullable": False, "length": 80},
            "resource_type": {"type": "str", "nullable": False, "length": 32},
            "resource_key": {"type": "str", "nullable": False, "length": 80},
            "module": {"type": "str", "nullable": False, "length": 50},
            "action": {"type": "str", "nullable": False, "length": 30},
            "description": {"type": "str", "nullable": True, "length": 255},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_rbac_permissions_permission_key", "keys": ["permission_key"], "unique": True},
            {"name": "idx_rbac_permissions_module", "keys": ["module"], "unique": False},
            {"name": "idx_rbac_permissions_resource_type", "keys": ["resource_type"], "unique": False},
            {"name": "idx_rbac_permissions_resource_key", "keys": ["resource_key"], "unique": False},
        ],
    },
}

RBAC_USER_ROLE_V1 = {
    "template_key": "rbac_user_role_v1",
    "template_name": "RBAC 用户角色关联表",
    "version": "v1",
    "table": "rbac_user_roles",
    "description": "建立用户与角色之间的多对多关系。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "user-role-binding"],
    "managed_fields": ["id", "created_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "user_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            "role_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "rbac_roles",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            **timestamp_fields(include_updated=False, include_deleted=False),
        },
        "indexes": [
            {"name": "idx_rbac_user_roles_user_id", "keys": ["user_id"], "unique": False},
            {"name": "idx_rbac_user_roles_role_id", "keys": ["role_id"], "unique": False},
            {"name": "uk_rbac_user_roles_user_role", "keys": ["user_id", "role_id"], "unique": True},
        ],
    },
}

RBAC_ROLE_PAGE_ACCESS_V1 = {
    "template_key": "rbac_role_page_access_v1",
    "template_name": "RBAC 角色页面访问表",
    "version": "v1",
    "table": "rbac_role_page_access",
    "description": "描述某个角色对某个后台页面的可见和可操作能力。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "page-access"],
    "managed_fields": ["id", "created_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "role_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "rbac_roles",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            "page_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "rbac_pages",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            "can_view": {"type": "bool", "nullable": False, "default": True},
            "can_create": {"type": "bool", "nullable": False, "default": False},
            "can_update": {"type": "bool", "nullable": False, "default": False},
            "can_delete": {"type": "bool", "nullable": False, "default": False},
            **timestamp_fields(include_updated=False, include_deleted=False),
        },
        "indexes": [
            {"name": "idx_rbac_role_page_access_role_id", "keys": ["role_id"], "unique": False},
            {"name": "idx_rbac_role_page_access_page_id", "keys": ["page_id"], "unique": False},
            {"name": "uk_rbac_role_page_access_role_page", "keys": ["role_id", "page_id"], "unique": True},
        ],
    },
}

RBAC_ROLE_PERMISSION_V1 = {
    "template_key": "rbac_role_permission_v1",
    "template_name": "RBAC 角色权限关联表",
    "version": "v1",
    "table": "rbac_role_permissions",
    "description": "建立角色与细粒度权限点之间的关系。",
    "category": "access-control",
    "stability": "stable",
    "scenarios": ["rbac", "admin-console", "role-permission-binding"],
    "managed_fields": ["id", "created_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "role_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "rbac_roles",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            "permission_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "rbac_permissions",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            **timestamp_fields(include_updated=False, include_deleted=False),
        },
        "indexes": [
            {"name": "idx_rbac_role_permissions_role_id", "keys": ["role_id"], "unique": False},
            {"name": "idx_rbac_role_permissions_permission_id", "keys": ["permission_id"], "unique": False},
            {"name": "uk_rbac_role_permissions_role_permission", "keys": ["role_id", "permission_id"], "unique": True},
        ],
    },
}

RBAC_ROLE_V1_RULES = build_rules(
    "rbac_role_v1",
    "v1",
    create_required=["role_key", "role_name"],
    create_properties={
        "role_key": {"type": "string", "min_length": 2, "max_length": 64, "pattern": "^[a-z][a-z0-9_]*$"},
        "role_name": {"type": "string", "min_length": 2, "max_length": 80},
        "description": {"type": "string", "max_length": 255},
        "status": {"type": "string", "enum": ["active", "disabled"]},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "role_name": {"type": "string", "min_length": 2, "max_length": 80},
        "description": {"type": "string", "max_length": 255},
        "status": {"type": "string", "enum": ["active", "disabled"]},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

RBAC_PAGE_V1_RULES = build_rules(
    "rbac_page_v1",
    "v1",
    create_required=["page_key", "page_name", "route_path"],
    create_properties={
        "page_key": {"type": "string", "min_length": 2, "max_length": 64, "pattern": "^[a-z][a-z0-9_]*$"},
        "page_name": {"type": "string", "min_length": 2, "max_length": 80},
        "route_path": {"type": "string", "min_length": 2, "max_length": 255},
        "parent_page_key": {"type": "string", "max_length": 64},
        "icon": {"type": "string", "max_length": 64},
        "sort_order": {"type": "integer", "minimum": 0},
        "status": {"type": "string", "enum": ["active", "hidden", "disabled"]},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "page_name": {"type": "string", "min_length": 2, "max_length": 80},
        "route_path": {"type": "string", "min_length": 2, "max_length": 255},
        "parent_page_key": {"type": "string", "max_length": 64},
        "icon": {"type": "string", "max_length": 64},
        "sort_order": {"type": "integer", "minimum": 0},
        "status": {"type": "string", "enum": ["active", "hidden", "disabled"]},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

RBAC_PERMISSION_V1_RULES = build_rules(
    "rbac_permission_v1",
    "v1",
    create_required=["permission_key", "permission_name", "resource_type", "resource_key", "module", "action"],
    create_properties={
        "permission_key": {"type": "string", "min_length": 3, "max_length": 80, "pattern": "^[a-z][a-z0-9_.]*$"},
        "permission_name": {"type": "string", "min_length": 2, "max_length": 80},
        "resource_type": {"type": "string", "enum": ["page", "api", "button", "resource"]},
        "resource_key": {"type": "string", "min_length": 2, "max_length": 80},
        "module": {"type": "string", "min_length": 2, "max_length": 50},
        "action": {"type": "string", "min_length": 2, "max_length": 30},
        "description": {"type": "string", "max_length": 255},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "permission_name": {"type": "string", "min_length": 2, "max_length": 80},
        "resource_type": {"type": "string", "enum": ["page", "api", "button", "resource"]},
        "resource_key": {"type": "string", "min_length": 2, "max_length": 80},
        "module": {"type": "string", "min_length": 2, "max_length": 50},
        "action": {"type": "string", "min_length": 2, "max_length": 30},
        "description": {"type": "string", "max_length": 255},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

RBAC_USER_ROLE_V1_RULES = build_rules(
    "rbac_user_role_v1",
    "v1",
    create_required=["user_id", "role_id"],
    create_properties={
        "user_id": {"type": "integer", "minimum": 1},
        "role_id": {"type": "integer", "minimum": 1},
    },
    create_forbidden=["id", "created_at"],
    update_properties={
        "user_id": {"type": "integer", "minimum": 1},
        "role_id": {"type": "integer", "minimum": 1},
    },
    update_forbidden=["id", "created_at"],
)

RBAC_ROLE_PAGE_ACCESS_V1_RULES = build_rules(
    "rbac_role_page_access_v1",
    "v1",
    create_required=["role_id", "page_id"],
    create_properties={
        "role_id": {"type": "integer", "minimum": 1},
        "page_id": {"type": "integer", "minimum": 1},
        "can_view": {"type": "boolean", "default": True},
        "can_create": {"type": "boolean", "default": False},
        "can_update": {"type": "boolean", "default": False},
        "can_delete": {"type": "boolean", "default": False},
    },
    create_forbidden=["id", "created_at"],
    update_properties={
        "can_view": {"type": "boolean"},
        "can_create": {"type": "boolean"},
        "can_update": {"type": "boolean"},
        "can_delete": {"type": "boolean"},
    },
    update_forbidden=["id", "created_at", "role_id", "page_id"],
)

RBAC_ROLE_PERMISSION_V1_RULES = build_rules(
    "rbac_role_permission_v1",
    "v1",
    create_required=["role_id", "permission_id"],
    create_properties={
        "role_id": {"type": "integer", "minimum": 1},
        "permission_id": {"type": "integer", "minimum": 1},
    },
    create_forbidden=["id", "created_at"],
    update_properties={
        "role_id": {"type": "integer", "minimum": 1},
        "permission_id": {"type": "integer", "minimum": 1},
    },
    update_forbidden=["id", "created_at"],
)

RBAC_TEMPLATE_LIBRARY = {
    RBAC_ROLE_V1["template_key"]: RBAC_ROLE_V1,
    RBAC_PAGE_V1["template_key"]: RBAC_PAGE_V1,
    RBAC_PERMISSION_V1["template_key"]: RBAC_PERMISSION_V1,
    RBAC_USER_ROLE_V1["template_key"]: RBAC_USER_ROLE_V1,
    RBAC_ROLE_PAGE_ACCESS_V1["template_key"]: RBAC_ROLE_PAGE_ACCESS_V1,
    RBAC_ROLE_PERMISSION_V1["template_key"]: RBAC_ROLE_PERMISSION_V1,
}

RBAC_RULE_LIBRARY = {
    RBAC_ROLE_V1_RULES["template_key"]: RBAC_ROLE_V1_RULES,
    RBAC_PAGE_V1_RULES["template_key"]: RBAC_PAGE_V1_RULES,
    RBAC_PERMISSION_V1_RULES["template_key"]: RBAC_PERMISSION_V1_RULES,
    RBAC_USER_ROLE_V1_RULES["template_key"]: RBAC_USER_ROLE_V1_RULES,
    RBAC_ROLE_PAGE_ACCESS_V1_RULES["template_key"]: RBAC_ROLE_PAGE_ACCESS_V1_RULES,
    RBAC_ROLE_PERMISSION_V1_RULES["template_key"]: RBAC_ROLE_PERMISSION_V1_RULES,
}
