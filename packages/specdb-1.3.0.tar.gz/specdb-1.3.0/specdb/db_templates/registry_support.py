"""Validation and override helpers for the template registry."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from specdb.executor.errors import DBExecuteError
from specdb.executor.relationship_metadata import build_table_dependency_plan, extract_relation_metadata

_ALLOWED_TEMPLATE_CATEGORIES = frozenset({"identity", "access-control", "content", "site-support"})
_ALLOWED_TEMPLATE_STABILITIES = frozenset({"stable", "legacy", "experimental"})
_SCHEMA_TO_RULE_TYPES = {
    "str": "string",
    "text": "string",
    "int": "integer",
    "float": "number",
    "decimal": "number",
    "bool": "boolean",
    "datetime": "string",
    "date": "string",
    "json": "object",
}
_REQUIRED_TEMPLATE_KEYS = {"template_key", "template_name", "version", "table", "description", "payload"}
_ALLOWED_OVERRIDE_TOP_LEVEL_KEYS = frozenset({"schema"})
_ALLOWED_SCHEMA_OVERRIDE_KEYS = frozenset({"nullable", "default", "length"})
_RELATION_PROTECTED_OVERRIDE_KEYS = frozenset({"relation", "type", "nullable", "unique", "primary", "auto_increment"})


def validate_template_item(item: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    missing = sorted(_REQUIRED_TEMPLATE_KEYS - set(item))
    if missing:
        errors.append(f"template {item.get('template_key', '<unknown>')} missing keys: {', '.join(missing)}")
        return errors

    payload = item.get("payload")
    if not isinstance(payload, dict):
        errors.append(f"template {item['template_key']} payload must be dict")
        return errors

    schema = payload.get("schema")
    if not isinstance(schema, dict) or not schema:
        errors.append(f"template {item['template_key']} schema must be non-empty dict")
        return errors
    try:
        extract_relation_metadata(schema, f"template {item['template_key']}.payload.schema")
    except DBExecuteError as exc:
        errors.append(exc.message)

    category = item.get("category")
    if category not in _ALLOWED_TEMPLATE_CATEGORIES:
        errors.append(f"template {item['template_key']} has invalid category: {category}")

    stability = item.get("stability")
    if stability not in _ALLOWED_TEMPLATE_STABILITIES:
        errors.append(f"template {item['template_key']} has invalid stability: {stability}")

    for field_name in ("scenarios", "managed_fields", "sensitive_fields"):
        value = item.get(field_name)
        if not isinstance(value, list) or not all(isinstance(entry, str) and entry for entry in value):
            errors.append(f"template {item['template_key']} {field_name} must be non-empty string list")
    scenarios = item.get("scenarios", [])
    if isinstance(scenarios, list) and not scenarios:
        errors.append(f"template {item['template_key']} scenarios must not be empty")

    schema_fields = set(schema.keys())
    managed_fields = set(item.get("managed_fields", []))
    sensitive_fields = set(item.get("sensitive_fields", []))
    if not managed_fields.issubset(schema_fields):
        missing_managed = sorted(managed_fields - schema_fields)
        errors.append(f"template {item['template_key']} managed_fields reference unknown fields: {', '.join(missing_managed)}")
    if not sensitive_fields.issubset(schema_fields):
        missing_sensitive = sorted(sensitive_fields - schema_fields)
        errors.append(f"template {item['template_key']} sensitive_fields reference unknown fields: {', '.join(missing_sensitive)}")

    indexes = payload.get("indexes", [])
    if indexes is None:
        indexes = []
    if not isinstance(indexes, list):
        errors.append(f"template {item['template_key']} indexes must be list")
        return errors

    for index_item in indexes:
        if not isinstance(index_item, dict):
            errors.append(f"template {item['template_key']} index item must be dict")
            continue
        name = index_item.get("name")
        keys = index_item.get("keys")
        if not isinstance(name, str) or not name.strip():
            errors.append(f"template {item['template_key']} index name must be non-empty string")
        if not isinstance(keys, list) or not keys:
            errors.append(f"template {item['template_key']} index keys must be non-empty list")
            continue
        for key in keys:
            if key not in schema_fields:
                errors.append(f"template {item['template_key']} index {name!r} references unknown field: {key}")

    return errors


def validate_rules(template_key: str, rules: dict[str, Any], template_library: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    template = template_library.get(template_key)
    if template is None:
        return [f"rules {template_key} references missing template"]

    schema_fields = set(template["payload"]["schema"])
    virtual_fields = set(rules.get("virtual_properties", []))
    allowed_fields = schema_fields | virtual_fields
    schema = template["payload"]["schema"]

    if rules.get("template_key") != template_key:
        errors.append(f"rules {template_key} has mismatched template_key")
    if rules.get("template_version") != template["version"]:
        errors.append(f"rules {template_key} template_version must match template version")

    for scope in ("create", "update"):
        scope_rules = rules.get(scope)
        if not isinstance(scope_rules, dict):
            errors.append(f"rules {template_key} missing scope: {scope}")
            continue

        required = scope_rules.get("required", [])
        forbidden = scope_rules.get("forbidden", [])
        properties = scope_rules.get("properties", {})
        cross_rules = scope_rules.get("cross_rules", [])

        if not isinstance(required, list):
            errors.append(f"rules {template_key}.{scope}.required must be list")
            required = []
        if not isinstance(forbidden, list):
            errors.append(f"rules {template_key}.{scope}.forbidden must be list")
            forbidden = []
        if not isinstance(properties, dict):
            errors.append(f"rules {template_key}.{scope}.properties must be dict")
            properties = {}
        if not isinstance(cross_rules, list):
            errors.append(f"rules {template_key}.{scope}.cross_rules must be list")
            cross_rules = []

        for key in set(required) | set(forbidden) | set(properties):
            if key not in allowed_fields:
                errors.append(f"rules {template_key}.{scope} references unknown field: {key}")

        overlaps = sorted(set(required).intersection(forbidden))
        if overlaps:
            errors.append(f"rules {template_key}.{scope} required/forbidden overlap: {', '.join(overlaps)}")

        missing_property_specs = sorted(set(required).difference(properties))
        if missing_property_specs:
            errors.append(f"rules {template_key}.{scope} required fields missing property specs: {', '.join(missing_property_specs)}")

        for key, property_spec in properties.items():
            if key in virtual_fields:
                continue
            if not isinstance(property_spec, dict):
                errors.append(f"rules {template_key}.{scope}.{key} property spec must be dict")
                continue
            field_spec = schema.get(key)
            if not isinstance(field_spec, dict):
                continue
            schema_type = field_spec.get("type")
            expected_rule_type = _SCHEMA_TO_RULE_TYPES.get(schema_type)
            actual_rule_type = property_spec.get("type")
            if isinstance(expected_rule_type, str) and actual_rule_type is not None and actual_rule_type != expected_rule_type:
                errors.append(
                    f"rules {template_key}.{scope}.{key} type {actual_rule_type!r} must match schema type {expected_rule_type!r}"
                )
            if schema_type == "datetime" and property_spec.get("format") not in {None, "datetime"}:
                errors.append(f"rules {template_key}.{scope}.{key} datetime field must use format 'datetime'")
            if schema_type == "date" and property_spec.get("format") not in {None, "date"}:
                errors.append(f"rules {template_key}.{scope}.{key} date field must use format 'date'")

        for cross_rule in cross_rules:
            if not isinstance(cross_rule, dict):
                errors.append(f"rules {template_key}.{scope} cross_rule must be dict")
                continue
            condition = cross_rule.get("if", {})
            then_required = cross_rule.get("then_required", [])
            condition_key = condition.get("key") if isinstance(condition, dict) else None
            if condition_key not in allowed_fields:
                errors.append(f"rules {template_key}.{scope} cross_rule condition references unknown field: {condition_key}")
            if not isinstance(then_required, list):
                errors.append(f"rules {template_key}.{scope} cross_rule then_required must be list")
                continue
            for key in then_required:
                if key not in allowed_fields:
                    errors.append(f"rules {template_key}.{scope} cross_rule requires unknown field: {key}")

    return errors


def validate_template_suite(item: dict[str, Any], template_library: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    suite_key = item.get("suite_key", "<unknown>")
    required_keys = {"suite_key", "suite_name", "version", "description", "stability", "scenarios", "template_keys"}
    missing = sorted(required_keys - set(item))
    if missing:
        errors.append(f"template suite {suite_key} missing keys: {', '.join(missing)}")
        return errors

    if item.get("stability") not in _ALLOWED_TEMPLATE_STABILITIES:
        errors.append(f"template suite {suite_key} has invalid stability: {item.get('stability')}")

    scenarios = item.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios or not all(isinstance(entry, str) and entry for entry in scenarios):
        errors.append(f"template suite {suite_key} scenarios must be non-empty string list")

    template_keys = item.get("template_keys")
    if not isinstance(template_keys, list) or not template_keys:
        errors.append(f"template suite {suite_key} template_keys must be non-empty list")
        return errors

    duplicates = {entry for entry in template_keys if template_keys.count(entry) > 1}
    if duplicates:
        errors.append(f"template suite {suite_key} contains duplicate template_keys: {', '.join(sorted(duplicates))}")

    missing_templates = sorted({entry for entry in template_keys if entry not in template_library})
    if missing_templates:
        errors.append(f"template suite {suite_key} references unknown templates: {', '.join(missing_templates)}")

    if not missing_templates:
        plan = build_template_suite_plan(item, template_library=template_library)
        order_positions = {template_key: idx for idx, template_key in enumerate(template_keys)}
        table_to_template = {template_library[key]["table"]: key for key in template_keys if key in template_library}
        for table_name, dependencies in plan["dependencies"].items():
            current_template = table_to_template.get(table_name)
            if current_template is None:
                continue
            for dependency_table in dependencies:
                dependency_template = table_to_template.get(dependency_table)
                if dependency_template is None:
                    continue
                if order_positions[dependency_template] > order_positions[current_template]:
                    errors.append(
                        f"template suite {suite_key} order violates relation dependency: "
                        f"{current_template} depends on {dependency_template}"
                    )

    seed_sets = item.get("seed_sets", {})
    if seed_sets is not None and not isinstance(seed_sets, dict):
        errors.append(f"template suite {suite_key} seed_sets must be dict")
        return errors
    if isinstance(seed_sets, dict):
        for seed_key, seed_spec in seed_sets.items():
            if not isinstance(seed_spec, dict):
                errors.append(f"template suite {suite_key} seed set {seed_key} must be dict")
                continue
            template_key = seed_spec.get("template_key")
            if not isinstance(template_key, str) or template_key not in template_library:
                errors.append(f"template suite {suite_key} seed set {seed_key} references unknown template: {template_key}")
                continue
            required_fields = seed_spec.get("required_fields", [])
            if not isinstance(required_fields, list) or not all(isinstance(entry, str) and entry for entry in required_fields):
                errors.append(f"template suite {suite_key} seed set {seed_key} required_fields must be string list")
            identity_field = seed_spec.get("identity_field")
            if identity_field is not None and identity_field not in template_library[template_key]["payload"]["schema"]:
                errors.append(f"template suite {suite_key} seed set {seed_key} identity_field references unknown field: {identity_field}")
            references = seed_spec.get("references", {})
            if references is not None and not isinstance(references, dict):
                errors.append(f"template suite {suite_key} seed set {seed_key} references must be dict")
                continue
            if isinstance(references, dict):
                for reference_field, reference_spec in references.items():
                    if not isinstance(reference_spec, dict):
                        errors.append(f"template suite {suite_key} seed set {seed_key} reference {reference_field} must be dict")
                        continue
                    target_seed_set = reference_spec.get("seed_set")
                    target_identity_field = reference_spec.get("identity_field")
                    if target_seed_set not in seed_sets:
                        errors.append(f"template suite {suite_key} seed set {seed_key} references unknown seed set: {target_seed_set}")
                        continue
                    target_template_key = seed_sets[target_seed_set].get("template_key")
                    if (
                        isinstance(target_template_key, str)
                        and target_template_key in template_library
                        and target_identity_field not in template_library[target_template_key]["payload"]["schema"]
                    ):
                        errors.append(
                            f"template suite {suite_key} seed set {seed_key} reference {reference_field} "
                            f"uses unknown identity field {target_identity_field!r} on {target_seed_set}"
                        )

    return errors


def build_template_suite_plan(item: dict[str, Any], *, template_library: dict[str, dict[str, Any]]) -> dict[str, Any]:
    template_keys = [entry for entry in item.get("template_keys", []) if entry in template_library]
    template_key_by_table: dict[str, str] = {}
    relations_by_table: dict[str, dict[str, Any]] = {}
    preferred_tables: list[str] = []
    for template_key in template_keys:
        template = template_library[template_key]
        table_name = template["table"]
        template_key_by_table[table_name] = template_key
        preferred_tables.append(table_name)
        relations_by_table[table_name] = extract_relation_metadata(
            template["payload"]["schema"],
            f"template {template_key}.payload.schema",
        )

    dependency_plan = build_table_dependency_plan(relations_by_table, preferred_order=preferred_tables)
    recommended_table_order = dependency_plan["table_order"]
    recommended_template_order = [
        template_key_by_table[table_name]
        for table_name in recommended_table_order
        if table_name in template_key_by_table
    ]
    return {
        "recommended_template_order": recommended_template_order,
        "recommended_table_order": recommended_table_order,
        "dependencies": dependency_plan["dependencies"],
        "external_dependencies": dependency_plan["external_dependencies"],
        "cyclic_tables": dependency_plan["cyclic_tables"],
        "has_relation_cycles": dependency_plan["has_cycles"],
    }


def validate_template_overrides(template_key: str, overrides: dict[str, Any], template_library: dict[str, dict[str, Any]]) -> list[str]:
    template = template_library.get(template_key)
    if template is None:
        return [f"template not found: {template_key}"]
    if not isinstance(overrides, dict):
        return ["overrides must be dict"]

    errors: list[str] = []
    unknown_top_level = sorted(set(overrides) - _ALLOWED_OVERRIDE_TOP_LEVEL_KEYS)
    if unknown_top_level:
        errors.append(f"template {template_key} override contains unsupported keys: {', '.join(unknown_top_level)}")

    schema_overrides = overrides.get("schema", {})
    if schema_overrides is None:
        schema_overrides = {}
    if not isinstance(schema_overrides, dict):
        errors.append(f"template {template_key} override schema must be dict")
        return errors

    base_schema = template["payload"]["schema"]
    for field_name, field_override in schema_overrides.items():
        if field_name not in base_schema:
            errors.append(f"template {template_key} override references unknown field: {field_name}")
            continue
        if not isinstance(field_override, dict):
            errors.append(f"template {template_key} override for field {field_name} must be dict")
            continue
        unknown_field_keys = sorted(set(field_override) - _ALLOWED_SCHEMA_OVERRIDE_KEYS)
        if unknown_field_keys:
            errors.append(
                f"template {template_key} override for field {field_name} contains unsupported keys: "
                f"{', '.join(unknown_field_keys)}"
            )
        relation_spec = base_schema[field_name].get("relation")
        if relation_spec is not None:
            dangerous_keys = sorted(set(field_override).intersection(_RELATION_PROTECTED_OVERRIDE_KEYS))
            if dangerous_keys:
                errors.append(
                    f"template {template_key} override cannot change relation-protected field {field_name}: "
                    f"{', '.join(dangerous_keys)}"
                )

    return errors


def apply_template_overrides(
    template_key: str,
    payload: dict[str, Any],
    overrides: dict[str, Any],
    *,
    template_library: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    errors = validate_template_overrides(template_key, overrides, template_library)
    if errors:
        raise ValueError("; ".join(errors))
    result_payload = deepcopy(payload)
    schema_overrides = overrides.get("schema", {})
    if isinstance(schema_overrides, dict):
        for field_name, field_override in schema_overrides.items():
            if field_name not in result_payload["schema"] or not isinstance(field_override, dict):
                continue
            result_payload["schema"][field_name].update(deepcopy(field_override))
    return result_payload
