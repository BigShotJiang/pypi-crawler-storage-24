from __future__ import annotations

from specdb.db_templates._shared import auto_increment_primary_key, build_rules, timestamp_fields

CONTENT_ARTICLE_V1 = {
    "template_key": "content_article_v1",
    "template_name": "内容文章表",
    "version": "v1",
    "table": "content_articles",
    "description": "适用于博客、资讯、帮助中心等简单内容管理场景的文章主体表。",
    "category": "content",
    "stability": "stable",
    "scenarios": ["cms", "blog", "article", "admin-console"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "title": {"type": "str", "nullable": False, "length": 150},
            "slug": {"type": "str", "nullable": False, "unique": True, "length": 150},
            "summary": {"type": "str", "nullable": True, "length": 500},
            "content": {"type": "text", "nullable": False},
            "status": {"type": "str", "nullable": False, "length": 20, "default": "draft"},
            "author_user_id": {
                "type": "int",
                "nullable": True,
                "relation": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
            },
            "category_id": {
                "type": "int",
                "nullable": True,
                "relation": {
                    "target_table": "content_categories",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
            },
            "published_at": {"type": "datetime", "nullable": True},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_content_articles_slug", "keys": ["slug"], "unique": True},
            {"name": "idx_content_articles_status", "keys": ["status"], "unique": False},
            {"name": "idx_content_articles_author_user_id", "keys": ["author_user_id"], "unique": False},
            {"name": "idx_content_articles_category_id", "keys": ["category_id"], "unique": False},
            {"name": "idx_content_articles_published_at", "keys": ["published_at"], "unique": False},
        ],
    },
}

CONTENT_CATEGORY_V1 = {
    "template_key": "content_category_v1",
    "template_name": "内容分类表",
    "version": "v1",
    "table": "content_categories",
    "description": "定义文章分类，适用于简单博客和网站后台内容管理。",
    "category": "content",
    "stability": "stable",
    "scenarios": ["cms", "blog", "category-management"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "category_key": {"type": "str", "nullable": False, "unique": True, "length": 64},
            "category_name": {"type": "str", "nullable": False, "length": 80},
            "slug": {"type": "str", "nullable": False, "unique": True, "length": 120},
            "status": {"type": "str", "nullable": False, "length": 20, "default": "active"},
            "sort_order": {"type": "int", "nullable": False, "default": 0},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_content_categories_category_key", "keys": ["category_key"], "unique": True},
            {"name": "uk_content_categories_slug", "keys": ["slug"], "unique": True},
            {"name": "idx_content_categories_status", "keys": ["status"], "unique": False},
            {"name": "idx_content_categories_sort_order", "keys": ["sort_order"], "unique": False},
        ],
    },
}

CONTENT_TAG_V1 = {
    "template_key": "content_tag_v1",
    "template_name": "内容标签表",
    "version": "v1",
    "table": "content_tags",
    "description": "定义文章标签，用于列表筛选和内容聚合。",
    "category": "content",
    "stability": "stable",
    "scenarios": ["cms", "blog", "tag-management"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "tag_key": {"type": "str", "nullable": False, "unique": True, "length": 64},
            "tag_name": {"type": "str", "nullable": False, "length": 80},
            "slug": {"type": "str", "nullable": False, "unique": True, "length": 120},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_content_tags_tag_key", "keys": ["tag_key"], "unique": True},
            {"name": "uk_content_tags_slug", "keys": ["slug"], "unique": True},
        ],
    },
}

CONTENT_ARTICLE_TAG_V1 = {
    "template_key": "content_article_tag_v1",
    "template_name": "内容文章标签关联表",
    "version": "v1",
    "table": "content_article_tags",
    "description": "建立文章与标签之间的多对多关系。",
    "category": "content",
    "stability": "stable",
    "scenarios": ["cms", "blog", "tag-binding"],
    "managed_fields": ["id", "created_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "article_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "content_articles",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            "tag_id": {
                "type": "int",
                "nullable": False,
                "relation": {
                    "target_table": "content_tags",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "cascade",
                    "on_update": "restrict",
                },
            },
            **timestamp_fields(include_updated=False, include_deleted=False),
        },
        "indexes": [
            {"name": "idx_content_article_tags_article_id", "keys": ["article_id"], "unique": False},
            {"name": "idx_content_article_tags_tag_id", "keys": ["tag_id"], "unique": False},
            {"name": "uk_content_article_tags_article_tag", "keys": ["article_id", "tag_id"], "unique": True},
        ],
    },
}

CONTENT_ARTICLE_V1_RULES = build_rules(
    "content_article_v1",
    "v1",
    create_required=["title", "slug", "content"],
    create_properties={
        "title": {"type": "string", "min_length": 2, "max_length": 150},
        "slug": {"type": "string", "min_length": 2, "max_length": 150, "pattern": "^[a-z0-9-_/]+$"},
        "summary": {"type": "string", "max_length": 500},
        "content": {"type": "string", "min_length": 1},
        "status": {"type": "string", "enum": ["draft", "published", "archived"]},
        "author_user_id": {"type": "integer", "minimum": 1},
        "category_id": {"type": "integer", "minimum": 1},
        "published_at": {"type": "string", "format": "datetime"},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "title": {"type": "string", "min_length": 2, "max_length": 150},
        "slug": {"type": "string", "min_length": 2, "max_length": 150, "pattern": "^[a-z0-9-_/]+$"},
        "summary": {"type": "string", "max_length": 500},
        "content": {"type": "string", "min_length": 1},
        "status": {"type": "string", "enum": ["draft", "published", "archived"]},
        "author_user_id": {"type": "integer", "minimum": 1},
        "category_id": {"type": "integer", "minimum": 1},
        "published_at": {"type": "string", "format": "datetime"},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

CONTENT_CATEGORY_V1_RULES = build_rules(
    "content_category_v1",
    "v1",
    create_required=["category_key", "category_name", "slug"],
    create_properties={
        "category_key": {"type": "string", "min_length": 2, "max_length": 64, "pattern": "^[a-z][a-z0-9_]*$"},
        "category_name": {"type": "string", "min_length": 2, "max_length": 80},
        "slug": {"type": "string", "min_length": 2, "max_length": 120, "pattern": "^[a-z0-9-_/]+$"},
        "status": {"type": "string", "enum": ["active", "disabled"]},
        "sort_order": {"type": "integer", "minimum": 0},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "category_name": {"type": "string", "min_length": 2, "max_length": 80},
        "slug": {"type": "string", "min_length": 2, "max_length": 120, "pattern": "^[a-z0-9-_/]+$"},
        "status": {"type": "string", "enum": ["active", "disabled"]},
        "sort_order": {"type": "integer", "minimum": 0},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

CONTENT_TAG_V1_RULES = build_rules(
    "content_tag_v1",
    "v1",
    create_required=["tag_key", "tag_name", "slug"],
    create_properties={
        "tag_key": {"type": "string", "min_length": 2, "max_length": 64, "pattern": "^[a-z][a-z0-9_]*$"},
        "tag_name": {"type": "string", "min_length": 2, "max_length": 80},
        "slug": {"type": "string", "min_length": 2, "max_length": 120, "pattern": "^[a-z0-9-_/]+$"},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "tag_name": {"type": "string", "min_length": 2, "max_length": 80},
        "slug": {"type": "string", "min_length": 2, "max_length": 120, "pattern": "^[a-z0-9-_/]+$"},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

CONTENT_ARTICLE_TAG_V1_RULES = build_rules(
    "content_article_tag_v1",
    "v1",
    create_required=["article_id", "tag_id"],
    create_properties={
        "article_id": {"type": "integer", "minimum": 1},
        "tag_id": {"type": "integer", "minimum": 1},
    },
    create_forbidden=["id", "created_at"],
    update_properties={
        "article_id": {"type": "integer", "minimum": 1},
        "tag_id": {"type": "integer", "minimum": 1},
    },
    update_forbidden=["id", "created_at"],
)

CONTENT_TEMPLATE_LIBRARY = {
    CONTENT_ARTICLE_V1["template_key"]: CONTENT_ARTICLE_V1,
    CONTENT_CATEGORY_V1["template_key"]: CONTENT_CATEGORY_V1,
    CONTENT_TAG_V1["template_key"]: CONTENT_TAG_V1,
    CONTENT_ARTICLE_TAG_V1["template_key"]: CONTENT_ARTICLE_TAG_V1,
}

CONTENT_RULE_LIBRARY = {
    CONTENT_ARTICLE_V1_RULES["template_key"]: CONTENT_ARTICLE_V1_RULES,
    CONTENT_CATEGORY_V1_RULES["template_key"]: CONTENT_CATEGORY_V1_RULES,
    CONTENT_TAG_V1_RULES["template_key"]: CONTENT_TAG_V1_RULES,
    CONTENT_ARTICLE_TAG_V1_RULES["template_key"]: CONTENT_ARTICLE_TAG_V1_RULES,
}
