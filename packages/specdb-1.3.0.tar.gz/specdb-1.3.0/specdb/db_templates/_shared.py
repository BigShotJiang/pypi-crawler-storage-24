from __future__ import annotations

TEMPLATE_RULE_SCHEMA_VERSION = "v1"


def auto_increment_primary_key() -> dict[str, object]:
    return {"type": "int", "primary": True, "auto_increment": True}


def timestamp_fields(*, include_updated: bool = True, include_deleted: bool = False) -> dict[str, dict[str, object]]:
    fields: dict[str, dict[str, object]] = {
        "created_at": {"type": "datetime", "nullable": False},
    }
    if include_updated:
        fields["updated_at"] = {"type": "datetime", "nullable": False}
    if include_deleted:
        fields["deleted_at"] = {"type": "datetime", "nullable": True}
    return fields


def build_rules(
    template_key: str,
    template_version: str,
    *,
    create_required: list[str] | None = None,
    create_properties: dict[str, dict[str, object]] | None = None,
    create_forbidden: list[str] | None = None,
    create_cross_rules: list[dict[str, object]] | None = None,
    update_required: list[str] | None = None,
    update_properties: dict[str, dict[str, object]] | None = None,
    update_forbidden: list[str] | None = None,
    update_cross_rules: list[dict[str, object]] | None = None,
    virtual_properties: list[str] | None = None,
) -> dict[str, object]:
    return {
        "template_key": template_key,
        "version": TEMPLATE_RULE_SCHEMA_VERSION,
        "template_version": template_version,
        "virtual_properties": virtual_properties or [],
        "create": {
            "required": create_required or [],
            "properties": create_properties or {},
            "forbidden": create_forbidden or [],
            "cross_rules": create_cross_rules or [],
        },
        "update": {
            "required": update_required or [],
            "properties": update_properties or {},
            "forbidden": update_forbidden or [],
            "cross_rules": update_cross_rules or [],
        },
    }
