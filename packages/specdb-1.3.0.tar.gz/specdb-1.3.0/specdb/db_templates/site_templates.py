from __future__ import annotations

from specdb.db_templates._shared import auto_increment_primary_key, build_rules, timestamp_fields

SITE_SETTING_V1 = {
    "template_key": "site_setting_v1",
    "template_name": "站点配置表",
    "version": "v1",
    "table": "site_settings",
    "description": "保存中小型网站后台常见的键值型站点配置。",
    "category": "site-support",
    "stability": "stable",
    "scenarios": ["admin-console", "site-settings", "configuration"],
    "managed_fields": ["id", "created_at", "updated_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "setting_key": {"type": "str", "nullable": False, "unique": True, "length": 80},
            "setting_name": {"type": "str", "nullable": False, "length": 100},
            "setting_value": {"type": "text", "nullable": True},
            "value_type": {"type": "str", "nullable": False, "length": 20, "default": "string"},
            "group_name": {"type": "str", "nullable": False, "length": 50, "default": "general"},
            "is_public": {"type": "bool", "nullable": False, "default": False},
            **timestamp_fields(include_updated=True, include_deleted=False),
        },
        "indexes": [
            {"name": "uk_site_settings_setting_key", "keys": ["setting_key"], "unique": True},
            {"name": "idx_site_settings_group_name", "keys": ["group_name"], "unique": False},
            {"name": "idx_site_settings_is_public", "keys": ["is_public"], "unique": False},
        ],
    },
}

MEDIA_ASSET_V1 = {
    "template_key": "media_asset_v1",
    "template_name": "素材元数据表",
    "version": "v1",
    "table": "media_assets",
    "description": "保存素材文件的元数据，不直接承担对象存储上传流程。",
    "category": "site-support",
    "stability": "stable",
    "scenarios": ["admin-console", "media-library", "asset-management"],
    "managed_fields": ["id", "created_at"],
    "sensitive_fields": [],
    "payload": {
        "schema": {
            "id": auto_increment_primary_key(),
            "storage_type": {"type": "str", "nullable": False, "length": 20, "default": "local"},
            "bucket": {"type": "str", "nullable": True, "length": 100},
            "object_key": {"type": "str", "nullable": False, "length": 255},
            "file_name": {"type": "str", "nullable": False, "length": 255},
            "mime_type": {"type": "str", "nullable": True, "length": 100},
            "file_size": {"type": "int", "nullable": False, "default": 0},
            "sha256": {"type": "str", "nullable": True, "length": 64},
            "uploaded_by_user_id": {
                "type": "int",
                "nullable": True,
                "relation": {
                    "target_table": "users",
                    "target_column": "id",
                    "kind": "many_to_one",
                    "on_delete": "set_null",
                    "on_update": "restrict",
                },
            },
            **timestamp_fields(include_updated=False, include_deleted=False),
        },
        "indexes": [
            {"name": "idx_media_assets_storage_type", "keys": ["storage_type"], "unique": False},
            {"name": "idx_media_assets_object_key", "keys": ["object_key"], "unique": False},
            {"name": "idx_media_assets_uploaded_by_user_id", "keys": ["uploaded_by_user_id"], "unique": False},
            {"name": "idx_media_assets_sha256", "keys": ["sha256"], "unique": False},
        ],
    },
}

SITE_SETTING_V1_RULES = build_rules(
    "site_setting_v1",
    "v1",
    create_required=["setting_key", "setting_name"],
    create_properties={
        "setting_key": {"type": "string", "min_length": 2, "max_length": 80, "pattern": "^[a-z][a-z0-9_.-]*$"},
        "setting_name": {"type": "string", "min_length": 2, "max_length": 100},
        "setting_value": {"type": "string"},
        "value_type": {"type": "string", "enum": ["string", "text", "json", "bool", "int"]},
        "group_name": {"type": "string", "max_length": 50},
        "is_public": {"type": "boolean"},
    },
    create_forbidden=["id", "created_at", "updated_at"],
    update_properties={
        "setting_name": {"type": "string", "min_length": 2, "max_length": 100},
        "setting_value": {"type": "string"},
        "value_type": {"type": "string", "enum": ["string", "text", "json", "bool", "int"]},
        "group_name": {"type": "string", "max_length": 50},
        "is_public": {"type": "boolean"},
    },
    update_forbidden=["id", "created_at", "updated_at"],
)

MEDIA_ASSET_V1_RULES = build_rules(
    "media_asset_v1",
    "v1",
    create_required=["object_key", "file_name"],
    create_properties={
        "storage_type": {"type": "string", "enum": ["local", "s3", "minio", "oss"]},
        "bucket": {"type": "string", "max_length": 100},
        "object_key": {"type": "string", "min_length": 1, "max_length": 255},
        "file_name": {"type": "string", "min_length": 1, "max_length": 255},
        "mime_type": {"type": "string", "max_length": 100},
        "file_size": {"type": "integer", "minimum": 0},
        "sha256": {"type": "string", "min_length": 64, "max_length": 64},
        "uploaded_by_user_id": {"type": "integer", "minimum": 1},
    },
    create_forbidden=["id", "created_at"],
    update_properties={
        "storage_type": {"type": "string", "enum": ["local", "s3", "minio", "oss"]},
        "bucket": {"type": "string", "max_length": 100},
        "object_key": {"type": "string", "min_length": 1, "max_length": 255},
        "file_name": {"type": "string", "min_length": 1, "max_length": 255},
        "mime_type": {"type": "string", "max_length": 100},
        "file_size": {"type": "integer", "minimum": 0},
        "sha256": {"type": "string", "min_length": 64, "max_length": 64},
        "uploaded_by_user_id": {"type": "integer", "minimum": 1},
    },
    update_forbidden=["id", "created_at"],
)

SITE_TEMPLATE_LIBRARY = {
    SITE_SETTING_V1["template_key"]: SITE_SETTING_V1,
    MEDIA_ASSET_V1["template_key"]: MEDIA_ASSET_V1,
}

SITE_RULE_LIBRARY = {
    SITE_SETTING_V1_RULES["template_key"]: SITE_SETTING_V1_RULES,
    MEDIA_ASSET_V1_RULES["template_key"]: MEDIA_ASSET_V1_RULES,
}
