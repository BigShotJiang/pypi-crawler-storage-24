"""Development-only reset helpers for specdb.install."""

from __future__ import annotations

from contextlib import nullcontext
from typing import Any

from flask import Flask, current_app, has_app_context

from specdb.db_executor import init_database
from specdb.install.seed_install import install_seed
from specdb.install.suite_install import install_suite
from specdb.install.types import build_install_result


def _resolve_app(app_or_client: Any) -> Flask | None:
    if isinstance(app_or_client, Flask):
        return app_or_client
    if has_app_context():
        return current_app._get_current_object()
    return None


def _is_dev_environment(app: Flask) -> bool:
    app_env = str(app.config.get("APP_ENV", "")).strip().lower()
    if app.config.get("TESTING"):
        return True
    if app.config.get("DEBUG"):
        return True
    if str(app.config.get("FLASK_DEBUG", "")).strip().lower() in {"1", "true", "yes", "on"}:
        return True
    return app_env in {"development", "dev", "local"}


def _dependency_order_for_drop(client: Any, tables: list[str]) -> tuple[list[str], bool]:
    dependencies: dict[str, set[str]] = {}
    for table_name in tables:
        describe = client.execute({"action": "table.describe", "table": table_name, "payload": {}, "options": {}})
        if not describe.get("success"):
            dependencies[table_name] = set()
            continue
        relation_summary = describe["data"].get("relation_summary", {})
        depends_on = relation_summary.get("depends_on_tables", [])
        if not isinstance(depends_on, list):
            depends_on = []
        dependencies[table_name] = {item for item in depends_on if item in tables}

    ordered: list[str] = []
    temporary = set()
    permanent = set()
    has_cycle = False

    def visit(table_name: str) -> None:
        nonlocal has_cycle
        if table_name in permanent:
            return
        if table_name in temporary:
            has_cycle = True
            return
        temporary.add(table_name)
        for dependency in sorted(dependencies.get(table_name, set())):
            visit(dependency)
        temporary.remove(table_name)
        permanent.add(table_name)
        ordered.append(table_name)

    for table_name in sorted(tables):
        visit(table_name)
    if has_cycle:
        return list(reversed(tables)), True
    return list(reversed(ordered)), False


def reset_dev_database(
    app_or_client: Any,
    *,
    confirm_dev: bool = False,
    reinstall_suite: str | None = None,
    reinstall_seed: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Drop all public tables in development/testing and optionally reinstall."""
    app = _resolve_app(app_or_client)
    if app is None:
        raise ValueError("reset_dev_database requires Flask app or active app context")
    if not confirm_dev:
        return build_install_result(
            success=False,
            code="DB_INSTALL_RESET_NOT_CONFIRMED",
            message="reset_dev_database requires confirm_dev=True",
            data={"dropped_tables": [], "reinstalled_suite": None, "seed_result": None, "warnings": []},
        )
    if not _is_dev_environment(app):
        return build_install_result(
            success=False,
            code="DB_INSTALL_RESET_FORBIDDEN",
            message="reset_dev_database is only allowed in development/testing",
            data={"dropped_tables": [], "reinstalled_suite": None, "seed_result": None, "warnings": []},
        )

    context = app.app_context() if not has_app_context() else nullcontext()
    with context:
        client = app_or_client if not isinstance(app_or_client, Flask) else init_database()
        listed = client.execute({"action": "table.list", "payload": {}, "options": {}})
        if not listed.get("success"):
            raise RuntimeError(f"failed to list tables before reset: {listed}")
        tables = listed["data"]
        ordered_drop, used_cycle_fallback = _dependency_order_for_drop(client, tables)
        dropped_tables: list[str] = []
        warnings: list[str] = []
        failed: list[dict[str, Any]] = []
        if used_cycle_fallback:
            warnings.append("dependency cycle detected during reset; falling back to reverse listed drop order")
        for table_name in ordered_drop:
            result = client.execute(
                {
                    "action": "table.drop",
                    "table": table_name,
                    "payload": {"if_exists": True},
                    "options": {},
                }
            )
            if result.get("success"):
                dropped_tables.append(table_name)
            else:
                failed.append({"table": table_name, "error": result.get("error")})
                warnings.append(f"failed to drop table during reset: {table_name}")

        suite_result = None
        if reinstall_suite:
            suite_result = install_suite(client, reinstall_suite)
        seed_result = None
        if reinstall_seed is not None and failed:
            warnings.append("skipped seed reinstall because table drops failed")
        elif reinstall_seed is not None and suite_result is not None and not suite_result.get("success"):
            warnings.append("skipped seed reinstall because suite reinstall failed")
        elif reinstall_seed is not None:
            seed_result = install_seed(client, reinstall_seed)

    data = {
        "dropped_tables": dropped_tables,
        "failed": failed,
        "reinstalled_suite": suite_result,
        "seed_result": seed_result,
        "warnings": warnings,
    }
    if failed or (suite_result is not None and not suite_result["success"]) or (seed_result is not None and not seed_result["success"]):
        return build_install_result(
            success=False,
            code="DB_INSTALL_RESET_FAILED",
            message="reset_dev_database failed",
            data=data,
        )
    return build_install_result(success=True, data=data)
