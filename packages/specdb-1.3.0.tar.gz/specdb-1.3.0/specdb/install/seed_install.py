"""Seed bundle installation helpers for specdb.install."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from specdb.db_runtime import db
from specdb.install.seed_support import (
    apply_common_seed_defaults,
    build_effective_key_query,
    build_persisted_row,
    describe_table_columns,
    insert_row,
    resolve_references,
    select_rows,
    update_rows,
)
from specdb.install.types import build_install_result

SEED_MODE_UPDATE_ALLOWED_FIELDS = "update_allowed_fields"
SEED_MODE_SKIP_IF_EXISTS = "skip_if_exists"
SEED_MODE_FAIL_ON_CONFLICT = "fail_on_conflict"
SUPPORTED_SEED_MODES = frozenset(
    {
        SEED_MODE_UPDATE_ALLOWED_FIELDS,
        SEED_MODE_SKIP_IF_EXISTS,
        SEED_MODE_FAIL_ON_CONFLICT,
    }
)

def _normalize_seed_bundle(
    seed_bundle: dict[str, Any],
    *,
    strict: bool,
    default_mode: str,
) -> tuple[dict[str, Any], list[str], list[dict[str, Any]]]:
    if not isinstance(seed_bundle, dict):
        raise ValueError("seed_bundle must be dict")
    tables = seed_bundle.get("tables")
    if not isinstance(tables, dict) or not tables:
        raise ValueError("seed_bundle.tables must be non-empty dict")
    errors: list[str] = []
    failed_tables: list[dict[str, Any]] = []

    normalized = {"meta": deepcopy(seed_bundle.get("meta", {})), "tables": {}}
    for table_name, table_seed in tables.items():
        table_errors: list[str] = []
        if not isinstance(table_name, str) or not table_name.strip():
            message = "seed bundle table key must be non-empty string"
            errors.append(message)
            failed_tables.append({"table": "<invalid-table-key>", "row": None, "error": message})
            continue
        if not isinstance(table_seed, dict):
            table_errors.append(f"{table_name}: table seed spec must be dict")
            errors.extend(table_errors)
            failed_tables.append({"table": table_name, "row": None, "error": "; ".join(table_errors)})
            continue
        key_fields = table_seed.get("key_fields")
        if not isinstance(key_fields, list) or not key_fields or not all(isinstance(item, str) and item for item in key_fields):
            table_errors.append(f"{table_name}: key_fields must be non-empty list[str]")
            errors.extend(table_errors)
            failed_tables.append({"table": table_name, "row": None, "error": "; ".join(table_errors)})
            continue
        raw_mode = table_seed.get("mode")
        mode = raw_mode if raw_mode is not None else default_mode
        if mode not in SUPPORTED_SEED_MODES:
            table_errors.append(f"{table_name}: unsupported mode {mode}")
        allowed_update_fields = table_seed.get("allowed_update_fields", [])
        if mode == SEED_MODE_UPDATE_ALLOWED_FIELDS:
            if not isinstance(allowed_update_fields, list) or not all(isinstance(item, str) and item for item in allowed_update_fields):
                table_errors.append(f"{table_name}: allowed_update_fields must be list[str] when mode=update_allowed_fields")
            forbidden_fields = set(key_fields) | {"id"}
            overlap = sorted(set(allowed_update_fields) & forbidden_fields)
            if overlap:
                table_errors.append(f"{table_name}: allowed_update_fields overlaps protected fields: {', '.join(overlap)}")
        rows = table_seed.get("rows")
        if not isinstance(rows, list):
            table_errors.append(f"{table_name}: rows must be list")
            errors.extend(table_errors)
            failed_tables.append({"table": table_name, "row": None, "error": "; ".join(table_errors)})
            continue
        references = table_seed.get("references", {})
        if references is None:
            references = {}
        if not isinstance(references, dict):
            table_errors.append(f"{table_name}: references must be dict")
            errors.extend(table_errors)
            failed_tables.append({"table": table_name, "row": None, "error": "; ".join(table_errors)})
            continue
        if table_errors:
            errors.extend(table_errors)
            failed_tables.append({"table": table_name, "row": None, "error": "; ".join(table_errors)})
            continue
        normalized["tables"][table_name] = {
            "key_fields": list(key_fields),
            "mode": mode,
            "allowed_update_fields": list(allowed_update_fields),
            "rows": deepcopy(rows),
            "references": deepcopy(references),
        }

    if strict and errors:
        return normalized, errors, failed_tables
    return normalized, errors, failed_tables


def _reset_attempted_table_results(table_results: dict[str, dict[str, int]]) -> None:
    for summary in table_results.values():
        summary["inserted"] = 0
        summary["updated"] = 0

def install_seed(
    client: Any,
    seed_bundle: dict[str, Any],
    *,
    default_mode: str = SEED_MODE_UPDATE_ALLOWED_FIELDS,
    strict: bool = True,
    atomic: bool = False,
) -> dict[str, Any]:
    """Install a Python-dict seed bundle with idempotent behavior."""
    if default_mode not in SUPPORTED_SEED_MODES:
        raise ValueError(f"unsupported default seed mode: {default_mode}")

    normalized, validation_errors, failed_tables = _normalize_seed_bundle(
        seed_bundle,
        strict=strict,
        default_mode=default_mode,
    )
    if validation_errors and strict:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SEED_FAILED",
            message="seed bundle validation failed",
            data={"tables": {}, "failed": deepcopy(failed_tables), "warnings": []},
        )
    if validation_errors and atomic:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SEED_FAILED",
            message="seed bundle validation failed",
            data={"tables": {}, "failed": deepcopy(failed_tables), "warnings": deepcopy(validation_errors)},
        )

    table_results: dict[str, dict[str, int]] = {}
    warnings: list[str] = []
    failed: list[Any] = []
    applied_operations: list[dict[str, Any]] = []

    def _execute_seed_rows(session=None) -> None:
        nonlocal table_results, warnings, failed, applied_operations
        for table_name, table_seed in normalized["tables"].items():
            mode = table_seed["mode"]
            key_fields = table_seed["key_fields"]
            allowed_update_fields = table_seed.get("allowed_update_fields", [])
            references = table_seed.get("references", {})
            rows = table_seed["rows"]
            columns = describe_table_columns(client, table_name)
            result_summary = {"inserted": 0, "updated": 0, "skipped": 0}

            for index, row in enumerate(rows):
                if not isinstance(row, dict):
                    failed.append({"table": table_name, "row": index, "error": "row must be dict"})
                    continue
                try:
                    prepared_row, source_field_to_target_field = resolve_references(
                        client,
                        table_name,
                        references,
                        row,
                        session=session,
                        strict=strict,
                        warnings=warnings,
                    )
                    effective_key_query = build_effective_key_query(
                        table_name,
                        key_fields,
                        prepared_row,
                        source_field_to_target_field,
                    )
                    persisted_row = apply_common_seed_defaults(
                        build_persisted_row(prepared_row, source_field_to_target_field),
                        columns,
                    )
                    selected = select_rows(client, table_name, effective_key_query, session=session)
                    total = selected.get("total", 0)

                    if total == 0:
                        insert_row(client, table_name, persisted_row, session=session)
                        applied_operations.append(
                            {
                                "kind": "insert",
                                "table": table_name,
                                "query": deepcopy(effective_key_query),
                            }
                        )
                        result_summary["inserted"] += 1
                        continue

                    if total != 1:
                        raise RuntimeError(f"{table_name}: expected 0 or 1 existing row for {effective_key_query}, got {total}")

                    if mode == SEED_MODE_SKIP_IF_EXISTS:
                        result_summary["skipped"] += 1
                        continue
                    if mode == SEED_MODE_FAIL_ON_CONFLICT:
                        raise RuntimeError(f"{table_name}: row already exists for {effective_key_query}")

                    update_data = {
                        field_name: persisted_row[field_name]
                        for field_name in allowed_update_fields
                        if field_name in persisted_row
                    }
                    if not update_data:
                        result_summary["skipped"] += 1
                        continue
                    existing_row = deepcopy(selected["items"][0])
                    update_rows(client, table_name, effective_key_query, update_data, session=session)
                    rollback_data = {
                        field_name: existing_row[field_name]
                        for field_name in update_data
                        if field_name in existing_row
                    }
                    applied_operations.append(
                        {
                            "kind": "update",
                            "table": table_name,
                            "query": deepcopy(effective_key_query),
                            "data": rollback_data,
                        }
                    )
                    result_summary["updated"] += 1
                except Exception as exc:
                    failed.append({"table": table_name, "row": index, "error": str(exc)})
                    if strict:
                        break

            table_results[table_name] = result_summary
            if strict and failed:
                break

    if atomic:
        try:
            with db.session.begin():
                _execute_seed_rows(session=db.session)
                if failed_tables:
                    failed.extend(deepcopy(failed_tables))
                if validation_errors and not strict:
                    warnings.extend(validation_errors)
                if failed:
                    raise RuntimeError("DB_INSTALL_SEED_ATOMIC_ABORT")
        except RuntimeError as exc:
            if str(exc) != "DB_INSTALL_SEED_ATOMIC_ABORT":
                raise
            _reset_attempted_table_results(table_results)
            warnings.append("rolled back atomic seed transaction after failure")
        if failed:
            return build_install_result(
                success=False,
                code="DB_INSTALL_SEED_FAILED",
                message="seed installation failed",
                data={"tables": table_results, "failed": failed, "warnings": warnings},
            )
        return build_install_result(success=True, data={"tables": table_results, "failed": failed, "warnings": warnings})

    _execute_seed_rows()

    if failed_tables:
        failed.extend(deepcopy(failed_tables))
    if validation_errors and not strict:
        warnings.extend(validation_errors)
    if failed and strict and applied_operations:
        rollback_failures: list[str] = []
        for operation in reversed(applied_operations):
            table_name = str(operation["table"])
            query = deepcopy(operation.get("query", {}))
            try:
                if operation.get("kind") == "insert":
                    result = client.execute(
                        {
                            "action": "data.delete",
                            "table": table_name,
                            "payload": {"query": query},
                            "options": {"allow_full_table": False},
                        }
                    )
                    if not result.get("success"):
                        raise RuntimeError(f"failed to delete seeded row from {table_name}: {result}")
                    deleted = int(result.get("data", {}).get("affected_rows", 0) or 0)
                    if deleted <= 0:
                        raise RuntimeError(f"no seeded row deleted from {table_name} during rollback")
                    table_results.setdefault(table_name, {"inserted": 0, "updated": 0, "skipped": 0})
                    table_results[table_name]["inserted"] = max(0, int(table_results[table_name]["inserted"]) - 1)
                elif operation.get("kind") == "update":
                    rollback_data = deepcopy(operation.get("data", {}))
                    if rollback_data:
                        result = client.execute(
                            {
                                "action": "data.update",
                                "table": table_name,
                                "payload": {"query": query, "data": rollback_data},
                                "options": {"allow_full_table": False},
                            }
                        )
                        if not result.get("success"):
                            raise RuntimeError(f"failed to restore seeded row in {table_name}: {result}")
                    table_results.setdefault(table_name, {"inserted": 0, "updated": 0, "skipped": 0})
                    table_results[table_name]["updated"] = max(0, int(table_results[table_name]["updated"]) - 1)
            except Exception as exc:
                rollback_failures.append(str(exc))
        if rollback_failures:
            warnings.append("seed rollback failed: " + " | ".join(rollback_failures))
        else:
            warnings.append("rolled back applied seed changes after strict failure")

    data = {"tables": table_results, "failed": failed, "warnings": warnings}
    if failed:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SEED_FAILED",
            message="seed installation failed",
            data=data,
        )
    return build_install_result(success=True, data=data)
