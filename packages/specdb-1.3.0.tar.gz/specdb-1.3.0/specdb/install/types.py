"""Shared result helpers for the install layer."""

from __future__ import annotations

from typing import Any

INSTALL_IF_EXISTS_SKIP = "skip"
INSTALL_IF_EXISTS_FAIL = "fail"
SUPPORTED_INSTALL_IF_EXISTS = frozenset({INSTALL_IF_EXISTS_SKIP, INSTALL_IF_EXISTS_FAIL})


def build_install_result(
    *,
    success: bool,
    data: dict[str, Any],
    code: str | None = None,
    message: str | None = None,
) -> dict[str, Any]:
    error = None
    if not success:
        error = {
            "code": code or "DB_INSTALL_FAILED",
            "message": message or "installation failed",
        }
    return {"success": success, "data": data, "error": error}


def assert_if_exists_mode(if_exists: str) -> str:
    if if_exists not in SUPPORTED_INSTALL_IF_EXISTS:
        allowed = ", ".join(sorted(SUPPORTED_INSTALL_IF_EXISTS))
        raise ValueError(f"unsupported if_exists mode: {if_exists}; allowed: {allowed}")
    return if_exists
