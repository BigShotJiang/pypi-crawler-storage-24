"""Suite installation helpers for specdb.install."""

from __future__ import annotations

from typing import Any

from specdb.db_templates import (
    build_define_spec,
    get_template,
    get_template_suite,
    get_template_suite_install_plan,
    validate_template_overrides,
)
from specdb.install.schema_install import install_schema
from specdb.install.types import INSTALL_IF_EXISTS_SKIP, assert_if_exists_mode, build_install_result


def _normalize_selected_template_keys(
    suite_key: str,
    ordered_template_keys: list[str],
    *,
    include_templates: list[str] | None,
    exclude_templates: list[str] | None,
) -> list[str]:
    selected = list(ordered_template_keys)
    valid_keys = set(ordered_template_keys)

    if include_templates is not None:
        if not isinstance(include_templates, list) or not all(isinstance(item, str) for item in include_templates):
            raise ValueError("include_templates must be list[str]")
        unknown = sorted(set(include_templates) - valid_keys)
        if unknown:
            raise ValueError(f"unknown suite templates for {suite_key}: {', '.join(unknown)}")
        allowed = set(include_templates)
        selected = [item for item in selected if item in allowed]

    if exclude_templates is not None:
        if not isinstance(exclude_templates, list) or not all(isinstance(item, str) for item in exclude_templates):
            raise ValueError("exclude_templates must be list[str]")
        unknown = sorted(set(exclude_templates) - valid_keys)
        if unknown:
            raise ValueError(f"unknown suite templates for {suite_key}: {', '.join(unknown)}")
        blocked = set(exclude_templates)
        selected = [item for item in selected if item not in blocked]

    return selected


def _normalize_template_overrides(
    selected_template_keys: list[str],
    template_overrides: dict[str, dict[str, Any]] | None,
) -> dict[str, dict[str, Any]]:
    if template_overrides is None:
        return {}
    if not isinstance(template_overrides, dict):
        raise ValueError("template_overrides must be dict[str, dict]")
    selected_set = set(selected_template_keys)
    normalized: dict[str, dict[str, Any]] = {}
    for template_key, overrides in template_overrides.items():
        if template_key not in selected_set:
            raise ValueError(f"template override targets non-selected template: {template_key}")
        if not isinstance(overrides, dict):
            raise ValueError(f"template override for {template_key} must be dict")
        errors = validate_template_overrides(template_key, overrides)
        if errors:
            raise ValueError("; ".join(errors))
        normalized[template_key] = overrides
    return normalized


def _filter_recommended_seed_sets(
    suite: dict[str, Any],
    selected_template_keys: list[str],
) -> list[str]:
    seed_sets = suite.get("seed_sets", {})
    if not isinstance(seed_sets, dict):
        return []

    selected_set = set(selected_template_keys)
    included = {
        seed_set_key
        for seed_set_key, seed_spec in seed_sets.items()
        if isinstance(seed_spec, dict) and seed_spec.get("template_key") in selected_set
    }
    changed = True
    while changed:
        changed = False
        for seed_set_key in list(included):
            seed_spec = seed_sets.get(seed_set_key, {})
            references = seed_spec.get("references", {}) if isinstance(seed_spec, dict) else {}
            if not isinstance(references, dict):
                continue
            required_seed_sets = {
                reference_spec.get("seed_set")
                for reference_spec in references.values()
                if isinstance(reference_spec, dict) and isinstance(reference_spec.get("seed_set"), str)
            }
            missing = {item for item in required_seed_sets if item not in included}
            if missing:
                included.remove(seed_set_key)
                changed = True
    return sorted(included)


def _filter_plan_for_selected_templates(
    plan: dict[str, Any],
    selected_templates: list[dict[str, str]],
) -> tuple[list[str], list[str], dict[str, list[str]], bool]:
    selected_template_keys = [item["template_key"] for item in selected_templates]
    selected_tables = [item["table"] for item in selected_templates]
    selected_table_set = set(selected_tables)
    raw_dependencies = plan.get("dependencies", {})
    filtered_dependencies: dict[str, list[str]] = {}
    if isinstance(raw_dependencies, dict):
        for table_name in selected_tables:
            dependency_items = raw_dependencies.get(table_name, [])
            if not isinstance(dependency_items, list):
                dependency_items = []
            filtered_dependencies[table_name] = [item for item in dependency_items if item in selected_table_set]

    permanent: set[str] = set()
    temporary: set[str] = set()
    has_cycles = False

    def visit(table_name: str) -> None:
        nonlocal has_cycles
        if table_name in permanent or has_cycles:
            return
        if table_name in temporary:
            has_cycles = True
            return
        temporary.add(table_name)
        for dependency in filtered_dependencies.get(table_name, []):
            visit(dependency)
        temporary.remove(table_name)
        permanent.add(table_name)

    for table_name in selected_tables:
        visit(table_name)

    return selected_template_keys, selected_tables, filtered_dependencies, has_cycles


def install_suite(
    client: Any,
    suite_key: str,
    *,
    include_templates: list[str] | None = None,
    exclude_templates: list[str] | None = None,
    if_exists: str = INSTALL_IF_EXISTS_SKIP,
    template_overrides: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Install suite structure only, keeping seed installation separate."""
    assert_if_exists_mode(if_exists)
    suite = get_template_suite(suite_key)
    plan = get_template_suite_install_plan(suite_key)
    if suite is None or plan is None:
        raise ValueError(f"template suite not found: {suite_key}")

    selected_template_keys = _normalize_selected_template_keys(
        suite_key,
        plan["recommended_template_order"],
        include_templates=include_templates,
        exclude_templates=exclude_templates,
    )
    overrides_by_template = _normalize_template_overrides(selected_template_keys, template_overrides)

    define_specs: list[dict[str, Any]] = []
    selected_templates: list[dict[str, str]] = []
    for template_key in selected_template_keys:
        template = get_template(template_key)
        if template is None:
            raise RuntimeError(f"missing template during suite install: {template_key}")
        define_spec = build_define_spec(template_key, overrides=overrides_by_template.get(template_key))
        if define_spec is None:
            raise RuntimeError(f"failed to build define spec: {template_key}")
        define_specs.append(define_spec)
        selected_templates.append({"template_key": template_key, "table": template["table"]})

    schema_result = install_schema(client, define_specs, if_exists=if_exists)
    installed_tables = set(schema_result["data"]["installed"])
    skipped_tables = set(schema_result["data"]["skipped"])

    installed_templates = [item for item in selected_templates if item["table"] in installed_tables]
    skipped_templates = [item for item in selected_templates if item["table"] in skipped_tables]
    failed_templates = []
    for item in schema_result["data"]["failed"]:
        failed_templates.append(
            {
                "template_key": next(
                    selected["template_key"] for selected in selected_templates if selected["table"] == item["table"]
                ),
                "table": item["table"],
                "error": item["error"],
            }
        )

    filtered_template_order, filtered_table_order, filtered_dependencies, filtered_has_cycles = _filter_plan_for_selected_templates(
        plan,
        selected_templates,
    )
    data = {
        "suite_key": suite_key,
        "selected_templates": selected_templates,
        "installed_templates": installed_templates,
        "skipped_templates": skipped_templates,
        "failed_templates": failed_templates,
        "recommended_seed_sets": _filter_recommended_seed_sets(suite, filtered_template_order),
        "recommended_template_order": filtered_template_order,
        "recommended_table_order": filtered_table_order,
        "dependencies": filtered_dependencies,
        "has_relation_cycles": filtered_has_cycles,
        "warnings": list(schema_result["data"]["warnings"]),
    }
    if failed_templates:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SUITE_FAILED",
            message="suite installation failed",
            data=data,
        )
    return build_install_result(success=True, data=data)
