"""Schema installation helpers for specdb.install."""

from __future__ import annotations

from typing import Any

from specdb.install.types import INSTALL_IF_EXISTS_SKIP, assert_if_exists_mode, build_install_result


def _list_public_tables(client: Any) -> set[str]:
    result = client.execute({"action": "table.list", "payload": {}, "options": {}})
    if not result.get("success"):
        raise RuntimeError(f"failed to list tables: {result}")
    tables = result.get("data", [])
    if not isinstance(tables, list):
        raise RuntimeError(f"invalid table.list response: {result}")
    return {item for item in tables if isinstance(item, str)}


def _normalize_define_spec(spec: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    if not isinstance(spec, dict):
        raise ValueError("define_specs items must be dict")
    if spec.get("action") != "table.define":
        raise ValueError("install_schema only accepts table.define specs")
    table_name = spec.get("table")
    if not isinstance(table_name, str) or not table_name.strip():
        raise ValueError("table.define spec requires non-empty table")
    normalized = {
        "action": "table.define",
        "table": table_name,
        "payload": spec.get("payload", {}),
        "options": spec.get("options", {}),
    }
    return table_name, normalized


def _validate_define_specs(define_specs: list[dict[str, Any]]) -> tuple[list[tuple[str, dict[str, Any]]], list[dict[str, Any]]]:
    normalized_specs: list[tuple[str, dict[str, Any]]] = []
    failed: list[dict[str, Any]] = []
    for index, spec in enumerate(define_specs):
        try:
            normalized_specs.append(_normalize_define_spec(spec))
        except Exception as exc:
            table_name = None
            if isinstance(spec, dict):
                raw_table = spec.get("table")
                if isinstance(raw_table, str) and raw_table.strip():
                    table_name = raw_table
            failed.append(
                {
                    "table": table_name or f"<define_specs[{index}]>",
                    "error": str(exc),
                }
            )
    return normalized_specs, failed


def install_schema(client: Any, define_specs: list[dict[str, Any]], *, if_exists: str = INSTALL_IF_EXISTS_SKIP) -> dict[str, Any]:
    """Install one or more define specs in order."""
    assert_if_exists_mode(if_exists)
    if not isinstance(define_specs, list):
        raise ValueError("define_specs must be list")

    normalized_specs, failed = _validate_define_specs(define_specs)
    existing_tables = _list_public_tables(client)
    installed: list[str] = []
    skipped: list[str] = []
    warnings: list[str] = []

    if failed:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SCHEMA_FAILED",
            message="schema installation validation failed",
            data={
                "installed": installed,
                "skipped": skipped,
                "updated": [],
                "failed": failed,
                "warnings": warnings,
            },
        )

    for table_name, normalized_spec in normalized_specs:
        if if_exists == INSTALL_IF_EXISTS_SKIP and table_name in existing_tables:
            skipped.append(table_name)
            continue

        result = client.execute(normalized_spec)
        if result.get("success"):
            installed.append(table_name)
            existing_tables.add(table_name)
            continue

        failed.append({"table": table_name, "error": result.get("error")})

    data = {
        "installed": installed,
        "skipped": skipped,
        "updated": [],
        "failed": failed,
        "warnings": warnings,
    }
    if failed:
        return build_install_result(
            success=False,
            code="DB_INSTALL_SCHEMA_FAILED",
            message="schema installation failed",
            data=data,
        )
    return build_install_result(success=True, data=data)
