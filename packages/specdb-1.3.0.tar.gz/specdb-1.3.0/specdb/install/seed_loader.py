"""File-based seed bundle loading helpers for specdb.install."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

_SUPPORTED_SUFFIXES = {
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
}


def _resolve_seed_format(path: Path, file_format: str | None) -> str:
    if file_format is not None:
        normalized = file_format.strip().lower()
        if normalized in {"json", "yaml", "yml"}:
            return "yaml" if normalized in {"yaml", "yml"} else normalized
        raise ValueError(f"unsupported seed file format: {file_format}")

    suffix = path.suffix.lower()
    resolved = _SUPPORTED_SUFFIXES.get(suffix)
    if resolved is None:
        allowed = ", ".join(sorted(_SUPPORTED_SUFFIXES))
        raise ValueError(f"unsupported seed file suffix: {suffix or '<none>'}; allowed: {allowed}")
    return resolved


def load_seed_bundle(
    seed_file: str | Path,
    *,
    file_format: str | None = None,
    encoding: str = "utf-8",
) -> dict[str, Any]:
    """Load a seed bundle from JSON or YAML."""
    path = Path(seed_file)
    if not path.exists():
        raise FileNotFoundError(f"seed file not found: {path}")
    if not path.is_file():
        raise ValueError(f"seed file is not a regular file: {path}")

    resolved_format = _resolve_seed_format(path, file_format)
    raw_text = path.read_text(encoding=encoding)

    if resolved_format == "json":
        payload = json.loads(raw_text)
    else:
        payload = yaml.safe_load(raw_text)

    if not isinstance(payload, dict):
        raise ValueError("seed file must contain a top-level object/dict")
    return payload

