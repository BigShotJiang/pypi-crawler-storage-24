"""Shared helper functions for specdb.install seed execution."""

from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from typing import Any
from sqlalchemy.orm import Session


def select_rows(client: Any, table: str, query: dict[str, Any], *, session: Session | None = None) -> dict[str, Any]:
    result = client.execute(
        {
            "action": "data.select",
            "table": table,
            "payload": {"query": query},
            "options": {"include_total": True},
        },
        session=session,
    )
    if not result.get("success"):
        raise RuntimeError(f"failed to select from {table}: {result}")
    return result["data"]


def insert_row(client: Any, table: str, data: dict[str, Any], *, session: Session | None = None) -> dict[str, Any]:
    result = client.execute(
        {
            "action": "data.insert",
            "table": table,
            "payload": {"data": data},
            "options": {},
        },
        session=session,
    )
    if not result.get("success"):
        raise RuntimeError(f"failed to insert into {table}: {result}")
    return result["data"]


def update_rows(
    client: Any,
    table: str,
    query: dict[str, Any],
    data: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    result = client.execute(
        {
            "action": "data.update",
            "table": table,
            "payload": {"query": query, "data": data},
            "options": {},
        },
        session=session,
    )
    if not result.get("success"):
        raise RuntimeError(f"failed to update {table}: {result}")
    return result["data"]


def describe_table_columns(client: Any, table: str) -> dict[str, dict[str, Any]]:
    result = client.execute({"action": "table.describe", "table": table, "payload": {}, "options": {}})
    if not result.get("success"):
        raise RuntimeError(f"failed to describe table {table}: {result}")
    return {
        item["key"]: item
        for item in result["data"].get("columns", [])
        if isinstance(item, dict) and isinstance(item.get("key"), str)
    }


def iso_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def apply_common_seed_defaults(row: dict[str, Any], columns: dict[str, dict[str, Any]]) -> dict[str, Any]:
    prepared = deepcopy(row)
    if "created_at" in columns and prepared.get("created_at") is None:
        prepared["created_at"] = iso_now()
    if "updated_at" in columns and prepared.get("updated_at") is None:
        prepared["updated_at"] = iso_now()
    return prepared


def resolve_references(
    client: Any,
    table_name: str,
    references: dict[str, Any],
    row: dict[str, Any],
    *,
    session: Session | None = None,
    strict: bool,
    warnings: list[str],
) -> tuple[dict[str, Any], dict[str, str]]:
    prepared = deepcopy(row)
    source_field_to_target_field: dict[str, str] = {}

    for target_field, reference_spec in references.items():
        if not isinstance(reference_spec, dict):
            raise ValueError(f"{table_name}: reference {target_field} must be dict")
        target_table = reference_spec.get("table")
        target_key_fields = reference_spec.get("target_key_fields")
        source_from = reference_spec.get("source_from")
        resolved_field = reference_spec.get("resolved_field", "id")
        if not isinstance(target_table, str) or not target_table.strip():
            raise ValueError(f"{table_name}: reference {target_field} missing table")
        if not isinstance(target_key_fields, list) or not target_key_fields or not all(isinstance(item, str) and item for item in target_key_fields):
            raise ValueError(f"{table_name}: reference {target_field} target_key_fields must be non-empty list[str]")
        if not isinstance(source_from, list) or not source_from or not all(isinstance(item, str) and item for item in source_from):
            raise ValueError(f"{table_name}: reference {target_field} source_from must be non-empty list[str]")
        if len(target_key_fields) != len(source_from):
            raise ValueError(f"{table_name}: reference {target_field} source_from length must match target_key_fields")

        query: dict[str, Any] = {}
        missing_source_fields = [field_name for field_name in source_from if row.get(field_name) is None]
        if missing_source_fields:
            if strict:
                raise RuntimeError(
                    f"{table_name}: reference {target_field} missing source fields: {', '.join(missing_source_fields)}"
                )
            warnings.append(f"{table_name}: skipped unresolved reference {target_field}")
            continue

        for target_key, source_key in zip(target_key_fields, source_from):
            query[target_key] = row[source_key]
            source_field_to_target_field[source_key] = target_field

        selected = select_rows(client, target_table, query, session=session)
        total = selected.get("total", 0)
        items = selected.get("items", [])
        if total != 1 or len(items) != 1:
            if strict:
                raise RuntimeError(f"{table_name}: reference {target_field} could not resolve {target_table} with {query}")
            warnings.append(f"{table_name}: skipped unresolved reference {target_field}")
            continue
        target_row = items[0]
        if resolved_field not in target_row:
            raise RuntimeError(f"{table_name}: reference {target_field} resolved row missing field {resolved_field}")
        prepared[target_field] = target_row[resolved_field]

    return prepared, source_field_to_target_field


def build_effective_key_query(
    table_name: str,
    key_fields: list[str],
    prepared_row: dict[str, Any],
    source_field_to_target_field: dict[str, str],
) -> dict[str, Any]:
    query: dict[str, Any] = {}
    for key_field in key_fields:
        if key_field in source_field_to_target_field:
            target_field = source_field_to_target_field[key_field]
            if target_field not in prepared_row:
                raise RuntimeError(f"{table_name}: key field {key_field} could not be resolved to {target_field}")
            query[target_field] = prepared_row[target_field]
            continue
        if key_field not in prepared_row:
            raise RuntimeError(f"{table_name}: row missing key field {key_field}")
        query[key_field] = prepared_row[key_field]
    return query


def build_persisted_row(prepared_row: dict[str, Any], source_field_to_target_field: dict[str, str]) -> dict[str, Any]:
    persisted = deepcopy(prepared_row)
    for source_field in source_field_to_target_field:
        persisted.pop(source_field, None)
    return persisted
