"""File-based seed installation wrappers for specdb.install."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from specdb.install.seed_install import SEED_MODE_UPDATE_ALLOWED_FIELDS, install_seed
from specdb.install.seed_loader import load_seed_bundle


def install_seed_file(
    client: Any,
    seed_file: str | Path,
    *,
    file_format: str | None = None,
    encoding: str = "utf-8",
    default_mode: str = SEED_MODE_UPDATE_ALLOWED_FIELDS,
    strict: bool = True,
    atomic: bool = False,
) -> dict[str, Any]:
    """Load a seed bundle from disk and install it."""
    seed_bundle = load_seed_bundle(seed_file, file_format=file_format, encoding=encoding)
    return install_seed(
        client,
        seed_bundle,
        default_mode=default_mode,
        strict=strict,
        atomic=atomic,
    )
