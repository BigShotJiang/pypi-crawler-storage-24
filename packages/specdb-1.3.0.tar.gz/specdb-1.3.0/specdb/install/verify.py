"""Installation verification helpers for specdb.install."""

from __future__ import annotations

from typing import Any

from specdb.db_templates import get_template_suite_install_plan
from specdb.install.types import build_install_result


def verify_installation(
    client: Any,
    *,
    expected_tables: list[str] | None = None,
    expected_suite: str | None = None,
    expected_seed_checks: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Perform lightweight verification after schema/seed installation."""
    listed = client.execute({"action": "table.list", "payload": {}, "options": {}})
    if not listed.get("success"):
        raise RuntimeError(f"failed to list tables during verification: {listed}")
    existing_tables = {item for item in listed["data"] if isinstance(item, str)}

    tables_to_check = set(expected_tables or [])
    suite_plan = None
    if expected_suite is not None:
        suite_plan = get_template_suite_install_plan(expected_suite)
        if suite_plan is None:
            raise ValueError(f"template suite not found: {expected_suite}")
        tables_to_check.update(suite_plan["recommended_table_order"])

    missing_tables = sorted(table_name for table_name in tables_to_check if table_name not in existing_tables)

    seed_checks: dict[str, list[dict[str, Any]]] = {}
    missing_seed_checks: list[dict[str, Any]] = []
    for table_name, queries in (expected_seed_checks or {}).items():
        if not isinstance(queries, list):
            raise ValueError("expected_seed_checks values must be list[dict]")
        seed_checks[table_name] = []
        for query in queries:
            if not isinstance(query, dict):
                raise ValueError("expected seed check query must be dict")
            result = client.execute(
                {
                    "action": "data.select",
                    "table": table_name,
                    "payload": {"query": query},
                    "options": {"include_total": True},
                }
            )
            if not result.get("success"):
                missing_seed_checks.append({"table": table_name, "query": query, "error": result.get("error")})
                continue
            count = result["data"].get("total", 0)
            seed_checks[table_name].append({"query": query, "matched": count})
            if count < 1:
                missing_seed_checks.append({"table": table_name, "query": query, "error": "missing expected seed row"})

    data = {
        "existing_tables": sorted(existing_tables),
        "missing_tables": missing_tables,
        "expected_suite": expected_suite,
        "suite_verified": expected_suite is not None and suite_plan is not None and not missing_tables,
        "seed_checks": seed_checks,
        "missing_seed_checks": missing_seed_checks,
        "warnings": [],
    }
    if missing_tables or missing_seed_checks:
        return build_install_result(
            success=False,
            code="DB_INSTALL_VERIFY_FAILED",
            message="installation verification failed",
            data=data,
        )
    return build_install_result(success=True, data=data)
