"""Helper functions for ops job runtime orchestration."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from specdb.ops.blueprint_support import _to_db_naive_utc
from specdb.ops.jobs_support import _actual_table_stats_from_metrics
from specdb.ops.request_validation import _parse_iso_datetime


def build_initial_compact_metrics(batch_size: int) -> dict[str, Any]:
    return {
        "batch_size": int(batch_size),
        "batches": 0,
        "deleted_rows": 0,
        "avg_batch_ms": 0,
        "max_batch_ms": 0,
        "log_batches": 0,
        "history_batches": 0,
        "log_deleted_rows": 0,
        "history_deleted_rows": 0,
        "archive_rows": 0,
    }


def parse_job_request(job: dict[str, Any], *, dialect_name: str) -> dict[str, Any]:
    req = job.get("request")
    if not isinstance(req, dict):
        raise ValueError("invalid job request payload")

    dry_run = bool(req.get("dry_run", False))
    targets_raw = req.get("targets", [])
    if not isinstance(targets_raw, list):
        raise ValueError("targets must be list")
    targets = [item for item in targets_raw if isinstance(item, str) and item.strip()]

    archive = req.get("archive", {"enabled": False, "mode": "internal"})
    if not isinstance(archive, dict):
        raise ValueError("archive must be object")

    compact_before_raw = None
    strategy = req.get("strategy")
    if isinstance(strategy, dict):
        compact_before_raw = strategy.get("compact_before")

    compact_before_dt = None
    if compact_before_raw is not None:
        parsed, err = _parse_iso_datetime(compact_before_raw, "strategy.compact_before")
        if err is not None:
            raise ValueError(err["error"]["message"])
        if parsed is not None:
            compact_before_dt = _to_db_naive_utc(parsed, dialect_name=dialect_name)

    return {
        "request": req,
        "dry_run": dry_run,
        "targets": targets,
        "archive": archive,
        "compact_before_dt": compact_before_dt,
        "operator": req.get("operator"),
        "node": req.get("node"),
    }


def build_archive_request(
    req: dict[str, Any],
    *,
    job_id: str,
    owner_id: str,
    snapshot_id: str,
    targets: list[str],
    compact_before_dt: datetime | None,
    dry_run: bool,
    archive_id: str | None = None,
) -> dict[str, Any]:
    archive = req.get("archive", {}) if isinstance(req.get("archive"), dict) else {}
    payload = {
        "enabled": bool(archive.get("enabled", False)),
        "mode": str(archive.get("mode", "internal")),
        "job_id": job_id,
        "owner_id": owner_id,
        "request_id": str(req.get("request_id", job_id)),
        "snapshot_id": snapshot_id,
        "targets": list(targets),
        "compact_before": compact_before_dt.isoformat() if compact_before_dt is not None else None,
        "dry_run": dry_run,
    }
    if archive_id is not None:
        payload["archive_id"] = archive_id
    return payload


def build_verified_summary(
    *,
    dry_run: bool,
    targets: list[str],
    compact_before_dt: datetime | None,
    table_stats: list[dict[str, Any]],
    compacted_rows: int,
    history_compacted_rows: int,
    archive_enabled: bool,
    archive_mode: str,
    archive_id: str | None,
    archived_rows: int,
    archive_persisted: bool,
    compact_metrics: dict[str, Any],
    duration_ms: int,
    operator: Any,
    node: Any,
    retry_count: int,
    max_retries: int,
) -> dict[str, Any]:
    return {
        "dry_run": dry_run,
        "targets": targets,
        "compact_before": compact_before_dt.isoformat() if compact_before_dt is not None else None,
        "tables": len(table_stats),
        "table_stats": table_stats,
        "log_rows_compacted": compacted_rows,
        "history_rows_compacted": history_compacted_rows,
        "rows_compacted_total": int(compacted_rows) + int(history_compacted_rows),
        "archive_enabled": archive_enabled,
        "archive_mode": archive_mode,
        "archive_id": archive_id,
        "archived_rows": archived_rows,
        "archive_persisted": archive_persisted,
        "compact_metrics": compact_metrics,
        "duration_ms": duration_ms,
        "operator": operator,
        "node": node,
        "retry_count": retry_count,
        "max_retries": max_retries,
        "error_code": None,
        "last_error_at": None,
        "last_error": None,
        "failed_stage": None,
    }


def build_failed_summary(
    *,
    req: dict[str, Any] | None,
    compacted_rows: int,
    history_compacted_rows: int,
    archive_id: str | None,
    archive_persisted: bool,
    archived_rows: int,
    compact_metrics: dict[str, Any],
    table_stats: list[dict[str, Any]],
    duration_ms: int,
    retry_count: int,
    max_retries: int,
    failed_stage: str,
    last_error: str,
    error_code: str,
    last_error_at: str,
) -> dict[str, Any]:
    actual_table_stats = _actual_table_stats_from_metrics(compact_metrics, table_stats)
    archive = req.get("archive", {}) if isinstance(req, dict) and isinstance(req.get("archive"), dict) else {}
    return {
        "log_rows_compacted": int(compacted_rows or 0),
        "history_rows_compacted": int(history_compacted_rows or 0),
        "rows_compacted_total": int(compacted_rows or 0) + int(history_compacted_rows or 0),
        "archive_enabled": bool(archive.get("enabled", False)),
        "archive_mode": archive.get("mode", "internal"),
        "archive_id": archive_id,
        "archived_rows": int(archived_rows or 0),
        "archive_persisted": archive_persisted,
        "tables": len(actual_table_stats),
        "table_stats": actual_table_stats,
        "compact_metrics": compact_metrics,
        "duration_ms": duration_ms,
        "retry_count": retry_count,
        "max_retries": max_retries,
        "error_code": error_code,
        "last_error_at": last_error_at,
        "last_error": last_error,
        "failed_stage": failed_stage,
    }
