"""Execution helpers for restore-from-logs flows."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import and_, select

from specdb.ops.restore_support import (
    _build_pk_filters,
    _build_row_key_from_payload,
    _sanitize_restore_payload,
)


def build_restore_selector(
    *,
    table_name: str,
    log_ids: list[int] | None,
    batch_id: str | None,
    from_changed_at: Any,
    to_changed_at: Any,
    to_db_naive_utc: Any,
    max_restore_rows: int,
) -> tuple[dict[str, Any], dict[str, Any], str]:
    params: dict[str, Any] = {"table_name": table_name}
    where_sql = "table_name = :table_name"
    if log_ids is not None:
        placeholders = ", ".join(f":id_{idx}" for idx in range(len(log_ids)))
        for idx, item in enumerate(log_ids):
            params[f"id_{idx}"] = item
        where_sql += f" AND id IN ({placeholders})"
        selector_payload: dict[str, Any] = {"type": "log_ids", "log_ids": log_ids}
    elif batch_id is not None:
        params["batch_id"] = batch_id
        where_sql += " AND batch_id = :batch_id"
        selector_payload = {"type": "batch_id", "batch_id": batch_id}
    else:
        params["from_changed_at"] = to_db_naive_utc(from_changed_at)
        params["to_changed_at"] = to_db_naive_utc(to_changed_at)
        where_sql += " AND changed_at >= :from_changed_at AND changed_at <= :to_changed_at"
        selector_payload = {
            "type": "time_window",
            "from_changed_at": from_changed_at.isoformat() if from_changed_at is not None else None,
            "to_changed_at": to_changed_at.isoformat() if to_changed_at is not None else None,
        }

    sql = f"""
        SELECT id, op, row_key_json, before_json, after_json
        FROM db_change_log
        WHERE {where_sql}
        ORDER BY id DESC
        LIMIT :query_limit
    """
    params["query_limit"] = int(max_restore_rows) + 1
    return selector_payload, params, sql


def execute_restore_logs(
    *,
    session: Any,
    table: Any,
    logs: list[dict[str, Any]],
    dry_run: bool,
    preview_details: bool,
    max_restore_preview_items: int,
) -> dict[str, Any]:
    restored = 0
    preview_items: list[dict[str, Any]] = []
    preview_truncated = False

    for log in logs:
        row_key = before_data = after_data = None
        if log.get("row_key_json"):
            row_key = json.loads(log["row_key_json"])
        if log.get("before_json"):
            before_data = json.loads(log["before_json"])
        if log.get("after_json"):
            after_data = json.loads(log["after_json"])

        if not isinstance(row_key, dict):
            raise ValueError(f"log id={log['id']} row_key_json is invalid")
        if preview_details:
            if len(preview_items) < max_restore_preview_items:
                preview_items.append({"log_id": log["id"], "op": log.get("op"), "row_key": row_key})
            else:
                preview_truncated = True

        op = log.get("op")
        if op == "insert":
            filters = _build_pk_filters(table, row_key)
            if not dry_run:
                result = session.execute(table.delete().where(and_(*filters)))
                if int(result.rowcount or 0) <= 0:
                    raise ValueError(f"log id={log['id']} target row not found for insert rollback")
            restored += 1
            continue

        if op == "update":
            if not isinstance(before_data, dict):
                raise ValueError(f"log id={log['id']} before_json is invalid")
            before_data = _sanitize_restore_payload(table, before_data)
            target_row_key = row_key
            if isinstance(after_data, dict):
                candidate_row_key = _build_row_key_from_payload(table, after_data, field_name="after_json")
                if candidate_row_key != row_key:
                    target_row_key = candidate_row_key
            filters = _build_pk_filters(table, target_row_key)
            if not dry_run:
                result = session.execute(table.update().where(and_(*filters)).values(**before_data))
                if int(result.rowcount or 0) <= 0:
                    raise ValueError(f"log id={log['id']} target row not found for update rollback")
            restored += 1
            continue

        if op == "delete":
            if not isinstance(before_data, dict):
                raise ValueError(f"log id={log['id']} before_json is invalid")
            before_data = _sanitize_restore_payload(table, before_data)
            filters = _build_pk_filters(table, row_key)
            if not dry_run:
                exists = session.execute(select(table).where(and_(*filters))).mappings().first()
                if exists is None:
                    session.execute(table.insert().values(**before_data))
                else:
                    session.execute(table.update().where(and_(*filters)).values(**before_data))
            restored += 1

    return {
        "restored": restored,
        "preview_items": preview_items,
        "preview_truncated": preview_truncated,
    }
