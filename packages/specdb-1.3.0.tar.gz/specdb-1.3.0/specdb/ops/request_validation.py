"""Request parsing and validation helpers for ops routes."""

from __future__ import annotations

from datetime import datetime
import re
from typing import Any

from specdb.db_executor import error_payload

_VALID_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_VALID_TARGET_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _parse_int_arg(raw: Any, name: str, default_value: int, *, min_value: int, max_value: int) -> tuple[int | None, dict[str, Any] | None]:
    if raw is None:
        return default_value, None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"{name} must be integer")
    if value < min_value or value > max_value:
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"{name} must be in [{min_value}, {max_value}]")
    return value, None


def _parse_bool(value: Any, field_name: str) -> tuple[bool | None, dict[str, Any] | None]:
    if value is None:
        return False, None
    if isinstance(value, bool):
        return value, None
    return None, error_payload("DB_OPS_REQUEST_INVALID", f"field '{field_name}' must be boolean")


def _parse_iso_datetime(value: Any, field_name: str) -> tuple[datetime | None, dict[str, Any] | None]:
    if value is None:
        return None, None
    if not isinstance(value, str) or not value.strip():
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"field '{field_name}' must be ISO datetime string")
    try:
        normalized = value.replace("Z", "+00:00")
        return datetime.fromisoformat(normalized), None
    except ValueError:
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"field '{field_name}' must be ISO datetime string")


def _validate_request_id(value: Any) -> tuple[str | None, dict[str, Any] | None]:
    if not isinstance(value, str) or not value.strip():
        return None, error_payload("DB_OPS_REQUEST_INVALID", "request_id is required")
    normalized = value.strip()
    if not _VALID_REQUEST_ID_RE.fullmatch(normalized):
        return None, error_payload(
            "DB_OPS_REQUEST_INVALID",
            "request_id must match [A-Za-z0-9._:-] and be at most 128 chars",
        )
    return normalized, None


def _validate_job_id(value: Any) -> tuple[str | None, dict[str, Any] | None]:
    if not isinstance(value, str) or not value.strip():
        return None, error_payload("DB_OPS_REQUEST_INVALID", "job_id is required")
    normalized = value.strip()
    if not _VALID_REQUEST_ID_RE.fullmatch(normalized):
        return None, error_payload(
            "DB_OPS_REQUEST_INVALID",
            "job_id must match [A-Za-z0-9._:-] and be at most 128 chars",
        )
    return normalized, None


def _validate_targets(value: Any) -> tuple[list[str] | None, dict[str, Any] | None]:
    if value is None:
        return [], None
    if not isinstance(value, list):
        return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'targets' must be string array")
    if len(value) > 100:
        return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'targets' supports at most 100 items")

    normalized_targets: list[str] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, str) or not item.strip():
            return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'targets' must be string array")
        normalized = item.strip()
        if not _VALID_TARGET_RE.fullmatch(normalized):
            return None, error_payload("DB_OPS_REQUEST_INVALID", f"invalid target table name: {normalized}")
        if normalized in seen:
            continue
        seen.add(normalized)
        normalized_targets.append(normalized)
    return normalized_targets, None


def _validate_archive_options(value: Any) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if value is None:
        return {"enabled": False, "mode": "internal"}, None
    if not isinstance(value, dict):
        return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'archive' must be object")
    enabled = value.get("enabled", False)
    if not isinstance(enabled, bool):
        return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'archive.enabled' must be boolean")
    mode = value.get("mode", "internal")
    if mode not in {"internal"}:
        return None, error_payload("DB_OPS_REQUEST_INVALID", "field 'archive.mode' currently only supports internal")
    return {"enabled": enabled, "mode": mode}, None


def _validate_table_name(value: Any, *, field_name: str = "table") -> tuple[str | None, dict[str, Any] | None]:
    if not isinstance(value, str) or not value.strip():
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"field '{field_name}' is required")
    normalized = value.strip()
    if not _VALID_TARGET_RE.fullmatch(normalized):
        return None, error_payload("DB_OPS_REQUEST_INVALID", f"invalid table name: {normalized}")
    return normalized, None


def _validate_time_window(
    start: datetime | None,
    end: datetime | None,
    *,
    start_field: str,
    end_field: str,
) -> dict[str, Any] | None:
    if start is None or end is None:
        return None
    if start > end:
        return error_payload(
            "DB_OPS_REQUEST_INVALID",
            f"field '{start_field}' must be less than or equal to '{end_field}'",
        )
    return None

