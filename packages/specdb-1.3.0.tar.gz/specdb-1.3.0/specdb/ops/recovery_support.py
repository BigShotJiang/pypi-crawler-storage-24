"""Recovery helpers for ops job lifecycle."""

from __future__ import annotations


def _recover_stale_job_if_needed(
    job_id: str,
    *,
    scope_key: str | None,
    context: str,
    get_recoverable_job_fn,
    mark_ops_job_failed_fn,
) -> None:
    job = get_recoverable_job_fn(job_id, scope_key=scope_key, only_claimable=True)
    if job is None:
        return
    mark_ops_job_failed_fn(
        job_id,
        scope_key=scope_key,
        error_code="DB_OPS_RECOVERY_REQUIRED",
        failed_stage="stale_recovery",
        last_error=f"stale job in state '{job['state']}' detected during {context}; retry required",
        expected_owner_id=job.get("owner_id"),
        expected_states=(str(job["state"]),),
        expected_lease_expires_at=job.get("lease_expires_at"),
    )


def _recover_incomplete_jobs_for_scope(
    app_obj,
    scope_key: str | None,
    *,
    list_recoverable_jobs_fn,
    mark_ops_job_failed_fn,
) -> None:
    with app_obj.app_context():
        for job in list_recoverable_jobs_fn(scope_key=scope_key, only_claimable=True):
            mark_ops_job_failed_fn(
                job["job_id"],
                scope_key=scope_key,
                error_code="DB_OPS_RECOVERY_REQUIRED",
                failed_stage="startup_recovery",
                last_error=f"stale job in state '{job['state']}' found during app startup; retry required",
                expected_owner_id=job.get("owner_id"),
                expected_states=(str(job["state"]),),
                expected_lease_expires_at=job.get("lease_expires_at"),
            )
