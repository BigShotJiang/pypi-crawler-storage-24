"""Shared helpers for blueprint state and request validation."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable

from flask import request

from specdb.db_executor import DBExecuteError, error_payload


def _status_for_error(code: str, error_http_status: dict[str, int]) -> int:
    return error_http_status.get(code, 400)


def _get_app_db_module_extension(app_obj) -> dict[str, Any]:
    ext = app_obj.extensions.setdefault("db_module", {})
    ext.setdefault("ops_states", {})
    ext.setdefault("ops_auth_callbacks", {})
    ext.setdefault("blueprint_options", {})
    return ext


def _normalize_ops_scope_key(scope_key: str | None) -> str:
    if not isinstance(scope_key, str):
        return "db"
    normalized = scope_key.strip()
    return normalized or "db"


def _is_ops_route_rule(rule: str) -> bool:
    segments = [segment for segment in rule.split("/") if segment]
    return "ops" in segments


def _resolve_ops_auth_callback(app_obj, scope_key: str | None) -> Callable[[Any], Any] | None:
    ext = _get_app_db_module_extension(app_obj)
    key = _normalize_ops_scope_key(scope_key)
    callbacks = ext["ops_auth_callbacks"]
    if key in callbacks:
        return callbacks[key]
    return None


def _resolve_blueprint_options(app_obj, scope_key: str | None) -> dict[str, Any]:
    ext = _get_app_db_module_extension(app_obj)
    key = scope_key or "db"
    options = ext["blueprint_options"].get(key)
    if isinstance(options, dict):
        return options
    return {
        "url_prefix": "/api/db",
        "enable_ops_routes": True,
        "enable_templates_routes": True,
        "enable_restore_routes": True,
    }


def _validate_request_json() -> dict[str, Any]:
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise DBExecuteError("DB_SCHEMA_ERROR", "request body must be a JSON object")
    spec = body.get("spec")
    if not isinstance(spec, dict):
        raise DBExecuteError("DB_SCHEMA_ERROR", "request body must contain object field 'spec'")
    return spec


def _to_db_naive_utc(dt: datetime, *, dialect_name: str) -> datetime:
    if dialect_name == "sqlite":
        if dt.tzinfo is None:
            return dt
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _validate_existing_targets(targets: list[str], *, existing_tables: list[str]) -> dict[str, Any] | None:
    if not targets:
        return None
    existing_table_names = set(existing_tables)
    missing_targets = [item for item in targets if item not in existing_table_names]
    if not missing_targets:
        return None
    return error_payload(
        "DB_OPS_REQUEST_INVALID",
        "target tables not found",
        {"missing_targets": missing_targets},
    )

