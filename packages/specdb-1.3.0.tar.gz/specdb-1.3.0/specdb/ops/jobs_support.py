"""Support helpers for compact job execution."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
from typing import Any
import uuid

from specdb.ops_jobs_store import resolve_job_storage_id


class _CompactExecutionError(RuntimeError):
    def __init__(
        self,
        cause: Exception,
        *,
        log_rows_compacted: int,
        history_rows_compacted: int,
        table_stats: list[dict[str, Any]],
        compact_metrics: dict[str, Any],
    ) -> None:
        super().__init__(str(cause))
        self.__cause__ = cause
        self.log_rows_compacted = int(log_rows_compacted)
        self.history_rows_compacted = int(history_rows_compacted)
        self.table_stats = list(table_stats)
        self.compact_metrics = dict(compact_metrics)


def _actual_table_stats_from_metrics(compact_metrics: dict[str, Any], table_stats: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for item in table_stats:
        table_name = item.get("table")
        if not isinstance(table_name, str) or not table_name:
            continue
        normalized.append(
            {
                "table": table_name,
                "log_rows": int(item.get("log_rows", 0) or 0),
                "history_rows": int(item.get("history_rows", 0) or 0),
            }
        )

    log_total = int(compact_metrics.get("log_deleted_rows", 0) or 0)
    history_total = int(compact_metrics.get("history_deleted_rows", 0) or 0)
    if sum(int(item["log_rows"]) for item in normalized) != log_total:
        for item in normalized:
            item["log_rows"] = 0
    if sum(int(item["history_rows"]) for item in normalized) != history_total:
        for item in normalized:
            item["history_rows"] = 0
    return normalized


def _merge_compact_table_stats(
    target: dict[str, dict[str, int | str]],
    table_stats: list[dict[str, Any]],
) -> None:
    for item in table_stats:
        table_name = item.get("table")
        if not isinstance(table_name, str) or not table_name:
            continue
        entry = target.setdefault(table_name, {"table": table_name, "log_rows": 0, "history_rows": 0})
        entry["log_rows"] = int(entry["log_rows"]) + int(item.get("log_rows", 0) or 0)
        entry["history_rows"] = int(entry["history_rows"]) + int(item.get("history_rows", 0) or 0)


def _merge_compact_metrics(total_metrics: dict[str, Any], current_metrics: dict[str, Any]) -> dict[str, Any]:
    merged = dict(total_metrics)
    current = dict(current_metrics)
    total_batches = int(merged.get("batches", 0) or 0)
    current_batches = int(current.get("batches", 0) or 0)
    total_avg = int(merged.get("avg_batch_ms", 0) or 0)
    current_avg = int(current.get("avg_batch_ms", 0) or 0)
    weighted_total_ms = total_avg * total_batches + current_avg * current_batches

    for key in ("batches", "deleted_rows", "log_batches", "history_batches", "log_deleted_rows", "history_deleted_rows", "archive_rows"):
        merged[key] = int(merged.get(key, 0) or 0) + int(current.get(key, 0) or 0)
    merged["max_batch_ms"] = max(int(merged.get("max_batch_ms", 0) or 0), int(current.get("max_batch_ms", 0) or 0))
    merged["batch_size"] = int(current.get("batch_size", merged.get("batch_size", 0)) or 0)
    if "archive_mode" in current:
        merged["archive_mode"] = current["archive_mode"]
    merged["archive_persisted"] = bool(merged.get("archive_persisted")) or bool(current.get("archive_persisted"))
    merged["avg_batch_ms"] = int(weighted_total_ms / merged["batches"]) if int(merged["batches"]) > 0 else 0
    return merged


def _build_ops_snapshot_and_archive_ids(
    job_id: str,
    *,
    scope_key: str | None = None,
    internal_job_id: str | None = None,
    now: datetime | None = None,
    run_token: str | None = None,
) -> tuple[str, str]:
    current = now or datetime.now(timezone.utc)
    token = (run_token or uuid.uuid4().hex).replace("-", "")[:12] or "run"
    storage_job_id = internal_job_id or resolve_job_storage_id(job_id, scope_key=scope_key)
    job_tag = hashlib.sha1(storage_job_id.encode("utf-8")).hexdigest()[:16]
    timestamp = current.astimezone(timezone.utc).strftime("%Y%m%d%H%M%S%f")
    snapshot_id = f"snapshot-{timestamp}-{job_tag}-{token}"
    archive_id = f"archive-{timestamp}-{job_tag}-{token}"
    return snapshot_id, archive_id


def _merge_table_stat(
    stats: dict[str, dict[str, Any]],
    table_name: str,
    *,
    log_rows: int = 0,
    history_rows: int = 0,
) -> None:
    entry = stats.setdefault(table_name, {"table": table_name, "log_rows": 0, "history_rows": 0})
    entry["log_rows"] = int(entry["log_rows"]) + int(log_rows)
    entry["history_rows"] = int(entry["history_rows"]) + int(history_rows)

