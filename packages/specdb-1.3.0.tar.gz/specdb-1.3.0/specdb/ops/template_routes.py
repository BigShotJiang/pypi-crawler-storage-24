"""Template route handlers."""

from __future__ import annotations

from flask import jsonify

from specdb.db_executor import error_payload, success_payload
from specdb.db_templates.template_library import build_define_spec, get_template, get_template_rules, list_templates


def list_db_templates_response():
    return jsonify(success_payload(list_templates()))


def get_db_template_response(template_key: str):
    template = get_template(template_key)
    if template is None:
        return jsonify(error_payload("DB_TEMPLATE_NOT_FOUND", f"template not found: {template_key}")), 404
    return jsonify(success_payload(template))


def get_db_template_define_spec_response(template_key: str):
    spec = build_define_spec(template_key)
    if spec is None:
        return jsonify(error_payload("DB_TEMPLATE_NOT_FOUND", f"template not found: {template_key}")), 404
    return jsonify(success_payload(spec))


def get_db_template_rules_response(template_key: str):
    rules = get_template_rules(template_key)
    if rules is None:
        return jsonify(error_payload("DB_TEMPLATE_RULES_NOT_FOUND", f"template rules not found: {template_key}")), 404
    return jsonify(success_payload(rules))

