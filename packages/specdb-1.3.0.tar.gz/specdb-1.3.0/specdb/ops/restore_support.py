"""Helpers shared by restore and change-log routes."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import MetaData, Table

from specdb.db_runtime import db


def _load_runtime_table(table_name: str) -> Table:
    metadata = MetaData()
    return Table(table_name, metadata, autoload_with=db.engine)


def _sanitize_restore_payload(table: Table, payload: dict[str, Any]) -> dict[str, Any]:
    allowed_columns = {column.name for column in table.columns}
    return {key: value for key, value in payload.items() if key in allowed_columns}


def _build_pk_filters(table: Table, row_key: dict[str, Any]) -> list[Any]:
    pk_columns = [col.name for col in table.primary_key.columns]
    if not pk_columns:
        raise ValueError(f"table has no primary key: {table.name}")
    filters: list[Any] = []
    for key in pk_columns:
        if key not in row_key:
            raise ValueError(f"row_key missing pk field: {key}")
        filters.append(table.c[key] == row_key[key])
    return filters


def _build_row_key_from_payload(table: Table, payload: dict[str, Any], *, field_name: str) -> dict[str, Any]:
    pk_columns = [col.name for col in table.primary_key.columns]
    if not pk_columns:
        raise ValueError(f"table has no primary key: {table.name}")
    row_key: dict[str, Any] = {}
    for key in pk_columns:
        if key not in payload:
            raise ValueError(f"{field_name} missing pk field: {key}")
        row_key[key] = payload[key]
    return row_key


def _serialize_ops_log_row(row: dict[str, Any]) -> dict[str, Any]:
    data = dict(row)
    changed_at = data.get("changed_at")
    if isinstance(changed_at, datetime):
        if changed_at.tzinfo is None:
            changed_at = changed_at.replace(tzinfo=timezone.utc)
        data["changed_at"] = changed_at.isoformat()
    elif isinstance(changed_at, str) and changed_at:
        try:
            parsed = datetime.fromisoformat(changed_at.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            data["changed_at"] = parsed.isoformat()
        except ValueError:
            pass
    return data
