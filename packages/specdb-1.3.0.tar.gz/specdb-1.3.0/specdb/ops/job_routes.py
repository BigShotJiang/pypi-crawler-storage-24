"""Job-related route handlers for ops endpoints."""

from __future__ import annotations

from datetime import timezone
from typing import Any, Callable

from flask import jsonify, request

from specdb.db_executor import success_payload
from specdb.ops.request_validation import (
    _parse_bool,
    _parse_iso_datetime,
    _validate_archive_options,
    _validate_job_id,
    _validate_request_id,
    _validate_targets,
)


def snapshot_and_compact_response(
    *,
    ops_error: Callable[..., Any],
    validate_existing_targets_fn,
    list_public_table_names_fn,
    create_pending_job_fn,
    submit_ops_job_or_error_fn,
    internal_request_keys: set[str] | tuple[str, ...],
    conflict_error_type,
):
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return ops_error("DB_OPS_REQUEST_INVALID", "request body must be a JSON object", 400)

    request_id, err = _validate_request_id(body.get("request_id"))
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    body["request_id"] = request_id

    dry_run, err = _parse_bool(body.get("dry_run"), "dry_run")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    body["dry_run"] = dry_run

    targets, err = _validate_targets(body.get("targets"))
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    err = validate_existing_targets_fn(targets, existing_tables=list_public_table_names_fn())
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400, err.get("error", {}).get("details"))
    body["targets"] = targets

    archive, err = _validate_archive_options(body.get("archive"))
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    body["archive"] = archive

    strategy = body.get("strategy")
    if strategy is None:
        body["strategy"] = {}
    else:
        if not isinstance(strategy, dict):
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'strategy' must be object", 400)
        mode = strategy.get("mode")
        if mode is not None and mode not in {"auto", "force"}:
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'strategy.mode' must be auto|force", 400)
        compact_before, err = _parse_iso_datetime(strategy.get("compact_before"), "strategy.compact_before")
        if err is not None:
            return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
        if compact_before is not None:
            if compact_before.tzinfo is None:
                compact_before = compact_before.replace(tzinfo=timezone.utc)
            strategy["compact_before"] = compact_before.astimezone(timezone.utc).isoformat()

    operator = body.get("operator")
    if operator is not None and (not isinstance(operator, str) or not operator.strip()):
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'operator' must be non-empty string", 400)
    node = body.get("node")
    if node is not None and (not isinstance(node, str) or not node.strip()):
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'node' must be non-empty string", 400)
    body[next(iter(internal_request_keys))] = request.blueprint

    try:
        job = create_pending_job_fn(request_id, body, scope_key=request.blueprint)
    except conflict_error_type as exc:
        return ops_error("DB_OPS_CONFLICT", str(exc), 409)
    if job.get("state") == "pending":
        submit_error = submit_ops_job_or_error_fn(job["job_id"], scope_key=request.blueprint)
        if submit_error is not None:
            return submit_error

    response_data = {
        "job_id": job["job_id"],
        "state": job.get("state", "pending"),
        "snapshot_id": job.get("snapshot_id"),
    }
    return jsonify(success_payload(response_data)), 202


def get_ops_job_response(*, ops_error: Callable[..., Any], get_job_fn):
    job_id, err = _validate_job_id(request.view_args["job_id"])
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    job = get_job_fn(job_id, scope_key=request.blueprint)
    if job is None:
        return ops_error("DB_OPS_NOT_FOUND", f"job not found: {job_id}", 404)
    return jsonify(success_payload(job))


def retry_ops_job_response(
    *,
    ops_error: Callable[..., Any],
    get_job_fn,
    retry_failed_job_fn,
    recover_stale_job_if_needed_fn,
    submit_ops_job_or_error_fn,
):
    body = request.get_json(silent=True)
    if body is None:
        body = {}
    if not isinstance(body, dict):
        return ops_error("DB_OPS_REQUEST_INVALID", "request body must be a JSON object", 400)
    if body:
        return ops_error("DB_OPS_REQUEST_INVALID", "retry endpoint does not accept request fields", 400)
    job_id, err = _validate_job_id(request.view_args["job_id"])
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    recover_stale_job_if_needed_fn(job_id, scope_key=request.blueprint, context="job retry")
    job = get_job_fn(job_id, scope_key=request.blueprint)
    if job is None:
        return ops_error("DB_OPS_NOT_FOUND", f"job not found: {job_id}", 404)
    if job.get("state") != "failed":
        return ops_error("DB_OPS_CONFLICT", f"job state does not allow retry: {job.get('state')}", 409)

    retried = retry_failed_job_fn(job_id, scope_key=request.blueprint)
    if retried is None:
        return ops_error("DB_OPS_NOT_FOUND", f"job not found: {job_id}", 404)
    submit_error = submit_ops_job_or_error_fn(job_id, scope_key=request.blueprint)
    if submit_error is not None:
        return submit_error
    return jsonify(success_payload({"job_id": job_id, "state": retried.get("state", "pending")})), 202
