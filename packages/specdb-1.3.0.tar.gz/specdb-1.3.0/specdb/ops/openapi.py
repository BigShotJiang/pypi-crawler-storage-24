"""OpenAPI helpers for the DB blueprint."""

from __future__ import annotations

from typing import Any


def _build_openapi_spec(
    *,
    url_prefix: str,
    enable_ops_routes: bool,
    enable_templates_routes: bool,
    enable_restore_routes: bool,
) -> dict[str, Any]:
    paths: dict[str, Any] = {
        f"{url_prefix}/table": {
            "post": {"summary": "Execute table.* actions", "requestBody": {"required": True}, "responses": {"200": {"description": "OK"}}}
        },
        f"{url_prefix}/data": {
            "post": {"summary": "Execute data.* actions", "requestBody": {"required": True}, "responses": {"200": {"description": "OK"}}}
        },
    }
    if enable_templates_routes:
        paths[f"{url_prefix}/templates"] = {"get": {"summary": "List DB templates", "responses": {"200": {"description": "OK"}}}}
        paths[f"{url_prefix}/templates/{{template_key}}"] = {
            "get": {"summary": "Get DB template detail", "responses": {"200": {"description": "OK"}}}
        }
        paths[f"{url_prefix}/templates/{{template_key}}/define-spec"] = {
            "get": {"summary": "Get template define spec", "responses": {"200": {"description": "OK"}}}
        }
        paths[f"{url_prefix}/templates/{{template_key}}/rules"] = {
            "get": {"summary": "Get template rules", "responses": {"200": {"description": "OK"}}}
        }
    if enable_ops_routes:
        paths[f"{url_prefix}/ops/snapshot-and-compact"] = {
            "post": {"summary": "Create snapshot+compact job", "responses": {"202": {"description": "Accepted"}}}
        }
        paths[f"{url_prefix}/ops/jobs/{{job_id}}"] = {
            "get": {"summary": "Get ops job", "responses": {"200": {"description": "OK"}}}
        }
        paths[f"{url_prefix}/ops/jobs/{{job_id}}/retry"] = {
            "post": {"summary": "Retry failed ops job", "responses": {"202": {"description": "Accepted"}}}
        }
        paths[f"{url_prefix}/ops/change-logs"] = {
            "get": {"summary": "List change logs", "responses": {"200": {"description": "OK"}}}
        }
        if enable_restore_routes:
            paths[f"{url_prefix}/ops/restore-from-logs"] = {
                "post": {"summary": "Restore from change logs", "responses": {"200": {"description": "OK"}}}
            }
            paths[f"{url_prefix}/ops/restore-audits"] = {
                "get": {"summary": "List restore audits", "responses": {"200": {"description": "OK"}}}
            }
            paths[f"{url_prefix}/ops/restore-audits/cleanup"] = {
                "post": {"summary": "Cleanup restore audits", "responses": {"200": {"description": "OK"}}}
            }

    return {
        "openapi": "3.0.3",
        "info": {
            "title": "Generic DB Module API",
            "version": "0.1.0",
        },
        "paths": paths,
        "components": {
            "schemas": {
                "ApiSuccess": {
                    "type": "object",
                    "required": ["success", "data", "error"],
                    "properties": {
                        "success": {"type": "boolean", "enum": [True]},
                        "data": {},
                        "error": {"type": "null"},
                    },
                },
                "ApiError": {
                    "type": "object",
                    "required": ["success", "data", "error"],
                    "properties": {
                        "success": {"type": "boolean", "enum": [False]},
                        "data": {"type": "null"},
                        "error": {
                            "type": "object",
                            "required": ["code", "message"],
                            "properties": {
                                "code": {"type": "string"},
                                "message": {"type": "string"},
                                "details": {"type": "object"},
                            },
                        },
                    },
                },
                "ExecuteSpecRequest": {
                    "type": "object",
                    "required": ["spec"],
                    "properties": {
                        "spec": {
                            "type": "object",
                            "required": ["action"],
                            "properties": {
                                "action": {"type": "string"},
                                "table": {"type": "string"},
                                "payload": {"type": "object"},
                                "options": {"type": "object"},
                            },
                        }
                    },
                },
            }
        },
    }


def _yaml_scalar(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    escaped = text.replace("\\", "\\\\").replace("\"", "\\\"")
    return f"\"{escaped}\""


def _to_yaml(value: Any, indent: int = 0) -> str:
    pad = " " * indent
    if isinstance(value, dict):
        if not value:
            return f"{pad}{{}}"
        lines: list[str] = []
        for key, item in value.items():
            if isinstance(item, dict):
                if not item:
                    lines.append(f"{pad}{key}: {{}}")
                    continue
                lines.append(f"{pad}{key}:")
                lines.append(_to_yaml(item, indent + 2))
            elif isinstance(item, list):
                if not item:
                    lines.append(f"{pad}{key}: []")
                    continue
                lines.append(f"{pad}{key}:")
                lines.append(_to_yaml(item, indent + 2))
            else:
                lines.append(f"{pad}{key}: {_yaml_scalar(item)}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return f"{pad}[]"
        lines = []
        for item in value:
            if isinstance(item, dict):
                if not item:
                    lines.append(f"{pad}- {{}}")
                    continue
                lines.append(f"{pad}-")
                lines.append(_to_yaml(item, indent + 2))
            elif isinstance(item, list):
                if not item:
                    lines.append(f"{pad}- []")
                    continue
                lines.append(f"{pad}-")
                lines.append(_to_yaml(item, indent + 2))
            else:
                lines.append(f"{pad}- {_yaml_scalar(item)}")
        return "\n".join(lines)
    return f"{pad}{_yaml_scalar(value)}"
