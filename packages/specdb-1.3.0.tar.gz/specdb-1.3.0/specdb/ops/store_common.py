"""Shared helpers for ops persistence stores."""

from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from specdb.db_runtime import db


class OpsStoreDataError(RuntimeError):
    """Raised when persisted ops metadata is corrupted or violates store contracts."""


def _json_default(obj: Any) -> str:
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"not JSON serializable: {type(obj)!r}")


def _normalize_datetime_value(value: Any) -> Any:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    if isinstance(value, str) and value:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return value
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.isoformat()
    return value


def _parse_datetime_value(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)
    if isinstance(value, str) and value:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    return None


def _to_db_datetime(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if db.engine.dialect.name == "sqlite":
        if value.tzinfo is None:
            return value
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _parse_json_object(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str) and value:
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return None
        if isinstance(parsed, dict):
            return parsed
    return None


def _decode_json_object_strict(
    value: Any,
    *,
    field_name: str,
    entity_name: str,
    entity_id: Any,
) -> dict[str, Any]:
    if not isinstance(value, str) or not value.strip():
        raise OpsStoreDataError(
            f"invalid ops store payload: {entity_name} {entity_id!r} field {field_name} must be non-empty JSON object"
        )
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise OpsStoreDataError(
            f"invalid ops store JSON: {entity_name} {entity_id!r} field {field_name}"
        ) from exc
    if not isinstance(parsed, dict):
        raise OpsStoreDataError(
            f"invalid ops store payload: {entity_name} {entity_id!r} field {field_name} must decode to object"
        )
    return parsed


def _normalize_ops_context(
    *,
    scope_key: str | None,
    dry_run: Any,
    operator: Any = None,
    node: Any = None,
    request_id: Any = None,
    targets: Any = None,
    archive_enabled: Any = None,
    archive_mode: Any = None,
) -> dict[str, Any]:
    context: dict[str, Any] = {
        "scope_key": scope_key if isinstance(scope_key, str) and scope_key.strip() else None,
        "dry_run": bool(dry_run),
        "operator": operator if isinstance(operator, str) and operator.strip() else None,
        "node": node if isinstance(node, str) and node.strip() else None,
    }
    if isinstance(request_id, str) and request_id.strip():
        context["request_id"] = request_id
    if isinstance(targets, list):
        normalized_targets = [item.strip() for item in targets if isinstance(item, str) and item.strip()]
        if normalized_targets:
            context["targets"] = normalized_targets
    if archive_enabled is not None:
        context["archive_enabled"] = bool(archive_enabled)
    if isinstance(archive_mode, str) and archive_mode.strip():
        context["archive_mode"] = archive_mode
    return context
