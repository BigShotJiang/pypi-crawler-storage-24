"""Shared ops job state and lease helpers."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Any
import uuid

from specdb.ops.blueprint_support import _get_app_db_module_extension


def _resolve_ops_instance_id(app_obj) -> str:
    ext = _get_app_db_module_extension(app_obj)
    instance_id = ext.get("ops_instance_id")
    if isinstance(instance_id, str) and instance_id.strip():
        return instance_id
    configured = app_obj.config.get("DB_MODULE_INSTANCE_ID")
    if isinstance(configured, str) and configured.strip():
        base = configured.strip()[:95]
        instance_id = f"{base}:{uuid.uuid4().hex}"
    else:
        instance_id = f"ops:{uuid.uuid4().hex}"
    ext["ops_instance_id"] = instance_id[:128]
    return ext["ops_instance_id"]


def _ops_job_lease_seconds(app_obj) -> int:
    raw_value = app_obj.config.get("OPS_JOB_LEASE_SECONDS", 900)
    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        value = 900
    return max(value, 30)


def _ops_job_lease_deadline(app_obj) -> datetime:
    return datetime.now(timezone.utc) + timedelta(seconds=_ops_job_lease_seconds(app_obj))


def shutdown_ops_executors(app_obj, *, wait: bool = False) -> None:
    ext = _get_app_db_module_extension(app_obj)
    states = ext.get("ops_states", {})
    for state in list(states.values()):
        executor = state.get("executor")
        if executor is None:
            continue
        try:
            executor.shutdown(wait=wait, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=wait)
    ext["ops_states"] = {}


def _build_ops_state(key: str) -> dict[str, Any]:
    return {
        "executor": ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"db-ops-{key}"),
        "inflight": set(),
        "lock": Lock(),
        "active_archive_request": None,
    }


def _get_ops_state(app_obj, scope_key: str | None) -> dict[str, Any]:
    ext = _get_app_db_module_extension(app_obj)
    states = ext["ops_states"]
    key = scope_key or "default"
    state = states.get(key)
    if not isinstance(state, dict) or state.get("executor") is None:
        state = _build_ops_state(key)
        states[key] = state
    else:
        state.setdefault("inflight", set())
        state.setdefault("lock", Lock())
        state.setdefault("active_archive_request", None)
    return state
