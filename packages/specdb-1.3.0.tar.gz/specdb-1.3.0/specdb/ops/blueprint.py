"""Database module API routes and ops blueprint composition."""

from __future__ import annotations

from typing import Any, Callable

from flask import Blueprint, Response, current_app, jsonify, request

from specdb.db_executor import DBExecuteError, error_payload, init_database, list_public_table_names
from specdb.db_runtime import db
from specdb.ops_jobs_store import (
    _INTERNAL_REQUEST_KEYS,
    JobRequestConflictError,
    create_pending_job,
    get_job,
    get_recoverable_job,
    list_recoverable_jobs,
    retry_failed_job,
)
from specdb.ops.blueprint_factory import (
    _register_db_blueprint_routes as _register_db_blueprint_routes_impl,
    create_db_blueprint as create_db_blueprint_impl,
)
from specdb.ops.blueprint_support import (
    _get_app_db_module_extension,
    _is_ops_route_rule,
    _normalize_ops_scope_key,
    _resolve_ops_auth_callback,
    _status_for_error,
    _to_db_naive_utc,
    _validate_existing_targets,
    _validate_request_json,
)
from specdb.ops.compact_engine import _execute_compact_once
from specdb.ops.job_routes import get_ops_job_response, retry_ops_job_response, snapshot_and_compact_response
from specdb.ops.job_runtime import _mark_ops_job_failed, _run_snapshot_and_compact_job, _submit_ops_job_if_needed
from specdb.ops.job_state import (
    _get_ops_state,
    _ops_job_lease_seconds,
    _resolve_ops_instance_id,
    shutdown_ops_executors,
)
from specdb.ops.recovery_support import _recover_incomplete_jobs_for_scope, _recover_stale_job_if_needed
from specdb.ops.restore_routes import (
    cleanup_restore_audits_response,
    get_restore_audits_response,
    list_change_logs_response,
    restore_from_logs_response,
)
from specdb.ops.template_routes import (
    get_db_template_define_spec_response,
    get_db_template_response,
    get_db_template_rules_response,
    list_db_templates_response,
)

db_bp = Blueprint("db", __name__, url_prefix="/api/db")
_db_client = init_database()

_ERROR_HTTP_STATUS = {
    "DB_SCHEMA_ERROR": 400,
    "DB_ACTION_NOT_SUPPORTED": 501,
    "DB_TABLE_OP_ERROR": 500,
    "DB_QUERY_ERROR": 500,
    "DB_CONNECTION_ERROR": 500,
}
_MAX_RESTORE_PREVIEW_ITEMS = 200


def register_ops_auth_callback(
    callback: Callable[[Any], Any] | None,
    *,
    app_obj=None,
    scope_key: str | None = None,
) -> None:
    if app_obj is None:
        raise ValueError("app_obj is required when registering DB module ops auth callback")
    ext = _get_app_db_module_extension(app_obj)
    key = _normalize_ops_scope_key(scope_key)
    ext["ops_auth_callbacks"][key] = callback


def _before_db_blueprint_request_impl(scope_key: str | None):
    if request.url_rule is None:
        return None
    rule = request.url_rule.rule
    if not _is_ops_route_rule(rule):
        return None
    callback = _resolve_ops_auth_callback(current_app, scope_key)
    if callback is None:
        return None
    try:
        verdict = callback(request)
    except Exception as exc:
        current_app.logger.exception(
            "DB module ops auth callback failed",
            extra={"scope_key": _normalize_ops_scope_key(scope_key)},
        )
        return _ops_error(
            "DB_OPS_AUTH_CALLBACK_FAILED",
            "ops auth callback failed",
            500,
            {"error": str(exc)},
        )
    if isinstance(verdict, Response):
        return verdict
    if verdict is None or verdict is True:
        return None
    if verdict is False:
        return _ops_error("DB_OPS_FORBIDDEN", "ops access denied", 403)
    if isinstance(verdict, tuple) and len(verdict) >= 1:
        allowed = bool(verdict[0])
        if allowed:
            return None
        message = "ops access denied"
        status = 403
        if len(verdict) >= 2 and isinstance(verdict[1], str) and verdict[1]:
            message = verdict[1]
        if len(verdict) >= 3 and isinstance(verdict[2], int) and verdict[2] > 0:
            status = verdict[2]
        return _ops_error("DB_OPS_FORBIDDEN", message, status)
    return _ops_error("DB_OPS_FORBIDDEN", "ops access denied", 403)


@db_bp.before_request
def _before_db_blueprint_request():
    return _before_db_blueprint_request_impl(request.blueprint)


def _run_execute(domain: str):
    try:
        spec = _validate_request_json()
        action = spec.get("action")
        if not isinstance(action, str):
            return jsonify(error_payload("DB_SCHEMA_ERROR", "action is required")), 400
        if domain == "table" and not action.startswith("table."):
            return jsonify(error_payload("DB_SCHEMA_ERROR", "table route only accepts table.* actions")), 400
        if domain == "data" and not action.startswith("data."):
            return jsonify(error_payload("DB_SCHEMA_ERROR", "data route only accepts data.* actions")), 400
        return jsonify(_db_client.execute(spec))
    except DBExecuteError as exc:
        status = _status_for_error(exc.code, _ERROR_HTTP_STATUS)
        return jsonify(error_payload(exc.code, exc.message, exc.details)), status
    except Exception as exc:  # pragma: no cover
        return jsonify(error_payload("DB_QUERY_ERROR", "execution failed", {"error": str(exc)})), 500


def _submit_ops_job_or_error(job_id: str, *, scope_key: str | None = None):
    try:
        _submit_ops_job_if_needed(job_id, scope_key=scope_key)
    except Exception as exc:
        return _ops_error("DB_OPS_SUBMIT_FAILED", "submit ops job failed", 503, {"error": str(exc)})
    return None


def _ops_error(code: str, message: str, status: int, details: dict[str, Any] | None = None):
    return jsonify(error_payload(code, message, details)), status


def _register_db_blueprint_routes(
    bp: Blueprint,
    *,
    url_prefix: str = "/api/db",
    enable_ops_routes: bool = True,
    enable_templates_routes: bool = True,
    enable_restore_routes: bool = True,
) -> None:
    _register_db_blueprint_routes_impl(
        bp,
        url_prefix=url_prefix,
        enable_ops_routes=enable_ops_routes,
        enable_templates_routes=enable_templates_routes,
        enable_restore_routes=enable_restore_routes,
        execute_table_view=execute_table,
        execute_data_view=execute_data,
        list_db_templates_view=list_db_templates,
        get_db_template_view=get_db_template,
        get_db_template_define_spec_view=get_db_template_define_spec,
        get_db_template_rules_view=get_db_template_rules,
        snapshot_and_compact_view=snapshot_and_compact,
        get_ops_job_view=get_ops_job,
        retry_ops_job_view=retry_ops_job,
        list_change_logs_view=list_change_logs,
        get_restore_audits_view=get_restore_audits,
        cleanup_restore_audits_view=cleanup_restore_audits_endpoint,
        restore_from_logs_view=restore_from_logs,
    )


def create_db_blueprint(
    *,
    name: str = "db",
    url_prefix: str = "/api/db",
    ops_auth_callback: Callable[[Any], Any] | None = None,
    enable_ops_routes: bool = True,
    enable_templates_routes: bool = True,
    enable_restore_routes: bool = True,
) -> Blueprint:
    return create_db_blueprint_impl(
        name=name,
        module_name=__name__,
        url_prefix=url_prefix,
        ops_auth_callback=ops_auth_callback,
        enable_ops_routes=enable_ops_routes,
        enable_templates_routes=enable_templates_routes,
        enable_restore_routes=enable_restore_routes,
        before_request_impl=_before_db_blueprint_request_impl,
        register_ops_auth_callback_fn=register_ops_auth_callback,
        get_app_db_module_extension_fn=_get_app_db_module_extension,
        recover_incomplete_jobs_for_scope_fn=lambda app_obj, scope_key: _recover_incomplete_jobs_for_scope(
            app_obj,
            scope_key,
            list_recoverable_jobs_fn=list_recoverable_jobs,
            mark_ops_job_failed_fn=_mark_ops_job_failed,
        ),
        execute_table_view=execute_table,
        execute_data_view=execute_data,
        list_db_templates_view=list_db_templates,
        get_db_template_view=get_db_template,
        get_db_template_define_spec_view=get_db_template_define_spec,
        get_db_template_rules_view=get_db_template_rules,
        snapshot_and_compact_view=snapshot_and_compact,
        get_ops_job_view=get_ops_job,
        retry_ops_job_view=retry_ops_job,
        list_change_logs_view=list_change_logs,
        get_restore_audits_view=get_restore_audits,
        cleanup_restore_audits_view=cleanup_restore_audits_endpoint,
        restore_from_logs_view=restore_from_logs,
    )


@db_bp.post("/table")
def execute_table():
    return _run_execute("table")


@db_bp.post("/data")
def execute_data():
    return _run_execute("data")


@db_bp.get("/templates")
def list_db_templates():
    return list_db_templates_response()


@db_bp.get("/templates/<template_key>")
def get_db_template(template_key: str):
    return get_db_template_response(template_key)


@db_bp.get("/templates/<template_key>/define-spec")
def get_db_template_define_spec(template_key: str):
    return get_db_template_define_spec_response(template_key)


@db_bp.get("/templates/<template_key>/rules")
def get_db_template_rules(template_key: str):
    return get_db_template_rules_response(template_key)


@db_bp.post("/ops/snapshot-and-compact")
def snapshot_and_compact():
    return snapshot_and_compact_response(
        ops_error=_ops_error,
        validate_existing_targets_fn=_validate_existing_targets,
        list_public_table_names_fn=list_public_table_names,
        create_pending_job_fn=create_pending_job,
        submit_ops_job_or_error_fn=_submit_ops_job_or_error,
        internal_request_keys=_INTERNAL_REQUEST_KEYS,
        conflict_error_type=JobRequestConflictError,
    )


@db_bp.get("/ops/jobs/<job_id>")
def get_ops_job(job_id: str):
    return get_ops_job_response(
        ops_error=_ops_error,
        get_job_fn=get_job,
    )


@db_bp.post("/ops/jobs/<job_id>/retry")
def retry_ops_job(job_id: str):
    return retry_ops_job_response(
        ops_error=_ops_error,
        get_job_fn=get_job,
        retry_failed_job_fn=retry_failed_job,
        recover_stale_job_if_needed_fn=lambda job_id_arg, *, scope_key, context: _recover_stale_job_if_needed(
            job_id_arg,
            scope_key=scope_key,
            context=context,
            get_recoverable_job_fn=get_recoverable_job,
            mark_ops_job_failed_fn=_mark_ops_job_failed,
        ),
        submit_ops_job_or_error_fn=_submit_ops_job_or_error,
    )


@db_bp.get("/ops/change-logs")
def list_change_logs():
    return list_change_logs_response(_ops_error)


@db_bp.get("/ops/restore-audits")
def get_restore_audits():
    return get_restore_audits_response(
        _ops_error,
        lambda dt: _to_db_naive_utc(dt, dialect_name=db.engine.dialect.name),
    )


@db_bp.post("/ops/restore-audits/cleanup")
def cleanup_restore_audits_endpoint():
    return cleanup_restore_audits_response(_ops_error)


@db_bp.post("/ops/restore-from-logs")
def restore_from_logs():
    return restore_from_logs_response(
        _ops_error,
        lambda dt: _to_db_naive_utc(dt, dialect_name=db.engine.dialect.name),
        max_restore_preview_items=_MAX_RESTORE_PREVIEW_ITEMS,
    )
