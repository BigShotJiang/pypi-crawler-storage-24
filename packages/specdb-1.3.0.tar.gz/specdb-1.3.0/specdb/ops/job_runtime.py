"""Background runtime for ops jobs."""

from __future__ import annotations

from datetime import datetime, timezone
import time
from typing import Any, Callable

from flask import current_app, request

from specdb.db_runtime import db
import specdb.ops_archive_store as archive_store
import specdb.ops_jobs_store as jobs_store
import specdb.ops.compact_engine as compact_engine
import specdb.ops.job_state as job_state
from specdb.ops.blueprint_support import _to_db_naive_utc
from specdb.ops.jobs_support import (
    _CompactExecutionError,
    _actual_table_stats_from_metrics,
    _build_ops_snapshot_and_archive_ids,
    _merge_compact_metrics,
    _merge_compact_table_stats,
)
from specdb.ops.job_runtime_support import (
    build_archive_request,
    build_failed_summary,
    build_initial_compact_metrics,
    build_verified_summary,
    parse_job_request,
)
from specdb.ops.request_validation import _parse_iso_datetime

_RECOVERABLE_OPS_JOB_STATES = ("pending", "snapshot_done", "compact_done")
_UNSET_EXPECTATION = object()


def _combine_followup_error(base_exc: Exception, action: str, followup_exc: Exception) -> RuntimeError:
    return RuntimeError(f"{base_exc}; {action}: {followup_exc}")


def _commit_guarded_side_effect(
    *,
    app,
    job_id: str,
    scope_key: str | None,
    owner_id: str,
    write_fn: Callable[[Any], None],
) -> None:
    session_conn = db.session.connection()
    if not jobs_store.renew_job_lease(
        job_id,
        scope_key=scope_key,
        owner_id=owner_id,
        lease_seconds=job_state._ops_job_lease_seconds(app),
        conn=session_conn,
        require_unexpired=True,
    ):
        raise RuntimeError(f"ops job lease lost: {job_id}")
    write_fn(session_conn)
    db.session.commit()


def _run_compaction_with_retries(
    *,
    app,
    state: dict[str, Any],
    job_id: str,
    scope_key: str | None,
    owner_id: str,
    archive_request: dict[str, Any],
    archive_id: str | None,
    snapshot_id: str,
    request_id: str,
    targets: list[str],
    compact_before_dt: datetime | None,
    dry_run: bool,
    heartbeat: Callable[[], None],
    max_retries: int,
    progress: dict[str, Any],
) -> dict[str, Any]:
    retry_count = 0
    batch_size = int(app.config.get("OPS_COMPACT_BATCH_SIZE", 5000) or 5000)
    compact_metrics = build_initial_compact_metrics(batch_size)
    compact_metrics["archive_persisted"] = False
    archive_created = False
    total_compacted_rows = 0
    total_history_compacted_rows = 0
    total_table_stats: dict[str, dict[str, int | str]] = {}
    total_compact_metrics = dict(compact_metrics)

    if archive_request["enabled"] and not dry_run:
        archive_store.ensure_ops_archive_tables()

    while True:
        try:
            archive_request["archive_persisted"] = archive_created
            with state["lock"]:
                state["active_archive_request"] = dict(archive_request)
            try:
                compacted_rows, history_compacted_rows, table_stats, compact_metrics = compact_engine._execute_compact_once(
                    dry_run=dry_run,
                    targets=targets,
                    compact_before_dt=compact_before_dt,
                    batch_size=batch_size,
                    scope_key=scope_key,
                    heartbeat=heartbeat,
                )
            except _CompactExecutionError as exc:
                compacted_rows = exc.log_rows_compacted
                history_compacted_rows = exc.history_rows_compacted
                table_stats = exc.table_stats
                compact_metrics = exc.compact_metrics
                total_compacted_rows += int(compacted_rows or 0)
                total_history_compacted_rows += int(history_compacted_rows or 0)
                _merge_compact_table_stats(total_table_stats, table_stats)
                total_compact_metrics = _merge_compact_metrics(total_compact_metrics, compact_metrics)
                archive_created = archive_created or bool(total_compact_metrics.get("archive_persisted"))
                raise
            finally:
                with state["lock"]:
                    state["active_archive_request"] = None

            total_compacted_rows += int(compacted_rows or 0)
            total_history_compacted_rows += int(history_compacted_rows or 0)
            _merge_compact_table_stats(total_table_stats, table_stats)
            total_compact_metrics = _merge_compact_metrics(total_compact_metrics, compact_metrics)
            archive_created = archive_created or bool(total_compact_metrics.get("archive_persisted"))

            if archive_request["enabled"] and not dry_run and not archive_created and archive_id is not None:
                _commit_guarded_side_effect(
                    app=app,
                    job_id=job_id,
                    scope_key=scope_key,
                    owner_id=owner_id,
                    write_fn=lambda conn: archive_store.create_archive(
                        archive_id,
                        job_id=job_id,
                        request_id=request_id,
                        snapshot_id=snapshot_id,
                        metadata={
                            "mode": archive_request["mode"],
                            "targets": targets,
                            "compact_before": compact_before_dt.isoformat() if compact_before_dt is not None else None,
                            "dry_run": dry_run,
                        },
                        conn=conn,
                    ),
                )
                archive_created = True
                total_compact_metrics["archive_persisted"] = True

            archived_rows = int(total_compact_metrics.get("archive_rows", 0) or 0)
            if archive_created and archive_id is not None:
                archived_rows = archive_store.get_archive_item_count(archive_id)
                _commit_guarded_side_effect(
                    app=app,
                    job_id=job_id,
                    scope_key=scope_key,
                    owner_id=owner_id,
                    write_fn=lambda conn: archive_store.update_archive(
                        archive_id,
                        item_count=archived_rows,
                        metadata={
                            "mode": archive_request["mode"],
                            "targets": targets,
                            "compact_before": compact_before_dt.isoformat() if compact_before_dt is not None else None,
                            "dry_run": dry_run,
                            "log_rows_compacted": total_compacted_rows,
                            "history_rows_compacted": total_history_compacted_rows,
                            "archived_rows": archived_rows,
                        },
                        conn=conn,
                    ),
                )
            result = {
                "retry_count": retry_count,
                "archive_created": archive_created,
                "archive_id": archive_id if archive_created else None,
                "archived_rows": archived_rows,
                "compacted_rows": total_compacted_rows,
                "history_compacted_rows": total_history_compacted_rows,
                "table_stats": list(total_table_stats.values()),
                "compact_metrics": total_compact_metrics,
            }
            progress.update(result)
            return result
        except Exception as compact_exc:
            db.session.rollback()
            archived_rows = int(total_compact_metrics.get("archive_rows", 0) or 0)
            progress.update(
                {
                    "retry_count": retry_count,
                    "archive_created": archive_created,
                    "archive_id": archive_id if archive_created else None,
                    "archived_rows": archived_rows,
                    "compacted_rows": total_compacted_rows,
                    "history_compacted_rows": total_history_compacted_rows,
                    "table_stats": list(total_table_stats.values()),
                    "compact_metrics": total_compact_metrics,
                }
            )
            if (
                archive_id is not None
                and archive_created
                and int(archived_rows or 0) <= 0
                and int(total_compacted_rows or 0) <= 0
                and int(total_history_compacted_rows or 0) <= 0
            ):
                try:
                    _commit_guarded_side_effect(
                        app=app,
                        job_id=job_id,
                        scope_key=scope_key,
                        owner_id=owner_id,
                        write_fn=lambda conn: archive_store.delete_archive(archive_id, conn=conn),
                    )
                except Exception as cleanup_exc:
                    db.session.rollback()
                    raise _combine_followup_error(compact_exc, "archive cleanup failed", cleanup_exc) from cleanup_exc
                archive_created = False
                archive_id = None
                archive_request.pop("archive_id", None)
                progress.update({"archive_created": False, "archive_id": None})
            if retry_count >= max_retries:
                raise
            retry_count += 1


def _run_snapshot_and_compact_job(
    app,
    job_id: str,
    scope_key: str | None = None,
    owner_id: str | None = None,
) -> None:
    with app.app_context():
        started = time.perf_counter()
        stage = "load_job"
        retry_count = 0
        state = job_state._get_ops_state(current_app, scope_key)
        max_retries = int(current_app.config.get("OPS_COMPACT_MAX_RETRIES", 1) or 0)
        if max_retries < 0:
            max_retries = 0
        owner = owner_id or job_state._resolve_ops_instance_id(current_app)
        req: dict[str, Any] | None = None
        dry_run = False
        targets: list[str] = []
        archive: dict[str, Any] = {"enabled": False, "mode": "internal"}
        compact_before_dt: datetime | None = None
        archive_id: str | None = None
        compacted_rows = 0
        archived_rows = 0
        history_compacted_rows = 0
        table_stats: list[dict[str, Any]] = []
        compact_metrics: dict[str, Any] = build_initial_compact_metrics(
            int(current_app.config.get("OPS_COMPACT_BATCH_SIZE", 5000) or 5000)
        )
        archive_created = False
        operator = None
        node = None

        def _heartbeat() -> None:
            if not jobs_store.renew_job_lease(
                job_id,
                scope_key=scope_key,
                owner_id=owner,
                lease_seconds=job_state._ops_job_lease_seconds(current_app),
            ):
                raise RuntimeError(f"ops job lease lost: {job_id}")

        try:
            _heartbeat()
            job = jobs_store.get_job(job_id, scope_key=scope_key)
            if job is None or job.get("state") != "pending":
                return

            snapshot_id, next_archive_id = _build_ops_snapshot_and_archive_ids(job_id, scope_key=scope_key)
            snapshot_job = jobs_store.update_job_state(
                job_id,
                "snapshot_done",
                scope_key=scope_key,
                snapshot_id=snapshot_id,
                error_code=None,
                owner_id=owner,
                lease_expires_at=job_state._ops_job_lease_deadline(current_app),
                expected_owner_id=owner,
                expected_states=("pending",),
            )
            if snapshot_job is None:
                raise RuntimeError(f"ops job ownership lost before snapshot transition: {job_id}")

            stage = "parse_request"
            parsed_request = parse_job_request(job, dialect_name=db.engine.dialect.name)
            req = parsed_request["request"]
            dry_run = parsed_request["dry_run"]
            targets = parsed_request["targets"]
            archive = parsed_request["archive"]
            compact_before_dt = parsed_request["compact_before_dt"]
            operator = parsed_request["operator"]
            node = parsed_request["node"]

            stage = "compact"
            archive_id = next_archive_id if bool(archive.get("enabled", False)) and not dry_run else None
            compact_progress = {
                "retry_count": 0,
                "archive_created": False,
                "archive_id": archive_id,
                "archived_rows": 0,
                "compacted_rows": 0,
                "history_compacted_rows": 0,
                "table_stats": [],
                "compact_metrics": dict(compact_metrics),
            }
            compact_result = _run_compaction_with_retries(
                app=current_app,
                state=state,
                job_id=job_id,
                scope_key=scope_key,
                owner_id=owner,
                archive_request=build_archive_request(
                    req,
                    job_id=job_id,
                    owner_id=owner,
                    snapshot_id=snapshot_id,
                    targets=targets,
                    compact_before_dt=compact_before_dt,
                    dry_run=dry_run,
                    archive_id=archive_id,
                ),
                archive_id=archive_id,
                snapshot_id=snapshot_id,
                request_id=str(req.get("request_id", job_id)),
                targets=targets,
                compact_before_dt=compact_before_dt,
                dry_run=dry_run,
                heartbeat=_heartbeat,
                max_retries=max_retries,
                progress=compact_progress,
            )
            retry_count = compact_result["retry_count"]
            archive_created = compact_result["archive_created"]
            archive_id = compact_result["archive_id"]
            archived_rows = compact_result["archived_rows"]
            compacted_rows = compact_result["compacted_rows"]
            history_compacted_rows = compact_result["history_compacted_rows"]
            table_stats = compact_result["table_stats"]
            compact_metrics = compact_result["compact_metrics"]

            compact_done = jobs_store.update_job_state(
                job_id,
                "compact_done",
                scope_key=scope_key,
                snapshot_id=snapshot_id,
                error_code=None,
                owner_id=owner,
                lease_expires_at=job_state._ops_job_lease_deadline(current_app),
                expected_owner_id=owner,
                expected_states=("snapshot_done", "compact_done"),
            )
            if compact_done is None:
                raise RuntimeError(f"ops job ownership lost before compact completion: {job_id}")
            verified_job = jobs_store.update_job_state_with_summary(
                job_id,
                scope_key=scope_key,
                state="verified",
                snapshot_id=snapshot_id,
                error_code=None,
                owner_id=None,
                lease_expires_at=None,
                summary=build_verified_summary(
                    dry_run=dry_run,
                    targets=targets,
                    compact_before_dt=compact_before_dt,
                    table_stats=table_stats,
                    compacted_rows=compacted_rows,
                    history_compacted_rows=history_compacted_rows,
                    archive_enabled=bool(archive.get("enabled", False)),
                    archive_mode=archive.get("mode", "internal"),
                    archive_id=archive_id if archive_created else None,
                    archived_rows=archived_rows,
                    archive_persisted=bool(archive_created or compact_metrics.get("archive_persisted")),
                    compact_metrics=compact_metrics,
                    duration_ms=int((time.perf_counter() - started) * 1000),
                    operator=operator,
                    node=node,
                    retry_count=retry_count,
                    max_retries=max_retries,
                ),
                expected_owner_id=owner,
                expected_states=("compact_done",),
            )
            if verified_job is None:
                raise RuntimeError(f"ops job ownership lost before verification: {job_id}")
        except Exception as exc:
            db.session.rollback()
            failing_exc: Exception = exc
            if "compact_progress" in locals():
                retry_count = compact_progress.get("retry_count", retry_count)
                archive_created = compact_progress.get("archive_created", archive_created)
                archive_id = compact_progress.get("archive_id", archive_id)
                archived_rows = compact_progress.get("archived_rows", archived_rows)
                compacted_rows = compact_progress.get("compacted_rows", compacted_rows)
                history_compacted_rows = compact_progress.get("history_compacted_rows", history_compacted_rows)
                table_stats = compact_progress.get("table_stats", table_stats)
                compact_metrics = compact_progress.get("compact_metrics", compact_metrics)
            if archive_created and archive_id is not None:
                try:
                    archived_rows = archive_store.get_archive_item_count(archive_id)
                    _commit_guarded_side_effect(
                        app=current_app,
                        job_id=job_id,
                        scope_key=scope_key,
                        owner_id=owner,
                        write_fn=lambda conn: archive_store.update_archive(
                            archive_id,
                            item_count=int(archived_rows or 0),
                            metadata={
                                "mode": archive.get("mode", "internal") if isinstance(archive, dict) else "internal",
                                "targets": targets if "targets" in locals() else [],
                                "compact_before": compact_before_dt.isoformat()
                                if "compact_before_dt" in locals() and compact_before_dt is not None
                                else None,
                                "dry_run": dry_run if "dry_run" in locals() else False,
                                "failed_stage": stage,
                                "last_error": str(exc),
                            },
                            conn=conn,
                        )
                    )
                except Exception as archive_exc:
                    db.session.rollback()
                    failing_exc = _combine_followup_error(exc, "archive metadata update failed", archive_exc)
            jobs_store.update_job_state_with_summary(
                job_id,
                scope_key=scope_key,
                state="failed",
                snapshot_id=None,
                error_code="DB_OPS_SNAPSHOT_COMPACT_ERROR",
                owner_id=None,
                lease_expires_at=None,
                summary=build_failed_summary(
                    req=req,
                    compacted_rows=compacted_rows,
                    history_compacted_rows=history_compacted_rows,
                    archive_id=archive_id if archive_created else None,
                    archive_persisted=bool(archive_created or compact_metrics.get("archive_persisted")),
                    archived_rows=int(archived_rows or 0),
                    compact_metrics=compact_metrics,
                    table_stats=table_stats,
                    duration_ms=int((time.perf_counter() - started) * 1000),
                    retry_count=retry_count,
                    max_retries=max_retries,
                    failed_stage=stage,
                    last_error=str(failing_exc),
                    error_code="DB_OPS_SNAPSHOT_COMPACT_ERROR",
                    last_error_at=datetime.now(timezone.utc).isoformat(),
                ),
                expected_owner_id=owner,
                expected_states=_RECOVERABLE_OPS_JOB_STATES,
            )
        finally:
            with state["lock"]:
                state["active_archive_request"] = None
                state["inflight"].discard(job_id)


def _submit_ops_job_if_needed(
    job_id: str,
    *,
    app_obj=None,
    scope_key: str | None = None,
) -> bool:
    app = app_obj or current_app._get_current_object()
    resolved_scope = scope_key or request.blueprint
    state = job_state._get_ops_state(app, resolved_scope)
    owner_id = job_state._resolve_ops_instance_id(app)
    with state["lock"]:
        if job_id in state["inflight"]:
            return False
        claimed = jobs_store.claim_job_execution(
            job_id,
            scope_key=resolved_scope,
            owner_id=owner_id,
            lease_seconds=job_state._ops_job_lease_seconds(app),
        )
        if claimed is None:
            return False
        state["inflight"].add(job_id)
    try:
        state["executor"].submit(_run_snapshot_and_compact_job, app, job_id, resolved_scope, owner_id)
    except Exception as exc:
        with state["lock"]:
            state["inflight"].discard(job_id)
        _mark_ops_job_failed(
            job_id,
            scope_key=resolved_scope,
            error_code="DB_OPS_SUBMIT_FAILED",
            failed_stage="submit",
            last_error=str(exc),
        )
        raise
    return True


def _mark_ops_job_failed(
    job_id: str,
    *,
    scope_key: str | None = None,
    error_code: str,
    failed_stage: str,
    last_error: str,
    expected_owner_id: str | None | object = _UNSET_EXPECTATION,
    expected_states: tuple[str, ...] | None = None,
    expected_lease_expires_at: datetime | None | object = _UNSET_EXPECTATION,
) -> bool:
    update_kwargs: dict[str, Any] = {
        "scope_key": scope_key,
        "state": "failed",
        "snapshot_id": None,
        "error_code": error_code,
        "owner_id": None,
        "lease_expires_at": None,
        "summary": {
            "error_code": error_code,
            "failed_stage": failed_stage,
            "last_error": last_error,
            "last_error_at": datetime.now(timezone.utc).isoformat(),
        },
    }
    if expected_owner_id is not _UNSET_EXPECTATION:
        update_kwargs["expected_owner_id"] = expected_owner_id
    if expected_states is not None:
        update_kwargs["expected_states"] = expected_states
    if expected_lease_expires_at is not _UNSET_EXPECTATION:
        update_kwargs["expected_lease_expires_at"] = expected_lease_expires_at
    failed = jobs_store.update_job_state_with_summary(job_id, **update_kwargs)
    return failed is not None
