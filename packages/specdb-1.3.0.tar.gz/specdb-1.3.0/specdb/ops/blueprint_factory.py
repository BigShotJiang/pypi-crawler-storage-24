"""Blueprint factory and route registration helpers."""

from __future__ import annotations

from typing import Any, Callable

from flask import Blueprint, Response, jsonify, request

from specdb.db_executor import success_payload
from specdb.ops.openapi import _build_openapi_spec, _to_yaml
from specdb.ops_security import validate_ops_blueprint_security


def _register_db_blueprint_routes(
    bp: Blueprint,
    *,
    url_prefix: str,
    enable_ops_routes: bool,
    enable_templates_routes: bool,
    enable_restore_routes: bool,
    execute_table_view,
    execute_data_view,
    list_db_templates_view,
    get_db_template_view,
    get_db_template_define_spec_view,
    get_db_template_rules_view,
    snapshot_and_compact_view,
    get_ops_job_view,
    retry_ops_job_view,
    list_change_logs_view,
    get_restore_audits_view,
    cleanup_restore_audits_view,
    restore_from_logs_view,
) -> None:
    def _openapi():
        return jsonify(
            success_payload(
                _build_openapi_spec(
                    url_prefix=url_prefix,
                    enable_ops_routes=enable_ops_routes,
                    enable_templates_routes=enable_templates_routes,
                    enable_restore_routes=enable_restore_routes,
                )
            )
        )

    def _openapi_yaml():
        spec = _build_openapi_spec(
            url_prefix=url_prefix,
            enable_ops_routes=enable_ops_routes,
            enable_templates_routes=enable_templates_routes,
            enable_restore_routes=enable_restore_routes,
        )
        content = _to_yaml(spec) + "\n"
        return Response(content, mimetype="application/yaml; charset=utf-8")

    bp.add_url_rule("/openapi", view_func=_openapi, methods=["GET"])
    bp.add_url_rule("/openapi.yaml", view_func=_openapi_yaml, methods=["GET"])
    bp.add_url_rule("/table", view_func=execute_table_view, methods=["POST"])
    bp.add_url_rule("/data", view_func=execute_data_view, methods=["POST"])
    if enable_templates_routes:
        bp.add_url_rule("/templates", view_func=list_db_templates_view, methods=["GET"])
        bp.add_url_rule("/templates/<template_key>", view_func=get_db_template_view, methods=["GET"])
        bp.add_url_rule("/templates/<template_key>/define-spec", view_func=get_db_template_define_spec_view, methods=["GET"])
        bp.add_url_rule("/templates/<template_key>/rules", view_func=get_db_template_rules_view, methods=["GET"])
    if enable_ops_routes:
        bp.add_url_rule("/ops/snapshot-and-compact", view_func=snapshot_and_compact_view, methods=["POST"])
        bp.add_url_rule("/ops/jobs/<job_id>", view_func=get_ops_job_view, methods=["GET"])
        bp.add_url_rule("/ops/jobs/<job_id>/retry", view_func=retry_ops_job_view, methods=["POST"])
        bp.add_url_rule("/ops/change-logs", view_func=list_change_logs_view, methods=["GET"])
        if enable_restore_routes:
            bp.add_url_rule("/ops/restore-audits", view_func=get_restore_audits_view, methods=["GET"])
            bp.add_url_rule("/ops/restore-audits/cleanup", view_func=cleanup_restore_audits_view, methods=["POST"])
            bp.add_url_rule("/ops/restore-from-logs", view_func=restore_from_logs_view, methods=["POST"])


def create_db_blueprint(
    *,
    name: str,
    module_name: str,
    url_prefix: str,
    ops_auth_callback: Callable[[Any], Any] | None,
    enable_ops_routes: bool,
    enable_templates_routes: bool,
    enable_restore_routes: bool,
    before_request_impl,
    register_ops_auth_callback_fn,
    get_app_db_module_extension_fn,
    recover_incomplete_jobs_for_scope_fn,
    execute_table_view,
    execute_data_view,
    list_db_templates_view,
    get_db_template_view,
    get_db_template_define_spec_view,
    get_db_template_rules_view,
    snapshot_and_compact_view,
    get_ops_job_view,
    retry_ops_job_view,
    list_change_logs_view,
    get_restore_audits_view,
    cleanup_restore_audits_view,
    restore_from_logs_view,
) -> Blueprint:
    bp = Blueprint(name, module_name, url_prefix=url_prefix)

    @bp.before_request
    def _before_request_for_factory():
        return before_request_impl(request.blueprint)

    @bp.record_once
    def _on_register(state):
        validate_ops_blueprint_security(
            state.app,
            enable_ops_routes=enable_ops_routes,
            ops_auth_callback=ops_auth_callback,
        )
        register_ops_auth_callback_fn(ops_auth_callback, app_obj=state.app, scope_key=name)
        ext = get_app_db_module_extension_fn(state.app)
        ext["blueprint_options"][name] = {
            "url_prefix": url_prefix,
            "enable_ops_routes": enable_ops_routes,
            "enable_templates_routes": enable_templates_routes,
            "enable_restore_routes": enable_restore_routes,
        }
        recover_incomplete_jobs_for_scope_fn(state.app, name)

    _register_db_blueprint_routes(
        bp,
        url_prefix=url_prefix,
        enable_ops_routes=enable_ops_routes,
        enable_templates_routes=enable_templates_routes,
        enable_restore_routes=enable_restore_routes,
        execute_table_view=execute_table_view,
        execute_data_view=execute_data_view,
        list_db_templates_view=list_db_templates_view,
        get_db_template_view=get_db_template_view,
        get_db_template_define_spec_view=get_db_template_define_spec_view,
        get_db_template_rules_view=get_db_template_rules_view,
        snapshot_and_compact_view=snapshot_and_compact_view,
        get_ops_job_view=get_ops_job_view,
        retry_ops_job_view=retry_ops_job_view,
        list_change_logs_view=list_change_logs_view,
        get_restore_audits_view=get_restore_audits_view,
        cleanup_restore_audits_view=cleanup_restore_audits_view,
        restore_from_logs_view=restore_from_logs_view,
    )
    return bp
