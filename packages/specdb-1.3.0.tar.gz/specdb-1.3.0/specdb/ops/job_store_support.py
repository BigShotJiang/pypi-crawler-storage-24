"""Shared helpers for db ops job-store serialization and identity logic."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from specdb.ops.store_common import (
    _decode_json_object_strict,
    _normalize_datetime_value,
    _normalize_ops_context,
    _parse_datetime_value,
)

_INTERNAL_REQUEST_KEYS = frozenset({"_scope_key"})
_DEFAULT_SCOPE_KEY = "db"


def serialize_request_payload(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def normalize_scope_key(scope_key: str | None) -> str | None:
    if not isinstance(scope_key, str):
        return None
    normalized = scope_key.strip()
    if not normalized:
        return None
    return normalized[:128]


def scope_key_matches(row_scope: Any, scope_key: str | None) -> bool:
    normalized_scope = normalize_scope_key(scope_key)
    if normalized_scope is None:
        return True
    normalized_row_scope = normalize_scope_key(row_scope) if isinstance(row_scope, str) else None
    if normalized_row_scope == normalized_scope:
        return True
    return normalized_row_scope is None and normalized_scope == _DEFAULT_SCOPE_KEY


def sanitize_request_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if key not in _INTERNAL_REQUEST_KEYS}


def deserialize_request_payload(
    request_json: str,
    *,
    include_internal: bool,
    entity_id: Any = None,
) -> dict[str, Any]:
    payload = _decode_json_object_strict(
        request_json,
        field_name="request_json",
        entity_name="job",
        entity_id=entity_id,
    )
    if include_internal:
        return payload
    return sanitize_request_payload(payload)


def row_identity_from_request_json(
    request_json: Any,
    *,
    fallback_job_id: Any,
) -> tuple[str | None, str | None]:
    payload = (
        deserialize_request_payload(request_json, include_internal=True, entity_id=fallback_job_id)
        if isinstance(request_json, str)
        else None
    )
    public_job_id = payload.get("request_id") if isinstance(payload, dict) else None
    if not isinstance(public_job_id, str) or not public_job_id.strip():
        public_job_id = fallback_job_id if isinstance(fallback_job_id, str) and fallback_job_id.strip() else None
    scope_key = payload.get("_scope_key") if isinstance(payload, dict) else None
    return public_job_id, normalize_scope_key(scope_key)


def request_scope_matches(request_json: str, scope_key: str | None) -> bool:
    if scope_key is None:
        return True
    _, row_scope = row_identity_from_request_json(request_json, fallback_job_id=None)
    return scope_key_matches(row_scope, scope_key)


def is_claimable_row(row: dict[str, Any], *, now: datetime | None = None) -> bool:
    current = now or datetime.now(timezone.utc)
    owner_id = row.get("owner_id")
    lease_expires_at = _parse_datetime_value(row.get("lease_expires_at"))
    if not isinstance(owner_id, str) or not owner_id.strip():
        return True
    if lease_expires_at is None:
        return True
    return lease_expires_at <= current


def public_job_id_from_row(row: dict[str, Any]) -> str | None:
    public_job_id = row.get("public_job_id")
    if isinstance(public_job_id, str) and public_job_id.strip():
        return public_job_id
    parsed_public_job_id, _ = row_identity_from_request_json(row.get("request_json"), fallback_job_id=row.get("job_id"))
    if isinstance(parsed_public_job_id, str) and parsed_public_job_id.strip():
        return parsed_public_job_id
    return None


def serialize_row(row: dict[str, Any]) -> dict[str, Any]:
    data = dict(row)
    public_job_id = public_job_id_from_row(data)
    if isinstance(public_job_id, str) and public_job_id.strip():
        data["job_id"] = public_job_id
    data.pop("public_job_id", None)
    data.pop("scope_key", None)
    data.pop("owner_id", None)
    data.pop("lease_expires_at", None)
    for key in ("created_at", "updated_at"):
        data[key] = _normalize_datetime_value(data.get(key))
    request_json = data.get("request_json")
    if isinstance(request_json, str):
        data["request"] = deserialize_request_payload(
            request_json,
            include_internal=False,
            entity_id=data.get("job_id"),
        )
        data.pop("request_json", None)
    return data


def summary_context_from_row(
    row: dict[str, Any],
    *,
    scope_key: str | None = None,
    fallback_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    request_payload = (
        deserialize_request_payload(
            row.get("request_json"),
            include_internal=True,
            entity_id=row.get("job_id"),
        )
        if isinstance(row.get("request_json"), str)
        else {}
    )
    archive_payload = request_payload.get("archive") if isinstance(request_payload.get("archive"), dict) else {}
    fallback_summary = fallback_summary if isinstance(fallback_summary, dict) else {}
    return _normalize_ops_context(
        scope_key=normalize_scope_key(row.get("scope_key")) or normalize_scope_key(scope_key),
        dry_run=fallback_summary.get("dry_run", request_payload.get("dry_run", False)),
        operator=fallback_summary.get("operator", request_payload.get("operator")),
        node=fallback_summary.get("node", request_payload.get("node")),
        request_id=request_payload.get("request_id") or public_job_id_from_row(row),
        targets=request_payload.get("targets"),
        archive_enabled=fallback_summary.get("archive_enabled", archive_payload.get("enabled")),
        archive_mode=fallback_summary.get("archive_mode", archive_payload.get("mode")),
    )


def normalize_job_summary(summary: dict[str, Any], row: dict[str, Any], *, scope_key: str | None = None) -> dict[str, Any]:
    normalized = dict(summary)
    merged_context = summary_context_from_row(row, scope_key=scope_key, fallback_summary=normalized)
    existing_context = normalized.get("context")
    if isinstance(existing_context, dict):
        merged_context.update({key: value for key, value in existing_context.items() if value is not None})
    normalized["context"] = merged_context
    return normalized


def build_storage_job_id(public_job_id: str, scope_key: str | None) -> str:
    normalized_scope = normalize_scope_key(scope_key) or ""
    digest = hashlib.sha1(f"{normalized_scope}\0{public_job_id}".encode("utf-8")).hexdigest()
    return f"job_{digest}"
