"""Restore and change-log route handlers."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import re
from typing import Any, Callable

from flask import current_app, jsonify, request
from sqlalchemy import inspect
from sqlalchemy.exc import NoSuchTableError

from specdb.db_executor import error_payload, success_payload
from specdb.db_runtime import db
from specdb.executor.relationship_metadata import summarize_table_relationships
from specdb.ops.request_validation import (
    _parse_bool,
    _parse_int_arg,
    _parse_iso_datetime,
    _validate_table_name,
    _validate_time_window,
)
from specdb.ops.restore_runtime import build_restore_selector, execute_restore_logs
from specdb.ops.restore_support import (
    _load_runtime_table,
    _serialize_ops_log_row,
)
from specdb.ops_restore_audit_store import cleanup_restore_audits, insert_restore_audit, list_restore_audits

_VALID_BATCH_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,128}$")


def list_change_logs_response(ops_error: Callable[..., Any]):
    table_name, err = _validate_table_name(request.args.get("table"))
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    limit, err = _parse_int_arg(request.args.get("limit"), "limit", 100, min_value=1, max_value=500)
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    offset, err = _parse_int_arg(request.args.get("offset"), "offset", 0, min_value=0, max_value=1_000_000)
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    op = request.args.get("op")
    if op is not None and op not in {"insert", "update", "delete"}:
        return ops_error("DB_OPS_REQUEST_INVALID", "op must be one of insert|update|delete", 400)

    sql = """
        SELECT id, batch_id, table_name, op, row_key_json, before_json, after_json, query_json, changed_at
        FROM db_change_log
        WHERE table_name = :table_name
    """
    params: dict[str, Any] = {"table_name": table_name, "limit": limit, "offset": offset}
    if op is not None:
        sql += " AND op = :op"
        params["op"] = op
    sql += " ORDER BY id DESC LIMIT :limit OFFSET :offset"

    try:
        rows = db.session.execute(db.text(sql), params).mappings().all()
    except Exception as exc:
        return ops_error("DB_OPS_QUERY_FAILED", "query change logs failed", 500, {"error": str(exc)})

    items = [_serialize_ops_log_row(dict(row)) for row in rows]
    return jsonify(success_payload({"items": items, "limit": limit, "offset": offset}))


def get_restore_audits_response(ops_error: Callable[..., Any], to_db_naive_utc: Callable[[datetime], datetime]):
    table_name = request.args.get("table")
    if table_name is not None:
        table_name, err = _validate_table_name(table_name)
        if err is not None:
            return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    operator = request.args.get("operator")
    node = request.args.get("node")
    dry_run_raw = request.args.get("dry_run")
    if dry_run_raw is None:
        dry_run = None
    elif dry_run_raw.lower() in {"true", "1"}:
        dry_run = True
    elif dry_run_raw.lower() in {"false", "0"}:
        dry_run = False
    else:
        return ops_error("DB_OPS_REQUEST_INVALID", "query arg 'dry_run' must be true|false", 400)

    from_created_at, err = _parse_iso_datetime(request.args.get("from_created_at"), "from_created_at")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    to_created_at, err = _parse_iso_datetime(request.args.get("to_created_at"), "to_created_at")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    if (from_created_at is None) != (to_created_at is None):
        return ops_error("DB_OPS_REQUEST_INVALID", "both from_created_at and to_created_at are required together", 400)
    err = _validate_time_window(
        from_created_at,
        to_created_at,
        start_field="from_created_at",
        end_field="to_created_at",
    )
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    limit, err = _parse_int_arg(request.args.get("limit"), "limit", 100, min_value=1, max_value=500)
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    offset, err = _parse_int_arg(request.args.get("offset"), "offset", 0, min_value=0, max_value=1_000_000)
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    try:
        items = list_restore_audits(
            table_name=table_name,
            operator=operator,
            node=node,
            dry_run=dry_run,
            from_created_at=to_db_naive_utc(from_created_at) if from_created_at is not None else None,
            to_created_at=to_db_naive_utc(to_created_at) if to_created_at is not None else None,
            limit=limit,
            offset=offset,
        )
    except Exception as exc:
        return ops_error("DB_OPS_QUERY_FAILED", "query restore audits failed", 500, {"error": str(exc)})
    return jsonify(success_payload({"items": items, "limit": limit, "offset": offset}))


def cleanup_restore_audits_response(ops_error: Callable[..., Any]):
    body = request.get_json(silent=True)
    if body is None:
        body = {}
    if not isinstance(body, dict):
        return ops_error("DB_OPS_REQUEST_INVALID", "request body must be a JSON object", 400)
    dry_run, err = _parse_bool(body.get("dry_run"), "dry_run")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    retention_days = body.get("retention_days")
    if retention_days is None:
        retention_days = int(current_app.config.get("OPS_RESTORE_AUDIT_RETENTION_DAYS", 180) or 180)
    if not isinstance(retention_days, int) or retention_days <= 0:
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'retention_days' must be positive integer", 400)

    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=retention_days)
    try:
        affected = cleanup_restore_audits(older_than=cutoff, dry_run=dry_run)
    except Exception as exc:
        return ops_error("DB_OPS_QUERY_FAILED", "cleanup restore audits failed", 500, {"error": str(exc)})
    return jsonify(
        success_payload(
            {
                "dry_run": dry_run,
                "retention_days": retention_days,
                "cutoff": cutoff.replace(tzinfo=timezone.utc).isoformat(),
                "affected_rows": affected,
            }
        )
    )


def restore_from_logs_response(
    ops_error: Callable[..., Any],
    to_db_naive_utc: Callable[[datetime], datetime],
    *,
    max_restore_preview_items: int,
):
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return ops_error("DB_OPS_REQUEST_INVALID", "request body must be a JSON object", 400)

    table_name, err = _validate_table_name(body.get("table"))
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    dry_run, err = _parse_bool(body.get("dry_run"), "dry_run")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    preview_details, err = _parse_bool(body.get("preview_details"), "preview_details")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    max_restore_rows = body.get("max_restore_rows", 1000)
    if not isinstance(max_restore_rows, int) or max_restore_rows <= 0 or max_restore_rows > 100000:
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'max_restore_rows' must be integer in [1, 100000]", 400)
    operator = body.get("operator")
    if operator is not None and (not isinstance(operator, str) or not operator.strip()):
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'operator' must be non-empty string", 400)
    node = body.get("node")
    if node is not None and (not isinstance(node, str) or not node.strip()):
        return ops_error("DB_OPS_REQUEST_INVALID", "field 'node' must be non-empty string", 400)

    log_ids = body.get("log_ids")
    batch_id = body.get("batch_id")
    from_changed_at, err = _parse_iso_datetime(body.get("from_changed_at"), "from_changed_at")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)
    to_changed_at, err = _parse_iso_datetime(body.get("to_changed_at"), "to_changed_at")
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    selectors = 0
    if log_ids is not None:
        selectors += 1
    if batch_id is not None:
        selectors += 1
    if from_changed_at is not None or to_changed_at is not None:
        selectors += 1
    if selectors != 1:
        return ops_error(
            "DB_OPS_REQUEST_INVALID",
            "exactly one selector is required: log_ids | batch_id | from_changed_at/to_changed_at",
            400,
        )

    if log_ids is not None:
        if not isinstance(log_ids, list) or not log_ids:
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'log_ids' must be a non-empty integer list", 400)
        if len(log_ids) > 1000:
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'log_ids' supports at most 1000 items", 400)
        if not all(isinstance(item, int) and item > 0 for item in log_ids):
            return ops_error("DB_OPS_REQUEST_INVALID", "log_ids must contain positive integers only", 400)

    if batch_id is not None:
        if not isinstance(batch_id, str) or not batch_id.strip():
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'batch_id' must be non-empty string", 400)
        batch_id = batch_id.strip()
        if not _VALID_BATCH_ID_RE.fullmatch(batch_id):
            return ops_error("DB_OPS_REQUEST_INVALID", "field 'batch_id' must match [A-Za-z0-9_-] and be at most 128 chars", 400)

    if (from_changed_at is None) != (to_changed_at is None):
        return ops_error("DB_OPS_REQUEST_INVALID", "both from_changed_at and to_changed_at are required together", 400)
    err = _validate_time_window(
        from_changed_at,
        to_changed_at,
        start_field="from_changed_at",
        end_field="to_changed_at",
    )
    if err is not None:
        return ops_error("DB_OPS_REQUEST_INVALID", err["error"]["message"], 400)

    try:
        table = _load_runtime_table(table_name)
    except NoSuchTableError as exc:
        return ops_error("DB_OPS_NOT_FOUND", f"table not found: {table_name}", 404, {"error": str(exc)})
    except Exception as exc:
        return ops_error("DB_OPS_QUERY_FAILED", "load runtime table failed", 500, {"error": str(exc), "table": table_name})
    if not any(True for _ in table.primary_key.columns):
        return ops_error("DB_OPS_REQUEST_INVALID", "restore-from-logs requires table with primary key", 400)
    if not inspect(db.engine).has_table("db_change_log"):
        return ops_error("DB_OPS_NOT_FOUND", "change log table not found", 404, {"table": "db_change_log"})
    selector_payload, params, sql = build_restore_selector(
        table_name=table_name,
        log_ids=log_ids,
        batch_id=batch_id,
        from_changed_at=from_changed_at,
        to_changed_at=to_changed_at,
        to_db_naive_utc=to_db_naive_utc,
        max_restore_rows=max_restore_rows,
    )

    session = db.session
    try:
        relationship_risks = summarize_table_relationships(table_name)
        logs = session.execute(db.text(sql), params).mappings().all()
        if len(logs) > max_restore_rows:
            session.rollback()
            return ops_error(
                "DB_OPS_REQUEST_INVALID",
                "restore size exceeds max_restore_rows",
                400,
                {"selected_logs": len(logs), "max_restore_rows": max_restore_rows},
            )
        restore_result = execute_restore_logs(
            session=session,
            table=table,
            logs=[dict(item) for item in logs],
            dry_run=dry_run,
            preview_details=preview_details,
            max_restore_preview_items=max_restore_preview_items,
        )
        restored = restore_result["restored"]
        preview_items = restore_result["preview_items"]
        preview_truncated = restore_result["preview_truncated"]
        if dry_run:
            session.rollback()
        else:
            insert_restore_audit(
                table_name=table_name,
                selector=selector_payload,
                restored_logs=restored,
                requested_logs=len(logs),
                dry_run=dry_run,
                operator=operator,
                node=node,
                scope_key=request.blueprint,
                relationship_risks=relationship_risks,
                conn=session,
            )
            session.commit()
    except Exception as exc:
        session.rollback()
        return jsonify(error_payload("DB_OPS_RESTORE_FAILED", "restore from logs failed", {"error": str(exc)})), 500

    if dry_run:
        try:
            insert_restore_audit(
                table_name=table_name,
                selector=selector_payload,
                restored_logs=restored,
                requested_logs=len(logs),
                dry_run=dry_run,
                operator=operator,
                node=node,
                scope_key=request.blueprint,
                relationship_risks=relationship_risks,
            )
        except Exception as exc:
            return jsonify(error_payload("DB_OPS_RESTORE_FAILED", "restore from logs failed", {"error": str(exc)})), 500

    response_data = {
        "table": table_name,
        "restored_logs": restored,
        "requested_logs": len(logs),
        "dry_run": dry_run,
        "max_restore_rows": max_restore_rows,
        "relationship_risks": relationship_risks,
        "audit_context": {
            "scope_key": request.blueprint,
            "dry_run": dry_run,
            "operator": operator,
            "node": node,
        },
    }
    if preview_details:
        response_data["preview"] = preview_items
        response_data["preview_truncated"] = preview_truncated
        response_data["preview_limit"] = max_restore_preview_items

    return jsonify(success_payload(response_data))
