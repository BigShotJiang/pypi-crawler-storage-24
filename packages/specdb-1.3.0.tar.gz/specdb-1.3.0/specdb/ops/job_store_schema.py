"""Schema and backfill helpers for the db ops job store."""

from __future__ import annotations

from typing import Any

from sqlalchemy import DateTime, String, inspect, select, text


def _quote_identifier(engine: Any, identifier: str) -> str:
    return engine.dialect.identifier_preparer.quote_identifier(identifier)


def ensure_optional_job_columns(
    engine: Any,
    *,
    jobs_table: Any,
    required_job_columns: frozenset[str],
) -> None:
    inspector = inspect(engine)
    column_names = {str(item.get("name")) for item in inspector.get_columns(jobs_table.name)}
    missing_columns = [column for column in required_job_columns if column not in column_names]
    if not missing_columns:
        return

    table_name = _quote_identifier(engine, jobs_table.name)
    statements: list[str] = []
    if "public_job_id" in missing_columns:
        public_job_id_type = String(128).compile(dialect=engine.dialect)
        statements.append(
            f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'public_job_id')} {public_job_id_type}"
        )
    if "scope_key" in missing_columns:
        scope_key_type = String(128).compile(dialect=engine.dialect)
        statements.append(f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'scope_key')} {scope_key_type}")
    if "owner_id" in missing_columns:
        owner_type = String(128).compile(dialect=engine.dialect)
        statements.append(f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'owner_id')} {owner_type}")
    if "lease_expires_at" in missing_columns:
        lease_type = DateTime(timezone=True).compile(dialect=engine.dialect)
        statements.append(
            f"ALTER TABLE {table_name} ADD COLUMN {_quote_identifier(engine, 'lease_expires_at')} {lease_type}"
        )
    with engine.begin() as conn:
        for statement in statements:
            conn.execute(text(statement))


def backfill_job_identity_columns(
    engine: Any,
    *,
    jobs_table: Any,
    row_identity_from_request_json: Any,
    normalize_scope_key: Any,
) -> None:
    with engine.begin() as conn:
        rows = conn.execute(
            select(
                jobs_table.c.job_id,
                jobs_table.c.public_job_id,
                jobs_table.c.scope_key,
                jobs_table.c.request_json,
            )
        ).mappings().all()
        for row in rows:
            fallback_public_job_id, fallback_scope_key = row_identity_from_request_json(
                row.get("request_json"),
                fallback_job_id=row.get("job_id"),
            )
            if not isinstance(fallback_public_job_id, str) or not fallback_public_job_id.strip():
                continue
            values: dict[str, Any] = {}
            current_public_job_id = row.get("public_job_id")
            if not isinstance(current_public_job_id, str) or not current_public_job_id.strip():
                values["public_job_id"] = fallback_public_job_id
            current_scope_key = normalize_scope_key(row.get("scope_key")) if row.get("scope_key") is not None else None
            if current_scope_key is None and fallback_scope_key is not None:
                values["scope_key"] = fallback_scope_key
            if values:
                conn.execute(
                    jobs_table.update()
                    .where(jobs_table.c.job_id == row["job_id"])
                    .values(**values)
                )
