"""Compact execution engine for ops jobs."""

from __future__ import annotations

import time
from typing import Any, Callable

from flask import current_app
from sqlalchemy import and_, asc, bindparam, inspect, select

from specdb.db_executor import list_table_tracking_strategies
from specdb.db_runtime import db
from specdb.executor.internal_tables import _CHANGE_LOG
import specdb.ops_archive_store as archive_store
import specdb.ops_jobs_store as jobs_store
import specdb.ops.job_state as job_state
from specdb.ops.jobs_support import _CompactExecutionError, _merge_table_stat
from specdb.ops.restore_support import _load_runtime_table


def _execute_compact_once(
    *,
    dry_run: bool,
    targets: list[str],
    compact_before_dt: Any,
    batch_size: int,
    scope_key: str | None = None,
    heartbeat: Callable[[], None] | None = None,
) -> tuple[int, int, list[dict[str, Any]], dict[str, Any]]:
    compacted_rows = 0
    history_compacted_rows = 0
    merged_table_stats: dict[str, dict[str, Any]] = {}
    actual_table_stats: dict[str, dict[str, Any]] = {}
    if batch_size <= 0:
        batch_size = 5000
    compact_metrics: dict[str, Any] = {
        "batch_size": int(batch_size),
        "batches": 0,
        "deleted_rows": 0,
        "avg_batch_ms": 0,
        "max_batch_ms": 0,
        "log_batches": 0,
        "history_batches": 0,
        "log_deleted_rows": 0,
        "history_deleted_rows": 0,
        "archive_persisted": False,
    }
    archive_rows = 0
    archive_id: str | None = None
    archive_mode: str | None = None
    archive_enabled = False
    archive_persisted = False
    archive_request_id: str | None = None
    archive_snapshot_id: str | None = None
    archive_targets: list[str] = []
    archive_compact_before: str | None = None
    archive_dry_run = dry_run
    guard_job_id: str | None = None
    guard_owner_id: str | None = None
    archive_state = job_state._get_ops_state(current_app, scope_key)
    with archive_state["lock"]:
        active_archive_request = archive_state.get("active_archive_request")
        archive_request = dict(active_archive_request) if isinstance(active_archive_request, dict) else None
    if isinstance(archive_request, dict):
        archive_enabled = bool(archive_request.get("enabled")) and not dry_run
        archive_id = archive_request.get("archive_id")
        archive_mode = archive_request.get("mode", "internal")
        archive_persisted = bool(archive_request.get("archive_persisted"))
        archive_request_id = archive_request.get("request_id")
        archive_snapshot_id = archive_request.get("snapshot_id")
        archive_targets = (
            list(archive_request.get("targets", []))
            if isinstance(archive_request.get("targets"), list)
            else list(targets)
        )
        archive_compact_before = archive_request.get("compact_before")
        archive_dry_run = bool(archive_request.get("dry_run", dry_run))
        guard_job_id = archive_request.get("job_id")
        guard_owner_id = archive_request.get("owner_id")

    def _pulse() -> None:
        if heartbeat is not None:
            heartbeat()

    def _fetch_change_log_batch(after_id: int) -> list[dict[str, Any]]:
        stmt = (
            select(
                _CHANGE_LOG.c.id,
                _CHANGE_LOG.c.batch_id,
                _CHANGE_LOG.c.table_name,
                _CHANGE_LOG.c.op,
                _CHANGE_LOG.c.row_key_json,
                _CHANGE_LOG.c.before_json,
                _CHANGE_LOG.c.after_json,
                _CHANGE_LOG.c.query_json,
                _CHANGE_LOG.c.changed_at,
            )
            .where(_CHANGE_LOG.c.id > int(after_id))
            .order_by(asc(_CHANGE_LOG.c.id))
            .limit(int(batch_size))
        )
        if targets:
            stmt = stmt.where(_CHANGE_LOG.c.table_name.in_(targets))
        if compact_before_dt is not None:
            stmt = stmt.where(_CHANGE_LOG.c.changed_at < compact_before_dt)
        with db.engine.connect() as conn:
            return [dict(row) for row in conn.execute(stmt).mappings().all()]

    def _fetch_append_history_batch(table: Any, after_row_id: int) -> list[dict[str, Any]]:
        filters = [table.c["__wt_is_current"].is_(False)]
        if compact_before_dt is not None:
            filters.append(table.c["__wt_changed_at"] < compact_before_dt)
        stmt = (
            select(table)
            .where(and_(*(filters + [table.c["__wt_row_id"] > bindparam("after_row_id")])))
            .order_by(asc(table.c["__wt_row_id"]))
            .limit(batch_size)
        )
        with db.engine.connect() as conn:
            return [dict(row) for row in conn.execute(stmt, {"after_row_id": int(after_row_id)}).mappings().all()]

    def _guard_mutation(session_conn: Any) -> None:
        if not isinstance(guard_job_id, str) or not guard_job_id:
            raise RuntimeError("ops job lease context missing")
        if not isinstance(guard_owner_id, str) or not guard_owner_id:
            raise RuntimeError("ops job owner missing")
        if not jobs_store.renew_job_lease(
            guard_job_id,
            scope_key=scope_key,
            owner_id=guard_owner_id,
            lease_seconds=job_state._ops_job_lease_seconds(current_app),
            conn=session_conn,
            require_unexpired=True,
        ):
            raise RuntimeError(f"ops job lease lost: {guard_job_id}")

    total_batch_ms = 0.0
    try:
        _pulse()
        if inspect(db.engine).has_table("db_change_log"):
            delete_stmt = _CHANGE_LOG.delete().where(_CHANGE_LOG.c.id.in_(bindparam("ids", expanding=True)))
            after_id = 0
            while True:
                _pulse()
                batch_rows = _fetch_change_log_batch(after_id)
                if not batch_rows:
                    break
                batch_grouped: dict[str, int] = {}
                for row in batch_rows:
                    table_name = str(row["table_name"])
                    batch_grouped[table_name] = int(batch_grouped.get(table_name, 0)) + 1
                compacted_rows += len(batch_rows)
                for table_name, count in batch_grouped.items():
                    _merge_table_stat(merged_table_stats, table_name, log_rows=count)
                after_id = int(batch_rows[-1]["id"])
                if dry_run:
                    continue
                batch_started = time.perf_counter()
                session_conn = db.session.connection()
                _guard_mutation(session_conn)
                if archive_enabled and archive_id is not None and not archive_persisted:
                    archive_store.create_archive(
                        archive_id,
                        job_id=guard_job_id,
                        request_id=str(archive_request_id or guard_job_id),
                        snapshot_id=archive_snapshot_id,
                        metadata={
                            "mode": archive_mode or "internal",
                            "targets": archive_targets,
                            "compact_before": archive_compact_before,
                            "dry_run": archive_dry_run,
                        },
                        conn=session_conn,
                    )
                    archive_persisted = True
                if archive_enabled and archive_id is not None:
                    archive_rows += archive_store.append_archive_items(
                        archive_id,
                        [
                            {
                                "category": "change_log",
                                "table_name": str(row["table_name"]),
                                "payload": dict(row),
                            }
                            for row in batch_rows
                        ],
                        conn=session_conn,
                    )
                db.session.execute(delete_stmt, {"ids": [int(row["id"]) for row in batch_rows]})
                db.session.commit()
                _pulse()
                for table_name, count in batch_grouped.items():
                    _merge_table_stat(actual_table_stats, table_name, log_rows=count)
                batch_ms = int((time.perf_counter() - batch_started) * 1000)
                compact_metrics["batches"] = int(compact_metrics["batches"]) + 1
                compact_metrics["log_batches"] = int(compact_metrics["log_batches"]) + 1
                compact_metrics["deleted_rows"] = int(compact_metrics["deleted_rows"]) + len(batch_rows)
                compact_metrics["log_deleted_rows"] = int(compact_metrics["log_deleted_rows"]) + len(batch_rows)
                compact_metrics["max_batch_ms"] = max(int(compact_metrics["max_batch_ms"]), batch_ms)
                total_batch_ms += batch_ms
        inspector = inspect(db.engine)
        table_strategies = list_table_tracking_strategies(targets if targets else None)
        append_tables = [
            table_name
            for table_name, strategy in sorted(table_strategies.items())
            if strategy == "append_only_versioned" and inspector.has_table(table_name)
        ]
        for table_name in append_tables:
            table = _load_runtime_table(table_name)
            delete_stmt = table.delete().where(table.c["__wt_row_id"].in_(bindparam("row_ids", expanding=True)))
            after_row_id = 0
            while True:
                _pulse()
                batch_rows = _fetch_append_history_batch(table, after_row_id)
                if not batch_rows:
                    break
                batch_count = len(batch_rows)
                history_compacted_rows += batch_count
                _merge_table_stat(merged_table_stats, table_name, history_rows=batch_count)
                after_row_id = int(batch_rows[-1]["__wt_row_id"])
                if dry_run:
                    continue
                batch_started = time.perf_counter()
                session_conn = db.session.connection()
                _guard_mutation(session_conn)
                if archive_enabled and archive_id is not None and not archive_persisted:
                    archive_store.create_archive(
                        archive_id,
                        job_id=guard_job_id,
                        request_id=str(archive_request_id or guard_job_id),
                        snapshot_id=archive_snapshot_id,
                        metadata={
                            "mode": archive_mode or "internal",
                            "targets": archive_targets,
                            "compact_before": archive_compact_before,
                            "dry_run": archive_dry_run,
                        },
                        conn=session_conn,
                    )
                    archive_persisted = True
                if archive_enabled and archive_id is not None:
                    archive_rows += archive_store.append_archive_items(
                        archive_id,
                        [
                            {
                                "category": "append_only_history",
                                "table_name": table_name,
                                "payload": row,
                            }
                            for row in batch_rows
                        ],
                        conn=session_conn,
                    )
                db.session.execute(delete_stmt, {"row_ids": [int(row["__wt_row_id"]) for row in batch_rows]})
                db.session.commit()
                _pulse()
                _merge_table_stat(actual_table_stats, table_name, history_rows=batch_count)
                batch_ms = int((time.perf_counter() - batch_started) * 1000)
                compact_metrics["batches"] = int(compact_metrics["batches"]) + 1
                compact_metrics["history_batches"] = int(compact_metrics["history_batches"]) + 1
                compact_metrics["deleted_rows"] = int(compact_metrics["deleted_rows"]) + batch_count
                compact_metrics["history_deleted_rows"] = int(compact_metrics["history_deleted_rows"]) + batch_count
                compact_metrics["max_batch_ms"] = max(int(compact_metrics["max_batch_ms"]), batch_ms)
                total_batch_ms += batch_ms
    except Exception as exc:
        compact_metrics["archive_rows"] = archive_rows
        compact_metrics["archive_persisted"] = archive_persisted
        if archive_mode is not None:
            compact_metrics["archive_mode"] = archive_mode
        raise _CompactExecutionError(
            exc,
            log_rows_compacted=int(compact_metrics.get("log_deleted_rows", 0) or 0),
            history_rows_compacted=int(compact_metrics.get("history_deleted_rows", 0) or 0),
            table_stats=list(actual_table_stats.values()),
            compact_metrics=compact_metrics,
        ) from exc

    if int(compact_metrics["batches"]) > 0:
        compact_metrics["avg_batch_ms"] = int(total_batch_ms / int(compact_metrics["batches"]))
    compact_metrics["archive_rows"] = archive_rows
    compact_metrics["archive_persisted"] = archive_persisted
    if archive_mode is not None:
        compact_metrics["archive_mode"] = archive_mode
    table_stats = list(merged_table_stats.values())
    return compacted_rows, history_compacted_rows, table_stats, compact_metrics
