"""以库方式集成数据库模块时使用的入口。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from flask import Flask, current_app, has_app_context

from specdb.db_executor import ensure_internal_tables
from specdb.db_runtime import init_db
from specdb.ops_db_routes import create_db_blueprint, register_ops_auth_callback, shutdown_ops_executors
from specdb.ops_jobs_store import ensure_ops_jobs_table
from specdb.ops_restore_audit_store import ensure_restore_audit_table
from specdb.ops_security import coerce_config_bool, validate_ops_blueprint_security

_UNSET = object()


def init_db_module_tables() -> None:
    """初始化 DB 模块依赖的全部内部表。"""
    ensure_internal_tables()
    ensure_ops_jobs_table()
    ensure_restore_audit_table()


@dataclass
class DBModuleOptions:
    register_blueprint: bool = True
    init_tables: bool = True
    db_url_prefix: str = "/api/db"
    blueprint_name: str = "db"
    ops_auth_callback: Callable[[Any], Any] | None = None
    enable_ops_routes: bool = True
    enable_templates_routes: bool = True
    enable_restore_routes: bool = True

    def validate(self) -> None:
        if not isinstance(self.register_blueprint, bool):
            raise ValueError("DBModuleOptions.register_blueprint must be bool")
        if not isinstance(self.init_tables, bool):
            raise ValueError("DBModuleOptions.init_tables must be bool")
        if not isinstance(self.db_url_prefix, str) or not self.db_url_prefix.startswith("/"):
            raise ValueError("DBModuleOptions.db_url_prefix must be path-like string starting with '/'")
        if not isinstance(self.blueprint_name, str) or not self.blueprint_name.strip():
            raise ValueError("DBModuleOptions.blueprint_name must be non-empty string")
        if self.ops_auth_callback is not None and not callable(self.ops_auth_callback):
            raise ValueError("DBModuleOptions.ops_auth_callback must be callable or None")
        if not isinstance(self.enable_ops_routes, bool):
            raise ValueError("DBModuleOptions.enable_ops_routes must be bool")
        if not isinstance(self.enable_templates_routes, bool):
            raise ValueError("DBModuleOptions.enable_templates_routes must be bool")
        if not isinstance(self.enable_restore_routes, bool):
            raise ValueError("DBModuleOptions.enable_restore_routes must be bool")
        if self.enable_restore_routes and not self.enable_ops_routes:
            raise ValueError("DBModuleOptions.enable_restore_routes requires enable_ops_routes=True")

    @classmethod
    def from_app_config(
        cls,
        app: Flask,
        *,
        ops_auth_callback: Callable[[Any], Any] | None = None,
        register_blueprint: bool = True,
        init_tables: bool = True,
    ) -> "DBModuleOptions":
        cfg = app.config
        options = cls(
            register_blueprint=register_blueprint,
            init_tables=init_tables,
            db_url_prefix=str(cfg.get("DB_MODULE_URL_PREFIX", "/api/db")),
            blueprint_name=str(cfg.get("DB_MODULE_BLUEPRINT_NAME", "db")),
            ops_auth_callback=ops_auth_callback,
            enable_ops_routes=coerce_config_bool(cfg.get("DB_MODULE_ENABLE_OPS_ROUTES", True), True),
            enable_templates_routes=coerce_config_bool(cfg.get("DB_MODULE_ENABLE_TEMPLATES_ROUTES", True), True),
            enable_restore_routes=coerce_config_bool(cfg.get("DB_MODULE_ENABLE_RESTORE_ROUTES", True), True),
        )
        options.validate()
        return options


def _validate_ops_security(app: Flask, options: DBModuleOptions) -> None:
    validate_ops_blueprint_security(
        app,
        enable_ops_routes=options.enable_ops_routes,
        ops_auth_callback=options.ops_auth_callback,
    )


def _get_db_module_extension(app: Flask) -> dict[str, Any]:
    ext = app.extensions.setdefault("db_module", {})
    ext.setdefault("ops_auth_callbacks", {})
    ext.setdefault("blueprint_options", {})
    return ext


def _normalize_scope_key(scope_key: str | None) -> str | None:
    if not isinstance(scope_key, str):
        return None
    normalized = scope_key.strip()
    return normalized or None


def _known_scope_keys(app: Flask) -> list[str]:
    ext = _get_db_module_extension(app)
    keys: set[str] = set()
    for source_name in ("ops_auth_callbacks", "blueprint_options"):
        source = ext.get(source_name)
        if not isinstance(source, dict):
            continue
        for key in source.keys():
            normalized = _normalize_scope_key(key)
            if normalized is not None:
                keys.add(normalized)
    return sorted(keys)


def _resolve_configure_scope_key(app: Flask, scope_key: str | None) -> str:
    explicit_scope = _normalize_scope_key(scope_key)
    if explicit_scope is not None:
        return explicit_scope

    known_scopes = _known_scope_keys(app)
    if len(known_scopes) == 1:
        return known_scopes[0]
    if len(known_scopes) > 1:
        raise ValueError("scope_key is required when multiple DB module blueprints are registered")

    configured_scope = _normalize_scope_key(app.config.get("DB_MODULE_BLUEPRINT_NAME"))
    if configured_scope is not None:
        return configured_scope
    return "db"


def _resolve_scope_enable_ops_routes(app: Flask, scope_key: str) -> bool:
    ext = _get_db_module_extension(app)
    blueprint_options = ext.get("blueprint_options", {})
    if isinstance(blueprint_options, dict):
        options = blueprint_options.get(scope_key)
        if isinstance(options, dict):
            return bool(options.get("enable_ops_routes", True))
    return coerce_config_bool(app.config.get("DB_MODULE_ENABLE_OPS_ROUTES", True), True)


def _record_blueprint_options(app: Flask, options: DBModuleOptions) -> None:
    ext = _get_db_module_extension(app)
    ext["blueprint_options"][options.blueprint_name] = {
        "url_prefix": options.db_url_prefix,
        "enable_ops_routes": options.enable_ops_routes,
        "enable_templates_routes": options.enable_templates_routes,
        "enable_restore_routes": options.enable_restore_routes,
    }


def configure_db_module(
    app: Flask | None = None,
    *,
    ops_auth_callback: Callable[[Any], Any] | None = None,
    scope_key: str | None = None,
) -> None:
    """配置 DB 模块的扩展点。"""
    target_app = app
    if target_app is None:
        if not has_app_context():
            raise ValueError("configure_db_module requires app or an active app context")
        target_app = current_app._get_current_object()
    resolved_scope_key = _resolve_configure_scope_key(target_app, scope_key)
    validate_ops_blueprint_security(
        target_app,
        enable_ops_routes=_resolve_scope_enable_ops_routes(target_app, resolved_scope_key),
        ops_auth_callback=ops_auth_callback,
    )
    register_ops_auth_callback(ops_auth_callback, app_obj=target_app, scope_key=resolved_scope_key)


def init_db_module(
    app: Flask,
    options: DBModuleOptions | None = None,
    *,
    register_blueprint: bool = True,
    init_tables: bool = True,
    db_url_prefix: str | object = _UNSET,
    blueprint_name: str | object = _UNSET,
    ops_auth_callback: Callable[[Any], Any] | None | object = _UNSET,
) -> None:
    """以库方式接入 DB 模块时的便捷初始化入口。

    包含：
    - SQLAlchemy 运行时初始化
    - 可选的内部表初始化
    - 可选的 ops 鉴权回调注册
    - 可选的 DB blueprint 注册
    """
    if options is None:
        callback_from_kwargs = None if ops_auth_callback is _UNSET else ops_auth_callback
        options = DBModuleOptions.from_app_config(
            app,
            ops_auth_callback=callback_from_kwargs,
            register_blueprint=register_blueprint,
            init_tables=init_tables,
        )
        if db_url_prefix is not _UNSET:
            options.db_url_prefix = db_url_prefix
        if blueprint_name is not _UNSET:
            options.blueprint_name = blueprint_name
        if ops_auth_callback is not _UNSET:
            options.ops_auth_callback = ops_auth_callback
        options.validate()
    else:
        options.validate()

    _validate_ops_security(app, options)
    init_db(app)
    _record_blueprint_options(app, options)
    configure_db_module(app, ops_auth_callback=options.ops_auth_callback, scope_key=options.blueprint_name)
    if options.init_tables:
        with app.app_context():
            init_db_module_tables()
    if options.register_blueprint:
        app.register_blueprint(
            create_db_blueprint(
                name=options.blueprint_name,
                url_prefix=options.db_url_prefix,
                ops_auth_callback=options.ops_auth_callback,
                enable_ops_routes=options.enable_ops_routes,
                enable_templates_routes=options.enable_templates_routes,
                enable_restore_routes=options.enable_restore_routes,
            )
        )


def shutdown_db_module(app: Flask, *, wait: bool = False) -> None:
    """关闭当前 app 由 DB 模块持有的异步资源。"""
    shutdown_ops_executors(app, wait=wait)
