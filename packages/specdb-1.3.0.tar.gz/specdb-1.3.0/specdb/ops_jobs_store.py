"""DB ops 任务的持久化存储。"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

from sqlalchemy import Column, DateTime, MetaData, String, Table, Text, inspect, or_, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.exc import IntegrityError

from specdb.db_init_guard import EngineInitGuard
from specdb.db_runtime import db
from specdb.ops.job_store_support import (
    build_storage_job_id as _build_storage_job_id_impl,
    is_claimable_row as _is_claimable_row_impl,
    normalize_job_summary as _normalize_job_summary_impl,
    normalize_scope_key as _normalize_scope_key_impl,
    public_job_id_from_row as _public_job_id_from_row_impl,
    request_scope_matches as _request_scope_matches_impl,
    row_identity_from_request_json as _row_identity_from_request_json_impl,
    sanitize_request_payload as _sanitize_request_payload_impl,
    scope_key_matches as _scope_key_matches_impl,
    serialize_request_payload as _serialize_request_payload_impl,
    serialize_row as _serialize_row_impl,
)
from specdb.ops.job_store_schema import backfill_job_identity_columns, ensure_optional_job_columns
from specdb.ops.store_common import (
    _decode_json_object_strict,
    _to_db_datetime,
)

_metadata = MetaData()
_ops_jobs_table = Table(
    "db_ops_jobs",
    _metadata,
    Column("job_id", String(128), primary_key=True),
    Column("public_job_id", String(128), nullable=True),
    Column("scope_key", String(128), nullable=True),
    Column("state", String(64), nullable=False),
    Column("snapshot_id", String(128), nullable=True),
    Column("request_json", Text, nullable=False),
    Column("error_code", String(128), nullable=True),
    Column("owner_id", String(128), nullable=True),
    Column("lease_expires_at", DateTime(timezone=True), nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
)
_ops_job_results_table = Table(
    "db_ops_job_results",
    _metadata,
    Column("job_id", String(128), primary_key=True),
    Column("summary_json", Text, nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
)
_init_guard = EngineInitGuard()
_INTERNAL_REQUEST_KEYS = frozenset({"_scope_key"})
_RECOVERABLE_JOB_STATES = frozenset({"pending", "snapshot_done", "compact_done"})
_REQUIRED_JOB_COLUMNS = frozenset({"public_job_id", "scope_key", "owner_id", "lease_expires_at"})
_KNOWN_JOB_STATES = frozenset({"pending", "snapshot_done", "compact_done", "verified", "failed"})
_ALLOWED_PREVIOUS_STATES = {
    "pending": frozenset(),
    "snapshot_done": frozenset({"pending"}),
    "compact_done": frozenset({"snapshot_done", "compact_done"}),
    "verified": frozenset({"compact_done"}),
    "failed": frozenset(_RECOVERABLE_JOB_STATES),
}
_UNSET = object()


class JobRequestConflictError(RuntimeError):
    """重复 request_id 对应的请求体不一致时抛出。"""


def _serialize_request_payload(payload: dict[str, Any]) -> str:
    return _serialize_request_payload_impl(payload)
def _normalize_scope_key(scope_key: str | None) -> str | None:
    return _normalize_scope_key_impl(scope_key)


def _scope_key_matches(row_scope: Any, scope_key: str | None) -> bool:
    return _scope_key_matches_impl(row_scope, scope_key)
def _sanitize_request_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return _sanitize_request_payload_impl(payload)


def _row_identity_from_request_json(
    request_json: Any,
    *,
    fallback_job_id: Any,
) -> tuple[str | None, str | None]:
    return _row_identity_from_request_json_impl(request_json, fallback_job_id=fallback_job_id)


def _request_scope_matches(request_json: str, scope_key: str | None) -> bool:
    return _request_scope_matches_impl(request_json, scope_key)


def _is_claimable_row(row: dict[str, Any], *, now: datetime | None = None) -> bool:
    return _is_claimable_row_impl(row, now=now)


def _public_job_id_from_row(row: dict[str, Any]) -> str | None:
    return _public_job_id_from_row_impl(row)


def _serialize_row(row: dict[str, Any]) -> dict[str, Any]:
    return _serialize_row_impl(row)


def _normalize_job_summary(summary: dict[str, Any], row: dict[str, Any], *, scope_key: str | None = None) -> dict[str, Any]:
    return _normalize_job_summary_impl(summary, row, scope_key=scope_key)


def _build_storage_job_id(public_job_id: str, scope_key: str | None) -> str:
    return _build_storage_job_id_impl(public_job_id, scope_key)


def _ensure_optional_job_columns(engine: Any) -> None:
    ensure_optional_job_columns(
        engine,
        jobs_table=_ops_jobs_table,
        required_job_columns=_REQUIRED_JOB_COLUMNS,
    )


def _backfill_job_identity_columns(engine: Any) -> None:
    backfill_job_identity_columns(
        engine,
        jobs_table=_ops_jobs_table,
        row_identity_from_request_json=_row_identity_from_request_json,
        normalize_scope_key=_normalize_scope_key,
    )


def _load_job_row(conn: Any, public_job_id: str, scope_key: str | None) -> dict[str, Any] | None:
    rows = conn.execute(
        select(_ops_jobs_table)
        .where(_ops_jobs_table.c.public_job_id == public_job_id)
        .order_by(_ops_jobs_table.c.created_at.asc(), _ops_jobs_table.c.job_id.asc())
    ).mappings().all()
    if rows:
        normalized_scope = _normalize_scope_key(scope_key)
        if normalized_scope is None:
            if len(rows) != 1:
                return None
            return dict(rows[0])
        exact_matches = [
            dict(row)
            for row in rows
            if _normalize_scope_key(row.get("scope_key")) == normalized_scope
        ]
        if len(exact_matches) == 1:
            return exact_matches[0]
        if len(exact_matches) > 1:
            return None
        legacy_matches = [dict(row) for row in rows if _scope_key_matches(row.get("scope_key"), normalized_scope)]
        if len(legacy_matches) != 1:
            return None
        return legacy_matches[0]

    legacy_row = conn.execute(
        select(_ops_jobs_table).where(_ops_jobs_table.c.job_id == public_job_id)
    ).mappings().first()
    if legacy_row is None:
        return None
    legacy_request_json = legacy_row.get("request_json")
    if not isinstance(legacy_request_json, str) or not _request_scope_matches(legacy_request_json, scope_key):
        return None
    return dict(legacy_row)


def _apply_expectation_filters(
    stmt: Any,
    *,
    expected_owner_id: str | None | object = _UNSET,
    expected_states: Iterable[str] | None = None,
    expected_lease_expires_at: datetime | None | object = _UNSET,
) -> Any:
    if expected_owner_id is not _UNSET:
        if expected_owner_id is None:
            stmt = stmt.where(_ops_jobs_table.c.owner_id.is_(None))
        else:
            stmt = stmt.where(_ops_jobs_table.c.owner_id == expected_owner_id)
    if expected_states is not None:
        normalized_states = tuple(sorted({str(item) for item in expected_states if isinstance(item, str) and item}))
        if not normalized_states:
            stmt = stmt.where(text("1 = 0"))
        elif len(normalized_states) == 1:
            stmt = stmt.where(_ops_jobs_table.c.state == normalized_states[0])
        else:
            stmt = stmt.where(_ops_jobs_table.c.state.in_(normalized_states))
    if expected_lease_expires_at is not _UNSET:
        expected_db_value = _to_db_datetime(expected_lease_expires_at)
        if expected_db_value is None:
            stmt = stmt.where(_ops_jobs_table.c.lease_expires_at.is_(None))
        else:
            stmt = stmt.where(_ops_jobs_table.c.lease_expires_at == expected_db_value)
    return stmt


def _effective_expected_states_for_transition(
    target_state: str,
    expected_states: Iterable[str] | None,
) -> tuple[str, ...] | None:
    allowed_previous = _ALLOWED_PREVIOUS_STATES.get(target_state)
    if allowed_previous is None:
        return expected_states
    if expected_states is None:
        return tuple(sorted(allowed_previous))
    normalized_expected = {str(item) for item in expected_states if isinstance(item, str) and item}
    return tuple(sorted(allowed_previous.intersection(normalized_expected)))


def _upsert_job_summary_row(conn: Any, internal_job_id: str, summary_json: str, updated_at: datetime) -> None:
    dialect_name = getattr(getattr(conn, "dialect", None), "name", "")
    if dialect_name == "sqlite":
        stmt = sqlite_insert(_ops_job_results_table).values(
            job_id=internal_job_id,
            summary_json=summary_json,
            updated_at=updated_at,
        )
        conn.execute(
            stmt.on_conflict_do_update(
                index_elements=[_ops_job_results_table.c.job_id],
                set_={"summary_json": summary_json, "updated_at": updated_at},
            )
        )
        return
    if dialect_name == "postgresql":
        stmt = pg_insert(_ops_job_results_table).values(
            job_id=internal_job_id,
            summary_json=summary_json,
            updated_at=updated_at,
        )
        conn.execute(
            stmt.on_conflict_do_update(
                index_elements=[_ops_job_results_table.c.job_id],
                set_={"summary_json": summary_json, "updated_at": updated_at},
            )
        )
        return
    try:
        conn.execute(
            _ops_job_results_table.insert().values(
                job_id=internal_job_id,
                summary_json=summary_json,
                updated_at=updated_at,
            )
        )
        return
    except IntegrityError:
        pass
    conn.execute(
        _ops_job_results_table.update()
        .where(_ops_job_results_table.c.job_id == internal_job_id)
        .values(summary_json=summary_json, updated_at=updated_at)
    )


def ensure_ops_jobs_table() -> None:
    engine = db.engine

    def _initializer() -> None:
        _metadata.create_all(bind=engine, tables=[_ops_jobs_table, _ops_job_results_table], checkfirst=True)
        _ensure_optional_job_columns(engine)
        _backfill_job_identity_columns(engine)

    def _is_initialized() -> bool:
        inspector = inspect(engine)
        if not inspector.has_table(_ops_jobs_table.name) or not inspector.has_table(_ops_job_results_table.name):
            return False
        column_names = {str(item.get("name")) for item in inspector.get_columns(_ops_jobs_table.name)}
        return _REQUIRED_JOB_COLUMNS.issubset(column_names)

    _init_guard.ensure(engine, _initializer, is_initialized=_is_initialized)


def get_job(job_id: str, *, scope_key: str | None = None) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return None
        summary_row = (
            conn.execute(
                select(_ops_job_results_table).where(_ops_job_results_table.c.job_id == row["job_id"])
            ).mappings().first()
        )
    data = _serialize_row(dict(row))
    if summary_row is not None:
        summary_json = summary_row.get("summary_json")
        if isinstance(summary_json, str):
            parsed_summary = _decode_json_object_strict(
                summary_json,
                field_name="summary_json",
                entity_name="job",
                entity_id=data.get("job_id") or row.get("job_id"),
            )
            data["summary"] = _normalize_job_summary(parsed_summary, dict(row), scope_key=scope_key)
    return data


def resolve_job_storage_id(job_id: str, *, scope_key: str | None = None) -> str:
    """根据公开 job_id 返回对应的持久化内部 job 标识。"""
    ensure_ops_jobs_table()
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
    if row is not None:
        internal_job_id = row.get("job_id")
        if isinstance(internal_job_id, str) and internal_job_id.strip():
            return internal_job_id
    return _build_storage_job_id(job_id, scope_key)


def create_pending_job(job_id: str, request_payload: dict[str, Any], *, scope_key: str | None = None) -> dict[str, Any]:
    ensure_ops_jobs_table()
    now = datetime.now(timezone.utc)
    public_job_id = job_id
    normalized_scope = _normalize_scope_key(scope_key)
    if normalized_scope is None:
        normalized_scope = _normalize_scope_key(request_payload.get("_scope_key"))
    serialized_request = _serialize_request_payload(request_payload)
    comparable_request = _serialize_request_payload(_sanitize_request_payload(request_payload))
    insert_values = dict(
        job_id=_build_storage_job_id(public_job_id, normalized_scope),
        public_job_id=public_job_id,
        scope_key=normalized_scope,
        state="pending",
        snapshot_id=None,
        request_json=serialized_request,
        error_code=None,
        owner_id=None,
        lease_expires_at=None,
        created_at=now,
        updated_at=now,
    )

    insert_error: IntegrityError | None = None
    with db.engine.begin() as conn:
        try:
            conn.execute(_ops_jobs_table.insert().values(**insert_values))
        except IntegrityError as exc:
            insert_error = exc
        row = _load_job_row(conn, public_job_id, normalized_scope)
    if row is None:
        if insert_error is not None:
            raise RuntimeError(f"failed to create pending job: {public_job_id}") from insert_error
        raise RuntimeError(f"job row not found after create: {public_job_id}")

    existing_request_json = row.get("request_json")
    if not isinstance(existing_request_json, str):
        raise JobRequestConflictError(f"request_id already exists with invalid payload: {public_job_id}")
    try:
        existing_payload = json.loads(existing_request_json)
    except json.JSONDecodeError as exc:
        raise JobRequestConflictError(f"request_id already exists with invalid payload: {public_job_id}") from exc
    if not isinstance(existing_payload, dict):
        raise JobRequestConflictError(f"request_id already exists with invalid payload: {public_job_id}")
    if _serialize_request_payload(_sanitize_request_payload(existing_payload)) != comparable_request:
        raise JobRequestConflictError(f"request_id already exists with different payload: {public_job_id}")

    return _serialize_row(dict(row))


def list_pending_job_ids(*, scope_key: str | None = None) -> list[str]:
    ensure_ops_jobs_table()
    stmt = select(_ops_jobs_table.c.public_job_id, _ops_jobs_table.c.request_json).where(_ops_jobs_table.c.state == "pending")
    with db.engine.begin() as conn:
        rows = conn.execute(stmt).mappings().all()

    result: list[str] = []
    for row in rows:
        public_job_id = row.get("public_job_id")
        request_json = row.get("request_json")
        if not isinstance(public_job_id, str) or not public_job_id.strip() or not isinstance(request_json, str):
            continue
        if not _request_scope_matches(request_json, scope_key):
            continue
        result.append(public_job_id)
    return result


def list_recoverable_jobs(*, scope_key: str | None = None, only_claimable: bool = False) -> list[dict[str, Any]]:
    ensure_ops_jobs_table()
    stmt = (
        select(
            _ops_jobs_table.c.job_id,
            _ops_jobs_table.c.public_job_id,
            _ops_jobs_table.c.scope_key,
            _ops_jobs_table.c.state,
            _ops_jobs_table.c.request_json,
            _ops_jobs_table.c.owner_id,
            _ops_jobs_table.c.lease_expires_at,
        )
        .where(_ops_jobs_table.c.state.in_(tuple(sorted(_RECOVERABLE_JOB_STATES))))
        .order_by(_ops_jobs_table.c.created_at.asc(), _ops_jobs_table.c.job_id.asc())
    )
    with db.engine.begin() as conn:
        rows = conn.execute(stmt).mappings().all()

    result: list[dict[str, Any]] = []
    now = datetime.now(timezone.utc)
    for row in rows:
        public_job_id = _public_job_id_from_row(dict(row))
        state = row.get("state")
        request_json = row.get("request_json")
        if not isinstance(public_job_id, str) or not public_job_id.strip() or not isinstance(state, str) or not isinstance(request_json, str):
            continue
        if not _request_scope_matches(request_json, scope_key):
            continue
        row_data = dict(row)
        if only_claimable and not _is_claimable_row(row_data, now=now):
            continue
        result.append(
            {
                "job_id": public_job_id,
                "state": state,
                "owner_id": row.get("owner_id"),
                "lease_expires_at": row.get("lease_expires_at"),
            }
        )
    return result


def get_recoverable_job(job_id: str, *, scope_key: str | None = None, only_claimable: bool = False) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
    if row is None or row.get("state") not in _RECOVERABLE_JOB_STATES:
        return None
    if only_claimable and not _is_claimable_row(row):
        return None
    data = dict(row)
    public_job_id = _public_job_id_from_row(data)
    if isinstance(public_job_id, str) and public_job_id.strip():
        data["job_id"] = public_job_id
    return data


def update_job_state(
    job_id: str,
    state: str,
    *,
    scope_key: str | None = None,
    snapshot_id: str | None = None,
    error_code: str | None = None,
    owner_id: str | None | object = _UNSET,
    lease_expires_at: datetime | None | object = _UNSET,
    expected_owner_id: str | None | object = _UNSET,
    expected_states: Iterable[str] | None = None,
    expected_lease_expires_at: datetime | None | object = _UNSET,
) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    if state not in _KNOWN_JOB_STATES:
        return None
    now = datetime.now(timezone.utc)
    values: dict[str, Any] = {
        "state": state,
        "snapshot_id": snapshot_id,
        "error_code": error_code,
        "updated_at": now,
    }
    if owner_id is not _UNSET:
        values["owner_id"] = owner_id
    if lease_expires_at is not _UNSET:
        values["lease_expires_at"] = _to_db_datetime(lease_expires_at)
    effective_expected_states = _effective_expected_states_for_transition(state, expected_states)
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return None
        result = conn.execute(
            _apply_expectation_filters(
                _ops_jobs_table.update().where(_ops_jobs_table.c.job_id == row["job_id"]),
                expected_owner_id=expected_owner_id,
                expected_states=effective_expected_states,
                expected_lease_expires_at=expected_lease_expires_at,
            ).values(**values)
        )
        if int(result.rowcount or 0) <= 0:
            return None
        updated = conn.execute(select(_ops_jobs_table).where(_ops_jobs_table.c.job_id == row["job_id"])).mappings().first()
    if updated is None:
        return None
    return _serialize_row(dict(updated))


def update_job_summary(job_id: str, summary: dict[str, Any], *, scope_key: str | None = None) -> None:
    ensure_ops_jobs_table()
    now = datetime.now(timezone.utc)
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return
        summary = _normalize_job_summary(summary, row, scope_key=scope_key)
        summary_json = json.dumps(summary, ensure_ascii=False)
        _upsert_job_summary_row(conn, row["job_id"], summary_json, now)


def update_job_state_with_summary(
    job_id: str,
    *,
    scope_key: str | None = None,
    state: str,
    snapshot_id: str | None = None,
    error_code: str | None = None,
    owner_id: str | None | object = _UNSET,
    lease_expires_at: datetime | None | object = _UNSET,
    summary: dict[str, Any] | object = _UNSET,
    expected_owner_id: str | None | object = _UNSET,
    expected_states: Iterable[str] | None = None,
    expected_lease_expires_at: datetime | None | object = _UNSET,
) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    if state not in _KNOWN_JOB_STATES:
        return None
    now = datetime.now(timezone.utc)
    values: dict[str, Any] = {
        "state": state,
        "snapshot_id": snapshot_id,
        "error_code": error_code,
        "updated_at": now,
    }
    if owner_id is not _UNSET:
        values["owner_id"] = owner_id
    if lease_expires_at is not _UNSET:
        values["lease_expires_at"] = _to_db_datetime(lease_expires_at)
    effective_expected_states = _effective_expected_states_for_transition(state, expected_states)

    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return None
        result = conn.execute(
            _apply_expectation_filters(
                _ops_jobs_table.update().where(_ops_jobs_table.c.job_id == row["job_id"]),
                expected_owner_id=expected_owner_id,
                expected_states=effective_expected_states,
                expected_lease_expires_at=expected_lease_expires_at,
            ).values(**values)
        )
        if int(result.rowcount or 0) <= 0:
            return None
        if summary is not _UNSET:
            normalized_summary = summary if not isinstance(summary, dict) else _normalize_job_summary(summary, row, scope_key=scope_key)
            summary_json = json.dumps(normalized_summary, ensure_ascii=False)
            _upsert_job_summary_row(conn, row["job_id"], summary_json, now)
        updated = conn.execute(select(_ops_jobs_table).where(_ops_jobs_table.c.job_id == row["job_id"])).mappings().first()
    if updated is None:
        return None
    return _serialize_row(dict(updated))


def claim_job_execution(
    job_id: str,
    *,
    scope_key: str | None = None,
    owner_id: str,
    lease_seconds: int,
) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    now = datetime.now(timezone.utc)
    lease_until = now + timedelta(seconds=max(int(lease_seconds), 1))
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return None
        result = conn.execute(
            _ops_jobs_table.update()
            .where(_ops_jobs_table.c.job_id == row["job_id"])
            .where(_ops_jobs_table.c.state.in_(tuple(sorted(_RECOVERABLE_JOB_STATES))))
            .where(
                or_(
                    _ops_jobs_table.c.owner_id.is_(None),
                    _ops_jobs_table.c.lease_expires_at.is_(None),
                    _ops_jobs_table.c.lease_expires_at <= _to_db_datetime(now),
                    _ops_jobs_table.c.owner_id == owner_id,
                )
            )
            .values(
                owner_id=owner_id,
                lease_expires_at=_to_db_datetime(lease_until),
                updated_at=now,
            )
        )
        if int(result.rowcount or 0) <= 0:
            return None
        updated = conn.execute(select(_ops_jobs_table).where(_ops_jobs_table.c.job_id == row["job_id"])).mappings().first()
    if updated is None:
        return None
    return _serialize_row(dict(updated))


def renew_job_lease(
    job_id: str,
    *,
    scope_key: str | None = None,
    owner_id: str,
    lease_seconds: int,
    conn: Any | None = None,
    require_unexpired: bool = False,
) -> bool:
    ensure_ops_jobs_table()
    now = datetime.now(timezone.utc)
    lease_until = now + timedelta(seconds=max(int(lease_seconds), 1))

    def _renew(active_conn: Any) -> bool:
        row = _load_job_row(active_conn, job_id, scope_key)
        if row is None:
            return False
        stmt = (
            _ops_jobs_table.update()
            .where(_ops_jobs_table.c.job_id == row["job_id"])
            .where(_ops_jobs_table.c.owner_id == owner_id)
            .where(_ops_jobs_table.c.state.in_(tuple(sorted(_RECOVERABLE_JOB_STATES))))
        )
        if require_unexpired:
            current_lease_deadline = _to_db_datetime(now)
            stmt = stmt.where(_ops_jobs_table.c.lease_expires_at.is_not(None)).where(
                _ops_jobs_table.c.lease_expires_at >= current_lease_deadline
            )
        result = active_conn.execute(
            stmt.values(
                lease_expires_at=_to_db_datetime(lease_until),
                updated_at=now,
            )
        )
        return int(result.rowcount or 0) > 0

    if conn is not None:
        return _renew(conn)
    with db.engine.begin() as local_conn:
        return _renew(local_conn)


def retry_failed_job(job_id: str, *, scope_key: str | None = None) -> dict[str, Any] | None:
    ensure_ops_jobs_table()
    now = datetime.now(timezone.utc)
    with db.engine.begin() as conn:
        row = _load_job_row(conn, job_id, scope_key)
        if row is None:
            return None
        if row.get("state") != "failed":
            return _serialize_row(dict(row))

        conn.execute(
            _ops_jobs_table.update()
            .where(_ops_jobs_table.c.job_id == row["job_id"])
            .values(
                state="pending",
                snapshot_id=None,
                error_code=None,
                owner_id=None,
                lease_expires_at=None,
                updated_at=now,
            )
        )
        conn.execute(_ops_job_results_table.delete().where(_ops_job_results_table.c.job_id == row["job_id"]))
        updated = conn.execute(select(_ops_jobs_table).where(_ops_jobs_table.c.job_id == row["job_id"])).mappings().first()
    if updated is None:
        return None
    return _serialize_row(dict(updated))
