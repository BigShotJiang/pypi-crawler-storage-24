"""Shared error and envelope helpers for DB execution."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class DBExecuteError(Exception):
    code: str
    message: str
    details: dict[str, Any] | None = None


def success_payload(data: Any) -> dict[str, Any]:
    return {"success": True, "data": data, "error": None}


def error_payload(code: str, message: str, details: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {"code": code, "message": message}
    if details:
        payload["details"] = details
    return {"success": False, "data": None, "error": payload}
