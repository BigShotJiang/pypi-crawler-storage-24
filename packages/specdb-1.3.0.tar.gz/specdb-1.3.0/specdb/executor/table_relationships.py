"""Shared relationship and foreign-key helpers for table actions."""

from __future__ import annotations

from typing import Any

from sqlalchemy import ForeignKeyConstraint, MetaData, Table, inspect

from specdb.db_runtime import db
from specdb.executor.errors import DBExecuteError
from specdb.executor.schema import (
    _assert_dict,
    _auto_db_object_name,
    _build_type,
    _normalize_sqla_type,
    _quote_identifier,
)


def ensure_postgres_foreign_keys_supported(
    *,
    enabled: bool,
    strategy: str,
    dialect_name: str | None = None,
) -> None:
    if not enabled:
        return
    if dialect_name is None:
        dialect_name = db.engine.dialect.name
    if dialect_name != "postgresql":
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            "postgres_foreign_keys requires PostgreSQL dialect",
            {"dialect": dialect_name},
        )
    if strategy == "append_only_versioned":
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            "postgres_foreign_keys does not support append_only_versioned tables",
            {"strategy": strategy},
        )


def validate_postgres_foreign_key_additions(
    table_name: str,
    table: Table,
    add_spec: dict[str, Any],
    added_relations: dict[str, dict[str, Any]],
) -> None:
    for column_name, relation in added_relations.items():
        column_spec = _assert_dict(add_spec[column_name], f"payload.add.{column_name}")
        validate_postgres_foreign_key_target(
            table_name,
            column_name,
            column_spec,
            relation,
            current_table=table,
        )


def append_postgres_foreign_key_constraints(
    table_name: str,
    table: Table,
    relations: dict[str, dict[str, Any]],
) -> None:
    for column_name, relation in relations.items():
        column_spec = {"nullable": bool(table.c[column_name].nullable)}
        target_table = validate_postgres_foreign_key_target(
            table_name,
            column_name,
            column_spec,
            relation,
            current_table=table,
        )
        table.append_constraint(
            ForeignKeyConstraint(
                [table.c[column_name].name],
                [target_table.c[relation["target_column"]]],
                name=_auto_db_object_name(table_name, f"fk_{column_name}"),
                ondelete=map_relation_action_to_sql(relation["on_delete"]),
                onupdate=map_relation_action_to_sql(relation["on_update"]),
            )
        )


def build_postgres_add_column_foreign_key_sql(
    table_name: str,
    column_name: str,
    column_spec: dict[str, Any],
    added_relations: dict[str, dict[str, Any]],
    *,
    enabled: bool,
) -> str | None:
    if not enabled:
        return None
    relation = added_relations.get(column_name)
    if relation is None:
        return None
    validate_postgres_foreign_key_target(
        table_name,
        column_name,
        column_spec,
        relation,
    )
    return (
        f"CONSTRAINT {_quote_identifier(_auto_db_object_name(table_name, f'fk_{column_name}'))} "
        f"REFERENCES {_quote_identifier(relation['target_table'])} "
        f"({_quote_identifier(relation['target_column'])}) "
        f"ON DELETE {map_relation_action_to_sql(relation['on_delete'])} "
        f"ON UPDATE {map_relation_action_to_sql(relation['on_update'])}"
    )


def map_relation_action_to_sql(action: str) -> str:
    mapping = {
        "restrict": "RESTRICT",
        "cascade": "CASCADE",
        "set_null": "SET NULL",
        "no_action": "NO ACTION",
    }
    return mapping[action]


def validate_postgres_foreign_key_target(
    table_name: str,
    column_name: str,
    column_spec: dict[str, Any],
    relation: dict[str, Any],
    *,
    current_table: Table | None = None,
) -> Table:
    target_table_name = relation["target_table"]
    target_column_name = relation["target_column"]
    if relation["on_delete"] == "set_null" and not bool(column_spec.get("nullable", True)):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            "postgres_foreign_keys with on_delete=set_null requires nullable column",
            {"field": column_name, "table": table_name},
        )

    if target_table_name == table_name and current_table is not None:
        target_table = current_table
    else:
        inspector = inspect(db.engine)
        if not inspector.has_table(target_table_name):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"foreign key target table not found: {target_table_name}",
                {"field": column_name, "target_table": target_table_name},
            )
        metadata = current_table.metadata if current_table is not None else MetaData()
        target_table = Table(target_table_name, metadata, autoload_with=db.engine)

    if target_column_name not in target_table.c:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"foreign key target column not found: {target_table_name}.{target_column_name}",
            {"field": column_name, "target_table": target_table_name, "target_column": target_column_name},
        )
    target_primary_keys = {column.name for column in target_table.primary_key.columns}
    if target_column_name not in target_primary_keys:
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            "postgres_foreign_keys only supports relations targeting primary key columns",
            {"field": column_name, "target_table": target_table_name, "target_column": target_column_name},
        )
    return target_table


def column_type_family(column_type: Any) -> str | None:
    from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text

    normalized = _normalize_sqla_type(column_type)
    if isinstance(normalized, Text):
        return "text"
    if isinstance(normalized, String):
        return "str"
    if isinstance(normalized, Integer):
        return "int"
    if isinstance(normalized, Boolean):
        return "bool"
    if isinstance(normalized, DateTime):
        return "datetime"
    if isinstance(normalized, Float):
        return "float"
    return None


def resolve_modified_column_type(
    column_name: str,
    column: Any,
    modify_spec: dict[str, Any],
    *,
    dialect_name: str,
) -> tuple[Any, bool]:
    if "type" not in modify_spec and "length" not in modify_spec:
        return column.type, False

    current_family = column_type_family(column.type)
    target_type = modify_spec.get("type", current_family)
    if current_family not in {"str", "text"} or target_type not in {"str", "text"}:
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            f"modify type change is not supported in current phase for field: {column_name}",
            {"field": column_name, "dialect": dialect_name},
        )

    if target_type == "text":
        target_spec: dict[str, Any] = {"type": "text"}
    else:
        target_spec = {"type": "str"}
        if "length" in modify_spec:
            target_spec["length"] = modify_spec["length"]
        elif current_family == "str" and getattr(column.type, "length", None):
            target_spec["length"] = int(column.type.length)
        else:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name}.length is required when converting text to str",
                {"field": column_name},
            )

    target_column_type = _normalize_sqla_type(_build_type(column_name, target_spec))
    current_type = _normalize_sqla_type(column.type)
    type_changed = (
        current_family != column_type_family(target_column_type)
        or getattr(current_type, "length", None) != getattr(target_column_type, "length", None)
    )
    return target_column_type, type_changed
