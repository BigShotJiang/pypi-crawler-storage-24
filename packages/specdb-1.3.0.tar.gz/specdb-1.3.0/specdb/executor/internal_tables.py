"""Internal metadata tables used by the executor."""

from __future__ import annotations

from typing import Any

from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, Text, inspect, select, text

from specdb.db_init_guard import EngineInitGuard
from specdb.db_runtime import db

_INTERNAL_TABLE_NAMES = frozenset(
    {
        "db_table_options",
        "db_change_log",
        "db_ops_jobs",
        "db_ops_job_results",
        "db_ops_restore_audit",
        "db_ops_archives",
        "db_ops_archive_items",
    }
)

_INTERNAL_METADATA = MetaData()
_TABLE_OPTIONS = Table(
    "db_table_options",
    _INTERNAL_METADATA,
    Column("table_name", String(128), primary_key=True),
    Column("change_tracking_strategy", String(64), nullable=False),
    Column("retention_days", Integer, nullable=True),
    Column("relations_json", Text, nullable=True),
    Column("relationship_options_json", Text, nullable=True),
    Column("updated_at", DateTime(timezone=True), nullable=False),
)
_CHANGE_LOG = Table(
    "db_change_log",
    _INTERNAL_METADATA,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("batch_id", String(64), nullable=False),
    Column("table_name", String(128), nullable=False),
    Column("op", String(16), nullable=False),
    Column("row_key_json", Text, nullable=True),
    Column("before_json", Text, nullable=True),
    Column("after_json", Text, nullable=True),
    Column("query_json", Text, nullable=True),
    Column("changed_at", DateTime(timezone=True), nullable=False),
)

_init_guard = EngineInitGuard()


def ensure_internal_tables() -> None:
    """Initialize internal metadata tables used by the DB module."""

    engine = db.engine

    def _initializer() -> None:
        _INTERNAL_METADATA.create_all(bind=engine, tables=[_TABLE_OPTIONS, _CHANGE_LOG], checkfirst=True)
        _ensure_table_options_columns(engine)

    def _is_initialized() -> bool:
        inspector = inspect(engine)
        if not inspector.has_table(_TABLE_OPTIONS.name) or not inspector.has_table(_CHANGE_LOG.name):
            return False
        column_names = {str(item.get("name")) for item in inspector.get_columns(_TABLE_OPTIONS.name)}
        return {"relations_json", "relationship_options_json"}.issubset(column_names)

    _init_guard.ensure(engine, _initializer, is_initialized=_is_initialized)


def _ensure_table_options_columns(engine: Any) -> None:
    inspector = inspect(engine)
    if not inspector.has_table(_TABLE_OPTIONS.name):
        return
    column_names = {item["name"] for item in inspector.get_columns(_TABLE_OPTIONS.name)}
    if "relations_json" not in column_names:
        quoted_table = engine.dialect.identifier_preparer.quote_identifier(_TABLE_OPTIONS.name)
        with engine.begin() as conn:
            conn.execute(text(f"ALTER TABLE {quoted_table} ADD COLUMN relations_json TEXT"))
    if "relationship_options_json" not in column_names:
        quoted_table = engine.dialect.identifier_preparer.quote_identifier(_TABLE_OPTIONS.name)
        with engine.begin() as conn:
            conn.execute(text(f"ALTER TABLE {quoted_table} ADD COLUMN relationship_options_json TEXT"))


def delete_change_logs_for_table(table_name: str, *, conn: Any | None = None) -> int:
    ensure_internal_tables()
    delete_stmt = _CHANGE_LOG.delete().where(_CHANGE_LOG.c.table_name == table_name)
    if conn is not None:
        result = conn.execute(delete_stmt)
        return int(result.rowcount or 0)
    with db.engine.begin() as local_conn:
        result = local_conn.execute(delete_stmt)
    return int(result.rowcount or 0)


def list_table_tracking_strategies(targets: list[str] | None = None) -> dict[str, str]:
    ensure_internal_tables()
    stmt = select(_TABLE_OPTIONS.c.table_name, _TABLE_OPTIONS.c.change_tracking_strategy)
    if targets:
        stmt = stmt.where(_TABLE_OPTIONS.c.table_name.in_(targets))
    with db.engine.begin() as conn:
        rows = conn.execute(stmt).mappings().all()
    return {
        str(row["table_name"]): str(row["change_tracking_strategy"] or "none")
        for row in rows
        if row.get("table_name") is not None
    }


def is_internal_table_name(table_name: str) -> bool:
    return table_name in _INTERNAL_TABLE_NAMES


def list_public_table_names() -> list[str]:
    inspector = inspect(db.engine)
    return [name for name in inspector.get_table_names() if not is_internal_table_name(name)]
