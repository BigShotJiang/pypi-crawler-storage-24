"""Database client entrypoint and dispatch layer."""

from __future__ import annotations

from typing import Any

from sqlalchemy import MetaData, Table
from sqlalchemy.orm import Session

from specdb.executor.change_tracking import (
    append_only_current_filters,
    assert_tracking_strategy_supported,
    build_inserted_primary_key,
    build_row_key,
    business_columns,
    delete_table_options,
    ensure_tracking_tables,
    get_table_tracking_options,
    get_table_tracking_strategy,
    is_append_only_strategy,
    row_to_jsonable,
    upsert_table_options,
    write_change_logs,
)
from specdb.executor.data_actions import execute_data_action
from specdb.executor.errors import DBExecuteError
from specdb.executor.table_actions import execute_table_action
from specdb.executor.spec_validation import validate_execute_spec


class DatabaseClient:
    """按 spec 执行数据库动作。"""

    def __init__(self) -> None:
        self._metadata = MetaData()

    def _ensure_internal_tables(self) -> None:
        ensure_tracking_tables()

    def _upsert_table_options(self, table_name: str, payload: dict[str, Any]) -> None:
        upsert_table_options(table_name, payload)

    def _delete_table_options(self, table_name: str) -> None:
        delete_table_options(table_name)

    def _get_table_tracking_options(self, table_name: str) -> dict[str, Any]:
        return get_table_tracking_options(table_name)

    def _get_table_tracking_strategy(self, table_name: str) -> str:
        return get_table_tracking_strategy(table_name)

    def _assert_tracking_strategy_supported(self, table: Table, strategy: str) -> None:
        assert_tracking_strategy_supported(table, strategy)

    def _append_only_current_filters(self, table: Table) -> list[Any]:
        return append_only_current_filters(table)

    def _business_columns(self, table: Table) -> list[str]:
        return business_columns(table)

    def _is_append_only_strategy(self, strategy: str) -> bool:
        return is_append_only_strategy(strategy)

    def _row_to_jsonable(self, row: dict[str, Any]) -> dict[str, Any]:
        return row_to_jsonable(row)

    def _build_row_key(self, table: Table, row: dict[str, Any]) -> dict[str, Any] | None:
        return build_row_key(table, row)

    def _build_inserted_primary_key(self, table: Table, values: Any) -> dict[str, Any] | None:
        return build_inserted_primary_key(table, values)

    def _write_change_logs(
        self,
        session: Session,
        table: Table,
        op: str,
        *,
        rows_before: list[dict[str, Any]] | None = None,
        update_data: dict[str, Any] | None = None,
        rows_after: list[dict[str, Any]] | None = None,
        query: dict[str, Any] | None = None,
    ) -> None:
        write_change_logs(
            session,
            table,
            op,
            rows_before=rows_before,
            update_data=update_data,
            rows_after=rows_after,
            query=query,
        )

    def execute(self, spec: dict[str, Any], *, session: Session | None = None) -> dict[str, Any]:
        action, options = validate_execute_spec(spec)
        if action.startswith("table."):
            return self._execute_table_action(action, spec, options)
        return self._execute_data_action(action, spec, options, session=session)

    def _execute_table_action(self, action: str, spec: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        return execute_table_action(action, spec, options)

    def _handle_table_define(self, table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return execute_table_action("table.define", {"table": table_name, "payload": payload}, {})

    def _handle_table_alter(self, table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return execute_table_action("table.alter", {"table": table_name, "payload": payload}, {})

    def _handle_table_drop(self, table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return execute_table_action("table.drop", {"table": table_name, "payload": payload}, {})

    def _handle_table_describe(self, table_name: str) -> dict[str, Any]:
        return execute_table_action("table.describe", {"table": table_name, "payload": {}}, {})

    def _handle_table_backup(self, table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        return execute_table_action("table.backup", {"table": table_name, "payload": payload}, {})

    def _execute_data_action(
        self,
        action: str,
        spec: dict[str, Any],
        options: dict[str, Any],
        *,
        session: Session | None = None,
    ) -> dict[str, Any]:
        return execute_data_action(action, spec, options, session=session)

    def _handle_data_insert(self, table: Table, payload: dict[str, Any]) -> dict[str, Any]:
        return execute_data_action("data.insert", {"table": table.name, "payload": payload}, {})

    def _handle_data_select(self, table: Table, payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        return execute_data_action("data.select", {"table": table.name, "payload": payload}, options)

    def _history_row_payload(self, row: dict[str, Any]) -> dict[str, Any]:
        return row_to_jsonable(row)

    def _handle_data_history(self, table: Table, payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        return execute_data_action("data.history", {"table": table.name, "payload": payload}, options)

    def _ensure_write_query(self, payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        from specdb.executor.spec_validation import ensure_write_query

        return ensure_write_query(payload, options)

    def _handle_data_update(self, table: Table, payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        return execute_data_action("data.update", {"table": table.name, "payload": payload}, options)

    def _handle_data_delete(self, table: Table, payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
        return execute_data_action("data.delete", {"table": table.name, "payload": payload}, options)


def init_database(config: dict[str, Any] | None = None, logger: Any | None = None) -> DatabaseClient:
    """文档约定入口，返回执行客户端实例。"""
    _ = config, logger
    return DatabaseClient()
