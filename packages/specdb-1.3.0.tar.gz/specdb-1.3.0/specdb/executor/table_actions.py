"""Dispatch layer for table.* actions."""

from __future__ import annotations

from typing import Any

from specdb.executor.errors import DBExecuteError, success_payload
from specdb.executor.internal_tables import list_public_table_names
from specdb.executor.schema import _assert_dict, _assert_public_table_name
from specdb.executor.table_alter import handle_table_alter
from specdb.executor.table_define import handle_table_define
from specdb.executor.table_introspection import handle_table_backup, handle_table_describe, handle_table_drop


def execute_table_action(action: str, spec: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
    _ = options
    table_name = spec.get("table")
    payload = spec.get("payload", {})
    payload = _assert_dict(payload, "payload")

    if action == "table.list":
        return success_payload(list_public_table_names())

    if not isinstance(table_name, str):
        raise DBExecuteError("DB_SCHEMA_ERROR", "table is required")
    _assert_public_table_name(table_name, "table")

    if action == "table.define":
        return handle_table_define(table_name, payload)
    if action == "table.alter":
        return handle_table_alter(table_name, payload)
    if action == "table.drop":
        return handle_table_drop(table_name, payload)
    if action == "table.describe":
        return handle_table_describe(table_name)
    if action == "table.backup":
        return handle_table_backup(table_name, payload)
    raise DBExecuteError("DB_ACTION_NOT_SUPPORTED", f"unsupported action: {action}", {"action": action})
