"""table.alter action implementation."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from sqlalchemy import Boolean, Column, DateTime, Float, Index, Integer, MetaData, String, Table, Text, inspect, select, text
from sqlalchemy.exc import SQLAlchemyError

from specdb.db_runtime import db
from specdb.executor.change_tracking import get_table_tracking_options
from specdb.executor.errors import DBExecuteError, success_payload
from specdb.executor.relationship_metadata import (
    extract_relation_metadata,
    get_table_relationships,
    merge_relation_metadata,
    upsert_table_relationships,
)
from specdb.executor.schema import (
    _assert_dict,
    _assert_valid_identifier,
    _auto_db_object_name,
    _build_add_column_sql,
    _build_column,
    _build_type,
    _normalize_sqla_type,
    _quote_identifier,
    _sql_literal,
)
from specdb.executor.table_introspection import create_rebuild_indexes, inspect_column_index_catalog
from specdb.executor.table_relationships import (
    build_postgres_add_column_foreign_key_sql,
    ensure_postgres_foreign_keys_supported,
    map_relation_action_to_sql,
    resolve_modified_column_type,
    validate_postgres_foreign_key_additions,
)
from specdb.executor.values import _APPEND_ONLY_COLUMNS

_MODIFY_ALLOWED_KEYS = {"nullable", "default", "type", "length", "index", "unique"}
_MODIFY_UNSUPPORTED_KEYS = {"primary", "auto_increment", "rename_to"}


def handle_table_alter(table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    add_spec = payload.get("add") or {}
    modify_spec = payload.get("modify") or {}
    drop_spec = payload.get("drop") or []

    if not isinstance(add_spec, dict):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.add must be object")
    if not isinstance(modify_spec, dict):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.modify must be object")
    if not isinstance(drop_spec, list):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.drop must be array")
    if not add_spec and not modify_spec and not drop_spec:
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload must include at least one of add/modify/drop")

    inspector = inspect(db.engine)
    if not inspector.has_table(table_name):
        raise DBExecuteError("DB_TABLE_OP_ERROR", f"table not found: {table_name}", {"table": table_name})

    table = Table(table_name, MetaData(), autoload_with=db.engine)
    existing_columns = {column.name for column in table.columns}
    dialect_name = db.engine.dialect.name
    existing_relations = get_table_relationships(table_name)
    added_relations = extract_relation_metadata(add_spec, "payload.add")
    _validate_alter_request(add_spec, modify_spec, drop_spec, existing_columns)
    index_catalog = inspect_column_index_catalog(inspector, table_name)

    if modify_spec and dialect_name == "sqlite":
        tracking_options = get_table_tracking_options(table_name)
        tracking_strategy = str(tracking_options.get("change_tracking_strategy") or "none")
        relationship_options = tracking_options.get("relationship_options", {"postgres_foreign_keys": False})
        ensure_postgres_foreign_keys_supported(
            enabled=bool(relationship_options.get("postgres_foreign_keys", False)),
            strategy=tracking_strategy,
            dialect_name=dialect_name,
        )
        if relationship_options.get("postgres_foreign_keys"):
            validate_postgres_foreign_key_additions(table_name, table, add_spec, added_relations)
        _validate_modify_specs(table, modify_spec, tracking_strategy, dialect_name, index_catalog)

        result = _rebuild_sqlite_table(inspector, table_name, table, add_spec, modify_spec, drop_spec, index_catalog)
        merged_relations = merge_relation_metadata(existing_relations, added_relations, result["dropped_columns"])
        upsert_table_relationships(table_name, merged_relations)
        return success_payload(
            {
                "action": "table.alter",
                "table": table_name,
                "ok": True,
                "added_columns": result["added_columns"],
                "modified_columns": result["modified_columns"],
                "dropped_columns": result["dropped_columns"],
                "relations_recorded": sorted(merged_relations.keys()),
            }
        )

    primary_key_columns = {column.name for column in table.primary_key.columns}
    added_columns: list[str] = []
    modified_columns: list[str] = []
    dropped_columns: list[str] = []

    try:
        with db.engine.begin() as conn:
            tracking_options = get_table_tracking_options(table_name, conn=conn)
            tracking_strategy = str(tracking_options.get("change_tracking_strategy") or "none")
            relationship_options = tracking_options.get("relationship_options", {"postgres_foreign_keys": False})
            ensure_postgres_foreign_keys_supported(
                enabled=bool(relationship_options.get("postgres_foreign_keys", False)),
                strategy=tracking_strategy,
                dialect_name=dialect_name,
            )
            if relationship_options.get("postgres_foreign_keys"):
                validate_postgres_foreign_key_additions(table_name, table, add_spec, added_relations)
            _validate_modify_specs(table, modify_spec, tracking_strategy, dialect_name, index_catalog)

            for column_name, raw_spec in add_spec.items():
                column_spec = _assert_dict(raw_spec, f"payload.add.{column_name}")
                if column_name in existing_columns:
                    raise DBExecuteError("DB_SCHEMA_ERROR", f"field already exists: {column_name}", {"field": column_name})
                column_sql = _build_add_column_sql(
                    column_name,
                    column_spec,
                    foreign_key_sql=build_postgres_add_column_foreign_key_sql(
                        table_name,
                        column_name,
                        column_spec,
                        added_relations,
                        enabled=bool(relationship_options.get("postgres_foreign_keys", False)),
                    ),
                )
                conn.execute(text(f"ALTER TABLE {_quote_identifier(table_name)} ADD COLUMN {column_sql}"))
                existing_columns.add(column_name)
                added_columns.append(column_name)

            for column_name, raw_spec in modify_spec.items():
                column_spec = _assert_dict(raw_spec, f"payload.modify.{column_name}")
                _apply_postgres_column_modify(conn, table_name, table.c[column_name], column_spec, index_catalog)
                modified_columns.append(column_name)

            for raw_column_name in drop_spec:
                if not isinstance(raw_column_name, str):
                    raise DBExecuteError("DB_SCHEMA_ERROR", "payload.drop items must be strings")
                column_name = raw_column_name.strip()
                _assert_valid_identifier(column_name, "payload.drop")
                if column_name not in existing_columns:
                    raise DBExecuteError("DB_SCHEMA_ERROR", f"field not found: {column_name}", {"field": column_name})
                if column_name in primary_key_columns:
                    raise DBExecuteError("DB_SCHEMA_ERROR", f"cannot drop primary key field: {column_name}", {"field": column_name})
                if tracking_strategy == "append_only_versioned" and column_name in _APPEND_ONLY_COLUMNS:
                    raise DBExecuteError(
                        "DB_SCHEMA_ERROR",
                        f"cannot drop append_only_versioned reserved field: {column_name}",
                        {"field": column_name},
                    )
                conn.execute(text(f"ALTER TABLE {_quote_identifier(table_name)} DROP COLUMN {_quote_identifier(column_name)}"))
                existing_columns.remove(column_name)
                dropped_columns.append(column_name)
            merged_relations = merge_relation_metadata(existing_relations, added_relations, dropped_columns)
            upsert_table_relationships(table_name, merged_relations, conn=conn)
    except DBExecuteError:
        raise
    except SQLAlchemyError as exc:
        raise DBExecuteError("DB_TABLE_OP_ERROR", "alter table failed", {"error": str(exc)}) from exc

    return success_payload(
        {
            "action": "table.alter",
            "table": table_name,
            "ok": True,
            "added_columns": added_columns,
            "modified_columns": modified_columns,
            "dropped_columns": dropped_columns,
            "relations_recorded": sorted(merged_relations.keys()),
            "postgres_foreign_keys": bool(relationship_options.get("postgres_foreign_keys", False)),
        }
    )


def _validate_alter_request(
    add_spec: dict[str, Any],
    modify_spec: dict[str, Any],
    drop_spec: list[Any],
    existing_columns: set[str],
) -> None:
    add_fields = set(add_spec.keys())
    modify_fields = set(modify_spec.keys())
    drop_fields: set[str] = set()

    for field in add_fields:
        _assert_valid_identifier(field, "payload.add")
    for field in modify_fields:
        _assert_valid_identifier(field, "payload.modify")
        if field not in existing_columns:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"field not found: {field}", {"field": field})
    for raw_column_name in drop_spec:
        if not isinstance(raw_column_name, str):
            continue
        column_name = raw_column_name.strip()
        if column_name:
            drop_fields.add(column_name)

    conflicts = (add_fields & modify_fields) | (add_fields & drop_fields) | (modify_fields & drop_fields)
    if conflicts:
        field = sorted(conflicts)[0]
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"payload.add/modify/drop cannot target the same field: {field}",
            {"field": field},
        )


def _validate_modify_specs(
    table: Table,
    modify_spec: dict[str, Any],
    tracking_strategy: str,
    dialect_name: str,
    index_catalog: dict[str, Any],
) -> None:
    if not modify_spec:
        return
    if tracking_strategy == "append_only_versioned":
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            "table.alter.modify does not support append_only_versioned tables",
            {"strategy": tracking_strategy},
        )

    primary_key_columns = {column.name for column in table.primary_key.columns}
    for column_name, raw_spec in modify_spec.items():
        column_spec = _assert_dict(raw_spec, f"payload.modify.{column_name}")
        if not column_spec:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"payload.modify.{column_name} cannot be empty", {"field": column_name})
        unsupported_keys = sorted(set(column_spec.keys()) & _MODIFY_UNSUPPORTED_KEYS)
        if unsupported_keys:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                f"modify does not support key '{unsupported_keys[0]}'",
                {"field": column_name, "key": unsupported_keys[0]},
            )
        unknown_keys = sorted(set(column_spec.keys()) - _MODIFY_ALLOWED_KEYS - _MODIFY_UNSUPPORTED_KEYS)
        if unknown_keys:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name} contains unknown key: {unknown_keys[0]}",
                {"field": column_name, "key": unknown_keys[0]},
            )
        if column_name in primary_key_columns:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                f"modify does not support primary key field: {column_name}",
                {"field": column_name},
            )
        if column_name in _APPEND_ONLY_COLUMNS:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                f"modify does not support reserved append_only field: {column_name}",
                {"field": column_name},
            )
        if "nullable" in column_spec and not isinstance(column_spec["nullable"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name}.nullable must be bool",
                {"field": column_name},
            )
        if "type" in column_spec and not isinstance(column_spec["type"], str):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name}.type must be string",
                {"field": column_name},
            )
        if "length" in column_spec:
            length = column_spec["length"]
            if not isinstance(length, int) or length <= 0:
                raise DBExecuteError(
                    "DB_SCHEMA_ERROR",
                    f"payload.modify.{column_name}.length must be positive int",
                    {"field": column_name, "length": length},
                )
        if "index" in column_spec and not isinstance(column_spec["index"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name}.index must be bool",
                {"field": column_name},
            )
        if "unique" in column_spec and not isinstance(column_spec["unique"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{column_name}.unique must be bool",
                {"field": column_name},
            )
        if "default" in column_spec:
            _validate_modify_default(column_name, column_spec["default"])
        if ("index" in column_spec or "unique" in column_spec) and column_name in index_catalog["locked_columns"]:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                f"modify does not support index/unique changes for multi-column indexed field: {column_name}",
                {"field": column_name, "dialect": dialect_name},
            )

        resolve_modified_column_type(
            column_name,
            table.c[column_name],
            column_spec,
            dialect_name=dialect_name,
        )


def _validate_modify_default(column_name: str, default_value: Any) -> None:
    if isinstance(default_value, dict):
        if set(default_value.keys()) == {"drop"} and default_value.get("drop") is True:
            return
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"payload.modify.{column_name}.default only supports literal values or {{\"drop\": true}}",
            {"field": column_name},
        )
    _sql_literal(default_value)


def _is_drop_default(value: Any) -> bool:
    return isinstance(value, dict) and set(value.keys()) == {"drop"} and value.get("drop") is True


def _apply_postgres_column_modify(
    conn: Any,
    table_name: str,
    column: Column[Any],
    modify_spec: dict[str, Any],
    index_catalog: dict[str, Any],
) -> None:
    table_sql = _quote_identifier(table_name)
    column_sql = _quote_identifier(column.name)
    target_type, type_changed = resolve_modified_column_type(
        column.name,
        column,
        modify_spec,
        dialect_name=db.engine.dialect.name,
    )

    if type_changed:
        compiled_type = target_type.compile(dialect=db.engine.dialect)
        conn.execute(text(f"ALTER TABLE {table_sql} ALTER COLUMN {column_sql} TYPE {compiled_type}"))

    if "default" in modify_spec:
        if _is_drop_default(modify_spec["default"]):
            conn.execute(text(f"ALTER TABLE {table_sql} ALTER COLUMN {column_sql} DROP DEFAULT"))
        else:
            conn.execute(
                text(
                    f"ALTER TABLE {table_sql} ALTER COLUMN {column_sql} SET DEFAULT {_sql_literal(modify_spec['default'])}"
                )
            )

    if "nullable" in modify_spec:
        if modify_spec["nullable"]:
            conn.execute(text(f"ALTER TABLE {table_sql} ALTER COLUMN {column_sql} DROP NOT NULL"))
        else:
            conn.execute(text(f"ALTER TABLE {table_sql} ALTER COLUMN {column_sql} SET NOT NULL"))

    if "unique" in modify_spec:
        _apply_postgres_unique_modify(conn, table_name, column.name, modify_spec["unique"], index_catalog)

    if "index" in modify_spec:
        _apply_postgres_index_modify(conn, table_name, column.name, modify_spec["index"], index_catalog)


def _build_rebuild_column(source_column: Column[Any], modify_spec: dict[str, Any] | None = None) -> Column[Any]:
    kwargs: dict[str, Any] = {
        "nullable": source_column.nullable,
        "primary_key": source_column.primary_key,
    }
    if source_column.autoincrement is not None:
        kwargs["autoincrement"] = source_column.autoincrement
    if source_column.server_default is not None:
        kwargs["server_default"] = source_column.server_default.arg

    column_type = source_column.type
    if modify_spec:
        target_type, type_changed = resolve_modified_column_type(
            source_column.name,
            source_column,
            modify_spec,
            dialect_name="sqlite",
        )
        if type_changed:
            column_type = target_type
        if "nullable" in modify_spec:
            kwargs["nullable"] = modify_spec["nullable"]
        if "default" in modify_spec:
            if _is_drop_default(modify_spec["default"]):
                kwargs.pop("server_default", None)
            else:
                kwargs["server_default"] = text(_sql_literal(modify_spec["default"]))

    return Column(source_column.name, column_type, **kwargs)


def _rebuild_sqlite_table(
    inspector: Any,
    table_name: str,
    source_table: Table,
    add_spec: dict[str, Any],
    modify_spec: dict[str, Any],
    drop_spec: list[Any],
    index_catalog: dict[str, Any],
) -> dict[str, list[str]]:
    dropped_columns = [raw_column_name.strip() for raw_column_name in drop_spec if isinstance(raw_column_name, str)]
    dropped_set = set(dropped_columns)
    temp_table_name = f"_specdb_tmp_{table_name}_{uuid4().hex[:8]}"
    rebuilt_metadata = MetaData()
    rebuilt_columns: list[Column[Any]] = []

    for source_column in source_table.columns:
        if source_column.name in dropped_set:
            continue
        rebuilt_columns.append(_build_rebuild_column(source_column, modify_spec.get(source_column.name)))

    for column_name, raw_spec in add_spec.items():
        rebuilt_columns.append(_build_column(column_name, _assert_dict(raw_spec, f"payload.add.{column_name}")))

    temp_table = Table(temp_table_name, rebuilt_metadata, *rebuilt_columns)
    copied_column_names = [column.name for column in source_table.columns if column.name not in dropped_set]
    rebuild_indexes = _introspect_rebuild_indexes(inspector, table_name, dropped_set, modify_spec, index_catalog)

    try:
        with db.engine.begin() as conn:
            temp_table.create(bind=conn, checkfirst=False)
            if copied_column_names:
                conn.execute(
                    temp_table.insert().from_select(
                        copied_column_names,
                        select(*[source_table.c[column_name] for column_name in copied_column_names]),
                    )
                )
            source_table.drop(bind=conn, checkfirst=False)
            conn.execute(
                text(
                    f"ALTER TABLE {_quote_identifier(temp_table_name)} "
                    f"RENAME TO {_quote_identifier(table_name)}"
                )
            )
            final_table = Table(table_name, MetaData(), autoload_with=conn)
            create_rebuild_indexes(conn, final_table, rebuild_indexes)
    except SQLAlchemyError as exc:
        raise DBExecuteError("DB_TABLE_OP_ERROR", "alter table failed", {"error": str(exc)}) from exc

    return {
        "added_columns": list(add_spec.keys()),
        "modified_columns": list(modify_spec.keys()),
        "dropped_columns": dropped_columns,
    }


def _introspect_rebuild_indexes(
    inspector: Any,
    table_name: str,
    dropped_columns: set[str],
    modify_spec: dict[str, Any],
    index_catalog: dict[str, Any],
) -> list[dict[str, Any]]:
    rebuild_indexes: list[dict[str, Any]] = []
    seen_names: set[str] = set()
    seen_defs: set[tuple[tuple[str, ...], bool]] = set()
    modify_index_fields = {
        column_name
        for column_name, field_spec in modify_spec.items()
        if isinstance(field_spec, dict) and ("index" in field_spec or "unique" in field_spec)
    }

    for item in inspector.get_indexes(table_name):
        column_names = item.get("column_names") or []
        if not column_names:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                "sqlite rebuild does not support expression indexes in first phase",
                {"table": table_name, "index": item.get("name")},
            )
        if any(column_name in dropped_columns for column_name in column_names):
            continue
        if len(column_names) == 1 and column_names[0] in modify_index_fields:
            continue
        name = item.get("name") or ""
        index_key = (tuple(column_names), bool(item.get("unique", False)))
        if name in seen_names or index_key in seen_defs:
            continue
        seen_names.add(name)
        seen_defs.add(index_key)
        rebuild_indexes.append(
            {
                "name": item.get("name"),
                "column_names": column_names,
                "unique": bool(item.get("unique", False)),
            }
        )

    for item in inspector.get_unique_constraints(table_name):
        column_names = item.get("column_names") or []
        if not column_names or any(column_name in dropped_columns for column_name in column_names):
            continue
        if len(column_names) == 1 and column_names[0] in modify_index_fields:
            continue
        name = item.get("name") or ""
        index_key = (tuple(column_names), True)
        if name in seen_names or index_key in seen_defs:
            continue
        seen_names.add(name)
        seen_defs.add(index_key)
        rebuild_indexes.append({"name": item.get("name"), "column_names": column_names, "unique": True})

    for column_name in sorted(modify_index_fields):
        field_spec = _assert_dict(modify_spec[column_name], f"payload.modify.{column_name}")
        current_non_unique = bool(index_catalog["indexes"].get(column_name))
        current_unique = bool(
            index_catalog["unique_indexes"].get(column_name) or index_catalog["unique_constraints"].get(column_name)
        )
        target_unique = field_spec.get("unique", current_unique)
        target_non_unique = field_spec.get("index", current_non_unique)
        if target_unique:
            rebuild_indexes.append(
                {
                    "name": _auto_db_object_name(table_name, f"ux_{column_name}"),
                    "column_names": [column_name],
                    "unique": True,
                }
            )
            continue
        if target_non_unique:
            rebuild_indexes.append(
                {
                    "name": _auto_db_object_name(table_name, f"idx_{column_name}"),
                    "column_names": [column_name],
                    "unique": False,
                }
            )

    return rebuild_indexes


def _apply_postgres_unique_modify(
    conn: Any,
    table_name: str,
    column_name: str,
    enabled: bool,
    index_catalog: dict[str, Any],
) -> None:
    constraint_names = sorted(index_catalog["unique_constraints"].get(column_name, set()))
    index_names = sorted(index_catalog["unique_indexes"].get(column_name, set()))
    if enabled:
        if constraint_names or index_names:
            return
        index_name = _auto_db_object_name(table_name, f"ux_{column_name}")
        conn.execute(
            text(
                f"CREATE UNIQUE INDEX {_quote_identifier(index_name)} "
                f"ON {_quote_identifier(table_name)} ({_quote_identifier(column_name)})"
            )
        )
        return

    for constraint_name in constraint_names:
        conn.execute(
            text(
                f"ALTER TABLE {_quote_identifier(table_name)} "
                f"DROP CONSTRAINT {_quote_identifier(constraint_name)}"
            )
        )
    for index_name in index_names:
        conn.execute(text(f"DROP INDEX IF EXISTS {_quote_identifier(index_name)}"))


def _apply_postgres_index_modify(
    conn: Any,
    table_name: str,
    column_name: str,
    enabled: bool,
    index_catalog: dict[str, Any],
) -> None:
    index_names = sorted(index_catalog["indexes"].get(column_name, set()))
    if enabled:
        if index_names:
            return
        index_name = _auto_db_object_name(table_name, f"idx_{column_name}")
        conn.execute(
            text(
                f"CREATE INDEX {_quote_identifier(index_name)} "
                f"ON {_quote_identifier(table_name)} ({_quote_identifier(column_name)})"
            )
        )
        return

    for index_name in index_names:
        conn.execute(text(f"DROP INDEX IF EXISTS {_quote_identifier(index_name)}"))
