"""table.define action implementation."""

from __future__ import annotations

import logging
from typing import Any

from flask import current_app, has_app_context
from sqlalchemy import Boolean, Column, DateTime, Index, Integer, MetaData, String, Table, UniqueConstraint
from sqlalchemy.exc import SQLAlchemyError

from specdb.db_runtime import db
from specdb.executor.change_tracking import upsert_table_options
from specdb.executor.errors import DBExecuteError, success_payload
from specdb.executor.metadata_codec import encode_relations_payload
from specdb.executor.relationship_metadata import extract_relation_metadata
from specdb.executor.schema import (
    _assert_dict,
    _assert_valid_identifier,
    _auto_db_object_name,
    _build_column,
    _extract_change_tracking_options,
    _extract_relationship_options,
    _validate_module_options,
)
from specdb.executor.table_relationships import (
    append_postgres_foreign_key_constraints,
    ensure_postgres_foreign_keys_supported,
)

_LOGGER = logging.getLogger(__name__)


def _log_table_define_error(table_name: str, exc: SQLAlchemyError) -> None:
    message = f"specdb executor table.define failed for table {table_name}"
    if has_app_context():
        current_app.logger.exception(message)
        return
    _LOGGER.exception(message)


def _cleanup_failed_table_define(table: Table, table_name: str) -> None:
    try:
        with db.engine.begin() as conn:
            table.drop(bind=conn, checkfirst=True)
    except Exception:
        message = f"specdb executor cleanup failed after table.define error for table {table_name}"
        if has_app_context():
            current_app.logger.exception(message)
            return
        _LOGGER.exception(message)


def handle_table_define(table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    schema = payload.get("schema")
    schema = _assert_dict(schema, "payload.schema")
    _validate_module_options(payload)
    strategy, _ = _extract_change_tracking_options(payload)
    relationship_options = _extract_relationship_options(payload)
    relations = extract_relation_metadata(schema, "payload.schema")
    ensure_postgres_foreign_keys_supported(
        enabled=bool(relationship_options.get("postgres_foreign_keys", False)),
        strategy=strategy,
    )

    columns = [_build_column(name, _assert_dict(spec, f"schema.{name}")) for name, spec in schema.items()]
    if not columns:
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.schema cannot be empty")
    if strategy == "update_with_compact_log" and not any(column.primary_key for column in columns):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            "update_with_compact_log requires at least one primary key column",
            {"table": table_name},
        )

    if strategy == "append_only_versioned":
        for name, spec in schema.items():
            column_spec = _assert_dict(spec, f"schema.{name}")
            if bool(column_spec.get("primary", False)):
                raise DBExecuteError(
                    "DB_SCHEMA_ERROR",
                    "append_only_versioned does not allow user primary key columns",
                    {"field": name},
                )
            if bool(column_spec.get("unique", False)):
                raise DBExecuteError(
                    "DB_SCHEMA_ERROR",
                    "append_only_versioned does not allow user unique columns",
                    {"field": name},
                )
        columns.extend(
            [
                Column("__wt_row_id", Integer, primary_key=True, autoincrement=True),
                Column("__wt_entity_id", String(64), nullable=False),
                Column("__wt_version", Integer, nullable=False),
                Column("__wt_is_current", Boolean, nullable=False, default=True),
                Column("__wt_is_deleted", Boolean, nullable=False, default=False),
                Column("__wt_op", String(16), nullable=False),
                Column("__wt_changed_at", DateTime(timezone=True), nullable=False),
            ]
        )

    table = Table(table_name, MetaData(), *columns)
    if relationship_options.get("postgres_foreign_keys"):
        append_postgres_foreign_key_constraints(table_name, table, relations)
    if strategy == "append_only_versioned":
        table.append_constraint(
            UniqueConstraint(
                table.c["__wt_entity_id"],
                table.c["__wt_version"],
                name=_auto_db_object_name(table_name, "uq_ent_ver"),
            )
        )
        Index(
            _auto_db_object_name(table_name, "ux_ent_cur"),
            table.c["__wt_entity_id"],
            unique=True,
            sqlite_where=table.c["__wt_is_current"].is_(True),
            postgresql_where=table.c["__wt_is_current"].is_(True),
        )
        Index(_auto_db_object_name(table_name, "idx_ent_cur"), table.c["__wt_entity_id"], table.c["__wt_is_current"])
        Index(_auto_db_object_name(table_name, "idx_ent_ver"), table.c["__wt_entity_id"], table.c["__wt_version"])
    indexes_raw = payload.get("indexes", [])
    if indexes_raw is None:
        indexes_raw = []
    if not isinstance(indexes_raw, list):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.indexes must be list")

    for item in indexes_raw:
        index_item = _assert_dict(item, "payload.indexes.item")
        index_name = index_item.get("name")
        keys = index_item.get("keys")
        unique = bool(index_item.get("unique", False))
        if not isinstance(index_name, str) or not isinstance(keys, list) or not keys:
            raise DBExecuteError("DB_SCHEMA_ERROR", "invalid index definition")
        if strategy == "append_only_versioned" and unique:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                "append_only_versioned does not allow unique indexes",
                {"index": index_name},
            )
        _assert_valid_identifier(index_name, "index.name")
        for key in keys:
            if key not in table.c:
                raise DBExecuteError("DB_SCHEMA_ERROR", f"index field not found: {key}", {"field": key})
        Index(index_name, *[table.c[key] for key in keys], unique=unique)

    created_table = False
    try:
        with db.engine.begin() as conn:
            table.create(bind=conn, checkfirst=False)
            created_table = True
            upsert_table_options(
                table_name,
                payload,
                relations_json=encode_relations_payload(relations),
                conn=conn,
            )
    except SQLAlchemyError as exc:
        if created_table:
            _cleanup_failed_table_define(table, table_name)
        _log_table_define_error(table_name, exc)
        raise DBExecuteError("DB_TABLE_OP_ERROR", "create table failed", {"table": table_name}) from exc
    except Exception as exc:
        if created_table:
            _cleanup_failed_table_define(table, table_name)
        raise DBExecuteError("DB_TABLE_OP_ERROR", "create table failed", {"table": table_name}) from exc
    return success_payload(
        {
            "action": "table.define",
            "table": table_name,
            "ok": True,
            "relations_recorded": sorted(relations.keys()),
            "postgres_foreign_keys": bool(relationship_options.get("postgres_foreign_keys", False)),
        }
    )
