"""Spec validation helpers for executor dispatch."""

from __future__ import annotations

from typing import Any

from specdb.executor.errors import DBExecuteError
from specdb.executor.schema import _assert_dict, _assert_public_table_name

VALID_ACTIONS = {
    "table.define",
    "table.alter",
    "table.drop",
    "table.backup",
    "table.list",
    "table.describe",
    "data.insert",
    "data.select",
    "data.history",
    "data.update",
    "data.delete",
}

SUPPORTED_ACTIONS = set(VALID_ACTIONS)
_TABLE_ACTIONS_WITH_TABLE = {"table.define", "table.alter", "table.drop", "table.backup", "table.describe"}
_WRITE_ACTIONS = {"data.update", "data.delete"}
_MODIFY_ALLOWED_KEYS = {"nullable", "default", "type", "length", "index", "unique"}
_MODIFY_UNSUPPORTED_KEYS = {"primary", "auto_increment", "rename_to"}


def validate_execute_spec(spec: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    spec = _assert_dict(spec, "spec")
    action = spec.get("action")
    if not isinstance(action, str):
        raise DBExecuteError("DB_SCHEMA_ERROR", "action is required")
    if action not in VALID_ACTIONS:
        raise DBExecuteError("DB_ACTION_NOT_SUPPORTED", f"unsupported action: {action}", {"action": action})
    if action not in SUPPORTED_ACTIONS:
        raise DBExecuteError("DB_ACTION_NOT_SUPPORTED", f"action is not enabled: {action}", {"action": action})

    payload = spec.get("payload", {})
    payload = _assert_dict(payload, "payload")
    options = spec.get("options", {})
    options = _assert_dict(options, "options")

    _validate_table_name_requirement(action, spec.get("table"))
    _validate_common_options(options)
    if action.startswith("table."):
        _validate_table_action_spec(action, payload)
    else:
        _validate_data_action_spec(action, payload, options)
    return action, options


def ensure_write_query(payload: dict[str, Any], options: dict[str, Any]) -> dict[str, Any]:
    allow_full_table = _read_bool_option(options, "allow_full_table", default=False)
    query = payload.get("query")
    if query is None:
        if allow_full_table:
            return {}
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.query is required unless allow_full_table=true")
    query = _assert_dict(query, "payload.query")
    if not query and not allow_full_table:
        raise DBExecuteError("DB_SCHEMA_ERROR", "empty payload.query requires allow_full_table=true")
    return query


def _validate_table_name_requirement(action: str, table_name: Any) -> None:
    if action == "table.list":
        return
    if not isinstance(table_name, str):
        raise DBExecuteError("DB_SCHEMA_ERROR", "table is required", {"action": action})
    _assert_public_table_name(table_name, "table")


def _validate_common_options(options: dict[str, Any]) -> None:
    _validate_optional_int(options, "limit", minimum=1)
    _validate_optional_int(options, "offset", minimum=0)
    _validate_optional_int(options, "version_limit", minimum=1)
    _validate_optional_int(options, "version_offset", minimum=0)
    _validate_optional_bool(options, "include_total")
    _validate_optional_bool(options, "allow_full_table")
    _validate_optional_order_by(options.get("order_by"))


def _validate_table_action_spec(action: str, payload: dict[str, Any]) -> None:
    if action == "table.list":
        return
    if action == "table.define":
        schema = payload.get("schema")
        schema = _assert_dict(schema, "payload.schema")
        if not schema:
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.schema cannot be empty")
        indexes = payload.get("indexes")
        if indexes is not None and not isinstance(indexes, list):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.indexes must be list")
        module_options = payload.get("module_options")
        if module_options is not None:
            _assert_dict(module_options, "payload.module_options")
        return
    if action == "table.alter":
        add_spec = payload.get("add")
        modify_spec = payload.get("modify")
        drop_spec = payload.get("drop")
        if add_spec is not None and not isinstance(add_spec, dict):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.add must be object")
        if modify_spec is not None and not isinstance(modify_spec, dict):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.modify must be object")
        if drop_spec is not None and not isinstance(drop_spec, list):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.drop must be array")
        if not (add_spec or modify_spec or drop_spec):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload must include at least one of add/modify/drop")
        if isinstance(modify_spec, dict):
            _validate_modify_shape(modify_spec)
        return
    if action == "table.drop":
        _validate_optional_bool(payload, "if_exists")
        return
    if action == "table.backup":
        target_table = payload.get("target_table")
        if not isinstance(target_table, str):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.target_table is required")
        _assert_public_table_name(target_table, "payload.target_table")
        return
    if action == "table.describe":
        return


def _validate_data_action_spec(action: str, payload: dict[str, Any], options: dict[str, Any]) -> None:
    if action == "data.insert":
        _assert_dict(payload.get("data"), "payload.data")
        return
    if action == "data.select":
        query = payload.get("query")
        if query is not None:
            _assert_dict(query, "payload.query")
        return
    if action == "data.history":
        query = payload.get("query")
        if query is not None:
            _assert_dict(query, "payload.query")
        entity_id = payload.get("entity_id")
        if entity_id is not None and (not isinstance(entity_id, str) or not entity_id.strip()):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.entity_id must be non-empty string")
        if entity_id is not None and isinstance(query, dict) and query:
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.entity_id and payload.query cannot be used together")
        _validate_optional_bool(payload, "include_deleted")
        version_order = payload.get("version_order")
        if version_order is not None and version_order not in {"asc", "desc"}:
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.version_order must be asc|desc")
        return
    if action in _WRITE_ACTIONS:
        if action == "data.update":
            _assert_dict(payload.get("data"), "payload.data")
        query = payload.get("query")
        if query is not None:
            _assert_dict(query, "payload.query")
        ensure_write_query(payload, options)
        return


def _validate_modify_shape(modify_spec: dict[str, Any]) -> None:
    for field_name, raw_spec in modify_spec.items():
        if not isinstance(field_name, str):
            raise DBExecuteError("DB_SCHEMA_ERROR", "payload.modify field name must be string")
        field_spec = _assert_dict(raw_spec, f"payload.modify.{field_name}")
        if not field_spec:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"payload.modify.{field_name} cannot be empty", {"field": field_name})
        unsupported_keys = sorted(set(field_spec.keys()) & _MODIFY_UNSUPPORTED_KEYS)
        if unsupported_keys:
            raise DBExecuteError(
                "DB_ACTION_NOT_SUPPORTED",
                f"modify does not support key '{unsupported_keys[0]}' in first phase",
                {"field": field_name, "key": unsupported_keys[0]},
            )
        unknown_keys = sorted(set(field_spec.keys()) - _MODIFY_ALLOWED_KEYS - _MODIFY_UNSUPPORTED_KEYS)
        if unknown_keys:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{field_name} contains unknown key: {unknown_keys[0]}",
                {"field": field_name, "key": unknown_keys[0]},
            )
        if "nullable" in field_spec and not isinstance(field_spec["nullable"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{field_name}.nullable must be bool",
                {"field": field_name},
            )
        if "type" in field_spec and not isinstance(field_spec["type"], str):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{field_name}.type must be string",
                {"field": field_name},
            )
        if "length" in field_spec:
            _validate_positive_int(field_spec["length"], f"payload.modify.{field_name}.length")
        if "index" in field_spec and not isinstance(field_spec["index"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{field_name}.index must be bool",
                {"field": field_name},
            )
        if "unique" in field_spec and not isinstance(field_spec["unique"], bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"payload.modify.{field_name}.unique must be bool",
                {"field": field_name},
            )
        if "default" in field_spec and isinstance(field_spec["default"], dict):
            default_spec = field_spec["default"]
            if set(default_spec.keys()) != {"drop"} or default_spec.get("drop") is not True:
                raise DBExecuteError(
                    "DB_SCHEMA_ERROR",
                    f"payload.modify.{field_name}.default only supports literal values or {{\"drop\": true}}",
                    {"field": field_name},
                )


def _validate_optional_int(container: dict[str, Any], key: str, *, minimum: int) -> None:
    if key not in container:
        return
    _validate_positive_int(container[key], key, minimum=minimum)


def _validate_positive_int(value: Any, field_name: str, *, minimum: int = 1) -> None:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        comparator = "positive integer" if minimum > 0 else "non-negative integer"
        raise DBExecuteError("DB_SCHEMA_ERROR", f"{field_name} must be {comparator}", {"field": field_name, "value": value})


def _validate_optional_bool(container: dict[str, Any], key: str) -> None:
    if key not in container:
        return
    if not isinstance(container[key], bool):
        raise DBExecuteError("DB_SCHEMA_ERROR", f"{key} must be bool", {"field": key, "value": container[key]})


def _validate_optional_order_by(value: Any) -> None:
    if value is None:
        return
    if not isinstance(value, list):
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.order_by must be array")
    for item in value:
        if not isinstance(item, str):
            raise DBExecuteError("DB_SCHEMA_ERROR", "options.order_by items must be strings")


def _read_bool_option(options: dict[str, Any], key: str, *, default: bool) -> bool:
    if key not in options:
        return default
    value = options[key]
    if not isinstance(value, bool):
        raise DBExecuteError("DB_SCHEMA_ERROR", f"{key} must be bool", {"field": key, "value": value})
    return value
