"""data.* action handlers."""

from __future__ import annotations

from datetime import datetime, timezone
import logging
import uuid
from typing import Any

from flask import current_app, has_app_context
from sqlalchemy import MetaData, Table, and_, asc, desc, func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from specdb.db_runtime import db
from specdb.executor.change_tracking import (
    append_only_current_filters,
    assert_tracking_strategy_supported,
    build_inserted_primary_key,
    business_columns,
    get_table_tracking_strategy,
    is_append_only_strategy,
    row_to_jsonable,
    write_change_logs,
)
from specdb.executor.errors import DBExecuteError, success_payload
from specdb.executor.query import _build_filters, _parse_order_by
from specdb.executor.schema import _assert_dict, _assert_public_table_name
from specdb.executor.spec_validation import ensure_write_query
from specdb.executor.values import _APPEND_ONLY_COLUMNS, _normalize_row_data

_LOGGER = logging.getLogger(__name__)


def _log_sqlalchemy_error(action: str, table_name: str, exc: SQLAlchemyError) -> None:
    message = f"specdb executor {action} failed for table {table_name}"
    if has_app_context():
        current_app.logger.exception(message)
        return
    _LOGGER.exception(message)


def execute_data_action(
    action: str,
    spec: dict[str, Any],
    options: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    table_name = spec.get("table")
    payload = spec.get("payload", {})
    payload = _assert_dict(payload, "payload")

    if not isinstance(table_name, str):
        raise DBExecuteError("DB_SCHEMA_ERROR", "table 必填")
    _assert_public_table_name(table_name, "table")

    try:
        table = Table(table_name, MetaData(), autoload_with=db.engine)
    except SQLAlchemyError as exc:
        _log_sqlalchemy_error("table.autoload", table_name, exc)
        raise DBExecuteError("DB_TABLE_OP_ERROR", f"表不存在: {table_name}", {"table": table_name}) from exc

    if action == "data.insert":
        return handle_data_insert(table, payload, session=session)
    if action == "data.select":
        return handle_data_select(table, payload, options, session=session)
    if action == "data.history":
        return handle_data_history(table, payload, options, session=session)
    if action == "data.update":
        return handle_data_update(table, payload, options, session=session)
    if action == "data.delete":
        return handle_data_delete(table, payload, options, session=session)
    raise DBExecuteError("DB_ACTION_NOT_SUPPORTED", f"暂不支持动作: {action}", {"action": action})


def handle_data_insert(table: Table, payload: dict[str, Any], *, session: Session | None = None) -> dict[str, Any]:
    data = payload.get("data")
    data = _assert_dict(data, "payload.data")
    normalized_data = _normalize_row_data(table, data, "payload.data")

    session_obj: Session = session or db.session
    manage_transaction = session is None
    strategy = get_table_tracking_strategy(table.name, session=session_obj)
    assert_tracking_strategy_supported(table, strategy)
    try:
        if is_append_only_strategy(strategy):
            row_data = dict(normalized_data)
            now = datetime.now(timezone.utc)
            row_data.update(
                {
                    "__wt_entity_id": uuid.uuid4().hex,
                    "__wt_version": 1,
                    "__wt_is_current": True,
                    "__wt_is_deleted": False,
                    "__wt_op": "insert",
                    "__wt_changed_at": now,
                }
            )
            result = session_obj.execute(table.insert().values(**row_data))
        else:
            result = session_obj.execute(table.insert().values(**normalized_data))

        if strategy == "update_with_compact_log":
            pk_columns = [col.name for col in table.primary_key.columns]
            row_after: dict[str, Any] = dict(normalized_data)
            if pk_columns and result.inserted_primary_key and len(result.inserted_primary_key) == len(pk_columns):
                inserted_primary_key = {name: result.inserted_primary_key[idx] for idx, name in enumerate(pk_columns)}
                row_after = _load_inserted_row(table, session_obj, inserted_primary_key) or {
                    **row_after,
                    **inserted_primary_key,
                }
            write_change_logs(session_obj, table, "insert", rows_after=[row_after])

        if manage_transaction:
            session_obj.commit()
    except SQLAlchemyError as exc:
        if manage_transaction:
            session_obj.rollback()
        _log_sqlalchemy_error("data.insert", table.name, exc)
        raise DBExecuteError("DB_QUERY_ERROR", "insert failed", {"table": table.name}) from exc

    inserted_primary_key = build_inserted_primary_key(table, result.inserted_primary_key)
    inserted_id = None
    if inserted_primary_key is not None and len(inserted_primary_key) == 1:
        inserted_id = next(iter(inserted_primary_key.values()))
    affected_rows = int(result.rowcount or 0)
    if affected_rows <= 0:
        affected_rows = 1
    response: dict[str, Any] = {"inserted_id": inserted_id, "affected_rows": affected_rows}
    if inserted_primary_key is not None:
        response["inserted_primary_key"] = inserted_primary_key
    return success_payload(response)


def _load_inserted_row(table: Table, session: Session, row_key: dict[str, Any]) -> dict[str, Any] | None:
    filters = [table.c[key] == value for key, value in row_key.items() if key in table.c]
    if len(filters) != len(row_key) or not filters:
        return None
    row = session.execute(select(table).where(and_(*filters))).mappings().first()
    if row is None:
        return None
    return dict(row)


def handle_data_select(
    table: Table,
    payload: dict[str, Any],
    options: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    query = payload.get("query", {})
    if query is None:
        query = {}
    query = _assert_dict(query, "payload.query")

    limit = options.get("limit", 100)
    offset = options.get("offset", 0)
    include_total = bool(options.get("include_total", False))
    if not isinstance(limit, int) or limit <= 0:
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.limit must be positive integer")
    if limit > 1000:
        limit = 1000
    if not isinstance(offset, int) or offset < 0:
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.offset must be non-negative integer")

    session_obj: Session = session or db.session
    strategy = get_table_tracking_strategy(table.name, session=session_obj)
    filters = _build_filters(table, query)
    if is_append_only_strategy(strategy):
        filters.extend(append_only_current_filters(table))

    stmt = select(table)
    if filters:
        stmt = stmt.where(and_(*filters))

    order_by = _parse_order_by(table, options.get("order_by"))
    if order_by:
        stmt = stmt.order_by(*order_by)
    stmt = stmt.limit(limit).offset(offset)

    try:
        rows = session_obj.execute(stmt).mappings().all()
    except SQLAlchemyError as exc:
        _log_sqlalchemy_error("data.select", table.name, exc)
        raise DBExecuteError("DB_QUERY_ERROR", "query failed", {"table": table.name}) from exc

    items = [dict(row) for row in rows]
    if is_append_only_strategy(strategy):
        items = [{k: v for k, v in item.items() if k not in _APPEND_ONLY_COLUMNS} for item in items]
    items = [row_to_jsonable(item) for item in items]

    data: dict[str, Any] = {"items": items, "limit": limit, "offset": offset}
    if include_total:
        total_stmt = select(func.count()).select_from(table)
        if filters:
            total_stmt = total_stmt.where(and_(*filters))
        total = session_obj.execute(total_stmt).scalar_one()
        data["total"] = int(total)
    return success_payload(data)


def _history_row_payload(row: dict[str, Any]) -> dict[str, Any]:
    payload = {k: v for k, v in row.items() if k not in _APPEND_ONLY_COLUMNS}
    payload["_history"] = {
        "entity_id": row.get("__wt_entity_id"),
        "version": row.get("__wt_version"),
        "is_current": row.get("__wt_is_current"),
        "is_deleted": row.get("__wt_is_deleted"),
        "op": row.get("__wt_op"),
        "changed_at": row.get("__wt_changed_at"),
    }
    return row_to_jsonable(payload)


def handle_data_history(
    table: Table,
    payload: dict[str, Any],
    options: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    session_obj: Session = session or db.session
    strategy = get_table_tracking_strategy(table.name, session=session_obj)
    if not is_append_only_strategy(strategy):
        raise DBExecuteError(
            "DB_ACTION_NOT_SUPPORTED",
            "data.history only supports append_only_versioned tables",
            {"table": table.name, "strategy": strategy},
        )

    query = payload.get("query", {})
    if query is None:
        query = {}
    query = _assert_dict(query, "payload.query")
    entity_id = payload.get("entity_id")
    if entity_id is not None and (not isinstance(entity_id, str) or not entity_id.strip()):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.entity_id must be non-empty string")
    normalized_entity_id = entity_id.strip() if isinstance(entity_id, str) else None
    if normalized_entity_id is not None and query:
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.entity_id and payload.query cannot be used together")
    include_deleted = bool(payload.get("include_deleted", False))
    version_order = payload.get("version_order", "asc")
    if version_order not in {"asc", "desc"}:
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.version_order must be asc|desc")

    limit = options.get("limit", 100)
    offset = options.get("offset", 0)
    version_limit = options.get("version_limit")
    version_offset = options.get("version_offset", 0)
    include_total = bool(options.get("include_total", False))
    if not isinstance(limit, int) or limit <= 0:
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.limit must be positive integer")
    if limit > 1000:
        limit = 1000
    if not isinstance(offset, int) or offset < 0:
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.offset must be non-negative integer")
    if version_limit is not None:
        if not isinstance(version_limit, int) or version_limit <= 0:
            raise DBExecuteError("DB_SCHEMA_ERROR", "options.version_limit must be positive integer")
        if version_limit > 1000:
            version_limit = 1000
    if not isinstance(version_offset, int) or version_offset < 0:
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.version_offset must be non-negative integer")

    if normalized_entity_id is not None:
        entity_ids = [normalized_entity_id]
        filters: list[Any] = []
    else:
        filters = _build_filters(table, query)
        filters.append(table.c["__wt_is_current"].is_(True))
        if not include_deleted:
            filters.append(table.c["__wt_is_deleted"].is_(False))

        entity_stmt = select(table.c["__wt_entity_id"])
        if filters:
            entity_stmt = entity_stmt.where(and_(*filters))
        entity_stmt = entity_stmt.order_by(asc(table.c["__wt_entity_id"])).limit(limit).offset(offset)
        try:
            entity_ids = [row[0] for row in session_obj.execute(entity_stmt).all() if row and row[0] is not None]
        except SQLAlchemyError as exc:
            _log_sqlalchemy_error("data.history.entity_ids", table.name, exc)
            raise DBExecuteError("DB_QUERY_ERROR", "history query failed", {"table": table.name}) from exc

    grouped: dict[str, list[dict[str, Any]]] = {}
    if entity_ids:
        history_stmt = select(table).where(table.c["__wt_entity_id"].in_(entity_ids))
        if version_order == "asc":
            history_stmt = history_stmt.order_by(asc(table.c["__wt_entity_id"]), asc(table.c["__wt_version"]))
        else:
            history_stmt = history_stmt.order_by(asc(table.c["__wt_entity_id"]), desc(table.c["__wt_version"]))
        try:
            rows = [dict(row) for row in session_obj.execute(history_stmt).mappings().all()]
        except SQLAlchemyError as exc:
            _log_sqlalchemy_error("data.history.rows", table.name, exc)
            raise DBExecuteError("DB_QUERY_ERROR", "history query failed", {"table": table.name}) from exc
        for row in rows:
            current_entity_id = row.get("__wt_entity_id")
            if current_entity_id is None:
                continue
            grouped.setdefault(str(current_entity_id), []).append(_history_row_payload(row))

    entities = []
    for current_entity_id in entity_ids:
        all_versions = grouped.get(str(current_entity_id), [])
        if not all_versions:
            continue
        paged_versions = all_versions[version_offset:]
        if version_limit is not None:
            paged_versions = paged_versions[:version_limit]
        entities.append(
            {
                "entity_id": current_entity_id,
                "versions": paged_versions,
                "versions_total": len(all_versions),
                "version_limit": version_limit,
                "version_offset": version_offset,
            }
        )

    data: dict[str, Any] = {"items": entities, "limit": limit, "offset": offset}
    if include_total:
        if normalized_entity_id is None:
            total_stmt = select(func.count()).select_from(table)
            if filters:
                total_stmt = total_stmt.where(and_(*filters))
            total = session_obj.execute(total_stmt).scalar_one()
        else:
            total = len(entities)
        data["total"] = int(total)
    return success_payload(data)


def handle_data_update(
    table: Table,
    payload: dict[str, Any],
    options: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    data = payload.get("data")
    data = _assert_dict(data, "payload.data")
    normalized_data = _normalize_row_data(table, data, "payload.data")
    query = ensure_write_query(payload, options)
    filters = _build_filters(table, query) if query else []

    session_obj: Session = session or db.session
    manage_transaction = session is None
    strategy = get_table_tracking_strategy(table.name, session=session_obj)
    assert_tracking_strategy_supported(table, strategy)
    try:
        if is_append_only_strategy(strategy):
            filters_with_current = list(filters) + append_only_current_filters(table)
            before_stmt = select(table)
            if filters_with_current:
                before_stmt = before_stmt.where(and_(*filters_with_current))
            before_rows = [dict(row) for row in session_obj.execute(before_stmt).mappings().all()]

            for row in before_rows:
                session_obj.execute(table.update().where(table.c["__wt_row_id"] == row["__wt_row_id"]).values(__wt_is_current=False))
                next_row = {key: row.get(key) for key in business_columns(table)}
                next_row.update(normalized_data)
                next_row.update(
                    {
                        "__wt_entity_id": row["__wt_entity_id"],
                        "__wt_version": int(row["__wt_version"]) + 1,
                        "__wt_is_current": True,
                        "__wt_is_deleted": False,
                        "__wt_op": "update",
                        "__wt_changed_at": datetime.now(timezone.utc),
                    }
                )
                session_obj.execute(table.insert().values(**next_row))
            affected_rows = len(before_rows)
        else:
            stmt = table.update().values(**normalized_data)
            if filters:
                stmt = stmt.where(and_(*filters))

            before_rows: list[dict[str, Any]] = []
            if strategy == "update_with_compact_log":
                before_stmt = select(table)
                if filters:
                    before_stmt = before_stmt.where(and_(*filters))
                before_rows = [dict(row) for row in session_obj.execute(before_stmt).mappings().all()]

            result = session_obj.execute(stmt)
            affected_rows = int(result.rowcount or 0)

            if strategy == "update_with_compact_log" and before_rows:
                write_change_logs(session_obj, table, "update", rows_before=before_rows, update_data=normalized_data, query=query)

        if manage_transaction:
            session_obj.commit()
    except SQLAlchemyError as exc:
        if manage_transaction:
            session_obj.rollback()
        _log_sqlalchemy_error("data.update", table.name, exc)
        raise DBExecuteError("DB_QUERY_ERROR", "update failed", {"table": table.name}) from exc
    return success_payload({"affected_rows": affected_rows})


def handle_data_delete(
    table: Table,
    payload: dict[str, Any],
    options: dict[str, Any],
    *,
    session: Session | None = None,
) -> dict[str, Any]:
    query = ensure_write_query(payload, options)
    filters = _build_filters(table, query) if query else []

    session_obj: Session = session or db.session
    manage_transaction = session is None
    strategy = get_table_tracking_strategy(table.name, session=session_obj)
    assert_tracking_strategy_supported(table, strategy)
    try:
        if is_append_only_strategy(strategy):
            filters_with_current = list(filters) + append_only_current_filters(table)
            before_stmt = select(table)
            if filters_with_current:
                before_stmt = before_stmt.where(and_(*filters_with_current))
            before_rows = [dict(row) for row in session_obj.execute(before_stmt).mappings().all()]

            for row in before_rows:
                session_obj.execute(table.update().where(table.c["__wt_row_id"] == row["__wt_row_id"]).values(__wt_is_current=False))
                tombstone_row = {key: row.get(key) for key in business_columns(table)}
                tombstone_row.update(
                    {
                        "__wt_entity_id": row["__wt_entity_id"],
                        "__wt_version": int(row["__wt_version"]) + 1,
                        "__wt_is_current": True,
                        "__wt_is_deleted": True,
                        "__wt_op": "delete",
                        "__wt_changed_at": datetime.now(timezone.utc),
                    }
                )
                session_obj.execute(table.insert().values(**tombstone_row))
            affected_rows = len(before_rows)
        else:
            stmt = table.delete()
            if filters:
                stmt = stmt.where(and_(*filters))

            before_rows: list[dict[str, Any]] = []
            if strategy == "update_with_compact_log":
                before_stmt = select(table)
                if filters:
                    before_stmt = before_stmt.where(and_(*filters))
                before_rows = [dict(row) for row in session_obj.execute(before_stmt).mappings().all()]

            result = session_obj.execute(stmt)
            affected_rows = int(result.rowcount or 0)

            if strategy == "update_with_compact_log" and before_rows:
                write_change_logs(session_obj, table, "delete", rows_before=before_rows, query=query)

        if manage_transaction:
            session_obj.commit()
    except SQLAlchemyError as exc:
        if manage_transaction:
            session_obj.rollback()
        _log_sqlalchemy_error("data.delete", table.name, exc)
        raise DBExecuteError("DB_QUERY_ERROR", "delete failed", {"table": table.name}) from exc
    return success_payload({"affected_rows": affected_rows})
