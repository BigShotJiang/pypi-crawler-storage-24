"""Query parsing helpers used by the executor."""

from __future__ import annotations

from typing import Any

from sqlalchemy import Table, asc, desc

from .errors import DBExecuteError
from .schema import _assert_valid_identifier
from .values import _coerce_value_for_column

_SUPPORTED_OPERATORS = {
    "eq",
    "ne",
    "gt",
    "gte",
    "lt",
    "lte",
    "in",
    "not_in",
    "like",
    "between",
}


def _parse_query_key(raw_key: str) -> tuple[str, str]:
    if "$" in raw_key:
        key, op = raw_key.split("$", 1)
    else:
        key, op = raw_key, "eq"

    _assert_valid_identifier(key, "query.key")
    if op not in _SUPPORTED_OPERATORS:
        raise DBExecuteError("DB_SCHEMA_ERROR", f"不支持的查询操作符: {op}", {"op": op})
    return key, op


def _build_filters(table: Table, query: dict[str, Any]) -> list[Any]:
    filters: list[Any] = []
    for raw_key, value in query.items():
        key, op = _parse_query_key(raw_key)
        if key not in table.c:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"字段不存在: {key}", {"field": key})
        column = table.c[key]

        if op == "eq":
            filters.append(column == _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "ne":
            filters.append(column != _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "gt":
            filters.append(column > _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "gte":
            filters.append(column >= _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "lt":
            filters.append(column < _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "lte":
            filters.append(column <= _coerce_value_for_column(column, value, f"query.{raw_key}"))
        elif op == "in":
            if not isinstance(value, list):
                raise DBExecuteError("DB_SCHEMA_ERROR", "in 操作符值必须是数组")
            filters.append(column.in_([_coerce_value_for_column(column, item, f"query.{raw_key}") for item in value]))
        elif op == "not_in":
            if not isinstance(value, list):
                raise DBExecuteError("DB_SCHEMA_ERROR", "not_in 操作符值必须是数组")
            filters.append(~column.in_([_coerce_value_for_column(column, item, f"query.{raw_key}") for item in value]))
        elif op == "like":
            filters.append(column.like(_coerce_value_for_column(column, value, f"query.{raw_key}")))
        elif op == "between":
            if not isinstance(value, list) or len(value) != 2:
                raise DBExecuteError("DB_SCHEMA_ERROR", "between 操作符值必须是双元素数组")
            filters.append(
                column.between(
                    _coerce_value_for_column(column, value[0], f"query.{raw_key}"),
                    _coerce_value_for_column(column, value[1], f"query.{raw_key}"),
                )
            )
    return filters


def _parse_order_by(table: Table, raw_order_by: Any) -> list[Any]:
    if raw_order_by is None:
        return []
    if not isinstance(raw_order_by, list):
        raise DBExecuteError("DB_SCHEMA_ERROR", "options.order_by 必须是数组")
    result = []
    for item in raw_order_by:
        if not isinstance(item, str):
            raise DBExecuteError("DB_SCHEMA_ERROR", "options.order_by 项必须是字符串")
        if ":" in item:
            key, direction = item.split(":", 1)
        else:
            key, direction = item, "asc"
        _assert_valid_identifier(key, "order_by.key")
        if key not in table.c:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"排序字段不存在: {key}", {"field": key})
        direction = direction.lower()
        if direction == "asc":
            result.append(asc(table.c[key]))
        elif direction == "desc":
            result.append(desc(table.c[key]))
        else:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"排序方向非法: {direction}", {"direction": direction})
    return result
