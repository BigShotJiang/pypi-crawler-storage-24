"""Helpers for table.describe and backup contract payloads."""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import Boolean, Column, Float, Integer, Table, UniqueConstraint

_POSTGRES_DEFAULT_CAST_RE = re.compile(r"::[\w\s\[\]\.\"]+$")


def strip_reflected_default_wrappers(raw_default: str) -> str:
    normalized = raw_default.strip()
    while normalized.startswith("(") and normalized.endswith(")"):
        candidate = normalized[1:-1].strip()
        if not candidate:
            break
        normalized = candidate
    normalized = _POSTGRES_DEFAULT_CAST_RE.sub("", normalized).strip()
    return normalized


def parse_reflected_default_literal(raw_default: str, column_type: Any) -> Any:
    normalized = strip_reflected_default_wrappers(raw_default)
    upper = normalized.upper()

    if upper == "NULL":
        return None
    if isinstance(column_type, Boolean):
        if upper in {"TRUE", "1"}:
            return True
        if upper in {"FALSE", "0"}:
            return False
    if isinstance(column_type, Integer):
        try:
            return int(normalized)
        except ValueError:
            return normalized
    if isinstance(column_type, Float):
        try:
            return float(normalized)
        except ValueError:
            return normalized
    if len(normalized) >= 2 and normalized.startswith("'") and normalized.endswith("'"):
        return normalized[1:-1].replace("''", "'")
    return normalized


def extract_reflected_default(column: Column[Any]) -> tuple[bool, Any]:
    server_default = getattr(column, "server_default", None)
    if server_default is None:
        return False, None
    raw_default = getattr(server_default, "arg", server_default)
    if hasattr(raw_default, "text"):
        raw_default = raw_default.text
    if raw_default is None:
        return False, None
    return True, parse_reflected_default_literal(str(raw_default), column.type)


def build_describe_columns_payload(table: Table, index_catalog: dict[str, Any]) -> list[dict[str, Any]]:
    locked_columns = set(index_catalog["locked_columns"])
    reflected_indexed_columns: set[str] = set()
    reflected_unique_columns: set[str] = set()

    for constraint in table.constraints:
        if not isinstance(constraint, UniqueConstraint):
            continue
        column_names = [column.name for column in constraint.columns]
        if len(column_names) == 1:
            reflected_unique_columns.add(column_names[0])
        else:
            locked_columns.update(column_names)

    for index in table.indexes:
        column_names = [column.name for column in index.columns]
        if len(column_names) == 1:
            if index.unique:
                reflected_unique_columns.add(column_names[0])
            else:
                reflected_indexed_columns.add(column_names[0])
        else:
            locked_columns.update(column_names)

    columns: list[dict[str, Any]] = []
    for column in table.columns:
        has_default, default_value = extract_reflected_default(column)
        columns.append(
            {
                "key": column.name,
                "type": str(column.type),
                "nullable": column.nullable,
                "primary": bool(column.primary_key),
                "has_default": has_default,
                "default": default_value,
                "indexed": bool(index_catalog["indexes"].get(column.name) or column.name in reflected_indexed_columns),
                "unique": bool(
                    index_catalog["unique_indexes"].get(column.name)
                    or index_catalog["unique_constraints"].get(column.name)
                    or column.name in reflected_unique_columns
                ),
                "contract_locked": column.name in locked_columns,
            }
        )
    return columns


def build_source_contract_payload(
    *,
    dialect_name: str,
    tracking_options: dict[str, Any],
    source_relations: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    return {
        "dialect": dialect_name,
        "change_tracking": {
            "strategy": tracking_options["change_tracking_strategy"],
            "retention_days": tracking_options["retention_days"],
        },
        "relationship_options": tracking_options.get("relationship_options", {"postgres_foreign_keys": False}),
        "relation_keys": sorted(source_relations.keys()),
    }
