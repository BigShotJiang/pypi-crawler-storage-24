"""Relationship metadata helpers for table definitions and dependency planning."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select

from specdb.db_runtime import db
from specdb.executor.metadata_codec import decode_relations_payload, encode_relations_payload
from specdb.executor.internal_tables import _TABLE_OPTIONS, ensure_internal_tables
from specdb.executor.schema import _assert_dict, _assert_public_table_name, _assert_valid_identifier

from .errors import DBExecuteError

_RELATION_KINDS = {"one_to_one", "many_to_one", "one_to_many", "many_to_many"}
_RELATION_ACTIONS = {"restrict", "cascade", "set_null", "no_action"}


def extract_relation_metadata(column_specs: dict[str, Any], field_name_prefix: str) -> dict[str, dict[str, Any]]:
    relations: dict[str, dict[str, Any]] = {}
    for field_name, raw_spec in column_specs.items():
        column_spec = _assert_dict(raw_spec, f"{field_name_prefix}.{field_name}")
        relation = column_spec.get("relation")
        if relation is None:
            continue
        relation_spec = _assert_dict(relation, f"{field_name_prefix}.{field_name}.relation")
        relations[field_name] = _normalize_relation_spec(field_name, relation_spec, field_name_prefix)
    return relations


def _normalize_relation_spec(field_name: str, relation_spec: dict[str, Any], field_name_prefix: str) -> dict[str, Any]:
    target_table = relation_spec.get("target_table")
    target_column = relation_spec.get("target_column")
    if not isinstance(target_table, str):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation.target_table is required",
            {"field": field_name},
        )
    if not isinstance(target_column, str):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation.target_column is required",
            {"field": field_name},
        )
    _assert_public_table_name(target_table, f"{field_name_prefix}.{field_name}.relation.target_table")
    _assert_valid_identifier(target_column, f"{field_name_prefix}.{field_name}.relation.target_column")

    kind = relation_spec.get("kind", "many_to_one")
    if kind not in _RELATION_KINDS:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation.kind is invalid",
            {"field": field_name, "kind": kind},
        )
    on_delete = relation_spec.get("on_delete", "restrict")
    if on_delete not in _RELATION_ACTIONS:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation.on_delete is invalid",
            {"field": field_name, "on_delete": on_delete},
        )
    on_update = relation_spec.get("on_update", "restrict")
    if on_update not in _RELATION_ACTIONS:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation.on_update is invalid",
            {"field": field_name, "on_update": on_update},
        )

    extra_keys = sorted(set(relation_spec.keys()) - {"target_table", "target_column", "kind", "on_delete", "on_update"})
    if extra_keys:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name_prefix}.{field_name}.relation contains unknown key: {extra_keys[0]}",
            {"field": field_name, "key": extra_keys[0]},
        )

    return {
        "field": field_name,
        "target_table": target_table,
        "target_column": target_column,
        "kind": kind,
        "on_delete": on_delete,
        "on_update": on_update,
    }


def get_table_relationships(table_name: str) -> dict[str, dict[str, Any]]:
    ensure_internal_tables()
    with db.engine.begin() as conn:
        row = (
            conn.execute(select(_TABLE_OPTIONS.c.relations_json).where(_TABLE_OPTIONS.c.table_name == table_name))
            .mappings()
            .first()
        )
    if row is None or not row.get("relations_json"):
        return {}
    raw_value = row["relations_json"]
    return decode_relations_payload(raw_value, table_name=table_name)


def get_all_table_relationships(table_names: list[str] | None = None) -> dict[str, dict[str, dict[str, Any]]]:
    ensure_internal_tables()
    stmt = select(_TABLE_OPTIONS.c.table_name, _TABLE_OPTIONS.c.relations_json)
    normalized_names: list[str] | None = None
    if table_names is not None:
        normalized_names = []
        for item in table_names:
            if not isinstance(item, str):
                continue
            table_name = item.strip()
            if not table_name:
                continue
            normalized_names.append(table_name)
        if not normalized_names:
            return {}
        stmt = stmt.where(_TABLE_OPTIONS.c.table_name.in_(normalized_names))

    with db.engine.begin() as conn:
        rows = conn.execute(stmt).mappings().all()

    relations_by_table = {
        str(row["table_name"]): decode_relations_payload(row.get("relations_json"), table_name=str(row["table_name"]))
        for row in rows
        if isinstance(row.get("table_name"), str)
    }
    if normalized_names is not None:
        for table_name in normalized_names:
            relations_by_table.setdefault(table_name, {})
    return relations_by_table


def upsert_table_relationships(table_name: str, relations: dict[str, dict[str, Any]], *, conn: Any | None = None) -> None:
    ensure_internal_tables()
    payload = encode_relations_payload(relations) or "{}"
    now = datetime.now(timezone.utc)
    values = {"relations_json": payload, "updated_at": now}

    def _apply(active_conn: Any) -> None:
        result = active_conn.execute(_TABLE_OPTIONS.update().where(_TABLE_OPTIONS.c.table_name == table_name).values(**values))
        if int(result.rowcount or 0) <= 0:
            active_conn.execute(
                _TABLE_OPTIONS.insert().values(
                    table_name=table_name,
                    change_tracking_strategy="none",
                    retention_days=None,
                    relations_json=payload,
                    relationship_options_json=None,
                    updated_at=now,
                )
            )

    if conn is not None:
        _apply(conn)
        return
    with db.engine.begin() as local_conn:
        _apply(local_conn)


def merge_relation_metadata(
    existing_relations: dict[str, dict[str, Any]],
    added_relations: dict[str, dict[str, Any]],
    dropped_columns: list[str],
) -> dict[str, dict[str, Any]]:
    merged = {key: dict(value) for key, value in existing_relations.items()}
    for column_name in dropped_columns:
        merged.pop(column_name, None)
    if added_relations:
        merged.update(added_relations)
    return merged


def build_table_dependency_plan(
    relations_by_table: dict[str, dict[str, dict[str, Any]]],
    *,
    preferred_order: list[str] | None = None,
) -> dict[str, Any]:
    nodes: list[str] = []
    if preferred_order:
        for item in preferred_order:
            if isinstance(item, str) and item not in nodes:
                nodes.append(item)
    for table_name in relations_by_table:
        if table_name not in nodes:
            nodes.append(table_name)

    dependencies = {table_name: set() for table_name in nodes}
    dependents = {table_name: set() for table_name in nodes}
    external_dependencies = {table_name: set() for table_name in nodes}
    self_references = {table_name: [] for table_name in nodes}
    node_set = set(nodes)
    order_index = {table_name: idx for idx, table_name in enumerate(nodes)}

    for table_name in nodes:
        relations = relations_by_table.get(table_name, {})
        for field_name, relation in relations.items():
            if not isinstance(relation, dict):
                continue
            target_table = relation.get("target_table")
            if not isinstance(target_table, str) or not target_table:
                continue
            if target_table == table_name:
                self_references[table_name].append(str(field_name))
                continue
            if target_table in node_set:
                dependencies[table_name].add(target_table)
                dependents[target_table].add(table_name)
            else:
                external_dependencies[table_name].add(target_table)

    indegree = {table_name: len(dependencies[table_name]) for table_name in nodes}
    ready = sorted((table_name for table_name in nodes if indegree[table_name] == 0), key=order_index.get)
    ordered: list[str] = []

    while ready:
        current = ready.pop(0)
        ordered.append(current)
        next_ready: list[str] = []
        for dependent in sorted(dependents[current], key=order_index.get):
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                next_ready.append(dependent)
        ready = sorted(ready + next_ready, key=order_index.get)

    cyclic_tables = [table_name for table_name in nodes if table_name not in ordered]
    ordered.extend(cyclic_tables)

    return {
        "table_order": ordered,
        "dependencies": {table_name: sorted(values) for table_name, values in dependencies.items()},
        "dependents": {table_name: sorted(values) for table_name, values in dependents.items()},
        "external_dependencies": {table_name: sorted(values) for table_name, values in external_dependencies.items()},
        "self_references": {table_name: sorted(values) for table_name, values in self_references.items()},
        "cyclic_tables": cyclic_tables,
        "has_cycles": bool(cyclic_tables),
    }


def summarize_table_relationships(
    table_name: str,
    *,
    relations_by_table: dict[str, dict[str, dict[str, Any]]] | None = None,
    preferred_order: list[str] | None = None,
) -> dict[str, Any]:
    if relations_by_table is None:
        relations_by_table = get_all_table_relationships()
    if table_name not in relations_by_table:
        relations_by_table = dict(relations_by_table)
        relations_by_table[table_name] = {}

    plan = build_table_dependency_plan(relations_by_table, preferred_order=preferred_order)
    own_relations = relations_by_table.get(table_name, {})
    dependency_details = []
    for field_name in sorted(own_relations):
        relation = own_relations[field_name]
        if not isinstance(relation, dict):
            continue
        dependency_details.append(
            {
                "field": field_name,
                "target_table": relation.get("target_table"),
                "target_column": relation.get("target_column"),
                "kind": relation.get("kind"),
                "on_delete": relation.get("on_delete"),
                "on_update": relation.get("on_update"),
            }
        )

    referenced_by_details = []
    for source_table, relations in relations_by_table.items():
        for field_name, relation in relations.items():
            if not isinstance(relation, dict):
                continue
            if relation.get("target_table") != table_name or source_table == table_name:
                continue
            referenced_by_details.append(
                {
                    "source_table": source_table,
                    "field": field_name,
                    "target_column": relation.get("target_column"),
                    "kind": relation.get("kind"),
                    "on_delete": relation.get("on_delete"),
                    "on_update": relation.get("on_update"),
                }
            )
    referenced_by_details.sort(key=lambda item: (item["source_table"], item["field"]))

    depends_on_tables = sorted(
        {
            item["target_table"]
            for item in dependency_details
            if isinstance(item.get("target_table"), str) and item["target_table"] != table_name
        }
    )
    referenced_by_tables = sorted({item["source_table"] for item in referenced_by_details})
    self_reference_fields = sorted(
        [
            item["field"]
            for item in dependency_details
            if isinstance(item.get("target_table"), str) and item["target_table"] == table_name
        ]
    )
    warnings: list[str] = []
    if depends_on_tables:
        warnings.append(f"restore/build depends on related tables: {', '.join(depends_on_tables)}")
    if referenced_by_tables:
        warnings.append(f"table is referenced by other tables: {', '.join(referenced_by_tables)}")
    external_dependencies = plan["external_dependencies"].get(table_name, [])
    if external_dependencies:
        warnings.append(f"some related target tables are outside current metadata scope: {', '.join(external_dependencies)}")
    if self_reference_fields:
        warnings.append(f"table contains self-referential relations: {', '.join(self_reference_fields)}")
    if table_name in plan["cyclic_tables"]:
        warnings.append("table participates in a relationship cycle; recommended order is partial")

    return {
        "depends_on_tables": depends_on_tables,
        "referenced_by_tables": referenced_by_tables,
        "dependency_details": dependency_details,
        "referenced_by_details": referenced_by_details,
        "self_reference_fields": self_reference_fields,
        "recommended_prerequisite_tables": plan["dependencies"].get(table_name, []),
        "external_dependencies": external_dependencies,
        "has_relation_cycle": table_name in plan["cyclic_tables"],
        "warnings": warnings,
    }
