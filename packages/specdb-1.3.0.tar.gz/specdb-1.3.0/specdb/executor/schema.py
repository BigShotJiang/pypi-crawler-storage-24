"""Schema and DDL helpers used by the executor."""

from __future__ import annotations

import hashlib
import re
from typing import Any

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Table, Text, text

from specdb.db_runtime import db

from .errors import DBExecuteError
from .internal_tables import is_internal_table_name

_VALID_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_RESERVED_PREFIX = "__wt_"
_SUPPORTED_TRACKING_STRATEGIES = {"none", "update_with_compact_log", "append_only_versioned"}


def _quote_identifier(identifier: str) -> str:
    return db.engine.dialect.identifier_preparer.quote_identifier(identifier)


def _auto_db_object_name(table_name: str, suffix: str, *, max_length: int = 63) -> str:
    candidate = f"{table_name}_{suffix}"
    if len(candidate) <= max_length:
        return candidate
    digest = hashlib.sha1(candidate.encode("utf-8")).hexdigest()[:8]
    head_length = max_length - len(suffix) - len(digest) - 2
    trimmed_table_name = table_name[: max(head_length, 1)]
    return f"{trimmed_table_name}_{suffix}_{digest}"


def _extract_change_tracking_options(payload: dict[str, Any]) -> tuple[str, int | None]:
    module_options = payload.get("module_options")
    if not isinstance(module_options, dict):
        return "none", None
    change_tracking = module_options.get("change_tracking")
    if not isinstance(change_tracking, dict):
        return "none", None
    strategy = change_tracking.get("strategy", "none")
    retention_days = change_tracking.get("retention_days")
    return strategy, retention_days


def _extract_relationship_options(payload: dict[str, Any]) -> dict[str, Any]:
    module_options = payload.get("module_options")
    if not isinstance(module_options, dict):
        return {"postgres_foreign_keys": False}
    relationships = module_options.get("relationships")
    if not isinstance(relationships, dict):
        return {"postgres_foreign_keys": False}
    return {"postgres_foreign_keys": bool(relationships.get("postgres_foreign_keys", False))}


def _table_has_primary_key(table: Table) -> bool:
    return any(True for _ in table.primary_key.columns)


def _assert_valid_identifier(value: str, field_name: str) -> None:
    if not isinstance(value, str) or not _VALID_IDENTIFIER_RE.fullmatch(value):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name} is invalid: {value}",
            {"field": field_name, "value": value},
        )


def _assert_public_table_name(value: str, field_name: str) -> None:
    _assert_valid_identifier(value, field_name)
    if is_internal_table_name(value):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name} cannot target internal table: {value}",
            {"field": field_name, "value": value},
        )


def _assert_dict(value: Any, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise DBExecuteError("DB_SCHEMA_ERROR", f"{field_name} must be object")
    return value


def _build_type(column_name: str, spec: dict[str, Any]) -> Any:
    dtype = spec.get("type")
    length = spec.get("length")
    if dtype == "int":
        return Integer
    if dtype == "str":
        if isinstance(length, int) and length > 0:
            if length > 2000:
                return Text
            return String(length)
        return String(255)
    if dtype == "bool":
        return Boolean
    if dtype == "datetime":
        return DateTime
    if dtype == "float":
        return Float
    if dtype == "text":
        return Text
    raise DBExecuteError(
        "DB_SCHEMA_ERROR",
        f"unsupported field type: {column_name}.{dtype}",
        {"field": column_name, "type": dtype},
    )


def _normalize_sqla_type(column_type: Any) -> Any:
    if isinstance(column_type, type):
        return column_type()
    return column_type


def _sql_literal(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    raise DBExecuteError(
        "DB_SCHEMA_ERROR",
        "default only supports null/bool/int/float/str",
        {"default": value},
    )


def _build_column(column_name: str, spec: dict[str, Any]) -> Column:
    _assert_valid_identifier(column_name, "column")

    if column_name.startswith(_RESERVED_PREFIX):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"field name uses reserved prefix: {column_name}",
            {"field": column_name, "reserved_prefix": _RESERVED_PREFIX},
        )

    column_type = _build_type(column_name, spec)
    kwargs: dict[str, Any] = {
        "nullable": bool(spec.get("nullable", True)),
        "primary_key": bool(spec.get("primary", False)),
        "unique": bool(spec.get("unique", False)),
    }

    if bool(spec.get("auto_increment", False)):
        kwargs["autoincrement"] = True
    if "default" in spec:
        value = spec.get("default")
        kwargs["default"] = value
        # Persist literal defaults in DDL so reflected tables keep the same semantics.
        kwargs["server_default"] = text(_sql_literal(value))

    return Column(column_name, column_type, **kwargs)


def _build_add_column_sql(
    column_name: str,
    spec: dict[str, Any],
    *,
    foreign_key_sql: str | None = None,
) -> str:
    _assert_valid_identifier(column_name, "column")
    if column_name.startswith(_RESERVED_PREFIX):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"field name uses reserved prefix: {column_name}",
            {"field": column_name, "reserved_prefix": _RESERVED_PREFIX},
        )
    if bool(spec.get("primary", False)):
        raise DBExecuteError("DB_SCHEMA_ERROR", "table.alter add does not support primary field", {"field": column_name})
    if bool(spec.get("unique", False)):
        raise DBExecuteError("DB_SCHEMA_ERROR", "table.alter add does not support unique field", {"field": column_name})
    if bool(spec.get("auto_increment", False)):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            "table.alter add does not support auto_increment field",
            {"field": column_name},
        )

    column_type = _normalize_sqla_type(_build_type(column_name, spec))
    compiled_type = column_type.compile(dialect=db.engine.dialect)
    chunks = [f"{_quote_identifier(column_name)} {compiled_type}"]
    if not bool(spec.get("nullable", True)):
        chunks.append("NOT NULL")
    if "default" in spec:
        chunks.append(f"DEFAULT {_sql_literal(spec.get('default'))}")
    if foreign_key_sql:
        chunks.append(foreign_key_sql)
    return " ".join(chunks)


def _rename_cloned_db_objects(table_name: str, target_table: str, target_table_def: Table) -> None:
    for constraint in target_table_def.constraints:
        name = getattr(constraint, "name", None)
        if not isinstance(name, str) or not name:
            continue
        if table_name in name:
            constraint.name = name.replace(table_name, target_table, 1)
        else:
            constraint.name = f"{target_table}_{name}"
    for index in target_table_def.indexes:
        if not isinstance(index.name, str) or not index.name:
            continue
        if table_name in index.name:
            index.name = index.name.replace(table_name, target_table, 1)
        else:
            index.name = f"{target_table}_{index.name}"


def _validate_module_options(payload: dict[str, Any]) -> None:
    module_options = payload.get("module_options")
    if module_options is None:
        return

    module_options = _assert_dict(module_options, "payload.module_options")
    allowed_top_keys = {"change_tracking", "relationships"}
    extra_keys = set(module_options.keys()) - allowed_top_keys
    if extra_keys:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            "module_options contains unknown keys",
            {"keys": sorted(extra_keys)},
        )

    change_tracking = module_options.get("change_tracking")
    if change_tracking is not None:
        change_tracking = _assert_dict(change_tracking, "payload.module_options.change_tracking")
        allowed_tracking_keys = {"strategy", "retention_days"}
        extra_tracking_keys = set(change_tracking.keys()) - allowed_tracking_keys
        if extra_tracking_keys:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                "change_tracking contains unknown keys",
                {"keys": sorted(extra_tracking_keys)},
            )

        strategy = change_tracking.get("strategy", "none")
        if strategy not in _SUPPORTED_TRACKING_STRATEGIES:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"change_tracking.strategy is invalid: {strategy}",
                {"strategy": strategy},
            )
        if "retention_days" in change_tracking:
            retention_days = change_tracking.get("retention_days")
            if not isinstance(retention_days, int) or retention_days <= 0:
                raise DBExecuteError(
                    "DB_SCHEMA_ERROR",
                    "retention_days must be positive integer",
                    {"retention_days": retention_days},
                )

    relationships = module_options.get("relationships")
    if relationships is not None:
        relationships = _assert_dict(relationships, "payload.module_options.relationships")
        allowed_relationship_keys = {"postgres_foreign_keys"}
        extra_relationship_keys = set(relationships.keys()) - allowed_relationship_keys
        if extra_relationship_keys:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                "relationships contains unknown keys",
                {"keys": sorted(extra_relationship_keys)},
            )
        if "postgres_foreign_keys" in relationships and not isinstance(relationships.get("postgres_foreign_keys"), bool):
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                "relationships.postgres_foreign_keys must be bool",
                {"postgres_foreign_keys": relationships.get("postgres_foreign_keys")},
            )
