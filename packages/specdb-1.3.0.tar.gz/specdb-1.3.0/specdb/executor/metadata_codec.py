"""Shared encoding and decoding helpers for executor metadata tables."""

from __future__ import annotations

import json
from typing import Any

from specdb.executor.errors import DBExecuteError


def encode_relations_payload(relations: dict[str, dict[str, Any]]) -> str | None:
    if not relations:
        return None
    return json.dumps(relations, ensure_ascii=False, sort_keys=True)


def decode_relations_payload(raw_value: Any, *, table_name: str | None = None) -> dict[str, dict[str, Any]]:
    payload = _decode_json_object(raw_value, field_name="relations_json", table_name=table_name)
    return {str(key): value for key, value in payload.items() if isinstance(value, dict)}


def decode_relationship_options_payload(raw_value: Any, *, table_name: str | None = None) -> dict[str, Any]:
    payload = _decode_json_object(raw_value, field_name="relationship_options_json", table_name=table_name)
    return {"postgres_foreign_keys": bool(payload.get("postgres_foreign_keys", False))}


def _decode_json_object(raw_value: Any, *, field_name: str, table_name: str | None = None) -> dict[str, Any]:
    if raw_value is None:
        return {}
    if not isinstance(raw_value, str):
        raise DBExecuteError(
            "DB_TABLE_OP_ERROR",
            f"invalid internal metadata: {field_name} must be JSON object string",
            {"table": table_name, "field": field_name},
        )
    if not raw_value.strip():
        return {}
    try:
        payload = json.loads(raw_value)
    except json.JSONDecodeError as exc:
        raise DBExecuteError(
            "DB_TABLE_OP_ERROR",
            f"invalid internal metadata JSON: {field_name}",
            {"table": table_name, "field": field_name, "error": str(exc)},
        ) from exc
    if not isinstance(payload, dict):
        raise DBExecuteError(
            "DB_TABLE_OP_ERROR",
            f"invalid internal metadata: {field_name} must decode to object",
            {"table": table_name, "field": field_name},
        )
    return payload
