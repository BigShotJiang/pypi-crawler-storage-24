"""Describe, backup, drop, and index introspection helpers for table actions."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Index, MetaData, Table, inspect, select
from sqlalchemy.exc import SQLAlchemyError

from specdb.db_runtime import db
from specdb.executor.change_tracking import delete_table_options, get_table_tracking_options
from specdb.executor.errors import DBExecuteError, success_payload
from specdb.executor.internal_tables import _CHANGE_LOG, _TABLE_OPTIONS, ensure_internal_tables
from specdb.executor.relationship_metadata import (
    build_table_dependency_plan,
    get_all_table_relationships,
    get_table_relationships,
    upsert_table_relationships,
    summarize_table_relationships,
)
from specdb.executor.schema import _assert_public_table_name, _auto_db_object_name, _quote_identifier, _rename_cloned_db_objects
from specdb.executor.table_contracts import build_describe_columns_payload, build_source_contract_payload
from specdb.ops_restore_audit_store import delete_restore_audits_for_table


def inspect_column_index_catalog(inspector: Any, table_name: str) -> dict[str, Any]:
    indexes: dict[str, set[str]] = {}
    unique_indexes: dict[str, set[str]] = {}
    unique_constraints: dict[str, set[str]] = {}
    locked_columns: set[str] = set()

    for item in inspector.get_indexes(table_name):
        column_names = item.get("column_names") or []
        if not column_names:
            continue
        if len(column_names) != 1:
            locked_columns.update(column_names)
            continue
        column_name = column_names[0]
        target = unique_indexes if bool(item.get("unique", False)) else indexes
        target.setdefault(column_name, set())
        name = item.get("name")
        if isinstance(name, str) and name:
            target[column_name].add(name)

    for item in inspector.get_unique_constraints(table_name):
        column_names = item.get("column_names") or []
        if not column_names:
            continue
        if len(column_names) != 1:
            locked_columns.update(column_names)
            continue
        column_name = column_names[0]
        unique_constraints.setdefault(column_name, set())
        name = item.get("name")
        if isinstance(name, str) and name:
            unique_constraints[column_name].add(name)

    return {
        "indexes": indexes,
        "unique_indexes": unique_indexes,
        "unique_constraints": unique_constraints,
        "locked_columns": locked_columns,
    }


def create_rebuild_indexes(conn: Any, final_table: Table, rebuild_indexes: list[dict[str, Any]]) -> None:
    for item in rebuild_indexes:
        column_names = item["column_names"]
        if any(column_name not in final_table.c for column_name in column_names):
            continue
        index_name = item.get("name")
        if not isinstance(index_name, str) or not index_name:
            suffix = "ux" if item["unique"] else "idx"
            index_name = _auto_db_object_name(final_table.name, f"{suffix}_{'_'.join(column_names)}")
        index = Index(index_name, *[final_table.c[column_name] for column_name in column_names], unique=item["unique"])
        index.create(bind=conn)


def handle_table_drop(table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    if_exists = bool(payload.get("if_exists", False))
    inspector = inspect(db.engine)
    table_exists = inspector.has_table(table_name)
    if not table_exists:
        if if_exists:
            return success_payload({"action": "table.drop", "table": table_name, "ok": True})
        raise DBExecuteError("DB_TABLE_OP_ERROR", f"table not found: {table_name}", {"table": table_name})

    table = Table(table_name, MetaData())
    try:
        with db.engine.begin() as conn:
            table.drop(bind=conn, checkfirst=False)
            ensure_internal_tables()
            delete_table_options(table_name, conn=conn)
            conn.execute(_CHANGE_LOG.delete().where(_CHANGE_LOG.c.table_name == table_name))
            delete_restore_audits_for_table(table_name, conn=conn)
    except SQLAlchemyError as exc:
        raise DBExecuteError("DB_TABLE_OP_ERROR", "drop table failed", {"error": str(exc)}) from exc
    return success_payload(
        {
            "action": "table.drop",
            "table": table_name,
            "ok": True,
            "cleanup": {
                "table_options_cleared": True,
                "change_logs_cleared": True,
                "restore_audits_cleared": True,
            },
        }
    )


def handle_table_describe(table_name: str) -> dict[str, Any]:
    inspector = inspect(db.engine)
    try:
        columns = inspector.get_columns(table_name)
    except SQLAlchemyError as exc:
        raise DBExecuteError("DB_TABLE_OP_ERROR", "describe table failed", {"error": str(exc)}) from exc
    if not columns:
        raise DBExecuteError("DB_TABLE_OP_ERROR", f"table not found or has no columns: {table_name}")
    table = Table(table_name, MetaData(), autoload_with=db.engine)
    index_catalog = inspect_column_index_catalog(inspector, table_name)
    relations_by_table = get_all_table_relationships()
    relation_summary = summarize_table_relationships(table_name, relations_by_table=relations_by_table)
    dependency_plan = build_table_dependency_plan(relations_by_table)
    tracking_options = get_table_tracking_options(table_name)
    return success_payload(
        {
            "table": table_name,
            "dialect": db.engine.dialect.name,
            "columns": build_describe_columns_payload(table, index_catalog),
            "change_tracking": {
                "strategy": tracking_options.get("change_tracking_strategy", "none"),
                "retention_days": tracking_options.get("retention_days"),
            },
            "relations": get_table_relationships(table_name),
            "relationship_options": tracking_options.get("relationship_options", {"postgres_foreign_keys": False}),
            "relation_summary": relation_summary,
            "recommended_table_order": dependency_plan["table_order"],
        }
    )


def handle_table_backup(table_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    target_table = payload.get("target_table")
    if not isinstance(target_table, str):
        raise DBExecuteError("DB_SCHEMA_ERROR", "payload.target_table is required")
    _assert_public_table_name(target_table, "payload.target_table")

    inspector = inspect(db.engine)
    if not inspector.has_table(table_name):
        raise DBExecuteError("DB_TABLE_OP_ERROR", f"table not found: {table_name}", {"table": table_name})
    if inspector.has_table(target_table):
        raise DBExecuteError(
            "DB_TABLE_OP_ERROR",
            f"target table already exists: {target_table}",
            {"target_table": target_table},
        )
    source_table = Table(table_name, MetaData(), autoload_with=db.engine)
    target_metadata = MetaData()
    target_table_def = source_table.to_metadata(target_metadata, name=target_table)
    _rename_cloned_db_objects(table_name, target_table, target_table_def)
    source_tracking = get_table_tracking_options(table_name)
    source_relations = get_table_relationships(table_name)
    target_columns = [column.name for column in target_table_def.columns]
    data_copy_stmt = target_table_def.insert().from_select(target_columns, select(*[source_table.c[name] for name in target_columns]))

    try:
        with db.engine.begin() as conn:
            target_table_def.create(bind=conn, checkfirst=False)
            conn.execute(data_copy_stmt)
            if (
                source_tracking["change_tracking_strategy"] != "none"
                or source_tracking.get("relationship_options_json") is not None
            ):
                now = datetime.now(timezone.utc)
                conn.execute(
                    _TABLE_OPTIONS.insert().values(
                        table_name=target_table,
                        change_tracking_strategy=source_tracking["change_tracking_strategy"],
                        retention_days=source_tracking["retention_days"],
                        relations_json=source_tracking.get("relations_json"),
                        relationship_options_json=source_tracking.get("relationship_options_json"),
                        updated_at=now,
                    )
                )
            elif source_relations:
                upsert_table_relationships(target_table, source_relations, conn=conn)
    except SQLAlchemyError as exc:
        raise DBExecuteError("DB_TABLE_OP_ERROR", "backup table failed", {"error": str(exc)}) from exc
    return success_payload(
        {
            "action": "table.backup",
            "table": table_name,
            "target_table": target_table,
            "ok": True,
            "copied_schema": True,
            "copied_indexes": True,
            "copied_data": True,
            "copied_tracking_options": source_tracking["change_tracking_strategy"] != "none",
            "copied_relationship_metadata": bool(source_relations),
            "copied_relationship_options": source_tracking.get("relationship_options_json") is not None,
            "source_contract": build_source_contract_payload(
                dialect_name=db.engine.dialect.name,
                tracking_options=source_tracking,
                source_relations=source_relations,
            ),
        }
    )
