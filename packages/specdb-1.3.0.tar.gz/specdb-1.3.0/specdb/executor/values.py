"""Value normalization helpers used by the executor."""

from __future__ import annotations

import base64
import json
import uuid
from datetime import date, datetime, time as dt_time, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import DateTime, Table

from .errors import DBExecuteError

_APPEND_ONLY_COLUMNS = {
    "__wt_row_id",
    "__wt_entity_id",
    "__wt_version",
    "__wt_is_current",
    "__wt_is_deleted",
    "__wt_op",
    "__wt_changed_at",
}


def _json_dumps(value: Any) -> str:
    def _default(obj: Any):
        if isinstance(obj, (datetime, date, dt_time)):
            return obj.isoformat()
        if isinstance(obj, Decimal):
            return str(obj)
        if isinstance(obj, uuid.UUID):
            return str(obj)
        if isinstance(obj, (bytes, bytearray, memoryview)):
            return base64.b64encode(bytes(obj)).decode("ascii")
        return str(obj)

    return json.dumps(value, ensure_ascii=False, default=_default)


def _coerce_datetime_value(value: Any, field_name: str, *, timezone_aware: bool) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str) and value.strip():
        try:
            parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        except ValueError as exc:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"{field_name} 必须是 ISO-8601 datetime 字符串",
                {"field": field_name, "value": value},
            ) from exc
    else:
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            f"{field_name} 必须是 datetime 或 ISO-8601 字符串",
            {"field": field_name, "value": value},
        )

    if timezone_aware:
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    if parsed.tzinfo is not None:
        return parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


def _coerce_value_for_column(column: Any, value: Any, field_name: str) -> Any:
    if isinstance(column.type, DateTime):
        return _coerce_datetime_value(value, field_name, timezone_aware=bool(getattr(column.type, "timezone", False)))
    return value


def _normalize_row_data(table: Table, data: dict[str, Any], field_name: str) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in data.items():
        if key not in table.c:
            raise DBExecuteError("DB_SCHEMA_ERROR", f"字段不存在: {key}", {"field": key})
        if key in _APPEND_ONLY_COLUMNS:
            raise DBExecuteError(
                "DB_SCHEMA_ERROR",
                f"{field_name}.{key} 不允许写入保留字段",
                {"field": key},
            )
        normalized[key] = _coerce_value_for_column(table.c[key], value, f"{field_name}.{key}")
    return normalized
