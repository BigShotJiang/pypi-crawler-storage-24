"""Change-tracking helpers for executor actions."""

from __future__ import annotations

from copy import deepcopy
import json
import uuid
from datetime import datetime, timezone
from typing import Any

from flask import g, has_app_context
from sqlalchemy import Table, select
from sqlalchemy.orm import Session

from specdb.db_runtime import db
from specdb.executor.errors import DBExecuteError
from specdb.executor.internal_tables import _CHANGE_LOG, _TABLE_OPTIONS, ensure_internal_tables
from specdb.executor.metadata_codec import decode_relationship_options_payload
from specdb.executor.schema import _extract_change_tracking_options, _extract_relationship_options, _table_has_primary_key
from specdb.executor.values import _APPEND_ONLY_COLUMNS, _json_dumps

_TRACKING_TABLES_READY_KEY = "_specdb_tracking_tables_ready"
_TRACKING_OPTIONS_CACHE_KEY = "_specdb_tracking_options_cache"


def _get_tracking_options_cache() -> dict[str, dict[str, Any]] | None:
    if not has_app_context():
        return None
    cache = getattr(g, _TRACKING_OPTIONS_CACHE_KEY, None)
    if cache is None:
        cache = {}
        setattr(g, _TRACKING_OPTIONS_CACHE_KEY, cache)
    return cache


def _invalidate_tracking_options_cache(table_name: str | None = None) -> None:
    cache = _get_tracking_options_cache()
    if cache is None:
        return
    if table_name is None:
        cache.clear()
        return
    cache.pop(table_name, None)


def ensure_tracking_tables() -> None:
    if has_app_context() and getattr(g, _TRACKING_TABLES_READY_KEY, False):
        return
    ensure_internal_tables()
    if has_app_context():
        setattr(g, _TRACKING_TABLES_READY_KEY, True)


def upsert_table_options(
    table_name: str,
    payload: dict[str, Any],
    *,
    relations_json: str | None = None,
    conn: Any | None = None,
) -> None:
    strategy, retention_days = _extract_change_tracking_options(payload)
    relationship_options = _extract_relationship_options(payload)
    relationship_options_json = None
    if relationship_options.get("postgres_foreign_keys"):
        relationship_options_json = json.dumps(relationship_options, ensure_ascii=False, sort_keys=True)
    ensure_tracking_tables()
    now = datetime.now(timezone.utc)
    values: dict[str, Any] = {
        "change_tracking_strategy": strategy,
        "retention_days": retention_days,
        "relationship_options_json": relationship_options_json,
        "updated_at": now,
    }
    if relations_json is not None:
        values["relations_json"] = relations_json
    if conn is not None:
        result = conn.execute(
            _TABLE_OPTIONS.update()
            .where(_TABLE_OPTIONS.c.table_name == table_name)
            .values(**values)
        )
        if int(result.rowcount or 0) <= 0:
            conn.execute(
                _TABLE_OPTIONS.insert().values(
                    table_name=table_name,
                    change_tracking_strategy=strategy,
                    retention_days=retention_days,
                    relations_json=relations_json,
                    relationship_options_json=relationship_options_json,
                    updated_at=now,
                )
            )
        _invalidate_tracking_options_cache(table_name)
        return

    with db.engine.begin() as local_conn:
        result = local_conn.execute(
            _TABLE_OPTIONS.update()
            .where(_TABLE_OPTIONS.c.table_name == table_name)
            .values(**values)
        )
        if int(result.rowcount or 0) <= 0:
            local_conn.execute(
                _TABLE_OPTIONS.insert().values(
                    table_name=table_name,
                    change_tracking_strategy=strategy,
                    retention_days=retention_days,
                    relations_json=relations_json,
                    relationship_options_json=relationship_options_json,
                    updated_at=now,
                )
            )
    _invalidate_tracking_options_cache(table_name)


def delete_table_options(table_name: str, *, conn: Any | None = None) -> None:
    ensure_tracking_tables()
    if conn is not None:
        conn.execute(_TABLE_OPTIONS.delete().where(_TABLE_OPTIONS.c.table_name == table_name))
        _invalidate_tracking_options_cache(table_name)
        return
    with db.engine.begin() as local_conn:
        local_conn.execute(_TABLE_OPTIONS.delete().where(_TABLE_OPTIONS.c.table_name == table_name))
    _invalidate_tracking_options_cache(table_name)


def get_table_tracking_options(
    table_name: str,
    *,
    session: Session | None = None,
    conn: Any | None = None,
) -> dict[str, Any]:
    ensure_tracking_tables()
    cache = _get_tracking_options_cache()
    if cache is not None and table_name in cache:
        return deepcopy(cache[table_name])
    if conn is not None:
        row = (
            conn.execute(select(_TABLE_OPTIONS).where(_TABLE_OPTIONS.c.table_name == table_name))
            .mappings()
            .first()
        )
    elif session is not None:
        row = (
            session.execute(select(_TABLE_OPTIONS).where(_TABLE_OPTIONS.c.table_name == table_name))
            .mappings()
            .first()
        )
    else:
        with db.engine.begin() as local_conn:
            row = (
                local_conn.execute(select(_TABLE_OPTIONS).where(_TABLE_OPTIONS.c.table_name == table_name))
                .mappings()
                .first()
            )
    if row is None:
        result = {
            "change_tracking_strategy": "none",
            "retention_days": None,
            "relations_json": None,
            "relationship_options_json": None,
            "relationship_options": {"postgres_foreign_keys": False},
        }
    else:
        relationship_options_json = row.get("relationship_options_json")
        relationship_options = {"postgres_foreign_keys": False}
        if isinstance(relationship_options_json, str) and relationship_options_json:
            relationship_options = decode_relationship_options_payload(
                relationship_options_json,
                table_name=table_name,
            )
        result = {
            "change_tracking_strategy": str(row.get("change_tracking_strategy") or "none"),
            "retention_days": row.get("retention_days"),
            "relations_json": row.get("relations_json"),
            "relationship_options_json": relationship_options_json,
            "relationship_options": relationship_options,
        }
    if cache is not None:
        cache[table_name] = deepcopy(result)
    return result


def get_table_tracking_strategy(
    table_name: str,
    *,
    session: Session | None = None,
    conn: Any | None = None,
) -> str:
    strategy = get_table_tracking_options(table_name, session=session, conn=conn).get("change_tracking_strategy")
    if not isinstance(strategy, str):
        return "none"
    return strategy


def assert_tracking_strategy_supported(table: Table, strategy: str) -> None:
    if strategy == "update_with_compact_log" and not _table_has_primary_key(table):
        raise DBExecuteError(
            "DB_SCHEMA_ERROR",
            "update_with_compact_log requires table primary key",
            {"table": table.name},
        )


def append_only_current_filters(table: Table) -> list[Any]:
    return [table.c["__wt_is_current"].is_(True), table.c["__wt_is_deleted"].is_(False)]


def business_columns(table: Table) -> list[str]:
    return [col.name for col in table.columns if col.name not in _APPEND_ONLY_COLUMNS]


def is_append_only_strategy(strategy: str) -> bool:
    return strategy == "append_only_versioned"


def row_to_jsonable(row: dict[str, Any]) -> dict[str, Any]:
    return json.loads(_json_dumps(row))


def build_row_key(table: Table, row: dict[str, Any]) -> dict[str, Any] | None:
    pk_columns = [col.name for col in table.primary_key.columns]
    if not pk_columns:
        return None
    key = {name: row.get(name) for name in pk_columns}
    return row_to_jsonable(key)


def build_inserted_primary_key(table: Table, values: Any) -> dict[str, Any] | None:
    pk_columns = [col.name for col in table.primary_key.columns]
    if not pk_columns or not values or len(values) != len(pk_columns):
        return None
    return row_to_jsonable({name: values[idx] for idx, name in enumerate(pk_columns)})


def write_change_logs(
    session: Session,
    table: Table,
    op: str,
    *,
    rows_before: list[dict[str, Any]] | None = None,
    update_data: dict[str, Any] | None = None,
    rows_after: list[dict[str, Any]] | None = None,
    query: dict[str, Any] | None = None,
) -> None:
    ensure_tracking_tables()
    now = datetime.now(timezone.utc)
    batch_id = uuid.uuid4().hex
    entries: list[dict[str, Any]] = []

    if op == "insert":
        for after_row in rows_after or []:
            entries.append(
                {
                    "batch_id": batch_id,
                    "table_name": table.name,
                    "op": op,
                    "row_key_json": _json_dumps(build_row_key(table, after_row)),
                    "before_json": None,
                    "after_json": _json_dumps(row_to_jsonable(after_row)),
                    "query_json": None,
                    "changed_at": now,
                }
            )
    elif op == "update":
        for before_row in rows_before or []:
            after_row = dict(before_row)
            after_row.update(update_data or {})
            entries.append(
                {
                    "batch_id": batch_id,
                    "table_name": table.name,
                    "op": op,
                    "row_key_json": _json_dumps(build_row_key(table, before_row)),
                    "before_json": _json_dumps(row_to_jsonable(before_row)),
                    "after_json": _json_dumps(row_to_jsonable(after_row)),
                    "query_json": _json_dumps(query or {}),
                    "changed_at": now,
                }
            )
    elif op == "delete":
        for before_row in rows_before or []:
            entries.append(
                {
                    "batch_id": batch_id,
                    "table_name": table.name,
                    "op": op,
                    "row_key_json": _json_dumps(build_row_key(table, before_row)),
                    "before_json": _json_dumps(row_to_jsonable(before_row)),
                    "after_json": None,
                    "query_json": _json_dumps(query or {}),
                    "changed_at": now,
                }
            )

    if entries:
        session.execute(_CHANGE_LOG.insert(), entries)
