"""DB ops 归档数据的持久化存储。"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, Text, func, inspect, select

from specdb.db_init_guard import EngineInitGuard
from specdb.db_runtime import db
from specdb.ops.store_common import _decode_json_object_strict, _json_default, _normalize_datetime_value

_metadata = MetaData()
_ops_archives_table = Table(
    "db_ops_archives",
    _metadata,
    Column("archive_id", String(128), primary_key=True),
    Column("job_id", String(128), nullable=False),
    Column("request_id", String(128), nullable=False),
    Column("snapshot_id", String(128), nullable=True),
    Column("item_count", Integer, nullable=False, default=0),
    Column("metadata_json", Text, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
)
_ops_archive_items_table = Table(
    "db_ops_archive_items",
    _metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("archive_id", String(128), nullable=False),
    Column("category", String(64), nullable=False),
    Column("table_name", String(128), nullable=False),
    Column("item_json", Text, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
)
_init_guard = EngineInitGuard()
def _serialize_row(row: dict[str, Any]) -> dict[str, Any]:
    data = dict(row)
    for key in ("created_at", "updated_at"):
        data[key] = _normalize_datetime_value(data.get(key))
    metadata_json = data.get("metadata_json")
    if isinstance(metadata_json, str):
        data["metadata"] = _decode_json_object_strict(
            metadata_json,
            field_name="metadata_json",
            entity_name="archive",
            entity_id=data.get("archive_id"),
        )
        data.pop("metadata_json", None)
    return data


def ensure_ops_archive_tables() -> None:
    engine = db.engine

    def _initializer() -> None:
        _metadata.create_all(bind=engine, tables=[_ops_archives_table, _ops_archive_items_table], checkfirst=True)

    def _is_initialized() -> bool:
        inspector = inspect(engine)
        return inspector.has_table(_ops_archives_table.name) and inspector.has_table(_ops_archive_items_table.name)

    _init_guard.ensure(engine, _initializer, is_initialized=_is_initialized)


def create_archive(
    archive_id: str,
    *,
    job_id: str,
    request_id: str,
    snapshot_id: str | None,
    metadata: dict[str, Any],
    conn: Any | None = None,
) -> None:
    ensure_ops_archive_tables()
    now = datetime.now(timezone.utc)
    values = dict(
        archive_id=archive_id,
        job_id=job_id,
        request_id=request_id,
        snapshot_id=snapshot_id,
        item_count=0,
        metadata_json=json.dumps(metadata, ensure_ascii=False, default=_json_default),
        created_at=now,
        updated_at=now,
    )
    if conn is not None:
        conn.execute(_ops_archives_table.insert().values(**values))
        return
    with db.engine.begin() as local_conn:
        local_conn.execute(_ops_archives_table.insert().values(**values))


def delete_archive(archive_id: str, *, conn: Any | None = None) -> None:
    ensure_ops_archive_tables()
    if conn is not None:
        conn.execute(_ops_archive_items_table.delete().where(_ops_archive_items_table.c.archive_id == archive_id))
        conn.execute(_ops_archives_table.delete().where(_ops_archives_table.c.archive_id == archive_id))
        return
    with db.engine.begin() as local_conn:
        local_conn.execute(_ops_archive_items_table.delete().where(_ops_archive_items_table.c.archive_id == archive_id))
        local_conn.execute(_ops_archives_table.delete().where(_ops_archives_table.c.archive_id == archive_id))


def append_archive_items(archive_id: str, items: list[dict[str, Any]], *, conn: Any | None = None) -> int:
    ensure_ops_archive_tables()
    if not items:
        return 0
    now = datetime.now(timezone.utc)
    rows = [
        {
            "archive_id": archive_id,
            "category": str(item["category"]),
            "table_name": str(item["table_name"]),
            "item_json": json.dumps(item["payload"], ensure_ascii=False, default=_json_default),
            "created_at": now,
        }
        for item in items
    ]
    if conn is not None:
        conn.execute(_ops_archive_items_table.insert(), rows)
        return len(rows)
    with db.engine.begin() as local_conn:
        local_conn.execute(_ops_archive_items_table.insert(), rows)
    return len(rows)


def update_archive(archive_id: str, *, item_count: int, metadata: dict[str, Any], conn: Any | None = None) -> None:
    ensure_ops_archive_tables()
    now = datetime.now(timezone.utc)
    if conn is not None:
        conn.execute(
            _ops_archives_table.update()
            .where(_ops_archives_table.c.archive_id == archive_id)
            .values(
                item_count=item_count,
                metadata_json=json.dumps(metadata, ensure_ascii=False, default=_json_default),
                updated_at=now,
            )
        )
        return
    with db.engine.begin() as local_conn:
        local_conn.execute(
            _ops_archives_table.update()
            .where(_ops_archives_table.c.archive_id == archive_id)
            .values(
                item_count=item_count,
                metadata_json=json.dumps(metadata, ensure_ascii=False, default=_json_default),
                updated_at=now,
            )
        )


def get_archive(archive_id: str) -> dict[str, Any] | None:
    ensure_ops_archive_tables()
    with db.engine.begin() as conn:
        row = conn.execute(
            select(_ops_archives_table).where(_ops_archives_table.c.archive_id == archive_id)
        ).mappings().first()
    if row is None:
        return None
    return _serialize_row(dict(row))


def get_archive_item_count(archive_id: str) -> int:
    ensure_ops_archive_tables()
    with db.engine.begin() as conn:
        total = conn.execute(
            select(func.count())
            .select_from(_ops_archive_items_table)
            .where(_ops_archive_items_table.c.archive_id == archive_id)
        ).scalar()
    return int(total or 0)
