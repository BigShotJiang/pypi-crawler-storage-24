"""按 SQLAlchemy engine 粒度做线程安全一次性初始化的辅助工具。"""

from __future__ import annotations

from threading import Lock
from typing import Any, Callable


class EngineInitGuard:
    """为每个 engine 实例线程安全地执行一次初始化。"""

    def __init__(self) -> None:
        self._lock = Lock()
        self._initialized_engine_ids: set[int] = set()

    def ensure(
        self,
        engine: Any,
        initializer: Callable[[], None],
        *,
        is_initialized: Callable[[], bool] | None = None,
    ) -> None:
        engine_id = id(engine)
        with self._lock:
            if engine_id in self._initialized_engine_ids:
                if is_initialized is None or is_initialized():
                    return
                self._initialized_engine_ids.discard(engine_id)
            initializer()
            if is_initialized is None or is_initialized():
                self._initialized_engine_ids.add(engine_id)
