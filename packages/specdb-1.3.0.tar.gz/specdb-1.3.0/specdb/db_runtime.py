﻿"""数据库运行时初始化。"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# 全局数据库对象，供模型和服务层复用。
db = SQLAlchemy()


def _validate_database_uri_config(app: Flask) -> None:
    database_uri = app.config.get("SQLALCHEMY_DATABASE_URI")
    if isinstance(database_uri, str) and database_uri.strip():
        return
    raise ValueError(
        "SQLALCHEMY_DATABASE_URI must be non-empty; set DATABASE_URL in production or provide a valid database URI"
    )


def init_db(app: Flask) -> None:
    """初始化 SQLAlchemy，并在启动时完成连通性检查。"""
    _validate_database_uri_config(app)
    extension = app.extensions.get("sqlalchemy")
    if extension is None:
        db.init_app(app)
    elif extension is not db:
        raise RuntimeError(
            "A different SQLAlchemy instance has already been registered on this Flask app."
        )

    # 启动时执行最小连通性检查，尽早暴露配置错误。
    with app.app_context():
        db.session.execute(db.text("SELECT 1"))

