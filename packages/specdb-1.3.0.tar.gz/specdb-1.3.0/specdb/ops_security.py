"""DB ops 路由安全校验的共享辅助函数。"""

from __future__ import annotations

from typing import Any, Callable

from flask import Flask

_OPS_SECURITY_WARNING_KEY = "specdb_missing_ops_auth_warning_emitted"


def coerce_config_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        return default
    if value is None:
        return default
    return bool(value)


def _is_production_like_app(app: Flask) -> bool:
    if bool(app.testing):
        return False
    for key in ("APP_ENV", "ENV", "FLASK_ENV"):
        raw = app.config.get(key)
        if not isinstance(raw, str):
            continue
        normalized = raw.strip().lower()
        if normalized in {"production", "prod"}:
            return True
        if normalized in {"development", "dev", "local", "testing", "test"}:
            return False
    return True


def validate_ops_blueprint_security(
    app: Flask,
    *,
    enable_ops_routes: bool,
    ops_auth_callback: Callable[[Any], Any] | None,
) -> None:
    if not enable_ops_routes:
        return
    has_auth_callback = ops_auth_callback is not None
    default_require_ops_auth = _is_production_like_app(app)
    require_ops_auth = coerce_config_bool(
        app.config.get("DB_MODULE_REQUIRE_OPS_AUTH", default_require_ops_auth),
        default_require_ops_auth,
    )
    if require_ops_auth and not has_auth_callback:
        raise ValueError(
            "DB module ops routes require auth callback when DB_MODULE_REQUIRE_OPS_AUTH=true"
        )
    extensions = getattr(app, "extensions", None)
    warning_emitted = False
    if isinstance(extensions, dict):
        warning_emitted = bool(extensions.get(_OPS_SECURITY_WARNING_KEY, False))
    if not has_auth_callback and not bool(app.testing) and not warning_emitted:
        if isinstance(extensions, dict):
            extensions[_OPS_SECURITY_WARNING_KEY] = True
        app.logger.warning(
            "DB module ops routes are enabled without ops_auth_callback; set "
            "APP_ENV=development or DB_MODULE_REQUIRE_OPS_AUTH=false only for explicit "
            "development/testing scenarios."
        )
