import sys
from pathlib import Path

from flask import Flask

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from specdb.db_module import DBModuleOptions, init_db_module


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///example.sqlite3"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    init_db_module(
        app,
        options=DBModuleOptions(
            db_url_prefix="/api/db",
            blueprint_name="db",
            enable_ops_routes=True,
            enable_restore_routes=True,
        ),
    )
    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
