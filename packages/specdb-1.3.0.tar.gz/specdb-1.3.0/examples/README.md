# 示例

本目录提供 `specdb` 后端的可执行示例，重点是说明接入方式和模板初始化方式。

- `minimal_app.py`：本地 SQLite 应用工厂示例，DB 模块挂载在 `/api/db`
- `production_app.py`：生产风格应用工厂示例，包含显式 ops 鉴权和更保守的路由开关
- `admin_basic_suite_init.py`：通过 `specdb.install` 初始化一套中小型后台推荐表结构，并写入最小 RBAC / 站点种子数据

这些示例主要用于说明如何接入和初始化，不是独立的部署包。
