import sys
from pathlib import Path

from flask import Flask, Request

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from specdb.db_module import DBModuleOptions, init_db_module


def allow_ops_from_header(req: Request):
    token = req.headers.get("X-DB-Ops-Token", "").strip()
    if token == "replace-this-token":
        return True
    return False, "ops access denied", 403


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["APP_ENV"] = "production"
    app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql+psycopg://user:pass@127.0.0.1:5432/specdb"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["DB_MODULE_REQUIRE_OPS_AUTH"] = True
    init_db_module(
        app,
        options=DBModuleOptions(
            db_url_prefix="/api/db",
            blueprint_name="db",
            ops_auth_callback=allow_ops_from_header,
            enable_ops_routes=True,
            enable_restore_routes=False,
        ),
    )
    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
