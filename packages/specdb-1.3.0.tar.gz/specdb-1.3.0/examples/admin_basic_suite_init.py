import sys
from pathlib import Path

from flask import Flask

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from specdb.db_executor import init_database
from specdb.db_module import DBModuleOptions, init_db_module, shutdown_db_module
from specdb.db_templates import build_define_spec, get_template_suite_install_plan
from specdb.install import install_schema, install_seed

DB_PATH = BASE_DIR / "examples" / "admin_basic_suite.sqlite3"
SUITE_KEY = "admin_basic_suite_v1"

TRACKING_BY_TEMPLATE = {
    "user_standard_v2": {"strategy": "update_with_compact_log", "retention_days": 90},
    "rbac_role_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "rbac_page_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "rbac_permission_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "rbac_user_role_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "rbac_role_page_access_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "rbac_role_permission_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "content_category_v1": {"strategy": "update_with_compact_log", "retention_days": 90},
    "content_tag_v1": {"strategy": "update_with_compact_log", "retention_days": 90},
    "content_article_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "content_article_tag_v1": {"strategy": "update_with_compact_log", "retention_days": 90},
    "site_setting_v1": {"strategy": "update_with_compact_log", "retention_days": 180},
    "media_asset_v1": {"strategy": "update_with_compact_log", "retention_days": 90},
}


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH.as_posix()}"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    init_db_module(
        app,
        options=DBModuleOptions(
            db_url_prefix="/api/db",
            blueprint_name="db",
            enable_ops_routes=False,
            enable_restore_routes=False,
        ),
    )
    return app


def build_tracked_define_spec(template_key: str) -> dict:
    spec = build_define_spec(template_key)
    if spec is None:
        raise RuntimeError(f"missing template: {template_key}")
    tracking = TRACKING_BY_TEMPLATE.get(template_key)
    if tracking:
        spec["payload"].setdefault("module_options", {})
        spec["payload"]["module_options"]["change_tracking"] = dict(tracking)
    spec.setdefault("options", {})
    return spec


def define_tables(client) -> dict:
    plan = get_template_suite_install_plan(SUITE_KEY)
    if plan is None:
        raise RuntimeError(f"missing template suite: {SUITE_KEY}")
    define_specs = [build_tracked_define_spec(template_key) for template_key in plan["recommended_template_order"]]
    result = install_schema(client, define_specs)
    if not result.get("success"):
        raise RuntimeError(f"failed to install suite schema: {result}")
    return result


def build_seed_bundle() -> dict:
    return {
        "meta": {
            "bundle_key": "admin_basic_seed_v1",
            "bundle_version": "1.0",
            "suite_key": SUITE_KEY,
        },
        "tables": {
            "users": {
                "key_fields": ["username"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["email", "display_name", "status", "role"],
                "rows": [
                    {
                        "username": "admin",
                        "email": "admin@example.com",
                        "password_hash": "replace-with-real-password-hash",
                        "role": "super_admin",
                        "status": "active",
                        "display_name": "System Admin",
                        "is_email_verified": True,
                        "is_phone_verified": False,
                        "must_reset_password": False,
                        "failed_login_count": 0,
                        "mfa_enabled": False,
                    }
                ],
            },
            "rbac_roles": {
                "key_fields": ["role_key"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["role_name", "description", "status"],
                "rows": [
                    {"role_key": "super_admin", "role_name": "Super Admin", "description": "Example super admin role", "status": "active"},
                    {"role_key": "site_admin", "role_name": "Site Admin", "description": "Example site admin role", "status": "active"},
                    {"role_key": "editor", "role_name": "Editor", "description": "Example editor role", "status": "active"},
                    {"role_key": "operator", "role_name": "Operator", "description": "Example operator role", "status": "active"},
                ],
            },
            "rbac_pages": {
                "key_fields": ["page_key"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["page_name", "route_path", "sort_order", "status"],
                "rows": [
                    {"page_key": "dashboard", "page_name": "Dashboard", "route_path": "/admin/dashboard", "sort_order": 10, "status": "active"},
                    {"page_key": "user_list", "page_name": "User List", "route_path": "/admin/users", "sort_order": 20, "status": "active"},
                    {"page_key": "role_list", "page_name": "Role List", "route_path": "/admin/roles", "sort_order": 30, "status": "active"},
                    {"page_key": "permission_list", "page_name": "Permission List", "route_path": "/admin/permissions", "sort_order": 40, "status": "active"},
                    {"page_key": "article_list", "page_name": "Article List", "route_path": "/admin/articles", "sort_order": 50, "status": "active"},
                    {"page_key": "article_edit", "page_name": "Article Edit", "route_path": "/admin/articles/edit", "sort_order": 60, "status": "active"},
                    {"page_key": "category_list", "page_name": "Category List", "route_path": "/admin/categories", "sort_order": 70, "status": "active"},
                    {"page_key": "tag_list", "page_name": "Tag List", "route_path": "/admin/tags", "sort_order": 80, "status": "active"},
                    {"page_key": "media_library", "page_name": "Media Library", "route_path": "/admin/media", "sort_order": 90, "status": "active"},
                    {"page_key": "site_settings", "page_name": "Site Settings", "route_path": "/admin/settings", "sort_order": 100, "status": "active"},
                ],
            },
            "rbac_permissions": {
                "key_fields": ["permission_key"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["permission_name", "resource_type", "resource_key", "module", "action", "description"],
                "rows": [
                    {"permission_key": "user.read", "permission_name": "User Read", "resource_type": "api", "resource_key": "user", "module": "user", "action": "read", "description": "Read users"},
                    {"permission_key": "user.write", "permission_name": "User Write", "resource_type": "api", "resource_key": "user", "module": "user", "action": "write", "description": "Write users"},
                    {"permission_key": "role.read", "permission_name": "Role Read", "resource_type": "api", "resource_key": "role", "module": "rbac", "action": "read", "description": "Read roles"},
                    {"permission_key": "role.write", "permission_name": "Role Write", "resource_type": "api", "resource_key": "role", "module": "rbac", "action": "write", "description": "Write roles"},
                    {"permission_key": "article.read", "permission_name": "Article Read", "resource_type": "api", "resource_key": "article", "module": "content", "action": "read", "description": "Read articles"},
                    {"permission_key": "article.write", "permission_name": "Article Write", "resource_type": "api", "resource_key": "article", "module": "content", "action": "write", "description": "Write articles"},
                    {"permission_key": "media.read", "permission_name": "Media Read", "resource_type": "api", "resource_key": "media", "module": "media", "action": "read", "description": "Read media"},
                    {"permission_key": "media.write", "permission_name": "Media Write", "resource_type": "api", "resource_key": "media", "module": "media", "action": "write", "description": "Write media"},
                    {"permission_key": "site_setting.read", "permission_name": "Site Setting Read", "resource_type": "api", "resource_key": "site_setting", "module": "site", "action": "read", "description": "Read site settings"},
                    {"permission_key": "site_setting.write", "permission_name": "Site Setting Write", "resource_type": "api", "resource_key": "site_setting", "module": "site", "action": "write", "description": "Write site settings"},
                ],
            },
            "site_settings": {
                "key_fields": ["setting_key"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["setting_name", "setting_value", "value_type", "group_name", "is_public"],
                "rows": [
                    {"setting_key": "site.name", "setting_name": "Site Name", "setting_value": "SpecDB Admin Demo", "value_type": "string", "group_name": "general", "is_public": True},
                    {"setting_key": "site.theme", "setting_name": "Admin Theme", "setting_value": "classic-light", "value_type": "string", "group_name": "appearance", "is_public": False},
                ],
            },
            "rbac_user_roles": {
                "key_fields": ["username_ref", "role_key_ref"],
                "mode": "skip_if_exists",
                "references": {
                    "user_id": {"table": "users", "target_key_fields": ["username"], "source_from": ["username_ref"]},
                    "role_id": {"table": "rbac_roles", "target_key_fields": ["role_key"], "source_from": ["role_key_ref"]},
                },
                "rows": [{"username_ref": "admin", "role_key_ref": "super_admin"}],
            },
            "rbac_role_page_access": {
                "key_fields": ["role_key_ref", "page_key_ref"],
                "mode": "update_allowed_fields",
                "allowed_update_fields": ["can_view", "can_create", "can_update", "can_delete"],
                "references": {
                    "role_id": {"table": "rbac_roles", "target_key_fields": ["role_key"], "source_from": ["role_key_ref"]},
                    "page_id": {"table": "rbac_pages", "target_key_fields": ["page_key"], "source_from": ["page_key_ref"]},
                },
                "rows": [
                    {"role_key_ref": "super_admin", "page_key_ref": "dashboard", "can_view": True, "can_create": True, "can_update": True, "can_delete": True},
                    {"role_key_ref": "site_admin", "page_key_ref": "dashboard", "can_view": True, "can_create": False, "can_update": False, "can_delete": False},
                    {"role_key_ref": "editor", "page_key_ref": "article_list", "can_view": True, "can_create": True, "can_update": True, "can_delete": False},
                    {"role_key_ref": "operator", "page_key_ref": "media_library", "can_view": True, "can_create": False, "can_update": False, "can_delete": False},
                ],
            },
            "rbac_role_permissions": {
                "key_fields": ["role_key_ref", "permission_key_ref"],
                "mode": "skip_if_exists",
                "references": {
                    "role_id": {"table": "rbac_roles", "target_key_fields": ["role_key"], "source_from": ["role_key_ref"]},
                    "permission_id": {"table": "rbac_permissions", "target_key_fields": ["permission_key"], "source_from": ["permission_key_ref"]},
                },
                "rows": [
                    {"role_key_ref": "super_admin", "permission_key_ref": "article.write"},
                    {"role_key_ref": "site_admin", "permission_key_ref": "site_setting.write"},
                    {"role_key_ref": "editor", "permission_key_ref": "article.write"},
                    {"role_key_ref": "operator", "permission_key_ref": "media.read"},
                ],
            },
        },
    }


def seed_sample_data(client) -> dict:
    result = install_seed(client, build_seed_bundle())
    if not result.get("success"):
        raise RuntimeError(f"failed to install seed bundle: {result}")
    return result


def print_summary() -> None:
    print("admin_basic_suite_v1 initialized")
    print(f"database: {DB_PATH}")
    print("seeded:")
    print("- users: admin")
    print("- roles: super_admin, site_admin, editor, operator")
    print("- pages: dashboard, user_list, role_list, permission_list, article_list, article_edit, category_list, tag_list, media_library, site_settings")
    print("- permissions: user.*, role.*, article.*, media.*, site_setting.*")


def main() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        DB_PATH.unlink()

    app = create_app()
    try:
        with app.app_context():
            client = init_database()
            define_tables(client)
            seed_sample_data(client)
        print_summary()
    finally:
        shutdown_db_module(app, wait=True)


if __name__ == "__main__":
    main()
