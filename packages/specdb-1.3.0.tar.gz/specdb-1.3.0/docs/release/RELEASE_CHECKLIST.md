# 发布检查清单

适用于 `specdb` 稳定版发布前的最终核对。

## 发布前整理

- 清理本地产物：`.tmp`、`.verify_venv`、`build`、`package_dist`、`specdb.egg-info`、`__pycache__`
- 确认 `git status` 干净，或只包含本次发布的目标改动
- 确认 `CHANGELOG.md` 和发布说明已经更新
- 确认 `pyproject.toml` 中的版本号与本次发布一致
- 确认 README、契约文档与主包稳定入口清单一致
- 确认示例脚本和示例文档没有被误写成正式兼容承诺

## 验证

- `python backend/scripts/run_tests.py`
- `python backend/scripts/build_package.py`
- `python backend/scripts/verify_package.py`
- 如本地环境限制严格隔离安装，再补：`$env:VERIFY_ALLOW_SYSTEM_SITE_PACKAGES='1'; python backend/scripts/verify_package.py`
- 确认生成的 `wheel` 与 `sdist` 版本号和发布版本一致
- 确认安装后可导入 `specdb`、`specdb.install`、模板 helper 和安装层 helper

## 发布文档

- 如果公共使用方式有变化，更新 `README.md`
- 如果存在未解决阻塞项，更新 `docs/maintenance/STABILITY_ISSUES.md`
- 新增或更新 `RELEASE_NOTES_<version>.md`
- 如果里程碑版本改变了发布基线，补充对应升级说明
- 如果主包稳定入口有新增或收口，同步更新主包边界文档和 PyPI 准备清单

## 版本控制

- 创建发布提交
- 创建带注释的标签 `v<version>`
- 确认分支 HEAD 与发布标签都指向同一已验证提交

## 1.3 主包边界补充检查

- `specdb` 根包稳定入口与 `specdb.install` 稳定入口已在 README 中说明
- 契约文档与示例文档之间的边界已经写清楚
- `future_options/` 未被误写成正式承诺能力
- 发布说明中已明确本次涉及的稳定入口变化或无变化判断
