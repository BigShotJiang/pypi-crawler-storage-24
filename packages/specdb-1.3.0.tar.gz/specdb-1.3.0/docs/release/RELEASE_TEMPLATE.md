# 发布说明模板

## 版本信息

- 发布版本：`x.y.z`
- 发布日期：`YYYY-MM-DD`

## 版本亮点

- 

## 新增

- 

## 变更

- 

## 修复

- 

## 文档

- 

## 稳定入口与边界

- 本次发布涉及的主包稳定入口：
- README / 契约文档是否与实际导入路径一致：
- 是否存在仅属示例资料、不构成兼容承诺的内容需要特别说明：

## 验证

- `python backend/scripts/run_tests.py`
- `python backend/scripts/build_package.py`
- `python backend/scripts/verify_package.py`

## 兼容性

- 升级说明：
- `docs/maintenance/STABILITY_ISSUES.md` 中已知阻塞项：

## 备注

- PostgreSQL 集成测试：
- CI 工作流运行记录：
- 发布产物位置：
- Git 标签：
