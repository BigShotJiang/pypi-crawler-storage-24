# 发布说明

## 版本信息

- 发布版本：`1.1.0`
- 发布日期：`2026-03-09`

## 版本亮点

- `specdb 1.1.0` 在 `1.0.0` 稳定基线之上补齐了一轮核心能力，而没有改写既有公开路由和基本执行模型。
- 本次版本只围绕核心代码推进，范围集中在 schema 演进、执行前校验、跨数据库回归、关系元数据、运维状态机和模板治理。

## 新增

- `table.alter.modify` 第一阶段稳定支持：
  - `nullable`
  - 字面量 `default`
  - 受限字符串族 `type/length`
- 正式关系元数据：
  - `table.define.payload.schema.<field>.relation`
  - `table.alter.payload.add.<field>.relation`
  - `table.describe.relations`
- 模板 suite 能力：
  - `list_template_suites()`
  - `get_template_suite()`

## 变更

- 新增统一执行前校验层，将一批结构错误前移到执行前暴露。
- PostgreSQL 集成回归从“可选补跑”提升为正式核心回归矩阵的一部分。
- `ops` 任务状态机补齐持久化层约束，非法跳转不再覆写 job 状态。

## 修复与加固

- 修复 `backend/scripts/run_tests.py` 的导入路径基线，使全量 discover 稳定通过。
- 收紧 `failed -> pending` 路径，仅允许通过 retry 专用入口恢复失败 job。
- 加强模板 rules 与 schema 的一致性校验，提前发现模板漂移。

## 验证

- `python backend/scripts/run_tests.py`
- `python backend/scripts/build_package.py`
- `python backend/scripts/verify_package.py`

## 备注

- `1.1.0` 仍然不引入 PostgreSQL-only 真实外键、PostgreSQL 扩展能力、companion library 或 CMS 方向。
- 这些方向继续保留在 `docs/modules/backend/database/future_options/` 中，等待后续版本决策。
