# 发布说明

## 版本信息

- 发布版本：`1.2.0`
- 发布日期：`2026-03-09`

## 版本亮点

- `specdb 1.2.0` 在 `1.1.0` 稳定基线之上继续只围绕核心代码推进，没有引入脚手架层、CMS 或前端产品化能力。
- 本次版本重点是把 schema 演进、关系元数据、PostgreSQL 可选真实外键、运维审计链路、模板治理和跨数据库公开契约补到更适合中小型后台长期维护的状态。

## 新增

- `table.alter.modify` 第二阶段稳定支持：
  - 单字段 `index`
  - 单字段 `unique`
  - 字符串族 `length`
- 关系元数据进一步进入执行链路：
  - 推荐建表顺序
  - suite 推荐初始化顺序
  - `restore-from-logs.relationship_risks`
- PostgreSQL-only、显式 opt-in 的真实外键：
  - `payload.module_options.relationships.postgres_foreign_keys = true`
  - `table.define`
  - `table.alter add`
- 模板与 suite 新增正式治理能力：
  - `get_template_suite_install_plan()`
  - `validate_template_suite_seed_bundle()`
  - `validate_template_overrides()`

## 变更

- `ops` job summary 统一增加 `summary.context`
- restore audit 统一增加 `context` / `result`
- `restore-from-logs` 响应增加 `audit_context`
- `table.describe` 统一增加：
  - `dialect`
  - `change_tracking`
  - `columns[*].has_default/default/indexed/unique/contract_locked`
- `table.backup` 统一增加 `source_contract`

## 修复与加固

- 补齐内部元数据损坏时的显式失败策略，不再在关系元数据、job request、restore audit 等路径静默降级。
- 收紧模板 override 边界，防止普通字段绕过限制修改危险 schema 形态。
- 收紧 restore audit 写入策略，避免恢复成功但无审计记录。
- 收紧 internal tables / ops jobs 初始化窗口，降低并发初始化漂移风险。
- 修正 `pyproject.toml` 打包配置，自动发现 `specdb*` 子包，确保 `executor/` 与 `ops/` 子包进入发布产物。

## 工程化与维护性

- 继续拆分核心实现，收口到更清晰的模块边界：
  - `executor/table_*`
  - `ops/job_store_*`
  - `ops/job_runtime_*`
  - `ops/restore_*`
- 当前核心代码已达到“可长期冻结，后续只按新功能需求再动”的状态。

## 验证

- `python backend/scripts/run_tests.py`
- `python backend/scripts/build_package.py`
- `python backend/scripts/verify_package.py`

## 备注

- `1.2.0` 仍然不引入 companion library / scaffold、CMS 方向、PostgreSQL 扩展能力或默认开启的全平台真实外键。
- 这些方向继续保留在 `docs/modules/backend/database/future_options/` 中，等待后续版本决策。
