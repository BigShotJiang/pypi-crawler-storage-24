# 升级到 1.0.0

`specdb 1.0.0` 是后端的第一个稳定版发布基线。

## 这意味着什么

- 核心 DB 模块路由和行为从现在开始视为稳定发布面。
- 后续 `1.x` 版本应尽量采用增量式演进，而不是随意改变既有行为。
- 后续缺陷修复仍应优先补回归测试，再改实现。

## 建议的升级检查项

1. 确认生产环境使用 `APP_ENV=production`
2. 确认生产环境提供了 `DATABASE_URL`
3. 如果启用了 `/ops/*` 路由，确认已经显式注册 `ops_auth_callback`
4. 重新执行 `python backend/scripts/run_tests.py`
5. 在发布产物前重新执行一次打包校验

## 运维说明

- 当前 production 默认姿态比本地开发环境更保守、更安全。
- 多 scope DB blueprint 和 PostgreSQL 校验路径已经纳入当前稳定版基线。
- 后续任何稳定版发布前，如存在阻塞项，需先记录到 `backend/docs/maintenance/STABILITY_ISSUES.md`。
