# 升级到 1.1.0

`specdb 1.1.0` 是在 `1.0.0` 稳定基线上的核心增强版本。

## 这意味着什么

- 既有 `table.*`、`data.*`、模板接口和 `ops` 路由的公开入口保持不变。
- `table.alter.modify` 不再统一返回 `501`，而是对第一阶段支持的字段修改正式执行，对不支持场景继续返回明确错误。
- 一批结构错误会更早在执行前校验阶段暴露，调用方可能比 `1.0.0` 更早收到 `DB_SCHEMA_ERROR` 一类错误。

## 升级前建议检查

1. 重新执行完整后端回归：
   - `python backend/scripts/run_tests.py`
2. 如本地配置了 PostgreSQL，确认 PostgreSQL 集成回归也可通过。
3. 检查是否有自定义调用依赖了 `table.alter.modify -> 501` 的旧行为。
4. 检查模板扩展代码是否满足更严格的 rules/schema 一致性校验。

## 需要重点关注的行为变化

### `table.alter.modify`

当前正式支持：
- `nullable`
- 字面量 `default`
- 字符串族 `type/length`

当前仍不支持：
- 主键字段修改
- `primary` / `unique` / `auto_increment` / `rename_to`
- `append_only_versioned` 表上的 `modify`
- 非字符串族类型变更

### 执行前校验层

以下错误现在会更早暴露：
- `spec` / `payload` / `options` 不是 object
- `table.*` / `data.*` 高频动作缺必填字段
- `order_by`、`include_total`、`allow_full_table` 等结构类型不合法
- `table.alter.modify` 字段级结构不合法

### 模板治理

- 模板元信息现在要求和 schema/rules 更严格对齐。
- suite 注册中如果引用缺失模板，会在校验阶段直接失败。

## 运维说明

- `ops` job 状态机已经加固，非法状态跳转不会再默默覆写持久化状态。
- `failed -> pending` 仅保留在 retry 专用路径。

## 建议升级流程

1. 升级包版本到 `1.1.0`
2. 运行 `python backend/scripts/run_tests.py`
3. 如有本地 PostgreSQL，补跑 PostgreSQL 集成回归
4. 对自定义模板和 `table.alter.modify` 调用做一次最小验收
