# 升级到 1.3.0

`specdb 1.3.0` 是在 `1.2.0` 稳定核心基础上，补齐主包安装层和发布边界的版本。

## 这意味着什么

- 既有运行期公开入口保持兼容：
  - `table.*`
  - `data.*`
  - 模板接口
  - `ops` 接口
- 主包新增了正式安装层：
  - `specdb.install`
  - 根包也同步导出安装层 helper
- `install_seed()` 现在支持显式 `atomic=True`
- `ops` 默认鉴权比 `1.2.0` 更严格

## 升级前建议检查

1. 重新运行完整后端回归：
   - `python backend/scripts/run_tests.py`
2. 如果项目启用了 `ops` 路由，检查是否已经提供 `ops_auth_callback`
3. 如果项目要开始使用主包安装层，明确区分：
   - `install_schema / install_suite`
   - `install_seed`
   - `verify_installation`
4. 如果项目已有 seed 安装脚本，决定是否要改为使用：
   - `load_seed_bundle`
   - `install_seed_file`
   - `atomic=True`

## 需要重点关注的行为变化

### 安装层

新增正式入口：

- `from specdb import install_schema`
- `from specdb import install_suite`
- `from specdb import install_seed`
- `from specdb import verify_installation`

以及：

- `from specdb.install import load_seed_bundle`
- `from specdb.install import install_seed_file`

### `install_seed(..., atomic=True)`

- `atomic=False` 仍保留兼容模式
- `atomic=True` 会把同一次 seed 安装放入单事务
- 失败时不会留下本次调用内的部分落库结果

### `ops` 默认鉴权

- 未声明环境的非测试 app，现在默认要求 `ops_auth_callback`
- 只有显式开发模式、`TESTING=True`，或显式配置关闭时，才允许无 callback

## 建议升级流程

1. 升级包版本到 `1.3.0`
2. 执行完整回归：
   - `python backend/scripts/run_tests.py`
3. 如需本地发布前复核：
   - `python backend/scripts/build_package.py`
   - `python backend/scripts/verify_package.py`
4. 检查项目 README / 接入文档是否已经改成正式安装层入口
