# 发布说明

## 版本信息

- 发布版本：`1.3.0`
- 发布日期：`2026-03-10`

## 版本亮点

- `specdb` 主包补齐了正式安装层，主包现在不只提供运行期 CRUD / ops / 模板能力，也提供可复用的 schema 安装、suite 安装、seed 安装和安装验收入口。
- `specdb 1.3.0` 的重点不是继续扩核心能力，而是把主包收口到“可真实落地、可长期冻结、可准备发布到 PyPI”的状态。

## 新增

- 新增正式安装层 `specdb.install`
- 新增稳定公开 helper：
  - `install_schema`
  - `install_suite`
  - `install_seed`
  - `load_seed_bundle`
  - `install_seed_file`
  - `reset_dev_database`
  - `verify_installation`
- 新增 JSON / YAML seed 文件加载与安装支持
- 新增 `install_seed(..., atomic=True)` 原子导入模式

## 变更

- 默认 `ops` 鉴权策略已收紧：
  - 未声明环境的非测试 app 默认要求 `ops_auth_callback`
  - `TESTING=True` 和显式开发模式仍保留豁免
- tracking helper 的事务边界进一步统一：
  - `delete_table_options(conn=...)`
  - `table.drop` 与 `table.alter` 复用既有连接
- 模板资产与 suite seed-set 校验继续收口为稳定契约

## 修复

- 修复 seed 安装层若干返回结构和默认模式边界
- 修复 suite 子集安装返回建议与完整 suite 漂移的问题
- 修复模板 seed-set 校验里重复业务键漏检的问题

## 文档

- 明确主包稳定入口与非稳定示例边界
- 明确 `specdb` 主包与未来外部业务层库的分层
- 补齐 PyPI 发布准备清单、安装层设计和 seed 契约设计

## 稳定入口与边界

本次发布涉及的主包稳定入口包括：

- `specdb`
- `specdb.install`
- `specdb.db_module`
- `specdb.db_templates`

README 和数据库契约文档中出现的导入入口，视为正式承诺；`examples/` 和设计文档中的示例内容，默认不视为稳定 API。

## 验证

- `python backend/scripts/run_tests.py`
- `python backend/scripts/build_package.py`
- `python backend/scripts/verify_package.py`
