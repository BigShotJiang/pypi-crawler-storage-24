# 升级到 1.2.0

`specdb 1.2.0` 是在 `1.1.0` 稳定基线上的核心增强版本。

## 这意味着什么

- 既有 `table.*`、`data.*`、模板接口和 `ops` 路由的公开入口保持不变。
- `table.alter.modify` 在 `1.1` 第一阶段基础上继续扩展了单字段 `index`、单字段 `unique` 和字符串族 `length` 修改。
- `table.describe` 和 `table.backup` 的返回结构更完整，调用方如果依赖这些接口，建议同步消费新增 contract 字段。
- PostgreSQL 环境现在可以显式启用真实外键，但该能力仍是 `opt-in`，默认不会开启。

## 升级前建议检查

1. 重新执行完整后端回归：
   - `python backend/scripts/run_tests.py`
2. 如果本地配置了 PostgreSQL，确认 PostgreSQL 集成回归也能通过。
3. 如果有自定义模板 override，检查是否依赖了更宽松的旧行为；`1.2.0` 会更严格拒绝危险 schema override。
4. 如果有依赖 `table.describe` / `table.backup` 固定返回结构的外部代码，检查是否需要兼容新增字段。

## 需要重点关注的行为变化

### `table.alter.modify`

当前正式支持：
- `nullable`
- 字面量 `default`
- 单字段 `index`
- 单字段 `unique`
- 字符串族 `type/length`

当前仍不支持：
- 主键字段修改
- 多字段索引 / 多字段唯一约束上的列级 `modify`
- `primary` / `auto_increment` / `rename_to`
- `append_only_versioned` 表上的 `modify`
- 非字符串族的大范围类型放宽

### 关系元数据与真实外键

- `relation` 现在会更深入参与建表顺序推导、suite 安装顺序和 restore 风险提示。
- 如果显式启用 `relationships.postgres_foreign_keys=true`：
  - 只在 PostgreSQL 下生效
  - 仅支持单字段、指向主键列的真实外键
  - SQLite / 非 PostgreSQL 会稳定拒绝

### 运维返回结构

- `GET /ops/jobs/<job_id>` 中的 `summary` 现在稳定带有 `context`
- `GET /ops/restore-audits` 中的条目现在稳定带有 `context` / `result`
- `POST /ops/restore-from-logs` 现在稳定返回 `audit_context`
- `POST /ops/jobs/<job_id>/retry` 现在只接受空 JSON 对象

### 跨数据库契约

`table.describe` 新增稳定字段：
- `dialect`
- `change_tracking`
- `columns[*].has_default`
- `columns[*].default`
- `columns[*].indexed`
- `columns[*].unique`
- `columns[*].contract_locked`

`table.backup` 新增稳定字段：
- `source_contract.dialect`
- `source_contract.change_tracking`
- `source_contract.relationship_options`
- `source_contract.relation_keys`

## 建议升级流程

1. 升级包版本到 `1.2.0`
2. 运行 `python backend/scripts/run_tests.py`
3. 如有 PostgreSQL，补跑 PostgreSQL 集成回归
4. 对自定义模板、`table.describe` 消费方和 restore / ops 链路做一次最小验收

## 打包与安装验收

如需发布前再次本地验收：

```bash
python backend/scripts/build_package.py
python backend/scripts/verify_package.py
```
