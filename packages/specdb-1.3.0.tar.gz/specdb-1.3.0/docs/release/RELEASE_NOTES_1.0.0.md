# 发布说明

## 版本信息

- 发布版本：`1.0.0`
- 发布日期：`2026-03-08`

## 版本亮点

- `specdb 1.0.0` 是后端核心的第一个稳定版基线。
- 当前核心路由、ops 流程、多 scope 行为、打包流程以及 PostgreSQL 校验路径都已经过系统复查，可以作为稳定版发布。

## 新增

- 补充正式的 `1.0.0` 里程碑发布说明。
- 在后端文档中明确稳定版定位。

## 变更

- 包版本从 `0.2.0` 提升到 `1.0.0`。
- `CHANGELOG` 与稳定性评估文档已同步到稳定版状态。

## 修复归并

- 将生产默认值、ops 鉴权、scope 隔离、租约恢复、归档副作用保护、响应归一化、恢复一致性等加固工作，统一纳入 `1.0.0` 稳定版基线。

## 文档

- 更新了 `README.md`、`CHANGELOG.md`、`docs/maintenance/STABILITY_ISSUES.md` 等稳定版文档。

## 验证

- `python backend/scripts/run_tests.py`
- `$env:VERIFY_ALLOW_SYSTEM_SITE_PACKAGES='1'; python backend\scripts\build_package.py; python backend\scripts\verify_package.py`

## 备注

- 当前结论：后端核心可以作为第一个稳定版基线发布。
- 剩余风险属于正常的后续回归风险，不是当前已确认的发布阻塞项。
