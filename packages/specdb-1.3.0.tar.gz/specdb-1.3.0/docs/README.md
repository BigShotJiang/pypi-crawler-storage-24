# 文档目录

`backend/docs/` 用于收拢原先散落在主目录下的发布与维护文档，减少根目录噪音。

当前结构：

- `release/`：发布说明、发布模板、发布检查清单、升级说明
- `maintenance/`：稳定性问题记录等维护期文档

常用文件：

- `release/RELEASE_NOTES_1.3.0.md`
- `release/RELEASE_NOTES_1.2.0.md`
- `release/RELEASE_NOTES_1.1.0.md`
- `release/RELEASE_NOTES_1.0.0.md`
- `release/RELEASE_TEMPLATE.md`
- `release/RELEASE_CHECKLIST.md`
- `release/UPGRADE_1.3.0.md`
- `release/UPGRADE_1.2.0.md`
- `release/UPGRADE_1.1.0.md`
- `release/UPGRADE_1.0.0.md`
- `maintenance/STABILITY_ISSUES.md`

未来可选技术方向已迁移到主文档目录：

- `docs/modules/backend/database/future_options/README.md`

当前 `1.3` 主干阶段的正式执行与边界文档优先看：
- `docs/modules/backend/database/specdb_1.3冻结与发布计划.md`
- `docs/modules/backend/database/正式初始化与安装层设计.md`
- `docs/modules/backend/database/正式seed_bundle与幂等策略设计.md`
- `docs/modules/backend/database/数据库模板体系详细设计.md`

发布前如果需要确认哪些内容属于正式承诺、哪些只是示例资料，优先看：
- `docs/modules/backend/database/specdb主包边界与外部库分层方案.md`
- `docs/modules/backend/database/specdb_PyPI发布准备清单.md`
