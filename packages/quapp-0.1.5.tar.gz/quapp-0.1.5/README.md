# Quapp CLI

A command-line interface for the [Quapp](https://quapp.cloud) quantum/cloud computing platform. Submit quantum jobs, manage functions and projects, and automate workflows from your terminal or Python scripts.

## Requirements

Python 3.10+ and pip.

## Install

```bash
pip install quapp
```

Or download a standalone binary from the [GitLab CI pipeline artifacts](https://gitlab.com/quapp/quapp-cli/-/pipelines) — no Python required.

## Quick Start

```bash
# 1. Authenticate (interactive prompt — use --email/--password flags for CI)
quapp login

# 2. Create a project and note the ID from the output
quapp project create --name my-project

# 3. Set it as default (avoids --project on every command)
quapp config set project-id <project-id>

# 4a. One-shot: upload handler, deploy, and run a job
quapp deploy \
  --project my-project \
  --function my-qec \
  --handler handler.py \
  --device Simulator \
  --shots 1024 \
  --wait

# 4b. Step-by-step (use when you need fine-grained control)
quapp function create --name my-qec --sdk-version 0.45.3 --lang qiskit
quapp function version <function-id> --description "v1" --files main.py
quapp job run --function <function-id> --device Simulator --shots 1024 --wait
```

## What's New

| Feature | Summary |
|---------|---------|
| **Unified error format** | All errors: `✗ ErrorType  message` + hint line (e.g. `→ Run 'quapp login' to re-authenticate`) |
| **Live spinner polling** | `--wait` on `deploy` and `invoke` shows a Rich spinner + elapsed time. Ctrl+C detaches (job keeps running). |
| **Shell completion** | `quapp --install-completion` installs tab completion. Git Bash: run `source ~/.bashrc` to activate. |
| **Grouped help panels** | `quapp --help` groups commands under: `Projects`, `Functions`, `Jobs`, `Workflows`. Key commands include usage examples in their `--help` epilog. |
| **`quapp watch <job-id>`** | Top-level shortcut — live Rich dashboard with job status, elapsed time, function/provider info, and log tail. Equivalent to `quapp job watch <job-id>`. |
| **`quapp browse`** | Interactive three-pane browser: Projects → Functions → Jobs. Arrow-key navigation; `d` on a function to deploy; `q` to quit. Git Bash: use `--fallback` for numbered-menu mode. |

---

## Commands

### Auth
```
quapp login                                  Authenticate (prompts for email + password)
quapp logout                                 Invalidate session
quapp whoami                                 Show the currently authenticated user
```

`quapp login` accepts `--email / -e` and `--password` flags for non-interactive/CI use.

### Config
```
quapp config show                            Print base_url, project_id, and masked token
quapp config set <key> <value>               Set base-url or project-id
```

Use `quapp config set project-id <id>` to set a default project. Project IDs are shown by `quapp project list`.

### SDKs
```
quapp sdk list                               List valid SDK names and versions for function create
```

### Projects
```
quapp project create --name X [--description Y] [--permission private|group]
quapp project list                           IDs shown here — use with config set project-id
quapp project get <id>
quapp project delete <id>
```

### Functions
```
quapp function create --name X --sdk-version X --lang qiskit|cuda [--description Y] [--project / -p <id>]
quapp function version <id> --description X --files file.py [--project / -p <id>]
quapp function list [--project / -p <id>]
quapp function get <id> [--project / -p <id>]
quapp function logs <id> [--project / -p <id>]
quapp function delete <id> [--project / -p <id>]
```

`quapp function version` accepts one or more `--files` entries.

### Jobs
```
quapp job run --function <id> --device X --shots N [--provider X] [--wait] [--project / -p <id>]
quapp job list [--project / -p <id>]
quapp job status <id> [--project / -p <id>]
quapp job results <id> [--project / -p <id>]
quapp job cancel <id> [--project / -p <id>]
quapp job retry <id> [--project / -p <id>]
quapp job watch <id> [--project / -p <id>]
```

`quapp job watch` live-polls until the job reaches a terminal state.

Use `quapp sdk list` to discover available providers and devices.

### Deploy (all-in-one)
```
quapp deploy --project X --function X --handler handler.py --device X [--sdk-version X]
             [--requirements requirements.txt] [--provider X] [--shots N]
             [--input KEY=VALUE ...] [--wait]
```

Uploads the handler, creates a function version, deploys it, and submits a job — all in one command. `--requirements` is auto-detected if omitted. Default provider is `Quapp`.

### Invoke (name-based shortcut)
```
quapp invoke invoke --project X --function X --device X [--provider X] [--shots N]
                    [--input KEY=VALUE ...] [--wait]
```

Resolves project/function/device names to IDs and submits a job without needing explicit IDs. Note: the command is `quapp invoke invoke` — `invoke` is both the command group and the subcommand.

### Watch (shortcut)
```
quapp watch <job-id>                         Live dashboard: status, elapsed time, function/provider, log tail
```

Equivalent to `quapp job watch <job-id>`. Press `q` to quit (job keeps running).

### Browse (interactive)
```
quapp browse [--fallback]                    Three-pane interactive browser: Projects → Functions → Jobs
```

- Arrow keys to navigate, Enter to drill down, Backspace to go back
- `d` on a function to deploy, `q` to quit
- `--fallback`: numbered-menu mode for terminals without raw key support (Git Bash)

### TUI
```
quapp tui                                    Launch the interactive terminal UI
```

### Global flags
```
--json    Output raw JSON instead of Rich tables
```

> **Note:** `--json` must precede the subcommand: `quapp --json job status <id>`.

## Python SDK

The `quapp` package can be used as a Python SDK — no CLI required.

```python
from quapp.config import load_config
from quapp.api.client import QuappClient
from quapp.api.jobs import run_job, get_job_status

config = load_config()
client = QuappClient(config.base_url, token=config.token, project_id=config.project_id)

job = run_job(client, function_id="f123", provider="Quapp", device="Simulator", shots=1024)
status = get_job_status(client, job["jobId"])
print(status["status"])
```

Full SDK reference: [`docs/SDK.md`](docs/SDK.md)

## Development

```bash
pip install -e .
python -m pytest tests/ -v
quapp tui          # launch interactive UI
```

## License

MIT
