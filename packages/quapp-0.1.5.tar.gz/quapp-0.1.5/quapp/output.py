"""Output helpers for the Quapp CLI.

_json_mode is a module-level flag set by the root --json callback.
When True, all output functions emit machine-readable JSON instead of Rich tables.
"""
from __future__ import annotations

import json
import time
from typing import Any, Callable

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich import print_json as _rich_print_json

console = Console(highlight=False)
err_console = Console(stderr=True, highlight=False)

# Global flag — set to True by root app --json callback
_json_mode: bool = False


def set_json_mode(enabled: bool) -> None:
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def print_table(title: str, columns: list[str], rows: list[list[Any]]) -> None:
    if _json_mode:
        data = [dict(zip(columns, row)) for row in rows]
        print_json({"title": title, "data": data})
        return
    table = Table(title=title, show_header=True, header_style="bold cyan")
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*[str(v) for v in row])
    console.print(table)


def print_json(data: dict | list) -> None:
    """Serialize *data* to JSON and pretty-print it via Rich.

    Uses ``default=str`` so non-serialisable values (datetime, UUID, etc.)
    are coerced to their string representation rather than raising.
    """
    _rich_print_json(json.dumps(data, default=str))


def print_job_result(result: Any, job_id: str = "") -> None:
    """Print jobResult payload in a formatted panel (normal mode) or raw JSON (--json mode)."""
    if _json_mode:
        print_json(result if result is not None else {})
        return
    label = f"Job Result: {job_id}" if job_id else "Job Result"
    if result is None:
        console.print(f"[dim]{label}: (no result)[/dim]")
        return
    text = json.dumps(result, indent=2, default=str)
    console.print(Panel(Syntax(text, "json", theme="ansi_dark", word_wrap=True), title=label))


def print_job_extras(job: dict) -> None:
    """Print histogram, execution time, and circuit URL from a full job dict."""
    if _json_mode:
        return

    histogram: dict | None = job.get("histogram")
    exec_ms = job.get("executionTime")
    total_ms = job.get("totalCompletionTime")
    circuit_url: str | None = job.get("circuitImageUrl")

    if histogram:
        shots = sum(histogram.values()) or 1
        table = Table(title="Shot Distribution", show_header=True, header_style="bold cyan")
        table.add_column("Bitstring")
        table.add_column("Count", justify="right")
        table.add_column("Probability", justify="right")
        for bitstring, count in sorted(histogram.items()):
            table.add_row(bitstring, str(count), f"{count / shots:.1%}")
        console.print(table)

    timing_parts = []
    if exec_ms is not None:
        timing_parts.append(f"execution {exec_ms:.4f}s")
    if total_ms is not None:
        timing_parts.append(f"total {total_ms / 1000:.2f}s")
    if timing_parts:
        console.print(f"[dim]Timing: {', '.join(timing_parts)}[/dim]")

    if circuit_url:
        console.print(f"[dim]Circuit: {circuit_url[:120]}{'...' if len(circuit_url) > 120 else ''}[/dim]")


def print_error(msg: str) -> None:
    err_console.print(f"[bold red]Error:[/bold red] {msg}")


def print_success(msg: str) -> None:
    console.print(f"[bold green]{msg}[/bold green]")


_HINT_TABLE: dict[str, str] = {
    # Exact class names verified from quapp/api/client.py
    "QuappAuthError": "Run 'quapp login' to re-authenticate",
    "QuappForbiddenError": "Run 'quapp login' to re-authenticate",
    "QuappNotFoundError": "Check the ID with 'quapp <resource> list'",
    "QuappRateLimitError": "Request was rate-limited; wait a moment and retry",
    "QuappServerError": "Platform error; check status at <QUAPP_STATUS_URL>",  # TODO: resolve Pre-Ship Blocker #1 — replace with real status URL
    "KeyError": "Unexpected API response — missing required field",
}


def format_error(exc: Exception) -> None:
    """Print a structured error to stderr: red type name, white message, optional hint."""
    type_name = type(exc).__name__
    msg = str(exc)
    err_console.print(f"[bold red]✗ {type_name}[/bold red]  {msg}")
    hint = _HINT_TABLE.get(type_name)
    if hint:
        err_console.print(f"  [dim]→ {hint}[/dim]")


def poll_with_spinner(
    poll_fn: Callable[[], dict],
    interval: float,
    label: str,
) -> dict:
    """Poll poll_fn in a Rich Live spinner until a terminal status is returned.

    poll_fn must return a dict with a "status" key.
    KeyboardInterrupt is NOT caught — it propagates to the caller.
    """
    # Lazy import to avoid circular: jobs.py imports from output.py
    from quapp.cli.jobs import _TERMINAL_STATUSES
    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text
    import typer

    start = time.monotonic()

    with Live(refresh_per_second=4) as live:
        while True:
            result = poll_fn()

            if "status" not in result:
                format_error(KeyError("status"))
                raise typer.Exit(code=1)

            status = result["status"]

            if not isinstance(status, str):
                console.print(f"[yellow]Warning: unexpected status type {type(status).__name__!r} — continuing to poll[/]")
                time.sleep(interval)
                continue

            elapsed = time.monotonic() - start
            live.update(
                Spinner("dots", text=Text(f"{label}… [{elapsed:.0f}s]  status: {status}"))
            )

            if status in _TERMINAL_STATUSES:
                return result

            time.sleep(interval)
