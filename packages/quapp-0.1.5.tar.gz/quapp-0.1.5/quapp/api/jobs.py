from __future__ import annotations

from typing import Any

from quapp.api.client import QuappClient, QuappNotFoundError, unwrap


def run_job(
    client: QuappClient,
    function_name: str,
    provider: str = "",
    device: int | str = 0,
    shots: int = 1024,
    invocation_input: dict | None = None,
    description: str = "",
) -> dict:
    """POST /function/invoke — submit a job; returns dict with 'id'/'jobId' keys."""
    body: dict = {
        "functionName": function_name,
        "deviceId": int(device),
        "shots": shots,
        "description": description,
    }
    if invocation_input is not None:
        body["input"] = invocation_input
    response = client.post("/function/invoke", json=body)
    job_id = unwrap(response.json())
    if isinstance(job_id, str):
        return {"id": job_id, "jobId": job_id}
    return job_id


def get_job_status(client: QuappClient, job_id: str) -> dict:
    """GET /jobs/{id}/detail — return job dict."""
    response = client.get(f"/jobs/{job_id}/detail")
    return unwrap(response.json())


def get_job_results(client: QuappClient, job_id: str) -> dict:
    """Return the full job detail dict (jobResult embedded inside).

    Results are embedded in the job object — no separate results endpoint.
    This is a thin alias for get_job_status.
    """
    return get_job_status(client, job_id)


def get_job_result(client: QuappClient, job_id: str) -> Any:
    """Return only the jobResult payload from a completed job.

    Returns None if the job is not yet done or has no result.
    """
    job = get_job_status(client, job_id)
    return job.get("jobResult")


def cancel_job(client: QuappClient, job_id: str) -> None:
    """DELETE /jobs/{id} — cancel a job; returns nothing."""
    client.delete(f"/jobs/{job_id}")


def retry_job(client: QuappClient, job_id: str) -> dict:
    """POST /jobs/{id}/retry — retry a failed job and return the response dict.

    NOTE: As of 2026-03, /jobs/{id}/retry returns 404; retry is not supported by the API.
    """
    response = client.post(f"/jobs/{job_id}/retry")
    return response.json()


def _extract_list(data) -> list:
    """Handle both paginated (data.content) and plain-array (data[]) shapes."""
    if isinstance(data, list):
        return data
    return data.get("content", data.get("items", []))


def list_jobs(client: QuappClient) -> list[dict]:
    """GET /jobs — return all job dicts (all pages, requires X-Project-Id header via client)."""
    return client.list_all_pages("/jobs")
