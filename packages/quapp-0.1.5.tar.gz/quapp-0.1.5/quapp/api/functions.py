from __future__ import annotations

from quapp.api.client import QuappClient, QuappNotFoundError, unwrap


def create_function(
    client: QuappClient,
    name: str,
    sdk_version: str,
    lang: str,
    description: str | None = None,
) -> dict:
    """POST /functions — create a new function and return the response dict."""
    body: dict = {
        "functionName": name,
        "sdkVersion": sdk_version,
        "templateLanguageTag": lang.upper(),
    }
    if description:
        body["description"] = description
    response = client.post("/functions", json=body)
    return response.json()


def create_function_version(
    client: QuappClient,
    function_id: str,
    description: str | None,
    files: list[dict],
) -> dict:
    """POST /functions/{id}/versions — create a new version and return the response dict."""
    body: dict = {"templateFiles": files}
    if description:
        body["description"] = description
    response = client.post(f"/functions/{function_id}/versions", json=body)
    return unwrap(response.json())


def get_function(client: QuappClient, function_id: str) -> dict:
    """GET /functions/{id} — return function details dict."""
    return unwrap(client.get(f"/functions/{function_id}").json())


def list_function_versions(client: QuappClient, function_id: str) -> list[dict]:
    """GET /functions/{id}/versions — return list of version dicts."""
    response = client.get(f"/functions/{function_id}/versions")
    data = unwrap(response.json())
    return data if isinstance(data, list) else data.get("content", [])


def get_function_logs(
    client: QuappClient,
    function_id: str,
    version_index: int = 0,
) -> dict:
    """Return the build and deploy logs for a function version.

    version_index=0 means most recent (first item in list).
    Raises QuappNotFoundError if no versions exist.
    Raises IndexError if version_index exceeds the number of versions.
    """
    versions = list_function_versions(client, function_id)
    if not versions:
        raise QuappNotFoundError(f"Function {function_id!r} has no versions.")
    if version_index >= len(versions):
        raise IndexError(
            f"Version {version_index + 1} not found — function has {len(versions)} version(s)."
        )
    return versions[version_index]


def delete_function(client: QuappClient, function_id: str) -> None:
    """DELETE /functions/{id} — delete a function; returns nothing."""
    client.delete(f"/functions/{function_id}")


def _extract_list(data) -> list:
    """Handle both paginated (data.content) and plain-array (data[]) shapes."""
    if isinstance(data, list):
        return data
    return data.get("content", data.get("items", []))


def list_functions(client: QuappClient) -> list[dict]:
    """GET /functions — return all function dicts (all pages, requires X-Project-Id header via client)."""
    return client.list_all_pages("/functions")


def find_function_by_name(client: QuappClient, name_or_id: str) -> dict:
    """Find by exact name or ID first, then case-insensitive name match. Raises QuappNotFoundError if not found."""
    functions = list_functions(client)
    for f in functions:
        if f.get("name") == name_or_id or str(f.get("id")) == name_or_id:
            return f
    for f in functions:
        if f.get("name", "").lower() == name_or_id.lower():
            return f
    raise QuappNotFoundError(f"Function {name_or_id!r} not found.")
