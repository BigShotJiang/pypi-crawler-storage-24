from __future__ import annotations

from quapp.api.client import QuappClient, QuappNotFoundError, unwrap


def create_project(
    client: QuappClient,
    name: str,
    description: str | None = None,
    members: list[str] | None = None,
    permission: str = "private",
) -> dict:
    """POST /projects — create a new project and return the response dict."""
    body: dict = {"name": name, "permission": permission}
    if description:
        body["description"] = description
    if members:
        body["members"] = members
    response = client.post("/projects", json=body)
    return response.json() if response.content else {}


def get_project(client: QuappClient, project_id: str) -> dict:
    """GET /projects/{id} — return project details dict."""
    return unwrap(client.get(f"/projects/{project_id}").json())


def delete_project(client: QuappClient, project_id: str) -> None:
    """DELETE /projects/{id} — delete a project; returns nothing."""
    client.delete(f"/projects/{project_id}")


def _extract_list(data) -> list:
    """Handle both paginated (data.content) and plain-array (data[]) shapes."""
    if isinstance(data, list):
        return data
    return data.get("content", data.get("items", []))


def list_projects(client: QuappClient) -> list[dict]:
    """GET /projects — return all project dicts (all pages)."""
    return client.list_all_pages("/projects")


def find_project_by_name(client: QuappClient, name_or_id: str) -> dict:
    """Find by exact name or ID first, then case-insensitive name match. Raises QuappNotFoundError if not found."""
    projects = list_projects(client)
    for p in projects:
        if p.get("name") == name_or_id or str(p.get("id")) == name_or_id:
            return p
    for p in projects:
        if p.get("name", "").lower() == name_or_id.lower():
            return p
    raise QuappNotFoundError(f"Project {name_or_id!r} not found.")
