from __future__ import annotations

from quapp.api.client import QuappClient, QuappNotFoundError, unwrap


def list_providers(client: QuappClient) -> list[dict]:
    """GET /providers — return list of provider dicts."""
    return _extract_list(unwrap(client.get("/providers").json()))


def list_devices(client: QuappClient, provider_id: int) -> list[dict]:
    """GET /providers/{provider_id}/devices — return list of device dicts."""
    return _extract_list(unwrap(client.get(f"/providers/{provider_id}/devices").json()))


def find_device_by_name(client: QuappClient, provider_id: int, name_or_id: str) -> dict:
    """Find by exact name or ID first, then case-insensitive name match. Raises QuappNotFoundError if not found."""
    devices = list_devices(client, provider_id)
    for d in devices:
        if d.get("name") == name_or_id or str(d.get("id")) == name_or_id:
            return d
    for d in devices:
        if d.get("name", "").lower() == name_or_id.lower():
            return d
    raise QuappNotFoundError(f"Device {name_or_id!r} not found.")


def find_provider_by_name(client: QuappClient, name_or_id: str) -> dict:
    """Find provider by exact name or ID first, then case-insensitive. Raises QuappNotFoundError if not found."""
    providers = list_providers(client)
    for p in providers:
        if p.get("name") == name_or_id or str(p.get("id")) == name_or_id:
            return p
    for p in providers:
        if p.get("name", "").lower() == name_or_id.lower():
            return p
    active_ids = [str(p.get("id")) for p in providers if p.get("active")]
    raise QuappNotFoundError(
        f"Provider {name_or_id!r} not found. Available provider IDs: {', '.join(active_ids)}"
    )


def _extract_list(data) -> list:
    """Handle both paginated (data.content) and plain-array (data[]) shapes."""
    if isinstance(data, list):
        return data
    return data.get("content", data.get("items", []))
