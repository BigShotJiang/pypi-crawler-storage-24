from __future__ import annotations

import time

from quapp.api.client import QuappClient, QuappNotFoundError, QuappError, unwrap
from quapp.api.projects import find_project_by_name, create_project
from quapp.api.functions import (
    find_function_by_name,
    create_function,
)

DEPLOY_POLL_INTERVAL_SECS: int = 5
DEPLOY_TIMEOUT_SECS: int = 360


def find_or_create_project(client: QuappClient, name: str) -> dict:
    """Return existing project by name, or create it if not found."""
    try:
        return find_project_by_name(client, name)
    except QuappNotFoundError:
        return create_project(client, name)


def wait_until_deployed(
    client: QuappClient,
    function_id: str,
    version_id: str,
) -> dict:
    """Trigger the deploy pipeline and wait until DEPLOY=PASSED.

    Flow:
      1. PUT /deploy/functions/{id}/version/{vid}  — triggers the pipeline
      2. Poll GET /deploy/{function_id}/steps every DEPLOY_POLL_INTERVAL_SECS
         until the DEPLOY step is PASSED (container is live).

    Returns the version dict from the PUT response.
    Raises:
        QuappError   — BUILD or DEPLOY step failed
        TimeoutError — pipeline did not reach DEPLOY=PASSED within DEPLOY_TIMEOUT_SECS
    """
    ver_response = client.put(f"/deploy/functions/{function_id}/version/{version_id}")
    version_dict = unwrap(ver_response.json())

    deadline = time.time() + DEPLOY_TIMEOUT_SECS
    while time.time() < deadline:
        time.sleep(DEPLOY_POLL_INTERVAL_SECS)
        steps_data = client.get(f"/deploy/{function_id}/steps").json()
        steps = unwrap(steps_data) if isinstance(steps_data, dict) else steps_data
        if not isinstance(steps, list):
            continue
        step_map = {s["name"]: s.get("status") for s in steps}

        if step_map.get("BUILD") in ("FAILED", "ERROR"):
            raise QuappError(f"Function build failed for version {version_id}.")
        if step_map.get("DEPLOY") in ("FAILED", "ERROR"):
            raise QuappError(f"Function deploy failed for version {version_id}.")
        if step_map.get("DEPLOY") == "PASSED":
            return version_dict

    raise TimeoutError(
        f"Deploy did not complete within {DEPLOY_TIMEOUT_SECS} s. "
        f"Check `quapp function logs {function_id}`."
    )


def find_or_create_function(
    client: QuappClient,
    name: str,
    sdk_version: str | None,
) -> dict:
    """Return existing function by name, or create it.

    Raises ValueError if the function does not exist and sdk_version is None.
    client must be project-scoped (project_id set).
    lang is hardcoded to 'qiskit' (handler must be a .py file).
    """
    try:
        return find_function_by_name(client, name)
    except QuappNotFoundError:
        if sdk_version is None:
            raise ValueError(
                "--sdk-version is required to create a new function."
            )
        return create_function(client, name, sdk_version, lang="qiskit")
