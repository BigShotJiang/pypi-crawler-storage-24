from __future__ import annotations

import base64
import json

from quapp.api.client import QuappClient, unwrap


def decode_user_id_from_token(token: str) -> str | None:
    """Extract the 'sub' claim from a JWT token without an external library.

    Returns None if the token is absent, not a valid JWT, or lacks a 'sub' claim.
    """
    if not token:
        return None
    parts = token.split(".")
    if len(parts) != 3:
        return None
    try:
        segment = parts[1]
        segment += "=" * (-len(segment) % 4)
        payload = json.loads(base64.urlsafe_b64decode(segment))
        return payload.get("sub")
    except Exception:
        return None


def get_current_user(client: QuappClient, user_id: str) -> dict:
    """GET /users/{user_id} — return user profile dict."""
    return unwrap(client.get(f"/users/{user_id}").json())
