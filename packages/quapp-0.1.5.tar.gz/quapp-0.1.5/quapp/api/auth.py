from __future__ import annotations

from quapp.api.client import QuappClient


def login(base_url: str, email: str, password: str) -> dict:
    """POST /auth/login — returns {"accessToken": ..., "refreshToken": ...}."""
    client = QuappClient(base_url)
    response = client.post("/auth/login", json={"username": email, "password": password})
    result = response.json()
    return result.get("data", result)


def logout(base_url: str, token: str) -> None:
    """POST /auth/logout — invalidates the refresh token server-side."""
    client = QuappClient(base_url, token=token)
    client.post("/auth/logout")
