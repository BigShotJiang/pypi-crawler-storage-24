from __future__ import annotations

from quapp.api.client import QuappClient, unwrap


def list_sdks(client: QuappClient) -> list[dict]:
    """GET /sdks — return list of available SDK dicts."""
    result = unwrap(client.get("/sdks").json())
    return result if isinstance(result, list) else result.get("items", [])
