from __future__ import annotations

import time

import requests

# ---------------------------------------------------------------------------
# Typed exceptions
# ---------------------------------------------------------------------------


class QuappError(Exception):
    """Base exception for all Quapp API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class QuappAuthError(QuappError):
    """401 — Not logged in or token expired."""


class QuappForbiddenError(QuappError):
    """403 — Permission denied."""


class QuappNotFoundError(QuappError):
    """404 — Resource not found."""


class QuappBadRequestError(QuappError):
    """400 — Bad request / validation error."""


class QuappRateLimitError(QuappError):
    """429 — Rate limit exceeded (triggers retry)."""


class QuappServerError(QuappError):
    """500 / 503 — Server-side error."""


_STATUS_MAP: dict[int, type[QuappError]] = {
    400: QuappBadRequestError,
    401: QuappAuthError,
    403: QuappForbiddenError,
    404: QuappNotFoundError,
    429: QuappRateLimitError,
    500: QuappServerError,
    503: QuappServerError,
}

_RETRY_STATUSES = {429, 503}
_MAX_RETRIES = 3
_BACKOFF_BASE = 1.0  # seconds


def unwrap(response_dict: dict) -> dict:
    """Strip the {"data": {...}} envelope returned by all API endpoints."""
    return response_dict.get("data", response_dict)


def _raise_for_status(response: requests.Response) -> None:
    if response.ok:
        return
    code = response.status_code
    try:
        detail = response.json().get("message") or response.json().get("error") or response.text
    except Exception:
        detail = response.text

    exc_class = _STATUS_MAP.get(code, QuappError)
    url_hint = getattr(response, "url", "")
    default_msgs = {
        401: "Not authenticated. Run `quapp login` to re-authenticate.",
        403: "Permission denied.",
        404: f"{detail or 'Resource not found'} [{url_hint}]",
        429: f"Rate limit exceeded: {detail}",
        500: "Quapp server error. Try again later.",
        503: "Quapp server unavailable. Try again later.",
    }
    msg = default_msgs.get(code, detail or f"HTTP {code}")
    raise exc_class(msg, status_code=code)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class QuappClient:
    def __init__(self, base_url: str, token: str | None = None, project_id: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.project_id = project_id
        self._session = requests.Session()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self.project_id:
            headers["X-Project-Id"] = self.project_id
        return headers

    def request(
        self,
        method: str,
        path: str,
        *,
        retries: int = _MAX_RETRIES,
        **kwargs,
    ) -> requests.Response:
        url = f"{self.base_url}/{path.lstrip('/')}"
        kwargs.setdefault("headers", {}).update(self._headers())
        attempt = 0
        while True:
            response = self._session.request(method, url, **kwargs)
            if response.status_code in _RETRY_STATUSES and attempt < retries:
                wait = _BACKOFF_BASE * (2 ** attempt)
                time.sleep(wait)
                attempt += 1
                continue
            _raise_for_status(response)
            return response

    def get(self, path: str, **kwargs) -> requests.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> requests.Response:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs) -> requests.Response:
        return self.request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs) -> requests.Response:
        return self.request("DELETE", path, **kwargs)

    def list_all_pages(self, path: str, **kwargs) -> list:
        """Fetch all pages from a paginated Spring endpoint (content/totalPages envelope).

        Only use with /projects, /functions, /jobs — not /providers or /devices.
        Stops when content is empty OR pageNumber >= totalPages.
        """
        results: list = []
        page = 0
        # Extract caller-supplied base params once (do not mutate kwargs)
        base_params = dict(kwargs.pop("params", {}))
        while True:
            params = {**base_params, "pageNumber": page}
            response = self.get(path, params=params, **kwargs)
            data = unwrap(response.json())
            content = data.get("content", [])
            total_pages = data.get("totalPages", 1)
            results.extend(content)
            if not content or page >= total_pages - 1:
                break
            page += 1
        return results
