from __future__ import annotations

import base64
import json
from pathlib import Path
import typer

from quapp.api.client import QuappClient
from quapp.api.functions import (
    create_function,
    create_function_version,
    delete_function,
    get_function,
    get_function_logs,
    list_functions,
)
from quapp.config import load_config
from quapp import output

app = typer.Typer(help="Manage functions.")


def _client(project_id: str | None = None) -> QuappClient:
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp auth login`.")
        raise typer.Exit(1)
    return QuappClient(config.base_url, token=config.token, project_id=project_id or config.project_id)


@app.command(rich_help_panel="Functions")
def create(
    name: str = typer.Option(..., "--name", "-n", help="Function name."),
    sdk_version: str = typer.Option(..., "--sdk-version", help="SDK version (e.g. 0.45.3)."),
    lang: str = typer.Option(..., "--lang", help="Template language: qiskit or cuda."),
    description: str | None = typer.Option(None, "--description", "-d"),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Create a new function."""
    client = _client(project_id)
    try:
        data = create_function(client, name, sdk_version, lang, description)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        function_id = data.get("functionId") or data.get("id") or "—"
        output.print_table(
            "Function Created",
            ["Field", "Value"],
            [
                ["ID", function_id],
                ["Name", name],
                ["SDK Version", sdk_version],
                ["Language", lang],
            ],
        )


@app.command(rich_help_panel="Functions")
def version(
    function_id: str = typer.Argument(..., help="Function ID."),
    description: str | None = typer.Option(None, "--description", "-d"),
    files: list[Path] = typer.Option(..., "--files", help="Source files to upload (repeatable)."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Create a new function version by uploading source files."""
    py_files = [f for f in files if Path(f).suffix == ".py"]
    if len(py_files) > 1:
        output.print_error(f"Only one .py file allowed per version. Got: {', '.join(str(f) for f in py_files)}")
        raise typer.Exit(1)
    template_files: list[dict] = []
    for fp in files:
        if not fp.exists():
            output.print_error(f"File not found: {fp}")
            raise typer.Exit(1)
        raw_bytes = fp.read_bytes()
        content_b64 = base64.b64encode(raw_bytes).decode("ascii")
        api_filename = "handler.py" if fp.suffix == ".py" else "requirements.txt"
        template_files.append(
            {
                "filename": api_filename,
                "language": "python" if fp.suffix == ".py" else "text",
                "fileId": None,
                "content": content_b64,
            }
        )
    client = _client(project_id)
    try:
        data = create_function_version(client, function_id, description, template_files)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        v = data.get("data") or data
        version_id = v.get("id") or v.get("version") or "—"
        output.print_success(f"Function version {version_id} created for {function_id}.")


@app.command(rich_help_panel="Functions")
def get(
    function_id: str = typer.Argument(..., help="Function ID."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Get function details."""
    client = _client(project_id)
    try:
        data = get_function(client, function_id)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        _STATUS_LABELS = {0: "draft", 1: "building", 2: "deployed", 3: "published"}
        rows = []
        for k, v in data.items():
            if isinstance(v, (dict, list)):
                continue
            if k == "status":
                v = _STATUS_LABELS.get(v, str(v))
            rows.append([k, v])
        output.print_table(f"Function: {function_id}", ["Field", "Value"], rows)


@app.command("list", rich_help_panel="Functions")
def list_functions_cmd(
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """List all functions in a project."""
    client = _client(project_id)
    try:
        functions = list_functions(client)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)
    if output.is_json_mode():
        output.print_json(functions)
    else:
        _STATUS_LABELS = {0: "draft", 1: "building", 2: "deployed", 3: "published"}
        output.print_table(
            "Functions",
            ["id", "name", "sdkVersion", "status"],
            [
                [
                    f.get("id", f.get("functionId", "")),
                    f.get("name", ""),
                    f.get("sdkVersion", ""),
                    _STATUS_LABELS.get(f.get("status", -1), "—"),
                ]
                for f in functions
            ],
        )


@app.command(rich_help_panel="Functions")
def logs(
    function_id: str = typer.Argument(..., help="Function ID."),
    version: str = typer.Option("latest", "--version", "-v", help="Version number (1-indexed) or 'latest'."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Show build and deploy logs for a function version."""
    client = _client(project_id)

    if version == "latest":
        version_index = 0
    else:
        try:
            version_index = int(version) - 1
            if version_index < 0:
                raise ValueError
        except ValueError:
            output.print_error("--version must be 'latest' or a positive integer (e.g. 1, 2, 3).")
            raise typer.Exit(1)

    try:
        ver = get_function_logs(client, function_id, version_index)
    except IndexError as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(ver)
        return

    build_logs = ver.get("buildLogs") or ""
    deploy_logs = ver.get("deployLogs") or ""

    output.console.print(f"\n[bold]Build Logs[/bold] (version {version}):")
    if build_logs:
        for line in build_logs.splitlines():
            output.console.print(f"  {line}")
    else:
        output.console.print("  [dim](no build logs)[/dim]")

    output.console.print(f"\n[bold]Deploy Logs[/bold] (version {version}):")
    if deploy_logs:
        for line in deploy_logs.splitlines():
            output.console.print(f"  {line}")
    else:
        output.console.print("  [dim](no deploy logs)[/dim]")


@app.command(rich_help_panel="Functions")
def delete(
    function_id: str = typer.Argument(..., help="Function ID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Delete a function."""
    if not yes:
        typer.confirm(f"Delete function {function_id}?", abort=True)
    client = _client(project_id)
    try:
        delete_function(client, function_id)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json({"deleted": function_id})
    else:
        output.print_success(f"Function {function_id} deleted.")
