from __future__ import annotations

import typer

from quapp.api.client import QuappClient
from quapp.api.projects import create_project, delete_project, get_project, list_projects
from quapp.config import load_config
from quapp import output

app = typer.Typer(help="Manage projects.")


def _client() -> QuappClient:
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp auth login`.")
        raise typer.Exit(1)
    return QuappClient(config.base_url, token=config.token)


@app.command(rich_help_panel="Projects")
def create(
    name: str = typer.Option(..., "--name", "-n", help="Project name."),
    description: str | None = typer.Option(None, "--description", "-d"),
    members: list[str] | None = typer.Option(None, "--member", help="Add member (repeatable)."),
    permission: str = typer.Option("private", "--permission", help="private or group."),
) -> None:
    """Create a new project."""
    client = _client()
    try:
        data = create_project(client, name, description, members, permission)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        project_id = data.get("id") or data.get("projectId") or "—"
        output.print_table(
            "Project Created",
            ["Field", "Value"],
            [["ID", project_id], ["Name", name], ["Permission", permission]],
        )


@app.command(rich_help_panel="Projects")
def get(
    project_id: str = typer.Argument(..., help="Project ID."),
) -> None:
    """Get project details."""
    client = _client()
    try:
        data = get_project(client, project_id)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        rows = [[k, v] for k, v in data.items() if not isinstance(v, (dict, list))]
        output.print_table(f"Project: {project_id}", ["Field", "Value"], rows)


@app.command(rich_help_panel="Projects")
def delete(
    project_id: str = typer.Argument(..., help="Project ID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Delete a project."""
    if not yes:
        typer.confirm(f"Delete project {project_id}?", abort=True)
    client = _client()
    try:
        delete_project(client, project_id)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json({"deleted": project_id})
    else:
        output.print_success(f"Project {project_id} deleted.")


@app.command("list", rich_help_panel="Projects")
def list_projects_cmd() -> None:
    """List all projects."""
    client = _client()
    try:
        projects = list_projects(client)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)
    if output.is_json_mode():
        output.print_json(projects)
    else:
        output.print_table(
            "Projects",
            ["id", "name", "status"],
            [[p.get("id", ""), p.get("name", ""), p.get("status", "")] for p in projects],
        )
