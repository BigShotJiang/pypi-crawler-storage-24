from __future__ import annotations

import time

import typer

from quapp.api.client import QuappClient
from quapp.api.jobs import (
    cancel_job,
    get_job_results,
    get_job_status,
    list_jobs,
    retry_job,
    run_job,
)
from quapp.config import load_config
from quapp import output

app = typer.Typer(help="Manage jobs.")

_TERMINAL_STATUSES = {"DONE", "FAILED", "CANCELLED", "CANCELED", "ERROR"}
_IN_PROGRESS_STATUSES = {"IN_QUEUE", "RUNNING", "PENDING", "QUEUED", "NEW", "INITIALIZING", "SUBMITTED"}
_POLL_INITIAL = 2.0   # seconds
_POLL_MAX = 30.0      # seconds


def _client(project_id: str | None = None) -> QuappClient:
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp auth login`.")
        raise typer.Exit(1)
    return QuappClient(config.base_url, token=config.token, project_id=project_id or config.project_id)


def _poll_until_done(client: QuappClient, job_id: str) -> dict:
    """Poll via list endpoint (GET /jobs) filtering by ID with exponential backoff until terminal status."""
    delay = _POLL_INITIAL
    while True:
        status_data = get_job_status(client, job_id)
        status = status_data.get("status") or ""
        if status in _TERMINAL_STATUSES:
            return status_data
        elif status not in _IN_PROGRESS_STATUSES:
            output.print_error(f"Unexpected job status: {status!r}")
            raise typer.Exit(1)
        output.console.print(f"  [dim]status: {status or '?'} — waiting {delay:.0f}s…[/dim]")
        time.sleep(delay)
        delay = min(delay * 2, _POLL_MAX)


@app.command(rich_help_panel="Jobs")
def run(
    function_id: str = typer.Option(..., "--function", help="Function ID."),
    provider: str = typer.Option(..., "--provider", help="Provider (e.g. aws, ibm)."),
    device: str = typer.Option(..., "--device", help="Device name."),
    shots: int = typer.Option(1000, "--shots", help="Number of shots."),
    wait: bool = typer.Option(False, "--wait", help="Poll until job completes."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Create and invoke a job."""
    client = _client(project_id)
    try:
        data = run_job(client, function_id, provider, device, shots)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    job_id = data.get("jobId") or data.get("id") or "—"

    if wait and job_id != "—":
        output.console.print(f"Job [bold]{job_id}[/bold] submitted. Waiting for completion…")
        try:
            final_job = _poll_until_done(client, job_id)
        except Exception as exc:
            output.format_error(exc)
            raise typer.Exit(1)
        status = final_job.get("status", "")
        if output.is_json_mode():
            output.print_json(final_job)
        else:
            output.print_success(f"Job {job_id} finished: {status}")
            if status == "DONE":
                output.print_job_extras(final_job)
                output.print_job_result(final_job.get("jobResult"), job_id)
        return

    if output.is_json_mode():
        output.print_json(data)
    else:
        output.print_table("Job Submitted", ["Field", "Value"], [["Job ID", job_id]])


@app.command("list", rich_help_panel="Jobs")
def list_jobs_cmd(
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """List all jobs in a project."""
    client = _client(project_id)
    try:
        jobs = list_jobs(client)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    if output.is_json_mode():
        output.print_json(jobs)
    else:
        output.print_table(
            "Jobs",
            ["id", "status", "statusDetail", "function"],
            [
                [
                    j.get("id", j.get("jobId", "")),
                    j.get("status", ""),
                    j.get("statusDetail", ""),
                    (j.get("function") or {}).get("name", ""),
                ]
                for j in jobs
            ],
        )


@app.command(rich_help_panel="Jobs")
def status(
    job_id: str = typer.Argument(..., help="Job ID."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Check job status."""
    client = _client(project_id)
    try:
        data = get_job_status(client, job_id)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        rows = [
            ["id", data.get("id") or data.get("jobId", "—")],
            ["status", data.get("status", "—")],
            ["statusDetail", data.get("statusDetail", "—")],
            ["ranTimestamp", data.get("ranTimestamp", "—")],
            ["finishedTimestamp", data.get("finishedTimestamp", "—")],
            ["retry", data.get("retry", "—")],
            ["shots", data.get("shots", "—")],
            ["device", data.get("device", "—")],
            ["provider", data.get("provider", "—")],
        ]
        output.print_table(f"Job: {job_id}", ["Field", "Value"], rows)


@app.command(rich_help_panel="Jobs")
def results(
    job_id: str = typer.Argument(..., help="Job ID."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Retrieve job results and logs."""
    client = _client(project_id)
    try:
        data = get_job_results(client, job_id)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        rows = [
            ["status", data.get("status", "—")],
            ["shots", data.get("shots", "—")],
            ["processor", data.get("processor", "—")],
            ["ranTimestamp", data.get("ranTimestamp", "—")],
            ["finishedTimestamp", data.get("finishedTimestamp", "—")],
        ]
        output.print_table(f"Job: {job_id}", ["Field", "Value"], rows)
        output.print_job_extras(data)
        output.print_job_result(data.get("jobResult"), job_id)


@app.command(rich_help_panel="Jobs")
def cancel(
    job_id: str = typer.Argument(..., help="Job ID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Cancel a running job."""
    if not yes:
        typer.confirm(f"Cancel job {job_id}?", abort=True)
    client = _client(project_id)
    try:
        cancel_job(client, job_id)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json({"cancelled": job_id})
    else:
        output.print_success(f"Job {job_id} cancelled.")


@app.command(rich_help_panel="Jobs")
def retry(
    job_id: str = typer.Argument(..., help="Job ID."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Retry a failed job."""
    client = _client(project_id)
    try:
        data = retry_job(client, job_id)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    new_id = data.get("jobId") or data.get("id") or "—"
    if output.is_json_mode():
        output.print_json(data)
    else:
        output.print_success(f"Job retried. New job ID: {new_id}")


@app.command(
    rich_help_panel="Jobs",
    epilog=(
        "Examples:\n"
        "  quapp job watch abc-123\n"
        "  quapp watch abc-123          # top-level shortcut (same behaviour)"
    ),
)
def watch(
    job_id: str = typer.Argument(..., help="Job ID to watch."),
    interval: int = typer.Option(3, "--interval", help="Polling interval in seconds (default: 3)."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Live-poll a job until it reaches a terminal state."""
    if output.is_json_mode():
        output.err_console.print(
            "Error: --json is incompatible with interactive watch mode. "
            "Use `quapp job status <id>` to poll programmatically."
        )
        raise typer.Exit(1)

    from quapp.tui.dashboard import run_dashboard
    client = _client(project_id)
    run_dashboard(client, job_id)
