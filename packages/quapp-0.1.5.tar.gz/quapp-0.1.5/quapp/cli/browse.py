"""Entry point for the `quapp browse` interactive browser."""
from __future__ import annotations

import typer

from quapp.api.client import QuappClient
from quapp.config import load_config
from quapp import output
from quapp.tui.browser import run_browser


def browse_cmd(
    fallback: bool = typer.Option(False, "--fallback", help="Force numbered-menu mode (useful on Git Bash)."),
) -> None:
    """Interactive three-pane browser: explore projects, functions, and jobs."""
    if output.is_json_mode():
        output.err_console.print(
            "Error: --json is incompatible with interactive TUI mode. "
            "Use individual commands (e.g. `quapp project list`) for scriptable output."
        )
        raise typer.Exit(1)

    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp login`.")
        raise typer.Exit(1)

    client = QuappClient(config.base_url, token=config.token)
    run_browser(client, fallback=fallback)
