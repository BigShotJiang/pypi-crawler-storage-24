from __future__ import annotations

import typer

from quapp.api.client import QuappClient
from quapp.api.sdks import list_sdks
from quapp.config import load_config
from quapp import output


def sdk_cmd() -> None:
    """List available SDKs and versions."""
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp login`.")
        raise typer.Exit(1)
    client = QuappClient(config.base_url, token=config.token)
    try:
        sdks = list_sdks(client)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)
    if output.is_json_mode():
        output.print_json(sdks)
    else:
        output.print_table(
            "Available SDKs",
            ["name", "version"],
            [
                [s.get("name", ""), s.get("version", "")]
                for s in sdks
            ],
        )
