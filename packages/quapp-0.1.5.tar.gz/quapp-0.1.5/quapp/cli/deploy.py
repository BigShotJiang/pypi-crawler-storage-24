from __future__ import annotations

import base64
import json
from pathlib import Path

import typer

from quapp.api.client import QuappClient
from quapp.api.deploy import find_or_create_project, find_or_create_function, wait_until_deployed
from quapp.api.functions import create_function_version
from quapp.api.jobs import run_job, get_job_status
from quapp.api.providers import find_provider_by_name, find_device_by_name
from quapp.config import load_config
from quapp import output

def _poll_until_done(client: QuappClient, job_id: str) -> dict:
    """Poll job status via poll_with_spinner until terminal state."""
    return output.poll_with_spinner(
        poll_fn=lambda: get_job_status(client, job_id),
        interval=3.0,
        label=f"Waiting for job {job_id}",
    )


def deploy_cmd(
    project: str = typer.Option(..., "--project", help="Project name (find or create)."),
    function: str = typer.Option(..., "--function", help="Function name (find or create)."),
    handler: Path = typer.Option(..., "--handler", help="Path to handler .py file."),
    sdk_version: str | None = typer.Option(None, "--sdk-version", help="SDK version (required when creating a new function)."),
    requirements: Path | None = typer.Option(None, "--requirements", help="Path to requirements.txt (auto-detected if omitted)."),
    device: str = typer.Option(..., "--device", help="Device name."),
    provider: str = typer.Option("5", "--provider", help="Provider name or ID (default: 5)."),
    shots: int = typer.Option(1024, "--shots", help="Number of shots (10-8000)."),
    input_pairs: list[str] = typer.Option([], "--input", help="Input as KEY=VALUE (repeatable)."),
    wait: bool = typer.Option(False, "--wait", help="Poll job until terminal state."),
) -> None:
    """Upload a handler, deploy it, and run a job — all in one command."""

    # Pre-flight validation
    if not 10 <= shots <= 8000:
        output.print_error("--shots must be between 10 and 8000.")
        raise typer.Exit(1)

    if not handler.exists():
        output.print_error(f"Handler file not found: {handler}")
        raise typer.Exit(1)

    if handler.suffix != ".py":
        output.print_error("--handler must be a .py file.")
        raise typer.Exit(1)

    # Config
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp login`.")
        raise typer.Exit(1)

    client = QuappClient(config.base_url, token=config.token)

    # Step 1: Project
    try:
        proj = find_or_create_project(client, project)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    project_id = str(proj["id"])
    output.console.print(f"[green]OK[/green] Project: {proj.get('name', project_id)} ({project_id})")

    project_client = QuappClient(config.base_url, token=config.token, project_id=project_id)

    # Step 2: Function
    try:
        func = find_or_create_function(project_client, function, sdk_version)
    except ValueError as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    function_id = str(func["id"])
    output.console.print(f"[green]OK[/green] Function: {func.get('name', function_id)} ({function_id})")

    # Step 3: Upload version + wait for deploy
    handler_abs = handler.resolve()
    req_path = requirements
    if req_path is None:
        auto_req = handler_abs.parent / "requirements.txt"
        if auto_req.exists():
            req_path = auto_req
            output.console.print(f"Using requirements: {req_path}")

    template_files: list[dict] = [
        {
            "filename": "handler.py",
            "language": "python",
            "fileId": None,
            "content": base64.b64encode(handler_abs.read_bytes()).decode("ascii"),
        }
    ]
    if req_path is not None:
        template_files.append({
            "filename": "requirements.txt",
            "language": "text",
            "fileId": None,
            "content": base64.b64encode(Path(req_path).read_bytes()).decode("ascii"),
        })

    try:
        ver_data = create_function_version(project_client, function_id, None, template_files)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    raw = ver_data.get("data") or ver_data
    version_id = str(raw.get("id") or raw.get("versionId") or "")
    output.console.print("[dim]Deploying…[/dim]")

    try:
        ver = wait_until_deployed(project_client, function_id, version_id)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    build_logs = ver.get("buildLogs") or ""
    last_lines = [ln for ln in build_logs.splitlines() if ln.strip()][-5:]
    for ln in last_lines:
        output.console.print(f"  [dim]{ln}[/dim]")
    output.console.print(f"[green]OK[/green] Deployed version {version_id}")

    # Step 4: Resolve device
    try:
        provider_obj = find_provider_by_name(client, provider)
        device_obj = find_device_by_name(client, provider_obj["id"], device)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    device_id = str(device_obj["id"])

    # Step 5: Parse inputs
    invocation_input: dict = {}
    for pair in input_pairs:
        if "=" not in pair:
            output.print_error(f"--input must be KEY=VALUE, got: {pair!r}")
            raise typer.Exit(1)
        k, v = pair.split("=", 1)
        try:
            invocation_input[k] = json.loads(v)
        except json.JSONDecodeError:
            invocation_input[k] = v

    # Step 6: Submit job
    try:
        data = run_job(
            project_client,
            function_name=func.get("name", function_id),
            provider=provider_obj.get("name", provider),
            device=device_id,
            shots=shots,
            invocation_input=invocation_input if invocation_input else None,
        )
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    job_id = data.get("jobId") or data.get("id") or "—"

    if wait and job_id != "—":
        try:
            final_job = _poll_until_done(project_client, job_id)
        except KeyboardInterrupt:
            output.console.print("\n[dim]Detached — job continues running on the platform.[/dim]")
            raise typer.Exit(0)
        except Exception as exc:
            output.format_error(exc)
            raise typer.Exit(1)
        status = final_job.get("status", "")
        output.print_success(f"Job {job_id} finished: {status}")
        if status == "DONE":
            output.print_job_extras(final_job)
            output.print_job_result(final_job.get("jobResult"), job_id)
        return

    if output.is_json_mode():
        output.print_json(data)
    else:
        output.print_table("Job Submitted", ["Field", "Value"], [
            ["Job ID", job_id],
            ["Project", proj.get("name", project_id)],
            ["Function", func.get("name", function_id)],
            ["Device", device_obj.get("name", device_id)],
            ["Shots", shots],
        ])
