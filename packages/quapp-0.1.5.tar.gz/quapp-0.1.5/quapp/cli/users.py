from __future__ import annotations

import typer

from quapp.api.client import QuappClient
from quapp.api.users import decode_user_id_from_token, get_current_user
from quapp.config import load_config
from quapp import output


def whoami_cmd() -> None:
    """Show the currently authenticated user."""
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp login`.")
        raise typer.Exit(1)

    user_id = decode_user_id_from_token(config.token)
    if not user_id:
        output.print_error("Could not decode user ID from token. Try `quapp logout` then `quapp login`.")
        raise typer.Exit(1)

    client = QuappClient(config.base_url, token=config.token)
    try:
        data = get_current_user(client, user_id)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)

    if output.is_json_mode():
        output.print_json(data)
    else:
        output.print_table(
            "Current User",
            ["Field", "Value"],
            [
                ["ID", data.get("id", user_id)],
                ["Name", data.get("name", "—")],
                ["Email", data.get("email", "—")],
            ],
        )
