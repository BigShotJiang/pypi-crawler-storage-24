from __future__ import annotations

import json
import typer

from quapp.config import load_config, save_config
from quapp import output


def login(
    email: str | None = typer.Option(None, "--email", "-e", help="Email address."),
    password: str | None = typer.Option(None, "--password", help="Password.", hide_input=True),
) -> None:
    """Authenticate with email + password and save token."""
    config = load_config()
    if email is None:
        email = typer.prompt("Email")
    if password is None:
        password = typer.prompt("Password", hide_input=True)
    try:
        from quapp.api.auth import login as api_login
        data = api_login(config.base_url, email, password)
    except Exception as exc:
        msg = str(exc)
        try:
            payload = json.loads(msg)
            msgs = [e.get("message", "") for e in payload.get("errors", []) if e.get("message")]
            if msgs:
                msg = "; ".join(msgs)
        except Exception:
            pass
        output.print_error(msg or "Login failed. Check your credentials and try again.")
        raise typer.Exit(1)

    token = data.get("accessToken") or data.get("token")
    if not token:
        output.print_error("Login response did not contain an access token.")
        raise typer.Exit(1)

    config.token = token
    save_config(config)

    if output.is_json_mode():
        output.print_json({"status": "logged_in", "email": email})
    else:
        output.print_success(f"Logged in as {email}.")


def logout() -> None:
    """Invalidate session and clear local token."""
    config = load_config()
    if not config.token:
        output.print_error("Not logged in.")
        raise typer.Exit(1)
    try:
        from quapp.api.auth import logout as api_logout
        api_logout(config.base_url, config.token)
    except Exception as exc:
        output.print_error(str(exc))
        raise typer.Exit(1)
    finally:
        config.token = None
        save_config(config)

    if output.is_json_mode():
        output.print_json({"status": "logged_out"})
    else:
        output.print_success("Logged out.")
