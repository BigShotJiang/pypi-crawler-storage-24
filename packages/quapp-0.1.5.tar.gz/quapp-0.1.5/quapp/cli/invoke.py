from __future__ import annotations
import json
import typer
from quapp.api.client import QuappClient, QuappError
from quapp.api.projects import find_project_by_name
from quapp.api.functions import find_function_by_name
from quapp.api.providers import list_devices, find_device_by_name, find_provider_by_name
from quapp.api.jobs import run_job, list_jobs, get_job_status
from quapp.cli.jobs import _poll_until_done
from quapp.config import load_config
from quapp import output

app = typer.Typer(
    help="Invoke a function by name, resolving project/function/device.",
    rich_help_panel="Workflows",
    epilog=(
        "Examples:\n"
        "  quapp invoke --project my-proj --function qec --device aer_simulator --shots 1024\n"
        "  quapp invoke --project my-proj --function qec --device aer_simulator --shots 1024 --wait"
    ),
)

def _client(project_id: str | None = None) -> QuappClient:
    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp auth login`.")
        raise typer.Exit(1)
    return QuappClient(config.base_url, token=config.token, project_id=project_id)

@app.command()
def invoke(
    project: str = typer.Option(..., "--project", help="Project name or ID."),
    function: str = typer.Option(..., "--function", help="Function name or ID."),
    device: str = typer.Option(..., "--device", help="Device name."),
    provider: str = typer.Option("5", "--provider", help="Provider name or ID (default: 5)."),
    shots: int = typer.Option(1024, "--shots", help="Number of shots (10–8000)."),
    input_pairs: list[str] = typer.Option([], "--input", help="Input as KEY=VALUE (JSON-decoded value). Repeatable."),
    wait: bool = typer.Option(False, "--wait", help="Poll until job completes."),
) -> None:
    """Resolve names to IDs and submit a job in one command."""
    # Validate shots
    if not 10 <= shots <= 8000:
        output.print_error("--shots must be between 10 and 8000.")
        raise typer.Exit(1)

    # Step 1: resolve project
    base_client = _client()
    try:
        proj = find_project_by_name(base_client, project)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    project_id = str(proj["id"])

    # Step 2: resolve function (need project-scoped client)
    project_client = _client(project_id)
    try:
        func = find_function_by_name(project_client, function)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    function_id = str(func["id"])

    # Step 3: resolve provider then device
    try:
        provider_obj = find_provider_by_name(base_client, provider)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    provider_id = provider_obj["id"]
    provider_name = provider_obj.get("name", provider)

    try:
        device_obj = find_device_by_name(base_client, provider_id, device)
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)
    device_id = str(device_obj["id"])

    # Step 4: parse --input KEY=VALUE pairs
    invocation_input: dict = {}
    for pair in input_pairs:
        if "=" not in pair:
            output.print_error(f"--input must be KEY=VALUE, got: {pair!r}")
            raise typer.Exit(1)
        k, v = pair.split("=", 1)
        try:
            invocation_input[k] = json.loads(v)
        except json.JSONDecodeError:
            invocation_input[k] = v  # treat as plain string

    # Step 5: submit job
    try:
        data = run_job(
            project_client,
            function_name=func.get("name", function_id),
            provider=provider_name,
            device=device_id,
            shots=shots,
            invocation_input=invocation_input if invocation_input else None,
        )
    except Exception as exc:
        output.format_error(exc)
        raise typer.Exit(1)

    job_id = data.get("jobId") or data.get("id") or "—"

    if wait and job_id != "—":
        try:
            final_job = output.poll_with_spinner(
                poll_fn=lambda: get_job_status(project_client, job_id),
                interval=3.0,
                label=f"Waiting for job {job_id}",
            )
        except KeyboardInterrupt:
            output.console.print("\n[dim]Detached — job continues running on the platform.[/dim]")
            raise typer.Exit(0)
        except Exception as exc:
            output.format_error(exc)
            raise typer.Exit(1)
        status = final_job.get("status", "")
        if output.is_json_mode():
            output.print_json(final_job)
        else:
            output.print_success(f"Job {job_id} finished: {status}")
            if status == "DONE":
                output.print_job_extras(final_job)
                output.print_job_result(final_job.get("jobResult"), job_id)
        return

    if output.is_json_mode():
        output.print_json(data)
    else:
        output.print_table("Job Submitted", ["Field", "Value"], [
            ["Job ID", job_id],
            ["Project", proj.get("name", project_id)],
            ["Function", func.get("name", function_id)],
            ["Device", device_obj.get("name", device_id)],
            ["Shots", shots],
        ])
