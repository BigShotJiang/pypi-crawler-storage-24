"""Top-level `quapp watch <job-id>` shortcut command."""
from __future__ import annotations

import typer

from quapp.api.client import QuappClient
from quapp.config import load_config
from quapp import output
from quapp.tui.dashboard import run_dashboard


def watch_cmd(
    job_id: str = typer.Argument(..., help="Job ID to watch."),
    project_id: str | None = typer.Option(None, "--project", "-p", help="Project ID (overrides config)."),
) -> None:
    """Live job dashboard — watch a job until it completes."""
    if output.is_json_mode():
        output.err_console.print(
            "Error: --json is incompatible with interactive watch mode. "
            "Use `quapp job status <id>` to poll programmatically."
        )
        raise typer.Exit(1)

    config = load_config()
    if not config.token:
        output.print_error("Not logged in. Run `quapp login`.")
        raise typer.Exit(1)

    pid = project_id or config.project_id
    client = QuappClient(config.base_url, token=config.token, project_id=pid)
    run_dashboard(client, job_id)
