from __future__ import annotations

import typer

from quapp import output
from quapp.cli import deploy as deploy_cmd, functions, invoke as invoke_cmd, jobs, projects, sdks, tui_cmd
from quapp.cli.watch import watch_cmd
from quapp.cli.auth import login, logout
#from quapp.cli.users import whoami_cmd
from quapp.cli.browse import browse_cmd
app = typer.Typer(
    name="quapp",
    help="Quapp quantum/cloud computing platform CLI.",
    epilog=(
        "Examples:\n\n"
        "  # Re-deploy existing function and run a job:\n"
        "  quapp deploy --project 518 --function qecdummies --handler tests/handler_qec.py"
        " --provider 5 --device aer_simulator --shots 1024"
        " --input 'p_values=[0.001,0.005,0.01,0.02,0.05,0.1]'"
        " --input 'shots=1024' --input 'error_types=[\"X\",\"Z\",\"dep\"]'"
        " --input 'noiseless=true' --wait\n\n"
        "\n\n"
        "  # Create a new function and run a job:\n"
        "  quapp deploy --project 518 --function my-new-function --sdk-version 0.45.3"
        " --handler tests/handler_qec.py --provider 5 --device aer_simulator --shots 1024"
        " --input 'p_values=[0.001,0.005,0.01,0.02,0.05,0.1]'"
        " --input 'shots=1024' --input 'error_types=[\"X\",\"Z\",\"dep\"]'"
        " --input 'noiseless=true' --wait"
        "\n\n"
        "\n\nShell completion: run `quapp --install-completion` then `source ~/.bashrc`"
        " (or `~/.bash_profile`) to activate tab completion on Git Bash."
    ),
    no_args_is_help=True,
    add_completion=False,
)

app.command("login")(login)
app.command("logout")(logout)
#app.command("whoami")(whoami_cmd)
app.add_typer(projects.app, name="project")
app.add_typer(functions.app, name="function")
app.add_typer(jobs.app, name="job")
app.command("sdk")(sdks.sdk_cmd)
app.add_typer(invoke_cmd.app, name="invoke", rich_help_panel="Workflows")
app.command(
    "deploy",
    rich_help_panel="Workflows",
    epilog=(
        "Examples:\n"
        "  quapp deploy --project my-proj --function qec --handler ./handler.py"
        " --device aer_simulator --provider Quapp --shots 1024\n"
        "  quapp deploy --project my-proj --function qec --handler ./handler.py"
        " --device aer_simulator --provider Quapp --shots 1024 --wait"
    ),
)(deploy_cmd.deploy_cmd)
app.command(
    "watch",
    rich_help_panel="Workflows",
    epilog=(
        "Examples:\n"
        "  quapp watch abc-123\n"
        "  quapp job watch abc-123    # equivalent via job subcommand"
    ),
)(watch_cmd)
app.add_typer(tui_cmd.app, name="tui")
app.command("browse", rich_help_panel="Workflows")(browse_cmd)


@app.callback()
def main(
    json: bool = typer.Option(False, "--json", help="Output raw JSON instead of Rich tables."),
) -> None:
    output.set_json_mode(json)
