from __future__ import annotations
import typer

app = typer.Typer(help="Launch the interactive TUI.")

@app.callback(invoke_without_command=True)
def tui(ctx: typer.Context) -> None:
    """Launch the Quapp interactive TUI."""
    if ctx.invoked_subcommand is None:
        from quapp.tui.app import QuappTuiApp
        QuappTuiApp().run()
