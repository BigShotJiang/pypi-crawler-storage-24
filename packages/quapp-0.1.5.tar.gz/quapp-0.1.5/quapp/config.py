from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_DIR = Path.home() / ".quapp"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_BASE_URL = "https://functions.quapp.cloud/api/v1"


@dataclass
class Config:
    """Runtime configuration loaded from ~/.quapp/config.json.

    Attributes:
        token: Bearer token obtained after `quapp auth login`.
        base_url: API base URL (default: https://functions.quapp.cloud/api/v1).
        project_id: Optional project ID sent as X-Project-Id header.
    """
    token: str | None = None
    base_url: str = field(default=DEFAULT_BASE_URL)
    project_id: str | None = None


def load_config() -> Config:
    if not CONFIG_FILE.exists():
        return Config()
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return Config(
            token=data.get("token"),
            base_url=data.get("base_url", DEFAULT_BASE_URL),
            project_id=data.get("project_id"),
        )
    except (json.JSONDecodeError, OSError):
        return Config()


def save_config(config: Config) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps(
            {
                "token": config.token,
                "base_url": config.base_url,
                "project_id": config.project_id,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    # Restrict permissions on non-Windows platforms
    if os.name != "nt":
        CONFIG_FILE.chmod(0o600)
