"""Live job dashboard — shared renderer for `quapp watch` and `quapp job watch`."""
from __future__ import annotations

import time
from datetime import datetime

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from quapp.api.client import QuappClient
from quapp.api.jobs import get_job_status
from quapp.cli.jobs import _TERMINAL_STATUSES
from quapp import output


def _format_elapsed(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _build_panel(job: dict, job_id: str, elapsed: float) -> Panel:
    """Build the Rich panel for a job's current state."""
    status = job.get("status", "?")
    function_name = job.get("functionName") or job.get("function", {}).get("name", "?")
    provider = job.get("providerName") or job.get("provider", {}).get("name", "?")

    # Header grid
    header = Table.grid(padding=(0, 2))
    header.add_column()
    header.add_column()
    header.add_column()
    header.add_column()
    header.add_row(
        "Status", f"[bold]{status}[/bold]",
        "Elapsed", _format_elapsed(elapsed),
    )
    header.add_row(
        "Function", function_name,
        "Provider", provider,
    )

    # Log section
    logs = job.get("logs")
    if not logs:
        log_text = Text("Log streaming not available", style="dim")
    else:
        entries = logs[-10:] if isinstance(logs, list) else []
        lines = []
        for entry in entries:
            if isinstance(entry, dict):
                ts = entry.get("timestamp", "")
                if ts and len(ts) >= 8:
                    ts_fmt = ts[11:19] if "T" in ts else ts[:8]
                else:
                    ts_fmt = datetime.now().strftime("%H:%M:%S")
                msg = entry.get("message", str(entry))
            else:
                ts_fmt = datetime.now().strftime("%H:%M:%S")
                msg = str(entry)
            lines.append(f"[dim][{ts_fmt}][/dim] {msg}")
        log_text = Text.from_markup("\n".join(lines) or "[dim](no log entries)[/dim]")

    layout = Layout()
    layout.split_column(
        Layout(header, name="header", size=3),
        Layout(Panel(log_text, title="Log"), name="log"),
    )

    color = "green" if status == "DONE" else "red" if status in {"FAILED", "ERROR"} else "cyan"
    return Panel(layout, title=f"[{color}]Job: {job_id}[/{color}]",
                 subtitle="Press Ctrl+C to detach (job keeps running)")


def run_dashboard(client: QuappClient, job_id: str) -> None:
    """Run the live job dashboard. Blocks until terminal status or Ctrl+C."""
    start = time.monotonic()
    console = Console()

    try:
        with Live(refresh_per_second=1, console=console) as live:
            while True:
                try:
                    job = get_job_status(client, job_id)
                except Exception as exc:
                    output.format_error(exc)
                    return

                elapsed = time.monotonic() - start
                live.update(_build_panel(job, job_id, elapsed))

                status = job.get("status", "")
                if status in _TERMINAL_STATUSES:
                    break

                time.sleep(2)

    except KeyboardInterrupt:
        output.console.print("\n[dim]Detached — job continues running on the platform.[/dim]")
        return

    # Job complete — print extras below the frozen panel
    output.print_job_extras(job)
    output.print_job_result(job.get("jobResult"), job_id)
