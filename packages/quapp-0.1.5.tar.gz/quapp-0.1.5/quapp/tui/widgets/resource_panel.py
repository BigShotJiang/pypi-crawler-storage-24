from __future__ import annotations
from textual.widget import Widget
from textual.widgets import ListView, ListItem, Label
from textual.reactive import reactive
from textual.app import ComposeResult

class ResourcePanel(Widget):
    """A titled panel containing a scrollable ListView of items."""

    COMPONENT_CLASSES = {"resource-panel--title", "resource-panel--item"}

    items: reactive[list[dict]] = reactive(list, recompose=True)

    def __init__(self, title: str, item_label_fn=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self._title = title
        self._item_label_fn = item_label_fn or (lambda item: str(item))

    def compose(self) -> ComposeResult:
        yield Label(self._title, classes="panel-title")
        yield ListView(
            *[ListItem(Label(self._item_label_fn(item)), id=f"item-{i}")
              for i, item in enumerate(self.items)],
            id="list-view",
        )

    def update_items(self, items: list[dict]) -> None:
        self.items = items
