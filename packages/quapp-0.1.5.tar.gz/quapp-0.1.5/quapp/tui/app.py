from __future__ import annotations
from textual.app import App, ComposeResult
from quapp.config import load_config

CSS_PATH = "app.tcss"

class QuappTuiApp(App):
    """Quapp interactive TUI."""
    TITLE = "Quapp"
    CSS_PATH = CSS_PATH

    def on_mount(self) -> None:
        config = load_config()
        if not config.token:
            from quapp.tui.screens.login import LoginScreen
            self.push_screen(LoginScreen())
        else:
            from quapp.tui.screens.main import MainScreen
            self.push_screen(MainScreen())
