from __future__ import annotations

import time
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Button, Label, LoadingIndicator, Log, Static
from textual.containers import Vertical, Horizontal, ScrollableContainer
from textual import work

from quapp.api.client import QuappClient
from quapp.api.functions import (
    create_function,
    create_function_version,
    get_function,
    list_function_versions,
)
from quapp.config import load_config


def _read_file_b64(path: str | None) -> str | None:
    """Read a file and return base64-encoded content, or None if path is None/missing."""
    if not path:
        return None
    import base64
    try:
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode("ascii")
    except OSError:
        return None


class DeployStatusScreen(Screen):
    """Screen that creates a function and polls deploy status."""

    BINDINGS = [
        ("escape", "go_back", "Back"),
        ("q", "quit_app", "Quit"),
    ]

    DEFAULT_CSS = """
    DeployStatusScreen {
        align: center middle;
    }
    DeployStatusScreen > Vertical {
        width: 80%;
        height: 80%;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }
    DeployStatusScreen .status-label {
        text-style: bold;
        margin-bottom: 1;
    }
    DeployStatusScreen .button-row {
        height: 3;
        align: right middle;
        margin-top: 1;
    }
    """

    def __init__(
        self,
        function_id: str | None = None,
        project_id: str | None = None,
        create_params: dict | None = None,
        **kwargs,
    ) -> None:
        """
        Either deploy an existing function (function_id set) or
        create + deploy a new one (create_params set).
        """
        super().__init__(**kwargs)
        self._function_id = function_id
        self._project_id = project_id
        self._create_params = create_params
        self._config = load_config()
        self._done = False
        self._success = False

    def _make_client(self, project_id: str | None = None) -> QuappClient:
        return QuappClient(
            self._config.base_url,
            token=self._config.token,
            project_id=project_id or self._project_id,
        )

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Deploy Status", classes="status-label")
            yield LoadingIndicator(id="spinner")
            yield Static("Initialising…", id="status-text")
            yield ScrollableContainer(
                Log(id="log-view", auto_scroll=True),
                id="log-container",
            )
            with Horizontal(classes="button-row", id="button-row"):
                yield Button("Back", id="btn-back", variant="default")

    def on_mount(self) -> None:
        self.start_deploy()

    @work(thread=True)
    def start_deploy(self) -> None:
        client = self._make_client()

        def update_status(msg: str) -> None:
            self.app.call_from_thread(self._set_status, msg)

        def append_log(line: str) -> None:
            self.app.call_from_thread(self._append_log_line, line)

        try:
            # Step 1: create function if needed
            if self._create_params and not self._function_id:
                update_status("Creating function…")
                result = create_function(
                    client,
                    name=self._create_params["name"],
                    sdk_version="0.45.3",
                    lang="python",
                    description=self._create_params.get("description"),
                )
                self._function_id = str(result.get("id") or result.get("data", {}).get("id", ""))
                append_log(f"Function created: id={self._function_id}")

            # Step 2: upload version if handler file provided
            if self._create_params and self._create_params.get("handler_path"):
                update_status("Uploading version…")
                files = []
                handler_b64 = _read_file_b64(self._create_params["handler_path"])
                if handler_b64:
                    files.append({
                        "fileName": "handler.py",
                        "content": handler_b64,
                        "isBase64": True,
                    })
                req_b64 = _read_file_b64(self._create_params.get("req_path"))
                if req_b64:
                    files.append({
                        "fileName": "requirements.txt",
                        "content": req_b64,
                        "isBase64": True,
                    })
                if files:
                    create_function_version(
                        client,
                        self._function_id,
                        description=None,
                        files=files,
                    )
                    append_log("Version uploaded.")

            # Step 3: poll for deploy status
            if not self._function_id:
                self.app.call_from_thread(self._deploy_failed, "No function ID — cannot poll deploy status.")
                return

            update_status("Polling deploy status…")
            poll_interval = 3
            max_polls = 40
            for attempt in range(max_polls):
                versions = list_function_versions(client, self._function_id)
                if versions:
                    latest = versions[0] if isinstance(versions, list) and versions else None
                    if isinstance(latest, dict) and latest.get("inDeployed"):
                        self.app.call_from_thread(self._deploy_success, {})
                        return
                    latest = versions[0] if versions else {}
                    build_snippet = (latest.get("buildLogs") or "")[-500:]
                    deploy_snippet = (latest.get("deployLogs") or "")[-200:]
                    append_log(f"── Poll {attempt+1}/{max_polls} ──")
                    if build_snippet:
                        for line in build_snippet.splitlines()[-5:]:
                            append_log(f"[BUILD] {line}")
                    if deploy_snippet:
                        for line in deploy_snippet.splitlines()[-3:]:
                            append_log(f"[DEPLOY] {line}")
                else:
                    append_log(f"Poll {attempt+1}/{max_polls}: no versions yet…")
                time.sleep(poll_interval)

            # Timeout — fetch function for logs
            func = get_function(client, self._function_id)
            self.app.call_from_thread(self._deploy_failed_with_logs, func)

        except Exception as e:
            self.app.call_from_thread(self._deploy_failed, str(e))

    def _set_status(self, msg: str) -> None:
        self.query_one("#status-text", Static).update(msg)

    def _append_log_line(self, line: str) -> None:
        self.query_one("#log-view", Log).write_line(line)

    def _deploy_success(self, func: dict) -> None:
        self.query_one("#spinner", LoadingIndicator).display = False
        self.query_one("#status-text", Static).update("[green]✓ Deployed successfully![/green]")
        btn_row = self.query_one("#button-row", Horizontal)
        btn_row.mount(Button("Create Job", id="btn-create-job", variant="success"))

    def _deploy_failed(self, reason: str) -> None:
        self.query_one("#spinner", LoadingIndicator).display = False
        self.query_one("#status-text", Static).update(f"[red]✗ Deploy failed: {reason}[/red]")

    def _deploy_failed_with_logs(self, func: dict) -> None:
        self.query_one("#spinner", LoadingIndicator).display = False
        self.query_one("#status-text", Static).update("[red]✗ Deploy timed out.[/red]")
        log_view = self.query_one("#log-view", Log)
        for line in (func.get("buildLogs") or "").splitlines():
            log_view.write_line(f"[BUILD] {line}")
        for line in (func.get("deployLogs") or "").splitlines():
            log_view.write_line(f"[DEPLOY] {line}")
        btn_row = self.query_one("#button-row", Horizontal)
        btn_row.mount(Button("View Logs", id="btn-view-logs", variant="warning"))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-back":
            self.app.pop_screen()
        elif event.button.id == "btn-create-job":
            from quapp.tui.modals.invoke import InvokeModal
            if self._function_id and self._project_id:
                self.app.push_screen(InvokeModal(
                    function_id=self._function_id,
                    project_id=self._project_id,
                ))
        elif event.button.id == "btn-view-logs":
            pass  # logs already visible in the log panel

    def action_go_back(self) -> None:
        self.app.pop_screen()

    def action_quit_app(self) -> None:
        self.app.exit()
