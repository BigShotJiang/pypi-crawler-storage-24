from __future__ import annotations

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static
from textual.containers import Vertical, Horizontal
from textual import work

from quapp.api.client import QuappClient, QuappAuthError
from quapp.config import load_config, save_config


def _do_login(base_url: str, email: str, password: str) -> str:
    """POST /auth/login → return access token. Raises on failure."""
    client = QuappClient(base_url)
    response = client.post(
        "/auth/login",
        json={"username": email, "password": password},
    )
    data = response.json()
    # Unwrap data envelope if present
    inner = data.get("data", data)
    token = inner.get("accessToken") or inner.get("idToken")
    if not token:
        raise ValueError("No token in login response.")
    return token


class LoginScreen(Screen):
    """Login screen — enter email and password to authenticate."""

    DEFAULT_CSS = """
    LoginScreen {
        align: center middle;
    }
    LoginScreen > Vertical {
        background: $surface;
        border: solid $primary;
        padding: 2 4;
        width: 50;
        height: auto;
    }
    LoginScreen .login-title {
        text-style: bold;
        text-align: center;
        margin-bottom: 2;
    }
    LoginScreen .field-label {
        margin-top: 1;
    }
    LoginScreen #error-msg {
        color: $error;
        margin-top: 1;
    }
    LoginScreen .button-row {
        margin-top: 2;
        align: center middle;
        height: 3;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Quapp Login", classes="login-title")
            yield Label("Email", classes="field-label")
            yield Input(placeholder="user@example.com", id="email-input")
            yield Label("Password", classes="field-label")
            yield Input(placeholder="••••••••", password=True, id="password-input")
            yield Static("", id="error-msg")
            with Horizontal(classes="button-row"):
                yield Button("Login", id="btn-login", variant="primary")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Allow pressing Enter in either field to submit."""
        self._attempt_login()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-login":
            self._attempt_login()

    def _attempt_login(self) -> None:
        email = self.query_one("#email-input", Input).value.strip()
        password = self.query_one("#password-input", Input).value

        error = self.query_one("#error-msg", Static)

        if not email:
            error.update("Email is required.")
            return
        if not password:
            error.update("Password is required.")
            return

        error.update("Logging in…")
        btn = self.query_one("#btn-login", Button)
        btn.disabled = True
        self._do_login_worker(email, password)

    @work(thread=True)
    def _do_login_worker(self, email: str, password: str) -> None:
        config = load_config()
        try:
            token = _do_login(config.base_url, email, password)
            config.token = token
            save_config(config)
            self.app.call_from_thread(self._login_success)
        except QuappAuthError:
            self.app.call_from_thread(self._login_failed, "Invalid email or password.")
        except Exception as e:
            self.app.call_from_thread(self._login_failed, f"Login error: {e}")

    def _login_success(self) -> None:
        from quapp.tui.screens.main import MainScreen
        self.app.switch_screen(MainScreen())

    def _login_failed(self, reason: str) -> None:
        self.query_one("#error-msg", Static).update(f"[red]{reason}[/red]")
        btn = self.query_one("#btn-login", Button)
        btn.disabled = False
