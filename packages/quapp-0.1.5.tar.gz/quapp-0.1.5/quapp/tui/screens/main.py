from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Footer, Header, Label, ListView
from textual.containers import Horizontal
from textual import work

from quapp.api.client import QuappClient
from quapp.api.projects import list_projects
from quapp.api.functions import list_functions
from quapp.api.jobs import list_jobs
from quapp.config import load_config
from quapp.tui.widgets.resource_panel import ResourcePanel


def _project_label(p: dict) -> str:
    return f"{p.get('id', '?')}  {p.get('name', '?')}"


_FUNCTION_STATUS_LABELS = {0: "draft", 1: "building", 2: "deployed", 3: "published"}


def _function_label(f: dict) -> str:
    fid = str(f.get("functionId") or f.get("id", "?"))
    status_int = f.get("status", -1)
    tag = _FUNCTION_STATUS_LABELS.get(status_int, "unknown")
    color = "green" if status_int == 2 else ("yellow" if status_int == 1 else "dim")
    return f"{fid}  {f.get('name', '?')}  [{color}]{tag}[/{color}]"


def _job_label(j: dict) -> str:
    jid = str(j.get("id") or j.get("jobId", "?"))
    status = j.get("status", "?")
    detail = j.get("statusDetail", "")
    suffix = f"  {detail}" if detail else ""
    return f"{jid[:8]}  {status}{suffix}"


class MainScreen(Screen):
    """Main 3-column TUI screen: Projects | Functions | Jobs."""

    BINDINGS = [
        Binding("enter", "confirm_action", "Action", priority=True),
        ("q",     "quit",               "Quit"),
        ("right", "select_and_advance", "Select →"),
        ("left",  "focus_prev_panel",   "← Back"),
        ("f5",    "refresh_panel",      "Refresh"),
        ("n",     "new_item",           "New"),
        ("slash", "jump_job",           "Jump to Job"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._config = load_config()
        self._projects: list[dict] = []
        self._functions: list[dict] = []
        self._all_jobs: list[dict] = []
        self._jobs: list[dict] = []
        self._selected_project: dict | None = None
        self._selected_function: dict | None = None
        self._panel_order = ["projects", "functions", "jobs"]
        self._focused_panel_idx = 0

    def _make_client(self, project_id: str | None = None) -> QuappClient:
        return QuappClient(
            self._config.base_url,
            token=self._config.token,
            project_id=project_id,
        )

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="panels"):
            yield ResourcePanel(
                "Projects",
                item_label_fn=_project_label,
                id="panel-projects",
            )
            yield ResourcePanel(
                "Functions",
                item_label_fn=_function_label,
                id="panel-functions",
            )
            yield ResourcePanel(
                "Jobs",
                item_label_fn=_job_label,
                id="panel-jobs",
            )
        yield Footer()

    def on_mount(self) -> None:
        self.load_projects()

    @work(thread=True)
    def load_projects(self) -> None:
        try:
            self._projects = list_projects(self._make_client())
            self.app.call_from_thread(self._update_projects_panel)
        except Exception as e:
            self._projects = []
            self.app.call_from_thread(self._update_projects_panel)
            self.app.call_from_thread(self.notify, f"Failed to load projects: {e}", severity="error")

    def _update_projects_panel(self) -> None:
        panel = self.query_one("#panel-projects", ResourcePanel)
        panel.update_items(self._projects)

    @work(thread=True)
    def load_functions(self, project_id: str) -> None:
        try:
            self._functions = list_functions(self._make_client(project_id))
            self.app.call_from_thread(self._update_functions_panel)
        except Exception as e:
            self._functions = []
            self.app.call_from_thread(self._update_functions_panel)
            self.app.call_from_thread(self.notify, f"Failed to load functions: {e}", severity="error")

    def _update_functions_panel(self) -> None:
        panel = self.query_one("#panel-functions", ResourcePanel)
        panel.update_items(self._functions)

    @work(thread=True)
    def load_jobs(self, project_id: str) -> None:
        try:
            self._all_jobs = list_jobs(self._make_client(project_id))
            self.app.call_from_thread(self._apply_job_filters)
        except Exception as e:
            self._all_jobs = []
            self.app.call_from_thread(self._apply_job_filters)
            self.app.call_from_thread(self.notify, f"Failed to load jobs: {e}", severity="error")

    def _apply_job_filters(self) -> None:
        func_id = (
            str(self._selected_function.get("functionId") or self._selected_function.get("id", ""))
            if self._selected_function else None
        )
        self._jobs = [
            j for j in self._all_jobs
            if func_id is None or (
                str((j.get("function") or {}).get("id", "")) == func_id
                or str(j.get("functionId", "")) == func_id
            )
        ]
        self._update_jobs_panel()

    def _update_jobs_panel(self) -> None:
        panel = self.query_one("#panel-jobs", ResourcePanel)
        panel.update_items(self._jobs)

    def on_list_view_selected(self, event) -> None:
        """Handle item selection in any ListView."""
        # Walk up to find the enclosing ResourcePanel
        panel = event.list_view.parent
        while panel is not None and not isinstance(panel, ResourcePanel):
            panel = panel.parent
        if panel is None:
            return
        panel_id = panel.id
        if panel_id == "panel-projects":
            idx = self._get_selected_index(event.list_view)
            if 0 <= idx < len(self._projects):
                self._selected_project = self._projects[idx]
                project_id = str(self._selected_project["id"])
                self.load_functions(project_id)
                self.load_jobs(project_id)
            self._focused_panel_idx = 1
            self._focus_panel("functions")
        elif panel_id == "panel-functions":
            idx = self._get_selected_index(event.list_view)
            if 0 <= idx < len(self._functions):
                self._selected_function = self._functions[idx]
            self._apply_job_filters()
            self._focused_panel_idx = 2
            self._focus_panel("jobs")
        elif panel_id == "panel-jobs":
            idx = self._get_selected_index(event.list_view)
            if 0 <= idx < len(self._jobs):
                selected_job = self._jobs[idx]
                project_id = str(self._selected_project["id"]) if self._selected_project else ""
                from quapp.tui.screens.job_detail import JobDetailScreen
                self.app.push_screen(JobDetailScreen(job=selected_job, project_id=project_id))

    def on_list_view_focus(self, event) -> None:
        """Sync _focused_panel_idx when a ListView gets focus (e.g., via click)."""
        panel = event.list_view.parent
        while panel is not None and not isinstance(panel, ResourcePanel):
            panel = panel.parent
        if panel is None:
            return
        pid = panel.id  # e.g. "panel-projects"
        name = pid.replace("panel-", "") if pid else None
        if name in self._panel_order:
            self._focused_panel_idx = self._panel_order.index(name)

    def _get_selected_index(self, list_view) -> int:
        if list_view.index is None:
            return -1
        return list_view.index

    def action_select_and_advance(self) -> None:
        panel_name = self._panel_order[self._focused_panel_idx]
        panel = self.query_one(f"#panel-{panel_name}", ResourcePanel)
        lv = panel.query_one(ListView)
        idx = lv.index if lv.index is not None else 0

        if panel_name == "projects":
            if idx < 0 or idx >= len(self._projects):
                return
            self._selected_project = self._projects[idx]
            project_id = str(self._selected_project["id"])
            self.load_functions(project_id)
            self.load_jobs(project_id)
            self._focused_panel_idx = 1
            self._focus_panel("functions")

        elif panel_name == "functions":
            if idx < 0 or idx >= len(self._functions):
                return
            self._selected_function = self._functions[idx]
            self._apply_job_filters()
            self._focused_panel_idx = 2
            self._focus_panel("jobs")

        elif panel_name == "jobs":
            if 0 <= idx < len(self._jobs):
                selected_job = self._jobs[idx]
                project_id = str(self._selected_project["id"]) if self._selected_project else ""
                from quapp.tui.screens.job_detail import JobDetailScreen
                self.app.push_screen(JobDetailScreen(job=selected_job, project_id=project_id))
            # Jobs is last panel — no further advance

    def action_focus_prev_panel(self) -> None:
        if self._focused_panel_idx > 0:
            self._focused_panel_idx -= 1
            self._focus_panel(self._panel_order[self._focused_panel_idx])
        # Projects panel: do nothing

    def action_confirm_action(self) -> None:
        panel_name = self._panel_order[self._focused_panel_idx]
        panel = self.query_one(f"#panel-{panel_name}", ResourcePanel)
        lv = panel.query_one(ListView)
        idx = lv.index if lv.index is not None else 0

        if panel_name == "projects":
            self.action_select_and_advance()

        elif panel_name == "functions":
            if 0 <= idx < len(self._functions):
                self._selected_function = self._functions[idx]
            self.action_deploy()

        elif panel_name == "jobs":
            self.action_run_job()

    def _focus_panel(self, panel_name: str) -> None:
        panel = self.query_one(f"#panel-{panel_name}", ResourcePanel)
        lv = panel.query_one(ListView)
        lv.focus()

    def action_refresh_panel(self) -> None:
        if self._selected_project:
            self.load_projects()
            self.load_functions(str(self._selected_project["id"]))
            self.load_jobs(str(self._selected_project["id"]))
        else:
            self.load_projects()

    def action_quit(self) -> None:
        self.app.exit()

    def action_new_item(self) -> None:
        """'n' key — open CreateFunctionModal if Functions panel focused."""
        from quapp.tui.modals.create_function import CreateFunctionModal
        from quapp.tui.screens.deploy_status import DeployStatusScreen
        if self._panel_order[self._focused_panel_idx] == "functions" and self._selected_project:
            def handle_create(result: dict | None) -> None:
                if result:
                    self.app.push_screen(DeployStatusScreen(
                        project_id=str(self._selected_project["id"]),
                        create_params=result,
                    ))
            self.app.push_screen(
                CreateFunctionModal(project_id=str(self._selected_project["id"])),
                handle_create,
            )

    def action_deploy(self) -> None:
        """'d' key — deploy selected function."""
        from quapp.tui.screens.deploy_status import DeployStatusScreen
        if self._selected_function and self._selected_project:
            self.app.push_screen(DeployStatusScreen(
                function_id=str(self._selected_function["id"]),
                project_id=str(self._selected_project["id"]),
            ))

    def action_run_job(self) -> None:
        """'r' key — open InvokeModal for selected function."""
        from quapp.tui.modals.invoke import InvokeModal
        if self._selected_function and self._selected_project:
            self.app.push_screen(InvokeModal(
                function_id=str(self._selected_function["id"]),
                project_id=str(self._selected_project["id"]),
            ))

    def action_jump_job(self) -> None:
        self.notify("Jump to Job ID: not yet implemented", severity="information")
