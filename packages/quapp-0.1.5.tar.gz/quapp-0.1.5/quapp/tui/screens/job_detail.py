from __future__ import annotations

import json as _json
import time
from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Button, Label, Log, Static, TabbedContent, TabPane
from textual.containers import Vertical, Horizontal
from textual import work
from textual.css.query import NoMatches

from quapp.api.client import QuappClient
from quapp.api.jobs import get_job_status
from quapp.config import load_config

_IN_PROGRESS_STATUSES = {"IN_QUEUE", "RUNNING", "PENDING", "QUEUED"}


class JobDetailScreen(Screen):
    """Tabbed detail view for a single job."""

    BINDINGS = [
        ("escape", "go_back", "Back"),
        ("q", "quit_app", "Quit"),
        ("r", "manual_refresh", "Refresh"),
    ]

    DEFAULT_CSS = """
    JobDetailScreen > Vertical {
        padding: 1 2;
    }
    JobDetailScreen .detail-title {
        text-style: bold;
        margin-bottom: 1;
    }
    JobDetailScreen .status-badge {
        margin-bottom: 1;
    }
    JobDetailScreen .button-row {
        height: 3;
        align: right middle;
        margin-top: 1;
    }
    """

    def __init__(self, job: dict, project_id: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self._job = job
        self._project_id = project_id
        self._job_id = job.get("id") or job.get("jobId", "?")
        self._config = load_config()
        self._auto_refresh = False

    def _make_client(self) -> QuappClient:
        return QuappClient(
            self._config.base_url,
            token=self._config.token,
            project_id=self._project_id,
        )

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(f"Job: {self._job_id}", classes="detail-title")
            yield Static(self._status_text(), id="status-badge", classes="status-badge")

            with TabbedContent():
                with TabPane("Data", id="tab-data"):
                    yield Log(id="data-log", auto_scroll=False)
                with TabPane("Output", id="tab-output"):
                    yield Log(id="output-log", auto_scroll=False)
                with TabPane("Logs", id="tab-logs"):
                    yield Log(id="logs-log", auto_scroll=False)

            with Horizontal(classes="button-row"):
                yield Button("Back", id="btn-back", variant="default")
                yield Button("Refresh", id="btn-refresh", variant="primary")

    def _status_text(self) -> str:
        status = self._job.get("status", "?")
        color = {
            "DONE": "green",
            "FAILED": "red",
            "IN_QUEUE": "yellow",
            "RUNNING": "blue",
        }.get(status, "white")
        return f"[{color}]Status: {status}[/{color}]"

    def on_mount(self) -> None:
        self._populate_data()
        status = self._job.get("status", "")
        if status in _IN_PROGRESS_STATUSES:
            self._auto_refresh = True
            self.poll_job_status()

    def _populate_data(self) -> None:
        """Fill tabs with job data."""
        try:
            data_log = self.query_one("#data-log", Log)
            data_log.clear()
            # Priority fields shown first
            priority_keys = ["id", "jobId", "status", "statusDetail", "ranTimestamp",
                             "finishedTimestamp", "retry", "shots", "device", "provider"]
            shown = set()
            for k in priority_keys:
                if k in self._job:
                    data_log.write_line(f"{k}: {self._job[k]}")
                    shown.add(k)
            # Remaining scalar fields
            for k, v in self._job.items():
                if k not in shown and not isinstance(v, (dict, list)):
                    data_log.write_line(f"{k}: {v}")
        except NoMatches:
            return

        # Output tab: result/output fields if present
        try:
            output_log = self.query_one("#output-log", Log)
            output_log.clear()
            result = self._job.get("result") or self._job.get("output") or {}
            if isinstance(result, dict):
                for k, v in result.items():
                    output_log.write_line(f"{k}: {v}")
            elif result:
                output_log.write_line(str(result))
            else:
                output_log.write_line("No output data available.")
        except NoMatches:
            pass

        # Logs tab: buildLogs / deployLogs from function (if embedded)
        try:
            logs_log = self.query_one("#logs-log", Log)
            logs_log.clear()
            func = self._job.get("function", {})
            build_logs = func.get("buildLogs", "") if isinstance(func, dict) else ""
            deploy_logs = func.get("deployLogs", "") if isinstance(func, dict) else ""
            if build_logs:
                for line in str(build_logs).splitlines():
                    logs_log.write_line(f"[BUILD] {line}")
            if deploy_logs:
                for line in str(deploy_logs).splitlines():
                    logs_log.write_line(f"[DEPLOY] {line}")
            if not build_logs and not deploy_logs:
                logs_log.write_line("No log data available.")
        except NoMatches:
            pass

    @work(thread=True)
    def poll_job_status(self) -> None:
        """Auto-refresh: poll every 5s while job is in progress."""
        client = self._make_client()
        while self._auto_refresh:
            time.sleep(5)
            try:
                updated = get_job_status(client, self._job_id)
                self._job = updated
                self.app.call_from_thread(self._refresh_ui)
                new_status = updated.get("status", "")
                if new_status not in _IN_PROGRESS_STATUSES:
                    self._auto_refresh = False
            except Exception:
                self._auto_refresh = False

    def _refresh_ui(self) -> None:
        if not self.is_attached:
            return
        try:
            self.query_one("#status-badge", Static).update(self._status_text())
        except NoMatches:
            pass
        self._populate_data()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-back":
            self._auto_refresh = False
            self.app.pop_screen()
        elif event.button.id == "btn-refresh":
            self.load_latest()

    @work(thread=True)
    def load_latest(self) -> None:
        client = self._make_client()
        try:
            updated = get_job_status(client, self._job_id)
            self._job = updated
            self.app.call_from_thread(self._refresh_ui)
        except Exception as e:
            self.app.call_from_thread(self.notify, f"Refresh failed: {e}", severity="error")

    def action_go_back(self) -> None:
        self._auto_refresh = False
        self.app.pop_screen()

    def action_quit_app(self) -> None:
        self._auto_refresh = False
        self.app.exit()

    def action_manual_refresh(self) -> None:
        self.load_latest()
