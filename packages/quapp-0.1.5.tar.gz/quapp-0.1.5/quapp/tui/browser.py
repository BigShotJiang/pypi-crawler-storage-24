"""Three-pane project/function/job browser with arrow-key and fallback modes."""
from __future__ import annotations

import os
import sys
from typing import Optional

try:
    import readchar
    HAS_READCHAR = True
except ImportError:
    HAS_READCHAR = False

IS_MINTTY = os.environ.get("TERM_PROGRAM") == "mintty" or bool(os.environ.get("MSYSTEM"))
USE_FALLBACK = IS_MINTTY or not HAS_READCHAR


# ---------------------------------------------------------------------------
# Key constants
# ---------------------------------------------------------------------------
_KEY_UP    = "up"
_KEY_DOWN  = "down"
_KEY_ENTER = "enter"
_KEY_BACK  = "back"
_KEY_QUIT  = "q"
_KEY_DEPLOY = "d"


class BrowserState:
    """Mutable navigation state for the browser. handle_key never blocks."""

    PANES = ("projects", "functions", "jobs")

    def __init__(self) -> None:
        self.pane: str = "projects"
        self.selected: dict[str, int] = {"projects": 0, "functions": 0, "jobs": 0}
        self.data: dict[str, list[dict]] = {"projects": [], "functions": [], "jobs": []}
        self.error: Optional[str] = None
        self.pending_action: Optional[tuple] = None
        self.should_quit: bool = False

    def _current_items(self) -> list[dict]:
        return self.data.get(self.pane, [])

    def _selected_item(self, pane: str) -> Optional[dict]:
        items = self.data.get(pane, [])
        idx = self.selected.get(pane, 0)
        return items[idx] if items and 0 <= idx < len(items) else None

    def handle_key(self, key: str) -> None:
        """Mutate state based on key. Never blocks. Returns None always."""
        items = self._current_items()
        idx = self.selected.get(self.pane, 0)

        if key == _KEY_QUIT:
            self.should_quit = True

        elif key == _KEY_UP:
            self.selected[self.pane] = max(0, idx - 1)

        elif key == _KEY_DOWN:
            self.selected[self.pane] = min(len(items) - 1, idx + 1) if items else 0

        elif key == _KEY_BACK:
            pane_order = list(self.PANES)
            current_idx = pane_order.index(self.pane)
            if current_idx > 0:
                self.pane = pane_order[current_idx - 1]

        elif key == _KEY_ENTER:
            if self.pane == "jobs":
                item = self._selected_item("jobs")
                if item:
                    self.pending_action = ("watch", item["id"])
            elif self.pane in ("projects", "functions"):
                pane_order = list(self.PANES)
                current_idx = pane_order.index(self.pane)
                if current_idx < len(pane_order) - 1:
                    self.pane = pane_order[current_idx + 1]

        elif key == _KEY_DEPLOY:
            if self.pane == "functions":
                func = self._selected_item("functions")
                proj = self._selected_item("projects")
                if func and proj:
                    self.pending_action = ("deploy", func["name"], proj["id"])


# ---------------------------------------------------------------------------
# API data loaders
# ---------------------------------------------------------------------------

from quapp.api.client import QuappClient
from quapp.api.projects import list_projects
from quapp.api.functions import list_functions
from quapp.api.jobs import list_jobs


def load_pane_data(state: BrowserState, client: QuappClient) -> None:
    """Lazily load data for the current pane if not already cached."""
    if state.data[state.pane]:
        return  # cached
    state.error = None
    try:
        if state.pane == "projects":
            state.data["projects"] = list_projects(client)
        elif state.pane == "functions":
            proj = state._selected_item("projects")
            if proj:
                pc = QuappClient(client.base_url, token=client.token, project_id=str(proj["id"]))
                state.data["functions"] = list_functions(pc)
        elif state.pane == "jobs":
            proj = state._selected_item("projects")
            if proj:
                pc = QuappClient(client.base_url, token=client.token, project_id=str(proj["id"]))
                state.data["jobs"] = list_jobs(pc)
    except Exception as exc:
        state.error = str(exc)


# ---------------------------------------------------------------------------
# Arrow-key renderer
# ---------------------------------------------------------------------------

from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


def _render_pane(title: str, items: list[dict], selected_idx: int, active: bool) -> Panel:
    table = Table.grid(padding=(0, 1))
    table.add_column(no_wrap=True)
    for i, item in enumerate(items):
        name = item.get("name") or item.get("id") or str(item)
        status = item.get("status", "")
        label = f"{name}  [dim]{status}[/dim]" if status else name
        if i == selected_idx and active:
            table.add_row(f"[bold cyan]▶ {label}[/bold cyan]")
        else:
            table.add_row(f"  {label}")
    border = "bold cyan" if active else "dim"
    return Panel(table, title=f"[bold]{title.upper()}[/bold]", border_style=border)


def _render_browser(state: BrowserState) -> Columns:
    panes_order = ["projects", "functions", "jobs"]
    panels = []
    for pane in panes_order:
        panels.append(_render_pane(
            title=pane,
            items=state.data[pane],
            selected_idx=state.selected[pane],
            active=(state.pane == pane),
        ))
    return Columns(panels, equal=True)


# ---------------------------------------------------------------------------
# Fallback (numbered menu) renderer
# ---------------------------------------------------------------------------

def _clear_screen() -> None:
    print("\033[2J\033[H", end="", flush=True)


def run_fallback(state: BrowserState, client: QuappClient) -> None:
    """Sequential numbered-menu fallback for mintty / Git Bash."""
    from quapp import output as out

    while not state.should_quit:
        _clear_screen()
        load_pane_data(state, client)

        if state.error:
            print(f"Error: {state.error}")
            choice = input("Press b to go back, q to quit: ").strip().lower()
            if choice == "q":
                state.should_quit = True
                return
            state.handle_key("back")
            state.error = None
            continue

        items = state.data[state.pane]
        print(f"\n  {state.pane.upper()}\n  {'─' * 20}")
        for i, item in enumerate(items, 1):
            name = item.get("name") or item.get("id") or str(item)
            status = item.get("status", "")
            suffix = f"  [{status}]" if status else ""
            print(f"  {i}) {name}{suffix}")

        prompt_extra = ""
        if state.pane == "functions":
            prompt_extra = ", d to deploy"
        print()
        raw = input(f"Enter number (or b to go back{prompt_extra}, q to quit): ").strip().lower()

        if raw == "q":
            state.should_quit = True
            return
        elif raw == "b":
            state.handle_key("back")
            # On back: invalidate child pane cache
            pane_order = list(BrowserState.PANES)
            child_idx = pane_order.index(state.pane) + 1
            if child_idx < len(pane_order):
                state.data[pane_order[child_idx]] = []
        elif raw == "d" and state.pane == "functions":
            func = state._selected_item("functions")
            proj = state._selected_item("projects")
            if func and proj:
                handler_path = input("Enter handler file path: ").strip()
                if not handler_path:
                    print("Cancelled.")
                    continue
                import pathlib
                if not pathlib.Path(handler_path).exists():
                    print(f"Error: file not found: {handler_path}")
                    continue
                _run_deploy_inprocess(proj["id"], func["name"], handler_path, client)
        else:
            try:
                num = int(raw)
            except ValueError:
                continue
            if 1 <= num <= len(items):
                state.selected[state.pane] = num - 1
                if state.pane == "jobs":
                    job = items[num - 1]
                    from quapp.tui.dashboard import run_dashboard
                    run_dashboard(client, job["id"])
                else:
                    state.handle_key("enter")
                    # Invalidate the child pane we just navigated INTO so it re-fetches on entry
                    state.data[state.pane] = []


def _run_deploy_inprocess(project_id: str, function_name: str, handler_path: str, client: QuappClient) -> None:
    """Execute a deploy in-process using the same API calls as deploy.py."""
    import base64
    import pathlib
    from quapp.api.deploy import find_or_create_function, wait_until_deployed
    from quapp.api.functions import create_function_version
    from quapp.api.jobs import run_job
    from quapp import output

    pc = QuappClient(client.base_url, token=client.token, project_id=project_id)

    try:
        func = find_or_create_function(pc, function_name, sdk_version=None)
    except ValueError:
        output.err_console.print(
            f"[red]✗[/red] Function '{function_name}' not found in this project. "
            "Create it first using `quapp function create` or `quapp deploy --sdk-version`."
        )
        return
    except Exception as exc:
        output.format_error(exc)
        return

    function_id = str(func["id"])
    handler_bytes = pathlib.Path(handler_path).read_bytes()
    files = [{
        "filename": "handler.py",
        "language": "python",
        "fileId": None,
        "content": base64.b64encode(handler_bytes).decode("ascii"),
    }]

    auto_req = pathlib.Path(handler_path).parent / "requirements.txt"
    if auto_req.exists():
        files.append({
            "filename": "requirements.txt",
            "language": "text",
            "fileId": None,
            "content": base64.b64encode(auto_req.read_bytes()).decode("ascii"),
        })

    try:
        ver_data = create_function_version(pc, function_id, None, files)
    except Exception as exc:
        output.format_error(exc)
        return

    raw = ver_data.get("data") or ver_data
    version_id = str(raw.get("id") or raw.get("versionId") or "")

    try:
        wait_until_deployed(pc, function_id, version_id)
    except Exception as exc:
        output.format_error(exc)
        return

    output.print_success(f"Deployed {function_name} (version {version_id}). Use `quapp invoke` to run a job.")


# ---------------------------------------------------------------------------
# Arrow-key main loop
# ---------------------------------------------------------------------------

def run_arrow_key(state: BrowserState, client: QuappClient) -> None:
    """Arrow-key browser loop. Uses readchar for input."""
    console = Console()

    with Live(refresh_per_second=4, console=console) as live:
        while not state.should_quit:
            load_pane_data(state, client)
            live.update(_render_browser(state))

            if state.pending_action:
                action = state.pending_action
                state.pending_action = None
                live.stop()

                if action[0] == "watch":
                    from quapp.tui.dashboard import run_dashboard
                    run_dashboard(client, action[1])

                elif action[0] == "deploy":
                    _, function_name, project_id = action
                    handler_path = input("Enter handler file path: ").strip()
                    if handler_path and __import__("pathlib").Path(handler_path).exists():
                        _run_deploy_inprocess(project_id, function_name, handler_path, client)
                    else:
                        console.print("[red]File not found or empty path.[/red]")

                live.start()
                if action[0] == "watch":
                    state.data["jobs"] = []
                continue

            if HAS_READCHAR:
                live.stop()
                key_raw = readchar.readkey()
                live.start()
                if key_raw == readchar.key.UP:
                    key = "up"
                elif key_raw == readchar.key.DOWN:
                    key = "down"
                elif key_raw in (readchar.key.ENTER, "\r", "\n"):
                    key = "enter"
                elif key_raw == readchar.key.BACKSPACE:
                    key = "back"
                elif key_raw == "q":
                    key = "q"
                elif key_raw == "d":
                    key = "d"
                else:
                    continue
            else:
                break

            state.handle_key(key)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_browser(client: QuappClient, fallback: bool = False) -> None:
    """Launch the browser in arrow-key or fallback mode."""
    state = BrowserState()
    if fallback or USE_FALLBACK:
        run_fallback(state, client)
    else:
        run_arrow_key(state, client)
