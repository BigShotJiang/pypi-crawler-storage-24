from __future__ import annotations

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Static
from textual.containers import Vertical, Horizontal


class CreateFunctionModal(ModalScreen[dict | None]):
    """Modal to create a new function."""

    DEFAULT_CSS = """
    CreateFunctionModal {
        align: center middle;
    }
    CreateFunctionModal > Vertical {
        background: $surface;
        border: solid $primary;
        padding: 1 2;
        width: 60;
        height: auto;
    }
    CreateFunctionModal .modal-title {
        text-style: bold;
        margin-bottom: 1;
    }
    CreateFunctionModal .field-label {
        margin-top: 1;
    }
    CreateFunctionModal .button-row {
        margin-top: 1;
        align: right middle;
        height: 3;
    }
    """

    def __init__(self, project_id: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.project_id = project_id

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Create Function", classes="modal-title")
            yield Label("Name *", classes="field-label")
            yield Input(placeholder="function-name", id="name-input")
            yield Label("Description", classes="field-label")
            yield Input(placeholder="Optional description", id="desc-input")
            yield Label("Handler file path *", classes="field-label")
            yield Input(placeholder="/path/to/handler.py", id="handler-input")
            yield Label("Requirements file path", classes="field-label")
            yield Input(placeholder="/path/to/requirements.txt (optional)", id="req-input")
            yield Static("", id="error-msg")
            with Horizontal(classes="button-row"):
                yield Button("Cancel", id="btn-cancel", variant="default")
                yield Button("Create & Deploy", id="btn-create", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-cancel":
            self.dismiss(None)
            return

        # Validate
        name = self.query_one("#name-input", Input).value.strip()
        handler_path = self.query_one("#handler-input", Input).value.strip()
        desc = self.query_one("#desc-input", Input).value.strip()
        req_path = self.query_one("#req-input", Input).value.strip()

        error = self.query_one("#error-msg", Static)

        if not name:
            error.update("[red]Name is required.[/red]")
            return

        if not handler_path:
            # First click with no handler: warn the user
            error = self.query_one("#error-msg", Static)
            if "[yellow]" not in str(error.renderable):
                # Show warning — require a second click to confirm
                error.update("[yellow]No handler file path. Click 'Create & Deploy' again to proceed without handler.[/yellow]")
                return
            # Second click: user confirmed, proceed

        self.dismiss({
            "name": name,
            "description": desc or None,
            "handler_path": handler_path or None,
            "req_path": req_path or None,
        })
