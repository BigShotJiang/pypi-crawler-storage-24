from __future__ import annotations

import json

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Select, Static
from textual.containers import Horizontal, Vertical, ScrollableContainer
from textual import work

from quapp.api.client import QuappClient
from quapp.api.providers import list_devices
from quapp.api.jobs import run_job
from quapp.config import load_config

QUAPP_PROVIDER_ID = 5
QUAPP_PROVIDER_NAME = "Quapp"


class KeyValueRow(Horizontal):
    """A single key=value input row with a remove button."""

    def __init__(self, row_id: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self._row_id = row_id

    @property
    def row_id(self) -> str:
        return self._row_id

    def compose(self) -> ComposeResult:
        yield Input(placeholder="key", id=f"{self._row_id}-key", classes="kv-key")
        yield Label("=", classes="kv-eq")
        yield Input(placeholder="value (JSON or string)", id=f"{self._row_id}-val", classes="kv-val")
        yield Button("✕", id=f"rm-{self._row_id}", classes="kv-remove", variant="error")


class InvokeModal(ModalScreen[dict | None]):
    """Modal to invoke a function: select device, set shots, add inputs."""

    DEFAULT_CSS = """
    InvokeModal {
        align: center middle;
    }
    InvokeModal > Vertical {
        background: $surface;
        border: solid $primary;
        padding: 1 2;
        width: 70;
        height: auto;
        max-height: 90%;
    }
    InvokeModal .modal-title {
        text-style: bold;
        margin-bottom: 1;
    }
    InvokeModal .field-label {
        margin-top: 1;
    }
    InvokeModal .kv-key {
        width: 30%;
    }
    InvokeModal .kv-val {
        width: 1fr;
    }
    InvokeModal .kv-eq {
        width: 3;
        padding: 1 1;
    }
    InvokeModal .kv-remove {
        width: 5;
    }
    InvokeModal .button-row {
        margin-top: 1;
        align: right middle;
        height: 3;
    }
    InvokeModal #error-msg {
        color: $error;
    }
    """

    def __init__(self, function_id: str, project_id: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self._function_id = function_id
        self._project_id = project_id
        self._config = load_config()
        self._devices: list[dict] = []
        self._row_counter = 0

    def _make_client(self, project_id: str | None = None) -> QuappClient:
        return QuappClient(
            self._config.base_url,
            token=self._config.token,
            project_id=project_id or self._project_id,
        )

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Invoke Function", classes="modal-title")

            yield Label("Device", classes="field-label")
            yield Select(
                options=[],  # populated on mount
                id="device-select",
                prompt="Loading devices…",
            )

            yield Label("Shots (10–8000)", classes="field-label")
            yield Input(value="1024", id="shots-input", type="integer")

            yield Label("Inputs (key=value)", classes="field-label")
            yield ScrollableContainer(id="kv-container")
            yield Button("+ Add Input", id="btn-add-kv", variant="default")

            yield Static("", id="error-msg")

            with Horizontal(classes="button-row"):
                yield Button("Cancel", id="btn-cancel", variant="default")
                yield Button("Submit Job", id="btn-submit", variant="primary")

    def on_mount(self) -> None:
        self.load_devices()

    @work(thread=True)
    def load_devices(self) -> None:
        try:
            self._devices = list_devices(self._make_client(), QUAPP_PROVIDER_ID)
        except Exception as e:
            self._devices = []
            self.app.call_from_thread(self._set_error, f"Failed to load devices: {e}")
            return
        self.app.call_from_thread(self._populate_device_select)

    def _populate_device_select(self) -> None:
        sel = self.query_one("#device-select", Select)
        options = [(d.get("name", str(d.get("id"))), str(d.get("id"))) for d in self._devices]
        sel.set_options(options)

    def _set_error(self, msg: str) -> None:
        self.query_one("#error-msg", Static).update(msg)

    def _new_row_id(self) -> str:
        self._row_counter += 1
        return f"row{self._row_counter}"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        bid = event.button.id

        if bid == "btn-cancel":
            self.dismiss(None)
            return

        if bid == "btn-add-kv":
            row_id = self._new_row_id()
            container = self.query_one("#kv-container")
            container.mount(KeyValueRow(row_id, id=f"kv-{row_id}"))
            return

        if bid and bid.startswith("rm-"):
            row_id = bid[3:]
            try:
                self.query_one(f"#kv-{row_id}").remove()
            except Exception:
                pass
            return

        if bid == "btn-submit":
            self._submit()

    def _submit(self) -> None:
        error = self.query_one("#error-msg", Static)

        # Validate shots
        shots_str = self.query_one("#shots-input", Input).value.strip()
        try:
            shots = int(shots_str)
        except ValueError:
            error.update("Shots must be an integer.")
            return
        if not 10 <= shots <= 8000:
            error.update("Shots must be between 10 and 8000.")
            return

        # Validate device
        sel = self.query_one("#device-select", Select)
        if sel.value is Select.NULL:
            error.update("Please select a device.")
            return
        device_id = sel.value

        # Collect key-value inputs
        invocation_input: dict = {}
        for row in self.query(KeyValueRow):
            row_id = row.row_id
            key_input = self.query_one(f"#{row_id}-key", Input).value.strip()
            val_input = self.query_one(f"#{row_id}-val", Input).value.strip()
            if not key_input:
                continue
            try:
                invocation_input[key_input] = json.loads(val_input)
            except json.JSONDecodeError:
                invocation_input[key_input] = val_input

        # Submit job in a worker
        error.update("Submitting…")
        self._submit_job(device_id, shots, invocation_input if invocation_input else None)

    @work(thread=True)
    def _submit_job(self, device_id: str, shots: int, invocation_input: dict | None) -> None:
        client = self._make_client()
        try:
            result = run_job(
                client,
                function_id=self._function_id,
                provider=QUAPP_PROVIDER_NAME,
                device=device_id,
                shots=shots,
                invocation_input=invocation_input,
            )
            job_id = result.get("jobId") or result.get("id") or "?"
            self.app.call_from_thread(self.dismiss, {"job_id": job_id, "status": "submitted"})
        except Exception as e:
            self.app.call_from_thread(self._set_error, f"Submit failed: {e}")
