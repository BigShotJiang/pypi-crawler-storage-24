import unittest
import base64
import os
import tempfile
from unittest.mock import MagicMock, patch

from quapp.api.client import QuappClient, QuappNotFoundError
from quapp.api.functions import (
    create_function,
    create_function_version,
    get_function,
    delete_function,
    list_functions,
    find_function_by_name,
    list_function_versions,
)


def _client():
    return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")


def _mock_response(status_code: int, json_data: dict | None = None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.content = b"x" if json_data else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


class TestFunctionsApi(unittest.TestCase):
    @patch("requests.Session.request")
    def test_create_function(self, mock_req):
        mock_req.return_value = _mock_response(200, {"functionId": "f1"})
        result = create_function(_client(), "my-func", "0.45.3", "qiskit")
        self.assertEqual(result["functionId"], "f1")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["functionName"], "my-func")
        self.assertEqual(kwargs["json"]["sdkVersion"], "0.45.3")

    @patch("requests.Session.request")
    def test_create_function_with_description(self, mock_req):
        mock_req.return_value = _mock_response(200, {"functionId": "f2"})
        create_function(_client(), "f", "1.0", "cuda", description="GPU fn")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["description"], "GPU fn")

    @patch("requests.Session.request")
    def test_create_function_version(self, mock_req):
        mock_req.return_value = _mock_response(200, {"data": {"id": "v1", "version": 1}})
        files = [{"filename": "main.py", "language": "python", "fileId": None, "content": "pass"}]
        result = create_function_version(_client(), "f1", "first version", files)
        self.assertEqual(result["id"], "v1")
        args, _ = mock_req.call_args
        self.assertIn("/functions/f1/versions", args[1])

    @patch("requests.Session.request")
    def test_get_function(self, mock_req):
        mock_req.return_value = _mock_response(200, {"functionId": "f1", "name": "my-func"})
        result = get_function(_client(), "f1")
        self.assertEqual(result["name"], "my-func")

    @patch("requests.Session.request")
    def test_get_function_unwraps_data_envelope(self, mock_req):
        mock_req.return_value = _mock_response(200, {"data": {"functionId": "f1", "name": "wrapped"}})
        result = get_function(_client(), "f1")
        self.assertEqual(result["name"], "wrapped")

    @patch("requests.Session.request")
    def test_delete_function(self, mock_req):
        mock_req.return_value = _mock_response(200, {})
        delete_function(_client(), "f1")
        args, _ = mock_req.call_args
        self.assertEqual(args[0], "DELETE")
        self.assertIn("/functions/f1", args[1])

    @patch("requests.Session.request")
    def test_create_function_lang_uppercased(self, mock_req):
        mock_req.return_value = _mock_response(200, {"functionId": "f1"})
        create_function(_client(), "fn", "2.3.1", "qiskit")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["templateLanguageTag"], "QISKIT")

    @patch("requests.Session.request")
    def test_create_function_lang_already_upper(self, mock_req):
        mock_req.return_value = _mock_response(200, {"functionId": "f1"})
        create_function(_client(), "fn", "2.3.1", "CUDA")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["templateLanguageTag"], "CUDA")

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_list_functions(self, mock_pages):
        mock_pages.return_value = [{"functionId": "f1", "name": "fn"}]
        result = list_functions(_client())
        mock_pages.assert_called_once_with("/functions")
        self.assertEqual(result[0]["functionId"], "f1")


class TestFunctionVersionCli(unittest.TestCase):
    @patch("requests.Session.request")
    def test_version_encodes_file_as_base64(self, mock_req):
        from typer.testing import CliRunner
        from quapp.cli.functions import app

        mock_req.return_value = _mock_response(200, {"data": {"id": "v1", "version": 1}})
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="wb") as f:
            f.write(b"print('hello')")
            tmp_path = f.name
        try:
            with patch("quapp.cli.functions.load_config") as mock_cfg:
                mock_cfg.return_value = MagicMock(
                    token="tok",
                    base_url="https://functions.quapp.cloud/api/v1",
                    project_id=None,
                )
                result = runner.invoke(app, ["version", "f1", "--files", tmp_path])
            _, kwargs = mock_req.call_args
            content = kwargs["json"]["templateFiles"][0]["content"]
            decoded = base64.b64decode(content)
            self.assertEqual(decoded, b"print('hello')")
        finally:
            os.unlink(tmp_path)

    @patch("requests.Session.request")
    def test_version_normalizes_py_filename_to_handler(self, mock_req):
        from typer.testing import CliRunner
        from quapp.cli.functions import app

        mock_req.return_value = _mock_response(200, {"data": {"id": "v1", "version": 1}})
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="wb") as f:
            f.write(b"# code")
            tmp_path = f.name
        try:
            with patch("quapp.cli.functions.load_config") as mock_cfg:
                mock_cfg.return_value = MagicMock(
                    token="tok",
                    base_url="https://functions.quapp.cloud/api/v1",
                    project_id=None,
                )
                runner.invoke(app, ["version", "f1", "--files", tmp_path])
            _, kwargs = mock_req.call_args
            self.assertEqual(kwargs["json"]["templateFiles"][0]["filename"], "handler.py")
        finally:
            os.unlink(tmp_path)

    @patch("requests.Session.request")
    def test_version_normalizes_txt_filename_to_requirements(self, mock_req):
        from typer.testing import CliRunner
        from quapp.cli.functions import app

        mock_req.return_value = _mock_response(200, {"data": {"id": "v1", "version": 1}})
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="wb") as f:
            f.write(b"qiskit==0.45.3")
            tmp_path = f.name
        try:
            with patch("quapp.cli.functions.load_config") as mock_cfg:
                mock_cfg.return_value = MagicMock(
                    token="tok",
                    base_url="https://functions.quapp.cloud/api/v1",
                    project_id=None,
                )
                runner.invoke(app, ["version", "f1", "--files", tmp_path])
            _, kwargs = mock_req.call_args
            self.assertEqual(kwargs["json"]["templateFiles"][0]["filename"], "requirements.txt")
            self.assertEqual(kwargs["json"]["templateFiles"][0]["language"], "text")
        finally:
            os.unlink(tmp_path)


    @patch("requests.Session.request")
    def test_duplicate_py_files_rejected(self, mock_req):
        from typer.testing import CliRunner
        from quapp.cli.functions import app

        runner = CliRunner()
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f1, \
             tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f2:
            p1, p2 = f1.name, f2.name
        try:
            with patch("quapp.cli.functions.load_config") as mock_cfg:
                mock_cfg.return_value = MagicMock(
                    token="tok",
                    base_url="https://functions.quapp.cloud/api/v1",
                    project_id=None,
                )
                result = runner.invoke(app, ["version", "f1", "--files", p1, "--files", p2])
            self.assertNotEqual(result.exit_code, 0)
            mock_req.assert_not_called()
        finally:
            os.unlink(p1)
            os.unlink(p2)


class TestFindFunctionByName(unittest.TestCase):
    def _client(self):
        return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_finds_by_exact_name(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "fn-a"}, {"id": 2, "name": "fn-b"}]
        result = find_function_by_name(self._client(), "fn-a")
        self.assertEqual(result["id"], 1)

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_finds_by_id_string(self, mock_pages):
        mock_pages.return_value = [{"id": 7, "name": "fn-a"}, {"id": 8, "name": "fn-b"}]
        result = find_function_by_name(self._client(), "7")
        self.assertEqual(result["name"], "fn-a")

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_finds_case_insensitive(self, mock_pages):
        mock_pages.return_value = [{"id": 3, "name": "MyFunc"}]
        result = find_function_by_name(self._client(), "myfunc")
        self.assertEqual(result["id"], 3)

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_exact_match_preferred_over_case_insensitive(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "Fn"}, {"id": 2, "name": "fn"}]
        result = find_function_by_name(self._client(), "fn")
        self.assertEqual(result["id"], 2)

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_raises_not_found_when_missing(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "other"}]
        with self.assertRaises(QuappNotFoundError):
            find_function_by_name(self._client(), "ghost")

    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_raises_not_found_on_empty_list(self, mock_pages):
        mock_pages.return_value = []
        with self.assertRaises(QuappNotFoundError):
            find_function_by_name(self._client(), "anything")


class TestListFunctionVersions(unittest.TestCase):
    def _client(self):
        return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")

    def _make_response(self, json_data):
        resp = MagicMock()
        resp.status_code = 200
        resp.ok = True
        resp.content = b"x"
        resp.json.return_value = json_data
        return resp

    @patch("requests.Session.request")
    def test_returns_plain_list(self, mock_req):
        versions = [{"id": "v1", "version": 1}, {"id": "v2", "version": 2}]
        mock_req.return_value = self._make_response({"data": versions})
        result = list_function_versions(self._client(), "f1")
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["id"], "v1")

    @patch("requests.Session.request")
    def test_unwraps_data_envelope(self, mock_req):
        mock_req.return_value = self._make_response(
            {"data": [{"id": "v1", "version": 1}]}
        )
        result = list_function_versions(self._client(), "f1")
        self.assertEqual(result[0]["id"], "v1")

    @patch("requests.Session.request")
    def test_unwraps_paginated_content(self, mock_req):
        mock_req.return_value = self._make_response(
            {"data": {"content": [{"id": "v1"}, {"id": "v2"}]}}
        )
        result = list_function_versions(self._client(), "f1")
        self.assertEqual(len(result), 2)

    @patch("requests.Session.request")
    def test_calls_correct_endpoint(self, mock_req):
        mock_req.return_value = self._make_response({"data": {"content": []}})
        list_function_versions(self._client(), "func-42")
        args, _ = mock_req.call_args
        self.assertIn("/functions/func-42/versions", args[1])

    @patch("requests.Session.request")
    def test_returns_empty_list_when_no_versions(self, mock_req):
        mock_req.return_value = self._make_response({"data": {"content": []}})
        result = list_function_versions(self._client(), "f1")
        self.assertEqual(result, [])


class TestListFunctionsAllPages(unittest.TestCase):
    @patch("quapp.api.functions.QuappClient.list_all_pages")
    def test_list_functions_uses_all_pages(self, mock_pages):
        mock_pages.return_value = [{"id": "f1"}, {"id": "f2"}]
        client = QuappClient("https://x.com", token="t", project_id="p1")
        result = list_functions(client)
        mock_pages.assert_called_once_with("/functions")
        self.assertEqual(len(result), 2)


class TestGetFunctionLogs(unittest.TestCase):
    @patch("quapp.api.functions.QuappClient.get")
    def test_returns_latest_version_logs(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "data": [
                {"id": "v2", "buildLogs": "build log v2", "deployLogs": "deploy log v2"},
                {"id": "v1", "buildLogs": "build log v1", "deployLogs": "deploy log v1"},
            ]
        }
        mock_get.return_value = mock_resp
        from quapp.api.functions import get_function_logs
        client = QuappClient("https://x.com", token="t", project_id="p1")
        result = get_function_logs(client, "f1")
        self.assertEqual(result["buildLogs"], "build log v2")

    @patch("quapp.api.functions.QuappClient.get")
    def test_version_index_out_of_range_raises(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": [{"id": "v1", "buildLogs": "b", "deployLogs": "d"}]}
        mock_get.return_value = mock_resp
        from quapp.api.functions import get_function_logs
        client = QuappClient("https://x.com", token="t", project_id="p1")
        with self.assertRaises(IndexError):
            get_function_logs(client, "f1", version_index=5)

    @patch("quapp.api.functions.QuappClient.get")
    def test_empty_versions_raises_not_found(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": []}
        mock_get.return_value = mock_resp
        from quapp.api.functions import get_function_logs
        from quapp.api.client import QuappNotFoundError
        client = QuappClient("https://x.com", token="t", project_id="p1")
        with self.assertRaises(QuappNotFoundError):
            get_function_logs(client, "f1")


class TestFunctionStatusLabel(unittest.TestCase):
    @patch("quapp.api.functions.QuappClient.get")
    def test_get_shows_status_label(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"id": "f1", "name": "foo", "status": 2}}
        mock_get.return_value = mock_resp
        from typer.testing import CliRunner
        from quapp.cli.functions import app
        runner = CliRunner()
        with patch("quapp.cli.functions.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id="p1")
            result = runner.invoke(app, ["get", "f1"])
        self.assertIn("deployed", result.output)
        self.assertNotIn("2", result.output.split("status")[-1][:10])


class TestFunctionVersionMissingFile(unittest.TestCase):
    def test_missing_file_exits_with_error(self):
        from typer.testing import CliRunner
        from quapp.cli.functions import app
        runner = CliRunner()
        with patch("quapp.cli.functions.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id="p1")
            result = runner.invoke(app, ["version", "f1", "--files", "/nonexistent/handler.py"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("File not found", result.output)


if __name__ == "__main__":
    unittest.main()
