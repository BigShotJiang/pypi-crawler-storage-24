from __future__ import annotations

import time
import unittest
from unittest.mock import MagicMock, patch, call

from quapp.api.client import QuappClient, QuappNotFoundError, QuappError
from quapp.api.deploy import (
    find_or_create_project,
    find_or_create_function,
    wait_until_deployed,
    DEPLOY_POLL_INTERVAL_SECS,
    DEPLOY_TIMEOUT_SECS,
)


def _client():
    return QuappClient("https://x.com", token="tok")


def _project_client():
    return QuappClient("https://x.com", token="tok", project_id="p1")


class TestFindOrCreateProject(unittest.TestCase):
    @patch("quapp.api.deploy.create_project")
    @patch("quapp.api.deploy.find_project_by_name")
    def test_returns_existing_project_without_creating(self, mock_find, mock_create):
        mock_find.return_value = {"id": "p1", "name": "my-proj"}
        result = find_or_create_project(_client(), "my-proj")
        self.assertEqual(result["id"], "p1")
        mock_create.assert_not_called()

    @patch("quapp.api.deploy.create_project")
    @patch("quapp.api.deploy.find_project_by_name")
    def test_creates_project_on_not_found(self, mock_find, mock_create):
        mock_find.side_effect = QuappNotFoundError("not found")
        mock_create.return_value = {"id": "p2", "name": "new-proj"}
        result = find_or_create_project(_client(), "new-proj")
        self.assertEqual(result["id"], "p2")
        mock_create.assert_called_once()

    @patch("quapp.api.deploy.find_project_by_name")
    def test_reraises_non_not_found_errors(self, mock_find):
        mock_find.side_effect = QuappError("server error")
        with self.assertRaises(QuappError):
            find_or_create_project(_client(), "any")


class TestFindOrCreateFunction(unittest.TestCase):
    @patch("quapp.api.deploy.create_function")
    @patch("quapp.api.deploy.find_function_by_name")
    def test_returns_existing_function_without_creating(self, mock_find, mock_create):
        mock_find.return_value = {"id": "f1", "name": "my-fn"}
        result = find_or_create_function(_project_client(), "my-fn", sdk_version=None)
        self.assertEqual(result["id"], "f1")
        mock_create.assert_not_called()

    @patch("quapp.api.deploy.create_function")
    @patch("quapp.api.deploy.find_function_by_name")
    def test_creates_function_when_not_found_and_sdk_version_provided(self, mock_find, mock_create):
        mock_find.side_effect = QuappNotFoundError("not found")
        mock_create.return_value = {"id": "f2", "name": "new-fn"}
        result = find_or_create_function(_project_client(), "new-fn", sdk_version="0.45.3")
        self.assertEqual(result["id"], "f2")
        mock_create.assert_called_once()
        # lang must be hardcoded to "qiskit"
        call_kwargs = mock_create.call_args
        self.assertIn("qiskit", str(call_kwargs).lower())

    @patch("quapp.api.deploy.find_function_by_name")
    def test_raises_value_error_when_not_found_and_no_sdk_version(self, mock_find):
        mock_find.side_effect = QuappNotFoundError("not found")
        with self.assertRaises(ValueError) as ctx:
            find_or_create_function(_project_client(), "missing-fn", sdk_version=None)
        self.assertIn("sdk-version", str(ctx.exception).lower())

    @patch("quapp.api.deploy.find_function_by_name")
    def test_reraises_non_not_found_errors(self, mock_find):
        mock_find.side_effect = QuappError("server error")
        with self.assertRaises(QuappError):
            find_or_create_function(_project_client(), "any", sdk_version="0.1")


def _make_steps(deploy_status="PASSED", build_status="PASSED"):
    return [
        {"name": "REGISTER", "status": "PASSED"},
        {"name": "BUILD", "status": build_status},
        {"name": "DEPLOY", "status": deploy_status},
        {"name": "FINALIZE", "status": "PASSED"},
    ]


def _put_response(vid="v1"):
    mock = MagicMock()
    mock.json.return_value = {"data": {"id": vid, "inDeployed": True}}
    return mock


def _steps_response(deploy_status="PASSED", build_status="PASSED"):
    mock = MagicMock()
    mock.json.return_value = {"data": _make_steps(deploy_status, build_status)}
    return mock


class TestWaitUntilDeployed(unittest.TestCase):

    @patch("quapp.api.deploy.time.sleep")
    def test_triggers_put_and_returns_version_dict(self, mock_sleep):
        client = _project_client()
        client.put = MagicMock(return_value=_put_response("v1"))
        client.get = MagicMock(return_value=_steps_response("PASSED"))
        result = wait_until_deployed(client, "f1", "v1")
        client.put.assert_called_once_with("/deploy/functions/f1/version/v1")
        self.assertEqual(result["id"], "v1")
        self.assertTrue(result["inDeployed"])

    @patch("quapp.api.deploy.time.sleep")
    def test_polls_steps_until_deploy_passed(self, mock_sleep):
        client = _project_client()
        client.put = MagicMock(return_value=_put_response("v1"))
        client.get = MagicMock(side_effect=[
            _steps_response("IN_PROGRESS"),
            _steps_response("IN_PROGRESS"),
            _steps_response("PASSED"),
        ])
        wait_until_deployed(client, "f1", "v1")
        self.assertEqual(client.get.call_count, 3)
        self.assertEqual(mock_sleep.call_count, 3)

    @patch("quapp.api.deploy.time.sleep")
    def test_raises_on_build_failed(self, mock_sleep):
        client = _project_client()
        client.put = MagicMock(return_value=_put_response("v1"))
        client.get = MagicMock(return_value=_steps_response("IN_PROGRESS", build_status="FAILED"))
        with self.assertRaises(QuappError) as ctx:
            wait_until_deployed(client, "f1", "v1")
        self.assertIn("build failed", str(ctx.exception).lower())

    @patch("quapp.api.deploy.time.sleep")
    def test_raises_on_deploy_failed(self, mock_sleep):
        client = _project_client()
        client.put = MagicMock(return_value=_put_response("v1"))
        client.get = MagicMock(return_value=_steps_response("FAILED"))
        with self.assertRaises(QuappError) as ctx:
            wait_until_deployed(client, "f1", "v1")
        self.assertIn("deploy failed", str(ctx.exception).lower())

    @patch("quapp.api.deploy.time.time")
    @patch("quapp.api.deploy.time.sleep")
    def test_raises_timeout_when_deadline_exceeded(self, mock_sleep, mock_time):
        mock_time.side_effect = [0, DEPLOY_TIMEOUT_SECS + 1]
        client = _project_client()
        client.put = MagicMock(return_value=_put_response("v1"))
        client.get = MagicMock(return_value=_steps_response("IN_PROGRESS"))
        with self.assertRaises(TimeoutError) as ctx:
            wait_until_deployed(client, "f1", "v1")
        self.assertIn(str(DEPLOY_TIMEOUT_SECS), str(ctx.exception))


class TestDeployCommand(unittest.TestCase):
    """Integration tests for `quapp deploy` CLI command."""

    def _invoke(self, extra_args: list[str], mock_cfg=None):
        from typer.testing import CliRunner
        from quapp.cli.app import app as root_app

        runner = CliRunner()
        base_args = [
            "--project", "my-proj",
            "--function", "my-fn",
            "--device", "Simulator",
        ]
        args = base_args + extra_args
        cfg = mock_cfg or MagicMock(
            token="tok", base_url="https://x.com", project_id=None
        )
        with patch("quapp.cli.deploy.load_config", return_value=cfg):
            return runner.invoke(root_app, ["deploy"] + args)

    def _full_mocks(self):
        return {
            "find_or_create_project": MagicMock(
                return_value={"id": "p1", "name": "my-proj"}
            ),
            "find_or_create_function": MagicMock(
                return_value={"id": "f1", "name": "my-fn"}
            ),
            "create_function_version": MagicMock(
                return_value={"data": {"id": "v1"}}
            ),
            "wait_until_deployed": MagicMock(
                return_value={"id": "v1", "inDeployed": True, "buildLogs": "ok"}
            ),
            "find_provider_by_name": MagicMock(
                return_value={"id": 5, "name": "Quapp"}
            ),
            "find_device_by_name": MagicMock(
                return_value={"id": "d1", "name": "Simulator"}
            ),
            "run_job": MagicMock(
                return_value={"jobId": "j1"}
            ),
        }

    def test_missing_handler_exits_1_before_api_call(self):
        result = self._invoke(["--handler", "/nonexistent/handler.py"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("not found", result.output.lower())

    def test_non_py_handler_exits_1_before_api_call(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            f.write(b"content")
            tmppath = f.name
        try:
            result = self._invoke(["--handler", tmppath])
            self.assertEqual(result.exit_code, 1)
            self.assertIn(".py", result.output)
        finally:
            os.unlink(tmppath)

    def test_shots_out_of_range_exits_1_before_api_call(self):
        result = self._invoke(["--handler", "handler.py", "--shots", "9"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("shots", result.output.lower())

    def test_happy_path_exit_0_with_job_table(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            f.write(b"# handler")
            tmppath = f.name
        try:
            with patch.multiple("quapp.cli.deploy", **self._full_mocks()):
                result = self._invoke(["--handler", tmppath])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("j1", result.output)
        finally:
            os.unlink(tmppath)

    def test_happy_path_with_wait_calls_poll(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            f.write(b"# handler")
            tmppath = f.name
        try:
            mock_poll = MagicMock(return_value={"status": "DONE", "id": "j1"})
            with patch.multiple("quapp.cli.deploy", **self._full_mocks()):
                with patch("quapp.cli.deploy._poll_until_done", mock_poll):
                    result = self._invoke(["--handler", tmppath, "--wait"])
            self.assertEqual(result.exit_code, 0)
            mock_poll.assert_called_once()
        finally:
            os.unlink(tmppath)

    def test_function_not_found_no_sdk_version_exits_1(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            f.write(b"# handler")
            tmppath = f.name
        try:
            mocks = self._full_mocks()
            mocks["find_or_create_function"] = MagicMock(
                side_effect=ValueError("--sdk-version is required to create a new function.")
            )
            with patch.multiple("quapp.cli.deploy", **mocks):
                result = self._invoke(["--handler", tmppath])
            self.assertEqual(result.exit_code, 1)
            self.assertIn("sdk-version", result.output.lower())
        finally:
            os.unlink(tmppath)

    def test_deploy_timeout_exits_1(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            f.write(b"# handler")
            tmppath = f.name
        try:
            mocks = self._full_mocks()
            mocks["wait_until_deployed"] = MagicMock(
                side_effect=TimeoutError("Deploy timed out after 120 s.")
            )
            with patch.multiple("quapp.cli.deploy", **mocks):
                result = self._invoke(["--handler", tmppath])
            self.assertEqual(result.exit_code, 1)
            self.assertIn("timed out", result.output.lower())
        finally:
            os.unlink(tmppath)

    def test_existing_function_without_sdk_version_succeeds(self):
        """--sdk-version not passed; function already exists; should proceed."""
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            f.write(b"# handler")
            tmppath = f.name
        try:
            with patch.multiple("quapp.cli.deploy", **self._full_mocks()):
                result = self._invoke(["--handler", tmppath])
            self.assertEqual(result.exit_code, 0)
        finally:
            os.unlink(tmppath)
