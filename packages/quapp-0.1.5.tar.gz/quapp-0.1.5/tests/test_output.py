import unittest
from unittest.mock import MagicMock, patch, call

import typer

from quapp.api.client import QuappAuthError, QuappNotFoundError
from quapp import output


class TestFormatError(unittest.TestCase):

    def test_type_name_and_message_in_output(self):
        with patch.object(output.err_console, "print") as mock_print:
            output.format_error(ValueError("bad value"))
        call_args = mock_print.call_args[0][0]
        self.assertIn("ValueError", call_args)
        self.assertIn("bad value", call_args)

    def test_hint_for_key_error(self):
        with patch.object(output.err_console, "print") as mock_print:
            output.format_error(KeyError("status"))
        all_calls = " ".join(str(a) for a in mock_print.call_args_list)
        self.assertIn("missing required field", all_calls)

    def test_no_hint_for_unknown_type(self):
        with patch.object(output.err_console, "print") as mock_print:
            output.format_error(RuntimeError("oops"))
        self.assertEqual(mock_print.call_count, 1)  # only one line, no hint

    def test_authentication_error_hint(self):
        with patch.object(output.err_console, "print") as mock_print:
            output.format_error(QuappAuthError("invalid token"))
        all_calls = " ".join(str(a) for a in mock_print.call_args_list)
        self.assertIn("quapp login", all_calls)

    def test_not_found_error_hint(self):
        with patch.object(output.err_console, "print") as mock_print:
            output.format_error(QuappNotFoundError("not found"))
        all_calls = " ".join(str(a) for a in mock_print.call_args_list)
        self.assertIn("list", all_calls)


class TestPollWithSpinner(unittest.TestCase):

    def _make_poll_fn(self, statuses):
        """Return a callable that yields statuses in order."""
        it = iter(statuses)
        def poll():
            return {"status": next(it)}
        return poll

    def test_returns_final_dict_on_done(self):
        poll_fn = self._make_poll_fn(["RUNNING", "RUNNING", "DONE"])
        with patch("rich.live.Live") as mock_live:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            result = output.poll_with_spinner(poll_fn, interval=0, label="test")
        self.assertEqual(result["status"], "DONE")

    def test_exits_on_failed(self):
        poll_fn = self._make_poll_fn(["RUNNING", "FAILED"])
        with patch("rich.live.Live") as mock_live:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            result = output.poll_with_spinner(poll_fn, interval=0, label="test")
        self.assertEqual(result["status"], "FAILED")

    def test_exits_on_cancelled(self):
        poll_fn = self._make_poll_fn(["RUNNING", "CANCELLED"])
        with patch("rich.live.Live") as mock_live:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            result = output.poll_with_spinner(poll_fn, interval=0, label="test")
        self.assertEqual(result["status"], "CANCELLED")

    def test_missing_status_key_calls_format_error_and_exits(self):
        def poll_fn():
            return {"other": "data"}  # no "status" key
        with patch("rich.live.Live") as mock_live, \
             patch.object(output, "format_error") as mock_fe:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            with self.assertRaises(typer.Exit):  # typer.Exit is NOT a SystemExit
                output.poll_with_spinner(poll_fn, interval=0, label="test")
        mock_fe.assert_called_once()
        self.assertIsInstance(mock_fe.call_args[0][0], KeyError)

    def test_status_none_value_does_NOT_trigger_missing_key_error(self):
        """{"status": None} is a present key — should warn-and-continue, not error."""
        calls = [0]
        def poll_fn():
            calls[0] += 1
            if calls[0] == 1:
                return {"status": None}
            return {"status": "DONE"}
        with patch("rich.live.Live") as mock_live, \
             patch.object(output.console, "print") as mock_print:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            result = output.poll_with_spinner(poll_fn, interval=0, label="test")
        self.assertEqual(result["status"], "DONE")
        # Warning should have been printed for the None status
        warning_calls = [str(c) for c in mock_print.call_args_list if "unexpected status type" in str(c).lower()]
        self.assertTrue(len(warning_calls) >= 1, "Expected warning for non-string status")

    def test_non_string_status_warns_and_continues(self):
        calls = [0]
        def poll_fn():
            calls[0] += 1
            if calls[0] == 1:
                return {"status": 200}  # non-string — should warn and continue
            return {"status": "DONE"}
        with patch("rich.live.Live") as mock_live, \
             patch.object(output.console, "print") as mock_print:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            result = output.poll_with_spinner(poll_fn, interval=0, label="test")
        self.assertEqual(result["status"], "DONE")
        warning_calls = [str(c) for c in mock_print.call_args_list if "unexpected status type" in str(c).lower()]
        self.assertTrue(len(warning_calls) >= 1)

    def test_keyboard_interrupt_propagates(self):
        """poll_fn raising KeyboardInterrupt must propagate out of poll_with_spinner."""
        call_count = [0]
        def poll_fn():
            call_count[0] += 1
            if call_count[0] >= 2:
                raise KeyboardInterrupt
            return {"status": "RUNNING"}

        with patch("rich.live.Live") as mock_live:
            mock_live.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_live.return_value.__exit__ = MagicMock(return_value=False)
            with self.assertRaises(KeyboardInterrupt):
                output.poll_with_spinner(poll_fn, interval=0, label="test")


if __name__ == "__main__":
    unittest.main()
