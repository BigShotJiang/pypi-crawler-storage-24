import unittest
from unittest.mock import MagicMock, patch
from typer.testing import CliRunner

from quapp.cli.app import app


class TestWatchJsonGuard(unittest.TestCase):
    """quapp --json watch should exit 1 with an incompatibility message."""

    def setUp(self):
        self.runner = CliRunner()
        from quapp import output
        output.set_json_mode(False)

    def tearDown(self):
        from quapp import output
        output.set_json_mode(False)

    def test_json_flag_exits_1(self):
        result = self.runner.invoke(app, ["--json", "watch", "abc-123"])
        self.assertEqual(result.exit_code, 1)

    def test_json_flag_stderr_message(self):
        result = self.runner.invoke(app, ["--json", "watch", "abc-123"], catch_exceptions=False)
        # Message should appear in output (CliRunner merges stdout/stderr by default)
        self.assertIn("incompatible", result.output.lower())


class TestJobWatchJsonGuard(unittest.TestCase):
    """quapp --json job watch should also exit 1."""

    def setUp(self):
        self.runner = CliRunner()
        from quapp import output
        output.set_json_mode(False)

    def tearDown(self):
        from quapp import output
        output.set_json_mode(False)

    def test_job_watch_json_exits_1(self):
        result = self.runner.invoke(app, ["--json", "job", "watch", "abc-123"])
        self.assertEqual(result.exit_code, 1)


if __name__ == "__main__":
    unittest.main()
