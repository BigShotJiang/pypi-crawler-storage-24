import unittest
from unittest.mock import MagicMock, patch
import base64
import json

from quapp.api.client import QuappClient, QuappAuthError
from quapp.api.users import get_current_user, decode_user_id_from_token


class TestDecodeUserIdFromToken(unittest.TestCase):

    def _make_jwt(self, payload: dict) -> str:
        header = base64.urlsafe_b64encode(b'{"alg":"HS256"}').rstrip(b"=").decode()
        body = base64.urlsafe_b64encode(
            json.dumps(payload).encode()
        ).rstrip(b"=").decode()
        return f"{header}.{body}.fakesig"

    def test_extracts_sub_claim(self):
        token = self._make_jwt({"sub": "user-123"})
        uid = decode_user_id_from_token(token)
        self.assertEqual(uid, "user-123")

    def test_missing_sub_returns_none(self):
        token = self._make_jwt({"email": "a@b.com"})
        uid = decode_user_id_from_token(token)
        self.assertIsNone(uid)

    def test_invalid_token_returns_none(self):
        uid = decode_user_id_from_token("not.a.jwt")
        self.assertIsNone(uid)

    def test_empty_token_returns_none(self):
        uid = decode_user_id_from_token("")
        self.assertIsNone(uid)

    def test_payload_with_padding_needed(self):
        payload = {"sub": "x" * 10}
        token = self._make_jwt(payload)
        uid = decode_user_id_from_token(token)
        self.assertEqual(uid, "x" * 10)


class TestGetCurrentUser(unittest.TestCase):

    @patch("quapp.api.users.QuappClient.get")
    def test_returns_user_dict(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"id": "u1", "name": "Alice", "email": "a@b.com"}}
        mock_get.return_value = mock_resp
        client = QuappClient("https://x.com", token="t")
        result = get_current_user(client, "u1")
        mock_get.assert_called_once_with("/users/u1")
        self.assertEqual(result["name"], "Alice")

    @patch("quapp.api.users.QuappClient.get")
    def test_401_raises_auth_error(self, mock_get):
        mock_get.side_effect = QuappAuthError("Not authenticated.", status_code=401)
        client = QuappClient("https://x.com", token="bad")
        with self.assertRaises(QuappAuthError):
            get_current_user(client, "u1")


if __name__ == "__main__":
    unittest.main()
