import time
import unittest
from unittest.mock import MagicMock, patch, call

from quapp.api.client import (
    QuappClient,
    QuappAuthError,
    QuappForbiddenError,
    QuappNotFoundError,
    QuappBadRequestError,
    QuappRateLimitError,
    QuappServerError,
)


def _mock_response(status_code: int, json_data: dict | None = None, text: str = ""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.text = text
    resp.content = b"content" if json_data is not None else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


class TestQuappClient(unittest.TestCase):
    def setUp(self):
        self.client = QuappClient("https://functions.quapp.cloud/api/v1", token="test-token")

    def test_auth_header_injected(self):
        headers = self.client._headers()
        self.assertEqual(headers["Authorization"], "Bearer test-token")

    def test_no_auth_header_without_token(self):
        c = QuappClient("https://functions.quapp.cloud/api/v1")
        headers = c._headers()
        self.assertNotIn("Authorization", headers)

    @patch("requests.Session.request")
    def test_successful_get(self, mock_req):
        mock_req.return_value = _mock_response(200, {"id": "abc"})
        resp = self.client.get("/projects/abc")
        self.assertEqual(resp.json(), {"id": "abc"})

    @patch("requests.Session.request")
    def test_raises_auth_error_on_401(self, mock_req):
        mock_req.return_value = _mock_response(401)
        with self.assertRaises(QuappAuthError):
            self.client.get("/projects/x")

    @patch("requests.Session.request")
    def test_raises_forbidden_on_403(self, mock_req):
        mock_req.return_value = _mock_response(403)
        with self.assertRaises(QuappForbiddenError):
            self.client.get("/projects/x")

    @patch("requests.Session.request")
    def test_raises_not_found_on_404(self, mock_req):
        mock_req.return_value = _mock_response(404)
        with self.assertRaises(QuappNotFoundError):
            self.client.get("/projects/missing")

    @patch("requests.Session.request")
    def test_raises_server_error_on_500(self, mock_req):
        mock_req.return_value = _mock_response(500)
        with self.assertRaises(QuappServerError):
            self.client.get("/projects/x")

    @patch("time.sleep")
    @patch("requests.Session.request")
    def test_retries_on_429_then_succeeds(self, mock_req, mock_sleep):
        mock_req.side_effect = [
            _mock_response(429),
            _mock_response(429),
            _mock_response(200, {"ok": True}),
        ]
        resp = self.client.get("/functions/x", retries=3)
        self.assertEqual(mock_req.call_count, 3)
        self.assertEqual(mock_sleep.call_count, 2)

    @patch("time.sleep")
    @patch("requests.Session.request")
    def test_raises_after_max_retries(self, mock_req, mock_sleep):
        mock_req.return_value = _mock_response(429)
        with self.assertRaises(QuappRateLimitError):
            self.client.get("/functions/x", retries=3)
        self.assertEqual(mock_req.call_count, 4)  # 1 initial + 3 retries

    @patch("time.sleep")
    @patch("requests.Session.request")
    def test_retries_on_503(self, mock_req, mock_sleep):
        mock_req.side_effect = [_mock_response(503), _mock_response(200, {})]
        self.client.get("/jobs/x", retries=2)
        self.assertEqual(mock_req.call_count, 2)

    def test_unwrap_strips_data_envelope(self):
        from quapp.api.client import unwrap
        self.assertEqual(unwrap({"data": {"id": "x"}}), {"id": "x"})

    def test_unwrap_passthrough_when_no_envelope(self):
        from quapp.api.client import unwrap
        self.assertEqual(unwrap({"id": "x"}), {"id": "x"})


class TestProjectIdHeader(unittest.TestCase):
    @patch("requests.Session.request")
    def test_project_id_injected_as_header(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.ok = True
        mock_req.return_value = mock_resp
        client = QuappClient("https://functions.quapp.cloud/api/v1", token="tok", project_id="518")
        client.get("/functions/1")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["headers"]["X-Project-Id"], "518")

    @patch("requests.Session.request")
    def test_no_project_id_header_when_not_set(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.ok = True
        mock_req.return_value = mock_resp
        client = QuappClient("https://functions.quapp.cloud/api/v1", token="tok")
        client.get("/functions/1")
        _, kwargs = mock_req.call_args
        self.assertNotIn("X-Project-Id", kwargs["headers"])


class TestListAllPages(unittest.TestCase):

    def _make_client(self):
        return QuappClient("https://example.com", token="tok")

    def _page_response(self, content, page_number, total_pages):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": {
                "content": content,
                "pageNumber": page_number,
                "totalPages": total_pages,
            }
        }
        return mock_resp

    @patch("requests.Session.request")
    def test_single_page_returns_content(self, mock_req):
        mock_req.return_value = self._page_response([{"id": 1}], 0, 1)
        client = self._make_client()
        result = client.list_all_pages("/projects")
        self.assertEqual(result, [{"id": 1}])
        self.assertEqual(mock_req.call_count, 1)

    @patch("requests.Session.request")
    def test_multi_page_accumulates(self, mock_req):
        mock_req.side_effect = [
            self._page_response([{"id": 1}], 0, 2),
            self._page_response([{"id": 2}], 1, 2),
        ]
        client = self._make_client()
        result = client.list_all_pages("/projects")
        self.assertEqual(result, [{"id": 1}, {"id": 2}])
        self.assertEqual(mock_req.call_count, 2)

    @patch("requests.Session.request")
    def test_empty_content_stops_iteration(self, mock_req):
        mock_req.side_effect = [
            self._page_response([{"id": 1}], 0, 3),
            self._page_response([], 1, 3),
        ]
        client = self._make_client()
        result = client.list_all_pages("/projects")
        self.assertEqual(result, [{"id": 1}])
        self.assertEqual(mock_req.call_count, 2)

    @patch("requests.Session.request")
    def test_total_pages_guard_stops_iteration(self, mock_req):
        mock_req.side_effect = [
            self._page_response([{"id": 1}], 0, 1),
            self._page_response([{"id": 2}], 1, 1),  # should never be called
        ]
        client = self._make_client()
        result = client.list_all_pages("/projects")
        self.assertEqual(result, [{"id": 1}])
        self.assertEqual(mock_req.call_count, 1)

    @patch("requests.Session.request")
    def test_caller_params_forwarded_to_every_page(self, mock_req):
        mock_req.side_effect = [
            self._page_response([{"id": 1}], 0, 2),
            self._page_response([{"id": 2}], 1, 2),
        ]
        client = self._make_client()
        result = client.list_all_pages("/projects", params={"size": 20})
        self.assertEqual(result, [{"id": 1}, {"id": 2}])
        # Both calls must include size=20 in the query params
        for call in mock_req.call_args_list:
            call_kwargs = call[1]  # keyword args dict
            params_sent = call_kwargs.get("params", {})
            self.assertIn("size", params_sent)
            self.assertEqual(params_sent["size"], 20)

    @patch("requests.Session.request")
    def test_empty_first_page_returns_empty_list(self, mock_req):
        mock_req.return_value = self._page_response([], 0, 0)
        client = self._make_client()
        result = client.list_all_pages("/projects")
        self.assertEqual(result, [])
        self.assertEqual(mock_req.call_count, 1)


if __name__ == "__main__":
    unittest.main()
