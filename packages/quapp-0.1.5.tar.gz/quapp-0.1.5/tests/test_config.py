import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from quapp.config import Config, load_config, save_config, DEFAULT_BASE_URL


class TestConfig(unittest.TestCase):
    def test_defaults(self):
        cfg = Config()
        self.assertIsNone(cfg.token)
        self.assertEqual(cfg.base_url, DEFAULT_BASE_URL)

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            with patch("quapp.config.CONFIG_FILE", config_file), \
                 patch("quapp.config.CONFIG_DIR", Path(tmpdir)):
                cfg = Config(token="tok123", base_url="https://example.com")
                save_config(cfg)
                loaded = load_config()
        self.assertEqual(loaded.token, "tok123")
        self.assertEqual(loaded.base_url, "https://example.com")

    def test_load_missing_file_returns_defaults(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "nonexistent.json"
            with patch("quapp.config.CONFIG_FILE", config_file):
                cfg = load_config()
        self.assertIsNone(cfg.token)
        self.assertEqual(cfg.base_url, DEFAULT_BASE_URL)

    def test_load_corrupt_file_returns_defaults(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            config_file.write_text("NOT JSON", encoding="utf-8")
            with patch("quapp.config.CONFIG_FILE", config_file):
                cfg = load_config()
        self.assertIsNone(cfg.token)


class TestConfigChmodGuard(unittest.TestCase):
    def test_chmod_not_called_on_windows(self):
        with tempfile.TemporaryDirectory() as tmp:
            config_file = Path(tmp) / "config.json"
            config_dir = Path(tmp)
            from quapp.config import Config, save_config
            with patch("quapp.config.CONFIG_FILE", config_file), \
                 patch("quapp.config.CONFIG_DIR", config_dir), \
                 patch("quapp.config.os.name", "nt"), \
                 patch("pathlib.Path.chmod") as mock_chmod:
                save_config(Config(token="t", base_url="https://x.com"))
                mock_chmod.assert_not_called()


if __name__ == "__main__":
    unittest.main()
