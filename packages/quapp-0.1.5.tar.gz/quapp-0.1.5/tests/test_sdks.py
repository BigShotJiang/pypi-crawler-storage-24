from __future__ import annotations

import unittest
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner
from quapp.cli.app import app


class TestSdkCommand(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    def _mock_config(self, token="tok"):
        return MagicMock(token=token, base_url="https://x.com", project_id=None)

    def test_sdk_lists_without_subcommand(self):
        """quapp sdk (no sub-verb) should return SDK table."""
        with patch("quapp.cli.sdks.load_config", return_value=self._mock_config()):
            with patch("quapp.cli.sdks.list_sdks", return_value=[
                {"name": "qiskit", "version": "0.45.3"}
            ]):
                result = self.runner.invoke(app, ["sdk"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("qiskit", result.output)

    def test_sdk_list_subcommand_no_longer_exists(self):
        """quapp sdk list should now be an error (no such sub-command)."""
        result = self.runner.invoke(app, ["sdk", "list"])
        self.assertNotEqual(result.exit_code, 0)

    def test_sdk_exits_1_when_not_logged_in(self):
        with patch("quapp.cli.sdks.load_config", return_value=self._mock_config(token=None)):
            result = self.runner.invoke(app, ["sdk"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("login", result.output.lower())


if __name__ == "__main__":
    unittest.main()
