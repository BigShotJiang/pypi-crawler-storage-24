"""
test_handler_qec.py — Unit + integration tests for handler_qec.py
Run: python -m pytest tests/test_handler_qec.py -v
Requires: pip install qiskit==1.3.2 qiskit-aer==0.17.2 numpy
"""
import importlib.util
import sys
import unittest

_QISKIT_AVAILABLE = importlib.util.find_spec("qiskit") is not None

if _QISKIT_AVAILABLE:
    import numpy as np
    sys.path.insert(0, "handlers/qec")
    import handler_qec as h
    from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
    from qiskit_aer import AerSimulator


# =============================================================================
# 1. Module-level constants
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestSyndromeTable(unittest.TestCase):

    def test_table_has_7_data_entries(self):
        """Each of the 7 qubits must appear as a value in the table."""
        qubits_in_table = set(v for v in h._SYNDROME_TABLE.values() if v >= 0)
        self.assertEqual(qubits_in_table, set(range(7)))

    def test_table_has_zero_entry_for_no_error(self):
        self.assertEqual(h._SYNDROME_TABLE[0], -1)

    def test_all_keys_are_nonzero_except_identity(self):
        for key, qubit in h._SYNDROME_TABLE.items():
            if key == 0:
                self.assertEqual(qubit, -1)
            else:
                self.assertGreaterEqual(qubit, 0)
                self.assertLess(qubit, 7)

    def test_H_matrix_shape(self):
        self.assertEqual(h._H.shape, (3, 7))

    def test_stabilizer_supports_length(self):
        self.assertEqual(len(h._STABILIZER_SUPPORTS), 3)
        for s in h._STABILIZER_SUPPORTS:
            self.assertGreater(len(s), 0)


# =============================================================================
# 2. _count_logical_errors
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestCountLogicalErrors(unittest.TestCase):

    def test_no_errors(self):
        counts = {"0 000 000": 100}
        n_err, total = h._count_logical_errors(counts)
        self.assertEqual(n_err, 0)
        self.assertEqual(total, 100)

    def test_all_errors(self):
        counts = {"1 000 000": 50}
        n_err, total = h._count_logical_errors(counts)
        self.assertEqual(n_err, 50)
        self.assertEqual(total, 50)

    def test_mixed(self):
        counts = {"0 000 000": 70, "1 000 000": 30}
        n_err, total = h._count_logical_errors(counts)
        self.assertEqual(n_err, 30)
        self.assertEqual(total, 100)

    def test_with_syndrome_bits(self):
        # logq=1 + various syndrome patterns
        counts = {"1 010 100": 10, "0 010 100": 90}
        n_err, total = h._count_logical_errors(counts)
        self.assertEqual(n_err, 10)
        self.assertEqual(total, 100)

    def test_empty_counts(self):
        n_err, total = h._count_logical_errors({})
        self.assertEqual(n_err, 0)
        self.assertEqual(total, 0)


# =============================================================================
# 3. _build_noise_model
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestBuildNoiseModel(unittest.TestCase):

    def test_x_noise_model_returns_noise_model(self):
        from qiskit_aer.noise import NoiseModel
        nm = h._build_noise_model(0.01, 'X')
        self.assertIsInstance(nm, NoiseModel)

    def test_z_noise_model_returns_noise_model(self):
        from qiskit_aer.noise import NoiseModel
        nm = h._build_noise_model(0.01, 'Z')
        self.assertIsInstance(nm, NoiseModel)

    def test_dep_noise_model_returns_noise_model(self):
        from qiskit_aer.noise import NoiseModel
        nm = h._build_noise_model(0.01, 'dep')
        self.assertIsInstance(nm, NoiseModel)

    def test_noise_model_at_p0_is_trivial(self):
        # p=0 should not add meaningful noise
        nm = h._build_noise_model(0.0, 'dep')
        from qiskit_aer.noise import NoiseModel
        self.assertIsInstance(nm, NoiseModel)

    def test_noise_model_at_p1_raises_or_valid(self):
        # p=1.0 should still construct a valid model (probabilities are 0 or 1)
        try:
            nm = h._build_noise_model(1.0, 'X')
            from qiskit_aer.noise import NoiseModel
            self.assertIsInstance(nm, NoiseModel)
        except Exception as exc:
            self.fail(f"_build_noise_model(1.0, 'X') raised unexpectedly: {exc}")


# =============================================================================
# 4. Circuit construction
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestBuildLerCircuit(unittest.TestCase):

    def setUp(self):
        self.qc = h._build_ler_circuit()

    def test_returns_quantum_circuit(self):
        self.assertIsInstance(self.qc, QuantumCircuit)

    def test_circuit_has_13_qubits(self):
        # 7 data + 3 anc_x + 3 anc_z = 13
        self.assertEqual(self.qc.num_qubits, 13)

    def test_circuit_has_7_classical_bits(self):
        # x_syn(3) + z_syn(3) + logq(1) = 7
        self.assertEqual(self.qc.num_clbits, 7)

    def test_circuit_has_positive_depth(self):
        self.assertGreater(self.qc.depth(), 0)

    def test_circuit_has_measure_operations(self):
        ops = [instr.operation.name for instr in self.qc.data]
        self.assertIn('measure', ops)


# =============================================================================
# 5. Encode / Decode roundtrip
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestEncodeDecode(unittest.TestCase):

    def test_encode_decode_roundtrip_noiseless(self):
        """
        Encode |0_L> then decode. The logical qubit (data[0]) must read 0
        with 100% probability in a noiseless simulation.
        """
        data = QuantumRegister(7, 'data')
        logq = ClassicalRegister(1, 'logq')
        qc = QuantumCircuit(data, logq)
        h._encode(qc, data)
        h._decode(qc, data)
        qc.measure(data[0], logq[0])

        backend = AerSimulator()
        tc = transpile(qc, backend=backend, optimization_level=0)
        counts = backend.run(tc, shots=1024).result().get_counts()
        # Should only get '0'
        self.assertNotIn('1', counts,
            "Encode→Decode roundtrip measured logical |1>: decode is not the inverse of encode")
        self.assertIn('0', counts)


# =============================================================================
# 6. Syndrome correction — critical test for bit-ordering bug
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestSyndromeCorrection(unittest.TestCase):

    def _run_with_injected_x_error(self, target_qubit: int) -> dict:
        """
        Build the full LER circuit, inject an X error on target_qubit
        AFTER encoding, then run. Returns get_counts().
        """
        data  = QuantumRegister(7, 'data')
        anc_x = QuantumRegister(3, 'anc_x')
        anc_z = QuantumRegister(3, 'anc_z')
        x_syn = ClassicalRegister(3, 'x_syn')
        z_syn = ClassicalRegister(3, 'z_syn')
        logq  = ClassicalRegister(1, 'logq')
        qc = QuantumCircuit(data, anc_x, anc_z, x_syn, z_syn, logq)

        h._encode(qc, data)
        qc.x(data[target_qubit])          # inject known X error
        h._measure_z_stabilizers(qc, data, anc_x, x_syn)
        h._measure_x_stabilizers(qc, data, anc_z, z_syn)

        # feedforward from handler
        from handler_qec import _SYNDROME_TABLE
        for syn_val, qubit in _SYNDROME_TABLE.items():
            if syn_val > 0:
                with qc.if_test((x_syn, syn_val)):
                    qc.x(data[qubit])

        h._decode(qc, data)
        qc.measure(data[0], logq[0])

        backend = AerSimulator()
        tc = transpile(qc, backend=backend, optimization_level=0)
        return backend.run(tc, shots=512).result().get_counts()

    def test_correct_x_error_on_each_qubit(self):
        """
        The Steane code should correct a single X error on any of the 7
        data qubits — logical readout must be 0 for all.
        Failed qubits indicate a syndrome table bit-ordering bug.
        """
        failed = []
        for q in range(7):
            counts = self._run_with_injected_x_error(q)
            logq_val = int(list(counts.keys())[0].split(' ')[0]) if counts else -1
            # Check if ANY shot gave logical 1 (all should give 0)
            logical_ones = sum(v for k, v in counts.items() if int(k.split(' ')[0]) == 1)
            total = sum(counts.values())
            ler = logical_ones / total if total > 0 else 1.0
            if ler > 0.05:   # allow small simulation noise
                failed.append((q, ler))

        self.assertEqual(failed, [],
            f"X error correction failed for qubit(s): "
            f"{[(q, f'{ler:.3f}') for q, ler in failed]}. "
            f"Likely cause: syndrome table bit ordering mismatch with if_test.")


# =============================================================================
# 7. processing() + post_processing() integration
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestProcessingIntegration(unittest.TestCase):

    def setUp(self):
        """Run processing() once with a minimal payload (fast)."""
        payload = {
            "p_values":    [0.05, 0.1],
            "shots":       256,
            "error_types": ["dep"],
            "noiseless":   True,
        }
        self.qc = h.processing(payload)
        self.result = h.post_processing(None)   # job_result is ignored in Option C

    def test_processing_returns_quantum_circuit(self):
        self.assertIsInstance(self.qc, QuantumCircuit)

    def test_processing_returns_placeholder_1_qubit(self):
        self.assertEqual(self.qc.num_qubits, 1)
        self.assertEqual(self.qc.name, "placeholder")

    def test_post_processing_returns_dict(self):
        self.assertIsInstance(self.result, dict)

    def test_result_has_required_keys(self):
        for key in ("code", "shots", "ler", "noiseless"):
            self.assertIn(key, self.result, f"Missing key: {key}")

    def test_result_code_is_steane(self):
        self.assertEqual(self.result["code"], "steane_7_1_3")

    def test_result_shots_matches_payload(self):
        self.assertEqual(self.result["shots"], 256)

    def test_result_ler_has_dep_key(self):
        self.assertIn("dep", self.result["ler"])

    def test_result_ler_dep_has_p_and_ler_lists(self):
        dep = self.result["ler"]["dep"]
        self.assertIn("p", dep)
        self.assertIn("ler", dep)
        self.assertEqual(len(dep["p"]), 2)
        self.assertEqual(len(dep["ler"]), 2)

    def test_result_ler_values_between_0_and_1(self):
        for et, data in self.result["ler"].items():
            for val in data["ler"]:
                self.assertGreaterEqual(val, 0.0, f"{et} LER < 0")
                self.assertLessEqual(val, 1.0,   f"{et} LER > 1")

    def test_noiseless_ler_is_zero(self):
        noiseless = self.result["noiseless"]
        self.assertEqual(noiseless["ler"], 0.0,
            "Noiseless run should have ler=0.0 (encode→syndrome→decode with no noise)")

    def test_noiseless_n_errors_is_zero(self):
        self.assertEqual(self.result["noiseless"]["n_errors"], 0)

    def test_ler_increases_with_p(self):
        """LER at p=0.1 should be >= LER at p=0.05."""
        dep = self.result["ler"]["dep"]
        self.assertGreaterEqual(dep["ler"][1], dep["ler"][0],
            "LER should increase with physical error rate")


# =============================================================================
# 8. Error types sweep
# =============================================================================

@unittest.skipUnless(_QISKIT_AVAILABLE, "qiskit not installed")
class TestAllErrorTypes(unittest.TestCase):

    def test_x_and_z_error_types(self):
        payload = {
            "p_values":    [0.05],
            "shots":       128,
            "error_types": ["X", "Z"],
            "noiseless":   False,
        }
        qc = h.processing(payload)
        result = h.post_processing(None)
        self.assertIn("X", result["ler"])
        self.assertIn("Z", result["ler"])
        self.assertNotIn("dep", result["ler"])

    def test_all_three_error_types(self):
        payload = {
            "p_values":    [0.05],
            "shots":       128,
            "error_types": ["X", "Z", "dep"],
            "noiseless":   False,
        }
        h.processing(payload)
        result = h.post_processing(None)
        for et in ("X", "Z", "dep"):
            self.assertIn(et, result["ler"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
