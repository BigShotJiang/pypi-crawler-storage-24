import unittest
from unittest.mock import MagicMock, patch

from quapp.api.client import QuappClient, QuappNotFoundError
from quapp.api.jobs import (
    run_job,
    get_job_status,
    get_job_results,
    cancel_job,
    retry_job,
    list_jobs,
)


def _client():
    return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")


def _mock_response(status_code: int, json_data: dict | None = None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.content = b"x" if json_data else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


class TestJobsApi(unittest.TestCase):
    @patch("requests.Session.request")
    def test_run_job_returns_job_id(self, mock_req):
        mock_req.return_value = _mock_response(202, {"jobId": "j1"})
        result = run_job(_client(), "f1", "quapp", 1, 1000)
        self.assertEqual(result["jobId"], "j1")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["functionName"], "f1")
        self.assertEqual(kwargs["json"]["shots"], 1000)

    @patch("requests.Session.request")
    def test_get_job_status(self, mock_req):
        resp = MagicMock()
        resp.ok = True
        resp.status_code = 200
        resp.json.return_value = {"data": {"id": "j1", "status": "RUNNING"}}
        mock_req.return_value = resp
        result = get_job_status(_client(), "j1")
        self.assertEqual(result["status"], "RUNNING")
        mock_req.assert_called_once()

    @patch("requests.Session.request")
    def test_get_job_status_not_found(self, mock_req):
        resp = MagicMock()
        resp.ok = False
        resp.status_code = 404
        resp.json.return_value = {"message": "not found"}
        resp.text = "not found"
        mock_req.return_value = resp
        with self.assertRaises(QuappNotFoundError):
            get_job_status(_client(), "ghost")

    @patch("requests.Session.request")
    def test_get_job_results(self, mock_req):
        resp = MagicMock()
        resp.ok = True
        resp.status_code = 200
        resp.json.return_value = {
            "data": {"id": "j1", "status": "DONE", "counts": {"0": 500, "1": 500}}
        }
        mock_req.return_value = resp
        result = get_job_results(_client(), "j1")
        self.assertIn("counts", result)
        mock_req.assert_called_once()

    @patch("requests.Session.request")
    def test_cancel_job(self, mock_req):
        mock_req.return_value = _mock_response(200, {})
        cancel_job(_client(), "j1")
        args, _ = mock_req.call_args
        self.assertEqual(args[0], "DELETE")
        self.assertIn("/jobs/j1", args[1])

    @patch("requests.Session.request")
    def test_retry_job(self, mock_req):
        mock_req.return_value = _mock_response(200, {"jobId": "j2"})
        result = retry_job(_client(), "j1")
        self.assertEqual(result["jobId"], "j2")
        args, _ = mock_req.call_args
        self.assertEqual(args[0], "POST")
        self.assertIn("/jobs/j1/retry", args[1])


class TestListJobsAllPages(unittest.TestCase):
    @patch("quapp.api.jobs.QuappClient.list_all_pages")
    def test_list_jobs_uses_all_pages(self, mock_pages):
        mock_pages.return_value = [{"id": "j1"}, {"id": "j2"}]
        client = QuappClient("https://x.com", token="t", project_id="p1")
        result = list_jobs(client)
        mock_pages.assert_called_once_with("/jobs")
        self.assertEqual(len(result), 2)


class TestGetJobStatusDetail(unittest.TestCase):

    @patch("requests.Session.request")
    def test_finds_job_by_detail_endpoint(self, mock_req):
        resp = MagicMock()
        resp.ok = True
        resp.status_code = 200
        resp.json.return_value = {"data": {"id": "abc", "status": "DONE"}}
        mock_req.return_value = resp
        client = QuappClient("https://x.com", token="t", project_id="p1")
        result = get_job_status(client, "abc")
        self.assertEqual(result["status"], "DONE")
        self.assertEqual(mock_req.call_count, 1)
        args, _ = mock_req.call_args
        self.assertIn("/jobs/abc/detail", args[1])

    @patch("requests.Session.request")
    def test_raises_not_found_on_404(self, mock_req):
        resp = MagicMock()
        resp.ok = False
        resp.status_code = 404
        resp.json.return_value = {"message": "not found"}
        resp.text = "not found"
        mock_req.return_value = resp
        client = QuappClient("https://x.com", token="t", project_id="p1")
        with self.assertRaises(QuappNotFoundError):
            get_job_status(client, "ghost")

    @patch("requests.Session.request")
    def test_single_http_call_per_status_check(self, mock_req):
        resp = MagicMock()
        resp.ok = True
        resp.status_code = 200
        resp.json.return_value = {"data": {"id": "j1", "status": "RUNNING"}}
        mock_req.return_value = resp
        client = QuappClient("https://x.com", token="t", project_id="p1")
        get_job_status(client, "j1")
        self.assertEqual(mock_req.call_count, 1)


class TestJobWatchCommand(unittest.TestCase):
    def setUp(self):
        from quapp import output
        output.set_json_mode(False)

    @patch("quapp.tui.dashboard.run_dashboard")
    def test_watch_exits_on_done(self, mock_dashboard):
        """watch delegates to run_dashboard and exits 0 on normal completion."""
        from typer.testing import CliRunner
        from quapp.cli.jobs import app
        runner = CliRunner()
        with patch("quapp.cli.jobs.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id="p1")
            result = runner.invoke(app, ["watch", "j1"])
        self.assertEqual(result.exit_code, 0)
        mock_dashboard.assert_called_once()

    @patch("quapp.tui.dashboard.run_dashboard")
    def test_watch_exits_code_1_on_failed(self, mock_dashboard):
        """watch delegates to run_dashboard; exit code from dashboard call."""
        from typer.testing import CliRunner
        from quapp.cli.jobs import app
        runner = CliRunner()
        with patch("quapp.cli.jobs.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id="p1")
            result = runner.invoke(app, ["watch", "j1"])
        self.assertEqual(result.exit_code, 0)
        mock_dashboard.assert_called_once()

    @patch("quapp.tui.dashboard.run_dashboard")
    def test_watch_polls_until_terminal(self, mock_dashboard):
        """watch delegates to run_dashboard; interval arg accepted for backward compat."""
        from typer.testing import CliRunner
        from quapp.cli.jobs import app
        runner = CliRunner()
        with patch("quapp.cli.jobs.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id="p1")
            result = runner.invoke(app, ["watch", "j1", "--interval", "1"])
        self.assertEqual(result.exit_code, 0)
        mock_dashboard.assert_called_once()


class TestCancelJob(unittest.TestCase):
    @patch("quapp.api.jobs.QuappClient.delete")
    def test_cancel_sends_delete(self, mock_delete):
        mock_delete.return_value = MagicMock(ok=True, status_code=200)
        client = QuappClient("https://x.com", token="t", project_id="p1")
        cancel_job(client, "j1")
        mock_delete.assert_called_once_with("/jobs/j1")

    @patch("quapp.api.jobs.QuappClient.delete")
    def test_cancel_not_found_raises(self, mock_delete):
        from quapp.api.client import QuappNotFoundError
        mock_delete.side_effect = QuappNotFoundError("not found", status_code=404)
        client = QuappClient("https://x.com", token="t", project_id="p1")
        with self.assertRaises(QuappNotFoundError):
            cancel_job(client, "ghost")


class TestRetryJob(unittest.TestCase):
    @patch("quapp.api.jobs.QuappClient.post")
    def test_retry_sends_post(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"jobId": "j2"}
        mock_post.return_value = mock_resp
        client = QuappClient("https://x.com", token="t", project_id="p1")
        result = retry_job(client, "j1")
        mock_post.assert_called_once_with("/jobs/j1/retry")
        self.assertEqual(result["jobId"], "j2")


class TestPollUntilDone(unittest.TestCase):
    @patch("quapp.cli.jobs.time.sleep")
    @patch("quapp.cli.jobs.get_job_status")
    def test_returns_immediately_on_done(self, mock_status, mock_sleep):
        mock_status.return_value = {"status": "DONE", "id": "j1"}
        client = QuappClient("https://x.com", token="t", project_id="p1")
        from quapp.cli.jobs import _poll_until_done
        result = _poll_until_done(client, "j1")
        self.assertEqual(result["status"], "DONE")
        mock_sleep.assert_not_called()

    @patch("quapp.cli.jobs.time.sleep")
    @patch("quapp.cli.jobs.get_job_status")
    def test_polls_with_backoff(self, mock_status, mock_sleep):
        mock_status.side_effect = [
            {"status": "IN_QUEUE", "id": "j1"},
            {"status": "RUNNING", "id": "j1"},
            {"status": "DONE", "id": "j1"},
        ]
        client = QuappClient("https://x.com", token="t", project_id="p1")
        from quapp.cli.jobs import _poll_until_done
        _poll_until_done(client, "j1")
        self.assertEqual(mock_sleep.call_count, 2)
        self.assertAlmostEqual(mock_sleep.call_args_list[0][0][0], 2.0)
        self.assertAlmostEqual(mock_sleep.call_args_list[1][0][0], 4.0)

    @patch("quapp.cli.jobs.time.sleep")
    @patch("quapp.cli.jobs.get_job_status")
    def test_exits_on_failed(self, mock_status, mock_sleep):
        mock_status.return_value = {"status": "FAILED", "id": "j1"}
        client = QuappClient("https://x.com", token="t", project_id="p1")
        from quapp.cli.jobs import _poll_until_done
        result = _poll_until_done(client, "j1")
        self.assertEqual(result["status"], "FAILED")
        mock_sleep.assert_not_called()


if __name__ == "__main__":
    unittest.main()
