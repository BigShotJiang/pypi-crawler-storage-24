import unittest
from unittest.mock import MagicMock, patch

from quapp.api.auth import login, logout
from quapp.api.client import QuappAuthError


def _mock_response(status_code: int, json_data: dict | None = None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.content = b"content" if json_data else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


class TestApiAuth(unittest.TestCase):
    @patch("requests.Session.request")
    def test_login_returns_tokens(self, mock_req):
        mock_req.return_value = _mock_response(
            200, {"accessToken": "at123", "refreshToken": "rt456"}
        )
        result = login("https://functions.quapp.cloud/api/v1", "user@example.com", "pass")
        self.assertEqual(result["accessToken"], "at123")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["username"], "user@example.com")

    @patch("requests.Session.request")
    def test_login_sends_username_key(self, mock_req):
        mock_req.return_value = _mock_response(
            200, {"accessToken": "at123", "refreshToken": "rt456"}
        )
        login("https://functions.quapp.cloud/api/v1", "user@example.com", "pass")
        _, kwargs = mock_req.call_args
        self.assertIn("username", kwargs["json"])
        self.assertNotIn("email", kwargs["json"])
        self.assertEqual(kwargs["json"]["username"], "user@example.com")

    @patch("requests.Session.request")
    def test_login_unwraps_data_envelope(self, mock_req):
        mock_req.return_value = _mock_response(
            200, {"data": {"accessToken": "wrapped_token", "refreshToken": "rt"}}
        )
        result = login("https://functions.quapp.cloud/api/v1", "u@example.com", "pass")
        self.assertEqual(result["accessToken"], "wrapped_token")

    @patch("requests.Session.request")
    def test_login_raises_on_401(self, mock_req):
        mock_req.return_value = _mock_response(401)
        with self.assertRaises(QuappAuthError):
            login("https://functions.quapp.cloud/api/v1", "bad@example.com", "wrong")

    @patch("requests.Session.request")
    def test_logout_calls_endpoint(self, mock_req):
        mock_req.return_value = _mock_response(200, {})
        logout("https://functions.quapp.cloud/api/v1", "tok123")
        args, _ = mock_req.call_args
        self.assertEqual(args[0], "POST")
        self.assertIn("/auth/logout", args[1])


class TestCliAuthLogin(unittest.TestCase):
    def test_login_uses_email_password_flags(self):
        from typer.testing import CliRunner
        from quapp.cli.app import app

        # Patch the module attribute directly — works because auth.py does a deferred
        # `from quapp.api.auth import login as api_login` inside the function body.
        with patch("quapp.cli.auth.load_config") as mock_load, \
             patch("quapp.cli.auth.save_config") as mock_save, \
             patch("quapp.api.auth.login", return_value={"accessToken": "tok123"}):
            mock_load.return_value = MagicMock(base_url="https://api.quapp.cloud", token=None)
            runner = CliRunner()
            result = runner.invoke(app, ["login", "--email", "user@test.com", "--password", "secret"])

        self.assertEqual(result.exit_code, 0)
        mock_save.assert_called_once()


if __name__ == "__main__":
    unittest.main()
