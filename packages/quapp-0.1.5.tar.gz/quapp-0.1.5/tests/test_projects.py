import unittest
from unittest.mock import MagicMock, patch

from quapp.api.client import QuappClient, QuappNotFoundError
from quapp.api.projects import create_project, get_project, delete_project, find_project_by_name, list_projects


def _client():
    return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")


def _mock_response(status_code: int, json_data: dict | None = None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.content = b"x" if json_data else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


class TestProjectsApi(unittest.TestCase):
    @patch("requests.Session.request")
    def test_create_project(self, mock_req):
        mock_req.return_value = _mock_response(200, {"id": "p1", "name": "test"})
        result = create_project(_client(), "test", permission="private")
        self.assertEqual(result["id"], "p1")
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["name"], "test")

    @patch("requests.Session.request")
    def test_create_project_with_description(self, mock_req):
        mock_req.return_value = _mock_response(200, {"id": "p2"})
        create_project(_client(), "proj", description="desc", members=["a@b.com"])
        _, kwargs = mock_req.call_args
        self.assertEqual(kwargs["json"]["description"], "desc")
        self.assertIn("a@b.com", kwargs["json"]["members"])

    @patch("requests.Session.request")
    def test_get_project(self, mock_req):
        mock_req.return_value = _mock_response(200, {"id": "p1", "name": "test"})
        result = get_project(_client(), "p1")
        self.assertEqual(result["name"], "test")
        args, _ = mock_req.call_args
        self.assertIn("/projects/p1", args[1])

    @patch("requests.Session.request")
    def test_get_project_unwraps_data_envelope(self, mock_req):
        mock_req.return_value = _mock_response(200, {"data": {"id": "p1", "name": "wrapped"}})
        result = get_project(_client(), "p1")
        self.assertEqual(result["name"], "wrapped")

    @patch("requests.Session.request")
    def test_delete_project(self, mock_req):
        mock_req.return_value = _mock_response(200, {})
        delete_project(_client(), "p1")
        args, _ = mock_req.call_args
        self.assertEqual(args[0], "DELETE")
        self.assertIn("/projects/p1", args[1])

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_list_projects(self, mock_pages):
        mock_pages.return_value = [{"id": "p1"}, {"id": "p2"}]
        result = list_projects(_client())
        mock_pages.assert_called_once_with("/projects")
        self.assertEqual(len(result), 2)

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_list_projects_unwraps_content(self, mock_pages):
        mock_pages.return_value = [{"id": "p1"}]
        result = list_projects(_client())
        self.assertEqual(result[0]["id"], "p1")


class TestFindProjectByName(unittest.TestCase):
    def _client(self):
        return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_finds_by_exact_name(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "alpha"}, {"id": 2, "name": "beta"}]
        result = find_project_by_name(self._client(), "alpha")
        self.assertEqual(result["id"], 1)

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_finds_by_id_string(self, mock_pages):
        mock_pages.return_value = [{"id": 42, "name": "alpha"}, {"id": 99, "name": "beta"}]
        result = find_project_by_name(self._client(), "42")
        self.assertEqual(result["name"], "alpha")

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_finds_case_insensitive(self, mock_pages):
        mock_pages.return_value = [{"id": 5, "name": "MyProject"}]
        result = find_project_by_name(self._client(), "myproject")
        self.assertEqual(result["id"], 5)

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_exact_match_preferred_over_case_insensitive(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "Proj"}, {"id": 2, "name": "proj"}]
        result = find_project_by_name(self._client(), "proj")
        self.assertEqual(result["id"], 2)

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_raises_not_found_when_missing(self, mock_pages):
        mock_pages.return_value = [{"id": 1, "name": "other"}]
        with self.assertRaises(QuappNotFoundError):
            find_project_by_name(self._client(), "ghost")

    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_raises_not_found_on_empty_list(self, mock_pages):
        mock_pages.return_value = []
        with self.assertRaises(QuappNotFoundError):
            find_project_by_name(self._client(), "anything")


class TestListProjectsAllPages(unittest.TestCase):
    @patch("quapp.api.projects.QuappClient.list_all_pages")
    def test_list_projects_uses_all_pages(self, mock_pages):
        mock_pages.return_value = [{"id": 1}, {"id": 2}]
        client = QuappClient("https://x.com", token="t")
        result = list_projects(client)
        mock_pages.assert_called_once_with("/projects")
        self.assertEqual(len(result), 2)


if __name__ == "__main__":
    unittest.main()
