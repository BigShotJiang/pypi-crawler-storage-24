import unittest
from unittest.mock import MagicMock, patch

from quapp.api.client import QuappClient, QuappNotFoundError
from quapp.api.providers import list_providers, list_devices, find_device_by_name, find_provider_by_name


def _client():
    return QuappClient("https://functions.quapp.cloud/api/v1", token="tok")


def _make_response(json_data):
    resp = MagicMock()
    resp.status_code = 200
    resp.ok = True
    resp.content = b"x"
    resp.json.return_value = json_data
    return resp


class TestListProviders(unittest.TestCase):
    @patch("requests.Session.request")
    def test_returns_plain_list(self, mock_req):
        mock_req.return_value = _make_response({"data": [{"id": 1, "name": "Quapp"}]})
        result = list_providers(_client())
        self.assertEqual(result[0]["name"], "Quapp")

    @patch("requests.Session.request")
    def test_unwraps_data_content(self, mock_req):
        mock_req.return_value = _make_response(
            {"data": {"content": [{"id": 1, "name": "Quapp"}, {"id": 2, "name": "IBM"}]}}
        )
        result = list_providers(_client())
        self.assertEqual(len(result), 2)

    @patch("requests.Session.request")
    def test_calls_providers_endpoint(self, mock_req):
        mock_req.return_value = _make_response({"data": {"content": []}})
        list_providers(_client())
        args, _ = mock_req.call_args
        self.assertIn("/providers", args[1])


class TestListDevices(unittest.TestCase):
    @patch("requests.Session.request")
    def test_returns_devices_for_provider(self, mock_req):
        mock_req.return_value = _make_response(
            {"data": [{"id": 10, "name": "sim"}, {"id": 11, "name": "real"}]}
        )
        result = list_devices(_client(), 1)
        self.assertEqual(len(result), 2)

    @patch("requests.Session.request")
    def test_calls_correct_endpoint(self, mock_req):
        mock_req.return_value = _make_response({"data": {"content": []}})
        list_devices(_client(), 99)
        args, _ = mock_req.call_args
        self.assertIn("/providers/99/devices", args[1])

    @patch("requests.Session.request")
    def test_unwraps_items_envelope(self, mock_req):
        mock_req.return_value = _make_response(
            {"data": {"items": [{"id": 5, "name": "gpu"}]}}
        )
        result = list_devices(_client(), 1)
        self.assertEqual(result[0]["name"], "gpu")


class TestFindDeviceByName(unittest.TestCase):
    def _make_devices_response(self, devices):
        return _make_response({"content": devices})

    @patch("requests.Session.request")
    def test_finds_by_exact_name(self, mock_req):
        mock_req.return_value = self._make_devices_response(
            [{"id": 3, "name": "sim"}, {"id": 4, "name": "real"}]
        )
        result = find_device_by_name(_client(), 1, "sim")
        self.assertEqual(result["id"], 3)

    @patch("requests.Session.request")
    def test_finds_by_id_string(self, mock_req):
        mock_req.return_value = self._make_devices_response(
            [{"id": 3, "name": "sim"}, {"id": 4, "name": "real"}]
        )
        result = find_device_by_name(_client(), 1, "4")
        self.assertEqual(result["name"], "real")

    @patch("requests.Session.request")
    def test_finds_case_insensitive(self, mock_req):
        mock_req.return_value = self._make_devices_response(
            [{"id": 5, "name": "SimDevice"}]
        )
        result = find_device_by_name(_client(), 1, "simdevice")
        self.assertEqual(result["id"], 5)

    @patch("requests.Session.request")
    def test_exact_match_preferred_over_case_insensitive(self, mock_req):
        mock_req.return_value = self._make_devices_response(
            [{"id": 1, "name": "Sim"}, {"id": 2, "name": "sim"}]
        )
        result = find_device_by_name(_client(), 1, "sim")
        self.assertEqual(result["id"], 2)

    @patch("requests.Session.request")
    def test_raises_not_found_when_missing(self, mock_req):
        mock_req.return_value = self._make_devices_response(
            [{"id": 1, "name": "other"}]
        )
        with self.assertRaises(QuappNotFoundError):
            find_device_by_name(_client(), 1, "ghost")

    @patch("requests.Session.request")
    def test_raises_not_found_on_empty_list(self, mock_req):
        mock_req.return_value = self._make_devices_response([])
        with self.assertRaises(QuappNotFoundError):
            find_device_by_name(_client(), 1, "sim")

    @patch("requests.Session.request")
    def test_passes_provider_id_in_endpoint(self, mock_req):
        mock_req.return_value = self._make_devices_response([{"id": 7, "name": "q"}])
        find_device_by_name(_client(), 42, "q")
        args, _ = mock_req.call_args
        self.assertIn("/providers/42/devices", args[1])


class TestFindProviderByName(unittest.TestCase):
    def _make_client(self):
        return QuappClient("https://x.com", token="t")

    @patch("quapp.api.providers.list_providers")
    def test_exact_name_match(self, mock_list):
        mock_list.return_value = [{"id": 5, "name": "Quapp"}, {"id": 1, "name": "IBM"}]
        client = self._make_client()
        result = find_provider_by_name(client, "Quapp")
        self.assertEqual(result["id"], 5)

    @patch("quapp.api.providers.list_providers")
    def test_case_insensitive_match(self, mock_list):
        mock_list.return_value = [{"id": 5, "name": "Quapp"}]
        client = self._make_client()
        result = find_provider_by_name(client, "quapp")
        self.assertEqual(result["id"], 5)

    @patch("quapp.api.providers.list_providers")
    def test_not_found_raises(self, mock_list):
        mock_list.return_value = [{"id": 5, "name": "Quapp"}]
        client = self._make_client()
        with self.assertRaises(QuappNotFoundError):
            find_provider_by_name(client, "zzz-unknown")


class TestFindDeviceByNameTask15(unittest.TestCase):
    def _make_client(self):
        return QuappClient("https://x.com", token="t")

    @patch("quapp.api.providers.list_devices")
    def test_exact_name_match(self, mock_list):
        mock_list.return_value = [{"id": "d1", "name": "ibm_q"}, {"id": "d2", "name": "other"}]
        result = find_device_by_name(self._make_client(), 1, "ibm_q")
        self.assertEqual(result["id"], "d1")

    @patch("quapp.api.providers.list_devices")
    def test_exact_id_match(self, mock_list):
        mock_list.return_value = [{"id": "d1", "name": "ibm_q"}]
        result = find_device_by_name(self._make_client(), 1, "d1")
        self.assertEqual(result["name"], "ibm_q")

    @patch("quapp.api.providers.list_devices")
    def test_case_insensitive_match(self, mock_list):
        mock_list.return_value = [{"id": "d1", "name": "IBM_Q"}]
        result = find_device_by_name(self._make_client(), 1, "ibm_q")
        self.assertEqual(result["id"], "d1")

    @patch("quapp.api.providers.list_devices")
    def test_not_found_raises(self, mock_list):
        mock_list.return_value = [{"id": "d1", "name": "ibm_q"}]
        from quapp.api.client import QuappNotFoundError
        with self.assertRaises(QuappNotFoundError):
            find_device_by_name(self._make_client(), 1, "zzz-unknown")


if __name__ == "__main__":
    unittest.main()
