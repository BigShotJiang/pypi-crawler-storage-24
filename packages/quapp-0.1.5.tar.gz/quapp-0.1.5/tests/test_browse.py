import unittest
from typer.testing import CliRunner
from quapp.cli.app import app


class TestBrowseJsonGuard(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()
        from quapp import output
        output.set_json_mode(False)

    def tearDown(self):
        from quapp import output
        output.set_json_mode(False)

    def test_json_flag_exits_1(self):
        result = self.runner.invoke(app, ["--json", "browse"])
        self.assertEqual(result.exit_code, 1)

    def test_json_flag_message_on_stderr(self):
        result = self.runner.invoke(app, ["--json", "browse"], catch_exceptions=False)
        self.assertIn("incompatible", result.output.lower())


if __name__ == "__main__":
    unittest.main()
