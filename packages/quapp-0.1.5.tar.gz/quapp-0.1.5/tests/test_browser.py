import unittest
from unittest.mock import MagicMock, patch


class TestBrowserState(unittest.TestCase):

    def _make_state(self):
        from quapp.tui.browser import BrowserState
        state = BrowserState()
        # Pre-load data to avoid API calls in tests
        state.data["projects"] = [{"id": "p1", "name": "my-project"}, {"id": "p2", "name": "other"}]
        state.data["functions"] = [{"id": "f1", "name": "qec"}, {"id": "f2", "name": "bell"}]
        state.data["jobs"] = [{"id": "j1", "status": "DONE"}, {"id": "j2", "status": "RUNNING"}]
        return state

    def test_initial_pane_is_projects(self):
        from quapp.tui.browser import BrowserState
        state = BrowserState()
        self.assertEqual(state.pane, "projects")

    def test_enter_moves_to_functions(self):
        state = self._make_state()
        state.pane = "projects"
        state.handle_key("enter")
        self.assertEqual(state.pane, "functions")

    def test_enter_from_functions_moves_to_jobs(self):
        state = self._make_state()
        state.pane = "functions"
        state.handle_key("enter")
        self.assertEqual(state.pane, "jobs")

    def test_back_from_functions_returns_to_projects(self):
        state = self._make_state()
        state.pane = "functions"
        state.handle_key("back")
        self.assertEqual(state.pane, "projects")

    def test_back_from_jobs_returns_to_functions(self):
        state = self._make_state()
        state.pane = "jobs"
        state.handle_key("back")
        self.assertEqual(state.pane, "functions")

    def test_back_at_root_is_noop(self):
        state = self._make_state()
        state.pane = "projects"
        state.handle_key("back")
        self.assertEqual(state.pane, "projects")

    def test_down_increments_selected(self):
        state = self._make_state()
        state.pane = "projects"
        state.selected["projects"] = 0
        state.handle_key("down")
        self.assertEqual(state.selected["projects"], 1)

    def test_down_clamps_at_last_item(self):
        state = self._make_state()
        state.pane = "projects"
        state.selected["projects"] = 1  # last index (2 items)
        state.handle_key("down")
        self.assertEqual(state.selected["projects"], 1)

    def test_up_decrements_selected(self):
        state = self._make_state()
        state.pane = "projects"
        state.selected["projects"] = 1
        state.handle_key("up")
        self.assertEqual(state.selected["projects"], 0)

    def test_up_clamps_at_zero(self):
        state = self._make_state()
        state.pane = "projects"
        state.selected["projects"] = 0
        state.handle_key("up")
        self.assertEqual(state.selected["projects"], 0)

    def test_q_sets_quit_flag(self):
        state = self._make_state()
        state.handle_key("q")
        self.assertTrue(state.should_quit)

    def test_enter_on_job_sets_pending_watch(self):
        state = self._make_state()
        state.pane = "jobs"
        state.selected["jobs"] = 0
        state.handle_key("enter")
        self.assertIsNotNone(state.pending_action)
        self.assertEqual(state.pending_action[0], "watch")
        self.assertEqual(state.pending_action[1], "j1")

    def test_d_on_functions_sets_pending_deploy(self):
        state = self._make_state()
        state.pane = "functions"
        state.selected["functions"] = 0
        state.selected["projects"] = 0
        state.handle_key("d")
        self.assertIsNotNone(state.pending_action)
        self.assertEqual(state.pending_action[0], "deploy")
        self.assertEqual(state.pending_action[1], "qec")   # function name
        self.assertEqual(state.pending_action[2], "p1")    # project id

    def test_d_not_available_on_jobs_pane(self):
        state = self._make_state()
        state.pane = "jobs"
        state.handle_key("d")
        self.assertIsNone(state.pending_action)

    def test_handle_key_returns_none(self):
        state = self._make_state()
        result = state.handle_key("up")
        self.assertIsNone(result)

    def test_data_cache_persists_on_back_navigation(self):
        """Back then forward should NOT wipe cached data — data survives a back/forward cycle."""
        state = self._make_state()
        state.pane = "functions"
        original_functions = state.data["functions"]  # pre-loaded in _make_state
        state.handle_key("back")  # go back to projects
        self.assertEqual(state.pane, "projects")
        # functions data should still be cached — handle_key("back") must NOT clear it
        self.assertIs(state.data["functions"], original_functions)


if __name__ == "__main__":
    unittest.main()
