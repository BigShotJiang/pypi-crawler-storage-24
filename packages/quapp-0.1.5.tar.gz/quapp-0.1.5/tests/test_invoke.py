import unittest
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from quapp.cli.invoke import app
from quapp.api.client import QuappNotFoundError, QuappError


runner = CliRunner()

_PROJ = {"id": 42, "name": "my-project"}
_FUNC = {"id": 7, "name": "my-function"}
_DEVICE = {"id": 3, "name": "sim"}
_JOB_RESP = {"jobId": "job-abc"}

_PROV = {"id": 5, "name": "Quapp"}

_BASE_ARGS = [
    "--project", "my-project",
    "--function", "my-function",
    "--device", "sim",
]


def _make_config(token="tok"):
    cfg = MagicMock()
    cfg.token = token
    cfg.base_url = "https://api.example.com"
    return cfg


class TestInvokeSuccess(unittest.TestCase):
    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_resolves_names_and_calls_run_job(
        self, _cfg, mock_proj, mock_func, mock_prov, mock_devs, mock_run
    ):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertEqual(result.exit_code, 0, result.output)
        mock_run.assert_called_once()
        _, kwargs = mock_run.call_args
        self.assertEqual(kwargs["function_id"], "7")
        self.assertEqual(kwargs["device"], "3")
        self.assertEqual(kwargs["provider"], "Quapp")
        self.assertEqual(kwargs["shots"], 1024)
        self.assertIsNone(kwargs["invocation_input"])

    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_input_json_list_decoded(
        self, _cfg, _proj, _func, _prov, _devs, mock_run
    ):
        result = runner.invoke(app, _BASE_ARGS + ["--input", "data=[1,2,3]"])
        self.assertEqual(result.exit_code, 0, result.output)
        _, kwargs = mock_run.call_args
        self.assertEqual(kwargs["invocation_input"], {"data": [1, 2, 3]})

    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_input_plain_string_fallback(
        self, _cfg, _proj, _func, _prov, _devs, mock_run
    ):
        result = runner.invoke(app, _BASE_ARGS + ["--input", "name=hello world"])
        self.assertEqual(result.exit_code, 0, result.output)
        _, kwargs = mock_run.call_args
        self.assertEqual(kwargs["invocation_input"], {"name": "hello world"})

    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_input_json_object_value(
        self, _cfg, _proj, _func, _prov, _devs, mock_run
    ):
        result = runner.invoke(app, _BASE_ARGS + ['--input', 'cfg={"k": 1}'])
        self.assertEqual(result.exit_code, 0, result.output)
        _, kwargs = mock_run.call_args
        self.assertEqual(kwargs["invocation_input"], {"cfg": {"k": 1}})


class TestInvokeShotsValidation(unittest.TestCase):
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_shots_below_minimum(self, _cfg):
        result = runner.invoke(app, _BASE_ARGS + ["--shots", "5"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("10", result.output)
        self.assertIn("8000", result.output)

    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_shots_above_maximum(self, _cfg):
        result = runner.invoke(app, _BASE_ARGS + ["--shots", "9000"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("10", result.output)
        self.assertIn("8000", result.output)

    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_shots_boundary_10(self, _cfg, _proj, _func, _prov, _devs, _run):
        result = runner.invoke(app, _BASE_ARGS + ["--shots", "10"])
        self.assertEqual(result.exit_code, 0, result.output)

    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_shots_boundary_8000(self, _cfg, _proj, _func, _prov, _devs, _run):
        result = runner.invoke(app, _BASE_ARGS + ["--shots", "8000"])
        self.assertEqual(result.exit_code, 0, result.output)


class TestInvokeNotFound(unittest.TestCase):
    @patch("quapp.cli.invoke.find_project_by_name",
           side_effect=QuappNotFoundError("Project 'x' not found."))
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_project_not_found_exits_1(self, _cfg, _proj):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertEqual(result.exit_code, 1)

    @patch("quapp.cli.invoke.find_function_by_name",
           side_effect=QuappNotFoundError("Function 'x' not found."))
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_function_not_found_exits_1(self, _cfg, _proj, _func):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertEqual(result.exit_code, 1)

    @patch("quapp.cli.invoke.find_device_by_name",
           side_effect=QuappNotFoundError("Device 'sim' not found."))
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_device_not_found_exits_1(self, _cfg, _proj, _func, _prov, _devs):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertEqual(result.exit_code, 1)


class TestInvokeNotLoggedIn(unittest.TestCase):
    @patch("quapp.cli.invoke.load_config", return_value=_make_config(token=None))
    def test_no_token_exits_1(self, _cfg):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertEqual(result.exit_code, 1)


class TestInvokeWait(unittest.TestCase):
    @patch("quapp.cli.invoke.output.poll_with_spinner", return_value={"status": "COMPLETED"})
    @patch("quapp.cli.invoke.run_job", return_value=_JOB_RESP)
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_wait_flag_polls_and_prints_status(
        self, _cfg, _proj, _func, _prov, _devs, _run, mock_poll
    ):
        result = runner.invoke(app, _BASE_ARGS + ["--wait"])
        self.assertEqual(result.exit_code, 0, result.output)
        mock_poll.assert_called_once()
        self.assertIn("COMPLETED", result.output)


class TestInvokeInputErrors(unittest.TestCase):
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_malformed_input_pair_missing_equals(self, _cfg, _proj, _func, _prov, _devs):
        result = runner.invoke(app, _BASE_ARGS + ["--input", "badvalue"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("KEY=VALUE", result.output)


class TestInvokeRunJobError(unittest.TestCase):
    @patch("quapp.cli.invoke.run_job", side_effect=QuappError("server error"))
    @patch("quapp.cli.invoke.find_device_by_name", return_value=_DEVICE)
    @patch("quapp.cli.invoke.find_provider_by_name", return_value=_PROV)
    @patch("quapp.cli.invoke.find_function_by_name", return_value=_FUNC)
    @patch("quapp.cli.invoke.find_project_by_name", return_value=_PROJ)
    @patch("quapp.cli.invoke.load_config", return_value=_make_config())
    def test_run_job_exception_exits_1(self, _cfg, _proj, _func, _prov, _devs, _run):
        result = runner.invoke(app, _BASE_ARGS)
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("server error", result.output)


class TestInvokeProviderFlag(unittest.TestCase):
    @patch("quapp.cli.invoke.find_provider_by_name")
    @patch("quapp.cli.invoke.find_device_by_name")
    @patch("quapp.cli.invoke.find_function_by_name")
    @patch("quapp.cli.invoke.find_project_by_name")
    @patch("quapp.cli.invoke.run_job")
    def test_provider_flag_resolved_by_name(self, mock_run, mock_proj, mock_func, mock_dev, mock_prov):
        mock_proj.return_value = {"id": "p1", "name": "my-project"}
        mock_func.return_value = {"id": "f1", "name": "my-function"}
        mock_prov.return_value = {"id": 99, "name": "IBM"}
        mock_dev.return_value = {"id": "d1", "name": "ibm_q"}
        mock_run.return_value = {"jobId": "j1"}
        from typer.testing import CliRunner
        from quapp.cli.invoke import app
        runner = CliRunner()
        with patch("quapp.cli.invoke.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id=None)
            result = runner.invoke(app, [
                "--project", "my-project",
                "--function", "my-function",
                "--provider", "IBM",
                "--device", "ibm_q",
                "--shots", "100",
            ])
        mock_prov.assert_called_once()
        self.assertEqual(result.exit_code, 0)


class TestInvokeEdgeCases(unittest.TestCase):
    def _run_invoke(self, extra_args=None):
        from typer.testing import CliRunner
        from quapp.cli.invoke import app
        runner = CliRunner()
        base_args = ["--project", "p", "--function", "f",
                     "--provider", "Quapp", "--device", "d"]
        args = base_args + (extra_args or [])
        with patch("quapp.cli.invoke.load_config") as mock_cfg:
            mock_cfg.return_value = MagicMock(token="tok", base_url="https://x.com", project_id=None)
            return runner.invoke(app, args)

    @patch("quapp.cli.invoke.find_device_by_name")
    @patch("quapp.cli.invoke.find_provider_by_name")
    @patch("quapp.cli.invoke.find_function_by_name")
    @patch("quapp.cli.invoke.find_project_by_name")
    def test_bad_input_format_exits_1(self, mock_proj, mock_func, mock_prov, mock_dev):
        mock_proj.return_value = {"id": "p1", "name": "p"}
        mock_func.return_value = {"id": "f1", "name": "f"}
        mock_prov.return_value = {"id": 5, "name": "Quapp"}
        mock_dev.return_value = {"id": "d1", "name": "d"}
        result = self._run_invoke(["--input", "no-equals-sign"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("KEY=VALUE", result.output)

    def test_shots_out_of_range_exits_1(self):
        result = self._run_invoke(["--shots", "9"])
        self.assertEqual(result.exit_code, 1)

    @patch("quapp.cli.invoke.find_project_by_name")
    def test_project_not_found_exits_1(self, mock_proj):
        from quapp.api.client import QuappNotFoundError
        mock_proj.side_effect = QuappNotFoundError("not found")
        result = self._run_invoke()
        self.assertEqual(result.exit_code, 1)

    @patch("quapp.cli.invoke.find_provider_by_name")
    @patch("quapp.cli.invoke.find_function_by_name")
    @patch("quapp.cli.invoke.find_project_by_name")
    def test_function_not_found_exits_1(self, mock_proj, mock_func, mock_prov):
        from quapp.api.client import QuappNotFoundError
        mock_proj.return_value = {"id": "p1", "name": "p"}
        mock_func.side_effect = QuappNotFoundError("not found")
        mock_prov.return_value = {"id": 5, "name": "Quapp"}
        result = self._run_invoke()
        self.assertEqual(result.exit_code, 1)


if __name__ == "__main__":
    unittest.main()
