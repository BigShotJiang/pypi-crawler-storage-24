"""CLI entry point and argparse command tree for xray-cli."""

import argparse
import sys

from xray_cli import __version__
from xray_cli.config import load_config
from xray_cli.errors import XrayCliError, EXIT_USAGE_ERROR
from xray_cli import log


def _build_parser():
    """Build the top-level argument parser with global flags."""
    parser = argparse.ArgumentParser(
        prog="xray",
        description="Command-line interface for Xray Cloud test management.",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "--config", metavar="PATH", default=None,
        help="Path to config file (default: auto-discover .xray-cli.ini)",
    )
    parser.add_argument(
        "--json", action="store_true", default=False, dest="json_output",
        help="Output in JSON format instead of human-readable text",
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", default=False,
        help="Enable verbose/debug output",
    )
    parser.add_argument(
        "--quiet", "-q", action="store_true", default=False,
        help="Suppress all non-error output",
    )
    parser.add_argument(
        "--timeout", type=int, default=None, metavar="SECONDS",
        help="Request timeout in seconds (default: from config or 30)",
    )

    subparsers = parser.add_subparsers(dest="command", title="commands")

    # Register command families
    from xray_cli.commands import execution, test, run, results
    from xray_cli.commands import precondition, test_set, test_plan, folder
    execution.register(subparsers)
    test.register(subparsers)
    run.register(subparsers)
    results.register(subparsers)
    precondition.register(subparsers)
    test_set.register(subparsers)
    test_plan.register(subparsers)
    folder.register(subparsers)

    return parser


def _collect_cli_overrides(args):
    """Extract CLI-level overrides to pass into config loading."""
    overrides = {}
    if args.json_output:
        overrides["output"] = "json"
    if args.timeout is not None:
        overrides["timeout_seconds"] = str(args.timeout)
    return overrides


_GLOBAL_FLAGS = {
    "--json": 0,       # 0 = flag takes no argument
    "--verbose": 0,
    "-v": 0,
    "--quiet": 0,
    "-q": 0,
    "--config": 1,     # 1 = flag takes one argument
    "--timeout": 1,
}


def _hoist_global_flags(argv):
    """Move global flags that appear after a subcommand to the front.

    argparse only recognises top-level flags when they precede the
    subcommand.  This helper lets users write them anywhere, e.g.
    ``xray test get OTR-1 --json`` instead of ``xray --json test get OTR-1``.
    """
    hoisted = []
    rest = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if token in _GLOBAL_FLAGS:
            n_args = _GLOBAL_FLAGS[token]
            hoisted.append(token)
            if n_args and i + 1 < len(argv):
                i += 1
                hoisted.append(argv[i])
        else:
            rest.append(token)
        i += 1
    return hoisted + rest


def main(argv=None):
    """Main entry point for xray-cli."""
    parser = _build_parser()
    raw = argv if argv is not None else sys.argv[1:]
    args = parser.parse_args(_hoist_global_flags(raw))

    # Configure logging
    log.configure_verbosity(verbose=args.verbose, quiet=args.quiet)

    # If no command given, print help
    if not args.command:
        parser.print_help(sys.stderr)
        return EXIT_USAGE_ERROR

    # Load config
    try:
        cli_overrides = _collect_cli_overrides(args)
        config = load_config(
            explicit_path=args.config,
            cli_overrides=cli_overrides,
        )
        log.debug("Config loaded: %s", config)
    except XrayCliError as exc:
        log.error("%s: %s", exc.category, exc)
        if exc.detail:
            log.debug("Detail: %s", exc.detail)
        return exc.exit_code

    # Dispatch to subcommand handler
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help(sys.stderr)
        return EXIT_USAGE_ERROR

    try:
        return handler(args, config)
    except XrayCliError as exc:
        log.error("%s: %s", exc.category, exc)
        if exc.detail:
            log.debug("Detail: %s", exc.detail)
        return exc.exit_code


def cli():
    """Console script entry point — calls main() and exits."""
    sys.exit(main() or 0)


if __name__ == "__main__":
    cli()
