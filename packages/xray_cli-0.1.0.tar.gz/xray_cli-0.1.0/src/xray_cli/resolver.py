"""Issue-key to Xray ID resolution."""

from xray_cli import log
from xray_cli.errors import ResolutionError


# GraphQL query to resolve an issue key to its ID via JQL
_RESOLVE_ISSUE_QUERY = """\
query ResolveIssue($jql: String!, $limit: Int!) {
    getTestExecutions(jql: $jql, limit: $limit) {
        results {
            issueId
            jira(fields: ["key"])
        }
    }
}
"""

# For tests, use getTests with JQL
_RESOLVE_TEST_QUERY = """\
query ResolveTest($jql: String!, $limit: Int!) {
    getTests(jql: $jql, limit: $limit) {
        results {
            issueId
            jira(fields: ["key"])
        }
    }
}
"""


class IssueResolver:
    """Resolves Jira issue keys to Xray issueId values."""

    def __init__(self, graphql_client):
        self._gql = graphql_client
        self._cache = {}

    def resolve(self, issue_key):
        """Resolve an issue key (e.g. 'XSP-123') to its issueId.

        Returns the issueId string.
        Raises ResolutionError if the key cannot be resolved.
        """
        if issue_key in self._cache:
            return self._cache[issue_key]

        log.debug("Resolving issue key: %s", issue_key)

        # Try resolving via getTests first (most common use case)
        issue_id = self._try_resolve(
            _RESOLVE_TEST_QUERY, "getTests", issue_key
        )
        if issue_id:
            self._cache[issue_key] = issue_id
            return issue_id

        # Fallback: try via getTestExecutions
        issue_id = self._try_resolve(
            _RESOLVE_ISSUE_QUERY, "getTestExecutions", issue_key
        )
        if issue_id:
            self._cache[issue_key] = issue_id
            return issue_id

        raise ResolutionError(
            f"Cannot resolve issue key: {issue_key}",
            detail="The key was not found via test or execution lookup.",
        )

    def _try_resolve(self, query, root_field, issue_key):
        """Attempt resolution with a specific query."""
        jql = f"key = {issue_key}"
        try:
            data = self._gql.execute(query, {"jql": jql, "limit": 1})
        except Exception:
            return None

        results = data.get(root_field, {}).get("results", [])
        for item in results:
            jira = item.get("jira") or {}
            if isinstance(jira, dict) and jira.get("key") == issue_key:
                return item.get("issueId")
            # If there's exactly one result, assume it's the match
            if len(results) == 1:
                return item.get("issueId")
        return None
