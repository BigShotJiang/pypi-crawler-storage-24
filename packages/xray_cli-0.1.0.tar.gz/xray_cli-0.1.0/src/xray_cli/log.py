"""Logging and diagnostic output for xray-cli."""

import logging
import sys


_logger = logging.getLogger("xray_cli")
_handler = logging.StreamHandler(sys.stderr)
_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
_logger.addHandler(_handler)
_logger.setLevel(logging.WARNING)


def configure_verbosity(verbose=False, quiet=False):
    """Set log level based on user flags."""
    if quiet:
        _logger.setLevel(logging.ERROR)
    elif verbose:
        _logger.setLevel(logging.DEBUG)
    else:
        _logger.setLevel(logging.WARNING)


def debug(msg, *args):
    _logger.debug(msg, *args)


def info(msg, *args):
    _logger.info(msg, *args)


def warning(msg, *args):
    _logger.warning(msg, *args)


def error(msg, *args):
    _logger.error(msg, *args)
