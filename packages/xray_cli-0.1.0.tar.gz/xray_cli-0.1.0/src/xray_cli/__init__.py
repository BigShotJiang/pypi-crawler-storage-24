"""Xray Cloud CLI - command-line interface for Xray test management."""

__version__ = "0.1.0"
