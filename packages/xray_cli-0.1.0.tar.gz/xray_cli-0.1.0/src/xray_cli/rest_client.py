"""REST client for Xray Cloud import endpoints."""

import json
import urllib.request
import urllib.error
from pathlib import Path

from xray_cli.errors import ImportError_, TransportError, AuthError
from xray_cli import log


class RestClient:
    """Handles REST requests to Xray Cloud import endpoints."""

    def __init__(self, base_url, token_service, timeout=30):
        self._base_url = base_url.rstrip("/")
        self._token_service = token_service
        self._timeout = timeout

    def import_results(self, format_name, file_path, project_key=None, execution_key=None):
        """Upload a results file to the appropriate import endpoint.

        Returns the parsed JSON response from the import API.
        """
        path = Path(file_path)
        if not path.is_file():
            raise ImportError_(f"Import file not found: {path}")

        content = path.read_bytes()

        endpoint, content_type = self._resolve_endpoint(format_name)

        # Build query params
        params = []
        if project_key:
            params.append(f"projectKey={project_key}")
        if execution_key:
            params.append(f"testExecKey={execution_key}")
        if params:
            endpoint = endpoint + "?" + "&".join(params)

        return self._send(endpoint, content, content_type, retry_auth=True)

    def _resolve_endpoint(self, format_name):
        """Map a format name to an endpoint path and content type."""
        formats = {
            "xray-json": ("/xray", "application/json"),
            "junit": ("/junit", "application/xml"),
        }
        if format_name not in formats:
            raise ImportError_(
                f"Unsupported import format: {format_name!r}. "
                f"Supported: {', '.join(sorted(formats))}"
            )
        suffix, content_type = formats[format_name]
        return self._base_url + suffix, content_type

    def _send(self, url, data, content_type, retry_auth=False):
        """Send the import request."""
        token = self._token_service.get_token()

        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": content_type,
                "Authorization": f"Bearer {token}",
            },
            method="POST",
        )

        log.debug("REST import request to %s", url)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body.strip() else {}
        except urllib.error.HTTPError as exc:
            status = exc.code
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                detail = None

            if status in (401, 403) and retry_auth:
                log.debug("Auth error on REST request, refreshing token")
                self._token_service.invalidate_token()
                return self._send(url, data, content_type, retry_auth=False)

            if status in (401, 403):
                raise AuthError(
                    f"REST import unauthorized (HTTP {status})",
                    detail=detail,
                )

            raise ImportError_(
                f"Import failed with HTTP {status}",
                detail=detail,
            )
        except urllib.error.URLError as exc:
            raise TransportError(
                f"Cannot reach import endpoint: {exc.reason}",
                detail=str(exc),
            )
        except (OSError, ValueError) as exc:
            raise TransportError(
                f"Import request failed: {exc}",
                detail=str(exc),
            )
