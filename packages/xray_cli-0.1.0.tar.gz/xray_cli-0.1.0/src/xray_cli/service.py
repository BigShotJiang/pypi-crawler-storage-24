"""Xray service layer — stable internal API for CLI command handlers."""

from xray_cli import log
from xray_cli.resolver import IssueResolver


# Known "failed" status names for --failed-only filtering
_FAILED_STATUSES = {"FAIL", "FAILED", "FAILING", "ABORTED", "TODO"}

# GraphQL document for listing test executions
_GET_TEST_EXECUTIONS = """\
query GetTestExecutions($jql: String, $issueIds: [String], $limit: Int!, $start: Int) {
    getTestExecutions(jql: $jql, issueIds: $issueIds, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            issueId
            jira(fields: ["summary", "key", "status"])
        }
    }
}
"""

# GraphQL document for getting a single test
_GET_TEST = """\
query GetTest($issueId: String!) {
    getTest(issueId: $issueId) {
        issueId
        testType {
            name
            kind
        }
        gherkin
        steps {
            id
            action
            data
            result
        }
        jira(fields: ["summary", "key", "status", "priority", "labels"])
    }
}
"""

# GraphQL document for listing tests
_GET_TESTS = """\
query GetTests($jql: String, $limit: Int!, $start: Int) {
    getTests(jql: $jql, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            issueId
            testType {
                name
                kind
            }
            jira(fields: ["summary", "key", "status"])
        }
    }
}
"""

# GraphQL document for listing test runs
_GET_TEST_RUNS = """\
query GetTestRuns($testIssueIds: [String], $testExecIssueIds: [String], $limit: Int!, $start: Int) {
    getTestRuns(testIssueIds: $testIssueIds, testExecIssueIds: $testExecIssueIds, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            id
            status {
                name
                color
                description
            }
            test {
                issueId
                jira(fields: ["key", "summary"])
            }
            testExecution {
                issueId
                jira(fields: ["key"])
            }
        }
    }
}
"""

# GraphQL document for listing preconditions
_GET_PRECONDITIONS = """\
query GetPreconditions($jql: String, $limit: Int!, $start: Int) {
    getPreconditions(jql: $jql, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            issueId
            preconditionType {
                name
                kind
            }
            jira(fields: ["summary", "key", "status"])
        }
    }
}
"""

# GraphQL document for listing test sets
_GET_TEST_SETS = """\
query GetTestSets($jql: String, $limit: Int!, $start: Int) {
    getTestSets(jql: $jql, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            issueId
            jira(fields: ["summary", "key", "status"])
        }
    }
}
"""

# GraphQL document for listing test plans
_GET_TEST_PLANS = """\
query GetTestPlans($jql: String, $limit: Int!, $start: Int) {
    getTestPlans(jql: $jql, limit: $limit, start: $start) {
        total
        start
        limit
        results {
            issueId
            jira(fields: ["summary", "key", "status"])
        }
    }
}
"""

# GraphQL document for listing folders
_GET_FOLDERS = """\
query GetFolder($projectId: String, $path: String!) {
    getFolder(projectId: $projectId, path: $path) {
        name
        path
        testsCount
        folders
    }
}
"""

# GraphQL mutation for creating a test execution
_CREATE_EXECUTION = """\
mutation CreateTestExecution($projectKey: String!, $summary: String!, $testIssueIds: [String]) {
    createTestExecution(
        testIssueIds: $testIssueIds
        testExecution: {
            projectId: $projectKey
            summary: $summary
        }
    ) {
        testExecution {
            issueId
            jira(fields: ["key", "summary"])
        }
        warnings
    }
}
"""

# GraphQL mutation for updating test run status
_UPDATE_RUN_STATUS = """\
mutation UpdateTestRunStatus($id: String!, $status: String!) {
    updateTestRunStatus(id: $id, status: $status)
}
"""

# GraphQL mutation for adding evidence to a test run
_ADD_EVIDENCE = """\
mutation AddEvidence($id: String!, $evidence: [EvidenceInput]!) {
    addEvidenceToTestRun(id: $id, evidence: $evidence)
}
"""

class XrayService:
    """Encapsulates Xray API operations for the CLI."""

    def __init__(self, graphql_client, rest_client=None):
        self._gql = graphql_client
        self._rest = rest_client
        self._resolver = IssueResolver(graphql_client)

    def list_executions(self, jql=None, issue_keys=None, limit=50, start=0):
        """List test executions, optionally filtered by JQL or issue keys.

        Returns a dict with total, start, limit, and results.
        """
        variables = {"limit": min(limit, 100), "start": start}
        if jql:
            variables["jql"] = jql
        if issue_keys:
            variables["issueIds"] = issue_keys

        log.debug("Listing executions: %s", variables)
        data = self._gql.execute(_GET_TEST_EXECUTIONS, variables)

        raw = data.get("getTestExecutions", {})
        results = []
        for item in raw.get("results", []):
            record = {
                "issueId": item.get("issueId", ""),
            }
            jira = item.get("jira") or {}
            if isinstance(jira, dict):
                record["issue_key"] = jira.get("key", "")
                record["summary"] = jira.get("summary", "")
                status = jira.get("status")
                if isinstance(status, dict):
                    record["status"] = status.get("name", "")
                elif isinstance(status, str):
                    record["status"] = status
            results.append(record)

        return {
            "_type": "execution_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def get_test(self, issue_key):
        """Fetch a single test by issue key.

        Returns a dict with the test details.
        """
        issue_id = self._resolver.resolve(issue_key)
        log.debug("Getting test: %s (id=%s)", issue_key, issue_id)

        data = self._gql.execute(_GET_TEST, {"issueId": issue_id})
        raw = data.get("getTest", {})

        record = {
            "_type": "test_detail",
            "issueId": raw.get("issueId", issue_id),
        }

        # Jira fields
        jira = raw.get("jira") or {}
        if isinstance(jira, dict):
            record["issue_key"] = jira.get("key", issue_key)
            record["summary"] = jira.get("summary", "")
            status = jira.get("status")
            if isinstance(status, dict):
                record["status"] = status.get("name", "")
            elif isinstance(status, str):
                record["status"] = status
            record["priority"] = jira.get("priority", "")
            if isinstance(record["priority"], dict):
                record["priority"] = record["priority"].get("name", "")
            labels = jira.get("labels", [])
            if isinstance(labels, list):
                record["labels"] = labels
            else:
                record["labels"] = []

        # Test type
        test_type = raw.get("testType") or {}
        record["test_type"] = test_type.get("name", "")
        record["test_kind"] = test_type.get("kind", "")

        # Gherkin
        record["gherkin"] = raw.get("gherkin")

        # Steps
        steps = raw.get("steps") or []
        record["steps"] = [
            {
                "id": s.get("id", ""),
                "action": s.get("action", ""),
                "data": s.get("data", ""),
                "result": s.get("result", ""),
            }
            for s in steps
        ]

        return record

    def list_tests(self, jql=None, limit=50, start=0):
        """List tests, optionally filtered by JQL.

        Returns a dict with total, start, limit, and results.
        """
        variables = {"limit": min(limit, 100), "start": start}
        if jql:
            variables["jql"] = jql

        log.debug("Listing tests: %s", variables)
        data = self._gql.execute(_GET_TESTS, variables)

        raw = data.get("getTests", {})
        results = []
        for item in raw.get("results", []):
            record = {"issueId": item.get("issueId", "")}
            jira = item.get("jira") or {}
            if isinstance(jira, dict):
                record["issue_key"] = jira.get("key", "")
                record["summary"] = jira.get("summary", "")
                status = jira.get("status")
                if isinstance(status, dict):
                    record["status"] = status.get("name", "")
                elif isinstance(status, str):
                    record["status"] = status
            test_type = item.get("testType") or {}
            record["test_type"] = test_type.get("name", "")
            record["test_kind"] = test_type.get("kind", "")
            results.append(record)

        return {
            "_type": "test_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def list_runs(self, test_keys=None, execution_keys=None, status=None,
                  failed_only=False, limit=50, start=0):
        """List test runs with optional filters.

        Args:
            test_keys: Filter by test issue keys.
            execution_keys: Filter by execution issue keys.
            status: Filter by status name (client-side).
            failed_only: If True, only return runs with failed-like statuses.
            limit: Page size (1-100).
            start: Pagination offset.
        """
        variables = {"limit": min(limit, 100), "start": start}
        if test_keys:
            variables["testIssueIds"] = test_keys
        if execution_keys:
            variables["testExecIssueIds"] = execution_keys

        log.debug("Listing runs: %s", variables)
        data = self._gql.execute(_GET_TEST_RUNS, variables)

        raw = data.get("getTestRuns", {})
        results = []
        for item in raw.get("results", []):
            status_obj = item.get("status") or {}
            status_name = status_obj.get("name", "")

            # Client-side status filtering
            if status and status_name.upper() != status.upper():
                continue
            if failed_only and status_name.upper() not in _FAILED_STATUSES:
                continue

            record = {
                "run_id": item.get("id", ""),
                "status": status_name,
                "status_color": status_obj.get("color", ""),
                "status_description": status_obj.get("description", ""),
            }

            test_info = item.get("test") or {}
            test_jira = test_info.get("jira") or {}
            record["test_issue_id"] = test_info.get("issueId", "")
            if isinstance(test_jira, dict):
                record["test_key"] = test_jira.get("key", "")
                record["test_summary"] = test_jira.get("summary", "")

            exec_info = item.get("testExecution") or {}
            exec_jira = exec_info.get("jira") or {}
            record["execution_issue_id"] = exec_info.get("issueId", "")
            if isinstance(exec_jira, dict):
                record["execution_key"] = exec_jira.get("key", "")

            results.append(record)

        return {
            "_type": "run_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def list_preconditions(self, jql=None, limit=50, start=0):
        """List preconditions, optionally filtered by JQL."""
        variables = {"limit": min(limit, 100), "start": start}
        if jql:
            variables["jql"] = jql

        data = self._gql.execute(_GET_PRECONDITIONS, variables)
        raw = data.get("getPreconditions", {})
        results = []
        for item in raw.get("results", []):
            record = {"issueId": item.get("issueId", "")}
            jira = item.get("jira") or {}
            if isinstance(jira, dict):
                record["issue_key"] = jira.get("key", "")
                record["summary"] = jira.get("summary", "")
            pc_type = item.get("preconditionType") or {}
            record["type"] = pc_type.get("name", "")
            record["kind"] = pc_type.get("kind", "")
            results.append(record)

        return {
            "_type": "precondition_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def list_test_sets(self, jql=None, limit=50, start=0):
        """List test sets, optionally filtered by JQL."""
        variables = {"limit": min(limit, 100), "start": start}
        if jql:
            variables["jql"] = jql

        data = self._gql.execute(_GET_TEST_SETS, variables)
        raw = data.get("getTestSets", {})
        results = self._extract_jira_list(raw)

        return {
            "_type": "test_set_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def list_test_plans(self, jql=None, limit=50, start=0):
        """List test plans, optionally filtered by JQL."""
        variables = {"limit": min(limit, 100), "start": start}
        if jql:
            variables["jql"] = jql

        data = self._gql.execute(_GET_TEST_PLANS, variables)
        raw = data.get("getTestPlans", {})
        results = self._extract_jira_list(raw)

        return {
            "_type": "test_plan_list",
            "total": raw.get("total", 0),
            "start": raw.get("start", 0),
            "limit": raw.get("limit", limit),
            "results": results,
        }

    def list_folders(self, project_key, path="/", limit=50, start=0):
        """List folders under a project at a given path."""
        variables = {"projectId": project_key, "path": path}

        data = self._gql.execute(_GET_FOLDERS, variables)
        raw = data.get("getFolder", {})

        # The root folder itself
        results = []
        child_folders = raw.get("folders") or []
        for item in child_folders:
            results.append({
                "name": item.get("name", ""),
                "path": item.get("path", ""),
                "tests_count": item.get("testsCount", 0),
            })

        return {
            "_type": "folder_list",
            "total": len(results),
            "start": 0,
            "limit": limit,
            "results": results,
        }

    def _extract_jira_list(self, raw):
        """Common extraction for simple Jira-backed list results."""
        results = []
        for item in raw.get("results", []):
            record = {"issueId": item.get("issueId", "")}
            jira = item.get("jira") or {}
            if isinstance(jira, dict):
                record["issue_key"] = jira.get("key", "")
                record["summary"] = jira.get("summary", "")
                status = jira.get("status")
                if isinstance(status, dict):
                    record["status"] = status.get("name", "")
                elif isinstance(status, str):
                    record["status"] = status
            results.append(record)
        return results

    def create_execution(self, project_key, summary, test_keys=None):
        """Create a new test execution.

        Returns a dict with the created execution details.
        """
        variables = {
            "projectKey": project_key,
            "summary": summary,
        }
        if test_keys:
            variables["testIssueIds"] = test_keys

        log.debug("Creating execution: %s", variables)
        data = self._gql.execute(_CREATE_EXECUTION, variables)

        raw = data.get("createTestExecution") or {}
        result = raw.get("testExecution") or {}
        jira = result.get("jira") or {}

        return {
            "_type": "mutation_result",
            "action": "create_execution",
            "success": True,
            "issueId": result.get("issueId", ""),
            "issue_key": jira.get("key", "") if isinstance(jira, dict) else "",
            "summary": jira.get("summary", "") if isinstance(jira, dict) else "",
        }

    def update_run_status(self, run_id, status):
        """Update the status of a test run.

        Returns a dict with the mutation result.
        """
        log.debug("Updating run %s to status %s", run_id, status)
        data = self._gql.execute(_UPDATE_RUN_STATUS, {"id": run_id, "status": status})

        result_msg = data.get("updateTestRunStatus", "")

        return {
            "_type": "mutation_result",
            "action": "update_run_status",
            "success": True,
            "run_id": run_id,
            "status": status,
            "message": result_msg if isinstance(result_msg, str) else str(result_msg),
        }

    def add_run_evidence(self, run_id, file_path):
        """Attach evidence (a file) to a test run.

        Reads the file and sends it as base64-encoded data.
        """
        import base64
        from pathlib import Path
        from xray_cli.errors import ValidationError

        path = Path(file_path)
        if not path.is_file():
            raise ValidationError(f"Evidence file not found: {path}")

        data = path.read_bytes()
        encoded = base64.b64encode(data).decode("ascii")
        filename = path.name

        log.debug("Adding evidence to run %s: %s", run_id, filename)
        result = self._gql.execute(_ADD_EVIDENCE, {
            "id": run_id,
            "evidence": [{"filename": filename, "data": encoded}],
        })

        return {
            "_type": "mutation_result",
            "action": "add_evidence",
            "success": True,
            "run_id": run_id,
            "filename": filename,
        }

    def import_xray_json(self, file_path, project_key=None, execution_key=None):
        """Import test results in Xray JSON format via REST.

        Returns a dict with the import result.
        """
        if not self._rest:
            from xray_cli.errors import ConfigError
            raise ConfigError("REST client not configured; import requires REST transport")

        log.debug("Importing Xray JSON from %s", file_path)
        raw = self._rest.import_results(
            "xray-json", file_path,
            project_key=project_key,
            execution_key=execution_key,
        )
        return self._parse_import_result("xray-json", raw)

    def import_junit_xml(self, file_path, project_key=None, execution_key=None):
        """Import test results in JUnit XML format via REST.

        Returns a dict with the import result.
        """
        if not self._rest:
            from xray_cli.errors import ConfigError
            raise ConfigError("REST client not configured; import requires REST transport")

        log.debug("Importing JUnit XML from %s", file_path)
        raw = self._rest.import_results(
            "junit", file_path,
            project_key=project_key,
            execution_key=execution_key,
        )
        return self._parse_import_result("junit", raw)

    def _parse_import_result(self, format_name, raw):
        """Parse a REST import response into a stable result shape."""
        test_exec_issue = raw.get("testExecIssue") or {}
        return {
            "_type": "import_result",
            "success": True,
            "format": format_name,
            "test_execution_key": test_exec_issue.get("key", ""),
            "test_execution_id": test_exec_issue.get("id", ""),
            "raw_response": raw,
        }
