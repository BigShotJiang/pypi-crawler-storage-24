"""Command handlers for execution operations."""

from xray_cli import formatter
from xray_cli.errors import ValidationError


def register(subparsers):
    """Register execution subcommands."""
    exec_parser = subparsers.add_parser("execution", help="Test execution operations")
    exec_sub = exec_parser.add_subparsers(dest="execution_command", title="execution commands")

    # execution list
    list_parser = exec_sub.add_parser("list", help="List test executions")
    list_parser.add_argument(
        "--jql", default=None,
        help="JQL filter for executions",
    )
    list_parser.add_argument(
        "--limit", type=int, default=None,
        help="Maximum results per page (1-100, default: from config)",
    )
    list_parser.add_argument(
        "--start", type=int, default=0,
        help="Start offset for pagination (default: 0)",
    )
    list_parser.set_defaults(handler=handle_execution_list)

    # execution create
    create_parser = exec_sub.add_parser("create", help="Create a test execution")
    create_parser.add_argument(
        "--project", required=True, dest="project_key",
        help="Jira project key (e.g. XSP)",
    )
    create_parser.add_argument(
        "--summary", required=True,
        help="Summary for the new test execution",
    )
    create_parser.add_argument(
        "--test", dest="test_keys", action="append", default=None,
        help="Test issue key to include (repeatable)",
    )
    create_parser.set_defaults(handler=handle_execution_create)

    # Set a fallback handler for bare "execution" with no subcommand
    exec_parser.set_defaults(handler=lambda args, config: _show_help(exec_parser))


def _show_help(parser):
    parser.print_help()
    return 2


def _build_service(config):
    from xray_cli.auth import TokenService
    from xray_cli.graphql_client import GraphQLClient
    from xray_cli.service import XrayService

    token_service = TokenService(
        config.auth_url, config.client_id, config.client_secret,
        timeout=config.timeout_seconds,
    )
    gql_client = GraphQLClient(
        config.graphql_url, token_service,
        timeout=config.timeout_seconds,
    )
    return XrayService(gql_client)


def handle_execution_list(args, config):
    """Handle 'execution list' command."""
    limit = args.limit if args.limit is not None else config.page_limit
    if limit < 1 or limit > 100:
        raise ValidationError("--limit must be between 1 and 100")

    service = _build_service(config)
    result = service.list_executions(
        jql=args.jql,
        limit=limit,
        start=args.start,
    )

    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0


def handle_execution_create(args, config):
    """Handle 'execution create' command."""
    service = _build_service(config)
    result = service.create_execution(
        project_key=args.project_key,
        summary=args.summary,
        test_keys=args.test_keys,
    )
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0
