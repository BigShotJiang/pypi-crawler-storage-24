"""Command handlers for test operations."""

from xray_cli import formatter
from xray_cli.errors import ValidationError


def register(subparsers):
    """Register test subcommands."""
    test_parser = subparsers.add_parser("test", help="Test operations")
    test_sub = test_parser.add_subparsers(dest="test_command", title="test commands")

    # test get
    get_parser = test_sub.add_parser("get", help="Get a single test by issue key")
    get_parser.add_argument("issue_key", help="Jira issue key (e.g. XSP-123)")
    get_parser.set_defaults(handler=handle_test_get)

    # test list
    list_parser = test_sub.add_parser("list", help="List tests")
    list_parser.add_argument(
        "--jql", default=None,
        help="JQL filter for tests",
    )
    list_parser.add_argument(
        "--limit", type=int, default=None,
        help="Maximum results per page (1-100, default: from config)",
    )
    list_parser.add_argument(
        "--start", type=int, default=0,
        help="Start offset for pagination (default: 0)",
    )
    list_parser.set_defaults(handler=handle_test_list)

    test_parser.set_defaults(handler=lambda args, config: _show_help(test_parser))


def _show_help(parser):
    parser.print_help()
    return 2


def _build_service(config):
    from xray_cli.auth import TokenService
    from xray_cli.graphql_client import GraphQLClient
    from xray_cli.service import XrayService

    token_service = TokenService(
        config.auth_url, config.client_id, config.client_secret,
        timeout=config.timeout_seconds,
    )
    gql_client = GraphQLClient(
        config.graphql_url, token_service,
        timeout=config.timeout_seconds,
    )
    return XrayService(gql_client)


def handle_test_get(args, config):
    """Handle 'test get <issue-key>' command."""
    service = _build_service(config)
    result = service.get_test(args.issue_key)
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0


def handle_test_list(args, config):
    """Handle 'test list' command."""
    limit = args.limit if args.limit is not None else config.page_limit
    if limit < 1 or limit > 100:
        raise ValidationError("--limit must be between 1 and 100")

    service = _build_service(config)
    result = service.list_tests(
        jql=args.jql,
        limit=limit,
        start=args.start,
    )
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0
