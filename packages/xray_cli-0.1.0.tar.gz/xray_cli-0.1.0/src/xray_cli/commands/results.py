"""Command handlers for results import operations."""

from xray_cli import formatter


def register(subparsers):
    """Register results subcommands."""
    results_parser = subparsers.add_parser("results", help="Test results operations")
    results_sub = results_parser.add_subparsers(dest="results_command", title="results commands")

    # results import
    import_parser = results_sub.add_parser("import", help="Import test results")
    import_sub = import_parser.add_subparsers(dest="import_format", title="import formats")

    # results import xray-json
    xray_json_parser = import_sub.add_parser("xray-json", help="Import Xray JSON results")
    xray_json_parser.add_argument("file", help="Path to Xray JSON results file")
    xray_json_parser.add_argument("--project", dest="project_key", default=None, help="Project key")
    xray_json_parser.add_argument("--execution", dest="execution_key", default=None, help="Existing execution key")
    xray_json_parser.set_defaults(handler=handle_import_xray_json)

    # results import junit
    junit_parser = import_sub.add_parser("junit", help="Import JUnit XML results")
    junit_parser.add_argument("file", help="Path to JUnit XML results file")
    junit_parser.add_argument("--project", dest="project_key", default=None, help="Project key")
    junit_parser.add_argument("--execution", dest="execution_key", default=None, help="Existing execution key")
    junit_parser.set_defaults(handler=handle_import_junit)

    import_parser.set_defaults(handler=lambda args, config: _show_help(import_parser))
    results_parser.set_defaults(handler=lambda args, config: _show_help(results_parser))


def _show_help(parser):
    parser.print_help()
    return 2


def _build_service(config):
    from xray_cli.auth import TokenService
    from xray_cli.graphql_client import GraphQLClient
    from xray_cli.rest_client import RestClient
    from xray_cli.service import XrayService

    token_service = TokenService(
        config.auth_url, config.client_id, config.client_secret,
        timeout=config.timeout_seconds,
    )
    gql_client = GraphQLClient(
        config.graphql_url, token_service,
        timeout=config.timeout_seconds,
    )
    rest_client = RestClient(
        config.import_base_url, token_service,
        timeout=config.timeout_seconds,
    )
    return XrayService(gql_client, rest_client=rest_client)


def handle_import_xray_json(args, config):
    """Handle 'results import xray-json <file>' command."""
    service = _build_service(config)
    result = service.import_xray_json(
        args.file,
        project_key=args.project_key or config.project_key,
        execution_key=args.execution_key,
    )
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0


def handle_import_junit(args, config):
    """Handle 'results import junit <file>' command."""
    service = _build_service(config)
    result = service.import_junit_xml(
        args.file,
        project_key=args.project_key or config.project_key,
        execution_key=args.execution_key,
    )
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0
