"""Command handlers for run operations."""

from xray_cli import formatter
from xray_cli.errors import ValidationError


def register(subparsers):
    """Register run subcommands."""
    run_parser = subparsers.add_parser("run", help="Test run operations")
    run_sub = run_parser.add_subparsers(dest="run_command", title="run commands")

    # run list
    list_parser = run_sub.add_parser("list", help="List test runs")
    list_parser.add_argument(
        "--test", dest="test_keys", action="append", default=None,
        help="Filter by test issue key (repeatable)",
    )
    list_parser.add_argument(
        "--execution", dest="execution_keys", action="append", default=None,
        help="Filter by execution issue key (repeatable)",
    )
    list_parser.add_argument(
        "--status", default=None,
        help="Filter by run status name",
    )
    list_parser.add_argument(
        "--failed-only", action="store_true", default=False,
        help="Show only failed/aborted runs",
    )
    list_parser.add_argument(
        "--limit", type=int, default=None,
        help="Maximum results per page (1-100, default: from config)",
    )
    list_parser.add_argument(
        "--start", type=int, default=0,
        help="Start offset for pagination (default: 0)",
    )
    list_parser.set_defaults(handler=handle_run_list)

    # run update-status
    update_parser = run_sub.add_parser("update-status", help="Update a test run status")
    update_parser.add_argument("run_id", help="Test run ID")
    update_parser.add_argument("status", help="New status (e.g. PASS, FAIL, TODO)")
    update_parser.set_defaults(handler=handle_run_update_status)

    # run add-evidence
    evidence_parser = run_sub.add_parser("add-evidence", help="Add evidence to a test run")
    evidence_parser.add_argument("run_id", help="Test run ID")
    evidence_parser.add_argument("file", help="Path to evidence file")
    evidence_parser.set_defaults(handler=handle_run_add_evidence)

    run_parser.set_defaults(handler=lambda args, config: _show_help(run_parser))


def _show_help(parser):
    parser.print_help()
    return 2


def _build_service(config):
    from xray_cli.auth import TokenService
    from xray_cli.graphql_client import GraphQLClient
    from xray_cli.service import XrayService

    token_service = TokenService(
        config.auth_url, config.client_id, config.client_secret,
        timeout=config.timeout_seconds,
    )
    gql_client = GraphQLClient(
        config.graphql_url, token_service,
        timeout=config.timeout_seconds,
    )
    return XrayService(gql_client)


def handle_run_list(args, config):
    """Handle 'run list' command."""
    limit = args.limit if args.limit is not None else config.page_limit
    if limit < 1 or limit > 100:
        raise ValidationError("--limit must be between 1 and 100")

    service = _build_service(config)
    result = service.list_runs(
        test_keys=args.test_keys,
        execution_keys=args.execution_keys,
        status=args.status,
        failed_only=args.failed_only,
        limit=limit,
        start=args.start,
    )
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0


def handle_run_update_status(args, config):
    """Handle 'run update-status <run-id> <status>' command."""
    service = _build_service(config)
    result = service.update_run_status(args.run_id, args.status)
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0


def handle_run_add_evidence(args, config):
    """Handle 'run add-evidence <run-id> <file>' command."""
    service = _build_service(config)
    result = service.add_run_evidence(args.run_id, args.file)
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0
