"""Shared helpers for command handlers."""


def build_service(config):
    """Build a fully wired XrayService from config."""
    from xray_cli.auth import TokenService
    from xray_cli.graphql_client import GraphQLClient
    from xray_cli.rest_client import RestClient
    from xray_cli.service import XrayService

    token_service = TokenService(
        config.auth_url, config.client_id, config.client_secret,
        timeout=config.timeout_seconds,
    )
    gql_client = GraphQLClient(
        config.graphql_url, token_service,
        timeout=config.timeout_seconds,
    )
    rest_client = RestClient(
        config.import_base_url, token_service,
        timeout=config.timeout_seconds,
    )
    return XrayService(gql_client, rest_client=rest_client)
