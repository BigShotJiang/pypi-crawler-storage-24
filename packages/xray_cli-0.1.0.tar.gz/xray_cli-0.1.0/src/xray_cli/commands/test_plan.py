"""Command handlers for test-plan operations."""

from xray_cli import formatter
from xray_cli.errors import ValidationError


def register(subparsers):
    """Register test-plan subcommands."""
    parser = subparsers.add_parser("test-plan", help="Test plan operations")
    sub = parser.add_subparsers(dest="test_plan_command", title="test-plan commands")

    list_parser = sub.add_parser("list", help="List test plans")
    list_parser.add_argument("--jql", default=None, help="JQL filter")
    list_parser.add_argument("--limit", type=int, default=None, help="Page size (1-100)")
    list_parser.add_argument("--start", type=int, default=0, help="Pagination offset")
    list_parser.set_defaults(handler=handle_list)

    parser.set_defaults(handler=lambda args, config: (parser.print_help(), 2)[1])


def handle_list(args, config):
    from xray_cli.commands._shared import build_service
    limit = args.limit if args.limit is not None else config.page_limit
    if limit < 1 or limit > 100:
        raise ValidationError("--limit must be between 1 and 100")
    service = build_service(config)
    result = service.list_test_plans(jql=args.jql, limit=limit, start=args.start)
    output_mode = "json" if args.json_output else config.output
    formatter.render(result, mode=output_mode)
    return 0
