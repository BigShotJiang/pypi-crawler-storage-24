"""GraphQL client for Xray Cloud API."""

import json
import urllib.request
import urllib.error

from xray_cli.errors import GraphQLError, TransportError, AuthError
from xray_cli import log


class GraphQLClient:
    """Sends GraphQL requests to the Xray Cloud endpoint."""

    def __init__(self, graphql_url, token_service, timeout=30):
        self._url = graphql_url
        self._token_service = token_service
        self._timeout = timeout

    def execute(self, document, variables=None):
        """Execute a GraphQL operation and return the data dict.

        Raises GraphQLError if the response contains errors.
        Raises TransportError for network failures.
        Raises AuthError for 401/403 responses (retries once after token refresh).
        """
        if not document or not document.strip():
            raise GraphQLError("GraphQL document must not be empty")

        payload = {"query": document}
        if variables:
            payload["variables"] = variables

        return self._send(payload, retry_auth=True)

    def _send(self, payload, retry_auth=False):
        """Send the GraphQL request, optionally retrying on auth failure."""
        token = self._token_service.get_token()
        body = json.dumps(payload).encode("utf-8")

        req = urllib.request.Request(
            self._url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
            },
            method="POST",
        )

        log.debug("GraphQL request to %s", self._url)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                response_body = resp.read().decode("utf-8")
                result = json.loads(response_body)
        except urllib.error.HTTPError as exc:
            status = exc.code
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                detail = None

            if status in (401, 403) and retry_auth:
                log.debug("Auth error on GraphQL request, refreshing token")
                self._token_service.invalidate_token()
                return self._send(payload, retry_auth=False)

            if status in (401, 403):
                raise AuthError(
                    f"GraphQL request unauthorized (HTTP {status})",
                    detail=detail,
                )
            raise TransportError(
                f"GraphQL request failed with HTTP {status}",
                detail=detail,
            )
        except urllib.error.URLError as exc:
            raise TransportError(
                f"Cannot reach GraphQL endpoint: {exc.reason}",
                detail=str(exc),
            )
        except (OSError, ValueError) as exc:
            raise TransportError(
                f"GraphQL request failed: {exc}",
                detail=str(exc),
            )

        # Check for GraphQL-level errors
        if "errors" in result:
            errors = result["errors"]
            messages = [e.get("message", "Unknown error") for e in errors]
            raise GraphQLError(
                "; ".join(messages),
                errors=errors,
            )

        return result.get("data", {})
