"""Output formatter for rendering domain results as text or JSON."""

import json
import sys


def render(data, mode="text", stream=None):
    """Render data in the specified output mode.

    Args:
        data: A dict, list, or domain object to render.
        mode: 'text' for human-readable output, 'json' for machine-readable.
        stream: Output stream (defaults to sys.stdout).
    """
    if stream is None:
        stream = sys.stdout

    if mode == "json":
        _render_json(data, stream)
    else:
        _render_text(data, stream)


def _render_json(data, stream):
    """Emit structured JSON output."""
    json.dump(data, stream, indent=2, default=str)
    stream.write("\n")


def _render_text(data, stream):
    """Emit human-readable text output."""
    if isinstance(data, dict):
        renderer = _TEXT_RENDERERS.get(data.get("_type"))
        if renderer:
            renderer(data, stream)
            return
    # Fallback: simple key-value dump
    _render_dict_flat(data, stream)


def _render_dict_flat(data, stream):
    """Generic flat rendering for dicts."""
    if isinstance(data, dict):
        for key, value in data.items():
            if key.startswith("_"):
                continue
            stream.write(f"{key}: {value}\n")
    elif isinstance(data, list):
        for item in data:
            _render_dict_flat(item, stream)
            stream.write("\n")
    else:
        stream.write(str(data) + "\n")


def render_execution_list(data, stream):
    """Render a paged list of executions."""
    total = data.get("total", 0)
    start = data.get("start", 0)
    limit = data.get("limit", 0)
    results = data.get("results", [])

    stream.write(f"Test Executions ({len(results)} of {total})\n")
    if total > 0:
        stream.write(f"Page: start={start}, limit={limit}\n")
    stream.write("-" * 60 + "\n")

    if not results:
        stream.write("No executions found.\n")
        return

    for ex in results:
        key = ex.get("issue_key", ex.get("issueId", "?"))
        summary = ex.get("summary", "")
        stream.write(f"  {key}")
        if summary:
            stream.write(f"  {summary}")
        stream.write("\n")


def render_message(message, stream=None):
    """Render a simple message."""
    if stream is None:
        stream = sys.stdout
    stream.write(message + "\n")


def render_test_detail(data, stream):
    """Render a single test's detail view."""
    key = data.get("issue_key", data.get("issueId", "?"))
    stream.write(f"Test: {key}\n")
    if data.get("summary"):
        stream.write(f"Summary: {data['summary']}\n")
    if data.get("status"):
        stream.write(f"Status: {data['status']}\n")
    if data.get("test_type"):
        stream.write(f"Type: {data['test_type']}")
        if data.get("test_kind"):
            stream.write(f" ({data['test_kind']})")
        stream.write("\n")
    if data.get("priority"):
        stream.write(f"Priority: {data['priority']}\n")
    if data.get("labels"):
        stream.write(f"Labels: {', '.join(data['labels'])}\n")

    # Gherkin
    if data.get("gherkin"):
        stream.write("\nGherkin:\n")
        for line in data["gherkin"].splitlines():
            stream.write(f"  {line}\n")

    # Steps
    steps = data.get("steps", [])
    if steps:
        stream.write(f"\nSteps ({len(steps)}):\n")
        for i, step in enumerate(steps, 1):
            stream.write(f"  {i}. {step.get('action', '')}\n")
            if step.get("data"):
                stream.write(f"     Data: {step['data']}\n")
            if step.get("result"):
                stream.write(f"     Expected: {step['result']}\n")


def render_test_list(data, stream):
    """Render a paged list of tests."""
    total = data.get("total", 0)
    start = data.get("start", 0)
    limit = data.get("limit", 0)
    results = data.get("results", [])

    stream.write(f"Tests ({len(results)} of {total})\n")
    if total > 0:
        stream.write(f"Page: start={start}, limit={limit}\n")
    stream.write("-" * 60 + "\n")

    if not results:
        stream.write("No tests found.\n")
        return

    for t in results:
        key = t.get("issue_key", t.get("issueId", "?"))
        summary = t.get("summary", "")
        test_type = t.get("test_type", "")
        stream.write(f"  {key}")
        if test_type:
            stream.write(f"  [{test_type}]")
        if summary:
            stream.write(f"  {summary}")
        stream.write("\n")


def render_run_list(data, stream):
    """Render a paged list of test runs."""
    total = data.get("total", 0)
    start = data.get("start", 0)
    limit = data.get("limit", 0)
    results = data.get("results", [])

    stream.write(f"Test Runs ({len(results)} of {total})\n")
    if total > 0:
        stream.write(f"Page: start={start}, limit={limit}\n")
    stream.write("-" * 60 + "\n")

    if not results:
        stream.write("No runs found.\n")
        return

    for run in results:
        run_id = run.get("run_id", "?")
        status = run.get("status", "")
        test_key = run.get("test_key", "")
        exec_key = run.get("execution_key", "")
        stream.write(f"  [{status}] {run_id}")
        if test_key:
            stream.write(f"  test={test_key}")
        if exec_key:
            stream.write(f"  exec={exec_key}")
        stream.write("\n")


def render_mutation_result(data, stream):
    """Render the result of a mutation."""
    action = data.get("action", "unknown")
    success = data.get("success", False)

    if action == "create_execution":
        key = data.get("issue_key", "")
        summary = data.get("summary", "")
        stream.write(f"Created execution: {key}\n")
        if summary:
            stream.write(f"Summary: {summary}\n")
    elif action == "update_run_status":
        run_id = data.get("run_id", "")
        status = data.get("status", "")
        stream.write(f"Updated run {run_id} to status: {status}\n")
    elif action == "add_evidence":
        run_id = data.get("run_id", "")
        filename = data.get("filename", "")
        stream.write(f"Added evidence to run {run_id}: {filename}\n")
    else:
        stream.write(f"Mutation {action}: {'success' if success else 'failed'}\n")


def render_import_result(data, stream):
    """Render the result of a results import."""
    fmt = data.get("format", "unknown")
    key = data.get("test_execution_key", "")
    stream.write(f"Import successful ({fmt})\n")
    if key:
        stream.write(f"Test Execution: {key}\n")


def render_simple_list(label, data, stream):
    """Render a generic paged list of Jira-backed items."""
    total = data.get("total", 0)
    start = data.get("start", 0)
    limit = data.get("limit", 0)
    results = data.get("results", [])

    stream.write(f"{label} ({len(results)} of {total})\n")
    if total > 0:
        stream.write(f"Page: start={start}, limit={limit}\n")
    stream.write("-" * 60 + "\n")

    if not results:
        stream.write(f"No {label.lower()} found.\n")
        return

    for item in results:
        key = item.get("issue_key", item.get("name", item.get("issueId", "?")))
        summary = item.get("summary", "")
        extra = item.get("type", "") or item.get("path", "")
        stream.write(f"  {key}")
        if extra:
            stream.write(f"  [{extra}]")
        if summary:
            stream.write(f"  {summary}")
        stream.write("\n")


def render_folder_list(data, stream):
    """Render a list of folders."""
    total = data.get("total", 0)
    results = data.get("results", [])

    stream.write(f"Folders ({len(results)} of {total})\n")
    stream.write("-" * 60 + "\n")

    if not results:
        stream.write("No folders found.\n")
        return

    for folder in results:
        name = folder.get("name", "?")
        path = folder.get("path", "")
        count = folder.get("tests_count", 0)
        stream.write(f"  {path}/{name}" if path else f"  {name}")
        stream.write(f"  ({count} tests)\n")


# Registry of type-specific text renderers
_TEXT_RENDERERS = {
    "execution_list": render_execution_list,
    "test_detail": render_test_detail,
    "test_list": render_test_list,
    "run_list": render_run_list,
    "mutation_result": render_mutation_result,
    "import_result": render_import_result,
    "precondition_list": lambda d, s: render_simple_list("Preconditions", d, s),
    "test_set_list": lambda d, s: render_simple_list("Test Sets", d, s),
    "test_plan_list": lambda d, s: render_simple_list("Test Plans", d, s),
    "folder_list": render_folder_list,
}
