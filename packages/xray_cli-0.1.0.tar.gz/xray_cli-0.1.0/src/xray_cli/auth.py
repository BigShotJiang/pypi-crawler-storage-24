"""Token service for Xray Cloud API authentication."""

import json
import urllib.request
import urllib.error

from xray_cli.errors import AuthError, TransportError
from xray_cli import log


class TokenService:
    """Acquires and caches Xray API tokens using Client ID and Secret."""

    def __init__(self, auth_url, client_id, client_secret, timeout=30):
        self._auth_url = auth_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._timeout = timeout
        self._token = None

    def get_token(self):
        """Return a cached token, or acquire a new one."""
        if self._token is not None:
            return self._token
        self._token = self._authenticate()
        return self._token

    def invalidate_token(self):
        """Clear the cached token so the next call re-authenticates."""
        self._token = None

    def _authenticate(self):
        """Exchange Client ID/Secret for an auth token."""
        payload = json.dumps({
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }).encode("utf-8")

        req = urllib.request.Request(
            self._auth_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        log.debug("Authenticating against %s", self._auth_url)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode("utf-8")
                # The Xray auth endpoint returns the token as a bare JSON string
                token = json.loads(body)
                if isinstance(token, str):
                    log.debug("Token acquired successfully")
                    return token
                # Some responses may wrap it differently
                if isinstance(token, dict) and "token" in token:
                    log.debug("Token acquired successfully")
                    return token["token"]
                raise AuthError(
                    "Unexpected auth response format",
                    detail=f"Response body: {body[:200]}",
                )
        except urllib.error.HTTPError as exc:
            status = exc.code
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                detail = None
            if status in (401, 403):
                raise AuthError(
                    "Authentication failed: invalid Client ID or Client Secret",
                    detail=detail,
                )
            raise AuthError(
                f"Authentication failed with HTTP {status}",
                detail=detail,
            )
        except urllib.error.URLError as exc:
            raise TransportError(
                f"Cannot reach auth endpoint: {exc.reason}",
                detail=str(exc),
            )
        except (OSError, ValueError) as exc:
            raise TransportError(
                f"Auth request failed: {exc}",
                detail=str(exc),
            )
