"""Shared exception hierarchy and exit-code mapping for xray-cli."""


# Exit code constants
EXIT_SUCCESS = 0
EXIT_USAGE_ERROR = 2
EXIT_CONFIG_ERROR = 3
EXIT_AUTH_ERROR = 4
EXIT_TRANSPORT_ERROR = 5
EXIT_API_ERROR = 6
EXIT_IMPORT_ERROR = 7


class XrayCliError(Exception):
    """Base exception for all xray-cli errors."""

    exit_code = 1
    category = "error"

    def __init__(self, message, detail=None):
        super().__init__(message)
        self.detail = detail


class ConfigError(XrayCliError):
    """Raised for configuration loading, validation, or precedence failures."""

    exit_code = EXIT_CONFIG_ERROR
    category = "config"


class AuthError(XrayCliError):
    """Raised for authentication failures such as bad credentials or token issues."""

    exit_code = EXIT_AUTH_ERROR
    category = "auth"


class TransportError(XrayCliError):
    """Raised for network-level failures such as timeouts, DNS, or TLS errors."""

    exit_code = EXIT_TRANSPORT_ERROR
    category = "transport"


class GraphQLError(XrayCliError):
    """Raised for GraphQL-level validation or execution errors from the Xray API."""

    exit_code = EXIT_API_ERROR
    category = "graphql"

    def __init__(self, message, errors=None, detail=None):
        super().__init__(message, detail=detail)
        self.errors = errors or []


class ImportError_(XrayCliError):
    """Raised for REST import failures (file validation, server rejection, etc.).

    Named with trailing underscore to avoid shadowing the builtin ImportError.
    """

    exit_code = EXIT_IMPORT_ERROR
    category = "import"


class ResolutionError(XrayCliError):
    """Raised when an issue key cannot be resolved to an internal ID."""

    exit_code = EXIT_API_ERROR
    category = "resolution"


class ValidationError(XrayCliError):
    """Raised for user-input validation failures before any network call."""

    exit_code = EXIT_USAGE_ERROR
    category = "validation"
