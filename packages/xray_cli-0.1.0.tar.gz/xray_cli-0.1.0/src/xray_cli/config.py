"""Configuration loading, merging, and validation for xray-cli."""

import configparser
import os
from pathlib import Path

from xray_cli.errors import ConfigError


# Default values
_DEFAULTS = {
    "auth_url": "https://xray.cloud.getxray.app/api/v2/authenticate",
    "graphql_url": "https://xray.cloud.getxray.app/api/v2/graphql",
    "import_base_url": "https://xray.cloud.getxray.app/api/v2/import/execution",
    "output": "text",
    "timeout_seconds": "30",
    "page_limit": "50",
}

# Config file search paths (checked in order)
_CONFIG_FILENAMES = [".xray-cli.ini", "xray-cli.ini"]

# Env var prefix mapping: env var name -> config key
_ENV_MAP = {
    "XRAY_CLIENT_ID": "client_id",
    "XRAY_CLIENT_SECRET": "client_secret",
    "XRAY_AUTH_URL": "auth_url",
    "XRAY_GRAPHQL_URL": "graphql_url",
    "XRAY_IMPORT_BASE_URL": "import_base_url",
    "XRAY_PROJECT_KEY": "project_key",
    "XRAY_OUTPUT": "output",
    "XRAY_TIMEOUT": "timeout_seconds",
    "XRAY_PAGE_LIMIT": "page_limit",
}


class AppConfig:
    """Holds validated configuration for an xray-cli session."""

    def __init__(
        self,
        client_id,
        client_secret,
        auth_url=None,
        graphql_url=None,
        import_base_url=None,
        project_key=None,
        output="text",
        timeout_seconds=30,
        page_limit=50,
        config_path=None,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.auth_url = auth_url or _DEFAULTS["auth_url"]
        self.graphql_url = graphql_url or _DEFAULTS["graphql_url"]
        self.import_base_url = import_base_url or _DEFAULTS["import_base_url"]
        self.project_key = project_key
        self.output = output
        self.timeout_seconds = timeout_seconds
        self.page_limit = page_limit
        self.config_path = config_path

    def __repr__(self):
        return (
            f"AppConfig(project_key={self.project_key!r}, "
            f"output={self.output!r}, timeout={self.timeout_seconds}s)"
        )


def _find_config_file():
    """Search for a config file in CWD, then home directory."""
    search_dirs = [Path.cwd(), Path.home()]
    for d in search_dirs:
        for name in _CONFIG_FILENAMES:
            candidate = d / name
            if candidate.is_file():
                return candidate
    return None


def _load_ini(path):
    """Load an INI config file and return a flat dict of values from [xray] and [defaults]."""
    parser = configparser.ConfigParser()
    try:
        parser.read(str(path), encoding="utf-8")
    except configparser.Error as exc:
        raise ConfigError(
            f"Malformed config file: {path}",
            detail=str(exc),
        )

    values = {}
    for section in ("xray", "defaults"):
        if parser.has_section(section):
            values.update(dict(parser.items(section)))
    return values


def _load_env():
    """Load config values from environment variables."""
    values = {}
    for env_var, key in _ENV_MAP.items():
        val = os.environ.get(env_var)
        if val is not None:
            values[key] = val
    return values


def _parse_int(value, name):
    """Parse a string to int, raising ConfigError on failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ConfigError(f"Invalid integer for {name}: {value!r}")


def load_config(explicit_path=None, cli_overrides=None):
    """Load and merge config from defaults, file, env vars, and CLI overrides.

    Precedence (highest wins): CLI flags > env vars > config file > defaults.
    """
    # Start with defaults
    merged = dict(_DEFAULTS)

    # Layer 1: config file
    config_path = None
    if explicit_path is not None:
        config_path = Path(explicit_path)
        if not config_path.is_file():
            raise ConfigError(f"Config file not found: {config_path}")
        merged.update(_load_ini(config_path))
    else:
        found = _find_config_file()
        if found is not None:
            config_path = found
            merged.update(_load_ini(found))

    # Layer 2: env vars
    merged.update(_load_env())

    # Layer 3: CLI overrides
    if cli_overrides:
        merged.update({k: v for k, v in cli_overrides.items() if v is not None})

    # Validate required fields
    client_id = merged.get("client_id")
    client_secret = merged.get("client_secret")
    missing = []
    if not client_id:
        missing.append("client_id (set XRAY_CLIENT_ID or add to config file)")
    if not client_secret:
        missing.append("client_secret (set XRAY_CLIENT_SECRET or add to config file)")
    if missing:
        raise ConfigError(
            "Missing required configuration:\n  - " + "\n  - ".join(missing)
        )

    # Validate output mode
    output = merged.get("output", "text")
    if output not in ("text", "json"):
        raise ConfigError(
            f"Unsupported output mode: {output!r}. Must be 'text' or 'json'."
        )

    return AppConfig(
        client_id=client_id,
        client_secret=client_secret,
        auth_url=merged.get("auth_url"),
        graphql_url=merged.get("graphql_url"),
        import_base_url=merged.get("import_base_url"),
        project_key=merged.get("project_key"),
        output=output,
        timeout_seconds=_parse_int(merged.get("timeout_seconds", 30), "timeout_seconds"),
        page_limit=_parse_int(merged.get("page_limit", 50), "page_limit"),
        config_path=config_path,
    )
