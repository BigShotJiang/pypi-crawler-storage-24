"""Tests for the error hierarchy and exit-code mapping."""

import unittest

from xray_cli.errors import (
    XrayCliError,
    ConfigError,
    AuthError,
    TransportError,
    GraphQLError,
    ImportError_,
    ResolutionError,
    ValidationError,
    EXIT_SUCCESS,
    EXIT_USAGE_ERROR,
    EXIT_CONFIG_ERROR,
    EXIT_AUTH_ERROR,
    EXIT_TRANSPORT_ERROR,
    EXIT_API_ERROR,
    EXIT_IMPORT_ERROR,
)


class TestExitCodes(unittest.TestCase):
    """Verify exit-code constants."""

    def test_exit_code_values(self):
        self.assertEqual(EXIT_SUCCESS, 0)
        self.assertEqual(EXIT_USAGE_ERROR, 2)
        self.assertEqual(EXIT_CONFIG_ERROR, 3)
        self.assertEqual(EXIT_AUTH_ERROR, 4)
        self.assertEqual(EXIT_TRANSPORT_ERROR, 5)
        self.assertEqual(EXIT_API_ERROR, 6)
        self.assertEqual(EXIT_IMPORT_ERROR, 7)


class TestExceptionHierarchy(unittest.TestCase):
    """Verify every custom exception inherits from XrayCliError."""

    def test_all_inherit_from_base(self):
        for cls in (
            ConfigError,
            AuthError,
            TransportError,
            GraphQLError,
            ImportError_,
            ResolutionError,
            ValidationError,
        ):
            with self.subTest(cls=cls.__name__):
                self.assertTrue(issubclass(cls, XrayCliError))
                self.assertTrue(issubclass(cls, Exception))


class TestExitCodeMapping(unittest.TestCase):
    """Each error type must map to the correct exit code."""

    def test_config_error(self):
        self.assertEqual(ConfigError("x").exit_code, EXIT_CONFIG_ERROR)

    def test_auth_error(self):
        self.assertEqual(AuthError("x").exit_code, EXIT_AUTH_ERROR)

    def test_transport_error(self):
        self.assertEqual(TransportError("x").exit_code, EXIT_TRANSPORT_ERROR)

    def test_graphql_error(self):
        self.assertEqual(GraphQLError("x").exit_code, EXIT_API_ERROR)

    def test_import_error(self):
        self.assertEqual(ImportError_("x").exit_code, EXIT_IMPORT_ERROR)

    def test_resolution_error(self):
        self.assertEqual(ResolutionError("x").exit_code, EXIT_API_ERROR)

    def test_validation_error(self):
        self.assertEqual(ValidationError("x").exit_code, EXIT_USAGE_ERROR)


class TestErrorAttributes(unittest.TestCase):
    """Verify message and detail attributes."""

    def test_message(self):
        err = ConfigError("bad config")
        self.assertEqual(str(err), "bad config")

    def test_detail(self):
        err = AuthError("auth failed", detail="token expired")
        self.assertEqual(err.detail, "token expired")

    def test_detail_default_none(self):
        err = TransportError("timeout")
        self.assertIsNone(err.detail)

    def test_category(self):
        self.assertEqual(ConfigError("x").category, "config")
        self.assertEqual(AuthError("x").category, "auth")
        self.assertEqual(TransportError("x").category, "transport")
        self.assertEqual(GraphQLError("x").category, "graphql")
        self.assertEqual(ImportError_("x").category, "import")
        self.assertEqual(ResolutionError("x").category, "resolution")
        self.assertEqual(ValidationError("x").category, "validation")

    def test_graphql_error_errors_list(self):
        err = GraphQLError("gql fail", errors=[{"message": "bad field"}])
        self.assertEqual(len(err.errors), 1)
        self.assertEqual(err.errors[0]["message"], "bad field")

    def test_graphql_error_errors_default_empty(self):
        err = GraphQLError("gql fail")
        self.assertEqual(err.errors, [])


if __name__ == "__main__":
    unittest.main()
