"""Tests for the REST import client."""

import json
import os
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from io import BytesIO

from xray_cli.rest_client import RestClient
from xray_cli.errors import ImportError_, TransportError, AuthError


class _FakeTokenService:
    def __init__(self, token="test-token"):
        self._token = token
        self.invalidate_count = 0

    def get_token(self):
        return self._token

    def invalidate_token(self):
        self.invalidate_count += 1


def _mock_urlopen(response_body, side_effect=None):
    if side_effect:
        return patch("xray_cli.rest_client.urllib.request.urlopen", side_effect=side_effect)
    mock_resp = MagicMock()
    if isinstance(response_body, str):
        response_body = response_body.encode("utf-8")
    mock_resp.read.return_value = response_body
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("xray_cli.rest_client.urllib.request.urlopen", return_value=mock_resp)


class TestImportFileValidation(unittest.TestCase):
    """Import requests must validate input files."""

    def test_file_not_found(self):
        client = RestClient("https://import.example.com", _FakeTokenService())
        with self.assertRaises(ImportError_) as ctx:
            client.import_results("xray-json", "/nonexistent/file.json")
        self.assertIn("not found", str(ctx.exception))

    def test_unsupported_format(self):
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
            f.write(b"data")
            f.flush()
            client = RestClient("https://import.example.com", _FakeTokenService())
            with self.assertRaises(ImportError_) as ctx:
                client.import_results("csv", f.name)
            self.assertIn("Unsupported", str(ctx.exception))
        os.unlink(f.name)


class TestEndpointSelection(unittest.TestCase):
    """The correct endpoint and content type must be selected per format."""

    def test_xray_json_endpoint(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{"tests": []}')
            f.flush()
            response = json.dumps({"testExecIssue": {"key": "XSP-1"}})
            with _mock_urlopen(response) as mock:
                client = RestClient("https://import.example.com/api/v2/import/execution", _FakeTokenService())
                client.import_results("xray-json", f.name)
                req = mock.call_args[0][0]
                self.assertIn("/xray", req.full_url)
                self.assertEqual(req.get_header("Content-type"), "application/json")
        os.unlink(f.name)

    def test_junit_endpoint(self):
        with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as f:
            f.write(b'<testsuites></testsuites>')
            f.flush()
            response = json.dumps({"testExecIssue": {"key": "XSP-2"}})
            with _mock_urlopen(response) as mock:
                client = RestClient("https://import.example.com/api/v2/import/execution", _FakeTokenService())
                client.import_results("junit", f.name)
                req = mock.call_args[0][0]
                self.assertIn("/junit", req.full_url)
                self.assertEqual(req.get_header("Content-type"), "application/xml")
        os.unlink(f.name)


class TestQueryParams(unittest.TestCase):
    """Query params for project and execution keys."""

    def test_project_key_param(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{}')
            f.flush()
            with _mock_urlopen(json.dumps({})) as mock:
                client = RestClient("https://import.example.com", _FakeTokenService())
                client.import_results("xray-json", f.name, project_key="TST")
                req = mock.call_args[0][0]
                self.assertIn("projectKey=TST", req.full_url)
        os.unlink(f.name)

    def test_execution_key_param(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{}')
            f.flush()
            with _mock_urlopen(json.dumps({})) as mock:
                client = RestClient("https://import.example.com", _FakeTokenService())
                client.import_results("xray-json", f.name, execution_key="XSP-99")
                req = mock.call_args[0][0]
                self.assertIn("testExecKey=XSP-99", req.full_url)
        os.unlink(f.name)


class TestImportFailures(unittest.TestCase):
    """Import failures should raise appropriate errors."""

    def _make_http_error(self, code, body="error"):
        import urllib.error
        return urllib.error.HTTPError(
            url="https://import.example.com",
            code=code,
            msg="error",
            hdrs={},
            fp=BytesIO(body.encode("utf-8")),
        )

    def test_400_raises_import_error(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{}')
            f.flush()
            err = self._make_http_error(400)
            with _mock_urlopen("", side_effect=err):
                client = RestClient("https://import.example.com", _FakeTokenService())
                with self.assertRaises(ImportError_):
                    client.import_results("xray-json", f.name)
        os.unlink(f.name)

    def test_401_retries_and_raises_auth(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{}')
            f.flush()
            err1 = self._make_http_error(401)
            err2 = self._make_http_error(401)
            ts = _FakeTokenService()
            with patch("xray_cli.rest_client.urllib.request.urlopen", side_effect=[err1, err2]):
                client = RestClient("https://import.example.com", ts)
                with self.assertRaises(AuthError):
                    client.import_results("xray-json", f.name)
            self.assertEqual(ts.invalidate_count, 1)
        os.unlink(f.name)

    def test_url_error_raises_transport(self):
        import urllib.error
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            f.write(b'{}')
            f.flush()
            err = urllib.error.URLError("DNS failed")
            with _mock_urlopen("", side_effect=err):
                client = RestClient("https://import.example.com", _FakeTokenService())
                with self.assertRaises(TransportError):
                    client.import_results("xray-json", f.name)
        os.unlink(f.name)


if __name__ == "__main__":
    unittest.main()
