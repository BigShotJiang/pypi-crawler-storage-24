"""Tests for the issue resolver."""

import unittest
from unittest.mock import MagicMock

from xray_cli.resolver import IssueResolver
from xray_cli.errors import ResolutionError


class TestIssueResolution(unittest.TestCase):
    """Issue resolver must translate keys to IDs."""

    def test_resolve_via_test_lookup(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getTests": {
                "results": [
                    {"issueId": "12345", "jira": {"key": "XSP-42"}},
                ]
            }
        }
        resolver = IssueResolver(mock_gql)
        result = resolver.resolve("XSP-42")
        self.assertEqual(result, "12345")

    def test_resolve_caches_result(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getTests": {
                "results": [
                    {"issueId": "12345", "jira": {"key": "XSP-42"}},
                ]
            }
        }
        resolver = IssueResolver(mock_gql)
        resolver.resolve("XSP-42")
        resolver.resolve("XSP-42")
        # Only called once thanks to caching
        self.assertEqual(mock_gql.execute.call_count, 1)

    def test_resolve_via_execution_fallback(self):
        mock_gql = MagicMock()
        # First call (getTests) returns no results
        # Second call (getTestExecutions) returns the match
        mock_gql.execute.side_effect = [
            {"getTests": {"results": []}},
            {"getTestExecutions": {"results": [{"issueId": "99", "jira": {"key": "XSP-99"}}]}},
        ]
        resolver = IssueResolver(mock_gql)
        result = resolver.resolve("XSP-99")
        self.assertEqual(result, "99")

    def test_resolve_not_found_raises(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {"getTests": {"results": []}}
        # Also fails on fallback
        mock_gql.execute.side_effect = [
            {"getTests": {"results": []}},
            {"getTestExecutions": {"results": []}},
        ]
        resolver = IssueResolver(mock_gql)
        with self.assertRaises(ResolutionError) as ctx:
            resolver.resolve("XSP-MISSING")
        self.assertIn("XSP-MISSING", str(ctx.exception))

    def test_resolve_single_result_without_key_match(self):
        """When there's exactly one result, use it even if key doesn't match."""
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getTests": {
                "results": [
                    {"issueId": "777", "jira": None},
                ]
            }
        }
        resolver = IssueResolver(mock_gql)
        result = resolver.resolve("XSP-777")
        self.assertEqual(result, "777")


if __name__ == "__main__":
    unittest.main()
