"""Tests for the CLI entry point, parser, and bootstrap."""

import unittest

from xray_cli.cli import main, _hoist_global_flags
from xray_cli.errors import EXIT_USAGE_ERROR


class TestCliHelp(unittest.TestCase):
    """Verify the CLI boots and can display help."""

    def test_help_flag_exits_zero(self):
        with self.assertRaises(SystemExit) as ctx:
            main(["--help"])
        self.assertEqual(ctx.exception.code, 0)

    def test_version_flag(self):
        with self.assertRaises(SystemExit) as ctx:
            main(["--version"])
        self.assertEqual(ctx.exception.code, 0)

    def test_no_command_returns_usage_error(self):
        result = main([])
        self.assertEqual(result, EXIT_USAGE_ERROR)


class TestCliGlobalFlags(unittest.TestCase):
    """Verify global flags are parsed without crashing."""

    def test_verbose_flag_parses(self):
        # No command → usage error, but parsing should succeed
        result = main(["--verbose"])
        self.assertEqual(result, EXIT_USAGE_ERROR)

    def test_quiet_flag_parses(self):
        result = main(["--quiet"])
        self.assertEqual(result, EXIT_USAGE_ERROR)

    def test_json_flag_parses(self):
        result = main(["--json"])
        self.assertEqual(result, EXIT_USAGE_ERROR)

    def test_timeout_flag_parses(self):
        result = main(["--timeout", "60"])
        self.assertEqual(result, EXIT_USAGE_ERROR)

    def test_config_flag_parses(self):
        result = main(["--config", "/nonexistent"])
        self.assertEqual(result, EXIT_USAGE_ERROR)


class TestHoistGlobalFlags(unittest.TestCase):
    """Unit tests for the _hoist_global_flags pre-processing."""

    def test_no_flags_unchanged(self):
        argv = ["test", "get", "OTR-1"]
        self.assertEqual(_hoist_global_flags(argv), ["test", "get", "OTR-1"])

    def test_flag_already_at_front(self):
        argv = ["--json", "test", "get", "OTR-1"]
        self.assertEqual(_hoist_global_flags(argv), ["--json", "test", "get", "OTR-1"])

    def test_flag_at_end_hoisted(self):
        argv = ["test", "get", "OTR-1", "--json"]
        self.assertEqual(_hoist_global_flags(argv), ["--json", "test", "get", "OTR-1"])

    def test_flag_in_middle_hoisted(self):
        argv = ["test", "--json", "get", "OTR-1"]
        self.assertEqual(_hoist_global_flags(argv), ["--json", "test", "get", "OTR-1"])

    def test_multiple_boolean_flags_hoisted(self):
        argv = ["test", "get", "OTR-1", "--json", "-v"]
        self.assertEqual(
            _hoist_global_flags(argv),
            ["--json", "-v", "test", "get", "OTR-1"],
        )

    def test_flag_with_argument_hoisted(self):
        argv = ["test", "get", "OTR-1", "--timeout", "60"]
        self.assertEqual(
            _hoist_global_flags(argv),
            ["--timeout", "60", "test", "get", "OTR-1"],
        )

    def test_config_flag_with_argument_hoisted(self):
        argv = ["test", "get", "OTR-1", "--config", "/my/config.ini"]
        self.assertEqual(
            _hoist_global_flags(argv),
            ["--config", "/my/config.ini", "test", "get", "OTR-1"],
        )

    def test_mixed_global_and_subcommand_flags(self):
        argv = ["test", "get", "--json", "OTR-1", "--timeout", "30", "--verbose"]
        result = _hoist_global_flags(argv)
        # Global flags come first, rest preserves order
        self.assertEqual(
            result,
            ["--json", "--timeout", "30", "--verbose", "test", "get", "OTR-1"],
        )

    def test_empty_argv(self):
        self.assertEqual(_hoist_global_flags([]), [])

    def test_short_verbose_flag_hoisted(self):
        argv = ["execution", "list", "-v"]
        self.assertEqual(_hoist_global_flags(argv), ["-v", "execution", "list"])

    def test_short_quiet_flag_hoisted(self):
        argv = ["execution", "list", "-q"]
        self.assertEqual(_hoist_global_flags(argv), ["-q", "execution", "list"])

    def test_subcommand_specific_flags_not_hoisted(self):
        """Flags not in the global set should stay in place."""
        argv = ["execution", "list", "--jql", "project=FOO", "--json"]
        self.assertEqual(
            _hoist_global_flags(argv),
            ["--json", "execution", "list", "--jql", "project=FOO"],
        )


if __name__ == "__main__":
    unittest.main()
