"""Tests for config loading, merging, and validation."""

import os
import tempfile
import unittest
from pathlib import Path

from xray_cli.config import load_config, AppConfig
from xray_cli.errors import ConfigError


class TestConfigPrecedence(unittest.TestCase):
    """Config sources must merge with deterministic precedence."""

    def _write_ini(self, path, content):
        Path(path).write_text(content, encoding="utf-8")

    def test_defaults_used_when_no_overrides(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_id = cid\nclient_secret = csec\n")
            f.flush()
            cfg = load_config(explicit_path=f.name)
        self.assertEqual(cfg.auth_url, "https://xray.cloud.getxray.app/api/v2/authenticate")
        self.assertEqual(cfg.graphql_url, "https://xray.cloud.getxray.app/api/v2/graphql")
        self.assertEqual(cfg.timeout_seconds, 30)
        self.assertEqual(cfg.page_limit, 50)
        self.assertEqual(cfg.output, "text")
        os.unlink(f.name)

    def test_ini_overrides_defaults(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(
                "[xray]\nclient_id = cid\nclient_secret = csec\n"
                "[defaults]\ntimeout_seconds = 60\npage_limit = 25\nproject_key = TST\n"
            )
            f.flush()
            cfg = load_config(explicit_path=f.name)
        self.assertEqual(cfg.timeout_seconds, 60)
        self.assertEqual(cfg.page_limit, 25)
        self.assertEqual(cfg.project_key, "TST")
        os.unlink(f.name)

    def test_env_overrides_ini(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(
                "[xray]\nclient_id = from_ini\nclient_secret = from_ini_sec\n"
                "[defaults]\ntimeout_seconds = 60\n"
            )
            f.flush()
            env_patch = {
                "XRAY_CLIENT_ID": "from_env",
                "XRAY_TIMEOUT": "15",
            }
            original = {k: os.environ.get(k) for k in env_patch}
            try:
                os.environ.update(env_patch)
                cfg = load_config(explicit_path=f.name)
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        self.assertEqual(cfg.client_id, "from_env")
        self.assertEqual(cfg.client_secret, "from_ini_sec")
        self.assertEqual(cfg.timeout_seconds, 15)
        os.unlink(f.name)

    def test_cli_overrides_env(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_id = cid\nclient_secret = csec\n")
            f.flush()
            env_patch = {"XRAY_TIMEOUT": "15"}
            original = {k: os.environ.get(k) for k in env_patch}
            try:
                os.environ.update(env_patch)
                cfg = load_config(
                    explicit_path=f.name,
                    cli_overrides={"timeout_seconds": "99"},
                )
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        self.assertEqual(cfg.timeout_seconds, 99)
        os.unlink(f.name)


class TestConfigValidation(unittest.TestCase):
    """Config loading must fail fast with clear errors for bad input."""

    def test_missing_client_id(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_secret = csec\n")
            f.flush()
            # Clear env vars that might satisfy the check
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                os.environ["XRAY_CLIENT_SECRET"] = "csec"
                with self.assertRaises(ConfigError) as ctx:
                    load_config(explicit_path=f.name)
                self.assertIn("client_id", str(ctx.exception))
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)

    def test_missing_client_secret(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_id = cid\n")
            f.flush()
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                os.environ["XRAY_CLIENT_ID"] = "cid"
                with self.assertRaises(ConfigError) as ctx:
                    load_config(explicit_path=f.name)
                self.assertIn("client_secret", str(ctx.exception))
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)

    def test_missing_both_credentials(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[defaults]\ntimeout_seconds = 10\n")
            f.flush()
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                with self.assertRaises(ConfigError) as ctx:
                    load_config(explicit_path=f.name)
                msg = str(ctx.exception)
                self.assertIn("client_id", msg)
                self.assertIn("client_secret", msg)
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)

    def test_invalid_output_mode(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_id = cid\nclient_secret = csec\n[defaults]\noutput = xml\n")
            f.flush()
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET", "XRAY_OUTPUT"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                with self.assertRaises(ConfigError) as ctx:
                    load_config(explicit_path=f.name)
                self.assertIn("xml", str(ctx.exception))
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)

    def test_invalid_timeout_string(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(
                "[xray]\nclient_id = cid\nclient_secret = csec\n"
                "[defaults]\ntimeout_seconds = notanumber\n"
            )
            f.flush()
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET", "XRAY_TIMEOUT"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                with self.assertRaises(ConfigError):
                    load_config(explicit_path=f.name)
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)

    def test_explicit_path_not_found(self):
        with self.assertRaises(ConfigError) as ctx:
            load_config(explicit_path="/nonexistent/path/config.ini")
        self.assertIn("not found", str(ctx.exception))

    def test_malformed_ini(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            # configparser tolerates a lot, but a bare key with = at start of line
            # without a section header will raise MissingSectionHeaderError
            f.write("= bad ini no section\n")
            f.flush()
            env_keys = ["XRAY_CLIENT_ID", "XRAY_CLIENT_SECRET"]
            original = {k: os.environ.get(k) for k in env_keys}
            try:
                for k in env_keys:
                    os.environ.pop(k, None)
                with self.assertRaises(ConfigError):
                    load_config(explicit_path=f.name)
            finally:
                for k, v in original.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v
        os.unlink(f.name)


class TestAppConfig(unittest.TestCase):
    """Verify AppConfig value object behavior."""

    def test_repr(self):
        cfg = AppConfig(client_id="SECRET_CID_123", client_secret="SECRET_CSEC_456", project_key="PRJ")
        r = repr(cfg)
        self.assertIn("PRJ", r)
        # Secrets should not appear in repr
        self.assertNotIn("SECRET_CID_123", r)
        self.assertNotIn("SECRET_CSEC_456", r)

    def test_json_output_mode(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write("[xray]\nclient_id = cid\nclient_secret = csec\n")
            f.flush()
            cfg = load_config(
                explicit_path=f.name,
                cli_overrides={"output": "json"},
            )
        self.assertEqual(cfg.output, "json")
        os.unlink(f.name)


if __name__ == "__main__":
    unittest.main()
