"""Tests for the Xray service layer."""

import unittest
from unittest.mock import MagicMock

from xray_cli.service import XrayService


class TestListExecutions(unittest.TestCase):
    """Service layer must transform GraphQL responses into stable shapes."""

    def _make_service(self, gql_response):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = gql_response
        return XrayService(mock_gql), mock_gql

    def test_basic_listing(self):
        gql_data = {
            "getTestExecutions": {
                "total": 2,
                "start": 0,
                "limit": 50,
                "results": [
                    {
                        "issueId": "12345",
                        "jira": {
                            "key": "XSP-10",
                            "summary": "Sprint Execution",
                            "status": {"name": "In Progress"},
                        },
                    },
                    {
                        "issueId": "12346",
                        "jira": {
                            "key": "XSP-11",
                            "summary": "Release Execution",
                            "status": {"name": "Done"},
                        },
                    },
                ],
            }
        }
        service, mock_gql = self._make_service(gql_data)
        result = service.list_executions(jql="project = XSP", limit=50)

        self.assertEqual(result["total"], 2)
        self.assertEqual(len(result["results"]), 2)
        self.assertEqual(result["results"][0]["issue_key"], "XSP-10")
        self.assertEqual(result["results"][0]["summary"], "Sprint Execution")
        self.assertEqual(result["results"][0]["status"], "In Progress")
        self.assertEqual(result["_type"], "execution_list")

    def test_jql_forwarded(self):
        service, mock_gql = self._make_service({"getTestExecutions": {"total": 0, "results": []}})
        service.list_executions(jql="project = XSP AND status = Done")
        call_args = mock_gql.execute.call_args
        variables = call_args[0][1] if len(call_args[0]) > 1 else call_args[1].get("variables", {})
        self.assertEqual(variables["jql"], "project = XSP AND status = Done")

    def test_limit_capped_at_100(self):
        service, mock_gql = self._make_service({"getTestExecutions": {"total": 0, "results": []}})
        service.list_executions(limit=200)
        call_args = mock_gql.execute.call_args
        variables = call_args[0][1]
        self.assertEqual(variables["limit"], 100)

    def test_empty_results(self):
        service, _ = self._make_service({"getTestExecutions": {"total": 0, "start": 0, "limit": 50, "results": []}})
        result = service.list_executions()
        self.assertEqual(result["total"], 0)
        self.assertEqual(result["results"], [])

    def test_missing_jira_fields(self):
        """Handle results where jira fields are missing or null."""
        gql_data = {
            "getTestExecutions": {
                "total": 1,
                "start": 0,
                "limit": 50,
                "results": [
                    {"issueId": "99999", "jira": None},
                ],
            }
        }
        service, _ = self._make_service(gql_data)
        result = service.list_executions()
        self.assertEqual(result["results"][0]["issueId"], "99999")


class TestGetTest(unittest.TestCase):
    """Service layer must fetch and transform a single test."""

    def _make_service(self, responses):
        """Create a service where execute returns different values per call."""
        mock_gql = MagicMock()
        if isinstance(responses, list):
            mock_gql.execute.side_effect = responses
        else:
            mock_gql.execute.return_value = responses
        return XrayService(mock_gql), mock_gql

    def test_get_test_basic(self):
        # First call: resolve issue key; Second call: getTest
        responses = [
            {"getTests": {"results": [{"issueId": "111", "jira": {"key": "XSP-1"}}]}},
            {"getTest": {
                "issueId": "111",
                "testType": {"name": "Manual", "kind": "Steps"},
                "gherkin": None,
                "steps": [
                    {"id": "s1", "action": "Click button", "data": "", "result": "Dialog opens"},
                ],
                "jira": {
                    "key": "XSP-1",
                    "summary": "Login Test",
                    "status": {"name": "Open"},
                    "priority": "High",
                    "labels": ["smoke"],
                },
            }},
        ]
        service, _ = self._make_service(responses)
        result = service.get_test("XSP-1")

        self.assertEqual(result["_type"], "test_detail")
        self.assertEqual(result["issue_key"], "XSP-1")
        self.assertEqual(result["summary"], "Login Test")
        self.assertEqual(result["test_type"], "Manual")
        self.assertEqual(result["test_kind"], "Steps")
        self.assertEqual(len(result["steps"]), 1)
        self.assertEqual(result["steps"][0]["action"], "Click button")

    def test_get_test_with_gherkin(self):
        responses = [
            {"getTests": {"results": [{"issueId": "222", "jira": {"key": "XSP-2"}}]}},
            {"getTest": {
                "issueId": "222",
                "testType": {"name": "Cucumber", "kind": "Gherkin"},
                "gherkin": "Given I am logged in\nWhen I click logout\nThen I see the login page",
                "steps": [],
                "jira": {"key": "XSP-2", "summary": "Logout BDD"},
            }},
        ]
        service, _ = self._make_service(responses)
        result = service.get_test("XSP-2")
        self.assertIn("Given I am logged in", result["gherkin"])


class TestListTests(unittest.TestCase):
    """Service layer must list tests with proper transformation."""

    def _make_service(self, gql_response):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = gql_response
        return XrayService(mock_gql), mock_gql

    def test_basic_test_listing(self):
        gql_data = {
            "getTests": {
                "total": 1,
                "start": 0,
                "limit": 50,
                "results": [
                    {
                        "issueId": "333",
                        "testType": {"name": "Manual", "kind": "Steps"},
                        "jira": {"key": "XSP-3", "summary": "Test A", "status": {"name": "Open"}},
                    },
                ],
            }
        }
        service, _ = self._make_service(gql_data)
        result = service.list_tests(jql="project = XSP")
        self.assertEqual(result["_type"], "test_list")
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["results"][0]["issue_key"], "XSP-3")
        self.assertEqual(result["results"][0]["test_type"], "Manual")

    def test_empty_test_listing(self):
        service, _ = self._make_service({"getTests": {"total": 0, "results": []}})
        result = service.list_tests()
        self.assertEqual(result["results"], [])


class TestListRuns(unittest.TestCase):
    """Service layer must list and filter runs."""

    def _make_service(self, gql_response):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = gql_response
        return XrayService(mock_gql), mock_gql

    def _sample_runs(self):
        return {
            "getTestRuns": {
                "total": 3,
                "start": 0,
                "limit": 50,
                "results": [
                    {
                        "id": "run-1",
                        "status": {"name": "PASS", "color": "#00FF00", "description": "Passed"},
                        "test": {"issueId": "t1", "jira": {"key": "XSP-1", "summary": "Test A"}},
                        "testExecution": {"issueId": "e1", "jira": {"key": "XSP-100"}},
                    },
                    {
                        "id": "run-2",
                        "status": {"name": "FAIL", "color": "#FF0000", "description": "Failed"},
                        "test": {"issueId": "t2", "jira": {"key": "XSP-2", "summary": "Test B"}},
                        "testExecution": {"issueId": "e1", "jira": {"key": "XSP-100"}},
                    },
                    {
                        "id": "run-3",
                        "status": {"name": "TODO", "color": "#CCCCCC", "description": "Not run"},
                        "test": {"issueId": "t3", "jira": {"key": "XSP-3", "summary": "Test C"}},
                        "testExecution": {"issueId": "e1", "jira": {"key": "XSP-100"}},
                    },
                ],
            }
        }

    def test_basic_run_listing(self):
        service, _ = self._make_service(self._sample_runs())
        result = service.list_runs()
        self.assertEqual(result["_type"], "run_list")
        self.assertEqual(result["total"], 3)
        self.assertEqual(len(result["results"]), 3)
        self.assertEqual(result["results"][0]["run_id"], "run-1")
        self.assertEqual(result["results"][0]["status"], "PASS")
        self.assertEqual(result["results"][0]["test_key"], "XSP-1")

    def test_failed_only_filter(self):
        service, _ = self._make_service(self._sample_runs())
        result = service.list_runs(failed_only=True)
        statuses = [r["status"] for r in result["results"]]
        self.assertIn("FAIL", statuses)
        self.assertIn("TODO", statuses)
        self.assertNotIn("PASS", statuses)

    def test_status_filter(self):
        service, _ = self._make_service(self._sample_runs())
        result = service.list_runs(status="PASS")
        self.assertEqual(len(result["results"]), 1)
        self.assertEqual(result["results"][0]["status"], "PASS")

    def test_execution_keys_forwarded(self):
        service, mock_gql = self._make_service(
            {"getTestRuns": {"total": 0, "results": []}}
        )
        service.list_runs(execution_keys=["XSP-100"])
        variables = mock_gql.execute.call_args[0][1]
        self.assertEqual(variables["testExecIssueIds"], ["XSP-100"])

    def test_empty_runs(self):
        service, _ = self._make_service(
            {"getTestRuns": {"total": 0, "start": 0, "limit": 50, "results": []}}
        )
        result = service.list_runs()
        self.assertEqual(result["results"], [])


class TestCreateExecution(unittest.TestCase):
    """Service must create executions via mutation."""

    def _make_service(self, gql_response):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = gql_response
        return XrayService(mock_gql), mock_gql

    def test_create_execution(self):
        gql_data = {
            "createTestExecution": {
                "testExecution": {
                    "issueId": "55555",
                    "jira": {"key": "XSP-50", "summary": "New Exec"},
                },
                "warnings": [],
            }
        }
        service, mock_gql = self._make_service(gql_data)
        result = service.create_execution("XSP", "New Exec", test_keys=["XSP-1"])
        self.assertEqual(result["_type"], "mutation_result")
        self.assertEqual(result["action"], "create_execution")
        self.assertTrue(result["success"])
        self.assertEqual(result["issue_key"], "XSP-50")

    def test_create_forwards_variables(self):
        service, mock_gql = self._make_service(
            {"createTestExecution": {"testExecution": {"issueId": "1", "jira": {}}}}
        )
        service.create_execution("TST", "My Exec", test_keys=["TST-1", "TST-2"])
        variables = mock_gql.execute.call_args[0][1]
        self.assertEqual(variables["projectKey"], "TST")
        self.assertEqual(variables["summary"], "My Exec")
        self.assertEqual(variables["testIssueIds"], ["TST-1", "TST-2"])


class TestUpdateRunStatus(unittest.TestCase):
    """Service must update run status via mutation."""

    def _make_service(self, gql_response):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = gql_response
        return XrayService(mock_gql), mock_gql

    def test_update_success(self):
        service, _ = self._make_service({"updateTestRunStatus": "Status updated"})
        result = service.update_run_status("run-123", "PASS")
        self.assertEqual(result["_type"], "mutation_result")
        self.assertEqual(result["action"], "update_run_status")
        self.assertTrue(result["success"])
        self.assertEqual(result["run_id"], "run-123")
        self.assertEqual(result["status"], "PASS")

    def test_variables_forwarded(self):
        service, mock_gql = self._make_service({"updateTestRunStatus": ""})
        service.update_run_status("run-abc", "FAIL")
        variables = mock_gql.execute.call_args[0][1]
        self.assertEqual(variables["id"], "run-abc")
        self.assertEqual(variables["status"], "FAIL")


class TestImportMethods(unittest.TestCase):
    """Service must delegate import to REST client."""

    def test_import_xray_json(self):
        mock_gql = MagicMock()
        mock_rest = MagicMock()
        mock_rest.import_results.return_value = {
            "testExecIssue": {"id": "999", "key": "XSP-99"},
        }
        service = XrayService(mock_gql, rest_client=mock_rest)
        result = service.import_xray_json("/path/to/results.json", project_key="XSP")
        self.assertEqual(result["_type"], "import_result")
        self.assertTrue(result["success"])
        self.assertEqual(result["format"], "xray-json")
        self.assertEqual(result["test_execution_key"], "XSP-99")
        mock_rest.import_results.assert_called_once_with(
            "xray-json", "/path/to/results.json",
            project_key="XSP", execution_key=None,
        )

    def test_import_junit_xml(self):
        mock_gql = MagicMock()
        mock_rest = MagicMock()
        mock_rest.import_results.return_value = {
            "testExecIssue": {"id": "888", "key": "XSP-88"},
        }
        service = XrayService(mock_gql, rest_client=mock_rest)
        result = service.import_junit_xml("/path/to/junit.xml", execution_key="XSP-50")
        self.assertEqual(result["format"], "junit")
        self.assertEqual(result["test_execution_key"], "XSP-88")

    def test_import_without_rest_client_raises(self):
        from xray_cli.errors import ConfigError
        mock_gql = MagicMock()
        service = XrayService(mock_gql)  # no rest_client
        with self.assertRaises(ConfigError):
            service.import_xray_json("/path/to/file.json")


class TestListPreconditions(unittest.TestCase):
    def test_basic(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getPreconditions": {
                "total": 1, "start": 0, "limit": 50,
                "results": [{
                    "issueId": "p1",
                    "preconditionType": {"name": "Manual", "kind": "Steps"},
                    "jira": {"key": "XSP-P1", "summary": "Login required"},
                }],
            }
        }
        service = XrayService(mock_gql)
        result = service.list_preconditions()
        self.assertEqual(result["_type"], "precondition_list")
        self.assertEqual(result["results"][0]["issue_key"], "XSP-P1")
        self.assertEqual(result["results"][0]["type"], "Manual")


class TestListTestSets(unittest.TestCase):
    def test_basic(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getTestSets": {
                "total": 1, "start": 0, "limit": 50,
                "results": [{"issueId": "ts1", "jira": {"key": "XSP-TS1", "summary": "Set A"}}],
            }
        }
        service = XrayService(mock_gql)
        result = service.list_test_sets()
        self.assertEqual(result["_type"], "test_set_list")
        self.assertEqual(result["results"][0]["issue_key"], "XSP-TS1")


class TestListTestPlans(unittest.TestCase):
    def test_basic(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getTestPlans": {
                "total": 1, "start": 0, "limit": 50,
                "results": [{"issueId": "tp1", "jira": {"key": "XSP-TP1", "summary": "Plan A"}}],
            }
        }
        service = XrayService(mock_gql)
        result = service.list_test_plans()
        self.assertEqual(result["_type"], "test_plan_list")
        self.assertEqual(result["results"][0]["issue_key"], "XSP-TP1")


class TestListFolders(unittest.TestCase):
    def test_basic(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {
            "getFolder": {
                "name": "Tests",
                "path": "/",
                "testsCount": 0,
                "folders": [
                    {"name": "Smoke", "path": "/Tests", "testsCount": 5},
                    {"name": "Regression", "path": "/Tests", "testsCount": 12},
                ],
            }
        }
        service = XrayService(mock_gql)
        result = service.list_folders("XSP")
        self.assertEqual(result["_type"], "folder_list")
        self.assertEqual(len(result["results"]), 2)
        self.assertEqual(result["results"][0]["name"], "Smoke")
        self.assertEqual(result["results"][0]["tests_count"], 5)


if __name__ == "__main__":
    unittest.main()
