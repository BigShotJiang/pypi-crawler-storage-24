"""Step 9-11 tests: evidence, formatter regression, and packaging smoke."""

import io
import json
import os
import tempfile
import unittest
from unittest.mock import MagicMock

from xray_cli.service import XrayService
from xray_cli.formatter import render
from xray_cli.errors import ValidationError


class TestAddEvidence(unittest.TestCase):
    """Service must send base64-encoded evidence."""

    def test_add_evidence_basic(self):
        mock_gql = MagicMock()
        mock_gql.execute.return_value = {"addEvidenceToTestRun": "ok"}
        service = XrayService(mock_gql)

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            f.write(b"fake image data")
            f.flush()
            result = service.add_run_evidence("run-1", f.name)
        os.unlink(f.name)

        self.assertEqual(result["_type"], "mutation_result")
        self.assertEqual(result["action"], "add_evidence")
        self.assertTrue(result["success"])
        self.assertEqual(result["run_id"], "run-1")
        self.assertIn(".png", result["filename"])

    def test_evidence_file_not_found(self):
        mock_gql = MagicMock()
        service = XrayService(mock_gql)
        with self.assertRaises(ValidationError):
            service.add_run_evidence("run-1", "/nonexistent/file.txt")


class TestFormatterRegression(unittest.TestCase):
    """Verify all entity types render without crashing in both modes."""

    def _types(self):
        return [
            {"_type": "execution_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "test_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "test_detail", "issue_key": "XSP-1", "summary": "T", "steps": []},
            {"_type": "run_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "mutation_result", "action": "create_execution", "success": True, "issue_key": "X"},
            {"_type": "mutation_result", "action": "update_run_status", "success": True, "run_id": "r1", "status": "PASS"},
            {"_type": "mutation_result", "action": "add_evidence", "success": True, "run_id": "r1", "filename": "f.png"},
            {"_type": "import_result", "success": True, "format": "junit", "test_execution_key": "X"},
            {"_type": "precondition_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "test_set_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "test_plan_list", "total": 0, "start": 0, "limit": 50, "results": []},
            {"_type": "folder_list", "total": 0, "start": 0, "limit": 50, "results": []},
        ]

    def test_all_types_render_text(self):
        for data in self._types():
            with self.subTest(type=data["_type"]):
                stream = io.StringIO()
                render(data, mode="text", stream=stream)
                self.assertTrue(len(stream.getvalue()) > 0)

    def test_all_types_render_json(self):
        for data in self._types():
            with self.subTest(type=data["_type"]):
                stream = io.StringIO()
                render(data, mode="json", stream=stream)
                parsed = json.loads(stream.getvalue())
                self.assertIn("_type", parsed)


class TestPackageSmoke(unittest.TestCase):
    """Verify the package can be imported and has expected attributes."""

    def test_import_package(self):
        import xray_cli
        self.assertTrue(hasattr(xray_cli, "__version__"))

    def test_cli_entry(self):
        from xray_cli.cli import main
        # No command → usage error code
        result = main([])
        self.assertEqual(result, 2)

    def test_help_has_all_commands(self):
        from xray_cli.cli import main
        import io
        import sys
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        try:
            main([])
            help_text = sys.stderr.getvalue()
        finally:
            sys.stderr = old_stderr
        for cmd in ["execution", "test", "run", "results", "precondition",
                     "test-set", "test-plan", "folder"]:
            self.assertIn(cmd, help_text, f"Command {cmd} missing from help")


if __name__ == "__main__":
    unittest.main()
