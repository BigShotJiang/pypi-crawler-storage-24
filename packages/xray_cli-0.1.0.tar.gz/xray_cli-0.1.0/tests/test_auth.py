"""Tests for the token service."""

import json
import unittest
from unittest.mock import patch, MagicMock
from http.client import HTTPResponse
from io import BytesIO

from xray_cli.auth import TokenService
from xray_cli.errors import AuthError, TransportError


def _mock_urlopen(response_body, status=200, side_effect=None):
    """Create a mock for urllib.request.urlopen."""
    if side_effect:
        return patch("xray_cli.auth.urllib.request.urlopen", side_effect=side_effect)
    mock_resp = MagicMock()
    mock_resp.read.return_value = response_body.encode("utf-8")
    mock_resp.status = status
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("xray_cli.auth.urllib.request.urlopen", return_value=mock_resp)


class TestTokenAcquisition(unittest.TestCase):
    """Token service must exchange credentials for a token."""

    def test_success_bare_string_token(self):
        """Xray returns the token as a bare JSON string."""
        token = "eyJhbGciOiJIUzI1NiJ9.test"
        with _mock_urlopen(json.dumps(token)):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            result = svc.get_token()
        self.assertEqual(result, token)

    def test_success_dict_token(self):
        """Alternative response format with token in a dict."""
        with _mock_urlopen(json.dumps({"token": "abc123"})):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            result = svc.get_token()
        self.assertEqual(result, "abc123")

    def test_unexpected_response_format(self):
        with _mock_urlopen(json.dumps({"something": "else"})):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(AuthError) as ctx:
                svc.get_token()
            self.assertIn("Unexpected", str(ctx.exception))


class TestTokenCaching(unittest.TestCase):
    """Tokens should be cached in memory."""

    def test_token_cached_after_first_call(self):
        token = "cached-token"
        with _mock_urlopen(json.dumps(token)) as mock:
            svc = TokenService("https://auth.example.com", "cid", "csec")
            svc.get_token()
            svc.get_token()
            self.assertEqual(mock.call_count, 1)

    def test_invalidate_forces_reauth(self):
        token = "new-token"
        with _mock_urlopen(json.dumps(token)) as mock:
            svc = TokenService("https://auth.example.com", "cid", "csec")
            svc.get_token()
            svc.invalidate_token()
            svc.get_token()
            self.assertEqual(mock.call_count, 2)


class TestAuthFailures(unittest.TestCase):
    """Auth failures should raise appropriate errors."""

    def _make_http_error(self, code, body="error"):
        import urllib.error
        resp = MagicMock()
        resp.read.return_value = body.encode("utf-8")
        return urllib.error.HTTPError(
            url="https://auth.example.com",
            code=code,
            msg="error",
            hdrs={},
            fp=BytesIO(body.encode("utf-8")),
        )

    def test_401_raises_auth_error(self):
        err = self._make_http_error(401, "bad credentials")
        with _mock_urlopen("", side_effect=err):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(AuthError) as ctx:
                svc.get_token()
            self.assertIn("invalid Client ID", str(ctx.exception))

    def test_403_raises_auth_error(self):
        err = self._make_http_error(403)
        with _mock_urlopen("", side_effect=err):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(AuthError):
                svc.get_token()

    def test_500_raises_auth_error(self):
        err = self._make_http_error(500)
        with _mock_urlopen("", side_effect=err):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(AuthError) as ctx:
                svc.get_token()
            self.assertIn("500", str(ctx.exception))

    def test_url_error_raises_transport_error(self):
        import urllib.error
        err = urllib.error.URLError("DNS resolution failed")
        with _mock_urlopen("", side_effect=err):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(TransportError):
                svc.get_token()

    def test_timeout_raises_transport_error(self):
        err = OSError("timed out")
        with _mock_urlopen("", side_effect=err):
            svc = TokenService("https://auth.example.com", "cid", "csec")
            with self.assertRaises(TransportError):
                svc.get_token()


if __name__ == "__main__":
    unittest.main()
