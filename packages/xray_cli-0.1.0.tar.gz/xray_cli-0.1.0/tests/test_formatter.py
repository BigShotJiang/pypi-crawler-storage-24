"""Tests for the output formatter."""

import io
import json
import unittest

from xray_cli.formatter import render, render_execution_list


class TestJsonMode(unittest.TestCase):
    """JSON mode should emit valid JSON."""

    def test_dict_output(self):
        stream = io.StringIO()
        data = {"key": "XSP-1", "summary": "Test Execution"}
        render(data, mode="json", stream=stream)
        result = json.loads(stream.getvalue())
        self.assertEqual(result["key"], "XSP-1")

    def test_list_output(self):
        stream = io.StringIO()
        data = [{"id": 1}, {"id": 2}]
        render(data, mode="json", stream=stream)
        result = json.loads(stream.getvalue())
        self.assertEqual(len(result), 2)


class TestExecutionListText(unittest.TestCase):
    """Text rendering for execution lists."""

    def test_with_results(self):
        stream = io.StringIO()
        data = {
            "_type": "execution_list",
            "total": 2,
            "start": 0,
            "limit": 50,
            "results": [
                {"issue_key": "XSP-10", "summary": "Sprint 1 Execution"},
                {"issue_key": "XSP-11", "summary": "Sprint 2 Execution"},
            ],
        }
        render(data, mode="text", stream=stream)
        output = stream.getvalue()
        self.assertIn("XSP-10", output)
        self.assertIn("XSP-11", output)
        self.assertIn("Sprint 1 Execution", output)
        self.assertIn("2 of 2", output)

    def test_empty_results(self):
        stream = io.StringIO()
        data = {
            "_type": "execution_list",
            "total": 0,
            "start": 0,
            "limit": 50,
            "results": [],
        }
        render(data, mode="text", stream=stream)
        output = stream.getvalue()
        self.assertIn("No executions found", output)

    def test_json_mode_for_execution_list(self):
        stream = io.StringIO()
        data = {
            "_type": "execution_list",
            "total": 1,
            "start": 0,
            "limit": 50,
            "results": [{"issue_key": "XSP-1"}],
        }
        render(data, mode="json", stream=stream)
        result = json.loads(stream.getvalue())
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["results"][0]["issue_key"], "XSP-1")


class TestFallbackRendering(unittest.TestCase):
    """Unknown types should still render."""

    def test_plain_dict(self):
        stream = io.StringIO()
        render({"name": "test", "value": 42}, mode="text", stream=stream)
        output = stream.getvalue()
        self.assertIn("name: test", output)
        self.assertIn("value: 42", output)


if __name__ == "__main__":
    unittest.main()
