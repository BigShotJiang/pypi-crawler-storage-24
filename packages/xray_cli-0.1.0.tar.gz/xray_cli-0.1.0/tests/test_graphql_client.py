"""Tests for the GraphQL client."""

import json
import unittest
from unittest.mock import patch, MagicMock
from io import BytesIO

from xray_cli.graphql_client import GraphQLClient
from xray_cli.errors import GraphQLError, TransportError, AuthError


class _FakeTokenService:
    """Minimal token service for testing."""
    def __init__(self, token="test-token"):
        self._token = token
        self.invalidate_count = 0

    def get_token(self):
        return self._token

    def invalidate_token(self):
        self.invalidate_count += 1


def _mock_urlopen(response_body, status=200, side_effect=None):
    if side_effect:
        return patch("xray_cli.graphql_client.urllib.request.urlopen", side_effect=side_effect)
    mock_resp = MagicMock()
    if isinstance(response_body, str):
        response_body = response_body.encode("utf-8")
    mock_resp.read.return_value = response_body
    mock_resp.status = status
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("xray_cli.graphql_client.urllib.request.urlopen", return_value=mock_resp)


class TestGraphQLExecution(unittest.TestCase):
    """GraphQL client must send requests and parse responses."""

    def test_successful_query(self):
        data = {"getTests": [{"issueId": "123"}]}
        body = json.dumps({"data": data})
        with _mock_urlopen(body):
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            result = client.execute("{ getTests { issueId } }")
        self.assertEqual(result, data)

    def test_variables_sent(self):
        body = json.dumps({"data": {"test": True}})
        with _mock_urlopen(body) as mock:
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            client.execute("query($id: String!) { test(id: $id) }", {"id": "x"})
            # Verify the request body contains variables
            call_args = mock.call_args
            req = call_args[0][0]
            sent = json.loads(req.data)
            self.assertIn("variables", sent)
            self.assertEqual(sent["variables"]["id"], "x")

    def test_empty_document_raises(self):
        client = GraphQLClient("https://gql.example.com", _FakeTokenService())
        with self.assertRaises(GraphQLError) as ctx:
            client.execute("")
        self.assertIn("empty", str(ctx.exception).lower())

    def test_whitespace_only_document_raises(self):
        client = GraphQLClient("https://gql.example.com", _FakeTokenService())
        with self.assertRaises(GraphQLError):
            client.execute("   \n  ")


class TestGraphQLErrorNormalization(unittest.TestCase):
    """GraphQL errors in response should be normalized."""

    def test_single_error(self):
        body = json.dumps({"errors": [{"message": "Field 'x' not found"}]})
        with _mock_urlopen(body):
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            with self.assertRaises(GraphQLError) as ctx:
                client.execute("{ x }")
            self.assertIn("Field 'x' not found", str(ctx.exception))
            self.assertEqual(len(ctx.exception.errors), 1)

    def test_multiple_errors(self):
        body = json.dumps({"errors": [
            {"message": "error one"},
            {"message": "error two"},
        ]})
        with _mock_urlopen(body):
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            with self.assertRaises(GraphQLError) as ctx:
                client.execute("{ x }")
            self.assertIn("error one", str(ctx.exception))
            self.assertIn("error two", str(ctx.exception))
            self.assertEqual(len(ctx.exception.errors), 2)


class TestGraphQLTransportFailures(unittest.TestCase):
    """Network failures should raise TransportError."""

    def _make_http_error(self, code, body="error"):
        import urllib.error
        return urllib.error.HTTPError(
            url="https://gql.example.com",
            code=code,
            msg="error",
            hdrs={},
            fp=BytesIO(body.encode("utf-8")),
        )

    def test_500_raises_transport_error(self):
        err = self._make_http_error(500)
        with _mock_urlopen("", side_effect=err):
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            with self.assertRaises(TransportError):
                client.execute("{ test }")

    def test_url_error_raises_transport(self):
        import urllib.error
        err = urllib.error.URLError("connection refused")
        with _mock_urlopen("", side_effect=err):
            client = GraphQLClient("https://gql.example.com", _FakeTokenService())
            with self.assertRaises(TransportError):
                client.execute("{ test }")


class TestGraphQLAuthRetry(unittest.TestCase):
    """401/403 should trigger one token refresh and retry."""

    def _make_http_error(self, code, body="error"):
        import urllib.error
        return urllib.error.HTTPError(
            url="https://gql.example.com",
            code=code,
            msg="error",
            hdrs={},
            fp=BytesIO(body.encode("utf-8")),
        )

    def test_401_retries_once(self):
        """First call gets 401, token is invalidated, second call succeeds."""
        data = {"test": True}
        success_resp = MagicMock()
        success_resp.read.return_value = json.dumps({"data": data}).encode("utf-8")
        success_resp.__enter__ = MagicMock(return_value=success_resp)
        success_resp.__exit__ = MagicMock(return_value=False)

        err = self._make_http_error(401)
        ts = _FakeTokenService()

        with patch("xray_cli.graphql_client.urllib.request.urlopen",
                   side_effect=[err, success_resp]):
            client = GraphQLClient("https://gql.example.com", ts)
            result = client.execute("{ test }")
        self.assertEqual(result, data)
        self.assertEqual(ts.invalidate_count, 1)

    def test_401_twice_raises_auth_error(self):
        """If retry also gets 401, raise AuthError."""
        err1 = self._make_http_error(401)
        err2 = self._make_http_error(401)
        ts = _FakeTokenService()

        with patch("xray_cli.graphql_client.urllib.request.urlopen",
                   side_effect=[err1, err2]):
            client = GraphQLClient("https://gql.example.com", ts)
            with self.assertRaises(AuthError):
                client.execute("{ test }")


if __name__ == "__main__":
    unittest.main()
