"""
LLM Provider using LiteLLM.

Provides a unified interface to 100+ LLM providers via LiteLLM.
See https://docs.litellm.ai/docs/providers for supported providers.

Model naming:
- OpenAI: "gpt-4o", "gpt-4o-mini"
- Anthropic: "anthropic/claude-haiku-4-5-20251001"
- Google: "gemini/gemini-2.5-flash-preview-09-2025"
"""

from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, NamedTuple, Optional

from litellm import acompletion, get_llm_provider, get_supported_openai_params
from litellm.utils import get_optional_params

from line.llm_agent.config import LlmConfig, _normalize_config
from line.llm_agent.schema_converter import tools_to_litellm
from line.llm_agent.tools.utils import FunctionTool


@dataclass
class ToolCall:
    """A tool/function call from the LLM."""

    id: str
    name: str
    arguments: str = ""
    is_complete: bool = False
    thought_signature: Optional[str] = None  # For Gemini 3+ models


@dataclass
class StreamChunk:
    """An output chunk from an LLM stream."""

    text: Optional[str] = None
    tool_calls: List[ToolCall] = field(default_factory=list)
    is_final: bool = False


@dataclass
class Message:
    """A input message in the conversation."""

    role: str
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None


class LLMProvider:
    """
    LLM provider using LiteLLM for unified multi-provider access.

    Handles streaming responses and tool calls for all LiteLLM-supported models.
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        config: Optional[LlmConfig] = None,
    ):
        self._model = model
        self._api_key = api_key
        self._config = _normalize_config(config or LlmConfig())

        supported = get_supported_openai_params(model=model) or []
        self._supports_reasoning_effort = "reasoning_effort" in supported

        # Determine the right default when no explicit reasoning_effort is configured.
        # Goal: use the absolute lowest reasoning level each provider supports.
        # Almost all providers support "low", so start there and then check if we can do better.
        self._default_reasoning_effort = "low"
        if self._supports_reasoning_effort:
            try:
                _, provider, _, _ = get_llm_provider(model=model)
                get_optional_params(model=model, custom_llm_provider=provider, reasoning_effort="none")
                self._default_reasoning_effort = "none"
            except Exception:
                # HACK: Anthropic's LiteLLM mapping annoyingly doesn't support `"none"` (the string) as a
                # value for reasoning_effort, so None (omitting the param) is the correct way
                # to skip the thinking block entirely; "low" would still enable a 1024-token
                # thinking budget.
                if "anthropic" in model.lower():
                    self._default_reasoning_effort = None

    def chat(
        self,
        messages: List[Message],
        tools: Optional[List[FunctionTool]] = None,
        config: Optional[LlmConfig] = None,
        **kwargs,
    ) -> "_ChatStream":
        """Start a streaming chat completion.

        Args:
            messages: Conversation messages.
            tools: Optional FunctionTools available for this call (converted
                to OpenAI function-calling format).
            config: Optional per-call config override. When provided, its values
                are used for sampling/model parameters and system prompt instead
                of the config passed at init time.
        """
        cfg = config or self._config
        llm_messages = self._build_messages(messages, cfg)

        llm_kwargs: Dict[str, Any] = {
            "model": self._model,
            "messages": llm_messages,
            "stream": True,
            "num_retries": cfg.num_retries,
        }

        if self._api_key:
            llm_kwargs["api_key"] = self._api_key
        if cfg.fallbacks:
            llm_kwargs["fallbacks"] = cfg.fallbacks
        if cfg.timeout:
            llm_kwargs["timeout"] = cfg.timeout

        # Add config parameters
        if cfg.temperature is not None:
            llm_kwargs["temperature"] = cfg.temperature
        if cfg.max_tokens is not None:
            llm_kwargs["max_tokens"] = cfg.max_tokens
        if cfg.top_p is not None:
            llm_kwargs["top_p"] = cfg.top_p
        if cfg.stop:
            llm_kwargs["stop"] = cfg.stop
        if cfg.seed is not None:
            llm_kwargs["seed"] = cfg.seed
        if cfg.presence_penalty is not None:
            llm_kwargs["presence_penalty"] = cfg.presence_penalty
        if cfg.frequency_penalty is not None:
            llm_kwargs["frequency_penalty"] = cfg.frequency_penalty
        if self._supports_reasoning_effort:
            llm_kwargs["reasoning_effort"] = cfg.reasoning_effort or self._default_reasoning_effort

        if cfg.extra:
            llm_kwargs.update(cfg.extra)

        if tools:
            llm_kwargs["tools"] = tools_to_litellm(tools)

        llm_kwargs.update(kwargs)

        return _ChatStream(llm_kwargs)

    def _build_messages(
        self, messages: List[Message], config: Optional[LlmConfig] = None
    ) -> List[Dict[str, Any]]:
        """Convert Message objects to LiteLLM format."""
        cfg = config or self._config
        result = []

        if cfg.system_prompt:
            result.append({"role": "system", "content": cfg.system_prompt})

        for msg in messages:
            llm_msg: Dict[str, Any] = {"role": msg.role}

            if msg.content is not None:
                llm_msg["content"] = msg.content

            if msg.tool_calls:
                # ToolCallRequest
                llm_msg["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": tc.arguments},
                        # Include thought_signature for Gemini 3+ models
                        # LiteLLM expects this in provider_specific_fields
                        **(
                            {"provider_specific_fields": {"thought_signature": tc.thought_signature}}
                            if tc.thought_signature
                            else {}
                        ),
                    }
                    for tc in msg.tool_calls
                ]

            if msg.role == "tool":
                # ToolCallResponse
                llm_msg["tool_call_id"] = msg.tool_call_id
                if msg.name:
                    llm_msg["name"] = msg.name

            result.append(llm_msg)
        return result

    async def aclose(self) -> None:
        """Close the provider (no-op for LiteLLM)."""
        pass


class _ChatStream:
    """Async context manager for streaming chat responses."""

    def __init__(self, llm_kwargs: Dict[str, Any]):
        self._kwargs = llm_kwargs
        self._response = None

    async def __aenter__(self) -> "_ChatStream":
        self._response = await acompletion(**self._kwargs)
        return self

    async def __aexit__(self, *args) -> None:
        pass

    async def __aiter__(self) -> AsyncIterator[StreamChunk]:
        if self._response is None:
            raise RuntimeError("Stream not started. Use 'async with' context manager.")

        tool_calls: Dict[int, ToolCall] = {}
        arg_states: Dict[int, _ArgState] = {}

        async for chunk in self._response:
            text = None
            if chunk.choices and chunk.choices[0].delta:
                delta = chunk.choices[0].delta
                text = getattr(delta, "content", None)

                # Handle incremental tool calls
                tc_delta = getattr(delta, "tool_calls", None)
                if tc_delta:
                    for tc in tc_delta:
                        idx = tc.index
                        if idx not in tool_calls:
                            tool_calls[idx] = ToolCall(
                                id=tc.id or "",
                                name=tc.function.name if tc.function else "",
                            )
                        else:
                            if tc.id:
                                tool_calls[idx].id = tc.id
                            if tc.function and tc.function.name:
                                tool_calls[idx].name = tc.function.name

                        if tc.function and tc.function.arguments:
                            arg_states[idx] = _feed_tool_args(arg_states.get(idx), tc.function.arguments)
                            tool_calls[idx].arguments = arg_states[idx].args

                        # Capture thought_signature for Gemini 3+ models
                        # LiteLLM stores it in provider_specific_fields
                        provider_fields = getattr(tc, "provider_specific_fields", None)
                        if provider_fields:
                            thought_sig = provider_fields.get("thought_signature")
                            if thought_sig:
                                tool_calls[idx].thought_signature = thought_sig

            # Check finish reason
            finish_reason = None
            if chunk.choices and chunk.choices[0].finish_reason:
                finish_reason = chunk.choices[0].finish_reason
                if finish_reason in ("tool_calls", "stop"):
                    for tc in tool_calls.values():
                        tc.is_complete = True

            yield StreamChunk(
                text=text,
                tool_calls=list(tool_calls.values()) if tool_calls else [],
                is_final=finish_reason is not None,
            )


class _ArgState(NamedTuple):
    """Immutable state for incremental JSON argument accumulation."""

    args: str
    depth: int
    in_string: bool
    escape_next: bool


def _feed_tool_args(state: Optional[_ArgState], fragment: str) -> _ArgState:
    """Accumulate a streamed tool-call argument fragment.

    Providers stream tool call arguments differently:
    - OpenAI/Anthropic send incremental fragments that must be concatenated.
    - Gemini sends complete args repeated each chunk that should replace.

    We distinguish these by tracking unquoted brace depth. When depth reaches 0
    the JSON object is complete; any subsequent fragment is a Gemini-style resend
    and replaces rather than concatenates.
    """
    if state is None or (state.depth == 0 and state.args):
        # First fragment, or previous args were complete (Gemini resend)
        args = fragment
        depth, in_str, esc = 0, False, False
    else:
        args = state.args + fragment
        depth, in_str, esc = state.depth, state.in_string, state.escape_next

    for ch in fragment:
        if esc:
            esc = False
            continue
        if ch == "\\" and in_str:
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if not in_str:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1

    return _ArgState(args, depth, in_str, esc)
