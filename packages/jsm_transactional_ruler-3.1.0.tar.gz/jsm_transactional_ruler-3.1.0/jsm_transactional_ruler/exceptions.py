class InvalidEventTypeError(Exception):
    pass
