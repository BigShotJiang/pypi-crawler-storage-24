# 最小化 Maven 示例项目

这是一个最简单的 Maven 项目，用于测试 IDCU CLI 的 Maven 功能。

## 项目结构

```
minimal-maven/
├── pom.xml
└── src/
    └── main/
        └── java/
            └── com/
                └── example/
                    └── HelloWorld.java
```

## 使用方法

### 1. 使用 IDCU CLI 列出 Maven 项目

```bash
idcu maven list
```

### 2. 编译项目

```bash
idcu maven compile
```

### 3. 完整构建

```bash
idcu maven build
```

### 4. 查看依赖树

```bash
idcu maven dep-tree
```

## 预期结果

- 项目应该能够成功编译
- 生成 `target/` 目录
- 生成 `.class` 文件
