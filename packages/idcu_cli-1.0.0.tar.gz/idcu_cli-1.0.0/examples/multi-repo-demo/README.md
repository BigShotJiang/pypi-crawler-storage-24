# 多仓库演示项目

本项目用于演示 IDCU CLI 的多仓库 Git 操作功能。

## 项目结构

此项目包含多个 Git 仓库（可以是真实仓库或模拟仓库），用于测试：
- 多仓库状态查看
- 批量提交
- 批量推送/拉取
- 分支切换

## 使用方法

### 1. 列出所有 Git 仓库

```bash
idcu git list
```

### 2. 查看所有仓库状态

```bash
idcu git status
```

### 3. 批量提交更改

```bash
idcu git commit -m "feat: update all modules" -a
```

### 4. 批量推送

```bash
idcu git push
```

## 注意事项

- 此示例需要实际的 Git 仓库才能正常工作
- 你可以将自己的多个仓库放在此目录下进行测试
