# IDCU CLI 示例工程

本目录包含 IDCU CLI 的示例项目，用于演示和测试各种功能。

## 示例项目列表

### 1. minimal-maven
最小化的 Maven 项目，用于测试 Maven 相关功能。

### 2. simple-python
简单的 Python 项目，用于测试跨语言构建功能。

### 3. multi-repo-demo
多仓库演示项目（Git 子模块），用于测试 Git 批量操作。

### 4. plugin-demo
插件开发演示，展示如何创建和使用自定义插件。

## 使用方法

### 运行示例

1. 进入特定示例目录
2. 按照该目录的 README 说明操作
3. 使用 IDCU CLI 命令进行操作

### 快速测试

```bash
# 测试 Maven 功能
cd examples/minimal-maven
idcu maven list
idcu maven build

# 测试 Git 功能
cd examples/multi-repo-demo
idcu git list
idcu git status
```

## 注意事项

- 某些示例需要额外的工具（如 Git、Maven、Node.js 等）
- 请确保已安装 IDCU CLI
- 示例项目仅用于演示和测试目的
