import pytest
from example.main import hello


def test_hello_default():
    assert hello() == "Hello, World!"


def test_hello_custom():
    assert hello("IDCU") == "Hello, IDCU!"
