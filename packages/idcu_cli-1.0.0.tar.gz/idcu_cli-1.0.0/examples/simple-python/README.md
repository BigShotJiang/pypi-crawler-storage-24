# 简单 Python 示例项目

这是一个简单的 Python 项目，用于测试 IDCU CLI 的跨语言构建功能。

## 项目结构

```
simple-python/
├── setup.py
├── pyproject.toml
├── src/
│   └── example/
│       ├── __init__.py
│       └── main.py
└── tests/
    └── test_example.py
```

## 使用方法

### 1. 检测项目类型

```bash
idcu build detect -p .
```

### 2. 构建项目

```bash
idcu build build -p .
```

## 预期结果

- 项目应该被正确识别为 Python 项目
- 可以执行 Python 相关的构建操作
