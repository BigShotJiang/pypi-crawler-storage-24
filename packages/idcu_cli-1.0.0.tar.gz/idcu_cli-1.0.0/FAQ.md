# IDCU CLI - 不羁盟命令行工具常见问题解答

## 安装与配置
### Q: 如何安装 IDCU CLI？
A: 您可以通过以下方式安装 IDCU CLI：
```bash
# 从源码安装（推荐开发人员）
git clone https://gitee.com/idcu/cli.git
cd cli
pip install -e .

# 或从 PyPI 安装（推荐用户）
pip install idcu-cli
```

### Q: IDCU 支持哪些 Python 版本？
A: IDCU 支持 Python 3.8 及更高版本，包括：
- Python 3.8
- Python 3.9
- Python 3.10
- Python 3.11
- Python 3.12
- Python 3.13
- Python 3.14

### Q: 如何查看和修改配置？

A: 配置文件存储在用户目录下的 `.idcu/config.yaml`，您可以使用 IDCU 命令来查看和修改配置：
```bash
idcu config show
```

### Q: 如何重置配置？
A: 您可以手动删除配置文件或使用以下命令：
```bash
idcu config reload
```

## Git 操作

### Q: 如何列出当前目录下的 Git 仓库？
A: IDCU 会自动检测当前目录及子目录中的 Git 仓库，您可以使用：
```bash
# 查看当前目录下所有 Git 仓库的状态
idcu git status

# 仅提交当前目录下的 Git 仓库
idcu git commit -m "提交信息" -a
```

### Q: 如何只对特定项目执行操作？
A: 使用 `-p` 或 `--projects` 参数指定项目：
```bash
# 仅对 project1 和 project2 执行 status
idcu git status -p project1 project2

# 仅对 project1 执行 commit
idcu git commit -m "提交信息" -a -p project1
```

### Q: Git 操作遇到问题怎么办？

A: 请按以下步骤排查：

1. **确保 Git 已安装**
   - 检查 Git 是否在 PATH 中
   - 使用 `git --version` 确认

2. **检查仓库权限**
   - 确保对仓库有读写权限
   - 如果是 root 用户检查权限

3. **检查网络连接**
   - 检查网络连接
   - 确保可以访问远程仓库

### Q: 如何使用 IDCU 的高级 Git 功能？
A: IDCU 提供了完整的 Git 高级功能：
```bash
# 变基操作
idcu git rebase -u origin/main

# 拣选提交
idcu git cherry-pick <commit-hash>

# 重置操作
idcu git reset --hard HEAD~1

# 查看统计信息
idcu git diff --stat

# 清理未跟踪文件
idcu git clean -fd

# 标签管理
idcu git tag -l
idcu git tag v1.0.0 -m "Release 1.0.0"

# 查看文件修改历史
idcu git blame <file-path>

# 二分查找 bug
idcu git bisect start
```

## Maven 操作

### Q: 如何使用 IDCU 的 Maven 高级功能？
A: IDCU 提供了完整的 Maven 高级功能：
```bash
# 查看依赖树
idcu maven dep-tree

# 列出所有依赖
idcu maven dep-list

# 分析依赖，找出未使用的
idcu maven dep-analyze

# 检查依赖冲突
idcu maven dep-conflict

# 显示有效 POM
idcu maven effective-pom
```

### Q: 如何使用 Maven Profiles？
A: 使用 profile 相关命令：
```bash
# 列出当前项目可用的 Profile
idcu maven profile-list

# 设置 Profile
idcu maven profile-set dev

# 清除 Profile，使用默认
idcu maven profile-set
```

### Q: 如何加速 Maven 构建？
A: 使用以下命令：
```bash
# 使用所有 CPU 核心
idcu maven parallel -t 1C

# 使用指定线程数
idcu maven parallel -t 4

# 跳过测试
idcu maven parallel --skip-tests

# 显示构建时间线
idcu maven timeline
```

### Q: 如何清理 Maven 本地仓库？
A: 使用 clean-local 命令：
```bash
# 清理本地仓库
idcu maven clean-local
```

## 插件和工具

### Q: 如何安装命令补全？
A: IDCU 支持 Bash、Zsh 和 PowerShell 的命令补全：

**Bash:**
```bash
# 生成 Bash 补全并安装
idcu completions bash -o ~/.idcu-completions.bash

# 添加到 ~/.bashrc
source ~/.idcu-completions.bash

# 重新加载配置
source ~/.bashrc
```

**Zsh:**
```bash
# 生成 Zsh 补全并安装
idcu completions zsh -o ~/.zsh/_idcu

# 添加到 ~/.zshrc 并更新 fpath
fpath=(~/.zsh $fpath)

# 添加到 ~/.zshrc
fpath=(~/.zsh $fpath)

# 重新加载配置
source ~/.zshrc
```

**PowerShell:**
```powershell
# 生成 PowerShell 补全并安装
idcu completions powershell -o idcu-completions.ps1

# 添加到 PowerShell 配置文件
. idcu-completions.ps1

# 重新加载配置
. $PROFILE
```

### Q: 如何使用命令别名？
A: IDCU 支持灵活的命令别名功能：

```bash
# 列出当前所有别名
idcu alias list

# 设置别名
idcu alias set gs "git status"
idcu alias set gc "git commit -m"
idcu alias set mb "maven build"

# 使用别名（示例）
# idcu gs

# 删除别名
idcu alias delete gs
```

### Q: 如何使用进度条？

A: 进度条是 IDCU 内置的一个便捷功能，您可以在自己的代码中使用：

```python
from idcu.core import ProgressBar

with ProgressBar(total=100, prefix="处理中") as bar:
    for i in range(100):
        # 您的代码
        bar.update(increment=1)
```

## 插件开发

### Q: 如何找到示例插件？
A: 您可以在 `idcu/devtools/plugins/examples/` 目录下找到示例插件：
1. `hello_plugin.py` - 简单的 Hello World 示例
2. `git_plugin.py` - Git 操作插件
3. `file_utils_plugin.py` - 文件处理工具
4. `system_info_plugin.py` - 系统信息工具
5. `release_plugin.py` - 项目发布工具

插件开发非常简单：
```python
from idcu.tools.plugins import Plugin, PluginMetadata

class MyPlugin(Plugin):
    metadata = PluginMetadata(
        name="my_plugin",
        version="1.0.0",
        description="我的插件",
        author="Your Name",
    )

    def initialize(self):
        # 插件初始化
        pass

    def cleanup(self):
        # 插件清理
        pass
```

### Q: 如何注册插件命令？
A: 使用 `@register_command` 装饰器：

```python
from idcu.tools.plugins import register_command

@register_command("mycommand")
def my_command(arg1, arg2):
    """
    我的命令的说明文档
    """
    # 命令实现
    return {"success": True, "message": "命令执行成功"}
```

## 常见错误

### Q: 遇到 "command not found: idcu"

A: 这通常意味着 IDCU 没有正确安装或不在 PATH 中：

1. 检查安装：`pip show idcu`
2. 重新安装：`pip install -e .`
3. 确保 Python 的 Scripts 目录在 PATH 中

### Q: YAML 解析错误

A: 这通常是因为您没有安装 yaml 库，安装 PyYAML：
```bash
pip install PyYAML
```

### Q: 编码检测错误

A: IDCU 内置了编码检测和修复功能，您可以：
```bash
# 使用编码检测插件查看配置
idcu plugin cmd encoding.scan

# 使用编码修复插件查看配置
idcu plugin cmd encoding.fix
```

## 社区支持

### Q: 发现 bug 或需要新功能怎么办？

A: 请在以下仓库创建 Issue：
- Gitee: https://gitee.com/idcu/cli/issues

请在报告 bug 时提供：
- IDCU 版本
- Python 版本
- 操作系统信息
- 错误的完整堆栈跟踪
- 复现步骤

### Q: 如何贡献代码？
A: 请查看 [贡献指南](CONTRIBUTING.md)，您可以：
1. Fork 本仓库
2. 创建 feature 分支
3. 提交更改
4. 推送到分支
5. 创建 Pull Request

### Q: IDCU 的未来发展计划是什么？

A: 您可以查看 [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md) 了解我们的计划，
目前的计划包括：
- 更多云服务集成
- 多仓库项目管理插件
- CI/CD 增强
- Web UI

未来可能的计划：
- AI 助手增强
- 更多语言支持
- 与其他工具集成（如 npm、pip、cargo 等）

## 联系方式

- 项目仓库: https://gitee.com/idcu/cli
- 联系邮箱: idcu@qq.com
