# 贡献指南

感谢您有兴趣为 IDCU CLI (不羁盟命令行工具) 项目贡献代码！

## 目录

- [行为准则](#行为准则)
- [我们接受的贡献](#我们接受的贡献)
- [开发环境设置](#开发环境设置)
- [代码风格](#代码风格)
- [提交信息规范](#提交信息规范)
- [测试指南](#测试指南)
- [Pull Request 流程](#pull-request-流程)
- [文档贡献](#文档贡献)
- [获取帮助](#获取帮助)

***

## 行为准则

### 我们的承诺

为了营造开放和友好的环境，我们承诺：

- 尊重不同的观点和经验
- 优雅地接受建设性批评
- 关注对社区最有利的事情
- 对其他社区成员表示同理心

### 不可接受的行为

- 使用性化的语言或图像
- 恶意评论或人身攻击
- 公开或私下骚扰
- 未经许可发布他人的私人信息
- 其他不专业或不恰当的行为

***

## 我们接受的贡献

有很多方式可以为这个项目做出贡献：

1. **报告 Bug** - 在 Gitee 上创建 Issues
2. **提出功能建议** - 在 Issues 中讨论新功能
3. **改进文档** - 修复拼写错误、添加示例、改进说明
4. **贡献代码** - 修复 Bug、实现新功能、优化性能
5. **审查代码** - 审查 Pull Requests
6. **回答问题** - 在 Issues 和讨论中帮助他人

***

## 开发环境设置

### 前置要求

- Python 3.8 或更高版本
- Git
- pip

### 克隆仓库

```bash
git clone https://gitee.com/your-username/cli.git
cd cli
```

### 创建虚拟环境

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### 安装开发依赖

```bash
pip install -e ".[dev]"
```

### 安装 pre-commit hooks

```bash
pre-commit install
```

### 运行测试

```bash
pytest tests/
```

***

## 代码风格

### Python 代码风格

我们遵循 [PEP 8](https://peps.python.org/pep-0008/) 代码风格指南，请确保代码符合规范。

- **代码格式化**: ruff format
- **导入排序**: ruff isort
- **代码 linting**: ruff
- **类型检查**: mypy

### 运行代码检查

```bash
# 格式化代码
ruff format idcu/ tests/

# 排序导入
ruff check idcu/ tests/ --select I --fix

# 运行 lint
ruff check idcu/ tests/

# 类型检查
mypy idcu/
```

也可以使用 pre-commit 运行所有检查：

```bash
pre-commit run --all-files
```

### 文档字符串风格

我们使用 Google 风格的文档字符串：

```python
def function_name(param1: int, param2: str) -&gt; bool:
    """简短的一行描述。

    更详细的描述，可以跨多行。
    解释函数的作用、参数的含义、返回值的意义等。

    Args:
        param1: 第一个参数的描述
        param2: 第二个参数的描述

    Returns:
        布尔值表示操作是否成功

    Raises:
        ValueError: 当参数不符合预期时

    Examples:
        &gt;&gt;&gt; function_name(42, "test")
        True
    """
    pass
```

***

## 提交信息规范

我们使用 [Conventional Commits](https://www.conventionalcommits.org/) 规范：

```
&lt;type&gt;(&lt;scope&gt;): &lt;subject&gt;

&lt;body&gt;

&lt;footer&gt;
```

### Type 类型

- `feat`: 新功能
- `fix`: 修复 bug
- `docs`: 文档变更
- `style`: 代码格式调整（不影响代码运行）
- `refactor`: 重构（既不修复 bug 也不添加新功能）
- `perf`: 性能优化
- `test`: 测试相关
- `chore`: 构建过程或辅助工具的变动

### 示例

```
feat(git): 添加多仓库提交功能

- 支持 multi-commit 操作
- 优化批量操作性能
- 添加相关测试

Closes #123
```

***

## 测试指南

### 运行测试

```bash
# 运行所有测试
pytest

# 运行特定测试文件
pytest tests/test_git.py

# 运行特定测试函数
pytest tests/test_git.py::test_git_clone

# 详细输出
pytest -v

# 生成覆盖率报告
pytest --cov=idcu --cov-report=html
```

### 编写测试

1. 测试文件放在 `tests/` 目录下
2. 测试文件以 `test_` 开头
3. 测试函数以 `test_` 开头
4. 使用 `pytest` 框架
5. 确保测试覆盖主要功能和边界情况

### 测试示例

```python
import pytest
from idcu.tools.git.git_single import GitSingleRepo

def test_git_status(tmp_path):
    repo = GitSingleRepo(str(tmp_path))
    repo.init()

    status = repo.status()
    assert status is not None
```

***

## Pull Request 流程

### 创建 PR

1. 确保您的代码通过所有测试
2. 更新相关文档
3. 遵循代码风格规范
4. 使用规范的提交信息

### 提交 PR

1. Fork 并克隆您的仓库
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启一个 Pull Request

### PR 审查标准

1. 代码通过所有自动化测试
2. 遵循代码风格指南
3. 有充分的测试覆盖
4. 文档已相应更新
5. 提交信息符合规范

### 审查 PR

1. 提供建设性的反馈
2. 关注代码质量和可维护性
3. 确认测试覆盖充分
4. 认可后批准合并

***

## 文档贡献

### 文档结构

- `README.md`: 项目主页面
- `docs/`: API 文档和参考
- `EXAMPLES.md`: 使用示例
- `FAQ.md`: 常见问题
- `TUTORIAL.md`: 教程

### 文档规范

- 使用 Markdown 格式
- 保持简洁明了
- 提供充分的示例
- 遵循代码风格规范
- 检查拼写和语法错误

### 更新文档流程

1. 找到需要更新的文档
2. 进行修改
3. 预览更改
4. 提交 Pull Request

***

## 获取帮助

如果您在贡献过程中遇到任何问题：

- 查看 [文档](README.md)
- 查看 [教程](TUTORIAL.md)
- 在 Issues 中提问
- 联系维护者

***

## 版本发布

查看 [发布指南](RELEASE.md) 了解如何发布新版本。

***

## 许可证

通过贡献代码，您同意您的贡献将根据项目的 LICENSE 文件进行许可。

***

感谢您为 IDCU CLI (不羁盟命令行工具) 项目做出的贡献！
