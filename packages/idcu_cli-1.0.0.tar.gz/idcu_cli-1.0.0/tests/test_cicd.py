
import tempfile
from pathlib import Path

import pytest

from idcu.tools.cicd import github_actions


def test_github_actions_generator_ci_workflow():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        generator = github_actions.GitHubActionsGenerator(project_root=tmp_path)
        path = generator.generate_ci_workflow()
        assert path.exists()


def test_github_actions_generator_publish_workflow():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        generator = github_actions.GitHubActionsGenerator(project_root=tmp_path)
        path = generator.generate_publish_workflow()
        assert path.exists()


def test_github_actions_generator_docker_workflow():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        generator = github_actions.GitHubActionsGenerator(project_root=tmp_path)
        path = generator.generate_docker_workflow(image_name="test/image")
        assert path.exists()

