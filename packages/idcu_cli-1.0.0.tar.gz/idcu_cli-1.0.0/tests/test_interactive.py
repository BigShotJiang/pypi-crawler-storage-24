
import unittest
from unittest.mock import patch, MagicMock
import sys
from io import StringIO
import os


class TestInteractiveCLI(unittest.TestCase):
    def setUp(self):
        self.original_stdout = sys.stdout
        sys.stdout = StringIO()
        
    def tearDown(self):
        sys.stdout = self.original_stdout
    
    def test_import_interactive(self):
        try:
            from idcu.cli.interactive import InteractiveCLI, IDCUCommandCompleter
            self.assertTrue(True)
        except ImportError as e:
            self.fail(f"Failed to import interactive module: {e}")
    
    def test_completer_initialization(self):
        try:
            from idcu.cli.interactive import IDCUCommandCompleter
            completer = IDCUCommandCompleter()
            self.assertIsNotNone(completer.commands)
            self.assertIsNotNone(completer.subcommands)
            self.assertIn("git", completer.commands)
            self.assertIn("maven", completer.commands)
            self.assertIn("quality", completer.commands)
            self.assertIn("template", completer.commands)
        except Exception as e:
            self.fail(f"Failed to initialize completer: {e}")
    
    def test_interactive_cli_initialization(self):
        try:
            from idcu.cli.interactive import InteractiveCLI
            with patch('idcu.cli.interactive.HAS_PROMPT_TOOLKIT', False):
                cli = InteractiveCLI()
                self.assertFalse(cli.running)
                self.assertEqual(cli.current_menu, "main")
                self.assertEqual(len(cli.menu_stack), 0)
                self.assertIsNotNone(cli.command_categories)
                self.assertIn(0, cli.command_categories)
                self.assertIn(12, cli.command_categories)
                self.assertIn(13, cli.command_categories)
        except Exception as e:
            self.fail(f"Failed to initialize InteractiveCLI: {e}")
    
    def test_command_categories_complete(self):
        from idcu.cli.interactive import InteractiveCLI
        with patch('idcu.cli.interactive.HAS_PROMPT_TOOLKIT', False):
            cli = InteractiveCLI()
            expected_categories = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
            for category in expected_categories:
                self.assertIn(category, cli.command_categories)
    
    def test_quality_menu_has_tck(self):
        from idcu.cli.interactive import InteractiveCLI
        with patch('idcu.cli.interactive.HAS_PROMPT_TOOLKIT', False):
            cli = InteractiveCLI()
            quality_category = cli.command_categories.get(12)
            self.assertIsNotNone(quality_category)
            self.assertEqual(quality_category["name"], "质量检查")
    
    def test_template_menu_exists(self):
        from idcu.cli.interactive import InteractiveCLI
        with patch('idcu.cli.interactive.HAS_PROMPT_TOOLKIT', False):
            cli = InteractiveCLI()
            template_category = cli.command_categories.get(13)
            self.assertIsNotNone(template_category)
            self.assertEqual(template_category["name"], "项目模板")
    
    def test_parse_command(self):
        from idcu.cli.interactive import InteractiveCLI
        with patch('idcu.cli.interactive.HAS_PROMPT_TOOLKIT', False):
            cli = InteractiveCLI()
            
            test_cases = [
                ("git status", ["git", "status"]),
                ("idcu maven build", ["maven", "build"]),
                ("quality encoding check", ["quality", "encoding", "check"]),
            ]
            
            for input_cmd, expected in test_cases:
                result = cli._parse_command(input_cmd)
                self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()

