
import os
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from idcu.tools.plugins.examples.release_plugin import ReleasePlugin
from idcu.tools.git.git_ops import run_git_checked
from tests.e2e.conftest import E2ETestContext, run_command


def create_release_test_project(path):
    """Create a project for release testing"""
    project_path = path / "release-test-project"
    project_path.mkdir(parents=True, exist_ok=True)

    pom_xml_content = []
    pom_xml_content.append('<?xml version="1.0" encoding="UTF-8"?>')
    pom_xml_content.append('<project xmlns="http://maven.apache.org/POM/4.0.0"')
    pom_xml_content.append('         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"')
    pom_xml_content.append('         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">')
    pom_xml_content.append('    <modelVersion>4.0.0</modelVersion>')
    pom_xml_content.append('')
    pom_xml_content.append('    <groupId>com.example</groupId>')
    pom_xml_content.append('    <artifactId>release-test</artifactId>')
    pom_xml_content.append('    <version>1.0.0-SNAPSHOT</version>')
    pom_xml_content.append('    <packaging>jar</packaging>')
    pom_xml_content.append('')
    pom_xml_content.append('    <name>Release Test Project</name>')
    pom_xml_content.append('    <description>Project for testing release workflow</description>')
    pom_xml_content.append('')
    pom_xml_content.append('    <properties>')
    pom_xml_content.append('        <maven.compiler.source>11</maven.compiler.source>')
    pom_xml_content.append('        <maven.compiler.target>11</maven.compiler.target>')
    pom_xml_content.append('        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>')
    pom_xml_content.append('    </properties>')
    pom_xml_content.append('')
    pom_xml_content.append('</project>')

    (project_path / "pom.xml").write_text("\n".join(pom_xml_content), encoding="utf-8")

    src_dir = project_path / "src" / "main" / "java" / "com" / "example"
    src_dir.mkdir(parents=True, exist_ok=True)

    java_source = []
    java_source.append("package com.example;")
    java_source.append("")
    java_source.append("public class ReleaseTest {")
    java_source.append("    public static void main(String[] args) {")
    java_source.append('        System.out.println("Release test project");')
    java_source.append("    }")
    java_source.append("}")

    (src_dir / "ReleaseTest.java").write_text("\n".join(java_source), encoding="utf-8")

    run_command(["git", "init"], cwd=project_path)
    run_command(["git", "config", "user.name", "Test User"], cwd=project_path)
    run_command(["git", "config", "user.email", "test@example.com"], cwd=project_path)
    run_command(["git", "add", "-A"], cwd=project_path)
    run_command(["git", "commit", "-m", "Initial commit"], cwd=project_path)

    return project_path


class TestReleaseWorkflow:
    """Test release dry-run full workflow E2E"""

    def test_release_plugin_initialization(self, e2e_context):
        """Test release plugin initialization"""
        plugin = ReleasePlugin()
        assert plugin is not None
        assert plugin.metadata.name == "release"
        assert plugin.metadata.version == "1.0.0-SNAPSHOT"

        commands = plugin.get_commands()
        assert "release.create_branch" in commands
        assert "release.update_version" in commands
        assert "release.build" in commands
        assert "release.deploy" in commands
        assert "release.tag" in commands
        assert "release.full" in commands
        assert "release.config" in commands

    def test_release_config_command(self, e2e_context):
        """Test release config command"""
        plugin = ReleasePlugin()
        plugin.project_path = e2e_context.tmp_dir

        result = plugin.cmd_show_config()
        assert result["success"] is True
        assert "config" in result
        assert "branch_pattern" in result["config"]
        assert "tag_pattern" in result["config"]

    def test_create_release_branch(self, e2e_context):
        """Test creating release branch"""
        project_path = create_release_test_project(e2e_context.tmp_dir)

        plugin = ReleasePlugin()
        plugin.project_path = project_path

        result = plugin.cmd_create_release_branch(
            version="1.0.0",
            repo_path=str(project_path),
            branch_pattern="release/{version}"
        )

        assert result["success"] is True
        assert result["branch"] == "release/1.0.0"

    def test_update_version(self, e2e_context):
        """Test updating version number"""
        project_path = create_release_test_project(e2e_context.tmp_dir)

        plugin = ReleasePlugin()
        plugin.project_path = project_path

        result = plugin.cmd_update_version(
            old_version="1.0.0-SNAPSHOT",
            new_version="1.0.0",
            repo_path=str(project_path),
            build_tool="maven"
        )

        assert result["success"] is True
        assert result["old_version"] == "1.0.0-SNAPSHOT"
        assert result["new_version"] == "1.0.0"
        updated_list = result["updated"]
        assert isinstance(updated_list, list)
        count = len(updated_list)
        assert count != 0

        updated_pom_content = (project_path / "pom.xml").read_text(encoding="utf-8")
        version_100_found = False
        version_snapshot_found = False
        for line in updated_pom_content.splitlines():
            if "1.0.0" in line and "SNAPSHOT" not in line:
                version_100_found = True
            if "1.0.0-SNAPSHOT" in line:
                version_snapshot_found = True
        assert version_100_found is True
        assert version_snapshot_found is False

    @patch("idcu.tools.plugins.examples.release_plugin.run_maven_checked")
    def test_build_command(self, mock_run_maven, e2e_context):
        """Test build command"""
        project_path = create_release_test_project(e2e_context.tmp_dir)

        mock_run_maven.return_value = (True, "Build successful", "")

        plugin = ReleasePlugin()
        plugin.project_path = project_path

        result = plugin.cmd_build(
            repo_path=str(project_path),
            skip_tests=True,
            profile="release",
            build_tool="maven"
        )

        assert result["success"] is True
        assert result["build_tool"] == "maven"

    @patch("idcu.tools.plugins.examples.release_plugin.run_maven_checked")
    @patch("idcu.tools.plugins.examples.release_plugin.run_git_checked")
    def test_release_dry_run_workflow(self, mock_run_git, mock_run_maven, e2e_context):
        """Test full release dry-run workflow"""
        project_path = create_release_test_project(e2e_context.tmp_dir)

        mock_run_maven.side_effect = [
            (True, "Build successful", ""),
            (True, "Deploy skipped (dry run)", ""),
        ]

        mock_run_git.side_effect = [
            (True, "Switched to new branch 'release/1.0.0'", ""),
            (True, "Tag v1.0.0 created", ""),
            (True, "Tag pushed", ""),
        ]

        plugin = ReleasePlugin()
        plugin.project_path = project_path

        create_result = plugin.cmd_create_release_branch(
            version="1.0.0",
            repo_path=str(project_path)
        )
        assert create_result["success"] is True

        update_result = plugin.cmd_update_version(
            old_version="1.0.0-SNAPSHOT",
            new_version="1.0.0",
            repo_path=str(project_path)
        )
        assert update_result["success"] is True

        build_result = plugin.cmd_build(
            repo_path=str(project_path),
            skip_tests=True
        )
        assert build_result["success"] is True

        config_result = plugin.cmd_show_config()
        assert config_result["success"] is True

    def test_release_branch_pattern_config(self, e2e_context):
        """Test release branch pattern configuration"""
        project_path = create_release_test_project(e2e_context.tmp_dir)

        plugin = ReleasePlugin()
        plugin.project_path = project_path

        config_dir = project_path / ".idcu"
        config_dir.mkdir(exist_ok=True)
        config_file = config_dir / "config.yaml"
        config_content = []
        config_content.append("release:")
        config_content.append('  branch_pattern: "custom-release/{version}"')
        config_content.append('  tag_pattern: "custom-v{version}"')
        config_content.append('  tag_message_pattern: "Custom release {version}"')
        config_file.write_text("\n".join(config_content), encoding="utf-8")

        branch_pattern = plugin._get_branch_pattern()
        assert branch_pattern == "custom-release/{version}"

        tag_pattern = plugin._get_tag_pattern()
        assert tag_pattern == "custom-v{version}"

        tag_message_pattern = plugin._get_tag_message_pattern()
        assert tag_message_pattern == "Custom release {version}"

    def test_hooks(self, e2e_context):
        """Test release plugin hooks"""
        plugin = ReleasePlugin()

        hooks = plugin.get_hooks()
        assert "before_release" in hooks
        assert "after_release" in hooks

        before_hook = hooks["before_release"]
        before_hook("1.0.0")

        after_hook = hooks["after_release"]
        after_hook("1.0.0", {"success": True})
