
import os
import shutil
from pathlib import Path

import pytest

from idcu.tools.plugins.base import Plugin, PluginMetadata, register_plugin, PluginManager, get_plugin_manager, reset_plugin_manager
from tests.e2e.conftest import E2ETestContext


TEST_PLUGIN_1 = """from idcu.tools.plugins.base import Plugin, PluginMetadata, register_plugin


class TestPlugin1(Plugin):
    metadata = PluginMetadata(
        name="test_plugin_1",
        version="1.0.0",
        description="Test plugin 1",
        author="Test Author",
    )

    def __init__(self):
        self.counter = 0
        self.initialized = False
        self.cleaned_up = False

    def initialize(self):
        self.counter += 1
        self.initialized = True

    def cleanup(self):
        self.cleaned_up = True

    def get_commands(self):
        return {
            "test.greet": self.cmd_greet,
            "test.increment": self.cmd_increment,
        }

    def cmd_greet(self, name="World"):
        return {"greeting": "Hello, {}!".format(name)}

    def cmd_increment(self):
        self.counter += 1
        return {"counter": self.counter}


register_plugin(TestPlugin1())
"""

TEST_PLUGIN_2 = """from idcu.tools.plugins.base import Plugin, PluginMetadata, register_plugin


class TestPlugin2(Plugin):
    metadata = PluginMetadata(
        name="test_plugin_2",
        version="2.0.0",
        description="Test plugin 2",
        author="Test Author",
    )

    def __init__(self):
        self.data = []

    def initialize(self):
        self.data.append("initialized")

    def get_commands(self):
        return {
            "test.add_data": self.cmd_add_data,
            "test.get_data": self.cmd_get_data,
        }

    def cmd_add_data(self, item):
        self.data.append(item)
        return {"added": item, "total": len(self.data)}

    def cmd_get_data(self):
        return {"data": self.data}


register_plugin(TestPlugin2())
"""


class TestPluginsWorkflow:
    """Test plugins from directory loading to command execution E2E"""

    def teardown_method(self):
        """Reset plugin manager after each test"""
        reset_plugin_manager()

    def test_plugin_manager_registration(self):
        """Test plugin manager registration and retrieval"""
        manager = PluginManager()

        class SimpleTestPlugin(Plugin):
            metadata = PluginMetadata(
                name="simple_test",
                version="0.1.0",
                description="Simple test plugin",
            )

            def initialize(self):
                pass

            def get_commands(self):
                return {"simple.test": lambda: {"result": "success"}}

        plugin = SimpleTestPlugin()
        manager.register(plugin)

        assert manager.has("simple_test")
        assert manager.get("simple_test") is plugin

        metadata_list = manager.list_all()
        assert len(metadata_list) == 1
        assert metadata_list[0].name == "simple_test"
        assert metadata_list[0].version == "0.1.0"

    def test_plugin_command_execution(self):
        """Test plugin command execution"""
        manager = PluginManager()

        class CommandTestPlugin(Plugin):
            metadata = PluginMetadata(
                name="command_test",
                version="0.1.0",
                description="Command test plugin",
            )

            def __init__(self):
                self.call_count = 0

            def initialize(self):
                pass

            def get_commands(self):
                return {
                    "command.echo": self.cmd_echo,
                    "command.count": self.cmd_count,
                }

            def cmd_echo(self, message):
                return {"echo": message}

            def cmd_count(self):
                self.call_count += 1
                return {"count": self.call_count}

        plugin = CommandTestPlugin()
        manager.register(plugin)
        manager.initialize_all()

        cmd_echo = manager.get_command("command.echo")
        assert cmd_echo is not None
        result = cmd_echo("Hello Test")
        assert result == {"echo": "Hello Test"}

        cmd_count = manager.get_command("command.count")
        assert cmd_count is not None
        result = cmd_count()
        assert result == {"count": 1}
        result = cmd_count()
        assert result == {"count": 2}

        commands = manager.list_commands()
        assert "command.echo" in commands
        assert "command.count" in commands

    def test_load_plugins_from_directory(self, e2e_context):
        """Test loading plugins from directory"""
        reset_plugin_manager()

        plugins_dir = e2e_context.tmp_dir / "plugins"
        plugins_dir.mkdir()

        (plugins_dir / "test_plugin_1.py").write_text(TEST_PLUGIN_1, encoding="utf-8")
        (plugins_dir / "test_plugin_2.py").write_text(TEST_PLUGIN_2, encoding="utf-8")

        manager = PluginManager()
        manager.load_from_directory(plugins_dir)

        assert manager.has("test_plugin_1")
        assert manager.has("test_plugin_2")

        manager.initialize_all()

        cmd_greet = manager.get_command("test.greet")
        assert cmd_greet is not None
        result = cmd_greet("Plugin Tester")
        assert result == {"greeting": "Hello, Plugin Tester!"}

        cmd_add_data = manager.get_command("test.add_data")
        assert cmd_add_data is not None
        result = cmd_add_data("item1")
        assert result["added"] == "item1"
        assert result["total"] == 2

        metadata_list = manager.list_all()
        assert len(metadata_list) == 2
        plugin_names = {meta.name for meta in metadata_list}
        assert "test_plugin_1" in plugin_names
        assert "test_plugin_2" in plugin_names

    def test_plugin_hooks(self):
        """Test plugin hook mechanism"""
        manager = PluginManager()

        hook_results = []

        class HookTestPlugin(Plugin):
            metadata = PluginMetadata(
                name="hook_test",
                version="0.1.0",
                description="Hook test plugin",
            )

            def initialize(self):
                pass

            def get_hooks(self):
                return {
                    "before_action": self.hook_before,
                    "after_action": self.hook_after,
                }

            def hook_before(self, *args, **kwargs):
                hook_results.append(("before", args, kwargs))
                return "before_result"

            def hook_after(self, *args, **kwargs):
                hook_results.append(("after", args, kwargs))
                return "after_result"

        plugin = HookTestPlugin()
        manager.register(plugin)
        manager.initialize_all()

        results = manager.trigger_hook("before_action", "arg1", "arg2", key1="value1")
        assert len(results) == 1
        assert results[0] == "before_result"

        results = manager.trigger_hook("after_action", "post_arg", key2="value2")
        assert len(results) == 1
        assert results[0] == "after_result"

        assert len(hook_results) == 2
        assert hook_results[0] == ("before", ("arg1", "arg2"), {"key1": "value1"})
        assert hook_results[1] == ("after", ("post_arg",), {"key2": "value2"})

    def test_plugin_lifecycle(self):
        """Test plugin lifecycle management"""
        manager = PluginManager()

        class LifecycleTestPlugin(Plugin):
            metadata = PluginMetadata(
                name="lifecycle_test",
                version="0.1.0",
                description="Lifecycle test plugin",
            )

            def __init__(self):
                self.state = "created"

            def initialize(self):
                self.state = "initialized"

            def cleanup(self):
                self.state = "cleaned_up"

        plugin = LifecycleTestPlugin()
        manager.register(plugin)

        assert plugin.state == "created"

        manager.initialize_all()
        assert plugin.state == "initialized"

        manager.cleanup_all()
        assert plugin.state == "cleaned_up"

