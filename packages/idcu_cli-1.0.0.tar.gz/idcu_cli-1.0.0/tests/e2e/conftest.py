
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


TMP_ROOT = Path(__file__).resolve().parent.parent / "tmp_e2e_workspace"
TMP_ROOT.mkdir(parents=True, exist_ok=True)

os.environ["TMP"] = str(TMP_ROOT)
os.environ["TEMP"] = str(TMP_ROOT)
tempfile.tempdir = str(TMP_ROOT)


class E2ETestContext:
    """E2E test context manager for managing temp directories and environment variables"""

    def __init__(self, name):
        self.name = name
        self.tmp_dir = None
        self.original_cwd = None
        self.env_vars = {}

    def __enter__(self):
        safe_name = self.name.replace(" ", "_").replace("/", "_")
        self.tmp_dir = TMP_ROOT / f"e2e_{safe_name}"
        self.tmp_dir.mkdir(parents=True, exist_ok=True)
        self.original_cwd = Path.cwd()
        os.chdir(str(self.tmp_dir))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.original_cwd:
            os.chdir(str(self.original_cwd))
        if self.tmp_dir and self.tmp_dir.exists():
            shutil.rmtree(self.tmp_dir, ignore_errors=True)
        self.restore_env()
        return False

    def set_env(self, key, value):
        if key not in self.env_vars:
            self.env_vars[key] = os.environ.get(key)
        os.environ[key] = value

    def restore_env(self):
        for key, value in self.env_vars.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def run_command(cmd, cwd=None, env=None, timeout=300):
    """Run command and handle encoding issues"""
    if cwd is None:
        cwd = Path.cwd()

    full_env = dict(os.environ)
    if env:
        full_env.update(env)

    try:
        import shlex
        if isinstance(cmd, str):
            cmd = shlex.split(cmd)
        
        result = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=full_env,
            capture_output=True,
            timeout=timeout,
            text=False,
            shell=os.name == 'nt' and cmd[0].endswith(('.cmd', '.bat'))
        )

        stdout = _smart_decode(result.stdout)
        stderr = _smart_decode(result.stderr)

        return result.returncode, stdout, stderr
    except subprocess.TimeoutExpired:
        return -1, "", "Command timed out"
    except Exception as e:
        import traceback
        return -2, "", "Error executing command: {}: {}".format(str(e), traceback.format_exc())



def _smart_decode(data):
    """Smart decoding to handle encoding issues"""
    if not data:
        return ""

    encodings = ["utf-8", "gbk", "gb18030", "big5", "shift_jis", "latin-1"]
    for encoding in encodings:
        try:
            return data.decode(encoding, errors="strict")
        except UnicodeDecodeError:
            continue

    return data.decode("utf-8", errors="replace")


def run_idcu_command(args, cwd=None):
    """Run idcu command"""
    cmd = [sys.executable, "-m", "idcu.cli.main"] + args
    return run_command(cmd, cwd=cwd)


@pytest.fixture
def e2e_context(request):
    """E2E test context fixture"""
    context = E2ETestContext(request.node.name)
    with context:
        yield context

