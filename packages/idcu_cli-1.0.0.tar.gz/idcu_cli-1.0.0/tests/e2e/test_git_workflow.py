
import os
from pathlib import Path

import pytest

from tests.e2e.conftest import run_command, E2ETestContext


def init_git_repo(path):
    """Initialize git repo"""
    run_command(["git", "init"], cwd=path)
    run_command(["git", "config", "user.name", "Test User"], cwd=path)
    run_command(["git", "config", "user.email", "test@example.com"], cwd=path)


def is_git_repo(path):
    """Check if it's a git repo"""
    return (path / ".git").exists()


def get_git_status(path):
    """Get git status"""
    _, stdout, _ = run_command(["git", "status"], cwd=path)
    return stdout


def get_git_branch(path):
    """Get current branch"""
    _, stdout, _ = run_command(["git", "branch", "--show-current"], cwd=path)
    return stdout.strip()


def get_git_branches(path):
    """Get all branches"""
    _, stdout, _ = run_command(["git", "branch", "-a"], cwd=path)
    return [line.strip().strip("*").strip() for line in stdout.splitlines() if line.strip()]


def git_add_all(path):
    """Add all changes"""
    run_command(["git", "add", "-A"], cwd=path)


def git_commit(path, message):
    """Commit changes"""
    return run_command(["git", "commit", "-m", message], cwd=path)


def git_create_branch(path, branch_name):
    """Create branch"""
    return run_command(["git", "checkout", "-b", branch_name], cwd=path)


def git_switch_branch(path, branch_name):
    """Switch branch"""
    return run_command(["git", "checkout", branch_name], cwd=path)


def get_git_log(path, limit=10):
    """Get git log"""
    _, stdout, _ = run_command(["git", "log", "-n", str(limit), "--oneline"], cwd=path)
    return stdout


class TestGitWorkflow:
    """Test temp Git repo status/commit/branch E2E"""

    def test_git_repo_initialization(self, e2e_context):
        """Test git repo initialization"""
        repo_path = e2e_context.tmp_dir / "test-git-repo"
        repo_path.mkdir()

        assert not is_git_repo(repo_path)

        init_git_repo(repo_path)

        assert is_git_repo(repo_path)
        assert get_git_branch(repo_path) in ["main", "master"]

    def test_git_status_and_commit(self, e2e_context):
        """Test git status and commit"""
        repo_path = e2e_context.tmp_dir / "test-git-repo"
        repo_path.mkdir(exist_ok=True)
        init_git_repo(repo_path)

        test_file = repo_path / "test.txt"
        test_file.write_text("Hello World", encoding="utf-8")

        status = get_git_status(repo_path)
        assert "Untracked files" in status or "test.txt" in status

        git_add_all(repo_path)
        status = get_git_status(repo_path)
        assert "Changes to be committed" in status or "test.txt" in status

        returncode, _, _ = git_commit(repo_path, "Initial commit")
        assert returncode == 0

        log = get_git_log(repo_path)
        assert "Initial commit" in log

    def test_git_branch_operations(self, e2e_context):
        """Test git branch operations"""
        repo_path = e2e_context.tmp_dir / "test-git-repo"
        repo_path.mkdir(exist_ok=True)
        init_git_repo(repo_path)

        test_file = repo_path / "test.txt"
        test_file.write_text("Initial content", encoding="utf-8")
        git_add_all(repo_path)
        git_commit(repo_path, "Initial commit")

        original_branch = get_git_branch(repo_path)
        branches = get_git_branches(repo_path)
        assert original_branch in branches

        feature_branch = "feature/new-feature"
        returncode, _, _ = git_create_branch(repo_path, feature_branch)
        assert returncode == 0

        current_branch = get_git_branch(repo_path)
        assert current_branch == feature_branch

        branches = get_git_branches(repo_path)
        assert feature_branch in branches
        assert original_branch in branches

        feature_file = repo_path / "feature.txt"
        feature_file.write_text("Feature content", encoding="utf-8")
        git_add_all(repo_path)
        git_commit(repo_path, "Add feature file")

        returncode, _, _ = git_switch_branch(repo_path, original_branch)
        assert returncode == 0

        current_branch = get_git_branch(repo_path)
        assert current_branch == original_branch
        assert not feature_file.exists()

    def test_multiple_commits_on_different_branches(self, e2e_context):
        """Test multiple commits on different branches"""
        repo_path = e2e_context.tmp_dir / "test-git-repo"
        repo_path.mkdir(exist_ok=True)
        init_git_repo(repo_path)

        main_file = repo_path / "main.txt"
        main_file.write_text("Main branch content", encoding="utf-8")
        git_add_all(repo_path)
        git_commit(repo_path, "Commit on main")

        main_branch = get_git_branch(repo_path)

        git_create_branch(repo_path, "develop")

        dev_file = repo_path / "develop.txt"
        dev_file.write_text("Develop branch content", encoding="utf-8")
        git_add_all(repo_path)
        git_commit(repo_path, "First commit on develop")

        dev_file.write_text("Develop branch content updated", encoding="utf-8")
        git_add_all(repo_path)
        git_commit(repo_path, "Second commit on develop")

        dev_log = get_git_log(repo_path)
        assert "Second commit on develop" in dev_log
        assert "First commit on develop" in dev_log

        git_switch_branch(repo_path, main_branch)

        assert not dev_file.exists()
        assert main_file.exists()

        main_log = get_git_log(repo_path)
        assert "Commit on main" in main_log
        assert "Second commit on develop" not in main_log

