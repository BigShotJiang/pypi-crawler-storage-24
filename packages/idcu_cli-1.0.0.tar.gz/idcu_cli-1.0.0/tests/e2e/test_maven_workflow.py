
import os
import shutil
from pathlib import Path

import pytest

from tests.e2e.conftest import run_command, E2ETestContext


MINIMAL_POM_XML = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>minimal-project</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <name>Minimal Maven Project</name>
    <description>A minimal Maven project for testing purposes</description>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

</project>
"""

MINIMAL_JAVA_SOURCE = """package com.example;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
"""


def create_minimal_maven_project(path):
    """Create minimal Maven project"""
    project_path = path / "minimal-maven"
    project_path.mkdir(parents=True, exist_ok=True)

    (project_path / "pom.xml").write_text(MINIMAL_POM_XML, encoding="utf-8")

    src_dir = project_path / "src" / "main" / "java" / "com" / "example"
    src_dir.mkdir(parents=True, exist_ok=True)

    (src_dir / "HelloWorld.java").write_text(MINIMAL_JAVA_SOURCE, encoding="utf-8")

    return project_path


def is_maven_project(path):
    """Check if it's a Maven project"""
    return (path / "pom.xml").exists()


def find_maven_executable():
    """Find Maven executable"""
    maven_names = ["mvn", "mvn.cmd", "mvn.bat"]

    for name in maven_names:
        path = shutil.which(name)
        if path:
            return path

    if os.name == "nt":
        possible_paths = [
            r"D:\os\run\maven",
            r"C:\Program Files\Maven",
            r"C:\Program Files (x86)\Maven",
            os.path.expanduser(r"~\scoop\apps\maven"),
        ]

        for base_path in possible_paths:
            for name in maven_names:
                full_path = os.path.join(base_path, "bin", name)
                if os.path.exists(full_path):
                    return full_path

    return None


MAVEN_AVAILABLE = find_maven_executable() is not None



class TestMavenWorkflow:
    """Test minimal Maven project detection and build E2E"""

    def test_maven_project_detection(self, e2e_context):
        """Test Maven project detection"""
        project_path = create_minimal_maven_project(e2e_context.tmp_dir)

        assert is_maven_project(project_path)

        non_maven_dir = e2e_context.tmp_dir / "non-maven"
        non_maven_dir.mkdir()
        assert not is_maven_project(non_maven_dir)

    @pytest.mark.skipif(not MAVEN_AVAILABLE, reason="Maven not available")
    def test_maven_project_validation(self, e2e_context):
        """Test Maven project validation"""
        project_path = create_minimal_maven_project(e2e_context.tmp_dir)

        mvn_exec = find_maven_executable()
        returncode, stdout, stderr = run_command([mvn_exec, "validate"], cwd=project_path, timeout=600)

        if returncode != 0:
            print("Maven validation stdout: {}".format(stdout))
            print("Maven validation stderr: {}".format(stderr))

        assert returncode == 0

    @pytest.mark.skipif(not MAVEN_AVAILABLE, reason="Maven not available")
    def test_maven_clean_verify(self, e2e_context):
        """Test Maven clean and verify"""
        project_path = create_minimal_maven_project(e2e_context.tmp_dir)

        mvn_exec = find_maven_executable()
        returncode, stdout, stderr = run_command(
            [mvn_exec, "clean", "verify", "-DskipTests"],
            cwd=project_path,
            timeout=900
        )

        if returncode != 0:
            print("Maven clean verify stdout: {}".format(stdout))
            print("Maven clean verify stderr: {}".format(stderr))

        assert returncode == 0

        target_dir = project_path / "target"
        assert target_dir.exists()
        assert (target_dir / "classes" / "com" / "example" / "HelloWorld.class").exists()

        jar_files = list(target_dir.glob("*.jar"))
        assert len(jar_files) > 0

    def test_maven_project_with_submodules(self, e2e_context):
        """Test Maven project with submodules"""
        parent_path = e2e_context.tmp_dir / "parent-project"
        parent_path.mkdir()

        parent_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>parent-project</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>pom</packaging>

    <name>Parent Project</name>

    <modules>
        <module>module-a</module>
        <module>module-b</module>
    </modules>

</project>
"""

        (parent_path / "pom.xml").write_text(parent_pom, encoding="utf-8")

        module_a = parent_path / "module-a"
        module_a.mkdir()
        module_a_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>com.example</groupId>
        <artifactId>parent-project</artifactId>
        <version>1.0.0-SNAPSHOT</version>
    </parent>

    <artifactId>module-a</artifactId>
    <name>Module A</name>

</project>
"""
        (module_a / "pom.xml").write_text(module_a_pom, encoding="utf-8")

        module_b = parent_path / "module-b"
        module_b.mkdir()
        module_b_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>com.example</groupId>
        <artifactId>parent-project</artifactId>
        <version>1.0.0-SNAPSHOT</version>
    </parent>

    <artifactId>module-b</artifactId>
    <name>Module B</name>

</project>
"""
        (module_b / "pom.xml").write_text(module_b_pom, encoding="utf-8")

        assert is_maven_project(parent_path)
        assert is_maven_project(module_a)
        assert is_maven_project(module_b)
