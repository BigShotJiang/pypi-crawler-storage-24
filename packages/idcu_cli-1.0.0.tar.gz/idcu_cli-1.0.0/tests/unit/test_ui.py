import sys
from io import StringIO
from unittest.mock import patch
from idcu.core.constants import DEFAULT_BRANCH, REMOTE_NAME
from idcu.core.ui import (
    Colors,
    ProgressBar,
    _format_message,
    _print_message,
    _resolve_color,
    _supports_text,
    colorize,
    print_error,
    print_error_with_suggestion,
    print_header,
    print_info,
    print_json,
    print_section,
    print_success,
    print_table,
    print_warning,
)


def test_constants():
    assert DEFAULT_BRANCH == "develop"
    assert REMOTE_NAME == "origin"


class TestColors:
    def test_colors_initial_values(self):
        assert Colors.RESET == "\033[0m"
        assert Colors.BOLD == "\033[1m"
        assert Colors.RED == "\033[91m"
        assert Colors.GREEN == "\033[92m"

    def test_colors_disable(self):
        Colors.disable()
        assert Colors.RESET == ""
        Colors.RESET = "\033[0m"
        Colors.BOLD = "\033[1m"
        Colors.RED = "\033[91m"
        Colors.GREEN = "\033[92m"
        Colors.YELLOW = "\033[93m"
        Colors.BLUE = "\033[94m"
        Colors.MAGENTA = "\033[95m"
        Colors.CYAN = "\033[96m"
        Colors.WHITE = "\033[97m"
        Colors.BG_RED = "\033[41m"
        Colors.BG_GREEN = "\033[42m"
        Colors.BG_YELLOW = "\033[43m"
        Colors.BG_BLUE = "\033[44m"
        Colors.BG_MAGENTA = "\033[45m"
        Colors.BG_CYAN = "\033[46m"
        Colors.BG_WHITE = "\033[47m"

    def test_resolve_color(self):
        assert _resolve_color("RED") == "\033[91m"
        assert _resolve_color("\033[91m") == "\033[91m"
        assert _resolve_color(None) == ""
        assert _resolve_color("") == ""


def test_colorize():
    assert colorize("test", "RED") == "\033[91mtest\033[0m"
    assert colorize("", "RED") == ""


def test_supports_text():
    assert _supports_text("hello", sys.stdout) is True


def test_format_message():
    assert _format_message("[OK]", "test") == "[OK] test"
    assert _format_message("[OK]", "") == ""
    assert _format_message("[OK]", None) == ""


def test_print_message():
    captured_output = StringIO()
    _print_message("test message", "GREEN", "\u2713", "[OK]", captured_output)
    output = captured_output.getvalue()
    assert "test message" in output


def test_print_functions():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_success("success")
        print_warning("warning")
        print_info("info")
        print_header("header")
        print_section("section")
    output = captured_output.getvalue()
    assert "success" in output or "warning" in output or "info" in output


def test_print_error():
    captured_output = StringIO()
    with patch('sys.stderr', new=captured_output):
        print_error("error")
    output = captured_output.getvalue()
    assert "error" in output


class TestProgressBar:
    def test_progress_bar_init(self):
        pb = ProgressBar(100)
        assert pb.total == 100
        assert pb.current == 0

    def test_progress_bar_update_current(self):
        pb = ProgressBar(100)
        pb.update(current=50)
        assert pb.current == 50

    def test_progress_bar_update_increment(self):
        pb = ProgressBar(100)
        pb.update(increment=10)
        assert pb.current == 10

    def test_progress_bar_context_manager(self):
        with ProgressBar(100) as pb:
            pb.update(increment=50)
        assert pb.current == 100


def test_print_table():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_table(["Col1", "Col2"], [["Val1", "Val2"]])
    output = captured_output.getvalue()
    assert "Col1" in output
    assert "Val1" in output


def test_print_table_empty():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_table(["Col1"], [])
    output = captured_output.getvalue()
    assert "无数据" in output


def test_print_json():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_json({"key": "value"})
    output = captured_output.getvalue()
    assert "key" in output
    assert "value" in output


def test_print_error_with_suggestion():
    captured_output = StringIO()
    with patch('sys.stderr', new=captured_output), patch('sys.stdout', new=captured_output):
        print_error_with_suggestion("error", ["fix1", "fix2"])
    output = captured_output.getvalue()
    assert "error" in output
    assert "fix1" in output
