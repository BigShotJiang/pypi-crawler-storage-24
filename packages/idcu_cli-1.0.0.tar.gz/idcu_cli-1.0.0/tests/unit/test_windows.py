from __future__ import annotations

from pathlib import Path, PureWindowsPath

from idcu.core.encoding_utils import detect_file_encoding, fix_file_encoding, is_binary_file


class TestWindowsPaths:
    def test_unicode_path_round_trip(self, tmp_path: Path) -> None:
        working_dir = tmp_path / "Windows Workspace" / "中文目录"
        working_dir.mkdir(parents=True)

        target = working_dir / "输出文件.txt"
        content = "中文内容\r\nsecond line\r\n"
        target.write_text(content, encoding="utf-8", newline="")

        assert target.exists()
        with target.open("r", encoding="utf-8", newline="") as handle:
            assert handle.read() == content

    def test_pure_windows_path_shape(self) -> None:
        path = PureWindowsPath(r"C:\work\项目\build\report.txt")

        assert path.drive == "C:"
        assert path.suffix == ".txt"
        assert path.parts[-2:] == ("build", "report.txt")

    def test_relative_path_survives_nested_directories(self, tmp_path: Path) -> None:
        nested = tmp_path / "a" / "b" / "c"
        nested.mkdir(parents=True)
        target = nested / "deep.txt"
        target.write_text("deep content", encoding="utf-8")

        assert target.relative_to(tmp_path) == Path("a") / "b" / "c" / "deep.txt"


class TestWindowsEncoding:
    def test_detect_utf8_with_crlf_content(self, tmp_path: Path) -> None:
        target = tmp_path / "utf8-crlf.txt"
        content = "第一行\r\nSecond line\r\n第三行\r\n"
        target.write_text(content, encoding="utf-8", newline="")

        result = detect_file_encoding(target)

        assert result.success is True
        assert result.encoding in {"utf-8", "utf-8-sig"}
        assert result.has_garbage is False

    def test_fix_gbk_file_to_utf8(self, tmp_path: Path) -> None:
        target = tmp_path / "gbk-source.txt"
        original = "这是 GBK 编码的内容"
        target.write_bytes(original.encode("gbk"))

        result = fix_file_encoding(target, target_encoding="utf-8", backup=False, force=True)

        assert result.success is True
        assert target.read_text(encoding="utf-8") == original

    def test_binary_detection_stays_false_for_text(self, tmp_path: Path) -> None:
        text_file = tmp_path / "notes.txt"
        text_file.write_text("plain utf-8 text", encoding="utf-8")

        assert is_binary_file(text_file) is False

    def test_binary_detection_stays_true_for_binary(self, tmp_path: Path) -> None:
        binary_file = tmp_path / "blob.bin"
        binary_file.write_bytes(b"\x00\x01\x02\x03")

        assert is_binary_file(binary_file) is True