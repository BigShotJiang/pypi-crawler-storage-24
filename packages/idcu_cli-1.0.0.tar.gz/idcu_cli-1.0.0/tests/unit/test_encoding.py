from pathlib import Path
from idcu.core.encoding_utils import (
    EncodingResult,
    _match_any_pattern,
    calculate_text_quality,
    detect_bom,
    detect_encoding_with_fallback,
    detect_file_encoding,
    has_garbage_text,
    is_valid_char_code,
    try_all_encodings,
    try_fix_encoding,
)


class TestEncodingUtils:
    def test_encoding_result_init(self):
        result = EncodingResult("test.txt", "utf-8", 0.9)
        assert result.path == "test.txt"
        assert result.encoding == "utf-8"
        assert result.confidence == 0.9

    def test_detect_bom(self):
        utf8_bom = b"\xef\xbb\xbfhello"
        encoding, bom = detect_bom(utf8_bom)
        assert encoding == "utf-8-sig"
        assert bom == b"\xef\xbb\xbf"

    def test_detect_bom_none(self):
        encoding, bom = detect_bom(b"no bom")
        assert encoding is None
        assert bom is None

    def test_is_valid_char_code(self):
        assert is_valid_char_code(65) is True
        assert is_valid_char_code(-1) is False
        assert is_valid_char_code(0xD800) is False
        assert is_valid_char_code(0xE000) is True
        assert is_valid_char_code(0x10FFFF) is True
        assert is_valid_char_code(0x110000) is False

    def test_calculate_text_quality(self):
        assert calculate_text_quality("") == 0.0
        quality = calculate_text_quality("Hello 世界!")
        assert quality > 0

    def test_detect_encoding_with_fallback_utf8(self):
        data = "Hello 世界!".encode()
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None

    def test_has_garbage_text_clean(self):
        has_garbage, count = has_garbage_text("Clean text")
        assert has_garbage is False

    def test_detect_file_encoding(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello 世界!", encoding="utf-8")
        result = detect_file_encoding(str(test_file))
        assert result.success is True

    def test_try_all_encodings(self):
        data = b"Hello"
        results = try_all_encodings(data)
        assert len(results) > 0

    def test_try_fix_encoding(self):
        data = b"Hello"
        text, encoding = try_fix_encoding(data)
        assert text == "Hello"

    def test_match_any_pattern(self):
        path = Path("test.py")
        assert _match_any_pattern(path, ["*.py"]) is True
        assert _match_any_pattern(path, ["*.txt"]) is False

    def test_match_any_pattern_with_string_match(self):
        path = Path("test.txt")
        assert _match_any_pattern(path, ["test"]) is True

    def test_calculate_text_quality_with_empty(self):
        assert calculate_text_quality("") == 0.0
        assert calculate_text_quality("   ") > 0

    def test_calculate_text_quality_with_high_quality(self):
        quality = calculate_text_quality("Hello world! This is a test with good quality text.")
        assert quality > 50

    def test_detect_encoding_with_fallback_utf16(self):
        data = "Hello".encode("utf-16-le")
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None

    def test_detect_encoding_with_fallback_low_quality(self):
        data = b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09" * 100
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None
        assert confidence <= 1.0

    def test_has_garbage_text_with_garbage(self):
        has_garbage, count = has_garbage_text("\ufffd\ufffe\uffff garbage text")
        assert has_garbage is True
        assert count > 0

    def test_has_garbage_text_with_invalid_consecutive(self):
        invalid_text = "".join([chr(0xFFFF) for _ in range(5)])
        has_garbage, count = has_garbage_text(invalid_text)
        assert has_garbage is True
        assert count >= 5

    def test_detect_file_encoding_error(self, tmp_path):
        test_file = tmp_path / "nonexistent.txt"
        result = detect_file_encoding(str(test_file))
        assert result.success is False
        assert result.error_message is not None

    def test_try_all_encodings_with_replace(self):
        invalid_data = b"\xFF\xFE\xFD\xFC"
        results = try_all_encodings(invalid_data)
        assert len(results) >= 0

    def test_try_fix_encoding_with_medium_quality(self):
        data = b"Test text with some content"
        text, encoding = try_fix_encoding(data)
        assert text is not None
        assert encoding is not None

    def test_try_fix_encoding_with_fallback(self):
        data = b"\xFF\xFE\xFD\xFC\xFB\xFA"
        text, encoding = try_fix_encoding(data)
        assert text is not None
        assert encoding is not None
