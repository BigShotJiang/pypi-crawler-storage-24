import sys
from io import StringIO
from unittest.mock import patch
from idcu.core.utils import Timer, format_size


def test_timer():
    timer = Timer("test")
    timer.start()
    assert timer.start_time is not None
    timer.stop()
    assert timer.elapsed() >= 0


def test_timer_context_manager():
    with Timer("context") as timer:
        assert timer.start_time is not None
    assert timer.end_time is not None
    assert timer.elapsed() >= 0


def test_timer_without_start():
    timer = Timer("test")
    assert timer.elapsed() == 0.0


def test_format_size():
    assert format_size(0) == "0 B"
    assert format_size(1024) == "1.0 KB"
    assert format_size(1024 * 1024) == "1.0 MB"
    assert format_size(1024 * 1024 * 1024) == "1.0 GB"
    assert format_size(1536) == "1.5 KB"
