

import pytest

from idcu.tools.plugins.base import (
    Plugin,
    PluginManager,
    PluginMetadata,
    get_plugin_manager,
    reset_plugin_manager,
    set_plugin_manager,
)

@pytest.fixture(autouse=True)
def reset_plugin_manager_singleton():
    reset_plugin_manager()
    yield
    reset_plugin_manager()


class TestPluginMetadata:
    def test_plugin_metadata_creation(self):
        metadata = PluginMetadata(
            name="test-plugin",
            version="1.0.0",
            description="Test plugin",
            author="Test Author",
        )
        assert metadata.name == "test-plugin"
        assert metadata.version == "1.0.0"
        assert metadata.enabled is True

    def test_plugin_metadata_defaults(self):
        metadata = PluginMetadata(name="test", version="0.1.0")
        assert metadata.description == ""
        assert metadata.author == ""
        assert metadata.dependencies == []


class TestPlugin:
    def test_plugin_subclass_must_have_metadata(self):
        class BadPlugin(Plugin):
            def initialize(self):
                pass

        with pytest.raises(ValueError):
            BadPlugin()

    def test_valid_plugin_creation(self):
        class GoodPlugin(Plugin):
            metadata = PluginMetadata(
                name="good-plugin",
                version="1.0.0"
            )
            def initialize(self):
                pass

        plugin = GoodPlugin()
        assert plugin.metadata.name == "good-plugin"


class TestPluginManager:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def sample_plugin_class(self):
        class SamplePlugin(Plugin):
            metadata = PluginMetadata(
                name="sample",
                version="1.0.0",
                description="A sample plugin"
            )
            def initialize(self):
                self.initialized = True

            def get_commands(self):
                return {
                    "hello": lambda: "Hello World!"
                }

        return SamplePlugin

    def test_register_plugin(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        assert plugin_manager.has("sample") is True

    def test_register_duplicate_plugin(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        with pytest.raises(ValueError):
            plugin_manager.register(plugin)

    def test_unregister_plugin(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        assert plugin_manager.unregister("sample") is True
        assert plugin_manager.has("sample") is False

    def test_get_plugin(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        retrieved = plugin_manager.get("sample")
        assert retrieved is not None
        assert retrieved.metadata.name == "sample"

    def test_list_plugins(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        plugins = plugin_manager.list_all()
        assert len(plugins) == 1
        assert plugins[0].name == "sample"

    def test_initialize_all(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        assert plugin.initialized is True

    def test_get_command(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        cmd = plugin_manager.get_command("hello")
        assert cmd is not None
        assert cmd() == "Hello World!"

    def test_list_commands(self, plugin_manager, sample_plugin_class):
        plugin = sample_plugin_class()
        plugin_manager.register(plugin)
        commands = plugin_manager.list_commands()
        assert "hello" in commands


class TestPluginManagerSingleton:
    def test_get_plugin_manager_returns_same_instance(self):
        pm1 = get_plugin_manager()
        pm2 = get_plugin_manager()
        assert pm1 is pm2


class TestPluginHooks:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def hook_plugin_class(self):
        class HookPlugin(Plugin):
            metadata = PluginMetadata(
                name="hook-plugin",
                version="1.0.0"
            )
            def initialize(self):
                pass

            def get_hooks(self):
                return {
                    "pre_build": lambda x: x + 1,
                    "post_build": lambda x: x * 2
                }

        return HookPlugin

    def test_trigger_hook(self, plugin_manager, hook_plugin_class):
        plugin = hook_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()

        results = plugin_manager.trigger_hook("pre_build", 5)
        assert results == [6]

        results = plugin_manager.trigger_hook("post_build", 10)
        assert results == [20]

    def test_trigger_hook_not_found(self, plugin_manager):
        results = plugin_manager.trigger_hook("nonexistent", 5)
        assert results == []


class TestPluginCleanup:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def cleanup_plugin_class(self):
        class CleanupPlugin(Plugin):
            metadata = PluginMetadata(
                name="cleanup-plugin",
                version="1.0.0"
            )
            def __init__(self):
                super().__init__()
                self.cleaned_up = False

            def initialize(self):
                pass

            def cleanup(self):
                self.cleaned_up = True

        return CleanupPlugin

    def test_cleanup_all(self, plugin_manager, cleanup_plugin_class):
        plugin = cleanup_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        plugin_manager.cleanup_all()
        assert plugin.cleaned_up is True

    def test_cleanup_on_unregister(self, plugin_manager, cleanup_plugin_class):
        plugin = cleanup_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        plugin_manager.unregister("cleanup-plugin")
        assert plugin.cleaned_up is True


class TestPluginDisabled:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def disabled_plugin_class(self):
        class DisabledPlugin(Plugin):
            metadata = PluginMetadata(
                name="disabled-plugin",
                version="1.0.0",
                enabled=False
            )
            def __init__(self):
                super().__init__()
                self.initialized = False

            def initialize(self):
                self.initialized = True

        return DisabledPlugin

    def test_disabled_plugin_not_initialized(self, plugin_manager, disabled_plugin_class):
        plugin = disabled_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        assert plugin.initialized is False


class TestPluginLoadFromModule:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    def test_load_from_module_failure(self, plugin_manager, monkeypatch):
        class BadPlugin(Plugin):
            metadata = PluginMetadata(name="bad", version="1.0.0")
            def initialize(self):
                pass

        def mock_register(plugin):
            raise ValueError("Registration failed")

        monkeypatch.setattr(plugin_manager, "register", mock_register)

        import types
        module = types.ModuleType("test_module")
        module.BadPlugin = BadPlugin

        plugin_manager._load_from_module(module)


class TestPluginHookErrorHandling:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def error_hook_plugin_class(self):
        class ErrorHookPlugin(Plugin):
            metadata = PluginMetadata(
                name="error-hook-plugin",
                version="1.0.0"
            )
            def initialize(self):
                pass

            def get_hooks(self):
                return {
                    "error_hook": lambda: 1 / 0
                }

        return ErrorHookPlugin

    def test_hook_execution_error(self, plugin_manager, error_hook_plugin_class, capsys):
        plugin = error_hook_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()

        results = plugin_manager.trigger_hook("error_hook")
        assert results == []
        captured = capsys.readouterr()
        assert "Hook 'error_hook' execution failed" in captured.out


class TestPluginInitializeError:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def init_error_plugin_class(self):
        class InitErrorPlugin(Plugin):
            metadata = PluginMetadata(
                name="init-error-plugin",
                version="1.0.0"
            )
            def initialize(self):
                raise ValueError("Initialization failed")

        return InitErrorPlugin

    def test_plugin_init_error(self, plugin_manager, init_error_plugin_class, capsys):
        plugin = init_error_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        captured = capsys.readouterr()
        assert "Failed to initialize plugin" in captured.out


class TestPluginCleanupError:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def cleanup_error_plugin_class(self):
        class CleanupErrorPlugin(Plugin):
            metadata = PluginMetadata(
                name="cleanup-error-plugin",
                version="1.0.0"
            )
            def initialize(self):
                pass

            def cleanup(self):
                raise ValueError("Cleanup failed")

        return CleanupErrorPlugin

    def test_plugin_cleanup_error(self, plugin_manager, cleanup_error_plugin_class, capsys):
        plugin = cleanup_error_plugin_class()
        plugin_manager.register(plugin)
        plugin_manager.initialize_all()
        plugin_manager.cleanup_all()
        captured = capsys.readouterr()
        assert "Failed to cleanup plugin" in captured.out


class TestPluginCommandsWithDoc:
    @pytest.fixture
    def plugin_manager(self):
        return PluginManager()

    @pytest.fixture
    def doc_plugin_class(self):
        class DocPlugin(Plugin):
            metadata = PluginMetadata(
                name="doc-plugin",
                version="1.0.0"
            )
            def initialize(self):
                pass

            def get_commands(self):
                def hello():
                    """Say hello"""
                    return "Hello"

                def goodbye():
                    return "Goodbye"

                return {
                    "hello": hello,
                    "goodbye": goodbye
                }

        return DocPlugin

    def test_list_commands_with_doc(self, plugin_manager, doc_plugin_class):
        plugin = doc_plugin_class()
        plugin_manager.register(plugin)
        commands = plugin_manager.list_commands()
        assert commands["hello"] == "Say hello"
        assert commands["goodbye"] == ""
