
from pathlib import Path
from unittest.mock import patch

from idcu.tools.git.git_common import (
    execute_git_operation_result_error_indicator,
    execute_push_operation_result_error_indicator,
    for_each_repo_operation,
    is_valid_git_repo,
    normalize_repos,
    validate_repo,
)


class TestGitCommon:
    def test_is_valid_git_repo_with_dir(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / ".git").mkdir()
        assert is_valid_git_repo(repo) is True

    def test_is_valid_git_repo_with_file(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / ".git").touch()
        assert is_valid_git_repo(repo) is True

    def test_is_valid_git_repo_invalid(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        assert is_valid_git_repo(repo) is False

    @patch("idcu.tools.git.git_common.print_error")
    def test_validate_repo_valid(self, mock_print_error, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / ".git").mkdir()
        assert validate_repo(repo) is True
        mock_print_error.assert_not_called()

    @patch("idcu.tools.git.git_common.print_error")
    def test_validate_repo_invalid(self, mock_print_error, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        assert validate_repo(repo) is False
        mock_print_error.assert_called_once()

    def test_normalize_repos_none(self):
        repos = normalize_repos(None)
        assert len(repos) == 1
        assert isinstance(repos[0], Path)

    def test_normalize_repos_single_path(self):
        repos = normalize_repos("/test/path")
        assert len(repos) == 1
        assert repos[0] == Path("/test/path")

    def test_normalize_repos_list(self):
        repos = normalize_repos(["/path1", "/path2"])
        assert len(repos) == 2
        assert repos[0] == Path("/path1")
        assert repos[1] == Path("/path2")

    def test_for_each_repo_operation_success(self, tmp_path):
        repo1 = tmp_path / "repo1"
        repo1.mkdir()
        (repo1 / ".git").mkdir()

        repo2 = tmp_path / "repo2"
        repo2.mkdir()
        (repo2 / ".git").mkdir()

        def operation(repo):
            return type("Result", (), {"success": True})()

        def error_indicator(result):
            return not result.success

        result = for_each_repo_operation([repo1, repo2], operation, error_indicator)
        assert result == 0

    def test_for_each_repo_operation_with_error(self, tmp_path):
        repo1 = tmp_path / "repo1"
        repo1.mkdir()
        (repo1 / ".git").mkdir()

        def operation(repo):
            return type("Result", (), {"success": False})()

        def error_indicator(result):
            return not result.success

        result = for_each_repo_operation([repo1], operation, error_indicator)
        assert result == 1

    def test_execute_push_operation_result_error_indicator(self):
        success_result = type("Result", (), {"success": True})()
        assert execute_push_operation_result_error_indicator(success_result) is False

        fail_result = type("Result", (), {"success": False})()
        assert execute_push_operation_result_error_indicator(fail_result) is True

    def test_execute_git_operation_result_error_indicator(self):
        success_result = type("Result", (), {"success": True})()
        assert execute_git_operation_result_error_indicator(success_result) is False

        fail_result = type("Result", (), {"success": False})()
        assert execute_git_operation_result_error_indicator(fail_result) is True

