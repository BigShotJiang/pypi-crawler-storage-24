

import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from idcu.tools.crosslang import (
    BuildResult,
    BuildTool,
    Dependency,
    ProjectDetector,
    UnifiedBuilder,
)
from idcu.tools.crosslang.base import BuildTool as BaseBuildTool


def test_build_result():
    result = BuildResult(success=True, output="test output", error="", return_code=0)
    assert result.success is True
    assert result.output == "test output"
    assert bool(result) is True

    result = BuildResult(success=False, output="", error="test error", return_code=1)
    assert result.success is False
    assert result.error == "test error"
    assert bool(result) is False


def test_dependency():
    dep = Dependency(name="test-package", version="1.0.0", scope="dev")
    assert dep.name == "test-package"
    assert dep.version == "1.0.0"
    assert dep.scope == "dev"
    
    dep_dict = dep.to_dict()
    assert dep_dict["name"] == "test-package"
    assert dep_dict["version"] == "1.0.0"


class TestBuildTool(BaseBuildTool):
    def is_available(self):
        return True
    
    def detect_project(self):
        return True
    
    def install_dependencies(self):
        return BuildResult(True)
    
    def build(self):
        return BuildResult(True)
    
    def test(self):
        return BuildResult(True)
    
    def clean(self):
        return BuildResult(True)
    
    def get_dependencies(self):
        return []
    
    def add_dependency(self, name, version=None, scope=None):
        return BuildResult(True)
    
    def remove_dependency(self, name):
        return BuildResult(True)


def test_build_tool_interface():
    tool = TestBuildTool()
    assert tool.is_available() is True
    assert tool.detect_project() is True
    assert tool.install_dependencies().success is True
    assert tool.build().success is True
    assert tool.test().success is True
    assert tool.clean().success is True


def test_project_detector():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        detector = ProjectDetector(str(tmp_path))
        tools = detector.detect_all_tools()
        assert isinstance(tools, list)
        
        primary = detector.detect_primary_tool()
        assert primary is None or isinstance(primary, BuildTool)


def test_unified_builder():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        builder = UnifiedBuilder(str(tmp_path))
        
        with patch.object(ProjectDetector, 'detect_primary_tool', return_value=None):
            assert builder.auto_build() is False
            assert builder.auto_test() is False
            assert builder.auto_clean() is False
