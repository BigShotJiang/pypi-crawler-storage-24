
from unittest.mock import patch

import pytest

from idcu.tools.git.git_ops import (
    _smart_decode,
    get_repo_name,
    get_submodule_paths,
    list_available_projects,
)


class TestSmartDecode:
    def test_smart_decode_empty_bytes(self):
        result = _smart_decode(b"")
        assert result == ""

    def test_smart_decode_utf8(self):
        test_str = "Hello, 世界!"
        result = _smart_decode(test_str.encode("utf-8"))
        assert result == test_str

    def test_smart_decode_gbk(self):
        test_str = "你好，世界！"
        gbk_bytes = test_str.encode("gbk")
        result = _smart_decode(gbk_bytes)
        assert result in [test_str, test_str.encode("gbk").decode("utf-8", errors="replace")]


class TestGitModuleFunctions:
    @pytest.fixture
    def mock_repo_root(self, tmp_path):
        repo_root = tmp_path / "test_repo"
        repo_root.mkdir()
        return repo_root

    @patch("idcu.tools.git.git_ops.run_git")
    def test_get_submodule_paths_no_gitmodules(self, mock_run_git, mock_repo_root):
        submodules = get_submodule_paths(mock_repo_root)
        assert submodules == []
        mock_run_git.assert_not_called()

    @patch("idcu.tools.git.git_ops.run_git")
    def test_get_submodule_paths_with_gitmodules(self, mock_run_git, mock_repo_root):
        gitmodules_file = mock_repo_root / ".gitmodules"
        gitmodules_file.touch()

        mock_run_git.return_value = (0, "submodule.sub1.path path1\nsubmodule.sub2.path path2", "")

        submodules = get_submodule_paths(mock_repo_root)
        assert submodules == ["path1", "path2"]

    def test_get_repo_name(self, mock_repo_root):
        assert get_repo_name(mock_repo_root, mock_repo_root) == "."
        sub_repo = mock_repo_root / "subproject"
        assert get_repo_name(mock_repo_root, sub_repo) == "subproject"

    @patch("idcu.tools.git.git_ops.get_submodule_paths")
    def test_list_available_projects(self, mock_get_submodules, mock_repo_root):
        mock_get_submodules.return_value = ["sub1", "sub2"]
        projects = list_available_projects(mock_repo_root)
        assert "." in projects
