from unittest.mock import MagicMock, patch

from idcu.tools.plugins.registry import (
    cleanup_plugins,
    get_command,
    get_plugin,
    has_plugin,
    initialize_plugins,
    list_commands,
    list_plugins,
    trigger_hook,
)


class TestPluginsRegistry:
    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_get_plugin(self, mock_get_manager):
        mock_plugin = MagicMock()
        mock_manager = MagicMock()
        mock_manager.get.return_value = mock_plugin
        mock_get_manager.return_value = mock_manager

        result = get_plugin("test")
        assert result == mock_plugin
        mock_manager.get.assert_called_once_with("test")

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_list_plugins(self, mock_get_manager):
        mock_plugins = [MagicMock(), MagicMock()]
        mock_manager = MagicMock()
        mock_manager.list_all.return_value = mock_plugins
        mock_get_manager.return_value = mock_manager

        result = list_plugins()
        assert result == mock_plugins
        mock_manager.list_all.assert_called_once()

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_has_plugin(self, mock_get_manager):
        mock_manager = MagicMock()
        mock_manager.has.return_value = True
        mock_get_manager.return_value = mock_manager

        result = has_plugin("test")
        assert result is True
        mock_manager.has.assert_called_once_with("test")

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_initialize_plugins(self, mock_get_manager):
        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        initialize_plugins()
        mock_manager.initialize_all.assert_called_once()

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_cleanup_plugins(self, mock_get_manager):
        mock_manager = MagicMock()
        mock_get_manager.return_value = mock_manager

        cleanup_plugins()
        mock_manager.cleanup_all.assert_called_once()

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_trigger_hook(self, mock_get_manager):
        mock_results = [1, 2, 3]
        mock_manager = MagicMock()
        mock_manager.trigger_hook.return_value = mock_results
        mock_get_manager.return_value = mock_manager

        result = trigger_hook("test_hook", "arg1", kwarg1="val1")
        assert result == mock_results
        mock_manager.trigger_hook.assert_called_once_with("test_hook", "arg1", kwarg1="val1")

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_get_command(self, mock_get_manager):
        mock_command = MagicMock()
        mock_manager = MagicMock()
        mock_manager.get_command.return_value = mock_command
        mock_get_manager.return_value = mock_manager

        result = get_command("test_cmd")
        assert result == mock_command
        mock_manager.get_command.assert_called_once_with("test_cmd")

    @patch("idcu.tools.plugins.registry.get_plugin_manager")
    def test_list_commands(self, mock_get_manager):
        mock_commands = {"cmd1": "desc1", "cmd2": "desc2"}
        mock_manager = MagicMock()
        mock_manager.list_commands.return_value = mock_commands
        mock_get_manager.return_value = mock_manager

        result = list_commands()
        assert result == mock_commands
        mock_manager.list_commands.assert_called_once()


def test_registry_helpers_accept_explicit_manager():
    mock_manager = MagicMock()
    mock_manager.get.return_value = "plugin"
    mock_manager.list_all.return_value = ["plugin"]
    mock_manager.has.return_value = True
    mock_manager.trigger_hook.return_value = [1]
    mock_manager.get_command.return_value = "command"
    mock_manager.list_commands.return_value = {"cmd": "desc"}

    assert get_plugin("name", plugin_manager=mock_manager) == "plugin"
    assert list_plugins(plugin_manager=mock_manager) == ["plugin"]
    assert has_plugin("name", plugin_manager=mock_manager) is True

    initialize_plugins(plugin_manager=mock_manager)
    cleanup_plugins(plugin_manager=mock_manager)

    assert trigger_hook("hook", plugin_manager=mock_manager) == [1]
    assert get_command("cmd", plugin_manager=mock_manager) == "command"
    assert list_commands(plugin_manager=mock_manager) == {"cmd": "desc"}

    mock_manager.initialize_all.assert_called_once()
    mock_manager.cleanup_all.assert_called_once()
