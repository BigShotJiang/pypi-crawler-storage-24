
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from idcu.system.env_utils import _get_single_env, _set_single_env, add_path, get_env, is_admin, set_default, set_env
from idcu.system.error_handler import (
    ConfigurationError,
    DevToolsError,
    ErrorHandler,
    GitOperationError,
    MavenOperationError,
    PluginError,
    RetryableError,
    fallback,
    handle_errors,
    retry,
    safe_execute,
    with_retry,
)
from idcu.system.i18n import I18nManager, _, get_i18n_manager
from idcu.system.logger import (
    LoggerManager,
    LogLevel,
    StructuredFormatter,
    get_logger,
    get_logger_manager,
    log_critical,
    log_debug,
    log_error,
    log_info,
    log_warning,
    reset_logger_manager,
    set_logger_manager,
)

@pytest.fixture(autouse=True)
def reset_logger_manager_singleton():
    reset_logger_manager()
    yield
    reset_logger_manager()


class TestLogLevel:
    def test_log_level_enum(self):
        assert LogLevel.DEBUG.value == "DEBUG"
        assert LogLevel.INFO.value == "INFO"
        assert LogLevel.WARNING.value == "WARNING"
        assert LogLevel.ERROR.value == "ERROR"
        assert LogLevel.CRITICAL.value == "CRITICAL"


class TestStructuredFormatter:
    def test_structured_formatter_init(self):
        formatter = StructuredFormatter()
        assert formatter.detailed is False

        detailed_formatter = StructuredFormatter(detailed=True)
        assert detailed_formatter.detailed is True

    def test_structured_formatter_format(self):
        import logging
        formatter = StructuredFormatter()

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=(),
            exc_info=None
        )

        result = formatter.format(record)
        assert "test message" in result
        assert "INFO" in result

    def test_structured_formatter_format_with_exception(self):
        import logging
        formatter = StructuredFormatter()

        try:
            raise ValueError("Test error")
        except ValueError:
            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=(),
            exc_info=exc_info
        )

        result = formatter.format(record)
        assert "exception" in result

    def test_structured_formatter_format_with_extra(self):
        import logging
        formatter = StructuredFormatter()

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=(),
            exc_info=None
        )
        record.extra_fields = {"custom_field": "custom_value"}

        result = formatter.format(record)
        assert "custom_field" in result
        assert "custom_value" in result

    def test_structured_formatter_format_detailed(self):
        import logging
        formatter = StructuredFormatter(detailed=True)

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=(),
            exc_info=None
        )

        result = formatter.format(record)
        assert "test message" in result


class TestLoggerManager:
    @pytest.fixture
    def temp_log_dir(self, tmp_path):
        return tmp_path / "logs"

    def test_logger_manager_init(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        assert manager.log_dir == temp_log_dir
        assert temp_log_dir.exists()

    def test_get_logger(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        logger = manager.get_logger("test")
        assert logger is not None

        same_logger = manager.get_logger("test")
        assert logger is same_logger

    def test_set_log_level(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        manager.set_log_level(LogLevel.DEBUG)
        manager.set_log_level("INFO")

    def test_log_methods(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        manager.debug("debug message")
        manager.info("info message")
        manager.warning("warning message")
        manager.error("error message")
        manager.critical("critical message")
        manager.exception("exception message")

    def test_get_log_files(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        files = manager.get_log_files()
        assert isinstance(files, list)

    def test_query_logs(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        logs = manager.query_logs()
        assert isinstance(logs, list)

    def test_clean_old_logs(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        count = manager.clean_old_logs(days=0)
        assert isinstance(count, int)

    def test_export_logs(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        output_file = temp_log_dir / "export.json"
        result = manager.export_logs(str(output_file), format="json")
        assert isinstance(result, bool)

    @patch("idcu.system.logger.print_error")
    def test_export_logs_unsupported_format(self, mock_print_error, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        output_file = temp_log_dir / "export.txt"
        result = manager.export_logs(str(output_file), format="txt")
        assert result is False
        mock_print_error.assert_called()

    def test_export_logs_csv(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        detailed_log = temp_log_dir / "est_spi_detailed.log"
        detailed_log.write_text('{"timestamp": "2024-01-01T00:00:00", "level": "INFO", "logger": "test", "message": "test"}')

        output_file = temp_log_dir / "export.csv"
        result = manager.export_logs(str(output_file), format="csv")
        assert isinstance(result, bool)

    @patch("idcu.system.logger.print_error")
    def test_export_logs_error(self, mock_print_error, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        with patch("builtins.open", side_effect=Exception("IO Error")):
            result = manager.export_logs("invalid/path.json", format="json")
            assert result is False
            mock_print_error.assert_called()

    def test_log_with_extra(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        manager.info("test message", extra={"key": "value"})

    def test_query_logs_with_level(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        logs = manager.query_logs(level=LogLevel.INFO)
        assert isinstance(logs, list)

    def test_query_logs_with_keyword(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        logs = manager.query_logs(keyword="test")
        assert isinstance(logs, list)

    def test_query_logs_with_time_range(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)
        start_time = datetime.now() - timedelta(days=1)
        end_time = datetime.now()
        logs = manager.query_logs(start_time=start_time, end_time=end_time)
        assert isinstance(logs, list)

    @patch("idcu.system.logger.print_error")
    def test_query_logs_error(self, mock_print_error, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        detailed_log = temp_log_dir / "est_spi_detailed.log"
        detailed_log.write_text("{invalid json")

        with patch.object(manager, "main_logger"):
            logs = manager.query_logs()
            assert isinstance(logs, list)

    def test_get_log_files_with_rotated(self, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        (temp_log_dir / "est_spi.log").touch()
        (temp_log_dir / "est_spi.log.1").touch()
        (temp_log_dir / "est_spi.log.2").touch()
        (temp_log_dir / "est_spi_detailed.log").touch()
        (temp_log_dir / "est_spi_detailed.log.1").touch()

        files = manager.get_log_files()
        assert len(files) >= 5

    @patch("idcu.system.logger.print_info")
    def test_clean_old_logs_with_cleanup(self, mock_print_info, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        old_log = temp_log_dir / "old.log"
        old_log.touch()

        import time
        old_time = time.time() - (40 * 24 * 60 * 60)
        os.utime(old_log, (old_time, old_time))

        count = manager.clean_old_logs(days=30)
        assert isinstance(count, int)

    @patch("idcu.system.logger.print_error")
    def test_clean_old_logs_error(self, mock_print_error, temp_log_dir):
        manager = LoggerManager(temp_log_dir)

        log_file = temp_log_dir / "test.log"
        log_file.touch()

        with patch("os.stat", return_value=MagicMock(st_mtime=0)):
            with patch.object(Path, "unlink", side_effect=Exception("Delete error")):
                count = manager.clean_old_logs(days=0)
                assert isinstance(count, int)

    @patch("idcu.system.logger.print_error")
    @patch("idcu.system.logger.Path.cwd", return_value=Path("/tmp"))
    def test_setup_main_logger_import_error(self, mock_cwd, mock_print_error, temp_log_dir):
        original_import = __import__

        def mock_import(name, *args, **kwargs):
            if name == "idcu.system.config_manager":
                raise ImportError("No module named config_manager")
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            manager = LoggerManager(temp_log_dir)
            assert manager.main_logger is not None


def test_get_logger_manager(tmp_path):
    with patch("idcu.system.logger.Path.cwd", return_value=tmp_path):
        manager1 = get_logger_manager()
        manager2 = get_logger_manager()
        assert manager1 is manager2


def test_log_functions(tmp_path):
    with patch("idcu.system.logger.Path.cwd", return_value=tmp_path):
        log_debug("test")
        log_info("test")
        log_warning("test")
        log_error("test")
        log_critical("test")


class TestI18nManager:
    def test_i18n_manager_init(self):
        manager = I18nManager("en")
        assert manager.language == "en"

    def test_set_language(self):
        manager = I18nManager("en")
        manager.set_language("zh")
        assert manager.language == "zh"

        manager.set_language("invalid")
        assert manager.language == "en"

    def test_get_translation(self):
        manager = I18nManager("en")
        assert manager.get("git_status") is not None

    def test_t_method(self):
        manager = I18nManager("en")
        assert manager.t("git_status") == manager.get("git_status")

    def test_get_with_kwargs(self):
        manager = I18nManager("en")
        result = manager.get("git_switch", branch="develop")
        assert "develop" in result

    def test_load_from_file(self, tmp_path):
        manager = I18nManager("en")
        test_file = tmp_path / "test_translations.json"
        test_file.write_text('{"en": {"test_key": "Test Value"}}')
        manager.load_from_file(test_file)

    def test_load_from_directory(self, tmp_path):
        manager = I18nManager("en")
        test_dir = tmp_path / "translations"
        test_dir.mkdir()
        manager.load_from_directory(test_dir)

    def test_get_available_languages(self):
        manager = I18nManager("en")
        languages = manager.get_available_languages()
        assert "en" in languages
        assert "zh" in languages


def test_get_i18n_manager():
    manager1 = get_i18n_manager()
    manager2 = get_i18n_manager()
    assert manager1 is manager2

    with patch.dict(os.environ, {"IDCU_LANGUAGE": "zh"}, clear=True):
        manager = get_i18n_manager()
        assert manager.language in ["zh", "en"]


def test_translation_function():
    result = _("git_status")
    assert result is not None


def test_set_default():
    test_var = None
    globals_dict = {"test_var": test_var}
    set_default("test_var", "default", globals_dict)
    assert globals_dict["test_var"] == "default"

    test_var2 = "already set"
    globals_dict2 = {"test_var2": test_var2}
    set_default("test_var2", "default", globals_dict2)
    assert globals_dict2["test_var2"] == "already set"


def test_is_admin():
    result = is_admin()
    assert isinstance(result, (bool, int))


class TestEnvUtils:
    @patch("idcu.system.env_utils.winreg")
    def test_set_single_env_user(self, mock_winreg):
        mock_key = MagicMock()
        mock_winreg.OpenKey.return_value = mock_key
        result = _set_single_env("TEST_VAR", "test_value", user=True)
        assert result is True

    @patch("idcu.system.env_utils.winreg")
    def test_set_single_env_system(self, mock_winreg):
        mock_key = MagicMock()
        mock_winreg.OpenKey.return_value = mock_key
        result = _set_single_env("TEST_VAR", "test_value", user=False)
        assert result is True

    @patch("idcu.system.env_utils._set_single_env")
    def test_set_env_single(self, mock_set_single):
        mock_set_single.return_value = True
        result = set_env("TEST_VAR", "value", user=True)
        assert result is True

    @patch("idcu.system.env_utils._set_single_env")
    def test_set_env_dict(self, mock_set_single):
        mock_set_single.return_value = True
        result = set_env({"VAR1": "val1", "VAR2": "val2"}, user=True)
        assert result is True

    @patch("idcu.system.env_utils.winreg")
    def test_get_single_env(self, mock_winreg):
        mock_key = MagicMock()
        mock_winreg.OpenKey.return_value = mock_key
        mock_winreg.QueryValueEx.return_value = ("test_value", 0)
        result = _get_single_env("TEST_VAR", user=True)
        assert result == "test_value"

    @patch("idcu.system.env_utils._get_single_env")
    def test_get_env_single(self, mock_get_single):
        mock_get_single.return_value = "value"
        result = get_env("TEST_VAR", user=True)
        assert result == "value"

    @patch("idcu.system.env_utils._get_single_env")
    def test_get_env_list(self, mock_get_single):
        mock_get_single.side_effect = ["val1", "val2"]
        result = get_env(["VAR1", "VAR2"], user=True)
        assert result == {"VAR1": "val1", "VAR2": "val2"}

    @patch("idcu.system.env_utils.get_env")
    @patch("idcu.system.env_utils.set_env")
    def test_add_path(self, mock_set_env, mock_get_env):
        mock_get_env.return_value = "C:\\existing"
        mock_set_env.return_value = True
        result = add_path("C:\\new", user=True)
        assert result is True


class TestDevToolsError:
    def test_devtools_error_init(self):
        error = DevToolsError("test error", error_code=123, details={"key": "value"}, suggestions=["fix it"])
        assert error.message == "test error"
        assert error.error_code == 123
        assert error.details == {"key": "value"}
        assert error.suggestions == ["fix it"]

    def test_devtools_error_defaults(self):
        error = DevToolsError("test error")
        assert error.error_code == 1
        assert error.details == {}
        assert error.suggestions == []


def test_specific_errors():
    git_error = GitOperationError("git error", git_command="git status", return_code=1, output="error")
    assert git_error.error_code == 2

    maven_error = MavenOperationError("maven error", maven_command="mvn clean", return_code=1, output="error")
    assert maven_error.error_code == 3

    config_error = ConfigurationError("config error", config_key="test", config_value="val")
    assert config_error.error_code == 4

    plugin_error = PluginError("plugin error", plugin_name="test", plugin_version="1.0")
    assert plugin_error.error_code == 5

    retry_error = RetryableError("retry error", error_code=10)
    assert retry_error.error_code == 10


class TestErrorHandler:
    def test_error_handler_init(self):
        handler = ErrorHandler()
        assert handler.logger is not None

    def test_get_suggestions(self):
        handler = ErrorHandler()
        error = DevToolsError("test", suggestions=["suggestion1"])
        suggestions = handler.get_suggestions(error)
        assert len(suggestions) >= 1

    def test_get_suggestions_from_keywords(self):
        handler = ErrorHandler()
        error = Exception("git not found")
        suggestions = handler.get_suggestions(error)
        assert len(suggestions) >= 0

    @patch("idcu.core.print_error")
    @patch("idcu.core.print_info")
    def test_handle_exception_devtools(self, mock_print_info, mock_print_error):
        handler = ErrorHandler()
        error = DevToolsError("test error")
        code = handler.handle_exception(error)
        assert code == 1

    @patch("idcu.core.print_info")
    def test_handle_exception_keyboard_interrupt(self, mock_print_info):
        handler = ErrorHandler()
        code = handler.handle_exception(KeyboardInterrupt())
        assert code == 130

    @patch("idcu.core.print_error")
    @patch("idcu.core.print_info")
    def test_handle_exception_generic(self, mock_print_info, mock_print_error):
        handler = ErrorHandler()
        code = handler.handle_exception(Exception("test"))
        assert code == 1

    def test_log_methods(self):
        handler = ErrorHandler()
        handler.log_warning("test")
        handler.log_info("test")
        handler.log_debug("test")


def test_handle_errors_decorator():
    @handle_errors
    def test_func():
        raise Exception("test")

    result = test_func()
    assert result == 1


def test_safe_execute():
    def test_func():
        raise Exception("test")

    result = safe_execute(test_func)
    assert result == 1


def test_retry_decorator():
    attempts = []

    @retry(max_attempts=2, delay=0.01)
    def test_func():
        attempts.append(1)
        raise Exception("fail")

    with pytest.raises(Exception):
        test_func()

    assert len(attempts) == 2


def test_retry_decorator_success():
    attempts = []

    @retry(max_attempts=3, delay=0.01)
    def test_func():
        attempts.append(1)
        if len(attempts) < 2:
            raise Exception("fail")
        return "success"

    result = test_func()
    assert result == "success"
    assert len(attempts) == 2


def test_with_retry():
    attempts = []

    def test_func():
        attempts.append(1)
        if len(attempts) < 2:
            raise Exception("fail")
        return "success"

    result = with_retry(test_func, max_attempts=3, delay=0.01)
    assert result == "success"
    assert len(attempts) == 2


def test_fallback():
    def primary():
        raise Exception("fail")

    def fallback_func():
        return "fallback"

    result = fallback(primary, fallback_func)
    assert result == "fallback"

