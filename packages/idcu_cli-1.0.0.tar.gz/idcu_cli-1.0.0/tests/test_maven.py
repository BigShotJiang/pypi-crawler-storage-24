
from pathlib import Path
from unittest.mock import patch

from idcu.tools.maven.maven_common import execute_maven_operation_result_error_indicator, for_each_maven_operation, is_valid_maven_project, normalize_projects, validate_maven_project


class TestMavenCommon:
    def test_is_valid_maven_project_with_pom(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        (project / "pom.xml").touch()
        assert is_valid_maven_project(project) is True

    def test_is_valid_maven_project_invalid(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        assert is_valid_maven_project(project) is False

    @patch("idcu.tools.maven.maven_common.print_error")
    def test_validate_maven_project_valid(self, mock_print_error, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        (project / "pom.xml").touch()
        assert validate_maven_project(project) is True
        mock_print_error.assert_not_called()

    @patch("idcu.tools.maven.maven_common.print_error")
    def test_validate_maven_project_invalid(self, mock_print_error, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        assert validate_maven_project(project) is False
        mock_print_error.assert_called_once()

    def test_normalize_projects_none(self):
        projects = normalize_projects(None)
        assert len(projects) == 1
        assert isinstance(projects[0], Path)

    def test_normalize_projects_single_path(self):
        projects = normalize_projects("/test/path")
        assert len(projects) == 1
        assert projects[0] == Path("/test/path")

    def test_normalize_projects_list(self):
        projects = normalize_projects(["/path1", "/path2"])
        assert len(projects) == 2
        assert projects[0] == Path("/path1")
        assert projects[1] == Path("/path2")

    def test_for_each_maven_operation_success(self, tmp_path):
        project1 = tmp_path / "project1"
        project1.mkdir()
        (project1 / "pom.xml").touch()

        project2 = tmp_path / "project2"
        project2.mkdir()
        (project2 / "pom.xml").touch()

        def operation(project):
            return type("Result", (), {"success": True})()

        def error_indicator(result):
            return not result.success

        result = for_each_maven_operation([project1, project2], operation, error_indicator)
        assert result == 0

    def test_for_each_maven_operation_with_error(self, tmp_path):
        project1 = tmp_path / "project1"
        project1.mkdir()
        (project1 / "pom.xml").touch()

        def operation(project):
            return type("Result", (), {"success": False})()

        def error_indicator(result):
            return not result.success

        result = for_each_maven_operation([project1], operation, error_indicator)
        assert result == 1

    def test_execute_maven_operation_result_error_indicator(self):
        success_result = type("Result", (), {"success": True})()
        assert execute_maven_operation_result_error_indicator(success_result) is False

        fail_result = type("Result", (), {"success": False})()
        assert execute_maven_operation_result_error_indicator(fail_result) is True

