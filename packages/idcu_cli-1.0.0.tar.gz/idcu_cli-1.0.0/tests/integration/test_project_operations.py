import os
import tempfile
from pathlib import Path
import pytest
from idcu.tools.project_template import ProjectTemplateManager, EstSpiModuleTemplate


class TestProjectTemplate:
    """测试项目模板功能的集成测试"""
    
    def test_template_initialization(self, tmp_path):
        """测试模板初始化"""
        template = ProjectTemplateManager(repo_root=tmp_path)
        assert template is not None
    
    def test_est_spi_module_template(self):
        """测试EST-SPI模块模板"""
        template = EstSpiModuleTemplate("test-module")
        assert template.name == "test-module"
        pom_xml = template.get_pom_xml()
        assert "<project" in pom_xml
        assert "test-module" in pom_xml
    
    def test_create_simple_project_structure(self, tmp_path):
        """测试创建简单的项目结构"""
        project_dir = tmp_path / "test-project"
        project_dir.mkdir()
        
        src_dir = project_dir / "src"
        src_dir.mkdir()
        
        test_dir = project_dir / "tests"
        test_dir.mkdir()
        
        assert src_dir.exists()
        assert test_dir.exists()
        assert len(list(project_dir.iterdir())) == 2


class TestGitIntegration:
    """测试Git相关功能的集成测试"""
    
    def test_git_directory_detection(self, tmp_path):
        """测试Git目录检测逻辑"""
        non_git_dir = tmp_path / "non-git"
        non_git_dir.mkdir()
        
        git_dir = tmp_path / "git-repo"
        git_dir.mkdir()
        (git_dir / ".git").mkdir()
        
        assert not (non_git_dir / ".git").exists()
        assert (git_dir / ".git").exists()


class TestMavenIntegration:
    """测试Maven相关功能的集成测试"""
    
    def test_maven_project_detection(self, tmp_path):
        """测试Maven项目检测逻辑"""
        non_maven_dir = tmp_path / "non-maven"
        non_maven_dir.mkdir()
        
        maven_dir = tmp_path / "maven-project"
        maven_dir.mkdir()
        (maven_dir / "pom.xml").write_text("<project></project>")
        
        assert not (non_maven_dir / "pom.xml").exists()
        assert (maven_dir / "pom.xml").exists()
