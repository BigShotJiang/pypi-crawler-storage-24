import os
import re
import shutil
import tempfile
from pathlib import Path
from uuid import uuid4

import pytest


TMP_ROOT = Path(__file__).resolve().parent.parent / "tmp_test_workspace"
TMP_ROOT.mkdir(parents=True, exist_ok=True)

os.environ["TMP"] = str(TMP_ROOT)
os.environ["TEMP"] = str(TMP_ROOT)
tempfile.tempdir = str(TMP_ROOT)


class WritableTemporaryDirectory:
    def __init__(self, suffix="", prefix="tmp", dir=None):
        self.base_dir = Path(dir) if dir else TMP_ROOT
        self.suffix = suffix
        self.prefix = prefix
        self.name = None

    def __enter__(self):
        directory = self.base_dir / f"{self.prefix}{uuid4().hex}{self.suffix}"
        directory.mkdir(parents=True, exist_ok=True)
        self.name = str(directory)
        return self.name

    def __exit__(self, exc_type, exc, tb):
        if self.name:
            shutil.rmtree(self.name, ignore_errors=True)
        return False

    def cleanup(self):
        if self.name:
            shutil.rmtree(self.name, ignore_errors=True)


tempfile.TemporaryDirectory = WritableTemporaryDirectory


@pytest.fixture
def tmp_path(request):
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", request.node.name)
    directory = TMP_ROOT / "cases" / f"{safe_name}_{uuid4().hex}"
    directory.mkdir(parents=True, exist_ok=True)
    yield directory
    shutil.rmtree(directory, ignore_errors=True)
