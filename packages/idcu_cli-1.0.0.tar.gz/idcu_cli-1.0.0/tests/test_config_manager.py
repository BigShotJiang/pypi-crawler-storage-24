
from unittest.mock import patch

import pytest

from idcu.system.config_manager import (
    ConfigManager,
    ConfigSchema,
    get_config_manager,
    reset_config_manager,
    set_config_manager,
)

@pytest.fixture(autouse=True)
def reset_config_manager_singleton():
    reset_config_manager()
    yield
    reset_config_manager()


class TestConfigSchema:
    def test_config_schema_defaults(self):
        schema = ConfigSchema()
        assert schema.global_config is not None
        assert schema.i18n_config is not None
        assert schema.plugin_config is not None
        assert schema.git_config is not None
        assert schema.maven_config is not None
        assert schema.audit_config is not None
        assert schema.aliases_config is not None

    def test_config_schema_global_defaults(self):
        schema = ConfigSchema()
        assert schema.global_config["color_output"] is True
        assert schema.global_config["verbose"] is False
        assert schema.global_config["quiet"] is False
        assert schema.global_config["dry_run"] is False

    def test_config_schema_i18n_defaults(self):
        schema = ConfigSchema()
        assert schema.i18n_config["language"] == "en"
        assert schema.i18n_config["auto_detect"] is True

    def test_config_schema_git_defaults(self):
        schema = ConfigSchema()
        assert schema.git_config["default_branch"] == "develop"
        assert schema.git_config["remote_name"] == "origin"
        assert schema.git_config["auto_fetch"] is False

    def test_config_schema_maven_defaults(self):
        schema = ConfigSchema()
        assert schema.maven_config["local_repo_path"] == ".mvn/local-repo"
        assert schema.maven_config["default_goals"] == ["clean", "install"]
        assert schema.maven_config["offline_mode"] is False


class TestConfigManager:
    @pytest.fixture
    def temp_config_dir(self, tmp_path):
        return tmp_path / ".idcu"

    def test_config_manager_init(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        assert manager.config_dir == temp_config_dir
        assert manager.config_file == temp_config_dir / "config.yaml"
        assert temp_config_dir.exists()

    @patch("idcu.system.config_manager.print_success")
    @patch("idcu.system.config_manager.print_error")
    def test_create_default_config(self, mock_print_error, mock_print_success, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        assert (temp_config_dir / "config.yaml").exists()
        mock_print_success.assert_called()

    def test_get_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.get("global", "color_output")
        assert result is True

        result = manager.get("git", "default_branch")
        assert result == "develop"

        result = manager.get("nonexistent", "key", "default_val")
        assert result == "default_val"

    @patch("idcu.system.config_manager.print_success")
    def test_set_config(self, mock_print_success, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set("git", "default_branch", "main")
        assert result is True
        assert manager.get("git", "default_branch") == "main"

        result = manager.set("nonexistent", "key", "val")
        assert result is False

    def test_get_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        global_section = manager.get_section("global")
        assert isinstance(global_section, dict)
        assert "color_output" in global_section

        nonexistent_section = manager.get_section("nonexistent")
        assert nonexistent_section == {}

    @patch("idcu.system.config_manager.print_success")
    def test_set_section(self, mock_print_success, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        new_global = {"color_output": False, "verbose": True}
        result = manager.set_section("global", new_global)
        assert result is True
        assert manager.get("global", "color_output") is False

        result = manager.set_section("nonexistent", {})
        assert result is False

    def test_get_all_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        all_config = manager.get_all_config()
        assert "global" in all_config
        assert "git" in all_config
        assert "maven" in all_config

    @patch("idcu.system.config_manager.print_success")
    def test_reset_to_default(self, mock_print_success, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.set("git", "default_branch", "main")
        result = manager.reset_to_default()
        assert result is True
        assert manager.get("git", "default_branch") == "develop"

    def test_alias_operations(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)

        assert manager.get_alias("test") is None

        result = manager.set_alias("test", "git status")
        assert result is True
        assert manager.get_alias("test") == "git status"

        aliases = manager.list_aliases()
        assert "test" in aliases

        result = manager.delete_alias("test")
        assert result is True
        assert manager.get_alias("test") is None

        result = manager.delete_alias("nonexistent")
        assert result is False

    def test_validate_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.validate_config()
        assert result is True

    def test_get_config_file_path(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        path = manager.get_config_file_path()
        assert path == temp_config_dir / "config.yaml"

    @patch("idcu.system.config_manager.print_info")
    @patch("idcu.system.config_manager.print_success")
    def test_force_reload(self, mock_print_success, mock_print_info, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.force_reload()
        mock_print_info.assert_called()
        mock_print_success.assert_called()

    @patch("idcu.system.config_manager.print_info")
    @patch("idcu.system.config_manager.print_success")
    def test_reload_if_changed_no_change(self, mock_print_success, mock_print_info, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.reload_if_changed()
        assert result is False

    def test_config_with_custom_values(self, temp_config_dir):
        schema = ConfigSchema()
        custom_global = {"color_output": False, "verbose": True}
        schema.global_config = custom_global
        assert schema.global_config["color_output"] is False


@patch("idcu.system.config_manager.Path.cwd")
def test_get_config_manager_singleton(mock_cwd, tmp_path):
    mock_cwd.return_value = tmp_path
    manager1 = get_config_manager()
    manager2 = get_config_manager()
    assert manager1 is manager2


class TestConfigManagerWithJSON:
    @pytest.fixture
    def temp_config_dir_json(self, tmp_path):
        config_dir = tmp_path / ".idcu"
        config_dir.mkdir()
        return config_dir

    @patch("idcu.system.config_manager.HAS_YAML", False)
    def test_config_manager_json_fallback(self, temp_config_dir_json):
        manager = ConfigManager(temp_config_dir_json)
        assert (temp_config_dir_json / "config.yaml").exists()


class TestConfigManagerErrorHandling:
    @pytest.fixture
    def temp_config_dir_errors(self, tmp_path):
        return tmp_path / ".idcu"

    @pytest.fixture
    def temp_config_dir(self, tmp_path):
        return tmp_path / ".idcu"

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_save_config_error(self, mock_open, mock_print_error, temp_config_dir_errors):
        manager = ConfigManager(temp_config_dir_errors)
        result = manager.save_config()
        assert result is False
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_set_config_error(self, mock_open, mock_print_error, temp_config_dir_errors):
        manager = ConfigManager(temp_config_dir_errors)
        result = manager.set("global", "color_output", False)
        assert result is False

    @patch("idcu.system.config_manager.print_info")
    @patch("idcu.system.config_manager.print_success")
    def test_reload_if_changed_with_change(self, mock_print_success, mock_print_info, temp_config_dir):
        manager = ConfigManager(temp_config_dir)

        with patch("os.stat") as mock_stat:
            mock_stat.return_value.st_mtime = 2.0
            manager._last_modified = 1.0
            result = manager.reload_if_changed()
            assert result is True
            mock_print_info.assert_called()
            mock_print_success.assert_called()

    @patch("idcu.system.config_manager.print_error")
    def test_reload_if_changed_error(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)

        with patch("os.stat", side_effect=Exception("Stat error")):
            result = manager.reload_if_changed()
            assert result is False
            mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_create_default_config_error(self, mock_open, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    @patch("idcu.system.config_manager.print_info")
    def test_load_config_error(self, mock_print_info, mock_print_error, temp_config_dir):
        temp_config_dir.mkdir()
        config_file = temp_config_dir / "config.yaml"
        config_file.write_text("invalid yaml: [")

        manager = ConfigManager(temp_config_dir)
        mock_print_error.assert_called()
        mock_print_info.assert_called()

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_set_alias_error(self, mock_open, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set_alias("test", "command")
        assert result is False

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_delete_alias_error(self, mock_open, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.set_alias("test", "command")
        result = manager.delete_alias("test")
        assert result is False

    @patch("idcu.system.config_manager.print_error")
    def test_validate_config_missing_global(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.config.global_config.pop("color_output")
        result = manager.validate_config()
        assert result is False
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    def test_validate_config_missing_git(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.config.git_config.pop("default_branch")
        result = manager.validate_config()
        assert result is False
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    def test_validate_config_missing_i18n(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.config.i18n_config.pop("language")
        result = manager.validate_config()
        assert result is False
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    def test_validate_config_missing_maven(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        manager.config.maven_config.pop("local_repo_path")
        result = manager.validate_config()
        assert result is False
        mock_print_error.assert_called()

    @patch("idcu.system.config_manager.print_error")
    def test_validate_config_exception(self, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)

        original_validate = manager.validate_config

        def bad_validate():
            raise Exception("Validation error")

        manager.validate_config = bad_validate
        try:
            result = manager.validate_config()
            assert result is False
        except:
            pass
        finally:
            manager.validate_config = original_validate

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_reset_to_default_error(self, mock_open, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.reset_to_default()
        assert result is False

    @patch("idcu.system.config_manager.print_error")
    @patch("builtins.open", side_effect=Exception("IO Error"))
    def test_set_section_error(self, mock_open, mock_print_error, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set_section("global", {})
        assert result is False

    def test_set_plugins_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set("plugins", "test_plugin", {"enabled": True})
        assert result is True
        assert manager.get("plugins", "test_plugin") == {"enabled": True}

    def test_set_plugins_config_new_key(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set("plugins", "new_plugin", {"config": "value"})
        assert result is True
        assert manager.get("plugins", "new_plugin") == {"config": "value"}

    def test_get_plugins_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        plugins_section = manager.get_section("plugins")
        assert isinstance(plugins_section, dict)
        assert plugins_section == {}

    def test_set_plugins_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        new_plugins = {"plugin1": {"enabled": True}}
        result = manager.set_section("plugins", new_plugins)
        assert result is True
        assert manager.get_section("plugins") == new_plugins

    def test_get_audit_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        audit_section = manager.get_section("audit")
        assert isinstance(audit_section, dict)
        assert "encoding_scan_patterns" in audit_section

    def test_set_audit_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set("audit", "deps_audit_strict", False)
        assert result is True
        assert manager.get("audit", "deps_audit_strict") is False

    def test_set_audit_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        new_audit = {"deps_audit_strict": False}
        result = manager.set_section("audit", new_audit)
        assert result is True
        assert manager.get("audit", "deps_audit_strict") is False

    def test_get_maven_section(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        maven_section = manager.get_section("maven")
        assert isinstance(maven_section, dict)
        assert "local_repo_path" in maven_section

    def test_set_maven_config(self, temp_config_dir):
        manager = ConfigManager(temp_config_dir)
        result = manager.set("maven", "offline_mode", True)
        assert result is True
        assert manager.get("maven", "offline_mode") is True

