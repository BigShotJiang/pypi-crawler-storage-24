
import sys
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from idcu.core.app_context import AppContext
from idcu.core.constants import DEFAULT_BRANCH, REMOTE_NAME
from idcu.core.encoding_utils import (
    EncodingResult,
    _match_any_pattern,
    calculate_text_quality,
    detect_bom,
    detect_encoding_with_fallback,
    detect_file_encoding,
    has_garbage_text,
    is_valid_char_code,
    try_all_encodings,
    try_fix_encoding,
)
from idcu.core.ui import (
    Colors,
    ProgressBar,
    _format_message,
    _print_message,
    _resolve_color,
    _supports_text,
    colorize,
    print_error,
    print_error_with_suggestion,
    print_header,
    print_info,
    print_json,
    print_section,
    print_success,
    print_table,
    print_warning,
)
from idcu.core.utils import Timer, format_size


def test_timer():
    timer = Timer("test")
    timer.start()
    assert timer.start_time is not None
    timer.stop()
    assert timer.elapsed() >= 0


def test_timer_context_manager():
    with Timer("context") as timer:
        assert timer.start_time is not None
    assert timer.end_time is not None
    assert timer.elapsed() >= 0


def test_timer_without_start():
    timer = Timer("test")
    assert timer.elapsed() == 0.0


def test_format_size():
    assert format_size(0) == "0 B"
    assert format_size(1024) == "1.0 KB"
    assert format_size(1024 * 1024) == "1.0 MB"
    assert format_size(1024 * 1024 * 1024) == "1.0 GB"
    assert format_size(1536) == "1.5 KB"


def test_constants():
    assert DEFAULT_BRANCH == "develop"
    assert REMOTE_NAME == "origin"


class TestColors:
    def test_colors_initial_values(self):
        assert Colors.RESET == "\033[0m"
        assert Colors.BOLD == "\033[1m"
        assert Colors.RED == "\033[91m"
        assert Colors.GREEN == "\033[92m"

    def test_colors_disable(self):
        Colors.disable()
        assert Colors.RESET == ""
        Colors.RESET = "\033[0m"
        Colors.BOLD = "\033[1m"
        Colors.RED = "\033[91m"
        Colors.GREEN = "\033[92m"
        Colors.YELLOW = "\033[93m"
        Colors.BLUE = "\033[94m"
        Colors.MAGENTA = "\033[95m"
        Colors.CYAN = "\033[96m"
        Colors.WHITE = "\033[97m"
        Colors.BG_RED = "\033[41m"
        Colors.BG_GREEN = "\033[42m"
        Colors.BG_YELLOW = "\033[43m"
        Colors.BG_BLUE = "\033[44m"
        Colors.BG_MAGENTA = "\033[45m"
        Colors.BG_CYAN = "\033[46m"
        Colors.BG_WHITE = "\033[47m"

    def test_resolve_color(self):
        assert _resolve_color("RED") == "\033[91m"
        assert _resolve_color("\033[91m") == "\033[91m"
        assert _resolve_color(None) == ""
        assert _resolve_color("") == ""


def test_colorize():
    assert colorize("test", "RED") == "\033[91mtest\033[0m"
    assert colorize("", "RED") == ""


def test_supports_text():
    assert _supports_text("hello", sys.stdout) is True


def test_format_message():
    assert _format_message("[OK]", "test") == "[OK] test"
    assert _format_message("[OK]", "") == ""
    assert _format_message("[OK]", None) == ""


def test_print_message():
    captured_output = StringIO()
    _print_message("test message", "GREEN", "\u2713", "[OK]", captured_output)
    output = captured_output.getvalue()
    assert "test message" in output


def test_print_functions():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_success("success")
        print_warning("warning")
        print_info("info")
        print_header("header")
        print_section("section")
    output = captured_output.getvalue()
    assert "success" in output or "warning" in output or "info" in output


def test_print_error():
    captured_output = StringIO()
    with patch('sys.stderr', new=captured_output):
        print_error("error")
    output = captured_output.getvalue()
    assert "error" in output


class TestProgressBar:
    def test_progress_bar_init(self):
        pb = ProgressBar(100)
        assert pb.total == 100
        assert pb.current == 0

    def test_progress_bar_update_current(self):
        pb = ProgressBar(100)
        pb.update(current=50)
        assert pb.current == 50

    def test_progress_bar_update_increment(self):
        pb = ProgressBar(100)
        pb.update(increment=10)
        assert pb.current == 10

    def test_progress_bar_context_manager(self):
        with ProgressBar(100) as pb:
            pb.update(increment=50)
        assert pb.current == 100


def test_print_table():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_table(["Col1", "Col2"], [["Val1", "Val2"]])
    output = captured_output.getvalue()
    assert "Col1" in output
    assert "Val1" in output


def test_print_table_empty():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_table(["Col1"], [])
    output = captured_output.getvalue()
    assert "无数据" in output


def test_print_json():
    captured_output = StringIO()
    with patch('sys.stdout', new=captured_output):
        print_json({"key": "value"})
    output = captured_output.getvalue()
    assert "key" in output
    assert "value" in output


def test_print_error_with_suggestion():
    captured_output = StringIO()
    with patch('sys.stderr', new=captured_output), patch('sys.stdout', new=captured_output):
        print_error_with_suggestion("error", ["fix1", "fix2"])
    output = captured_output.getvalue()
    assert "error" in output
    assert "fix1" in output


class TestEncodingUtils:
    def test_encoding_result_init(self):
        result = EncodingResult("test.txt", "utf-8", 0.9)
        assert result.path == "test.txt"
        assert result.encoding == "utf-8"
        assert result.confidence == 0.9

    def test_detect_bom(self):
        utf8_bom = b"\xef\xbb\xbfhello"
        encoding, bom = detect_bom(utf8_bom)
        assert encoding == "utf-8-sig"
        assert bom == b"\xef\xbb\xbf"

    def test_detect_bom_none(self):
        encoding, bom = detect_bom(b"no bom")
        assert encoding is None
        assert bom is None

    def test_is_valid_char_code(self):
        assert is_valid_char_code(65) is True
        assert is_valid_char_code(-1) is False
        assert is_valid_char_code(0xD800) is False
        assert is_valid_char_code(0xE000) is True
        assert is_valid_char_code(0x10FFFF) is True
        assert is_valid_char_code(0x110000) is False

    def test_calculate_text_quality(self):
        assert calculate_text_quality("") == 0.0
        quality = calculate_text_quality("Hello 世界!")
        assert quality > 0

    def test_detect_encoding_with_fallback_utf8(self):
        data = "Hello 世界!".encode()
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None

    def test_has_garbage_text_clean(self):
        has_garbage, count = has_garbage_text("Clean text")
        assert has_garbage is False

    def test_detect_file_encoding(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello 世界!", encoding="utf-8")
        result = detect_file_encoding(str(test_file))
        assert result.success is True

    def test_try_all_encodings(self):
        data = b"Hello"
        results = try_all_encodings(data)
        assert len(results) > 0

    def test_try_fix_encoding(self):
        data = b"Hello"
        text, encoding = try_fix_encoding(data)
        assert text == "Hello"

    def test_match_any_pattern(self):
        path = Path("test.py")
        assert _match_any_pattern(path, ["*.py"]) is True
        assert _match_any_pattern(path, ["*.txt"]) is False

    def test_match_any_pattern_with_string_match(self):
        path = Path("test.txt")
        assert _match_any_pattern(path, ["test"]) is True

    def test_calculate_text_quality_with_empty(self):
        assert calculate_text_quality("") == 0.0
        assert calculate_text_quality("   ") > 0

    def test_calculate_text_quality_with_high_quality(self):
        quality = calculate_text_quality("Hello world! This is a test with good quality text.")
        assert quality > 50

    def test_detect_encoding_with_fallback_utf16(self):
        data = "Hello".encode("utf-16-le")
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None

    def test_detect_encoding_with_fallback_low_quality(self):
        data = b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09" * 100
        encoding, confidence = detect_encoding_with_fallback(data)
        assert encoding is not None
        assert confidence <= 1.0

    def test_has_garbage_text_with_garbage(self):
        has_garbage, count = has_garbage_text("\ufffd\ufffe\uffff garbage text")
        assert has_garbage is True
        assert count > 0

    def test_has_garbage_text_with_invalid_consecutive(self):
        invalid_text = "".join([chr(0xFFFF) for _ in range(5)])
        has_garbage, count = has_garbage_text(invalid_text)
        assert has_garbage is True
        assert count >= 5

    def test_detect_file_encoding_error(self, tmp_path):
        test_file = tmp_path / "nonexistent.txt"
        result = detect_file_encoding(str(test_file))
        assert result.success is False
        assert result.error_message is not None

    def test_try_all_encodings_with_replace(self):
        invalid_data = b"\xFF\xFE\xFD\xFC"
        results = try_all_encodings(invalid_data)
        assert len(results) >= 0

    def test_try_fix_encoding_with_medium_quality(self):
        data = b"Test text with some content"
        text, encoding = try_fix_encoding(data)
        assert text is not None
        assert encoding is not None

    def test_try_fix_encoding_with_fallback(self):
        data = b"\xFF\xFE\xFD\xFC\xFB\xFA"
        text, encoding = try_fix_encoding(data)
        assert text is not None
        assert encoding is not None

    def test_fix_file_encoding(self, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello 世界!", encoding="gbk")
        from idcu.core.encoding_utils import fix_file_encoding
        result = fix_file_encoding(str(test_file), backup=False)
        assert result.success is True or result.success is False

    def test_fix_file_encoding_error(self, tmp_path):
        from idcu.core.encoding_utils import fix_file_encoding
        test_file = tmp_path / "nonexistent.txt"
        result = fix_file_encoding(str(test_file))
        assert result.success is False

    def test_fix_file_encoding_safe(self, tmp_path):
        from idcu.core.encoding_utils import fix_file_encoding_safe
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello")
        result = fix_file_encoding_safe(str(test_file))
        assert result is not None

    def test_detect_garbage(self, tmp_path):
        from idcu.core.encoding_utils import detect_garbage
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello")
        result = detect_garbage(str(test_file))
        assert result is not None

    def test_fix_garbage(self, tmp_path):
        from idcu.core.encoding_utils import fix_garbage
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello")
        result = fix_garbage(str(test_file), backup=False)
        assert result is not None

    def test_fix_garbage_safe(self, tmp_path):
        from idcu.core.encoding_utils import fix_garbage_safe
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello")
        result = fix_garbage_safe(str(test_file))
        assert result is not None

    def test_process_path_file(self, tmp_path):
        from idcu.core.encoding_utils import process_path
        test_file = tmp_path / "test.java"
        test_file.write_text("public class Test {}")
        results = process_path(str(test_file), backup=False)
        assert isinstance(results, list)

    def test_process_path_directory(self, tmp_path):
        from idcu.core.encoding_utils import process_path
        test_dir = tmp_path / "src"
        test_dir.mkdir()
        test_file = test_dir / "test.java"
        test_file.write_text("public class Test {}")
        results = process_path(str(test_dir), backup=False)
        assert isinstance(results, list)

    def test_process_path_safe(self, tmp_path):
        from idcu.core.encoding_utils import process_path_safe
        test_file = tmp_path / "test.java"
        test_file.write_text("public class Test {}")
        results = process_path_safe(str(test_file))
        assert isinstance(results, list)

    def test_process_path_exclude(self, tmp_path):
        from idcu.core.encoding_utils import process_path
        test_file = tmp_path / "target" / "test.java"
        test_file.parent.mkdir()
        test_file.write_text("public class Test {}")
        results = process_path(str(test_file), backup=False)
        assert len(results) == 1 or len(results) == 0

def test_app_context_uses_injected_managers(tmp_path):
    from idcu.system.config_manager import ConfigManager
    from idcu.system.logger import LoggerManager
    from idcu.tools.plugins.base import PluginManager

    config_manager = ConfigManager(tmp_path / "config")
    logger_manager = LoggerManager(tmp_path / "logs", config_manager=config_manager)
    plugin_manager = PluginManager()

    context = AppContext(
        base_dir=tmp_path,
        config_manager=config_manager,
        logger_manager=logger_manager,
        plugin_manager=plugin_manager,
    )

    assert context.config_manager is config_manager
    assert context.logger_manager is logger_manager
    assert context.plugin_manager is plugin_manager


def test_app_context_builds_logger_from_injected_config_manager(tmp_path):
    from idcu.system.config_manager import ConfigManager

    config_manager = ConfigManager(tmp_path / "config")
    context = AppContext(base_dir=tmp_path, config_manager=config_manager)

    assert context.logger_manager._config_manager is config_manager
