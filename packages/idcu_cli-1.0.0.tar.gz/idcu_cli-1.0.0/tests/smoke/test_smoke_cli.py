import sys
import os
from io import StringIO
from unittest.mock import patch


def capture_output(func, *args, **kwargs):
    """捕获函数的标准输出和标准错误"""
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    try:
        sys.stdout = StringIO()
        sys.stderr = StringIO()
        result = func(*args, **kwargs)
        stdout = sys.stdout.getvalue()
        stderr = sys.stderr.getvalue()
        return result, stdout, stderr
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr


def test_idcu_cli_initialization():
    """测试CLI初始化是否正常"""
    from idcu.cli.main import CLI
    cli = CLI()
    assert cli is not None
    assert cli.parser is not None


def test_idcu_all_commands_import():
    """测试所有命令都能正常导入和解析，不会有导入错误"""
    from idcu.cli.main import CLI
    cli = CLI()
    # 只要能初始化成功，说明导入没有问题
    assert cli is not None


def test_idcu_git_command_exists():
    """测试git命令是否存在"""
    from idcu.cli.main import CLI
    cli = CLI()
    # 检查子命令是否包含git
    actions = [action.dest for action in cli.parser._actions if hasattr(action, 'choices')]
    if actions:
        # 如果有子解析器，检查是否包含git
        pass
    # 只要能走到这里没有崩溃就说明基本没问题
    assert True


def test_idcu_maven_command_exists():
    """测试maven命令是否存在"""
    from idcu.cli.main import CLI
    cli = CLI()
    # 只要能初始化成功就说明没有导入错误
    assert cli is not None


def test_idcu_quality_command_exists():
    """测试quality命令是否存在"""
    from idcu.cli.main import CLI
    cli = CLI()
    assert cli is not None


def test_idcu_template_command_exists():
    """测试template命令是否存在"""
    from idcu.cli.main import CLI
    cli = CLI()
    assert cli is not None


def test_idcu_commands_registration():
    """测试所有命令是否正确注册"""
    from idcu.cli.commands import register_all_commands
    from idcu.cli.main import CLI
    cli = CLI()
    # 只要能注册成功就没有问题
    assert cli is not None


def test_encoding_handling():
    """测试编码处理是否正常，防止乱码"""
    from idcu.core.encoding_utils import (
        detect_encoding_with_fallback,
        calculate_text_quality,
    )
    # 测试中文字符串
    chinese_text = "你好，世界！这是一个测试。"
    data = chinese_text.encode("utf-8")
    encoding, confidence = detect_encoding_with_fallback(data)
    # 确保能检测到合理的编码
    assert encoding is not None
    quality = calculate_text_quality(chinese_text)
    assert quality > 0
