
import pytest

from idcu.system.config.schema import get_config_schema
from idcu.system.config.validator import ConfigValidator, ValidationError, validate_config


class TestConfigSchema:
    def test_get_config_schema(self):
        schema = get_config_schema()
        assert "global" in schema
        assert "i18n" in schema
        assert "git" in schema
        assert "maven" in schema
        assert "audit" in schema

    def test_global_section_schema(self):
        schema = get_config_schema()
        global_schema = schema["global"]
        assert global_schema["type"] == "object"
        assert "color_output" in global_schema["properties"]
        assert "verbose" in global_schema["properties"]
        assert "quiet" in global_schema["properties"]
        assert "dry_run" in global_schema["properties"]
        assert "log_level" in global_schema["properties"]
        assert "color_output" in global_schema["required"]

    def test_git_section_schema(self):
        schema = get_config_schema()
        git_schema = schema["git"]
        assert "default_branch" in git_schema["properties"]
        assert "remote_name" in git_schema["properties"]
        assert "auto_fetch" in git_schema["properties"]


class TestValidationError:
    def test_validation_error_init(self):
        error = ValidationError("test.field", "Test message")
        assert error.field == "test.field"
        assert error.message == "Test message"

    def test_validation_error_str(self):
        error = ValidationError("global.color_output", "Invalid value")
        assert str(error) == "[global.color_output] Invalid value"


class TestConfigValidator:
    @pytest.fixture
    def sample_schema(self):
        return {
            "section": {
                "type": "object",
                "properties": {
                    "bool_field": {"type": "boolean"},
                    "str_field": {"type": "string", "enum": ["a", "b", "c"]},
                    "int_field": {"type": "integer", "minimum": 10},
                    "arr_field": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["bool_field"]
            }
        }

    @pytest.fixture
    def full_schema(self):
        return get_config_schema()

    def test_validator_init(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        assert validator.schema == sample_schema
        assert validator.errors == []

    def test_validate_success(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {
            "section": {
                "bool_field": True,
                "str_field": "a",
                "int_field": 15,
                "arr_field": ["test"]
            }
        }
        is_valid, errors = validator.validate(config)
        assert is_valid is True
        assert errors == []

    def test_validate_missing_section(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert len(errors) == 1
        assert "Missing required section" in errors[0].message

    def test_validate_missing_required_field(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert len(errors) == 1
        assert "Missing required field" in errors[0].message

    def test_validate_type_error_boolean(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": "not a bool"}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert len(errors) == 1
        assert "Expected type boolean" in errors[0].message

    def test_validate_type_error_string(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "str_field": 123}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert "Expected type string" in errors[0].message

    def test_validate_type_error_integer(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "int_field": "not int"}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert "Expected type integer" in errors[0].message

    def test_validate_type_error_array(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "arr_field": "not array"}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert "Expected type array" in errors[0].message

    def test_validate_string_enum_invalid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "str_field": "invalid"}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert "Value must be one of" in errors[0].message

    def test_validate_string_enum_valid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "str_field": "b"}}
        is_valid, errors = validator.validate(config)
        assert is_valid is True

    def test_validate_integer_minimum_invalid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "int_field": 5}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert "Value must be at least" in errors[0].message

    def test_validate_integer_minimum_valid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "int_field": 10}}
        is_valid, errors = validator.validate(config)
        assert is_valid is True

    def test_validate_array_items_invalid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "arr_field": ["valid", 123]}}
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert len(errors) == 1
        assert "Expected type string" in errors[0].message

    def test_validate_array_items_valid(self, sample_schema):
        validator = ConfigValidator(sample_schema)
        config = {"section": {"bool_field": True, "arr_field": ["a", "b", "c"]}}
        is_valid, errors = validator.validate(config)
        assert is_valid is True

    def test_validate_full_schema_valid(self, full_schema):
        validator = ConfigValidator(full_schema)
        config = {
            "global": {
                "color_output": True,
                "verbose": False,
                "quiet": False,
                "dry_run": False,
                "log_level": "INFO",
                "log_max_file_size": 1048576,
                "log_backup_count": 5
            },
            "i18n": {
                "language": "zh",
                "auto_detect": True
            },
            "git": {
                "default_branch": "main",
                "remote_name": "origin",
                "auto_fetch": True
            },
            "maven": {
                "local_repo_path": "~/.m2/repository",
                "default_goals": ["clean", "install"],
                "offline_mode": False
            },
            "audit": {
                "encoding_scan_patterns": ["*.py", "*.java"],
                "encoding_scan_excludes": ["test_*"],
                "deps_audit_strict": True
            },
            "project": {
                "type": "est-spi",
                "version": "2.0.0",
                "jdk": "1.8",
                "tiers": []
            }
        }
        is_valid, errors = validator.validate(config)
        assert is_valid is True
        assert errors == []

    def test_validate_full_schema_invalid_log_level(self, full_schema):
        validator = ConfigValidator(full_schema)
        config = {
            "global": {
                "color_output": True,
                "verbose": False,
                "quiet": False,
                "dry_run": False,
                "log_level": "INVALID"
            },
            "i18n": {"language": "zh"},
            "git": {"default_branch": "main", "remote_name": "origin"},
            "maven": {"local_repo_path": "~/.m2", "default_goals": ["clean"]},
            "audit": {},
            "project": {
                "type": "est-spi",
                "version": "2.0.0",
                "jdk": "1.8",
                "tiers": []
            }
        }
        is_valid, errors = validator.validate(config)
        assert is_valid is False
        assert len(errors) >= 1
        has_log_level_error = any("log_level" in e.field and "Value must be one of" in e.message for e in errors)
        assert has_log_level_error


class TestValidateConfigFunction:
    def test_validate_config_with_default_schema(self):
        config = {
            "global": {
                "color_output": True,
                "verbose": False,
                "quiet": False,
                "dry_run": False
            },
            "i18n": {"language": "zh"},
            "git": {"default_branch": "main", "remote_name": "origin"},
            "maven": {"local_repo_path": "~/.m2", "default_goals": ["clean"]},
            "audit": {},
            "project": {
                "type": "est-spi",
                "version": "2.0.0",
                "jdk": "1.8",
                "tiers": []
            }
        }
        is_valid, errors = validate_config(config)
        assert is_valid is True

    def test_validate_config_with_custom_schema(self):
        custom_schema = {
            "test": {
                "type": "object",
                "properties": {"field": {"type": "string"}},
                "required": ["field"]
            }
        }
        config = {"test": {"field": "value"}}
        is_valid, errors = validate_config(config, custom_schema)
        assert is_valid is True

