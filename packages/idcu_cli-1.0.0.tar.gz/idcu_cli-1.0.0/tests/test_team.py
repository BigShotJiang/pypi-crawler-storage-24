

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from idcu.tools.team import config, permissions


def test_team_config_init():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        assert team_config.get_team_name() == ""
        assert isinstance(team_config.get_members(), list)


def test_team_config_set_name():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.set_team_name("Test Team")
        assert team_config.get_team_name() == "Test Team"


def test_team_config_add_member():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.add_member("Test User", "test@example.com", "member")
        members = team_config.get_members()
        
        assert len(members) == 1
        assert members[0]["name"] == "Test User"
        assert members[0]["email"] == "test@example.com"
        assert members[0]["role"] == "member"


def test_team_config_shared_config():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.set_shared_config("key1", "value1")
        assert team_config.get_shared_config("key1") == "value1"
        
        team_config.set_shared_config("key2", {"nested": "value"})
        assert team_config.get_shared_config("key2") == {"nested": "value"}


def test_team_config_history():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.set_shared_config("history_test", "v1")
        team_config.set_shared_config("history_test", "v2")
        
        history = team_config.get_config_history("history_test")
        assert len(history) >= 2


def test_team_config_export():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        export_path = Path(tmpdir) / "exported_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.set_team_name("Export Test")
        team_config.export_config(str(export_path))
        
        assert export_path.exists()


def test_team_config_remove_member():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        
        team_config.add_member("User1", "user1@example.com")
        team_config.add_member("User2", "user2@example.com")
        
        assert len(team_config.get_members()) == 2
        
        team_config.remove_member("user1@example.com")
        members = team_config.get_members()
        
        assert len(members) == 1
        assert members[0]["email"] == "user2@example.com"


def test_permission_manager_add_role():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        perm_manager = permissions.PermissionManager(team_config)
        
        perm_manager.add_role("test_role", ["perm1", "perm2"])
        
        roles = perm_manager.get_roles()
        assert "test_role" in roles
        assert roles["test_role"]["permissions"] == ["perm1", "perm2"]


def test_permission_manager_set_and_check_permission():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "team_config.yaml"
        team_config = config.TeamConfig(config_path=str(tmp_path))
        perm_manager = permissions.PermissionManager(team_config)
        
        team_config.add_member("Test User", "test@example.com", "member")
        
        assert perm_manager.has_permission("test@example.com", "config.read") is True
        assert perm_manager.has_permission("test@example.com", "nonexistent.perm") is False
        
        perm_manager.set_member_role("test@example.com", "admin")
        assert perm_manager.has_permission("test@example.com", "any.perm") is True
