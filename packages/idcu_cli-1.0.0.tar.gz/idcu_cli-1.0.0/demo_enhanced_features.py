
#!/usr/bin/env python3
"""增强版功能演示脚本

展示统一输出格式、失败码规范、dry-run和JSON输出等功能
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from idcu.tools.git.git_enhanced import GitEnhancedOperations
from idcu.tools.maven.maven_enhanced import MavenEnhancedOperations
from idcu.core import OperationResult, BatchOperationReport, OutputFormatter, ErrorCode


def demo_unified_output():
    """演示统一输出格式"""
    print("\n" + "="*70)
    print("1. 统一输出格式演示")
    print("="*70)
    
    git_ops = GitEnhancedOperations(json_mode=False, dry_run=False)
    
    print("\n--- Git show 操作 (统一格式输出) ---")
    result = git_ops.show()
    git_ops.print_result(result)


def demo_dry_run():
    """演示dry-run模式"""
    print("\n" + "="*70)
    print("2. Dry-Run 模式演示")
    print("="*70)
    
    git_ops = GitEnhancedOperations(json_mode=False, dry_run=True)
    
    print("\n--- Git status 操作 (Dry-Run 模式) ---")
    result = git_ops.status()
    git_ops.print_result(result)
    
    print("\n--- Git clean 操作 (Dry-Run 模式) ---")
    maven_ops = MavenEnhancedOperations(json_mode=False, dry_run=True)
    result = maven_ops.clean()
    maven_ops.print_result(result)


def demo_json_output():
    """演示JSON输出模式"""
    print("\n" + "="*70)
    print("3. JSON 输出模式演示")
    print("="*70)
    
    git_ops = GitEnhancedOperations(json_mode=True, dry_run=False)
    
    print("\n--- Git log 操作 (JSON 输出模式) ---")
    result = git_ops.log(limit=3)
    git_ops.print_result(result)


def demo_error_codes():
    """演示错误码规范"""
    print("\n" + "="*70)
    print("4. 错误码规范演示")
    print("="*70)
    
    from idcu.core import ErrorCode
    
    print("\n可用的错误码:")
    print(f"  SUCCESS: {ErrorCode.SUCCESS.value} - {ErrorCode.SUCCESS.name}")
    print(f"  GENERAL_ERROR: {ErrorCode.GENERAL_ERROR.value} - {ErrorCode.GENERAL_ERROR.name}")
    print(f"  GIT_ERROR_BASE: {ErrorCode.GIT_ERROR_BASE.value} - {ErrorCode.GIT_ERROR_BASE.name}")
    print(f"  GIT_NOT_A_REPO: {ErrorCode.GIT_NOT_A_REPO.value} - {ErrorCode.GIT_NOT_A_REPO.name}")
    print(f"  MAVEN_ERROR_BASE: {ErrorCode.MAVEN_ERROR_BASE.value} - {ErrorCode.MAVEN_ERROR_BASE.name}")
    print(f"  MAVEN_NOT_FOUND: {ErrorCode.MAVEN_NOT_FOUND.value} - {ErrorCode.MAVEN_NOT_FOUND.name}")
    print(f"  DRY_RUN: {ErrorCode.DRY_RUN.value} - {ErrorCode.DRY_RUN.name}")


def demo_batch_operations():
    """演示批量操作（概念演示）"""
    print("\n" + "="*70)
    print("5. 批量操作报告（概念演示）")
    print("="*70)
    
    report = BatchOperationReport(operation_name="Git Status 批量检查")
    
    result1 = OperationResult.success_result(
        message="状态检查成功",
        project="project-a",
        duration_seconds=0.5
    )
    report.add_result(result1)
    
    result2 = OperationResult.success_result(
        message="状态检查成功",
        project="project-b",
        duration_seconds=0.7
    )
    report.add_result(result2)
    
    result3 = OperationResult.error_result(
        error_code=ErrorCode.GIT_NOT_A_REPO,
        message="不是Git仓库",
        project="project-c",
        duration_seconds=0.1
    )
    report.add_result(result3)
    
    report.finish()
    
    print("\n--- 批量操作报告 ---")
    formatter = OutputFormatter(json_mode=False, dry_run=False)
    formatter.print_batch_report(report)


def demo_json_batch_report():
    """演示JSON格式的批量操作报告"""
    print("\n" + "="*70)
    print("6. JSON 格式批量操作报告（概念演示）")
    print("="*70)
    
    report = BatchOperationReport(operation_name="Maven Build 批量构建")
    
    result1 = OperationResult.success_result(
        message="构建成功",
        project="module-api",
        duration_seconds=12.5
    )
    report.add_result(result1)
    
    result2 = OperationResult.dry_run_result(
        message="Dry-run 模拟构建",
        project="module-impl",
        duration_seconds=0.0
    )
    report.add_result(result2)
    
    report.finish()
    
    print("\n--- JSON 批量操作报告 ---")
    formatter = OutputFormatter(json_mode=True, dry_run=False)
    formatter.print_batch_report(report)


def main():
    """主演示函数"""
    print("\n" + "="*70)
    print("IDCU CLI - 增强版功能演示")
    print("="*70)
    print("\n演示内容:")
    print("  1. 统一输出格式")
    print("  2. Dry-Run 模式")
    print("  3. JSON 输出模式")
    print("  4. 错误码规范")
    print("  5. 批量操作报告")
    print("  6. JSON 批量操作报告")
    
    try:
        demo_unified_output()
        demo_dry_run()
        demo_json_output()
        demo_error_codes()
        demo_batch_operations()
        demo_json_batch_report()
        
        print("\n" + "="*70)
        print("演示完成!")
        print("="*70)
        print("\n这些功能使 IDCU CLI 从 '工具集合' 提升为 '可以接入自动化链路的 CLI 产品'")
        
    except Exception as e:
        print(f"\n演示过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
