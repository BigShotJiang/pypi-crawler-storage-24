# 最小用户旅程

本文档描述新用户从安装到使用 IDCU CLI 的最小、完整的用户旅程。

---

## 旅程 1：新手入门（5 分钟）

### 目标
让用户在 5 分钟内完成安装并体验核心功能。

### 步骤

#### 1. 安装 IDCU CLI（1 分钟）
```bash
pip install idcu-cli
```

**预期结果：**
- 安装成功完成
- 无错误信息

#### 2. 验证安装（30 秒）
```bash
idcu --version
idcu --help
```

**预期结果：**
- 显示版本号（如：`IDCU CLI 1.0.0`）
- 显示完整的帮助信息

#### 3. 查看可用命令（30 秒）
```bash
idcu
```

**预期结果：**
- 显示交互式菜单（如果安装了 interactive 依赖）
- 或显示帮助信息

#### 4. 配置管理入门（1 分钟）
```bash
idcu config show
```

**预期结果：**
- 显示当前配置
- 创建默认配置文件（如不存在）

#### 5. 设置命令别名（1 分钟）
```bash
idcu alias set gs "git status"
idcu alias list
```

**预期结果：**
- 别名设置成功
- 列出所有已设置的别名

---

## 旅程 2：Git 工作流（10 分钟）

### 目标
体验多仓库 Git 管理功能。

### 前置条件
- 已安装 Git
- 当前目录下有一个或多个 Git 仓库

### 步骤

#### 1. 扫描 Git 仓库（1 分钟）
```bash
idcu git list
```

**预期结果：**
- 列出所有发现的 Git 仓库

#### 2. 查看仓库状态（2 分钟）
```bash
idcu git status
```

**预期结果：**
- 显示所有仓库的状态
- 清晰标识有变更的仓库

#### 3. 分支操作（2 分钟）
```bash
idcu git switch develop
```

**预期结果：**
- 切换到指定分支（支持多仓库）

#### 4. 提交更改（3 分钟）
```bash
idcu git commit -m "feat: add new feature" -a
```

**预期结果：**
- 提交所有暂存的更改
- 显示提交结果

#### 5. 同步远程（2 分钟）
```bash
idcu git pull
idcu git push
```

**预期结果：**
- 拉取远程更新
- 推送本地提交

---

## 旅程 3：Maven 构建（10 分钟）

### 目标
体验 Maven 项目管理和构建功能。

### 前置条件
- 已安装 Java 和 Maven
- 当前目录下有 Maven 项目

### 步骤

#### 1. 扫描 Maven 项目（1 分钟）
```bash
idcu maven list
```

**预期结果：**
- 列出所有发现的 Maven 项目

#### 2. 编译项目（2 分钟）
```bash
idcu maven compile
```

**预期结果：**
- 成功编译项目
- 显示编译结果

#### 3. 完整构建（3 分钟）
```bash
idcu maven build
```

**预期结果：**
- 执行完整的构建流程
- 生成构建产物

#### 4. 依赖分析（2 分钟）
```bash
idcu maven dep-tree
idcu maven dep-analyze
```

**预期结果：**
- 显示依赖树
- 分析依赖问题

#### 5. 查看 Profiles（2 分钟）
```bash
idcu maven list-profiles
```

**预期结果：**
- 列出可用的 Maven Profiles

---

## 旅程 4：质量检查（8 分钟）

### 目标
体验代码质量检查功能。

### 步骤

#### 1. 查看质量检查工具（1 分钟）
```bash
idcu quality list
```

**预期结果：**
- 列出可用的质量检查工具

#### 2. 编码检查（2 分钟）
```bash
idcu quality encoding check -p .
```

**预期结果：**
- 检查文件编码
- 显示编码问题

#### 3. 编码修复（2 分钟）
```bash
idcu quality encoding fix -p . -t utf-8
```

**预期结果：**
- 修复编码问题
- 转换为指定编码

#### 4. 质量门禁（1 分钟）
```bash
idcu quality gates
```

**预期结果：**
- 运行质量门禁检查
- 显示检查结果

#### 5. 依赖审计（2 分钟）
```bash
idcu quality dependency-audit audit -p .
```

**预期结果：**
- 审计项目依赖
- 显示安全问题

---

## 旅程 5：插件系统（5 分钟）

### 目标
体验插件系统功能。

### 步骤

#### 1. 列出可用插件（1 分钟）
```bash
idcu plugin list
```

**预期结果：**
- 列出所有已安装的插件

#### 2. 查看插件命令（1 分钟）
```bash
idcu plugin commands
```

**预期结果：**
- 列出插件提供的命令

#### 3. 执行插件命令（2 分钟）
```bash
idcu cmd <plugin-command>
```

**预期结果：**
- 成功执行插件命令

#### 4. 探索示例插件（1 分钟）
查看 `idcu/tools/plugins/examples/` 目录下的示例插件。

**预期结果：**
- 理解插件开发方式

---

## 验收标准

每条用户旅程都应满足以下标准：

1. **可复现性**：任何用户按照步骤操作都能得到相同结果
2. **完整性**：从开始到结束形成闭环
3. **有用性**：解决实际问题或展示核心价值
4. **效率性**：在预计时间内完成
5. **清晰性**：步骤说明清晰，预期结果明确

---

## 常见问题

### Q: 安装失败怎么办？
A: 检查 Python 版本（需要 3.8+），确保 pip 是最新版本。

### Q: 找不到 Git/Maven 命令？
A: 确保已安装相应工具并添加到 PATH 环境变量。

### Q: 如何获得更多帮助？
A: 运行 `idcu --help` 或查看 README.md 和 TUTORIAL.md。
