# IDCU CLI v1.0.0 发布检查清单

## 发布标准（5 条）

- [x] **1. 安装成功**
  - [x] pip install 能够正常完成
  - [x] 依赖（PyYAML）自动安装
  - [x] 无安装错误

- [x] **2. 核心命令可跑**
  - [x] idcu --version 正常显示版本号
  - [x] idcu --help 正常显示帮助
  - [x] git 命令可用
  - [x] maven 命令可用
  - [x] quality 命令可用
  - [x] config 命令可用
  - [x] plugin 命令可用

- [x] **3. 帮助信息一致**
  - [x] 主命令帮助信息完整
  - [x] 子命令帮助信息完整
  - [x] 命令分类标识清晰（[核心]/[增强]/[实验]）

- [x] **4. 错误信息可诊断**
  - [x] 无效命令有明确提示
  - [x] 错误信息包含可用选项列表

- [x] **5. 文档按主航道可走通**
  - [x] README.md 完整
  - [x] TUTORIAL.md 存在
  - [x] EXAMPLES.md 存在
  - [x] FAQ.md 存在
  - [x] USER_JOURNEY.md 存在
  - [x] CHANGELOG.md 存在

---

## 发布前准备

### 代码质量
- [x] 所有单元测试通过
- [x] 冒烟测试通过
- [x] ruff 检查通过
- [x] mypy 类型检查通过

### 文档
- [x] README.md 更新到 v1.0.0
- [x] CHANGELOG.md 添加 v1.0.0 条目
- [x] USER_JOURNEY.md 创建完成
- [x] 示例工程创建完成（examples/）

### 版本
- [x] 版本号更新为 1.0.0
- [x] 开发状态更新为 Production/Stable

### 打包
- [ ] 清理旧的构建文件
- [ ] 构建源码分发包（sdist）
- [ ] 构建 wheel 包
- [ ] 验证构建产物

---

## 发布步骤

### 1. 本地验证
```bash
# 运行完整测试
pytest tests/ -v

# 检查代码质量
ruff check idcu/
mypy idcu/

# 本地安装测试
pip install -e .
idcu --version
idcu --help
```

### 2. 构建发布包
```bash
# 清理旧构建
rm -rf dist/ build/ *.egg-info/

# 构建
python -m build

# 检查构建产物
ls -la dist/
```

### 3. TestPyPI 测试发布（可选但推荐）
```bash
# 上传到 TestPyPI
python -m twine upload --repository testpypi dist/*

# 从 TestPyPI 安装测试
pip install --index-url https://test.pypi.org/simple/ idcu-cli

# 验证安装
idcu --version
```

### 4. 正式发布到 PyPI
```bash
# 上传到 PyPI
python -m twine upload dist/*
```

### 5. Git 标签
```bash
git tag -a v1.0.0 -m "Release v1.0.0 - 首次正式发布"
git push origin v1.0.0
```

### 6. GitHub/Gitee Release
- 创建 Release 页面
- 附加构建产物
- 复制 CHANGELOG 内容作为发布说明

---

## 发布后验证

- [ ] PyPI 页面可访问：https://pypi.org/project/idcu-cli/
- [ ] pip install idcu-cli 成功
- [ ] idcu --version 显示 1.0.0
- [ ] 核心功能正常
- [ ] 文档链接有效

---

## 平台兼容性

- [x] Windows (已测试)
- [ ] Linux (待验证)
- [ ] macOS (待验证)

### Python 版本支持
- [x] Python 3.8
- [x] Python 3.9
- [x] Python 3.10
- [x] Python 3.11
- [x] Python 3.12
- [x] Python 3.13
- [x] Python 3.14 (当前测试环境)

---

## 备注

- 发布日期：2026-03-24
- 发布版本：1.0.0
- 发布类型：首次正式发布 (General Availability)
