#!/usr/bin/env python3
"""Import-smoke all first-party modules that should remain importable."""

from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PACKAGE_ROOT = ROOT / "idcu"
SKIP_PREFIXES = (
    "idcu.tools.web.api",
)


def module_name_for_path(path: Path) -> str:
    relative = path.relative_to(ROOT).with_suffix("")
    parts = list(relative.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def iter_modules() -> list[str]:
    modules = {"idcu", "idcu_cli"}

    for path in PACKAGE_ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        module_name = module_name_for_path(path)
        if not module_name:
            continue
        if module_name.startswith(SKIP_PREFIXES):
            continue
        modules.add(module_name)

    return sorted(modules)


def import_module(module_name: str) -> tuple[bool, str | None]:
    try:
        importlib.import_module(module_name)
    except Exception:
        return False, traceback.format_exc()
    return True, None


def main() -> int:
    sys.path.insert(0, str(ROOT))
    modules = iter_modules()

    print(f"Testing imports for {len(modules)} modules...")
    print("=" * 80)

    failures: list[tuple[str, str]] = []
    for module_name in modules:
        ok, error = import_module(module_name)
        if ok:
            print(f"OK   {module_name}")
            continue

        failures.append((module_name, error or "unknown import failure"))
        print(f"FAIL {module_name}")
        print("     import failed")

    print("=" * 80)
    if failures:
        print(f"Import smoke gate failed for {len(failures)} module(s).")
        for module_name, error in failures:
            print(f"\n--- {module_name} ---")
            print(error.rstrip())
        return 1

    print("Import smoke gate passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())