#!/usr/bin/env python3
"""Check repository text files for UTF-8 and HTML-escape corruption."""

from __future__ import annotations

import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SCAN_DIRS = (".github", "docs", "idcu", "scripts", "tests")
SCAN_FILES = ("README.md", "pyproject.toml", "idcu_cli.py")
TEXT_SUFFIXES = {
    ".css",
    ".html",
    ".ini",
    ".js",
    ".json",
    ".md",
    ".py",
    ".toml",
    ".txt",
    ".yaml",
    ".yml",
}
SOURCE_SUFFIXES = {
    ".ini",
    ".json",
    ".py",
    ".toml",
    ".yaml",
    ".yml",
}
EXCLUDED_DIRS = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "htmlcov",
    "tmp_test_workspace",
    "venv",
}
HTML_ESCAPE_PATTERN = re.compile(r"&(?:amp|lt|gt|quot|apos|#34|#39);")


def iter_text_files() -> list[Path]:
    files: set[Path] = set()

    for relative_dir in SCAN_DIRS:
        base_dir = ROOT / relative_dir
        if not base_dir.exists():
            continue

        for path in base_dir.rglob("*"):
            if not path.is_file():
                continue
            if any(part in EXCLUDED_DIRS for part in path.parts):
                continue
            if path.suffix.lower() in TEXT_SUFFIXES:
                files.add(path)

    for relative_file in SCAN_FILES:
        path = ROOT / relative_file
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            files.add(path)

    return sorted(files)


def check_file(path: Path) -> list[str]:
    issues: list[str] = []
    raw = path.read_bytes()

    if not raw:
        return issues

    if raw.startswith(b"\xef\xbb\xbf"):
        issues.append("contains UTF-8 BOM")

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        issues.append(f"not valid UTF-8: {exc}")
        return issues

    if "\ufffd" in text:
        issues.append("contains Unicode replacement character")

    if path.suffix.lower() in SOURCE_SUFFIXES:
        for match in HTML_ESCAPE_PATTERN.finditer(text):
            issues.append(f"suspicious HTML escape '{match.group(0)}'")

    return issues


def main() -> int:
    files = iter_text_files()
    print(f"Checking {len(files)} files for UTF-8 and HTML-escape issues...")
    print("=" * 80)

    failures: list[tuple[Path, list[str]]] = []
    for path in files:
        issues = check_file(path)
        rel_path = path.relative_to(ROOT)
        if not issues:
            print(f"OK   {rel_path}")
            continue

        failures.append((rel_path, issues))
        print(f"FAIL {rel_path}")
        for issue in issues:
            print(f"     - {issue}")

    print("=" * 80)
    if failures:
        print(f"Encoding gate failed for {len(failures)} file(s).")
        return 1

    print("Encoding gate passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())