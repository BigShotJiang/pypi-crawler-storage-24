#!/usr/bin/env python3
"""Compile all Python sources that should block CI."""

from __future__ import annotations

import py_compile
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SCAN_DIRS = ("idcu", "tests", "scripts")
SCAN_FILES = ("idcu_cli.py",)
EXCLUDED_DIRS = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".nox",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "htmlcov",
    "tmp_test_workspace",
    "venv",
}


def iter_python_files() -> list[Path]:
    files: set[Path] = set()

    for relative_dir in SCAN_DIRS:
        base_dir = ROOT / relative_dir
        if not base_dir.exists():
            continue

        for path in base_dir.rglob("*.py"):
            if any(part in EXCLUDED_DIRS for part in path.parts):
                continue
            if path.is_file():
                files.add(path)

    for relative_file in SCAN_FILES:
        path = ROOT / relative_file
        if path.is_file():
            files.add(path)

    return sorted(files)


def compile_file(path: Path) -> tuple[bool, str | None]:
    try:
        py_compile.compile(str(path), doraise=True)
    except py_compile.PyCompileError as exc:
        return False, exc.msg
    except Exception as exc:  # pragma: no cover - defensive fallback
        return False, str(exc)
    return True, None


def main() -> int:
    python_files = iter_python_files()
    print(f"Checking {len(python_files)} Python files for compile errors...")
    print("=" * 80)

    failures: list[tuple[Path, str]] = []
    for path in python_files:
        ok, error = compile_file(path)
        rel_path = path.relative_to(ROOT)
        if ok:
            print(f"OK   {rel_path}")
            continue

        failures.append((rel_path, error or "unknown compile error"))
        print(f"FAIL {rel_path}")
        print(f"     {error}")

    print("=" * 80)
    if failures:
        print(f"Compile gate failed for {len(failures)} file(s).")
        return 1

    print("Compile gate passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())