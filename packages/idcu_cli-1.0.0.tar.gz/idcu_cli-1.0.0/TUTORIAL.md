
# IDCU CLI - 不羁盟命令行工具

基于 Python 3.8+ 开发的 IDCU (不羁盟) CLI 工具，让您的开发更加高效！

## 目录

1. [快速开始](#快速开始)
2. [Git操作](#git操作)
3. [Maven构建](#maven构建)
4. [插件系统](#插件系统)
5. [环境配置](#环境配置)
6. [CI/CD集成](#cicd集成)
7. [AI增强功能](#ai增强功能)
8. [团队协作](#团队协作)
9. [跨语言构建](#跨语言构建)
10. [Web UI](#web-ui)
11. [高级用法](#高级用法)
12. [常见问题](#常见问题)

---

## 快速开始

### 安装 IDCU

#### 从源码安装

```bash
# 克隆仓库
git clone https://gitee.com/idcu/cli.git
cd cli

# 安装为可编辑模式
pip install -e .
```

#### 从 PyPI 安装（推荐）

```bash
pip install idcu-cli
```

### 验证安装

```bash
# 查看帮助
idcu --help

# 查看版本
idcu --version
```

### 交互式模式

IDCU CLI 提供了强大的交互式模式，让您可以通过菜单导航和命令补全更轻松地使用所有功能。

#### 进入交互式模式

```bash
# 直接输入 idcu 命令进入交互式模式
idcu
```

#### 安装交互式依赖（如需要）

如果看到提示"交互式 CLI 依赖未安装"，请运行：

```bash
# 安装交互式依赖
pip install "idcu-cli[interactive]"

# 或安装所有可选依赖
pip install "idcu-cli[interactive,web,ai,quality]"
```

#### 交互式模式功能

进入交互式模式后，您将看到一个美观的菜单界面，包含以下功能：

1. **Git 管理** - 列出项目、查看状态、提交、推送、拉取等
2. **Maven 构建** - 列出项目、构建、梯队构建、并行构建等
3. **配置管理** - 查看和修改配置
4. **插件管理** - 管理和执行插件命令
5. **环境配置** - 配置开发环境
6. **发布管理** - 版本发布流程
7. **跨语言构建** - 多语言项目构建
8. **AI 增强** - AI 辅助功能
9. **CI/CD 集成** - 持续集成和部署
10. **团队协作** - 团队协作工具
11. **Web UI** - 启动 Web 界面
12. **质量检查** - 代码质量和安全检查
13. **项目模板** - 从模板创建项目
14. **直接输入命令** - 直接输入 idcu 命令
0. **退出** - 退出交互式模式

#### 菜单导航

- **数字选择** - 输入对应的数字（0-14）选择菜单项
- **特殊命令**：
  - `help` 或 `?` - 显示帮助信息
  - `menu` 或 `m` - 显示主菜单
  - `back` 或 `..` - 返回上级菜单
  - `quit` 或 `exit` 或 `q` - 退出交互式模式
  - `clear` 或 `cls` - 清屏

#### 直接命令模式

在主菜单选择"直接输入命令"或在任何子菜单中，您可以直接输入 idcu 命令：

```bash
# 可省略 idcu 前缀
git status

# 或完整输入
idcu git status

# 使用命令历史（上下键浏览）
# 使用 Tab 键自动补全
```

#### 命令补全

交互式模式支持智能命令补全：
- 使用 Tab 键补全命令和子命令
- 支持命令历史记录（保存到 `~/.idcu/history`）
- 使用上下键浏览历史命令

### 创建第一个项目

首先，让我们创建一个新的项目或使用现有项目，IDCU会自动检测并配置：

```bash
# 列出所有 Git 项目
idcu git list
```

项目配置文件位于 `.idcu/config.yaml`

---

## Git操作

### 列出项目

```bash
# 列出所有 Git 项目
idcu git list
```

### 查看状态

```bash
# 查看所有项目状态
idcu git status

# 查看指定项目状态
idcu git status -p project1 project2
```

### 提交更改

```bash
# 提交所有项目更改
idcu git commit -m "提交信息" -a

# 提交指定项目
idcu git commit -m "提交信息" -a -p project1
```

### 推送和拉取

```bash
# 推送所有项目
idcu git push

# 拉取所有项目
idcu git pull

# 抓取远程更新
idcu git fetch
```

### 分支和日志

```bash
# 切换分支
idcu git switch develop

# 查看日志
idcu git log -n 20
```

### 暂存操作

```bash
# 暂存更改
idcu git stash -m "临时保存"

# 查看暂存列表
idcu git stash-list

# 恢复暂存
idcu git stash-pop
```

### 查看变更

```bash
# 查看变更
idcu git changes
```

---

## Maven构建

### 列出 Maven 项目

```bash
idcu maven list
```

### 构建项目

```bash
# 默认构建（clean install）
idcu maven build

# 自定义目标
idcu maven build clean compile test

# 构建指定项目
idcu maven build -p project1

# 指定本地仓库
idcu maven build -l /path/to/repo
```

### 依赖分析

```bash
# 查看依赖树
idcu maven dep-tree

# 列出所有依赖
idcu maven dep-list

# 分析依赖（找出未使用的）
idcu maven dep-analyze

# 检查依赖冲突
idcu maven dep-conflict
```

### POM 和 Profile 操作

```bash
# 显示有效 POM
idcu maven effective-pom

# 列出可用 Profile
idcu maven profile-list

# 设置 Profile
idcu maven profile-set release
```

### 仓库操作

```bash
# 列出本地仓库
idcu maven repo-list

# 清理本地仓库
idcu maven clean-local
```

### 高级构建选项

```bash
# 显示构建时间线
idcu maven timeline
idcu maven timeline --skip-tests

# 并行构建
idcu maven parallel
idcu maven parallel -t 1C  # 使用所有 CPU 核心
idcu maven parallel -t 4   # 使用 4 个线程
```

---

## 插件系统

### 安装命令补全

IDCU 提供了强大的 Shell 补全功能，让您的使用更加流畅：

```bash
# 生成 Bash 补全
idcu completions bash
idcu completions bash -o ~/.idcu-completions.bash

# 生成 Zsh 补全
idcu completions zsh
idcu completions zsh -o ~/.zsh/_idcu

# 生成 PowerShell 补全
idcu completions powershell
idcu completions powershell -o idcu-completions.ps1
```

### 启用命令补全

**Bash:**
```bash
idcu completions bash -o ~/.idcu-completions.bash
echo 'source ~/.idcu-completions.bash' &gt;&gt; ~/.bashrc
source ~/.bashrc
```

**Zsh:**
```bash
idcu completions zsh -o ~/.zsh/_idcu
echo 'fpath=(~/.zsh $fpath)' &gt;&gt; ~/.zshrc
compinit
```

**PowerShell:**
```powershell
idcu completions powershell -o idcu-completions.ps1
echo '. idcu-completions.ps1' &gt;&gt; $PROFILE
. $PROFILE
```

---

## 环境配置

### 查看环境版本

```bash
# 获取开发环境软件版本
idcu env versions
```

### 配置开发环境

```bash
# 自动配置开发环境
idcu env setup

# 指定基础目录
idcu env setup --base-dir /path/to/base

# 仅用户级别配置
idcu env setup --user

# 系统级别配置（需要管理员权限）
idcu env setup --system
```

---

## 插件系统使用

### 查看已安装插件

```bash
idcu plugin list
```

### 使用插件命令

```bash
# 运行 hello 插件
idcu plugin cmd hello "World"

# 运行 file_utils 插件
idcu plugin cmd file_utils.count-files
idcu plugin cmd file_utils.find-files .py
idcu plugin cmd file_utils.file-stats

# 运行 system_info 插件
idcu plugin cmd system_info.system-info
idcu plugin cmd system_info.python-info
idcu plugin cmd system_info.env-info PATH,HOME
```

### 开发自定义插件

参考 `idcu/tools/plugins/examples/` 目录下的示例插件！

---

## 项目配置

### 默认配置示例

```yaml
global:
  color_output: true
  verbose: false
  quiet: false
  dry_run: false

git:
  default_branch: develop
  remote_name: origin
  auto_fetch: false

maven:
  local_repo_path: .mvn/local-repo
  default_goals:
    - clean
    - install
  offline_mode: false
```

### 程序化访问配置

```python
from idcu.system import get_config_manager

config = get_config_manager()

# 读取配置
verbose = config.get("global.verbose")

# 设置配置
config.set("global.verbose", True)

# 保存配置
config.save_config()
```

---

## Python API 开发

### 直接使用工具函数

```python
from pathlib import Path
from idcu.tools import (
    git_status,
    git_commit,
    git_push,
    list_available_projects,
)

# 查看状态
result = git_status(Path.cwd())
if result.success:
    print(result.message)

# 提交更改
result = git_commit(Path.cwd(), message="修复 bug", all=True)

# 推送更改
result = git_push(Path.cwd())
```

### 使用重试机制

```python
from idcu.system import retry, with_retry

# 装饰器方式
@retry(max_attempts=3, delay=1.0)
def unstable_operation():
    # 可能会失败的操作
    pass

# 函数调用方式
result = with_retry(
    unstable_operation,
    max_attempts=5,
    delay=0.5,
    backoff=2.0
)
```

### 使用国际化

```python
from idcu.system import _

# 获取翻译文本
text = _("git_status")
print(text)
```

### 环境变量操作

```python
from idcu.system import set_env, get_env, add_path, is_admin

# 设置环境变量（用户级别）
set_env("MY_APP_KEY", "secret123", user=True)

# 获取环境变量
value = get_env("MY_APP_KEY", user=True)

# 添加到 PATH
add_path(["/path/to/bin"], user=True)

# 检查是否有管理员权限
if is_admin():
    print("有管理员权限")
```

### 编码检测和修复

```python
from idcu.core import detect_file_encoding, fix_file_encoding
from pathlib import Path

# 检测文件编码
result = detect_file_encoding(Path("file.txt"))
print(f"检测编码: {result.encoding}, 置信度: {result.confidence}")

# 修复文件编码
result = fix_file_encoding(Path("file.txt"), target_encoding="utf-8")
if result.success:
    print("编码修复成功")
```

---

## 故障排除

### 1. 卸载并重新安装

```bash
pip uninstall idcu
```

### 2. 重置配置文件

- Windows: `%USERPROFILE%\.idcu\config.yaml`
- Linux/macOS: `~/.idcu/config.yaml`

### 3. 删除缓存文件

删除项目缓存文件，然后重新扫描项目以检测新项目。

### 4. 调试插件问题

参考 `idcu/tools/plugins/examples/` 目录，尝试编写简单的 hello 插件 PR。

---

## CI/CD 集成

### 生成 GitHub Actions 工作流

```python
from idcu.tools.cicd import GitHubActionsGenerator

generator = GitHubActionsGenerator()

# 生成 CI 工作流
generator.generate_ci_workflow(".github/workflows/ci.yml")

# 生成发布工作流
generator.generate_publish_workflow(".github/workflows/publish.yml")

# 生成 Docker 工作流
generator.generate_docker_workflow(".github/workflows/docker.yml")

# 生成完整发布工作流
generator.generate_release_workflow(".github/workflows/release.yml")

# 生成所有工作流
generator.generate_all_workflows(".github/workflows/")
```

### GitLab CI 配置生成

```python
from idcu.tools.cicd import GitLabCIGenerator

generator = GitLabCIGenerator()
generator.generate_gitlab_ci(".gitlab-ci.yml")
```

### Jenkins Pipeline 生成

```python
from idcu.tools.cicd import JenkinsPipelineGenerator

generator = JenkinsPipelineGenerator()
generator.generate_jenkinsfile("Jenkinsfile")
```

### Docker 部署

```python
from idcu.tools.cicd import DockerDeployer
from pathlib import Path

deployer = DockerDeployer()

# 登录 Docker Hub
deployer.login("username", "password")

# 构建镜像
deployer.build_image(Path("."), "myapp:latest")

# 推送镜像
deployer.push_image("myapp:latest")
```

### CI 状态检查

```python
from idcu.tools.cicd import GitHubActionsStatus

status = GitHubActionsStatus("owner", "repo", "token")

# 列出工作流
workflows = status.list_workflows()
for wf in workflows:
    print(f"{wf.name}: {wf.state}")

# 列出工作流运行
runs = status.list_runs()
for run in runs:
    print(f"{run.name}: {run.status}")

# 查看日志
logs = status.view_logs(run_id=123)
print(logs)
```

---

## AI 增强功能

### 安装 AI 依赖

```bash
pip install idcu-cli[ai]
```

### 配置 AI 提供方

```python
from idcu.tools.ai import OpenAIProvider, OllamaProvider

# 使用 OpenAI
provider = OpenAIProvider(
    api_key="your-api-key",
    base_url="https://api.openai.com/v1",
    model="gpt-4"
)

# 或使用本地 Ollama
provider = OllamaProvider(
    base_url="http://localhost:11434",
    model="llama2"
)

# 聊天
response = provider.chat([
    {"role": "user", "content": "你好，请介绍一下这个项目"}
])
print(response)

# 流式输出
for chunk in provider.chat_stream([
    {"role": "user", "content": "写一个简单的 Python 函数"}
]):
    print(chunk, end="")
```

### 自动生成提交信息

```python
from idcu.tools.ai import CommitGenerator
from pathlib import Path

generator = CommitGenerator(provider)

# 从工作区自动生成提交信息
message = generator.generate_commit_message(Path("."))
print(f"生成的提交信息: {message}")

# 从 diff 生成
diff = """
diff --git a/file.py b/file.py
index 123..456 100644
--- a/file.py
+++ b/file.py
@@ -1,2 +1,3 @@
 def hello():
+    print("world")
     return "hello"
"""
message = generator.generate_from_diff(diff)
```

### 代码变更摘要

```python
from idcu.tools.ai import DiffSummarizer
from pathlib import Path

summarizer = DiffSummarizer(provider)

# 摘要工作区变更
summary = summarizer.summarize_working_dir(Path("."))
print(summary)

# 摘要暂存变更
summary = summarizer.summarize_staged(Path("."))
print(summary)

# 摘要特定提交
summary = summarizer.summarize_commit(Path("."), "abc123")
print(summary)
```

---

## 团队协作

### 团队配置管理

```python
from idcu.tools.team import TeamConfig
from pathlib import Path

# 创建团队配置
team_config = TeamConfig(
    name="My Team",
    description="我们的团队配置"
)

# 添加成员
team_config.add_member("user1", "admin")
team_config.add_member("user2", "member")
team_config.add_member("user3", "viewer")

# 设置团队配置
team_config.set_config("git.default_branch", "main")
team_config.set_config("maven.offline_mode", False)

# 导出配置
team_config.export(Path("team_config.yaml"))

# 加载配置
loaded_config = TeamConfig.load(Path("team_config.yaml"))

# 查看历史
history = loaded_config.get_history()
for entry in history:
    print(f"{entry.timestamp}: {entry.change}")
```

### 权限管理

```python
from idcu.tools.team import PermissionManager

manager = PermissionManager()

# 添加角色
manager.add_role("admin", ["*"])
manager.add_role("member", ["git.*", "maven.*"])
manager.add_role("viewer", ["git.read", "maven.read"])

# 分配角色
manager.assign_role("user1", "admin")
manager.assign_role("user2", "member")

# 检查权限
if manager.has_permission("user1", "git.push"):
    print("有推送权限")

if manager.has_permission("user3", "maven.deploy"):
    print("有部署权限")
else:
    print("没有权限")
```

### 代码审查

```python
from idcu.tools.team import CodeReview
from pathlib import Path

review = CodeReview()

# 创建审查
review_id = review.create_review(
    repo_path=Path("."),
    title="新功能代码审查",
    author="user1",
    reviewers=["user2", "user3"],
    commit_hash="abc123"
)

# 添加评论
review.add_comment(review_id, "user2", "这个函数看起来不错")

# 批准审查
review.approve_review(review_id, "user2")

# 获取审查详情
details = review.get_review(review_id)
print(f"状态: {details.status}")
print(f"评论: {details.comments}")

# 列出审查
reviews = review.list_reviews(status="pending")
for r in reviews:
    print(f"{r.title} - {r.author}")
```

---

## 跨语言构建

### 自动检测项目类型

```python
from idcu.tools.crosslang import ProjectDetector, UnifiedBuilder
from pathlib import Path

detector = ProjectDetector()

# 检测项目类型
project_type = detector.detect_project_type(Path("."))
print(f"项目类型: {project_type}")

# 获取可用的构建工具
build_tools = detector.get_available_build_tools(Path("."))
print(f"可用工具: {build_tools}")
```

### 使用统一构建接口

```python
from idcu.tools.crosslang import UnifiedBuilder
from pathlib import Path

builder = UnifiedBuilder()

# 自动检测并构建项目
result = builder.build(Path("."))
print(f"成功: {result.success}")
print(f"输出: {result.output}")

# 运行测试
result = builder.test(Path("."))
print(f"测试通过: {result.success}")

# 清理
result = builder.clean(Path("."))
```

### npm/yarn/pnpm 项目

```python
from idcu.tools.crosslang import NPMBuildTool
from pathlib import Path

# 自动检测
npm = NPMBuildTool.auto_detect(Path("."))

# 或指定使用 npm
npm = NPMBuildTool(package_manager="npm")

# 安装依赖
result = npm.install_dependencies(Path("."))

# 构建
result = npm.build(Path("."))

# 测试
result = npm.test(Path("."))

# 运行脚本
result = npm.run_script(Path("."), "dev")

# 添加依赖
result = npm.add_dependency(Path("."), "lodash")
result = npm.add_dev_dependency(Path("."), "typescript")
```

### Python 项目

```python
from idcu.tools.crosslang import PythonBuildTool
from pathlib import Path

# 自动检测
python = PythonBuildTool.auto_detect(Path("."))

# 或指定使用 poetry
python = PythonBuildTool(build_tool="poetry")

# 安装依赖
result = python.install_dependencies(Path("."))

# 构建
result = python.build(Path("."))

# 测试
result = python.test(Path("."))

# 清理
result = python.clean(Path("."))
```

### Go 项目

```python
from idcu.tools.crosslang import GoBuildTool
from pathlib import Path

go = GoBuildTool()

# 下载依赖
result = go.download_dependencies(Path("."))

# 构建
result = go.build(Path("."), output="myapp")

# 测试
result = go.test(Path("."))

# 清理
result = go.clean(Path("."))
```

### Rust 项目

```python
from idcu.tools.crosslang import RustBuildTool
from pathlib import Path

rust = RustBuildTool()

# 构建（发布模式）
result = rust.build(Path("."), release=True)

# 测试
result = rust.test(Path("."))

# 运行
result = rust.run(Path("."))

# 添加依赖
result = rust.add_dependency(Path("."), "serde", features=["derive"])
```

---

## Web UI

### 启动 Web 服务

首先安装 web 依赖：

```bash
pip install idcu-cli[web]
```

然后启动服务：

```python
from idcu.tools.web import app
import uvicorn

uvicorn.run(app, host="0.0.0.0", port=8000)
```

### 使用 API

```python
import requests

# 获取仪表板信息
response = requests.get("http://localhost:8000/api/dashboard/info")
print(response.json())

# 获取 Git 状态
response = requests.get("http://localhost:8000/api/git/status")
print(response.json())

# 获取配置
response = requests.get("http://localhost:8000/api/config/")
print(response.json())

# 更新配置
response = requests.put("http://localhost:8000/api/config/", json={
    "global": {
        "verbose": True
    }
})
print(response.json())

# 列出插件
response = requests.get("http://localhost:8000/api/plugins/")
print(response.json())
```

---

## 下一步

- 查看 [API 文档](docs/index.md) 了解更多 API
- 查看 [README](README.md) 了解项目概览
- 在 [Gitee Issues](https://gitee.com/idcu/cli/issues) 报告问题
