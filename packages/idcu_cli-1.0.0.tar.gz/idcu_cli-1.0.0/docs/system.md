# System 模块文档

System 模块提供系统层功能，包括配置管理、日志、错误处理和国际化。

## 配置管理

```python
from idcu.system import ConfigManager

config_manager = ConfigManager()

# 获取配置
config = config_manager.get_config()

# 更新配置
config_manager.update_config({"git": {"default_branch": "main"}})

# 保存配置
config_manager.save_config()
```

## 日志系统

```python
from idcu.system import get_logger

logger = get_logger(__name__)

logger.debug("调试信息")
logger.info("普通信息")
logger.warning("警告信息")
logger.error("错误信息")
logger.critical("严重错误")
```

## 错误处理

```python
from idcu.system import ErrorHandler

error_handler = ErrorHandler()

try:
    pass
except Exception as e:
    error_handler.handle_error(e, context="操作上下文")
```

## 国际化

```python
from idcu.system import i18n

# 设置语言
i18n.set_language("zh_CN")

# 获取翻译
text = i18n.t("key", default="默认值")
```

## 环境工具

```python
from idcu.system import env_utils

# 获取环境变量
value = env_utils.get_env("VAR_NAME", default="default")

# 设置环境变量
env_utils.set_env("VAR_NAME", "value")

# 检测软件版本
versions = env_utils.detect_versions()
```
