# AI 文档

IDCU CLI 提供 AI 增强功能，支持 OpenAI 和 Ollama。

## 安装 AI 依赖

```bash
pip install "idcu-cli[ai]"
```

## OpenAI 提供商

```python
from idcu.tools.ai import OpenAIProvider

provider = OpenAIProvider(
    api_key="your-api-key",
    model="gpt-4"
)

# 生成文本
response = provider.generate("你的提示词")
print(response)
```

## Ollama 提供商

```python
from idcu.tools.ai import OllamaProvider

provider = OllamaProvider(
    model="llama2",
    base_url="http://localhost:11434"
)

# 生成文本
response = provider.generate("你的提示词")
print(response)
```

## 提交信息生成

```python
from idcu.tools.ai import CommitGenerator
from pathlib import Path

generator = CommitGenerator(provider)

# 生成提交信息
message = generator.generate_commit_message(
    repo_path=Path.cwd()
)
print(message)
```

## 变更摘要生成

```python
from idcu.tools.ai import DiffSummarizer
from pathlib import Path

summarizer = DiffSummarizer(provider)

# 生成变更摘要
summary = summarizer.summarize_diff(
    repo_path=Path.cwd()
)
print(summary)
```
