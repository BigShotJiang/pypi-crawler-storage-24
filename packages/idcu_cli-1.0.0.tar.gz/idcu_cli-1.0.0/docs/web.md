# Web UI 文档

IDCU CLI 提供 Web UI 界面，基于 FastAPI。

## 安装 Web 依赖

```bash
pip install "idcu-cli[web]"
```

## 启动 Web 服务器

```bash
idcu web serve
```

或使用 Python API：

```python
from idcu.tools.web import app
import uvicorn

uvicorn.run(app, host="0.0.0.0", port=8000)
```

## API 端点

### 仪表盘

```
GET /api/dashboard
```

返回项目概览信息。

### Git 操作

```
GET /api/git/status
POST /api/git/commit
POST /api/git/push
POST /api/git/pull
```

### 插件管理

```
GET /api/plugins
POST /api/plugins/cmd/{command}
```

### 配置

```
GET /api/config
PUT /api/config
```

## 前端界面

访问 `http://localhost:8000` 查看 Web UI。

前端提供：
- 项目仪表盘
- Git 状态查看
- 构建操作
- 插件管理
- 配置编辑
