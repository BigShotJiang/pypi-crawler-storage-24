# CI/CD 指南

## GitHub Actions

项目包含以下工作流：

### CI 工作流 (ci.yml)

- 运行测试
- 代码检查
- 类型检查

```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
      - run: pip install -e ".[dev]"
      - run: pytest tests/ -v
```

### 发布工作流 (publish.yml)

- 构建包
- 发布到 PyPI
- 构建 Docker 镜像

### 发布工作流 (release.yml)

- 创建 GitHub Release
- 上传构建产物

## GitLab CI

参考 `.gitlab-ci.yml` 配置：

```yaml
image: python:3.11

test:
  script:
    - pip install -e ".[dev]"
    - pytest tests/ -v
```

## Jenkins

创建 Jenkinsfile：

```groovy
pipeline {
    agent any
    stages {
        stage('Test') {
            steps {
                sh 'pip install -e ".[dev]"'
                sh 'pytest tests/ -v'
            }
        }
    }
}
```
