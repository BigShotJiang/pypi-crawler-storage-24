# CLI 文档

IDCU CLI 提供丰富的命令行工具，简化开发工作流。

## 安装

```bash
pip install idcu-cli
```

## 基本命令

### 查看帮助

```bash
idcu --help
```

### 查看版本

```bash
idcu --version
```

## Git 命令

```bash
# 列出可用项目
idcu git list

# 查看状态
idcu git status
idcu git status -p proj1 proj2

# 提交更改
idcu git commit -m "提交信息" -a
idcu git commit -m "提交信息" -p proj1

# 推送到远程
idcu git push
idcu git push -p proj1 proj2

# 从远程拉取
idcu git pull
idcu git pull -p proj1 proj2

# 获取远程更新
idcu git fetch
idcu git fetch -p proj1 proj2

# 切换分支
idcu git switch develop
idcu git switch develop -p proj1 proj2

# 查看日志
idcu git log -n 10
idcu git log -n 10 -p proj1 proj2

# 暂存更改
idcu git stash -m "暂存信息"
idcu git stash -m "暂存信息" -p proj1 proj2

# 恢复暂存
idcu git stash-pop
idcu git stash-pop -p proj1 proj2

# 查看暂存列表
idcu git stash-list
idcu git stash-list -p proj1 proj2

# 查看更改
idcu git changes
idcu git changes -p proj1 proj2

# 子模块操作
idcu git sub-status
idcu git sub-switch develop
idcu git sub-commit -m "提交信息" -a
idcu git sub-push
idcu git sub-sync
```

## Maven 命令

```bash
# 列出 Maven 项目
idcu maven list

# 构建项目
idcu maven build
idcu maven build clean install -p proj1 -l .mvn/repo

# 显示依赖树
idcu maven dep-tree
idcu maven dep-tree -p proj1

# 显示依赖列表
idcu maven dep-list
idcu maven dep-list -p proj1

# 依赖分析
idcu maven dep-analyze
idcu maven dep-analyze -p proj1

# 依赖冲突检测
idcu maven dep-conflict
idcu maven dep-conflict -p proj1

# 显示有效POM
idcu maven effective-pom
idcu maven effective-pom -p proj1

# 列出Profiles
idcu maven profile-list
idcu maven profile-list -p proj1

# 设置Profile
idcu maven profile-set prod
idcu maven profile-set prod -p proj1

# 显示仓库配置
idcu maven repo-list
idcu maven repo-list -p proj1

# 清理本地仓库
idcu maven clean-local
idcu maven clean-local -p proj1

# 构建性能监控
idcu maven timeline
idcu maven timeline -p proj1 --skip-tests

# 并行构建
idcu maven parallel -t 1C
idcu maven parallel -t 4 -p proj1 --skip-tests

# 梯队构建
idcu maven tier-list
idcu maven build-tier foundation clean install --skip-tests
idcu maven build-tier clean install --skip-tests

# 按模块列表构建
idcu maven build-modules module1 module2 clean install --skip-tests
```

## 插件命令

```bash
# 列出插件
idcu plugin list

# 运行插件命令
idcu plugin cmd <command> [args...]
```

## 环境命令

```bash
# 查看环境版本
idcu env versions

# 设置开发环境
idcu env setup
idcu env setup --base-dir /path/to/base --run-dir /path/to/run
idcu env setup --user
idcu env setup --system
```

## 配置命令

```bash
# 显示配置
idcu config show

# 重新加载配置
idcu config reload
```

## 别名命令

```bash
# 列出所有别名
idcu alias list

# 设置别名
idcu alias set gs "git status"

# 删除别名
idcu alias delete gs
```

## 发布命令

```bash
# 查看当前配置
idcu release config

# 创建发布分支
idcu release create-branch 1.0.0
idcu release create-branch 1.0.0 -p /path/to/project

# 更新版本号
idcu release update-version 1.0.0-SNAPSHOT 1.0.0
idcu release update-version 1.0.0-SNAPSHOT 1.0.0 -p /path/to/project

# 构建项目
idcu release build
idcu release build -p /path/to/project --skip-tests

# 部署项目
idcu release deploy
idcu release deploy maven-central -p /path/to/project

# 创建并推送 Git Tag
idcu release tag 1.0.0
idcu release tag 1.0.0 -p /path/to/project --no-push

# 执行完整发布流程
idcu release full 1.0.0-SNAPSHOT 1.0.0
idcu release full 1.0.0-SNAPSHOT 1.0.0 -p /path/to/project --skip-tests
```

## 跨语言构建命令

```bash
# 检测项目类型
idcu build detect
idcu build detect -p /path/to/project

# 构建项目
idcu build build
idcu build build -p /path/to/project

# 运行测试
idcu build test
idcu build test -p /path/to/project

# 清理项目
idcu build clean
idcu build clean -p /path/to/project
```

## AI 命令

```bash
# 智能生成提交信息
idcu ai commit
idcu ai commit -p /path/to/project --provider ollama

# 代码变更摘要
idcu ai summarize
idcu ai summarize -p /path/to/project -c abc123

# AI 聊天
idcu ai chat "你的问题"
idcu ai chat "你的问题" --model gpt-4
```

## CI/CD 命令

```bash
# 生成 CI 工作流
idcu cicd generate ci
idcu cicd generate ci -o .github/workflows/ci.yml

# 生成发布工作流
idcu cicd generate publish
idcu cicd generate publish -o .github/workflows/publish.yml

# 生成 Docker 工作流
idcu cicd generate docker
idcu cicd generate docker -i myimage -o .github/workflows/docker.yml

# 生成所有工作流
idcu cicd generate all
idcu cicd generate all -o .github/workflows/
```

## 团队协作命令

```bash
# 团队配置管理
idcu team config show
idcu team config init -n "我的团队" -d "团队描述"
idcu team config export -o team-config.yaml

# 权限管理
idcu team perm add-role developer read write
idcu team perm assign user1 developer
idcu team perm check user1 read
```

## Web UI 命令

```bash
# 启动 Web 服务
idcu web start
idcu web start -H 127.0.0.1 -p 8080 --reload
```

## 质量检查命令

```bash
# 运行所有质量检查
idcu quality run

# 运行单个质量检查
idcu quality check encoding

# 列出可用质量检查
idcu quality list

# 列出配置的质量门控
idcu quality gates
```

## 命令补全

```bash
# 生成 Bash 补全脚本
idcu completions bash
idcu completions bash -o ~/.bash_completion.d/idcu

# 生成 Zsh 补全脚本
idcu completions zsh
idcu completions zsh -o ~/.zsh/completions/_idcu

# 生成 PowerShell 补全脚本
idcu completions powershell
idcu completions powershell -o $PROFILE\idcu_completions.ps1
```
