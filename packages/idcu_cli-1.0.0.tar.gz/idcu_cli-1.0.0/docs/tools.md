# Tools 模块文档

Tools 模块提供完整的开发工具集，包括 Git 操作、Maven 构建、环境配置和插件系统。

## Git 操作

### GitOperationResult

Git 操作结果类。

```python
from idcu.tools.git import GitOperationResult

result = GitOperationResult(
    success=True,
    message="操作成功",
    details={"log": "提交日志"}
)

print(result.success)
print(result.message)
```

### 基础 Git 操作（单项目）

```python
from idcu.tools.git import (
    git_status,
    git_commit,
    git_push,
    git_pull,
    git_switch,
    git_log,
    git_fetch,
    git_stash,
    git_stash_pop,
    git_stash_list,
    git_changes,
    git_show,
    git_delete,
    git_rebase,
    git_cherry_pick,
    git_reset,
    git_diff_enhanced,
    git_clean,
    git_tag,
    git_blame,
    git_bisect
)
from pathlib import Path

# 查看状态
result = git_status(Path.cwd())

# 提交更改
result = git_commit(Path.cwd(), message="提交信息", all=True)

# 推送到远程
result = git_push(Path.cwd())

# 从远程拉取
result = git_pull(Path.cwd())

# 切换分支
result = git_switch(Path.cwd(), branch="develop")

# 查看日志
result = git_log(Path.cwd(), number=10)

# 获取远程更新
result = git_fetch(Path.cwd())

# 暂存更改
result = git_stash(Path.cwd(), message="暂存信息")

# 恢复暂存
result = git_stash_pop(Path.cwd())

# 查看暂存列表
result = git_stash_list(Path.cwd())

# 查看更改
result = git_changes(Path.cwd())

# 显示 Git 信息
result = git_show(Path.cwd())

# 变基
result = git_rebase(Path.cwd(), branch="main")

# 拣选提交
result = git_cherry_pick(Path.cwd(), commit="abc123")

# 重置
result = git_reset(Path.cwd(), mode="soft", commit="HEAD~1")

# 清理
result = git_clean(Path.cwd(), force=True)

# 标签
result = git_tag(Path.cwd(), tag_name="v1.0.0")

# 追溯
result = git_blame(Path.cwd(), file="file.py")

# 二分查找
result = git_bisect(Path.cwd(), command="pytest")
```

### 多项目 Git 操作

```python
from idcu.tools.git import (
    git_status_multi,
    git_commit_multi,
    git_push_multi,
    git_pull_multi,
    git_switch_multi,
    git_log_multi,
    git_fetch_multi,
    git_stash_multi,
    git_stash_pop_multi,
    git_stash_list_multi,
    git_changes_multi,
    git_show_multi,
    git_show_remote_multi,
    git_delete_multi,
    git_rebase_multi,
    git_cherry_pick_multi,
    git_reset_multi,
    git_diff_enhanced_multi,
    git_clean_multi,
    git_tag_multi,
    git_blame_multi,
    git_bisect_multi
)
from pathlib import Path

# 多项目查看状态
result = git_status_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目提交
result = git_commit_multi(Path.cwd(), message="提交信息", all=True, projects=["proj1"])

# 多项目推送
result = git_push_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目拉取
result = git_pull_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目切换分支
result = git_switch_multi(Path.cwd(), branch="develop", projects=["proj1", "proj2"])

# 多项目查看日志
result = git_log_multi(Path.cwd(), number=10, projects=["proj1", "proj2"])
```

### 子模块 Git 操作

```python
from idcu.tools.git import (
    git_status_submodule,
    git_commit_submodule,
    git_push_submodule,
    git_pull_submodule,
    git_switch_submodule,
    git_log_submodule,
    git_fetch_submodule,
    git_stash_submodule,
    git_stash_pop_submodule,
    git_stash_list_submodule,
    git_changes_submodule,
    git_show_submodule,
    git_show_remote_submodule,
    git_delete_submodule
)
from pathlib import Path

# 子模块查看状态
result = git_status_submodule(Path.cwd())

# 子模块提交
result = git_commit_submodule(Path.cwd(), message="提交信息", all=True)

# 子模块推送
result = git_push_submodule(Path.cwd())

# 子模块拉取
result = git_pull_submodule(Path.cwd())

# 子模块切换分支
result = git_switch_submodule(Path.cwd(), branch="develop")

# 子模块查看日志
result = git_log_submodule(Path.cwd(), number=10)
```

### Git 工具函数

```python
from idcu.tools.git import (
    list_available_projects,
    for_each_repo,
    get_repo_name,
    get_repo_paths,
    get_submodule_paths,
    run_git,
    run_git_checked
)
from pathlib import Path

# 列出可用项目
projects = list_available_projects(Path.cwd())
print(projects)

# 遍历所有仓库
def op(repo_path, repo_name):
    print(f"处理 {repo_name}")
    return 0

for_each_repo(Path.cwd(), op, projects=["proj1", "proj2"])

# 获取仓库名称
name = get_repo_name(Path.cwd())
print(name)

# 获取仓库路径列表
paths = get_repo_paths(Path.cwd())
print(paths)

# 获取子模块路径列表
paths = get_submodule_paths(Path.cwd())
print(paths)

# 运行 Git 命令
output = run_git(Path.cwd(), ["status"])
print(output)

# 运行 Git 命令并检查结果
success, output = run_git_checked(Path.cwd(), ["status"])
print(success, output)
```

## Maven 操作

### MavenOperationResult

Maven 操作结果类。

```python
from idcu.tools.maven import MavenOperationResult

result = MavenOperationResult(
    success=True,
    message="构建成功"
)

print(result.success)
print(result.message)
```

### 基础 Maven 操作（单项目）

```python
from idcu.tools.maven import (
    maven_clean,
    maven_compile,
    maven_test,
    maven_package,
    maven_install,
    maven_deploy,
    maven_goals,
    maven_clean_install,
    maven_clean_package,
    maven_dependency_tree,
    maven_dependency_list,
    maven_dependency_analyze,
    maven_dependency_conflict,
    maven_effective_pom,
    maven_set_profile,
    maven_list_profiles,
    maven_repo_list,
    maven_clean_local,
    maven_timeline,
    maven_build_parallel
)
from pathlib import Path

# 清理
result = maven_clean(Path.cwd())

# 编译
result = maven_compile(Path.cwd())

# 测试
result = maven_test(Path.cwd())

# 打包
result = maven_package(Path.cwd())

# 安装
result = maven_install(Path.cwd())

# 部署
result = maven_deploy(Path.cwd())

# 自定义目标
result = maven_goals(Path.cwd(), goals=["clean", "compile"])

# 清理并安装
result = maven_clean_install(Path.cwd())

# 清理并打包
result = maven_clean_package(Path.cwd())

# 依赖树
result = maven_dependency_tree(Path.cwd())

# 依赖列表
result = maven_dependency_list(Path.cwd())

# 依赖分析
result = maven_dependency_analyze(Path.cwd())

# 依赖冲突
result = maven_dependency_conflict(Path.cwd())

# 有效 POM
result = maven_effective_pom(Path.cwd())

# 设置 Profile
result = maven_set_profile(Path.cwd(), profile="prod")

# 列出 Profiles
result = maven_list_profiles(Path.cwd())

# 列出仓库
result = maven_repo_list(Path.cwd())

# 清理本地仓库
result = maven_clean_local(Path.cwd())

# 构建时间线
result = maven_timeline(Path.cwd())

# 并行构建
result = maven_build_parallel(Path.cwd())
```

### 多项目 Maven 操作

```python
from idcu.tools.maven import (
    maven_clean_multi,
    maven_compile_multi,
    maven_test_multi,
    maven_package_multi,
    maven_install_multi,
    maven_deploy_multi,
    maven_goals_multi,
    maven_clean_install_multi,
    maven_clean_package_multi,
    maven_dependency_tree_multi,
    maven_dependency_list_multi,
    maven_dependency_analyze_multi,
    maven_dependency_conflict_multi,
    maven_effective_pom_multi,
    maven_set_profile_multi,
    maven_list_profiles_multi,
    maven_repo_list_multi,
    maven_clean_local_multi,
    maven_timeline_multi,
    maven_build_parallel_multi
)
from pathlib import Path

# 多项目清理
result = maven_clean_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目编译
result = maven_compile_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目测试
result = maven_test_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目打包
result = maven_package_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目安装
result = maven_install_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目部署
result = maven_deploy_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目自定义目标
result = maven_goals_multi(Path.cwd(), goals=["clean", "compile"], projects=["proj1", "proj2"])

# 多项目清理并安装
result = maven_clean_install_multi(Path.cwd(), projects=["proj1", "proj2"])

# 多项目清理并打包
result = maven_clean_package_multi(Path.cwd(), projects=["proj1", "proj2"])
```

### 子模块 Maven 操作

```python
from idcu.tools.maven import (
    maven_clean_submodule,
    maven_compile_submodule,
    maven_test_submodule,
    maven_package_submodule,
    maven_install_submodule,
    maven_deploy_submodule,
    maven_goals_submodule,
    maven_clean_install_submodule,
    maven_clean_package_submodule,
    get_submodule_projects
)
from pathlib import Path

# 子模块清理
result = maven_clean_submodule(Path.cwd())

# 子模块编译
result = maven_compile_submodule(Path.cwd())

# 子模块测试
result = maven_test_submodule(Path.cwd())

# 子模块打包
result = maven_package_submodule(Path.cwd())

# 子模块安装
result = maven_install_submodule(Path.cwd())

# 子模块部署
result = maven_deploy_submodule(Path.cwd())

# 子模块自定义目标
result = maven_goals_submodule(Path.cwd(), goals=["clean", "compile"])

# 子模块清理并安装
result = maven_clean_install_submodule(Path.cwd())

# 子模块清理并打包
result = maven_clean_package_submodule(Path.cwd())

# 获取子模块项目
projects = get_submodule_projects(Path.cwd())
print(projects)
```

### Maven 工具函数

```python
from idcu.tools.maven import (
    list_available_maven_projects,
    for_each_maven_project,
    get_maven_project_paths,
    get_project_name,
    run_maven,
    run_maven_checked
)
from pathlib import Path

# 列出可用 Maven 项目
projects = list_available_maven_projects(Path.cwd())
print(projects)

# 遍历所有 Maven 项目
def op(project_path, project_name):
    print(f"处理 {project_name}")
    return 0

for_each_maven_project(Path.cwd(), op, projects=["proj1", "proj2"])

# 获取 Maven 项目路径列表
paths = get_maven_project_paths(Path.cwd())
print(paths)

# 获取项目名称
name = get_project_name(Path.cwd())
print(name)

# 运行 Maven 命令
result = run_maven(
    goals=["clean", "install"],
    local_repo=Path(".mvn/repo"),
    repo_root=Path.cwd(),
    args=[],
    projects=["proj1", "proj2"]
)

# 运行 Maven 命令并检查结果
success, output = run_maven_checked(Path.cwd(), ["clean", "install"])
print(success, output)
```

## 环境配置

环境配置功能主要通过命令行工具提供。请使用 `idcu env` 相关命令进行环境配置。

```bash
# 查看环境版本
idcu env versions

# 设置开发环境
idcu env setup
```

### 环境变量工具

系统提供了环境变量管理工具：

```python
from idcu.system.env_utils import (
    set_env,
    get_env,
    add_path,
    is_admin
)

# 设置环境变量
set_env("MY_VAR", "my_value")

# 获取环境变量
value = get_env("MY_VAR")
print(value)

# 添加路径到 PATH
add_path("/path/to/bin")

# 检查是否是管理员
print(is_admin())
```

**注意**：`EnvConfig`、`SoftwareVersion` 等高级环境配置类目前是可选模块，若需要使用请确保相关模块已安装。

## 插件系统

### 插件基础

```python
from idcu.tools.plugins import (
    Plugin,
    PluginMetadata,
    PluginManager,
    register_plugin
)

# 定义插件元数据
metadata = PluginMetadata(
    name="my_plugin",
    version="1.0.0",
    description="我的插件"
)

# 创建插件
class MyPlugin(Plugin):
    def __init__(self):
        super().__init__(metadata)
    
    def initialize(self):
        pass

# 注册插件
plugin = MyPlugin()
register_plugin(plugin)
```

### 插件管理

```python
from idcu.tools.plugins import (
    list_plugins,
    initialize_plugins,
    get_plugin,
    has_plugin,
    cleanup_plugins,
    trigger_hook
)

# 列出所有插件
plugins = list_plugins()
for p in plugins:
    print(f"{p.name} v{p.version}")
    print(f"  {p.description}")

# 初始化所有插件
initialize_plugins()

# 获取插件
plugin = get_plugin("my_plugin")
if plugin:
    print(plugin.name)

# 检查插件是否存在
exists = has_plugin("my_plugin")
print(exists)

# 清理插件
cleanup_plugins()

# 触发钩子
trigger_hook("before_build", context={})
```

### 插件命令

```python
from idcu.tools.plugins import (
    get_command,
    list_commands
)

# 获取插件命令
cmd = get_command("hello")
if cmd:
    print(cmd("World"))

# 列出所有插件命令
commands = list_commands()
for name, desc in commands.items():
    print(f"{name}: {desc}")
```

### 插件市场和脚手架

```python
from idcu.tools.plugins import market, scaffold

# 插件市场
# market.search_plugins("keyword")
# market.install_plugin("plugin-name")

# 插件脚手架
# scaffold.create_plugin("my-new-plugin")
```
