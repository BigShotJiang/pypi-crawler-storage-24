# CI/CD 文档

IDCU CLI 提供 CI/CD 集成功能，支持 GitHub Actions、GitLab CI 和 Jenkins。

## GitHub Actions

```python
from idcu.tools.cicd import github_actions

# 获取工作流状态
status = github_actions.get_workflow_status(
    repo="owner/repo",
    workflow_id="workflow.yml"
)

# 触发工作流
github_actions.trigger_workflow(
    repo="owner/repo",
    workflow_id="workflow.yml",
    ref="main"
)
```

## GitLab CI

```python
from idcu.tools.cicd import gitlab_ci

# 获取流水线状态
status = gitlab_ci.get_pipeline_status(
    project_id="123",
    pipeline_id="456"
)

# 触发流水线
gitlab_ci.trigger_pipeline(
    project_id="123",
    ref="main"
)
```

## Jenkins

```python
from idcu.tools.cicd import jenkins

# 获取构建状态
status = jenkins.get_build_status(
    job="my-job",
    build_number="123"
)

# 触发构建
jenkins.trigger_build(
    job="my-job",
    parameters={"param": "value"}
)
```

## 部署功能

```python
from idcu.tools.cicd import deploy

# Docker 构建
deploy.docker_build(
    context=".",
    tag="my-image:latest"
)

# Docker 推送
deploy.docker_push(
    tag="my-image:latest",
    registry="registry.example.com"
)

# SCP 部署
deploy.scp_deploy(
    source="dist/",
    destination="user@server:/path/",
    host="server",
    user="user"
)
```
