# 团队协作文档

IDCU CLI 提供团队协作功能，包括配置共享、权限管理和代码审查。

## 团队配置

```python
from idcu.tools.team import TeamConfig

config = TeamConfig()

# 加载团队配置
config.load()

# 获取团队成员
members = config.get_members()

# 添加团队成员
config.add_member(
    name="张三",
    email="zhangsan@example.com",
    role="developer"
)

# 保存配置
config.save()
```

## 权限管理

```python
from idcu.tools.team import PermissionManager

manager = PermissionManager()

# 检查权限
has_permission = manager.check_permission(
    user="zhangsan",
    permission="push"
)

# 授予权限
manager.grant_permission(
    user="zhangsan",
    permission="push"
)

# 撤销权限
manager.revoke_permission(
    user="zhangsan",
    permission="push"
)
```

## 代码审查

```python
from idcu.tools.team import CodeReview

review = CodeReview()

# 创建审查
review.create_review(
    title="审查标题",
    description="审查描述",
    author="zhangsan",
    reviewers=["lisi", "wangwu"]
)

# 添加评论
review.add_comment(
    review_id="123",
    author="lisi",
    content="评论内容"
)

# 批准审查
review.approve_review(
    review_id="123",
    reviewer="lisi"
)
```
