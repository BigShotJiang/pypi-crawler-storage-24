# IDCU CLI - API 文档

欢迎使用 IDCU CLI（不羁盟）API 文档。IDCU CLI 是一站式全栈开发工作流管理工具，提供统一的命令行接口和 Python API。

## 文档导航

- [CLI 文档](cli.md) - 命令行接口使用指南
- [Core 文档](core.md) - 核心工具模块
- [Tools 文档](tools.md) - 开发工具集
- [System 文档](system.md) - 系统层模块
- [CI/CD 文档](cicd.md) - CI/CD 集成指南
- [AI 文档](ai.md) - AI 增强功能
- [团队协作文档](team.md) - 团队协作功能
- [跨语言文档](crosslang.md) - 跨语言构建支持
- [Web UI 文档](web.md) - Web 界面和 API

## 快速开始

### 安装

```bash
pip install idcu-cli
```

### 基本使用

```python
from idcu import git_status, git_commit
from pathlib import Path

# 查看 Git 状态
result = git_status(Path.cwd())
print(result.message)

# 提交更改
result = git_commit(Path.cwd(), message="提交信息", all=True)
```

## 项目架构

```
idcu/
├── cli/          # 命令行界面
├── core/         # 核心工具
├── system/       # 系统层
└── tools/        # 开发工具集
    ├── git/      # Git 操作
    ├── maven/    # Maven 操作
    ├── plugins/  # 插件系统
    ├── cicd/     # CI/CD 集成
    ├── ai/       # AI 增强
    ├── team/     # 团队协作
    ├── crosslang/# 跨语言支持
    └── web/      # Web UI
```

## 许可证

Apache License 2.0
