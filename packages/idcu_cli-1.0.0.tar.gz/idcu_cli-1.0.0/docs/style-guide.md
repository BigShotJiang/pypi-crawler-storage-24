# 代码风格指南

## Python 代码风格

### 格式化工具

使用 Black 和 Ruff：

```bash
# 格式化
ruff format

# 检查
ruff check
```

### 命名约定

- 类名：`PascalCase`
- 函数名：`snake_case`
- 变量名：`snake_case`
- 常量：`UPPER_SNAKE_CASE`

### 类型注解

使用类型注解：

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"
```

### 文档字符串

使用 Google 风格文档字符串：

```python
def function(param: int) -> str:
    """函数描述。

    Args:
        param: 参数描述

    Returns:
        返回值描述
    """
    pass
```

## 测试

使用 pytest 编写测试：

```python
def test_function():
    assert function(1) == "expected"
```

## Git 提交

遵循 Conventional Commits：

```
feat: 添加新功能
fix: 修复问题
docs: 更新文档
```
