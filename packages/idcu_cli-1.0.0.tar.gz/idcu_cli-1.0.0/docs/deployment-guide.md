# 部署指南

## 本地安装

```bash
# 从 PyPI 安装
pip install idcu-cli

# 验证安装
idcu --version
```

## Docker 部署

```bash
# 拉取镜像
docker pull idcu/dev-tools:latest

# 运行
docker run -it --rm idcu/dev-tools:latest idcu --help
```

## 开发环境部署

```bash
# 克隆仓库
git clone https://gitee.com/idcu/cli.git
cd cli

# 安装开发依赖
pip install -e ".[dev,web,ai]"

# 运行测试
pytest tests/ -v
```

## Web UI 部署

```bash
# 安装 Web 依赖
pip install "idcu-cli[web]"

# 启动服务
idcu web serve --host 0.0.0.0 --port 8000
```

## 配置

创建 `.idcu/config.yaml`：

```yaml
global:
  color_output: true
  verbose: false

git:
  default_branch: develop
  remote_name: origin
```
