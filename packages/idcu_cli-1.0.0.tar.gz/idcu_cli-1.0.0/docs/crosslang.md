# 跨语言文档

IDCU CLI 提供跨语言构建支持，包括 npm/yarn/pnpm、Python、Go 和 Rust。

## 语言检测

```python
from idcu.tools.crosslang import detect_project_type
from pathlib import Path

# 检测项目类型
project_type = detect_project_type(Path.cwd())
print(project_type)  # npm, python, go, rust, etc.
```

## npm/yarn/pnpm

```python
from idcu.tools.crosslang import npm

# 安装依赖
npm.install(Path.cwd())

# 运行脚本
npm.run_script(Path.cwd(), "build")

# 测试
npm.test(Path.cwd())

# 打包
npm.package(Path.cwd())
```

## Python

```python
from idcu.tools.crosslang import python

# 安装依赖
python.install(Path.cwd())

# 测试
python.test(Path.cwd())

# 打包
python.package(Path.cwd())
```

## Go

```python
from idcu.tools.crosslang import golang

# 安装依赖
golang.install(Path.cwd())

# 构建
golang.build(Path.cwd())

# 测试
golang.test(Path.cwd())
```

## Rust

```python
from idcu.tools.crosslang import rust

# 安装依赖
rust.install(Path.cwd())

# 构建
rust.build(Path.cwd())

# 测试
rust.test(Path.cwd())
```

## 统一构建接口

```python
from idcu.tools.crosslang import build_project
from pathlib import Path

# 自动检测项目类型并构建
result = build_project(Path.cwd())
print(result)
```
