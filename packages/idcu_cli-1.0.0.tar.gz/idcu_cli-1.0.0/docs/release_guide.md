# 发布指南

## 发布前检查

1. 确保所有测试通过
2. 更新版本号
3. 更新 CHANGELOG.md
4. 创建 Git 标签

```bash
# 运行测试
pytest tests/ -v

# 更新版本号
# 编辑 pyproject.toml

# 更新 CHANGELOG
# 编辑 CHANGELOG.md

# 提交
git add pyproject.toml CHANGELOG.md
git commit -m "chore: 准备发布 v1.0.0"

# 创建标签
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

## 构建和发布

```bash
# 安装构建工具
pip install build twine

# 构建
python -m build

# 上传到 PyPI
twine upload dist/*
```

## Docker 发布

```bash
# 构建镜像
docker build -t idcu/cli:v1.0.0 .

# 推送
docker push idcu/cli:v1.0.0
docker push idcu/cli:latest
```

## 发布后

1. 创建 GitHub Release
2. 发布公告
3. 更新文档
