# Core 模块文档

Core 模块提供核心工具函数和常量定义。

## 常量

```python
from idcu.core import DEFAULT_BRANCH, REMOTE_NAME

print(DEFAULT_BRANCH)  # 默认分支名
print(REMOTE_NAME)     # 默认远程名
```

## UI 工具

```python
from idcu.core import (
    print_success,
    print_error,
    print_warning,
    print_info,
    print_header,
    print_section
)

print_success("操作成功")
print_error("发生错误")
print_warning("警告信息")
print_info("普通信息")
print_header("标题")
print_section("章节")
```

## 编码工具

```python
from idcu.core import (
    detect_file_encoding,
    fix_file_encoding,
    has_garbage_text,
    fix_garbage
)
from pathlib import Path

# 检测文件编码
encoding = detect_file_encoding(Path("file.txt"))

# 修复文件编码
fix_file_encoding(Path("file.txt"))

# 检查是否有乱码
has_garbage = has_garbage_text("乱码文本")

# 修复乱码
fixed = fix_garbage("乱码文本")
```

## 缓存管理

```python
from idcu.core import get_memory_cache, get_file_cache, cached

# 获取内存缓存（TTL: 300秒）
memory_cache = get_memory_cache()
memory_cache.set("key", "value")
value = memory_cache.get("key")

# 获取文件缓存（TTL: 3600秒）
file_cache = get_file_cache()
file_cache.set("key", {"data": "value"})
data = file_cache.get("key")

# 清除缓存
memory_cache.clear()
file_cache.clear()

# 缓存装饰器
@cached(memory_cache, key_prefix="my_func", ttl=60)
def expensive_function(x):
    return x * 2
```

## 内存管理

```python
from idcu.core import (
    get_memory_usage,
    memory_efficient,
    monitor_memory_usage,
    clear_cache_and_collect,
    optimize_list,
    LazyIterator
)

# 获取当前进程内存使用（MB）
usage = get_memory_usage()
print(f"Memory usage: {usage:.2f} MB")

# 内存效率装饰器 - 函数执行后自动清理缓存和GC
@memory_efficient
def process_large_data():
    return [i for i in range(1000000)]

# 内存监控装饰器
@monitor_memory_usage
def analyze_data():
    pass

# 手动清理和GC
clear_cache_and_collect()

# 列表优化处理
result = optimize_list([1, 2, 3, 4, 5], chunk_size=1000)

# 延迟迭代器
def load_large_dataset():
    return [i for i in range(1000000)]

lazy_data = LazyIterator(load_large_dataset)
for item in lazy_data:
    print(item)
```

## 工具函数

```python
from idcu.core import Timer, format_size

# 计时器
with Timer() as t:
    pass
print(f"耗时: {t.elapsed:.2f}秒")

# 格式化文件大小
print(format_size(1024))  # 1.0 KB
```
