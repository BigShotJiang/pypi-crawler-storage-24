# 首次贡献指南

欢迎参与 IDCU CLI 项目贡献！

## 准备工作

1. Fork 项目仓库
2. 克隆你的 Fork
3. 安装开发依赖

```bash
git clone https://gitee.com/your-username/cli.git
cd cli
pip install -e ".[dev]"
```

## 开发流程

1. 创建功能分支
2. 进行修改
3. 运行测试
4. 提交更改
5. 推送并创建 PR

```bash
# 创建分支
git checkout -b feature/your-feature

# 运行测试
pytest tests/ -v

# 格式化代码
ruff format
ruff check

# 提交
git add .
git commit -m "feat: 添加新功能"
git push origin feature/your-feature
```

## 代码规范

- 使用 Black 格式化代码
- 使用 Ruff 进行代码检查
- 使用 MyPy 进行类型检查
- 编写单元测试

## 提交信息规范

遵循 Conventional Commits 规范：

- `feat:` 新功能
- `fix:` 修复
- `docs:` 文档
- `style:` 格式
- `refactor:` 重构
- `test:` 测试
- `chore:` 构建/工具

## 获得帮助

如有问题，请提交 Issue 或联系维护者。
