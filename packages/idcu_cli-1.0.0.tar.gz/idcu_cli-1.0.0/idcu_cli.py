#!/usr/bin/env python3
"""IDCU CLI entry point."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from idcu.cli.main import CLI


def run_cli():
    """Run the CLI."""
    cli = CLI()
    return cli.run()


if __name__ == "__main__":
    raise SystemExit(run_cli())
