
from typing import Any, Dict


def get_config_schema() -> Dict[str, Dict[str, Any]]:
    return {
        "global": {
            "type": "object",
            "properties": {
                "color_output": {"type": "boolean"},
                "verbose": {"type": "boolean"},
                "quiet": {"type": "boolean"},
                "dry_run": {"type": "boolean"},
                "log_level": {"type": "string", "enum": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]},
                "log_max_file_size": {"type": "integer", "minimum": 1024},
                "log_backup_count": {"type": "integer", "minimum": 0},
            },
            "required": ["color_output", "verbose", "quiet", "dry_run"],
        },
        "i18n": {
            "type": "object",
            "properties": {
                "language": {"type": "string"},
                "auto_detect": {"type": "boolean"},
            },
            "required": ["language"],
        },
        "git": {
            "type": "object",
            "properties": {
                "default_branch": {"type": "string"},
                "remote_name": {"type": "string"},
                "auto_fetch": {"type": "boolean"},
            },
            "required": ["default_branch", "remote_name"],
        },
        "maven": {
            "type": "object",
            "properties": {
                "local_repo_path": {"type": "string"},
                "default_goals": {"type": "array", "items": {"type": "string"}},
                "offline_mode": {"type": "boolean"},
            },
            "required": ["local_repo_path", "default_goals"],
        },
        "audit": {
            "type": "object",
            "properties": {
                "encoding_scan_patterns": {"type": "array", "items": {"type": "string"}},
                "encoding_scan_excludes": {"type": "array", "items": {"type": "string"}},
                "deps_audit_strict": {"type": "boolean"},
            },
        },
        "project": {
            "type": "object",
            "properties": {
                "type": {"type": "string"},
                "version": {"type": "string"},
                "jdk": {"type": "string"},
                "tiers": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "order": {"type": "integer"},
                            "modules": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["name", "order", "modules"],
                    },
                },
                "quality-gates": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["type", "version", "jdk"],
        },
    }
