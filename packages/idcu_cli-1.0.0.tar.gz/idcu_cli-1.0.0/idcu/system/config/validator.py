
from typing import Any, Dict, List, Optional, Tuple


class ValidationError:
    def __init__(self, field: str, message: str):
        self.field = field
        self.message = message

    def __str__(self):
        return f"[{self.field}] {self.message}"


class ConfigValidator:
    def __init__(self, schema: Dict[str, Dict[str, Any]]):
        self.schema = schema
        self.errors: List[ValidationError] = []

    def validate(self, config: Dict[str, Any]) -> Tuple[bool, List[ValidationError]]:
        self.errors = []

        for section_name, section_schema in self.schema.items():
            if section_name not in config:
                self.errors.append(ValidationError(
                    section_name,
                    f"Missing required section: {section_name}"
                ))
                continue

            section_config = config[section_name]
            self._validate_section(
                section_name,
                section_config,
                section_schema
            )

        return len(self.errors) == 0, self.errors

    def _validate_section(
        self,
        section_name: str,
        section_config: Dict[str, Any],
        section_schema: Dict[str, Any]
    ):
        properties = section_schema.get("properties", {})
        required = section_schema.get("required", [])

        for req_field in required:
            if req_field not in section_config:
                self.errors.append(ValidationError(
                    f"{section_name}.{req_field}",
                    f"Missing required field: {req_field}"
                ))

        for field_name, field_value in section_config.items():
            if field_name not in properties:
                continue

            field_schema = properties[field_name]
            field_path = f"{section_name}.{field_name}"

            self._validate_field(field_path, field_value, field_schema)

    def _validate_field(
        self,
        field_path: str,
        field_value: Any,
        field_schema: Dict[str, Any]
    ):
        expected_type = field_schema.get("type")

        if not self._check_type(field_value, expected_type):
            self.errors.append(ValidationError(
                field_path,
                f"Expected type {expected_type}, got {type(field_value).__name__}"
            ))
            return

        if expected_type == "string":
            self._validate_string(field_path, field_value, field_schema)
        elif expected_type == "integer":
            self._validate_integer(field_path, field_value, field_schema)
        elif expected_type == "array":
            self._validate_array(field_path, field_value, field_schema)

    def _check_type(self, value: Any, expected_type: str) -> bool:
        if expected_type == "string":
            return isinstance(value, str)
        elif expected_type == "integer":
            return isinstance(value, int)
        elif expected_type == "boolean":
            return isinstance(value, bool)
        elif expected_type == "array":
            return isinstance(value, list)
        elif expected_type == "object":
            return isinstance(value, dict)
        return True

    def _validate_string(
        self,
        field_path: str,
        value: str,
        schema: Dict[str, Any]
    ):
        enum_values = schema.get("enum")
        if enum_values and value not in enum_values:
            self.errors.append(ValidationError(
                field_path,
                f"Value must be one of: {', '.join(enum_values)}"
            ))

    def _validate_integer(
        self,
        field_path: str,
        value: int,
        schema: Dict[str, Any]
    ):
        minimum = schema.get("minimum")
        if minimum is not None and value < minimum:
            self.errors.append(ValidationError(
                field_path,
                f"Value must be at least {minimum}"
            ))

    def _validate_array(
        self,
        field_path: str,
        value: List[Any],
        schema: Dict[str, Any]
    ):
        items_schema = schema.get("items", {})
        item_type = items_schema.get("type")

        if item_type:
            for i, item in enumerate(value):
                if not self._check_type(item, item_type):
                    self.errors.append(ValidationError(
                        f"{field_path}[{i}]",
                        f"Expected type {item_type}, got {type(item).__name__}"
                    ))


def validate_config(config: Dict[str, Any], schema: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[bool, List[ValidationError]]:
    if schema is None:
        from .schema import get_config_schema
        schema = get_config_schema()

    validator = ConfigValidator(schema)
    return validator.validate(config)
