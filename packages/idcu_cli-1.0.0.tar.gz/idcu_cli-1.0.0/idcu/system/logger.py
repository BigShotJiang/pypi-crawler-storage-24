import json
import logging
import sys
from datetime import datetime
from enum import Enum
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Callable, Optional

from idcu.core import print_error, print_info


class LogLevel(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class StructuredFormatter(logging.Formatter):
    def __init__(self, detailed: bool = False):
        super().__init__()
        self.detailed = detailed

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        if hasattr(record, "extra_fields"):
            log_entry.update(record.extra_fields)

        if self.detailed:
            return json.dumps(log_entry, ensure_ascii=False, indent=2)
        return json.dumps(log_entry, ensure_ascii=False)


class LoggerManager:
    def __init__(self, log_dir: Path, config_manager=None):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.loggers = {}
        self.main_logger: Optional[logging.Logger] = None
        self._config_manager = config_manager
        self._setup_main_logger()

    def _setup_main_logger(self) -> None:
        try:
            if self._config_manager is None:
                from .config_manager import get_config_manager

                config_manager = get_config_manager()
            else:
                config_manager = self._config_manager

            log_level = config_manager.get("global", "log_level", "INFO")
            max_file_size = config_manager.get("global", "log_max_file_size", 10 * 1024 * 1024)
            backup_count = config_manager.get("global", "log_backup_count", 5)
        except ImportError:
            log_level = "INFO"
            max_file_size = 10 * 1024 * 1024
            backup_count = 5

        self.main_logger = logging.getLogger("est_spi")
        self.main_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
        self.main_logger.handlers.clear()

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        self.main_logger.addHandler(console_handler)

        log_file = self.log_dir / "est_spi.log"
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setFormatter(StructuredFormatter(detailed=False))
        self.main_logger.addHandler(file_handler)

        detailed_log_file = self.log_dir / "est_spi_detailed.log"
        detailed_handler = RotatingFileHandler(
            detailed_log_file,
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding="utf-8",
        )
        detailed_handler.setFormatter(StructuredFormatter(detailed=True))
        self.main_logger.addHandler(detailed_handler)

    def close(self) -> None:
        seen_handlers = set()
        managed_loggers = []
        if self.main_logger is not None:
            managed_loggers.append(self.main_logger)
        managed_loggers.extend(self.loggers.values())

        for logger in managed_loggers:
            for handler in list(logger.handlers):
                logger.removeHandler(handler)
                handler_id = id(handler)
                if handler_id in seen_handlers:
                    continue
                seen_handlers.add(handler_id)
                try:
                    handler.flush()
                except Exception:
                    pass
                try:
                    handler.close()
                except Exception:
                    pass

        self.loggers.clear()
        self.main_logger = None

    def get_logger(self, name: str) -> logging.Logger:
        if name in self.loggers:
            return self.loggers[name]

        logger = logging.getLogger(f"est_spi.{name}")
        logger.setLevel(self.main_logger.level)
        logger.propagate = False
        logger.handlers.clear()

        for handler in self.main_logger.handlers:
            logger.addHandler(handler)

        self.loggers[name] = logger
        return logger

    def set_log_level(self, level) -> None:
        if isinstance(level, str):
            level = LogLevel(level.upper())

        level_value = getattr(logging, level.value, logging.INFO)
        self.main_logger.setLevel(level_value)

        for logger in self.loggers.values():
            logger.setLevel(level_value)

    def log(self, level: LogLevel, message: str, **kwargs) -> None:
        if self.main_logger is None:
            return

        extra_fields = kwargs.pop("extra", {})
        if extra_fields:
            kwargs["extra"] = {"extra_fields": extra_fields}

        log_method = getattr(self.main_logger, level.value.lower())
        log_method(message, **kwargs)

    def debug(self, message: str, **kwargs) -> None:
        self.log(LogLevel.DEBUG, message, **kwargs)

    def info(self, message: str, **kwargs) -> None:
        self.log(LogLevel.INFO, message, **kwargs)

    def warning(self, message: str, **kwargs) -> None:
        self.log(LogLevel.WARNING, message, **kwargs)

    def error(self, message: str, **kwargs) -> None:
        self.log(LogLevel.ERROR, message, **kwargs)

    def critical(self, message: str, **kwargs) -> None:
        self.log(LogLevel.CRITICAL, message, **kwargs)

    def exception(self, message: str, **kwargs) -> None:
        if self.main_logger:
            self.main_logger.exception(message, **kwargs)

    def get_log_files(self):
        log_files = []

        main_log = self.log_dir / "est_spi.log"
        if main_log.exists():
            log_files.append(main_log)

        for i in range(1, 10):
            rotated_log = self.log_dir / f"est_spi.log.{i}"
            if rotated_log.exists():
                log_files.append(rotated_log)

        detailed_log = self.log_dir / "est_spi_detailed.log"
        if detailed_log.exists():
            log_files.append(detailed_log)

        for i in range(1, 10):
            rotated_detailed = self.log_dir / f"est_spi_detailed.log.{i}"
            if rotated_detailed.exists():
                log_files.append(rotated_detailed)

        return log_files

    def query_logs(self, level=None, start_time=None, end_time=None, keyword=None, limit: int = 100):
        results = []
        detailed_log = self.log_dir / "est_spi_detailed.log"

        if not detailed_log.exists():
            return results

        try:
            if self.main_logger:
                for handler in self.main_logger.handlers:
                    handler.flush()

            with open(detailed_log, encoding="utf-8") as handle:
                content = handle.read()

            import re

            json_pattern = r"\{(?:[^{}]|(?:\{[^{}]*\}))*\}"
            json_matches = re.findall(json_pattern, content)

            for json_str in json_matches:
                if len(results) >= limit:
                    break

                try:
                    log_entry = json.loads(json_str)

                    if level and log_entry.get("level") != level.value:
                        continue

                    if start_time or end_time:
                        try:
                            log_time_str = log_entry.get("timestamp", "")
                            if log_time_str:
                                log_time = datetime.fromisoformat(log_time_str)
                                if start_time and log_time < start_time:
                                    continue
                                if end_time and log_time > end_time:
                                    continue
                        except (ValueError, AttributeError):
                            pass

                    if keyword and keyword.lower() not in log_entry.get("message", "").lower():
                        continue

                    results.append(log_entry)
                except (json.JSONDecodeError, ValueError, KeyError):
                    continue
        except Exception as exc:
            print_error(f"Error reading log file: {exc}")

        return results

    def clean_old_logs(self, days: int = 30) -> int:
        cleaned_count = 0
        cutoff_time = datetime.now().timestamp() - (days * 24 * 60 * 60)

        for log_file in self.log_dir.glob("*.log*"):
            try:
                if log_file.stat().st_mtime < cutoff_time:
                    log_file.unlink()
                    cleaned_count += 1
            except Exception as exc:
                print_error(f"Error deleting log file {log_file}: {exc}")

        if cleaned_count > 0:
            print_info(f"Cleaned {cleaned_count} old log files")

        return cleaned_count

    def export_logs(self, output_file, format: str = "json") -> bool:
        logs = self.query_logs(limit=10000)

        try:
            if format.lower() == "json":
                with open(output_file, "w", encoding="utf-8") as handle:
                    json.dump(logs, handle, ensure_ascii=False, indent=2)
            elif format.lower() == "csv":
                import csv

                with open(output_file, "w", encoding="utf-8", newline="") as handle:
                    if logs:
                        writer = csv.DictWriter(handle, fieldnames=logs[0].keys())
                        writer.writeheader()
                        writer.writerows(logs)
            else:
                print_error(f"Unsupported export format: {format}")
                return False

            return True
        except Exception as exc:
            print_error(f"Error exporting logs: {exc}")
            return False


_logger_manager: Optional[LoggerManager] = None


def set_logger_manager(manager: Optional[LoggerManager]) -> Optional[LoggerManager]:
    global _logger_manager

    if _logger_manager is not None and _logger_manager is not manager:
        _logger_manager.close()

    _logger_manager = manager
    return _logger_manager


def reset_logger_manager() -> None:
    set_logger_manager(None)


def get_logger_manager(
    log_dir: Optional[Path] = None,
    config_manager=None,
    *,
    reset: bool = False,
    factory: Optional[Callable[[Path, object], LoggerManager]] = None,
) -> LoggerManager:
    global _logger_manager

    if reset:
        reset_logger_manager()

    if _logger_manager is None:
        if log_dir is None:
            log_dir = Path.cwd() / ".idcu" / "logs"
        manager_factory = factory or LoggerManager
        _logger_manager = manager_factory(log_dir, config_manager)

    return _logger_manager


def get_logger(name: str, logger_manager: Optional[LoggerManager] = None):
    manager = logger_manager or get_logger_manager()
    return manager.get_logger(name)


def log_debug(message: str, logger_manager: Optional[LoggerManager] = None, **kwargs) -> None:
    manager = logger_manager or get_logger_manager()
    manager.debug(message, **kwargs)


def log_info(message: str, logger_manager: Optional[LoggerManager] = None, **kwargs) -> None:
    manager = logger_manager or get_logger_manager()
    manager.info(message, **kwargs)


def log_warning(message: str, logger_manager: Optional[LoggerManager] = None, **kwargs) -> None:
    manager = logger_manager or get_logger_manager()
    manager.warning(message, **kwargs)


def log_error(message: str, logger_manager: Optional[LoggerManager] = None, **kwargs) -> None:
    manager = logger_manager or get_logger_manager()
    manager.error(message, **kwargs)


def log_critical(message: str, logger_manager: Optional[LoggerManager] = None, **kwargs) -> None:
    manager = logger_manager or get_logger_manager()
    manager.critical(message, **kwargs)
