

import time
import traceback
from functools import wraps
from typing import Any, Callable, List, Optional, Tuple, Type, Union

from idcu.system.logger import get_logger

logger = get_logger(__name__)


class DevToolsError(Exception):
    """开发工具基础异常类
    所有自定义异常都应继承此类，提供错误码、详细信息和修复建议
    Attributes:
        message: 错误消息
        error_code: 错误码
        details: 详细信息字典
        suggestions: 修复建议列表
    """
    def __init__(self, message, error_code=1, details=None, suggestions=None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.suggestions = suggestions or []


class GitOperationError(DevToolsError):
    def __init__(
        self,
        message,
        git_command=None,
        return_code=None,
        output=None,
    ):
        details = {"git_command": git_command, "return_code": return_code, "output": output}
        super().__init__(message, error_code=2, details=details)


class MavenOperationError(DevToolsError):
    def __init__(
        self,
        message,
        maven_command=None,
        return_code=None,
        output=None,
    ):
        details = {"maven_command": maven_command, "return_code": return_code, "output": output}
        super().__init__(message, error_code=3, details=details)


class ConfigurationError(DevToolsError):
    def __init__(
        self, message, config_key=None, config_value=None
    ):
        details = {"config_key": config_key, "config_value": config_value}
        super().__init__(message, error_code=4, details=details)


class PluginError(DevToolsError):
    def __init__(
        self, message, plugin_name=None, plugin_version=None
    ):
        details = {"plugin_name": plugin_name, "plugin_version": plugin_version}
        super().__init__(message, error_code=5, details=details)


class RetryableError(DevToolsError):
    def __init__(self, message, error_code=10, details=None):
        super().__init__(message, error_code=error_code, details=details)


ERROR_SUGGESTIONS = {
    "git_not_found": ["请确保已安装 Git 并添加到 PATH", "运行 git --version 验证安装"],
    "maven_not_found": ["请确保已安装 Maven 并添加到 PATH", "运行 mvn --version 验证安装"],
    "permission_denied": ["请检查文件或目录权限", "尝试使用管理员/root 权限运行"],
    "network_error": ["请检查网络连接", "尝试使用代理或镜像源"],
    "invalid_branch": ["请检查分支名称是否正确", "使用 git branch -a 查看所有分支"],
    "conflict": ["请先解决冲突再继续", "使用 git status 查看冲突文件"],
    "dependency_not_found": ["请检查依赖坐标是否正确", "检查网络连接和 Maven 仓库配置"],
    "build_failed": ["请检查代码是否有编译错误", "查看详细的构建日志"],
}


class ErrorHandler:
    def __init__(self):
        self.logger = get_logger(__name__)

    def get_suggestions(self, exc) -> List[str]:
        suggestions = []
        if isinstance(exc, DevToolsError) and exc.suggestions:
            suggestions.extend(exc.suggestions)

        error_msg = str(exc).lower()
        for key, suggs in ERROR_SUGGESTIONS.items():
            if key in error_msg:
                suggestions.extend(suggs)

        return list(set(suggestions))

    def handle_exception(self, exc, verbose=False, print_suggestions=True):
        from idcu.core import colorize, print_error, print_info

        if isinstance(exc, DevToolsError):
            self.logger.error(f"Error: {exc.message}")
            print_error(exc.message)
            if verbose and exc.details:
                self.logger.debug(f"Error details: {exc.details}")
            if print_suggestions:
                suggestions = self.get_suggestions(exc)
                if suggestions:
                    print_info("建议:")
                    for i, suggestion in enumerate(suggestions, 1):
                        print(f"  {i}. {colorize(suggestion, 'YELLOW')}")
            return exc.error_code
        elif isinstance(exc, KeyboardInterrupt):
            self.logger.info("Operation cancelled by user")
            print_info("操作已取消")
            return 130
        else:
            self.logger.error(f"Unexpected error: {str(exc)}")
            print_error(f"发生意外错误: {str(exc)}")
            if verbose:
                self.logger.error("Traceback:")
                self.logger.error(traceback.format_exc())
                print_error("详细堆栈:")
                print(traceback.format_exc())
            if print_suggestions:
                suggestions = self.get_suggestions(exc)
                if suggestions:
                    print_info("建议:")
                    for i, suggestion in enumerate(suggestions, 1):
                        print(f"  {i}. {colorize(suggestion, 'YELLOW')}")
            return 1

    def log_warning(self, message, **kwargs):
        self.logger.warning(message, **kwargs)

    def log_info(self, message, **kwargs):
        self.logger.info(message, **kwargs)

    def log_debug(self, message, **kwargs):
        self.logger.debug(message, **kwargs)


error_handler = ErrorHandler()


def handle_errors(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            verbose = kwargs.get("verbose", False)
            if args and hasattr(args[0], "global_options"):
                verbose = args[0].global_options.verbose

            return error_handler.handle_exception(exc, verbose=verbose)

    return wrapper


def safe_execute(func, *args, **kwargs):
    try:
        return func(*args, **kwargs)
    except Exception as exc:
        verbose = kwargs.get("verbose", False)
        return error_handler.handle_exception(exc, verbose=verbose)


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Union[Type[Exception], Tuple[Type[Exception], ...]] = Exception,
    on_retry: Optional[Callable[[int, Exception], None]] = None,
):
    """
    重试装饰器
    Args:
        max_attempts: 最大重试次数
        delay: 初始延迟（秒）
        backoff: 延迟倍数
        exceptions: 需要重试的异常类型
        on_retry: 重试时的回调函数
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_exception: Optional[Exception] = None
            current_delay = delay

            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e

                    if attempt >= max_attempts:
                        break

                    if on_retry:
                        on_retry(attempt, e)
                    else:
                        logger.warning(
                            f"Attempt {attempt}/{max_attempts} failed: {e}. "
                            f"Retrying in {current_delay:.2f}s..."
                        )

                    time.sleep(current_delay)
                    current_delay *= backoff

            raise last_exception

        return wrapper
    return decorator


def with_retry(
    func: Callable,
    *args,
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Union[Type[Exception], Tuple[Type[Exception], ...]] = Exception,
    **kwargs
) -> Any:
    """
    带重试的函数执行

    Args:
        func: 要执行的函数
        *args: 函数参数
        max_attempts: 最大重试次数
        delay: 初始延迟（秒）
        backoff: 延迟倍数
        exceptions: 需要重试的异常类型
        **kwargs: 函数关键字参数
    Returns:
        函数执行结果
    """
    @retry(
        max_attempts=max_attempts,
        delay=delay,
        backoff=backoff,
        exceptions=exceptions
    )
    def wrapped():
        return func(*args, **kwargs)

    return wrapped()


def fallback(
    primary: Callable,
    fallback_func: Callable,
    *args,
    **kwargs
) -> Any:
    """
    带降级的函数执行

    Args:
        primary: 主函数
        fallback_func: 降级函数
        *args: 函数参数
        **kwargs: 函数关键字参数
    Returns:
        函数执行结果
    """
    try:
        return primary(*args, **kwargs)
    except Exception as e:
        logger.warning(f"Primary function failed: {e}, falling back to alternative")
        return fallback_func(*args, **kwargs)

