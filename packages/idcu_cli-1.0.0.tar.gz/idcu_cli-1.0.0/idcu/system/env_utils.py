

import ctypes
import winreg


def set_default(var_name, default_value, globals_dict):
    """
    设置默认值的通用方法
    :param var_name: 变量名（字符串）
    :param default_value: 默认值
    :param globals_dict: globals() 字典
    """
    if globals_dict[var_name] is None:
        globals_dict[var_name] = default_value


def is_admin():
    """检查当前是否以管理员权限运行"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False


def set_env(name_or_dict, value=None, user=True):
    """
    设置Windows环境变量
    :param name_or_dict: 环境变量名或环境变量字典 {name: value}
    :param value: 环境变量值（当name_or_dict是字符串时）
    :param user: True表示用户环境变量，False表示系统环境变量
    :return: 全部设置成功返回True，有失败返回False
    """
    if isinstance(name_or_dict, dict):
        success = True
        for name, val in name_or_dict.items():
            if not _set_single_env(name, val, user):
                success = False
        return success
    else:
        return _set_single_env(name_or_dict, value, user)


def _set_single_env(name, value, user=True):
    """
    设置单个Windows环境变量（内部函数）
    :param name: 环境变量名
    :param value: 环境变量值
    :param user: True表示用户环境变量，False表示系统环境变量
    :return: 设置成功返回True，失败返回False
    """
    try:
        if user:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_ALL_ACCESS)
        else:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment", 0, winreg.KEY_ALL_ACCESS)

        try:
            winreg.SetValueEx(key, name, 0, winreg.REG_EXPAND_SZ, value)
        finally:
            winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"设置环境变量 {name} 失败: {e}")
        return False


def get_env(name_or_list, user=True):
    """
    获取Windows环境变量
    :param name_or_list: 环境变量名或环境变量名列表
    :param user: True表示用户环境变量，False表示系统环境变量
    :return: 单个值返回字符串，多个值返回字典 {name: value}
    """
    if isinstance(name_or_list, (list, tuple)):
        result = {}
        for name in name_or_list:
            result[name] = _get_single_env(name, user)
        return result
    else:
        return _get_single_env(name_or_list, user)


def _get_single_env(name, user=True):
    """
    获取单个Windows环境变量（内部函数）
    :param name: 环境变量名
    :param user: True表示用户环境变量，False表示系统环境变量
    :return: 环境变量值，不存在返回空字符串
    """
    try:
        if user:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ)
        else:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment", 0, winreg.KEY_READ)

        try:
            value, _ = winreg.QueryValueEx(key, name)
            return value
        finally:
            winreg.CloseKey(key)
    except OSError:
        return ""


def add_path(paths, user=True):
    """
    将路径添加到PATH环境变量中，避免重复添加
    :param paths: 要添加的路径，单个字符串或路径列表
    :param user: True表示用户环境变量，False表示系统环境变量
    :return: 成功返回True，失败返回False
    """
    current_path = get_env("Path", user)
    path_parts = current_path.split(";")

    new_path_parts = []

    for p in path_parts:
        p = p.strip()
        if p and p not in new_path_parts:
            new_path_parts.append(p)

    if isinstance(paths, str):
        paths_to_process = [paths]
    else:
        paths_to_process = paths

    for path in paths_to_process:
        if path not in new_path_parts:
            new_path_parts.insert(0, path)

    new_path = ";".join(new_path_parts)
    return set_env("Path", new_path, user)

