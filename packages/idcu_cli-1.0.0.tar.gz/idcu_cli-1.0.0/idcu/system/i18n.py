

import os
from pathlib import Path
from typing import Dict, Optional

TRANSLATIONS: Dict[str, Dict[str, str]] = {
    "en": {
        "git_list": "Git projects list",
        "maven_list": "Maven projects list",
        "maven_build": "Maven build",
        "plugin_list": "Installed plugins",
        "no_plugins": "No plugins installed",
        "unknown_command": "Unknown command",
        "available_commands": "Available commands",
        "command_failed": "Command execution failed",
        "command_success": "Command execution succeeded",
        "build_success": "Build succeeded",
        "build_failed": "Build failed",
        "projects_found": "Found {count} projects",
        "processing_project": "Processing project: {name}",
        "git_status": "Git status",
        "git_commit": "Git commit",
        "git_push": "Git push",
        "git_pull": "Git pull",
        "git_fetch": "Git fetch",
        "git_switch": "Git switch to {branch}",
        "git_log": "Git log (last {count} entries)",
        "git_stash": "Git stash",
        "git_stash_pop": "Git stash pop",
        "git_stash_list": "Git stash list",
        "git_changes": "Git changes",
    },
    "zh": {
        "git_list": "Git项目列表",
        "maven_list": "Maven项目列表",
        "maven_build": "Maven构建",
        "plugin_list": "已安装插件",
        "no_plugins": "没有安装插件",
        "unknown_command": "未知命令",
        "available_commands": "可用命令",
        "command_failed": "命令执行失败",
        "command_success": "命令执行成功",
        "build_success": "构建成功",
        "build_failed": "构建失败",
        "projects_found": "共找到 {count} 个项目",
        "processing_project": "处理项目: {name}",
        "git_status": "Git状态",
        "git_commit": "Git提交",
        "git_push": "Git推送",
        "git_pull": "Git拉取",
        "git_fetch": "Git获取",
        "git_switch": "Git切换到 {branch}",
        "git_log": "Git日志 (最近 {count} 条)",
        "git_stash": "Git暂存",
        "git_stash_pop": "Git恢复暂存",
        "git_stash_list": "Git暂存列表",
        "git_changes": "Git更改",
    }
}


class I18nManager:
    def __init__(self, language: str = "en"):
        self.language = language
        self._translations = TRANSLATIONS.copy()

    def set_language(self, language: str) -> None:
        if language in self._translations:
            self.language = language
        else:
            self.language = "en"

    def get(self, key: str, **kwargs) -> str:
        translations = self._translations.get(self.language, self._translations["en"])
        text = translations.get(key, key)
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, IndexError):
                return text
        return text

    def t(self, key: str, **kwargs) -> str:
        return self.get(key, **kwargs)

    def load_from_file(self, file_path: Path) -> None:
        try:
            import json
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)
                for lang, trans in data.items():
                    if lang not in self._translations:
                        self._translations[lang] = {}
                    self._translations[lang].update(trans)
        except Exception as e:
            print(f"Failed to load translations from {file_path}: {e}")

    def load_from_directory(self, dir_path: Path) -> None:
        if not dir_path.exists():
            return
        for file_path in dir_path.glob("*.json"):
            self.load_from_file(file_path)

    def get_available_languages(self) -> list[str]:
        return list(self._translations.keys())


_i18n_manager: Optional[I18nManager] = None


def get_i18n_manager(language: Optional[str] = None) -> I18nManager:
    global _i18n_manager
    if _i18n_manager is None:
        lang = language or os.environ.get("IDCU_LANGUAGE", "en")
        _i18n_manager = I18nManager(lang)
    elif language is not None:
        _i18n_manager.set_language(language)
    return _i18n_manager


def _(key: str, **kwargs) -> str:
    return get_i18n_manager().t(key, **kwargs)

