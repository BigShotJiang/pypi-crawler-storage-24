
from dataclasses import dataclass, field
from pathlib import Path

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

from idcu.core import print_error, print_info, print_success


@dataclass
class Tier:
    name: str
    order: int
    modules: list = field(default_factory=list)


@dataclass
class ProjectConfig:
    type: str
    version: str
    jdk: str
    tiers: list = field(default_factory=list)
    quality_gates: list = field(default_factory=list)

    @classmethod
    def from_dict(cls, data):
        tiers = []
        if 'tiers' in data:
            for tier_data in data['tiers']:
                tiers.append(Tier(
                    name=tier_data['name'],
                    order=tier_data['order'],
                    modules=tier_data.get('modules', [])
                ))
        
        return cls(
            type=data.get('type', ''),
            version=data.get('version', ''),
            jdk=data.get('jdk', ''),
            tiers=tiers,
            quality_gates=data.get('quality-gates', [])
        )

    def to_dict(self):
        data = {
            'type': self.type,
            'version': self.version,
            'jdk': self.jdk
        }
        
        if self.tiers:
            data['tiers'] = [
                {
                    'name': tier.name,
                    'order': tier.order,
                    'modules': tier.modules
                }
                for tier in self.tiers
            ]
        
        if self.quality_gates:
            data['quality-gates'] = self.quality_gates
        
        return data

    def get_tier_by_name(self, name):
        for tier in self.tiers:
            if tier.name == name:
                return tier
        return None

    def get_tier_by_order(self, order):
        for tier in self.tiers:
            if tier.order == order:
                return tier
        return None

    def get_all_modules(self):
        all_modules = []
        for tier in self.tiers:
            all_modules.extend(tier.modules)
        return all_modules

    def has_quality_gate(self, gate_name):
        return gate_name in self.quality_gates


class ProjectConfigManager:
    def __init__(self, config_dir):
        self.config_dir = config_dir
        self.config_file = config_dir / "project.yaml"
        self.config = None
        self._last_modified = None
        self._load_config()

    def _load_config(self):
        if not self.config_file.exists():
            self.config = None
            return

        try:
            import os
            stat = os.stat(self.config_file)
            self._last_modified = stat.st_mtime

            with open(self.config_file, encoding="utf-8") as f:
                if HAS_YAML:
                    data = yaml.safe_load(f) or {}
                else:
                    print_error("PyYAML is not available. Cannot load project.yaml")
                    self.config = None
                    return

            if 'project' in data:
                self.config = ProjectConfig.from_dict(data['project'])
            else:
                self.config = None

        except Exception as e:
            print_error(f"Error loading project config: {e}")
            self.config = None

    def reload_if_changed(self):
        if not self.config_file.exists():
            return False

        try:
            import os
            stat = os.stat(self.config_file)
            if self._last_modified is not None and stat.st_mtime > self._last_modified:
                print_info("Project config file changed, reloading...")
                self._load_config()
                print_success("Project config reloaded successfully")
                return True
            return False
        except Exception as e:
            print_error(f"Error checking project config file: {e}")
            return False

    def force_reload(self):
        print_info("Force reloading project config...")
        self._load_config()
        print_success("Project config reloaded successfully")

    def exists(self):
        return self.config_file.exists()

    def is_valid(self):
        return self.config is not None and self.config.type and self.config.version and self.config.jdk

    def get_config(self):
        return self.config

    def save_config(self, config):
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            
            data = {'project': config.to_dict()}

            with open(self.config_file, "w", encoding="utf-8") as f:
                if HAS_YAML:
                    yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
                else:
                    print_error("PyYAML is not available. Cannot save project.yaml")
                    return False

            import os
            stat = os.stat(self.config_file)
            self._last_modified = stat.st_mtime
            self.config = config
            return True

        except Exception as e:
            print_error(f"Error saving project config: {e}")
            return False

    def get_config_file_path(self):
        return self.config_file


_project_config_manager = None


def get_project_config_manager(config_dir=None):
    global _project_config_manager

    if _project_config_manager is None:
        if config_dir is None:
            config_dir = Path.cwd() / ".idcu"
        _project_config_manager = ProjectConfigManager(config_dir)

    return _project_config_manager
