import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Optional

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

from idcu.core.ui import print_error, print_info, print_success


@dataclass
class ConfigSchema:
    global_config: Optional[Dict[str, Any]] = None
    i18n_config: Optional[Dict[str, Any]] = None
    plugin_config: Optional[Dict[str, Any]] = None
    git_config: Optional[Dict[str, Any]] = None
    maven_config: Optional[Dict[str, Any]] = None
    audit_config: Optional[Dict[str, Any]] = None
    aliases_config: Optional[Dict[str, Any]] = None

    def __post_init__(self) -> None:
        if self.global_config is None:
            self.global_config = {
                "color_output": True,
                "verbose": False,
                "quiet": False,
                "dry_run": False,
            }

        if self.i18n_config is None:
            self.i18n_config = {
                "language": "en",
                "auto_detect": True,
            }

        if self.plugin_config is None:
            self.plugin_config = {}

        if self.git_config is None:
            self.git_config = {
                "default_branch": "develop",
                "remote_name": "origin",
                "auto_fetch": False,
            }

        if self.maven_config is None:
            self.maven_config = {
                "local_repo_path": ".mvn/local-repo",
                "default_goals": ["clean", "install"],
                "offline_mode": False,
            }

        if self.audit_config is None:
            self.audit_config = {
                "encoding_scan_patterns": ["*.java", "*.md", "*.xml", "*.properties"],
                "encoding_scan_excludes": [".git", "target", ".mvn/local-repo"],
                "deps_audit_strict": True,
            }

        if self.aliases_config is None:
            self.aliases_config = {}


class ConfigManager:
    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.config_file = config_dir / "config.yaml"
        self.config = ConfigSchema()
        self._last_modified: Optional[float] = None
        self._load_config()

    def _load_config(self) -> None:
        if not self.config_file.exists():
            self._create_default_config()
            return

        try:
            stat = os.stat(self.config_file)
            self._last_modified = stat.st_mtime

            with open(self.config_file, encoding="utf-8") as handle:
                if self.config_file.suffix.lower() in {".yaml", ".yml"}:
                    data = yaml.safe_load(handle) if HAS_YAML else {}
                else:
                    data = json.load(handle)

            data = data or {}

            if "global" in data:
                self.config.global_config.update(data["global"])
            if "i18n" in data:
                self.config.i18n_config.update(data["i18n"])
            if "plugins" in data:
                self.config.plugin_config.update(data["plugins"])
            if "git" in data:
                self.config.git_config.update(data["git"])
            if "maven" in data:
                self.config.maven_config.update(data["maven"])
            if "audit" in data:
                self.config.audit_config.update(data["audit"])
            if "aliases" in data:
                self.config.aliases_config.update(data["aliases"])
        except Exception as exc:
            print_error(f"Error loading config: {exc}")
            print_info("Using default configuration")

    def reload_if_changed(self) -> bool:
        if not self.config_file.exists():
            return False

        try:
            stat = os.stat(self.config_file)
            if self._last_modified is not None and stat.st_mtime > self._last_modified:
                print_info("Config file changed, reloading...")
                self.config = ConfigSchema()
                self._load_config()
                print_success("Config reloaded successfully")
                return True
            return False
        except Exception as exc:
            print_error(f"Error checking config file: {exc}")
            return False

    def force_reload(self) -> None:
        print_info("Force reloading config...")
        self.config = ConfigSchema()
        self._load_config()
        print_success("Config reloaded successfully")

    def get_alias(self, alias_name: str) -> Optional[str]:
        return self.config.aliases_config.get(alias_name)

    def set_alias(self, alias_name: str, command: str) -> bool:
        try:
            self.config.aliases_config[alias_name] = command
            return self.save_config()
        except Exception as exc:
            print_error(f"Error setting alias: {exc}")
            return False

    def delete_alias(self, alias_name: str) -> bool:
        try:
            if alias_name in self.config.aliases_config:
                del self.config.aliases_config[alias_name]
                return self.save_config()
            return False
        except Exception as exc:
            print_error(f"Error deleting alias: {exc}")
            return False

    def list_aliases(self) -> Dict[str, str]:
        return self.config.aliases_config.copy()

    def _create_default_config(self) -> None:
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            default_config = self.get_all_config()

            with open(self.config_file, "w", encoding="utf-8") as handle:
                if HAS_YAML:
                    yaml.dump(default_config, handle, default_flow_style=False, allow_unicode=True)
                else:
                    json.dump(default_config, handle, ensure_ascii=False, indent=2)

            print_success(f"Created default config file: {self.config_file}")
        except Exception as exc:
            print_error(f"Error creating default config: {exc}")

    def save_config(self) -> bool:
        try:
            config_data = self.get_all_config()

            with open(self.config_file, "w", encoding="utf-8") as handle:
                if HAS_YAML:
                    yaml.dump(config_data, handle, default_flow_style=False, allow_unicode=True)
                else:
                    json.dump(config_data, handle, ensure_ascii=False, indent=2)

            stat = os.stat(self.config_file)
            self._last_modified = stat.st_mtime
            return True
        except Exception as exc:
            print_error(f"Error saving config: {exc}")
            return False

    def get(self, section: str, key: str, default: Any = None) -> Any:
        if section == "global":
            return self.config.global_config.get(key, default)
        if section == "i18n":
            return self.config.i18n_config.get(key, default)
        if section == "plugins":
            return self.config.plugin_config.get(key, default)
        if section == "git":
            return self.config.git_config.get(key, default)
        if section == "maven":
            return self.config.maven_config.get(key, default)
        if section == "audit":
            return self.config.audit_config.get(key, default)
        return default

    def set(self, section: str, key: str, value: Any) -> bool:
        try:
            if section == "global":
                self.config.global_config[key] = value
            elif section == "i18n":
                self.config.i18n_config[key] = value
            elif section == "plugins":
                self.config.plugin_config[key] = value
            elif section == "git":
                self.config.git_config[key] = value
            elif section == "maven":
                self.config.maven_config[key] = value
            elif section == "audit":
                self.config.audit_config[key] = value
            else:
                return False

            return self.save_config()
        except Exception as exc:
            print_error(f"Error setting config: {exc}")
            return False

    def get_section(self, section: str) -> Dict[str, Any]:
        if section == "global":
            return self.config.global_config.copy()
        if section == "i18n":
            return self.config.i18n_config.copy()
        if section == "plugins":
            return self.config.plugin_config.copy()
        if section == "git":
            return self.config.git_config.copy()
        if section == "maven":
            return self.config.maven_config.copy()
        if section == "audit":
            return self.config.audit_config.copy()
        if section == "aliases":
            return self.config.aliases_config.copy()
        return {}

    def set_section(self, section: str, data: Dict[str, Any]) -> bool:
        try:
            if section == "global":
                self.config.global_config = data
            elif section == "i18n":
                self.config.i18n_config = data
            elif section == "plugins":
                self.config.plugin_config = data
            elif section == "git":
                self.config.git_config = data
            elif section == "maven":
                self.config.maven_config = data
            elif section == "audit":
                self.config.audit_config = data
            elif section == "aliases":
                self.config.aliases_config = data
            else:
                return False

            return self.save_config()
        except Exception as exc:
            print_error(f"Error setting config section: {exc}")
            return False

    def get_all_config(self) -> Dict[str, Dict[str, Any]]:
        return {
            "global": self.config.global_config,
            "i18n": self.config.i18n_config,
            "plugins": self.config.plugin_config,
            "git": self.config.git_config,
            "maven": self.config.maven_config,
            "audit": self.config.audit_config,
            "aliases": self.config.aliases_config,
        }

    def reset_to_default(self) -> bool:
        try:
            self.config = ConfigSchema()
            return self.save_config()
        except Exception as exc:
            print_error(f"Error resetting config: {exc}")
            return False

    def validate_config(self) -> bool:
        try:
            required_global = ["color_output", "verbose", "quiet", "dry_run"]
            for key in required_global:
                if key not in self.config.global_config:
                    print_error(f"Missing required global config: {key}")
                    return False

            required_git = ["default_branch", "remote_name"]
            for key in required_git:
                if key not in self.config.git_config:
                    print_error(f"Missing required git config: {key}")
                    return False

            required_i18n = ["language"]
            for key in required_i18n:
                if key not in self.config.i18n_config:
                    print_error(f"Missing required i18n config: {key}")
                    return False

            required_maven = ["local_repo_path", "default_goals"]
            for key in required_maven:
                if key not in self.config.maven_config:
                    print_error(f"Missing required maven config: {key}")
                    return False

            return True
        except Exception as exc:
            print_error(f"Error validating config: {exc}")
            return False

    def get_config_file_path(self) -> Path:
        return self.config_file


_config_manager: Optional[ConfigManager] = None


def set_config_manager(manager: Optional[ConfigManager]) -> Optional[ConfigManager]:
    global _config_manager
    _config_manager = manager
    return _config_manager


def reset_config_manager() -> None:
    set_config_manager(None)


def get_config_manager(
    config_dir: Optional[Path] = None,
    *,
    reset: bool = False,
    factory: Optional[Callable[[Path], ConfigManager]] = None,
) -> ConfigManager:
    global _config_manager

    if reset:
        _config_manager = None

    if _config_manager is None:
        if config_dir is None:
            config_dir = Path.cwd() / ".idcu"
        manager_factory = factory or ConfigManager
        _config_manager = manager_factory(config_dir)

    return _config_manager
