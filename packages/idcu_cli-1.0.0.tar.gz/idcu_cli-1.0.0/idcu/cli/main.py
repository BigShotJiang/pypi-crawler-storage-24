import argparse
import sys
from typing import Optional

from idcu.core import VERSION, print_error, AppContext
from idcu.cli.commands import register_all_commands


class CLI:
    def __init__(self, app_context: Optional[AppContext] = None):
        if app_context is None:
            app_context = AppContext()
        self.app_context = app_context
        self.parser = argparse.ArgumentParser(
            description="IDCU CLI - 不羁盟开发工具\n\n主航道命令: git | maven | quality | config | plugin",
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        self._imported_modules = {}
        self._setup_subparsers()

    def _lazy_import(self, module_name, import_func):
        if module_name not in self._imported_modules:
            self._imported_modules[module_name] = import_func()
        return self._imported_modules[module_name]

    def _get_completions(self):
        def _import():
            from idcu.cli.completions import (
                generate_bash_completion,
                generate_powershell_completion,
                generate_zsh_completion,
            )
            return (generate_bash_completion, generate_powershell_completion, generate_zsh_completion)
        return self._lazy_import("completions", _import)

    def _get_devtools(self):
        def _import():
            from idcu.tools.git import (
                GitOperationResult,
                list_available_projects,
                for_each_repo,
                get_repo_name,
                get_repo_paths,
                get_submodule_paths,
                git_status,
                git_status_multi,
                git_status_submodule,
                git_commit,
                git_commit_multi,
                git_commit_submodule,
                git_push,
                git_push_multi,
                git_push_submodule,
                git_pull,
                git_pull_multi,
                git_pull_submodule,
                git_switch,
                git_switch_multi,
                git_switch_submodule,
                git_log,
                git_log_multi,
                git_log_submodule,
                git_fetch,
                git_fetch_multi,
                git_fetch_submodule,
                git_stash,
                git_stash_multi,
                git_stash_submodule,
                git_stash_pop,
                git_stash_pop_multi,
                git_stash_pop_submodule,
                git_stash_list,
                git_stash_list_multi,
                git_stash_list_submodule,
                git_changes,
                git_changes_multi,
                git_changes_submodule,
                git_show,
                git_show_multi,
                git_show_submodule,
                git_show_remote_multi,
                git_show_remote_submodule,
                git_delete,
                git_delete_multi,
                git_delete_submodule,
                git_rebase,
                git_rebase_multi,
                git_cherry_pick,
                git_cherry_pick_multi,
                git_reset,
                git_reset_multi,
                git_diff_enhanced,
                git_diff_enhanced_multi,
                git_clean,
                git_clean_multi,
                git_tag,
                git_tag_multi,
                git_blame,
                git_blame_multi,
                git_bisect,
                git_bisect_multi,
                run_git,
                run_git_checked,
            )
            from idcu.tools.maven import (
                MavenOperationResult,
                list_available_maven_projects,
                for_each_maven_project,
                get_maven_project_paths,
                get_project_name,
                get_submodule_projects,
                maven_clean,
                maven_clean_multi,
                maven_clean_submodule,
                maven_compile,
                maven_compile_multi,
                maven_compile_submodule,
                maven_test,
                maven_test_multi,
                maven_test_submodule,
                maven_package,
                maven_package_multi,
                maven_package_submodule,
                maven_install,
                maven_install_multi,
                maven_install_submodule,
                maven_deploy,
                maven_deploy_multi,
                maven_deploy_submodule,
                maven_goals,
                maven_goals_multi,
                maven_goals_submodule,
                maven_clean_install,
                maven_clean_install_multi,
                maven_clean_install_submodule,
                maven_clean_package,
                maven_clean_package_multi,
                maven_clean_package_submodule,
                maven_dependency_tree,
                maven_dependency_tree_multi,
                maven_dependency_list,
                maven_dependency_list_multi,
                maven_dependency_analyze,
                maven_dependency_analyze_multi,
                maven_dependency_conflict,
                maven_dependency_conflict_multi,
                maven_effective_pom,
                maven_effective_pom_multi,
                maven_set_profile,
                maven_set_profile_multi,
                maven_list_profiles,
                maven_list_profiles_multi,
                maven_repo_list,
                maven_repo_list_multi,
                maven_clean_local,
                maven_clean_local_multi,
                maven_timeline,
                maven_timeline_multi,
                maven_build_parallel,
                maven_build_parallel_multi,
                run_maven,
                run_maven_checked,
            )
            from idcu.tools import (
                EnvConfig,
                SoftwareVersion,
                determine_env_scope,
                get_default_base_dir,
                get_default_run_dir,
                get_versions_dict,
                setup_environment,
            )
            return {
                "GitOperationResult": GitOperationResult,
                "list_available_projects": list_available_projects,
                "for_each_repo": for_each_repo,
                "get_repo_name": get_repo_name,
                "get_repo_paths": get_repo_paths,
                "get_submodule_paths": get_submodule_paths,
                "git_status": git_status,
                "git_status_multi": git_status_multi,
                "git_status_submodule": git_status_submodule,
                "git_commit": git_commit,
                "git_commit_multi": git_commit_multi,
                "git_commit_submodule": git_commit_submodule,
                "git_push": git_push,
                "git_push_multi": git_push_multi,
                "git_push_submodule": git_push_submodule,
                "git_pull": git_pull,
                "git_pull_multi": git_pull_multi,
                "git_pull_submodule": git_pull_submodule,
                "git_switch": git_switch,
                "git_switch_multi": git_switch_multi,
                "git_switch_submodule": git_switch_submodule,
                "git_log": git_log,
                "git_log_multi": git_log_multi,
                "git_log_submodule": git_log_submodule,
                "git_fetch": git_fetch,
                "git_fetch_multi": git_fetch_multi,
                "git_fetch_submodule": git_fetch_submodule,
                "git_stash": git_stash,
                "git_stash_multi": git_stash_multi,
                "git_stash_submodule": git_stash_submodule,
                "git_stash_pop": git_stash_pop,
                "git_stash_pop_multi": git_stash_pop_multi,
                "git_stash_pop_submodule": git_stash_pop_submodule,
                "git_stash_list": git_stash_list,
                "git_stash_list_multi": git_stash_list_multi,
                "git_stash_list_submodule": git_stash_list_submodule,
                "git_changes": git_changes,
                "git_changes_multi": git_changes_multi,
                "git_changes_submodule": git_changes_submodule,
                "git_show": git_show,
                "git_show_multi": git_show_multi,
                "git_show_submodule": git_show_submodule,
                "git_show_remote_multi": git_show_remote_multi,
                "git_show_remote_submodule": git_show_remote_submodule,
                "git_delete": git_delete,
                "git_delete_multi": git_delete_multi,
                "git_delete_submodule": git_delete_submodule,
                "git_rebase": git_rebase,
                "git_rebase_multi": git_rebase_multi,
                "git_cherry_pick": git_cherry_pick,
                "git_cherry_pick_multi": git_cherry_pick_multi,
                "git_reset": git_reset,
                "git_reset_multi": git_reset_multi,
                "git_diff_enhanced": git_diff_enhanced,
                "git_diff_enhanced_multi": git_diff_enhanced_multi,
                "git_clean": git_clean,
                "git_clean_multi": git_clean_multi,
                "git_tag": git_tag,
                "git_tag_multi": git_tag_multi,
                "git_blame": git_blame,
                "git_blame_multi": git_blame_multi,
                "git_bisect": git_bisect,
                "git_bisect_multi": git_bisect_multi,
                "run_git": run_git,
                "run_git_checked": run_git_checked,
                "MavenOperationResult": MavenOperationResult,
                "list_available_maven_projects": list_available_maven_projects,
                "for_each_maven_project": for_each_maven_project,
                "get_maven_project_paths": get_maven_project_paths,
                "get_project_name": get_project_name,
                "get_submodule_projects": get_submodule_projects,
                "maven_clean": maven_clean,
                "maven_clean_multi": maven_clean_multi,
                "maven_clean_submodule": maven_clean_submodule,
                "maven_compile": maven_compile,
                "maven_compile_multi": maven_compile_multi,
                "maven_compile_submodule": maven_compile_submodule,
                "maven_test": maven_test,
                "maven_test_multi": maven_test_multi,
                "maven_test_submodule": maven_test_submodule,
                "maven_package": maven_package,
                "maven_package_multi": maven_package_multi,
                "maven_package_submodule": maven_package_submodule,
                "maven_install": maven_install,
                "maven_install_multi": maven_install_multi,
                "maven_install_submodule": maven_install_submodule,
                "maven_deploy": maven_deploy,
                "maven_deploy_multi": maven_deploy_multi,
                "maven_deploy_submodule": maven_deploy_submodule,
                "maven_goals": maven_goals,
                "maven_goals_multi": maven_goals_multi,
                "maven_goals_submodule": maven_goals_submodule,
                "maven_clean_install": maven_clean_install,
                "maven_clean_install_multi": maven_clean_install_multi,
                "maven_clean_install_submodule": maven_clean_install_submodule,
                "maven_clean_package": maven_clean_package,
                "maven_clean_package_multi": maven_clean_package_multi,
                "maven_clean_package_submodule": maven_clean_package_submodule,
                "maven_dependency_tree": maven_dependency_tree,
                "maven_dependency_tree_multi": maven_dependency_tree_multi,
                "maven_dependency_list": maven_dependency_list,
                "maven_dependency_list_multi": maven_dependency_list_multi,
                "maven_dependency_analyze": maven_dependency_analyze,
                "maven_dependency_analyze_multi": maven_dependency_analyze_multi,
                "maven_dependency_conflict": maven_dependency_conflict,
                "maven_dependency_conflict_multi": maven_dependency_conflict_multi,
                "maven_effective_pom": maven_effective_pom,
                "maven_effective_pom_multi": maven_effective_pom_multi,
                "maven_set_profile": maven_set_profile,
                "maven_set_profile_multi": maven_set_profile_multi,
                "maven_list_profiles": maven_list_profiles,
                "maven_list_profiles_multi": maven_list_profiles_multi,
                "maven_repo_list": maven_repo_list,
                "maven_repo_list_multi": maven_repo_list_multi,
                "maven_clean_local": maven_clean_local,
                "maven_clean_local_multi": maven_clean_local_multi,
                "maven_timeline": maven_timeline,
                "maven_timeline_multi": maven_timeline_multi,
                "maven_build_parallel": maven_build_parallel,
                "maven_build_parallel_multi": maven_build_parallel_multi,
                "run_maven": run_maven,
                "run_maven_checked": run_maven_checked,
                "EnvConfig": EnvConfig,
                "SoftwareVersion": SoftwareVersion,
                "determine_env_scope": determine_env_scope,
                "get_default_base_dir": get_default_base_dir,
                "get_default_run_dir": get_default_run_dir,
                "get_versions_dict": get_versions_dict,
                "setup_environment": setup_environment,
            }
        return self._lazy_import("devtools", _import)

    def _get_plugins(self):
        def _import():
            from idcu.tools.plugins import get_command, list_commands, list_plugins
            return (get_command, list_commands, list_plugins)
        return self._lazy_import("plugins", _import)

    def _get_config_manager(self):
        return self.app_context.config_manager

    def _setup_subparsers(self):
        subparsers = self.parser.add_subparsers(title="可用命令", dest="command")
        register_all_commands(subparsers, self)
        self.parser.add_argument("--version", action="version", version=f"IDCU CLI {VERSION}")

    def run(self, args=None):
        if args is None:
            args = sys.argv[1:]

        if not args:
            return self._try_interactive_mode()

        parsed_args = self.parser.parse_args(args)

        if hasattr(parsed_args, "func"):
            try:
                return parsed_args.func(parsed_args)
            except Exception as e:
                print_error(f"命令执行失败: {e}")
                return 1
        else:
            self.parser.print_help()
            return 0

    def _try_interactive_mode(self):
        try:
            from idcu.cli.interactive import InteractiveCLI
            cli = InteractiveCLI()
            cli.run()
            return 0
        except ImportError as e:
            print_error("交互式 CLI 依赖未安装")
            from idcu.core import print_info
            print_info("请运行以下命令安装交互式依赖:")
            print_info("  pip install \"idcu-cli[interactive]\"")
            print_info("\n或安装所有可选依赖:")
            print_info("  pip install \"idcu-cli[interactive,quality]\"")
            print_info("\n显示帮助信息:")
            self.parser.print_help()
            return 1


def main(app_context: Optional[AppContext] = None):
    cli = CLI(app_context)
    return cli.run()


def run_cli(app_context: Optional[AppContext] = None):
    sys.exit(main(app_context))


if __name__ == "__main__":
    run_cli()
