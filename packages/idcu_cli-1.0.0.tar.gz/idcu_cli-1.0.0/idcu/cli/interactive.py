
import sys
import shlex
from typing import Optional, Dict, List, Callable

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.shortcuts import clear
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.completion import Completer, Completion, WordCompleter, PathCompleter
    from pathlib import Path
    HAS_PROMPT_TOOLKIT = True
except ImportError:
    HAS_PROMPT_TOOLKIT = False


class IDCUCommandCompleter(Completer):
    def __init__(self):
        self.commands = [
            "git", "maven", "config", "plugin", "env", "release", "build", "ai", 
            "cicd", "team", "web", "quality", "template", "help", "quit", "exit"
        ]
        self.subcommands = {
            "git": ["list", "status", "commit", "push", "pull", "fetch", "switch", 
                    "log", "stash", "stash-pop", "stash-list", "changes", 
                    "sub-status", "sub-switch", "sub-commit", "sub-push", "sub-sync"],
            "maven": ["list", "build", "dep-tree", "dep-list", "dep-analyze", "dep-conflict", 
                      "effective-pom", "profile-list", "profile-set", "repo-list", 
                      "clean-local", "timeline", "parallel", "tier-list", "build-tier", 
                      "build-modules"],
            "config": ["show", "reload"],
            "quality": ["run", "check", "list", "gates", "encoding", "dependency-audit", "tck"],
            "encoding": ["check", "fix"],
            "dependency-audit": ["audit"],
            "tck": ["run"],
            "template": ["list", "create"],
            "web": ["start"],
        }
        
    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        words = text.split()
        
        if len(words) == 0:
            for cmd in self.commands:
                yield Completion(cmd, start_position=-len(text))
        elif len(words) == 1:
            prefix = words[0]
            for cmd in self.commands:
                if cmd.startswith(prefix):
                    yield Completion(cmd, start_position=-len(prefix))
        elif len(words) >= 2:
            cmd = words[0]
            subcmd = words[1] if len(words) > 1 else ""
            
            if cmd in self.subcommands:
                sub_prefix = subcmd
                for sub in self.subcommands[cmd]:
                    if sub.startswith(sub_prefix):
                        yield Completion(sub, start_position=-len(sub_prefix))


class InteractiveCLI:
    def __init__(self):
        self.running = False
        self.console = Console() if HAS_RICH else None
        self.current_menu = "main"
        self.menu_stack = []
        
        if HAS_PROMPT_TOOLKIT:
            try:
                history_path = Path.home() / ".idcu" / "history"
                history_path.parent.mkdir(parents=True, exist_ok=True)
                self.history = FileHistory(str(history_path))
                self.completer = IDCUCommandCompleter()
                self.session = PromptSession(history=self.history, completer=self.completer)
            except Exception:
                self.history = None
                self.completer = None
                self.session = PromptSession()
        else:
            self.history = None
            self.completer = None
            self.session = None
        
        self.command_categories = {
            1: {"name": "Git 管理", "description": "Git 相关操作", "handler": self._handle_git_menu},
            2: {"name": "Maven 构建", "description": "Maven 构建和梯队构建", "handler": self._handle_maven_menu},
            3: {"name": "配置管理", "description": "项目和全局配置", "handler": self._handle_config_menu},
            4: {"name": "插件管理", "description": "插件安装和管理", "handler": self._handle_plugin_menu},
            5: {"name": "环境配置", "description": "开发环境配置", "handler": self._handle_env_menu},
            6: {"name": "发布管理", "description": "版本发布流程", "handler": self._handle_release_menu},
            7: {"name": "跨语言构建", "description": "多语言项目构建", "handler": self._handle_crosslang_menu},
            8: {"name": "AI 增强", "description": "AI 辅助功能", "handler": self._handle_ai_menu},
            9: {"name": "CI/CD 集成", "description": "持续集成和部署", "handler": self._handle_cicd_menu},
            10: {"name": "团队协作", "description": "团队协作工具", "handler": self._handle_team_menu},
            11: {"name": "Web UI", "description": "启动 Web 界面", "handler": self._handle_web_menu},
            12: {"name": "质量检查", "description": "代码质量和安全检查", "handler": self._handle_quality_menu},
            13: {"name": "项目模板", "description": "从模板创建项目", "handler": self._handle_template_menu},
            14: {"name": "直接输入命令", "description": "直接输入 idcu 命令", "handler": self._handle_direct_command},
            0: {"name": "退出", "description": "退出交互式模式", "handler": self._handle_quit},
        }

    def print_welcome(self):
        if HAS_RICH and self.console:
            welcome_text = Text()
            welcome_text.append("欢迎使用 ", style="blue")
            welcome_text.append("IDCU CLI", style="bold cyan")
            welcome_text.append(" 交互式模式", style="blue")
            
            panel = Panel(
                welcome_text,
                title="IDCU CLI",
                subtitle="不羁盟开发工具",
                border_style="cyan"
            )
            self.console.print(panel)
        else:
            print("=" * 50)
            print("欢迎使用 IDCU CLI 交互式模式")
            print("=" * 50)

    def display_main_menu(self):
        if HAS_RICH and self.console:
            self._display_main_menu_rich()
        else:
            self._display_main_menu_plain()

    def _display_main_menu_rich(self):
        table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
        table.add_column("序号", style="bold yellow", width=6)
        table.add_column("功能", style="white")
        table.add_column("描述", style="dim", width=30)
        
        for num in sorted(self.command_categories.keys()):
            category = self.command_categories[num]
            if num == 0:
                table.add_row(str(num), category["name"], category["description"], style="red")
            else:
                table.add_row(str(num), category["name"], category["description"])
        
        panel = Panel(
            table,
            title="主菜单",
            subtitle="请选择功能序号或使用上下键导航",
            border_style="blue"
        )
        self.console.print(panel)

    def _display_main_menu_plain(self):
        print("\n" + "=" * 60)
        print("主菜单".center(60))
        print("=" * 60)
        print(f"{'序号':<6} {'功能':<20} {'描述':<30}")
        print("-" * 60)
        
        for num in sorted(self.command_categories.keys()):
            category = self.command_categories[num]
            if num == 0:
                print(f"\033[91m{num:<6} {category['name']:<20} {category['description']:<30}\033[0m")
            else:
                print(f"{num:<6} {category['name']:<20} {category['description']:<30}")
        print("=" * 60)

    def run(self):
        self.running = True
        self.print_welcome()
        
        try:
            while self.running:
                self.display_main_menu()
                
                try:
                    user_input = self._get_user_input()
                    if user_input:
                        self._handle_menu_selection(user_input)
                        
                except KeyboardInterrupt:
                    print("\n")
                    if HAS_RICH and self.console:
                        self.console.print("[yellow]按 Ctrl+C 再次退出[/yellow]")
                    else:
                        print("按 Ctrl+C 再次退出")
                except EOFError:
                    print("\n")
                    self.running = False
                    
        except KeyboardInterrupt:
            if HAS_RICH and self.console:
                self.console.print("\n[yellow]再见！[/yellow]")
            else:
                print("\n再见！")
            self.running = False

    def _get_user_input(self):
        if HAS_RICH and self.console:
            prompt = Text("[cyan]请选择 [/cyan][bold white](0-14)[/bold white][cyan]: [/cyan]")
            return self.console.input(prompt).strip()
        else:
            return input("请选择 (0-14): ").strip()

    def _handle_menu_selection(self, user_input: str):
        try:
            choice = int(user_input)
            if choice in self.command_categories:
                handler = self.command_categories[choice]["handler"]
                handler()
            else:
                self._show_invalid_choice()
        except ValueError:
            self._handle_input(user_input)

    def _show_invalid_choice(self):
        if HAS_RICH and self.console:
            self.console.print("[red]无效的选择，请输入 0-14 之间的数字[/red]")
        else:
            print("无效的选择，请输入 0-14 之间的数字")

    def _handle_input(self, user_input: str):
        if user_input.lower() in ("quit", "exit", "q"):
            self._handle_quit()
        elif user_input.lower() in ("help", "?"):
            self._print_help()
        elif user_input.lower() in ("menu", "m"):
            pass
        elif user_input.lower() in ("back", ".."):
            self._go_back()
        elif user_input.lower() in ("clear", "cls"):
            self._clear_screen()
        else:
            if HAS_RICH and self.console:
                self.console.print(f"[dim]执行命令: {user_input}[/dim]")
                self.console.print("[yellow]命令执行功能尚未实现[/yellow]")
            else:
                print(f"执行命令: {user_input}")
                print("命令执行功能尚未实现")

    def _go_back(self):
        if self.menu_stack:
            self.current_menu = self.menu_stack.pop()
            if HAS_RICH and self.console:
                self.console.print("[dim]返回上级菜单[/dim]")
            else:
                print("返回上级菜单")
        else:
            if HAS_RICH and self.console:
                self.console.print("[dim]已经在主菜单[/dim]")
            else:
                print("已经在主菜单")

    def _push_menu(self, menu_name: str):
        self.menu_stack.append(self.current_menu)
        self.current_menu = menu_name

    def _print_help(self):
        if HAS_RICH and self.console:
            help_text = Text()
            help_text.append("可用命令:\n", style="bold")
            help_text.append("  help, ?    - 显示此帮助信息\n", style="white")
            help_text.append("  menu, m    - 显示主菜单\n", style="white")
            help_text.append("  back, ..   - 返回上级菜单\n", style="white")
            help_text.append("  quit, exit - 退出交互式模式\n", style="white")
            help_text.append("  clear, cls - 清屏\n", style="white")
            help_text.append("\n[dim]或直接输入菜单序号 (0-14)[/dim]", style="dim")
            self.console.print(help_text)
        else:
            print("可用命令:")
            print("  help, ?    - 显示此帮助信息")
            print("  menu, m    - 显示主菜单")
            print("  back, ..   - 返回上级菜单")
            print("  quit, exit - 退出交互式模式")
            print("  clear, cls - 清屏")
            print("\n或直接输入菜单序号 (0-14)")

    def _handle_git_menu(self):
        self._push_menu("git")
        
        git_options = {
            1: {"name": "列出所有项目", "command": "git list"},
            2: {"name": "查看Git状态", "command": "git status"},
            3: {"name": "提交更改", "command": "git commit"},
            4: {"name": "推送到远程", "command": "git push"},
            5: {"name": "从远程拉取", "command": "git pull"},
            6: {"name": "获取远程更新", "command": "git fetch"},
            7: {"name": "切换分支", "command": "git switch"},
            8: {"name": "子模块详细状态", "command": "git sub-status"},
            9: {"name": "批量切换子模块分支", "command": "git sub-switch"},
            10: {"name": "批量提交子模块", "command": "git sub-commit"},
            11: {"name": "批量推送子模块", "command": "git sub-push"},
            12: {"name": "同步子模块", "command": "git sub-sync"},
            0: {"name": "返回主菜单", "command": None},
        }
        
        while self.running and self.current_menu == "git":
            if HAS_RICH and self.console:
                table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
                table.add_column("序号", style="bold yellow", width=6)
                table.add_column("功能", style="white")
                
                for num in sorted(git_options.keys()):
                    option = git_options[num]
                    if num == 0:
                        table.add_row(str(num), option["name"], style="red")
                    else:
                        table.add_row(str(num), option["name"])
                
                panel = Panel(
                    table,
                    title="Git 管理",
                    subtitle="请选择功能序号",
                    border_style="blue"
                )
                self.console.print(panel)
            else:
                print("\n" + "=" * 60)
                print("Git 管理".center(60))
                print("=" * 60)
                for num in sorted(git_options.keys()):
                    option = git_options[num]
                    if num == 0:
                        print(f"\033[91m{num:<6} {option['name']}\033[0m")
                    else:
                        print(f"{num:<6} {option['name']}")
                print("=" * 60)
            
            try:
                user_input = self._get_git_menu_input()
                if user_input:
                    choice = int(user_input)
                    if choice in git_options:
                        if choice == 0:
                            self._go_back()
                            break
                        else:
                            command = git_options[choice]["command"]
                            if command:
                                self._execute_direct_command(command)
                    else:
                        self._show_invalid_choice()
            except ValueError:
                self._handle_input(user_input)
            except KeyboardInterrupt:
                self._go_back()
                break
    
    def _get_git_menu_input(self):
        if HAS_RICH and self.console:
            prompt = Text("[cyan]请选择 [/cyan][bold white](0-12)[/bold white][cyan]: [/cyan]")
            return self.console.input(prompt).strip()
        else:
            return input("请选择 (0-12): ").strip()

    def _handle_maven_menu(self):
        self._push_menu("maven")
        
        maven_options = {
            1: {"name": "列出所有Maven项目", "command": "maven list"},
            2: {"name": "构建Maven项目", "command": "maven build"},
            3: {"name": "列出所有梯队", "command": "maven tier-list"},
            4: {"name": "按梯队构建", "command": "maven build-tier"},
            5: {"name": "按模块列表构建", "command": "maven build-modules"},
            6: {"name": "并行构建", "command": "maven parallel"},
            7: {"name": "依赖树", "command": "maven dep-tree"},
            0: {"name": "返回主菜单", "command": None},
        }
        
        while self.running and self.current_menu == "maven":
            if HAS_RICH and self.console:
                table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
                table.add_column("序号", style="bold yellow", width=6)
                table.add_column("功能", style="white")
                
                for num in sorted(maven_options.keys()):
                    option = maven_options[num]
                    if num == 0:
                        table.add_row(str(num), option["name"], style="red")
                    else:
                        table.add_row(str(num), option["name"])
                
                panel = Panel(
                    table,
                    title="Maven 构建",
                    subtitle="请选择功能序号",
                    border_style="blue"
                )
                self.console.print(panel)
            else:
                print("\n" + "=" * 60)
                print("Maven 构建".center(60))
                print("=" * 60)
                for num in sorted(maven_options.keys()):
                    option = maven_options[num]
                    if num == 0:
                        print(f"\033[91m{num:<6} {option['name']}\033[0m")
                    else:
                        print(f"{num:<6} {option['name']}")
                print("=" * 60)
            
            try:
                user_input = self._get_maven_menu_input()
                if user_input:
                    choice = int(user_input)
                    if choice in maven_options:
                        if choice == 0:
                            self._go_back()
                            break
                        else:
                            command = maven_options[choice]["command"]
                            if command:
                                self._execute_direct_command(command)
                    else:
                        self._show_invalid_choice()
            except ValueError:
                self._handle_input(user_input)
            except KeyboardInterrupt:
                self._go_back()
                break
    
    def _get_maven_menu_input(self):
        if HAS_RICH and self.console:
            prompt = Text("[cyan]请选择 [/cyan][bold white](0-7)[/bold white][cyan]: [/cyan]")
            return self.console.input(prompt).strip()
        else:
            return input("请选择 (0-7): ").strip()

    def _handle_config_menu(self):
        self._show_menu_message("配置管理")

    def _handle_plugin_menu(self):
        self._show_menu_message("插件管理")

    def _handle_env_menu(self):
        self._show_menu_message("环境配置")

    def _handle_release_menu(self):
        self._show_menu_message("发布管理")

    def _handle_crosslang_menu(self):
        self._show_menu_message("跨语言构建")

    def _handle_ai_menu(self):
        self._show_menu_message("AI 增强")

    def _handle_cicd_menu(self):
        self._show_menu_message("CI/CD 集成")

    def _handle_team_menu(self):
        self._show_menu_message("团队协作")

    def _handle_web_menu(self):
        self._show_menu_message("Web UI")

    def _handle_quality_menu(self):
        self._push_menu("quality")
        
        quality_options = {
            1: {"name": "运行所有质量检查", "command": "quality run"},
            2: {"name": "列出可用质量检查", "command": "quality list"},
            3: {"name": "列出配置的质量门控", "command": "quality gates"},
            4: {"name": "检查编码问题", "command": "quality encoding check"},
            5: {"name": "修复编码问题", "command": "quality encoding fix"},
            6: {"name": "依赖审计", "command": "quality dependency-audit audit"},
            7: {"name": "运行 TCK 测试", "command": "quality tck run"},
            0: {"name": "返回主菜单", "command": None},
        }
        
        while self.running and self.current_menu == "quality":
            if HAS_RICH and self.console:
                table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
                table.add_column("序号", style="bold yellow", width=6)
                table.add_column("功能", style="white")
                
                for num in sorted(quality_options.keys()):
                    option = quality_options[num]
                    if num == 0:
                        table.add_row(str(num), option["name"], style="red")
                    else:
                        table.add_row(str(num), option["name"])
                
                panel = Panel(
                    table,
                    title="质量检查",
                    subtitle="请选择功能序号",
                    border_style="blue"
                )
                self.console.print(panel)
            else:
                print("\n" + "=" * 60)
                print("质量检查".center(60))
                print("=" * 60)
                for num in sorted(quality_options.keys()):
                    option = quality_options[num]
                    if num == 0:
                        print("\033[91m%d\t%s\033[0m" % (num, option["name"]))
                    else:
                        print("%d\t%s" % (num, option["name"]))
                print("=" * 60)
            
            try:
                user_input = self._get_quality_menu_input()
                if user_input:
                    choice = int(user_input)
                    if choice in quality_options:
                        if choice == 0:
                            self._go_back()
                            break
                        else:
                            command = quality_options[choice]["command"]
                            if command:
                                self._execute_direct_command(command)
                    else:
                        self._show_invalid_choice()
            except ValueError:
                self._handle_input(user_input)
            except KeyboardInterrupt:
                self._go_back()
                break
    
    def _get_quality_menu_input(self):
        if HAS_RICH and self.console:
            prompt = Text("[cyan]请选择 [/cyan][bold white](0-7)[/bold white][cyan]: [/cyan]")
            return self.console.input(prompt).strip()
        else:
            return input("请选择 (0-7): ").strip()
    
    def _handle_template_menu(self):
        self._push_menu("template")
        
        template_options = {
            1: {"name": "列出可用模板", "command": "template list"},
            2: {"name": "从模板创建项目", "command": "template create"},
            0: {"name": "返回主菜单", "command": None},
        }
        
        while self.running and self.current_menu == "template":
            if HAS_RICH and self.console:
                table = Table(show_header=False, box=box.ROUNDED, border_style="cyan")
                table.add_column("序号", style="bold yellow", width=6)
                table.add_column("功能", style="white")
                
                for num in sorted(template_options.keys()):
                    option = template_options[num]
                    if num == 0:
                        table.add_row(str(num), option["name"], style="red")
                    else:
                        table.add_row(str(num), option["name"])
                
                panel = Panel(
                    table,
                    title="项目模板",
                    subtitle="请选择功能序号",
                    border_style="blue"
                )
                self.console.print(panel)
            else:
                print("\n" + "=" * 60)
                print("项目模板".center(60))
                print("=" * 60)
                for num in sorted(template_options.keys()):
                    option = template_options[num]
                    if num == 0:
                        print("\033[91m%d\t%s\033[0m" % (num, option["name"]))
                    else:
                        print("%d\t%s" % (num, option["name"]))
                print("=" * 60)
            
            try:
                user_input = self._get_template_menu_input()
                if user_input:
                    choice = int(user_input)
                    if choice in template_options:
                        if choice == 0:
                            self._go_back()
                            break
                        else:
                            command = template_options[choice]["command"]
                            if command:
                                self._execute_direct_command(command)
                    else:
                        self._show_invalid_choice()
            except ValueError:
                self._handle_input(user_input)
            except KeyboardInterrupt:
                self._go_back()
                break
    
    def _get_template_menu_input(self):
        if HAS_RICH and self.console:
            prompt = Text("[cyan]请选择 [/cyan][bold white](0-2)[/bold white][cyan]: [/cyan]")
            return self.console.input(prompt).strip()
        else:
            return input("请选择 (0-2): ").strip()

    def _handle_direct_command(self):
        if HAS_RICH and self.console:
            self.console.print("\n[bold cyan]直接命令模式[/bold cyan]")
            self.console.print("[dim]输入 idcu 命令（可省略 'idcu' 前缀）[/dim]")
            self.console.print("[dim]输入 'back' 或 '..' 返回主菜单[/dim]\n")
        else:
            print("\n直接命令模式")
            print("输入 idcu 命令（可省略 'idcu' 前缀）")
            print("输入 'back' 或 '..' 返回主菜单\n")
        
        while self.running:
            try:
                user_input = self._get_direct_command_input()
                if not user_input:
                    continue
                
                user_input = user_input.strip()
                
                if user_input.lower() in ("back", "..", "menu", "m"):
                    break
                elif user_input.lower() in ("quit", "exit", "q"):
                    self._handle_quit()
                    break
                elif user_input.lower() in ("help", "?"):
                    self._print_direct_command_help()
                    continue
                elif user_input.lower() in ("clear", "cls"):
                    self._clear_screen()
                    continue
                
                self._execute_direct_command(user_input)
                
            except KeyboardInterrupt:
                print("\n")
                if HAS_RICH and self.console:
                    self.console.print("[yellow]返回主菜单...[/yellow]")
                else:
                    print("返回主菜单...")
                break
            except EOFError:
                print("\n")
                break

    def _get_direct_command_input(self):
        if HAS_PROMPT_TOOLKIT and self.session:
            try:
                if HAS_RICH and self.console:
                    prompt = HTML('<ansicyan>idcu</ansicyan> > ')
                else:
                    prompt = 'idcu > '
                return self.session.prompt(prompt)
            except Exception:
                pass
        
        if HAS_RICH and self.console:
            prompt_text = Text("[cyan]idcu[/cyan] > ")
            return self.console.input(prompt_text)
        else:
            return input("idcu > ")

    def _parse_command(self, user_input: str) -> List[str]:
        if user_input.lower().startswith("idcu "):
            user_input = user_input[5:]
        
        try:
            return shlex.split(user_input)
        except Exception:
            return user_input.split()

    def _execute_direct_command(self, user_input: str):
        args = self._parse_command(user_input)
        
        if not args:
            return
        
        try:
            from idcu.cli.main import CLI
            cli = CLI()
            cli.run(args)
        except Exception as e:
            if HAS_RICH and self.console:
                self.console.print(f"[red]命令执行失败: {e}[/red]")
            else:
                print(f"命令执行失败: {e}")

    def _print_direct_command_help(self):
        if HAS_RICH and self.console:
            help_text = Text()
            help_text.append("直接命令模式帮助:\n", style="bold")
            help_text.append("  输入任意 idcu 命令（可省略 'idcu' 前缀）\n", style="white")
            help_text.append("  例如: 'git status' 或 'idcu git status'\n", style="dim")
            help_text.append("\n特殊命令:\n", style="bold")
            help_text.append("  help, ?    - 显示此帮助信息\n", style="white")
            help_text.append("  back, ..   - 返回主菜单\n", style="white")
            help_text.append("  menu, m    - 返回主菜单\n", style="white")
            help_text.append("  quit, exit - 退出交互式模式\n", style="white")
            help_text.append("  clear, cls - 清屏\n", style="white")
            self.console.print(help_text)
        else:
            print("直接命令模式帮助:")
            print("  输入任意 idcu 命令（可省略 'idcu' 前缀）")
            print("  例如: 'git status' 或 'idcu git status'")
            print("\n特殊命令:")
            print("  help, ?    - 显示此帮助信息")
            print("  back, ..   - 返回主菜单")
            print("  menu, m    - 返回主菜单")
            print("  quit, exit - 退出交互式模式")
            print("  clear, cls - 清屏")

    def _clear_screen(self):
        if HAS_PROMPT_TOOLKIT:
            try:
                clear()
            except Exception:
                pass
        
        if HAS_RICH and self.console:
            self.console.clear()
        else:
            import os
            os.system('cls' if os.name == 'nt' else 'clear')

    def _show_menu_message(self, menu_name: str):
        if HAS_RICH and self.console:
            self.console.print(f"[yellow]{menu_name} 菜单功能即将推出...[/yellow]")
        else:
            print(f"{menu_name} 菜单功能即将推出...")

    def _handle_quit(self):
        self.running = False
        if HAS_RICH and self.console:
            self.console.print("[yellow]再见！[/yellow]")
        else:
            print("再见！")

