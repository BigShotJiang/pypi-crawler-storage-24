from pathlib import Path
from typing import Optional

from idcu.core import print_error, print_info, print_success, print_warning
from idcu.system.project_config import ProjectConfig, Tier, get_project_config_manager


class ProjectManager:
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_manager = get_project_config_manager(config_dir)

    def exists(self) -> bool:
        return self.config_manager.exists()

    def is_valid(self) -> bool:
        return self.config_manager.is_valid()

    def get_config(self) -> Optional[ProjectConfig]:
        return self.config_manager.get_config()

    def create_default_config(
        self,
        project_type: str = "est-spi",
        version: str = "2.0.0",
        jdk: str = "1.8",
    ) -> bool:
        config = ProjectConfig(
            type=project_type,
            version=version,
            jdk=jdk,
            tiers=[],
            quality_gates=["encoding-check", "dependency-audit", "unit-tests"],
        )
        return self.config_manager.save_config(config)

    def update_config(
        self,
        project_type: Optional[str] = None,
        version: Optional[str] = None,
        jdk: Optional[str] = None,
    ) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        if project_type is not None:
            config.type = project_type
        if version is not None:
            config.version = version
        if jdk is not None:
            config.jdk = jdk

        return self.config_manager.save_config(config)

    def add_tier(self, name: str, order: int, modules: Optional[list] = None) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        if config.get_tier_by_name(name) is not None:
            print_error(f"Tier with name '{name}' already exists.")
            return False

        if config.get_tier_by_order(order) is not None:
            print_error(f"Tier with order '{order}' already exists.")
            return False

        tier = Tier(name=name, order=order, modules=modules or [])
        config.tiers.append(tier)
        config.tiers.sort(key=lambda item: item.order)
        return self.config_manager.save_config(config)

    def remove_tier(self, name: str) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        tier = config.get_tier_by_name(name)
        if tier is None:
            print_error(f"Tier with name '{name}' not found.")
            return False

        config.tiers.remove(tier)
        return self.config_manager.save_config(config)

    def add_modules_to_tier(self, tier_name: str, modules: list) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        tier = config.get_tier_by_name(tier_name)
        if tier is None:
            print_error(f"Tier with name '{tier_name}' not found.")
            return False

        for module in modules:
            if module not in tier.modules:
                tier.modules.append(module)

        return self.config_manager.save_config(config)

    def remove_modules_from_tier(self, tier_name: str, modules: list) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        tier = config.get_tier_by_name(tier_name)
        if tier is None:
            print_error(f"Tier with name '{tier_name}' not found.")
            return False

        for module in modules:
            if module in tier.modules:
                tier.modules.remove(module)

        return self.config_manager.save_config(config)

    def add_quality_gate(self, gate_name: str) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        if gate_name in config.quality_gates:
            print_warning(f"Quality gate '{gate_name}' already exists.")
            return True

        config.quality_gates.append(gate_name)
        return self.config_manager.save_config(config)

    def remove_quality_gate(self, gate_name: str) -> bool:
        config = self.get_config()
        if config is None:
            print_error("No project config found. Please create one first.")
            return False

        if gate_name not in config.quality_gates:
            print_warning(f"Quality gate '{gate_name}' not found.")
            return True

        config.quality_gates.remove(gate_name)
        return self.config_manager.save_config(config)

    def show_config(self) -> None:
        config = self.get_config()
        if config is None:
            print_info("No project config found.")
            return

        print_success("Project Configuration:")
        print_info(f"  Type: {config.type}")
        print_info(f"  Version: {config.version}")
        print_info(f"  JDK: {config.jdk}")

        if config.tiers:
            print_info("")
            print_info("  Tiers:")
            for tier in config.tiers:
                print_info(f"    - {tier.name} (Order: {tier.order})")
                if tier.modules:
                    print_info(f"      Modules: {', '.join(tier.modules)}")

        if config.quality_gates:
            print_info("")
            print_info("  Quality Gates:")
            for gate in config.quality_gates:
                print_info(f"    - {gate}")
