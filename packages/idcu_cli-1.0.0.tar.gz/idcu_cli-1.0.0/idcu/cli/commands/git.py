from pathlib import Path
from idcu.core import print_header, print_section, print_success, print_error


def register_commands(subparsers, cli_instance):
    git_parser = subparsers.add_parser("git", help="[核心] Git相关操作")
    git_subparsers = git_parser.add_subparsers(title="Git命令", dest="git_command")

    git_list_parser = git_subparsers.add_parser("list", help="列出所有可用项目")
    git_list_parser.set_defaults(func=lambda args: cmd_git_list(args, cli_instance))

    git_status_parser = git_subparsers.add_parser("status", help="查看Git状态")
    git_status_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_status_parser.set_defaults(func=lambda args: cmd_git_status(args, cli_instance))

    git_commit_parser = git_subparsers.add_parser("commit", help="提交更改")
    git_commit_parser.add_argument("-m", "--message", required=True, help="提交信息")
    git_commit_parser.add_argument("-a", "--all", action="store_true", help="提交所有更改")
    git_commit_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_commit_parser.set_defaults(func=lambda args: cmd_git_commit(args, cli_instance))

    git_push_parser = git_subparsers.add_parser("push", help="推送到远程")
    git_push_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_push_parser.set_defaults(func=lambda args: cmd_git_push(args, cli_instance))

    git_pull_parser = git_subparsers.add_parser("pull", help="从远程拉取")
    git_pull_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_pull_parser.set_defaults(func=lambda args: cmd_git_pull(args, cli_instance))

    git_fetch_parser = git_subparsers.add_parser("fetch", help="获取远程更新")
    git_fetch_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_fetch_parser.set_defaults(func=lambda args: cmd_git_fetch(args, cli_instance))

    git_switch_parser = git_subparsers.add_parser("switch", help="切换分支")
    git_switch_parser.add_argument("branch", help="目标分支")
    git_switch_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_switch_parser.set_defaults(func=lambda args: cmd_git_switch(args, cli_instance))

    git_log_parser = git_subparsers.add_parser("log", help="查看提交日志")
    git_log_parser.add_argument("-n", "--number", type=int, default=10, help="显示条数")
    git_log_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_log_parser.set_defaults(func=lambda args: cmd_git_log(args, cli_instance))

    git_stash_parser = git_subparsers.add_parser("stash", help="暂存更改")
    git_stash_parser.add_argument("-m", "--message", help="暂存信息")
    git_stash_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_stash_parser.set_defaults(func=lambda args: cmd_git_stash(args, cli_instance))

    git_stash_pop_parser = git_subparsers.add_parser("stash-pop", help="恢复暂存")
    git_stash_pop_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_stash_pop_parser.set_defaults(func=lambda args: cmd_git_stash_pop(args, cli_instance))

    git_stash_list_parser = git_subparsers.add_parser("stash-list", help="查看暂存列表")
    git_stash_list_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_stash_list_parser.set_defaults(func=lambda args: cmd_git_stash_list(args, cli_instance))

    git_changes_parser = git_subparsers.add_parser("changes", help="查看更改")
    git_changes_parser.add_argument("-p", "--projects", nargs="*", help="指定项目")
    git_changes_parser.set_defaults(func=lambda args: cmd_git_changes(args, cli_instance))

    git_sub_status_parser = git_subparsers.add_parser("sub-status", help="子模块详细状态")
    git_sub_status_parser.set_defaults(func=lambda args: cmd_git_sub_status(args, cli_instance))

    git_sub_switch_parser = git_subparsers.add_parser("sub-switch", help="批量切换子模块分支")
    git_sub_switch_parser.add_argument("branch", help="目标分支")
    git_sub_switch_parser.add_argument("--no-confirm", action="store_false", dest="confirm", help="跳过确认")
    git_sub_switch_parser.set_defaults(func=lambda args: cmd_git_sub_switch(args, cli_instance))

    git_sub_commit_parser = git_subparsers.add_parser("sub-commit", help="批量提交子模块")
    git_sub_commit_parser.add_argument("-m", "--message", required=True, help="提交信息")
    git_sub_commit_parser.add_argument("-a", "--all", action="store_true", help="添加所有更改")
    git_sub_commit_parser.add_argument("-p", "--projects", nargs="*", help="指定子模块")
    git_sub_commit_parser.set_defaults(func=lambda args: cmd_git_sub_commit(args, cli_instance))

    git_sub_push_parser = git_subparsers.add_parser("sub-push", help="批量推送子模块")
    git_sub_push_parser.add_argument("-p", "--projects", nargs="*", help="指定子模块")
    git_sub_push_parser.add_argument("-r", "--remote", default="origin", help="远程仓库")
    git_sub_push_parser.add_argument("-b", "--branch", help="目标分支")
    git_sub_push_parser.set_defaults(func=lambda args: cmd_git_sub_push(args, cli_instance))

    git_sub_sync_parser = git_subparsers.add_parser("sub-sync", help="同步子模块")
    git_sub_sync_parser.add_argument("--no-init", action="store_false", dest="init", help="不初始化新子模块")
    git_sub_sync_parser.add_argument("--no-pull", action="store_false", dest="pull", help="不拉取更新")
    git_sub_sync_parser.set_defaults(func=lambda args: cmd_git_sub_sync(args, cli_instance))


def cmd_git_list(args, cli):
    devtools = cli._get_devtools()
    print_header("Git项目列表")
    projects = devtools["list_available_projects"](Path.cwd())
    for project in projects:
        print(f"  - {project}")
    print_success(f"共找到 {len(projects)} 个项目")
    return 0


def _git_operation_wrapper(operation_name, operation_func, args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header(f"Git {operation_name}")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = operation_func(repo_path)
        if hasattr(result, 'success'):
            if result.success:
                print_success(f"{repo_name}: {result.message}")
            else:
                print_error(f"{repo_name}: {result.message}")
            return 0 if result.success else 1
        return result

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_status(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("status", devtools["git_status"], args, cli)


def cmd_git_commit(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("Git commit")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["git_commit"](repo_path, message=args.message, all=args.all)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_push(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("push", devtools["git_push"], args, cli)


def cmd_git_pull(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("pull", devtools["git_pull"], args, cli)


def cmd_git_fetch(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("fetch", devtools["git_fetch"], args, cli)


def cmd_git_switch(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header(f"Git switch to {args.branch}")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["git_switch"](repo_path, branch=args.branch)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_log(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header(f"Git log (最近 {args.number} 条)")

    def op(repo_path, repo_name):
        print_section(f"项目: {repo_name}")
        result = devtools["git_log"](repo_path, number=args.number)
        if result.success and result.details and 'log' in result.details:
            print(result.details['log'])
        elif not result.success:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_stash(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("Git stash")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["git_stash"](repo_path, message=args.message)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_stash_pop(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("stash-pop", devtools["git_stash_pop"], args, cli)


def cmd_git_stash_list(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("Git stash list")

    def op(repo_path, repo_name):
        print_section(f"项目: {repo_name}")
        result = devtools["git_stash_list"](repo_path)
        if result.success and result.details and 'list' in result.details:
            print(result.details['list'])
        elif not result.success:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_repo"](repo_root, op, args.projects)


def cmd_git_changes(args, cli):
    devtools = cli._get_devtools()
    return _git_operation_wrapper("changes", devtools["git_changes"], args, cli)


def cmd_git_sub_status(args, cli):
    from idcu.tools.git.submodule_enhanced import EnhancedSubmoduleManager
    manager = EnhancedSubmoduleManager()
    success = manager.print_detailed_status()
    return 0 if success else 1


def cmd_git_sub_switch(args, cli):
    from idcu.tools.git.submodule_enhanced import EnhancedSubmoduleManager
    manager = EnhancedSubmoduleManager()
    success = manager.switch_branch_all(args.branch, confirm=args.confirm)
    return 0 if success else 1


def cmd_git_sub_commit(args, cli):
    from idcu.tools.git.submodule_enhanced import EnhancedSubmoduleManager
    manager = EnhancedSubmoduleManager()
    success = manager.commit_selected(args.message, args.projects, args.all)
    return 0 if success else 1


def cmd_git_sub_push(args, cli):
    from idcu.tools.git.submodule_enhanced import EnhancedSubmoduleManager
    manager = EnhancedSubmoduleManager()
    success = manager.push_selected(args.projects, args.remote, args.branch)
    return 0 if success else 1


def cmd_git_sub_sync(args, cli):
    from idcu.tools.git.submodule_enhanced import EnhancedSubmoduleManager
    manager = EnhancedSubmoduleManager()
    success = manager.sync_submodules(pull=args.pull, init=args.init)
    return 0 if success else 1
