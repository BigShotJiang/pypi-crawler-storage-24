from .git import register_commands as register_git_commands
from .maven import register_commands as register_maven_commands
from .quality import register_commands as register_quality_commands
from .team import register_commands as register_team_commands
from .common import register_commands as register_common_commands


def register_all_commands(subparsers, cli_instance):
    register_git_commands(subparsers, cli_instance)
    register_maven_commands(subparsers, cli_instance)
    register_quality_commands(subparsers, cli_instance)
    register_team_commands(subparsers, cli_instance)
    register_common_commands(subparsers, cli_instance)
