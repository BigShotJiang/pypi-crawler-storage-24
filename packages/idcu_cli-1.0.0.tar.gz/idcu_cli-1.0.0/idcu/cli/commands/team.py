from idcu.core import print_header, print_success, print_error, print_json, print_info


def register_commands(subparsers, cli_instance):
    team_parser = subparsers.add_parser("team", help="[增强] 团队协作功能")
    team_subparsers = team_parser.add_subparsers(title="团队命令", dest="team_command")

    team_config_parser = team_subparsers.add_parser("config", help="团队配置管理")
    team_config_subparsers = team_config_parser.add_subparsers(title="配置命令", dest="team_config_command")

    team_config_show_parser = team_config_subparsers.add_parser("show", help="显示团队配置")
    team_config_show_parser.add_argument("-f", "--file", help="配置文件路径")
    team_config_show_parser.set_defaults(func=lambda args: cmd_team_config_show(args, cli_instance))

    team_config_init_parser = team_config_subparsers.add_parser("init", help="初始化团队配置")
    team_config_init_parser.add_argument("-n", "--name", required=True, help="团队名称")
    team_config_init_parser.add_argument("-d", "--description", help="团队描述")
    team_config_init_parser.add_argument("-f", "--file", help="配置文件路径")
    team_config_init_parser.set_defaults(func=lambda args: cmd_team_config_init(args, cli_instance))

    team_config_export_parser = team_config_subparsers.add_parser("export", help="导出团队配置")
    team_config_export_parser.add_argument("-f", "--file", help="配置文件路径")
    team_config_export_parser.add_argument("-o", "--output", required=True, help="输出文件路径")
    team_config_export_parser.set_defaults(func=lambda args: cmd_team_config_export(args, cli_instance))

    team_perm_parser = team_subparsers.add_parser("perm", help="权限管理")
    team_perm_subparsers = team_perm_parser.add_subparsers(title="权限命令", dest="team_perm_command")

    team_perm_add_parser = team_perm_subparsers.add_parser("add-role", help="添加角色")
    team_perm_add_parser.add_argument("role", help="角色名称")
    team_perm_add_parser.add_argument("permissions", nargs="+", help="权限列表")
    team_perm_add_parser.set_defaults(func=lambda args: cmd_team_perm_add_role(args, cli_instance))

    team_perm_assign_parser = team_perm_subparsers.add_parser("assign", help="分配角色")
    team_perm_assign_parser.add_argument("user", help="用户名")
    team_perm_assign_parser.add_argument("role", help="角色名称")
    team_perm_assign_parser.set_defaults(func=lambda args: cmd_team_perm_assign(args, cli_instance))

    team_perm_check_parser = team_perm_subparsers.add_parser("check", help="检查权限")
    team_perm_check_parser.add_argument("user", help="用户名")
    team_perm_check_parser.add_argument("permission", help="权限名称")
    team_perm_check_parser.set_defaults(func=lambda args: cmd_team_perm_check(args, cli_instance))


def _get_team(cli):
    def _import():
        from idcu.tools.team import config, permissions
        return (config, permissions)
    return cli._lazy_import("team", _import)


def cmd_team_config_show(args, cli):
    config, _ = _get_team(cli)
    print_header("显示团队配置")
    try:
        team_config = config.TeamConfig(config_path=args.file)
        print_json(team_config.config)
        return 0
    except Exception as e:
        print_error(f"显示团队配置失败: {e}")
        return 1


def cmd_team_config_init(args, cli):
    config, _ = _get_team(cli)
    print_header("初始化团队配置")
    try:
        team_config = config.TeamConfig(config_path=args.file)
        team_config.set_team_name(args.name)
        if args.description:
            team_config.set_shared_config("description", args.description)
        print_success("团队配置已初始化")
        return 0
    except Exception as e:
        print_error(f"初始化团队配置失败: {e}")
        return 1


def cmd_team_config_export(args, cli):
    config, _ = _get_team(cli)
    print_header("导出团队配置")
    try:
        team_config = config.TeamConfig(config_path=args.file)
        team_config.export_config(args.output)
        print_success(f"团队配置已导出到: {args.output}")
        return 0
    except Exception as e:
        print_error(f"导出团队配置失败: {e}")
        return 1


def cmd_team_perm_add_role(args, cli):
    config, permissions = _get_team(cli)
    print_header("添加角色")
    try:
        team_config = config.TeamConfig(config_path=args.file if hasattr(args, "file") else None)
        perm_manager = permissions.PermissionManager(team_config)
        perm_manager.add_role(args.role, args.permissions)
        print_success(f"角色 '{args.role}' 已添加，权限: {args.permissions}")
        return 0
    except Exception as e:
        print_error(f"添加角色失败: {e}")
        return 1


def cmd_team_perm_assign(args, cli):
    config, permissions = _get_team(cli)
    print_header("分配角色")
    try:
        team_config = config.TeamConfig(config_path=args.file if hasattr(args, "file") else None)
        perm_manager = permissions.PermissionManager(team_config)
        perm_manager.set_member_role(args.user, args.role)
        print_success(f"用户 '{args.user}' 已分配角色 '{args.role}'")
        return 0
    except Exception as e:
        print_error(f"分配角色失败: {e}")
        return 1


def cmd_team_perm_check(args, cli):
    config, permissions = _get_team(cli)
    print_header("检查权限")
    try:
        team_config = config.TeamConfig(config_path=args.file if hasattr(args, "file") else None)
        perm_manager = permissions.PermissionManager(team_config)
        has_perm = perm_manager.has_permission(args.user, args.permission)
        if has_perm:
            print_success(f"用户 '{args.user}' 拥有权限 '{args.permission}'")
        else:
            print_error(f"用户 '{args.user}' 没有权限 '{args.permission}'")
        return 0
    except Exception as e:
        print_error(f"检查权限失败: {e}")
        return 1
