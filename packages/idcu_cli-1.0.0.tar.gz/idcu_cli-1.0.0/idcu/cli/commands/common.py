from pathlib import Path
import json
from idcu.core import print_header, print_success, print_error, print_info, print_json, print_table


def register_commands(subparsers, cli_instance):
    register_completions_commands(subparsers, cli_instance)
    register_config_commands(subparsers, cli_instance)
    register_alias_commands(subparsers, cli_instance)
    register_plugin_commands(subparsers, cli_instance)
    register_env_commands(subparsers, cli_instance)
    register_release_commands(subparsers, cli_instance)
    register_build_commands(subparsers, cli_instance)
    register_ai_commands(subparsers, cli_instance)
    register_cicd_commands(subparsers, cli_instance)
    register_web_commands(subparsers, cli_instance)
    register_template_commands(subparsers, cli_instance)


def register_completions_commands(subparsers, cli_instance):
    completions_parser = subparsers.add_parser("completions", help="[增强] 生成命令补全脚本")
    completions_subparsers = completions_parser.add_subparsers(title="补全命令", dest="completions_command")

    completions_bash_parser = completions_subparsers.add_parser("bash", help="生成 Bash 补全脚本")
    completions_bash_parser.add_argument("-o", "--output", help="输出文件路径")
    completions_bash_parser.set_defaults(func=lambda args: cmd_completions_bash(args, cli_instance))

    completions_zsh_parser = completions_subparsers.add_parser("zsh", help="生成 Zsh 补全脚本")
    completions_zsh_parser.add_argument("-o", "--output", help="输出文件路径")
    completions_zsh_parser.set_defaults(func=lambda args: cmd_completions_zsh(args, cli_instance))

    completions_powershell_parser = completions_subparsers.add_parser("powershell", help="生成 PowerShell 补全脚本")
    completions_powershell_parser.add_argument("-o", "--output", help="输出文件路径")
    completions_powershell_parser.set_defaults(func=lambda args: cmd_completions_powershell(args, cli_instance))


def register_config_commands(subparsers, cli_instance):
    config_parser = subparsers.add_parser("config", help="[核心] 配置管理")
    config_subparsers = config_parser.add_subparsers(title="配置命令", dest="config_command")

    config_show_parser = config_subparsers.add_parser("show", help="显示配置")
    config_show_parser.set_defaults(func=lambda args: cmd_config_show(args, cli_instance))

    config_reload_parser = config_subparsers.add_parser("reload", help="重新加载配置")
    config_reload_parser.set_defaults(func=lambda args: cmd_config_reload(args, cli_instance))


def register_alias_commands(subparsers, cli_instance):
    alias_parser = subparsers.add_parser("alias", help="[核心] 命令别名管理")
    alias_subparsers = alias_parser.add_subparsers(title="别名命令", dest="alias_command")

    alias_list_parser = alias_subparsers.add_parser("list", help="列出所有别名")
    alias_list_parser.set_defaults(func=lambda args: cmd_alias_list(args, cli_instance))

    alias_set_parser = alias_subparsers.add_parser("set", help="设置别名")
    alias_set_parser.add_argument("name", help="别名名称")
    alias_set_parser.add_argument("command", help="命令内容")
    alias_set_parser.set_defaults(func=lambda args: cmd_alias_set(args, cli_instance))

    alias_delete_parser = alias_subparsers.add_parser("delete", help="删除别名")
    alias_delete_parser.add_argument("name", help="别名名称")
    alias_delete_parser.set_defaults(func=lambda args: cmd_alias_delete(args, cli_instance))


def register_plugin_commands(subparsers, cli_instance):
    plugin_parser = subparsers.add_parser("plugin", help="[核心] 插件管理")
    plugin_subparsers = plugin_parser.add_subparsers(title="插件命令", dest="plugin_command")

    plugin_list_parser = plugin_subparsers.add_parser("list", help="列出所有插件")
    plugin_list_parser.set_defaults(func=lambda args: cmd_plugin_list(args, cli_instance))

    plugin_cmd_parser = subparsers.add_parser("cmd", help="[核心] 执行插件命令")
    plugin_cmd_parser.add_argument("cmd_name", help="命令名称")
    plugin_cmd_parser.add_argument("args", nargs="*", help="命令参数")
    plugin_cmd_parser.set_defaults(func=lambda args: cmd_plugin_cmd(args, cli_instance))


def register_env_commands(subparsers, cli_instance):
    env_parser = subparsers.add_parser("env", help="[增强] 环境配置相关操作")
    env_subparsers = env_parser.add_subparsers(title="环境配置命令", dest="env_command")

    env_setup_parser = env_subparsers.add_parser("setup", help="配置开发环境变量")
    env_setup_parser.add_argument("--base-dir", type=str, default=None, help="基础目录 (默认: 当前工作目录的父目录)")
    env_setup_parser.add_argument("--run-dir", type=str, default=None, help="运行目录 (默认: <base-dir>/run)")
    env_setup_parser.add_argument("--user", action="store_true", help="强制配置用户环境变量（即使是管理员）")
    env_setup_parser.add_argument("--system", action="store_true", help="强制配置系统环境变量（需要管理员权限）")
    env_setup_parser.set_defaults(func=lambda args: cmd_env_setup(args, cli_instance))

    env_versions_parser = env_subparsers.add_parser("versions", help="显示环境软件版本信息")
    env_versions_parser.set_defaults(func=lambda args: cmd_env_versions(args, cli_instance))


def register_release_commands(subparsers, cli_instance):
    release_parser = subparsers.add_parser("release", help="[增强] 发布管理相关操作")
    release_subparsers = release_parser.add_subparsers(title="发布命令", dest="release_command")

    release_config_parser = release_subparsers.add_parser("config", help="查看当前配置")
    release_config_parser.set_defaults(func=lambda args: cmd_release_config(args, cli_instance))

    release_branch_parser = release_subparsers.add_parser("create-branch", help="创建发布分支")
    release_branch_parser.add_argument("version", help="版本号，例如 1.0.0")
    release_branch_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_branch_parser.add_argument("--branch-pattern", help="分支命名模式（默认为 release/{version}）")
    release_branch_parser.set_defaults(func=lambda args: cmd_release_create_branch(args, cli_instance))

    release_version_parser = release_subparsers.add_parser("update-version", help="更新版本号")
    release_version_parser.add_argument("old_version", help="旧版本号，例如 1.0.0-SNAPSHOT")
    release_version_parser.add_argument("new_version", help="新版本号，例如 1.0.0")
    release_version_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_version_parser.add_argument("--build-tool", default="maven", choices=["maven"], help="构建工具（默认为 maven）")
    release_version_parser.set_defaults(func=lambda args: cmd_release_update_version(args, cli_instance))

    release_build_parser = release_subparsers.add_parser("build", help="构建项目")
    release_build_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_build_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    release_build_parser.add_argument("--profile", default="release", help="Maven profile（默认为 release）")
    release_build_parser.add_argument("--build-tool", default="maven", choices=["maven"], help="构建工具（默认为 maven）")
    release_build_parser.add_argument("--goals", nargs="*", help="Maven goals（默认为 clean,install）")
    release_build_parser.set_defaults(func=lambda args: cmd_release_build(args, cli_instance))

    release_deploy_parser = release_subparsers.add_parser("deploy", help="部署项目")
    release_deploy_parser.add_argument("target", nargs="?", default="maven-central", help="部署目标（默认为 maven-central）")
    release_deploy_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_deploy_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    release_deploy_parser.add_argument("--build-tool", default="maven", choices=["maven"], help="构建工具（默认为 maven）")
    release_deploy_parser.add_argument("--custom-url", help="自定义仓库URL（使用 target=custom 时）")
    release_deploy_parser.set_defaults(func=lambda args: cmd_release_deploy(args, cli_instance))

    release_tag_parser = release_subparsers.add_parser("tag", help="创建并推送 Git Tag")
    release_tag_parser.add_argument("version", help="版本号，例如 1.0.0")
    release_tag_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_tag_parser.add_argument("--no-push", action="store_false", dest="push", help="仅创建标签不推送")
    release_tag_parser.add_argument("--tag-pattern", help="标签命名模式（默认为 v{version}）")
    release_tag_parser.add_argument("--tag-message", help="标签消息模式（默认为 Release version {version}）")
    release_tag_parser.add_argument("--remote", default="origin", help="远程仓库名称（默认为 origin）")
    release_tag_parser.set_defaults(func=lambda args: cmd_release_tag(args, cli_instance))

    release_full_parser = release_subparsers.add_parser("full", help="执行完整发布流程")
    release_full_parser.add_argument("old_version", help="旧版本号，例如 1.0.0-SNAPSHOT")
    release_full_parser.add_argument("new_version", help="新版本号，例如 1.0.0")
    release_full_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    release_full_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    release_full_parser.add_argument("--deploy-target", default="all", help="部署目标（默认为 all）")
    release_full_parser.add_argument("--build-tool", default="maven", choices=["maven"], help="构建工具（默认为 maven）")
    release_full_parser.add_argument("--branch-pattern", help="分支命名模式")
    release_full_parser.add_argument("--tag-pattern", help="标签命名模式")
    release_full_parser.add_argument("--tag-message", help="标签消息模式")
    release_full_parser.add_argument("--remote", default="origin", help="远程仓库名称")
    release_full_parser.set_defaults(func=lambda args: cmd_release_full(args, cli_instance))


def register_build_commands(subparsers, cli_instance):
    build_parser = subparsers.add_parser("build", help="[增强] 跨语言项目构建")
    build_subparsers = build_parser.add_subparsers(title="构建命令", dest="build_command")

    build_detect_parser = build_subparsers.add_parser("detect", help="检测项目类型")
    build_detect_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    build_detect_parser.set_defaults(func=lambda args: cmd_build_detect(args, cli_instance))

    build_build_parser = build_subparsers.add_parser("build", help="构建项目")
    build_build_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    build_build_parser.set_defaults(func=lambda args: cmd_build_build(args, cli_instance))

    build_test_parser = build_subparsers.add_parser("test", help="运行测试")
    build_test_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    build_test_parser.set_defaults(func=lambda args: cmd_build_test(args, cli_instance))

    build_clean_parser = build_subparsers.add_parser("clean", help="清理项目")
    build_clean_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    build_clean_parser.set_defaults(func=lambda args: cmd_build_clean(args, cli_instance))


def register_ai_commands(subparsers, cli_instance):
    ai_parser = subparsers.add_parser("ai", help="[实验] AI增强功能")
    ai_subparsers = ai_parser.add_subparsers(title="AI命令", dest="ai_command")

    ai_commit_parser = ai_subparsers.add_parser("commit", help="智能生成提交信息")
    ai_commit_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    ai_commit_parser.add_argument("-m", "--model", help="AI模型名称")
    ai_commit_parser.add_argument("--provider", choices=["openai", "ollama"], default="openai", help="AI提供者")
    ai_commit_parser.set_defaults(func=lambda args: cmd_ai_commit(args, cli_instance))

    ai_summarize_parser = ai_subparsers.add_parser("summarize", help="代码变更摘要")
    ai_summarize_parser.add_argument("-p", "--path", help="项目路径（默认为当前目录）")
    ai_summarize_parser.add_argument("-c", "--commit", help="指定提交哈希")
    ai_summarize_parser.add_argument("-m", "--model", help="AI模型名称")
    ai_summarize_parser.add_argument("--provider", choices=["openai", "ollama"], default="openai", help="AI提供者")
    ai_summarize_parser.set_defaults(func=lambda args: cmd_ai_summarize(args, cli_instance))

    ai_chat_parser = ai_subparsers.add_parser("chat", help="AI聊天")
    ai_chat_parser.add_argument("-m", "--model", help="AI模型名称")
    ai_chat_parser.add_argument("--provider", choices=["openai", "ollama"], default="openai", help="AI提供者")
    ai_chat_parser.add_argument("message", help="消息内容")
    ai_chat_parser.set_defaults(func=lambda args: cmd_ai_chat(args, cli_instance))


def register_cicd_commands(subparsers, cli_instance):
    cicd_parser = subparsers.add_parser("cicd", help="[实验] CI/CD集成功能")
    cicd_subparsers = cicd_parser.add_subparsers(title="CI/CD命令", dest="cicd_command")

    cicd_generate_parser = cicd_subparsers.add_parser("generate", help="生成CI/CD配置")
    cicd_generate_subparsers = cicd_generate_parser.add_subparsers(title="生成命令", dest="cicd_generate_command")

    cicd_generate_ci_parser = cicd_generate_subparsers.add_parser("ci", help="生成GitHub Actions CI工作流")
    cicd_generate_ci_parser.add_argument("-o", "--output", help="输出文件路径")
    cicd_generate_ci_parser.set_defaults(func=lambda args: cmd_cicd_generate_ci(args, cli_instance))

    cicd_generate_publish_parser = cicd_generate_subparsers.add_parser("publish", help="生成PyPI发布工作流")
    cicd_generate_publish_parser.add_argument("-o", "--output", help="输出文件路径")
    cicd_generate_publish_parser.set_defaults(func=lambda args: cmd_cicd_generate_publish(args, cli_instance))

    cicd_generate_docker_parser = cicd_generate_subparsers.add_parser("docker", help="生成Docker工作流")
    cicd_generate_docker_parser.add_argument("-o", "--output", help="输出文件路径")
    cicd_generate_docker_parser.add_argument("-i", "--image", default="idcu/cli", help="镜像名称")
    cicd_generate_docker_parser.set_defaults(func=lambda args: cmd_cicd_generate_docker(args, cli_instance))

    cicd_generate_all_parser = cicd_generate_subparsers.add_parser("all", help="生成所有工作流")
    cicd_generate_all_parser.add_argument("-o", "--output", help="输出目录")
    cicd_generate_all_parser.set_defaults(func=lambda args: cmd_cicd_generate_all(args, cli_instance))


def register_web_commands(subparsers, cli_instance):
    web_parser = subparsers.add_parser("web", help="[实验] Web UI功能")
    web_subparsers = web_parser.add_subparsers(title="Web命令", dest="web_command")

    web_start_parser = web_subparsers.add_parser("start", help="启动Web服务")
    web_start_parser.add_argument("-H", "--host", default="0.0.0.0", help="监听地址")
    web_start_parser.add_argument("-p", "--port", type=int, default=8000, help="监听端口")
    web_start_parser.add_argument("--reload", action="store_true", help="自动重载")
    web_start_parser.set_defaults(func=lambda args: cmd_web_start(args, cli_instance))


def register_template_commands(subparsers, cli_instance):
    template_parser = subparsers.add_parser("template", help="[实验] 项目模板")
    template_subparsers = template_parser.add_subparsers(title="模板命令", dest="template_command")

    template_list_parser = template_subparsers.add_parser("list", help="列出可用模板")
    template_list_parser.set_defaults(func=lambda args: cmd_template_list(args, cli_instance))

    template_create_parser = template_subparsers.add_parser("create", help="从模板创建项目")
    template_create_parser.add_argument("name", help="模块名称")
    template_create_parser.add_argument("-g", "--group-id", default="com.example", help="Maven group ID（默认 com.example）")
    template_create_parser.add_argument("-a", "--artifact-id", help="Maven artifact ID（默认模块名）")
    template_create_parser.add_argument("-v", "--version", default="1.0.0-SNAPSHOT", help="版本号（默认 1.0.0-SNAPSHOT）")
    template_create_parser.add_argument("-d", "--description", default="EST-SPI Module", help="描述（默认 EST-SPI Module）")
    template_create_parser.add_argument("-t", "--tier", help="添加到指定梯队")
    template_create_parser.add_argument("--add-git", action="store_true", help="添加到 Git 子模块")
    template_create_parser.set_defaults(func=lambda args: cmd_template_create(args, cli_instance))


def cmd_completions_bash(args, cli):
    generate_bash_completion, generate_powershell_completion, generate_zsh_completion = cli._get_completions()
    print_header("生成 Bash 补全脚本")
    output_path = Path(args.output) if args.output else None
    script = generate_bash_completion(output_path)
    if not output_path:
        print(script)
        print_info("\n使用方法：")
        print_info("  1. 将脚本保存到 ~/.idcu-completions.bash")
        print_info("  2. 在 ~/.bashrc 中添加 source ~/.idcu-completions.bash")
        print_info("  3. 重新加载配置 source ~/.bashrc")
    else:
        print_success(f"Bash 补全脚本已保存到: {output_path}")
    return 0


def cmd_completions_zsh(args, cli):
    generate_bash_completion, generate_powershell_completion, generate_zsh_completion = cli._get_completions()
    print_header("生成 Zsh 补全脚本")
    output_path = Path(args.output) if args.output else None
    script = generate_zsh_completion(output_path)
    if not output_path:
        print(script)
        print_info("\n使用方法：")
        print_info("  1. 将脚本保存到 ~/.zsh/_idcu")
        print_info("  2. 确保 ~/.zsh 配置了 fpath")
        print_info("  3. 重新加载配置 source ~/.zshrc")
    else:
        print_success(f"Zsh 补全脚本已保存到: {output_path}")
    return 0


def cmd_completions_powershell(args, cli):
    generate_bash_completion, generate_powershell_completion, generate_zsh_completion = cli._get_completions()
    print_header("生成 PowerShell 补全脚本")
    output_path = Path(args.output) if args.output else None
    script = generate_powershell_completion(output_path)
    if not output_path:
        print(script)
        print_info("\n使用方法：")
        print_info("  1. 将脚本保存到 idcu-completions.ps1")
        print_info("  2. 在 PowerShell 中执行 . idcu-completions.ps1")
        print_info("  3. 重新加载配置 $PROFILE")
    else:
        print_success(f"PowerShell 补全脚本已保存到: {output_path}")
    return 0


def cmd_config_show(args, cli):
    config_manager = cli._get_config_manager()
    print_header("显示配置")
    config = config_manager.get_all_config()
    print_json(config)
    return 0


def cmd_config_reload(args, cli):
    config_manager = cli._get_config_manager()
    print_header("重新加载配置")
    config_manager.force_reload()
    return 0


def cmd_alias_list(args, cli):
    config_manager = cli._get_config_manager()
    print_header("别名列表")
    aliases = config_manager.list_aliases()

    if not aliases:
        print_info("没有设置别名")
        return 0

    headers = ["别名", "命令"]
    rows = [[name, cmd] for name, cmd in aliases.items()]
    print_table(headers, rows)
    return 0


def cmd_alias_set(args, cli):
    config_manager = cli._get_config_manager()
    print_header("设置别名")
    if config_manager.set_alias(args.name, args.command):
        print_success(f"别名 '{args.name}' 已设置为: {args.command}")
        return 0
    else:
        print_error(f"设置别名 '{args.name}' 失败")
        return 1


def cmd_alias_delete(args, cli):
    config_manager = cli._get_config_manager()
    print_header("删除别名")
    if config_manager.delete_alias(args.name):
        print_success(f"别名 '{args.name}' 已删除")
        return 0
    else:
        print_error(f"删除别名 '{args.name}' 失败")
        return 1


def cmd_plugin_list(args, cli):
    get_command, list_commands, list_plugins = cli._get_plugins()
    print_header("已安装插件")
    plugins = list_plugins()
    if not plugins:
        print_info("没有安装插件")
        return 0

    for plugin in plugins:
        status = "启用" if plugin.enabled else "禁用"
        print(f"  - {plugin.name} v{plugin.version} ({status})")
        if plugin.description:
            print(f"    {plugin.description}")
    return 0


def cmd_plugin_cmd(args, cli):
    get_command, list_commands, list_plugins = cli._get_plugins()
    cmd_name = args.cmd_name
    cmd_args = args.args

    cmd = get_command(cmd_name)
    if cmd is None:
        print_error(f"未知命令: {cmd_name}")
        available = list_commands()
        if available:
            print_info("可用命令:")
            for name, desc in available.items():
                print(f"  - {name}: {desc}")
        return 1

    try:
        result = cmd(*cmd_args)
        if result is not None:
            print(result)
        print_success(f"命令执行成功: {cmd_name}")
        return 0
    except Exception as e:
        print_error(f"命令执行失败: {e}")
        return 1


def cmd_env_versions(args, cli):
    devtools = cli._get_devtools()
    print_header("开发环境软件版本")
    versions = devtools["SoftwareVersion"]()
    versions_dict = devtools["get_versions_dict"](versions)
    for name, ver in versions_dict.items():
        print(f"  {name}: {ver}")
    print_success("版本信息显示完成")
    return 0


def cmd_env_setup(args, cli):
    devtools = cli._get_devtools()
    base_dir = Path(args.base_dir) if args.base_dir else devtools["get_default_base_dir"]()
    run_dir = Path(args.run_dir) if args.run_dir else devtools["get_default_run_dir"](base_dir)
    config = devtools["EnvConfig"](base_dir=base_dir, run_dir=run_dir)

    print_header("开发环境配置")
    versions_dict = devtools["get_versions_dict"](config.versions)
    for name, ver in versions_dict.items():
        print_info(f"  {name}: {ver}")

    try:
        user_env, scope_name = devtools["determine_env_scope"](
            force_user=args.user,
            force_system=args.system
        )

        print_info(f"\n配置 {scope_name} 环境变量...")

        success, set_vars, added_paths = devtools["setup_environment"](config, user_env)

        if success:
            print_success("环境变量设置成功")
            print_info("设置的环境变量:")
            for var in set_vars:
                print(f"  - {var}")

            print_info("\n添加到 PATH 的路径:")
            for path in added_paths:
                print(f"  - {path}")

            print_info("\n请重启终端或重新登录以使环境变量生效")
            return 0
        else:
            print_error("环境变量设置失败")
            return 1

    except RuntimeError as e:
        print_error(str(e))
        return 1


def _get_release_plugin_cmd(cmd_name, cli):
    get_command, list_commands, list_plugins = cli._get_plugins()
    cmd = get_command(cmd_name)
    if cmd is None:
        print_error("发布插件未正确加载，请确保 release_plugin.py 已正确注册")
        return None
    return cmd


def _print_result(result):
    if isinstance(result, dict):
        if result.get("success", False):
            print_success("操作成功")
            if "message" in result:
                print_info(f"  消息: {result['message']}")
        else:
            print_error("操作失败")
            if "message" in result:
                print_error(f"  错误: {result['message']}")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(result)


def cmd_release_config(args, cli):
    print_header("发布配置")
    cmd = _get_release_plugin_cmd("release.config", cli)
    if not cmd:
        return 1

    result = cmd()
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_create_branch(args, cli):
    print_header("创建发布分支")
    cmd = _get_release_plugin_cmd("release.create_branch", cli)
    if not cmd:
        return 1

    result = cmd(version=args.version, repo_path=args.path, branch_pattern=args.branch_pattern)
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_update_version(args, cli):
    print_header(f"更新版本号 {args.old_version} -> {args.new_version}")
    cmd = _get_release_plugin_cmd("release.update_version", cli)
    if not cmd:
        return 1

    result = cmd(old_version=args.old_version, new_version=args.new_version,
                repo_path=args.path, build_tool=args.build_tool)
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_build(args, cli):
    print_header("构建项目")
    cmd = _get_release_plugin_cmd("release.build", cli)
    if not cmd:
        return 1

    result = cmd(repo_path=args.path, skip_tests=args.skip_tests,
                profile=args.profile, build_tool=args.build_tool,
                goals=args.goals)
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_deploy(args, cli):
    print_header(f"部署目标: {args.target}")
    cmd = _get_release_plugin_cmd("release.deploy", cli)
    if not cmd:
        return 1

    result = cmd(target=args.target, repo_path=args.path,
                skip_tests=args.skip_tests, build_tool=args.build_tool,
                custom_url=args.custom_url)
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_tag(args, cli):
    print_header("创建并推送标签")
    cmd = _get_release_plugin_cmd("release.tag", cli)
    if not cmd:
        return 1

    result = cmd(version=args.version, repo_path=args.path, push=args.push,
                tag_pattern=args.tag_pattern, tag_message_pattern=args.tag_message,
                remote=args.remote)
    _print_result(result)
    return 0 if result.get("success", False) else 1


def cmd_release_full(args, cli):
    print_header(f"执行完整发布流程: {args.old_version} -> {args.new_version}")
    cmd = _get_release_plugin_cmd("release.full", cli)
    if not cmd:
        return 1

    result = cmd(
        old_version=args.old_version,
        new_version=args.new_version,
        repo_path=args.path,
        skip_tests=args.skip_tests,
        deploy_target=args.deploy_target,
        build_tool=args.build_tool,
        branch_pattern=args.branch_pattern,
        tag_pattern=args.tag_pattern,
        tag_message_pattern=args.tag_message,
        remote=args.remote
    )
    _print_result(result)
    return 0 if result.get("success", False) else 1


def _get_crosslang(cli):
    def _import():
        from idcu.tools.crosslang import ProjectDetector, UnifiedBuilder
        return (ProjectDetector, UnifiedBuilder)
    return cli._lazy_import("crosslang", _import)


def cmd_build_detect(args, cli):
    ProjectDetector, _ = _get_crosslang(cli)
    path = args.path or Path.cwd()
    print_header("检测项目类型")
    detector = ProjectDetector(str(path))
    tools = detector.detect_all_tools()
    if not tools:
        print_info("未检测到任何构建工具")
        return 1
    for tool in tools:
        print_success(f"检测到: {type(tool).__name__}")
    return 0


def cmd_build_build(args, cli):
    _, UnifiedBuilder = _get_crosslang(cli)
    path = args.path or Path.cwd()
    print_header("构建项目")
    builder = UnifiedBuilder(str(path))
    if builder.auto_build():
        print_success("构建成功")
        return 0
    else:
        print_error("构建失败")
        return 1


def cmd_build_test(args, cli):
    _, UnifiedBuilder = _get_crosslang(cli)
    path = args.path or Path.cwd()
    print_header("运行测试")
    builder = UnifiedBuilder(str(path))
    if builder.auto_test():
        print_success("测试成功")
        return 0
    else:
        print_error("测试失败")
        return 1


def cmd_build_clean(args, cli):
    _, UnifiedBuilder = _get_crosslang(cli)
    path = args.path or Path.cwd()
    print_header("清理项目")
    builder = UnifiedBuilder(str(path))
    if builder.auto_clean():
        print_success("清理成功")
        return 0
    else:
        print_error("清理失败")
        return 1


def _get_ai(cli):
    def _import():
        from idcu.tools.ai import CommitGenerator, DiffSummarizer
        from idcu.tools.ai.ollama_provider import OllamaProvider
        from idcu.tools.ai.openai_provider import OpenAIProvider
        return (CommitGenerator, DiffSummarizer, OpenAIProvider, OllamaProvider)
    return cli._lazy_import("ai", _import)


def _get_ai_provider(cli, provider_type, model):
    CommitGenerator, _, OpenAIProvider, OllamaProvider = _get_ai(cli)
    if provider_type == "openai":
        return OpenAIProvider(model=model) if model else OpenAIProvider()
    else:
        return OllamaProvider(model=model) if model else OllamaProvider()


def cmd_ai_commit(args, cli):
    CommitGenerator, _, _, _ = _get_ai(cli)
    print_header("智能生成提交信息")
    try:
        provider = _get_ai_provider(cli, args.provider, args.model)
        generator = CommitGenerator(provider=provider)
        message = generator.generate_commit_message(language="zh")
        print_success("已生成提交信息")
        print(message)
        return 0
    except Exception as e:
        print_error(f"生成提交信息失败: {e}")
        return 1


def cmd_ai_summarize(args, cli):
    _, DiffSummarizer, _, _ = _get_ai(cli)
    print_header("代码变更摘要")
    try:
        provider = _get_ai_provider(cli, args.provider, args.model)
        summarizer = DiffSummarizer(provider=provider)
        summary = summarizer.summarize(commit_hash=args.commit, language="zh")
        print_success("生成摘要:")
        print(summary)
        return 0
    except Exception as e:
        print_error(f"生成摘要失败: {e}")
        return 1


def cmd_ai_chat(args, cli):
    _, _, _, _ = _get_ai(cli)
    print_header("AI聊天")
    try:
        provider = _get_ai_provider(cli, args.provider, args.model)
        response = provider.chat([{"role": "user", "content": args.message}])
        print_success("AI回复:")
        print(response)
        return 0
    except Exception as e:
        print_error(f"聊天失败: {e}")
        return 1


def _get_cicd(cli):
    def _import():
        try:
            from idcu.tools.cicd import github_actions
            return github_actions
        except ImportError:
            return None
    return cli._lazy_import("cicd", _import)


def cmd_cicd_generate_ci(args, cli):
    github_actions = _get_cicd(cli)
    print_header("生成CI工作流")
    try:
        generator = github_actions.GitHubActionsGenerator()
        generator.generate_ci_workflow()
        print_success(f"CI工作流已生成: {generator.workflows_dir / 'ci.yml'}")
        return 0
    except Exception as e:
        print_error(f"生成CI工作流失败: {e}")
        return 1


def cmd_cicd_generate_publish(args, cli):
    github_actions = _get_cicd(cli)
    print_header("生成PyPI发布工作流")
    try:
        generator = github_actions.GitHubActionsGenerator()
        path = generator.generate_publish_workflow()
        print_success(f"PyPI发布工作流已生成: {path}")
        return 0
    except Exception as e:
        print_error(f"生成发布工作流失败: {e}")
        return 1


def cmd_cicd_generate_docker(args, cli):
    github_actions = _get_cicd(cli)
    print_header("生成Docker工作流")
    try:
        generator = github_actions.GitHubActionsGenerator()
        path = generator.generate_docker_workflow(image_name=args.image)
        print_success(f"Docker工作流已生成: {path}")
        return 0
    except Exception as e:
        print_error(f"生成Docker工作流失败: {e}")
        return 1


def cmd_cicd_generate_all(args, cli):
    github_actions = _get_cicd(cli)
    print_header("生成所有工作流")
    try:
        generator = github_actions.GitHubActionsGenerator()
        paths = generator.generate_all_workflows()
        print_success(f"所有工作流已生成: {generator.workflows_dir}")
        for path in paths:
            print_info(f"  - {path}")
        return 0
    except Exception as e:
        print_error(f"生成工作流失败: {e}")
        return 1


def _get_web(cli):
    def _import():
        from idcu.tools.web import run_server
        return run_server
    return cli._lazy_import("web", _import)


def cmd_web_start(args, cli):
    run_server = _get_web(cli)
    print_header("启动Web服务")
    try:
        print_info(f"Web服务监听 http://{args.host}:{args.port}")
        if run_server:
            run_server(host=args.host, port=args.port, reload=args.reload)
        return 0
    except Exception as e:
        print_error(f"启动Web服务失败: {e}")
        return 1


def cmd_template_list(args, cli):
    from idcu.tools.project_template import ProjectTemplateManager
    manager = ProjectTemplateManager()
    manager.list_templates()
    return 0


def cmd_template_create(args, cli):
    from idcu.tools.project_template import ProjectTemplateManager
    manager = ProjectTemplateManager()
    success = manager.create_est_spi_module(
        name=args.name,
        group_id=args.group_id,
        artifact_id=args.artifact_id,
        version=args.version,
        description=args.description,
        tier=args.tier,
        add_to_git=args.add_git
    )
    return 0 if success else 1
