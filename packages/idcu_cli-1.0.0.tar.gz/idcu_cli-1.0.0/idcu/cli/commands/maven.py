from pathlib import Path
from idcu.core import print_header, print_section, print_success, print_error


def register_commands(subparsers, cli_instance):
    maven_parser = subparsers.add_parser("maven", help="[核心] Maven相关操作")
    maven_subparsers = maven_parser.add_subparsers(title="Maven命令", dest="maven_command")

    maven_list_parser = maven_subparsers.add_parser("list", help="列出所有Maven项目")
    maven_list_parser.set_defaults(func=lambda args: cmd_maven_list(args, cli_instance))

    maven_build_parser = maven_subparsers.add_parser("build", help="构建Maven项目")
    maven_build_parser.add_argument("goals", nargs="*", default=["clean", "install"], help="Maven目标")
    maven_build_parser.add_argument("-p", "--projects", nargs="*", help="要构建的项目")
    maven_build_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_build_parser.set_defaults(func=lambda args: cmd_maven_build(args, cli_instance))

    maven_dep_tree_parser = maven_subparsers.add_parser("dep-tree", help="显示依赖树")
    maven_dep_tree_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_dep_tree_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_dep_tree_parser.set_defaults(func=lambda args: cmd_maven_dep_tree(args, cli_instance))

    maven_dep_list_parser = maven_subparsers.add_parser("dep-list", help="显示依赖列表")
    maven_dep_list_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_dep_list_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_dep_list_parser.set_defaults(func=lambda args: cmd_maven_dep_list(args, cli_instance))

    maven_dep_analyze_parser = maven_subparsers.add_parser("dep-analyze", help="依赖分析")
    maven_dep_analyze_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_dep_analyze_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_dep_analyze_parser.set_defaults(func=lambda args: cmd_maven_dep_analyze(args, cli_instance))

    maven_dep_conflict_parser = maven_subparsers.add_parser("dep-conflict", help="依赖冲突检测")
    maven_dep_conflict_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_dep_conflict_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_dep_conflict_parser.set_defaults(func=lambda args: cmd_maven_dep_conflict(args, cli_instance))

    maven_effective_pom_parser = maven_subparsers.add_parser("effective-pom", help="显示有效POM")
    maven_effective_pom_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_effective_pom_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_effective_pom_parser.set_defaults(func=lambda args: cmd_maven_effective_pom(args, cli_instance))

    maven_profile_list_parser = maven_subparsers.add_parser("profile-list", help="列出所有Profile")
    maven_profile_list_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_profile_list_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_profile_list_parser.set_defaults(func=lambda args: cmd_maven_profile_list(args, cli_instance))

    maven_profile_set_parser = maven_subparsers.add_parser("profile-set", help="设置Profile")
    maven_profile_set_parser.add_argument("profile", nargs="?", help="Profile名称，不指定则使用默认")
    maven_profile_set_parser.add_argument("-p", "--projects", nargs="*", help="要设置的项目")
    maven_profile_set_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_profile_set_parser.set_defaults(func=lambda args: cmd_maven_profile_set(args, cli_instance))

    maven_repo_list_parser = maven_subparsers.add_parser("repo-list", help="显示仓库配置")
    maven_repo_list_parser.add_argument("-p", "--projects", nargs="*", help="要分析的项目")
    maven_repo_list_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_repo_list_parser.set_defaults(func=lambda args: cmd_maven_repo_list(args, cli_instance))

    maven_clean_local_parser = maven_subparsers.add_parser("clean-local", help="清理本地仓库")
    maven_clean_local_parser.add_argument("-p", "--projects", nargs="*", help="要清理的项目")
    maven_clean_local_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_clean_local_parser.set_defaults(func=lambda args: cmd_maven_clean_local(args, cli_instance))

    maven_timeline_parser = maven_subparsers.add_parser("timeline", help="构建性能监控")
    maven_timeline_parser.add_argument("-p", "--projects", nargs="*", help="要监控的项目")
    maven_timeline_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_timeline_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    maven_timeline_parser.set_defaults(func=lambda args: cmd_maven_timeline(args, cli_instance))

    maven_parallel_parser = maven_subparsers.add_parser("parallel", help="并行构建")
    maven_parallel_parser.add_argument("-t", "--threads", help="线程数，例如1C 表示 CPU 核心数")
    maven_parallel_parser.add_argument("-p", "--projects", nargs="*", help="要构建的项目")
    maven_parallel_parser.add_argument("-l", "--local-repo", help="本地Maven仓库路径")
    maven_parallel_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    maven_parallel_parser.set_defaults(func=lambda args: cmd_maven_parallel(args, cli_instance))

    maven_tier_list_parser = maven_subparsers.add_parser("tier-list", help="列出所有梯队")
    maven_tier_list_parser.set_defaults(func=lambda args: cmd_maven_tier_list(args, cli_instance))

    maven_build_tier_parser = maven_subparsers.add_parser("build-tier", help="按梯队构建")
    maven_build_tier_parser.add_argument("tier", nargs="?", help="梯队名称，不指定则构建所有梯队")
    maven_build_tier_parser.add_argument("goals", nargs="*", default=["clean", "install"], help="Maven目标")
    maven_build_tier_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    maven_build_tier_parser.set_defaults(func=lambda args: cmd_maven_build_tier(args, cli_instance))

    maven_build_modules_parser = maven_subparsers.add_parser("build-modules", help="按模块列表构建")
    maven_build_modules_parser.add_argument("modules", nargs="+", help="要构建的模块列表")
    maven_build_modules_parser.add_argument("goals", nargs="*", default=["clean", "install"], help="Maven目标")
    maven_build_modules_parser.add_argument("--skip-tests", action="store_true", help="跳过测试")
    maven_build_modules_parser.set_defaults(func=lambda args: cmd_maven_build_modules(args, cli_instance))


def cmd_maven_list(args, cli):
    devtools = cli._get_devtools()
    print_header("Maven项目列表")
    projects = devtools["list_available_maven_projects"](Path.cwd())
    for project in projects:
        print(f"  - {project}")
    print_success(f"共找到 {len(projects)} 个项目")
    return 0


def cmd_maven_build(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    local_repo = Path(args.local_repo) if args.local_repo else repo_root / ".mvn" / "local-repo"

    print_header(f"Maven构建: {' '.join(args.goals)}")

    result = devtools["run_maven"](
        goals=args.goals,
        local_repo=local_repo,
        repo_root=repo_root,
        args=[],
        projects=args.projects
    )

    if result == 0:
        print_success("构建成功")
    else:
        print_error("构建失败")
    return result


def _maven_operation_wrapper(operation_name, operation_func, args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header(f"Maven {operation_name}")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = operation_func(repo_path)
        if hasattr(result, 'success'):
            if result.success:
                print_success(f"{repo_name}: {result.message}")
                if result.details and 'output' in result.details:
                    print(result.details['output'])
            else:
                print_error(f"{repo_name}: {result.message}")
            return 0 if result.success else 1
        return result

    return devtools["for_each_maven_project"](repo_root, op, args.projects)


def cmd_maven_dep_tree(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("依赖树", devtools["maven_dependency_tree"], args, cli)


def cmd_maven_dep_list(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("依赖列表", devtools["maven_dependency_list"], args, cli)


def cmd_maven_dep_analyze(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("依赖分析", devtools["maven_dependency_analyze"], args, cli)


def cmd_maven_dep_conflict(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("依赖冲突检测", devtools["maven_dependency_conflict"], args, cli)


def cmd_maven_effective_pom(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("有效POM", devtools["maven_effective_pom"], args, cli)


def cmd_maven_profile_list(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("列出Profiles", devtools["maven_list_profiles"], args, cli)


def cmd_maven_profile_set(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("设置Profile")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["maven_set_profile"](repo_path, profile=args.profile)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_maven_project"](repo_root, op, args.projects)


def cmd_maven_repo_list(args, cli):
    devtools = cli._get_devtools()
    return _maven_operation_wrapper("仓库配置", devtools["maven_repo_list"], args, cli)


def cmd_maven_clean_local(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("清理本地仓库")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["maven_clean_local"](repo_path)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_maven_project"](repo_root, op, args.projects)


def cmd_maven_timeline(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("构建性能监控")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["maven_timeline"](repo_path, skip_tests=args.skip_tests)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
            if result.details and 'output' in result.details:
                print(result.details['output'])
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_maven_project"](repo_root, op, args.projects)


def cmd_maven_parallel(args, cli):
    devtools = cli._get_devtools()
    repo_root = Path.cwd()
    print_header("并行构建")

    def op(repo_path, repo_name):
        print_section(f"处理项目: {repo_name}")
        result = devtools["maven_build_parallel"](repo_path, threads=args.threads, skip_tests=args.skip_tests)
        if result.success:
            print_success(f"{repo_name}: {result.message}")
        else:
            print_error(f"{repo_name}: {result.message}")
        return 0 if result.success else 1

    return devtools["for_each_maven_project"](repo_root, op, args.projects)


def cmd_maven_tier_list(args, cli):
    from idcu.tools.maven.tier_builder import TierBuilder
    builder = TierBuilder()
    success = builder.list_tiers()
    return 0 if success else 1


def cmd_maven_build_tier(args, cli):
    from idcu.tools.maven.tier_builder import TierBuilder
    builder = TierBuilder()
    
    if args.tier:
        success = builder.build_tier(args.tier, args.goals, args.skip_tests)
    else:
        success = builder.build_all_tiers(args.goals, args.skip_tests)
    
    return 0 if success else 1


def cmd_maven_build_modules(args, cli):
    from idcu.tools.maven.tier_builder import TierBuilder
    builder = TierBuilder()
    success = builder.build_modules(args.modules, args.goals, args.skip_tests)
    return 0 if success else 1
