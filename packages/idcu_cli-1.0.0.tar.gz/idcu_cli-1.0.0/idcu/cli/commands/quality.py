from pathlib import Path
from idcu.tools.quality import QualityGateManager
from idcu.tools.quality.encoding_check import EncodingChecker
from idcu.tools.quality.dependency_audit import DependencyAuditor
from idcu.tools.quality.tck_runner import TCKRunner


def register_commands(subparsers, cli_instance):
    quality_parser = subparsers.add_parser("quality", help="[核心] 质量检查")
    quality_subparsers = quality_parser.add_subparsers(title="质量检查命令", dest="quality_command")

    quality_run_parser = quality_subparsers.add_parser("run", help="运行所有质量检查")
    quality_run_parser.set_defaults(func=lambda args: cmd_quality_run(args, cli_instance))

    quality_check_parser = quality_subparsers.add_parser("check", help="运行单个质量检查")
    quality_check_parser.add_argument("check", help="检查名称")
    quality_check_parser.set_defaults(func=lambda args: cmd_quality_check(args, cli_instance))

    quality_list_parser = quality_subparsers.add_parser("list", help="列出可用质量检查")
    quality_list_parser.set_defaults(func=lambda args: cmd_quality_list(args, cli_instance))

    quality_gates_parser = quality_subparsers.add_parser("gates", help="列出配置的质量门控")
    quality_gates_parser.set_defaults(func=lambda args: cmd_quality_gates(args, cli_instance))

    quality_encoding_parser = quality_subparsers.add_parser("encoding", help="编码检查和修复")
    quality_encoding_subparsers = quality_encoding_parser.add_subparsers(title="编码检查命令", dest="encoding_command")

    quality_encoding_check_parser = quality_encoding_subparsers.add_parser("check", help="检查编码问题")
    quality_encoding_check_parser.add_argument("-p", "--path", help="检查路径（默认为当前目录）")
    quality_encoding_check_parser.add_argument("--no-recursive", action="store_false", dest="recursive", help="不递归检查子目录")
    quality_encoding_check_parser.add_argument("-o", "--output", help="报告输出文件")
    quality_encoding_check_parser.set_defaults(func=lambda args: cmd_quality_encoding_check(args, cli_instance))

    quality_encoding_fix_parser = quality_encoding_subparsers.add_parser("fix", help="修复编码问题")
    quality_encoding_fix_parser.add_argument("-p", "--path", help="修复路径（默认为当前目录）")
    quality_encoding_fix_parser.add_argument("-t", "--target-encoding", default="utf-8", help="目标编码（默认为 utf-8）")
    quality_encoding_fix_parser.add_argument("--no-backup", action="store_false", dest="backup", help="不创建备份文件")
    quality_encoding_fix_parser.add_argument("--force", action="store_true", help="强制修复所有文件，即使编码看起来正常")
    quality_encoding_fix_parser.add_argument("--no-recursive", action="store_false", dest="recursive", help="不递归修复子目录")
    quality_encoding_fix_parser.add_argument("-o", "--output", help="报告输出文件")
    quality_encoding_fix_parser.set_defaults(func=lambda args: cmd_quality_encoding_fix(args, cli_instance))

    quality_dependency_parser = quality_subparsers.add_parser("dependency-audit", help="依赖审计")
    quality_dependency_subparsers = quality_dependency_parser.add_subparsers(title="依赖审计命令", dest="dependency_command")
    
    quality_dependency_audit_parser = quality_dependency_subparsers.add_parser("audit", help="运行依赖审计")
    quality_dependency_audit_parser.add_argument("-p", "--path", help="审计路径（默认为当前目录）")
    quality_dependency_audit_parser.add_argument("-o", "--output", help="报告输出文件")
    quality_dependency_audit_parser.set_defaults(func=lambda args: cmd_quality_dependency_audit(args, cli_instance))
    
    quality_tck_parser = quality_subparsers.add_parser("tck", help="TCK 测试")
    quality_tck_subparsers = quality_tck_parser.add_subparsers(title="TCK 测试命令", dest="tck_command")
    
    quality_tck_run_parser = quality_tck_subparsers.add_parser("run", help="运行 TCK 测试")
    quality_tck_run_parser.add_argument("-p", "--path", help="测试路径（默认为当前目录）")
    quality_tck_run_parser.add_argument("-t", "--test-pattern", help="测试模式，例如 *Test")
    quality_tck_run_parser.add_argument("-o", "--output", help="报告输出文件")
    quality_tck_run_parser.add_argument("-f", "--format", choices=["text", "json", "html"], default="text", help="报告格式（默认 text）")
    quality_tck_run_parser.set_defaults(func=lambda args: cmd_quality_tck_run(args, cli_instance))


def cmd_quality_run(args, cli):
    manager = QualityGateManager()
    results = manager.run_all_checks()
    all_passed = all(result.passed for result in results)
    if all_passed:
        return 0
    else:
        return 1


def cmd_quality_check(args, cli):
    manager = QualityGateManager()
    result = manager.run_check(args.check)
    if result and result.passed:
        return 0
    else:
        return 1


def cmd_quality_list(args, cli):
    manager = QualityGateManager()
    manager.list_available_checks()
    return 0


def cmd_quality_gates(args, cli):
    manager = QualityGateManager()
    manager.list_configured_gates()
    return 0


def cmd_quality_encoding_check(args, cli):
    path = Path(args.path) if args.path else None
    checker = EncodingChecker()
    results = checker.check(path, recursive=args.recursive)
    
    if args.output:
        checker.generate_report(results, Path(args.output))
    
    has_garbage = 0
    for r in results:
        if r.has_garbage:
            has_garbage = has_garbage + 1
    if has_garbage > 0:
        return 1
    else:
        return 0


def cmd_quality_encoding_fix(args, cli):
    path = Path(args.path) if args.path else None
    checker = EncodingChecker()
    results = checker.fix(
        path, 
        target_encoding=args.target_encoding,
        backup=args.backup,
        force=args.force,
        recursive=args.recursive
    )
    
    if args.output:
        checker.generate_report(results, Path(args.output))
    
    errors = sum(1 for r in results if not r.success)
    if errors > 0:
        return 1
    else:
        return 0


def cmd_quality_dependency_audit(args, cli):
    path = Path(args.path) if args.path else None
    auditor = DependencyAuditor(path)
    results = auditor.audit()
    
    if args.output:
        auditor.generate_report(results, Path(args.output))
    
    invalid = sum(1 for r in results if not r.is_valid)
    if invalid > 0:
        return 1
    else:
        return 0


def cmd_quality_tck_run(args, cli):
    path = Path(args.path) if args.path else None
    runner = TCKRunner(path)
    result = runner.run_tests(args.test_pattern)
    
    if args.output:
        runner.generate_report(result, Path(args.output), args.format)
    
    if result.success:
        return 0
    else:
        return 1
