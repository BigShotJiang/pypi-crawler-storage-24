
"""Е▒╫Д╩╓Х║╔Е┘╗Ф╗║Е²≈О╪▄Ф▐░Д╬?BashЦ─│Zsh Е▓?PowerShell Г └Х║╔Е┘╗Х└ Ф°╛Г■÷Ф┬░Е┼÷Х┐╫Ц─?

Ф■╞Ф▄│Г■÷Ф┬░Д╦┴Г╖█Д╦╩Ф╣│ Shell Г └Е▒╫Д╩╓Х║╔Е┘╗Х└ Ф°╛О╪▄Ф▐░Е█┤Г■╗Ф┬╥Д╫⌠И╙▄Ц─?
"""

from pathlib import Path
from typing import Optional

BASH_COMPLETION_SCRIPT = '''_idcu_completions() {
    local cur prev words cword
    COMPREPLY=()
    _get_comp_words_by_ref -n : cur prev words cword

    case "${words[1]}" in
        git)
            case "${words[2]}" in
                "")
                    COMPREPLY=( $(compgen -W "list status commit push pull fetch switch log stash stash-pop stash-list changes rebase cherry-pick reset diff clean tag blame bisect" -- "$cur") )
                    ;;
                *)
                    ;;
            esac
            ;;
        maven)
            case "${words[2]}" in
                "")
                    COMPREPLY=( $(compgen -W "list build dep-tree dep-list dep-analyze dep-conflict effective-pom profile-list profile-set repo-list clean-local timeline parallel" -- "$cur") )
                    ;;
                *)
                    ;;
            esac
            ;;
        plugin)
            case "${words[2]}" in
                "")
                    COMPREPLY=( $(compgen -W "list" -- "$cur") )
                    ;;
                *)
                    ;;
            esac
            ;;
        env)
            case "${words[2]}" in
                "")
                    COMPREPLY=( $(compgen -W "setup versions" -- "$cur") )
                    ;;
                *)
                    ;;
            esac
            ;;
        release)
            case "${words[2]}" in
                "")
                    COMPREPLY=( $(compgen -W "config create-branch update-version build deploy tag full" -- "$cur") )
                    ;;
                *)
                    ;;
            esac
            ;;
        cmd)
            ;;
        *)
            if [[ $cword -eq 1 ]]; then
                COMPREPLY=( $(compgen -W "git maven plugin env release cmd --version" -- "$cur") )
            fi
            ;;
    esac

    return 0
}

complete -F _idcu_completions idcu
'''


ZSH_COMPLETION_SCRIPT = '''#compdef idcu

_idcu() {
    local -a commands git_commands maven_commands plugin_commands env_commands release_commands

    commands=(
        'git:GitГ⌡╦Е┘ЁФ⌠█Д╫°'
        'maven:MavenГ⌡╦Е┘ЁФ⌠█Д╫°'
        'plugin:Ф▐▓Д╩╤Г╝║Г░├'
        'env:Г▌╞Е╒┐И┘█Г╫╝Г⌡╦Е┘ЁФ⌠█Д╫°'
        'release:Е▐▒Е╦┐Г╝║Г░├Г⌡╦Е┘ЁФ⌠█Д╫°'
        'cmd:Ф┴╖Х║▄Ф▐▓Д╩╤Е▒╫Д╩╓'
        '--version:Ф≤╬Г╓╨Г┴┬Ф°╛Д©║Ф│╞'
    )

    git_commands=(
        'list:Е┬≈Е┤╨Ф┴─Ф°┴Е▐╞Г■╗И║╧Г⌡?
        'status:Ф÷╔Г°▀GitГ┼╤Ф─?
        'commit:Ф▐░Д╨╓Ф⌡╢Ф■╧'
        'push:Ф▌╗И─│Е┬╟Х©°Г╗▀'
        'pull:Д╩▌Х©°Г╗▀Ф▀┴Е▐?
        'fetch:Х▌╥Е▐√Х©°Г╗▀Ф⌡╢Ф√╟'
        'switch:Е┬┤Ф█╒Е┬├Ф■╞'
        'log:Ф÷╔Г°▀Ф▐░Д╨╓Ф≈╔Е©≈'
        'stash:Ф ┌Е╜≤Ф⌡╢Ф■╧'
        'stash-pop:Ф│╒Е╓█Ф ┌Е╜≤'
        'stash-list:Ф÷╔Г°▀Ф ┌Е╜≤Е┬≈Х║╗'
        'changes:Ф÷╔Г°▀Ф⌡╢Ф■╧'
        'rebase:Е▐≤Е÷╨Ф⌠█Д╫°'
        'cherry-pick:Ф▄▒И─┴Ф▐░Д╨?
        'reset:И┤█Г╫╝Ф⌠█Д╫°'
        'diff:Ф÷╔Г°▀Е╥╝Е╪┌'
        'clean:Ф╦┘Г░├Е╥╔Д╫°Е▄?
        'tag:Ф═┤Г╜╬Г╝║Г░├'
        'blame:Ф÷╔Г°▀Ф√┤Д╩╤Д©╝Ф■╧Е▌├Е▐╡'
        'bisect:Д╨▄Е┬├Ф÷╔Ф┴╬'
    )

    maven_commands=(
        'list:Е┬≈Е┤╨Ф┴─Ф°┴MavenИ║╧Г⌡╝'
        'build:Ф·└Е╩╨MavenИ║╧Г⌡╝'
        'dep-tree:Ф≤╬Г╓╨Д╬²Х╣√Ф═?
        'dep-list:Ф≤╬Г╓╨Д╬²Х╣√Е┬≈Х║╗'
        'dep-analyze:Д╬²Х╣√Е┬├Ф·░'
        'dep-conflict:Д╬²Х╣√Е├╡Г╙│Фё─Ф╣?
        'effective-pom:Ф≤╬Г╓╨Ф°┴Ф∙┬POM'
        'profile-list:Е┬≈Е┤╨Ф┴─Ф°┴Profile'
        'profile-set:Х╝╬Г╫╝Profile'
        'repo-list:Ф≤╬Г╓╨Д╩⌠Е╨⌠И┘█Г╫╝'
        'clean-local:Ф╦┘Г░├Ф°╛Е°╟Д╩⌠Е╨⌠'
        'timeline:Ф·└Е╩╨Ф─╖Х┐╫Г⌡▒Ф▌╖'
        'parallel:Е╧╤Х║▄Ф·└Е╩╨'
    )

    plugin_commands=(
        'list:Е┬≈Е┤╨Ф┴─Ф°┴Ф▐▓Д╩?
    )

    env_commands=(
        'setup:И┘█Г╫╝Е╪─Е▐▒Г▌╞Е╒┐Е▐≤И┤?
        'versions:Ф≤╬Г╓╨Г▌╞Е╒┐Х╫╞Д╩╤Г┴┬Ф°╛Д©║Ф│╞'
    )

    release_commands=(
        'config:Ф÷╔Г°▀Е╫⌠Е┴█И┘█Г╫╝'
        'create-branch:Е┬⌡Е╩╨Е▐▒Е╦┐Е┬├Ф■╞'
        'update-version:Ф⌡╢Ф√╟Г┴┬Ф°╛Е▐?
        'build:Ф·└Е╩╨И║╧Г⌡╝'
        'deploy:И┐╗Г╫╡И║╧Г⌡╝'
        'tag:Е┬⌡Е╩╨Е╧╤Ф▌╗И─│Git Tag'
        'full:Ф┴╖Х║▄Е╝▄Ф∙╢Е▐▒Е╦┐Ф╣│Г╗▀'
    )

    _arguments -C \\
        '1: :->command' \\
        '*: :->args'

    case $state in
        command)
            _describe 'command' commands
            ;;
        args)
            case $words[2] in
                git)
                    _describe 'git_command' git_commands
                    ;;
                maven)
                    _describe 'maven_command' maven_commands
                    ;;
                plugin)
                    _describe 'plugin_command' plugin_commands
                    ;;
                env)
                    _describe 'env_command' env_commands
                    ;;
                release)
                    _describe 'release_command' release_commands
                    ;;
            esac
            ;;
    esac
}

_idcu "$@"
'''


POWERSHELL_COMPLETION_SCRIPT = '''Register-ArgumentCompleter -Native -CommandName idcu -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commands = @(
        'git',
        'maven',
        'plugin',
        'env',
        'release',
        'cmd',
        '--version'
    )

    $gitCommands = @(
        'list', 'status', 'commit', 'push', 'pull', 'fetch', 'switch', 'log',
        'stash', 'stash-pop', 'stash-list', 'changes', 'rebase', 'cherry-pick',
        'reset', 'diff', 'clean', 'tag', 'blame', 'bisect'
    )

    $mavenCommands = @(
        'list', 'build', 'dep-tree', 'dep-list', 'dep-analyze', 'dep-conflict',
        'effective-pom', 'profile-list', 'profile-set', 'repo-list', 'clean-local',
        'timeline', 'parallel'
    )

    $pluginCommands = @('list')
    $envCommands = @('setup', 'versions')
    $releaseCommands = @(
        'config', 'create-branch', 'update-version', 'build', 'deploy', 'tag', 'full'
    )

    $elements = $commandAst.CommandElements
    if ($elements.Count -eq 0) {
        return
    }

    $currentWord = $elements[-1].Value
    if (-not $currentWord) {
        $currentWord = ''
    }

    $completions = @()

    if ($elements.Count -eq 1) {
        $completions = $commands | Where-Object { $_ -like "$currentWord*" }
    } else {
        $mainCommand = $elements[1].Value
        switch ($mainCommand) {
            'git' {
                if ($elements.Count -eq 2) {
                    $completions = $gitCommands | Where-Object { $_ -like "$currentWord*" }
                }
            }
            'maven' {
                if ($elements.Count -eq 2) {
                    $completions = $mavenCommands | Where-Object { $_ -like "$currentWord*" }
                }
            }
            'plugin' {
                if ($elements.Count -eq 2) {
                    $completions = $pluginCommands | Where-Object { $_ -like "$currentWord*" }
                }
            }
            'env' {
                if ($elements.Count -eq 2) {
                    $completions = $envCommands | Where-Object { $_ -like "$currentWord*" }
                }
            }
            'release' {
                if ($elements.Count -eq 2) {
                    $completions = $releaseCommands | Where-Object { $_ -like "$currentWord*" }
                }
            }
        }
    }

    $completions | ForEach-Object {
        [System.Management.Automation.CompletionResult]::new(
            $_,
            $_,
            'ParameterValue',
            $_
        )
    }
}
'''


def generate_bash_completion(output_path: Optional[Path] = None) -> str:
    """Г■÷Ф┬░ Bash Е▒╫Д╩╓Х║╔Е┘╗Х└ Ф°╛Ц─?

    Args:
        output_path: Е▐╞И─┴Г └Х╬⌠Е┤╨Ф√┤Д╩╤Х╥╞Е╬└О╪▄Е╕┌Ф·°Ф▐░Д╬⌡Е┬≥Е├≥Е┘╔Ф√┤Д╩╤

    Returns:
        Bash Х║╔Е┘╗Х└ Ф°╛Е├┘Е╝╧

    Examples:
        >>> script = generate_bash_completion()
        >>> generate_bash_completion(Path("/etc/bash_completion.d/idcu"))
    """
    if output_path:
        output_path.write_text(BASH_COMPLETION_SCRIPT, encoding="utf-8")
    return BASH_COMPLETION_SCRIPT


def generate_zsh_completion(output_path: Optional[Path] = None) -> str:
    """Г■÷Ф┬░ Zsh Е▒╫Д╩╓Х║╔Е┘╗Х└ Ф°╛Ц─?

    Args:
        output_path: Е▐╞И─┴Г └Х╬⌠Е┤╨Ф√┤Д╩╤Х╥╞Е╬└О╪▄Е╕┌Ф·°Ф▐░Д╬⌡Е┬≥Е├≥Е┘╔Ф√┤Д╩╤

    Returns:
        Zsh Х║╔Е┘╗Х└ Ф°╛Е├┘Е╝╧

    Examples:
        >>> script = generate_zsh_completion()
        >>> generate_zsh_completion(Path("~/.zsh/completions/_idcu"))
    """
    if output_path:
        output_path.write_text(ZSH_COMPLETION_SCRIPT, encoding="utf-8")
    return ZSH_COMPLETION_SCRIPT


def generate_powershell_completion(output_path: Optional[Path] = None) -> str:
    """Г■÷Ф┬░ PowerShell Е▒╫Д╩╓Х║╔Е┘╗Х└ Ф°╛Ц─?

    Args:
        output_path: Е▐╞И─┴Г └Х╬⌠Е┤╨Ф√┤Д╩╤Х╥╞Е╬└О╪▄Е╕┌Ф·°Ф▐░Д╬⌡Е┬≥Е├≥Е┘╔Ф√┤Д╩╤

    Returns:
        PowerShell Х║╔Е┘╗Х└ Ф°╛Е├┘Е╝╧

    Examples:
        >>> script = generate_powershell_completion()
        >>> generate_powershell_completion(Path("$PROFILE"))
    """
    if output_path:
        output_path.write_text(POWERSHELL_COMPLETION_SCRIPT, encoding="utf-8")
    return POWERSHELL_COMPLETION_SCRIPT

