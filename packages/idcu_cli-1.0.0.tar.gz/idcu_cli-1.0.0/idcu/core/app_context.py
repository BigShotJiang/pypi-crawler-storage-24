from pathlib import Path
from typing import Optional

from idcu.core.cache import FileCache, SimpleCache
from idcu.system.config_manager import ConfigManager
from idcu.system.logger import LoggerManager
from idcu.tools.plugins.base import PluginManager


class AppContext:
    def __init__(
        self,
        base_dir: Optional[Path] = None,
        config_dir: Optional[Path] = None,
        log_dir: Optional[Path] = None,
        cache_dir: Optional[Path] = None,
        config_manager: Optional[ConfigManager] = None,
        logger_manager: Optional[LoggerManager] = None,
        plugin_manager: Optional[PluginManager] = None,
    ):
        if base_dir is None:
            base_dir = Path.cwd() / ".idcu"

        self.base_dir = base_dir
        self.config_dir = config_dir or base_dir
        self.log_dir = log_dir or (base_dir / "logs")
        self.cache_dir = cache_dir or (base_dir / "cache")

        self._config_manager = config_manager
        self._logger_manager = logger_manager
        self._plugin_manager = plugin_manager
        self._file_cache: Optional[FileCache] = None
        self._memory_cache: Optional[SimpleCache] = None

    @property
    def config_manager(self) -> ConfigManager:
        if self._config_manager is None:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self._config_manager = ConfigManager(self.config_dir)
        return self._config_manager

    @property
    def logger_manager(self) -> LoggerManager:
        if self._logger_manager is None:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self._logger_manager = LoggerManager(self.log_dir, config_manager=self.config_manager)
        return self._logger_manager

    @property
    def plugin_manager(self) -> PluginManager:
        if self._plugin_manager is None:
            self._plugin_manager = PluginManager()
        return self._plugin_manager

    @property
    def file_cache(self) -> FileCache:
        if self._file_cache is None:
            self._file_cache = FileCache(self.cache_dir)
        return self._file_cache

    @property
    def memory_cache(self) -> SimpleCache:
        if self._memory_cache is None:
            self._memory_cache = SimpleCache(ttl=300)
        return self._memory_cache

    def get_logger(self, name: str):
        return self.logger_manager.get_logger(name)
