
import json
import sys
from typing import Any, List, Optional


class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"

    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"

    @classmethod
    def disable(cls):
        for attr in dir(cls):
            if not attr.startswith("_") and isinstance(getattr(cls, attr), str):
                setattr(cls, attr, "")

    @classmethod
    def disable_colors(cls):
        cls.disable()


def _resolve_color(color_code):
    if not color_code:
        return ""
    return getattr(Colors, color_code, color_code)


def colorize(text, color_code):
    if not text:
        return ""
    return f"{_resolve_color(color_code)}{text}{Colors.RESET}"


def _supports_text(text, stream):
    encoding = getattr(stream, "encoding", None) or "utf-8"
    try:
        text.encode(encoding)
    except (LookupError, UnicodeEncodeError):
        return False
    return True


def _write_line(text, stream):
    encoding = getattr(stream, "encoding", None) or "utf-8"
    safe_text = text
    if not _supports_text(text, stream):
        safe_text = text.encode(encoding, errors="replace").decode(encoding, errors="replace")
    print(safe_text, file=stream)


def _format_message(prefix, message):
    if message in (None, ""):
        return ""
    return f"{prefix} {message}"


def _print_message(
    message,
    color_code,
    unicode_prefix,
    ascii_prefix,
    stream,
):
    prefix = unicode_prefix if _supports_text(unicode_prefix, stream) else ascii_prefix
    formatted = _format_message(prefix, message)
    if not formatted:
        _write_line("", stream)
        return
    _write_line(colorize(formatted, color_code), stream)


def print_success(message=""):
    _print_message(
        message,
        color_code="GREEN",
        unicode_prefix="\u2713",
        ascii_prefix="[OK]",
        stream=sys.stdout,
    )


def print_error(message=""):
    _print_message(
        message,
        color_code="RED",
        unicode_prefix="\u2717",
        ascii_prefix="[ERROR]",
        stream=sys.stderr,
    )


def print_warning(message=""):
    _print_message(
        message,
        color_code="YELLOW",
        unicode_prefix="!",
        ascii_prefix="[WARN]",
        stream=sys.stdout,
    )


def print_info(message=""):
    _print_message(
        message,
        color_code="BLUE",
        unicode_prefix="\u2139",
        ascii_prefix="[INFO]",
        stream=sys.stdout,
    )


def print_header(message):
    _write_line(colorize(f"\n=== {message} ===", _resolve_color("BOLD") + _resolve_color("CYAN")), sys.stdout)


def print_section(message):
    _write_line(colorize(f"\n--- {message} ---", "BOLD"), sys.stdout)


class ProgressBar:
    def __init__(
        self,
        total: int,
        prefix: str = "进度",
        suffix: str = "完成",
        decimals: int = 1,
        length: int = 50,
        fill: str = "=",
        print_end: str = "\r",
    ):
        self.total = total
        self.prefix = prefix
        self.suffix = suffix
        self.decimals = decimals
        self.length = length
        self.fill = fill
        self.print_end = print_end
        self.current = 0

    def update(self, current: Optional[int] = None, increment: Optional[int] = None):
        if current is not None:
            self.current = current
        elif increment is not None:
            self.current += increment
        self._print()

    def _print(self):
        percent = ("{0:." + str(self.decimals) + "f}").format(
            100 * (self.current / float(self.total))
        )
        filled_length = int(self.length * self.current // self.total)
        bar = self.fill * filled_length + "-" * (self.length - filled_length)
        sys.stdout.write(f"\r{self.prefix} |{bar}| {percent}% {self.suffix}")
        sys.stdout.flush()
        if self.current >= self.total:
            sys.stdout.write("\n")

    def __enter__(self):
        self._print()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.current < self.total:
            self.current = self.total
            self._print()


def print_table(
    headers: List[str],
    rows: List[List[Any]],
    header_color: str = "CYAN",
    border_color: str = "BLUE",
):
    if not rows:
        print_info("无数据可显示")
        return

    col_widths = [len(str(h)) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    separator = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"
    header_row = "|" + "|".join(f" {{:<{w}}} " for w in col_widths) + "|"
    header_row = header_row.format(*headers)

    _write_line(colorize(separator, border_color), sys.stdout)
    _write_line(colorize(header_row, header_color), sys.stdout)
    _write_line(colorize(separator, border_color), sys.stdout)

    for row in rows:
        data_row = "|" + "|".join(f" {{:<{w}}} " for w in col_widths) + "|"
        data_row = data_row.format(*[str(cell) for cell in row])
        _write_line(data_row, sys.stdout)

    _write_line(colorize(separator, border_color), sys.stdout)


def print_json(data: Any, indent: int = 2, ensure_ascii: bool = False):
    _write_line(json.dumps(data, indent=indent, ensure_ascii=ensure_ascii), sys.stdout)


def print_error_with_suggestion(message: str, suggestions: Optional[List[str]] = None):
    print_error(message)
    if suggestions:
        print_info("建议:")
        for i, suggestion in enumerate(suggestions, 1):
            _write_line(colorize(f"  {i}. {suggestion}", "YELLOW"), sys.stdout)

