
from idcu.version import VERSION

DEFAULT_BRANCH = "develop"
REMOTE_NAME = "origin"
GIT_PORCELAIN_FORMAT = "--porcelain"
GIT_ABBREV_REF_FORMAT = "--abbrev-ref"
MAVEN_REPO_LOCAL_PREFIX = "-Dmaven.repo.local="
INTERNAL_GROUP_PREFIX = "ltd.idcu.est.spi"
POM_NAMESPACE_URI = "http://maven.apache.org/POM/4.0.0"

ENCODING_SCAN_INCLUDES = [
    "*.java",
    "*.md",
    "*.xml",
    "*.cmd",
    "*.ps1",
    "*.properties",
    "*.yml",
    "*.yaml",
]
ENCODING_SCAN_EXCLUDES = [r"\\\.git\\", r"\\target\\", r"\\\.mvn\\local-repo\\", r"\\backup\\"]
