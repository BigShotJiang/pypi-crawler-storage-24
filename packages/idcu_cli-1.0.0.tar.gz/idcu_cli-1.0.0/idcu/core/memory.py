
import gc
import sys
from functools import wraps

from idcu.system.logger import get_logger

logger = get_logger("memory")


def get_memory_usage():
    """Get current process memory usage in MB"""
    try:
        import psutil
        process = psutil.Process()
        return process.memory_info().rss / 1024 / 1024
    except ImportError:
        logger.warning("psutil not installed, memory usage estimation may be inaccurate")
        return sys.getsizeof({}) / 1024 / 1024 * 100


def clear_cache_and_collect(cache_instance=None):
    """Clear cache and run garbage collection"""
    if cache_instance and hasattr(cache_instance, 'clear'):
        cache_instance.clear()
    gc.collect()
    if hasattr(gc, 'collect'):
        gc.collect(2)


def memory_efficient(func):
    """Decorator that clears cache and runs GC after function completes"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        finally:
            clear_cache_and_collect()
    return wrapper


def monitor_memory_usage(func):
    """Decorator that monitors memory usage before and after function execution"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        before = get_memory_usage()
        logger.debug(f"Memory before {func.__name__}: {before:.2f} MB")

        try:
            result = func(*args, **kwargs)
            return result
        finally:
            after = get_memory_usage()
            logger.debug(f"Memory after {func.__name__}: {after:.2f} MB")
            logger.debug(f"Memory change: {after - before:+.2f} MB")
    return wrapper


def optimize_list(items, chunk_size=1000):
    """Process list in chunks to optimize memory usage"""
    result = []
    for i in range(0, len(items), chunk_size):
        chunk = items[i:i + chunk_size]
        result.extend(chunk)
        del chunk
        gc.collect()
    return result


class LazyIterator:
    """Lazy iterator that loads data only when needed"""

    def __init__(self, data_loader):
        self.data_loader = data_loader
        self._data = None

    def _ensure_loaded(self):
        if self._data is None:
            self._data = self.data_loader()

    def __iter__(self):
        self._ensure_loaded()
        return iter(self._data)

    def __len__(self):
        self._ensure_loaded()
        return len(self._data)

    def __getitem__(self, index):
        self._ensure_loaded()
        return self._data[index]

