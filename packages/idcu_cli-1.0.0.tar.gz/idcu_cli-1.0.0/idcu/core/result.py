
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


class ErrorCode(IntEnum):
    """统一错误码规范"""
    SUCCESS = 0
    GENERAL_ERROR = 1
    
    GIT_ERROR_BASE = 100
    GIT_NOT_A_REPO = 101
    GIT_NO_CHANGES = 102
    GIT_BRANCH_NOT_EXISTS = 103
    GIT_COMMIT_FAILED = 104
    GIT_PUSH_FAILED = 105
    GIT_PULL_FAILED = 106
    GIT_FETCH_FAILED = 107
    GIT_SWITCH_FAILED = 108
    GIT_STASH_FAILED = 109
    GIT_SUBMODULE_ERROR = 110
    
    MAVEN_ERROR_BASE = 200
    MAVEN_NOT_FOUND = 201
    MAVEN_BUILD_FAILED = 202
    MAVEN_POM_NOT_FOUND = 203
    MAVEN_PROJECT_INVALID = 204
    MAVEN_DEPENDENCY_ERROR = 205
    
    PLUGIN_ERROR_BASE = 300
    PLUGIN_NOT_FOUND = 301
    PLUGIN_LOAD_FAILED = 302
    PLUGIN_COMMAND_FAILED = 303
    
    RELEASE_ERROR_BASE = 400
    RELEASE_VERSION_INVALID = 401
    RELEASE_BRANCH_EXISTS = 402
    RELEASE_BUILD_FAILED = 403
    RELEASE_TAG_FAILED = 404
    
    DRY_RUN = 999


@dataclass
class OperationResult:
    """统一的操作结果类"""
    success: bool
    error_code: ErrorCode = ErrorCode.SUCCESS
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    project: str = ""
    duration_seconds: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    raw_output: str = ""
    raw_error: str = ""
    dry_run: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "error_code": self.error_code.value,
            "error_code_name": self.error_code.name,
            "message": self.message,
            "details": self.details,
            "project": self.project,
            "duration_seconds": self.duration_seconds,
            "timestamp": self.timestamp,
            "dry_run": self.dry_run,
        }
    
    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
    
    @classmethod
    def success_result(cls, message: str = "操作成功", project: str = "", details: Dict[str, Any] = None, **kwargs) -> "OperationResult":
        return cls(
            success=True,
            error_code=ErrorCode.SUCCESS,
            message=message,
            project=project,
            details=details or {},
            **kwargs
        )
    
    @classmethod
    def error_result(cls, error_code: ErrorCode, message: str = "操作失败", project: str = "", details: Dict[str, Any] = None, **kwargs) -> "OperationResult":
        return cls(
            success=False,
            error_code=error_code,
            message=message,
            project=project,
            details=details or {},
            **kwargs
        )
    
    @classmethod
    def dry_run_result(cls, message: str = "Dry run 模拟执行", project: str = "", details: Dict[str, Any] = None, **kwargs) -> "OperationResult":
        return cls(
            success=True,
            error_code=ErrorCode.DRY_RUN,
            message=message,
            project=project,
            details=details or {},
            dry_run=True,
            **kwargs
        )


@dataclass
class BatchOperationReport:
    """批量操作报告"""
    operation_name: str
    total: int = 0
    successful: int = 0
    failed: int = 0
    dry_run: int = 0
    results: List[OperationResult] = field(default_factory=list)
    start_time: str = field(default_factory=lambda: datetime.now().isoformat())
    end_time: Optional[str] = None
    total_duration_seconds: float = 0.0
    
    def add_result(self, result: OperationResult):
        self.results.append(result)
        self.total += 1
        if result.dry_run:
            self.dry_run += 1
        elif result.success:
            self.successful += 1
        else:
            self.failed += 1
    
    def finish(self):
        self.end_time = datetime.now().isoformat()
        if self.results:
            self.total_duration_seconds = sum(r.duration_seconds for r in self.results)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "operation_name": self.operation_name,
            "summary": {
                "total": self.total,
                "successful": self.successful,
                "failed": self.failed,
                "dry_run": self.dry_run,
            },
            "results": [r.to_dict() for r in self.results],
            "start_time": self.start_time,
            "end_time": self.end_time,
            "total_duration_seconds": self.total_duration_seconds,
        }
    
    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
    
    def get_exit_code(self) -> int:
        if self.failed > 0:
            return 1
        return 0


class OutputFormatter:
    """统一的输出格式化器"""
    
    def __init__(self, json_mode: bool = False, dry_run: bool = False):
        self.json_mode = json_mode
        self.dry_run = dry_run
    
    def print_result(self, result: OperationResult):
        if self.json_mode:
            print(result.to_json())
        else:
            self._print_human_readable(result)
    
    def print_batch_report(self, report: BatchOperationReport):
        if self.json_mode:
            print(report.to_json())
        else:
            self._print_batch_report_human_readable(report)
    
    def _print_human_readable(self, result: OperationResult):
        from idcu.core.ui import print_success, print_error, print_info, print_warning
        
        prefix = "[DRY-RUN] " if result.dry_run else ""
        
        if result.success:
            if result.dry_run:
                print_warning(f"{prefix}{result.message}")
            else:
                print_success(f"{prefix}{result.message}")
        else:
            print_error(f"{prefix}{result.message}")
            if result.error_code != ErrorCode.SUCCESS:
                print_info(f"  错误码: {result.error_code.name} ({result.error_code.value})")
        
        if result.project:
            print_info(f"  项目: {result.project}")
        
        if result.duration_seconds > 0:
            print_info(f"  耗时: {result.duration_seconds:.2f}秒")
        
        if result.details:
            for key, value in result.details.items():
                if key not in ['output', 'log']:
                    print_info(f"  {key}: {value}")
        
        if result.raw_output:
            print("\n输出:")
            print(result.raw_output)
        
        if result.raw_error:
            print("\n错误:")
            print(result.raw_error)
    
    def _print_batch_report_human_readable(self, report: BatchOperationReport):
        from idcu.core.ui import print_header, print_success, print_error, print_info, print_table
        
        print_header(f"{report.operation_name} 批量操作报告")
        
        headers = ["项目", "结果", "错误码", "耗时(秒)", "消息"]
        rows = []
        
        for result in report.results:
            status = "成功" if result.success else "失败"
            if result.dry_run:
                status = "Dry-Run"
            error_code = f"{result.error_code.name} ({result.error_code.value})"
            duration = f"{result.duration_seconds:.2f}"
            rows.append([result.project or "-", status, error_code, duration, result.message])
        
        print_table(headers, rows)
        
        print_info(f"\n总计: {report.total} 个项目")
        if report.successful > 0:
            print_success(f"  成功: {report.successful}")
        if report.failed > 0:
            print_error(f"  失败: {report.failed}")
        if report.dry_run > 0:
            print_info(f"  Dry-Run: {report.dry_run}")
        
        if report.total_duration_seconds > 0:
            print_info(f"  总耗时: {report.total_duration_seconds:.2f}秒")
