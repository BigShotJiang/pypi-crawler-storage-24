import concurrent.futures
import os

from idcu.system.logger import get_logger

logger = get_logger("parallel")


def execute_parallel(
    items,
    operation,
    max_workers=None,
    show_progress=False,
):
    """Execute an operation for multiple items in parallel.

    Args:
        items: Iterable of input items.
        operation: Callable applied to each item.
        max_workers: Optional worker count for the thread pool.
        show_progress: Reserved flag for future progress reporting.

    Returns:
        A list of ``(item, result)`` tuples in completion order.
    """
    del show_progress

    results = []

    def wrapper(item):
        return (item, operation(item))

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_item = {executor.submit(wrapper, item): item for item in items}

        for future in concurrent.futures.as_completed(future_to_item):
            item = future_to_item[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                logger.error(f"Error processing {item}: {e}")
                results.append((item, e))

    return results


def execute_parallel_with_error_handler(
    items,
    operation,
    error_indicator,
    max_workers=None,
):
    """Execute items in parallel and collapse the result to an exit code.

    Args:
        items: Iterable of input items.
        operation: Callable applied to each item.
        error_indicator: Predicate that marks a result as failed.
        max_workers: Optional worker count for the thread pool.

    Returns:
        ``1`` when any item fails, otherwise ``0``.
    """
    results = execute_parallel(items, operation, max_workers=max_workers)

    has_error = False
    for item, result in results:
        if isinstance(result, Exception):
            has_error = True
        elif error_indicator(result):
            has_error = True

    return 1 if has_error else 0


def get_optimal_workers():
    """Return a conservative default worker count based on CPU cores."""
    cpu_count = os.cpu_count() or 4
    return min(cpu_count * 2, 16)
