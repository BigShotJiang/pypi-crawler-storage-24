
import os
import re
import stat
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from collections import Counter

from idcu.core.constants import ENCODING_SCAN_EXCLUDES, ENCODING_SCAN_INCLUDES


COMMON_ENCODINGS = [
    "utf-8", "utf-8-sig", "gbk", "gb2312", "gb18030", "big5",
    "shift_jis", "euc-jp", "euc-kr", "cp949",
    "cp1250", "cp1251", "cp1252", "cp1253", "cp1254", "cp1255", "cp1256", "cp1257", "cp1258",
    "iso-8859-1", "iso-8859-2", "iso-8859-5", "iso-8859-6", "iso-8859-7",
    "koi8-r", "koi8-u",
    "utf-16", "utf-16-le", "utf-16-be", "utf-32", "utf-32-le", "utf-32-be",
    "latin-1", "ascii"
]


CHINESE_ENCODINGS = ["gbk", "gb2312", "gb18030", "big5"]
JAPANESE_ENCODINGS = ["shift_jis", "euc-jp"]
KOREAN_ENCODINGS = ["euc-kr", "cp949"]
WESTERN_ENCODINGS = ["cp1252", "iso-8859-1", "latin-1"]


BOM_MARKS = {
    b"\xef\xbb\xbf": "utf-8-sig",
    b"\xff\xfe": "utf-16-le",
    b"\xfe\xff": "utf-16-be",
    b"\xff\xfe\x00\x00": "utf-32-le",
    b"\x00\x00\xfe\xff": "utf-32-be",
}


GARBAGE_PATTERNS = [
    re.compile(r"[\ufffd\ufffe\uffff]"),
    re.compile(r"[\\x][0-9a-fA-F]{2}[\\x][0-9a-fA-F]{2}[\\x][0-9a-fA-F]{2}"),
    re.compile(r"[\\u][0-9a-fA-F]{4}[\\u][0-9a-fA-F]{4}[\\u][0-9a-fA-F]{4}"),
    re.compile(r"[^\x20-\x7E\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\n\r\t]"),
]


CHINESE_PATTERN = re.compile(r"[\u4E00-\u9FFF]")
JAPANESE_PATTERN = re.compile(r"[\u3040-\u30FF]")
KOREAN_PATTERN = re.compile(r"[\uAC00-\uD7AF]")
ENGLISH_PATTERN = re.compile(r"[a-zA-Z]")


class EncodingResult:
    def __init__(self, path, encoding=None, confidence=0.0,
                 has_garbage=False, garbage_count=0,
                 fixed_encoding=None):
        self.path = path
        self.encoding = encoding
        self.confidence = confidence
        self.has_garbage = has_garbage
        self.garbage_count = garbage_count
        self.fixed_encoding = fixed_encoding
        self.restored = False
        self.success = False
        self.error_message = None
        self.quality_score = 0.0
        self.original_size = 0
        self.fixed_size = 0


def detect_bom(data):
    for bom, encoding in BOM_MARKS.items():
        if data.startswith(bom):
            return encoding, bom
    return None, None


def is_valid_char_code(code):
    if code < 0:
        return False
    elif code <= 0xD7FF:
        return True
    elif code >= 0xE000 and code <= 0xFFFD:
        return True
    elif code >= 0x10000 and code <= 0x10FFFF:
        return True
    else:
        return False


def analyze_language_patterns(text):
    chinese_chars = len(CHINESE_PATTERN.findall(text))
    japanese_chars = len(JAPANESE_PATTERN.findall(text))
    korean_chars = len(KOREAN_PATTERN.findall(text))
    english_chars = len(ENGLISH_PATTERN.findall(text))
    total = len(text)
    
    return {
        "chinese": chinese_chars / total if total > 0 else 0,
        "japanese": japanese_chars / total if total > 0 else 0,
        "korean": korean_chars / total if total > 0 else 0,
        "english": english_chars / total if total > 0 else 0,
    }


def calculate_text_quality(text):
    if not text:
        return 0.0

    total_chars = len(text)
    if total_chars == 0:
        return 0.0

    valid_chars = 0
    printable_chars = 0
    control_chars = 0

    for char in text:
        char_code = ord(char)
        if is_valid_char_code(char_code):
            valid_chars += 1
        if char.isprintable() or char.isspace():
            printable_chars += 1
        if char_code < 32 and char not in '\n\r\t':
            control_chars += 1

    valid_ratio = valid_chars / total_chars
    printable_ratio = printable_chars / total_chars
    control_ratio = control_chars / total_chars

    common_patterns = 0.0
    lang_patterns = analyze_language_patterns(text)
    
    if lang_patterns["english"] > 0.1:
        common_patterns += 0.15
    if lang_patterns["chinese"] > 0.05:
        common_patterns += 0.15
    if lang_patterns["japanese"] > 0.05:
        common_patterns += 0.1
    if lang_patterns["korean"] > 0.05:
        common_patterns += 0.1
    
    if re.search(r"[\s\n\r\t.,!?;:'\"]", text):
        common_patterns += 0.1
    
    quality_score = (valid_ratio * 0.35 + printable_ratio * 0.35 + common_patterns - control_ratio * 0.5) * 100

    return max(0.0, min(quality_score, 100.0))


def detect_encoding_with_fallback(data, sample_size=100000):
    bom_encoding, bom = detect_bom(data)
    if bom_encoding:
        return bom_encoding, 1.0

    sample = data[:sample_size]
    
    lang_hint = analyze_byte_patterns(sample)
    
    priority_encodings = []
    if lang_hint == "chinese":
        priority_encodings = CHINESE_ENCODINGS + ["utf-8", "utf-8-sig"]
    elif lang_hint == "japanese":
        priority_encodings = JAPANESE_ENCODINGS + ["utf-8", "utf-8-sig"]
    elif lang_hint == "korean":
        priority_encodings = KOREAN_ENCODINGS + ["utf-8", "utf-8-sig"]
    else:
        priority_encodings = ["utf-8", "utf-8-sig"] + WESTERN_ENCODINGS
    
    all_encodings = priority_encodings + [enc for enc in COMMON_ENCODINGS if enc not in priority_encodings]

    encoding_scores = {}

    for enc in all_encodings:
        try:
            text = sample.decode(enc, errors="strict")
            quality = calculate_text_quality(text)
            encoding_scores[enc] = quality
        except (UnicodeDecodeError, LookupError):
            continue

    if encoding_scores:
        best_enc = max(encoding_scores.items(), key=lambda x: x[1])
        if best_enc[1] > 50:
            return best_enc[0], best_enc[1] / 100

    for enc in all_encodings:
        try:
            sample.decode(enc, errors="replace")
            return enc, 0.6
        except (UnicodeDecodeError, LookupError):
            continue

    return "utf-8", 0.5


def analyze_byte_patterns(data):
    sample = data[:50000]
    
    chinese_byte_pattern = re.compile(b'[\x80-\xFF]{2,4}')
    chinese_matches = len(chinese_byte_pattern.findall(sample))
    
    if chinese_matches > len(sample) * 0.01:
        return "chinese"
    
    null_count = sample.count(b'\x00')
    if null_count > len(sample) * 0.1:
        return "utf16"
    
    return "unknown"


def has_garbage_text(text):
    count = 0
    for pattern in GARBAGE_PATTERNS:
        matches = pattern.findall(text)
        count += len(matches)

    invalid_consecutive = 0
    max_invalid = 0
    for char in text:
        char_code = ord(char)
        is_valid = is_valid_char_code(char_code)

        if not is_valid and char_code > 127:
            invalid_consecutive += 1
            if invalid_consecutive > max_invalid:
                max_invalid = invalid_consecutive
        else:
            invalid_consecutive = 0

    if max_invalid >= 4:
        count += max_invalid

    return count > 0, count


def detect_file_encoding(file_path):
    result = EncodingResult(file_path)

    try:
        with open(file_path, "rb") as f:
            data = f.read()
            result.original_size = len(data)

        encoding, confidence = detect_encoding_with_fallback(data)
        result.encoding = encoding
        result.confidence = confidence

        if encoding:
            try:
                text = data.decode(encoding, errors="replace")
                has_garbage, garbage_count = has_garbage_text(text)
                result.has_garbage = has_garbage
                result.garbage_count = garbage_count
                result.quality_score = calculate_text_quality(text)
            except Exception:
                pass

        result.success = True
    except Exception as e:
        result.success = False
        result.error_message = str(e)

    return result


def try_all_encodings(data):
    results = []

    for enc in COMMON_ENCODINGS:
        try:
            text = data.decode(enc, errors="strict")
            quality = calculate_text_quality(text)
            has_garbage, garbage_count = has_garbage_text(text)
            results.append({
                "encoding": enc,
                "text": text,
                "quality": quality,
                "has_garbage": has_garbage,
                "garbage_count": garbage_count
            })
        except (UnicodeDecodeError, LookupError):
            continue

    for enc in COMMON_ENCODINGS:
        try:
            text = data.decode(enc, errors="replace")
            quality = calculate_text_quality(text)
            has_garbage, garbage_count = has_garbage_text(text)
            results.append({
                "encoding": enc,
                "text": text,
                "quality": quality,
                "has_garbage": has_garbage,
                "garbage_count": garbage_count
            })
        except (UnicodeDecodeError, LookupError):
            continue

    results.sort(key=lambda x: (not x["has_garbage"], x["quality"], -x["garbage_count"]), reverse=True)
    return results


def try_fix_encoding(data, source_encoding=None):
    all_results = try_all_encodings(data)

    for result in all_results:
        if not result["has_garbage"] and result["quality"] > 75:
            return result["text"], result["encoding"]

    for result in all_results:
        if result["quality"] > 60:
            return result["text"], result["encoding"]

    return data.decode("utf-8", errors="replace"), "utf-8"


def fix_file_encoding(file_path, target_encoding="utf-8", backup=True, force=False):
    result = EncodingResult(file_path)

    try:
        with open(file_path, "rb") as f:
            data = f.read()
            result.original_size = len(data)

        encoding_result = detect_file_encoding(file_path)
        result.encoding = encoding_result.encoding
        result.confidence = encoding_result.confidence
        result.has_garbage = encoding_result.has_garbage
        result.garbage_count = encoding_result.garbage_count
        result.quality_score = encoding_result.quality_score

        if not force and not result.encoding == target_encoding and not result.has_garbage:
            result.success = True
            result.restored = False
            return result

        if backup:
            backup_path = Path(str(file_path) + ".bak")
            with open(backup_path, "wb") as f:
                f.write(data)

        fixed_text, used_encoding = try_fix_encoding(data, encoding_result.encoding)
        result.fixed_encoding = used_encoding

        with open(file_path, "w", encoding=target_encoding, newline="") as f:
            f.write(fixed_text)
            result.fixed_size = len(fixed_text.encode(target_encoding))

        result.success = True
        result.restored = True
    except Exception as e:
        result.success = False
        result.error_message = str(e)

    return result


def fix_file_encoding_safe(file_path, target_encoding="utf-8"):
    return fix_file_encoding(file_path, target_encoding, backup=True)


def detect_garbage(file_path):
    return detect_file_encoding(file_path)


def fix_garbage(file_path, target_encoding="utf-8", backup=True):
    return fix_file_encoding(file_path, target_encoding, backup)


def fix_garbage_safe(file_path, target_encoding="utf-8"):
    return fix_file_encoding_safe(file_path, target_encoding)


def _match_any_pattern(path, patterns):
    path_str = str(path)
    for pattern in patterns:
        if path.match(pattern):
            return True
        if pattern in path_str:
            return True
    return False


def is_binary_file(file_path, sample_size=8192):
    try:
        with open(file_path, 'rb') as f:
            sample = f.read(sample_size)
            if b'\x00' in sample:
                return True
            text_chars = bytearray({7,8,9,10,12,13,27} | set(range(0x20, 0x100)))
            is_binary = bool(sample.translate(None, text_chars))
            return is_binary
    except:
        return False


def process_path(path, target_encoding="utf-8", backup=True, force=False, recursive=True):
    results = []
    path_obj = Path(path)

    if path_obj.is_file():
        if not is_binary_file(path_obj):
            if _match_any_pattern(path_obj, ENCODING_SCAN_INCLUDES):
                if not _match_any_pattern(path_obj, ENCODING_SCAN_EXCLUDES):
                    results.append(fix_file_encoding(path_obj, target_encoding, backup, force))
    elif path_obj.is_dir():
        for root, dirs, files in os.walk(str(path_obj)):
            root_path = Path(root)
            for file_name in files:
                file_path = root_path / file_name
                if not is_binary_file(file_path):
                    if _match_any_pattern(file_path, ENCODING_SCAN_INCLUDES):
                        if not _match_any_pattern(file_path, ENCODING_SCAN_EXCLUDES):
                            results.append(fix_file_encoding(file_path, target_encoding, backup, force))

    return results


def process_path_safe(path, target_encoding="utf-8", recursive=True):
    return process_path(path, target_encoding, backup=True, force=False, recursive=recursive)


def get_file_encoding_statistics(results):
    stats = Counter()
    total = 0
    has_garbage = 0
    restored = 0
    errors = 0
    
    for r in results:
        total += 1
        if r.encoding:
            stats[r.encoding] += 1
        if r.has_garbage:
            has_garbage += 1
        if r.restored:
            restored += 1
        if not r.success:
            errors += 1
    
    return {
        "total": total,
        "encoding_distribution": dict(stats),
        "has_garbage": has_garbage,
        "restored": restored,
        "errors": errors
    }

