
import hashlib
import json
import pickle
import time
from pathlib import Path

from idcu.system.logger import get_logger

logger = get_logger("cache")


class SimpleCache:
    """Simple in-memory cache implementation"""

    def __init__(self, ttl=300):
        """Initialize simple cache
        Args:
            ttl: Time to live in seconds for cache entries
        """
        self._cache = {}
        self._ttl = ttl

    def get(self, key):
        """Get a cache entry
        Args:
            key: Cache key
        Returns:
            Cache value if exists and not expired, otherwise None
        """
        if key not in self._cache:
            return None

        value, timestamp = self._cache[key]
        if time.time() - timestamp > self._ttl:
            del self._cache[key]
            return None

        return value

    def set(self, key, value, ttl=None):
        """Set a cache entry
        Args:
            key: Cache key
            value: Cache value
            ttl: Optional custom time to live in seconds
        """
        self._cache[key] = (value, time.time())

    def clear(self):
        """Clear all cache entries"""
        self._cache.clear()

    def delete(self, key):
        """Delete a specific cache entry
        Args:
            key: The cache key to delete
        """
        if key in self._cache:
            del self._cache[key]


class FileCache:
    """File-based cache implementation"""

    def __init__(self, cache_dir=None, ttl=3600):
        """Initialize file cache
        Args:
            cache_dir: Cache directory, defaults to ~/.idcu/cache
            ttl: Time to live in seconds for cache entries
        """
        if cache_dir is None:
            cache_dir = Path.cwd() / ".idcu" / "cache"

        self._cache_dir = cache_dir
        self._ttl = ttl
        try:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            fallback_dir = Path.cwd() / ".idcu" / "cache"
            fallback_dir.mkdir(parents=True, exist_ok=True)
            self._cache_dir = fallback_dir

    def _get_cache_path(self, key):
        """Get cache file path"""
        key_hash = hashlib.md5(key.encode()).hexdigest()
        return self._cache_dir / f"{key_hash}.cache"

    def get(self, key):
        """Get a cache entry
        Args:
            key: Cache key
        Returns:
            Cache value if exists and not expired, otherwise None
        """
        cache_path = self._get_cache_path(key)

        if not cache_path.exists():
            return None

        if time.time() - cache_path.stat().st_mtime > self._ttl:
            cache_path.unlink(missing_ok=True)
            return None

        try:
            with open(cache_path, "rb") as f:
                return pickle.load(f)
        except Exception as e:
            logger.warning(f"Failed to read cache: {e}")
            cache_path.unlink(missing_ok=True)
            return None

    def set(self, key, value, ttl=None):
        """Set a cache entry
        Args:
            key: Cache key
            value: Cache value
            ttl: Optional custom time to live in seconds
        """
        cache_path = self._get_cache_path(key)

        try:
            with open(cache_path, "wb") as f:
                pickle.dump(value, f)
        except Exception as e:
            logger.warning(f"Failed to write cache: {e}")

    def clear(self):
        """Clear all cache entries"""
        for cache_file in self._cache_dir.glob("*.cache"):
            try:
                cache_file.unlink()
            except Exception as e:
                logger.warning(f"Failed to delete cache file: {e}")

    def delete(self, key):
        """Delete a specific cache entry
        Args:
            key: The cache key to delete
        """
        cache_path = self._get_cache_path(key)
        cache_path.unlink(missing_ok=True)


def cached(cache, key_prefix="", ttl=None):
    """Cache decorator
    Args:
        cache: Cache instance
        key_prefix: Key prefix
        ttl: Time to live in seconds
    Returns:
        Decorated function
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            key_parts = [key_prefix, func.__name__]
            key_parts.extend(str(arg) for arg in args)
            key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
            key = "|".join(key_parts)

            result = cache.get(key)
            if result is not None:
                return result

            result = func(*args, **kwargs)
            cache.set(key, result, ttl=ttl)
            return result

        return wrapper

    return decorator


_memory_cache = SimpleCache(ttl=300)
_file_cache = None


def get_memory_cache():
    """Get memory cache instance"""
    return _memory_cache


def get_file_cache():
    """Get file cache instance"""
    global _file_cache
    if _file_cache is None:
        _file_cache = FileCache(ttl=3600)
    return _file_cache

