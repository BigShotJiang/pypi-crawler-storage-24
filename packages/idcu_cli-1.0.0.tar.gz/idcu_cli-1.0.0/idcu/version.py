"""Single source of truth for the package version."""

VERSION = "1.0.0"
__version__ = VERSION
