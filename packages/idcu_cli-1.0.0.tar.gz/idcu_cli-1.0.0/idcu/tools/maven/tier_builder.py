
from pathlib import Path
from typing import List, Optional

from idcu.core import print_error, print_info, print_success, print_header, print_section
from idcu.system.project_config import get_project_config_manager, ProjectConfig
from idcu.tools.maven.maven_ops import run_maven


class TierBuilder:
    def __init__(self, repo_root: Optional[Path] = None):
        self.repo_root = repo_root or Path.cwd()
        self.config_manager = get_project_config_manager(self.repo_root / ".idcu")

    def get_project_config(self):
        if not self.config_manager.exists():
            print_error("Project config not found. Please create .idcu/project.yaml")
            return None
        
        if not self.config_manager.is_valid():
            print_error("Invalid project config")
            return None
        
        return self.config_manager.get_config()

    def build_tier(self, tier_name, goals=None, skip_tests=False):
        goals = goals or ["clean", "install"]
        config = self.get_project_config()
        
        if not config:
            return False
        
        tier = config.get_tier_by_name(tier_name)
        if not tier:
            print_error(f"Tier '{tier_name}' not found")
            return False
        
        print_header(f"Building tier: {tier.name} (order: {tier.order})")
        
        if not tier.modules:
            print_info("No modules in this tier")
            return True
        
        maven_args = []
        if skip_tests:
            maven_args.append("-DskipTests")
        
        success = True
        for module in tier.modules:
            module_path = self.repo_root / module
            if not (module_path / "pom.xml").exists():
                print_error(f"Module {module} not found or not a Maven project")
                success = False
                continue
            
            print_section(f"Building module: {module}")
            code, stdout, stderr = run_maven(
                project_path=module_path,
                goals=goals,
                args=maven_args
            )
            
            if code != 0:
                print_error(f"Failed to build {module}")
                if stderr:
                    print_error(stderr)
                success = False
                break
            else:
                print_success(f"Successfully built {module}")
        
        return success

    def build_all_tiers(self, goals=None, skip_tests=False):
        goals = goals or ["clean", "install"]
        config = self.get_project_config()
        
        if not config:
            return False
        
        if not config.tiers:
            print_error("No tiers defined in project config")
            return False
        
        sorted_tiers = sorted(config.tiers, key=lambda t: t.order)
        
        print_header(f"Building {len(sorted_tiers)} tiers in order")
        
        for tier in sorted_tiers:
            print_info(f"\n{'='*60}")
            if not self.build_tier(tier.name, goals, skip_tests):
                print_error(f"Build failed at tier: {tier.name}")
                return False
        
        print_success("All tiers built successfully!")
        return True

    def build_modules(self, modules, goals=None, skip_tests=False):
        goals = goals or ["clean", "install"]
        maven_args = []
        if skip_tests:
            maven_args.append("-DskipTests")
        
        print_header(f"Building {len(modules)} modules")
        
        success = True
        for module in modules:
            module_path = self.repo_root / module
            if not (module_path / "pom.xml").exists():
                print_error(f"Module {module} not found or not a Maven project")
                success = False
                continue
            
            print_section(f"Building module: {module}")
            code, stdout, stderr = run_maven(
                project_path=module_path,
                goals=goals,
                args=maven_args
            )
            
            if code != 0:
                print_error(f"Failed to build {module}")
                if stderr:
                    print_error(stderr)
                success = False
                break
            else:
                print_success(f"Successfully built {module}")
        
        return success

    def list_tiers(self):
        config = self.get_project_config()
        
        if not config:
            return False
        
        if not config.tiers:
            print_info("No tiers defined in project config")
            return True
        
        sorted_tiers = sorted(config.tiers, key=lambda t: t.order)
        
        print_header("Tiers:")
        for tier in sorted_tiers:
            print(f"\n  Tier: {tier.name} (order: {tier.order})")
            print(f"  Modules: {len(tier.modules)}")
            for module in tier.modules:
                print(f"    - {module}")
        
        return True
