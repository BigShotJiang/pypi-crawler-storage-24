

from idcu.system.logger import get_logger

from .maven_common import (
    execute_maven_operation_result_error_indicator,
    for_each_maven_operation,
    normalize_projects,
)
from .maven_single import (
    maven_build_parallel,
    maven_clean,
    maven_clean_install,
    maven_clean_local,
    maven_clean_package,
    maven_compile,
    maven_dependency_analyze,
    maven_dependency_conflict,
    maven_dependency_list,
    maven_dependency_tree,
    maven_deploy,
    maven_effective_pom,
    maven_goals,
    maven_install,
    maven_list_profiles,
    maven_package,
    maven_repo_list,
    maven_set_profile,
    maven_test,
    maven_timeline,
)

logger = get_logger("maven_multi")


def maven_clean_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_clean(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_compile_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_compile(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_test_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_test(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_package_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_package(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_install_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_install(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_deploy_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_deploy(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_goals_multi(goals, projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_goals(
            goals,
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_clean_install_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_clean_install(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_clean_package_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_clean_package(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_dependency_tree_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_dependency_tree(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_dependency_list_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_dependency_list(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_dependency_analyze_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_dependency_analyze(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_dependency_conflict_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_dependency_conflict(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_effective_pom_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_effective_pom(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_set_profile_multi(projects=None, profile=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_set_profile(
            project_path=project_path,
            profile=profile,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_list_profiles_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_list_profiles(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_repo_list_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_repo_list(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_clean_local_multi(projects=None, local_repo=None, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_clean_local(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_timeline_multi(projects=None, local_repo=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_timeline(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_build_parallel_multi(projects=None, local_repo=None, threads=None, skip_tests=False, args=None):
    project_list = normalize_projects(projects)

    def operation(project_path):
        return maven_build_parallel(
            project_path=project_path,
            local_repo=local_repo,
            threads=threads,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )
