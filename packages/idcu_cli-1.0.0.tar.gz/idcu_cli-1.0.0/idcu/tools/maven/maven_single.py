

from dataclasses import dataclass
from pathlib import Path

from idcu.core import print_error, print_header, print_success
from idcu.system.logger import get_logger

from .maven_ops import run_maven_checked

logger = get_logger("maven_single")


@dataclass
class MavenOperationResult:
    success: bool
    message: str
    details: dict = None


def maven_clean(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Clean: {project_name}")

    success, stdout, stderr = run_maven_checked(project_path, ["clean"], local_repo, args)

    if success:
        print_success("Clean successful")
        return MavenOperationResult(True, "Clean successful", {"output": stdout})
    else:
        print_error(f"Clean failed: {stderr}")
        return MavenOperationResult(False, f"Clean failed: {stderr}")


def maven_compile(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Compile: {project_name}")

    success, stdout, stderr = run_maven_checked(project_path, ["compile"], local_repo, args)

    if success:
        print_success("Compile successful")
        return MavenOperationResult(True, "Compile successful", {"output": stdout})
    else:
        print_error(f"Compile failed: {stderr}")
        return MavenOperationResult(False, f"Compile failed: {stderr}")


def maven_test(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Test: {project_name}")

    success, stdout, stderr = run_maven_checked(project_path, ["test"], local_repo, args)

    if success:
        print_success("Test successful")
        return MavenOperationResult(True, "Test successful", {"output": stdout})
    else:
        print_error(f"Test failed: {stderr}")
        return MavenOperationResult(False, f"Test failed: {stderr}")


def maven_package(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Package: {project_name}")

    goals = ["package"]
    if skip_tests:
        goals.append("-DskipTests")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Package successful")
        return MavenOperationResult(True, "Package successful", {"output": stdout})
    else:
        print_error(f"Package failed: {stderr}")
        return MavenOperationResult(False, f"Package failed: {stderr}")


def maven_install(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Install: {project_name}")

    goals = ["install"]
    if skip_tests:
        goals.append("-DskipTests")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Install successful")
        return MavenOperationResult(True, "Install successful", {"output": stdout})
    else:
        print_error(f"Install failed: {stderr}")
        return MavenOperationResult(False, f"Install failed: {stderr}")


def maven_deploy(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Deploy: {project_name}")

    goals = ["deploy"]
    if skip_tests:
        goals.append("-DskipTests")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Deploy successful")
        return MavenOperationResult(True, "Deploy successful", {"output": stdout})
    else:
        print_error(f"Deploy failed: {stderr}")
        return MavenOperationResult(False, f"Deploy failed: {stderr}")


def maven_goals(goals, project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Maven Goals: {project_name} - {', '.join(goals)}")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Maven operation successful")
        return MavenOperationResult(True, "Maven operation successful", {"output": stdout})
    else:
        print_error(f"Maven operation failed: {stderr}")
        return MavenOperationResult(False, f"Maven operation failed: {stderr}")


def maven_clean_install(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Clean Install Workflow: {project_name}")

    goals = ["clean", "install"]
    if skip_tests:
        goals.append("-DskipTests")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Clean Install successful")
        return MavenOperationResult(True, "Clean Install successful", {"output": stdout})
    else:
        print_error(f"Clean Install failed: {stderr}")
        return MavenOperationResult(False, f"Clean Install failed: {stderr}")


def maven_clean_package(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Clean Package Workflow: {project_name}")

    goals = ["clean", "package"]
    if skip_tests:
        goals.append("-DskipTests")

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Clean Package successful")
        return MavenOperationResult(True, "Clean Package successful", {"output": stdout})
    else:
        print_error(f"Clean Package failed: {stderr}")
        return MavenOperationResult(False, f"Clean Package failed: {stderr}")


def maven_dependency_tree(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Dependency Tree: {project_name}")

    goals = ["dependency:tree"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Dependency tree analysis successful")
        return MavenOperationResult(True, "Dependency tree analysis successful", {"output": stdout, "tree": stdout})
    else:
        print_error(f"Dependency tree analysis failed: {stderr}")
        return MavenOperationResult(False, f"Dependency tree analysis failed: {stderr}")


def maven_dependency_list(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Dependency List: {project_name}")

    goals = ["dependency:list"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Dependency list retrieved successfully")
        return MavenOperationResult(True, "Dependency list retrieved successfully", {"output": stdout, "dependencies": stdout})
    else:
        print_error(f"Dependency list retrieval failed: {stderr}")
        return MavenOperationResult(False, f"Dependency list retrieval failed: {stderr}")


def maven_dependency_analyze(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Dependency Analyze: {project_name}")

    goals = ["dependency:analyze"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Dependency analysis successful")
        return MavenOperationResult(True, "Dependency analysis successful", {"output": stdout, "analysis": stdout})
    else:
        print_error(f"Dependency analysis failed: {stderr}")
        return MavenOperationResult(False, f"Dependency analysis failed: {stderr}")


def maven_dependency_conflict(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Dependency Conflict Check: {project_name}")

    goals = ["dependency:tree", "-Dverbose"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Dependency conflict check complete")
        return MavenOperationResult(True, "Dependency conflict check complete", {"output": stdout, "conflicts": stdout})
    else:
        print_error(f"Dependency conflict check failed: {stderr}")
        return MavenOperationResult(False, f"Dependency conflict check failed: {stderr}")


def maven_effective_pom(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Effective POM: {project_name}")

    goals = ["help:effective-pom"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Effective POM retrieved successfully")
        return MavenOperationResult(True, "Effective POM retrieved successfully", {"output": stdout, "pom": stdout})
    else:
        print_error(f"Effective POM retrieval failed: {stderr}")
        return MavenOperationResult(False, f"Effective POM retrieval failed: {stderr}")


def maven_set_profile(project_path=None, profile=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Set Profile: {project_name} -> {profile if profile else 'default'}")

    if profile:
        if args is None:
            args = []
        args.insert(0, f"-P{profile}")

    goals = ["validate"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success(f"Profile {profile if profile else 'default'} set successfully")
        return MavenOperationResult(True, f"Profile {profile if profile else 'default'} set successfully", {"output": stdout, "profile": profile})
    else:
        print_error(f"Profile set failed: {stderr}")
        return MavenOperationResult(False, f"Profile set failed: {stderr}")


def maven_list_profiles(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"List Profiles: {project_name}")

    goals = ["help:all-profiles"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Profiles list retrieved successfully")
        return MavenOperationResult(True, "Profiles list retrieved successfully", {"output": stdout, "profiles": stdout})
    else:
        print_error(f"Profiles list retrieval failed: {stderr}")
        return MavenOperationResult(False, f"Profiles list retrieval failed: {stderr}")


def maven_repo_list(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Repository Configuration: {project_name}")

    goals = ["help:effective-settings"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Repository configuration retrieved successfully")
        return MavenOperationResult(True, "Repository configuration retrieved successfully", {"output": stdout, "repos": stdout})
    else:
        print_error(f"Repository configuration retrieval failed: {stderr}")
        return MavenOperationResult(False, f"Repository configuration retrieval failed: {stderr}")


def maven_clean_local(project_path=None, local_repo=None, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Clean Local Repository: {project_name}")

    goals = ["dependency:purge-local-repository"]
    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Local repository cleaned successfully")
        return MavenOperationResult(True, "Local repository cleaned successfully", {"output": stdout})
    else:
        print_error(f"Local repository cleaning failed: {stderr}")
        return MavenOperationResult(False, f"Local repository cleaning failed: {stderr}")


def maven_timeline(project_path=None, local_repo=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name
    print_header(f"Build Performance Monitor: {project_name}")

    goals = ["validate"]
    if args is None:
        args = []
    args.extend(["-Dmaven.build.timestamp.format=yyyy-MM-dd'T'HH:mm:ss.SSSZ", "-X"])

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print(stdout)
        print_success("Build performance monitoring complete")
        return MavenOperationResult(True, "Build performance monitoring complete", {"output": stdout})
    else:
        print_error(f"Build performance monitoring failed: {stderr}")
        return MavenOperationResult(False, f"Build performance monitoring failed: {stderr}")


def maven_build_parallel(project_path=None, local_repo=None, threads=None, skip_tests=False, args=None):
    if project_path is None:
        project_path = Path.cwd()
    project_name = project_path.name

    thread_count = threads or "1C"
    print_header(f"Parallel Build: {project_name} (threads={thread_count})")

    goals = ["clean", "install"]
    if skip_tests:
        goals.append("-DskipTests")

    if args is None:
        args = []
    args.extend([f"-T{thread_count}"])

    success, stdout, stderr = run_maven_checked(project_path, goals, local_repo, args)

    if success:
        print_success("Parallel build successful")
        return MavenOperationResult(True, "Parallel build successful", {"output": stdout})
    else:
        print_error(f"Parallel build failed: {stderr}")
        return MavenOperationResult(False, f"Parallel build failed: {stderr}")
