

from pathlib import Path

from idcu.core import print_error


def is_valid_maven_project(project_path):
    project_path = Path(project_path)
    return (project_path / "pom.xml").exists()


def validate_maven_project(project_path):
    project_path = Path(project_path)
    if not is_valid_maven_project(project_path):
        print_error(f"Project does not exist or is not a valid Maven project: {project_path}")
        return False
    return True


def normalize_projects(projects=None):
    if projects is None:
        return [Path.cwd()]
    elif isinstance(projects, (str, Path)):
        return [Path(projects)]
    else:
        return [Path(r) for r in projects]


def for_each_maven_operation(projects, operation, error_indicator, parallel=True, max_workers=None):
    has_error = False
    for project_path in projects:
        if not validate_maven_project(project_path):
            has_error = True
            continue
        result = operation(project_path)
        if error_indicator(result):
            has_error = True
    return 1 if has_error else 0


def execute_maven_operation_result_error_indicator(result):
    return not result.success
