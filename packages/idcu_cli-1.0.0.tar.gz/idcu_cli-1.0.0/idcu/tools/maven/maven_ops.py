

import os
import shutil
import subprocess
from pathlib import Path

from idcu.core import MAVEN_REPO_LOCAL_PREFIX
from idcu.core.encoding_utils import detect_encoding_with_fallback
from idcu.system.config_manager import get_config_manager
from idcu.system.logger import get_logger

logger = get_logger("maven_ops")


def _smart_decode(data):
    if not data:
        return ""

    try:
        encoding, confidence = detect_encoding_with_fallback(data)
        if encoding:
            try:
                return data.decode(encoding, errors="strict")
            except UnicodeDecodeError:
                logger.debug(f"Decoding with {encoding} failed, using fallback")
    except Exception as e:
        logger.debug(f"Encoding detection failed: {e}")

    common_encodings = ['utf-8', 'gbk', 'gb18030', 'latin-1']
    for encoding in common_encodings:
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue

    logger.warning("All encoding attempts failed, using replace mode")
    return data.decode('utf-8', errors='replace')


def _find_maven_executable():
    maven_names = ["mvn", "mvn.cmd", "mvn.bat"]

    for name in maven_names:
        path = shutil.which(name)
        if path:
            return path

    if os.name == "nt":
        possible_paths = [
            r"D:\os\run\maven",
            r"C:\Program Files\Maven",
            r"C:\Program Files (x86)\Maven",
            os.path.expanduser(r"~\scoop\apps\maven"),
        ]

        for base_path in possible_paths:
            for name in maven_names:
                full_path = os.path.join(base_path, "bin", name)
                if os.path.exists(full_path):
                    return full_path

    raise FileNotFoundError(
        "Maven not found in PATH. Please install Maven or add it to your PATH environment variable."
    )


def run_maven(project_path, goals, local_repo=None, args=None, suppress_warning=False):
    try:
        maven_exec = _find_maven_executable()
        logger.debug(f"Using Maven executable: {maven_exec}")
    except FileNotFoundError as e:
        logger.error(f"Maven not found: {e}")
        return -1, "", str(e)

    cmd = [maven_exec]

    if local_repo:
        local_repo = Path(local_repo)
        local_repo.mkdir(parents=True, exist_ok=True)
        cmd.append(f"{MAVEN_REPO_LOCAL_PREFIX}{local_repo.resolve()}")

    config_manager = get_config_manager()
    if config_manager.get("maven", "offline_mode", False):
        cmd.append("-o")
    elif args and ("-o" in args or "--offline" in args):
        cmd.append("-o")
        args = [a for a in args if a not in ("-o", "--offline")]

    cmd.extend(goals)

    if args:
        cmd.extend(args)

    logger.debug(f"Running Maven command: {' '.join(cmd)} in {project_path}")

    try:
        result = subprocess.run(cmd, cwd=str(project_path), capture_output=True)
        stdout = _smart_decode(result.stdout)
        stderr = _smart_decode(result.stderr)

        if result.returncode != 0 and not suppress_warning:
            logger.warning(f"Maven command failed: {' '.join(cmd)} - {stderr}")

        return result.returncode, stdout, stderr
    except Exception as exc:
        logger.error(f"Error running Maven command: {' '.join(cmd)} - {exc}")
        return -1, "", str(exc)


def get_maven_project_paths(repo_root):
    repo_root = Path(repo_root)
    project_paths = []

    def find_poms(directory):
        if (directory / "pom.xml").exists():
            project_paths.append(directory)
        for item in directory.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                find_poms(item)

    find_poms(repo_root)
    return project_paths


def get_project_name(repo_root, project_path):
    repo_root = Path(repo_root)
    project_path = Path(project_path)
    return "." if project_path == repo_root else str(project_path.relative_to(repo_root))


def for_each_maven_project(repo_root, operation, projects=None):
    repo_root = Path(repo_root)
    all_projects = get_maven_project_paths(repo_root)

    if projects:
        target_projects = []
        if isinstance(projects, str):
            projects = [projects]

        for project_name in projects:
            found = False
            for project_path in all_projects:
                proj_name = get_project_name(repo_root, project_path)
                if proj_name == project_name or (project_path.name == project_name):
                    target_projects.append(project_path)
                    found = True
                    break
            if not found:
                logger.warning(f"Project '{project_name}' not found")
    else:
        target_projects = all_projects

    has_error = False
    for project_path in target_projects:
        project_name = get_project_name(repo_root, project_path)
        result = operation(project_path, project_name)
        if result is not None and result != 0:
            has_error = True
    return 1 if has_error else 0


def list_available_maven_projects(repo_root):
    repo_root = Path(repo_root)
    return [get_project_name(repo_root, path) for path in get_maven_project_paths(repo_root)]


def run_maven_checked(project_path, goals, local_repo=None, args=None, description="Maven operation"):
    code, stdout, stderr = run_maven(project_path, goals, local_repo, args)
    return code == 0, stdout, stderr
