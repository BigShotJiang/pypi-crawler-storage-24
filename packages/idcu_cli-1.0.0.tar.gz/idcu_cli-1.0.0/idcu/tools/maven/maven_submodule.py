
from pathlib import Path

from idcu.system.logger import get_logger

from .maven_common import (
    execute_maven_operation_result_error_indicator,
    for_each_maven_operation,
)
from .maven_ops import (
    get_maven_project_paths,
)
from .maven_single import (
    maven_clean,
    maven_clean_install,
    maven_clean_package,
    maven_compile,
    maven_deploy,
    maven_goals,
    maven_install,
    maven_package,
    maven_test,
)

logger = get_logger("maven_submodule")


def get_submodule_projects(repo_root=None):
    if repo_root is None:
        repo_root = Path.cwd()
    return get_maven_project_paths(Path(repo_root))


def maven_clean_submodule(repo_root=None, local_repo=None, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_clean(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_compile_submodule(repo_root=None, local_repo=None, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_compile(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_test_submodule(repo_root=None, local_repo=None, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_test(
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_package_submodule(repo_root=None, local_repo=None, skip_tests=False, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_package(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_install_submodule(repo_root=None, local_repo=None, skip_tests=False, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_install(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_deploy_submodule(repo_root=None, local_repo=None, skip_tests=False, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_deploy(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_goals_submodule(goals, repo_root=None, local_repo=None, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_goals(
            goals,
            project_path=project_path,
            local_repo=local_repo,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_clean_install_submodule(repo_root=None, local_repo=None, skip_tests=False, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_clean_install(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )


def maven_clean_package_submodule(repo_root=None, local_repo=None, skip_tests=False, args=None):
    project_list = get_submodule_projects(repo_root)

    def operation(project_path):
        return maven_clean_package(
            project_path=project_path,
            local_repo=local_repo,
            skip_tests=skip_tests,
            args=args
        )

    return for_each_maven_operation(
        project_list,
        operation,
        execute_maven_operation_result_error_indicator
    )
