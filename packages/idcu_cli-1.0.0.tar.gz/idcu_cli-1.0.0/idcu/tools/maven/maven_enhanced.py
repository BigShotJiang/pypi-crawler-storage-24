
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from idcu.core import (
    ErrorCode,
    OperationResult,
    BatchOperationReport,
    OutputFormatter,
)
from idcu.system.logger import get_logger

from .maven_ops import run_maven_checked
from .maven_single import (
    maven_clean as maven_clean_old,
    maven_compile as maven_compile_old,
    maven_test as maven_test_old,
    maven_package as maven_package_old,
    maven_install as maven_install_old,
    maven_goals as maven_goals_old,
)

logger = get_logger("maven_enhanced")


class MavenEnhancedOperations:
    """增强版Maven操作，支持统一输出格式、dry-run、批量操作报告等"""

    def __init__(self, json_mode: bool = False, dry_run: bool = False):
        self.json_mode = json_mode
        self.dry_run = dry_run
        self.formatter = OutputFormatter(json_mode=json_mode, dry_run=dry_run)

    def _execute_with_timing(
        self, 
        operation_func: Callable, 
        operation_name: str,
        project_name: str,
        *args, 
        **kwargs
    ) -> OperationResult:
        """执行操作并计时"""
        start_time = time.time()
        
        try:
            if self.dry_run:
                result = self._dry_run_operation(operation_name, project_name, *args, **kwargs)
            else:
                result = operation_func(*args, **kwargs)
            
            duration = time.time() - start_time
            
            if hasattr(result, 'success'):
                op_result = OperationResult(
                    success=result.success,
                    message=result.message,
                    details=result.details or {},
                    project=project_name,
                    duration_seconds=duration,
                    dry_run=self.dry_run,
                    error_code=ErrorCode.SUCCESS if result.success else ErrorCode.MAVEN_ERROR_BASE
                )
            else:
                op_result = OperationResult.success_result(
                    message="操作完成",
                    project=project_name,
                    duration_seconds=duration,
                    dry_run=self.dry_run
                )
                
            return op_result
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Operation {operation_name} failed: {e}")
            return OperationResult.error_result(
                error_code=ErrorCode.MAVEN_ERROR_BASE,
                message=str(e),
                project=project_name,
                duration_seconds=duration,
                dry_run=self.dry_run
            )

    def _dry_run_operation(self, func_name: str, project_name: str, *args, **kwargs) -> Any:
        """Dry run模拟操作"""
        logger.info(f"[DRY-RUN] {func_name} on {project_name}")
        from dataclasses import dataclass
        
        @dataclass
        class DryRunResult:
            success: bool = True
            message: str = f"Dry-run: {func_name} 操作已模拟执行"
            details: Dict[str, Any] = None
        
        return DryRunResult(details={"dry_run": True, "operation": func_name})

    def clean(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven clean操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_clean_old(project_path, local_repo, args)
        
        return self._execute_with_timing(op, "clean", project_name)

    def compile(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven compile操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_compile_old(project_path, local_repo, args)
        
        return self._execute_with_timing(op, "compile", project_name)

    def test(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven test操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_test_old(project_path, local_repo, args)
        
        return self._execute_with_timing(op, "test", project_name)

    def package(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        skip_tests: bool = False,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven package操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_package_old(project_path, local_repo, skip_tests, args)
        
        return self._execute_with_timing(op, "package", project_name)

    def install(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        skip_tests: bool = False,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven install操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_install_old(project_path, local_repo, skip_tests, args)
        
        return self._execute_with_timing(op, "install", project_name)

    def validate(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven validate操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            return maven_goals_old(["validate"], project_path, local_repo, args)
        
        return self._execute_with_timing(op, "validate", project_name)

    def verify(
        self,
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        skip_tests: bool = False,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """Maven verify操作"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            goals = ["verify"]
            if skip_tests:
                goals.append("-DskipTests")
            return maven_goals_old(goals, project_path, local_repo, args)
        
        return self._execute_with_timing(op, "verify", project_name)

    def build(
        self,
        goals: List[str],
        project_path: Optional[Path] = None,
        local_repo: Optional[Path] = None,
        args: Optional[List[str]] = None
    ) -> OperationResult:
        """自定义Maven goals构建"""
        if project_path is None:
            project_path = Path.cwd()
        project_name = project_path.name
        
        def op():
            success, stdout, stderr = run_maven_checked(
                project_path, goals, local_repo, args
            )
            from dataclasses import dataclass
            
            @dataclass
            class SimpleResult:
                success: bool
                message: str
                details: Dict[str, Any] = None
            
            if success:
                return SimpleResult(True, f"Maven {' '.join(goals)} 成功", {"output": stdout})
            else:
                return SimpleResult(False, f"Maven {' '.join(goals)} 失败: {stderr}", {"output": stdout, "error": stderr})
        
        return self._execute_with_timing(op, "build", project_name)

    def batch_operation(
        self,
        operation_name: str,
        project_paths: List[Path],
        operation_func: Callable[[Path], OperationResult]
    ) -> BatchOperationReport:
        """执行批量操作并生成报告"""
        report = BatchOperationReport(operation_name=operation_name)
        
        for project_path in project_paths:
            result = operation_func(project_path)
            report.add_result(result)
        
        report.finish()
        return report

    def print_result(self, result: OperationResult):
        """打印单个操作结果"""
        self.formatter.print_result(result)

    def print_batch_report(self, report: BatchOperationReport):
        """打印批量操作报告"""
        self.formatter.print_batch_report(report)
