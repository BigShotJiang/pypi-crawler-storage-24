
from pathlib import Path

from idcu.system.logger import get_logger
from idcu.version import VERSION

try:
    import uvicorn
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.staticfiles import StaticFiles

    from .api import router as api_router
except ImportError:
    uvicorn = None
    FastAPI = None
    CORSMiddleware = None
    StaticFiles = None
    api_router = None

logger = get_logger("web_app")


def create_app():
    if FastAPI is None or api_router is None:
        raise ImportError("Web UI dependencies not installed. Please install with 'pip install idcu-cli[web]'")

    app = FastAPI(
        title="IDCU DevTools Web UI",
        description="IDCU开发工具集 - Web可视化界面",
        version=VERSION,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(api_router, prefix="/api")

    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    @app.get("/")
    async def root():
        return {"message": "IDCU DevTools Web UI", "version": VERSION}

    @app.get("/health")
    async def health_check():
        return {"status": "healthy"}

    return app


def run_server(host="127.0.0.1", port=8000, reload=False):
    if uvicorn is None:
        raise ImportError("Web UI dependencies not installed. Please install with 'pip install idcu-cli[web]'")

    app = create_app()
    logger.info(f"Starting server on {host}:{port}")
    uvicorn.run(
        app,
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


if __name__ == "__main__":
    run_server()
