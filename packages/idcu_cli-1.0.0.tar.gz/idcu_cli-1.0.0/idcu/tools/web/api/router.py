
from fastapi import APIRouter

from . import config, dashboard, git, plugins

router = APIRouter()

router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
router.include_router(config.router, prefix="/config", tags=["config"])
router.include_router(git.router, prefix="/git", tags=["git"])
router.include_router(plugins.router, prefix="/plugins", tags=["plugins"])
