import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class ProjectInfo(BaseModel):
    path: str
    name: str
    type: str
    has_git: bool = False
    has_maven: bool = False


class RecentActivity(BaseModel):
    id: str
    type: str
    message: str
    timestamp: str
    project: Optional[str] = None


class DashboardStats(BaseModel):
    total_projects: int = 0
    git_repositories: int = 0
    maven_projects: int = 0
    active_plugins: int = 0
    recent_activities: List[RecentActivity] = []
    system_info: Dict = {}
    projects: List[ProjectInfo] = []


_activities: List[RecentActivity] = []


def _add_activity(activity_type: str, message: str, project: Optional[str] = None):
    activity = RecentActivity(
        id=str(len(_activities) + 1),
        type=activity_type,
        message=message,
        timestamp=datetime.now().isoformat(),
        project=project
    )
    _activities.insert(0, activity)
    if len(_activities) > 50:
        _activities.pop()


def _scan_projects(base_path: str = ".") -> List[ProjectInfo]:
    projects: List[ProjectInfo] = []
    base_dir = Path(base_path)

    for item in base_dir.iterdir():
        if item.is_dir() and not item.name.startswith('.'):
            project_info = ProjectInfo(
                path=str(item.absolute()),
                name=item.name,
                type="unknown",
                has_git=(item / ".git").exists(),
                has_maven=(item / "pom.xml").exists()
            )

            if project_info.has_maven:
                project_info.type = "maven"
            elif project_info.has_git:
                project_info.type = "git"

            projects.append(project_info)

    return projects


@router.get("/stats", response_model=DashboardStats)
async def get_dashboard_stats():
    import platform

    from idcu.tools.plugins import get_plugin_manager

    pm = get_plugin_manager()
    active_plugins = len([p for p in pm.list_all() if p.enabled])

    system_info = {
        "python_version": platform.python_version(),
        "os": platform.system(),
        "os_version": platform.release(),
        "machine": platform.machine(),
    }

    try:
        projects = _scan_projects()
        git_repos = sum(1 for p in projects if p.has_git)
        maven_projects = sum(1 for p in projects if p.has_maven)
    except Exception:
        projects = []
        git_repos = 0
        maven_projects = 0

    return DashboardStats(
        total_projects=len(projects),
        git_repositories=git_repos,
        maven_projects=maven_projects,
        active_plugins=active_plugins,
        recent_activities=_activities[:20],
        system_info=system_info,
        projects=projects
    )


@router.get("/projects", response_model=List[ProjectInfo])
async def list_projects(path: Optional[str] = "."):
    try:
        return _scan_projects(path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/activities", response_model=List[RecentActivity])
async def list_activities(limit: int = 20):
    return _activities[:limit]


@router.post("/activities")
async def add_activity_endpoint(activity_type: str, message: str, project: Optional[str] = None):
    _add_activity(activity_type, message, project)
    return {"success": True}
