
from pathlib import Path
from typing import Any, Dict

import yaml
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class ConfigUpdate(BaseModel):
    config: Dict[str, Any]


@router.get("/")
async def get_config():
    config_path = Path(".idcu/config.yaml")
    if not config_path.exists():
        return {"config": {}}

    try:
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        return {"config": config}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/")
async def update_config(config_update: ConfigUpdate):
    config_path = Path(".idcu/config.yaml")
    config_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config_update.config, f, allow_unicode=True)
        return {"success": True, "config": config_update.config}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/validate")
async def validate_config():
    config_path = Path(".idcu/config.yaml")
    if not config_path.exists():
        return {"valid": True, "message": "No config file found"}

    try:
        with open(config_path, encoding="utf-8") as f:
            yaml.safe_load(f)
        return {"valid": True, "message": "Config is valid"}
    except Exception as e:
        return {"valid": False, "message": str(e)}


@router.post("/export")
async def export_config():
    config_path = Path(".idcu/config.yaml")
    if not config_path.exists():
        raise HTTPException(status_code=404, detail="Config file not found")

    try:
        with open(config_path, encoding="utf-8") as f:
            content = f.read()
        return {"content": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
