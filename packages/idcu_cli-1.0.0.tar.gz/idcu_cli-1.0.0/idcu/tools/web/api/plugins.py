
from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class PluginInfo(BaseModel):
    name: str
    version: str
    description: str
    author: str
    enabled: bool
    commands: List[str] = []


@router.get("/", response_model=List[PluginInfo])
async def list_plugins():
    from idcu.tools.plugins import get_plugin_manager

    pm = get_plugin_manager()
    plugins_info = []

    for metadata in pm.list_all():
        plugin = pm.get(metadata.name)
        commands = list(plugin.get_commands().keys()) if plugin else []

        plugins_info.append(PluginInfo(
            name=metadata.name,
            version=metadata.version,
            description=metadata.description,
            author=metadata.author,
            enabled=metadata.enabled,
            commands=commands,
        ))

    return plugins_info


@router.get("/{plugin_name}")
async def get_plugin(plugin_name: str):
    from idcu.tools.plugins import get_plugin_manager

    pm = get_plugin_manager()
    plugin = pm.get(plugin_name)

    if not plugin:
        raise HTTPException(status_code=404, detail="Plugin not found")

    return {
        "name": plugin.metadata.name,
        "version": plugin.metadata.version,
        "description": plugin.metadata.description,
        "author": plugin.metadata.author,
        "enabled": plugin.metadata.enabled,
        "commands": list(plugin.get_commands().keys()),
    }


@router.post("/{plugin_name}/execute")
async def execute_plugin_command(plugin_name: str, command: str, args: Dict[str, Any] = {}):
    from idcu.tools.plugins import get_plugin_manager

    pm = get_plugin_manager()
    plugin = pm.get(plugin_name)

    if not plugin:
        raise HTTPException(status_code=404, detail="Plugin not found")

    commands = plugin.get_commands()
    if command not in commands:
        raise HTTPException(status_code=404, detail="Command not found")

    try:
        result = commands[command](**args)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
