
import subprocess
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class GitStatus(BaseModel):
    branch: str
    modified: List[str] = []
    staged: List[str] = []
    untracked: List[str] = []


@router.get("/status")
async def get_git_status(path: Optional[str] = "."):
    work_dir = Path(path)
    if not (work_dir / ".git").exists():
        raise HTTPException(status_code=400, detail="Not a git repository")

    try:
        result = subprocess.run(
            ["git", "status", "--porcelain", "-b"],
            cwd=work_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise HTTPException(status_code=500, detail=result.stderr)

        lines = result.stdout.strip().split("\n")
        branch = lines[0].split("...")[0].replace("## ", "") if lines else ""
        modified = []
        staged = []
        untracked = []

        for line in lines[1:]:
            if line:
                status = line[:2]
                file = line[3:]
                if status == "??":
                    untracked.append(file)
                elif status[0] != " ":
                    staged.append(file)
                elif status[1] != " ":
                    modified.append(file)

        return GitStatus(
            branch=branch,
            modified=modified,
            staged=staged,
            untracked=untracked,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/log")
async def get_git_log(path: Optional[str] = ".", limit: int = 20):
    work_dir = Path(path)
    if not (work_dir / ".git").exists():
        raise HTTPException(status_code=400, detail="Not a git repository")

    try:
        result = subprocess.run(
            ["git", "log", f"-{limit}", "--pretty=format:%h|%an|%ae|%ad|%s", "--date=iso"],
            cwd=work_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise HTTPException(status_code=500, detail=result.stderr)

        commits = []
        for line in result.stdout.strip().split("\n"):
            if line:
                parts = line.split("|", 4)
                if len(parts) == 5:
                    commits.append({
                        "hash": parts[0],
                        "author": parts[1],
                        "email": parts[2],
                        "date": parts[3],
                        "message": parts[4],
                    })

        return {"commits": commits}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
