# IDCU CLI Web UI

Х©≥Ф≤╞ IDCU CLI - Д╦█Г╬│Г⌡÷Е╪─Е▐▒Е╥╔Е┘╥Г └ Web Г■╗Ф┬╥Г∙▄И²╒Ц─?
## Е©╚И─÷Е╪─Е╖?
### 1. Е╝┴Хё┘Д╬²Х╣√

```bash
pip install idcu-cli[web]
```

### 2. Е░╞Е┼╗Ф°█Е┼║Е≥?
#### Д╫©Г■╗ Python Д╩ёГ═│О╪?
```python
from idcu.tools.web import run_server
run_server(host="127.0.0.1", port=8000)
```

#### Ф┬√Г⌡╢Ф▌╔Х©░Х║▄О╪ 

```bash
python -c "from idcu.tools.web import run_server; run_server()"
```

### 3. Х╝©И≈╝Г∙▄И²╒

Ф┴⌠Е╪─Ф╣▐Х╖┬Е≥╗Х╝©И≈╝О╪ http://127.0.0.1:8000

## API Ф√┤Ф║ё

### Е÷╨Г║─Г╚╞Г┌╧

- `GET /` - Ф╛╒Х©▌Д©║Ф│╞
- `GET /health` - Е│╔Е╨╥Фё─Ф÷?
### Д╩╙Х║╗Г⌡?API

- `GET /api/dashboard/stats` - Х▌╥Е▐√Д╩╙Х║╗Г⌡≤Г╩÷Х╝║Ф∙╟Ф█?
### И┘█Г╫╝Г╝║Г░├ API

- `GET /api/config/` - Х▌╥Е▐√И┘█Г╫╝
- `PUT /api/config/` - Ф⌡╢Ф√╟И┘█Г╫╝
- `GET /api/config/validate` - И╙▄Х╞│И┘█Г╫╝
- `POST /api/config/export` - Е╞╪Е┤╨И┘█Г╫╝

### Git Г╝║Г░├ API

- `GET /api/git/status` - Х▌╥Е▐√ Git Г┼╤Ф─?- `GET /api/git/log` - Х▌╥Е▐√ Git Ф≈╔Е©≈

### Ф▐▓Д╩╤Г╝║Г░├ API

- `GET /api/plugins/` - Х▌╥Е▐√Ф▐▓Д╩╤Е┬≈Х║╗
- `GET /api/plugins/{name}` - Х▌╥Е▐√Ф▐▓Д╩╤Х╞╕Ф┐┘
- `POST /api/plugins/{name}/execute` - Ф┴╖Х║▄Ф▐▓Д╩╤Е▒╫Д╩╓

## Ф┼─Ф°╞Ф═┬

- **Е░▌Г╚╞**: FastAPI
- **Е┴█Г╚╞**: Е▌÷Г■÷ HTML/CSS/JavaScript (Е▐╞Ф┴╘Е╠∙Д╦╨ Vue 3)
- **Ф°█Е┼║Е≥?*: Uvicorn

## Е╪─Е▐▒Х╝║Е┬?
Ф═╧Ф█╝ DEVELOPMENT_PLAN.mdО╪▄v1.7.0 И≤╤Ф╝╣Х©≤Е▄┘Ф▀╛О╪ 

- [x] Web Ф°█Е┼║Ф║├Ф·╤Ф░╜Е╩╨
- [x] И║╧Г⌡╝Д╩╙Х║╗Г⌡?API
- [x] И┘█Г╫╝Г╝║Г░├ API
- [x] Git Г╝║Г░├ API
- [x] Ф▐▓Д╩╤Г╝║Г░├ API
- [ ] Git Е▌├Е▐╡Е▐╞Х╖├Е▄√О╪┬Е┴█Г╚╞О╪?- [ ] Ф·└Е╩╨Г┼╤Ф─│Г⌡▒Ф▌?- [ ] Е⌠█Е╨■Е╪▐Х╝╬Х╝║О╪┬Vue 3 Г┴┬Ф°╛О╪?
