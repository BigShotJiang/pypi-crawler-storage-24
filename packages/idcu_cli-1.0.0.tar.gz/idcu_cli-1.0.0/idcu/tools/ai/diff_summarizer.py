import os
import subprocess
from typing import Optional

from .base import AIProvider, Message
from .ollama_provider import OllamaProvider
from .openai_provider import OpenAIProvider


class DiffSummarizer:
    def __init__(self, provider: Optional[AIProvider] = None):
        self.provider = provider
        self._init_default_provider()

    def _init_default_provider(self):
        if self.provider:
            return

        if os.environ.get("OPENAI_API_KEY"):
            self.provider = OpenAIProvider()
        elif os.environ.get("OLLAMA_BASE_URL") or os.path.exists(os.path.expanduser("~/.ollama")):
            self.provider = OllamaProvider()

    def get_git_diff(self, commit_hash: Optional[str] = None, staged_only: bool = False) -> str:
        cmd = ["git", "diff"]
        if commit_hash:
            cmd.append(f"{commit_hash}^!")
        elif staged_only:
            cmd.append("--cached")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to get git diff: {e.stderr}")

    def summarize_diff(self, diff: Optional[str] = None, commit_hash: Optional[str] = None,
                      staged_only: bool = False, language: str = "zh") -> str:
        if not self.provider:
            raise RuntimeError("No AI provider available. Please set OPENAI_API_KEY or OLLAMA_BASE_URL environment variables.")

        if diff is None:
            diff = self.get_git_diff(commit_hash=commit_hash, staged_only=staged_only)

        if not diff:
            raise RuntimeError("No changes found in git diff.")

        system_prompt = """You are a helpful assistant that provides comprehensive summaries of code changes.

When summarizing a diff:
1. Identify the main purpose of the changes
2. List key modifications with file locations
3. Highlight breaking changes if any
4. Note any important architectural changes
5. Keep the summary clear, concise, and well-structured
6. Use bullet points for clarity
7. Focus on what changed and why"""

        if language == "zh":
            system_prompt = """你是一个帮助提供代码变更全面摘要的助手。
在总结 diff 时：
1. 确定变更的主要目的
2. 列出关键修改及文件位置
3. 突出显示任何破坏性变更
4. 注意任何重要的架构变更
5. 保持摘要清晰、简洁且结构良好
6. 使用项目符号提高清晰度
7. 重点关注变更的内容和原因"""

        user_prompt = f"""Please provide a comprehensive summary of the following code changes:

```diff
{diff}
```"""

        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]

        return self.provider.chat(messages, max_tokens=1000, temperature=0.5)
