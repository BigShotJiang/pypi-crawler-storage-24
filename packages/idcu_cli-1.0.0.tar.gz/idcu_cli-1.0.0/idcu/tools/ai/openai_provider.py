import os
from typing import List, Optional

from .base import AIProvider, AIProviderError, AIProviderAPIError, AIProviderConfigError, Message


class OpenAIProvider(AIProvider):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, model: Optional[str] = None):
        api_key = api_key or os.environ.get("OPENAI_API_KEY")
        base_url = base_url or os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")
        model = model or os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        super().__init__(api_key=api_key, base_url=base_url, model=model)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import openai
                self._client = openai.OpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url
                )
            except ImportError:
                raise AIProviderConfigError("OpenAI 库未安装，请运行: pip install openai")
        return self._client

    def chat(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None) -> str:
        if not self.api_key:
            raise AIProviderConfigError("OpenAI API 密钥未配置")

        client = self._get_client()
        max_tokens = max_tokens or self.default_max_tokens
        temperature = temperature or self.default_temperature

        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=[msg.to_dict() for msg in messages],
                max_tokens=max_tokens,
                temperature=temperature
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise AIProviderAPIError(f"OpenAI API 调用失败: {str(e)}")

    def chat_stream(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None):
        if not self.api_key:
            raise AIProviderConfigError("OpenAI API 密钥未配置")

        client = self._get_client()
        max_tokens = max_tokens or self.default_max_tokens
        temperature = temperature or self.default_temperature

        try:
            stream = client.chat.completions.create(
                model=self.model,
                messages=[msg.to_dict() for msg in messages],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True
            )
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            raise AIProviderAPIError(f"OpenAI API 流式调用失败: {str(e)}")

    def get_available_models(self) -> List[str]:
        if not self.api_key:
            raise AIProviderConfigError("OpenAI API 密钥未配置")

        client = self._get_client()
        try:
            models = client.models.list()
            return [model.id for model in models.data]
        except Exception as e:
            raise AIProviderAPIError(f"获取 OpenAI 模型列表失败: {str(e)}")

    def is_available(self) -> bool:
        if not self.api_key:
            return False
        try:
            self._get_client()
            return True
        except Exception:
            return False
