import os
from typing import List, Optional

from .base import AIProvider, AIProviderError, AIProviderAPIError, AIProviderConfigError, Message


class OllamaProvider(AIProvider):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, model: Optional[str] = None):
        base_url = base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
        model = model or os.environ.get("OLLAMA_MODEL", "llama3.1")
        super().__init__(api_key=api_key, base_url=base_url, model=model)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import ollama
                self._client = ollama.Client(host=self.base_url)
            except ImportError:
                raise AIProviderConfigError("Ollama 库未安装，请运行: pip install ollama")
        return self._client

    def chat(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None) -> str:
        client = self._get_client()
        temperature = temperature or self.default_temperature

        try:
            options = {}
            if temperature is not None:
                options["temperature"] = temperature
            if max_tokens is not None:
                options["num_predict"] = max_tokens

            response = client.chat(
                model=self.model,
                messages=[msg.to_dict() for msg in messages],
                options=options,
                stream=False
            )
            return response["message"]["content"].strip()
        except Exception as e:
            raise AIProviderAPIError(f"Ollama API 调用失败: {str(e)}")

    def chat_stream(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None):
        client = self._get_client()
        temperature = temperature or self.default_temperature

        try:
            options = {}
            if temperature is not None:
                options["temperature"] = temperature
            if max_tokens is not None:
                options["num_predict"] = max_tokens

            stream = client.chat(
                model=self.model,
                messages=[msg.to_dict() for msg in messages],
                options=options,
                stream=True
            )
            for chunk in stream:
                if chunk["message"]["content"]:
                    yield chunk["message"]["content"]
        except Exception as e:
            raise AIProviderAPIError(f"Ollama API 流式调用失败: {str(e)}")

    def get_available_models(self) -> List[str]:
        client = self._get_client()
        try:
            models = client.list()
            return [model["name"] for model in models["models"]]
        except Exception as e:
            raise AIProviderAPIError(f"获取 Ollama 模型列表失败: {str(e)}")

    def is_available(self) -> bool:
        try:
            client = self._get_client()
            client.list()
            return True
        except Exception:
            return False
