import os
import subprocess
from typing import Optional

from .base import AIProvider, Message
from .ollama_provider import OllamaProvider
from .openai_provider import OpenAIProvider


class CommitGenerator:
    def __init__(self, provider: Optional[AIProvider] = None):
        self.provider = provider
        self._init_default_provider()

    def _init_default_provider(self):
        if self.provider:
            return

        if os.environ.get("OPENAI_API_KEY"):
            self.provider = OpenAIProvider()
        elif os.environ.get("OLLAMA_BASE_URL") or os.path.exists(os.path.expanduser("~/.ollama")):
            self.provider = OllamaProvider()

    def get_git_diff(self, staged_only: bool = True) -> str:
        cmd = ["git", "diff"]
        if staged_only:
            cmd.append("--cached")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to get git diff: {e.stderr}")

    def generate_commit_message(self, diff: Optional[str] = None, staged_only: bool = True, language: str = "zh") -> str:
        if not self.provider:
            raise RuntimeError("No AI provider available. Please set OPENAI_API_KEY or OLLAMA_BASE_URL environment variables.")

        if diff is None:
            diff = self.get_git_diff(staged_only=staged_only)

        if not diff:
            raise RuntimeError("No changes found in git diff.")

        system_prompt = """You are a helpful assistant that generates clear, concise git commit messages following the Conventional Commits specification.

Conventional Commits format:
<type>(<scope>): <description>

[optional body]

[optional footer(s)]

Types:
- feat: New feature
- fix: Bug fix
- docs: Documentation changes
- style: Code style changes
- refactor: Refactoring
- test: Test changes
- chore: Build/tooling changes

Rules:
- Keep the subject line under 50 characters
- Use imperative mood (e.g., "Add feature" not "Added feature")
- Be specific and descriptive
- Use bullet points in the body for multiple changes
- Only return the commit message, no additional text"""

        if language == "zh":
            system_prompt = """你是一个帮助生成清晰简洁的 git 提交信息的助手，遵循 Conventional Commits 规范。
Conventional Commits 格式：<type>(<scope>): <description>

[可选的正文]

[可选的页脚]

类型：
- feat: 新功能
- fix: 修复 bug
- docs: 文档变更
- style: 代码风格变更
- refactor: 重构
- test: 测试变更
- chore: 构建/工具变更

规则：
- 标题行保持在 50 个字符以内
- 使用祈使语气（例如，"Add feature" 而不是 "Added feature"）
- 具体且具有描述性
- 正文中使用项目符号列出多个变更
- 只返回提交信息，不要有额外的文本"""

        user_prompt = f"""Please generate a git commit message for the following diff:

```diff
{diff}
```"""

        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]

        return self.provider.chat(messages, max_tokens=500, temperature=0.3)
