from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class Message:
    def __init__(self, role: str, content: str):
        self.role = role
        self.content = content

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}

    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> "Message":
        return cls(role=data["role"], content=data["content"])


class AIProvider(ABC):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.default_max_tokens = 2048
        self.default_temperature = 0.7

    @abstractmethod
    def chat(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None) -> str:
        pass

    @abstractmethod
    def chat_stream(self, messages: List[Message], max_tokens: Optional[int] = None, temperature: Optional[float] = None):
        pass

    @abstractmethod
    def get_available_models(self) -> List[str]:
        pass

    @abstractmethod
    def is_available(self) -> bool:
        pass

    def get_provider_name(self) -> str:
        return self.__class__.__name__.replace("Provider", "")


class AIProviderError(Exception):
    pass


class AIProviderConfigError(AIProviderError):
    pass


class AIProviderAPIError(AIProviderError):
    pass


class AIProviderNotFoundError(AIProviderError):
    pass
