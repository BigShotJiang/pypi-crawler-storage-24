from pathlib import Path
from typing import List, Optional, Type

from .base import BuildTool
from .golang import GoBuildTool
from .npm import NPMBuildTool
from .python import PythonBuildTool
from .rust import RustBuildTool


class ProjectDetector:
    def __init__(self, project_path: Optional[str] = None):
        self.project_path = Path(project_path or ".")
        self._tool_classes = [
            (NPMBuildTool, ["npm", "yarn", "pnpm"]),
            (PythonBuildTool, ["pip", "poetry"]),
            (GoBuildTool, ["go"]),
            (RustBuildTool, ["cargo"]),
        ]

    def detect_all_tools(self) -> List[BuildTool]:
        available_tools = []

        for tool_class, _ in self._tool_classes:
            tool = tool_class(str(self.project_path))
            if tool.detect_project():
                available_tools.append(tool)

        return available_tools

    def detect_primary_tool(self) -> Optional[BuildTool]:
        tools = self.detect_all_tools()
        return tools[0] if tools else None

    def get_available_build_tools(self) -> List[Type[BuildTool]]:
        return [cls for cls, _ in self._tool_classes]


class UnifiedBuilder:
    def __init__(self, project_path: Optional[str] = None):
        self.project_path = Path(project_path or ".")
        self.detector = ProjectDetector(str(self.project_path))

    def auto_build(self) -> bool:
        tool = self.detector.detect_primary_tool()
        if not tool:
            return False

        result = tool.install_dependencies()
        if not result:
            return False

        result = tool.build()
        return bool(result)

    def auto_test(self) -> bool:
        tool = self.detector.detect_primary_tool()
        if not tool:
            return False

        result = tool.test()
        return bool(result)

    def auto_clean(self) -> bool:
        tool = self.detector.detect_primary_tool()
        if not tool:
            return False

        result = tool.clean()
        return bool(result)
