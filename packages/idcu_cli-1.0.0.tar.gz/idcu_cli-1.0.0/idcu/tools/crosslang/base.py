import subprocess
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional


class BuildResult:
    def __init__(self, success: bool, output: str = "", error: str = "", return_code: int = 0):
        self.success = success
        self.output = output
        self.error = error
        self.return_code = return_code

    def __bool__(self):
        return self.success


class Dependency:
    def __init__(self, name: str, version: Optional[str] = None, scope: Optional[str] = None):
        self.name = name
        self.version = version
        self.scope = scope

    def to_dict(self) -> Dict[str, Any]:
        result = {"name": self.name}
        if self.version:
            result["version"] = self.version
        if self.scope:
            result["scope"] = self.scope
        return result


class BuildTool(ABC):
    def __init__(self, project_path: Optional[str] = None):
        self.project_path = Path(project_path or ".")

    @abstractmethod
    def is_available(self) -> bool:
        pass

    @abstractmethod
    def detect_project(self) -> bool:
        pass

    @abstractmethod
    def install_dependencies(self) -> BuildResult:
        pass

    @abstractmethod
    def build(self) -> BuildResult:
        pass

    @abstractmethod
    def test(self) -> BuildResult:
        pass

    @abstractmethod
    def clean(self) -> BuildResult:
        pass

    @abstractmethod
    def get_dependencies(self) -> List[Dependency]:
        pass

    @abstractmethod
    def add_dependency(self, name: str, version: Optional[str] = None, scope: Optional[str] = None) -> BuildResult:
        pass

    @abstractmethod
    def remove_dependency(self, name: str) -> BuildResult:
        pass

    def _run_command(self, cmd: List[str], cwd: Optional[Path] = None) -> BuildResult:
        cwd = cwd or self.project_path
        try:
            result = subprocess.run(
                cmd,
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=300
            )
            return BuildResult(
                success=result.returncode == 0,
                output=result.stdout,
                error=result.stderr,
                return_code=result.returncode
            )
        except subprocess.TimeoutExpired:
            return BuildResult(
                success=False,
                error="Command timed out after 300 seconds",
                return_code=-1
            )
        except Exception as e:
            return BuildResult(
                success=False,
                error=str(e),
                return_code=-1
            )
