from typing import List, Optional

from .base import BuildResult, BuildTool, Dependency


class PythonBuildTool(BuildTool):
    def __init__(self, project_path: Optional[str] = None, build_tool: str = "pip"):
        super().__init__(project_path)
        self.build_tool = build_tool
        self._validate_build_tool()

    def _validate_build_tool(self):
        valid_tools = ["pip", "poetry"]
        if self.build_tool not in valid_tools:
            raise ValueError(f"Invalid build tool: {self.build_tool}. Must be one of {valid_tools}")

    def is_available(self) -> bool:
        try:
            if self.build_tool == "pip":
                result = self._run_command(["pip", "--version"])
            else:
                result = self._run_command(["poetry", "--version"])
            return result.success
        except Exception:
            return False

    def detect_project(self) -> bool:
        if self.build_tool == "poetry":
            return (self.project_path / "pyproject.toml").exists()
        else:
            return (self.project_path / "requirements.txt").exists() or (self.project_path / "setup.py").exists() or (self.project_path / "pyproject.toml").exists()

    def install_dependencies(self) -> BuildResult:
        if self.build_tool == "poetry":
            return self._run_command(["poetry", "install"])
        else:
            requirements = self.project_path / "requirements.txt"
            if requirements.exists():
                return self._run_command(["pip", "install", "-r", "requirements.txt"])
            else:
                return BuildResult(True, output="No requirements.txt found, skipping install")

    def build(self) -> BuildResult:
        if self.build_tool == "poetry":
            return self._run_command(["poetry", "build"])
        else:
            setup_py = self.project_path / "setup.py"
            pyproject_toml = self.project_path / "pyproject.toml"
            if setup_py.exists():
                return self._run_command(["python", "setup.py", "sdist", "bdist_wheel"])
            elif pyproject_toml.exists():
                return self._run_command(["python", "-m", "build"])
            else:
                return BuildResult(True, output="No build configuration found, skipping build")

    def test(self) -> BuildResult:
        if self.build_tool == "poetry":
            return self._run_command(["poetry", "run", "pytest"])
        else:
            return self._run_command(["python", "-m", "pytest"])

    def clean(self) -> BuildResult:
        dirs_to_clean = ["build", "dist", ".pytest_cache", "__pycache__"]
        for dir_name in dirs_to_clean:
            dir_path = self.project_path / dir_name
            if dir_path.exists():
                import shutil
                shutil.rmtree(dir_path)

        for egg_dir in self.project_path.glob("*.egg-info"):
            if egg_dir.exists():
                import shutil
                shutil.rmtree(egg_dir)

        return BuildResult(True, output="Cleaned build artifacts")

    def get_dependencies(self) -> List[Dependency]:
        dependencies = []

        if self.build_tool == "poetry":
            pyproject = self.project_path / "pyproject.toml"
            if not pyproject.exists():
                return dependencies

            try:
                import toml
                with open(pyproject, encoding="utf-8") as f:
                    data = toml.load(f)

                tool_poetry = data.get("tool", {}).get("poetry", {})
                for dep_type in ["dependencies", "dev-dependencies"]:
                    if dep_type in tool_poetry:
                        scope = "dev" if dep_type == "dev-dependencies" else None
                        deps = tool_poetry[dep_type]
                        for name, version in deps.items():
                            if name == "python":
                                continue
                            if isinstance(version, dict):
                                version = version.get("version", "")
                            dependencies.append(Dependency(name=name, version=version, scope=scope))
            except ImportError:
                pass
        else:
            requirements = self.project_path / "requirements.txt"
            if requirements.exists():
                with open(requirements, encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "==" in line:
                                name, version = line.split("==", 1)
                                dependencies.append(Dependency(name=name.strip(), version=version.strip()))
                            else:
                                dependencies.append(Dependency(name=line))

        return dependencies

    def add_dependency(self, name: str, version: Optional[str] = None, scope: Optional[str] = None) -> BuildResult:
        if self.build_tool == "poetry":
            cmd = ["poetry", "add"]
            if scope == "dev":
                cmd.append("--dev")
            pkg = name if not version else f"{name}=={version}"
            cmd.append(pkg)
            return self._run_command(cmd)
        else:
            pkg = name if not version else f"{name}=={version}"
            return self._run_command(["pip", "install", pkg])

    def remove_dependency(self, name: str) -> BuildResult:
        if self.build_tool == "poetry":
            return self._run_command(["poetry", "remove", name])
        else:
            return self._run_command(["pip", "uninstall", "-y", name])
