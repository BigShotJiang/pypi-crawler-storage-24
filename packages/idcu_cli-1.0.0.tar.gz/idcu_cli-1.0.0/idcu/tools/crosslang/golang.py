from typing import List, Optional

from .base import BuildResult, BuildTool, Dependency


class GoBuildTool(BuildTool):
    def __init__(self, project_path: Optional[str] = None):
        super().__init__(project_path)

    def is_available(self) -> bool:
        try:
            result = self._run_command(["go", "version"])
            return result.success
        except Exception:
            return False

    def detect_project(self) -> bool:
        return (self.project_path / "go.mod").exists()

    def install_dependencies(self) -> BuildResult:
        return self._run_command(["go", "mod", "download"])

    def build(self) -> BuildResult:
        return self._run_command(["go", "build", "-v", "./..."])

    def test(self) -> BuildResult:
        return self._run_command(["go", "test", "-v", "./..."])

    def clean(self) -> BuildResult:
        result = self._run_command(["go", "clean", "-v", "./..."])
        if result.success:
            return BuildResult(True, output="Cleaned build artifacts")
        return result

    def get_dependencies(self) -> List[Dependency]:
        dependencies = []
        go_mod = self.project_path / "go.mod"
        if not go_mod.exists():
            return dependencies

        result = self._run_command(["go", "list", "-m", "all"])
        if result.success:
            lines = result.output.strip().split("\n")
            for line in lines:
                parts = line.split()
                if len(parts) >= 2:
                    name = parts[0]
                    version = parts[1] if len(parts) > 1 else None
                    dependencies.append(Dependency(name=name, version=version))

        return dependencies

    def add_dependency(self, name: str, version: Optional[str] = None, scope: Optional[str] = None) -> BuildResult:
        pkg = name if not version else f"{name}@{version}"
        return self._run_command(["go", "get", pkg])

    def remove_dependency(self, name: str) -> BuildResult:
        result = self._run_command(["go", "get", f"{name}@none"])
        if result.success:
            self._run_command(["go", "mod", "tidy"])
        return result
