import json
from typing import List, Optional

from .base import BuildResult, BuildTool, Dependency


class NPMBuildTool(BuildTool):
    def __init__(self, project_path: Optional[str] = None, package_manager: str = "npm"):
        super().__init__(project_path)
        self.package_manager = package_manager
        self._validate_package_manager()

    def _validate_package_manager(self):
        valid_managers = ["npm", "yarn", "pnpm"]
        if self.package_manager not in valid_managers:
            raise ValueError(f"Invalid package manager: {self.package_manager}. Must be one of {valid_managers}")

    def is_available(self) -> bool:
        try:
            result = self._run_command([self.package_manager, "--version"])
            return result.success
        except Exception:
            return False

    def detect_project(self) -> bool:
        return (self.project_path / "package.json").exists()

    def install_dependencies(self) -> BuildResult:
        cmd = [self.package_manager, "install"]
        return self._run_command(cmd)

    def build(self) -> BuildResult:
        package_json = self.project_path / "package.json"
        if not package_json.exists():
            return BuildResult(False, error="package.json not found")

        with open(package_json, encoding="utf-8") as f:
            data = json.load(f)

        scripts = data.get("scripts", {})
        if "build" in scripts:
            return self._run_command([self.package_manager, "run", "build"])
        else:
            return BuildResult(True, output="No build script found, skipping build")

    def test(self) -> BuildResult:
        package_json = self.project_path / "package.json"
        if not package_json.exists():
            return BuildResult(False, error="package.json not found")

        with open(package_json, encoding="utf-8") as f:
            data = json.load(f)

        scripts = data.get("scripts", {})
        if "test" in scripts:
            return self._run_command([self.package_manager, "test"])
        else:
            return BuildResult(True, output="No test script found, skipping test")

    def clean(self) -> BuildResult:
        node_modules = self.project_path / "node_modules"
        if node_modules.exists():
            import shutil
            shutil.rmtree(node_modules)
        return BuildResult(True, output="Cleaned node_modules")

    def get_dependencies(self) -> List[Dependency]:
        dependencies = []
        package_json = self.project_path / "package.json"
        if not package_json.exists():
            return dependencies

        with open(package_json, encoding="utf-8") as f:
            data = json.load(f)

        for dep_type in ["dependencies", "devDependencies", "peerDependencies"]:
            if dep_type in data:
                scope = "dev" if dep_type == "devDependencies" else "peer" if dep_type == "peerDependencies" else None
                for name, version in data[dep_type].items():
                    dependencies.append(Dependency(name=name, version=version, scope=scope))

        return dependencies

    def add_dependency(self, name: str, version: Optional[str] = None, scope: Optional[str] = None) -> BuildResult:
        cmd = [self.package_manager, "add"] if self.package_manager in ["yarn", "pnpm"] else [self.package_manager, "install"]

        if scope == "dev":
            if self.package_manager == "npm":
                cmd.append("--save-dev")
            elif self.package_manager == "yarn":
                cmd.append("--dev")
            elif self.package_manager == "pnpm":
                cmd.append("-D")

        pkg = name if not version else f"{name}@{version}"
        cmd.append(pkg)

        return self._run_command(cmd)

    def remove_dependency(self, name: str) -> BuildResult:
        cmd = [self.package_manager, "remove"] if self.package_manager in ["yarn", "pnpm"] else [self.package_manager, "uninstall"]
        cmd.append(name)
        return self._run_command(cmd)
