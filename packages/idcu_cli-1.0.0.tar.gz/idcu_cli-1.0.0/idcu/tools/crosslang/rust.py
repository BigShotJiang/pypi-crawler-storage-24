from typing import List, Optional

from .base import BuildResult, BuildTool, Dependency


class RustBuildTool(BuildTool):
    def __init__(self, project_path: Optional[str] = None):
        super().__init__(project_path)

    def is_available(self) -> bool:
        try:
            result = self._run_command(["cargo", "--version"])
            return result.success
        except Exception:
            return False

    def detect_project(self) -> bool:
        return (self.project_path / "Cargo.toml").exists()

    def install_dependencies(self) -> BuildResult:
        return self._run_command(["cargo", "fetch"])

    def build(self) -> BuildResult:
        return self._run_command(["cargo", "build"])

    def test(self) -> BuildResult:
        return self._run_command(["cargo", "test"])

    def clean(self) -> BuildResult:
        return self._run_command(["cargo", "clean"])

    def get_dependencies(self) -> List[Dependency]:
        dependencies = []
        cargo_toml = self.project_path / "Cargo.toml"
        if not cargo_toml.exists():
            return dependencies

        try:
            import toml
            with open(cargo_toml, encoding="utf-8") as f:
                data = toml.load(f)

            for dep_type in ["dependencies", "dev-dependencies", "build-dependencies"]:
                if dep_type in data:
                    scope = "dev" if dep_type == "dev-dependencies" else "build" if dep_type == "build-dependencies" else None
                    deps = data[dep_type]
                    for name, version_info in deps.items():
                        if isinstance(version_info, str):
                            version = version_info
                        elif isinstance(version_info, dict):
                            version = version_info.get("version", "")
                        else:
                            version = None
                        dependencies.append(Dependency(name=name, version=version, scope=scope))
        except ImportError:
            pass

        return dependencies

    def add_dependency(self, name: str, version: Optional[str] = None, scope: Optional[str] = None) -> BuildResult:
        cmd = ["cargo", "add"]
        if scope == "dev":
            cmd.append("--dev")
        elif scope == "build":
            cmd.append("--build")
        if version:
            cmd.append(f"{name}@{version}")
        else:
            cmd.append(name)
        return self._run_command(cmd)

    def remove_dependency(self, name: str) -> BuildResult:
        return self._run_command(["cargo", "remove", name])
