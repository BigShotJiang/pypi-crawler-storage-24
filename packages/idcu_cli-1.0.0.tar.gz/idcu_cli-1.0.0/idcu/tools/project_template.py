
from pathlib import Path
from string import Template

from idcu.core import print_error, print_info, print_success, print_header, print_section, print_warning
from idcu.system.project_config import get_project_config_manager, ProjectConfig


class EstSpiModuleTemplate:
    def __init__(self, name, group_id="com.example", artifact_id=None, 
                 version="1.0.0-SNAPSHOT", description="EST-SPI Module"):
        self.name = name
        self.group_id = group_id
        self.artifact_id = artifact_id or name.lower().replace(" ", "-")
        self.version = version
        self.description = description

    def get_pom_xml(self):
        template = Template("""<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>${group_id}</groupId>
    <artifactId>${artifact_id}</artifactId>
    <version>${version}</version>
    <packaging>jar</packaging>

    <name>${name}</name>
    <description>${description}</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
    </properties>

    <dependencies>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.13.2</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                </configuration>
            </plugin>
        </plugins>
    </build>

</project>
""")
        return template.substitute(
            group_id=self.group_id,
            artifact_id=self.artifact_id,
            version=self.version,
            name=self.name,
            description=self.description
        )

    def get_readme_md(self):
        template = Template("""# ${name}

${description}

## Building

```bash
mvn clean install
```

## Testing

```bash
mvn test
```
""")
        return template.substitute(name=self.name, description=self.description)

    def get_gitignore(self):
        return """target/
*.iml
.idea/
*.class
*.log
.DS_Store
"""


class ProjectTemplateManager:
    def __init__(self, repo_root=None):
        self.repo_root = repo_root or Path.cwd()
        self.config_manager = get_project_config_manager(self.repo_root / ".idcu")

    def create_est_spi_module(self, name, group_id="com.example", 
                              artifact_id=None, version="1.0.0-SNAPSHOT",
                              description="EST-SPI Module", tier=None,
                              add_to_git=False):
        module_dir = self.repo_root / name
        if module_dir.exists():
            print_error(f"Module directory '{name}' already exists!")
            return False

        print_header(f"Creating EST-SPI Module: {name}")

        template = EstSpiModuleTemplate(
            name=name,
            group_id=group_id,
            artifact_id=artifact_id,
            version=version,
            description=description
        )

        try:
            module_dir.mkdir(parents=True, exist_ok=True)
            print_section(f"Created directory: {module_dir}")

            pom_file = module_dir / "pom.xml"
            pom_file.write_text(template.get_pom_xml(), encoding="utf-8")
            print_success(f"Created: pom.xml")

            readme_file = module_dir / "README.md"
            readme_file.write_text(template.get_readme_md(), encoding="utf-8")
            print_success(f"Created: README.md")

            gitignore_file = module_dir / ".gitignore"
            gitignore_file.write_text(template.get_gitignore(), encoding="utf-8")
            print_success(f"Created: .gitignore")

            src_main_java = module_dir / "src" / "main" / "java"
            src_main_java.mkdir(parents=True, exist_ok=True)
            print_success(f"Created: src/main/java")

            src_test_java = module_dir / "src" / "test" / "java"
            src_test_java.mkdir(parents=True, exist_ok=True)
            print_success(f"Created: src/test/java")

            if tier:
                self._add_module_to_tier(name, tier)

            if add_to_git:
                self._add_to_gitmodules(name)

            print_success(f"\nModule '{name}' created successfully!")
            return True

        except Exception as e:
            print_error(f"Failed to create module: {e}")
            if module_dir.exists():
                import shutil
                shutil.rmtree(module_dir)
            return False

    def _add_module_to_tier(self, module_name, tier_name):
        config = self.config_manager.get_config()
        if config is None:
            print_warning("No project config found, skipping tier update")
            return False

        tier = config.get_tier_by_name(tier_name)
        if tier is None:
            print_warning(f"Tier '{tier_name}' not found, skipping tier update")
            return False

        if module_name not in tier.modules:
            tier.modules.append(module_name)
            if self.config_manager.save_config(config):
                print_success(f"Added module '{module_name}' to tier '{tier_name}'")
                return True
        else:
            print_info(f"Module '{module_name}' already in tier '{tier_name}'")
            return True

        return False

    def _add_to_gitmodules(self, module_name):
        print_warning("Git submodule addition is not fully implemented yet")
        print_info("Please manually add the submodule using: git submodule add <url> " + module_name)
        return False

    def list_templates(self):
        print_header("Available Project Templates")
        print_info("  - est-spi-module: EST-SPI 标准模块模板")
