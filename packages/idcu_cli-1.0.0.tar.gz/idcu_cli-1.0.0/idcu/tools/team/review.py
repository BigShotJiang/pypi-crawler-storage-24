import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class CodeReview:
    def __init__(self, team_config):
        self.team_config = team_config
        self.reviews_dir = Path.home() / ".idcu" / "team" / "reviews"
        self.reviews_dir.mkdir(parents=True, exist_ok=True)

    def create_review(self, title: str, description: str, author: str,
                      commit_hash: Optional[str] = None, diff: Optional[str] = None) -> str:
        review_id = f"review_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        review_data = {
            "id": review_id,
            "title": title,
            "description": description,
            "author": author,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "commit_hash": commit_hash,
            "diff": diff or self._get_git_diff(commit_hash),
            "comments": [],
            "approvers": [],
            "rejecters": []
        }

        review_file = self.reviews_dir / f"{review_id}.json"
        with open(review_file, "w", encoding="utf-8") as f:
            import json
            json.dump(review_data, f, ensure_ascii=False, indent=2)

        return review_id

    def _get_git_diff(self, commit_hash: Optional[str] = None) -> str:
        cmd = ["git", "diff"]
        if commit_hash:
            cmd.append(f"{commit_hash}^!")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except Exception:
            return ""

    def get_review(self, review_id: str) -> Optional[Dict[str, Any]]:
        review_file = self.reviews_dir / f"{review_id}.json"
        if not review_file.exists():
            return None

        import json
        with open(review_file, encoding="utf-8") as f:
            return json.load(f)

    def list_reviews(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        reviews = []
        for review_file in self.reviews_dir.glob("review_*.json"):
            import json
            with open(review_file, encoding="utf-8") as f:
                review = json.load(f)
                if status is None or review["status"] == status:
                    reviews.append(review)
        return sorted(reviews, key=lambda r: r["created_at"], reverse=True)

    def add_comment(self, review_id: str, author: str, comment: str):
        review = self.get_review(review_id)
        if not review:
            raise ValueError(f"Review {review_id} not found")

        comment_data = {
            "author": author,
            "content": comment,
            "created_at": datetime.now().isoformat()
        }
        review["comments"].append(comment_data)

        review_file = self.reviews_dir / f"{review_id}.json"
        import json
        with open(review_file, "w", encoding="utf-8") as f:
            json.dump(review, f, ensure_ascii=False, indent=2)

    def approve(self, review_id: str, approver: str):
        review = self.get_review(review_id)
        if not review:
            raise ValueError(f"Review {review_id} not found")

        if approver not in review["approvers"]:
            review["approvers"].append(approver)

        if approver in review["rejecters"]:
            review["rejecters"].remove(approver)

        if len(review["approvers"]) >= 1:
            review["status"] = "approved"

        review_file = self.reviews_dir / f"{review_id}.json"
        import json
        with open(review_file, "w", encoding="utf-8") as f:
            json.dump(review, f, ensure_ascii=False, indent=2)

    def reject(self, review_id: str, rejecter: str, reason: str):
        review = self.get_review(review_id)
        if not review:
            raise ValueError(f"Review {review_id} not found")

        if rejecter not in review["rejecters"]:
            review["rejecters"].append(rejecter)

        if rejecter in review["approvers"]:
            review["approvers"].remove(rejecter)

        review["status"] = "rejected"

        self.add_comment(review_id, rejecter, f"Rejected: {reason}")

    def update_status(self, review_id: str, status: str):
        review = self.get_review(review_id)
        if not review:
            raise ValueError(f"Review {review_id} not found")

        valid_statuses = ["pending", "approved", "rejected", "merged"]
        if status not in valid_statuses:
            raise ValueError(f"Invalid status: {status}. Must be one of {valid_statuses}")

        review["status"] = status

        review_file = self.reviews_dir / f"{review_id}.json"
        import json
        with open(review_file, "w", encoding="utf-8") as f:
            json.dump(review, f, ensure_ascii=False, indent=2)
