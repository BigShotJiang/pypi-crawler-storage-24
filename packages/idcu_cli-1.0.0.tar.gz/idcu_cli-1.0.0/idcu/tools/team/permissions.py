from typing import Any, Dict, List, Optional


class PermissionManager:
    def __init__(self, team_config):
        self.team_config = team_config

    def get_roles(self) -> Dict[str, Any]:
        return self.team_config.config.get("permissions", {}).get("roles", {})

    def get_role_permissions(self, role: str) -> List[str]:
        roles = self.get_roles()
        return roles.get(role, {}).get("permissions", [])

    def add_role(self, role_name: str, permissions: List[str]):
        if "permissions" not in self.team_config.config:
            self.team_config.config["permissions"] = {}
        if "roles" not in self.team_config.config["permissions"]:
            self.team_config.config["permissions"]["roles"] = {}

        self.team_config.config["permissions"]["roles"][role_name] = {
            "permissions": permissions
        }
        self.team_config.save_config()

    def remove_role(self, role_name: str):
        roles = self.team_config.config.get("permissions", {}).get("roles", {})
        if role_name in roles:
            del roles[role_name]
            self.team_config.save_config()

    def get_member_role(self, email: str) -> Optional[str]:
        members = self.team_config.get_members()
        for member in members:
            if member["email"] == email:
                return member.get("role")
        return None

    def set_member_role(self, email: str, role: str):
        members = self.team_config.get_members()
        for member in members:
            if member["email"] == email:
                member["role"] = role
                self.team_config.save_config()
                return
        raise ValueError(f"Member with email {email} not found")

    def has_permission(self, email: str, permission: str) -> bool:
        role = self.get_member_role(email)
        if not role:
            return False

        role_permissions = self.get_role_permissions(role)

        if "*" in role_permissions:
            return True

        if permission in role_permissions:
            return True

        for p in role_permissions:
            if p.endswith(".*"):
                prefix = p[:-1]
                if permission.startswith(prefix):
                    return True

        return False
