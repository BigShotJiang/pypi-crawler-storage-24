import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class TeamConfig:
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = Path(config_path or self._get_default_config_path())
        self.config = self._load_config()

    def _get_default_config_path(self) -> str:
        home = Path.home()
        config_dir = home / ".idcu" / "team"
        config_dir.mkdir(parents=True, exist_ok=True)
        return str(config_dir / "config.yaml")

    def _load_config(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return self._get_default_config()

        try:
            with open(self.config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f)
                if config is None:
                    return self._get_default_config()
                return config
        except Exception:
            return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            "team_name": "",
            "members": [],
            "shared_configs": {},
            "config_history": [],
            "permissions": {
                "roles": {
                    "admin": {
                        "permissions": ["*"]
                    },
                    "member": {
                        "permissions": ["config.read", "config.write", "review.create"]
                    },
                    "viewer": {
                        "permissions": ["config.read"]
                    }
                }
            }
        }

    def save_config(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w", encoding="utf-8") as f:
            yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)

    def get_team_name(self) -> str:
        return self.config.get("team_name", "")

    def set_team_name(self, name: str):
        self.config["team_name"] = name
        self.save_config()

    def get_members(self) -> List[Dict[str, Any]]:
        return self.config.get("members", [])

    def add_member(self, name: str, email: str, role: str = "member"):
        member = {
            "name": name,
            "email": email,
            "role": role,
            "joined_at": datetime.now().isoformat()
        }
        self.config["members"].append(member)
        self.save_config()

    def remove_member(self, email: str):
        self.config["members"] = [m for m in self.config["members"] if m["email"] != email]
        self.save_config()

    def get_shared_config(self, key: str) -> Optional[Any]:
        return self.config.get("shared_configs", {}).get(key)

    def set_shared_config(self, key: str, value: Any):
        if "shared_configs" not in self.config:
            self.config["shared_configs"] = {}

        old_value = self.config["shared_configs"].get(key)
        self.config["shared_configs"][key] = value

        self._add_config_history(key, old_value, value)
        self.save_config()

    def _add_config_history(self, key: str, old_value: Any, new_value: Any):
        if "config_history" not in self.config:
            self.config["config_history"] = []

        history_entry = {
            "key": key,
            "old_value": old_value,
            "new_value": new_value,
            "timestamp": datetime.now().isoformat(),
            "hash": self._compute_hash(new_value)
        }
        self.config["config_history"].append(history_entry)

    def _compute_hash(self, value: Any) -> str:
        value_str = json.dumps(value, sort_keys=True)
        return hashlib.sha256(value_str.encode()).hexdigest()

    def get_config_history(self, key: Optional[str] = None) -> List[Dict[str, Any]]:
        history = self.config.get("config_history", [])
        if key:
            history = [h for h in history if h["key"] == key]
        return history

    def export_config(self, export_path: str):
        export_data = {
            "team_name": self.get_team_name(),
            "members": self.get_members(),
            "shared_configs": self.config.get("shared_configs", {}),
            "exported_at": datetime.now().isoformat()
        }

        with open(export_path, "w", encoding="utf-8") as f:
            yaml.dump(export_data, f, default_flow_style=False, allow_unicode=True)

    def import_config(self, import_path: str):
        with open(import_path, encoding="utf-8") as f:
            import_data = yaml.safe_load(f)

        if "team_name" in import_data:
            self.config["team_name"] = import_data["team_name"]
        if "members" in import_data:
            self.config["members"] = import_data["members"]
        if "shared_configs" in import_data:
            for key, value in import_data["shared_configs"].items():
                self.set_shared_config(key, value)

        self.save_config()
