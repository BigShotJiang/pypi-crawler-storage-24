
from pathlib import Path
from typing import Any, Callable, List, Optional, Union

from idcu.core import REMOTE_NAME
from idcu.system.logger import get_logger

from .git_common import (
    execute_git_operation_result_error_indicator,
    execute_push_operation_result_error_indicator,
    for_each_repo_operation,
)
from .git_ops import (
    get_repo_paths,
)
from .git_single import (
    git_changes,
    git_commit,
    git_delete,
    git_fetch,
    git_log,
    git_pull,
    git_push,
    git_show,
    git_stash,
    git_stash_list,
    git_stash_pop,
    git_status,
    git_switch,
)

logger = get_logger("git_submodule")


def get_submodule_repos(repo_root: Optional[Union[str, Path]] = None) -> List[Path]:
    if repo_root is None:
        repo_root = Path.cwd()
    return get_repo_paths(Path(repo_root))


def git_push_submodule(
    commit_message: str,
    repo_root: Optional[Union[str, Path]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    add_all: bool = True,
    backup_suffix: str = "_backup_before_push",
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_push(
            commit_message,
            repo_path=repo_path,
            remote=remote,
            branch=branch,
            remote_branch=remote_branch,
            add_all=add_all,
            backup_suffix=backup_suffix,
            pre_checks=pre_checks,
            dry_run=dry_run
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_push_operation_result_error_indicator
    )


def git_pull_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    use_rebase: bool = False,
    stash_before: bool = True,
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_pull(
            repo_path,
            remote=remote,
            branch=branch,
            remote_branch=remote_branch,
            use_rebase=use_rebase,
            stash_before=stash_before,
            pre_checks=pre_checks,
            dry_run=dry_run
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_push_operation_result_error_indicator
    )


def git_status_submodule(
    repo_root: Optional[Union[str, Path]] = None
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_status(repo_path)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_switch_submodule(
    branch: str,
    repo_root: Optional[Union[str, Path]] = None,
    create: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_switch(branch, repo_path=repo_path, create=create)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_changes_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    staged: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_changes(repo_path=repo_path, staged=staged)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_delete_submodule(
    branch: str,
    repo_root: Optional[Union[str, Path]] = None,
    force: bool = False,
    remote: bool = False,
    remote_name: str = REMOTE_NAME
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_delete(
            branch,
            repo_path=repo_path,
            force=force,
            remote=remote,
            remote_name=remote_name
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_show_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    remote: bool = False,
    remote_name: str = REMOTE_NAME
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_show(repo_path=repo_path, remote=remote, remote_name=remote_name)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


git_show_remote_submodule = git_show_submodule


def git_log_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    limit: int = 20,
    oneline: bool = False,
    since: Optional[str] = None,
    until: Optional[str] = None,
    author: Optional[str] = None,
    grep: Optional[str] = None
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_log(
            repo_path=repo_path,
            limit=limit,
            oneline=oneline,
            since=since,
            until=until,
            author=author,
            grep=grep
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_fetch_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    prune: bool = False,
    tags: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_fetch(
            repo_path=repo_path,
            remote=remote,
            branch=branch,
            prune=prune,
            tags=tags
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    message: Optional[str] = None,
    include_untracked: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_stash(
            repo_path=repo_path,
            message=message,
            include_untracked=include_untracked
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_pop_submodule(
    repo_root: Optional[Union[str, Path]] = None,
    stash_id: Optional[str] = None
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_stash_pop(
            repo_path=repo_path,
            stash_id=stash_id
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_list_submodule(
    repo_root: Optional[Union[str, Path]] = None
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_stash_list(
            repo_path=repo_path
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_commit_submodule(
    commit_message: str,
    repo_root: Optional[Union[str, Path]] = None,
    amend: bool = False,
    no_edit: bool = False,
    add_all: bool = False
) -> int:
    repo_list = get_submodule_repos(repo_root)

    def operation(repo_path: Path) -> Any:
        return git_commit(
            commit_message,
            repo_path=repo_path,
            amend=amend,
            no_edit=no_edit,
            add_all=add_all
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )
