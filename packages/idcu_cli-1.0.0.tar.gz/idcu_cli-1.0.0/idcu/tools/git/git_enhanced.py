
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from idcu.core import (
    ErrorCode,
    OperationResult,
    BatchOperationReport,
    OutputFormatter,
)
from idcu.core import REMOTE_NAME
from idcu.system.logger import get_logger

from .git_ops import run_git
from .git_single import (
    git_status as git_status_old,
    git_commit as git_commit_old,
    git_push as git_push_old,
    git_pull as git_pull_old,
    git_switch as git_switch_old,
    git_fetch as git_fetch_old,
    git_stash as git_stash_old,
    git_stash_pop as git_stash_pop_old,
    git_stash_list as git_stash_list_old,
    git_log as git_log_old,
    git_changes as git_changes_old,
    git_show as git_show_old,
)

logger = get_logger("git_enhanced")


class GitEnhancedOperations:
    """增强版Git操作，支持统一输出格式、dry-run、批量操作报告等"""

    def __init__(self, json_mode: bool = False, dry_run: bool = False):
        self.json_mode = json_mode
        self.dry_run = dry_run
        self.formatter = OutputFormatter(json_mode=json_mode, dry_run=dry_run)

    def _execute_with_timing(
        self, 
        operation_func: Callable, 
        operation_name: str,
        project_name: str,
        *args, 
        **kwargs
    ) -> OperationResult:
        """执行操作并计时"""
        start_time = time.time()
        
        try:
            if self.dry_run:
                result = self._dry_run_operation(operation_name, project_name, *args, **kwargs)
            else:
                result = operation_func(*args, **kwargs)
            
            duration = time.time() - start_time
            
            if hasattr(result, 'success'):
                op_result = OperationResult(
                    success=result.success,
                    message=result.message,
                    details=result.details or {},
                    project=project_name,
                    duration_seconds=duration,
                    dry_run=self.dry_run,
                    error_code=ErrorCode.SUCCESS if result.success else ErrorCode.GIT_ERROR_BASE
                )
            else:
                op_result = OperationResult.success_result(
                    message="操作完成",
                    project=project_name,
                    duration_seconds=duration,
                    dry_run=self.dry_run
                )
                
            return op_result
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Operation {operation_name} failed: {e}")
            return OperationResult.error_result(
                error_code=ErrorCode.GIT_ERROR_BASE,
                message=str(e),
                project=project_name,
                duration_seconds=duration,
                dry_run=self.dry_run
            )

    def _dry_run_operation(self, func_name: str, project_name: str, *args, **kwargs) -> Any:
        """Dry run模拟操作"""
        logger.info(f"[DRY-RUN] {func_name} on {project_name}")
        from dataclasses import dataclass
        
        @dataclass
        class DryRunResult:
            success: bool = True
            message: str = f"Dry-run: {func_name} 操作已模拟执行"
            details: Dict[str, Any] = None
        
        return DryRunResult(details={"dry_run": True, "operation": func_name})

    def status(self, repo_path: Optional[Path] = None) -> OperationResult:
        """获取Git状态"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_status_old(repo_path)
        
        return self._execute_with_timing(op, "status", project_name)

    def commit(
        self,
        commit_message: str,
        repo_path: Optional[Path] = None,
        amend: bool = False,
        no_edit: bool = False,
        add_all: bool = False
    ) -> OperationResult:
        """提交更改"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_commit_old(
                commit_message, 
                repo_path=repo_path,
                amend=amend,
                no_edit=no_edit,
                add_all=add_all
            )
        
        return self._execute_with_timing(op, "commit", project_name)

    def push(
        self,
        commit_message: str,
        repo_path: Optional[Path] = None,
        remote: str = REMOTE_NAME,
        branch: Optional[str] = None,
        remote_branch: Optional[str] = None,
        add_all: bool = True,
        backup_suffix: str = "_backup_before_push",
        pre_checks: Optional[Union[Callable, List[Callable]]] = None
    ) -> OperationResult:
        """推送更改"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_push_old(
                commit_message,
                repo_path=repo_path,
                remote=remote,
                branch=branch,
                remote_branch=remote_branch,
                add_all=add_all,
                backup_suffix=backup_suffix,
                pre_checks=pre_checks,
                dry_run=self.dry_run
            )
        
        return self._execute_with_timing(op, "push", project_name)

    def pull(
        self,
        repo_path: Optional[Path] = None,
        remote: str = REMOTE_NAME,
        branch: Optional[str] = None,
        remote_branch: Optional[str] = None,
        use_rebase: bool = False,
        stash_before: bool = True,
        pre_checks: Optional[Union[Callable, List[Callable]]] = None
    ) -> OperationResult:
        """拉取更新"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_pull_old(
                repo_path,
                remote=remote,
                branch=branch,
                remote_branch=remote_branch,
                use_rebase=use_rebase,
                stash_before=stash_before,
                pre_checks=pre_checks,
                dry_run=self.dry_run
            )
        
        return self._execute_with_timing(op, "pull", project_name)

    def switch(
        self,
        branch: str,
        repo_path: Optional[Path] = None,
        create: bool = False
    ) -> OperationResult:
        """切换分支"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_switch_old(branch, repo_path=repo_path, create=create)
        
        return self._execute_with_timing(op, "switch", project_name)

    def fetch(
        self,
        repo_path: Optional[Path] = None,
        remote: str = REMOTE_NAME,
        branch: Optional[str] = None,
        prune: bool = False,
        tags: bool = False
    ) -> OperationResult:
        """获取远程更新"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_fetch_old(
                repo_path,
                remote=remote,
                branch=branch,
                prune=prune,
                tags=tags
            )
        
        return self._execute_with_timing(op, "fetch", project_name)

    def stash(
        self,
        repo_path: Optional[Path] = None,
        message: Optional[str] = None,
        include_untracked: bool = False
    ) -> OperationResult:
        """暂存更改"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_stash_old(
                repo_path,
                message=message,
                include_untracked=include_untracked
            )
        
        return self._execute_with_timing(op, "stash", project_name)

    def stash_pop(
        self,
        repo_path: Optional[Path] = None,
        stash_id: Optional[str] = None
    ) -> OperationResult:
        """恢复暂存"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_stash_pop_old(repo_path, stash_id=stash_id)
        
        return self._execute_with_timing(op, "stash_pop", project_name)

    def stash_list(self, repo_path: Optional[Path] = None) -> OperationResult:
        """查看暂存列表"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_stash_list_old(repo_path)
        
        return self._execute_with_timing(op, "stash_list", project_name)

    def log(
        self,
        repo_path: Optional[Path] = None,
        limit: int = 20,
        oneline: bool = False,
        since: Optional[str] = None,
        until: Optional[str] = None,
        author: Optional[str] = None,
        grep: Optional[str] = None
    ) -> OperationResult:
        """查看提交日志"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_log_old(
                repo_path,
                limit=limit,
                oneline=oneline,
                since=since,
                until=until,
                author=author,
                grep=grep
            )
        
        return self._execute_with_timing(op, "log", project_name)

    def changes(
        self,
        repo_path: Optional[Path] = None,
        staged: bool = False
    ) -> OperationResult:
        """查看更改"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_changes_old(repo_path, staged=staged)
        
        return self._execute_with_timing(op, "changes", project_name)

    def show(
        self,
        repo_path: Optional[Path] = None,
        remote: bool = False,
        remote_name: str = REMOTE_NAME
    ) -> OperationResult:
        """显示分支信息"""
        if repo_path is None:
            repo_path = Path.cwd()
        project_name = repo_path.name
        
        def op():
            return git_show_old(repo_path, remote=remote, remote_name=remote_name)
        
        return self._execute_with_timing(op, "show", project_name)

    def batch_operation(
        self,
        operation_name: str,
        repo_paths: List[Path],
        operation_func: Callable[[Path], OperationResult]
    ) -> BatchOperationReport:
        """执行批量操作并生成报告"""
        report = BatchOperationReport(operation_name=operation_name)
        
        for repo_path in repo_paths:
            result = operation_func(repo_path)
            report.add_result(result)
        
        report.finish()
        return report

    def print_result(self, result: OperationResult):
        """打印单个操作结果"""
        self.formatter.print_result(result)

    def print_batch_report(self, report: BatchOperationReport):
        """打印批量操作报告"""
        self.formatter.print_batch_report(report)
