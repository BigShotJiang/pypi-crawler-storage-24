
from pathlib import Path
from typing import Any, Callable, List, Optional, Union

from idcu.core import REMOTE_NAME
from idcu.system.logger import get_logger

from .git_common import (
    execute_git_operation_result_error_indicator,
    execute_push_operation_result_error_indicator,
    for_each_repo_operation,
    normalize_repos,
)
from .git_single import (
    git_bisect,
    git_blame,
    git_changes,
    git_cherry_pick,
    git_clean,
    git_commit,
    git_delete,
    git_diff_enhanced,
    git_fetch,
    git_log,
    git_pull,
    git_push,
    git_rebase,
    git_reset,
    git_show,
    git_stash,
    git_stash_list,
    git_stash_pop,
    git_status,
    git_switch,
    git_tag,
)

logger = get_logger("git_multi")


def git_push_multi(
    commit_message: str,
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    add_all: bool = True,
    backup_suffix: str = "_backup_before_push",
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_push(
            commit_message,
            repo_path=repo_path,
            remote=remote,
            branch=branch,
            remote_branch=remote_branch,
            add_all=add_all,
            backup_suffix=backup_suffix,
            pre_checks=pre_checks,
            dry_run=dry_run
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_push_operation_result_error_indicator
    )


def git_pull_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    use_rebase: bool = False,
    stash_before: bool = True,
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_pull(
            repo_path,
            remote=remote,
            branch=branch,
            remote_branch=remote_branch,
            use_rebase=use_rebase,
            stash_before=stash_before,
            pre_checks=pre_checks,
            dry_run=dry_run
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_push_operation_result_error_indicator
    )


def git_status_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_status(repo_path)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_switch_multi(
    branch: str,
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    create: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_switch(branch, repo_path=repo_path, create=create)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_changes_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    staged: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_changes(repo_path=repo_path, staged=staged)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_delete_multi(
    branch: str,
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    force: bool = False,
    remote: bool = False,
    remote_name: str = REMOTE_NAME
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_delete(
            branch,
            repo_path=repo_path,
            force=force,
            remote=remote,
            remote_name=remote_name
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_show_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    remote: bool = False,
    remote_name: str = REMOTE_NAME
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_show(repo_path=repo_path, remote=remote, remote_name=remote_name)

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


git_show_remote_multi = git_show_multi


def git_log_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    limit: int = 20,
    oneline: bool = False,
    since: Optional[str] = None,
    until: Optional[str] = None,
    author: Optional[str] = None,
    grep: Optional[str] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_log(
            repo_path=repo_path,
            limit=limit,
            oneline=oneline,
            since=since,
            until=until,
            author=author,
            grep=grep
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_fetch_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    prune: bool = False,
    tags: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_fetch(
            repo_path=repo_path,
            remote=remote,
            branch=branch,
            prune=prune,
            tags=tags
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    message: Optional[str] = None,
    include_untracked: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_stash(
            repo_path=repo_path,
            message=message,
            include_untracked=include_untracked
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_pop_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    stash_id: Optional[str] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_stash_pop(
            repo_path=repo_path,
            stash_id=stash_id
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_stash_list_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_stash_list(
            repo_path=repo_path
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_commit_multi(
    commit_message: str,
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    amend: bool = False,
    no_edit: bool = False,
    add_all: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_commit(
            commit_message,
            repo_path=repo_path,
            amend=amend,
            no_edit=no_edit,
            add_all=add_all
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_rebase_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    upstream: Optional[str] = None,
    branch: Optional[str] = None,
    interactive: bool = False,
    abort: bool = False,
    continue_rebase: bool = False,
    skip: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_rebase(
            repo_path=repo_path,
            upstream=upstream,
            branch=branch,
            interactive=interactive,
            abort=abort,
            continue_rebase=continue_rebase,
            skip=skip
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_cherry_pick_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    commits: Optional[List[str]] = None,
    continue_cherry: bool = False,
    abort: bool = False,
    skip: bool = False,
    no_commit: bool = False,
    edit: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_cherry_pick(
            repo_path=repo_path,
            commits=commits,
            continue_cherry=continue_cherry,
            abort=abort,
            skip=skip,
            no_commit=no_commit,
            edit=edit
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_reset_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    commit: Optional[str] = None,
    mode: str = "mixed",
    hard: bool = False,
    soft: bool = False,
    mixed: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_reset(
            repo_path=repo_path,
            commit=commit,
            mode=mode,
            hard=hard,
            soft=soft,
            mixed=mixed
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_diff_enhanced_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    staged: bool = False,
    cached: bool = False,
    stat: bool = False,
    name_only: bool = False,
    name_status: bool = False,
    color: bool = True,
    commit1: Optional[str] = None,
    commit2: Optional[str] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_diff_enhanced(
            repo_path=repo_path,
            staged=staged,
            cached=cached,
            stat=stat,
            name_only=name_only,
            name_status=name_status,
            color=color,
            commit1=commit1,
            commit2=commit2
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_clean_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    force: bool = False,
    directories: bool = False,
    dry_run: bool = False,
    ignored: bool = False,
    exclude: Optional[List[str]] = None
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_clean(
            repo_path=repo_path,
            force=force,
            directories=directories,
            dry_run=dry_run,
            ignored=ignored,
            exclude=exclude
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_tag_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    tag_name: Optional[str] = None,
    message: Optional[str] = None,
    annotated: bool = False,
    delete: bool = False,
    list_tags: bool = False,
    push: bool = False,
    remote: str = REMOTE_NAME
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_tag(
            repo_path=repo_path,
            tag_name=tag_name,
            message=message,
            annotated=annotated,
            delete=delete,
            list_tags=list_tags,
            push=push,
            remote=remote
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_blame_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    file_path: str = "",
    line: Optional[str] = None,
    show_email: bool = False,
    show_name: bool = True,
    show_date: bool = True
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_blame(
            repo_path=repo_path,
            file_path=file_path,
            line=line,
            show_email=show_email,
            show_name=show_name,
            show_date=show_date
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )


def git_bisect_multi(
    repos: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
    start: bool = False,
    bad: Optional[str] = None,
    good: Optional[List[str]] = None,
    reset: bool = False,
    skip: bool = False,
    visualize: bool = False
) -> int:
    repo_list = normalize_repos(repos)

    def operation(repo_path: Path) -> Any:
        return git_bisect(
            repo_path=repo_path,
            start=start,
            bad=bad,
            good=good,
            reset=reset,
            skip=skip,
            visualize=visualize
        )

    return for_each_repo_operation(
        repo_list,
        operation,
        execute_git_operation_result_error_indicator
    )
