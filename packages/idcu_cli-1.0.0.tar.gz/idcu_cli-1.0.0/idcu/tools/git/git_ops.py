
import subprocess
from pathlib import Path
from typing import Callable, List, Optional, Tuple, Union

from idcu.core.encoding_utils import detect_encoding_with_fallback
from idcu.system.logger import get_logger

logger = get_logger("git_ops")


def _smart_decode(data: bytes) -> str:
    """Smart decoding using encoding_utils to automatically detect and decode"""
    if not data:
        return ""

    # First try UTF-8 as it's the most common
    try:
        return data.decode('utf-8', errors="strict")
    except UnicodeDecodeError:
        pass

    # Then try GBK/GB18030 for Chinese content
    try:
        return data.decode('gbk', errors="strict")
    except UnicodeDecodeError:
        pass

    try:
        return data.decode('gb18030', errors="strict")
    except UnicodeDecodeError:
        pass

    # Try encoding detection
    try:
        encoding, confidence = detect_encoding_with_fallback(data)
        if encoding and encoding not in ['utf-8', 'gbk', 'gb18030']:
            try:
                return data.decode(encoding, errors="strict")
            except UnicodeDecodeError:
                logger.debug(f"Decoding with {encoding} failed, using fallback")
    except Exception as e:
        logger.debug(f"Encoding detection failed: {e}")

    # Try other common encodings
    common_encodings = ['big5', 'shift_jis', 'euc-jp', 'euc-kr', 'latin-1']
    for encoding in common_encodings:
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue

    # Final fallback
    logger.warning("All encoding attempts failed, using replace mode")
    return data.decode('utf-8', errors='replace')


def run_git(repo_path: Path, args: List[str], suppress_warning: bool = False) -> Tuple[int, str, str]:
    cmd = ["git", "-C", str(repo_path)] + args
    logger.debug(f"Running Git command: {' '.join(cmd)}")

    try:
        result = subprocess.run(cmd, capture_output=True)
        stdout = _smart_decode(result.stdout)
        stderr = _smart_decode(result.stderr)

        if result.returncode != 0 and not suppress_warning:
            logger.warning(f"Git command failed: {' '.join(cmd)} - {stderr}")

        return result.returncode, stdout, stderr
    except Exception as exc:
        logger.error(f"Error running Git command: {' '.join(cmd)} - {exc}")
        return -1, "", str(exc)


def get_submodule_paths(repo_root: Path) -> List[str]:
    submodule_paths: List[str] = []
    gitmodules_path = repo_root / ".gitmodules"
    if not gitmodules_path.exists():
        return submodule_paths
    code, stdout, _ = run_git(
        repo_root,
        ["config", "--file", ".gitmodules", "--get-regexp", r"submodule\..*\.path"],
    )
    if code != 0:
        return submodule_paths
    for line in stdout.strip().splitlines():
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) == 2:
            submodule_paths.append(parts[1].strip())
    return submodule_paths


def get_repo_paths(repo_root: Path) -> List[Path]:
    repo_paths = [repo_root]
    for path_str in get_submodule_paths(repo_root):
        path = repo_root / path_str
        git_ref = path / ".git"
        if git_ref.exists() or git_ref.is_file():
            repo_paths.append(path)
    return repo_paths


def get_repo_name(repo_root: Path, repo_path: Path) -> str:
    return "." if repo_path == repo_root else repo_path.name


def for_each_repo(
    repo_root: Path,
    operation: Callable[[Path, str], Optional[int]],
    projects: Optional[Union[str, List[str]]] = None
) -> int:
    all_repos = get_repo_paths(repo_root)

    if projects:
        target_repos = []
        if isinstance(projects, str):
            projects = [projects]

        for project_name in projects:
            found = False
            for repo_path in all_repos:
                repo_name = get_repo_name(repo_root, repo_path)
                if repo_name == project_name or (repo_path.name == project_name):
                    target_repos.append(repo_path)
                    found = True
                    break
            if not found:
                logger.warning(f"Project '{project_name}' not found")
    else:
        target_repos = all_repos

    has_error = False
    for repo_path in target_repos:
        repo_name = get_repo_name(repo_root, repo_path)
        result = operation(repo_path, repo_name)
        if result is not None and result != 0:
            has_error = True
    return 1 if has_error else 0


def list_available_projects(repo_root: Path) -> List[str]:
    return [get_repo_name(repo_root, path) for path in get_repo_paths(repo_root)]


def run_git_checked(
    repo_path: Path, args: List[str], description: str = "Git operation"
) -> Tuple[bool, str, str]:
    code, stdout, stderr = run_git(repo_path, args)
    return code == 0, stdout, stderr

