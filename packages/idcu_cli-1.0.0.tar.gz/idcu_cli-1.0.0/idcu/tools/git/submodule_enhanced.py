
from dataclasses import dataclass
from pathlib import Path

from idcu.core import print_error, print_info, print_success, print_header, print_section, print_warning
from idcu.system.logger import get_logger
from idcu.tools.git.git_ops import run_git
from idcu.tools.git.git_submodule import get_submodule_repos

logger = get_logger("submodule_enhanced")


@dataclass
class SubmoduleStatus:
    name: str
    path: Path
    branch: str
    has_changes: bool
    ahead: int
    behind: int
    commit_hash: str


class EnhancedSubmoduleManager:
    def __init__(self, repo_root=None):
        self.repo_root = repo_root or Path.cwd()
        self.submodules = get_submodule_repos(self.repo_root)

    def _get_submodule_name(self, repo_path):
        return str(repo_path.relative_to(self.repo_root))

    def _get_current_branch(self, repo_path):
        code, stdout, _ = run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"])
        if code == 0:
            return stdout.strip()
        return None

    def _get_commit_hash(self, repo_path):
        code, stdout, _ = run_git(repo_path, ["rev-parse", "HEAD"])
        if code == 0:
            return stdout.strip()
        return None

    def _has_uncommitted_changes(self, repo_path):
        code, stdout, _ = run_git(repo_path, ["status", "--porcelain"])
        return code == 0 and bool(stdout.strip())

    def get_detailed_status(self):
        status_list = []
        
        for repo_path in self.submodules:
            name = self._get_submodule_name(repo_path)
            branch = self._get_current_branch(repo_path)
            commit_hash = self._get_commit_hash(repo_path)
            has_changes = self._has_uncommitted_changes(repo_path)
            
            status = SubmoduleStatus(
                name=name,
                path=repo_path,
                branch=branch,
                has_changes=has_changes,
                ahead=0,
                behind=0,
                commit_hash=commit_hash
            )
            status_list.append(status)
        
        return status_list

    def print_detailed_status(self):
        status_list = self.get_detailed_status()
        
        print_header("Submodule Detailed Status")
        
        if not status_list:
            print_info("No submodules found")
            return True
        
        for status in status_list:
            print_section(f"Submodule: {status.name}")
            print(f"  Path: {status.path}")
            print(f"  Branch: {status.branch or 'detached HEAD'}")
            print(f"  Commit: {status.commit_hash[:8] if status.commit_hash else 'N/A'}")
            
            change_status = "Changed" if status.has_changes else "Clean"
            print(f"  Status: {change_status}")
        
        return True

    def switch_branch_all(self, branch, confirm=True):
        if confirm:
            print_warning(f"About to switch all submodules to branch: {branch}")
            response = input("Confirm? (y/n): ").strip().lower()
            if response != "y":
                print_info("Operation cancelled")
                return False
        
        success = True
        
        for repo_path in self.submodules:
            name = self._get_submodule_name(repo_path)
            print_section(f"Switching submodule: {name}")
            
            code, _, stderr = run_git(repo_path, ["checkout", branch])
            if code == 0:
                print_success(f"Successfully switched to branch: {branch}")
            else:
                print_error(f"Switch failed: {stderr}")
                success = False
        
        return success

    def commit_selected(self, message, selected_modules=None, add_all=True):
        success = True
        
        for repo_path in self.submodules:
            name = self._get_submodule_name(repo_path)
            if selected_modules and name not in selected_modules:
                continue
            
            print_section(f"Committing submodule: {name}")
            
            if add_all:
                code, _, stderr = run_git(repo_path, ["add", "-A"])
                if code != 0:
                    print_error(f"Add failed: {stderr}")
                    success = False
                    continue
            
            code, _, stderr = run_git(repo_path, ["commit", "-m", message])
            if code == 0:
                print_success(f"Commit successful")
            else:
                print_error(f"Commit failed: {stderr}")
                success = False
        
        return success

    def push_selected(self, selected_modules=None, remote="origin", branch=None):
        success = True
        
        for repo_path in self.submodules:
            name = self._get_submodule_name(repo_path)
            if selected_modules and name not in selected_modules:
                continue
            
            print_section(f"Pushing submodule: {name}")
            
            target_branch = branch or self._get_current_branch(repo_path)
            if target_branch is None:
                print_error("Cannot determine current branch")
                success = False
                continue
            
            code, _, stderr = run_git(repo_path, ["push", remote, target_branch])
            if code == 0:
                print_success(f"Push successful")
            else:
                print_error(f"Push failed: {stderr}")
                success = False
        
        return success

    def sync_submodules(self, pull=True, init=True):
        print_header("Sync submodules")
        
        args = ["submodule", "sync"]
        if init:
            args.append("--init")
        if pull:
            args.append("--recursive")
        
        code, _, stderr = run_git(self.repo_root, args)
        if code == 0:
            print_success("Submodule sync successful")
            return True
        else:
            print_error(f"Submodule sync failed: {stderr}")
            return False
