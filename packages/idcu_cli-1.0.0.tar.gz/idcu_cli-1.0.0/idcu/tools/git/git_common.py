
from pathlib import Path

from idcu.core import print_error


def is_valid_git_repo(repo_path):
    repo_path = Path(repo_path)
    return (repo_path / ".git").exists() or (repo_path / ".git").is_file()


def validate_repo(repo_path):
    repo_path = Path(repo_path)
    if not is_valid_git_repo(repo_path):
        print_error(f"Repository does not exist or is not a valid Git repository: {repo_path}")
        return False
    return True


def normalize_repos(repos=None):
    if repos is None:
        return [Path.cwd()]
    elif isinstance(repos, (str, Path)):
        return [Path(repos)]
    else:
        return [Path(r) for r in repos]


def for_each_repo_operation(repos, operation, error_indicator, parallel=True, max_workers=None):
    has_error = False
    for repo_path in repos:
        if not validate_repo(repo_path):
            has_error = True
            continue
        result = operation(repo_path)
        if error_indicator(result):
            has_error = True
    return 1 if has_error else 0


def execute_push_operation_result_error_indicator(result):
    return not result.success


def execute_git_operation_result_error_indicator(result):
    return not result.success

