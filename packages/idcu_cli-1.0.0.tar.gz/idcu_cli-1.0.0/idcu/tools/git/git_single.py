
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from idcu.core import REMOTE_NAME, print_error, print_header, print_info, print_section, print_success, print_warning
from idcu.system.logger import get_logger

from .git_ops import run_git

logger = get_logger("git_single")


@dataclass
class GitOperationResult:
    success: bool
    message: str
    details: Optional[Dict[str, Any]] = None


def _get_current_branch(repo_path: Path) -> Optional[str]:
    code, stdout, stderr = run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"])
    if code == 0:
        return stdout.strip()
    return None


def _get_current_commit(repo_path: Path) -> Optional[str]:
    code, stdout, stderr = run_git(repo_path, ["rev-parse", "HEAD"])
    if code == 0:
        return stdout.strip()
    return None


def _has_uncommitted_changes(repo_path: Path) -> bool:
    code, stdout, stderr = run_git(repo_path, ["status", "--porcelain"])
    return code == 0 and bool(stdout.strip())


def _create_backup_branch(repo_path: Path, backup_branch_name: str) -> bool:
    code, stdout, stderr = run_git(repo_path, ["checkout", "-b", backup_branch_name])
    if code != 0:
        logger.warning(f"Failed to create backup branch: {stderr}")
        return False

    code, _, _ = run_git(repo_path, ["checkout", "-"])
    if code != 0:
        logger.warning(f"Failed to switch back to original branch: {stderr}")
        return False

    return True


def _execute_pre_checks(pre_checks: Optional[Union[Callable, List[Callable]]], repo_path: Path) -> bool:
    if pre_checks is None:
        return True

    if callable(pre_checks):
        pre_checks = [pre_checks]

    for i, check in enumerate(pre_checks, 1):
        print_section(f"Executing pre-check [{i}/{len(pre_checks)}]")
        try:
            if not check(repo_path):
                print_error(f"Pre-check [{i}/{len(pre_checks)}] failed")
                return False
            print_success(f"Pre-check [{i}/{len(pre_checks)}] passed")
        except Exception as e:
            print_error(f"Pre-check [{i}/{len(pre_checks)}] execution error: {e}")
            return False

    return True


def _get_repo_info(
    repo_path: Path,
    branch: Optional[str],
    remote_branch: Optional[str],
    remote: str
) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    original_branch = _get_current_branch(repo_path)
    if not original_branch:
        return None, None, None, None

    target_branch = branch or original_branch
    target_remote_branch = remote_branch or target_branch
    original_commit = _get_current_commit(repo_path)

    return original_branch, target_branch, target_remote_branch, original_commit


def _rollback_to_commit(repo_path: Path, original_commit: str, stashed: bool = False) -> None:
    code, _, _ = run_git(repo_path, ["reset", "--hard", original_commit])
    if code == 0:
        print_success(f"Rolled back to initial state (commit: {original_commit[:8]})")
    else:
        print_warning("Rollback may have failed, please check manually")

    if stashed:
        print_section("Restoring stashed changes")
        run_git(repo_path, ["stash", "pop"], suppress_warning=True)


def _print_dry_run_info(action: str, cmd: List[str]) -> None:
    print_info(f"[Dry-run] {action}: git {' '.join(cmd)}")


def _try_stash_changes(repo_path: Path, dry_run: bool) -> bool:
    print_section("[1/5] Checking for uncommitted changes")
    code, stdout, _ = run_git(repo_path, ["status", "--porcelain"])
    if code != 0 or not stdout.strip():
        return False

    if not dry_run:
        print_info("Uncommitted changes detected, stashing...")
        code, _, stderr = run_git(repo_path, ["stash", "push", "-m", "auto-stash-before-pull"])
        if code == 0:
            print_success("Changes stashed")
            return True
        print_warning(f"Stash failed: {stderr}")
        return False
    else:
        print_info("[Dry-run] Uncommitted changes detected, will stash")
        return True


def _restore_stash(repo_path: Path) -> None:
    print_section("Restoring stashed changes")
    run_git(repo_path, ["stash", "pop"], suppress_warning=True)


def _abort_and_rollback(
    repo_path: Path,
    original_commit: str,
    use_rebase: bool,
    stashed: bool
) -> None:
    print_section("Rolling back to initial state")
    if use_rebase:
        run_git(repo_path, ["rebase", "--abort"], suppress_warning=True)
    else:
        run_git(repo_path, ["merge", "--abort"], suppress_warning=True)
    _rollback_to_commit(repo_path, original_commit, stashed)


def git_status(repo_path=None):
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name
    print_header(f"Status check: {repo_name}")

    code, stdout, stderr = run_git(repo_path, ["status"])
    if code != 0:
        return GitOperationResult(False, f"Failed to get status: {stderr}")

    print(stdout)

    current_branch = _get_current_branch(repo_path)
    current_commit = _get_current_commit(repo_path)

    details = {
        "branch": current_branch,
        "commit": current_commit[:8] if current_commit else None,
        "has_changes": _has_uncommitted_changes(repo_path)
    }

    return GitOperationResult(True, "Status check complete", details)


git_status_single = git_status


def git_switch(branch, repo_path=None, create=False):
    if repo_path is None:
        repo_path = Path.cwd()
    print_header(f"Switching branch: {repo_path.name} -> {branch}")

    args = ["checkout"]
    if create:
        args.append("-b")
    args.append(branch)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Failed to switch branch: {stderr}")

    print_success(f"Switched to branch: {branch}")
    return GitOperationResult(True, f"Switched to branch: {branch}")


git_switch_branch = git_switch


def git_push(
    commit_message: str,
    repo_path: Optional[Path] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    add_all: bool = True,
    backup_suffix: str = "_backup_before_push",
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Push workflow: {repo_name}")

    if dry_run:
        print_info("Dry-run mode - will not actually execute push operation")

    if not _execute_pre_checks(pre_checks, repo_path):
        error_msg = "Pre-checks failed, Push operation cancelled"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)

    original_branch, target_branch, target_remote_branch, original_commit = _get_repo_info(repo_path, branch, remote_branch, remote)
    if not original_branch:
        error_msg = "Could not get current branch"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)
    if not original_commit:
        error_msg = "Could not get current commit"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)

    backup_branch = f"{target_branch}{backup_suffix}"

    print_info(f"Current branch: {original_branch}")
    print_info(f"Local target branch: {target_branch}")
    print_info(f"Remote target branch: {target_remote_branch}")

    print_section(f"[1/6] Creating backup branch: {backup_branch}")
    if not dry_run:
        if not _create_backup_branch(repo_path, backup_branch):
            error_msg = f"Failed to create backup branch {backup_branch}"
            print_error(error_msg)
            return GitOperationResult(False, error_msg)
        print_success(f"Backup branch {backup_branch} created successfully")
    else:
        print_info(f"[Dry-run] Will create backup branch: {backup_branch}")

    print_section("[2/6] Adding files to staging area")
    add_args = ["add", "-A"] if add_all else ["add", "-u"]
    if not dry_run:
        code, stdout, stderr = run_git(repo_path, add_args)
        if code != 0:
            print_warning(f"Warning when adding files: {stderr}")

        code, stdout, _ = run_git(repo_path, ["status", "--porcelain"])
        if code == 0 and not stdout.strip():
            print_info("No changes to commit")
            print_success("Push workflow complete (no changes)")
            return GitOperationResult(True, "No changes to commit")

        print_success("Files added to staging area")
    else:
        _print_dry_run_info("Will execute", add_args)

    print_section("[3/6] Committing changes")
    commit_args = ["commit", "-m", commit_message]
    if not dry_run:
        code, stdout, stderr = run_git(repo_path, commit_args)
        if code != 0:
            error_msg = f"Commit failed: {stderr}"
            print_error(error_msg)
            print_section("Rolling back to initial state")
            _rollback_to_commit(repo_path, original_commit)
            return GitOperationResult(False, error_msg)
        print_success("Commit successful")
    else:
        _print_dry_run_info("Will execute", commit_args)

    print_section(f"[4/6] Pushing to {remote}/{target_remote_branch}")
    push_args = ["push", remote, f"{target_branch}:{target_remote_branch}"]
    if not dry_run:
        code, stdout, stderr = run_git(repo_path, push_args)
        if code != 0:
            error_msg = f"Push failed: {stderr}"
            print_error(error_msg)
            print_section("Rolling back to initial state")
            _rollback_to_commit(repo_path, original_commit)
            return GitOperationResult(False, error_msg)
        print_success("Push successful")
    else:
        _print_dry_run_info("Will execute", push_args)

    print_section(f"[5/6] Cleaning up backup branch: {backup_branch}")
    if not dry_run:
        code, _, _ = run_git(repo_path, ["branch", "-D", backup_branch], suppress_warning=True)
        if code == 0:
            print_success("Backup branch cleaned up")
        else:
            print_warning(f"Backup branch {backup_branch} kept locally, you can delete it manually")
    else:
        print_info(f"[Dry-run] Will clean up backup branch: {backup_branch}")

    print_section("[6/6] Complete")
    print_success(f"Push workflow complete: {repo_name}")
    return GitOperationResult(True, "Push successful")


git_push_single = git_push


def git_pull(
    repo_path: Optional[Path] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    remote_branch: Optional[str] = None,
    use_rebase: bool = False,
    stash_before: bool = True,
    pre_checks: Optional[Union[Callable, List[Callable]]] = None,
    dry_run: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Pull workflow: {repo_name}")

    if dry_run:
        print_info("Dry-run mode - will not actually execute pull operation")

    if not _execute_pre_checks(pre_checks, repo_path):
        error_msg = "Pre-checks failed, Pull operation cancelled"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)

    original_branch, target_branch, target_remote_branch, original_commit = _get_repo_info(repo_path, branch, remote_branch, remote)
    if not original_branch:
        error_msg = "Could not get current branch"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)
    if not original_commit:
        error_msg = "Could not get current commit"
        print_error(error_msg)
        return GitOperationResult(False, error_msg)

    print_info(f"Current branch: {original_branch}")
    print_info(f"Local target branch: {target_branch}")
    print_info(f"Remote target branch: {target_remote_branch}")

    stashed = False
    if stash_before:
        stashed = _try_stash_changes(repo_path, dry_run)

    print_section(f"[2/5] Fetching updates from {remote}")
    fetch_args = ["fetch", remote, target_remote_branch]
    if not dry_run:
        code, stdout, stderr = run_git(repo_path, fetch_args)
        if code != 0:
            error_msg = f"Fetch failed: {stderr}"
            print_error(error_msg)
            if stashed:
                _restore_stash(repo_path)
            return GitOperationResult(False, error_msg)
        print_success("Fetch successful")
    else:
        _print_dry_run_info("Will execute", fetch_args)

    strategy = "Rebase" if use_rebase else "Merge"
    print_section(f"[3/5] Applying updates ({strategy})")

    apply_args = ["rebase", f"{remote}/{target_remote_branch}"] if use_rebase else ["merge", f"{remote}/{target_remote_branch}"]
    if not dry_run:
        code, stdout, stderr = run_git(repo_path, apply_args)
        if code != 0:
            error_msg = f"{strategy} failed: {stderr}"
            print_error(error_msg)
            _abort_and_rollback(repo_path, original_commit, use_rebase, stashed)
            return GitOperationResult(False, error_msg)
        print_success(f"{strategy} successful")
    else:
        _print_dry_run_info("Will execute", apply_args)

    if stashed:
        print_section("[4/5] Restoring stashed changes")
        if not dry_run:
            code, _, stderr = run_git(repo_path, ["stash", "pop"])
            if code == 0:
                print_success("Stashed changes restored")
            else:
                print_warning(f"Warning when restoring stash: {stderr}")
        else:
            print_info("[Dry-run] Will restore stashed changes")

    print_section("[5/5] Complete")
    print_success(f"Pull workflow complete: {repo_name}")
    return GitOperationResult(True, "Pull successful")


git_pull_single = git_pull


def git_changes(repo_path=None, staged=False):
    if repo_path is None:
        repo_path = Path.cwd()

    args = ["diff"]
    if staged:
        args.append("--cached")

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Failed to get changes: {stderr}")

    details = {
        "diff": stdout,
        "has_changes": bool(stdout.strip())
    }

    return GitOperationResult(True, "Got changes successfully", details)


def git_delete(branch, repo_path=None, force=False, remote=False, remote_name=REMOTE_NAME):
    if repo_path is None:
        repo_path = Path.cwd()

    if remote:
        args = ["push", remote_name, "--delete", branch]
    else:
        args = ["branch", "-D" if force else "-d", branch]

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Failed to delete branch: {stderr}")

    return GitOperationResult(True, f"Branch {branch} deleted")


def git_show(repo_path=None, remote=False, remote_name=REMOTE_NAME):
    if repo_path is None:
        repo_path = Path.cwd()

    if remote:
        code, stdout, stderr = run_git(repo_path, ["branch", "-r"])
        if code != 0:
            return GitOperationResult(False, f"Failed to get remote branches: {stderr}")

        branches = []
        prefix = f"{remote_name}/"
        for line in stdout.strip().split('\n'):
            line = line.strip()
            if line and line.startswith(prefix):
                branches.append(line[len(prefix):])

        details = {
            "branches": branches,
            "remote": remote_name
        }
    else:
        code, stdout, stderr = run_git(repo_path, ["branch", "--list"])
        if code != 0:
            return GitOperationResult(False, f"Failed to get branches: {stderr}")

        branches = []
        current_branch = None
        for line in stdout.strip().split('\n'):
            line = line.strip()
            if line:
                if line.startswith('*'):
                    branch_name = line[1:].strip()
                    current_branch = branch_name
                    branches.append(branch_name)
                else:
                    branches.append(line)

        details = {
            "branches": branches,
            "current": current_branch
        }

    return GitOperationResult(True, "Got branches successfully", details)


def git_log(repo_path=None, limit=20, oneline=False, since=None, until=None, author=None, grep=None):
    if repo_path is None:
        repo_path = Path.cwd()

    args = ["log"]
    if oneline:
        args.append("--oneline")
    if limit:
        args.extend(["-n", str(limit)])
    if since:
        args.extend(["--since", since])
    if until:
        args.extend(["--until", until])
    if author:
        args.extend(["--author", author])
    if grep:
        args.extend(["--grep", grep])

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Failed to get log: {stderr}")

    details = {
        "log": stdout
    }

    return GitOperationResult(True, "Got log successfully", details)


def git_fetch(
    repo_path: Optional[Path] = None,
    remote: str = REMOTE_NAME,
    branch: Optional[str] = None,
    prune: bool = False,
    tags: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Fetch: {repo_name}")

    args = ["fetch", remote]
    if branch:
        args.append(branch)
    if prune:
        args.append("--prune")
    if tags:
        args.append("--tags")

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Fetch failed: {stderr}")

    print_success("Fetch successful")
    return GitOperationResult(True, "Fetch successful", {"output": stdout})


git_fetch_single = git_fetch


def git_stash(
    repo_path: Optional[Path] = None,
    message: Optional[str] = None,
    include_untracked: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Stash: {repo_name}")

    args = ["stash", "push"]
    if message:
        args.extend(["-m", message])
    if include_untracked:
        args.append("-u")

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Stash failed: {stderr}")

    print_success("Stash successful")
    return GitOperationResult(True, "Stash successful", {"output": stdout})


git_stash_single = git_stash


def git_stash_pop(
    repo_path: Optional[Path] = None,
    stash_id: Optional[str] = None
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Stash Pop: {repo_name}")

    args = ["stash", "pop"]
    if stash_id:
        args.append(stash_id)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Stash Pop failed: {stderr}")

    print_success("Stash Pop successful")
    return GitOperationResult(True, "Stash Pop successful", {"output": stdout})


git_stash_pop_single = git_stash_pop


def git_stash_list(repo_path: Optional[Path] = None) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()

    code, stdout, stderr = run_git(repo_path, ["stash", "list"])
    if code != 0:
        return GitOperationResult(False, f"Failed to get stash list: {stderr}")

    details = {
        "stashes": stdout.strip().splitlines() if stdout.strip() else []
    }

    return GitOperationResult(True, "Got stash list successfully", details)


git_stash_list_single = git_stash_list


def git_commit(
    commit_message: str,
    repo_path: Optional[Path] = None,
    amend: bool = False,
    no_edit: bool = False,
    add_all: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Commit: {repo_name}")

    if add_all:
        add_code, _, add_stderr = run_git(repo_path, ["add", "-A"])
        if add_code != 0:
            print_warning(f"Warning when adding files: {add_stderr}")

    args = ["commit", "-m", commit_message]
    if amend:
        args.append("--amend")
        if no_edit:
            args.append("--no-edit")

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Commit failed: {stderr}")

    print_success("Commit successful")
    return GitOperationResult(True, "Commit successful", {"output": stdout})


git_commit_single = git_commit


def git_rebase(
    repo_path: Optional[Path] = None,
    upstream: Optional[str] = None,
    branch: Optional[str] = None,
    interactive: bool = False,
    abort: bool = False,
    continue_rebase: bool = False,
    skip: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Rebase: {repo_name}")

    args = ["rebase"]
    if abort:
        args.append("--abort")
    elif continue_rebase:
        args.append("--continue")
    elif skip:
        args.append("--skip")
    else:
        if interactive:
            args.append("-i")
        if upstream:
            args.append(upstream)
        if branch:
            args.append(branch)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Rebase failed: {stderr}")

    print_success("Rebase successful")
    return GitOperationResult(True, "Rebase successful", {"output": stdout})


git_rebase_single = git_rebase


def git_cherry_pick(
    repo_path: Optional[Path] = None,
    commits: Optional[List[str]] = None,
    continue_cherry: bool = False,
    abort: bool = False,
    skip: bool = False,
    no_commit: bool = False,
    edit: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Cherry-pick: {repo_name}")

    args = ["cherry-pick"]
    if abort:
        args.append("--abort")
    elif continue_cherry:
        args.append("--continue")
    elif skip:
        args.append("--skip")
    else:
        if no_commit:
            args.append("-n")
        if edit:
            args.append("-e")
        if commits:
            args.extend(commits)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Cherry-pick failed: {stderr}")

    print_success("Cherry-pick successful")
    return GitOperationResult(True, "Cherry-pick successful", {"output": stdout})


git_cherry_pick_single = git_cherry_pick


def git_reset(
    repo_path: Optional[Path] = None,
    commit: Optional[str] = None,
    mode: str = "mixed",
    hard: bool = False,
    soft: bool = False,
    mixed: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Reset: {repo_name}")

    args = ["reset"]
    if hard:
        args.append("--hard")
    elif soft:
        args.append("--soft")
    elif mixed or mode == "mixed":
        args.append("--mixed")
    elif mode == "keep":
        args.append("--keep")
    elif mode == "merge":
        args.append("--merge")

    if commit:
        args.append(commit)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Reset failed: {stderr}")

    print_success("Reset successful")
    return GitOperationResult(True, "Reset successful", {"output": stdout})


git_reset_single = git_reset


def git_diff_enhanced(
    repo_path: Optional[Path] = None,
    staged: bool = False,
    cached: bool = False,
    stat: bool = False,
    name_only: bool = False,
    name_status: bool = False,
    color: bool = True,
    commit1: Optional[str] = None,
    commit2: Optional[str] = None
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()

    args = ["diff"]
    if color:
        args.append("--color=always")
    if staged or cached:
        args.append("--cached")
    if stat:
        args.append("--stat")
    if name_only:
        args.append("--name-only")
    if name_status:
        args.append("--name-status")
    if commit1:
        args.append(commit1)
        if commit2:
            args.append(commit2)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Failed to get diff: {stderr}")

    details = {
        "diff": stdout,
        "has_changes": bool(stdout.strip())
    }

    return GitOperationResult(True, "Got diff successfully", details)


git_diff_enhanced_single = git_diff_enhanced


def git_clean(
    repo_path: Optional[Path] = None,
    force: bool = False,
    directories: bool = False,
    dry_run: bool = False,
    ignored: bool = False,
    exclude: Optional[List[str]] = None
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Clean: {repo_name}")

    args = ["clean"]
    if dry_run:
        args.append("-n")
    else:
        if force:
            args.append("-f")
        if directories:
            args.append("-d")
        if ignored:
            args.append("-x")
    if exclude:
        for e in exclude:
            args.extend(["-e", e])

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Clean failed: {stderr}")

    if dry_run:
        print_info("Dry-run mode - will not actually delete files")
        print(stdout)
    else:
        print_success("Clean successful")
        if stdout:
            print(stdout)

    return GitOperationResult(True, "Clean successful", {"output": stdout})


git_clean_single = git_clean


def git_tag(
    repo_path: Optional[Path] = None,
    tag_name: Optional[str] = None,
    message: Optional[str] = None,
    annotated: bool = False,
    delete: bool = False,
    list_tags: bool = False,
    push: bool = False,
    remote: str = REMOTE_NAME
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Tag: {repo_name}")

    args = ["tag"]
    if list_tags:
        args.append("-l")
    elif delete:
        if tag_name:
            args.extend(["-d", tag_name])
    else:
        if annotated:
            args.append("-a")
        if message:
            args.extend(["-m", message])
        if tag_name:
            args.append(tag_name)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Tag operation failed: {stderr}")

    if push and tag_name and not delete and not list_tags:
        print_section(f"Pushing to remote: {remote}")
        push_code, push_stdout, push_stderr = run_git(repo_path, ["push", remote, tag_name])
        if push_code != 0:
            return GitOperationResult(False, f"Push tag failed: {push_stderr}")

    if list_tags:
        details = {"tags": stdout.strip().splitlines() if stdout.strip() else []}
        print(stdout)
    else:
        details = {"output": stdout}

    print_success("Tag operation successful")
    return GitOperationResult(True, "Tag operation successful", details)


git_tag_single = git_tag


def git_blame(
    repo_path: Optional[Path] = None,
    file_path: str = "",
    line: Optional[str] = None,
    show_email: bool = False,
    show_name: bool = True,
    show_date: bool = True
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()

    args = ["blame"]
    if show_email:
        args.append("-e")
    if not show_name:
        args.append("-s")
    if show_date:
        args.append("-t")
    if line:
        args.extend(["-L", line])
    args.append(file_path)

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Blame failed: {stderr}")

    return GitOperationResult(True, "Blame successful", {"output": stdout})


git_blame_single = git_blame


def git_bisect(
    repo_path: Optional[Path] = None,
    start: bool = False,
    bad: Optional[str] = None,
    good: Optional[List[str]] = None,
    reset: bool = False,
    skip: bool = False,
    visualize: bool = False
) -> GitOperationResult:
    if repo_path is None:
        repo_path = Path.cwd()
    repo_name = repo_path.name

    print_header(f"Bisect: {repo_name}")

    args = ["bisect"]
    if reset:
        args.append("reset")
    elif start:
        args.append("start")
    elif bad:
        args.extend(["bad", bad])
    elif good and good:
        args.append("good")
        args.extend(good)
    elif skip:
        args.append("skip")
    elif visualize:
        args.append("visualize")

    code, stdout, stderr = run_git(repo_path, args)
    if code != 0:
        return GitOperationResult(False, f"Bisect failed: {stderr}")

    print(stdout)
    print_success("Bisect operation successful")
    return GitOperationResult(True, "Bisect operation successful", {"output": stdout})


git_bisect_single = git_bisect

