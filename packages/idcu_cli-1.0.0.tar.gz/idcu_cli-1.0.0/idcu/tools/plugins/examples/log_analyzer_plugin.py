
import re
from collections import Counter, defaultdict
from pathlib import Path

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("log_analyzer_plugin")


class LogAnalyzerPlugin(Plugin):
    metadata = PluginMetadata(
        name="log_analyzer",
        version="1.0.0",
        description="Log analysis plugin for searching and summarizing log files.",
        author="IDCU Team",
    )

    def __init__(self):
        pass

    def initialize(self):
        logger.info("[LogAnalyzerPlugin] Initialized")

    def cleanup(self):
        logger.info("[LogAnalyzerPlugin] Cleaned up")

    def get_commands(self):
        return {
            "log.analyze": self.cmd_analyze,
            "log.search": self.cmd_search,
            "log.stats": self.cmd_stats,
            "log.errors": self.cmd_errors,
        }

    def get_hooks(self):
        return {}

    def _parse_log_line(self, line, log_format="common"):
        try:
            if log_format == "json":
                import json
                return json.loads(line.strip())
            else:
                return {"raw": line.strip()}
        except Exception:
            return None

    def cmd_analyze(self, file_path, log_format="common", error_pattern=None, date_format=None):
        file = Path(file_path)
        if not file.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
            }

        total_lines = 0
        error_count = 0
        warning_count = 0
        info_count = 0
        timestamps = []
        error_messages = []
        unique_errors = set()

        error_re = None
        if error_pattern:
            try:
                error_re = re.compile(error_pattern, re.IGNORECASE)
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Invalid error pattern: {str(e)}",
                }

        try:
            with open(file, encoding="utf-8", errors="replace") as f:
                for line in f:
                    total_lines += 1
                    line_lower = line.lower()

                    if "error" in line_lower or (error_re and error_re.search(line)):
                        error_count += 1
                        error_messages.append(line.strip())
                        if len(error_messages) > 100:
                            unique_errors.add(line.strip())
                    elif "warning" in line_lower or "warn" in line_lower:
                        warning_count += 1
                    elif "info" in line_lower:
                        info_count += 1

                    if date_format:
                        try:
                            parsed = self._parse_log_line(line, log_format)
                            if parsed and "timestamp" in parsed:
                                timestamps.append(parsed["timestamp"])
                        except Exception:
                            pass

            return {
                "success": True,
                "total_lines": total_lines,
                "error_count": error_count,
                "warning_count": warning_count,
                "info_count": info_count,
                "error_rate": (error_count / total_lines * 100) if total_lines > 0 else 0,
                "sample_errors": error_messages[:10],
                "unique_error_count": len(unique_errors) if unique_errors else error_count,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_search(self, file_path, pattern, case_sensitive=False, max_results=100, context_lines=0):
        file = Path(file_path)
        if not file.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
            }

        try:
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)

            results = []
            lines_buffer = []

            with open(file, encoding="utf-8", errors="replace") as f:
                for line_num, line in enumerate(f, 1):
                    lines_buffer.append((line_num, line.rstrip("\n")))
                    if len(lines_buffer) > context_lines * 2 + 1:
                        lines_buffer.pop(0)

                    if regex.search(line):
                        if len(results) >= max_results:
                            break

                        result = {
                            "line_number": line_num,
                            "line": line.rstrip("\n"),
                        }

                        if context_lines > 0:
                            context_before = []
                            context_after = []
                            for i, (num, line_text) in enumerate(lines_buffer):
                                if num == line_num:
                                    context_before = [line_text for n, line_text in lines_buffer[:i]]
                                    context_after = [line_text for n, line_text in lines_buffer[i+1:]]
                                    break
                            result["context_before"] = context_before[-context_lines:] if context_before else []
                            result["context_after"] = context_after[:context_lines] if context_after else []

                        results.append(result)

            return {
                "success": True,
                "total_matches": len(results),
                "results": results,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_stats(self, file_path, top_n=10):
        file = Path(file_path)
        if not file.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
            }

        try:
            line_lengths = []
            word_counter = Counter()
            first_chars = defaultdict(int)

            with open(file, encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.rstrip("\n")
                    line_lengths.append(len(line))

                    if line:
                        first_chars[line[0].upper()] += 1

                    words = re.findall(r"\b\w+\b", line)
                    word_counter.update(words)

            return {
                "success": True,
                "total_lines": len(line_lengths),
                "avg_line_length": sum(line_lengths) / len(line_lengths) if line_lengths else 0,
                "min_line_length": min(line_lengths) if line_lengths else 0,
                "max_line_length": max(line_lengths) if line_lengths else 0,
                "file_size_bytes": file.stat().st_size,
                "top_words": word_counter.most_common(top_n),
                "first_char_distribution": dict(sorted(first_chars.items(), key=lambda x: -x[1])[:top_n]),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_errors(self, file_path, max_errors=50):
        file = Path(file_path)
        if not file.exists():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
            }

        try:
            errors = []
            error_patterns = [
                r"error",
                r"exception",
                r"failed",
                r"fatal",
                r"critical",
            ]
            combined_pattern = re.compile("|".join(error_patterns), re.IGNORECASE)

            with open(file, encoding="utf-8", errors="replace") as f:
                for line_num, line in enumerate(f, 1):
                    if combined_pattern.search(line):
                        if len(errors) >= max_errors:
                            break
                        errors.append({
                            "line_number": line_num,
                            "line": line.rstrip("\n"),
                        })

            return {
                "success": True,
                "total_errors": len(errors),
                "errors": errors,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }


register_plugin(LogAnalyzerPlugin())

