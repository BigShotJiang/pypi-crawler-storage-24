
import subprocess

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("redis_plugin")


class RedisPlugin(Plugin):
    metadata = PluginMetadata(
        name="redis",
        version="1.0.0",
        description="Redis management plugin for common key-value operations.",
        author="IDCU Team",
    )

    def __init__(self):
        self.redis_cli_cmd = "redis-cli"

    def initialize(self):
        logger.info("[RedisPlugin] Initialized")

    def cleanup(self):
        logger.info("[RedisPlugin] Cleaned up")

    def get_commands(self):
        return {
            "redis.ping": self.cmd_ping,
            "redis.info": self.cmd_info,
            "redis.get": self.cmd_get,
            "redis.set": self.cmd_set,
            "redis.del": self.cmd_delete,
            "redis.keys": self.cmd_keys,
            "redis.exists": self.cmd_exists,
            "redis.ttl": self.cmd_ttl,
            "redis.expire": self.cmd_expire,
            "redis.dbsize": self.cmd_dbsize,
            "redis.flushdb": self.cmd_flushdb,
            "redis.flushall": self.cmd_flushall,
        }

    def get_hooks(self):
        return {}

    def _run_redis_command(self, args, host=None, port=None, password=None):
        cmd = [self.redis_cli_cmd]
        if host:
            cmd.extend(["-h", host])
        if port:
            cmd.extend(["-p", str(port)])
        if password:
            cmd.extend(["-a", password])
        cmd.extend(args)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_ping(self, host=None, port=None, password=None):
        result = self._run_redis_command(["PING"], host, port, password)
        if result["success"]:
            result["pong"] = result["stdout"].strip()
        return result

    def cmd_info(self, section=None, host=None, port=None, password=None):
        args = ["INFO"]
        if section:
            args.append(section)
        result = self._run_redis_command(args, host, port, password)
        return result

    def cmd_get(self, key, host=None, port=None, password=None):
        result = self._run_redis_command(["GET", key], host, port, password)
        if result["success"]:
            result["value"] = result["stdout"].strip()
        return result

    def cmd_set(self, key, value, nx=False, xx=False, ex=None, px=None, host=None, port=None, password=None):
        args = ["SET", key, value]
        if nx:
            args.append("NX")
        if xx:
            args.append("XX")
        if ex:
            args.extend(["EX", str(ex)])
        if px:
            args.extend(["PX", str(px)])
        result = self._run_redis_command(args, host, port, password)
        return result

    def cmd_delete(self, key, host=None, port=None, password=None):
        result = self._run_redis_command(["DEL", key], host, port, password)
        if result["success"]:
            result["deleted"] = int(result["stdout"].strip())
        return result

    def cmd_keys(self, pattern="*", host=None, port=None, password=None):
        result = self._run_redis_command(["KEYS", pattern], host, port, password)
        if result["success"]:
            result["keys"] = [k for k in result["stdout"].split("\n") if k]
        return result

    def cmd_exists(self, key, host=None, port=None, password=None):
        result = self._run_redis_command(["EXISTS", key], host, port, password)
        if result["success"]:
            result["exists"] = int(result["stdout"].strip()) == 1
        return result

    def cmd_ttl(self, key, host=None, port=None, password=None):
        result = self._run_redis_command(["TTL", key], host, port, password)
        if result["success"]:
            result["ttl"] = int(result["stdout"].strip())
        return result

    def cmd_expire(self, key, seconds, host=None, port=None, password=None):
        result = self._run_redis_command(["EXPIRE", key, str(seconds)], host, port, password)
        return result

    def cmd_dbsize(self, host=None, port=None, password=None):
        result = self._run_redis_command(["DBSIZE"], host, port, password)
        if result["success"]:
            result["size"] = int(result["stdout"].strip())
        return result

    def cmd_flushdb(self, host=None, port=None, password=None):
        result = self._run_redis_command(["FLUSHDB"], host, port, password)
        return result

    def cmd_flushall(self, host=None, port=None, password=None):
        result = self._run_redis_command(["FLUSHALL"], host, port, password)
        return result


register_plugin(RedisPlugin())
