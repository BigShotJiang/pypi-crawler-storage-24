
from pathlib import Path
from typing import Any, Callable, Dict

from ...git import git_pull, git_push, git_status
from ..base import Plugin, PluginMetadata, register_plugin


class GitPlugin(Plugin):
    metadata = PluginMetadata(
        name="git",
        version="1.0.0",
        description="Git operation plugin, providing convenient Git command interfaces",
        author="IDCU Team",
    )

    def __init__(self):
        self.current_repo = Path.cwd()

    def initialize(self) -> None:
        print(f"[GitPlugin] Initialized at: {self.current_repo}")

    def cleanup(self) -> None:
        print("[GitPlugin] Cleaned up")

    def get_commands(self) -> Dict[str, Callable]:
        return {
            "git.status": self.cmd_status,
            "git.push": self.cmd_push,
            "git.pull": self.cmd_pull,
        }

    def get_hooks(self) -> Dict[str, Callable]:
        return {
            "before_git_operation": self.hook_before_operation,
            "after_git_operation": self.hook_after_operation,
        }

    def cmd_status(self, repo_path: str = None) -> Dict[str, Any]:
        path = Path(repo_path) if repo_path else self.current_repo
        result = git_status(path)
        return {
            "success": result.success,
            "message": result.message,
            "details": result.details if hasattr(result, 'details') else None
        }

    def cmd_push(self, message: str, repo_path: str = None, **kwargs) -> Dict[str, Any]:
        path = Path(repo_path) if repo_path else self.current_repo
        result = git_push(message, path, **kwargs)
        return {
            "success": result.success,
            "message": result.message,
            "details": result.details if hasattr(result, 'details') else None
        }

    def cmd_pull(self, repo_path: str = None, **kwargs) -> Dict[str, Any]:
        path = Path(repo_path) if repo_path else self.current_repo
        result = git_pull(path, **kwargs)
        return {
            "success": result.success,
            "message": result.message,
            "details": result.details if hasattr(result, 'details') else None
        }

    def hook_before_operation(self, operation: str, **kwargs) -> None:
        print(f"[GitPlugin] Before {operation} operation")

    def hook_after_operation(self, operation: str, result: Any, **kwargs) -> None:
        print(f"[GitPlugin] After {operation} operation, result: {result}")


register_plugin(GitPlugin())
