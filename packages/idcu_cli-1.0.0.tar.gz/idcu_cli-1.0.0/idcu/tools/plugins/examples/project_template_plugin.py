
import os
from pathlib import Path

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("project_template_plugin")


class ProjectTemplatePlugin(Plugin):
    metadata = PluginMetadata(
        name="project_template",
        version="1.0.0",
        description="项目模板插件 - 提供项目模板生成功能",
        author="IDCU Team",
    )

    def __init__(self):
        pass

    def initialize(self):
        logger.info("[ProjectTemplatePlugin] Initialized")

    def cleanup(self):
        logger.info("[ProjectTemplatePlugin] Cleaned up")

    def get_commands(self):
        return {
            "template.list": self.cmd_list,
            "template.create": self.cmd_create,
        }

    def get_hooks(self):
        return {}

    def _get_java_pom_content(self, name):
        return f'''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>{name}</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
</project>
'''

    def _get_templates(self):
        return {
            "python": {
                "name": "Python Basic Project",
                "description": "基础Python项目模板",
                "files": [
                    {
                        "path": "README.md",
                        "content": "# {name}\n\nA Python project.\n",
                    },
                    {
                        "path": "requirements.txt",
                        "content": "# Add your dependencies here\n",
                    },
                    {
                        "path": "src/__init__.py",
                        "content": "",
                    },
                    {
                        "path": "src/main.py",
                        "content": 'def main():\n    print("Hello, World!")\n\n\nif __name__ == "__main__":\n    main()\n',
                    },
                ],
            },
            "python_flask": {
                "name": "Python Flask Project",
                "description": "Flask Web应用项目模板",
                "files": [
                    {
                        "path": "README.md",
                        "content": "# {name}\n\nA Flask web application.\n",
                    },
                    {
                        "path": "requirements.txt",
                        "content": "flask>=2.0.0\n",
                    },
                    {
                        "path": "app/__init__.py",
                        "content": "from flask import Flask\n\napp = Flask(__name__)\n\nfrom app import routes\n",
                    },
                    {
                        "path": "app/routes.py",
                        "content": 'from app import app\n\n\n@app.route("/")\ndef index():\n    return "Hello, World!"\n',
                    },
                    {
                        "path": "run.py",
                        "content": 'from app import app\n\n\nif __name__ == "__main__":\n    app.run(debug=True)\n',
                    },
                ],
            },
            "java_maven": {
                "name": "Java Maven Project",
                "description": "Java Maven项目模板",
                "files": [
                    {
                        "path": "README.md",
                        "content": "# {name}\n\nA Java Maven project.\n",
                    },
                    {
                        "path": "pom.xml",
                        "content": None,
                    },
                    {
                        "path": "src/main/java/com/example/App.java",
                        "content": 'package com.example;\n\npublic class App {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}\n',
                    },
                ],
            },
        }

    def cmd_list(self):
        templates = self._get_templates()
        result = []
        for key, template in templates.items():
            result.append({
                "id": key,
                "name": template["name"],
                "description": template["description"],
            })
        return {
            "success": True,
            "templates": result,
        }

    def cmd_create(self, template_id, output_dir, name=None):
        templates = self._get_templates()
        if template_id not in templates:
            return {
                "success": False,
                "error": f"Template not found: {template_id}",
            }

        template = templates[template_id]
        project_name = name or os.path.basename(output_dir)

        try:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)

            created_files = []

            for file_info in template["files"]:
                file_path = output_path / file_info["path"]
                file_path.parent.mkdir(parents=True, exist_ok=True)

                if file_info["content"] is None and file_info["path"] == "pom.xml":
                    content = self._get_java_pom_content(project_name)
                else:
                    content = file_info["content"].format(name=project_name)

                file_path.write_text(content, encoding="utf-8")
                created_files.append(file_info["path"])

            return {
                "success": True,
                "message": f"Project created successfully: {output_dir}",
                "template": template_id,
                "project_name": project_name,
                "files": created_files,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }


register_plugin(ProjectTemplatePlugin())

