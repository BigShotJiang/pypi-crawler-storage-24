
import os
import platform
import sys
from typing import Any, Callable, Dict

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin


class SystemInfoPlugin(Plugin):
    metadata = PluginMetadata(
        name="system_info",
        version="1.0.0",
        description="System information plugin for OS, Python, and environment details.",
        author="IDCU Team",
    )

    def initialize(self) -> None:
        pass

    def get_commands(self) -> Dict[str, Callable]:
        return {
            "system-info": self.cmd_system_info,
            "python-info": self.cmd_python_info,
            "env-info": self.cmd_env_info,
        }

    def cmd_system_info(self) -> Dict[str, str]:
        """Return basic operating-system information."""
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "architecture": platform.architecture()[0],
        }

    def cmd_python_info(self) -> Dict[str, Any]:
        """Return details about the current Python runtime."""
        return {
            "version": sys.version,
            "version_info": {
                "major": sys.version_info.major,
                "minor": sys.version_info.minor,
                "micro": sys.version_info.micro,
                "releaselevel": sys.version_info.releaselevel,
                "serial": sys.version_info.serial,
            },
            "implementation": platform.python_implementation(),
            "compiler": platform.python_compiler(),
            "executable": sys.executable,
            "prefix": sys.prefix,
            "exec_prefix": sys.exec_prefix,
        }

    def cmd_env_info(self, vars: str = "") -> Dict[str, str]:
        """Return selected environment variables or the full environment."""
        if vars:
            var_list = [v.strip() for v in vars.split(",")]
            return {v: os.environ.get(v, "") for v in var_list}
        else:
            return dict(os.environ)


register_plugin(SystemInfoPlugin())
