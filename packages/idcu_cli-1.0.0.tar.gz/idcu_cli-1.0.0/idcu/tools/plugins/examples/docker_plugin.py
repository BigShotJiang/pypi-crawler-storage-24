
import subprocess

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("docker_plugin")


class DockerPlugin(Plugin):
    metadata = PluginMetadata(
        name="docker",
        version="1.0.0",
        description="Docker management plugin for container and image operations.",
        author="IDCU Team",
    )

    def __init__(self):
        self.docker_cmd = "docker"

    def initialize(self):
        logger.info("[DockerPlugin] Initialized")

    def cleanup(self):
        logger.info("[DockerPlugin] Cleaned up")

    def get_commands(self):
        return {
            "docker.ps": self.cmd_ps,
            "docker.images": self.cmd_images,
            "docker.run": self.cmd_run,
            "docker.stop": self.cmd_stop,
            "docker.rm": self.cmd_rm,
            "docker.rmi": self.cmd_rmi,
            "docker.build": self.cmd_build,
            "docker.logs": self.cmd_logs,
        }

    def get_hooks(self):
        return {}

    def _run_docker_command(self, args):
        try:
            result = subprocess.run(
                [self.docker_cmd] + args,
                capture_output=True,
                text=True,
                timeout=300,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_ps(self, all_containers=False):
        args = ["ps"]
        if all_containers:
            args.append("-a")
        args.extend(["--format", "{{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Image}}"])

        result = self._run_docker_command(args)
        if result["success"]:
            containers = []
            for line in result["stdout"].strip().split("\n"):
                if line:
                    parts = line.split("\t")
                    containers.append({
                        "id": parts[0] if len(parts) > 0 else "",
                        "name": parts[1] if len(parts) > 1 else "",
                        "status": parts[2] if len(parts) > 2 else "",
                        "image": parts[3] if len(parts) > 3 else "",
                    })
            result["containers"] = containers
        return result

    def cmd_images(self):
        args = ["images", "--format", "{{.ID}}\t{{.Repository}}\t{{.Tag}}\t{{.Size}}"]
        result = self._run_docker_command(args)
        if result["success"]:
            images = []
            for line in result["stdout"].strip().split("\n"):
                if line:
                    parts = line.split("\t")
                    images.append({
                        "id": parts[0] if len(parts) > 0 else "",
                        "repository": parts[1] if len(parts) > 1 else "",
                        "tag": parts[2] if len(parts) > 2 else "",
                        "size": parts[3] if len(parts) > 3 else "",
                    })
            result["images"] = images
        return result

    def cmd_run(self, image, name=None, ports=None, detach=True, environment=None, command=None):
        args = ["run"]
        if name:
            args.extend(["--name", name])
        if ports:
            for port in ports:
                args.extend(["-p", port])
        if detach:
            args.append("-d")
        if environment:
            for env in environment:
                args.extend(["-e", env])
        args.append(image)
        if command:
            args.extend(command.split())

        return self._run_docker_command(args)

    def cmd_stop(self, container, timeout=10):
        args = ["stop", "-t", str(timeout), container]
        return self._run_docker_command(args)

    def cmd_rm(self, container, force=False):
        args = ["rm"]
        if force:
            args.append("-f")
        args.append(container)
        return self._run_docker_command(args)

    def cmd_rmi(self, image, force=False):
        args = ["rmi"]
        if force:
            args.append("-f")
        args.append(image)
        return self._run_docker_command(args)

    def cmd_build(self, path=".", tag=None, dockerfile=None):
        args = ["build"]
        if tag:
            args.extend(["-t", tag])
        if dockerfile:
            args.extend(["-f", dockerfile])
        args.append(path)
        return self._run_docker_command(args)

    def cmd_logs(self, container, follow=False, tail=None):
        args = ["logs"]
        if follow:
            args.append("-f")
        if tail is not None:
            args.extend(["--tail", str(tail)])
        args.append(container)
        return self._run_docker_command(args)


register_plugin(DockerPlugin())

