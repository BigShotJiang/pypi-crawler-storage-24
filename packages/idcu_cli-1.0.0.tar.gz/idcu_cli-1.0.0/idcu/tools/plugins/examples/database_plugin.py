
import sqlite3

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("database_plugin")


class DatabasePlugin(Plugin):
    metadata = PluginMetadata(
        name="database",
        version="1.0.0",
        description="Database management plugin with SQLite helpers.",
        author="IDCU Team",
    )

    def __init__(self):
        self.connections = {}

    def initialize(self):
        logger.info("[DatabasePlugin] Initialized")

    def cleanup(self):
        for conn in self.connections.values():
            try:
                conn.close()
            except Exception:
                pass
        self.connections.clear()
        logger.info("[DatabasePlugin] Cleaned up")

    def get_commands(self):
        return {
            "db.connect": self.cmd_connect,
            "db.disconnect": self.cmd_disconnect,
            "db.execute": self.cmd_execute,
            "db.query": self.cmd_query,
            "db.tables": self.cmd_tables,
        }

    def get_hooks(self):
        return {}

    def cmd_connect(self, db_path, name="default"):
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            self.connections[name] = conn
            return {
                "success": True,
                "message": f"Connected to database: {db_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_disconnect(self, name="default"):
        try:
            if name in self.connections:
                self.connections[name].close()
                del self.connections[name]
                return {
                    "success": True,
                    "message": f"Disconnected from database: {name}",
                }
            else:
                return {
                    "success": False,
                    "error": f"Database connection not found: {name}",
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_execute(self, sql, params=None, name="default"):
        try:
            if name not in self.connections:
                return {
                    "success": False,
                    "error": f"Database connection not found: {name}",
                }

            conn = self.connections[name]
            cursor = conn.cursor()

            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)

            conn.commit()

            return {
                "success": True,
                "rowcount": cursor.rowcount,
                "lastrowid": cursor.lastrowid,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_query(self, sql, params=None, name="default"):
        try:
            if name not in self.connections:
                return {
                    "success": False,
                    "error": f"Database connection not found: {name}",
                }

            conn = self.connections[name]
            cursor = conn.cursor()

            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)

            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description] if cursor.description else []

            result_rows = []
            for row in rows:
                result_rows.append(dict(row))

            return {
                "success": True,
                "columns": columns,
                "rows": result_rows,
                "rowcount": len(result_rows),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_tables(self, name="default"):
        return self.cmd_query(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",
            name=name
        )


register_plugin(DatabasePlugin())

