
import subprocess
from pathlib import Path

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("nginx_plugin")


class NginxPlugin(Plugin):
    metadata = PluginMetadata(
        name="nginx",
        version="1.0.0",
        description="Nginx configuration and administration plugin.",
        author="IDCU Team",
    )

    def __init__(self):
        self.nginx_cmd = "nginx"
        self.default_config_path = Path("/etc/nginx/nginx.conf")
        self.default_sites_available = Path("/etc/nginx/sites-available")
        self.default_sites_enabled = Path("/etc/nginx/sites-enabled")

    def initialize(self):
        logger.info("[NginxPlugin] Initialized")

    def cleanup(self):
        logger.info("[NginxPlugin] Cleaned up")

    def get_commands(self):
        return {
            "nginx.test": self.cmd_test_config,
            "nginx.reload": self.cmd_reload,
            "nginx.restart": self.cmd_restart,
            "nginx.stop": self.cmd_stop,
            "nginx.start": self.cmd_start,
            "nginx.status": self.cmd_status,
            "nginx.version": self.cmd_version,
            "nginx.create_site": self.cmd_create_site,
            "nginx.enable_site": self.cmd_enable_site,
            "nginx.disable_site": self.cmd_disable_site,
            "nginx.list_sites": self.cmd_list_sites,
        }

    def get_hooks(self):
        return {}

    def _run_nginx_command(self, args):
        try:
            result = subprocess.run(
                [self.nginx_cmd] + args,
                capture_output=True,
                text=True,
                timeout=60,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_test_config(self, config_path=None):
        args = ["-t"]
        if config_path:
            args.extend(["-c", config_path])
        return self._run_nginx_command(args)

    def cmd_reload(self):
        return self._run_nginx_command(["-s", "reload"])

    def cmd_restart(self):
        result = self.cmd_stop()
        if result["success"]:
            return self.cmd_start()
        return result

    def cmd_stop(self):
        return self._run_nginx_command(["-s", "stop"])

    def cmd_start(self):
        return self._run_nginx_command([])

    def cmd_status(self):
        try:
            result = subprocess.run(
                ["systemctl", "status", "nginx"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
            }
        except Exception:
            return self._run_nginx_command(["-v"])

    def cmd_version(self):
        return self._run_nginx_command(["-v"])

    def cmd_create_site(self, domain, port, root_path=None, config_path=None):
        if config_path is None:
            config_path = self.default_sites_available / domain

        if root_path is None:
            root_path = f"/var/www/{domain}"

        config_content = f"""server {{
    listen 80;
    listen [::]:80;

    server_name {domain};

    root {root_path};
    index index.html index.htm;

    location / {{
        proxy_pass http://localhost:{port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}
"""

        try:
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(config_content)
            return {
                "success": True,
                "config_path": str(config_path),
                "content": config_content,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_enable_site(self, domain, sites_available=None, sites_enabled=None):
        if sites_available is None:
            sites_available = self.default_sites_available
        if sites_enabled is None:
            sites_enabled = self.default_sites_enabled

        available_path = Path(sites_available) / domain
        enabled_path = Path(sites_enabled) / domain

        if not available_path.exists():
            return {
                "success": False,
                "error": f"Site configuration not found: {available_path}",
            }

        try:
            sites_enabled.mkdir(parents=True, exist_ok=True)
            if enabled_path.exists():
                if enabled_path.is_symlink():
                    enabled_path.unlink()
                else:
                    return {
                        "success": False,
                        "error": f"File exists and is not a symlink: {enabled_path}",
                    }
            enabled_path.symlink_to(available_path)
            return {
                "success": True,
                "enabled_path": str(enabled_path),
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_disable_site(self, domain, sites_enabled=None):
        if sites_enabled is None:
            sites_enabled = self.default_sites_enabled

        enabled_path = Path(sites_enabled) / domain

        if not enabled_path.exists():
            return {
                "success": False,
                "error": f"Site not found: {enabled_path}",
            }

        try:
            if enabled_path.is_symlink():
                enabled_path.unlink()
                return {
                    "success": True,
                    "message": f"Site disabled: {domain}",
                }
            else:
                return {
                    "success": False,
                    "error": f"Not a symlink: {enabled_path}",
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_list_sites(self, sites_available=None, sites_enabled=None):
        if sites_available is None:
            sites_available = self.default_sites_available
        if sites_enabled is None:
            sites_enabled = self.default_sites_enabled

        available_sites = []
        enabled_sites = []

        try:
            if Path(sites_available).exists():
                available_sites = [
                    f.name for f in Path(sites_available).iterdir()
                    if f.is_file()
                ]

            if Path(sites_enabled).exists():
                enabled_sites = [
                    f.name for f in Path(sites_enabled).iterdir()
                    if f.is_symlink()
                ]

            return {
                "success": True,
                "available": available_sites,
                "enabled": enabled_sites,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }


register_plugin(NginxPlugin())
