
from pathlib import Path
from typing import Callable, Dict, List

from idcu.tools.plugins import Plugin, PluginMetadata


class FileUtilsPlugin(Plugin):
    metadata = PluginMetadata(
        name="file_utils",
        version="1.0.0",
        description="File utility plugin for searching and counting files.",
        author="IDCU Team",
    )

    def initialize(self) -> None:
        pass

    def get_commands(self) -> Dict[str, Callable]:
        return {
            "count-files": self.cmd_count_files,
            "find-files": self.cmd_find_files,
            "file-stats": self.cmd_file_stats,
        }

    def cmd_count_files(self, directory: str = ".", pattern: str = "*") -> str:
        """Count files in a directory that match a glob pattern."""
        dir_path = Path(directory)
        if not dir_path.exists():
            return f"Directory does not exist: {directory}"

        count = len(list(dir_path.glob(pattern)))
        return f"Found {count} files in {directory} (pattern: {pattern})"

    def cmd_find_files(self, directory: str = ".", extension: str = "") -> List[str]:
        """Find files by extension under a directory."""
        dir_path = Path(directory)
        if not dir_path.exists():
            return []

        if extension:
            pattern = f"**/*{extension}"
        else:
            pattern = "**/*"

        files = [str(f) for f in dir_path.glob(pattern) if f.is_file()]
        return files

    def cmd_file_stats(self, directory: str = ".") -> Dict[str, any]:
        """Return basic file statistics for a directory tree."""
        dir_path = Path(directory)
        if not dir_path.exists():
            return {"error": f"Directory does not exist: {directory}"}

        total_files = 0
        total_dirs = 0
        total_size = 0
        extensions = {}

        for item in dir_path.rglob("*"):
            if item.is_file():
                total_files += 1
                total_size += item.stat().st_size
                ext = item.suffix.lower()
                extensions[ext] = extensions.get(ext, 0) + 1
            elif item.is_dir():
                total_dirs += 1

        return {
            "directory": str(dir_path),
            "total_files": total_files,
            "total_directories": total_dirs,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "extensions": extensions
        }
