
import urllib.error
import urllib.parse
import urllib.request

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("http_client_plugin")


class HTTPClientPlugin(Plugin):
    metadata = PluginMetadata(
        name="http_client",
        version="1.0.0",
        description="HTTP client plugin for basic request execution.",
        author="IDCU Team",
    )

    def __init__(self):
        self.timeout = 30

    def initialize(self):
        logger.info("[HTTPClientPlugin] Initialized")

    def cleanup(self):
        logger.info("[HTTPClientPlugin] Cleaned up")

    def get_commands(self):
        return {
            "http.get": self.cmd_get,
            "http.post": self.cmd_post,
            "http.put": self.cmd_put,
            "http.delete": self.cmd_delete,
            "http.patch": self.cmd_patch,
        }

    def get_hooks(self):
        return {}

    def _make_request(self, url, method="GET", data=None, headers=None, params=None):
        try:
            full_url = url
            if params:
                query_string = urllib.parse.urlencode(params)
                if "?" in url:
                    full_url = url + "&" + query_string
                else:
                    full_url = url + "?" + query_string

            req_data = None
            if data:
                if isinstance(data, dict):
                    req_data = urllib.parse.urlencode(data).encode("utf-8")
                elif isinstance(data, str):
                    req_data = data.encode("utf-8")
                else:
                    req_data = data

            req = urllib.request.Request(full_url, data=req_data, headers=headers or {}, method=method)

            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                content = response.read()
                try:
                    text_content = content.decode("utf-8")
                except UnicodeDecodeError:
                    text_content = content.decode("latin-1")

                return {
                    "success": True,
                    "status_code": response.status,
                    "headers": dict(response.getheaders()),
                    "content": text_content,
                    "raw_content": content,
                }
        except urllib.error.HTTPError as e:
            return {
                "success": False,
                "status_code": e.code,
                "error": f"HTTP Error: {e.code} - {e.reason}",
            }
        except urllib.error.URLError as e:
            return {
                "success": False,
                "error": f"URL Error: {str(e.reason)}",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_get(self, url, headers=None, params=None):
        return self._make_request(url, method="GET", headers=headers, params=params)

    def cmd_post(self, url, data=None, headers=None, params=None):
        return self._make_request(url, method="POST", data=data, headers=headers, params=params)

    def cmd_put(self, url, data=None, headers=None, params=None):
        return self._make_request(url, method="PUT", data=data, headers=headers, params=params)

    def cmd_delete(self, url, headers=None, params=None):
        return self._make_request(url, method="DELETE", headers=headers, params=params)

    def cmd_patch(self, url, data=None, headers=None, params=None):
        return self._make_request(url, method="PATCH", data=data, headers=headers, params=params)


register_plugin(HTTPClientPlugin())

