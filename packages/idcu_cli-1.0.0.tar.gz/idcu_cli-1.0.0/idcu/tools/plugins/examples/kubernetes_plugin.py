
import subprocess

from idcu.tools.plugins import Plugin, PluginMetadata, register_plugin
from idcu.system.logger import get_logger

logger = get_logger("kubernetes_plugin")


class KubernetesPlugin(Plugin):
    metadata = PluginMetadata(
        name="kubernetes",
        version="1.0.0",
        description="Kubernetes管理插件 - 提供Kubernetes集群管理功能",
        author="IDCU Team",
    )

    def __init__(self):
        self.kubectl_cmd = "kubectl"

    def initialize(self):
        logger.info("[KubernetesPlugin] Initialized")

    def cleanup(self):
        logger.info("[KubernetesPlugin] Cleaned up")

    def get_commands(self):
        return {
            "k8s.get_pods": self.cmd_get_pods,
            "k8s.get_services": self.cmd_get_services,
            "k8s.get_deployments": self.cmd_get_deployments,
            "k8s.get_namespaces": self.cmd_get_namespaces,
            "k8s.describe": self.cmd_describe,
            "k8s.logs": self.cmd_logs,
            "k8s.exec": self.cmd_exec,
            "k8s.apply": self.cmd_apply,
            "k8s.delete": self.cmd_delete,
            "k8s.get_nodes": self.cmd_get_nodes,
        }

    def get_hooks(self):
        return {}

    def _run_kubectl_command(self, args):
        try:
            result = subprocess.run(
                [self.kubectl_cmd] + args,
                capture_output=True,
                text=True,
                timeout=300,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def cmd_get_pods(self, namespace=None, all_namespaces=False, selector=None):
        args = ["get", "pods", "-o", "wide"]
        if all_namespaces:
            args.append("-A")
        elif namespace:
            args.extend(["-n", namespace])
        if selector:
            args.extend(["-l", selector])

        result = self._run_kubectl_command(args)
        return result

    def cmd_get_services(self, namespace=None, all_namespaces=False):
        args = ["get", "svc", "-o", "wide"]
        if all_namespaces:
            args.append("-A")
        elif namespace:
            args.extend(["-n", namespace])

        result = self._run_kubectl_command(args)
        return result

    def cmd_get_deployments(self, namespace=None, all_namespaces=False):
        args = ["get", "deployments", "-o", "wide"]
        if all_namespaces:
            args.append("-A")
        elif namespace:
            args.extend(["-n", namespace])

        result = self._run_kubectl_command(args)
        return result

    def cmd_get_namespaces(self):
        args = ["get", "namespaces"]
        result = self._run_kubectl_command(args)
        return result

    def cmd_get_nodes(self):
        args = ["get", "nodes", "-o", "wide"]
        result = self._run_kubectl_command(args)
        return result

    def cmd_describe(self, resource_type, resource_name, namespace=None):
        args = ["describe", resource_type, resource_name]
        if namespace:
            args.extend(["-n", namespace])

        result = self._run_kubectl_command(args)
        return result

    def cmd_logs(self, pod_name, container=None, follow=False, tail=None, namespace=None):
        args = ["logs", pod_name]
        if container:
            args.extend(["-c", container])
        if follow:
            args.append("-f")
        if tail is not None:
            args.extend(["--tail", str(tail)])
        if namespace:
            args.extend(["-n", namespace])

        result = self._run_kubectl_command(args)
        return result

    def cmd_exec(self, pod_name, command, container=None, namespace=None):
        args = ["exec", pod_name]
        if container:
            args.extend(["-c", container])
        if namespace:
            args.extend(["-n", namespace])
        args.append("--")
        args.extend(command.split())

        result = self._run_kubectl_command(args)
        return result

    def cmd_apply(self, file_path, namespace=None):
        args = ["apply", "-f", file_path]
        if namespace:
            args.extend(["-n", namespace])

        result = self._run_kubectl_command(args)
        return result

    def cmd_delete(self, resource_type, resource_name, namespace=None, force=False):
        args = ["delete", resource_type, resource_name]
        if namespace:
            args.extend(["-n", namespace])
        if force:
            args.extend(["--force", "--grace-period=0"])

        result = self._run_kubectl_command(args)
        return result


register_plugin(KubernetesPlugin())
