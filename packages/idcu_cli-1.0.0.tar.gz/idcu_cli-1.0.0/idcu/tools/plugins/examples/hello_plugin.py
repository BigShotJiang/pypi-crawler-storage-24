
from typing import Any, Callable, Dict

from ..base import Plugin, PluginMetadata, register_plugin


class HelloPlugin(Plugin):
    metadata = PluginMetadata(
        name="hello",
        version="1.0.0",
        description="A simple hello world plugin",
        author="IDCU Team",
    )

    def initialize(self) -> None:
        print("HelloPlugin initialized!")

    def cleanup(self) -> None:
        print("HelloPlugin cleaned up!")

    def get_commands(self) -> Dict[str, Callable]:
        return {
            "hello": self.say_hello,
        }

    def get_hooks(self) -> Dict[str, Callable]:
        return {
            "before_command": self.before_command_hook,
            "after_command": self.after_command_hook,
        }

    def say_hello(self, name: str = "World") -> str:
        return f"Hello, {name}!"

    def before_command_hook(self, command_name: str) -> None:
        print(f"[HelloPlugin] Before command: {command_name}")

    def after_command_hook(self, command_name: str, result: Any) -> None:
        print(f"[HelloPlugin] After command: {command_name}, result: {result}")


register_plugin(HelloPlugin())
