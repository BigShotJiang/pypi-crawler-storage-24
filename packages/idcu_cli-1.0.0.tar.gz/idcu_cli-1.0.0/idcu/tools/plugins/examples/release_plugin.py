
from pathlib import Path
from typing import Any, Callable, Dict, List

from idcu.tools.git.git_ops import run_git_checked
from idcu.tools.maven.maven_ops import run_maven_checked
from idcu.system.config_manager import get_config_manager
from idcu.system.logger import get_logger

from ..base import Plugin, PluginMetadata, register_plugin

logger = get_logger("release_plugin")


class ReleasePlugin(Plugin):
    metadata = PluginMetadata(
        name="release",
        version="1.0.0-SNAPSHOT",
        description="Universal release management plugin, supporting multiple build tools and repositories",
        author="IDCU Team",
    )

    def __init__(self):
        self.project_path = Path.cwd()
        self.config_manager = get_config_manager()

    def initialize(self) -> None:
        logger.info(f"[ReleasePlugin] Initialized at: {self.project_path}")

    def cleanup(self) -> None:
        logger.info("[ReleasePlugin] Cleaned up")

    def get_commands(self) -> Dict[str, Callable]:
        return {
            "release.create_branch": self.cmd_create_release_branch,
            "release.update_version": self.cmd_update_version,
            "release.build": self.cmd_build,
            "release.deploy": self.cmd_deploy,
            "release.tag": self.cmd_create_tag,
            "release.full": self.cmd_full_release,
            "release.config": self.cmd_show_config,
        }

    def get_hooks(self) -> Dict[str, Callable]:
        return {
            "before_release": self.hook_before_release,
            "after_release": self.hook_after_release,
        }

    def _get_config(self, key: str, default: Any = None) -> Any:
        """从配置管理器获取配置，支持项目特定配置和全局默认配置"""
        config_path = self.project_path / ".idcu" / "config.yaml"
        if config_path.exists():
            try:
                import yaml
                with open(config_path, encoding='utf-8') as f:
                    project_config = yaml.safe_load(f)
                    if project_config and "release" in project_config:
                        if key in project_config["release"]:
                            return project_config["release"][key]
            except Exception as e:
                logger.debug(f"Failed to load project config: {e}")

        return self.config_manager.get("release", key, default)

    def _get_branch_pattern(self) -> str:
        return self._get_config("branch_pattern", "release/{version}")

    def _get_tag_pattern(self) -> str:
        return self._get_config("tag_pattern", "v{version}")

    def _get_tag_message_pattern(self) -> str:
        return self._get_config("tag_message_pattern", "Release version {version}")

    def _get_repositories(self) -> Dict[str, Dict[str, str]]:
        default_repos = {
            "maven-central": {
                "type": "maven",
                "url": "https://oss.sonatype.org/service/local/staging/deploy/maven2/",
                "description": "Maven Central Repository"
            },
            "gitee": {
                "type": "maven",
                "url": "https://packages.gitee.com/{owner}/maven",
                "owner": "idcu",
                "description": "Gitee Maven Repository"
            }
        }
        return self._get_config("repositories", default_repos)

    def _update_pom_version(self, pom_path: Path, old_version: str, new_version: str) -> bool:
        try:
            with open(pom_path, encoding='utf-8') as f:
                content = f.read()

            updated_content = content.replace(
                f"<version>{old_version}</version>",
                f"<version>{new_version}</version>"
            )

            with open(pom_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)

            logger.info(f"Updated version in {pom_path}: {old_version} -> {new_version}")
            return True
        except Exception as e:
            logger.error(f"Failed to update version in {pom_path}: {e}")
            return False

    def _find_all_poms(self, root_path: Path) -> List[Path]:
        poms = []
        for pom_path in root_path.rglob("pom.xml"):
            if "target" not in pom_path.parts:
                poms.append(pom_path)
        return poms

    def cmd_show_config(self) -> Dict[str, Any]:
        """Show current release configuration. Usage: release.config"""
        return {
            "success": True,
            "config": {
                "branch_pattern": self._get_branch_pattern(),
                "tag_pattern": self._get_tag_pattern(),
                "tag_message_pattern": self._get_tag_message_pattern(),
                "repositories": self._get_repositories()
            }
        }

    def cmd_create_release_branch(self, version: str, repo_path: str = None, branch_pattern: str = None) -> Dict[str, Any]:
        """Create a release branch. Usage: release.create_branch version=1.0.0 [repo_path=.] [branch_pattern=release/{version}]"""
        path = Path(repo_path) if repo_path else self.project_path
        pattern = branch_pattern or self._get_branch_pattern()
        branch_name = pattern.format(version=version)

        logger.info(f"Creating release branch: {branch_name}")

        success, stdout, stderr = run_git_checked(path, ["checkout", "-b", branch_name])

        return {
            "success": success,
            "branch": branch_name,
            "pattern": pattern,
            "message": stdout if success else stderr,
        }

    def cmd_update_version(self, old_version: str, new_version: str, repo_path: str = None,
                          build_tool: str = "maven") -> Dict[str, Any]:
        """Update version in project files. Usage: release.update_version old_version=1.0.0-SNAPSHOT new_version=1.0.0 [repo_path=.] [build_tool=maven]"""
        path = Path(repo_path) if repo_path else self.project_path

        if build_tool == "maven":
            poms = self._find_all_poms(path)

            updated = []
            failed = []

            for pom in poms:
                if self._update_pom_version(pom, old_version, new_version):
                    updated.append(str(pom))
                else:
                    failed.append(str(pom))

            return {
                "success": len(failed) == 0,
                "build_tool": build_tool,
                "updated": updated,
                "failed": failed,
                "old_version": old_version,
                "new_version": new_version,
            }
        else:
            return {
                "success": False,
                "message": f"Unsupported build tool: {build_tool}",
                "supported_tools": ["maven"]
            }

    def cmd_build(self, repo_path: str = None, skip_tests: bool = False,
                  profile: str = None, build_tool: str = "maven", goals: List[str] = None) -> Dict[str, Any]:
        """Build the project. Usage: release.build [repo_path=.] [skip_tests=false] [profile=release] [build_tool=maven] [goals=clean,install]"""
        path = Path(repo_path) if repo_path else self.project_path

        if build_tool == "maven":
            default_goals = ["clean", "install"] if goals is None else goals
            args = []

            if skip_tests:
                args.append("-DskipTests")

            if profile:
                args.append(f"-P{profile}")

            logger.info(f"Building Maven project with: {' '.join(default_goals + args)}")

            success, stdout, stderr = run_maven_checked(path, default_goals, args=args, description="Build project")

            return {
                "success": success,
                "build_tool": build_tool,
                "goals": default_goals,
                "output": stdout,
                "error": stderr,
            }
        else:
            return {
                "success": False,
                "message": f"Unsupported build tool: {build_tool}",
                "supported_tools": ["maven"]
            }

    def cmd_deploy(self, target: str = "maven-central", repo_path: str = None,
                  skip_tests: bool = False, build_tool: str = "maven",
                  custom_url: str = None, **kwargs) -> Dict[str, Any]:
        """Deploy to repository. Usage: release.deploy [target=maven-central|gitee|custom] [repo_path=.] [skip_tests=false] [build_tool=maven] [custom_url=...]"""
        path = Path(repo_path) if repo_path else self.project_path
        repositories = self._get_repositories()

        if target == "all":
            results = {}
            all_success = True
            for repo_name in repositories.keys():
                logger.info(f"Deploying to {repo_name}...")
                result = self.cmd_deploy(repo_name, str(path), skip_tests, build_tool)
                results[repo_name] = result
                if not result.get("success", False):
                    all_success = False
            return {
                "success": all_success,
                "target": target,
                "results": results
            }

        if build_tool == "maven":
            goals = ["clean", "deploy"]
            args = ["-Prelease"]

            if skip_tests:
                args.append("-DskipTests")

            repo_config = None
            if target == "custom" and custom_url:
                repo_config = {"type": "maven", "url": custom_url}
            elif target in repositories:
                repo_config = repositories[target]
            else:
                return {
                    "success": False,
                    "message": f"Unknown repository target: {target}",
                    "available_targets": list(repositories.keys()) + ["custom", "all"]
                }

            if repo_config.get("type") == "maven":
                url = repo_config["url"]
                if "{owner}" in url and "owner" in repo_config:
                    url = url.format(owner=repo_config["owner"])

                if target != "maven-central":
                    args.extend([
                        f"-DaltDeploymentRepository={target}::default::{url}"
                    ])

                logger.info(f"Deploying to {target} ({url}) with: {' '.join(goals + args)}")

                success, stdout, stderr = run_maven_checked(path, goals, args=args, description=f"Deploy to {target}")

                return {
                    "success": success,
                    "target": target,
                    "url": url,
                    "build_tool": build_tool,
                    "output": stdout,
                    "error": stderr,
                }
            else:
                return {
                    "success": False,
                    "message": f"Unsupported repository type: {repo_config.get('type')}",
                    "supported_types": ["maven"]
                }
        else:
            return {
                "success": False,
                "message": f"Unsupported build tool: {build_tool}",
                "supported_tools": ["maven"]
            }

    def cmd_create_tag(self, version: str, repo_path: str = None, push: bool = True,
                      tag_pattern: str = None, tag_message_pattern: str = None,
                      remote: str = "origin") -> Dict[str, Any]:
        """Create and push Git tag. Usage: release.tag version=1.0.0 [repo_path=.] [push=true] [tag_pattern=v{version}] [tag_message_pattern='Release version {version}'] [remote=origin]"""
        path = Path(repo_path) if repo_path else self.project_path
        pattern = tag_pattern or self._get_tag_pattern()
        message_pattern = tag_message_pattern or self._get_tag_message_pattern()
        tag_name = pattern.format(version=version)
        tag_message = message_pattern.format(version=version)

        logger.info(f"Creating tag: {tag_name}")

        success, stdout, stderr = run_git_checked(path, ["tag", "-a", tag_name, "-m", tag_message])

        if not success:
            return {
                "success": False,
                "tag": tag_name,
                "pattern": pattern,
                "message": stderr,
            }

        if push:
            logger.info(f"Pushing tag {tag_name} to {remote}")
            push_success, push_stdout, push_stderr = run_git_checked(path, ["push", remote, tag_name])

            if not push_success:
                return {
                    "success": False,
                    "tag": tag_name,
                    "tag_created": True,
                    "push_failed": True,
                    "remote": remote,
                    "message": push_stderr,
                }

        return {
            "success": True,
            "tag": tag_name,
            "pattern": pattern,
            "pushed": push,
            "remote": remote if push else None,
            "message": stdout,
        }

    def cmd_full_release(self, old_version: str, new_version: str, repo_path: str = None,
                        skip_tests: bool = False, deploy_target: str = "all",
                        build_tool: str = "maven", **kwargs) -> Dict[str, Any]:
        """Perform full release process. Usage: release.full old_version=1.0.0-SNAPSHOT new_version=1.0.0 [repo_path=.] [skip_tests=false] [deploy_target=all] [build_tool=maven]"""
        path = Path(repo_path) if repo_path else self.project_path
        results = {}

        logger.info(f"Starting full release: {old_version} -> {new_version}")

        results["create_branch"] = self.cmd_create_release_branch(new_version, str(path), **kwargs)
        if not results["create_branch"]["success"]:
            return {"success": False, "step": "create_branch", "results": results}

        results["update_version"] = self.cmd_update_version(old_version, new_version, str(path), build_tool)
        if not results["update_version"]["success"]:
            return {"success": False, "step": "update_version", "results": results}

        results["build"] = self.cmd_build(str(path), skip_tests=skip_tests, profile="release", build_tool=build_tool)
        if not results["build"]["success"]:
            return {"success": False, "step": "build", "results": results}

        if deploy_target != "none":
            results["deploy"] = self.cmd_deploy(deploy_target, str(path), skip_tests=skip_tests, build_tool=build_tool, **kwargs)

        results["create_tag"] = self.cmd_create_tag(new_version, str(path), push=True, **kwargs)

        all_success = all(r.get("success", False) for r in results.values())

        return {
            "success": all_success,
            "old_version": old_version,
            "new_version": new_version,
            "build_tool": build_tool,
            "deploy_target": deploy_target,
            "results": results,
        }

    def hook_before_release(self, version: str, **kwargs) -> None:
        logger.info(f"[ReleasePlugin] Before release: {version}")

    def hook_after_release(self, version: str, result: Any, **kwargs) -> None:
        logger.info(f"[ReleasePlugin] After release: {version}, result: {result}")


register_plugin(ReleasePlugin())

