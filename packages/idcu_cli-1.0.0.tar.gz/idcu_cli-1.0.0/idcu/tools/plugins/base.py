import abc
import importlib
import inspect
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


@dataclass
class PluginMetadata:
    name: str
    version: str
    description: str = ""
    author: str = ""
    dependencies: List[str] = field(default_factory=list)
    enabled: bool = True


class Plugin(abc.ABC):
    metadata: PluginMetadata

    def __init__(self):
        if not hasattr(self, "metadata"):
            raise ValueError("Plugin must define metadata")

    @abc.abstractmethod
    def initialize(self) -> None:
        pass

    def cleanup(self) -> None:
        pass

    def get_commands(self) -> Dict[str, Callable]:
        return {}

    def get_hooks(self) -> Dict[str, Callable]:
        return {}


class PluginManager:
    def __init__(self):
        self._plugins: Dict[str, Plugin] = {}
        self._hooks: Dict[str, List[Callable]] = {}
        self._initialized = False

    def register(self, plugin: Plugin) -> None:
        name = plugin.metadata.name
        if name in self._plugins:
            raise ValueError(f"Plugin '{name}' already registered")
        self._plugins[name] = plugin

    def unregister(self, name: str) -> bool:
        if name not in self._plugins:
            return False
        plugin = self._plugins[name]
        plugin.cleanup()
        del self._plugins[name]
        self._clear_plugin_hooks(name)
        return True

    def get(self, name: str) -> Optional[Plugin]:
        return self._plugins.get(name)

    def list_all(self) -> List[PluginMetadata]:
        return [plugin.metadata for plugin in self._plugins.values()]

    def has(self, name: str) -> bool:
        return name in self._plugins

    def initialize_all(self) -> None:
        for name, plugin in self._plugins.items():
            if plugin.metadata.enabled:
                try:
                    plugin.initialize()
                    self._register_plugin_hooks(plugin)
                except Exception as exc:
                    print(f"Failed to initialize plugin '{name}': {exc}")
        self._initialized = True

    def cleanup_all(self) -> None:
        for name, plugin in self._plugins.items():
            try:
                plugin.cleanup()
            except Exception as exc:
                print(f"Failed to cleanup plugin '{name}': {exc}")
        self._hooks.clear()
        self._initialized = False

    def _register_plugin_hooks(self, plugin: Plugin) -> None:
        hooks = plugin.get_hooks()
        for hook_name, hook_func in hooks.items():
            if hook_name not in self._hooks:
                self._hooks[hook_name] = []
            self._hooks[hook_name].append(hook_func)

    def _clear_plugin_hooks(self, plugin_name: str) -> None:
        plugin = self._plugins.get(plugin_name)
        if plugin:
            hooks = plugin.get_hooks()
            for hook_name in hooks.keys():
                if hook_name in self._hooks:
                    self._hooks[hook_name] = [
                        hook for hook in self._hooks[hook_name]
                        if not self._is_hook_from_plugin(hook, plugin_name)
                    ]

    def _is_hook_from_plugin(self, hook: Callable, plugin_name: str) -> bool:
        module = inspect.getmodule(hook)
        if module:
            return plugin_name in module.__name__
        return False

    def trigger_hook(self, hook_name: str, *args, **kwargs) -> List[Any]:
        results = []
        if hook_name in self._hooks:
            for hook in self._hooks[hook_name]:
                try:
                    results.append(hook(*args, **kwargs))
                except Exception as exc:
                    print(f"Hook '{hook_name}' execution failed: {exc}")
        return results

    def get_command(self, command_name: str) -> Optional[Callable]:
        for plugin in self._plugins.values():
            commands = plugin.get_commands()
            if command_name in commands:
                return commands[command_name]
        return None

    def list_commands(self) -> Dict[str, str]:
        all_commands = {}
        for plugin in self._plugins.values():
            commands = plugin.get_commands()
            for command_name, command_func in commands.items():
                all_commands[command_name] = command_func.__doc__ or ""
        return all_commands

    def load_from_directory(self, directory: Path) -> None:
        if not directory.exists():
            return

        for file_path in directory.glob("*.py"):
            if file_path.name.startswith("_"):
                continue
            self.load_from_file(file_path)

    def load_from_file(self, file_path: Path) -> None:
        module_name = file_path.stem
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self._load_from_module(module)

    def _load_from_module(self, module) -> None:
        for name, obj in inspect.getmembers(module):
            if inspect.isclass(obj) and issubclass(obj, Plugin) and obj is not Plugin:
                try:
                    self.register(obj())
                except Exception as exc:
                    print(f"Failed to load plugin class '{name}': {exc}")


_plugin_manager: Optional[PluginManager] = None


def set_plugin_manager(
    manager: Optional[PluginManager],
    *,
    cleanup_existing: bool = True,
) -> Optional[PluginManager]:
    global _plugin_manager

    if cleanup_existing and _plugin_manager is not None and _plugin_manager is not manager:
        _plugin_manager.cleanup_all()

    _plugin_manager = manager
    return _plugin_manager


def reset_plugin_manager(*, cleanup_existing: bool = True) -> None:
    set_plugin_manager(None, cleanup_existing=cleanup_existing)


def get_plugin_manager(
    *,
    reset: bool = False,
    factory: Optional[Callable[[], PluginManager]] = None,
) -> PluginManager:
    global _plugin_manager

    if reset:
        reset_plugin_manager()

    if _plugin_manager is None:
        manager_factory = factory or PluginManager
        _plugin_manager = manager_factory()

    return _plugin_manager


def register_plugin(plugin: Plugin, plugin_manager: Optional[PluginManager] = None) -> None:
    manager = plugin_manager or get_plugin_manager()
    manager.register(plugin)
