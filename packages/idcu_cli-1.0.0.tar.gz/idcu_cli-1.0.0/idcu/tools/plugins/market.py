
"""插件市场模块"""
import json
import urllib.request
from datetime import datetime
from pathlib import Path

from idcu.system.logger import get_logger

logger = get_logger("plugins.market")


class PluginMetadata:
    """插件元数据类"""

    def __init__(
        self,
        name,
        version,
        author,
        description,
        keywords=None,
        homepage=None,
        repository=None,
        license=None,
        dependencies=None,
        tags=None,
        created_at=None,
        updated_at=None,
        downloads=0,
    ):
        self.name = name
        self.version = version
        self.author = author
        self.description = description
        self.keywords = keywords or []
        self.homepage = homepage
        self.repository = repository
        self.license = license
        self.dependencies = dependencies or []
        self.tags = tags or []
        self.created_at = created_at
        self.updated_at = updated_at
        self.downloads = downloads

    def to_dict(self):
        """转换为字典格式"""
        return {
            "name": self.name,
            "version": self.version,
            "author": self.author,
            "description": self.description,
            "keywords": self.keywords,
            "homepage": self.homepage,
            "repository": self.repository,
            "license": self.license,
            "dependencies": self.dependencies,
            "tags": self.tags,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "downloads": self.downloads,
        }

    @classmethod
    def from_dict(cls, data):
        """从字典创建对象"""
        created_at = None
        if data.get("created_at"):
            created_at = datetime.fromisoformat(data["created_at"])
        updated_at = None
        if data.get("updated_at"):
            updated_at = datetime.fromisoformat(data["updated_at"])

        return cls(
            name=data["name"],
            version=data["version"],
            author=data["author"],
            description=data["description"],
            keywords=data.get("keywords", []),
            homepage=data.get("homepage"),
            repository=data.get("repository"),
            license=data.get("license"),
            dependencies=data.get("dependencies", []),
            tags=data.get("tags", []),
            created_at=created_at,
            updated_at=updated_at,
            downloads=data.get("downloads", 0),
        )


class PluginRepository:
    """插件仓库类"""

    def __init__(self, repo_url, cache_dir=None):
        self.repo_url = repo_url.rstrip("/")
        self.cache_dir = cache_dir or Path.home() / ".idcu" / "plugins" / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._plugins = None

    def _get_index_path(self):
        """获取索引文件路径"""
        return self.cache_dir / "index.json"

    def _fetch_index(self):
        """从仓库获取插件索引"""
        index_url = f"{self.repo_url}/index.json"
        logger.info(f"Fetching plugin index from {index_url}")

        try:
            with urllib.request.urlopen(index_url, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
                plugins = {}
                for plugin_data in data.get("plugins", []):
                    plugin = PluginMetadata.from_dict(plugin_data)
                    plugins[plugin.name] = plugin

                with open(self._get_index_path(), "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

                return plugins
        except Exception as e:
            logger.error(f"Failed to fetch index: {e}")
            return self._load_cached_index()

    def _load_cached_index(self):
        """加载缓存的索引"""
        index_path = self._get_index_path()
        if not index_path.exists():
            return {}

        try:
            with open(index_path, encoding="utf-8") as f:
                data = json.load(f)
                plugins = {}
                for plugin_data in data.get("plugins", []):
                    plugin = PluginMetadata.from_dict(plugin_data)
                    plugins[plugin.name] = plugin
                return plugins
        except Exception as e:
            logger.error(f"Failed to load cached index: {e}")
            return {}

    def refresh(self, force=False):
        """刷新插件索引

        Args:
            force: 是否强制刷新

        Returns:
            是否刷新成功
        """
        if force or not self._get_index_path().exists():
            self._plugins = self._fetch_index()
        else:
            self._plugins = self._load_cached_index()
        return True

    def list_plugins(
        self,
        search=None,
        tags=None,
        author=None,
    ):
        """列出插件

        Args:
            search: 搜索关键词
            tags: 标签列表
            author: 作者
        Returns:
            插件列表
        """
        if self._plugins is None:
            self.refresh()

        plugins = list(self._plugins.values())

        if search:
            search_lower = search.lower()
            plugins = [
                p for p in plugins
                if search_lower in p.name.lower()
                or search_lower in p.description.lower()
                or any(search_lower in kw.lower() for kw in p.keywords)
            ]

        if tags:
            plugins = [
                p for p in plugins
                if any(tag in p.tags for tag in tags)
            ]

        if author:
            plugins = [
                p for p in plugins
                if p.author == author
            ]

        return sorted(plugins, key=lambda p: (-p.downloads, p.name))

    def get_plugin(self, name):
        """获取插件信息

        Args:
            name: 插件名称

        Returns:
            插件信息
        """
        if self._plugins is None:
            self.refresh()
        return self._plugins.get(name)

    def download_plugin(
        self,
        name,
        output_dir,
        version=None,
    ):
        """下载插件

        Args:
            name: 插件名称
            output_dir: 输出目录
            version: 版本

        Returns:
            下载的文件路径
        """
        plugin = self.get_plugin(name)
        if not plugin:
            logger.error(f"Plugin not found: {name}")
            return None

        target_version = version or plugin.version
        download_url = f"{self.repo_url}/{name}/{target_version}/{name}.py"

        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"{name}.py"

        logger.info(f"Downloading plugin {name} v{target_version} from {download_url}")

        try:
            with urllib.request.urlopen(download_url, timeout=60) as response:
                content = response.read()
                with open(output_path, "wb") as f:
                    f.write(content)

            logger.info(f"Plugin downloaded to {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"Failed to download plugin: {e}")
            return None


class LocalPluginRegistry:
    """本地插件注册表"""

    def __init__(self, plugins_dir=None):
        self.plugins_dir = plugins_dir or Path.home() / ".idcu" / "plugins"
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self._metadata_file = self.plugins_dir / "registry.json"
        self._registry = self._load_registry()

    def _load_registry(self):
        """加载注册表"""
        if not self._metadata_file.exists():
            return {}

        try:
            with open(self._metadata_file, encoding="utf-8") as f:
                data = json.load(f)
                registry = {}
                for name, plugin_data in data.items():
                    registry[name] = PluginMetadata.from_dict(plugin_data)
                return registry
        except Exception as e:
            logger.error(f"Failed to load registry: {e}")
            return {}

    def _save_registry(self):
        """保存注册表"""
        data = {
            name: plugin.to_dict()
            for name, plugin in self._registry.items()
        }
        with open(self._metadata_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def install_plugin(
        self,
        plugin_path,
        metadata=None,
    ):
        """安装插件

        Args:
            plugin_path: 插件文件路径
            metadata: 插件元数据
        Returns:
            是否安装成功
        """
        if not plugin_path.exists():
            logger.error(f"Plugin file not found: {plugin_path}")
            return False

        try:
            import shutil
            dest_path = self.plugins_dir / plugin_path.name
            shutil.copy2(plugin_path, dest_path)

            if metadata:
                self._registry[metadata.name] = metadata
                self._save_registry()

            logger.info(f"Plugin installed: {plugin_path.name}")
            return True
        except Exception as e:
            logger.error(f"Failed to install plugin: {e}")
            return False

    def uninstall_plugin(self, name):
        """卸载插件

        Args:
            name: 插件名称

        Returns:
            是否卸载成功
        """
        plugin_path = self.plugins_dir / f"{name}.py"

        if not plugin_path.exists():
            logger.error(f"Plugin not found: {name}")
            return False

        try:
            plugin_path.unlink()
            if name in self._registry:
                del self._registry[name]
                self._save_registry()
            logger.info(f"Plugin uninstalled: {name}")
            return True
        except Exception as e:
            logger.error(f"Failed to uninstall plugin: {e}")
            return False

    def list_installed(self):
        """列出已安装的插件"""
        return list(self._registry.values())

    def is_installed(self, name):
        """检查插件是否已安装"""
        return name in self._registry
