
"""插件脚手架生成器"""
from pathlib import Path

from idcu.system.logger import get_logger

logger = get_logger("plugins.scaffold")


class PluginScaffoldGenerator:
    """插件脚手架生成器"""

    def __init__(self, output_dir=None):
        self.output_dir = output_dir or Path.cwd()

    def generate_plugin(
        self,
        name,
        description,
        author,
        version="0.1.0",
        keywords=None,
        tags=None,
    ):
        """生成插件脚手架

        Args:
            name: 插件名称
            description: 插件描述
            author: 作者
            version: 版本
            keywords: 关键词
            tags: 标签

        Returns:
            生成的插件文件路径
        """
        if keywords is None:
            keywords = []
        if tags is None:
            tags = []

        plugin_name = name.lower().replace(" ", "_").replace("-", "_")
        class_name = "".join(word.capitalize() for word in name.replace("-", " ").split())

        plugin_file = self.output_dir / f"{plugin_name}_plugin.py"

        content = f'''"""
{name} Plugin
{description}

Author: {author}
Version: {version}
"""

from idcu.tools.plugins.base import BasePlugin, command


class {class_name}Plugin(BasePlugin):
    """{name} 插件"""

    name = "{plugin_name}"
    version = "{version}"
    description = "{description}"
    author = "{author}"
    keywords = {keywords}
    tags = {tags}

    def __init__(self):
        super().__init__()

    def initialize(self):
        """初始化插件"""
        self.logger.info(f"Initializing {{self.name}} plugin")

    def cleanup(self):
        """清理插件"""
        self.logger.info(f"Cleaning up {{self.name}} plugin")

    @command("hello", help="Say hello from {plugin_name} plugin")
    def cmd_hello(self, args):
        """Hello 命令"""
        print(f"Hello from {{self.name}} plugin!")
        print(f"Version: {{self.version}}")

    @command("info", help="Show plugin information")
    def cmd_info(self, args):
        """信息命令"""
        print(f"=== {{self.name}} ===")
        print(f"Version: {{self.version}}")
        print(f"Author: {{self.author}}")
        print(f"Description: {{self.description}}")
        if self.keywords:
            print(f"Keywords: {{', '.join(self.keywords)}}")
        if self.tags:
            print(f"Tags: {{', '.join(self.tags)}}")


def get_plugin():
    """获取插件实例"""
    return {class_name}Plugin()
'''

        plugin_file.write_text(content, encoding="utf-8")
        logger.info(f"Generated plugin scaffold: {plugin_file}")
        return plugin_file

    def generate_metadata(
        self,
        name,
        description,
        author,
        version="0.1.0",
        keywords=None,
        tags=None,
        homepage=None,
        repository=None,
        license="Apache-2.0",
        dependencies=None,
    ):
        """生成插件元数据文件

        Args:
            name: 插件名称
            description: 插件描述
            author: 作者
            version: 版本
            keywords: 关键词
            tags: 标签
            homepage: 主页
            repository: 仓库
            license: 许可证
            dependencies: 依赖

        Returns:
            生成的元数据文件路径
        """
        if keywords is None:
            keywords = []
        if tags is None:
            tags = []
        if dependencies is None:
            dependencies = []

        import json
        from datetime import datetime

        metadata = {
            "name": name,
            "version": version,
            "author": author,
            "description": description,
            "keywords": keywords,
            "homepage": homepage,
            "repository": repository,
            "license": license,
            "dependencies": dependencies,
            "tags": tags,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "downloads": 0,
        }

        metadata_file = self.output_dir / f"{name.lower().replace(' ', '_')}_metadata.json"
        with open(metadata_file, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)

        logger.info(f"Generated plugin metadata: {metadata_file}")
        return metadata_file

    def generate_test_file(
        self,
        name,
    ):
        """生成插件测试文件

        Args:
            name: 插件名称

        Returns:
            生成的测试文件路径
        """
        plugin_name = name.lower().replace(" ", "_").replace("-", "_")
        class_name = "".join(word.capitalize() for word in name.replace("-", " ").split())

        test_file = self.output_dir / f"test_{plugin_name}_plugin.py"

        content = f'''"""
Tests for {name} plugin
"""

import pytest
from pathlib import Path


def test_plugin_metadata():
    """测试插件元数据"""
    import importlib.util
    import sys
    from pathlib import Path
    
    plugin_path = Path(__file__).parent / "{plugin_name}_plugin.py"
    spec = importlib.util.spec_from_file_location("{plugin_name}_plugin", plugin_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["{plugin_name}_plugin"] = module
    spec.loader.exec_module(module)
    
    plugin = module.get_plugin()
    assert plugin.name == "{plugin_name}"
    assert plugin.version is not None
    assert plugin.description is not None
    assert plugin.author is not None


def test_plugin_initialize():
    """测试插件初始化"""
    import importlib.util
    import sys
    from pathlib import Path
    
    plugin_path = Path(__file__).parent / "{plugin_name}_plugin.py"
    spec = importlib.util.spec_from_file_location("{plugin_name}_plugin", plugin_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["{plugin_name}_plugin"] = module
    spec.loader.exec_module(module)
    
    plugin = module.get_plugin()
    plugin.initialize()
    assert True


def test_plugin_cleanup():
    """测试插件清理"""
    import importlib.util
    import sys
    from pathlib import Path
    
    plugin_path = Path(__file__).parent / "{plugin_name}_plugin.py"
    spec = importlib.util.spec_from_file_location("{plugin_name}_plugin", plugin_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["{plugin_name}_plugin"] = module
    spec.loader.exec_module(module)
    
    plugin = module.get_plugin()
    plugin.cleanup()
    assert True


def test_plugin_commands():
    """测试插件命令"""
    import importlib.util
    import sys
    from pathlib import Path
    
    plugin_path = Path(__file__).parent / "{plugin_name}_plugin.py"
    spec = importlib.util.spec_from_file_location("{plugin_name}_plugin", plugin_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["{plugin_name}_plugin"] = module
    spec.loader.exec_module(module)
    
    plugin = module.get_plugin()
    commands = plugin.get_commands()
    assert len(commands) > 0
    assert "hello" in commands
    assert "info" in commands
'''

        test_file.write_text(content, encoding="utf-8")
        logger.info(f"Generated plugin test file: {test_file}")
        return test_file

    def generate_all(
        self,
        name,
        description,
        author,
        version="0.1.0",
        keywords=None,
        tags=None,
        include_tests=True,
        include_metadata=True,
    ):
        """生成所有的插件脚手架

        Args:
            name: 插件名称
            description: 插件描述
            author: 作者
            version: 版本
            keywords: 关键词
            tags: 标签
            include_tests: 是否包含测试文件
            include_metadata: 是否包含元数据文件
        Returns:
            生成的文件列表
        """
        generated_files = []

        plugin_file = self.generate_plugin(
            name=name,
            description=description,
            author=author,
            version=version,
            keywords=keywords,
            tags=tags,
        )
        generated_files.append(plugin_file)

        if include_metadata:
            metadata_file = self.generate_metadata(
                name=name,
                description=description,
                author=author,
                version=version,
                keywords=keywords,
                tags=tags,
            )
            generated_files.append(metadata_file)

        if include_tests:
            test_file = self.generate_test_file(name=name)
            generated_files.append(test_file)

        return generated_files
