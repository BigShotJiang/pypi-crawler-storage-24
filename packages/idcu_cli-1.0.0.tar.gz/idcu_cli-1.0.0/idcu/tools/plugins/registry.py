from typing import Callable, Dict, List, Optional

from .base import Plugin, PluginManager, get_plugin_manager


def _resolve_plugin_manager(plugin_manager: Optional[PluginManager] = None) -> PluginManager:
    return plugin_manager or get_plugin_manager()


def get_plugin(name: str, plugin_manager: Optional[PluginManager] = None) -> Optional[Plugin]:
    return _resolve_plugin_manager(plugin_manager).get(name)


def list_plugins(plugin_manager: Optional[PluginManager] = None) -> List:
    return _resolve_plugin_manager(plugin_manager).list_all()


def has_plugin(name: str, plugin_manager: Optional[PluginManager] = None) -> bool:
    return _resolve_plugin_manager(plugin_manager).has(name)


def initialize_plugins(plugin_manager: Optional[PluginManager] = None) -> None:
    _resolve_plugin_manager(plugin_manager).initialize_all()


def cleanup_plugins(plugin_manager: Optional[PluginManager] = None) -> None:
    _resolve_plugin_manager(plugin_manager).cleanup_all()


def trigger_hook(hook_name: str, *args, plugin_manager: Optional[PluginManager] = None, **kwargs) -> List:
    return _resolve_plugin_manager(plugin_manager).trigger_hook(hook_name, *args, **kwargs)


def get_command(command_name: str, plugin_manager: Optional[PluginManager] = None) -> Optional[Callable]:
    return _resolve_plugin_manager(plugin_manager).get_command(command_name)


def list_commands(plugin_manager: Optional[PluginManager] = None) -> Dict[str, str]:
    return _resolve_plugin_manager(plugin_manager).list_commands()
