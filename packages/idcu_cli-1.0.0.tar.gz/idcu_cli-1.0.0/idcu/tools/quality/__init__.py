
from dataclasses import dataclass
from pathlib import Path

from idcu.core import print_error, print_info, print_success, print_header, print_section, print_warning
from idcu.system.logger import get_logger
from idcu.system.project_config import get_project_config_manager

logger = get_logger("quality")


@dataclass
class QualityCheckResult:
    check_name: str
    passed: bool
    message: str
    details: dict = None


class QualityCheck:
    name = ""
    description = ""
    
    def __init__(self):
        pass
    
    def run(self, repo_root=None):
        raise NotImplementedError("Subclasses must implement run method")


class QualityGateManager:
    def __init__(self, repo_root=None):
        self.repo_root = repo_root or Path.cwd()
        self.config_manager = get_project_config_manager(self.repo_root / ".idcu")
        self.checks = {}
        self._register_default_checks()
    
    def _register_default_checks(self):
        try:
            from idcu.tools.quality.encoding_check import EncodingQualityCheck
            self.register_check(EncodingQualityCheck())
        except ImportError as e:
            logger.warning("Failed to register encoding check: %s" % e)
        
        try:
            from idcu.tools.quality.dependency_audit import DependencyAuditQualityCheck
            self.register_check(DependencyAuditQualityCheck())
        except ImportError as e:
            logger.warning("Failed to register dependency audit check: %s" % e)
        
        try:
            from idcu.tools.quality.tck_runner import TCKQualityCheck
            self.register_check(TCKQualityCheck())
        except ImportError as e:
            logger.warning("Failed to register TCK check: %s" % e)
    
    def register_check(self, check):
        self.checks[check.name] = check
    
    def get_enabled_checks(self):
        enabled_checks = []
        
        config = self.config_manager.get_config()
        if config and config.quality_gates:
            for gate_name in config.quality_gates:
                if gate_name in self.checks:
                    enabled_checks.append(self.checks[gate_name])
        
        return enabled_checks
    
    def run_all_checks(self):
        results = []
        enabled_checks = self.get_enabled_checks()
        
        if not enabled_checks:
            print_info("No quality gates configured")
            return results
        
        print_header("Running quality gates")
        
        for check in enabled_checks:
            print_section(f"Running check: {check.name}")
            result = check.run(self.repo_root)
            results.append(result)
            
            if result.passed:
                print_success(f"{check.name}: PASSED - {result.message}")
            else:
                print_error(f"{check.name}: FAILED - {result.message}")
        
        return results
    
    def run_check(self, check_name):
        if check_name not in self.checks:
            print_error(f"Check '{check_name}' not found")
            return None
        
        check = self.checks[check_name]
        print_header(f"Running check: {check.name}")
        result = check.run(self.repo_root)
        
        if result.passed:
            print_success(f"PASSED - {result.message}")
        else:
            print_error(f"FAILED - {result.message}")
        
        return result
    
    def list_available_checks(self):
        print_header("Available quality checks")
        
        if not self.checks:
            print_info("No checks registered")
            return
        
        for name, check in self.checks.items():
            print(f"  - {name}: {check.description}")
    
    def list_configured_gates(self):
        config = self.config_manager.get_config()
        
        print_header("Configured quality gates")
        
        if not config or not config.quality_gates:
            print_info("No quality gates configured in project.yaml")
            return
        
        print("Enabled gates:")
        for gate_name in config.quality_gates:
            status = " (available)" if gate_name in self.checks else " (NOT AVAILABLE)"
            print(f"  - {gate_name}{status}")
