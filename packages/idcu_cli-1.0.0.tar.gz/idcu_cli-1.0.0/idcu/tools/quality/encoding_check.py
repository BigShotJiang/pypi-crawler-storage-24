

from pathlib import Path

from idcu.core import print_error, print_info, print_success, print_header, print_section, print_warning
from idcu.core.encoding_utils import (
    EncodingResult,
    detect_file_encoding,
    fix_file_encoding,
    _match_any_pattern,
    ENCODING_SCAN_INCLUDES,
    ENCODING_SCAN_EXCLUDES,
    get_file_encoding_statistics,
    is_binary_file,
)
from idcu.tools.quality import QualityCheck, QualityCheckResult


class EncodingQualityCheck(QualityCheck):
    name = "encoding-check"
    description = "检查文件编码和乱码问题"
    
    def __init__(self):
        super().__init__()
    
    def run(self, repo_root=None):
        repo_path = Path(repo_root) if repo_root else Path.cwd()
        
        print_info("检查目录: %s" % repo_path)
        
        results = self._check_path(repo_path, recursive=True)
        
        total_files = len(results)
        garbage_files = sum(1 for r in results if r.has_garbage)
        success = garbage_files == 0
        
        message = "检查了 %d 个文件，发现 %d 个文件存在编码问题" % (total_files, garbage_files)
        
        details = {
            "total": total_files,
            "garbage_files": garbage_files,
            "results": []
        }
        
        for r in results:
            details["results"].append({
                "path": str(r.path) if isinstance(r.path, Path) else r.path,
                "encoding": r.encoding,
                "confidence": r.confidence,
                "has_garbage": r.has_garbage,
                "garbage_count": r.garbage_count,
                "quality_score": r.quality_score,
                "restored": r.restored,
                "success": r.success,
                "error_message": r.error_message,
                "fixed_encoding": r.fixed_encoding,
                "original_size": r.original_size,
                "fixed_size": r.fixed_size
            })
        
        return QualityCheckResult(
            check_name=self.name,
            passed=success,
            message=message,
            details=details
        )
    
    def _check_path(self, path, recursive=True):
        results = []
        path_obj = Path(path)

        if path_obj.is_file():
            if not is_binary_file(path_obj):
                if _match_any_pattern(path_obj, ENCODING_SCAN_INCLUDES):
                    if not _match_any_pattern(path_obj, ENCODING_SCAN_EXCLUDES):
                        results.append(detect_file_encoding(path_obj))
        elif path_obj.is_dir():
            import os
            if recursive:
                for root, dirs, files in os.walk(str(path_obj)):
                    root_path = Path(root)
                    for file_name in files:
                        file_path = root_path / file_name
                        if not is_binary_file(file_path):
                            if _match_any_pattern(file_path, ENCODING_SCAN_INCLUDES):
                                if not _match_any_pattern(file_path, ENCODING_SCAN_EXCLUDES):
                                    results.append(detect_file_encoding(file_path))
            else:
                for item in path_obj.iterdir():
                    if item.is_file() and not is_binary_file(item):
                        if _match_any_pattern(item, ENCODING_SCAN_INCLUDES):
                            if not _match_any_pattern(item, ENCODING_SCAN_EXCLUDES):
                                results.append(detect_file_encoding(item))

        return results


class EncodingChecker:
    def __init__(self, repo_root=None):
        self.repo_root = repo_root or Path.cwd()
    
    def check(self, path=None, recursive=True):
        target_path = path or self.repo_root
        print_header("编码检查")
        print_info("检查路径: %s" % target_path)
        print_section("正在扫描文件...")
        
        results = self._check_path(target_path, recursive)
        
        self._print_check_summary(results)
        
        return results
    
    def fix(self, path=None, target_encoding="utf-8", backup=True, force=False, recursive=True):
        target_path = path or self.repo_root
        print_header("编码修复")
        print_info("修复路径: %s" % target_path)
        print_info("目标编码: %s" % target_encoding)
        print_info("备份: %s" % ("是" if backup else "否"))
        print_info("强制修复: %s" % ("是" if force else "否"))
        print_section("正在处理文件...")
        
        results = self._process_path(target_path, target_encoding, backup, force, recursive)
        
        self._print_fix_summary(results)
        
        return results
    
    def fix_safe(self, path=None, target_encoding="utf-8", recursive=True):
        return self.fix(path, target_encoding, backup=True, force=False, recursive=recursive)
    
    def generate_report(self, results, output_path=None):
        report = self._generate_report_dict(results)
        
        print_header("检查报告")
        
        summary = report["summary"]
        print_section("摘要")
        print("  总文件数: %d" % summary["total"])
        print("  成功: %d" % summary["success"])
        print("  存在编码问题: %d" % summary["has_garbage"])
        print("  已修复: %d" % summary["restored"])
        print("  错误: %d" % summary["errors"])
        
        if report["files_by_encoding"]:
            print_section("编码分布")
            for enc, count in sorted(report["files_by_encoding"].items(), key=lambda x: -x[1]):
                print("  %s: %d 个文件" % (enc, count))
        
        if output_path:
            import json
            try:
                with open(output_path, "w", encoding="utf-8") as f:
                    json.dump(report, f, ensure_ascii=False, indent=2)
                print_success("报告已保存到: %s" % output_path)
            except Exception as e:
                print_error("保存报告失败: %s" % e)
        
        return report
    
    def _check_path(self, path, recursive=True):
        results = []
        path_obj = Path(path)

        if path_obj.is_file():
            if not is_binary_file(path_obj):
                if _match_any_pattern(path_obj, ENCODING_SCAN_INCLUDES):
                    if not _match_any_pattern(path_obj, ENCODING_SCAN_EXCLUDES):
                        results.append(detect_file_encoding(path_obj))
        elif path_obj.is_dir():
            import os
            if recursive:
                for root, dirs, files in os.walk(str(path_obj)):
                    root_path = Path(root)
                    for file_name in files:
                        file_path = root_path / file_name
                        if not is_binary_file(file_path):
                            if _match_any_pattern(file_path, ENCODING_SCAN_INCLUDES):
                                if not _match_any_pattern(file_path, ENCODING_SCAN_EXCLUDES):
                                    results.append(detect_file_encoding(file_path))
            else:
                for item in path_obj.iterdir():
                    if item.is_file() and not is_binary_file(item):
                        if _match_any_pattern(item, ENCODING_SCAN_INCLUDES):
                            if not _match_any_pattern(item, ENCODING_SCAN_EXCLUDES):
                                results.append(detect_file_encoding(item))

        return results
    
    def _process_path(self, path, target_encoding="utf-8", backup=True, force=False, recursive=True):
        results = []
        path_obj = Path(path)

        if path_obj.is_file():
            if not is_binary_file(path_obj):
                if _match_any_pattern(path_obj, ENCODING_SCAN_INCLUDES):
                    if not _match_any_pattern(path_obj, ENCODING_SCAN_EXCLUDES):
                        results.append(fix_file_encoding(path_obj, target_encoding, backup, force))
        elif path_obj.is_dir():
            import os
            if recursive:
                for root, dirs, files in os.walk(str(path_obj)):
                    root_path = Path(root)
                    for file_name in files:
                        file_path = root_path / file_name
                        if not is_binary_file(file_path):
                            if _match_any_pattern(file_path, ENCODING_SCAN_INCLUDES):
                                if not _match_any_pattern(file_path, ENCODING_SCAN_EXCLUDES):
                                    results.append(fix_file_encoding(file_path, target_encoding, backup, force))
            else:
                for item in path_obj.iterdir():
                    if item.is_file() and not is_binary_file(item):
                        if _match_any_pattern(item, ENCODING_SCAN_INCLUDES):
                            if not _match_any_pattern(item, ENCODING_SCAN_EXCLUDES):
                                results.append(fix_file_encoding(item, target_encoding, backup, force))

        return results
    
    def _generate_report_dict(self, results):
        stats = get_file_encoding_statistics(results)
        
        files_by_encoding = stats.get("encoding_distribution", {})
        
        details_list = []
        for r in results:
            details_list.append({
                "path": str(r.path) if isinstance(r.path, Path) else r.path,
                "encoding": r.encoding,
                "confidence": r.confidence,
                "has_garbage": r.has_garbage,
                "garbage_count": r.garbage_count,
                "quality_score": r.quality_score,
                "restored": r.restored,
                "success": r.success,
                "error_message": r.error_message,
                "fixed_encoding": r.fixed_encoding,
                "original_size": r.original_size,
                "fixed_size": r.fixed_size
            })

        return {
            "summary": {
                "total": stats.get("total", 0),
                "success": stats.get("total", 0) - stats.get("errors", 0),
                "has_garbage": stats.get("has_garbage", 0),
                "restored": stats.get("restored", 0),
                "errors": stats.get("errors", 0)
            },
            "files_by_encoding": files_by_encoding,
            "details": details_list
        }
    
    def _print_check_summary(self, results):
        stats = get_file_encoding_statistics(results)
        total = stats.get("total", 0)
        success = total - stats.get("errors", 0)
        has_garbage = stats.get("has_garbage", 0)
        
        print_section("检查结果")
        print("  总文件数: %d" % total)
        print("  检查成功: %d" % success)
        print("  存在编码问题: %d" % has_garbage)
        
        if has_garbage > 0:
            print_warning("发现 %d 个文件存在编码问题" % has_garbage)
            print_section("问题文件列表:")
            for r in results:
                if r.has_garbage:
                    status = "✗"
                    print("  %s %s" % (status, r.path))
                    print("    检测编码: %s, 质量分数: %.1f, 乱码数: %d" % (r.encoding, r.quality_score, r.garbage_count))
        else:
            print_success("所有文件编码正常!")
    
    def _print_fix_summary(self, results):
        stats = get_file_encoding_statistics(results)
        total = stats.get("total", 0)
        success = total - stats.get("errors", 0)
        restored = stats.get("restored", 0)
        errors = stats.get("errors", 0)
        
        print_section("修复结果")
        print("  总文件数: %d" % total)
        print("  成功: %d" % success)
        print("  已修复: %d" % restored)
        print("  错误: %d" % errors)
        
        if restored > 0:
            print_success("已修复 %d 个文件" % restored)
            print_section("已修复文件列表:")
            for r in results:
                if r.restored:
                    print("  ✓ %s" % r.path)
                    print("    原编码: %s -> 新编码: %s" % (r.encoding, r.fixed_encoding))
        
        if errors > 0:
            print_error("有 %d 个文件处理失败" % errors)
            print_section("错误文件列表:")
            for r in results:
                if not r.success:
                    print("  ✗ %s: %s" % (r.path, r.error_message))

