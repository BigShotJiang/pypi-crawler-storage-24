

from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Optional
import re

from idcu.core import print_error, print_info, print_success, print_header, print_section, print_warning
from idcu.tools.quality import QualityCheck, QualityCheckResult
from idcu.tools.maven import maven_dependency_tree, maven_dependency_list


@dataclass
class DependencyInfo:
    group_id: str
    artifact_id: str
    version: str
    scope: str
    type: str = "jar"
    classifier: Optional[str] = None
    is_transitive: bool = False


@dataclass
class AuditResult:
    dependency: DependencyInfo
    issues: List[str]
    is_valid: bool


class DependencyAuditQualityCheck(QualityCheck):
    name = "dependency-audit"
    description = "检查 Maven 依赖范围，确保零运行时第三方依赖"
    
    def __init__(self):
        super().__init__()
    
    def run(self, repo_root=None):
        repo_path = Path(repo_root) if repo_root else Path.cwd()
        
        print_info("检查目录: %s" % repo_path)
        
        auditor = DependencyAuditor(repo_path)
        results = auditor.audit()
        
        total_deps = len(results)
        invalid_deps = sum(1 for r in results if not r.is_valid)
        success = invalid_deps == 0
        
        message = "检查了 %d 个依赖，发现 %d 个依赖存在问题" % (total_deps, invalid_deps)
        
        details = {
            "total": total_deps,
            "invalid_dependencies": invalid_deps,
            "results": []
        }
        
        for r in results:
            details["results"].append({
                "group_id": r.dependency.group_id,
                "artifact_id": r.dependency.artifact_id,
                "version": r.dependency.version,
                "scope": r.dependency.scope,
                "is_transitive": r.dependency.is_transitive,
                "is_valid": r.is_valid,
                "issues": r.issues
            })
        
        return QualityCheckResult(
            check_name=self.name,
            passed=success,
            message=message,
            details=details
        )


class DependencyAuditor:
    ALLOWED_SCOPES = ["test", "provided", "system"]
    FORBIDDEN_SCOPES = ["compile", "runtime"]
    
    def __init__(self, repo_root=None):
        self.repo_root = repo_root or Path.cwd()
    
    def audit(self):
        print_header("依赖审计")
        print_info("正在分析依赖...")
        
        dependencies = self._parse_dependencies()
        
        if not dependencies:
            print_warning("没有找到任何依赖")
            return []
        
        results = []
        for dep in dependencies:
            audit_result = self._audit_dependency(dep)
            results.append(audit_result)
        
        self._print_audit_summary(results)
        
        return results
    
    def _parse_dependencies(self):
        dependencies = []
        
        try:
            result = maven_dependency_list(str(self.repo_root))
            if result.success and "dependencies" in result.details:
                dependencies = self._parse_dependency_list_output(result.details["dependencies"])
        except Exception as e:
            print_error("解析依赖列表失败: %s" % e)
        
        return dependencies
    
    def _parse_dependency_list_output(self, output):
        dependencies = []
        
        pattern = re.compile(
            r'([\w\-.]+):([\w\-.]+):([\w\-.]+):([\w\-.]+):([\w\-.]+)(?::([\w\-.]+))?'
        )
        
        for line in output.split('\n'):
            line = line.strip()
            if not line or 'The following files have been resolved:' in line:
                continue
            
            match = pattern.match(line)
            if match:
                groups = match.groups()
                dep = DependencyInfo(
                    group_id=groups[0],
                    artifact_id=groups[1],
                    type=groups[2],
                    version=groups[4],
                    scope=groups[3],
                    classifier=groups[5] if len(groups) > 5 else None,
                    is_transitive=False
                )
                dependencies.append(dep)
        
        return dependencies
    
    def _parse_dependency_tree_output(self, output):
        dependencies = []
        
        tree_pattern = re.compile(
            r'[\+\\\s]+([\w\-.]+):([\w\-.]+):([\w\-.]+):([\w\-.]+):([\w\-.]+)'
        )
        
        for line in output.split('\n'):
            line = line.strip()
            if not line:
                continue
            
            match = tree_pattern.search(line)
            if match:
                groups = match.groups()
                is_transitive = line.startswith(('|', '\\', '+'))
                dep = DependencyInfo(
                    group_id=groups[0],
                    artifact_id=groups[1],
                    type=groups[2],
                    scope=groups[3],
                    version=groups[4],
                    is_transitive=is_transitive
                )
                dependencies.append(dep)
        
        return dependencies
    
    def _audit_dependency(self, dependency):
        issues = []
        is_valid = True
        
        if dependency.scope in self.FORBIDDEN_SCOPES:
            issues.append("依赖范围 '%s' 不被允许，应使用 test 或 provided" % dependency.scope)
            is_valid = False
        
        if not dependency.is_transitive and dependency.scope == "compile":
            issues.append("直接依赖使用 compile 范围，这会引入运行时依赖")
            is_valid = False
        
        return AuditResult(
            dependency=dependency,
            issues=issues,
            is_valid=is_valid
        )
    
    def _print_audit_summary(self, results):
        total = len(results)
        valid = sum(1 for r in results if r.is_valid)
        invalid = sum(1 for r in results if not r.is_valid)
        
        print_section("审计结果")
        print("  总依赖数: %d" % total)
        print("  合规依赖: %d" % valid)
        print("  问题依赖: %d" % invalid)
        
        if invalid > 0:
            print_warning("发现 %d 个依赖存在问题" % invalid)
            print_section("问题依赖列表:")
            for r in results:
                if not r.is_valid:
                    status = "✗"
                    print("  %s %s:%s:%s" % (
                        status, 
                        r.dependency.group_id, 
                        r.dependency.artifact_id, 
                        r.dependency.version
                    ))
                    print("    范围: %s, 传递性: %s" % (
                        r.dependency.scope,
                        "是" if r.dependency.is_transitive else "否"
                    ))
                    for issue in r.issues:
                        print("    - %s" % issue)
        else:
            print_success("所有依赖合规!")
    
    def generate_report(self, results, output_path=None):
        report = self._generate_report_dict(results)
        
        print_header("审计报告")
        
        summary = report["summary"]
        print_section("摘要")
        print("  总依赖数: %d" % summary["total"])
        print("  合规依赖: %d" % summary["valid"])
        print("  问题依赖: %d" % summary["invalid"])
        
        if output_path:
            import json
            try:
                with open(output_path, "w", encoding="utf-8") as f:
                    json.dump(report, f, ensure_ascii=False, indent=2)
                print_success("报告已保存到: %s" % output_path)
            except Exception as e:
                print_error("保存报告失败: %s" % e)
        
        return report
    
    def _generate_report_dict(self, results):
        total = len(results)
        valid = sum(1 for r in results if r.is_valid)
        invalid = sum(1 for r in results if not r.is_valid)
        
        scopes_count = {}
        for r in results:
            scope = r.dependency.scope
            scopes_count[scope] = scopes_count.get(scope, 0) + 1
        
        details_list = []
        for r in results:
            details_list.append({
                "group_id": r.dependency.group_id,
                "artifact_id": r.dependency.artifact_id,
                "version": r.dependency.version,
                "scope": r.dependency.scope,
                "type": r.dependency.type,
                "classifier": r.dependency.classifier,
                "is_transitive": r.dependency.is_transitive,
                "is_valid": r.is_valid,
                "issues": r.issues
            })

        return {
            "summary": {
                "total": total,
                "valid": valid,
                "invalid": invalid
            },
            "scopes_distribution": scopes_count,
            "details": details_list
        }

