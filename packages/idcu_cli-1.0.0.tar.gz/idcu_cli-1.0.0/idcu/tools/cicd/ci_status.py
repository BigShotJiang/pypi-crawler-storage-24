"""CI status helpers built on top of GitHub CLI and GitLab CLI."""

import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.ci_status")


def _run_json_command(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    return json.loads(result.stdout or "[]")


class GitHubActionsStatus:
    """Inspect GitHub Actions workflows and runs via `gh`."""

    def __init__(self, repo: Optional[str] = None):
        self.repo = repo

    def _get_repo_info(self):
        if self.repo:
            owner, repo = self.repo.split("/", 1)
            return owner, repo

        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            check=True,
        )
        url = result.stdout.strip().removesuffix(".git")
        if "github.com/" not in url:
            raise ValueError("Could not determine GitHub repository info")
        owner, repo = url.split("github.com/", 1)[1].split("/", 1)
        return owner, repo

    def list_workflows(self):
        owner, repo = self._get_repo_info()
        try:
            return _run_json_command(
                [
                    "gh",
                    "workflow",
                    "list",
                    "--repo",
                    f"{owner}/{repo}",
                    "--json",
                    "name,id,state",
                ]
            )
        except subprocess.CalledProcessError as exc:
            logger.error(f"Failed to list workflows: {exc.stderr}")
            return []

    def list_runs(self, workflow_id: Optional[str] = None, limit: int = 10):
        owner, repo = self._get_repo_info()
        cmd = [
            "gh",
            "run",
            "list",
            "--repo",
            f"{owner}/{repo}",
            "--limit",
            str(limit),
            "--json",
            "databaseId,status,conclusion,headBranch,headSha,workflowName,startedAt",
        ]
        if workflow_id:
            cmd.extend(["--workflow", workflow_id])

        try:
            runs = _run_json_command(cmd)
        except subprocess.CalledProcessError as exc:
            logger.error(f"Failed to list runs: {exc.stderr}")
            return []

        for run in runs:
            if run.get("startedAt"):
                run["startedAt"] = datetime.fromisoformat(run["startedAt"].replace("Z", "+00:00"))
        return runs

    def view_logs(self, run_id: str):
        owner, repo = self._get_repo_info()
        try:
            result = subprocess.run(
                ["gh", "run", "view", run_id, "--repo", f"{owner}/{repo}", "--log"],
                capture_output=True,
                text=True,
                check=True,
            )
            return result.stdout
        except subprocess.CalledProcessError as exc:
            logger.error(f"Failed to view logs: {exc.stderr}")
            return None

    def download_logs(self, run_id: str, output_dir: Path = Path(".")):
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"logs-{run_id}.txt"
        logs = self.view_logs(run_id)
        if logs is None:
            return None
        output_file.write_text(logs, encoding="utf-8")
        return output_file


class GitLabCIStatus:
    """Inspect GitLab pipelines via `glab`."""

    def __init__(self, project_id: Optional[str] = None, gitlab_url: str = "https://gitlab.com"):
        self.project_id = project_id
        self.gitlab_url = gitlab_url

    def list_pipelines(self, limit: int = 10):
        if not self.project_id:
            logger.error("Project ID not set")
            return []

        try:
            result = subprocess.run(
                ["glab", "ci", "list", "--repo", self.project_id, "--limit", str(limit)],
                capture_output=True,
                text=True,
                check=True,
            )
            return result.stdout.splitlines()
        except subprocess.CalledProcessError as exc:
            logger.error(f"Failed to list pipelines: {exc.stderr}")
            return []

    def view_pipeline_logs(self, pipeline_id: str):
        if not self.project_id:
            logger.error("Project ID not set")
            return None

        try:
            result = subprocess.run(
                ["glab", "ci", "trace", pipeline_id, "--repo", self.project_id],
                capture_output=True,
                text=True,
                check=True,
            )
            return result.stdout
        except subprocess.CalledProcessError as exc:
            logger.error(f"Failed to view pipeline logs: {exc.stderr}")
            return None
