"""GitHub Actions workflow generators."""

from pathlib import Path
from typing import List, Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.github_actions")


class GitHubActionsGenerator:
    def __init__(self, project_root: Optional[Path] = None):
        self.project_root = project_root or Path.cwd()
        self.workflows_dir = self.project_root / ".github" / "workflows"

    def ensure_workflows_dir(self) -> None:
        self.workflows_dir.mkdir(parents=True, exist_ok=True)

    def _write(self, filename: str, content: str) -> Path:
        self.ensure_workflows_dir()
        path = self.workflows_dir / filename
        path.write_text(content, encoding="utf-8")
        logger.info(f"Generated workflow: {path}")
        return path

    def generate_ci_workflow(self, python_versions: Optional[List[str]] = None, os_list: Optional[List[str]] = None) -> Path:
        python_versions = python_versions or ["3.9", "3.10", "3.11", "3.12", "3.13"]
        os_list = os_list or ["ubuntu-latest", "windows-latest", "macos-latest"]
        content = f"""name: CI

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    name: Test on ${{{{ matrix.os }}}} / Python ${{{{ matrix.python-version }}}}
    runs-on: ${{{{ matrix.os }}}}
    strategy:
      fail-fast: false
      matrix:
        os: {os_list}
        python-version: {python_versions}

    steps:
    - uses: actions/checkout@v4

    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: ${{{{ matrix.python-version }}}}
        cache: pip

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        python -m pip install ".[dev]"

    - name: Run tests
      run: |
        python -m pytest tests -v

  lint:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v5
      with:
        python-version: "3.11"
        cache: pip
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        python -m pip install ".[dev]"
    - name: Ruff
      run: python -m ruff check idcu tests
    - name: MyPy
      run: python -m mypy idcu
"""
        return self._write("ci.yml", content)

    def generate_publish_workflow(self) -> Path:
        content = """name: Publish to PyPI

on:
  push:
    tags:
      - "v*"
  workflow_dispatch:
    inputs:
      version:
        description: "Version to publish"
        required: false
        type: string

jobs:
  build-and-publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: write

    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v5
      with:
        python-version: "3.11"
        cache: pip
    - name: Install build tooling
      run: |
        python -m pip install --upgrade pip
        python -m pip install build twine hatchling
    - name: Build package
      run: python -m build
    - name: Verify package
      run: python -m twine check dist/*
    - name: Publish to PyPI
      uses: pypa/gh-action-pypi-publish@release/v1
      with:
        skip-existing: true
"""
        return self._write("publish.yml", content)

    def generate_docker_workflow(self, image_name: str = "idcu/cli", platforms: Optional[List[str]] = None) -> Path:
        platforms = platforms or ["linux/amd64", "linux/arm64"]
        content = f"""name: Build Docker Image

on:
  push:
    branches: [ main ]
    tags:
      - "v*"
  workflow_dispatch:

env:
  IMAGE_NAME: {image_name}

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - uses: docker/setup-buildx-action@v3
    - uses: docker/login-action@v3
      with:
        registry: ghcr.io
        username: ${{{{ github.actor }}}}
        password: ${{{{ secrets.GITHUB_TOKEN }}}}
    - uses: docker/build-push-action@v6
      with:
        context: .
        push: true
        platforms: {",".join(platforms)}
        tags: ghcr.io/${{{{ github.repository_owner }}}}/{image_name}:latest
"""
        return self._write("docker.yml", content)

    def generate_release_workflow(self) -> Path:
        content = """name: Full Release Pipeline

on:
  workflow_dispatch:
    inputs:
      version:
        description: "Version to release"
        required: true
        type: string

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Validate version
      run: |
        VERSION="${{ inputs.version }}"
        if ! [[ $VERSION =~ ^[0-9]+\\.[0-9]+\\.[0-9]+([.-][A-Za-z0-9]+)?$ ]]; then
          echo "Invalid version format: $VERSION"
          exit 1
        fi

  build:
    runs-on: ubuntu-latest
    needs: validate
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v5
      with:
        python-version: "3.11"
        cache: pip
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        python -m pip install build twine hatchling
    - name: Build package
      run: python -m build
"""
        return self._write("release.yml", content)

    def generate_all_workflows(
        self,
        python_versions: Optional[List[str]] = None,
        os_list: Optional[List[str]] = None,
        image_name: str = "idcu/cli",
        platforms: Optional[List[str]] = None,
    ):
        return [
            self.generate_ci_workflow(python_versions, os_list),
            self.generate_publish_workflow(),
            self.generate_docker_workflow(image_name, platforms),
            self.generate_release_workflow(),
        ]
