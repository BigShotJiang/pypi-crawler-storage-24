"""Deployment helpers for Docker and SCP."""

import subprocess
from pathlib import Path
from typing import List, Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.deploy")


class DockerDeployer:
    def __init__(self, image_name: str, registry: Optional[str] = None):
        self.image_name = image_name
        self.registry = registry

    def _tag_name(self, tag: str) -> str:
        image = f"{self.image_name}:{tag}"
        return f"{self.registry}/{image}" if self.registry else image

    def build_image(
        self,
        context: Path = Path("."),
        dockerfile: Optional[Path] = None,
        tags: Optional[List[str]] = None,
        build_args: Optional[dict] = None,
    ) -> bool:
        tags = tags or ["latest"]
        cmd = ["docker", "build"]
        if dockerfile:
            cmd.extend(["-f", str(dockerfile)])
        for tag in tags:
            cmd.extend(["-t", self._tag_name(tag)])
        if build_args:
            for key, value in build_args.items():
                cmd.extend(["--build-arg", f"{key}={value}"])
        cmd.append(str(context))

        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            return True
        except subprocess.CalledProcessError as exc:
            logger.error(f"Docker build failed: {exc.stderr}")
            return False

    def push_image(self, tags: Optional[List[str]] = None) -> bool:
        tags = tags or ["latest"]
        success = True
        for tag in tags:
            try:
                subprocess.run(["docker", "push", self._tag_name(tag)], check=True, capture_output=True, text=True)
            except subprocess.CalledProcessError as exc:
                logger.error(f"Failed to push image: {exc.stderr}")
                success = False
        return success

    def login(self, username: str, password: str, registry: Optional[str] = None) -> bool:
        cmd = ["docker", "login"]
        if registry:
            cmd.append(registry)
        cmd.extend(["-u", username, "--password-stdin"])
        try:
            subprocess.run(cmd, input=password, check=True, capture_output=True, text=True)
            return True
        except subprocess.CalledProcessError as exc:
            logger.error(f"Docker login failed: {exc.stderr}")
            return False


class SCPDeployer:
    def __init__(self, host: str, username: str, port: int = 22):
        self.host = host
        self.username = username
        self.port = port

    def upload(self, local_path: Path, remote_path: str, recursive: bool = True) -> bool:
        cmd = ["scp", "-P", str(self.port)]
        if recursive and local_path.is_dir():
            cmd.append("-r")
        cmd.extend([str(local_path), f"{self.username}@{self.host}:{remote_path}"])
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            return True
        except subprocess.CalledProcessError as exc:
            logger.error(f"SCP upload failed: {exc.stderr}")
            return False

    def execute_remote_command(self, command: str):
        cmd = ["ssh", "-p", str(self.port), f"{self.username}@{self.host}", command]
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            return True, result.stdout, result.stderr
        except subprocess.CalledProcessError as exc:
            return False, exc.stdout, exc.stderr
