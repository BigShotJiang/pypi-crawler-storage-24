"""GitLab CI config generator."""

from pathlib import Path
from typing import List, Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.gitlab_ci")


class GitLabCIGenerator:
    def __init__(self, project_root: Optional[Path] = None):
        self.project_root = project_root or Path.cwd()

    def generate_gitlab_ci(self, python_versions: Optional[List[str]] = None, stages: Optional[List[str]] = None) -> Path:
        python_versions = python_versions or ["3.10", "3.11", "3.12"]
        stages = stages or ["build", "test", "lint", "deploy"]
        gitlab_ci_path = self.project_root / ".gitlab-ci.yml"

        content = f"""stages:
  - {stages[0]}
  - {stages[1]}
  - {stages[2]}
  - {stages[3]}

before_script:
  - python -m pip install --upgrade pip
  - python -m pip install ".[dev]"

build:
  stage: {stages[0]}
  image: python:3.11
  script:
    - python -m build
"""
        for version in python_versions:
            content += f"""
test:python-{version}:
  stage: {stages[1]}
  image: python:{version}
  script:
    - python -m pytest tests -v
"""
        content += f"""
lint:
  stage: {stages[2]}
  image: python:3.11
  script:
    - python -m ruff check idcu tests
    - python -m mypy idcu

deploy:
  stage: {stages[3]}
  image: python:3.11
  script:
    - python -m twine upload dist/*
  only:
    - tags
"""
        gitlab_ci_path.write_text(content, encoding="utf-8")
        logger.info(f"Generated GitLab CI config: {gitlab_ci_path}")
        return gitlab_ci_path
