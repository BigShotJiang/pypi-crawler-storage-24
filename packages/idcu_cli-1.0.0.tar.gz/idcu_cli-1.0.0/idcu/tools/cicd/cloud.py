"""Cloud CLI integration helpers."""

import subprocess
from pathlib import Path
from typing import Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.cloud")


def _run_checked(cmd) -> bool:
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        return True
    except subprocess.CalledProcessError as exc:
        logger.error(f"Command failed: {exc.stderr or exc}")
        return False


class AliyunCLI:
    def __init__(self, region: str = "cn-hangzhou", access_key_id: Optional[str] = None, access_key_secret: Optional[str] = None):
        self.region = region
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret

    def configure(self) -> bool:
        if self.access_key_id and not _run_checked(["aliyun", "configure", "set", "AccessKeyId", self.access_key_id]):
            return False
        if self.access_key_secret and not _run_checked(["aliyun", "configure", "set", "AccessKeySecret", self.access_key_secret]):
            return False
        return _run_checked(["aliyun", "configure", "set", "Region", self.region])

    def upload_oss(self, local_path: Path, bucket: str, oss_path: str) -> bool:
        return _run_checked(["aliyun", "oss", "cp", str(local_path), f"oss://{bucket}/{oss_path}"])


class TencentCloudCLI:
    def __init__(self, region: str = "ap-guangzhou", secret_id: Optional[str] = None, secret_key: Optional[str] = None):
        self.region = region
        self.secret_id = secret_id
        self.secret_key = secret_key

    def configure(self) -> bool:
        cmd = ["tccli", "configure", "set", "--region", self.region]
        if self.secret_id:
            cmd.extend(["--secretId", self.secret_id])
        if self.secret_key:
            cmd.extend(["--secretKey", self.secret_key])
        return _run_checked(cmd)


class AWSCLI:
    def __init__(self, region: str = "us-east-1", access_key_id: Optional[str] = None, secret_access_key: Optional[str] = None):
        self.region = region
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key

    def configure(self) -> bool:
        if self.access_key_id and not _run_checked(["aws", "configure", "set", "aws_access_key_id", self.access_key_id]):
            return False
        if self.secret_access_key and not _run_checked(["aws", "configure", "set", "aws_secret_access_key", self.secret_access_key]):
            return False
        return _run_checked(["aws", "configure", "set", "region", self.region])

    def upload_s3(self, local_path: Path, bucket: str, s3_path: str) -> bool:
        return _run_checked(["aws", "s3", "cp", str(local_path), f"s3://{bucket}/{s3_path}"])
