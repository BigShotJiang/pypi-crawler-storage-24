"""Jenkins pipeline generator."""

from pathlib import Path
from typing import List, Optional

from idcu.system.logger import get_logger

logger = get_logger("cicd.jenkins")


class JenkinsPipelineGenerator:
    def __init__(self, project_root: Optional[Path] = None):
        self.project_root = project_root or Path.cwd()

    def generate_jenkinsfile(self, agent_label: str = "python", python_versions: Optional[List[str]] = None) -> Path:
        python_versions = python_versions or ["3.11"]
        jenkinsfile_path = self.project_root / "Jenkinsfile"

        test_stages = "\n".join(
            f"""        stage('Test - Python {version}') {{
            steps {{
                sh 'python -m pytest tests -v'
            }}
        }}"""
            for version in python_versions
        )

        content = f"""pipeline {{
    agent {{ label '{agent_label}' }}

    stages {{
        stage('Setup') {{
            steps {{
                sh 'python -m pip install --upgrade pip'
                sh 'python -m pip install .[dev]'
            }}
        }}
{test_stages}
        stage('Lint') {{
            steps {{
                sh 'python -m ruff check idcu tests'
                sh 'python -m mypy idcu'
            }}
        }}
        stage('Build') {{
            steps {{
                sh 'python -m build'
            }}
        }}
    }}
}}
"""
        jenkinsfile_path.write_text(content, encoding="utf-8")
        logger.info(f"Generated Jenkinsfile: {jenkinsfile_path}")
        return jenkinsfile_path
