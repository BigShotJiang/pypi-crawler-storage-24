# IDCU CLI - 不羁盟命令行工具使用示例

本文件收集了 IDCU CLI 的常用使用示例，帮助您快速上手！

## 目录

- [Git 基础操作](#git-基础操作)
- [Git 高级功能](#git-高级功能)
- [Maven 基础操作](#maven-基础操作)
- [Maven 高级功能](#maven-高级功能)
- [插件和工具](#插件和工具)
- [配置管理](#配置管理)

---

## Git 基础操作

### 1. 列出所有 Git 项目

```bash
# 列出当前目录下所有检测到的 Git 项目
idcu git list
```

**输出示例：**
```
=== Git项目列表 ===
  - project1
  - project2
  - project3
共检测到 3 个项目
```

### 2. 查看项目状态
```bash
# 查看所有项目的状态
idcu git status

# 仅查看指定项目的状态
idcu git status -p project1 project2
```

**输出示例：**
```
=== Git status ===

--- 当前目录: project1 ---
✓ project1: 工作区干净

--- 当前目录: project2 ---
✗ project2: 有 2 个文件未提交
```

### 3. 提交更改

```bash
# 提交所有项目的更改
idcu git commit -m "提交信息" -a

# 仅提交指定项目
idcu git commit -m "提交信息" -a -p project1

# 不使用 -a 参数，仅提交已暂存的更改
idcu git commit -m "提交信息"
```

### 4. 推送和拉取

```bash
# 推送到远程仓库
idcu git push

# 从远程仓库拉取
idcu git pull

# 仅获取更新而不合并
idcu git fetch

# 仅对指定项目执行操作
idcu git push -p project1
idcu git pull -p project2
```

### 5. 切换分支

```bash
# 切换到 develop 分支
idcu git switch develop

# 切换到 feature 分支
idcu git switch feature/new-feature

# 仅对指定项目切换分支
idcu git switch main -p project1
```

### 6. 查看提交日志

```bash
# 查看最近 10 条提交
idcu git log

# 查看最近 20 条提交
idcu git log -n 20

# 仅查看指定项目的日志
idcu git log -n 5 -p project1
```

### 7. 暂存操作

```bash
# 暂存当前更改
idcu git stash -m "临时保存"

# 恢复暂存
idcu git stash-pop

# 查看暂存列表
idcu git stash-list

# 仅对指定项目执行暂存操作
idcu git stash -p project1
idcu git stash-pop -p project1
```

### 8. 查看变更

```bash
# 查看所有项目的变更
idcu git changes

# 仅查看指定项目的变更
idcu git changes -p project1
```

---

## Git 高级功能

### 1. 变基操作

```bash
# 变基到远程 main 分支
idcu git rebase -u origin/main

# 交互式变基
idcu git rebase -i

# 继续变基
idcu git rebase --continue

# 跳过当前提交
idcu git rebase --skip

# 中止变基
idcu git rebase --abort
```

### 2. 拣选提交
```bash
# 拣选单个提交
idcu git cherry-pick <commit-hash>

# 拣选多个提交
idcu git cherry-pick <commit1> <commit2> <commit3>

# 继续拣选
idcu git cherry-pick --continue

# 中止拣选
idcu git cherry-pick --abort

# 跳过当前提交
idcu git cherry-pick --skip

# 拣选但不自动提交
idcu git cherry-pick --no-commit <commit-hash>
```

### 3. 重置操作

```bash
# 软重置：仅重置HEAD，保留更改
idcu git reset --soft HEAD~1

# 混合重置：重置HEAD和暂存区，保留工作区更改
idcu git reset --mixed HEAD~1

# 硬重置：重置所有内容
idcu git reset --hard HEAD~1

# 重置到指定提交
idcu git reset --hard <commit-hash>

# 使用模式参数
idcu git reset --mode hard HEAD~1
```

### 4. 差异比较 (diff)

```bash
# 查看工作区与暂存区的差异
idcu git diff

# 查看暂存区与最后一次提交的差异
idcu git diff --cached

# 统计变更
idcu git diff --stat

# 仅显示变更的文件名
idcu git diff --name-only

# 显示文件名和状态
idcu git diff --name-status

# 比较两个提交
idcu git diff <commit1> <commit2>
```

### 5. 清理工作区
```bash
# 预览将要删除的文件
idcu git clean --dry-run

# 强制删除未跟踪的文件
idcu git clean --force

# 强制删除未跟踪的文件和目录
idcu git clean --force --directories

# 强制删除未跟踪的文件和忽略的文件
idcu git clean --force --ignored

# 排除特定文件
idcu git clean --force --exclude="*.log"
```

### 6. 标签管理

```bash
# 列出所有标签
idcu git tag --list

# 创建轻量级标签
idcu git tag v1.0.0

# 创建附注标签
idcu git tag v1.0.0 -m "Release version 1.0.0" --annotated

# 删除标签
idcu git tag --delete v1.0.0

# 推送标签到远程
idcu git tag --push v1.0.0

# 推送标签到指定远程
idcu git tag --push v1.0.0 --remote upstream
```

### 7. 查看文件修改历史

```bash
# 查看文件的修改历史
idcu git blame <file-path>

# 查看指定行范围
idcu git blame <file-path> --line 10-20

# 显示邮箱
idcu git blame <file-path> --show-email

# 不显示作者名
idcu git blame <file-path> --no-show-name

# 不显示日期
idcu git blame <file-path> --no-show-date
```

### 8. 二分查找 bug

```bash
# 开始二分查找
idcu git bisect --start

# 标记当前为坏版本
idcu git bisect --bad

# 标记某个提交为好版本
idcu git bisect --good <commit-hash>

# 跳过当前提交
idcu git bisect --skip

# 可视化二分查找过程
idcu git bisect --visualize

# 重置二分查找
idcu git bisect --reset
```

---

## Maven 基础操作

### 1. 列出所有 Maven 项目

```bash
# 列出当前目录下所有检测到的 Maven 项目
idcu maven list
```

**输出示例：**
```
=== Maven项目列表 ===
  - project1
  - project2
  - project3
共检测到 3 个项目
```

### 2. 构建项目

```bash
# 使用默认 goal (clean install) 构建
idcu maven build

# 使用自定义 goal
idcu maven build clean package

# 使用自定义 goal 并跳过测试
idcu maven build clean install -DskipTests

# 仅构建指定项目
idcu maven build -p project1

# 指定本地仓库路径
idcu maven build -l /path/to/local/repo
```

---

## Maven 高级功能

### 1. 依赖树分析

```bash
# 查看依赖树
idcu maven dep-tree

# 仅查看指定项目的依赖树
idcu maven dep-tree -p project1

# 指定本地仓库路径
idcu maven dep-tree -l /path/to/local/repo
```

### 2. 依赖列表

```bash
# 列出所有依赖
idcu maven dep-list

# 仅查看指定项目的依赖
idcu maven dep-list -p project1
```

### 3. 依赖分析（找出未使用的）
```bash
# 分析依赖，找出未使用的依赖
idcu maven dep-analyze

# 仅分析指定项目
idcu maven dep-analyze -p project1
```

### 4. 依赖冲突检测
```bash
# 检测依赖冲突
idcu maven dep-conflict

# 仅检测指定项目
idcu maven dep-conflict -p project1
```

### 5. 有效 POM

```bash
# 显示有效 POM
idcu maven effective-pom

# 仅显示指定项目的有效 POM
idcu maven effective-pom -p project1
```

### 6. Profile 管理

```bash
# 列出可用的 Profile
idcu maven profile-list

# 仅列出指定项目的 Profile
idcu maven profile-list -p project1

# 设置 Profile
idcu maven profile-set dev

# 重置 Profile（使用默认）
idcu maven profile-set

# 仅对指定项目设置 Profile
idcu maven profile-set prod -p project1
```

### 7. 仓库列表

```bash
# 列出本地仓库
idcu maven repo-list

# 仅列出指定项目的仓库
idcu maven repo-list -p project1
```

### 8. 清理本地仓库

```bash
# 清理本地仓库
idcu maven clean-local

# 仅清理指定项目关联的本地仓库
idcu maven clean-local -p project1
```

### 9. 构建时间线分析

```bash
# 显示构建时间线
idcu maven timeline

# 跳过测试
idcu maven timeline --skip-tests

# 仅分析指定项目
idcu maven timeline -p project1
```

### 10. 并行构建

```bash
# 使用所有 CPU 核心并行构建
idcu maven parallel -t 1C

# 使用指定线程数
idcu maven parallel -t 4

# 跳过测试
idcu maven parallel --skip-tests

# 仅对指定项目并行构建
idcu maven parallel -t 2 -p project1
```

---

## 插件和工具

### 1. 命令补全安装

**Bash:**
```bash
# 生成 Bash 补全并安装
idcu completions bash -o ~/.idcu-completions.bash

# 添加到 ~/.bashrc
echo "source ~/.idcu-completions.bash" >> ~/.bashrc

# 重新加载配置
source ~/.bashrc
```

**Zsh:**
```bash
# 生成 Zsh 补全并安装
idcu completions zsh -o ~/.zsh/_idcu

# 添加到 ~/.zshrc
echo "fpath=(~/.zsh \$fpath)" >> ~/.zshrc

# 重新加载配置
source ~/.zshrc
```

**PowerShell:**
```powershell
# 生成 PowerShell 补全并安装
idcu completions powershell -o idcu-completions.ps1

# 添加到 PowerShell 配置文件
echo ". idcu-completions.ps1" >> $PROFILE

# 重新加载配置
. $PROFILE
```

### 2. 命令别名

```bash
# 列出所有别名
idcu alias list

# 设置别名
idcu alias set gs "git status"
idcu alias set gc "git commit -m"
idcu alias set gb "git branch"
idcu alias set mb "maven build"
idcu alias set mc "maven clean"

# 删除别名
idcu alias delete gs
idcu alias delete gc
```

### 3. 配置管理

```bash
# 查看当前配置
idcu config show

# 重新加载配置
idcu config reload
```

---

## 配置管理

### 1. 默认配置

配置文件位于 `.idcu/config.yaml`，首次运行会自动创建默认配置。

```yaml
global:
  color_output: true
  verbose: false
  quiet: false
  dry_run: false

i18n:
  language: en
  auto_detect: true

plugins: {}

git:
  default_branch: develop
  remote_name: origin
  auto_fetch: false

maven:
  local_repo_path: .mvn/local-repo
  default_goals:
    - clean
    - install
  offline_mode: false

audit:
  encoding_scan_patterns:
    - "*.java"
    - "*.md"
    - "*.xml"
    - "*.properties"
  encoding_scan_excludes:
    - ".git"
    - "target"
    - ".mvn/local-repo"
  deps_audit_strict: true

aliases: {}
```

### 2. 自定义配置示例

```yaml
global:
  color_output: true
  verbose: true
  dry_run: false

i18n:
  language: zh
  auto_detect: true

git:
  default_branch: main
  remote_name: origin
  auto_fetch: true

maven:
  local_repo_path: ~/.m2/repository
  default_goals:
    - clean
    - package
  offline_mode: false

aliases:
  gs: git status
  gc: git commit -m
  gb: git branch
  gp: git push
  gpl: git pull
  mb: maven build
  mc: maven clean
  mi: maven install
```

---

## 插件系统使用

### 1. 列出插件

```bash
# 列出所有已安装的插件
idcu plugin list
```

### 2. 执行插件命令

```bash
# 执行插件命令
idcu plugin cmd <command-name> <args>

# 示例：使用 release 插件
idcu plugin cmd release.config
idcu plugin cmd release.create-branch 1.0.0
idcu plugin cmd release.update-version 1.0.0-SNAPSHOT 1.0.0
idcu plugin cmd release.build
idcu plugin cmd release.deploy
idcu plugin cmd release.tag 1.0.0
idcu plugin cmd release.full 1.0.0-SNAPSHOT 1.0.0
```

---

## 完整工作流示例

### 1. 日常开发工作流

```bash
# 1. 开始新工作前，拉取最新代码
idcu git pull

# 2. 查看状态
idcu git status

# 3. 进行开发...

# 4. 查看变更
idcu git changes

# 5. 提交更改
idcu git commit -m "完成新功能" -a

# 6. 再次拉取，解决冲突（如有）
idcu git pull

# 7. 推送更改
idcu git push

# 8. 构建项目
idcu maven build
```

### 2. 发布工作流

```bash
# 1. 查看项目状态
idcu git status

# 2. 创建发布分支
idcu git switch -c release/1.0.0

# 3. 更新版本号
# 使用 maven 命令或 release 插件

# 4. 构建项目
idcu maven build

# 5. 运行测试
idcu maven build clean test

# 6. 提交版本更新
idcu git commit -m "Release version 1.0.0" -a

# 7. 创建标签
idcu git tag v1.0.0 -m "Release version 1.0.0" --annotated

# 8. 推送到远程
idcu git push
idcu git tag --push v1.0.0

# 9. 部署
idcu maven build clean deploy
```

### 3. 依赖管理工作流

```bash
# 1. 查看依赖树
idcu maven dep-tree

# 2. 检查依赖冲突
idcu maven dep-conflict

# 3. 分析未使用的依赖
idcu maven dep-analyze

# 4. 查看有效 POM
idcu maven effective-pom

# 5. 清理本地仓库
idcu maven clean-local

# 6. 并行构建（跳过测试）
idcu maven parallel -t 1C --skip-tests
```

---

## 实用技巧

### 技巧 1：同时处理多个项目

```bash
# 1. 拉取所有项目的最新代码
idcu git pull

# 2. 切换到 feature 分支
idcu git switch feature/new-feature

# 3. 进行开发...

# 4. 提交所有项目的更改
idcu git commit -m "完成新功能" -a

# 5. 推送所有项目
idcu git push

# 6. 构建所有项目
idcu maven build
```

### 技巧 2：解决 Git 冲突

```bash
# 1. 拉取远程更改
idcu git pull

# 2. 查看状态
idcu git status

# 3. 解决冲突...

# 4. 标记解决并继续
idcu git commit -m "解决冲突" -a

# 5. 继续推送
idcu git push
```

### 技巧 3：Maven 构建优化

```bash
# 1. 首次构建：显示时间线
idcu maven timeline

# 2. 分析依赖
idcu maven dep-analyze

# 3. 检查冲突
idcu maven dep-conflict

# 4. 使用并行构建
idcu maven parallel -t 4
```

---

## 下一步

- 查看 [README.md](README.md) - 项目主页
- 查看 [TUTORIAL.md](TUTORIAL.md) - 详细教程
- 查看 [FAQ.md](FAQ.md) - 常见问题解答
- 查看 [API 文档](docs/index.md) - 完整 API 参考
