
#!/usr/bin/env python3
"""测试增强版Git和Maven操作"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from idcu.tools.git.git_enhanced import GitEnhancedOperations
from idcu.tools.maven.maven_enhanced import MavenEnhancedOperations


def test_git_enhanced():
    """测试Git增强版操作"""
    print("=== 测试Git增强版操作 ===")
    
    git_ops = GitEnhancedOperations(json_mode=False, dry_run=False)
    
    print("\n1. 测试status操作...")
    result = git_ops.status()
    git_ops.print_result(result)
    
    print("\n2. 测试show操作...")
    result = git_ops.show()
    git_ops.print_result(result)
    
    print("\n3. 测试log操作...")
    result = git_ops.log(limit=5)
    git_ops.print_result(result)
    
    print("\n=== Git增强版操作测试完成!")


def test_git_dry_run():
    """测试Git dry-run模式"""
    print("\n=== 测试Git Dry-Run模式 ===")
    
    git_ops = GitEnhancedOperations(json_mode=False, dry_run=True)
    
    print("\n1. Dry-run status操作...")
    result = git_ops.status()
    git_ops.print_result(result)
    
    print("\n=== Git Dry-Run测试完成!")


def test_git_json_output():
    """测试Git JSON输出模式"""
    print("\n=== 测试Git JSON输出模式 ===")
    
    git_ops = GitEnhancedOperations(json_mode=True, dry_run=False)
    
    print("\n1. JSON status操作 (JSON)...")
    result = git_ops.status()
    git_ops.print_result(result)
    
    print("\n=== Git JSON输出测试完成!")


def test_maven_enhanced():
    """测试Maven增强版操作"""
    print("\n=== 测试Maven增强版操作 ===")
    
    maven_ops = MavenEnhancedOperations(json_mode=False, dry_run=False)
    
    print("\n1. 测试validate操作...")
    result = maven_ops.validate()
    maven_ops.print_result(result)
    
    print("\n=== Maven增强版操作测试完成!")


def test_maven_dry_run():
    """测试Maven dry-run模式"""
    print("\n=== 测试Maven Dry-Run模式 ===")
    
    maven_ops = MavenEnhancedOperations(json_mode=False, dry_run=True)
    
    print("\n1. Dry-run clean操作...")
    result = maven_ops.clean()
    maven_ops.print_result(result)
    
    print("\n=== Maven Dry-Run测试完成!")


def test_maven_json_output():
    """测试Maven JSON输出模式"""
    print("\n=== 测试Maven JSON输出模式 ===")
    
    maven_ops = MavenEnhancedOperations(json_mode=True, dry_run=False)
    
    print("\n1. JSON validate操作...")
    result = maven_ops.validate()
    maven_ops.print_result(result)
    
    print("\n=== Maven JSON输出测试完成!")


def main():
    """主测试主函数"""
    print("开始测试增强版Git和Maven操作...")
    
    try:
        test_git_enhanced()
        test_git_dry_run()
        test_git_json_output()
        
        test_maven_enhanced()
        test_maven_dry_run()
        test_maven_json_output()
        
        print("\n" + "="*50)
        print("所有测试完成!")
        print("="*50)
        
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
