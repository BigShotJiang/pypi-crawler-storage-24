<div align="center">

# IDCU CLI - 不羁盟命令行工具

[![PyPI version](https://img.shields.io/pypi/v/idcu-cli?style=flat-square)](https://pypi.org/project/idcu-cli/)
[![Python Version](https://img.shields.io/badge/python-3.8+-blue?style=flat-square)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache--2.0-green?style=flat-square)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000?style=flat-square)](https://github.com/psf/black)

**面向多仓库开发、构建、质量检查的一站式 CLI 工具**

</div>

---

## 简介

IDCU CLI（不羁盟）是由 **IDCU (I Don't Care Union - 不羁盟)** 维护的开发工作流命令行工具集，基于 **Python 3.8+** 开发，目标是把日常开发中高频、重复、容易出错的操作收敛为统一命令。

## 主航道功能

### 核心能力

- **Git 管理** [核心]：支持仓库扫描、状态查看、提交、推送、拉取、分支切换、stash、子模块批量操作
- **Maven 构建** [核心]：支持项目发现、构建、依赖分析、Profile 管理、并行构建、梯队构建
- **质量检查** [核心]：内置编码检查/修复、依赖审计、TCK 测试入口
- **配置管理** [核心]：支持项目级 `.idcu/config.yaml`、命令别名和配置热重载
- **插件系统** [核心]：支持插件发现、命令注册和示例插件扩展

### 增强能力

- **跨语言构建** [增强]：统一检测和构建 npm/yarn/pnpm、Python、Go、Rust 项目
- **团队协作** [增强]：支持团队配置初始化、导出、权限角色管理
- **发布管理** [增强]：支持发布分支、版本更新、构建部署流程

### 实验能力

- **AI 能力** [实验]：支持 OpenAI/Ollama，用于生成提交信息和代码摘要
- **CI/CD 集成** [实验]：生成 GitHub Actions、PyPI 发布、Docker 相关工作流
- **Web UI** [实验]：基于 FastAPI 提供可视化 Web 界面
- **项目模板** [实验]：支持生成 EST-SPI 标准模块模板

## 安装

### `pip install idcu-cli` 前置依赖

执行 `pip install idcu-cli` 前，至少需要先安装：

- `Python 3.8+`
- `pip`

检查命令：

```bash
python --version
pip --version
```

如果系统里还没有 `pip`，通常可以这样安装或启用：

```bash
python -m ensurepip --upgrade
python -m pip install --upgrade pip
```

确认基础环境就绪后，再安装：

```bash
pip install idcu-cli
```

`PyYAML` 会作为运行时依赖自动安装，一般不需要手动单独安装。

### 功能相关外部依赖

下面这些不是 `pip install idcu-cli` 的前置要求，而是使用对应功能时需要额外安装的外部工具：

- **Git 功能**：安装 `Git` 并确保其在 `PATH` 中
- **Maven 功能**：安装 `Java` 和 `Maven`
- **跨语言构建**：按需安装 `Node.js` / `npm` / `yarn` / `pnpm`、`Go`、`Rust`

如果希望提前检查这些功能依赖，可参考：

```bash
git --version
java -version
mvn -version
node --version
npm --version
go version
rustc --version
```

### 安装可选功能

```bash
pip install "idcu-cli[interactive,web,ai,dev]"
```

### 从源码安装

```bash
git clone https://gitee.com/idcu/cli.git
cd cli
pip install -e ".[interactive,web,ai,dev]"
```

## 快速开始

### 基础命令

```bash
idcu --help
idcu --version
idcu
```

### Git 工作流 [核心]

```bash
idcu git list
idcu git status
idcu git commit -m "feat: update module" -a
idcu git push
idcu git pull
idcu git switch develop
idcu git sub-status
idcu git sub-sync
```

### Maven 与构建 [核心]

```bash
idcu maven list
idcu maven build
idcu maven dep-tree
idcu maven dep-analyze
idcu build detect -p .
idcu build build -p .
```

### 配置、插件与质量检查 [核心]

```bash
idcu config show
idcu alias set gs "git status"
idcu alias list
idcu plugin list
idcu cmd <plugin-command> [args...]
idcu quality list
idcu quality gates
idcu quality encoding check -p .
idcu quality encoding fix -p . -t utf-8
idcu quality dependency-audit audit -p .
idcu quality tck run -p . -f html
```

## 命令总览

### 核心命令

- `git` [核心] - Git 管理
- `maven` [核心] - Maven 构建
- `quality` [核心] - 质量检查
- `config` [核心] - 配置管理
- `alias` [核心] - 命令别名
- `plugin` [核心] - 插件管理
- `cmd` [核心] - 执行插件命令

### 增强命令

- `build` [增强] - 跨语言项目构建
- `team` [增强] - 团队协作
- `release` [增强] - 发布管理
- `env` [增强] - 环境配置
- `completions` [增强] - 命令补全

### 实验命令

- `ai` [实验] - AI 增强功能
- `cicd` [实验] - CI/CD 集成功能
- `web` [实验] - Web UI 功能
- `template` [实验] - 项目模板

## 配置文件

默认配置文件位于当前项目目录下：

```text
.idcu/config.yaml
```

首次运行相关命令时会自动创建默认配置。

示例：

```yaml
global:
  color_output: true
  verbose: false
  quiet: false
  dry_run: false

git:
  default_branch: develop
  remote_name: origin
  auto_fetch: false

maven:
  local_repo_path: .mvn/local-repo
  default_goals:
    - clean
    - install
  offline_mode: false
```

## 目录结构

```text
idcu/
├── cli/                  # CLI 入口、交互模式、补全与项目命令
├── core/                 # 通用能力：UI、缓存、并行、编码处理等
├── system/               # 配置、日志、错误处理、国际化
│   └── config/           # 配置 schema 与校验
└── tools/                # 面向具体场景的工具模块
    ├── git/              # Git 与子模块操作
    ├── maven/            # Maven 相关构建能力
    ├── quality/          # 编码检查、依赖审计、TCK
    ├── plugins/          # 插件系统与示例插件
    ├── crosslang/        # 多语言构建检测与执行
    ├── team/             # 团队配置、权限、审查
    ├── ai/               # OpenAI / Ollama 能力接入
    ├── cicd/             # CI/CD 工作流生成
    └── web/              # FastAPI Web UI
```

## 编码说明

- 仓库文档统一建议使用 **UTF-8** 编码
- `README.md` 已按 **UTF-8 with BOM** 保存，以避免 Windows PowerShell 下直接读取时出现中文乱码
- 如果终端仍显示乱码，请确认 Shell 与编辑器都已启用 UTF-8

## 开发

### 运行测试

```bash
pytest tests/ -v
```

### 静态检查

```bash
mypy idcu/
ruff format
ruff check
black .
```

## 文档

- [TUTORIAL.md](TUTORIAL.md)：从安装到高级用法的完整教程
- [EXAMPLES.md](EXAMPLES.md)：常见命令的实际使用示例
- [FAQ.md](FAQ.md)：常见问题与排查建议
- [CONTRIBUTING.md](CONTRIBUTING.md)：贡献规范
- [RELEASE.md](RELEASE.md)：发布流程

## 许可证

Apache License 2.0

---

<div align="center">
<strong>IDCU CLI - 不羁盟命令行工具</strong><br />
统一命令入口，减少重复劳动，提升开发交付效率
</div>
