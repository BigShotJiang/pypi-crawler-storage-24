# IDCU CLI 发布指南

本指南详细说明了如何将 IDCU CLI 发布到 PyPI。

## 发布前检查清单
- [ ] 所有测试通过 (`pytest tests/ -v`)
- [ ] ruff 检查通过 (`ruff check idcu/`)
- [ ] mypy 类型检查通过 (`mypy idcu/`)
- [ ] 更新版本号
- [ ] 更新 CHANGELOG.md，添加新版本条目
- [ ] 更新 README.md
- [ ] 更新文档

## 发布步骤

### 1. 更新版本号
在 `pyproject.toml` 中更新版本号：
```toml
[project]
version = "1.0.0-SNAPSHOT"
```

### 2. 安装构建工具

```bash
pip install --upgrade pip
pip install build twine hatchling
```

### 3. 清理之前的构建文件

```bash
rm -rf dist/ build/ *.egg-info/
```

### 4. 构建发行包
```bash
python -m build
```

这会在 `dist/` 目录下生成：
- `.whl` 文件（wheel 包）
- `.tar.gz` 文件（源代码分发包）

### 5. 上传到 TestPyPI（可选，推荐）
首先测试上传：
```bash
python -m twine upload --repository testpypi dist/*
```

在 https://test.pypi.org/project/idcu-cli/ 检查上传，
然后测试安装：
```bash
pip install --index-url https://test.pypi.org/simple/ idcu-cli
```

### 6. 上传到 PyPI

确认测试没问题后，上传到正式 PyPI：
```bash
python -m twine upload dist/*
```

### 7. 创建 Git 标签

```bash
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

## 使用 GitHub Releases

在 GitHub 上同时创建一个 Release：
- 版本标签：`v1.0.0`
- 发布说明
- 附件：上传构建的文件

## 发布后验证
1. 验证 PyPI 页面：https://pypi.org/project/idcu-cli/
2. 测试安装：`pip install idcu-cli`
3. 测试功能：`idcu --help`
4. 验证文档更新

## 使用 GitHub Actions 自动发布

配置 GitHub Actions 自动发布：
```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.11'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build and publish
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: |
        python -m build
        twine upload dist/*
```

## 版本号规范
遵循语义化版本（Semantic Versioning）：

- `MAJOR.MINOR.PATCH`
  - MAJOR：不兼容的 API 修改
  - MINOR：向下兼容的功能性新增
  - PATCH：向下兼容的问题修正

示例：
- `1.0.0` → `1.0.1` (bug 修复)
- `1.0.0` → `1.1.0` (新功能)
- `1.1.0` → `2.0.0` (不兼容变更)
