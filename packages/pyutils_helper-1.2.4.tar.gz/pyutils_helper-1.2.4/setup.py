from setuptools import setup, find_packages

setup(
    name='pyutils-helper',
    version='1.2.3',
    description='Python utility helpers for data processing',
    author='Python Utils Team',
    author_email='utils@pypi.org',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
        'psutil>=5.8.0',
    ],
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],
)
