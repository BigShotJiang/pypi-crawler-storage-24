YOUR_API_KEY = "3LDIzg4l.IsJ7zC7WXJ00dNZASD5pzdZBQuYdjDca"

import time
import wave

from orpheus_tts import OrpheusClient

PROVIDER = "baseten"
VOICE = "josh"
TEXT = "Hello from Orpheus."
OUTPUT = "output.wav"

client = OrpheusClient(api_key=YOUR_API_KEY, provider=PROVIDER)
client.connect(voice=VOICE, websocket_count=1)
time.sleep(1) # Brief pause to ensure connection is stable

chunks = []
start = time.perf_counter()

for i, chunk in enumerate(client.stream(TEXT, voice=VOICE)):
    if i == 0:
        print(f"TTFA: {(time.perf_counter() - start) * 1000:.1f}ms")
    chunks.append(chunk)

client.close()
audio = b"".join(chunks)

with wave.open(OUTPUT, "wb") as wav:
    wav.setnchannels(1)
    wav.setsampwidth(2)
    wav.setframerate(48000)
    wav.writeframes(audio)