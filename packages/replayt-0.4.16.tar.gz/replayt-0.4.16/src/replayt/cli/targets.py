"""Resolve MODULE:VAR, .py, and .yaml workflow targets."""

from __future__ import annotations

import importlib
import importlib.util
import re
from pathlib import Path
from typing import Any

import typer

from replayt.workflow import Workflow
from replayt.yaml_workflow import load_workflow_yaml, workflow_from_spec


def _workflow_objects(obj: Any) -> list[tuple[str, Workflow]]:
    return [(name, value) for name, value in vars(obj).items() if isinstance(value, Workflow)]


# Dotted Python module path without ":" — common first-hour mistake (MODULE:VAR).
_DOTTED_MODULEISH = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+$")


def _looks_like_dotted_module_target(target: str) -> bool:
    if not target or "/" in target or "\\" in target:
        return False
    return _DOTTED_MODULEISH.fullmatch(target) is not None


def _is_windows_drive_path_target(target: str) -> bool:
    """True for ``C:\\...`` / ``C:/...`` so the drive letter colon is not treated as MODULE:VAR."""

    if len(target) < 3:
        return False
    return target[0].isalpha() and target[1] == ":" and target[2] in "/\\"


def _target_path_not_found_message(target: str, path: Path) -> str:
    """Explain missing targets with copy-paste fixes (junior onboarding)."""

    base = (
        f"Expected a MODULE:VAR target, a `.py` / `.yaml` workflow path, or `replayt try` to copy an example; "
        f"nothing exists at {path!r}."
    )
    if _looks_like_dotted_module_target(target):
        return (
            f"{base} If you meant a Python module, put a colon before the workflow variable "
            f"(for example: `replayt run {target}:wf`). "
            f"Run `replayt doctor --skip-connectivity --target {target}:wf` after imports work."
        )
    # Only append extensions when *target* has no pathlib-style suffix, otherwise
    # `replayt_examples.e01_hello_world` would wrongly become `replayt_examples.py`.
    if not path.suffix:
        py_sibling = path.parent / f"{path.name}.py"
        yml_sibling = path.parent / f"{path.name}.yml"
        yaml_sibling = path.parent / f"{path.name}.yaml"
        if py_sibling.is_file():
            return (
                f"{base} `{py_sibling.name}` exists here — pass that path "
                f"(for example: `replayt run {py_sibling}`) or set `target` in `.replaytrc.toml`."
            )
        if yml_sibling.is_file():
            return (
                f"{base} `{yml_sibling.name}` exists here — pass that path "
                f"(for example: `replayt run {yml_sibling}`) or set `target` in `.replaytrc.toml`."
            )
        if yaml_sibling.is_file():
            return (
                f"{base} `{yaml_sibling.name}` exists here — pass that path "
                f"(for example: `replayt run {yaml_sibling}`) or set `target` in `.replaytrc.toml`."
            )
    return base


def _python_file_import_bad_parameter(path: Path, exc: ModuleNotFoundError) -> typer.BadParameter:
    missing = getattr(exc, "name", None)
    inner = repr(missing) if missing else "a dependency"
    return typer.BadParameter(
        f"Importing Python workflow file {path} failed: {inner} is missing "
        "(not installed or not on PYTHONPATH). "
        "Activate the right virtual environment, install your project editable (`pip install -e .`) "
        "if this file imports local packages, or switch to a `MODULE:VAR` target once imports work. "
        f"After it imports, `replayt doctor --skip-connectivity --target {path}` checks the graph without executing."
    )


def _python_file_syntax_bad_parameter(path: Path, exc: SyntaxError) -> typer.BadParameter:
    detail = exc.msg or "invalid syntax"
    location = f"line {exc.lineno}"
    if exc.offset is not None:
        location += f", column {exc.offset}"
    return typer.BadParameter(
        f"Python workflow file {path} has a syntax error at {location}: {detail}. "
        f"Fix the file, then retry. Tip: `python -m py_compile {path}` shows the same parser error directly."
    )


def _python_file_runtime_bad_parameter(path: Path, exc: ImportError) -> typer.BadParameter:
    detail = str(exc).strip() or exc.__class__.__name__
    return typer.BadParameter(
        f"Importing Python workflow file {path} failed with {exc.__class__.__name__}: {detail}. "
        "If this file uses package-relative imports, install your project editable (`pip install -e .`) "
        "and prefer a `MODULE:VAR` target once imports work. "
        f"After that, `replayt doctor --skip-connectivity --target {path}` checks the graph without executing."
    )


def load_python_file(path: Path) -> Any:
    module_name = f"replayt_user_{path.stem}_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise typer.BadParameter(f"Could not import Python workflow file: {path}")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except ModuleNotFoundError as exc:
        raise _python_file_import_bad_parameter(path, exc) from exc
    except SyntaxError as exc:
        raise _python_file_syntax_bad_parameter(path, exc) from exc
    except ImportError as exc:
        raise _python_file_runtime_bad_parameter(path, exc) from exc
    for attr in ("wf", "workflow"):
        if hasattr(module, attr):
            return getattr(module, attr)
    workflows = _workflow_objects(module)
    if len(workflows) == 1:
        return workflows[0][1]
    if workflows:
        names = ", ".join(name for name, _ in workflows)
        raise typer.BadParameter(
            f"Python workflow file {path} defines multiple Workflow objects ({names}); "
            "rename the one you want to `wf` or `workflow`."
        )
    raise typer.BadParameter(
        f"Python workflow file {path} must define `wf` or `workflow`, "
        "or exactly one top-level Workflow object."
    )


def _module_import_bad_parameter(target: str, mod_name: str, exc: ModuleNotFoundError) -> typer.BadParameter:
    """Turn import failures into onboarding-friendly CLI errors (common footguns)."""

    missing = getattr(exc, "name", None)
    if missing == mod_name:
        msg = (
            f"Could not import module {mod_name!r} from target {target!r}. "
            "Check spelling and your current working directory. "
            "If this is your own code, install it editable from the project root (`pip install -e .`) "
            "or put your package or `src/` tree on `PYTHONPATH` before running replayt. "
            "You can also pass a trusted `workflow.py` or `.yaml` path instead of MODULE:VAR. "
            "After the import works, `replayt doctor --target TARGET` checks the graph without executing."
        )
    else:
        inner = repr(missing) if missing else "a dependency"
        msg = (
            f"Importing {mod_name!r} for target {target!r} failed: {inner} is missing "
            "(not installed or not on PYTHONPATH). "
            "Install that dependency or fix imports inside your package, then retry."
        )
    return typer.BadParameter(msg)


def load_target(target: str) -> Workflow:
    """Resolve *target* to a :class:`~replayt.workflow.Workflow`.

    ``*.py`` paths are loaded with :func:`importlib.util.spec_from_file_location` and
    :meth:`importlib.abc.Loader.exec_module` (same trust model as ``python path/to/file.py``).
    Use only trusted files; prefer ``MODULE:VAR`` from installed
    packages or YAML workflows when inputs are less trusted.
    """
    path = Path(target)
    looks_like_file = path.suffix in {".py", ".yaml", ".yml"} and path.is_file()
    if looks_like_file:
        if path.suffix == ".py":
            obj = load_python_file(path)
        else:
            obj = workflow_from_spec(load_workflow_yaml(path))
    elif ":" in target and not _is_windows_drive_path_target(target):
        mod_name, attr = target.split(":", 1)
        try:
            mod = importlib.import_module(mod_name)
        except ModuleNotFoundError as exc:
            raise _module_import_bad_parameter(target, mod_name, exc) from exc
        if not hasattr(mod, attr):
            workflows = _workflow_objects(mod)
            if workflows:
                names = ", ".join(name for name, _ in workflows)
                raise typer.BadParameter(
                    f"Module {mod_name!r} has no attribute {attr!r}; available Workflow objects: {names}"
                )
            raise typer.BadParameter(
                f"Module {mod_name!r} has no attribute {attr!r} and exports no Workflow objects."
            )
        obj = getattr(mod, attr)
    else:
        if not path.exists():
            raise typer.BadParameter(_target_path_not_found_message(target, path))
        if path.is_dir():
            raise typer.BadParameter(
                f"Target {path!r} is a directory. Pass a `.py` or `.yaml` workflow file, "
                "or a MODULE:VAR target such as `my_pkg.workflow:wf`."
            )
        raise typer.BadParameter(
            f"Target {path!r} is not a supported workflow file. "
            "Use a `.py` or `.yaml` / `.yml` path, or MODULE:VAR (for example `replayt_examples.e01_hello_world:wf`)."
        )
    if not isinstance(obj, Workflow):
        raise typer.BadParameter(f"{target} did not resolve to a replayt.workflow.Workflow")
    return obj


def workflow_trust_audit_paths(target: str) -> list[Path]:
    """Resolve filesystem paths to audit for POSIX permission bits (no workflow execution).

    Used by ``replayt doctor`` / ``replayt config`` trust reports: ``replayt run`` executes code from
    the workflow entry file (Python path or the module's ``__file__``). Returns at most one path.
    """

    raw = str(target).strip()
    if not raw:
        return []
    path = Path(raw)
    looks_like_file = path.suffix in {".py", ".yaml", ".yml"} and path.is_file()
    if looks_like_file:
        try:
            return [path.resolve()]
        except OSError:
            return []
    if ":" in raw and not _is_windows_drive_path_target(raw):
        mod_name, _attr = raw.split(":", 1)
        mod_name = mod_name.strip()
        if not mod_name:
            return []
        try:
            mod = importlib.import_module(mod_name)
        except ModuleNotFoundError:
            return []
        fn = getattr(mod, "__file__", None)
        if not fn:
            return []
        p = Path(fn)
        if not p.is_file() or p.suffix != ".py":
            return []
        try:
            return [p.resolve()]
        except OSError:
            return []
    return []
