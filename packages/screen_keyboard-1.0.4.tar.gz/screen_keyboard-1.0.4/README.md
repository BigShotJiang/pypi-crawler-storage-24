# 手机键盘控制电脑

通过手机浏览器访问网页，使用虚拟键盘控制电脑输入。

**原理**：网页发送键盘按键到电脑，由电脑上的输入法（如搜狗、微软拼音）处理拼音转换。

## 快速安装

### 方法一：pip 安装（推荐）

```bash
# 安装
pip install screen-keyboard

# 运行
screen-keyboard start
```

### 方法二：源码安装

```bash
# 克隆或直接下载后
pip install -e .

# 运行
screen-keyboard start
```

### 方法三：一行命令安装

```bash
curl -sL https://raw.githubusercontent.com/your-username/screen-keyboard/main/install-one-line.sh | bash
```

## CLI 命令行使用

### 可用命令

```bash
# 启动服务（默认端口 5000）
screen-keyboard start

# 指定端口启动
screen-keyboard start --port 8080
screen-keyboard start -p 8080

# 快速查看局域网 IP
screen-keyboard ip

# 查看本机详细网络信息
screen-keyboard info

# 检查端口是否被占用
screen-keyboard check -p 5000

# 显示帮助信息
screen-keyboard help
screen-keyboard --help
```

### 终端图形界面

启动服务时会显示漂亮的终端图形界面：

```
╔══════════════════════════════════════════════════════════╗
║                                                      ▄▀█║
║  █▀▀ █▀█ █▀▄▀█ █▀▀ ▄▀█                              █║
║  █▄▄ █▄█ █░▀░█ ██▄ █▀█                              █║
║                                                      █║
║  █▀▀ █▀█ █░█ █▀▀ █▀█ ▄▀█ █░                    ▀█║
║  █▄▄ █▄█ ▀▄▀ ██▄ █▀█ █▀█ ▄██                      █║
║                                                      █║
╠══════════════════════════════════════════════════════════╣
║  服务已启动                                          ║
╠══════════════════════════════════════════════════════════╣
║  局域网地址：                                        ║
║  http://192.168.1.100:5000                             ║
║  ┊                                                    ┊
║  ┊  其他可用地址：                                       ┊
╠══════════════════════════════════════════════════════════╣
║  请在手机浏览器访问上述地址                            ║
║  按 Ctrl+C 停止服务                                   ║
╚══════════════════════════════════════════════════════════╝
```

## 使用方法

### 1. 启动服务

```bash
screen-keyboard start
```

服务端启动后会显示局域网地址，例如：
```
局域网地址：http://192.168.1.100:5000
```

### 2. 手机访问

在手机上连接同一 WiFi，用浏览器访问该地址即可。

## 功能

- ✅ 全键盘布局（QWERTY）
- ✅ 符号/数字键盘切换
- ✅ Shift 大写切换
- ✅ 特殊按键（回车、退格、空格）
- ✅ 方向键（倒 T 布局）
- ✅ 触控板鼠标控制
- ✅ 摇杆鼠标控制
- ✅ 鼠标左右中键 + 滚轮
- ✅ Win+Space 中英文切换
- ✅ 拖动窗口/文件（双击触控板后拖动）
- ✅ 锁定页面防止误触

## 说明

- 确保手机和电脑在同一局域网
- 电脑需开启拼音输入法
- 如果防火墙阻止，请开放 5000 端口

## 开发

```bash
# 创建 conda 环境
conda env create -f environment.yml
conda activate screen-keyboard

# 安装依赖
pip install -r requirements.txt

# 运行
python app.py
```

## 发布到 PyPI

```bash
# 安装构建和发布工具
pip install build twine

# 构建包
python -m build

# 上传到 PyPI
python -m twine upload dist/*

# 或使用发布脚本
chmod +x publish.sh
./publish.sh
```

首次发布需要配置 PyPI API Token：
```bash
# 创建 ~/.pypirc 文件
cat > ~/.pypirc << EOF
[distutils]
index-servers =
    pypi

[pypi]
username = __token__
password = pypi-xxxxx  # 从 https://pypi.org/manage/account/token/ 获取
EOF
```

## License

MIT License

