class ElevationServiceException(Exception):
    pass
