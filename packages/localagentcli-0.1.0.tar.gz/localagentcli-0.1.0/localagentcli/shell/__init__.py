"""Shell UI subsystem."""
