"""Storage and logging subsystem."""
