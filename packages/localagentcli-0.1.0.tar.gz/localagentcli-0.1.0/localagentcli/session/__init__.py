"""Session management subsystem."""
