from setuptools import setup, find_packages

setup(
    name='hyperdd',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # List your project's dependencies here,
        # for example: 'requests>=2.0',
    ],
    # Add all other necessary metadata
)

