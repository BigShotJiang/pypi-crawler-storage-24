# dsai-synapsis-agent-init

Tool internal Synapsis DSAI untuk melakukan inisialisasi dan sinkronisasi aturan AI agent (standardized agent rules, skills, and workflows).

## Deskripsi
Alat ini mendistribusikan standar operasional prosedur (SOP) dan kemampuan (skills) ke berbagai platform AI agent untuk memastikan seluruh tim DSAI bekerja dengan standar yang sama.

### Platform yang Didukung:
- **Generic Agent / Antigravity:** Folder `.agent/` dan `.agents/`
- **Claude Code:** Folder `.claude/`
- **Cursor AI:** Folder `.cursor/rules/` (Modern `.mdc` format)
- **GitHub Copilot:** Folder `.github/` (Custom instructions)
- **Standalone Files:** `GEMINI.md`, `CLAUDE.md`, `AGENTS.md`, `.cursorrules`

---

## 🚀 Cara Penggunaan (Tim)

### 1. Inisialisasi / Update (Direkomendasikan)
Jalankan perintah ini di root repositori project Anda untuk mendapatkan aturan terbaru:

```bash
uvx --refresh dsai-synapsis-agent-init
```

### 2. Melihat Detail Sinkronisasi
Gunakan flag `--verbose` untuk melihat file apa saja yang dibuat, diperbarui, atau dilewati:

```bash
uvx --refresh dsai-synapsis-agent-init --verbose
```

---

## 🛡️ Fitur Utama

### 1. Ownership Protection (Managed Marker)
Tool ini sangat menghormati kustomisasi personal Anda.
- Setiap file yang dikelola tool memiliki baris: `<!-- synapsis-dsai-managed -->`.
- **Jika Anda ingin mengubah isi file secara permanen** dan tidak ingin tool menimpanya saat update, cukup **HAPUS** baris marker tersebut.
- Tool akan otomatis melewati (*skip*) file yang tidak memiliki marker managed.

### 2. Smart-Merge (Standalone Files)
Untuk file tunggal seperti `GEMINI.md` atau `CLAUDE.md`, tool menggunakan mekanisme "Zonasi":
- Tool hanya mengupdate konten di antara marker `synapsis-dsai-core-start` dan `synapsis-dsai-core-end`.
- Konten buatan Anda di luar marker tersebut akan tetap aman dan tidak tersentuh.

### 3. Binary Asset Support
Tool secara otomatis mendeteksi file gambar atau aset binary lainnya dan melakukan salinan langsung tanpa merusak struktur file.

---

## ❓ Q&A (Pertanyaan Umum)

### Apa itu "Skills" dalam repositori ini?
**Skills** adalah kumpulan instruksi dan praktik terbaik (best practices) yang telah diformat khusus agar AI agent dapat memahami konteks kerja tim secara mendalam.

### Bahasa apa saja yang didukung?
Mendukung berbagai teknologi: Python, Rust, SQL, Shell, serta instruksi dalam **Bahasa Indonesia** dan **English**.

### Apakah skills hanya untuk coding?
**Tidak.** Tersedia juga skill untuk Product Management (PRD, Backlog), Data & Research, serta Design & Architecture.

---

## 🛠️ Pengembangan

### Setup Lokal
```bash
cd dsai-synapsis-agent-init
uv sync --extra dev
```

### Menjalankan Test
Project ini dikembangkan dengan **TDD**. Pastikan unit test tetap hijau sebelum melakukan push:
```bash
uv run pytest
```

### Menambah Template Baru
1. Letakkan file di root repositori pusat (misal di folder `.cursor/rules/`).
2. Jalankan proses sinkronisasi ke folder `templates` di dalam tool.
3. Naikkan versi di `pyproject.toml` dan publish ke PyPI.
