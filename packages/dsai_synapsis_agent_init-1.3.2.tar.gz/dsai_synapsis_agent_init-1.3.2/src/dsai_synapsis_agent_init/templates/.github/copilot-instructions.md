# Synapsis DSAI Copilot Instructions

Follow the standardized Synapsis DSAI engineering rules for all AI interactions in this repository.

## Core Mandates
- **Rules:** Adhere to `.agent/rules/main-rules.md`.
- **API:** Adhere to `.agent/skills/api-standards/SKILL.md`.
- **Commit:** Use Conventional Commits.
- **Workflow:** Research -> Strategy -> Execution -> Validation.
