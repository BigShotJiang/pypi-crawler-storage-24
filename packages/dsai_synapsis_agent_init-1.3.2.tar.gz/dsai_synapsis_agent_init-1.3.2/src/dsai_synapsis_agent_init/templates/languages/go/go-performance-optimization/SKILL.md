---
name: go-performance-optimization
description: "Techniques for optimizing Go performance, focusing on memory allocation and concurrency."
language: go
---

# Go Performance Optimization

Strategies for making Go applications fast, efficient, and scalable.

## Guidelines
- **Avoid unnecessary allocations**: Use `sync.Pool` to reuse objects and minimize GC pressure.
- **Pre-allocate slices and maps**: Use `make(T, 0, capacity)` when the size is known or can be estimated.
- **Use `pprof`**: Profile CPU, memory, and goroutine blocking to find real bottlenecks before optimizing.
- **Efficient String Concatenation**: Use `strings.Builder` instead of `+` in loops.
- **Minimize Pointer Chasing**: Prefer value types for small structs to improve cache locality.
- **Concurrency Overkill**: Don't use goroutines for tasks that are too small. The overhead might exceed the benefits.
- **Avoid `interface{}` in hot paths**: Method calls on interfaces are slower than concrete type calls due to dynamic dispatch.

## Tools & Libraries
- **pprof**: The standard Go profiling tool.
- **benchstat**: For comparing benchmark results.
- **easyjson / ffjson**: For faster JSON serialization if the standard library is too slow.
- **gcvis**: For visualizing garbage collection behavior.

## Trigger Scenarios
- When an application has high CPU usage or slow response times.
- When the garbage collector is taking up too much time (GC pressure).
- When optimizing data processing pipelines.
- When a developer asks how to reduce memory footprint.

<!-- synapsis-dsai-managed -->
