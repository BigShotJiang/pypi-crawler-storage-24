---
name: go-testing-patterns
description: "Comprehensive testing strategies for Go including table-driven tests and benchmarking."
language: go
---

# Go Testing Patterns

Effective patterns for testing Go code using the standard `testing` package and idiomatic approaches.

## Guidelines
- **Table-Driven Tests**: Use a slice of structs to define test cases and a loop to run them. This is the Go standard.
- **Use `t.Run` for subtests**: This allows for better organization and the ability to run specific test cases.
- **Test files in the same package**: Name test files `filename_test.go` and put them in the same directory.
- **External tests**: Use `package name_test` to test the public API and avoid circular dependencies.
- **Mocking**: Use interfaces for dependency injection. Use tools like `gomock` or `testify/mock` if manual mocks become too verbose.
- **Assertions**: While some prefer standard `if` checks, `testify/assert` is widely used for more readable assertions.
- **Benchmarks**: Use `func BenchmarkXxx(b *testing.B)` to measure performance.
- **Fuzzing**: Use `func FuzzXxx(f *testing.F)` (Go 1.18+) for automated property-based testing.

## Tools & Libraries
- **go test**: The built-in test runner.
- **testify**: Popular toolkit for assertions and mocks.
- **gomock**: Official mocking framework for Go.
- **gotests**: Automatically generates table-driven tests from source code.

## Trigger Scenarios
- When adding new features that require verification.
- When writing tests for functions with many edge cases (Table-driven tests).
- When mocking external services (databases, APIs).
- When a developer needs to verify the performance of a hot path (Benchmarks).

<!-- synapsis-dsai-managed -->
