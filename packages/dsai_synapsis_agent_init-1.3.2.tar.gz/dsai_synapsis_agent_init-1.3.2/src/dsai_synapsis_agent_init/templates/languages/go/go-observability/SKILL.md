---
name: go-observability
description: "Implementing observability in Go with logging, metrics, and tracing."
language: go
---

# Go Observability

Best practices for monitoring and diagnosing Go applications in production.

## Guidelines
- **Structured Logging**: Use `slog` (Go 1.21+) or `zerolog`/`zap` for structured, high-performance logging.
- **Instrumentation with OpenTelemetry**: Use the official Go OTel SDK for distributed tracing and metrics.
- **Expose `/debug/pprof`**: Securely expose pprof endpoints for on-demand profiling in production.
- **Standard Metrics**: Collect "Golden Signals" (Latency, Traffic, Errors, Saturation).
- **Contextual Logging**: Pass `context.Context` through your layers to carry trace IDs and other metadata for logging.
- **Prometheus Integration**: Use `prometheus/client_golang` for exposing metrics in Prometheus format.
- **Health Checks**: Implement `/healthz` (liveness) and `/readyz` (readiness) endpoints for orchestrators like Kubernetes.

## Tools & Libraries
- **slog**: The standard library's structured logging package.
- **zap / zerolog**: High-performance third-party logging libraries.
- **opentelemetry-go**: The standard for tracing and metrics.
- **prometheus/client_golang**: The most popular metrics library for Go.

## Trigger Scenarios
- When building a web service or microservice.
- When debugging performance issues in production.
- When setting up dashboards and alerts for a Go application.
- When a developer needs to correlate logs with specific user requests.

<!-- synapsis-dsai-managed -->
