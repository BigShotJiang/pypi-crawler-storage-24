---
name: go-anti-patterns
description: "Common Go anti-patterns to avoid, focusing on simplicity and idiomatic Go."
language: go
---

# Go Anti-patterns

Common pitfalls and anti-patterns to avoid in Go development, ensuring maintainability and performance.

## Guidelines
- **Avoid overusing `interface{}` (any)**: It bypasses type safety. Use generics (Go 1.18+) or specific interfaces instead.
- **Don't ignore errors**: Always check the error returned by a function. Use `_` only if you are absolutely sure.
- **Avoid deep nesting**: Use "guard clauses" and early returns to keep the happy path at a low indentation level.
- **Don't use `init()` functions excessively**: They can make initialization order non-deterministic and hard to test.
- **Avoid `panic` in normal flow**: Use `error` for expected failures. `panic` should be reserved for truly unrecoverable situations (e.g., programmer errors).
- **Don't over-interface**: Don't define interfaces before you have a real need for them. Define interfaces where they are used (consumer-side).
- **Avoid pointer-to-interface**: An interface is already a pointer-like header. `*MyInterface` is almost always a mistake.
- **Don't leak goroutines**: Always ensure goroutines have a clear exit strategy (e.g., using `context` or `done` channels).

## Tools & Libraries
- **golangci-lint**: The ultimate linter aggregator for Go.
- **staticcheck**: Advanced static analysis for Go.
- **errcheck**: Specifically checks for unchecked errors.
- **govet**: The standard Go tool for identifying common mistakes.

## Trigger Scenarios
- When reviewing Go code with complex nesting or missing error checks.
- When an implementation uses `interface{}` where a concrete type or generic would work.
- When goroutines are started without a clear way to stop them.
- When a developer asks about Go best practices and common pitfalls.

<!-- synapsis-dsai-managed -->
