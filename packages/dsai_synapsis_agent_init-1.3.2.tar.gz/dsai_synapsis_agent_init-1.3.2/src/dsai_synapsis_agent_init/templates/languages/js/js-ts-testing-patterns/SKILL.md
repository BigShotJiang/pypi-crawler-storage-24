---
name: js-ts-testing-patterns
description: "Comprehensive testing strategies for JS/TS including unit, integration, and E2E testing."
language: js-ts
---

# JS/TS Testing Patterns

Effective patterns for testing JavaScript and TypeScript applications across the stack.

## Guidelines
- **Use Jest or Vitest for Unit/Integration Tests**: The industry standards for JS/TS testing.
- **React Testing Library**: Prefer testing component behavior over implementation details.
- **Mocking**: Use `jest.mock()` or `vi.mock()` for external dependencies and APIs.
- **Arrange-Act-Assert (AAA)**: Follow this structure for clear and readable test cases.
- **TDD (Test Driven Development)**: Write tests before implementation for critical logic.
- **Snapshot Testing**: Use sparingly for UI components that change infrequently.
- **E2E Testing**: Use Cypress or Playwright for critical user journeys.
- **Code Coverage**: Aim for high coverage in business logic, but don't obsess over 100% for boilerplate code.

## Tools & Libraries
- **Jest / Vitest**: Core test runners.
- **React Testing Library**: For testing React components.
- **Cypress / Playwright**: For end-to-end testing.
- **msw (Mock Service Worker)**: For mocking API requests at the network level.

## Trigger Scenarios
- When adding new UI components or business logic.
- When refactoring code and ensuring no regressions.
- When setting up a CI/CD pipeline with automated tests.
- When a developer needs to simulate complex user interactions.

<!-- synapsis-dsai-managed -->
