---
name: js-ts-anti-patterns
description: "Common JavaScript and TypeScript anti-patterns to avoid, focusing on type safety and modern syntax."
language: js-ts
---

# JS/TS Anti-patterns

Common pitfalls and anti-patterns to avoid in JavaScript and TypeScript development.

## Guidelines
- **Avoid `any` type in TypeScript**: It defeats the purpose of using TypeScript. Use `unknown` if the type is truly unknown, or define proper interfaces/types.
- **Don't use `var`**: Always use `const` by default, and `let` only if reassignment is necessary.
- **Avoid Callback Hell**: Use Promises and `async/await` for cleaner asynchronous code.
- **Don't ignore Promise rejections**: Always handle errors in async code using `try/catch` or `.catch()`.
- **Avoid "Magic Numbers" and Strings**: Use constants or enums to improve readability and maintainability.
- **Don't modify global objects**: Avoid adding properties to `window`, `process`, or prototype of built-in objects.
- **Avoid excessive nesting**: Use early returns (guard clauses) to keep code flat.
- **Don't use `==` (loose equality)**: Always use `===` (strict equality) to avoid unexpected type coercion.

## Tools & Libraries
- **ESLint**: The standard linter for JS and TS.
- **TypeScript Compiler (tsc)**: For type checking.
- **typescript-eslint**: For TS-specific linting rules.
- **SonarQube**: For deep code quality and security analysis.

## Trigger Scenarios
- When reviewing code that uses `any` frequently in TypeScript.
- When an implementation uses old-fashioned callbacks instead of `async/await`.
- When type safety is bypassed or ignored.
- When a developer asks about common pitfalls in modern JS/TS.

<!-- synapsis-dsai-managed -->
