---
name: js-ts-observability
description: "Implementing observability in JS/TS with logging, tracing, and error monitoring."
language: js-ts
---

# JS/TS Observability

Best practices for monitoring and diagnosing JavaScript and TypeScript applications in production.

## Guidelines
- **Structured Logging**: Use `pino` or `winston` for structured logging in Node.js. Avoid raw `console.log` in production.
- **Frontend Error Monitoring**: Use Sentry or Honeycomb to capture uncaught exceptions and performance metrics in the browser.
- **Distributed Tracing**: Implement OpenTelemetry to track requests through frontend and backend services.
- **Performance Metrics**: Use the Web Vitals API to track real-user performance metrics (LCP, FID, CLS).
- **Log Correlation**: Attach trace IDs to logs to correlate frontend actions with backend logs.
- **Health Checks**: Implement `/health` endpoints in Node.js services for monitoring by orchestrators.

## Tools & Libraries
- **Pino / Winston**: High-performance logging for Node.js.
- **OpenTelemetry JS**: For tracing and metrics across JS environments.
- **Sentry**: For error and performance monitoring.
- **Web Vitals**: For measuring frontend performance.

## Trigger Scenarios
- When launching a new production application.
- When debugging intermittent issues in a distributed system.
- When setting up alerts for application errors or performance regressions.
- When a developer needs to understand the user's path leading to a crash.

<!-- synapsis-dsai-managed -->
