---
name: js-ts-code-style
description: "Standard JS/TS code style and formatting guidelines based on Airbnb and Google standards."
language: js-ts
---

# JS/TS Code Style

Standardized formatting and style guidelines for JavaScript and TypeScript, ensuring consistency and readability.

## Guidelines
- **Follow Prettier/ESLint defaults**: Use automated tools to enforce consistency.
- **Naming Conventions**:
  - `camelCase` for variables, functions, and class instances.
  - `PascalCase` for classes, interfaces, types, and enums.
  - `SCREAMING_SNAKE_CASE` for global constants.
- **TypeScript Specifics**:
  - Prefer `interface` for public APIs and `type` for internal definitions or unions/intersections.
  - Don't use the `I` prefix for interfaces (e.g., use `User`, not `IUser`).
- **File Organization**: One component/class per file. Use descriptive file names (e.g., `UserProfile.tsx`).
- **Arrow Functions**: Prefer arrow functions for anonymous functions and callbacks.
- **Destructuring**: Use object and array destructuring for cleaner access to properties and elements.
- **Template Literals**: Use template literals (backticks) instead of string concatenation.

## Tools & Libraries
- **Prettier**: The opinionated code formatter.
- **ESLint**: For style and logic linting.
- **EditorConfig**: For consistent editor settings across different IDEs.

## Trigger Scenarios
- When starting a new frontend or backend project.
- When formatting code before a pull request.
- When reviewing code for naming and structural consistency.
- When a developer asks about the difference between `interface` and `type`.

<!-- synapsis-dsai-managed -->
