---
name: rust-testing-patterns
description: "Comprehensive testing strategies for Rust including unit, integration, and property-based testing."
language: rust
---

# Rust Testing Patterns

Effective patterns for testing Rust code to ensure correctness, reliability, and performance.

## Guidelines
- **Unit tests in the same file**: Place unit tests in a `mod tests` at the bottom of the source file, annotated with `#[cfg(test)]`.
- **Integration tests in `tests/`**: Place integration tests that use the public API in the `tests/` directory at the root of the project.
- **Use `assert!`, `assert_eq!`, and `assert_ne!`**: Use standard macros for validation.
- **Doc tests**: Write examples in documentation that also serve as tests.
- **Mocking**: Use crates like `mockall` or `simulacrum` for dependency injection and mocking.
- **Property-based testing**: Use `proptest` or `quickcheck` to test properties over a wide range of inputs.
- **Benchmark tests**: Use `criterion` for high-performance benchmarking.

## Tools & Libraries
- **cargo test**: The built-in test runner.
- **mockall**: Powerful mocking library for Rust.
- **proptest**: Property-based testing framework.
- **criterion**: For micro-benchmarking and performance tracking.
- **nextest**: A faster, more feature-rich test runner for Rust.

## Trigger Scenarios
- When adding new features that require verification.
- When fixing bugs and adding regression tests.
- When writing public documentation with examples.
- When a developer needs to verify the performance of a function.

<!-- synapsis-dsai-managed -->
