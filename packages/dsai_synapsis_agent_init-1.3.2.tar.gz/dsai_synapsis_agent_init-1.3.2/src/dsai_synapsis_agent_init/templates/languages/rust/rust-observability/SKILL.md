---
name: rust-observability
description: "Implementing observability in Rust with logging, metrics, and distributed tracing."
language: rust
---

# Rust Observability

Best practices for monitoring, logging, and tracing Rust applications for production reliability.

## Guidelines
- **Structured Logging**: Use structured logs (JSON or key-value) instead of raw text for better machine readability.
- **Use `tracing` for instrumentation**: Prefer the `tracing` crate over simple logging for rich, asynchronous diagnostics.
- **Expose Metrics**: Use crates like `metrics` or `prometheus` to export performance and business metrics.
- **Distributed Tracing**: Implement OpenTelemetry to track requests across service boundaries.
- **Standard Log Levels**: Use `trace`, `debug`, `info`, `warn`, and `error` appropriately.
- **Contextual Information**: Attach relevant context (e.g., request IDs, user IDs) to logs and spans.
- **Error Reporting**: Integrate with tools like Sentry or Honeycomb for automated error aggregation.

## Tools & Libraries
- **tracing**: The industry standard for tracing and logging in Rust.
- **log**: A lightweight logging facade.
- **metrics**: A facade for collecting and exporting metrics.
- **opentelemetry**: For standardized distributed tracing and metrics.
- **sentry-rust**: For error tracking and reporting.

## Trigger Scenarios
- When building a production-ready web service or CLI tool.
- When debugging issues in a distributed system.
- When setting up monitoring and alerting for an application.
- When a developer needs to track the flow of a request through the system.

<!-- synapsis-dsai-managed -->
