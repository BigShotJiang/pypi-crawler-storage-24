---
name: rust-code-style
description: "Standard Rust code style and formatting guidelines based on rustfmt and RFCs."
language: rust
---

# Rust Code Style

Standardized formatting and style guidelines for Rust, ensuring consistency across the codebase.

## Guidelines
- **Follow `rustfmt` defaults**: Use the standard formatting provided by the language.
- **Naming Conventions**:
  - `Snake_case` for variables, functions, methods, and modules.
  - `PascalCase` for types (structs, enums, traits, unions).
  - `SCREAMING_SNAKE_CASE` for constants and statics.
- **Module Organization**: Prefer a `src/lib.rs` or `src/main.rs` as the entry point, and use a hierarchical module structure.
- **Use meaningful names**: Avoid single-letter variables except for common idioms like `i` in loops or `e` for errors.
- **Implicit returns**: Use implicit returns for the last expression in a function.
- **Documentation**: Use `///` for doc comments and `//!` for module-level documentation. Provide examples in doc comments.
- **Order of imports**: Group imports into three sections: standard library, external crates, and local modules, separated by a blank line.

## Tools & Libraries
- **rustfmt**: The official Rust formatter.
- **rust-analyzer**: For IDE support and style enforcement.
- **clippy**: For style-related linting beyond formatting.

## Trigger Scenarios
- When starting a new Rust project or module.
- When formatting code before a commit.
- When reviewing code for style and naming consistency.
- When a developer asks about Rust naming conventions.

<!-- synapsis-dsai-managed -->
