---
name: cpp-testing-patterns
description: "Comprehensive testing strategies for C++ including unit testing with GTest and Catch2."
language: cpp
---

# C++ Testing Patterns

Effective patterns for testing C++ code to ensure correctness, reliability, and performance.

## Guidelines
- **Use GoogleTest (GTest) or Catch2**: The most popular unit testing frameworks for C++.
- **Test-Driven Development (TDD)**: Write a failing test before implementing the corresponding feature.
- **Isolate Logic with Dependency Injection**: Use interfaces (abstract classes) to mock dependencies.
- **Mocking with GoogleMock**: Use `gmock` to create mock objects for testing interactions.
- **Property-Based Testing**: Use `RapidCheck` to test properties over a wide range of inputs.
- **Death Tests**: Use GTest's death tests to verify that code crashes or terminates correctly in response to invalid input.
- **Continuous Integration**: Ensure tests are run automatically on every commit.

## Tools & Libraries
- **GoogleTest (GTest) / GoogleMock**: The standard for C++ testing.
- **Catch2**: A modern, header-only C++ test framework.
- **Fuzzing with libFuzzer / AFL**: For automated discovery of security vulnerabilities and crashes.
- **Benchmark.js / Catch2 Benchmark**: For measuring performance.

## Trigger Scenarios
- When adding new features that require verification.
- When fixing bugs and adding regression tests.
- When mocking complex dependencies in a unit test.
- When a developer needs to verify the behavior of code in error conditions.

<!-- synapsis-dsai-managed -->
