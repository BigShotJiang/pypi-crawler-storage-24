---
name: cpp-code-style
description: "Standard C++ code style and formatting guidelines based on Google and LLVM standards."
language: cpp
---

# C++ Code Style

Standardized formatting and style guidelines for C++, ensuring consistency across large codebases.

## Guidelines
- **Follow `clang-format`**: Use a consistent style (e.g., Google, LLVM, or Microsoft) defined in a `.clang-format` file.
- **Naming Conventions**:
  - `PascalCase` for types (classes, structs, enums).
  - `snake_case` or `camelCase` for variables and functions (be consistent).
  - `kPascalCase` or `SCREAMING_SNAKE_CASE` for constants.
  - Prefix private member variables with an underscore (e.g., `_member`) or suffix them (e.g., `member_`).
- **Header Guards**: Use `#ifndef FILENAME_H` or `#pragma once` to prevent multiple inclusions.
- **Const Correctness**: Use `const` as much as possible for variables and member functions that don't modify state.
- **Include Order**: Standard library, then third-party libraries, then local headers.
- **Documentation**: Use Doxygen-style comments (`/** ... */` or `///`) for public APIs.

## Tools & Libraries
- **clang-format**: The industry standard for C++ code formatting.
- **EditorConfig**: To maintain consistent coding styles between different editors.
- **Doxygen**: For generating documentation from source code comments.

## Trigger Scenarios
- When starting a new C++ project or module.
- When formatting code before a commit.
- When reviewing code for style and naming consistency.
- When a developer asks about C++ naming conventions or header organization.

<!-- synapsis-dsai-managed -->
