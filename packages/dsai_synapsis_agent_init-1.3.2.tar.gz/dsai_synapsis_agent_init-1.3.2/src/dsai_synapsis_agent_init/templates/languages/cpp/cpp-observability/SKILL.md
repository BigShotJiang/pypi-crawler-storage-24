---
name: cpp-observability
description: "Implementing observability in C++ with logging, metrics, and tracing."
language: cpp
---

# C++ Observability

Best practices for monitoring and diagnosing C++ applications in production.

## Guidelines
- **Structured Logging**: Use libraries like `spdlog` or `glog` for high-performance, structured logging.
- **Instrumentation with OpenTelemetry**: Use the OpenTelemetry C++ SDK for distributed tracing and metrics.
- **Expose Performance Metrics**: Use `Prometheus-cpp` to export internal metrics in a standardized format.
- **Custom Diagnostics**: Implement heartbeat/health-check endpoints or shared memory segments for external monitoring.
- **Standard Log Levels**: Use `TRACE`, `DEBUG`, `INFO`, `WARN`, `ERROR`, and `FATAL` appropriately.
- **Contextual Logging**: Include thread IDs, timestamps, and request context in log messages.
- **Crash Reporting**: Integrate with tools like Sentry or Breakpad/Crashpad for automated crash analysis.

## Tools & Libraries
- **spdlog**: Very fast, header-only or compiled C++ logging library.
- **opentelemetry-cpp**: The standard for tracing and metrics in C++.
- **prometheus-cpp**: Prometheus client library for C++.
- **Sentry (Native SDK)**: For error tracking and crash reporting.

## Trigger Scenarios
- When building a production-ready system service or backend application.
- When debugging issues in a distributed C++ system.
- When setting up monitoring and alerting for a C++ application.
- When a developer needs to track the internal state of a long-running process.

<!-- synapsis-dsai-managed -->
