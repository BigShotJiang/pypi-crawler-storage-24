---
name: cpp-anti-patterns
description: "Common C++ anti-patterns to avoid, focusing on memory safety and modern C++ (C++11 and beyond)."
language: cpp
---

# C++ Anti-patterns

Common pitfalls and anti-patterns to avoid in C++ development, ensuring safety and performance.

## Guidelines
- **Avoid Manual Memory Management**: Don't use raw `new` and `delete`. Prefer smart pointers (`std::unique_ptr`, `std::shared_ptr`) or stack allocation.
- **Don't use `using namespace std;` in headers**: It pollutes the global namespace and can lead to naming conflicts.
- **Avoid C-style casts**: Use C++ casts (`static_cast`, `dynamic_cast`, `reinterpret_cast`, `const_cast`) for better type safety and visibility.
- **Don't ignore compiler warnings**: Treat warnings as errors (`-Werror`). Modern compilers are very good at catching potential bugs.
- **Avoid raw arrays**: Use `std::array` or `std::vector` instead of C-style arrays for better safety and features.
- **Don't use `NULL`**: Use `nullptr` (C++11) for pointer nullity.
- **Avoid "God Classes"**: Follow the Single Responsibility Principle. Don't let a class grow too large.
- **Don't use `std::endl` when `\n` suffices**: `std::endl` forces a flush, which can be a performance bottleneck in loops.

## Tools & Libraries
- **clang-tidy**: Powerful static analysis tool for catching anti-patterns and enforcing modern C++ styles.
- **Cppcheck**: Static analysis tool for C/C++ code.
- **Clang Static Analyzer**: Finds bugs in C, C++, and Objective-C programs.

## Trigger Scenarios
- When reviewing legacy C++ code or code using raw pointers.
- When an implementation uses C-style arrays or casts.
- When a header file contains `using namespace std;`.
- When a developer asks how to modernize an existing C++ codebase.

<!-- synapsis-dsai-managed -->
