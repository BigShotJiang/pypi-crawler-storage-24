
<!-- synapsis-dsai-core-start -->
<!-- ⛔ JANGAN EDIT BLOK INI SECARA MANUAL. AKAN TERUPDATE OTOMATIS OLEH dsai-synapsis-agent-init -->
## 💠 Synapsis DSAI Core Rules
You are an agent working within the Synapsis DSAI ecosystem. 
**CRITICAL:** You MUST read and adhere to the following directory-based rules and skills:

1. **Core Trajectories:** Refer to `.agent/rules/main-rules.md` for project lifecycle, feature development, and bugfix workflows.
2. **Technical Standards:** Refer to `.agent/skills/` for specific standards (API design, TDD, SOLID, etc.).
3. **Platform Context:** Refer to `.cursor/rules/` or `.github/copilot-instructions.md` if using those tools.
4. **Git Policy:** Follow Conventional Commits and branch naming standards as defined in `main-rules.md`.

*Last Updated: 2026-03-05*
<!-- synapsis-dsai-core-end -->
