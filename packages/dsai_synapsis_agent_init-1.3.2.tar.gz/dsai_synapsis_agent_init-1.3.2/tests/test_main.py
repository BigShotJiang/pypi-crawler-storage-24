"""
Refactored test cases for the main initialization module.
"""

import shutil
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest
from dsai_synapsis_agent_init.main import run, TOOL_MAPPING

class TestTemplateInitialization:
    """Test suite for template initialization logic."""

    def test_tool_mapping_defined(self):
        """Test that TOOL_MAPPING contains expected data."""
        assert isinstance(TOOL_MAPPING, dict)
        assert "1" in TOOL_MAPPING
        assert TOOL_MAPPING["1"]["name"] == "Gemini CLI"

    def test_run_function_exists_and_callable(self):
        """Test that run function is properly defined and callable."""
        assert callable(run)

    @patch("dsai_synapsis_agent_init.main.files")
    @patch("dsai_synapsis_agent_init.main.Path.cwd")
    @patch("builtins.print")
    def test_run_prints_startup_message(self, mock_print, mock_cwd, mock_files):
        """Test that run() prints the startup message."""
        mock_cwd.return_value = Path("/tmp/work")
        mock_pkg = MagicMock()
        mock_files.return_value = mock_pkg

        # Use --all to skip interactive prompts
        with patch.object(sys, 'argv', ['prog', '--all']):
            run()
            
        calls = [str(call) for call in mock_print.call_args_list]
        assert any("🚀" in c for c in calls)

class TestDocumentation:
    """Test suite for code documentation."""

    def test_main_module_has_docstring(self):
        """Test that main module is properly documented."""
        from dsai_synapsis_agent_init import main
        assert main.__doc__ is not None
        assert len(main.__doc__) > 0

    def test_run_function_has_docstring(self):
        """Test that run() function has documentation."""
        from dsai_synapsis_agent_init.main import run
        assert run.__doc__ is not None

class TestErrorHandling:
    """Test suite for error handling and edge cases."""

    @patch("dsai_synapsis_agent_init.main.files")
    @patch("dsai_synapsis_agent_init.main.Path.cwd")
    @patch("builtins.print")
    def test_git_warning_if_no_git_dir(self, mock_print, mock_cwd, mock_files):
        """Test that a warning is printed if .git directory is not found."""
        temp_dir = Path("/tmp/work")
        mock_cwd.return_value = temp_dir
        mock_pkg = MagicMock()
        mock_files.return_value = mock_pkg
        
        with patch.object(sys, 'argv', ['prog', '--all']):
            run()
        
        calls = [str(call) for call in mock_print.call_args_list]
        assert any("⚠️  Direktori .git tidak ditemukan" in c for c in calls)

    @patch("dsai_synapsis_agent_init.main.files")
    def test_missing_package_resources_handled(self, mock_files):
        """Test that missing package resources are handled gracefully."""
        mock_files.side_effect = Exception("Package resources not found")

        with patch("builtins.print"):
            with patch("sys.exit") as mock_exit:
                with patch.object(sys, 'argv', ['prog', '--all']):
                    run()
                mock_exit.assert_called()
