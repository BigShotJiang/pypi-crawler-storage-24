import sys
import importlib
from pathlib import Path
from unittest.mock import patch, MagicMock
import dsai_synapsis_agent_init.main

class TestInteractiveCLI:
    """Tests for the Interactive CLI selection logic with language support."""

    @patch("dsai_synapsis_agent_init.main._get_template_path")
    @patch("dsai_synapsis_agent_init.main.Path.cwd")
    @patch("builtins.input")
    def test_initializes_selected_tool_and_language(self, mock_input, mock_cwd, mock_get_template, tmp_path):
        """Test: User selects Gemini and Python -> Correct folders and skills created."""
        from dsai_synapsis_agent_init.main import run, TOOL_MAPPING, LANGUAGE_MAPPING
        
        # Setup mock environment
        target_dir = tmp_path / "work"
        target_dir.mkdir()
        mock_cwd.return_value = target_dir
        
        # Mock templates in package
        source_dir = tmp_path / "templates"
        source_dir.mkdir()
        (source_dir / ".agent").mkdir()
        (source_dir / ".agent" / "rules").mkdir()
        (source_dir / ".agent" / "rules" / "main-rules.md").write_text("rules content")
        
        (source_dir / "core").mkdir()
        (source_dir / "core" / "common-skill").mkdir()
        (source_dir / "core" / "common-skill" / "SKILL.md").write_text("common skill")
        
        (source_dir / "languages").mkdir()
        (source_dir / "languages" / "python").mkdir()
        (source_dir / "languages" / "python" / "python-skill").mkdir()
        (source_dir / "languages" / "python" / "python-skill" / "SKILL.md").write_text("python skill")
        
        (source_dir / "languages" / "rust").mkdir()
        (source_dir / "languages" / "rust" / "rust-skill").mkdir()
        (source_dir / "languages" / "rust" / "rust-skill" / "SKILL.md").write_text("rust skill")
        
        (source_dir / "domains").mkdir()
        (source_dir / "standalone").mkdir()
        (source_dir / "standalone" / "core-rules-block.md").write_text("block")
        
        mock_get_template.return_value = source_dir

        # Simulate user selecting 'Gemini' (option 1) and 'Python' (option 1)
        mock_input.side_effect = ["1", "1"]

        # Run in interactive mode
        with patch.object(sys, 'argv', ['prog']):
            run()
            
        # Verify .agent exists
        assert (target_dir / ".agent").exists()
        assert (target_dir / ".agent" / "rules" / "main-rules.md").exists()
        
        # Verify skills exist
        assert (target_dir / ".agent" / "skills" / "common-skill").exists()
        assert (target_dir / ".agent" / "skills" / "python-skill").exists()
        
        # Verify Rust skill does NOT exist
        assert not (target_dir / ".agent" / "skills" / "rust-skill").exists()
        
        # Verify standalone file
        assert (target_dir / "GEMINI.md").exists()

    @patch("dsai_synapsis_agent_init.main._get_template_path")
    @patch("dsai_synapsis_agent_init.main.Path.cwd")
    @patch("builtins.input")
    def test_initializes_multiple_languages(self, mock_input, mock_cwd, mock_get_template, tmp_path):
        """Test: User selects multiple languages -> All corresponding skills created."""
        from dsai_synapsis_agent_init.main import run
        
        target_dir = tmp_path / "work_multi"
        target_dir.mkdir()
        mock_cwd.return_value = target_dir
        
        source_dir = tmp_path / "templates_multi"
        source_dir.mkdir()
        (source_dir / ".agent").mkdir()
        (source_dir / "core").mkdir()
        (source_dir / "languages").mkdir()
        (source_dir / "languages" / "python").mkdir()
        (source_dir / "languages" / "python" / "py-skill").mkdir()
        (source_dir / "languages" / "python" / "py-skill" / "SKILL.md").write_text("py")
        (source_dir / "languages" / "rust").mkdir()
        (source_dir / "languages" / "rust" / "rs-skill").mkdir()
        (source_dir / "languages" / "rust" / "rs-skill" / "SKILL.md").write_text("rs")
        (source_dir / "domains").mkdir()
        (source_dir / "standalone").mkdir()
        (source_dir / "standalone" / "core-rules-block.md").write_text("block")
        
        mock_get_template.return_value = source_dir

        # Select Gemini (1) and Python + Rust (1,2)
        mock_input.side_effect = ["1", "1,2"]

        with patch.object(sys, 'argv', ['prog']):
            run()
            
        assert (target_dir / ".agent" / "skills" / "py-skill").exists()
        assert (target_dir / ".agent" / "skills" / "rs-skill").exists()
