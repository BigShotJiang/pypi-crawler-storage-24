"""
Test suite for dsai-synapsis-agent-init tool.

This module contains tests for the agent initialization functionality,
including template copying and CLI behavior validation.
"""
