# mng-pair

This package has been renamed to [imbue-mngr-pair](https://pypi.org/project/imbue-mngr-pair/).

Install the new package:

```
pip install imbue-mngr-pair
```
