"""
Remove Ontology Class tool for the AGS SPARQL Agent.

This tool handles remove ontology class operations.
"""

import os
import sys
from datetime import datetime

# Add src directory to path for imports
src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from utils.agent_utils import get_agent, get_graphmart_uri


async def remove_ontology_class(
    ontology_uri: str,
    class_uri: str,
    explanation: str = None,
    dry_run: bool = False
    ) -> str:
    """Remove a class from an ontology.
    
    This tool removes an OWL class and all its metadata from an ontology.
    
    Args:
        ontology_uri: URI of the ontology to remove the class from (required)
        class_uri: URI of the class to remove (required)
        explanation: Human-readable description of the operation
        dry_run: If true, validate inputs without executing
        
    Returns:
        JSON response with class removal results
    """
    BaseToolMixin.validate_required_param(ontology_uri, "ontology_uri")
    BaseToolMixin.validate_required_param(class_uri, "class_uri")
    BaseToolMixin.validate_uri(ontology_uri, "ontology_uri")
    BaseToolMixin.validate_uri(class_uri, "class_uri")
    
    agent = await get_agent()
    
    # Check if class exists
    class_exists_query = f"SELECT ?type WHERE {{ GRAPH <{ontology_uri}> {{ <{class_uri}> a ?type . FILTER(?type = <http://www.w3.org/2002/07/owl#Class>) }} }}"
    class_exists_result = agent.anzo_client.query_journal(class_exists_query)
    table_results = class_exists_result.as_table_results().as_list()
    class_exists = len(table_results) > 0
    
    if not class_exists:
        return BaseToolMixin.create_success_response({
            "ontology_uri": ontology_uri,
            "class_uri": class_uri,
            "not_found": True,
            "explanation": explanation
        }, f"Class '{class_uri}' does not exist in ontology '{ontology_uri}'")
    
    # Dry run mode
    if dry_run:
        return BaseToolMixin.create_success_response({
            "dry_run": True,
            "ontology_uri": ontology_uri,
            "class_uri": class_uri,
            "explanation": explanation
        }, "Class removal validated. Set dry_run=false to execute.")
    
    # Get current timestamp for metadata
    current_timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
    
    # Remove the class and all its properties
    remove_class_sparql = f"""
    PREFIX owl: <http://www.w3.org/2002/07/owl#>
    PREFIX dct: <http://purl.org/dc/terms/>
    
    DELETE {{
        GRAPH <{ontology_uri}> {{
            <{class_uri}> ?p ?o .
            ?s ?p2 <{class_uri}> .
        }}
    }}
    INSERT {{
        GRAPH <{ontology_uri}> {{
            <{ontology_uri}> dct:modified "{current_timestamp}" ;
                            dct:modifier <http://openanzo.org/system/internal/sysadmin> .
        }}
    }}
    WHERE {{
        GRAPH <{ontology_uri}> {{
            {{
                <{class_uri}> ?p ?o .
            }} UNION {{
                ?s ?p2 <{class_uri}> .
            }}
        }}
    }}
    """
    
    # Execute the class removal
    agent.anzo_client.update_journal(remove_class_sparql)
    
    return BaseToolMixin.create_success_response({
        "ontology_uri": ontology_uri,
        "class_uri": class_uri,
        "removed_timestamp": current_timestamp,
        "explanation": explanation
    }, f"Successfully removed class '{class_uri}' from ontology '{ontology_uri}'")