"""
Get Ontology Cache Status tool for the AGS SPARQL Agent.

This tool handles get ontology cache status operations.
"""

import os
import sys
from datetime import datetime

# Add src directory to path for imports
src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from utils.agent_utils import get_agent, get_graphmart_uri
from ontology_cache import OntologyCacheManager


async def get_ontology_cache_status() -> str:
    """Get information about ontology caches.
    
    This tool provides status information about the ontology cache system
    including cache entries, sizes, and last update times.
    
    Returns:
        JSON response with cache status information
    """
    from ontology_cache import OntologyCacheManager
    
    cache_manager = OntologyCacheManager()
    cache_info = cache_manager.get_cache_info()
    
    return BaseToolMixin.create_success_response({
        "cache_info": cache_info
    })