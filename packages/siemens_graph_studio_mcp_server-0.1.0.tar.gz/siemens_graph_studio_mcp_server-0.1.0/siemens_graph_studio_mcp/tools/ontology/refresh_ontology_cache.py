"""
Refresh Ontology Cache tool for the AGS SPARQL Agent.

This tool handles refresh ontology cache operations.
"""

import os
import sys
from datetime import datetime

# Add src directory to path for imports
src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from utils.agent_utils import get_agent, get_graphmart_uri


async def refresh_ontology_cache() -> str:
    """Force refresh of ontology cache by re-discovering from graphmart.
    
    This tool forces a complete refresh of the ontology cache by re-discovering
    all ontology information from the graphmart.
    
    Returns:
        JSON response with refresh results and discovery statistics
    """
    agent = await get_agent()
    success = await agent.refresh_ontology_cache()
    
    if success:
        class_count = len(agent.ontology_info.classes) if agent.ontology_info else 0
        property_count = len(agent.ontology_info.properties) if agent.ontology_info else 0
        
        return BaseToolMixin.create_success_response({
            "classes_discovered": class_count,
            "properties_discovered": property_count,
            "graphmart_uri": agent.config.graphmart_uri,
            "cache_refreshed": True
        }, "Ontology cache refreshed successfully")
    else:
        return BaseToolMixin.create_error_response(
            "Failed to refresh ontology cache",
            suggestions=["Check graphmart connectivity", "Verify permissions"]
        )