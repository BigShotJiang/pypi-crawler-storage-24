"""
Knowledge overview discovery tool for the AGS SPARQL Agent.

This tool provides high-level summaries of the graphmart's knowledge
including domain information, key classes, properties, and sample questions.
"""

import os
import sys

# Add src directory to path for imports
src_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from tools.base_tool import BaseToolMixin, handle_tool_errors, ToolError
from utils.agent_utils import get_agent


@handle_tool_errors
async def discover_knowledge_overview(focus: str = "overview") -> str:
    """Get an overview of what's available in the knowledge graph.
    
    This tool provides a high-level summary of the graphmart's knowledge
    including domain information, key classes, properties, and sample questions.
    
    Args:
        focus: What to focus on - "overview", "classes", "properties", or "examples"
        
    Returns:
        JSON response with knowledge graph overview and statistics
    """
    agent = await get_agent()
    result = await agent.explore_knowledge(focus)
    
    # Use the new populated summary method if available
    populated_summary = ""
    if hasattr(agent.ontology_info, 'get_populated_summary'):
        populated_summary = agent.ontology_info.get_populated_summary()
    
    return BaseToolMixin.create_success_response({
        "domain_summary": result.domain_summary,
        "populated_summary": populated_summary,
        "key_classes": result.key_classes,
        "key_properties": result.key_properties,
        "sample_questions": result.sample_questions,
        "total_classes": result.total_classes,
        "total_properties": result.total_properties,
        "focus_area": focus
    })