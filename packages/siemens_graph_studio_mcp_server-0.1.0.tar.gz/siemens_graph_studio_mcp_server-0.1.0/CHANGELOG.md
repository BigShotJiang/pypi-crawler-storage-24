# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-10

### Added
- Initial public release
- MCP server implementation for Siemens Graph Studio
- SPARQL query execution tools
- Knowledge discovery tools (ontologies, classes, properties)
- Ontology management tools (create, delete, modify)
- GraphMart transformation layer management
- Support for multiple MCP transports (stdio, SSE, HTTP)
- Configuration via environment variables or JSON config files
- OpenAI integration for natural language to SPARQL translation
- Ontology caching for improved performance
- Claude Desktop integration support
- Comprehensive documentation and examples

### Security
- No hardcoded credentials - all configuration via environment variables or config files
- Sensitive values masked in log output
- Apache 2.0 license

## [Unreleased]

### Planned
- Additional query optimization features
- Enhanced error handling and retry logic
- Support for federated queries
- Performance monitoring tools
- Integration with additional AI providers
