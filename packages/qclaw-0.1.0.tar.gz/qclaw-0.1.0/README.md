# r

`r` is a tiny command line tool that opens a URL in your default browser.

## Install

```bash
pip install .
```

## Usage

```bash
r https://www.baidu.com
```

If the URL has no scheme, `https://` is added automatically.