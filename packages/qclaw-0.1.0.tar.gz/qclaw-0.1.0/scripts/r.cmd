@echo off
setlocal

if exist "%~dp0python.exe" (
    "%~dp0python.exe" -m r %*
    exit /b %errorlevel%
)

if exist "%~dp0..\python.exe" (
    "%~dp0..\python.exe" -m r %*
    exit /b %errorlevel%
)

python -m r %*
exit /b %errorlevel%