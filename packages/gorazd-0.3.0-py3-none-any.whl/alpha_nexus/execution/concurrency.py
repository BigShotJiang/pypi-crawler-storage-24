import ctypes
from multiprocessing import shared_memory
import numpy as np

class SPSCStruct(ctypes.Structure):
    _fields_ = [
        ("write_idx", ctypes.c_uint64),
        ("_pad0", ctypes.c_uint8 * 56),
        ("read_idx", ctypes.c_uint64),
        ("_pad1", ctypes.c_uint8 * 56),
        ("data", ctypes.c_float * 1024) 
    ]

class SPSCRingBuffer:
    def __init__(self, name="alpha_nexus_ipc", create=True):
        self.name = name
        self.size = ctypes.sizeof(SPSCStruct)
        self.capacity = 1024
        self._mask = self.capacity - 1
        
        if create:
            try:
                self.shm = shared_memory.SharedMemory(name=self.name, create=True, size=self.size)
            except FileExistsError:
                self.shm = shared_memory.SharedMemory(name=self.name, create=False)
        else:
            self.shm = shared_memory.SharedMemory(name=self.name, create=False)
            
        self.struct = SPSCStruct.from_buffer(self.shm.buf)
        
        if create:
            self.struct.write_idx = 0
            self.struct.read_idx = 0

    def push_lockfree(self, value: float) -> bool:
        next_write = (self.struct.write_idx + 1) & self._mask
        if next_write == (self.struct.read_idx & self._mask):
            return False 
        self.struct.data[self.struct.write_idx & self._mask] = value
        self.struct.write_idx = next_write
        return True

    def pop_lockfree(self) -> float:
        if self.struct.read_idx == self.struct.write_idx:
            return -1.0 
        val = self.struct.data[self.struct.read_idx & self._mask]
        self.struct.read_idx = (self.struct.read_idx + 1) & self._mask
        return val
        
    def close(self):
        # [!] TACTICAL COUNTERMEASURE: Destroy the C-pointer before releasing RAM
        del self.struct 
        self.shm.close()
        try:
            self.shm.unlink()
        except FileNotFoundError:
            pass
