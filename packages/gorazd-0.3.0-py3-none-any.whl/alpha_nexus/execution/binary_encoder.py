# src/alpha_nexus/execution/binary_encoder.py
import struct

class BOEEncoder:
    """
    Absolute Binary Order Entry (BOE) Matrix.
    Eradicates string-based FIX protocols. Pre-compiles the static byte-array 
    at daemon initialization and overwrites only the dynamic bytes at execution.
    """
    def __init__(self, token: bytes, symbol: bytes, side: bytes):
        # Struct Format: 4s(Type) 8s(Token) 8s(Symbol) 1s(Side) Q(Qty) d(Price)
        # Total packed size = 37 bytes. We pad to exactly 64 bytes for network efficiency.
        self.struct_format = "!4s8s8scQd27x"
        self.buffer = bytearray(64)
        
        print(f"[+] BINARY ENCODER: Compiling static C-struct for {symbol.decode().strip()}...")
        
        # Pre-pack the static fields into the bytearray ONCE.
        struct.pack_into("!4s8s8sc", self.buffer, 0, b'ORD ', token, symbol, side)
        
        # The offset for Qty and Price begins exactly at byte 21
        self.dynamic_offset = 21

    def mutate_and_dispatch(self, qty: int, price: float) -> memoryview:
        """
        Zero-Allocation Network Dispatch.
        Mechanically overwrites ONLY the 16 bytes representing Qty (uint64) and Price (double).
        """
        # Overwrite the memory in-place
        struct.pack_into("!Qd", self.buffer, self.dynamic_offset, qty, price)
        
        # Return a zero-copy memory view of the raw binary payload ready for the TCP socket
        return memoryview(self.buffer)