# src/alpha_nexus/execution/memory_pool.py
import numpy as np

class StaticMemoryPool:
    """
    Absolute Zero-Allocation Ring Buffer.
    Pre-allocates a monolithic C-contiguous tensor at boot. Mutates strictly 
    in-place via bitwise modulo, permanently eliminating malloc syscalls and GC pauses.
    """
    def __init__(self, capacity: int = 65536, feature_dim: int = 9):
        # Capacity MUST be a power of 2 for bitwise modulo to function
        if (capacity & (capacity - 1)) != 0:
            raise ValueError("[-] FATAL: Capacity must be an exact power of 2 (e.g., 4096, 65536).")
            
        self.capacity = capacity
        self.feature_dim = feature_dim
        self._mask = capacity - 1
        
        print(f"[+] MEMORY POOL: Pre-allocating {capacity}x{feature_dim} monolithic C-tensor...")
        # Allocate once. Never allocate again.
        self.matrix = np.zeros((capacity, feature_dim), dtype=np.float32)
        self.write_ptr = 0

    def get_next_view(self) -> np.ndarray:
        """
        Calculates the memory address using ultra-fast bitwise math and 
        returns a zero-copy pointer to the specific pre-allocated row.
        """
        # Bitwise AND instead of modulo (e.g., write_ptr & 65535)
        idx = self.write_ptr & self._mask
        self.write_ptr += 1
        
        # Return an in-place memory view, NOT a new array
        return self.matrix[idx, :]