import os
import math
import numpy as np
from alpha_nexus.execution.binary_encoder import BOEEncoder
from alpha_nexus.execution.telemetry import TelemetryPublisher

class ExecutionNode:
    def __init__(self, spsc_queue, base_capital: float = 250000.0, max_leverage: float = 1.5, shadow_mode: bool = True):
        self.base_capital = base_capital
        self.current_capital = base_capital
        self.max_leverage = max_leverage
        self.spsc_queue = spsc_queue
        self.shadow_mode = shadow_mode
        
        self.current_holding_prob = 0.5 
        self.current_position_qty = 0
        self.entry_price = 0.0
        
        self.encoder_long = BOEEncoder(b'TOKEN123', b'SPY     ', b'B')
        self.encoder_short = BOEEncoder(b'TOKEN124', b'SPY     ', b'S')
        
        self.telemetry = TelemetryPublisher()
        
        mode_str = "SHADOW (DIAGNOSTIC)" if self.shadow_mode else "LIVE (CAPITAL AT RISK)"
        print(f"[+] EXECUTION NODE: {mode_str} Locked. Capital: $250,000")

    def _calculate_fractional_kelly(self, prob: float) -> float:
        p_win = 1.0 - prob if prob < 0.5 else prob
        kelly_pct = p_win - ((1.0 - p_win) / 1.0)
        return max(0.0, kelly_pct * 0.25)

    def poll_and_execute(self, current_price: float, volatility: float = 0.15):
        probability = self.spsc_queue.pop_lockfree()
        
        if probability != -1.0: 
            state_delta = abs(probability - self.current_holding_prob)
            
            if state_delta > 0.05: 
                action_str = "HOLD"
                is_bps = 0.0
                
                if self.current_position_qty != 0:
                    slippage = np.random.uniform(0.01, 0.03) if self.current_position_qty > 0 else np.random.uniform(-0.03, -0.01)
                    fill_price = current_price - slippage
                    realized_pnl = (fill_price - self.entry_price) * self.current_position_qty
                    self.current_capital += realized_pnl
                    
                    is_bps = (abs(current_price - fill_price) / current_price) * 10000
                    action_str = f"CLOSED PnL: ${realized_pnl:.2f}"

                kelly_fraction = self._calculate_fractional_kelly(probability)
                vol_scalar = 0.10 / max(volatility, 0.01) 
                target_exposure = min(kelly_fraction * vol_scalar * self.max_leverage, self.max_leverage) 
                
                final_alloc = self.current_capital * target_exposure
                qty = int(final_alloc / current_price)
                if probability < 0.5: qty = -qty 
                
                if abs(qty) > 0:
                    if action_str == "HOLD":
                        action_str = f"EXEC {qty} @ ${current_price:.2f}"
                    self.current_holding_prob = probability
                    self.current_position_qty = qty
                    self.entry_price = current_price
                
                self.telemetry.broadcast_state(current_price, probability, self.current_capital, action_str, is_bps)
