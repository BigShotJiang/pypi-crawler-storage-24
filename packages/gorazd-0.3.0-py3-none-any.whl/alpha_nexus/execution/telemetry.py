import zmq
import json

class TelemetryPublisher:
    """
    Absolute ZeroMQ Broadcast Matrix.
    Fires asynchronous, non-blocking telemetry payloads over TCP 
    to decouple logging latency from the execution core.
    """
    def __init__(self, port: int = 5555):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.bind(f"tcp://127.0.0.1:{port}")
        print(f"[+] TELEMETRY: ZeroMQ Publisher bound to Port {port}.")

    def broadcast_state(self, current_price: float, prob: float, capital: float, action: str, shortfall: float = 0.0):
        payload = {
            "price": round(current_price, 2),
            "probability": round(prob, 4),
            "capital": round(capital, 2),
            "action": action,
            "shortfall_bps": round(shortfall, 2)
        }
        # Fire and forget. Zero execution blocking.
        self.socket.send_string(f"GORAZD_METRICS {json.dumps(payload)}")
