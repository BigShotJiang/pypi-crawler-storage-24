# src/alpha_nexus/math/core.py
import numpy as np
from numba import njit, float64, float32, void

# Notice the return type is now 'void' and we strictly pass a float32[:] output buffer
@njit(
    void(float64, float64, float64[:], float64[:], float64[:], float64[:], float64, float64, float64, float64, float64, float32[:]),
    nogil=True, 
    fastmath=True,
    cache=True
)
def compute_institutional_features_inplace(
    t0_target: float, t1_target: float, 
    t0_macros: np.ndarray, t1_macros: np.ndarray, 
    t0_megas: np.ndarray, t1_megas: np.ndarray, 
    vix_t0: float, vix_t1: float, 
    vix3m_t0: float, vix6m_t0: float, 
    t1_vol: float,
    out_view: np.ndarray  # MUTATED IN-PLACE
):
    """
    Zero-Allocation Hardware Physics.
    Writes predictive features directly into the physical RAM address of the StaticMemoryPool.
    """
    num_macros = t0_macros.shape[0]
    num_megas = t0_megas.shape[0]
    
    t_ret = np.log((t0_target + 1e-8) / (t1_target + 1e-8))
    out_view[0] = t_ret
    
    for i in range(num_macros):
        out_view[1 + i] = np.log((t0_macros[i] + 1e-8) / (t1_macros[i] + 1e-8))
        
    mega_sum = 0.0
    for i in range(num_megas):
        mega_sum += np.log((t0_megas[i] + 1e-8) / (t1_megas[i] + 1e-8))
    out_view[1 + num_macros] = mega_sum / num_megas
    
    out_view[1 + num_macros + 1] = vix_t0 - vix_t1
    out_view[1 + num_macros + 2] = vix_t0 - vix3m_t0 
    
    idx = 1 + num_macros + 3
    for i in range(num_macros):
        out_view[idx + i] = t_ret - out_view[1 + i]
        
    out_view[-1] = t1_vol