# src/alpha_nexus/math/core.pyi
import numpy as np

def compute_institutional_features(
    t0_target: float, 
    t1_target: float, 
    t0_macros: np.ndarray, 
    t1_macros: np.ndarray, 
    t0_megas: np.ndarray, 
    t1_megas: np.ndarray, 
    vix_t0: float, 
    vix_t1: float, 
    vix3m_t0: float, 
    vix6m_t0: float, 
    t1_vol: float
) -> np.ndarray: ...