# src/alpha_nexus/math/compiler.py
import numpy as np
import time
from alpha_nexus.math.core import compute_institutional_features_inplace

def execute_aot_build():
    print("="*65)
    print("    [+] COMPILER: Forcing Zero-Allocation AOT Generation")
    print("="*65)
    
    start_time = time.perf_counter()
    
    # Pre-allocate the memory view exactly as it will happen in live trading
    dummy_out = np.zeros(9, dtype=np.float32)
    
    # Trigger the compiler using the in-place memory pointer
    compute_institutional_features_inplace(
        510.0, 509.0, 
        np.array([1.0, 2.0], dtype=np.float64), 
        np.array([1.0, 2.0], dtype=np.float64), 
        np.array([1.0, 2.0, 3.0], dtype=np.float64), 
        np.array([1.0, 2.0, 3.0], dtype=np.float64), 
        14.0, 14.5, 15.0, 16.0, 0.12,
        dummy_out
    )
    
    duration = (time.perf_counter() - start_time) * 1000
    print(f"[+] COMPILER: In-Place Matrix baked into native cache in {duration:.2f}ms.")

if __name__ == "__main__":
    execute_aot_build()