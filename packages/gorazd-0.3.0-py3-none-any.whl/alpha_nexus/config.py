# src/alpha_nexus/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class InstitutionalConfig(BaseSettings):
    """
    Absolute Configuration Matrix.
    Violently crashes the interpreter on import if the server environment is compromised.
    """
    # Microstructure & Data Routing
    bbg_host: str = Field(default="localhost")
    bbg_port: int = Field(default=8194)
    alpaca_api_key: str = Field(default="")
    alpaca_api_secret: str = Field(default="")
    tiingo_api_key: str = Field(default="")
    
    # Execution Risk Limits (STRICTLY REQUIRED)
    base_capital: float = Field(...) 
    max_position_size: float = Field(default=0.15)
    
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

# Instantiate instantly to trigger the validation check the millisecond the library loads
settings = InstitutionalConfig()