import polars as pl
import numpy as np
from pathlib import Path
import os
from alpha_nexus.data.gateway import DataGateway
from alpha_nexus.data.storage import ParquetVault

class HistoricalFeedGenerator:
    """
    Absolute Historical Data Compiler.
    Transforms raw Tiingo/Alpaca JSON into a strictly 9-dimensional 
    C-contiguous Parquet matrix ready for the Bayesian Engine.
    """
    def __init__(self, target_ticker="SPY"):
        self.gateway = DataGateway()
        self.vault = ParquetVault()
        self.target = target_ticker
        self.assets = [target_ticker, 'QQQ', 'TLT', 'GLD']
        self.macro = '^VIX'

    def compile_training_matrix(self, start_date="2016-01-01"):
        print("="*70)
        print(f" [+] COMPILER: Extracting Physical Reality Matrix for {self.target}")
        print("="*70)

        raw_lfs = [self.gateway.fetch_tiingo_daily_lazy(a, start_date) for a in self.assets]
        vix_lf = self.gateway.fetch_fred_vix_lazy()
        vwap_lf = self.gateway.fetch_alpaca_sip_vwap(self.assets, start_date)

        # 1. Join Price Matrices
        price_matrix = raw_lfs[0]
        for i in range(1, len(raw_lfs)):
            price_matrix = price_matrix.join(raw_lfs[i], on='Date', how='full', coalesce=True)
            
        price_matrix = price_matrix.join(vwap_lf, on='Date', how='left')
        price_matrix = price_matrix.sort('Date').join_asof(vix_lf, on='Date', strategy='backward')

        # 2. Strict Mathematical Parity (Backward Dividend/Split Scaling)
        adj_exprs = []
        for a in self.assets:
            split_f = pl.col(f'{a}_Split').fill_null(1.0)
            div_f = pl.max_horizontal(1.0 - (pl.col(f'{a}_Div').fill_null(0.0) / (pl.col(a).shift(1) / split_f)).fill_nan(0.0), 0.0001)
            
            split_mult = split_f.shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            div_mult = div_f.shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            
            adj_exprs.extend([
                ((pl.col(a) / split_mult) * div_mult).alias(a),
                ((pl.col(f'{a}_VWAP').fill_null(pl.col(a)) / split_mult) * div_mult).alias(f'{a}_VWAP'),
                (pl.col(f'{a}_Volume') * split_mult).alias(f'{a}_Volume')
            ])
            
        final_lf = price_matrix.with_columns(adj_exprs)

        # 3. Extract the 9 Specific Features for the AOT C-Compiler
        # F1: SPY_Ret, F2: QQQ_Ret, F3: TLT_Ret, F4: GLD_Ret
        # F5: SPY_VWAP_Ret, F6: SPY_Vol_14d, F7: SPY_QQQ_Spread, F8: SPY_TLT_Spread, F9: VIX_Diff
        
        feat_exprs = [(pl.col(a).log() - pl.col(a).shift(1).log()).alias(f"{a}_LogRet") for a in self.assets]
        feat_exprs.append((pl.col(f"{self.target}_VWAP") / pl.col(self.target).shift(1)).log().alias("VWAP_LogRet"))
        feat_exprs.append((pl.col(self.macro) - pl.col(self.macro).shift(2)).alias("VIX_Diff"))
        
        final_lf = final_lf.with_columns(feat_exprs).with_columns([
            (pl.col(f'{self.target}_LogRet').rolling_std(14) * np.sqrt(252)).alias('Vol_14d'),
            (pl.col(f'{self.target}_LogRet') - pl.col('QQQ_LogRet')).alias('Spread_QQQ'),
            (pl.col(f'{self.target}_LogRet') - pl.col('TLT_LogRet')).alias('Spread_TLT'),
            (pl.col(f"{self.target}").shift(-1) > pl.col(f"{self.target}")).cast(pl.Int32).alias('Label'),
            pl.col('Date').cast(pl.Date).cast(pl.Int32).alias('Epoch')
        ])
        
        feature_cols = [
            f"{self.target}_LogRet", "QQQ_LogRet", "TLT_LogRet", "GLD_LogRet",
            "VWAP_LogRet", "Vol_14d", "Spread_QQQ", "Spread_TLT", "VIX_Diff"
        ]
        
        df_final = final_lf.select(feature_cols + ['Label', 'Epoch', f"{self.target}_Volume", f"{self.target}_LogRet", 'Spread_QQQ', 'VIX_Diff']).drop_nulls().collect()
        
        file_path = self.vault.lock_matrix(df_final, f"{self.target}_institutional_matrix.parquet")
        print(f"[+] MATRIX LOCKED: {df_final.height} physical trading days compiled to {file_path.name}.")
        return file_path
