import os
import sys
from alpha_nexus.data.compiler import HistoricalFeedGenerator
from alpha_nexus.ml.trainer import BayesianEmbargoTrainer

def run_compiler():
    # Triggered via 'gorazd-fetch'
    compiler = HistoricalFeedGenerator(target_ticker="SPY", source="tiingo")
    compiler.compile_training_matrix("2020-01-01")

def run_trainer():
    # Triggered via 'gorazd-train'
    trainer = BayesianEmbargoTrainer()
    # It will automatically find the synthetic or real matrix built by the compiler
    target_file = "SPY_institutional_matrix.parquet"
    if not os.path.exists(os.path.join(os.getcwd(), "data_vault", target_file)):
        target_file = "synthetic_fallback.parquet"
        
    trainer.execute_study(target_file, "institutional_core.ubj")

def run_daemon():
    # Triggered via 'gorazd-live'
    print("[!] Use 'python live_daemon.py' for multi-core IPC execution in this environment.")
