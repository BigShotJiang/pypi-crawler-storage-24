# alpha_nexus/Layer_3_Execution/terminal_inference.py
import sys
import time
import os
import psutil
import numpy as np
import xgboost as xgb
import gc
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config
from alpha_nexus.Layer_2_Macro_Matrix.alpha_compiler import AlphaCompiler
from alpha_nexus.Layer_3_Execution.order_gateway import AsyncOrderGateway
from alpha_nexus.Layer_3_Execution.physics_metrics import ExecutionPhysics
from alpha_nexus.Layer_3_Execution.risk_reconciliation import RiskReconciliationDaemon
from alpha_nexus.Layer_2_Macro_Matrix.shared_memory import IPCZeroCopyMatrix
from alpha_nexus.Layer_3_Execution.telemetry_buffer import TelemetryRingBuffer

class TerminalExecutionNode:
    def __init__(self):
        gc.disable()
        self._lock_hardware_affinity(core_id=2)
        
        # TACTICAL COUNTERMEASURE: Ignite the Memory-Mapped Telemetry
        self.telemetry = TelemetryRingBuffer()
        self.telemetry.ignite_daemon()
        
        self.config = load_institutional_config()
        self.model_path = Path("alpha_nexus/models/registry/institutional_core.ubj")
        self.compiler = AlphaCompiler()
        self.gateway = AsyncOrderGateway(self.telemetry)
        self.physics = ExecutionPhysics(base_capital=100000.0)
        
        self.risk_daemon = RiskReconciliationDaemon()
        self.risk_daemon.ignite_daemon()
        
        self.telemetry.log_fast("[+] INITIATING EXECUTION NODE: Loading XGBoost Universal Binary JSON...")
        self.booster = xgb.Booster()
        
        if not self.model_path.exists():
            raise FileNotFoundError("[-] MODEL REGISTRY VOID: Execute optuna_surface.py to forge the institutional core.")
        else:
            self.booster.load_model(str(self.model_path))
            
        self.telemetry.log_fast("[+] EXECUTION NODE SECURED: Awaiting live memory pointer.")

    def _lock_hardware_affinity(self, core_id: int):
        try:
            p = psutil.Process(os.getpid())
            logical_cores = psutil.cpu_count(logical=True)
            target_core = core_id if core_id < logical_cores else (logical_cores - 1)
            p.cpu_affinity([target_core])
            print(f"[+] HARDWARE ISOLATION: Inference matrix permanently locked to CPU Core {target_core}.")
        except Exception as e:
            pass

    def _get_live_bid_ask(self) -> tuple:
        target = self.config.universe.target_asset
        try:
            ipc = IPCZeroCopyMatrix(create=False)
            idx = ipc.ticker_map[target]
            last_price = ipc.read_tensor()[idx]
            if np.isnan(last_price):
                last_price = 510.00
        except RuntimeError:
            last_price = 510.00 
        return last_price - 0.01, last_price + 0.01

    def trigger_live_inference(self):
        try:
            start_ns = time.perf_counter_ns()
            inference_pointer = self.compiler.get_live_inference_pointer()
            raw_probability = self.booster.inplace_predict(inference_pointer)[0]
            end_ns = time.perf_counter_ns()
            
            latency_micros = (end_ns - start_ns) / 1000.0
            signal = "LONG" if raw_probability > 0.5 else "FADE"
            conviction = abs(raw_probability - 0.5) * 200.0 
            
            bid, ask = self._get_live_bid_ask()
            simulated_depth = 50000.0 
            raw_alloc, final_alloc = self.physics.apply_convex_penalty(conviction, simulated_depth)
            
            # TACTICAL COUNTERMEASURE: Absolute Memory Write (Zero I/O)
            log_payload = f"[{self.config.universe.target_asset}] | {signal} | Conviction: {conviction:.2f}% | Latency: {latency_micros:.2f} us | Alloc: ${final_alloc:,.2f}"
            self.telemetry.log_fast(log_payload)
            
            self.gateway.dispatch_signal_nonblocking(
                target=self.config.universe.target_asset,
                signal=signal,
                allocation=final_alloc,
                probability=raw_probability,
                bid=bid,
                ask=ask
            )
            
            self.risk_daemon.update_theoretical_state(final_alloc)
            self.risk_daemon.simulate_broker_fill(final_alloc)
            
        except Exception as e:
            self.telemetry.log_fast(f"[-] EXECUTION HALTED: Fatal pointer exception. {e}")

if __name__ == "__main__":
    execution_node = TerminalExecutionNode()
    execution_node.trigger_live_inference()
    time.sleep(1.5)