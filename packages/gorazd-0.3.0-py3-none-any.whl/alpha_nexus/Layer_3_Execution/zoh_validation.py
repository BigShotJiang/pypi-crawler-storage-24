# alpha_nexus/Layer_3_Execution/zoh_validation.py
import sys
import time
from pathlib import Path

# TACTICAL COUNTERMEASURE: Absolute Path Resolution
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_2_Macro_Matrix.shared_memory import IPCZeroCopyMatrix
from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config

def execute_zoh_validation():
    print("\n[+] INITIATING ZERO-ORDER HOLD (ZOH) VALIDATION SEQUENCE...")
    config = load_institutional_config()
    target = config.universe.target_asset
    macro = [m for m in config.universe.macro_assets if "VIX" in m][0]
    
    # 1. Mount the shared memory block
    ipc = IPCZeroCopyMatrix(create=True)
    
    try:
        # 2. Inject the slow macro tick (VIX)
        print(f"[+] T=0.00ms | Writing slow macro vector ({macro}) to POSIX memory...")
        ipc.write_tick(macro, 24.50)
        
        # 3. Simulate the 50ms structural desynchronization
        print("[-] SYNTHETIC OFFSET: Inducing 50ms structural network delay...")
        time.sleep(0.05)
        
        # 4. Inject the fast primary liquidity tick (SPY)
        print(f"[+] T=50.0ms | Primary target liquidity updates ({target})...")
        ipc.write_tick(target, 510.25)
        
        # 5. Instantly trigger the memory extraction
        start_ns = time.perf_counter_ns()
        zoh_state = ipc.read_zoh_state()
        end_ns = time.perf_counter_ns()
        
        target_idx = ipc.ticker_map[target]
        macro_idx = ipc.ticker_map[macro]
        
        target_time = zoh_state[target_idx, 1]
        macro_time = zoh_state[macro_idx, 1]
        
        # Calculate the absolute temporal gap in milliseconds
        temporal_gap_ms = (target_time - macro_time) / 1_000_000.0
        extraction_latency_us = (end_ns - start_ns) / 1000.0
        
        print("\n" + "="*65)
        print("    [$$$] ZOH LATCH VALIDATION SECURED [$$$]    ")
        print("="*65)
        print(f"Extraction Latency:     {extraction_latency_us:.2f} μs")
        print(f"Primary Tick ({target}):   ${zoh_state[target_idx, 0]:.2f}")
        print(f"Cached Macro ({macro}):     {zoh_state[macro_idx, 0]:.2f}")
        print(f"Asynchronous Gap:       {temporal_gap_ms:.2f} ms")
        print("="*65)
        print(f"[+] ABSOLUTE VICTORY: Matrix ignored the {temporal_gap_ms:.2f}ms offset and extracted the payload in {extraction_latency_us:.2f} microseconds.")
        
    finally:
        ipc.unlink()

if __name__ == "__main__":
    execute_zoh_validation()