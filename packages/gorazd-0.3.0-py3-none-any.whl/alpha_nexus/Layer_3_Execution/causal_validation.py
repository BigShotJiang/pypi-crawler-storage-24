# alpha_nexus/Layer_3_Execution/causal_validation.py
import numpy as np

class PurgedTimeSeriesFold:
    """
    Absolute Time-Series Segregation Matrix.
    Enforces a strict embargo between training and validation sets to permanently 
    eradicate Look-Ahead Bias and overlapping temporal leakage.
    """
    def __init__(self, n_splits: int = 5, embargo_pct: float = 0.05):
        self.n_splits = n_splits
        self.embargo_pct = embargo_pct

    def split(self, X):
        n_samples = len(X)
        if n_samples < self.n_splits:
            raise ValueError("[-] INSUFFICIENT DATA: Cannot execute causal split on limited timeframe.")

        # Calculate embargo size (e.g., 5% of data is purged between train and test)
        embargo_size = int(n_samples * self.embargo_pct)
        indices = np.arange(n_samples)
        
        # Calculate the size of each test block
        test_size = (n_samples - embargo_size) // self.n_splits
        
        for i in range(self.n_splits):
            # Test block slides forward in time
            test_start = n_samples - (self.n_splits - i) * test_size
            test_end = test_start + test_size
            
            # Train block is everything BEFORE the embargo zone
            train_end = test_start - embargo_size
            
            if train_end <= 0:
                continue
                
            train_indices = indices[:train_end]
            test_indices = indices[test_start:test_end]
            
            yield train_indices, test_indices