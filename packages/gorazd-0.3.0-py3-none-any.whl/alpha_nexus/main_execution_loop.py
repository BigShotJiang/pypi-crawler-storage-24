# alpha_nexus/main_execution_loop.py
import sys
import time
import subprocess
import threading
from pathlib import Path

# TACTICAL COUNTERMEASURE: Absolute Path Resolution
sys.path.append(str(Path(__file__).resolve().parent.parent))

from alpha_nexus.Layer_3_Execution.terminal_inference import TerminalExecutionNode

class MasterExecutionOrchestrator:
    """
    The Absolute Apex Matrix.
    Ignites the Layer 1 zero-copy C++ event stream in a background thread, 
    binds Layer 3 to the POSIX shared memory, and executes perpetual, 
    nanosecond-latency capital allocation inference.
    """
    def __init__(self):
        self.stream_process = None
        
    def _ignite_background_stream(self):
        """Spins up the Bloomberg bpipe stream as an isolated background process."""
        print("[+] MASTER NODE: Igniting Layer 1 bpipe_event_stream as daemon...")
        stream_path = Path("alpha_nexus/Layer_1_Ingestion/bpipe_event_stream.py")
        
        # Subprocess physically isolates the network stream from the prediction thread
        self.stream_process = subprocess.Popen(
            [sys.executable, str(stream_path)],
            stdout=subprocess.DEVNULL, # Mute the stream output so it doesn't flood the terminal
            stderr=subprocess.DEVNULL
        )
        
        # Wait 3 seconds to guarantee Windows OS has mapped the POSIX shared memory block
        print("[+] MASTER NODE: Waiting for OS POSIX Memory allocation...")
        time.sleep(3)

    def engage_perpetual_execution(self):
        print("\n" + "="*65)
        print("    [$$$] INITIATING ABSOLUTE INSTITUTIONAL EXECUTION [$$$]    ")
        print("="*65 + "\n")
        
        try:
            # 1. Forge the physical data pipeline
            self._ignite_background_stream()
            
            # 2. Instantiate the Execution Node (Will lock onto the newly created POSIX block)
            inference_node = TerminalExecutionNode()
            
            print("\n[+] APEX PREDATOR ONLINE: Locking into high-frequency inference loop. (Press Ctrl+C to abort)")
            
            # 3. The Perpetual Execution Matrix
            while True:
                # Fire the physical prediction sequence
                inference_node.trigger_live_inference()
                
                # TACTICAL THROTTLE:
                # In a live high-frequency environment, you would run this unthrottled.
                # For this validation loop, we sleep for 5 seconds to prevent your terminal from exploding.
                time.sleep(5.0)
                
        except KeyboardInterrupt:
            print("\n[!] OPERATOR INTERRUPT: Weapon system powering down.")
        finally:
            if self.stream_process:
                print("[+] MASTER NODE: Terminating bpipe_event_stream background daemon...")
                self.stream_process.terminate()
                self.stream_process.wait()

if __name__ == "__main__":
    orchestrator = MasterExecutionOrchestrator()
    orchestrator.engage_perpetual_execution()