import xgboost as xgb
import optuna
import polars as pl
import numpy as np
from pathlib import Path
import os
from alpha_nexus.data.storage import ParquetVault
from alpha_nexus.ml.physics import StrictCausalTernaryFold, ExecutionPhysicsEngine

class BayesianEmbargoTrainer:
    def __init__(self):
        self.vault = ParquetVault()
        self.physics = ExecutionPhysicsEngine()
        self.cv = StrictCausalTernaryFold(n_groups=5)

    def _institutional_objective(self, preds: np.ndarray, dmatrix: xgb.DMatrix) -> tuple:
        labels = dmatrix.get_label()
        prev_holds = dmatrix.get_base_margin()
        if prev_holds is None or len(prev_holds) == 0:
            prev_holds = np.zeros_like(preds) + 0.5 

        prob = 1.0 / (1.0 + np.exp(-preds))
        delta_y = prob - prev_holds
        
        # Base spread assumption (can be derived from features in advanced models)
        spread_bps = np.full_like(preds, 0.002) 
        
        _, dF, d2F = self.physics.compute_impact_derivatives(delta_y, spread_bps)
        
        grad = (prob - labels) + dF
        hess = np.maximum((prob * (1.0 - prob)) + d2F, 1e-16) 
        return grad, hess

    def objective(self, trial: optuna.Trial, X: np.ndarray, y: np.ndarray, epochs: np.ndarray) -> float:
        params = {
            "tree_method": "hist",
            "learning_rate": trial.suggest_float("learning_rate", 1e-3, 0.1, log=True),
            "max_depth": trial.suggest_int("max_depth", 3, 7),
            "gamma": trial.suggest_float("gamma", 0.1, 5.0),
            "subsample": trial.suggest_float("subsample", 0.5, 0.9),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.9),
            "disable_default_eval_metric": 1 
        }
        
        fold_scores = []
        for train_idx, stop_idx, eval_idx in self.cv.split(epochs):
            X_train, y_train = X[train_idx], y[train_idx]
            X_test, y_test = X[eval_idx], y[eval_idx]
            
            dtrain = xgb.DMatrix(X_train, label=y_train)
            dtest = xgb.DMatrix(X_test, label=y_test)
            dtrain.set_base_margin(np.zeros(len(X_train)) + 0.5)
            dtest.set_base_margin(np.zeros(len(X_test)) + 0.5)
            
            def eval_net_pnl(preds, dmatrix):
                prob = 1.0 / (1.0 + np.exp(-preds))
                acc = 1.0 - np.abs(prob - dmatrix.get_label())
                turnover = np.abs(prob - 0.5)
                return 'net_loss', float(-np.mean(acc - (turnover * 0.002 * 10)))

            bst = xgb.train(
                params, dtrain, evals=[(dtest, "eval")], 
                obj=self._institutional_objective, custom_metric=eval_net_pnl, 
                early_stopping_rounds=15, verbose_eval=False
            )
            fold_scores.append(bst.best_score)
            
        return float(np.mean(fold_scores)) if fold_scores else 0.0

    def execute_study(self, parquet_filename: str, model_name: str = "institutional_core.ubj"):
        print("="*65)
        print(f"    [?? ML ENGINE] Extracting Physical Reality Matrix from {parquet_filename}")
        print("="*65)
        
        df = self.vault.extract_matrix(parquet_filename)
        X = df.select(df.columns[:9]).to_numpy().astype(np.float32)
        y = df.select("Label").to_numpy().flatten().astype(np.int32)
        epochs = df.select("Epoch").to_numpy().flatten().astype(np.float64) * 86400.0
        
        study = optuna.create_study(direction="minimize")
        study.optimize(lambda trial: self.objective(trial, X, y, epochs), n_trials=5)
        
        print(f"\n[+] OPTIMIZATION COMPLETE. Best Physics-Aware Loss: {study.best_value:.5f}")
        
        best_params = study.best_params
        best_params["disable_default_eval_metric"] = 1
        
        final_dmatrix = xgb.DMatrix(X, label=y)
        final_dmatrix.set_base_margin(np.zeros(len(X)) + 0.5) 
        final_bst = xgb.train(best_params, final_dmatrix, num_boost_round=100, obj=self._institutional_objective)
        
        save_path = Path(os.getcwd()) / model_name
        final_bst.save_model(str(save_path))
        print(f"[+] PHYSICAL CAUSAL MATRIX BAKED: Deployed to {save_path.name}.")
