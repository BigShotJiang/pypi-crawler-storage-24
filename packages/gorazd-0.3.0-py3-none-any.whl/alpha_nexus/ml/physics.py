import numpy as np

class StrictCausalTernaryFold:
    """Isolates Data into strict Purge/Embargo temporal blocks."""
    def __init__(self, n_groups=5, purge_seconds=1296000.0, embargo_seconds=1296000.0):
        self.n_groups = n_groups
        self.purge_seconds = purge_seconds
        self.embargo_seconds = embargo_seconds

    def split(self, epochs: np.ndarray):
        if len(epochs) < 100: return
        time_diffs = np.zeros_like(epochs)
        if len(epochs) > 1: time_diffs[1:] = np.minimum(epochs[1:] - epochs[:-1], 3600.0)
        
        active_time = np.cumsum(time_diffs)
        step = active_time[-1] / float(self.n_groups)
        
        groups = []
        for i in range(self.n_groups):
            start = i * step
            end = (i + 1) * step if i < self.n_groups - 1 else active_time[-1] + 1.0
            groups.append(np.where((active_time >= start) & (active_time < end))[0])

        for i in range(2, self.n_groups):
            stop_raw, eval_raw = groups[i-1], groups[i]
            if len(stop_raw) == 0 or len(eval_raw) == 0: continue
                
            train_raw = np.concatenate(groups[:i-1])
            if len(train_raw) == 0: continue
                
            stop_start, eval_start = epochs[stop_raw[0]], epochs[eval_raw[0]]
            train_indices = train_raw[epochs[train_raw] <= (stop_start - self.purge_seconds)]
            stop_indices = stop_raw[epochs[stop_raw] <= (eval_start - self.embargo_seconds)]
            
            if len(train_indices) > 5 and len(stop_indices) > 0:
                yield train_indices, stop_indices, eval_raw

class ExecutionPhysicsEngine:
    """Physical Slippage and Impact Modeling for XGBoost Gradients."""
    def __init__(self, stationary_qty: float = 1000.0, tick_size: float = 0.01):
        self.stat_qty = stationary_qty
        self.tick_size = tick_size

    def compute_impact_derivatives(self, delta_y: np.ndarray, spread_bps: np.ndarray) -> tuple:
        # Simplified for robust Optuna Integration while maintaining strict convexity
        c = np.maximum(0.01 * spread_bps, self.tick_size)
        c2 = np.square(c)
        dy_sq_c2 = np.square(delta_y) + c2
        
        F_smooth = spread_bps * np.power(dy_sq_c2, 0.5) - (spread_bps * c)
        dF_ddeltay = spread_bps * delta_y * np.power(dy_sq_c2, -0.5)
        d2F_ddeltay2 = spread_bps * c2 * np.power(dy_sq_c2, -1.5)
        
        return F_smooth, dF_ddeltay, d2F_ddeltay2
