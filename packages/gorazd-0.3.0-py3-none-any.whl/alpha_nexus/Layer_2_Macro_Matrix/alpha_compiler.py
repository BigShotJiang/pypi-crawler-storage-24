# alpha_nexus/Layer_2_Macro_Matrix/alpha_compiler.py
import sys
import numpy as np
import pyarrow as pa
import polars as pl
from pathlib import Path

# Absolute Path Resolution
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config
from alpha_nexus.Layer_2_Macro_Matrix.shared_memory import IPCZeroCopyMatrix
from alpha_nexus.Layer_2_Macro_Matrix.feature_engine import FeatureEngine

class AlphaCompiler:
    def __init__(self):
        self.config = load_institutional_config()
        self.historical_path = Path("alpha_nexus/data/raw/institutional_eod_matrix.parquet")
        self.feature_engine = FeatureEngine(
            target_ticker=self.config.universe.target_asset,
            macro_tickers=self.config.universe.macro_assets,
            mega_tickers=self.config.universe.mega_cap_components,
            vol_tickers=self.config.universe.volatility_surface
        )
        
        self.tickers = (
            [self.config.universe.target_asset] + 
            self.config.universe.macro_assets + 
            self.config.universe.mega_cap_components + 
            self.config.universe.volatility_surface
        )
        self.num_assets = len(self.tickers)

    def compile_historical_tensors(self):
        if not self.historical_path.exists():
            raise FileNotFoundError("[-] RAW DATA MISSING: Execute fetch_historical.py first.")
            
        print("[+] COMPILER ENGAGED: Ingesting historical Parquet matrix...")
        historical_df = pl.read_parquet(self.historical_path)
        
        print("[+] FUSION COMPLETE: Applying quantitative derivative physics...")
        processed_lf = self.feature_engine.apply_historical_bulk_transformations(historical_df.lazy())
        
        selected_cols = self.feature_engine.feature_columns + ["Target_Label"]
        final_df = processed_lf.select(selected_cols).drop_nulls().collect()
        
        y_train = final_df.get_column("Target_Label").to_arrow()
        X_train = final_df.drop(["Target_Label"]).to_arrow()
        
        print(f"[+] ABSOLUTE TRAINING TENSORS READY | X_train: {X_train.shape}")
        return X_train, y_train

    def get_live_inference_pointer(self) -> np.ndarray:
        try:
            ipc = IPCZeroCopyMatrix(create=False)
            t0_vector = ipc.read_tensor()
        except RuntimeError:
            t0_vector = np.full(self.num_assets, np.nan)
        
        historical_df = pl.read_parquet(self.historical_path)
        
        hist_features_lf = self.feature_engine.apply_historical_bulk_transformations(historical_df.lazy())
        hist_features = hist_features_lf.select(self.feature_engine.feature_columns).drop_nulls().collect()
        
        t1_vol_raw = hist_features.select(pl.col("Target_Vol_14d").last()).item()
        t1_vol = float(t1_vol_raw) if t1_vol_raw is not None else 0.0
        
        t_minus_1_vector = np.empty(self.num_assets, dtype=np.float64)
        for i, ticker in enumerate(self.tickers):
            col_name = f"{ticker.replace(' ', '_')}_PX_LAST"
            last_val = historical_df.select(pl.col(col_name)).drop_nulls().tail(1).item()
            t_minus_1_vector[i] = last_val
            if np.isnan(t0_vector[i]):
                t0_vector[i] = t_minus_1_vector[i]

        # TACTICAL COUNTERMEASURE: Strict Index Slicing (Avoids String Lookup Overhead)
        macro_start = 1
        mega_start = macro_start + len(self.config.universe.macro_assets)
        vol_start = mega_start + len(self.config.universe.mega_cap_components)
        
        raw_features = self.feature_engine.execute_live_numba_inference(
            t0_target=t0_vector[0],
            t1_target=t_minus_1_vector[0],
            t0_macros=np.ascontiguousarray(t0_vector[macro_start:mega_start]),
            t1_macros=np.ascontiguousarray(t_minus_1_vector[macro_start:mega_start]),
            t0_megas=np.ascontiguousarray(t0_vector[mega_start:vol_start]),
            t1_megas=np.ascontiguousarray(t_minus_1_vector[mega_start:vol_start]),
            vix_t0=t0_vector[vol_start],
            vix_t1=t_minus_1_vector[vol_start],
            vix3m_t0=t0_vector[vol_start + 1],
            vix6m_t0=t0_vector[vol_start + 2],
            t1_vol=t1_vol
        )
        
        feature_tensor = np.ascontiguousarray(raw_features.reshape(1, -1), dtype=np.float32)
        return feature_tensor