# alpha_nexus/Layer_2_Macro_Matrix/feature_engine.py
import polars as pl
import numpy as np
from numba import njit

# TACTICAL COUNTERMEASURE: Hardware-Native Derivative Physics
@njit(nogil=True, fastmath=True)
def _compiled_t0_derivation(t0_target, t1_target, t0_macros, t1_macros, 
                            t0_megas, t1_megas, 
                            vix_t0, vix_t1, vix3m_t0, vix6m_t0, t1_vol):
    
    num_macros = t0_macros.shape[0]
    num_megas = t0_megas.shape[0]
    
    # Architecture: [Target_Ret (1)] + [Macro_Rets (N)] + [Mega_Momentum (1)] + 
    # [VIX_Diff (1)] + [Vol_Surface_Slope (1)] + [Spreads (N)] + [Vol_14d (1)]
    out = np.empty(1 + num_macros + 1 + 1 + 1 + num_macros + 1, dtype=np.float64)
    
    # 1. Target Log Return
    t_ret = np.log((t0_target + 1e-8) / (t1_target + 1e-8))
    out[0] = t_ret
    
    # 2. Macro Log Returns
    for i in range(num_macros):
        out[1 + i] = np.log((t0_macros[i] + 1e-8) / (t1_macros[i] + 1e-8))
        
    # 3. MEGA-CAP NAV MOMENTUM (Aggregate physical thrust of the top 10 stocks)
    mega_sum = 0.0
    for i in range(num_megas):
        mega_sum += np.log((t0_megas[i] + 1e-8) / (t1_megas[i] + 1e-8))
    out[1 + num_macros] = mega_sum / num_megas # Average Mega-Cap trajectory
    
    # 4. Volatility Front-End Differential (VIX T0 - VIX T-1)
    out[1 + num_macros + 1] = vix_t0 - vix_t1
    
    # 5. VOLATILITY SURFACE SLOPE (Contango/Backwardation Proxy)
    # If VIX > VIX3M, dealers are physically short front-end gamma (Panic State)
    out[1 + num_macros + 2] = vix_t0 - vix3m_t0 
    
    # 6. Cross-Asset Spreads
    idx = 1 + num_macros + 3
    for i in range(num_macros):
        out[idx + i] = t_ret - out[1 + i]
        
    # 7. Volatility Carryover
    out[-1] = t1_vol
    
    return out

class FeatureEngine:
    def __init__(self, target_ticker: str, macro_tickers: list, mega_tickers: list, vol_tickers: list):
        self.target = f"{target_ticker.replace(' ', '_')}_PX_LAST"
        
        self.macro_cols = [f"{m.replace(' ', '_')}_PX_LAST" for m in macro_tickers]
        self.mega_cols = [f"{m.replace(' ', '_')}_PX_LAST" for m in mega_tickers]
        
        # Strict Volatility Surface mapping
        self.vix_col = f"{vol_tickers[0].replace(' ', '_')}_PX_LAST"
        self.vix3m_col = f"{vol_tickers[1].replace(' ', '_')}_PX_LAST"
        self.vix6m_col = f"{vol_tickers[2].replace(' ', '_')}_PX_LAST"
        
        self.vol_window = 14
        
        self.feature_columns = [
            "Target_LogRet"
        ] + [
            f"{m}_LogRet" for m in self.macro_cols
        ] + [
            "Mega_Cap_Momentum",
            "VIX_Diff",
            "Vol_Surface_Slope"
        ] + [
            f"Spread_Target_{m}" for m in self.macro_cols
        ] + [
            "Target_Vol_14d"
        ]
        
    def apply_historical_bulk_transformations(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        lf = lf.with_columns(pl.all().forward_fill())
        
        exprs = []
        exprs.append((pl.col(self.target) / pl.col(self.target).shift(1)).log().alias("Target_LogRet"))
        
        for m in self.macro_cols:
            exprs.append((pl.col(m) / pl.col(m).shift(1)).log().alias(f"{m}_LogRet"))
            
        # Bulk calculate Mega-Cap momentum
        mega_exprs = [(pl.col(m) / pl.col(m).shift(1)).log() for m in self.mega_cols]
        exprs.append((sum(mega_exprs) / len(self.mega_cols)).alias("Mega_Cap_Momentum"))
            
        lf = lf.with_columns(exprs)
        
        derived = [
            (pl.col("Target_LogRet").rolling_std(self.vol_window) * np.sqrt(252)).alias("Target_Vol_14d"),
            (pl.col(self.vix_col).shift(1) - pl.col(self.vix_col).shift(2)).alias("VIX_Diff"),
            (pl.col(self.vix_col).shift(1) - pl.col(self.vix3m_col).shift(1)).alias("Vol_Surface_Slope")
        ]
        
        for m in self.macro_cols:
            derived.append((pl.col("Target_LogRet") - pl.col(f"{m}_LogRet")).alias(f"Spread_Target_{m}"))
            
        lf = lf.with_columns(derived)
        target_expr = (pl.col("Target_LogRet").shift(-1) > 0).cast(pl.Int8).alias("Target_Label")
        lf = lf.with_columns([target_expr])
        
        return lf

    def execute_live_numba_inference(self, t0_target, t1_target, t0_macros, t1_macros, 
                                     t0_megas, t1_megas, vix_t0, vix_t1, vix3m_t0, vix6m_t0, t1_vol) -> np.ndarray:
        return _compiled_t0_derivation(t0_target, t1_target, t0_macros, t1_macros, 
                                       t0_megas, t1_megas, vix_t0, vix_t1, vix3m_t0, vix6m_t0, t1_vol)