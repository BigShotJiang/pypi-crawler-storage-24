"""Gorazd Institutional Quantitative Library"""
from .config import settings
from .execution.affinity import lock_hardware_core
from .data.kernel_bypass import DPDKRingBuffer
from .data.gateway import DataGateway
from .data.storage import ParquetVault
from .data.compiler import HistoricalFeedGenerator
from .execution.memory_pool import StaticMemoryPool
from .ml.engine import InferenceEngine
from .ml.native_infer import NativeXGBoostEngine
from .math.core import compute_institutional_features_inplace
from .execution.router import ExecutionNode
from .execution.concurrency import SPSCRingBuffer
from .execution.binary_encoder import BOEEncoder
from .ml.trainer import BayesianEmbargoTrainer
from .execution.telemetry import TelemetryPublisher

__version__ = "0.3.0"
