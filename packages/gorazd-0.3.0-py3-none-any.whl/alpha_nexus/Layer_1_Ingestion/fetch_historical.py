# alpha_nexus/Layer_1_Ingestion/fetch_historical.py
import sys
import blpapi
import polars as pl
from pathlib import Path
from datetime import datetime

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config
from alpha_nexus.Layer_1_Ingestion.blp_daemon import BloombergDaemon

class HistoricalIngestionNode:
    """
    Zero-Copy EOD Ingestion Engine.
    Extracts 10+ years of Target, Macro, Mega-Cap, and Volatility Surface data 
    and directly serializes it to physical Parquet storage.
    """
    def __init__(self):
        self.config = load_institutional_config()
        self.daemon = BloombergDaemon()
        self.session = self.daemon.get_session()
        
        if not self.session:
            raise ConnectionError("[-] ABSOLUTE API VOID: Bloomberg session inactive. Execute blp_daemon.py first.")
            
        # Concatenate the complete asymmetric universe
        self.tickers = (
            [self.config.universe.target_asset] + 
            self.config.universe.macro_assets + 
            self.config.universe.mega_cap_components + 
            self.config.universe.volatility_surface
        )
        
        self.output_dir = Path("alpha_nexus/data/raw")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.parquet_path = self.output_dir / "institutional_eod_matrix.parquet"

    def execute_bulk_extraction(self, start_date="20100101", end_date=None):
        if not end_date:
            end_date = datetime.today().strftime('%Y%m%d')

        print("[+] INITIATING ZERO-COPY EOD EXTRACTION: Querying BBG Native C++ Backend...")
        
        # TACTICAL COUNTERMEASURE: Absolute Service Handshake
        if not self.session.openService("//blp/refdata"):
            raise RuntimeError("[-] C++ SOCKET FATAL: Failed to open //blp/refdata service channel.")
            
        refDataService = self.session.getService("//blp/refdata")
        request = refDataService.createRequest("HistoricalDataRequest")
        
        for ticker in self.tickers:
            request.getElement("securities").appendValue(ticker)
            
        request.getElement("fields").appendValue("PX_LAST")
        request.set("periodicitySelection", "DAILY")
        request.set("startDate", start_date)
        request.set("endDate", end_date)
        
        print("[+] DISPATCHING REQUEST: Awaiting asynchronous memory stream...")
        self.session.sendRequest(request)
        
        data_records = []
        while True:
            event = self.session.nextEvent(500)
            if event.eventType() in [blpapi.Event.PARTIAL_RESPONSE, blpapi.Event.RESPONSE]:
                for msg in event:
                    security_data = msg.getElement("securityData")
                    ticker = security_data.getElementAsString("security")
                    field_data_array = security_data.getElement("fieldData")
                    
                    for i in range(field_data_array.numValues()):
                        field_data = field_data_array.getValueAsElement(i)
                        date = field_data.getElementAsDatetime("date")
                        if field_data.hasElement("PX_LAST"):
                            px_last = field_data.getElementAsFloat("PX_LAST")
                            data_records.append({
                                "Date": date,
                                "Ticker": ticker,
                                "PX_LAST": px_last
                            })
            
            if event.eventType() == blpapi.Event.RESPONSE:
                break

        print("[+] STREAM INTERCEPTED: Fusing primitives into Polars memory space...")
        df_long = pl.DataFrame(data_records)
        
        # Transform from long to wide format and forward fill missing calendar dates
        df_wide = df_long.pivot(
            values="PX_LAST", 
            index="Date", 
            on="Ticker"
        ).sort("Date").with_columns(pl.all().forward_fill())
        
        # Standardize column names to match the C-Compiler expectations
        rename_map = {col: f"{col.replace(' ', '_')}_PX_LAST" for col in df_wide.columns if col != "Date"}
        df_wide = df_wide.rename(rename_map)
        
        df_wide.write_parquet(str(self.parquet_path))
        print(f"[+] INGESTION COMPLETE: Zero-copy EOD Matrix serialized to {self.parquet_path}")

if __name__ == "__main__":
    node = HistoricalIngestionNode()
    node.execute_bulk_extraction()