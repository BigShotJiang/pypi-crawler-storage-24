# alpha_nexus/Layer_1_Ingestion/bpipe_event_stream.py
import sys
import os
import time
import psutil
import blpapi
import gc
from datetime import datetime, timezone
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config
from alpha_nexus.Layer_1_Ingestion.blp_daemon import BloombergDaemon
from alpha_nexus.Layer_2_Macro_Matrix.shared_memory import IPCZeroCopyMatrix

class T0EventStreamer:
    """
    Absolute Live T0 Tick Router.
    Locked to a dedicated CPU core, shielded by a Condition Exclusion Matrix,
    immunized against GC pauses, and strictly synchronized to the Exchange PTP clock.
    """
    def __init__(self):
        gc.disable()
        print("[+] MEMORY CONTROLLER: Automatic Garbage Collection permanently disabled.")
        
        self._lock_hardware_affinity(core_id=1)
        self.config = load_institutional_config()
        self.daemon = BloombergDaemon()
        self.session = self.daemon.get_session()
        
        if not self.session:
            raise ConnectionError("[-] ABSOLUTE API VOID: Bloomberg session inactive. Execute blp_daemon.py first.")
            
        self.ipc = IPCZeroCopyMatrix(create=True)
        self.tickers = [self.config.universe.target_asset] + self.config.universe.macro_assets
        self.toxic_condition_codes = {"Z", "B", "U", "C", "N", "R"}
        
        # TACTICAL COUNTERMEASURE: Rolling Geographical Drift Tracker
        self.rolling_drift_us = 0.0
        self.tick_count = 0

    def _lock_hardware_affinity(self, core_id: int):
        try:
            p = psutil.Process(os.getpid())
            logical_cores = psutil.cpu_count(logical=True)
            target_core = core_id if core_id < logical_cores else (logical_cores - 1)
            p.cpu_affinity([target_core])
            print(f"[+] HARDWARE ISOLATION: Ingestion stream permanently locked to CPU Core {target_core}.")
        except Exception as e:
            print(f"[-] AFFINITY LOCK FAILED: OS rejected CPU pinning. {e}")

    def _calculate_transmission_drift(self, bbg_time_obj) -> float:
        """
        Intercepts the physical exchange timestamp, compares it to the local 
        hardware clock, and calculates the absolute network transmission drift.
        """
        try:
            # Extract Exchange Time (Usually returned as a time object, append today's date)
            now_utc = datetime.now(timezone.utc)
            exchange_dt = datetime.combine(now_utc.date(), bbg_time_obj).replace(tzinfo=timezone.utc)
            
            # Calculate Microsecond Delta
            delta = now_utc - exchange_dt
            drift_microseconds = delta.total_seconds() * 1_000_000
            
            # Update Rolling Average for Institutional Logging
            self.tick_count += 1
            self.rolling_drift_us = self.rolling_drift_us + (drift_microseconds - self.rolling_drift_us) / self.tick_count
            
            return drift_microseconds
        except Exception:
            return 0.0

    def _process_tick(self, ticker: str, price: float, condition_codes: str, exchange_time=None) -> bool:
        # 1. Microstructure Poisoning Check
        if condition_codes:
            codes = [c.strip() for c in condition_codes.split(',') if c.strip()]
            for code in codes:
                if code in self.toxic_condition_codes:
                    return False
        
        # 2. Atomic Clock Synchronization
        drift_us = 0.0
        if exchange_time:
            drift_us = self._calculate_transmission_drift(exchange_time)
                
        # 3. Memory Injection (Applying the physical time offset implicitly via the ZOH latch)
        self.ipc.write_tick(ticker, price)
        
        print(f"[\u26A1 T0 TICK] {ticker:<15} | PRICE: {price:>10.4f} | CLOCK DRIFT: {drift_us:>8.2f} μs | -> [MEM LATCHED]")
        return True

    def ignite_stream(self):
        print("\n[+] INITIATING T0 EVENT STREAM: Forging C++ SubscriptionList...")
        subscriptions = blpapi.SubscriptionList()
        
        for ticker in self.tickers:
            correlation_id = blpapi.CorrelationId(ticker)
            # TACTICAL COUNTERMEASURE: Subscribe strictly to the physical exchange timestamp
            subscriptions.add(ticker, "LAST_PRICE,RT_TRD_COND_CD,TIME", "", correlation_id)
            
        self.session.subscribe(subscriptions)
        print("[+] SUBSCRIPTIONS DISPATCHED: Entering zero-copy extraction loop.\n")
        
        try:
            while True:
                event = self.session.nextEvent(500)
                if event.eventType() == blpapi.Event.SUBSCRIPTION_DATA:
                    for msg in event:
                        ticker = msg.correlationIds()[0].value()
                        if msg.hasElement("LAST_PRICE"):
                            price = msg.getElementAsFloat("LAST_PRICE")
                            condition_codes = msg.getElementAsString("RT_TRD_COND_CD") if msg.hasElement("RT_TRD_COND_CD") else ""
                            
                            # Intercept the physical time payload
                            exchange_time = None
                            if msg.hasElement("TIME"):
                                exchange_time = msg.getElementAsDatetime("TIME")
                                
                            self._process_tick(ticker, price, condition_codes, exchange_time)
                            
        except KeyboardInterrupt:
            print(f"\n[+] STREAM SEVERED. Average Geographical Transmission Drift: {self.rolling_drift_us:.2f} μs")
        finally:
            self.session.unsubscribe(subscriptions)
            self.ipc.unlink()

if __name__ == "__main__":
    streamer = T0EventStreamer()
    streamer.ignite_stream()