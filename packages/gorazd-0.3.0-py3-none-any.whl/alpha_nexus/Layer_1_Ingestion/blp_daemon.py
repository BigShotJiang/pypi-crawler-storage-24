import sys
from pathlib import Path
import blpapi
from typing import Optional

# TACTICAL COUNTERMEASURE: Absolute Path Resolution
# Forces the root workspace into the system path, permanently eradicating ModuleNotFoundError.
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from alpha_nexus.Layer_1_Ingestion.config_parser import load_institutional_config

class BloombergDaemon:
    """Absolute persistent C++ socket manager for BLPAPI."""
    _instance: Optional['BloombergDaemon'] = None

    def __new__(cls):
        # TACTICAL COUNTERMEASURE: Strict Singleton Enforcement
        # Mathematically guarantees only one C++ socket exists across the entire Python memory space.
        if cls._instance is None:
            cls._instance = super(BloombergDaemon, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        self.config = load_institutional_config()
        session_options = blpapi.SessionOptions()
        session_options.setServerHost(self.config.connection.bbg_host)
        session_options.setServerPort(self.config.connection.bbg_port)
        
        # TACTICAL COUNTERMEASURE: Force absolute hardware reconnection on packet drop
        session_options.setAutoRestartOnDisconnection(True)
        
        self.session = blpapi.Session(session_options)
        
        print("[+] INITIATING BLOOMBERG DAEMON: Forging absolute C++ socket connection...")
        if not self.session.start():
            raise ConnectionError("[-] DAEMON FAILURE: Failed to start blpapi session. Verify Bloomberg Terminal/B-Pipe is physically active.")
        
        print("[+] DAEMON SECURED: Persistent blpapi session established.")

    def get_session(self) -> blpapi.Session:
        return self.session

    def terminate(self):
        print("[!] TERMINATING DAEMON: Severing physical socket link.")
        self.session.stop()

if __name__ == "__main__":
    # Physical verification sequence
    daemon = BloombergDaemon()
    session = daemon.get_session()
    daemon.terminate()