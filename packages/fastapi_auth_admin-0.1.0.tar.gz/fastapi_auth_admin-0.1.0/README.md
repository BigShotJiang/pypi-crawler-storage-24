# fastapi-auth-admin

Standalone JWT authentication package for FastAPI applications with admin-approved registration, password management, and extensible token claims (e.g. multi-tenant `company_id`).

## Installation

```bash
pip install fastapi-auth-admin
```

Or with uv:

```bash
uv add fastapi-auth-admin
```

All dependencies (`fastapi`, `sqlalchemy`, `bcrypt`, `pyjwt`, `pydantic[email]`, `python-multipart`) are installed automatically.

## Features

- One-call setup — `setup_auth(app)` does everything
- Email/password registration and login
- Admin-approved user registration workflow
- JWT tokens with extensible arbitrary claims
- Password change (authenticated, requires current password)
- SQLAlchemy user repository (dedicated `users.db` database)
- Auto-seeded admin user on first run
- Swagger UI `/docs` compatible (OAuth2 password flow)

## Quick start

Two touch points — that's it:

**1. Entry point** — one call to set up auth:

```python
from fastapi import FastAPI
from fastapi_auth import setup_auth

app = FastAPI()
setup_auth(app)
```

This single call:
- Configures JWT security
- Initializes a dedicated `users.db` SQLite database
- Seeds the default admin user
- Registers all `/auth/*` endpoints on your app

**2. Endpoints** — add `RequireLogin` where needed:

```python
from fastapi_auth import RequireLogin

@router.get("/orders")
def list_orders(user: RequireLogin):
    ...
```

Run with:

```bash
uvicorn myapp:app --reload
```

### setup_auth options

```python
setup_auth(
    app,
    secret_key="your-secret-key-min-32-bytes-long!",  # JWT secret (use a strong key in production)
    algorithm="HS256",                                  # JWT algorithm (default)
    expire_minutes=30,                                  # token TTL (default)
    db_url="sqlite:///./users.db",                      # user database URL (default)
)
```

Any SQLAlchemy-compatible URL works:

```python
setup_auth(app, db_url="sqlite:///./data/auth.db")           # custom SQLite path
setup_auth(app, db_url="postgresql://user:pass@host/mydb")   # PostgreSQL
```

## Endpoints

| Method | Path                    | Auth   | Description                      |
|--------|-------------------------|--------|----------------------------------|
| POST   | `/auth/register`        | public | Register a new user (pending)    |
| POST   | `/auth/login`           | public | Login, returns JWT (OAuth2 form) |
| GET    | `/auth/me`              | login  | Current user info + token claims |
| POST   | `/auth/change-password` | login  | Change own password              |
| GET    | `/auth/pending`         | admin  | List unapproved users            |
| POST   | `/auth/approve`         | admin  | Approve a user by email          |
| POST   | `/auth/reject`          | admin  | Reject a user by email           |

## Default admin

On first startup the adapter auto-creates an admin user:

- **Email:** `admin@admin.com`
- **Password:** `changeme`

Change the password immediately after first login via `/auth/change-password`.

## Protecting endpoints

Add `RequireLogin` as a parameter to any endpoint to require a valid JWT:

```python
from fastapi import APIRouter
from fastapi_auth import RequireLogin

router = APIRouter()

@router.get("/dashboard")
def dashboard(user: RequireLogin):
    print(user.sub)                        # user email
    print(user.extra.get("is_admin"))      # True/False
```

If you don't need user info in the function body, it still enforces authentication just by being declared as a parameter.

## Multi-tenant / custom token claims

The JWT token supports arbitrary extra claims. Call the `login` use case directly with `extra_claims`:

```python
from fastapi_auth.use_cases import login

token = login(
    email="user@example.com",
    password="secret",
    repo=repo,
    extra_claims={"company_id": 42, "role": "manager"},
)
```

These claims are available in any protected endpoint:

```python
@router.get("/tenant-data")
def tenant_data(user: RequireLogin):
    company_id = user.extra.get("company_id")
    role = user.extra.get("role")
```

## Custom user repository

Implement the `UserRepositoryPort` protocol to use any storage backend:

```python
from fastapi_auth import UserRepositoryPort, User, set_get_user_repo

class MyUserRepository:
    def find_by_email(self, email: str) -> User | None: ...
    def create(self, user: User) -> None: ...
    def update(self, user: User) -> None: ...
    def list_pending(self) -> list[User]: ...
    def ensure_admin(self, email: str, hashed_password: str) -> None: ...

def get_user_repo():
    yield MyUserRepository()

set_get_user_repo(get_user_repo)
```

## Package structure

```
fastapi_auth/
  __init__.py            # setup_auth() + public API exports
  models.py              # User, TokenPayload dataclasses
  ports.py               # UserRepositoryPort protocol
  errors.py              # AuthError, InvalidCredentials, NotAuthorized, ...
  security.py            # bcrypt password hashing, JWT encode/decode, configure()
  use_cases.py           # register, login, approve, reject, change_password, list_pending
  dependencies.py        # FastAPI deps: get_current_user, RequireLogin
  router.py              # APIRouter with all auth endpoints
  sqlalchemy_adapter.py  # SQLAlchemy user repository (default, recommended)
  json_adapter.py        # JSON file user repository (dev/prototyping only)
```

## Workflow

1. Admin logs in with default credentials
2. Users register via `POST /auth/register` (created as unapproved)
3. Admin views pending users via `GET /auth/pending`
4. Admin approves (`POST /auth/approve`) or rejects (`POST /auth/reject`)
5. Approved users can log in and receive a JWT
6. Users change their own password via `POST /auth/change-password`
