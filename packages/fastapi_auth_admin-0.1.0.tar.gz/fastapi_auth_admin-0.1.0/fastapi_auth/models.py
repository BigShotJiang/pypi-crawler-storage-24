from dataclasses import dataclass, field


@dataclass
class User:
    email: str
    hashed_password: str
    is_admin: bool = False
    approved: bool = False


@dataclass(frozen=True)
class TokenPayload:
    """JWT payload with required subject (user email) and arbitrary extra claims.

    Usage:
        TokenPayload(sub="user@example.com")
        TokenPayload(sub="user@example.com", extra={"company_id": 42})
    """

    sub: str
    extra: dict = field(default_factory=dict)

    def to_claims(self) -> dict:
        return {"sub": self.sub, **self.extra}

    @classmethod
    def from_claims(cls, claims: dict) -> "TokenPayload":
        sub = claims.pop("sub")
        claims.pop("exp", None)
        return cls(sub=sub, extra=claims)
