import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .models import TokenPayload

SECRET_KEY = secrets.token_urlsafe(32)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30


def configure(
    secret_key: str | None = None,
    algorithm: str | None = None,
    expire_minutes: int | None = None,
) -> None:
    global SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES
    if secret_key is not None:
        SECRET_KEY = secret_key
    if algorithm is not None:
        ALGORITHM = algorithm
    if expire_minutes is not None:
        ACCESS_TOKEN_EXPIRE_MINUTES = expire_minutes


def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode(), hashed.encode())


def create_access_token(
    payload: TokenPayload,
    expires_delta: timedelta | None = None,
) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    claims = payload.to_claims()
    claims["exp"] = expire
    return jwt.encode(claims, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> TokenPayload:
    claims = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    return TokenPayload.from_claims(claims)
