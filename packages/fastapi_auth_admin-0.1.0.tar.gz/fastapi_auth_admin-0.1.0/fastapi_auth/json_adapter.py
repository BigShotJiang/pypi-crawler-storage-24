import json
from pathlib import Path

from .models import User
from .security import hash_password

DEFAULT_PATH = Path("users.json")
ADMIN_EMAIL = "admin@admin.com"
ADMIN_INITIAL_PASSWORD = "changeme"


class JsonUserRepository:
    def __init__(self, path: Path = DEFAULT_PATH) -> None:
        self._path = path
        if not self._path.exists():
            self._path.write_text("[]")
        self.ensure_admin(ADMIN_EMAIL, hash_password(ADMIN_INITIAL_PASSWORD))

    def _load(self) -> list[dict]:
        return json.loads(self._path.read_text())

    def _save(self, data: list[dict]) -> None:
        self._path.write_text(json.dumps(data, indent=2))

    def _to_user(self, entry: dict) -> User:
        return User(
            email=entry["email"],
            hashed_password=entry["hashed_password"],
            is_admin=entry.get("is_admin", False),
            approved=entry.get("approved", False),
        )

    def _to_dict(self, user: User) -> dict:
        return {
            "email": user.email,
            "hashed_password": user.hashed_password,
            "is_admin": user.is_admin,
            "approved": user.approved,
        }

    def find_by_email(self, email: str) -> User | None:
        for entry in self._load():
            if entry["email"] == email:
                return self._to_user(entry)
        return None

    def create(self, user: User) -> None:
        data = self._load()
        data.append(self._to_dict(user))
        self._save(data)

    def update(self, user: User) -> None:
        data = self._load()
        for i, entry in enumerate(data):
            if entry["email"] == user.email:
                data[i] = self._to_dict(user)
                break
        self._save(data)

    def list_pending(self) -> list[User]:
        return [
            self._to_user(entry)
            for entry in self._load()
            if not entry.get("approved", False) and not entry.get("is_admin", False)
        ]

    def ensure_admin(self, email: str, hashed_password: str) -> None:
        data = self._load()
        for entry in data:
            if entry["email"] == email:
                return
        data.append({
            "email": email,
            "hashed_password": hashed_password,
            "is_admin": True,
            "approved": True,
        })
        self._save(data)


def get_user_repo():
    yield JsonUserRepository()
