from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr

from .dependencies import RequireLogin, get_user_repo
from .errors import (
    InvalidCredentials,
    NotAuthorized,
    UserAlreadyExists,
    UserNotApproved,
    UserNotFound,
)
from .ports import UserRepositoryPort
from .use_cases import (
    approve_user,
    change_password,
    list_pending_users,
    login,
    register,
    reject_user,
)

router = APIRouter(prefix="/auth", tags=["auth"])


# ── Request / Response schemas ──────────────────────────────────────


class RegisterIn(BaseModel):
    email: EmailStr
    password: str


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str


class EmailIn(BaseModel):
    email: EmailStr


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    email: str
    approved: bool


class MessageOut(BaseModel):
    detail: str


# ── Public endpoints ────────────────────────────────────────────────


@router.post("/register", response_model=UserOut)
def register_endpoint(
    payload: RegisterIn,
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> UserOut:
    try:
        user = register(payload.email, payload.password, repo)
    except UserAlreadyExists as e:
        raise HTTPException(status_code=409, detail=str(e)) from e
    return UserOut(email=user.email, approved=user.approved)


@router.post("/login", response_model=TokenOut)
def login_endpoint(
    form_data: OAuth2PasswordRequestForm = Depends(),
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> TokenOut:
    try:
        token = login(form_data.username, form_data.password, repo)
    except InvalidCredentials as e:
        raise HTTPException(status_code=401, detail=str(e)) from e
    except UserNotApproved as e:
        raise HTTPException(status_code=403, detail=str(e)) from e
    return TokenOut(access_token=token)


# ── Authenticated endpoints ─────────────────────────────────────────


@router.get("/me")
def me_endpoint(user: RequireLogin) -> dict:
    return {"email": user.sub, **user.extra}


@router.post("/change-password", response_model=MessageOut)
def change_password_endpoint(
    payload: ChangePasswordIn,
    user: RequireLogin,
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> MessageOut:
    try:
        change_password(
            user.sub, payload.current_password, payload.new_password, user, repo
        )
    except InvalidCredentials as e:
        raise HTTPException(status_code=401, detail=str(e)) from e
    return MessageOut(detail="Password changed successfully")


# ── Admin endpoints ─────────────────────────────────────────────────


@router.get("/pending", response_model=list[UserOut])
def list_pending_endpoint(
    user: RequireLogin,
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> list[UserOut]:
    try:
        users = list_pending_users(user, repo)
    except NotAuthorized as e:
        raise HTTPException(status_code=403, detail=str(e)) from e
    return [UserOut(email=u.email, approved=u.approved) for u in users]


@router.post("/approve", response_model=UserOut)
def approve_endpoint(
    payload: EmailIn,
    user: RequireLogin,
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> UserOut:
    try:
        approved = approve_user(payload.email, user, repo)
    except NotAuthorized as e:
        raise HTTPException(status_code=403, detail=str(e)) from e
    except UserNotFound as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    return UserOut(email=approved.email, approved=approved.approved)


@router.post("/reject", response_model=MessageOut)
def reject_endpoint(
    payload: EmailIn,
    user: RequireLogin,
    repo: UserRepositoryPort = Depends(get_user_repo),
) -> MessageOut:
    try:
        reject_user(payload.email, user, repo)
    except NotAuthorized as e:
        raise HTTPException(status_code=403, detail=str(e)) from e
    except UserNotFound as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    return MessageOut(detail=f"User {payload.email} rejected")
