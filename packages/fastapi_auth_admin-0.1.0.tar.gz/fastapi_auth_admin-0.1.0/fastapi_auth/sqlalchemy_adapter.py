from dataclasses import dataclass

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from .models import User
from .security import hash_password

ADMIN_EMAIL = "admin@admin.com"
ADMIN_INITIAL_PASSWORD = "changeme"

# ── ORM model ───────────────────────────────────────────────────────


class Base(DeclarativeBase):
    pass


class UserModel(Base):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(primary_key=True)
    hashed_password: Mapped[str]
    is_admin: Mapped[bool] = mapped_column(default=False)
    approved: Mapped[bool] = mapped_column(default=False)


# ── Engine / session setup ──────────────────────────────────────────

_engine = None
_SessionLocal = None


def init_db(url: str = "sqlite:///./users.db") -> None:
    global _engine, _SessionLocal

    _engine = create_engine(url, connect_args={"check_same_thread": False})

    @event.listens_for(_engine, "connect")
    def set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)

    Base.metadata.create_all(bind=_engine)

    # Seed admin user
    session = _SessionLocal()
    try:
        if session.get(UserModel, ADMIN_EMAIL) is None:
            session.add(UserModel(
                email=ADMIN_EMAIL,
                hashed_password=hash_password(ADMIN_INITIAL_PASSWORD),
                is_admin=True,
                approved=True,
            ))
            session.commit()
    finally:
        session.close()


# ── Adapter ─────────────────────────────────────────────────────────


@dataclass
class SqlAlchemyUserRepository:
    conn: Session

    def find_by_email(self, email: str) -> User | None:
        row = self.conn.get(UserModel, email)
        if row is None:
            return None
        return User(
            email=row.email,
            hashed_password=row.hashed_password,
            is_admin=row.is_admin,
            approved=row.approved,
        )

    def create(self, user: User) -> None:
        self.conn.add(UserModel(
            email=user.email,
            hashed_password=user.hashed_password,
            is_admin=user.is_admin,
            approved=user.approved,
        ))
        self.conn.commit()

    def update(self, user: User) -> None:
        row = self.conn.get(UserModel, user.email)
        if row is None:
            return
        row.hashed_password = user.hashed_password
        row.is_admin = user.is_admin
        row.approved = user.approved
        self.conn.commit()

    def list_pending(self) -> list[User]:
        rows = (
            self.conn.query(UserModel)
            .filter(UserModel.approved == False, UserModel.is_admin == False)
            .all()
        )
        return [
            User(
                email=r.email,
                hashed_password=r.hashed_password,
                is_admin=r.is_admin,
                approved=r.approved,
            )
            for r in rows
        ]

    def ensure_admin(self, email: str, hashed_password: str) -> None:
        if self.conn.get(UserModel, email) is not None:
            return
        self.conn.add(UserModel(
            email=email,
            hashed_password=hashed_password,
            is_admin=True,
            approved=True,
        ))
        self.conn.commit()


# ── FastAPI dependency ──────────────────────────────────────────────


def get_user_repo():
    if _SessionLocal is None:
        raise RuntimeError("User DB not initialized. Call init_db() first.")
    session = _SessionLocal()
    try:
        yield SqlAlchemyUserRepository(conn=session)
    finally:
        session.close()
