"""Standalone FastAPI JWT auth package.

Quick start:
    from fastapi import FastAPI
    from fastapi_auth import setup_auth

    app = FastAPI()
    setup_auth(app)

    # Or with options:
    setup_auth(app, secret_key="my-secret", db_url="sqlite:///./auth.db")

Protect endpoints:
    from fastapi_auth import RequireLogin

    @router.get("/protected")
    def protected(user: RequireLogin):
        print(user.sub)                        # email
        print(user.extra.get("is_admin"))      # bool
        print(user.extra.get("company_id"))    # custom claim
"""

from fastapi import FastAPI

from .dependencies import RequireLogin, get_current_user, set_get_user_repo
from .errors import (
    AuthError,
    InvalidCredentials,
    NotAuthorized,
    UserAlreadyExists,
    UserNotApproved,
    UserNotFound,
)
from .models import TokenPayload, User
from .ports import UserRepositoryPort
from .router import router as auth_router
from .security import configure as configure_security
from .security import hash_password, verify_password


def setup_auth(
    app: FastAPI,
    *,
    secret_key: str | None = None,
    algorithm: str | None = None,
    expire_minutes: int | None = None,
    db_url: str = "sqlite:///./users.db",
) -> None:
    """One-call setup: configures security, initializes the user DB, and
    registers the auth router on the given FastAPI app."""
    from .sqlalchemy_adapter import get_user_repo, init_db

    configure_security(secret_key, algorithm, expire_minutes)
    init_db(db_url)
    set_get_user_repo(get_user_repo)
    app.include_router(auth_router)


__all__ = [
    "setup_auth",
    "auth_router",
    "configure_security",
    "get_current_user",
    "hash_password",
    "verify_password",
    "set_get_user_repo",
    "RequireLogin",
    "AuthError",
    "InvalidCredentials",
    "NotAuthorized",
    "UserAlreadyExists",
    "UserNotApproved",
    "UserNotFound",
    "TokenPayload",
    "User",
    "UserRepositoryPort",
]
