from typing import Annotated

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
import jwt

from .models import TokenPayload
from .security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

_get_user_repo = None


def set_get_user_repo(fn) -> None:
    global _get_user_repo
    _get_user_repo = fn


def get_user_repo():
    if _get_user_repo is None:
        raise RuntimeError(
            "User repository not configured. Call set_get_user_repo() first."
        )
    yield from _get_user_repo()


def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]) -> TokenPayload:
    try:
        return decode_access_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )


RequireLogin = Annotated[TokenPayload, Depends(get_current_user)]
