class AuthError(Exception):
    """Base class for authentication errors."""


class InvalidCredentials(AuthError):
    def __init__(self) -> None:
        super().__init__("Invalid email or password")


class UserAlreadyExists(AuthError):
    def __init__(self, email: str) -> None:
        super().__init__(f"User already exists: {email}")
        self.email = email


class UserNotApproved(AuthError):
    def __init__(self, email: str) -> None:
        super().__init__(f"User not yet approved: {email}")
        self.email = email


class NotAuthorized(AuthError):
    def __init__(self) -> None:
        super().__init__("Admin privileges required")


class UserNotFound(AuthError):
    def __init__(self, email: str) -> None:
        super().__init__(f"User not found: {email}")
        self.email = email
