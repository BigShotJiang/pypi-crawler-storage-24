"""Allow running as: python -m datasets.checkbox.pipeline [args]"""
from .run import main

main()
