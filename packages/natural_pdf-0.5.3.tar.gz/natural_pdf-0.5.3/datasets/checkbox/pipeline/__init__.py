"""Checkbox dataset acquisition pipeline."""
