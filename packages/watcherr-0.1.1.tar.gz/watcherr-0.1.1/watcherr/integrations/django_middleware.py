from __future__ import annotations

from watcherr.sender import send_alert


class WatcherrMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_exception(self, request, exception):
        send_alert(
            f"Unhandled exception in {request.method} {request.path}",
            exc=exception,
            method=request.method,
            path=request.path,
            client=request.META.get("REMOTE_ADDR", "unknown"),
        )
        return None
