# About OpenCOS

OpenCOS is an open-source EDA flow runner developed to provide a unified interface for hardware design tools.

## License

ISC License - see LICENSE file in repository.

## Contributing

Contributions welcome! Please open issues and pull requests on GitHub.
