# OpenROAD Placement with IO sites

set design "ast_module_000"
set lib "/tools/OpenROAD-flow-scripts/flow/platforms/sky130hs/lib/sky130_fd_sc_hs__tt_025C_1v80.lib"
set lef_dir "/tools/OpenROAD-flow-scripts/flow/platforms/sky130hs/lef"

puts "=== OpenROAD Placement ==="

read_liberty $lib
read_lef $lef_dir/sky130_fd_sc_hs.tlef
read_lef $lef_dir/sky130_fd_sc_hs_merged.lef

read_verilog sky130_results/${design}_sky130.v
link_design $design
read_sdc sky130_results/${design}_auto.sdc

initialize_floorplan -utilization 0.40 -aspect_ratio 1.0 -core_space 10.0 -site unit

puts "Creating IO sites..."
make_tracks
place_pins -hor_layer met3 -ver_layer met2

puts "Global placement..."
global_placement
detailed_placement

puts "\nResults:"
report_design_area
check_placement

estimate_parasitics -placement
report_checks -path_delay max -digits 3
report_wns -digits 3

write_def openroad_results/${design}_placed.def
write_db openroad_results/${design}_placed.odb

puts "\nDone! Files in openroad_results/"
exit
