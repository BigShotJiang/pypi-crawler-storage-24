'''opencos.commands.show_tools - command handler for: eda show_tools [args]

Note this command is handled differently than others (such as CommandSim),
it is generally run as simply

    > eda show_tools

uses no tools and will print a pretty list of tools installed (similar to --help)
'''

# Note - similar code waiver, tricky to eliminate it with inheritance when
# calling reusable methods.
# pylint: disable=R0801

import os

from opencos import util
from opencos.eda_base import Command


class CommandShowTools(Command):
    '''command handler for: eda targets'''

    command_name = 'targets'

    def __init__(self, config: dict):
        super().__init__(config)
        # We don't have any args, clear them.
        self.args = {}
        self.args_help = {}
        self.config = config
        self.status = 0

    def process_tokens( # pylint: disable=unused-argument
        self, tokens: list, process_all: bool = True,
        pwd: str = os.getcwd()
    ) -> list:
        '''This is effectively our 'run' method, entrypoint from opencos.eda.main'''

        # disable artifacts, logging is disabled by eda.py adding 'deps-help' to:
        #   util.global_log.default_log_disable_with_args
        util.artifacts.enabled = False

        # run with process_all=False, we don't care about unparsed args
        super().process_tokens(tokens=tokens, process_all=False, pwd=pwd)
        return []
