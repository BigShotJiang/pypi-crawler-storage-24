'''__init__ acts mostly a package convenience, so that the following works:

    from opencos.commands import CommandSim

without having to know that it's in opencos.commands.sim
'''

from .build import CommandBuild
from .coverage import CommandCoverage
from .elab import CommandElab
from .export import CommandExport
from .flist import CommandFList
from .multi import CommandMulti, CommandToolsMulti
from .lint import CommandLint
from .open import CommandOpen
from .pnr import CommandPnr
from .proj import CommandProj
from .sim import CommandSim
from .sta import CommandSta
from .sweep import CommandSweep
from .synth import CommandSynth
from .upload import CommandUpload
from .waves import CommandWaves
from .shell import CommandShell
from .targets import CommandTargets
from .lec import CommandLec
from .deps_help import CommandDepsHelp

__all__ = [
    'CommandBuild',
    'CommandCoverage',
    'CommandElab',
    'CommandExport',
    'CommandFList',
    'CommandMulti',
    'CommandLint',
    'CommandOpen',
    'CommandPnr',
    'CommandProj',
    'CommandSim',
    'CommandSta',
    'CommandSweep',
    'CommandSynth',
    'CommandToolsMulti',
    'CommandUpload',
    'CommandWaves',
    'CommandShell',
    'CommandTargets',
    'CommandLec',
    'CommandDepsHelp',
]
