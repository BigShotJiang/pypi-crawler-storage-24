package _waves_pkg;

`ifdef SIMULATION
`ifndef _WAVES_PKG_DISABLE_DUMPFILE // hook to disable this if user chooses
`ifdef VERILATOR

  //
  // Handle waves for +trace for Verilator, if there was no other $dumpfile in the
  // user source code, and the `eda` command had --waves present.
  //
  // Simulation runtime usage:
  // +trace=vcd    : Verilator/iverilog dump.vcd
  // all others    : Verilator dump.fst
  //
  bit        trace_en_init = 0;
  bit        trace_en      = init_trace();

  function bit init_trace();

    if (trace_en_init) // only do this once.
      return trace_en;

    trace_en_init = 1;

    if ($test$plusargs("trace") != 0) begin
      automatic string trace_str_value = "";
      void'($value$plusargs("trace=%s", trace_str_value));
      if (trace_str_value.tolower() == "vcd") begin
        $display("%t %m: Starting tracing to ./dump.vcd, plusarg +trace=vcd", $realtime);
        $dumpfile("dump.vcd");
        $dumpvars();
      end else begin
        $display("%t %m: Starting tracing to ./dump.fst", $realtime);
        $dumpfile("dump.fst");
        $dumpvars();
      end
    end

    return 1;

  endfunction : init_trace

`elsif IVERILOG

  bit        trace_en_init = 0;
  bit        trace_en      = init_trace();

  function bit init_trace();

    if (trace_en_init) // only do this once.
      return trace_en;

    trace_en_init = 1;

    if ($test$plusargs("trace") != 0) begin
      $display("%t %m: Starting tracing to ./dump.vcd, plusarg +trace present", $realtime);
      $dumpfile("dump.vcd");
      $dumpvars();
      return 1;
    end

  endfunction : init_trace

`endif
`endif
`endif

endpackage : _waves_pkg

//
// For RIVIERA (and SIMULATION, and not disabled):
// - it will not run system calls from a package function, unless that package was
//   used by the testbench
// - so we have to
//   - create a side module _waves_module. Fortunately the $dumpvars() in riviera
//     dumps all module hier, not just that from _waves_module.
//   - We will have to include work._waves_module in the vsim call (in riviera.py)
//

// TODO(drew): please test this on a file that doesn't involve ocsim_pkg.sv

`ifdef SIMULATION
`ifndef _WAVES_PKG_DISABLE_DUMPFILE // hook to disable this if user chooses
`ifdef RIVIERA

module _waves_module;

  string trace_str_value = "";

  initial begin

    if ($test$plusargs("trace") != 0) begin
      void'($value$plusargs("trace=%s", trace_str_value));
      if (trace_str_value.tolower() == "vcd") begin
        $display("%t %m: Starting tracing to ./dump.vcd, plusarg +trace=vcd", $realtime);
        $dumpfile("dump.vcd");
        $dumpvars();
      end else begin
        $display("%t %m: Starting tracing to ./dump.fst", $realtime);
        $dumpfile("dump.fst");
        $dumpvars();
      end
    end

  end

endmodule : _waves_module

`endif
`endif
`endif
