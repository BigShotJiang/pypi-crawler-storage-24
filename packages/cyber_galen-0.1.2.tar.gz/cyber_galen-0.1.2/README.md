# 🩺 CyberGalen

> **This package is a protective alias for [CyberHuaTuo](https://pypi.org/project/cyberhuatuo/).**
> **本包是 CyberHuaTuo 开源生态的护城河别名包。**

## 🌐 Brand Matrix / 品牌矩阵

CyberHuaTuo project claims the following globally-recognized medical deities as aliases to provide a seamless namespace experience:
赛博华佗项目已全面注册以下东西方“医药神祗”作为官方别名，**无论安装以下哪个包，均会自动获取核心诊断引擎：**

* **Core/核心**: `cyberhuatuo`, `openhuatuo`
* **Greek/Roman Mythology**: `cyber-asclepius`, `open-asclepius`, `cyber-panacea`, `open-panacea`, `cyber-galen`, `open-galen`
* **Medical Pioneers**: `cyber-hippocrates`, `open-hippocrates`
* **Ancient Civilizations**: `cyber-imhotep`, `open-imhotep`, `cyber-avicenna`, `open-avicenna`

---

## 🚀 Installation & Usage / 安装与使用

Please install and use the core framework directory:
请直接唤醒核心框架体验：

```bash
pip install cyberhuatuo
# or
uvx cyberhuatuo
```

Project Homepage / 项目主页: https://github.com/JinNing6/CyberHuaTuo
