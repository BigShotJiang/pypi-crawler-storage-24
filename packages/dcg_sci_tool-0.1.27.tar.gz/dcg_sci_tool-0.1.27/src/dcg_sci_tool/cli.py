import argparse
import sys
from dcg_sci_tool.merge_xyz import merge_xyz
from dcg_sci_tool.applications.manual_name_xyz_png_at_nebdir import manual_name_xyz_png_at_nebdir

# 第一步：为每个子命令定义其对应的处理函数
def merge_xyz_command(args):
    """
    处理 merge_xyz 子命令的实际逻辑。
    当前示例只是打印输入文件路径。
    """
    print(f"正在处理输入文件列表: {args.input}")
    input_files = args.input.split(' ')
    merge_xyz(input_files)
    return 0

# def manual_name_xyz_png_at_nebdir_command():
#     """
#     处理 manual_name_xyz_png_at_nebdir 子命令的实际逻辑。
#     当前示例只是打印输入文件路径。
#     """
#     manual_name_xyz_png_at_nebdir()
#     return 0

def main():
    """主 CLI 入口函数"""
    # 可保留的欢迎语（可选，也可以注释掉）
    # print("欢迎使用dcg-sci-tool！这是一个用于科学计算的工具包。")

    # 1. 创建顶层解析器
    parser = argparse.ArgumentParser(
        description="dcg-sci-tool: 一个用于科学计算的工具包。",
        epilog="使用 'dcg-sci-tool <命令> -h' 查看具体命令帮助。"
    )
    parser.add_argument(
        '--version',
        action='version',
        version='dcg-sci-tool 0.1.26'
    )

    # 2. 创建子命令解析器
    subparsers = parser.add_subparsers(
        dest='command',
        title='可用命令',
        help='选择要执行的操作'
    )
    subparsers.required = True  # 强制必须提供子命令

    # 3. 定义 'merge_xyz' 子命令
    parser_merge_xyz = subparsers.add_parser(
        'merge_xyz',
        help='合并多个xyz文件'  # 这里定义了您想看到的帮助信息
    )
    parser_merge_xyz.add_argument(
        'input',
        help='输入轨迹列表'  # 对 input 参数的说明
    )

    # 3. 定义 'manual_name_xyz_png_at_nebdir' 子命令
    parser_manual_name_xyz_png_at_nebdir = subparsers.add_parser(
        'manual_name_xyz_png_at_nebdir',
        help='手动命名xyz文件和png文件'
    )

    # 可以继续为 merge_xyz 子命令添加其他参数，例如：
    # parser_merge_xyz.add_argument(
    #     '-o', '--output',
    #     default='merged.xyz',
    #     help='输出文件的路径 (默认: merged.xyz)'
    # )
    # ！！！关键一步：将这个子命令绑定到上面定义的处理函数
    parser_merge_xyz.set_defaults(func=merge_xyz_command)
    parser_manual_name_xyz_png_at_nebdir.set_defaults(func=manual_name_xyz_png_at_nebdir)

    # 4. 解析用户从命令行传入的参数
    args = parser.parse_args()

    # 5. 调用对应子命令的处理函数
    # 如果用户输入了 -h 或 --help，argparse 会自行处理并退出，不会执行到这里。
    # 只有用户输入了合法命令时，才会执行以下调用。
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())