"""Funções utilitárias: normalização, conversão e execução com timeout.

Contém helpers usados em pipelines para preparar dados antes do envio
ao BigQuery e para executar tarefas com timeout/fallback.
"""

import json
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from unidecode import unidecode
import re
import math


def ajusta_nome_coluna(nome_coluna):
    """Normaliza um nome de coluna para formato compatível com BigQuery.

    - converte para minúsculas
    - substitui espaços por `_`
    - remove acentos e caracteres especiais
    - compacta múltiplos underscores
    """
    normalized = unidecode(nome_coluna.lower().replace(" ", "_"))
    sem_caractere_especial = re.sub(r"[^a-zA-Z0-9_]", "", normalized)
    return re.sub(r"_{2,}", "_", sem_caractere_especial)


def converter_valor(row, schema_map, gerador_log):
    """Converte e sanitiza os valores de uma linha segundo o `schema_map`.

    - Recebe `row` (dict coluna->valor) e `schema_map` (coluna->TIPO BigQuery).
    - Converte tipos básicos (STRING, INTEGER, FLOAT, BOOLEAN, DATE, DATETIME).
    - Sanitiza NaN/Inf e formata datas no padrão aceito pelo BigQuery.
    - Em falhas de conversão registra avisos e armazena `None` no campo.
    """

    if not schema_map:
        return row

    nova_linha = {}

    regex_data_br = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
    regex_iso_tz = re.compile(
        r"^(\d{4}-\d{2}-\d{2})[T ]" r"(\d{2}:\d{2}:\d{2}(?:\.\d+)?)" r"(?:Z|[+-]\d{2}:?\d{2})?$"
    )

    for col, val in row.items():
        # Valores vazios viram NULL
        if val is None or val == "":
            nova_linha[col] = None
            continue

        # Serializa estruturas complexas para JSON
        if isinstance(val, (dict, list)):
            try:
                nova_linha[col] = json.dumps(val, ensure_ascii=False)
            except Exception:
                nova_linha[col] = str(val)
            continue

        tipo_bq = schema_map.get(col, "STRING")

        try:
            if tipo_bq == "STRING":
                val_str = str(val).replace("\n", " ").replace("\r", "").strip()
                nova_linha[col] = val_str

            elif tipo_bq in ("INTEGER", "INT64"):
                # Garante conversão segura string -> float -> int (ex: "10.0" vira 10)
                nova_linha[col] = int(float(str(val)))

            elif tipo_bq in ("FLOAT", "FLOAT64", "NUMERIC"):
                # Limpeza inicial de moeda e espaços
                val_str = str(val).replace("R$", "").replace(" ", "").strip()

                # Trata traço como zero (comum em planilhas)
                if val_str in ("-", ""):
                    nova_linha[col] = 0.0

                else:
                    # Converte formato brasileiro 1.000,00 -> 1000.00
                    if "," in val_str:
                        val_str = val_str.replace(".", "").replace(",", ".")

                    try:
                        valor_float = float(val_str)

                        # Verifica NaN/Infinity
                        if math.isnan(valor_float) or math.isinf(valor_float):
                            nova_linha[col] = None
                        else:
                            nova_linha[col] = valor_float
                    except ValueError:
                        gerador_log.add(
                            f"AVISO: Não foi possível converter '{val}' para FLOAT. Coluna: {col}. Enviando NULL.",
                            severity="WARNING",
                        )
                        nova_linha[col] = None

            elif tipo_bq in ("BOOLEAN", "BOOL"):
                nova_linha[col] = str(val).lower() in ("true", "1", "t", "yes")

            elif tipo_bq == "DATE":
                val_str = str(val).strip()
                match_br = regex_data_br.match(val_str)
                if match_br:
                    nova_linha[col] = f"{match_br.group(3)}-{match_br.group(2)}-{match_br.group(1)}"
                else:
                    nova_linha[col] = val_str[:10]

            elif tipo_bq == "DATETIME":
                val_str = str(val).strip()
                match_iso = regex_iso_tz.match(val_str)
                if match_iso:
                    nova_linha[col] = f"{match_iso.group(1)} {match_iso.group(2)}"
                else:
                    # Limpeza robusta de timezone para evitar erro de formato
                    limpo = val_str.replace("T", " ").replace("Z", "")
                    # Remove offsets como -03:00 ou +00:00 manualmente se regex falhar
                    if "+" in limpo:
                        limpo = limpo.split("+")[0]
                    if "-" in limpo and len(limpo.split("-")[-1]) == 5:  # tenta pegar offsets tipo -03:00
                        limpo = limpo.rsplit("-", 1)[0]
                    nova_linha[col] = limpo.strip()[:23]

            else:
                # Tipo não tratado: devolve o valor como veio
                nova_linha[col] = val

        except Exception:
            # Se falhar a conversão, registra aviso e envia NULL para evitar erros BQ
            gerador_log.add(
                f"AVISO: Falha conversão coluna '{col}' valor '{val}'. Enviando NULL."
            )
            nova_linha[col] = None

    return nova_linha


def executar_com_fallback(func, bq_client, timeout, project, dataset, tabela, gerador_log):
    """Executa `func` em um executor com timeout e captura falhas.

    Retorna uma string entre: `"sucesso"`, `"timeout"`, `"falha"`.
    """
    executor = ThreadPoolExecutor(max_workers=1)
    future = executor.submit(func, bq_client, project, dataset, tabela, gerador_log)
    shutdown_done = False
    try:
        future.result(timeout=timeout)
        gerador_log.add(f"✅ {func.__name__} concluída no projeto {bq_client.project}")
        return "sucesso"
    except TimeoutError:
        # Cancela a execução e encerra o executor sem bloquear,
        # garantindo que o timeout seja efetivo.
        future.cancel()
        executor.shutdown(wait=False, cancel_futures=True)
        shutdown_done = True
        return "timeout"
    except Exception as e:
        gerador_log.add(f"❌ Erro {func.__name__}: {e}")
        return "falha"
    finally:
        if not shutdown_done:
            # Encerra o executor normalmente nos demais cenários.
            executor.shutdown(wait=True, cancel_futures=True)
