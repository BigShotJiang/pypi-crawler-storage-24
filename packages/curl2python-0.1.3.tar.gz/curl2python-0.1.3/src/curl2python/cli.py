import argparse
from .extract_configs import curl_to_python

def main():
    parser = argparse.ArgumentParser(description="Convert curl to Python requests")
    parser.add_argument("curl", help="curl command")

    args = parser.parse_args()

    result = curl_to_python(args.curl)

    print(result)

if __name__ == "__main__":
    main()