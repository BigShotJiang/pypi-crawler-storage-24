def main():
    print("Hello from syncytium!")


if __name__ == "__main__":
    main()
