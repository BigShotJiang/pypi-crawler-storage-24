"""
画布渲染系统 — 根据布局树动态构建 Textual Widget 树
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static, RichLog
from textual.containers import Horizontal, Vertical

from .tui_layout import (
    LayoutNode, PaneNode, SplitNode,
    all_panes, find_pane, find_module_pane, serialize, MODULE_LABELS, MODULES,
)
from .tui_widgets import ChatPanel, CommandPanel, InfoTablePanel, InfoGamePanel, OnlineUsersPanel


# ── 模块注册表 ──

MODULE_REGISTRY: dict[str, dict] = {
    'chat':       {'label': '聊天',     'class': ChatPanel},
    'cmd':        {'label': '指令',     'class': CommandPanel},
    'info_table': {'label': '信息表',   'class': InfoTablePanel},
    'game':       {'label': '游戏面板', 'class': InfoGamePanel},
    'online':     {'label': '在线用户', 'class': OnlineUsersPanel},
}


# ── 空窗格占位 ──

class EmptyPane(Widget):
    """空窗格显示提示"""

    def compose(self) -> ComposeResult:
        yield Static("Space+e 打开模块", id="empty-hint", classes="empty-hint")


# ── 窗格包装器 ──

class PaneWrapper(Widget):
    """包装一个模块 Widget 的窗格容器"""

    def __init__(self, pane_id: str, module: str | None = None, **kw):
        super().__init__(id=pane_id, **kw)
        self.pane_id = pane_id
        self.module_name = module
        self._module_widget: Widget | None = None

    def compose(self) -> ComposeResult:
        if self.module_name and self.module_name in MODULE_REGISTRY:
            widget = MODULE_REGISTRY[self.module_name]['class']()
            self._module_widget = widget
            yield widget
        else:
            yield EmptyPane()

    def on_mount(self) -> None:
        label = MODULE_LABELS.get(self.module_name, '') if self.module_name else ''
        self.border_title = label

    @property
    def module_widget(self) -> Widget | None:
        return self._module_widget

    async def set_module(self, module_name: str | None):
        """替换当前模块"""
        self.module_name = module_name
        # 移除所有子组件
        await self.remove_children()
        # 挂载新模块
        if module_name and module_name in MODULE_REGISTRY:
            widget = MODULE_REGISTRY[module_name]['class']()
            self._module_widget = widget
            await self.mount(widget)
        else:
            self._module_widget = None
            await self.mount(EmptyPane())
        label = MODULE_LABELS.get(module_name, '') if module_name else ''
        self.border_title = label


# ── 画布 ──

class Canvas(Widget):
    """动态画布：根据布局树构建嵌套的 Widget 容器"""

    def __init__(self, layout_tree: LayoutNode, **kw):
        super().__init__(**kw)
        self._layout_tree = layout_tree

    @property
    def layout_tree(self) -> LayoutNode:
        return self._layout_tree

    def compose(self) -> ComposeResult:
        yield from self._build_node(self._layout_tree)

    def _build_node(self, node: LayoutNode, weight: float = 1.0, parent_dir: str | None = None):
        if isinstance(node, PaneNode):
            pw = PaneWrapper(node.pane_id, node.module, classes="pane-wrapper")
            if parent_dir == 'h':
                pw.styles.width = f"{weight:g}fr"
            elif parent_dir == 'v':
                pw.styles.height = f"{weight:g}fr"
            yield pw
        elif isinstance(node, SplitNode):
            container_cls = Horizontal if node.direction == 'h' else Vertical
            children = []
            for child, w in zip(node.children, node.weights):
                children.extend(self._build_node(child, w, node.direction))
            container = container_cls(*children, classes=f"split-{'h' if node.direction == 'h' else 'v'}")
            if parent_dir == 'h':
                container.styles.width = f"{weight:g}fr"
            elif parent_dir == 'v':
                container.styles.height = f"{weight:g}fr"
            yield container

    async def rebuild(self, new_tree: LayoutNode):
        """用新的布局树重建画布"""
        self._layout_tree = new_tree
        await self.remove_children()
        children = list(self._build_node(new_tree))
        await self.mount_all(children)

    def get_pane(self, pane_id: str) -> PaneWrapper | None:
        try:
            return self.query_one(f"#{pane_id}", PaneWrapper)
        except Exception:
            return None

    def get_module_widget(self, module_name: str) -> Widget | None:
        """查找当前画布中特定模块的 Widget 实例"""
        pane_node = find_module_pane(self._layout_tree, module_name)
        if not pane_node:
            return None
        wrapper = self.get_pane(pane_node.pane_id)
        if wrapper:
            return wrapper.module_widget
        return None


# ── 模块选择器 ──

class ModulePicker(Widget):
    """左侧浮动模块选择器"""

    def __init__(self, **kw):
        super().__init__(**kw)
        self._selected = 0
        self._items = list(MODULES)

    def render(self) -> str:
        lines = ["[b]选择模块[/b]", ""]
        for i, mod in enumerate(self._items):
            label = MODULE_LABELS.get(mod, mod)
            if i == self._selected:
                lines.append(f"  [reverse] {label} [/]")
            else:
                lines.append(f"    {label}")
        lines.append("")
        lines.append("[dim]j/k 选择  Enter 确认  Esc 取消[/]")
        return "\n".join(lines)

    def move_down(self):
        self._selected = (self._selected + 1) % len(self._items)
        self.refresh()

    def move_up(self):
        self._selected = (self._selected - 1) % len(self._items)
        self.refresh()

    def get_selected(self) -> str:
        return self._items[self._selected]
