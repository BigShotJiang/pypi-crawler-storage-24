"""
Textual TUI 主应用 — 极简终端风格
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.widgets import Static, Input, RichLog
from textual.containers import Vertical, Horizontal, Center, Middle
from textual.binding import Binding
from textual.message import Message
from textual import work

from .config import PORT, DEFAULT_HOST
from .network import NetworkManager
from .vim_mode import VimMode, Mode
from .message_handler import (
    parse_server_message,
    LoginPrompt, RequestAvatar, LoginSuccess,
    SystemMessage, GameMessage, ChatMessage, ChatHistory,
    StatusUpdate, OnlineUsers, GameInvite,
    RoomUpdate, RoomLeave, GameQuit, LocationUpdate,
    HandUpdate, ActionPrompt, SelfActionPrompt,
    WinAnimation, ActionCommand,
)
from .tui_layout import (
    LayoutNode, PaneNode, SplitNode,
    get_default_layout, serialize, deserialize,
    all_panes, find_pane, find_module_pane,
    split_pane, close_pane, navigate, next_pane_id, resize_pane,
)
from .tui_canvas import Canvas, PaneWrapper, MODULE_REGISTRY
from .tui_widgets import ChatPanel, CommandPanel, InfoTablePanel, InfoGamePanel, OnlineUsersPanel

try:
    from .config import VERSION
except ImportError:
    VERSION = None


# ═══════════════════════════════════════════════════════
#  自定义消息
# ═══════════════════════════════════════════════════════

class ServerMsg(Message):
    def __init__(self, data: dict) -> None:
        super().__init__()
        self.data = data


class Disconnected(Message):
    pass


# ═══════════════════════════════════════════════════════
#  LoginScreen
# ═══════════════════════════════════════════════════════

class LoginScreen(Screen):
    BINDINGS = [Binding("escape", "quit", "退出", show=True)]

    def compose(self) -> ComposeResult:
        with Center():
            with Middle():
                with Vertical(id="login-container"):
                    yield Static("游戏大厅", id="login-title")
                    yield Input(placeholder=f"服务器地址 ({DEFAULT_HOST})", id="login-input")
                    yield Static("按 Enter 连接", id="login-status")

    def on_mount(self) -> None:
        pass

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "login-input":
            return
        ip = event.value.strip() or DEFAULT_HOST
        self.query_one("#login-status", Static).update(f"正在连接 {ip}…")
        self.app.connect_to_server(ip)

    def set_status(self, text: str):
        try:
            self.query_one("#login-status", Static).update(text)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════
#  GameScreen — NVim 风格动态窗口
# ═══════════════════════════════════════════════════════

class GameScreen(Screen):
    BINDINGS = [Binding("escape", "enter_normal", "", show=False)]

    def __init__(self, layout_data: dict | None = None, **kw):
        super().__init__(**kw)
        self.logged_in = False
        self.in_mahjong_game = False
        self.current_location = "lobby"
        self.current_room_id = None
        self.need_discard = False
        self._input_buffer = ""
        self._focused_pane_id = ""
        self._which_key = None        # None / "top" / "window" / "modules"
        self._picker_selected = 0     # 模块选择器当前选中
        # 恢复或创建默认布局
        tree = None
        if layout_data:
            tree = deserialize(layout_data)
        if tree is None:
            tree = get_default_layout()
        self._layout_tree = tree

    def compose(self) -> ComposeResult:
        yield Canvas(self._layout_tree, id="canvas")
        with Vertical(id="which-key-wrapper"):
            with Vertical(id="which-key-overlay"):
                yield Static("", id="which-key-content")
        with Horizontal(id="footer-bar"):
            yield Static(" NORMAL ", id="mode-indicator")
            yield Static("大厅", id="location-indicator")
            yield Static("已连接", id="connection-status")

    def on_mount(self) -> None:
        # 聚焦到第一个可输入窗格（cmd 优先）
        panes = all_panes(self._layout_tree)
        focus_id = ""
        for p in panes:
            if p.module == 'cmd':
                focus_id = p.pane_id
                break
        if not focus_id and panes:
            focus_id = panes[0].pane_id
        if focus_id:
            self._set_focused_pane(focus_id)
        # 初始化面板标题
        self._init_panel_titles()
        # 登录阶段自动进入输入模式
        self._enter_insert()

    def _init_panel_titles(self):
        """初始化各模块面板标题"""
        canvas = self.query_one("#canvas", Canvas)
        chat = canvas.get_module_widget('chat')
        if isinstance(chat, ChatPanel):
            chat_pane = self._get_pane_for_module('chat')
            if chat_pane:
                wrapper = canvas.get_pane(chat_pane.pane_id)
                if wrapper:
                    wrapper.border_title = "[b]世界[/b] │ [dim]房间[/]"

    # ── 画布与面板访问 ──

    @property
    def canvas(self) -> Canvas:
        return self.query_one("#canvas", Canvas)

    def _get_module(self, module_name: str):
        """获取指定模块的 Widget 实例"""
        return self.canvas.get_module_widget(module_name)

    def _get_pane_for_module(self, module_name: str) -> PaneNode | None:
        return find_module_pane(self._layout_tree, module_name)

    @property
    def vim(self) -> VimMode:
        return self.app.vim

    # ── 焦点管理 ──

    def _set_focused_pane(self, pane_id: str):
        self._focused_pane_id = pane_id
        canvas = self.canvas
        for p in all_panes(self._layout_tree):
            wrapper = canvas.get_pane(p.pane_id)
            if wrapper:
                if p.pane_id == pane_id:
                    wrapper.add_class("--focused")
                else:
                    wrapper.remove_class("--focused")

    def _focused_module(self) -> str | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        return pane.module if pane else None

    @property
    def _input_target(self) -> str:
        mod = self._focused_module()
        if mod == 'chat':
            return 'chat'
        if mod == 'cmd':
            return 'cmd'
        return ''

    def _can_input(self) -> bool:
        return self._input_target in ('chat', 'cmd')

    # ── 模式切换 ──

    def action_enter_normal(self):
        self._hide_which_key()
        if self.vim.mode == Mode.INSERT:
            self._input_buffer = ""
            self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()
        self.set_focus(None)

    def _enter_insert(self):
        if not self._can_input():
            return
        self._input_buffer = ""
        self.vim.enter_insert()
        self._update_mode_indicator()
        self._show_panel_prompt("")

    def _update_mode_indicator(self):
        indicator = self.query_one("#mode-indicator", Static)
        mode = self.vim.mode
        if mode == Mode.NORMAL:
            indicator.update(" NORMAL ")
        elif mode == Mode.INSERT:
            indicator.update(" INSERT ")

    # ── 面板内输入提示 ──

    def _show_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel)):
            widget.show_prompt(text)

    def _update_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel)):
            widget.update_prompt(text)

    def _hide_panel_prompt(self):
        for mod in ('chat', 'cmd'):
            widget = self._get_module(mod)
            if isinstance(widget, (ChatPanel, CommandPanel)):
                widget.hide_prompt()

    # ── Which-key 菜单（屏幕中央浮动） ──

    def _show_which_key(self, level: str):
        from .tui_layout import MODULE_LABELS, MODULES
        from rich.table import Table
        wrapper = self.query_one("#which-key-wrapper")
        overlay = self.query_one("#which-key-overlay")
        content = self.query_one("#which-key-content", Static)
        table = Table(show_header=False, box=None, padding=(0, 1), expand=True)
        table.add_column(justify="left", no_wrap=True)
        table.add_column(justify="right", no_wrap=True)
        if level == "top":
            overlay.border_title = "菜单"
            table.add_row("[b]e[/b]", "模块")
            table.add_row("[b]w[/b]", "窗口")
            table.add_row("[b]q[/b]", "退出")
        elif level == "window":
            overlay.border_title = "窗口"
            table.add_row("[b]/[/b]", "横分")
            table.add_row("[b]-[/b]", "纵分")
            table.add_row("[b]h[/b]", "←")
            table.add_row("[b]j[/b]", "↓")
            table.add_row("[b]k[/b]", "↑")
            table.add_row("[b]l[/b]", "→")
            table.add_row("[b][ ][/b]", "缩放")
            table.add_row("[b]q[/b]", "关闭")
        elif level == "modules":
            overlay.border_title = "模块"
            for i, mod in enumerate(MODULES):
                label = MODULE_LABELS.get(mod, mod)
                if i == self._picker_selected:
                    table.add_row(f"[reverse] {label} [/]", "")
                else:
                    table.add_row(f"  {label}", "")
            table.add_row("", "")
            table.add_row("[dim]j/k[/dim]", "[dim]选择[/dim]")
            table.add_row("[dim]Enter[/dim]", "[dim]确认[/dim]")
            table.add_row("[dim]Esc[/dim]", "[dim]取消[/dim]")
        content.update(table)
        wrapper.add_class("visible")

    def _hide_which_key(self):
        self._which_key = None
        wrapper = self.query_one("#which-key-wrapper")
        wrapper.remove_class("visible")

    # ── 模块选择确认 ──

    def _picker_confirm(self):
        from .tui_layout import MODULES
        module_name = MODULES[self._picker_selected]
        self._hide_which_key()
        # 如果该模块已在其他窗格打开，把旧窗格清空
        existing = find_module_pane(self._layout_tree, module_name)
        if existing and existing.pane_id != self._focused_pane_id:
            existing.module = None
            old_wrapper = self.canvas.get_pane(existing.pane_id)
            if old_wrapper:
                self.call_later(old_wrapper.set_module, None)
        # 设置当前窗格的模块
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        if pane:
            pane.module = module_name
            wrapper = self.canvas.get_pane(self._focused_pane_id)
            if wrapper:
                self.call_later(wrapper.set_module, module_name)
        self._save_layout()

    # ── 布局操作 ──

    async def _do_split(self, direction: str):
        self._layout_tree = split_pane(self._layout_tree, self._focused_pane_id, direction)
        await self.canvas.rebuild(self._layout_tree)
        self._set_focused_pane(self._focused_pane_id)
        self._save_layout()

    async def _do_close_pane(self):
        panes = all_panes(self._layout_tree)
        if len(panes) <= 1:
            return  # 不关闭最后一个
        # 找到下一个窗格
        ids = [p.pane_id for p in panes]
        idx = ids.index(self._focused_pane_id) if self._focused_pane_id in ids else 0
        next_id = ids[(idx + 1) % len(ids)] if len(ids) > 1 else ""
        if next_id == self._focused_pane_id:
            next_id = ids[(idx - 1) % len(ids)]
        result = close_pane(self._layout_tree, self._focused_pane_id)
        if result is None:
            return
        self._layout_tree = result
        await self.canvas.rebuild(self._layout_tree)
        if next_id:
            self._set_focused_pane(next_id)
        self._save_layout()

    def _resize_focused(self, delta: float):
        """调整当前焦点窗格的权重"""
        if resize_pane(self._layout_tree, self._focused_pane_id, delta):
            self.call_later(self.canvas.rebuild, self._layout_tree)
            self._save_layout()

    def _save_layout(self):
        """序列化布局并发送到服务端保存"""
        if not self.logged_in:
            return
        layout_data = serialize(self._layout_tree)
        self.app.network.send({"type": "save_layout", "layout": layout_data})

    def _update_location(self, location: str):
        self.current_location = location
        indicator = self.query_one("#location-indicator", Static)
        info_table = self._get_module('info_table')
        if isinstance(info_table, InfoTablePanel):
            info_table.set_location(location)
        loc_names = {
            "lobby": "大厅", "mahjong": "麻将",
            "mahjong_room": "麻将房间", "mahjong_playing": "麻将对局",
            "chess": "象棋", "chess_room": "象棋房间",
            "chess_playing": "象棋对局", "jrpg": "JRPG",
        }
        indicator.update(loc_names.get(location, location))

    # ── 键位处理 ──

    def on_key(self, event) -> None:
        vim = self.vim

        # ── INSERT 模式 ──
        if vim.mode == Mode.INSERT:
            event.prevent_default()
            event.stop()

            if event.key == "escape":
                self.action_enter_normal()
            elif event.key == "enter":
                self._submit_input()
            elif event.key == "backspace":
                self._input_buffer = self._input_buffer[:-1]
                self._update_panel_prompt(self._input_buffer)
            elif event.key == "space":
                self._input_buffer += " "
                self._update_panel_prompt(self._input_buffer)
            else:
                ch = event.character
                if ch and ch.isprintable():
                    self._input_buffer += ch
                    self._update_panel_prompt(self._input_buffer)
            return

        # ── NORMAL 模式 ──
        event.prevent_default()
        event.stop()
        key = event.key

        # 前缀键
        if vim.pending_key == "g":
            vim.pending_key = ""
            if key == "g":
                self._scroll_focused_top()
            return

        if vim.pending_key == "d":
            vim.pending_key = ""
            ch = event.character
            if ch and ch.isprintable():
                self._discard_tile(ch)
            return

        # which-key 菜单
        if self._which_key is not None:
            if key == "escape":
                self._hide_which_key()
            elif self._which_key == "top":
                if key == "e":
                    self._which_key = "modules"
                    self._picker_selected = 0
                    self._show_which_key("modules")
                elif key == "w":
                    self._which_key = "window"
                    self._show_which_key("window")
                elif key == "q":
                    self._hide_which_key()
                    self._send_command("/back")
                else:
                    self._hide_which_key()
            elif self._which_key == "modules":
                from .tui_layout import MODULES
                if key == "j":
                    self._picker_selected = (self._picker_selected + 1) % len(MODULES)
                    self._show_which_key("modules")
                elif key == "k":
                    self._picker_selected = (self._picker_selected - 1) % len(MODULES)
                    self._show_which_key("modules")
                elif key == "enter":
                    self._picker_confirm()
                else:
                    self._hide_which_key()
            elif self._which_key == "window":
                self._hide_which_key()
                if key == "slash":
                    self.call_later(self._do_split, 'h')
                elif key == "minus":
                    self.call_later(self._do_split, 'v')
                elif key in ("h", "j", "k", "l"):
                    new_id = navigate(self._layout_tree, self._focused_pane_id, key)
                    self._set_focused_pane(new_id)
                elif key == "q":
                    self.call_later(self._do_close_pane)
            return

        # 单键
        if key == "space":
            self._which_key = "top"
            self._show_which_key("top")
        elif key == "i":
            self._enter_insert()
        elif key == "j":
            self._scroll_focused_down()
        elif key == "k":
            self._scroll_focused_up()
        elif key == "G":
            self._scroll_focused_bottom()
        elif key == "g":
            vim.pending_key = "g"
        elif key == "d":
            if self.need_discard:
                vim.pending_key = "d"
        elif key == "q":
            self._send_command("/back")
        elif key == "tab":
            self._cycle_channel()
        elif key == "right_square_bracket":
            self._resize_focused(0.25)
        elif key == "left_square_bracket":
            self._resize_focused(-0.25)
        elif event.character and event.character.isdigit() and event.character != "0":
            self._send_command(f"/{event.character}")

    # ── 输入提交 ──

    def _submit_input(self):
        text = self._input_buffer.strip()
        self._input_buffer = ""
        self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()

        if not text:
            return

        if self._input_target == "chat":
            chat = self._get_module('chat')
            ch = chat.current_channel if isinstance(chat, ChatPanel) else 1
            self._send_chat(text, ch)
        else:
            if not self.logged_in:
                self._send_command(text)
            else:
                if not text.startswith("/"):
                    text = "/" + text
                self._send_command(text)
        if not self.logged_in:
            self._enter_insert()

    # ── 滚动 ──

    def _get_focused_log(self) -> RichLog | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        if not pane or not pane.module:
            return None
        widget = self._get_module(pane.module)
        if widget is None:
            return None
        # 找到该 widget 内的 RichLog
        try:
            logs = widget.query(RichLog)
            return logs.first() if logs else None
        except Exception:
            return None

    def _scroll_focused_down(self):
        log = self._get_focused_log()
        if log:
            log.scroll_down(animate=False)

    def _scroll_focused_up(self):
        log = self._get_focused_log()
        if log:
            log.scroll_up(animate=False)

    def _scroll_focused_bottom(self):
        log = self._get_focused_log()
        if log:
            log.scroll_end(animate=False)

    def _scroll_focused_top(self):
        log = self._get_focused_log()
        if log:
            log.scroll_home(animate=False)

    # ── 指令发送 ──

    def _send_command(self, text: str):
        self.app.send_command(text)

    def _send_chat(self, text: str, channel: int):
        self.app.send_chat(text, channel)

    def _discard_tile(self, tile_name: str):
        self._send_command(f"/d {tile_name}")

    def _cycle_channel(self):
        chat = self._get_module('chat')
        if not isinstance(chat, ChatPanel):
            return
        ch = chat.current_channel
        new_ch = 2 if ch == 1 else 1
        chat.switch_channel(new_ch)
        self.app.switch_channel(new_ch)

    # ── 操作提示 ──

    def show_action_prompt(self, actions: dict, tile: str, from_player: str):
        parts = []
        idx = 1
        for action_name, label in [("ron", "荣和"), ("pon", "碰"), ("kan", "杠")]:
            if action_name in actions:
                parts.append(f"[{idx}]{label}")
                idx += 1
        if "chi" in actions:
            chi_opts = actions["chi"]
            if isinstance(chi_opts, list):
                for c in chi_opts:
                    parts.append(f"[{idx}]吃{c}")
                    idx += 1
            else:
                parts.append(f"[{idx}]吃")
                idx += 1
        parts.append(f"[{idx}]跳过")
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.set_action_bar(f"{from_player}打出 {tile}: {' '.join(parts)}")

    def show_self_action_prompt(self, actions: dict):
        parts = []
        idx = 1
        if "tsumo" in actions:
            parts.append(f"[{idx}]自摸"); idx += 1
        if "riichi" in actions:
            parts.append(f"[{idx}]立直"); idx += 1
        if "ankan" in actions:
            for tiles in actions["ankan"]:
                parts.append(f"[{idx}]暗杠{tiles}"); idx += 1
        if "kakan" in actions:
            for tile in actions["kakan"]:
                parts.append(f"[{idx}]加杠{tile}"); idx += 1
        parts.append(f"[{idx}]跳过")
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.set_action_bar(" ".join(parts))


# ═══════════════════════════════════════════════════════
#  GameLobbyApp — 主应用
# ═══════════════════════════════════════════════════════


class GameLobbyApp(App):
    """游戏大厅 TUI 客户端"""

    TITLE = "游戏大厅"
    CSS_PATH = "theme.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "退出", show=True, priority=True),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.network = NetworkManager(PORT)
        self.vim = VimMode()
        self.player_data: dict = {}
        self._pending_messages: list[dict] = []
        self._current_channel = 1
        self._saved_layout: dict | None = None

    def on_mount(self) -> None:
        self.push_screen(LoginScreen())

    # ── 网络 ──

    def connect_to_server(self, ip: str):
        """从 LoginScreen 调用，建立连接"""
        try:
            self.network.connect(ip)
        except Exception as e:
            screen = self.screen
            if isinstance(screen, LoginScreen):
                screen.set_status(f"连接失败: {e}")
            return

        self.network.disconnect_callback = self._on_disconnect
        self._start_receive_worker()

        # 切换到游戏界面
        self.switch_screen(GameScreen(layout_data=self._saved_layout))

        # 处理缓冲消息
        for msg in self._pending_messages:
            self.post_message(ServerMsg(msg))
        self._pending_messages.clear()

    @work(thread=True)
    def _start_receive_worker(self):
        """后台线程：接收服务器消息并投递到事件循环"""
        buffer = ""
        import json
        while self.network.connected:
            try:
                data = self.network.socket.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    msg_str, buffer = buffer.split("\n", 1)
                    if msg_str:
                        try:
                            msg = json.loads(msg_str)
                            self.post_message(ServerMsg(msg))
                        except Exception:
                            pass
            except Exception:
                break

        self.network.connected = False
        self.post_message(Disconnected())

    def _on_disconnect(self):
        self.post_message(Disconnected())

    def on_disconnected(self, _msg: Disconnected) -> None:
        """处理连接断开"""
        screen = self.screen
        if isinstance(screen, GameScreen):
            cmd = screen._get_module('cmd')
            if isinstance(cmd, CommandPanel):
                cmd.add_message("[dim]连接已断开[/]")
            try:
                conn = screen.query_one("#connection-status", Static)
                conn.update("已断开")
            except Exception:
                pass

    # ── 消息处理 ──

    def on_server_msg(self, event: ServerMsg) -> None:
        """统一处理服务器消息"""
        screen = self.screen
        if not isinstance(screen, GameScreen):
            self._pending_messages.append(event.data)
            return

        parsed = parse_server_message(event.data)
        gs = screen

        # 获取模块的便捷方法
        def _chat() -> ChatPanel | None:
            w = gs._get_module('chat')
            return w if isinstance(w, ChatPanel) else None

        def _cmd() -> CommandPanel | None:
            w = gs._get_module('cmd')
            return w if isinstance(w, CommandPanel) else None

        def _info() -> InfoTablePanel | None:
            w = gs._get_module('info_table')
            return w if isinstance(w, InfoTablePanel) else None

        def _game() -> InfoGamePanel | None:
            w = gs._get_module('game')
            return w if isinstance(w, InfoGamePanel) else None

        def _online() -> OnlineUsersPanel | None:
            w = gs._get_module('online')
            return w if isinstance(w, OnlineUsersPanel) else None

        if isinstance(parsed, LoginPrompt):
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)

        elif isinstance(parsed, RequestAvatar):
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)
                cmd.add_message("[dim]（TUI 模式下暂不支持编辑头像，跳过）[/]")

        elif isinstance(parsed, LoginSuccess):
            gs.logged_in = True
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text)
            gs.action_enter_normal()

        elif isinstance(parsed, SystemMessage):
            chat = _chat()
            if chat:
                chat.add_system_message(parsed.text)

        elif isinstance(parsed, GameMessage):
            cmd = _cmd()
            if cmd:
                cmd.add_message(parsed.text, update_last=parsed.update_last)
            if parsed.clear_discard:
                gs.need_discard = False

        elif isinstance(parsed, ChatMessage):
            chat = _chat()
            if chat:
                chat.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)

        elif isinstance(parsed, ChatHistory):
            chat = _chat()
            if chat:
                chat.show_history(parsed.messages, parsed.channel)

        elif isinstance(parsed, StatusUpdate):
            self.player_data = parsed.data
            # 保存布局数据
            layout_data = parsed.data.get('window_layout')
            if layout_data:
                self._saved_layout = layout_data
            info = _info()
            if info:
                info.update_status(parsed.data)
            if parsed.map_data and info:
                info.update_map(parsed.map_data)

        elif isinstance(parsed, OnlineUsers):
            chat = _chat()
            if chat:
                chat.update_online_users(parsed.users)
            online = _online()
            if online:
                online.update_users(parsed.users)

        elif isinstance(parsed, GameInvite):
            inv = parsed.raw
            cmd = _cmd()
            if cmd:
                cmd.add_message(
                    f"[b]游戏邀请[/b]: {inv.get('from', '?')} 邀请你加入 {inv.get('game', '?')}"
                )

        elif isinstance(parsed, RoomUpdate):
            if parsed.room_data:
                info = _info()
                if info:
                    info.update_table(parsed.room_data)
                room_id = parsed.room_data.get("room_id")
                if room_id:
                    gs.current_room_id = room_id
                game_type = parsed.room_data.get("game_type", "mahjong")
                state = parsed.room_data.get("state", "waiting")
                if game_type == "mahjong":
                    gs.in_mahjong_game = state == "playing"
            if parsed.message:
                cmd = _cmd()
                if cmd:
                    cmd.add_message(parsed.message)

        elif isinstance(parsed, (RoomLeave, GameQuit)):
            info = _info()
            if info:
                info.update_table(None)
            game = _game()
            if game:
                game.clear_hand()
            gs.in_mahjong_game = False
            gs.current_room_id = None
            if parsed.location:
                gs._update_location(parsed.location)

        elif isinstance(parsed, LocationUpdate):
            gs._update_location(parsed.location)

        elif isinstance(parsed, HandUpdate):
            game = _game()
            if game:
                game.update_hand(
                    parsed.hand, parsed.drawn, parsed.tenpai_analysis, parsed.need_discard
                )
            gs.need_discard = parsed.need_discard

        elif isinstance(parsed, ActionPrompt):
            gs.show_action_prompt(parsed.actions, parsed.tile, parsed.from_player)

        elif isinstance(parsed, SelfActionPrompt):
            gs.show_self_action_prompt(parsed.actions)

        elif isinstance(parsed, WinAnimation):
            self._show_win_animation(gs, parsed)

        elif isinstance(parsed, ActionCommand):
            action = parsed.action
            if action == "clear":
                cmd = _cmd()
                if cmd:
                    cmd.clear()
            elif action == "version":
                sv = parsed.raw.get("server_version", "未知")
                cv = VERSION or "开发版"
                cmd = _cmd()
                if cmd:
                    cmd.add_message(f"版本信息\n客户端: v{cv}\n服务器: v{sv}")
            elif action == "exit":
                self.network.disconnect()
                self.exit()
            elif action == "maintenance":
                cmd = _cmd()
                if cmd:
                    cmd.add_message("[b]系统维护[/b]: 服务器正在维护，请稍后重连。")
                self.network.disconnect()

    def _show_win_animation(self, gs: GameScreen, w: WinAnimation):
        cmd = gs._get_module('cmd')
        if not isinstance(cmd, CommandPanel):
            return
        if w.win_type == "tsumo":
            header = f"[b]【{w.winner} 自摸】[/b] [{w.tile}]"
        else:
            header = f"[b]【{w.winner} 荣和】[/b] [{w.tile}]"
            if w.loser:
                header += f" (放铳: {w.loser})"
        cmd.add_message(header)

        delay = 0.8
        for i, yaku in enumerate(w.yakus):
            yaku_name = yaku[0]
            yaku_han = yaku[1]
            is_yakuman = yaku[2] if len(yaku) > 2 else False
            if is_yakuman:
                text = f"  ★ {yaku_name} (役满)"
            else:
                text = f"  · {yaku_name} ({yaku_han}番)"
            self.set_timer(delay * (i + 1), lambda t=text: self._add_to_cmd(t))

        final_delay = delay * (len(w.yakus) + 1)
        if w.is_yakuman:
            score_text = f"\n[b]【点数】役满 {w.score}点[/b]"
        else:
            score_text = f"\n[b]【点数】{w.han}番{w.fu}符 = {w.score}点[/b]"

        self.set_timer(final_delay, lambda: self._add_to_cmd(score_text))
        self.set_timer(
            final_delay + 0.4,
            lambda: self._add_to_cmd("\n输入 /next 开始下一局"),
        )

    def _add_to_cmd(self, text: str):
        screen = self.screen
        if isinstance(screen, GameScreen):
            cmd = screen._get_module('cmd')
            if isinstance(cmd, CommandPanel):
                cmd.add_message(text)

    # ── 发送 ──

    def send_command(self, text: str):
        self.network.send({"type": "command", "text": text})

    def send_chat(self, text: str, channel: int):
        self.network.send({"type": "chat", "text": text, "channel": channel})

    def switch_channel(self, channel_id: int):
        self._current_channel = channel_id
        self.network.send({"type": "switch_channel", "channel": channel_id})

    # ── 退出 ──

    def action_quit(self) -> None:
        self.network.disconnect()
        self.exit()


def _check_version() -> bool:
    """检查是否最新版，返回 True 表示可以启动"""
    import json
    import urllib.request
    current = VERSION or "0.0.0"
    print(f"gamelobby v{current}")
    print("正在检查更新...")
    try:
        req = urllib.request.Request(
            "https://pypi.org/pypi/gamelobby/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            latest = json.loads(resp.read().decode())["info"]["version"]
        cur = tuple(int(x) for x in current.split("."))
        lat = tuple(int(x) for x in latest.split("."))
        if lat > cur:
            print(f"\n发现新版本 v{latest}（当前 v{current}）")
            choice = input("是否立即更新？(y/N): ").strip().lower()
            if choice == 'y':
                import subprocess
                import sys
                print("正在更新...")
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--upgrade", "gamelobby"],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    print("更新完成！正在重启...\n")
                    import os
                    os.execv(sys.executable, [sys.executable, "-m", "client"])
                else:
                    print(f"更新失败：{result.stderr.strip()}")
                    print("请手动运行：pip install --upgrade gamelobby\n")
                return False
            else:
                print("已跳过更新。\n")
                return False
    except Exception:
        print("\n网络不可用，无法连接服务器。")
        print("请检查网络连接后重试。\n")
        return False
    return True


def main():
    """CLI 入口点"""
    if not _check_version():
        return
    app = GameLobbyApp()
    app.run()
