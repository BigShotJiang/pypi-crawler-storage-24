"""Scoring result internals."""

