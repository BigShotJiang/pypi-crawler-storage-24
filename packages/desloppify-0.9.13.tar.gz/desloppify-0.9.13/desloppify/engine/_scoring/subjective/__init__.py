"""Subjective scoring internals."""

