"""Resolve command package."""
