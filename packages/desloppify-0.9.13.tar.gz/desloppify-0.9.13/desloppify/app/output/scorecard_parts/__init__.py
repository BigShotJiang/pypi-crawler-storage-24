"""Scorecard rendering package."""
