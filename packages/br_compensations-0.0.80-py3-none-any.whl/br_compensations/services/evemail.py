from dateutil import parser
from typing import List, Dict, Any, Optional
from django.core.cache import cache
from ..utils.eveonline import EveCharacterUtils
from allianceauth.services.hooks import get_extension_logger
from allianceauth import __version__, __title_useragent__, __url__
from esi.errors import TokenExpiredError, TokenInvalidError
from esi.models import Token

logger = get_extension_logger(__name__)

class EveMailService:
    """Сервис для работы с почтой персонажа EVE Online через ESI API"""
    
    REQUIRED_SCOPES = ['esi-mail.read_mail.v1']
    CACHE_TIMEOUT = 30  # 30 секунд для кэширования списка писем
    
    @classmethod
    def get_character_mail_list(cls, character_id: int, token: Token, last_mail_id:int = None) -> List[Dict[str, Any]]:
        """
        Получить список писем персонажа (только метаданные, без содержимого).
        
        Args:
            character_id: ID персонажа
            token: Токен авторизации
            
        Returns:
            Список писем с метаданными
        """
        try:
            # Проверяем кэш
            cache_key = f'mail_list_{character_id}'
            cached_mails = cache.get(cache_key)
            
            if cached_mails is not None:
                logger.debug(f'Использован кэш для списка писем персонажа {character_id}')
                return cached_mails
            
            # Получаем ESI клиент с автоматическим обновлением токена
            client = token.get_esi_client(spec_file=None)
            
            # Запрашиваем список писем
            mail_list = client.Mail.get_characters_character_id_mail(
                character_id=character_id,
            ).result()
            
            # Сохраняем в кэш
            cache.set(cache_key, mail_list, cls.CACHE_TIMEOUT)
            
            logger.info(f'Получено {len(mail_list)} писем для персонажа {character_id}')
            
            if not last_mail_id == None:
                mail_list = [ mail for mail in mail_list if mail['mail_id'] > last_mail_id ]
            
            return mail_list
            
        except TokenExpiredError as e:
            logger.warning(
                f'Токен пользователя {character_id} просрочен или недействителен. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO с скоупом esi-mail.read_mail.v1. '
                f'Ошибка: {e}'
            )
            return []
        except TokenInvalidError as e:
            logger.warning(
                f'Некорректный токен пользователя {character_id}. '
                f'Токен был отозван или имеет недействительный refresh token. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO. '
                f'Ошибка: {e}'
            )
            return []
        except Exception as e:
            logger.error(f'Ошибка при получении списка писем для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_mail_content(cls, character_id: int, mail_id: int, token: Token) -> Optional[Dict[str, Any]]:
        """
        Получить содержимое конкретного письма.
        
        Args:
            character_id: ID персонажа
            mail_id: ID письма
            token: Токен авторизации
            
        Returns:
            Словарь с содержимым письма включая body
        """
        try:
            # Проверяем кэш
            cache_key = f'mail_content_{character_id}_{mail_id}'
            cached_mail = cache.get(cache_key)
            
            if cached_mail is not None:
                logger.debug(f'Использован кэш для письма {mail_id} персонажа {character_id}')
                return cached_mail
            
            # Получаем ESI клиент с автоматическим обновлением токена
            client = token.get_esi_client(spec_file=None)
            
            # Запрашиваем содержимое письма
            mail_content = client.Mail.get_characters_character_id_mail_mail_id(
                character_id=character_id,
                mail_id=mail_id
            ).result()
            
            # Сохраняем в кэш
            cache.set(cache_key, mail_content, cls.CACHE_TIMEOUT * 2)
            
            logger.debug(f'Получено содержимое письма {mail_id} для персонажа {character_id}')
            return mail_content
            
        except TokenExpiredError as e:
            logger.warning(
                f'Токен пользователя {character_id} просрочен или недействителен. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO с скоупом esi-mail.read_mail.v1. '
                f'Ошибка: {e}'
            )
            return None
        except TokenInvalidError as e:
            logger.warning(
                f'Некорректный токен пользователя {character_id}. '
                f'Токен был отозван или имеет недействительный refresh token. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO. '
                f'Ошибка: {e}'
            )
            return None
        except Exception as e:
            logger.error(f'Ошибка при получении письма {mail_id} для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_all_mails_with_content(
        cls,
        character_id: int,
        token: Token,
        limit: int = 50,
        last_mail_id: int = None,
        unread_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Получить все письма с содержимым.
        
        Args:
            character_id: ID персонажа
            token: Токен авторизации
            limit: Максимальное количество писем для загрузки
            unread_only: Загружать только непрочитанные письма
            
        Returns:
            Список писем с полным содержимым
        """
        try:
            # Получаем список писем
            mail_list = cls.get_character_mail_list(character_id, token, last_mail_id)
            
            if not mail_list:
                return []
            
            # Фильтруем по is_read если нужно
            if unread_only:
                mail_list = [mail for mail in mail_list if not mail.get('is_read', False)]
            
            # Ограничиваем количество
            mail_list = mail_list[:limit]
            
            # Получаем содержимое для каждого письма
            mails_with_content = []
            for mail in mail_list:
                mail_id = mail.get('mail_id')
                if mail_id:
                    mail_content = cls.get_mail_content(character_id, mail_id, token)
                    if mail_content:
                        # Объединяем метаданные и содержимое
                        mail_with_content = {**mail, **mail_content}
                        mails_with_content.append(mail_with_content)
            
            logger.info(f'Получено {len(mails_with_content)} писем с содержимым для персонажа {character_id}')
            return mails_with_content
            
        except Exception as e:
            logger.error(f'Ошибка при получении писем с содержимым для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_character_mails(
        cls,
        character_id: int,
        limit: int = 50,
        last_mail_id: int = None,
        unread_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Получить письма персонажа (автоматически находит токен).
        
        Args:
            character_id: ID персонажа
            limit: Максимальное количество писем для загрузки
            unread_only: Загружать только непрочитанные письма
            
        Returns:
            Список писем с полным содержимым или пустой список при ошибке
        """
        try:
            # Получаем токен
            token = EveCharacterUtils.get_token_for_character(character_id,cls.REQUIRED_SCOPES)
            
            if not token:
                logger.warning(f'Не найден токен для персонажа {character_id} или токен не имеет нужных скоупов')
                return []
            
            # Получаем письма с содержимым
            return cls.get_all_mails_with_content(
                character_id=character_id,
                token=token,
                limit=limit,
                unread_only=unread_only,
                last_mail_id=last_mail_id
            )
            
        except Exception as e:
            logger.error(f'Ошибка при получении писем для персонажа {character_id}: {e}')
            return []


