from typing import Any, Dict
from esi.clients import EsiClientProvider
from django.core.cache import cache
from eveuniverse.models import EveEntity
from allianceauth.services.hooks import get_extension_logger
from allianceauth import __version__, __title_useragent__, __url__

logger = get_extension_logger(__name__)

esi = EsiClientProvider()

class EveUniverseSearchService:
    """Сервис для поиска сущностей в EVE Universe через ESI"""
    
    CACHE_TIMEOUT = 300  # 5 минут
    
    @classmethod
    def search_by_name(cls, name: str) -> Dict[str, Any]:
        """Поиск сущности по имени (использует локальную базу данных)"""
        cache_key = f"local_search_{name}"
        cached_result = cache.get(cache_key)
        if cached_result is not None:
            return cached_result
        
        try:
            # Поиск в локальной базе данных
            entities = EveEntity.objects.filter(name__icontains=name)[:50]
            
            formatted_result = [
                    {'id': e.id, 'name': e.name, 'type': e.category} 
                    for e in entities
                ]
            
            cache.set(cache_key, formatted_result, cls.CACHE_TIMEOUT)
            return formatted_result
        except Exception as e:
            logger.error(f"Ошибка при поиске: {e}")
            return []
 