from django.db import models
from django.utils.translation import gettext_lazy as _

# Create your models here.
class FilterEntity(models.Model):
    '''
        Таблица для хранения данных фильтров киллмэйлов
    '''
    ALLIANCE = 'alliance'
    CORPORATION = 'corporation'
    CHARACTER = 'character'
    ENTITY_TYPE_CHOICE = [
        (ALLIANCE,'Alliance'),
        (CORPORATION,'Corporation'),
        (CHARACTER,'Character')
    ]
    
    entity_type = models.CharField(max_length=20, choices=ENTITY_TYPE_CHOICE)
    entity_id = models.IntegerField(
        name='entity_id',
        null=False,
        blank=False,
        unique=True
    )
    added_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['entity_type']),
        ]
        unique_together = [('entity_type', 'entity_id')]
    def __str__(self):
        if self.entity_type == self.ALLIANCE:
            return f"Alliance: {self.entity_id}"
        elif self.entity_type == self.CORPORATION:
            return f"Corporation: {self.entity_id}"
        return f"Character: {self.entity_id}"