from django.db import models
from django.utils.translation import gettext_lazy as _

class CharMailParse(models.Model):
    '''
        Таблица для хранения списка персонажей, чью почту будет обрабатывать автомат и искать киллмеэлы
    '''
    character_id = models.PositiveBigIntegerField(null=False)
    lastmail_id = models.PositiveBigIntegerField(null=True,blank=True)
    updated_at = models.DateTimeField(null=True,blank=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['character_id'])
        ]