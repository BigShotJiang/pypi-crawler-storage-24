from typing import List

from allianceauth.eveonline.models import EveCharacter
from .eveonline import EveCharacterUtils
from allianceauth.services.hooks import get_extension_logger


logger = get_extension_logger(__name__)

class IngameMail:
    #'esi-ui.open_window.v1'
    @classmethod
    def send_mail(self,sender:EveCharacter, to:list[int], subject:str, body:str):
        token = EveCharacterUtils.get_token_for_character(sender.character_id, ['esi-mail.send_mail.v1'])
        if token is None:
            return
        client = token.get_esi_client()
        try:
            # Создаем список получателей в формате, ожидаемом ESI API
            recipients = []
            # recipients.append({
            #     'recipient_id': 2121985292,
            #      'recipient_type': 'character'
            # })
            for recipient_id in to:
                recipients.append({
                    'recipient_id': recipient_id,
                    'recipient_type': 'character'
                })
            
            # Создаем запрос в формате словаря, который может быть маршализован bravado
            request = {
                'subject': subject,
                'body': body,
                'recipients': recipients,
                'approved_cost': 0
            }
            
            # Передаем character_id как параметр, а mail как словарь
            client.Mail.post_characters_character_id_mail(
                character_id=sender.character_id,
                mail=request
            ).result()
        except Exception as e:
            logger.error(e)
        pass
    
    @classmethod
    def create_mail(self,sender:EveCharacter, to:list[int], subject:str, body:str):
        token = EveCharacterUtils.get_token_for_character(sender.character_id, ['esi-ui.open_window.v1'])
        if token is None:
            logger.warning(f"Токен не найден для персонажа {sender.character_id}")
            return
        
        client = token.get_esi_client()
        
        try:
            # Создаем запрос в формате словаря
            request = {
                'subject': subject,
                'body': body,
                'recipients': to,
                'to_corp_or_alliance_id': 0,
                'to_mailing_list_id': 0
            }
            
            # Логируем параметры запроса
            logger.info(f"Запрос на открытие окна письма: subject='{subject}', recipients={to}, character_id={sender.character_id}")
            
            # Выполняем запрос и получаем результат
            result = client.User_Interface.post_ui_openwindow_newmail(
                new_mail=request
            ).result()
            
            # Логируем успешный результат
            logger.info(f"Окно письма успешно открыто для персонажа {sender.character_id}")
            
        except Exception as e:
            logger.error(f"Ошибка при открытии окна письма для персонажа {sender.character_id}: {e}")