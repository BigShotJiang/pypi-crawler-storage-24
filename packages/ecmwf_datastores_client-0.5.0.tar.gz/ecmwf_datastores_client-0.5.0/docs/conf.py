# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Import and path setup ---------------------------------------------------

import os
import sys

import ecmwf.datastores

sys.path.insert(0, os.path.abspath("../"))

# -- Project information -----------------------------------------------------

project = "ecmwf.datastores"
copyright = "2022, European Union"
author = "European Union"
version = ecmwf.datastores.__version__
release = ecmwf.datastores.__version__

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "autoapi.extension",
    "myst_parser",
    "nbsphinx",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
]

# autodoc configuration
autodoc_typehints = "none"

# autoapi configuration
autoapi_add_toctree_entry = False
autoapi_dirs = ["../ecmwf/datastores"]
autoapi_ignore = ["*/version.py"]
autoapi_member_order = "groupwise"
autoapi_options = [
    "members",
    "inherited-members",
    # "undoc-members",
    "show-inheritance",
    "show-module-summary",
    "imported-members",
]
autoapi_own_page_level = "class"
autoapi_root = "_api"

# napoleon configuration
napoleon_google_docstring = False
napoleon_numpy_docstring = True
napoleon_preprocess_types = True

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = "pydata_sphinx_theme"

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ["_static"]
