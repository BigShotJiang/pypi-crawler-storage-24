from .tomledit import *

__doc__ = tomledit.__doc__
if hasattr(tomledit, "__all__"):
    __all__ = tomledit.__all__