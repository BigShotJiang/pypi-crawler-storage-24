"""Tests for Socratic Knowledge."""
