"""Anomaly utilities."""
