"""Analysis utilities."""
