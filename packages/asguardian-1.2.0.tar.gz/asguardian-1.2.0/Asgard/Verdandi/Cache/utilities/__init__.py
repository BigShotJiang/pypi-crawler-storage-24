"""Cache utilities."""
