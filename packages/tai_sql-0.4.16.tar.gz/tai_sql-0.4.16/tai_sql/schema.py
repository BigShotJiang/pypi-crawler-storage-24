"""
Gestor de base de datos con funcionalidad de carga de schema integrada.
"""
from __future__ import annotations
import sys
import warnings
import importlib.util
from pathlib import Path
from typing import Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from .generators import BaseGenerator
    from .core import Provider
    from .orm import Table, View, Enum

class SchemaManager:
    """
    Gestor de base de datos con funcionalidad de carga de schema integrada.
    Cada instancia maneja un schema específico.
    """
    
    def __init__(self, schema_name: str, schema_path: Optional[Path] = None):
        """
        Inicializa el gestor de base de datos para un schema específico
        
        Args:
            schema_name: Nombre identificador del schema
            schema_path: Ruta al archivo de schema (opcional, se resuelve automáticamente)
        """
        self.schema_name = schema_name
        self.schema_path = schema_path
        self._provider = None
        self.secret_key_name = 'SECRET_KEY'
        self._operative_fields = False
        self._generators = []
        self._tables = None
        self._views = None
        self._enums = None
        self._loaded = False
        self._validated = False
        self._loaded_module = None  # Almacenar el módulo cargado
        
        # Backup/Restore
        self._backup_storage = None  # tai_storage Origin
        self._backup_format = 'custom'
        self._backup_retention = None  # None = sin rotación
        self._restore_provider = None  # Provider destino para restore
    
    @property
    def loaded(self) -> bool:
        return self._loaded
    
    @property
    def provider(self) -> Optional[Provider]:
        """Proveedor de la base de datos"""
        return self._provider
    
    @provider.setter
    def provider(self, value: Provider):
        """Establece el proveedor de la base de datos"""
        self._provider = value
    
    @property
    def backup_storage(self):
        """Origin de tai-storage para almacenar backups"""
        if self._backup_storage is None:
            from tai_storage import StorageFactory
            from tai_alphi import Alphi
            Alphi.configure_logger('tai-storage', {'consola': {'log_level': 'ERROR'}})
            root_path = f'.database_backups/{self.schema_name}'
            self._backup_storage = StorageFactory.create_local(root_path=root_path)
        return self._backup_storage
    
    @backup_storage.setter
    def backup_storage(self, value):
        """Establece el origin de tai-storage para backups"""
        self._backup_storage = value
    
    @property
    def backup_format(self) -> str:
        """Formato de backup: 'custom' (binario) o 'sql' (texto plano)"""
        return self._backup_format
    
    @backup_format.setter
    def backup_format(self, value: str):
        if value not in ('custom', 'sql'):
            raise ValueError(f"Formato de backup no válido: '{value}'. Usa 'custom' o 'sql'")
        self._backup_format = value
    
    @property
    def backup_retention(self) -> Optional[int]:
        """Número máximo de backups a retener (None = sin límite)"""
        return self._backup_retention
    
    @backup_retention.setter
    def backup_retention(self, value: Optional[int]):
        self._backup_retention = value

    @property
    def restore_provider(self):
        """Provider destino para restore. Si no se configura, usa el mismo provider."""
        return self._restore_provider or self.provider

    @restore_provider.setter
    def restore_provider(self, value):
        """Establece el provider destino para restore."""
        self._restore_provider = value

    @property
    def operative_fields(self) -> bool:
        """Indica si se deben generar campos operativos (created_at, updated_at)"""
        return self._operative_fields
    
    @operative_fields.setter
    def operative_fields(self, value: bool):
        """Establece si se deben generar campos operativos (created_at, updated_at)"""
        self._operative_fields = value
    
    @property
    def generators(self) -> List[BaseGenerator]:
        """Lista de generadores configurados"""
        return self._generators
    
    @generators.setter
    def generators(self, value: List[BaseGenerator]):
        """Establece la lista de generadores"""
        self._generators = value
    
    @property
    def tables(self) -> List[Table]:
        """Lista de tablas definidas por el usuario"""
        if not self._tables:
            from .orm import Table
            self._tables = Table.get_models()
        return self._tables
    
    @property
    def views(self) -> List[View]:
        """Lista de vistas definidas por el usuario"""
        if not self._views:
            from .orm import View
            self._views = View.get_models()
        return self._views
    
    @property
    def enums(self) -> List[Enum]:
        """Lista de enumeraciones definidas por el usuario"""
        if not self._enums:
            from .orm import Enum
            self._enums = Enum.get_registered_enums()
        return self._enums
    
    @property
    def is_loaded(self) -> bool:
        """Indica si el schema ha sido cargado"""
        return self._loaded
    
    @property
    def loaded_module(self):
        """Obtiene el módulo cargado"""
        return self._loaded_module
    
    def load(self) -> None:
        """
        Carga el módulo del schema. Integra funcionalidad de SchemaFile.
        """
        if self.loaded:
            return
        
        if not self.schema_path:
            raise ValueError(f"No se ha especificado schema_path para {self.schema_name}")
        
        if not self.schema_path.exists():
            raise FileNotFoundError(f"El archivo de schema {self.schema_path} no existe")
        
        try:
            from .orm.base import DatabaseObject
            DatabaseObject.registry.clear()  # Limpiar registro previo
            
            # Crear nombre de módulo único para evitar conflictos
            module_name = f"tai_sql_schema_{self.schema_name}"
            
            # Limpiar módulo previo si existe
            if module_name in sys.modules:
                del sys.modules[module_name]
            
            spec = importlib.util.spec_from_file_location(module_name, self.schema_path)
            if spec is None:
                raise ImportError(f"No se pudo cargar el archivo de esquema: {self.schema_path}")
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            
            self._loaded = True
            self._loaded_module = module  # Almacenar el módulo cargado
            
        except Exception as e:
            raise RuntimeError(f"Error al cargar el schema '{self.schema_name}': {e}")
    
    def validations(self) -> None:
        """
        Ejecuta validaciones del schema cargado. Integra funcionalidad de SchemaFile.
        
        Raises:
            RuntimeError: Si el schema no ha sido cargado
            ValueError: Si falta el proveedor, engine o nombre de base de datos
        """
        if self._validated:
            return
        
        if not self.loaded:
            raise RuntimeError(f"El schema '{self.schema_name}' no ha sido cargado")
        
        if not self.provider:
            raise ValueError(
                f"No se ha configurado un proveedor de datos en {self.schema_path}. "
                f"Schema: {self.schema_name}. Asegúrate de llamar a datasource()"
            )
            
        if not self.provider.engine:
            raise ValueError(
                f"No se pudo crear el engine de base de datos. "
                f"Schema: {self.schema_name}. Verifica la configuración de tu proveedor"
            )

        if not self.provider.database:
            raise ValueError(
                f"No se pudo encontrar el nombre de la base de datos. "
                f"Schema: {self.schema_name}. Verifica la configuración de tu proveedor"
            )

        if not self.generators:
            warnings.warn(
                f"No se han configurado generadores para '{self.schema_name}'. "
                f"No se generará ningún recurso.",
                stacklevel=2
            )
        
        if self.provider.source_input_type in ('connection_string', 'params'):
            warnings.warn(
                f'ADVERTENCIA DE SEGURIDAD para schema "{self.schema_name}": '
                f'El método "{self.provider.source_input_type}" expone credenciales en el código fuente. '
                f'Se recomienda usar env() en su lugar.',
                UserWarning,
                stacklevel=2
            )
        
        self._validated = True
    
    def reset(self) -> None:
        """Resetea el estado del DatabaseManager"""
        self._provider = None
        self._generators = []
        self._tables = []
        self._views = []
        self._loaded = False
        self._loaded_module = None  # Resetear módulo cargado
        self._backup_storage = None
        self._backup_format = 'custom'
        self._backup_retention = None
        self._restore_provider = None
    
    def get_info(self) -> dict:
        """Obtiene información completa del DatabaseManager"""
        return {
            'schema_name': self.schema_name,
            'schema_path': str(self.schema_path) if self.schema_path else None,
            'is_loaded': self.is_loaded,
            'has_provider': self.provider is not None,
            'has_engine': self.provider.engine is not None if self.provider else False,
            'generators_count': len(self.generators),
            'tables_count': len(self.tables),
            'views_count': len(self.views),
            'database_name': self.provider.database if self.provider else None
        }