"""
Safety checker for DDL operations.
Validates that DDL statements can be safely executed against a database
that may already contain data.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, TYPE_CHECKING

import click
from sqlalchemy import text

from tai_sql import pm

if TYPE_CHECKING:
    from .ddl import (
        Statement, DDLStatements, CreateStatement, AlterColumnStatement,
        ForeignKeyStatement, AlterForeignKeyStatement, DropForeignKeyStatement,
    )


class RiskLevel(Enum):
    """Nivel de riesgo de una operación DDL"""
    SAFE = "safe"           # Se puede ejecutar sin problemas
    WARNING = "warning"     # Puede fallar o causar pérdida de datos, requiere confirmación
    BLOCKED = "blocked"     # Imposible sin intervención manual


@dataclass
class SafetyIssue:
    """Representa un problema de seguridad detectado en un statement DDL"""
    statement: Statement
    risk_level: RiskLevel
    message: str
    suggestion: Optional[str] = None
    table_name: Optional[str] = None
    column_name: Optional[str] = None


class SafetyChecker:
    """
    Validates DDL statements against the current state of the database.
    Detects operations that would fail or cause data loss when there are
    existing rows in affected tables.
    """

    def __init__(self):
        self.issues: List[SafetyIssue] = []

    def validate(self, statements: DDLStatements) -> List[SafetyIssue]:
        """
        Validates all DDL statements and returns a list of safety issues.
        """
        from .ddl import (
            AlterColumnStatement, ForeignKeyStatement,
            AlterForeignKeyStatement,
        )

        self.issues = []

        for stmt in statements:
            if isinstance(stmt, AlterColumnStatement):
                self._check_alter_column(stmt)
            elif isinstance(stmt, ForeignKeyStatement):
                self._check_add_foreign_key(stmt)
            elif isinstance(stmt, AlterForeignKeyStatement):
                self._check_alter_foreign_key(stmt)

        return self.issues

    # ──────────────────────────────────────────
    #  ALTER COLUMN checks
    # ──────────────────────────────────────────

    def _check_alter_column(self, stmt: AlterColumnStatement) -> None:
        """Check safety of ALTER COLUMN operations"""
        from .ddl import AlterColumnStatement

        column = stmt.column
        table_name = stmt.table_name

        # Determine if this is an ADD COLUMN (text is a single string starting with ALTER TABLE ... ADD COLUMN)
        is_add = False
        if isinstance(stmt.text, str) and 'ADD COLUMN' in stmt.text.upper():
            is_add = True

        # Determine if this is a DROP COLUMN
        is_drop = False
        if isinstance(stmt.text, str) and 'DROP COLUMN' in stmt.text.upper():
            is_drop = True

        row_count = self._get_row_count(table_name)

        if row_count == 0:
            # Table is empty, any operation is safe
            return

        # ── ADD COLUMN NOT NULL without DEFAULT on a table with data ──
        if is_add and not column.nullable and column.server_default is None and column.default is None:
            self.issues.append(SafetyIssue(
                statement=stmt,
                risk_level=RiskLevel.BLOCKED,
                message=(
                    f'No se puede añadir la columna "{stmt.column_name}" como NOT NULL '
                    f'sin DEFAULT en la tabla "{table_name}" que ya contiene {row_count} fila(s).'
                ),
                suggestion=(
                    f'Opciones:\n'
                    f'   1. Definir la columna como NULLABLE: Optional[{column.type}]\n'
                    f'   2. Añadir un valor por defecto: column(default=<valor>)'
                ),
                table_name=table_name,
                column_name=stmt.column_name,
            ))
            return

        # ── MODIFY COLUMN: SET NOT NULL when there are NULLs ──
        if not is_add and not is_drop and not column.nullable:
            has_nulls = self._column_has_nulls(table_name, stmt.column_name)
            if has_nulls:
                self.issues.append(SafetyIssue(
                    statement=stmt,
                    risk_level=RiskLevel.BLOCKED,
                    message=(
                        f'No se puede establecer NOT NULL en la columna "{stmt.column_name}" '
                        f'de la tabla "{table_name}": existen valores NULL.'
                    ),
                    suggestion=(
                        f'Opciones:\n'
                        f'   1. Mantener la columna como NULLABLE\n'
                        f'   2. Rellenar los valores NULL antes del push: '
                        f'UPDATE {table_name} SET {stmt.column_name} = <valor> WHERE {stmt.column_name} IS NULL'
                    ),
                    table_name=table_name,
                    column_name=stmt.column_name,
                ))

        # ── MODIFY COLUMN: UNIQUE when there are duplicates ──
        if not is_add and not is_drop and column.unique:
            has_dupes = self._column_has_duplicates(table_name, stmt.column_name)
            if has_dupes:
                self.issues.append(SafetyIssue(
                    statement=stmt,
                    risk_level=RiskLevel.BLOCKED,
                    message=(
                        f'No se puede añadir UNIQUE a la columna "{stmt.column_name}" '
                        f'de la tabla "{table_name}": existen valores duplicados.'
                    ),
                    suggestion=(
                        f'Elimina los duplicados manualmente antes del push, o quita la restricción UNIQUE.'
                    ),
                    table_name=table_name,
                    column_name=stmt.column_name,
                ))

    # ──────────────────────────────────────────
    #  FOREIGN KEY checks
    # ──────────────────────────────────────────

    def _check_add_foreign_key(self, stmt: ForeignKeyStatement) -> None:
        """Check if adding a FK would fail due to orphan rows"""
        row_count = self._get_row_count(stmt.table_name)
        if row_count == 0:
            return

        fk = stmt.fk
        local_cols = [col.name for col in fk.columns]
        target_table = fk.referred_table
        target_cols = [elem.column.name for elem in fk.elements]

        orphans = self._has_orphan_rows(
            stmt.table_name, local_cols,
            target_table.name, target_cols
        )

        if orphans:
            local_str = ', '.join(local_cols)
            target_str = ', '.join(target_cols)
            self.issues.append(SafetyIssue(
                statement=stmt,
                risk_level=RiskLevel.BLOCKED,
                message=(
                    f'No se puede crear la FK en "{stmt.table_name}" [{local_str}] → '
                    f'"{target_table.name}" [{target_str}]: existen filas huérfanas '
                    f'que no tienen correspondencia en la tabla referenciada.'
                ),
                suggestion=(
                    f'Elimina las filas huérfanas:\n'
                    f'   DELETE FROM {stmt.table_name} WHERE {local_cols[0]} NOT IN '
                    f'(SELECT {target_cols[0]} FROM {target_table.name})'
                ),
                table_name=stmt.table_name,
            ))

    def _check_alter_foreign_key(self, stmt: AlterForeignKeyStatement) -> None:
        """Check if modifying a FK would cause issues"""
        # Modification is DROP + ADD. The DROP is always safe.
        # For the ADD, check orphans against the new FK definition.
        fk_new = stmt.fk_new
        row_count = self._get_row_count(stmt.table_name)
        if row_count == 0:
            return

        local_cols = [col.name for col in fk_new.columns]
        target_table = fk_new.referred_table
        target_cols = [elem.column.name for elem in fk_new.elements]

        orphans = self._has_orphan_rows(
            stmt.table_name, local_cols,
            target_table.name, target_cols
        )

        if orphans:
            local_str = ', '.join(local_cols)
            target_str = ', '.join(target_cols)
            self.issues.append(SafetyIssue(
                statement=stmt,
                risk_level=RiskLevel.WARNING,
                message=(
                    f'La modificación de la FK en "{stmt.table_name}" [{local_str}] → '
                    f'"{target_table.name}" [{target_str}] podría fallar: existen filas huérfanas.'
                ),
                suggestion=(
                    f'Revisa la integridad referencial antes de continuar.'
                ),
                table_name=stmt.table_name,
            ))

    # ──────────────────────────────────────────
    #  Database query helpers
    # ──────────────────────────────────────────

    def _get_row_count(self, table_name: str) -> int:
        """Returns the number of rows in a table. Returns 0 if table doesn't exist yet."""
        try:
            # Handle schema-qualified table names (e.g. "public.usuario")
            qualified_name = table_name
            if '.' not in table_name and pm.db.provider.driver.supports_schemas():
                qualified_name = f"{pm.db.schema_name}.{table_name}"

            with pm.db.provider.engine.connect() as conn:
                if pm.db.provider.drivername == 'postgresql':
                    conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))
                result = conn.execute(text(f"SELECT COUNT(*) FROM {qualified_name}"))
                count = result.scalar()
                return count or 0
        except Exception:
            # Table may not exist yet (being created in the same push)
            return 0

    def _column_has_nulls(self, table_name: str, column_name: str) -> bool:
        """Check if a column has any NULL values"""
        try:
            qualified_name = table_name
            if '.' not in table_name and pm.db.provider.driver.supports_schemas():
                qualified_name = f"{pm.db.schema_name}.{table_name}"

            with pm.db.provider.engine.connect() as conn:
                if pm.db.provider.drivername == 'postgresql':
                    conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))
                result = conn.execute(
                    text(f"SELECT EXISTS(SELECT 1 FROM {qualified_name} WHERE {column_name} IS NULL)")
                )
                return result.scalar() or False
        except Exception:
            return False

    def _column_has_duplicates(self, table_name: str, column_name: str) -> bool:
        """Check if a column has duplicate values"""
        try:
            qualified_name = table_name
            if '.' not in table_name and pm.db.provider.driver.supports_schemas():
                qualified_name = f"{pm.db.schema_name}.{table_name}"

            with pm.db.provider.engine.connect() as conn:
                if pm.db.provider.drivername == 'postgresql':
                    conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))
                result = conn.execute(text(
                    f"SELECT EXISTS("
                    f"SELECT {column_name} FROM {qualified_name} "
                    f"GROUP BY {column_name} HAVING COUNT(*) > 1"
                    f")"
                ))
                return result.scalar() or False
        except Exception:
            return False

    def _has_orphan_rows(self, local_table: str, local_cols: list[str],
                         target_table: str, target_cols: list[str]) -> bool:
        """Check if there are rows in local_table whose FK columns don't match any row in target_table"""
        try:
            qualified_local = local_table
            qualified_target = target_table
            if '.' not in local_table and pm.db.provider.driver.supports_schemas():
                qualified_local = f"{pm.db.schema_name}.{local_table}"
            if '.' not in target_table and pm.db.provider.driver.supports_schemas():
                qualified_target = f"{pm.db.schema_name}.{target_table}"

            # Build the join condition for potentially composite FKs
            join_conditions = " AND ".join(
                f"l.{lc} = r.{tc}" for lc, tc in zip(local_cols, target_cols)
            )

            with pm.db.provider.engine.connect() as conn:
                if pm.db.provider.drivername == 'postgresql':
                    conn.execute(text(f"SET search_path TO {pm.db.schema_name}, public"))
                result = conn.execute(text(
                    f"SELECT EXISTS("
                    f"SELECT 1 FROM {qualified_local} l "
                    f"LEFT JOIN {qualified_target} r ON {join_conditions} "
                    f"WHERE r.{target_cols[0]} IS NULL"
                    f")"
                ))
                return result.scalar() or False
        except Exception:
            return False

    # ──────────────────────────────────────────
    #  Display
    # ──────────────────────────────────────────

    def has_blocked(self) -> bool:
        """Returns True if any issue is BLOCKED"""
        return any(i.risk_level == RiskLevel.BLOCKED for i in self.issues)

    def has_warnings(self) -> bool:
        """Returns True if any issue is WARNING"""
        return any(i.risk_level == RiskLevel.WARNING for i in self.issues)

    def show_issues(self) -> None:
        """Display all detected safety issues"""
        if not self.issues:
            return

        click.echo()

        blocked = [i for i in self.issues if i.risk_level == RiskLevel.BLOCKED]
        warnings = [i for i in self.issues if i.risk_level == RiskLevel.WARNING]

        if blocked:
            click.echo(click.style("🚫 OPERACIONES BLOQUEADAS", fg="red", bold=True))
            click.echo(click.style("=" * 50, fg="red"))
            click.echo()

            for issue in blocked:
                click.echo(click.style(f"   ❌ {issue.message}", fg="red"))
                if issue.suggestion:
                    click.echo()
                    click.echo(click.style(f"   💡 Sugerencia:", fg="yellow", bold=True))
                    for line in issue.suggestion.split('\n'):
                        click.echo(click.style(f"   {line}", fg="yellow"))
                click.echo()

        if warnings:
            click.echo(click.style("⚠️  ADVERTENCIAS", fg="yellow", bold=True))
            click.echo(click.style("=" * 50, fg="yellow"))
            click.echo()

            for issue in warnings:
                click.echo(click.style(f"   ⚠️  {issue.message}", fg="yellow"))
                if issue.suggestion:
                    click.echo(click.style(f"      💡 {issue.suggestion}", fg="yellow"))
                click.echo()
