"""测试析构函数 __del__ 支持"""

import unittest
import sys
import os
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from l0n0lc import jit


# 测试用的类定义（需要在模块级别以便 JIT 函数访问）
class TestClass:
    value: int

    def __init__(self, v: int):
        self.value = v

    def __del__(self):
        # 析构函数：将 value 设置为 -1
        self.value = -1

    def get_value(self) -> int:
        return self.value


class Counter:
    count: int

    def __init__(self):
        self.count = 0

    def increment(self) -> int:
        self.count = self.count + 1
        return self.count

    def __del__(self):
        # 析构函数：将计数重置
        self.count = 0


class Point:
    x: int
    y: int

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def __del__(self):
        # 析构函数：重置为原点
        self.x = 0
        self.y = 0

    def get_x(self) -> int:
        return self.x

    def get_y(self) -> int:
        return self.y


class A:
    value: int

    def __init__(self, v: int):
        self.value = v

    def __del__(self):
        self.value = 0


class B:
    data: int

    def __init__(self, d: int):
        self.data = d

    def __del__(self):
        self.data = -1


class Logger:
    message: int

    def __init__(self, msg: int):
        self.message = msg

    def log(self, value: int):
        self.message = value

    def __del__(self):
        # 析构函数：调用方法记录
        self.log(999)

    def get_message(self) -> int:
        return self.message


class TestDestructor(unittest.TestCase):
    """测试析构函数功能"""

    def test_basic_destructor(self):
        """测试基本析构函数"""

        @jit(总是重编=True)
        def test_destructor(v: int) -> int:
            obj = TestClass(v)
            return obj.get_value()

        result = test_destructor(42)
        self.assertEqual(result, 42)

    def test_destructor_with_operations(self):
        """测试析构函数中包含复杂操作"""

        @jit(总是重编=True)
        def test_counter() -> int:
            c = Counter()
            c.increment()
            c.increment()
            result = c.count
            return result

        result = test_counter()
        self.assertEqual(result, 2)

    def test_destructor_member_access(self):
        """测试析构函数访问多个成员变量"""

        @jit(总是重编=True)
        def test_point() -> int:
            p = Point(10, 20)
            x = p.get_x()
            y = p.get_y()
            return x + y

        result = test_point()
        self.assertEqual(result, 30)

    def test_multiple_classes_with_destructor(self):
        """测试多个类都有析构函数"""

        @jit(总是重编=True)
        def test_both() -> int:
            a = A(100)
            b = B(200)
            return a.value + b.data

        result = test_both()
        self.assertEqual(result, 300)

    def test_destructor_with_method_call(self):
        """测试析构函数中调用其他方法"""

        @jit(总是重编=True)
        def test_logger() -> int:
            logger = Logger(42)
            return logger.get_message()

        result = test_logger()
        self.assertEqual(result, 42)


if __name__ == "__main__":
    unittest.main(verbosity=2)
