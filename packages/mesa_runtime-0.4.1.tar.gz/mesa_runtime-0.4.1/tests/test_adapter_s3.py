"""Tests for S3Adapter.

S3 connectivity is bypassed by overriding _connect() to return a plain
duckdb.connect(). All SQL logic (ANTI JOINs, read_text, glob, COPY TO)
is exercised against local paths, so no MinIO instance is required.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Literal
from unittest.mock import patch

import duckdb
import pytest
from pydantic import BaseModel

from mesa_runtime.adapters.io_schemas import (
    DocumentInput,
    InferenceMetadata,
    InferenceResult,
    ModelMetadata,
)
from mesa_runtime.adapters.s3 import S3Adapter
from mesa_runtime.config.s3 import AWSCredentials, S3StorageConfig

_CREDS = AWSCredentials(endpoint="localhost:9000", key_id="test", secret="test")


class _TestableAdapter(S3Adapter):
    """Replaces S3 connection with a plain local DuckDB connection."""

    def _connect(self) -> duckdb.DuckDBPyConnection:
        return duckdb.connect()

    def _check_document_output_writable(self): ...

    def _check_document_source_exists(self): ...


@pytest.fixture
def dirs(tmp_path):
    src = tmp_path / "src"
    tgt = tmp_path / "tgt"
    src.mkdir()
    tgt.mkdir()
    return src, tgt


def _make_adapter(
    src: Path,
    tgt: Path,
    input_fmt: Literal["txt", "json", "json.gz", "csv", "csv.gz", "parquet"] = "txt",
    output_fmt: Literal["json", "json.gz", "csv", "csv.gz", "parquet"] = "json",
    model_name: str = "mymodel",
) -> _TestableAdapter:
    config = S3StorageConfig(
        type="s3",
        source_path=str(src),
        destination_path=str(tgt),
        input_file_format=input_fmt,
        output_file_format=output_fmt,
        connection_params=_CREDS,
    )
    return _TestableAdapter(config, model_name)


def _make_result(doc_id: str, valid: bool = False) -> InferenceResult:
    return InferenceResult(
        master_document_id=doc_id,
        document_id=doc_id,
        document_update_dt=datetime.now(),
        validated_output=None,
        inference_result_metadata=InferenceMetadata(
            schema_package_name="pkg",
            schema_package_version="1.0",
            inference_metadata=datetime.now(),
        ),
        model_metadata=ModelMetadata(
            model_name="mymodel",
            model_version="1.0",
            trained_schema_name="schema",
            trained_schema_version="1.0",
        ),
        is_valid=valid,
    )


def _make_row(doc_id: str) -> dict:
    return {
        "document_id": doc_id,
        "document_source": "{}",
        "document_inference": "{}",
        "metadata": "{}",
        "is_valid": False,
    }


class TestGetUnprocessedDocumentCountTxt:
    def test_counts_all_when_no_output(self, dirs):
        src, tgt = dirs
        (src / "a.txt").write_text("aaa")
        (src / "b.txt").write_text("bbb")

        assert _make_adapter(src, tgt).get_unprocessed_document_count() == 2

    def test_excludes_already_processed(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("one")
        (src / "doc2.txt").write_text("two")
        (src / "doc3.txt").write_text("three")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))

        assert _make_adapter(src, tgt).get_unprocessed_document_count() == 2

    def test_zero_when_all_processed(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("one")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))

        assert _make_adapter(src, tgt).get_unprocessed_document_count() == 0


class TestGetDocumentsTxt:
    def test_yields_document_input_instances(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content")

        docs = list(_make_adapter(src, tgt).get_documents())

        assert all(isinstance(d, DocumentInput) for d in docs)

    def test_yields_only_unprocessed(self, dirs):
        src, tgt = dirs
        (src / "alpha.txt").write_text("alpha")
        (src / "beta.txt").write_text("beta")
        (tgt / "alpha.json").write_text(json.dumps({"document_id": "alpha"}))

        docs = list(_make_adapter(src, tgt).get_documents())

        assert {d.document_id for d in docs} == {"beta"}

    def test_document_id_strips_txt_extension(self, dirs):
        src, tgt = dirs
        (src / "report.txt").write_text("body")

        docs = list(_make_adapter(src, tgt).get_documents())

        assert docs[0].document_id == "report"

    def test_document_content_matches_file(self, dirs):
        src, tgt = dirs
        (src / "note.txt").write_text("hello world")

        docs = list(_make_adapter(src, tgt).get_documents())

        assert docs[0].document_content == "hello world"

    def test_yields_nothing_when_all_processed(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content")
        (tgt / "doc1.json").write_text(json.dumps({"document_id": "doc1"}))

        assert list(_make_adapter(src, tgt).get_documents()) == []

    def test_handles_empty_output_directory(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content")

        docs = list(_make_adapter(src, tgt).get_documents())

        assert docs[0].document_id == "doc1"


class TestStructuredInputJson:
    def _write_json_src(self, src: Path, records: list[dict]):
        """Write one NDJSON record per line into a single source file."""
        (src / "docs.json").write_text("\n".join(json.dumps(r) for r in records) + "\n")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )

        adapter = _make_adapter(src, tgt, input_fmt="json")
        assert adapter.get_unprocessed_document_count() == 2

    def test_count_excludes_processed(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )
        (tgt / "out.json").write_text(json.dumps({"document_id": "id1"}))

        adapter = _make_adapter(src, tgt, input_fmt="json")
        assert adapter.get_unprocessed_document_count() == 1

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_json_src(src, [{"document_id": "x", "document_content": "body text"}])

        docs = list(_make_adapter(src, tgt, input_fmt="json").get_documents())

        assert len(docs) == 1
        assert docs[0].document_id == "x"
        assert docs[0].document_content == "body text"

    def test_get_documents_excludes_processed(self, dirs):
        src, tgt = dirs
        self._write_json_src(
            src,
            [
                {"document_id": "id1", "document_content": "one"},
                {"document_id": "id2", "document_content": "two"},
            ],
        )
        (tgt / "out.json").write_text(json.dumps({"document_id": "id1"}))

        docs = list(_make_adapter(src, tgt, input_fmt="json").get_documents())

        assert {d.document_id for d in docs} == {"id2"}


class TestStructuredInputParquet:
    def _write_parquet_src(self, src: Path, records: list[dict]):
        rows = "\n".join(
            f"SELECT '{r['document_id']}' AS document_id,"
            f" '{r['document_content']}' AS document_content"
            for r in records
        )
        union = " UNION ALL ".join(rows.splitlines())
        with duckdb.connect() as conn:
            conn.sql(f"COPY ({union}) TO '{src}/docs.parquet'")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_parquet_src(
            src,
            [
                {"document_id": "p1", "document_content": "one"},
                {"document_id": "p2", "document_content": "two"},
            ],
        )

        adapter = _make_adapter(src, tgt, input_fmt="parquet")
        assert adapter.get_unprocessed_document_count() == 2

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_parquet_src(src, [{"document_id": "p1", "document_content": "parquet body"}])

        docs = list(_make_adapter(src, tgt, input_fmt="parquet").get_documents())

        assert docs[0].document_id == "p1"
        assert docs[0].document_content == "parquet body"


class TestStructuredInputCsv:
    def _write_csv_src(self, src: Path, records: list[dict]):
        lines = ["document_id,document_content"] + [
            f"{r['document_id']},{r['document_content']}" for r in records
        ]
        (src / "docs.csv").write_text("\n".join(lines) + "\n")

    def test_count_all_when_no_output(self, dirs):
        src, tgt = dirs
        self._write_csv_src(
            src,
            [
                {"document_id": "c1", "document_content": "one"},
                {"document_id": "c2", "document_content": "two"},
            ],
        )

        adapter = _make_adapter(src, tgt, input_fmt="csv")
        assert adapter.get_unprocessed_document_count() == 2

    def test_get_documents_yields_correct_fields(self, dirs):
        src, tgt = dirs
        self._write_csv_src(src, [{"document_id": "c1", "document_content": "csv body"}])

        docs = list(_make_adapter(src, tgt, input_fmt="csv").get_documents())

        assert docs[0].document_id == "c1"
        assert docs[0].document_content == "csv body"


class TestWriteDocument:
    def test_buffer_accumulates(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-1")])
        assert len(adapter._buffer) == 1

        adapter.write_document([_make_result("doc-2"), _make_result("doc-3")])
        assert len(adapter._buffer) == 3

    def test_flush_not_called_below_threshold(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        with patch.object(adapter, "flush") as mock_flush:
            adapter.write_document([_make_result(f"doc-{i}") for i in range(49)])
            mock_flush.assert_not_called()

    def test_flush_called_when_buffer_exceeds_50(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        with patch.object(adapter, "flush") as mock_flush:
            adapter.write_document([_make_result(f"doc-{i}") for i in range(51)])
            mock_flush.assert_called_once()

    def test_row_format_is_valid_flag(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-ok", valid=True)])

        assert adapter._buffer[0]["is_valid"] is True

    def test_row_format_no_output_produces_empty_json(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc-1")])

        assert adapter._buffer[0]["document_inference"] == "{}"

    def test_row_format_with_validated_output(self, dirs):
        class SimpleOutput(BaseModel):
            label: str

        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        result = _make_result("doc-1")
        result.validated_output = SimpleOutput(label="yes")

        adapter.write_document([result])

        assert json.loads(adapter._buffer[0]["document_inference"]) == {"label": "yes"}


class TestFlush:
    def test_empty_buffer_writes_no_files(self, dirs):
        src, tgt = dirs
        _make_adapter(src, tgt).flush()

        assert list(tgt.glob("*.json")) == []

    def test_writes_file_to_destination(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("doc1")]

        adapter.flush()

        assert len(list(tgt.glob("*.json"))) == 1

    def test_filename_starts_with_model_name(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt, model_name="mymodel")
        adapter._buffer = [_make_row("doc1")]

        adapter.flush()

        written = list(tgt.glob("*.json"))
        assert written[0].name.startswith("mymodel_")

    def test_clears_buffer_after_flush(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("doc1"), _make_row("doc2")]

        adapter.flush()

        assert adapter._buffer == []

    def test_multiple_flushes_write_separate_files(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)

        adapter._buffer = [_make_row("doc1")]
        adapter.flush()
        adapter._buffer = [_make_row("doc2")]
        adapter.flush()

        assert len(list(tgt.glob("*.json"))) == 2

    def test_document_id_survives_in_output(self, dirs):
        src, tgt = dirs
        adapter = _make_adapter(src, tgt)
        adapter._buffer = [_make_row("my-doc")]

        adapter.flush()

        with duckdb.connect() as conn:
            rows = conn.sql(f"SELECT document_id FROM '{tgt}/*.json'").fetchdf()

        assert list(rows["document_id"]) == ["my-doc"]

    def test_flushed_documents_excluded_from_get_documents(self, dirs):
        src, tgt = dirs
        (src / "doc1.txt").write_text("content one")
        (src / "doc2.txt").write_text("content two")
        adapter = _make_adapter(src, tgt)

        adapter.write_document([_make_result("doc1")])
        adapter.flush()

        remaining = list(adapter.get_documents())
        assert {d.document_id for d in remaining} == {"doc2"}


# ---------------------------------------------------------------------------
# AWSCredentials — env var resolution
# ---------------------------------------------------------------------------


class TestAWSCredentialsEnvResolution:
    def test_explicit_values_take_precedence(self, monkeypatch):
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "env-key")
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "env-secret")
        monkeypatch.setenv("AWS_DEFAULT_REGION", "eu-west-1")

        creds = AWSCredentials(
            endpoint="localhost:9000", key_id="cfg-key", secret="cfg-secret", region="us-west-2"
        )

        assert creds.key_id == "cfg-key"
        assert creds.secret == "cfg-secret"
        assert creds.region == "us-west-2"

    def test_secret_resolved_from_env(self, monkeypatch):
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "env-secret")

        creds = AWSCredentials(endpoint="localhost:9000", key_id="cfg-key")

        assert creds.secret == "env-secret"

    def test_key_id_resolved_from_env(self, monkeypatch):
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "env-key")

        creds = AWSCredentials(endpoint="localhost:9000", secret="cfg-secret")

        assert creds.key_id == "env-key"

    def test_region_resolved_from_env(self, monkeypatch):
        monkeypatch.setenv("AWS_DEFAULT_REGION", "ap-southeast-1")

        creds = AWSCredentials(endpoint="localhost:9000", key_id="k", secret="s")

        assert creds.region == "ap-southeast-1"

    def test_region_defaults_when_absent_from_env(self, monkeypatch):
        monkeypatch.delenv("AWS_DEFAULT_REGION", raising=False)

        creds = AWSCredentials(endpoint="localhost:9000", key_id="k", secret="s")

        assert creds.region == "us-east-1"

    def test_missing_key_id_raises(self, monkeypatch):
        monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)

        with pytest.raises(Exception, match="AWS_ACCESS_KEY_ID"):
            AWSCredentials(endpoint="localhost:9000", secret="s")

    def test_missing_secret_raises(self, monkeypatch):
        monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)

        with pytest.raises(Exception, match="AWS_SECRET_ACCESS_KEY"):
            AWSCredentials(endpoint="localhost:9000", key_id="k")
