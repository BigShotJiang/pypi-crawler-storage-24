import pytest

from mesa_runtime.config import SourceBase, load_config
from mesa_runtime.config.config_base import SourceConfig
from mesa_runtime.config.snowflake import SnowflakeStorageConfig

# Ensure our example config is available for testing the loading of config from YAML
with open("config.yaml", "r") as f:
    yaml_config_fixture = f.read()


class TestSnowflakeStorageConfig:
    def test_snowflake_storage_config_valid(self, snowflake_storage_config: SnowflakeStorageConfig):
        assert snowflake_storage_config.type == "snowflake"
        assert snowflake_storage_config.source_database == "analytics"
        assert snowflake_storage_config.source_schema == "raw"
        assert snowflake_storage_config.source_table == "events"
        assert snowflake_storage_config.sink_database == "analytics"
        assert snowflake_storage_config.sink_schema == "processed"
        assert snowflake_storage_config.sink_table == "events"

        # Snowflake config setup
        assert snowflake_storage_config.connection_params.account == "test_account"

    def test_get_source_fqn(self, snowflake_storage_config: SnowflakeStorageConfig):
        assert snowflake_storage_config.source_table_fqn == '"analytics"."raw"."events"'

    def test_get_sink_fqn(self, snowflake_storage_config: SnowflakeStorageConfig):
        assert snowflake_storage_config.sink_table_fqn == '"analytics"."processed"."events"'


class TestSourceConfig:
    def test_model_valid_source_s3_uri(self):
        assert (
            SourceConfig.validate_s3_uri("s3://mybucket/models/model/")
            == "s3://mybucket/models/model/"
        )

    def test_model_invalid_source_s3_uri(self):
        with pytest.raises(ValueError):
            SourceConfig.validate_s3_uri("s3://mybucket/models/model")


class TestSourceBase:
    def test_load_from_yaml(self, tmp_path, monkeypatch):

        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml_config_fixture)
        monkeypatch.chdir(tmp_path)

        source = SourceBase()  # type: ignore

        assert source.name == "gstt_sde_mock"
        assert (
            source.config.model_s3_uri
            == "s3://aicentre-nlpteam-mesa-build/models/oncoqwen/oncoqwen_1/"
        )
        assert isinstance(source.config.storage, SnowflakeStorageConfig)
        assert source.config.storage.type == "snowflake"
        assert source.config.storage.source_database == "MESA_TEST"
        assert source.config.storage.source_schema == "DOCUMENT_SOURCE"
        assert source.config.storage.source_table == "CANCER_BATCH_2025_12_31"
        assert source.config.storage.sink_database == "MESA_TEST"
        assert source.config.storage.sink_schema == "DOCUMENT_SINK"
        assert source.config.storage.sink_table == "INFERRENCE_CANCER_BATCH_2025_12_31"


class TestLoadConfig:
    def test_load_config_from_custom_path(self, tmp_path):
        """Test the load config method (using a custom path)"""
        config_file = tmp_path / "custom_config.yaml"
        config_file.write_text(yaml_config_fixture)

        result = load_config(str(config_file))

        assert result.name == "gstt_sde_mock"
        assert isinstance(result.config.storage, SnowflakeStorageConfig)
        assert result.config.storage.type == "snowflake"
        assert result.config.storage.source_database == "MESA_TEST"
