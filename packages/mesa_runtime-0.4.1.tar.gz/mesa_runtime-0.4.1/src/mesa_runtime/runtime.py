import itertools
import logging
import queue
import threading
import time
from datetime import datetime
from typing import Iterator

from pydantic import ValidationError

from mesa_runtime.adapters.io_schemas import (
    DocumentInput,
    InferenceMetadata,
    InferenceResult,
    ModelMetadata,
)
from mesa_runtime.adapters.storage_base import AbstractStorageAdapter
from mesa_runtime.inferrer import InferrenceBackend, ModelConfig, parse_output

logger = logging.getLogger(__name__)


def _fetch_batches(
    doc_stream: Iterator[DocumentInput], batch_q: queue.Queue, batch_size: int
) -> None:
    """Producer: reads document batches from the stream and enqueues them.

    Runs in a background thread. Puts Exception into the queue on failure
    so the consumer can re-raise rather than block indefinitely.
    """
    try:
        for batch in iter(lambda: list(itertools.islice(doc_stream, batch_size)), []):
            batch_q.put(batch)
    except Exception as e:
        batch_q.put(e)
    finally:
        batch_q.put(None)


def _doc_stream(
    batch_q: queue.Queue[list[DocumentInput] | Exception | None],
    docs_by_id: dict[str, DocumentInput],
) -> Iterator[tuple[str, str]]:
    """Flatten fetch batches into a continuous (doc_id, content) stream."""
    while True:
        item = batch_q.get()
        if item is None:
            break
        if isinstance(item, Exception):
            raise item
        for doc in item:
            docs_by_id[doc.document_id] = doc
            yield doc.document_id, doc.document_content


class Runtime:
    def __init__(
        self,
        backend: InferrenceBackend,
        model_config: ModelConfig,
        storage_adapter: AbstractStorageAdapter,
        fetch_batch_size: int,
    ) -> None:
        self.backend = backend
        self.model_config = model_config
        self.storage_adapter = storage_adapter
        self._fetch_batch_size = fetch_batch_size

    def _make_failed_result(
        self,
        doc: DocumentInput,
        raw_output: str,
        error: Exception,
        model_metadata: ModelMetadata,
    ) -> InferenceResult:
        inference_metadata = InferenceMetadata(
            schema_package_name=self.model_config.schema_package,
            schema_package_version=self.model_config.schema_version,
            inference_metadata=datetime.now(),
            failed_output=raw_output,
            inference_error=str(error),
        )
        return InferenceResult(
            master_document_id=doc.document_id,
            document_id=doc.document_id,
            document_update_dt=doc.document_update_dt or datetime.now(),
            validated_output=None,
            document_source=doc.document_source,
            inference_result_metadata=inference_metadata,
            model_metadata=model_metadata,
            is_valid=False,
        )

    def _process_result(
        self,
        doc: DocumentInput,
        raw_output: str,
        model_metadata: ModelMetadata,
    ) -> tuple[InferenceResult, bool]:
        """Parse a single inference output. Returns (result, is_valid)."""
        try:
            parsed = parse_output(raw_output, self.model_config.output_model)
            inference_metadata = InferenceMetadata(
                schema_package_name=self.model_config.schema_package,
                schema_package_version=self.model_config.schema_version,
                inference_metadata=datetime.now(),
            )
            return InferenceResult(
                master_document_id=doc.document_id,
                document_id=doc.document_id,
                document_update_dt=doc.document_update_dt or datetime.now(),
                validated_output=parsed,
                document_source=doc.document_source,
                inference_result_metadata=inference_metadata,
                model_metadata=model_metadata,
                is_valid=True,
            ), True
        except ValidationError as e:
            logger.debug("Output parse failed for %s: %s", doc.document_id, e)
            return self._make_failed_result(doc, raw_output, e, model_metadata), False
        except Exception as e:
            logger.error("Unexpected error for %s", doc.document_id, exc_info=True)
            return self._make_failed_result(doc, raw_output, e, model_metadata), False

    def infer_documents(self, threaded: bool = True):
        total_to_process = self.storage_adapter.get_unprocessed_document_count()
        total_processed = 0
        total_valid = 0
        total_failed = 0
        run_start = time.monotonic()

        # Build model metadata once (same for all results)
        model_metadata = ModelMetadata(
            model_name=self.model_config.model_name,
            model_version="1.0",  # TODO: Get from config
            trained_schema_name=self.model_config.schema_package,
            trained_schema_version=self.model_config.schema_version,
        )

        # Populated just before each doc is dispatched; entries removed as results arrive.
        # Bounds to ~max_concurrent_requests entries in steady state.
        docs_by_id: dict[str, DocumentInput] = {}

        if threaded:
            # maxsize=1 — producer fetches one batch ahead while current batch is being inferred
            batch_q: queue.Queue[list[DocumentInput] | Exception | None] = queue.Queue(maxsize=1)
            producer = threading.Thread(
                target=_fetch_batches,
                args=(self.storage_adapter.get_documents(), batch_q, self._fetch_batch_size),
                daemon=True,
            )
            producer.start()
            doc_stream = _doc_stream(batch_q, docs_by_id)
        else:

            def _doc_stream_sync() -> Iterator[tuple[str, str]]:
                for doc in self.storage_adapter.get_documents():
                    docs_by_id[doc.document_id] = doc
                    yield doc.document_id, doc.document_content

            doc_stream = _doc_stream_sync()

        logger.debug("Dispatching document stream to inference backend")
        result_stream = self.backend.generate(doc_stream)
        for doc_id, raw_output in result_stream:
            if total_processed == 0:
                logger.debug("First inference result received for doc_id=%s", doc_id)

            doc = docs_by_id.pop(doc_id)
            result, is_valid = self._process_result(doc, raw_output, model_metadata)

            total_valid += is_valid
            total_failed += not is_valid
            self.storage_adapter.write_document([result])
            total_processed += 1

            if total_processed % 10 == 0:
                elapsed = time.monotonic() - run_start
                rate = total_processed / elapsed
                pct = (total_processed / total_to_process * 100) if total_to_process else 0
                logger.info(
                    "Progress: %d/%d (%.1f%%) | %.1f docs/s",
                    total_processed,
                    total_to_process,
                    pct,
                    rate,
                )

        self.storage_adapter.flush()

        if threaded:
            producer.join()

        run_elapsed = time.monotonic() - run_start
        overall_rate = total_processed / run_elapsed if run_elapsed > 0 else 0
        logger.info(
            f"Inference complete: {total_processed} docs in {run_elapsed:.1f}s "
            f"({overall_rate:.2f} docs/s) | {total_valid} valid, {total_failed} failed"
        )
