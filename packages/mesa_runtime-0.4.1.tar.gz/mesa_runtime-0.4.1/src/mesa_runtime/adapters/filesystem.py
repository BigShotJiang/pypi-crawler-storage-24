import glob
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

import duckdb
import pandas as pd

from mesa_runtime.adapters.io_schemas import DocumentInput, InferenceResult
from mesa_runtime.adapters.storage_base import AbstractStorageAdapter
from mesa_runtime.config.filesystem import FilesystemStorageConfig

"""
This storage adapter class represents methods for how other adapters can be setup as different
sources and sinks of data.

It is up to the adapter to decide on batching/write back strategy.
"""

logger = logging.getLogger(__name__)

_READ_FN: dict[str, str] = {
    "json": "read_json",
    "json.gz": "read_json",
    "csv": "read_csv",
    "csv.gz": "read_csv",
    "parquet": "read_parquet",
}


class FileSystemAdapter(AbstractStorageAdapter):
    def __init__(
        self,
        storage_config: FilesystemStorageConfig,
        model_name: str,
    ):
        self.storage_config = storage_config
        self.model_name = model_name
        self._buffer = []

        self._check_document_output_writable()
        self._check_document_source_exists()

    def _output_files_exist(self) -> bool:
        fmt = self.storage_config.output_file_format
        tgt = self.storage_config.target_directory
        return bool(glob.glob(str(Path(tgt) / f"*.{fmt}")))

    def get_unprocessed_document_count(self) -> int:
        fmt = self.storage_config.input_file_format
        src = self.storage_config.source_directory
        tgt = self.storage_config.target_directory
        out_fmt = self.storage_config.output_file_format

        has_output = self._output_files_exist()
        read_out_fn = _READ_FN[out_fmt]

        if fmt == "txt":
            base = f"SELECT COUNT(*) FROM read_text('{src}/*.txt')"
            anti = f"""
                SELECT COUNT(*) FROM read_text('{src}/*.txt') src
                ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                    ON replace(parse_filename(src.filename), '.txt', '') = tgt.document_id
            """
            query = base if not has_output else anti
        else:
            read_fn = _READ_FN[fmt]
            base = f"SELECT COUNT(*) FROM {read_fn}('{src}/*.{fmt}')"
            anti = f"""
                SELECT COUNT(*) FROM {read_fn}('{src}/*.{fmt}') src
                ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                    ON src.document_id = tgt.document_id
            """
            query = base if not has_output else anti

        with duckdb.connect() as conn:
            res = conn.sql(query).fetchone()

        count = int(res[0]) if res else 0
        logger.info(f"Unprocessed document count: {count}")
        return count

    def get_documents(self) -> Generator[DocumentInput, None, None]:
        fmt = self.storage_config.input_file_format
        src = self.storage_config.source_directory
        tgt = self.storage_config.target_directory
        out_fmt = self.storage_config.output_file_format

        has_output = self._output_files_exist()
        read_out_fn = _READ_FN[out_fmt]

        if fmt == "txt":
            select = """
                replace(parse_filename(src.filename), '.txt', '') AS document_id,
                src.content AS document_content
            """
            base = f"SELECT {select} FROM read_text('{src}/*.txt') src"
            anti = f"""
                SELECT {select} FROM read_text('{src}/*.txt') src
                ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                    ON replace(parse_filename(src.filename), '.txt', '') = tgt.document_id
            """
            query = base if not has_output else anti
        else:
            read_fn = _READ_FN[fmt]
            base = f"SELECT document_id, document_content FROM {read_fn}('{src}/*.{fmt}')"
            anti = f"""
                SELECT src.document_id, src.document_content
                FROM {read_fn}('{src}/*.{fmt}') src
                ANTI JOIN {read_out_fn}('{tgt}/*.{out_fmt}') tgt
                    ON src.document_id = tgt.document_id
            """
            query = base if not has_output else anti

        with duckdb.connect() as conn:
            rows = conn.sql(query).fetchdf().to_dict(orient="records")

        logger.info(f"Fetched {len(rows)} documents")
        for row in rows:
            yield DocumentInput(
                document_id=str(row["document_id"]),
                document_content=str(row["document_content"]),
                document_update_dt=datetime.now(),
            )

    @staticmethod
    def __filesystem_row_format(document: InferenceResult) -> dict[str, Any]:
        return {
            "document_id": document.document_id,
            "document_source": json.dumps(document.document_source or {}, default=str),
            "document_inference": document.validated_output.model_dump_json()
            if document.validated_output
            else "{}",
            "metadata": json.dumps(
                {
                    "inference": document.inference_result_metadata.model_dump(),
                    "model": document.model_metadata.model_dump(),
                },
                default=str,
            ),
            "is_valid": document.is_valid,
        }

    def write_document(self, documents: list[InferenceResult]):
        rows = [self.__filesystem_row_format(doc) for doc in documents]
        self._buffer.extend(rows)

        if len(self._buffer) >= self.storage_config.write_buffer_size:
            self.flush()

    def _check_document_output_writable(self):
        # Given we are writing to local files, we will assume this is okay.
        pass

    def _check_document_source_exists(self):
        # Given we are reading from local files, we will assume this is okay.
        pass

    def flush(self):

        if not self._buffer:
            return

        logger.debug(f"Writing buffer of length: {len(self._buffer)}")

        tgt = self.storage_config.target_directory
        fmt = self.storage_config.output_file_format
        ts = datetime.now().strftime("%Y%m%d_%H%M%S%f")
        df = pd.DataFrame(self._buffer)  # noqa

        with duckdb.connect() as conn:
            conn.sql(f"COPY (FROM df) TO '{tgt}/{self.model_name}_{ts}.{fmt}';")

        self._buffer = []
