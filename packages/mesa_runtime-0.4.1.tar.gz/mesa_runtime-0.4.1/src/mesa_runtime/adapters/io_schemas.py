from datetime import datetime
from typing import Any, Generic, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T", bound=BaseModel)


class ModelMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")

    model_name: str
    model_version: str
    trained_schema_name: str
    trained_schema_version: str


class InferenceMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")

    failed_output: Optional[str] = None
    inference_error: Optional[str] = None
    schema_package_name: str
    schema_package_version: str
    inference_metadata: datetime

    @classmethod
    def create(
        cls,
        schema_package_name: str,
        schema_package_version: str,
        failed_output: str | None = None,
        **kwargs,
    ) -> "InferenceMetadata":
        return cls(
            schema_package_name=schema_package_name,
            schema_package_version=schema_package_version,
            inference_metadata=datetime.now(),
            failed_output=failed_output,
            **kwargs,
        )


class DocumentInput(BaseModel):
    document_id: str
    document_content: str
    document_update_dt: Optional[datetime]

    # All other fields in the source table that are not explicitly needed for generation can be
    # added here as optional fields.
    # This will include NHS Numbers, names, or any other metadata
    document_source: Optional[dict[str, Any]] = Field(default_factory=dict)


class InferenceResult(BaseModel, Generic[T]):
    master_document_id: str
    document_id: str
    document_update_dt: datetime
    validated_output: Optional[T] = None

    # Original document source data for auditing/traceability
    document_source: Optional[dict[str, Any]] = Field(default_factory=dict)

    inference_result_metadata: InferenceMetadata
    model_metadata: ModelMetadata
    is_valid: bool
