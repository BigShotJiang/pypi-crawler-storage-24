from mesa_runtime.adapters.storage_base import AbstractStorageAdapter
from mesa_runtime.config.config_base import SourceConfig
from mesa_runtime.config.filesystem import FilesystemStorageConfig
from mesa_runtime.config.s3 import S3StorageConfig
from mesa_runtime.config.snowflake import SnowflakeStorageConfig


def build_storage_adapter(source_config: SourceConfig) -> AbstractStorageAdapter:
    if source_config.storage.type == "snowflake":
        from mesa_runtime.adapters.snowflake import SnowflakeWrapper

        # Assertion to help type checking
        assert isinstance(source_config.storage, SnowflakeStorageConfig)

        return SnowflakeWrapper(
            params=source_config.storage.connection_params, storage_config=source_config.storage
        )
    elif source_config.storage.type == "s3":
        from mesa_runtime.adapters.s3 import S3Adapter

        assert isinstance(source_config.storage, S3StorageConfig)

        # TODO CHANGE - this needs to be passed through more intelligently
        return S3Adapter(
            storage_config=source_config.storage,
            model_name=source_config.model_name,
        )
    elif source_config.storage.type == "filesystem":
        from mesa_runtime.adapters.filesystem import FileSystemAdapter

        assert isinstance(source_config.storage, FilesystemStorageConfig)

        # TODO CHANGE - this needs to be passed through more intelligently
        return FileSystemAdapter(
            storage_config=source_config.storage,
            model_name=source_config.model_name,
        )

    else:
        raise ValueError(f"Unknown storage type: {source_config.storage.type}")
