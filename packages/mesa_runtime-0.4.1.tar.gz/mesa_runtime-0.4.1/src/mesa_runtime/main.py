import argparse
import logging
import os
from sys import exit

from mesalocal.settings import WeightsConfig
from mesalocal.weights import Weights
from oncoschema.prompt_builder import PromptBuilder
from oncoschema.schema import OncologyModel
from pydantic import ValidationError

from mesa_runtime.adapters import build_storage_adapter
from mesa_runtime.config import load_config
from mesa_runtime.inferrer import ModelConfig, VLLMBackend
from mesa_runtime.runtime import Runtime


def main() -> None:
    log_level = getattr(logging, os.environ.get("LOG_LEVEL", "INFO").upper(), logging.INFO)
    logging.basicConfig(
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        level=log_level,
    )
    logging.getLogger("snowflake.connector").setLevel(logging.WARNING)
    logging.getLogger("snowflake.snowpark").setLevel(logging.CRITICAL)
    logging.getLogger("snowflake.core").setLevel(logging.WARNING)
    logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
    logging.getLogger("botocore").setLevel(logging.WARNING)
    logging.getLogger("boto3").setLevel(logging.WARNING)
    logging.getLogger("s3transfer").setLevel(logging.WARNING)

    parser = argparse.ArgumentParser(description="Mesa Runtime")
    parser.add_argument("--config", "-c", default="config.yaml", help="Path to YAML config file")

    args = parser.parse_args()

    logging.info("== mesa-runtime ==")
    logging.info("Collecting configuration")
    logging.info(f"  Using config at {args.config}")

    try:
        cfg = load_config(args.config)
    except ValidationError as e:
        logging.critical("Invalid configuration; unable to start")
        logging.debug(e)
        exit(1)

    # TODO: In future allow more than one type of source, more than one source
    logging.info(f"Got asset: {cfg.name}")

    # Build storage adapter before turning on the model to check if we can quickly stop
    storage_adapter = build_storage_adapter(cfg.config)
    if storage_adapter.get_unprocessed_document_count() == 0:
        logging.info("No documents required to infer; stopping early.")
        exit(0)

    # Sync model files from S3 and resolve the local cache path
    logging.info("Syncing model files from S3 to local cache...")
    weights: Weights = Weights(
        model_name=cfg.config.model_name,
        weights_config=WeightsConfig(
            id=cfg.config.model_id, key=cfg.config.model_key, uri=cfg.config.model_s3_uri
        ),
    )
    weights.download()
    logging.info(f"Model files synced to {weights.get_model_folder()}")

    # Build prompt template and model config
    prompt_template = PromptBuilder().build_main_prompt()
    inference_cfg = cfg.config.inference

    model_config: ModelConfig[OncologyModel] = ModelConfig(
        prompt_template=prompt_template,
        output_model=OncologyModel,
        max_tokens=inference_cfg.max_tokens,
        max_model_len=inference_cfg.max_model_len,
        temperature=inference_cfg.temperature,
        max_concurrent_requests=inference_cfg.max_concurrent_requests,
        model_name=cfg.config.model_name,
        schema_package="londonaicentre-oncoschema",
    )

    # Initialize vLLM backend with any additional VLLM kwargs from config
    backend = VLLMBackend(
        model_path=str(weights.get_model_folder()),
        model_config=model_config,
        **inference_cfg.vllm_kwargs,
    )

    runtime = Runtime(
        backend=backend,
        model_config=model_config,
        storage_adapter=storage_adapter,
        fetch_batch_size=inference_cfg.fetch_batch_size,
    )

    runtime.infer_documents(inference_cfg.threaded)
