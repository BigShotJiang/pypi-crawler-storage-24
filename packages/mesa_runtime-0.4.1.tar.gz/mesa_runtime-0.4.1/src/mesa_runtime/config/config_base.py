import os
import re
from typing import Annotated, Any, Self

from pydantic import BaseModel, Field, computed_field, field_validator, model_validator
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

from mesa_runtime.config.filesystem import FilesystemStorageConfig
from mesa_runtime.config.s3 import S3StorageConfig
from mesa_runtime.config.snowflake import SnowflakeStorageConfig


class InferenceConfig(BaseModel):
    """Inference parameters for model generation."""

    max_tokens: int = 20_000  # output length
    temperature: float = 0.0
    max_concurrent_requests: int = 150  # internal batching control
    fetch_batch_size: int = 1000  # documents fetched per Snowflake round-trip
    # max model context length — mandatory, passed to both truncation and engine
    max_model_len: int
    threaded: bool = True

    # Arbitrary VLLM engine kwargs passed directly to AsyncEngineArgs.
    # These override any defaults. See vLLM docs for available options.
    # Example: {"gpu_memory_utilization": 0.9, "tensor_parallel_size": 2}
    # Note: max_model_len must NOT be set here; use inference.max_model_len instead.
    vllm_kwargs: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _reject_max_model_len_in_vllm_kwargs(self) -> "InferenceConfig":
        if "max_model_len" in self.vllm_kwargs:
            raise ValueError(
                "max_model_len must not be set in vllm_kwargs; "
                "set it as inference.max_model_len instead."
            )
        return self


StorageConfig = Annotated[
    SnowflakeStorageConfig | S3StorageConfig | FilesystemStorageConfig, Field(discriminator="type")
]


class SourceConfig(BaseModel):
    model_s3_uri: str | None = Field(
        default=None,
        description="S3 URI where model files are stored, e.g. s3://my-bucket/models/model/",
    )
    model_name_input: str | None = Field(default=None, validation_alias="model_name")
    model_id: str | None = None
    model_key: str | None = None
    inference: InferenceConfig

    storage: StorageConfig

    @computed_field
    @property
    def model_name(self) -> str:
        if not (
            result := (
                self.model_name_input
                or os.getenv("MODEL_NAME")
                or (self.model_s3_uri and self.model_s3_uri.split("/")[-2])
            )
        ):
            raise ValueError("model_name must be provided or derivable from model_s3_uri")
        return result

    @field_validator("model_s3_uri")
    @classmethod
    def validate_s3_uri(cls, value: str) -> str:
        if value is None:
            return value
        regex_check = re.compile("^s3://([^/]+)/(.*?([^/]+)/)$").findall(value)
        if not regex_check:
            raise ValueError(
                "Model source in unexpected format; ensure a valid S3 URI ending with a slash is "
                "used, e.g. s3://my-bucket/models/model/"
            )
        return value

    @model_validator(mode="after")
    def validate_model_source(self) -> Self:
        if not (
            self.model_s3_uri is not None or all([self.model_name, self.model_id, self.model_key])
        ):
            raise ValueError(
                "either model_s3_uri AND/OR all of (model_name, model_id, model_key) must be "
                "provided"
            )
        if self.model_id is None:
            self.model_id = os.getenv("WEIGHTS_ID")
        if self.model_key is None:
            self.model_key = os.getenv("WEIGHTS_KEY")
        return self


class SourceBase(BaseSettings):
    model_config = SettingsConfigDict(yaml_file="config.yaml")

    name: str = Field(description="Identifier")
    config: SourceConfig

    @model_validator(mode="before")
    @classmethod
    def _extract_named_source(cls, data: dict) -> dict:
        # Expect a single top-level key as the source name,
        # with its value containing the SourceConfig fields.
        # e.g. {"my_param": {"type": "snowflake", ...}}
        if "name" not in data and "config" not in data and len(data) == 1:
            name, config = next(iter(data.items()))
            return {"name": name, "config": config}
        return data

    # Boilerplate to get yaml config working
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            YamlConfigSettingsSource(settings_cls),
        )


def load_config(yaml_file: str = "config.yaml") -> SourceBase:
    """Load settings from a specific YAML file."""

    class _ConfigWithFile(SourceBase):
        model_config = SettingsConfigDict(yaml_file=yaml_file)

    return _ConfigWithFile()  # type: ignore
