import os
from typing import Literal

from pydantic import BaseModel, model_validator


class AWSCredentials(BaseModel):
    endpoint: str | None = None
    key_id: str | None = None
    secret: str | None = None
    region: str | None = None
    use_ssl: bool = False
    url_style: str = "path"

    @model_validator(mode="after")
    def _resolve_from_env(self) -> "AWSCredentials":
        if self.endpoint is None:
            val = os.getenv("AWS_ENDPOINT_URL_S3") or os.getenv("AWS_ENDPOINT_URL")
            if val is None:
                raise ValueError(
                    "endpoint must be set in config or via AWS_ENDPOINT_URL_S3 / AWS_ENDPOINT_URL"
                )
            self.endpoint = val
        if self.key_id is None:
            val = os.getenv("AWS_ACCESS_KEY_ID")
            if val is None:
                raise ValueError("key_id must be set in config or via AWS_ACCESS_KEY_ID")
            self.key_id = val
        if self.secret is None:
            val = os.getenv("AWS_SECRET_ACCESS_KEY")
            if val is None:
                raise ValueError("secret must be set in config or via AWS_SECRET_ACCESS_KEY")
            self.secret = val
        if self.region is None:
            self.region = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
        return self


class S3StorageConfig(BaseModel):
    type: Literal["s3"]

    source_path: str  # e.g. s3://bucket/input
    destination_path: str  # e.g. s3://bucket/output

    input_file_format: Literal["txt", "json", "json.gz", "csv", "csv.gz", "parquet"]
    output_file_format: Literal["json", "json.gz", "csv", "csv.gz", "parquet"]

    connection_params: AWSCredentials
    write_buffer_size: int = 50
