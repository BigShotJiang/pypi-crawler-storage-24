from typing import Literal

from pydantic import BaseModel, DirectoryPath


class FilesystemStorageConfig(BaseModel):
    type: Literal["filesystem"]

    # Source configuration
    input_file_format: Literal["txt", "json", "json.gz", "csv", "csv.gz", "parquet"]
    output_file_format: Literal["json", "json.gz", "csv", "csv.gz", "parquet"]

    # DirectoryPath validates these are valid paths that exist
    source_directory: DirectoryPath
    target_directory: DirectoryPath
    write_buffer_size: int = 50
