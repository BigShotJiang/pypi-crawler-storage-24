from pydantic_settings import SettingsConfigDict

from mesa_runtime.config.config_base import SourceBase


def load_config(yaml_file: str = "config.yaml") -> SourceBase:
    """Load settings from a specific YAML file."""

    class _ConfigWithFile(SourceBase):
        model_config = SettingsConfigDict(yaml_file=yaml_file)

    return _ConfigWithFile()  # type: ignore
