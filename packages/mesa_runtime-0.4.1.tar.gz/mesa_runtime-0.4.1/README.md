# MESA Runtime

A stateless runtime for deploying MESA registered models onto GSTT Infrastructure. It syncs models from S3, reads unprocessed documents from Snowflake, runs inference, and writes results back.

## Requirements

- Python 3.13+
- [uv](https://github.com/astral-sh/uv) package manager

## Installation

```bash
uv sync
```

## Configuration

Create a `config.yaml` file (see example below):

```yaml
my_source:
  model_s3_uri: "s3://aicentre-nlpteam-mesa-build/models/oncoqwen/oncoqwen_1/"

  storage:
    type: snowflake
    source_database: "str"
    source_schema: "str"
    source_table: "str"

    sink_database: "str"
    sink_schema: "str"
    sink_table: "str"

    connection_params:
      account: "str"
      user: "str"
      role: "str"
      password: "str"
      warehouse: "str"
      database: "str"
```

## Usage

```bash
# Run with default config.yaml
mesa_runtime

# Or specify a config file
mesa_runtime --config /path/to/config.yaml
```

## Docker

```bash
docker build -t mesa-runtime .
docker run mesa-runtime
```

## Development

```bash
# Run linting and tests
make test

# Auto-fix linting issues
make fix

# Run tests with coverage
make cov
```
