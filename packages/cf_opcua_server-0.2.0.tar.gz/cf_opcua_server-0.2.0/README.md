# cf-opcua-server

Current-phase Cogniflow OPC UA owner module.

The package still publishes under the existing `cf-opcua-server` name for compatibility, but it now covers both:

- virtual OPC UA server utilities for demos
- reusable one-shot OPC UA read APIs for owner-module consumers
- a compact JSON read surface consumed by `cf-pipeline-engine` for runner-owned `cfio:OpcuaReaderStep`

Architecture note:

- `cf_datahive` is the reference owner for storage egress
- `cf_opcua_server` is the current owner for OPC UA integration until a future dedicated rename/migration task possibly broadens the package to `cf-opencua`

Published distribution name:

```bash
pip install cf-opcua-server
```

## Usage

```bash
cf-opcua-server start --interval 1.0
```

Read a snapshot from an OPC UA endpoint:

```bash
cf-opcua-server read --endpoint opc.tcp://127.0.0.1:4840/VirtualPhServer
```

Python API:

```python
from cf_opcua_server import DEFAULT_NODE_MAP, read_nodes_once_json_sync, read_nodes_once_sync

payload = read_nodes_once_sync(
    "opc.tcp://127.0.0.1:4840/VirtualPhServer",
    DEFAULT_NODE_MAP,
    timeout=2.0,
)
print(payload)

payload_json = read_nodes_once_json_sync(
    "opc.tcp://127.0.0.1:4840/VirtualPhServer",
    DEFAULT_NODE_MAP,
    timeout=2.0,
)
print(payload_json)
```

The default read mapping uses the virtual demo nodes:

- `pH`
- `temperature`
- `timestamp`

Runner-owned consumers that need a single-line payload can use:

```bash
cf-opcua-server read --compact --endpoint opc.tcp://127.0.0.1:4840/VirtualPhServer
```

## Publishing

`cf_opcua_server` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_opcua_server_windows_publish.yml`
- Package directory: `sandcastle/cf_opcua_server`
- PyPI tag: `cf-opcua-server-v<version>`
- TestPyPI tag: `cf-opcua-server-v<version>-test`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_opcua_server_windows_publish.yml `
  -PackageDir sandcastle/cf_opcua_server `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_opcua_server_windows_publish.yml `
  -PackageDir sandcastle/cf_opcua_server `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```
