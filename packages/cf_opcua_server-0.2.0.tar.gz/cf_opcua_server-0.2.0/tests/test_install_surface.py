from __future__ import annotations

from importlib import metadata
from pathlib import Path
import subprocess
import sys

import cf_opcua_server


def _script_path() -> Path:
    python_dir = Path(sys.executable).resolve().parent
    candidate_dirs = (
        python_dir,
        python_dir / "Scripts",
        python_dir.parent / "Scripts",
    )
    for scripts_dir in candidate_dirs:
        for candidate in (
            "cf-opcua-server.exe",
            "cf-opcua-server.cmd",
            "cf-opcua-server-script.py",
            "cf-opcua-server",
        ):
            path = scripts_dir / candidate
            if path.is_file():
                return path
    raise FileNotFoundError(
        f"cf-opcua-server console script not found near interpreter {Path(sys.executable).resolve()}"
    )


def test_distribution_metadata_matches_module_version() -> None:
    assert metadata.version("cf-opcua-server") == cf_opcua_server.__version__
    assert "read_nodes_once" in cf_opcua_server.__all__
    assert "read_nodes_once_json_sync" in cf_opcua_server.__all__
    assert "read_nodes_once_sync" in cf_opcua_server.__all__


def test_installed_console_script_help_surface() -> None:
    result = subprocess.run(
        [str(_script_path()), "--help"],
        check=False,
        capture_output=True,
        text=True,
    )

    combined_output = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined_output
    assert "Cogniflow OPC UA tools" in combined_output
    assert "start" in combined_output
    assert "read" in combined_output


def test_read_command_help_exposes_compact_runtime_surface() -> None:
    result = subprocess.run(
        [str(_script_path()), "read", "--help"],
        check=False,
        capture_output=True,
        text=True,
    )

    combined_output = f"{result.stdout}\n{result.stderr}"
    assert result.returncode == 0, combined_output
    assert "--compact" in combined_output
