"""
engines.py — Stage 1: Three-engine OCR runners.

All three engines return the same schema:
    {"text": str, "confidence": float, "bbox": [x1,y1,x2,y2], "engine": str}

Key design decisions:
- EasyOCR and PaddleOCR are lazy-initialised at module level (10–30 s startup).
- USE_GPU from config is wired into both GPU engine initialisers.
- GPU engines run SEQUENTIALLY to avoid CUDA context conflicts across threads.
- Tesseract (CPU-only) runs in a thread so it overlaps with GPU engine inference.
- Every engine is wrapped in try/except — a failure returns [] so the pipeline
  continues with the remaining engines.
"""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import numpy as np
import pytesseract
from PIL import Image

from . import config  # sets tesseract_cmd + loads .env at import time
from .logger import get_logger

log = get_logger(__name__)

# ── Lazy singletons ──────────────────────────────────────────────────────────
_easyocr_reader: Any = None
_paddle_ocr: Any = None
_lock = threading.Lock()


def _get_easyocr():
    global _easyocr_reader
    if _easyocr_reader is None:
        with _lock:
            if _easyocr_reader is None:
                import easyocr  # noqa: PLC0415
                log.info("Initialising EasyOCR (gpu=%s) …", config.USE_GPU)
                _easyocr_reader = easyocr.Reader(["en"], gpu=config.USE_GPU)
                log.info("EasyOCR ready.")
    return _easyocr_reader


def _get_paddleocr():
    global _paddle_ocr
    if _paddle_ocr is None:
        with _lock:
            if _paddle_ocr is None:
                from paddleocr import PaddleOCR  # noqa: PLC0415
                log.info("Initialising PaddleOCR (gpu=%s) …", config.USE_GPU)
                _paddle_ocr = PaddleOCR(
                    use_angle_cls=True,
                    lang="en",
                    use_gpu=config.USE_GPU,   # ← wired from config (review fix #6)
                )
                log.info("PaddleOCR ready.")
    return _paddle_ocr


# ── Public runners ───────────────────────────────────────────────────────────


def run_tesseract(img: np.ndarray) -> list[dict]:
    """Tesseract LSTM + sparse-text mode. Expects binarized grayscale."""
    try:
        pil_img = Image.fromarray(img)
        data = pytesseract.image_to_data(
            pil_img,
            output_type=pytesseract.Output.DICT,
            config="--oem 1 --psm 11",
        )
        results: list[dict] = []
        for i, txt in enumerate(data["text"]):
            txt = txt.strip()
            conf = int(data["conf"][i])
            if txt and conf > config.MIN_TESSERACT_CONF:
                x, y, w, h = (
                    data["left"][i], data["top"][i],
                    data["width"][i], data["height"][i],
                )
                results.append({
                    "text": txt,
                    "confidence": conf / 100.0,
                    "bbox": [x, y, x + w, y + h],
                    "engine": "tesseract",
                })
        log.info("Tesseract: %d detections.", len(results))
        return results
    except Exception as exc:
        log.warning("Tesseract failed: %s", exc)
        return []


def run_paddleocr(img: np.ndarray) -> list[dict]:
    """PaddleOCR PP-OCRv5: DBNet + SVTR. Expects denoised colour image."""
    try:
        paddle = _get_paddleocr()
        result = paddle.ocr(img)
        results: list[dict] = []
        if result and result[0]:
            for line in result[0]:
                box, (text, conf) = line
                xs = [p[0] for p in box]
                ys = [p[1] for p in box]
                results.append({
                    "text": text,
                    "confidence": float(conf),
                    "bbox": [min(xs), min(ys), max(xs), max(ys)],
                    "engine": "paddleocr",
                })
        log.info("PaddleOCR: %d detections.", len(results))
        return results
    except Exception as exc:
        log.warning("PaddleOCR failed: %s", exc)
        return []


def run_easyocr(img: np.ndarray) -> list[dict]:
    """EasyOCR: CRAFT + CRNN. Expects adaptive-threshold grayscale."""
    try:
        reader = _get_easyocr()
        raw = reader.readtext(img, detail=1, paragraph=False)
        results: list[dict] = []
        for box, text, conf in raw:
            xs = [p[0] for p in box]
            ys = [p[1] for p in box]
            results.append({
                "text": text,
                "confidence": float(conf),
                "bbox": [min(xs), min(ys), max(xs), max(ys)],
                "engine": "easyocr",
            })
        log.info("EasyOCR: %d detections.", len(results))
        return results
    except Exception as exc:
        log.warning("EasyOCR failed: %s", exc)
        return []


def run_all_parallel(variants: dict[str, np.ndarray]) -> list[list[dict]]:
    """
    Whole-image fallback: run all three engines on pre-built image variants.
    Used when detect_regions() finds nothing (very faint or atypical diagrams).
    Tesseract runs in a thread (CPU-safe); GPU engines run sequentially.
    """
    with ThreadPoolExecutor(max_workers=1) as executor:
        tess_future = executor.submit(run_tesseract, variants["for_tesseract"])
        paddle_results = run_paddleocr(variants["for_paddleocr"])
        easy_results = run_easyocr(variants["for_easyocr"])

    tess_results = tess_future.result()
    return [tess_results, paddle_results, easy_results]


# ── Two-stage pipeline (detection → per-crop recognition) ────────────────────
# This is the Google Vision-style architecture that makes the difference on
# engineering diagrams. Stage 1 asks PaddleOCR's DBNet detector ONLY WHERE
# text regions are (det=True, rec=False). Stage 2 crops each region out of
# the original high-resolution image, deskews it individually, and runs all
# three engines on that clean, upright, line-suppressed crop.


def detect_regions(img: np.ndarray) -> list[np.ndarray]:
    """
    Stage 1 — Use PaddleOCR's DBNet detector to locate all text regions.

    We pass det=True, rec=False so PaddleOCR only runs its detection network
    and returns bounding quads without doing any recognition. This gives us
    accurate region locations without committing to PaddleOCR's recognition
    output for each one — we'll run all three engines on the crops ourselves.

    Returns a list of (4, 2) numpy arrays, one per detected region, with
    corner coordinates in the original image's pixel space.
    """
    try:
        paddle = _get_paddleocr()
        results = paddle.ocr(img, det=True, rec=False)
        if not results or results[0] is None:
            log.warning("DBNet returned no regions — will use whole-image fallback.")
            return []
        quads = []
        for pts in results[0]:
            arr = np.array(pts, dtype=np.float32)
            if arr.shape == (4, 2):
                quads.append(arr)
        log.info("DBNet detected %d text regions.", len(quads))
        return quads
    except Exception as exc:
        log.warning("detect_regions failed: %s — falling back to whole-image mode.", exc)
        return []


def _tess_on_crop(crop: np.ndarray, bbox: list[float]) -> list[dict]:
    """
    Run Tesseract on a single pre-processed crop.

    We use PSM 7 (single text line) first — the right mode for a crop that
    contains exactly one detected text region. If that returns nothing (e.g.
    a multi-word label) we retry with PSM 6 (uniform block of text).
    The bbox argument carries the region's location in original image space
    so downstream voters and pipeline output use correct coordinates.
    """
    try:
        pil_img = Image.fromarray(crop)
        for psm in (7, 6):
            data = pytesseract.image_to_data(
                pil_img,
                output_type=pytesseract.Output.DICT,
                config=f"--oem 1 --psm {psm}",
            )
            tokens = []
            for i, txt in enumerate(data["text"]):
                txt = txt.strip()
                conf = int(data["conf"][i])
                if txt and conf > config.MIN_TESSERACT_CONF:
                    tokens.append((txt, conf / 100.0))
            if tokens:
                # Combine all tokens from this crop into one result whose
                # bbox is the original-image region location (not crop-local)
                combined_text = " ".join(t for t, _ in tokens)
                avg_conf = sum(c for _, c in tokens) / len(tokens)
                return [{"text": combined_text, "confidence": avg_conf,
                         "bbox": bbox, "engine": "tesseract"}]
        return []
    except Exception as exc:
        log.warning("_tess_on_crop failed: %s", exc)
        return []


def _easy_on_crop(crop: np.ndarray, bbox: list[float]) -> list[dict]:
    """
    Run EasyOCR on a single pre-processed crop.
    EasyOCR receives the already-binarized, upright, line-suppressed crop
    so its CRAFT detector works on clean input with no competing line noise.
    """
    try:
        reader = _get_easyocr()
        raw = reader.readtext(crop, detail=1, paragraph=False)
        results = []
        for _, text, conf in raw:
            text = text.strip()
            if text:
                results.append({"text": text, "confidence": float(conf),
                                 "bbox": bbox, "engine": "easyocr"})
        return results
    except Exception as exc:
        log.warning("_easy_on_crop failed: %s", exc)
        return []


def _paddle_rec_on_crop(crop: np.ndarray, bbox: list[float]) -> list[dict]:
    """
    Run PaddleOCR's recognition-only step on a pre-processed crop.

    We use det=False, rec=True so PaddleOCR skips its internal detection
    (we already know where the text is) and only runs SVTR/CRNN recognition.
    This is faster and more accurate than re-running the full pipeline on
    a crop that's already been isolated and straightened.
    """
    try:
        paddle = _get_paddleocr()
        results_raw = paddle.ocr(crop, det=False, rec=True)
        results = []
        if results_raw and results_raw[0]:
            for line in results_raw[0]:
                if isinstance(line, (list, tuple)) and len(line) >= 2:
                    text = str(line[0]).strip()
                    conf = float(line[1]) if isinstance(line[1], (int, float)) else 0.5
                    if text:
                        results.append({"text": text, "confidence": conf,
                                         "bbox": bbox, "engine": "paddleocr"})
        return results
    except Exception as exc:
        log.warning("_paddle_rec_on_crop failed: %s", exc)
        return []


def run_two_stage(
    original: np.ndarray,
    variants: dict[str, np.ndarray],
) -> list[list[dict]]:
    """
    Two-stage OCR: detect text regions, then recognise each crop individually.

    This is the main entry point for engineering diagrams. It replaces
    run_all_parallel() when the detector finds at least one region.

    The return type is the same as run_all_parallel() — a list of three
    lists (one per engine) of {text, confidence, bbox, engine} dicts — so
    the voter receives exactly the same schema it already expects. The only
    difference is that the bbox values now come from the DBNet detector's
    output (more accurate region locations) instead of each engine's own
    detection heuristics, and each recognition call sees a clean, upright,
    line-free crop instead of a messy whole-image slice.

    Falls back transparently to run_all_parallel() if detection finds nothing.
    """
    # Import here to avoid a circular import (preprocessor imports config,
    # engines imports preprocessor — keeping the import local breaks the cycle)
    from .preprocessor import crop_region

    # ── Stage 1: detect region locations ─────────────────────────────────────
    # Feed the denoised colour variant to DBNet — it was trained on colour
    quads = detect_regions(variants["for_paddleocr"])

    if not quads:
        log.warning("No regions detected — falling back to whole-image mode.")
        return run_all_parallel(variants)

    # ── Stage 2: recognise each crop with all three engines ───────────────────
    tess_all, easy_all, paddle_all = [], [], []

    with ThreadPoolExecutor(max_workers=1) as executor:
        for idx, quad in enumerate(quads):
            try:
                crop, bbox = crop_region(original, quad)
            except Exception as exc:
                log.warning("crop_region failed for quad %d: %s", idx, exc)
                continue

            # Tesseract in a background thread (CPU — safe to thread)
            tess_future = executor.submit(_tess_on_crop, crop, bbox)

            # GPU engines sequentially (avoids CUDA context conflict)
            paddle_all.extend(_paddle_rec_on_crop(crop, bbox))
            easy_all.extend(_easy_on_crop(crop, bbox))

            try:
                tess_all.extend(tess_future.result(timeout=30))
            except Exception as exc:
                log.warning("Tesseract future failed for region %d: %s", idx, exc)

    log.info(
        "Two-stage complete: Tesseract=%d, PaddleOCR=%d, EasyOCR=%d results.",
        len(tess_all), len(paddle_all), len(easy_all),
    )
    return [tess_all, paddle_all, easy_all]
