"""
corrector.py — Stage 3: Domain-aware SymSpell post-corrector.

Post-processes voted OCR results by spell-correcting general English tokens
while NEVER modifying domain-specific terms (valve codes, pipe labels, etc.).

Logic per token:
  1. Skip if the token is in DOMAIN_TERMS (any case normalisation applied).
  2. Skip if the token looks like a numeric/alphanumeric code (e.g. "DN300").
  3. Apply SymSpell with edit-distance ≤ 2; only accept suggestions with
     high corpus frequency (avoids over-correcting rare but valid words).
"""

from __future__ import annotations

import re

from symspellpy import SymSpell, Verbosity

from . import config

# ── Initialise SymSpell once at module level ─────────────────────────────────
_sym_spell: SymSpell | None = None


def _get_sym_spell() -> SymSpell:
    global _sym_spell
    if _sym_spell is None:
        _sym_spell = SymSpell(max_dictionary_edit_distance=config.SYMSPELL_MAX_EDIT_DISTANCE)
        if not _sym_spell.load_dictionary(
            config.SYMSPELL_DICT_PATH,
            term_index=0,
            count_index=1,
        ):
            print(
                f"[WARN] SymSpell dictionary not found at {config.SYMSPELL_DICT_PATH}. "
                "Run download_models.py. Spell correction disabled."
            )
            # Return an initialised-but-empty SymSpell so callers don't crash
    return _sym_spell


# ── Numeric / code pattern — never correct these tokens ──────────────────────
_CODE_PATTERN = re.compile(r"^\d+[\w/\-]*$|^[\w/\-]*\d+[\w/\-]*$")


def correct_token(token: str) -> str:
    """
    Correct a single OCR token, respecting domain vocabulary.

    Returns the original token unchanged if:
    - It matches a domain term (case-insensitive look-up)
    - It looks like a numeric/alphanumeric code (e.g. "DN300", "2B-PRV")
    """
    upper = token.upper()
    if upper in config.DOMAIN_TERMS:
        return token
    if upper in config.DOMAIN_MISREADS:
        return config.DOMAIN_MISREADS[upper]

    # Numeric / code pattern check
    if _CODE_PATTERN.match(token):
        return token

    sym = _get_sym_spell()
    suggestions = sym.lookup(
        token,
        Verbosity.CLOSEST,
        max_edit_distance=config.SYMSPELL_MAX_EDIT_DISTANCE,
        include_unknown=True,
    )

    if suggestions:
        best = suggestions[0]
        # Only accept if the correction is well attested in general English
        if best.count >= config.SYMSPELL_MIN_FREQUENCY:
            return best.term

    return token


def post_correct(voted_results: list[dict]) -> list[dict]:
    """
    Apply ``correct_token`` to every token in every result entry.

    Modifies results in-place and also returns the list.
    """
    for item in voted_results:
        tokens = item["text"].split()
        item["text"] = " ".join(correct_token(t) for t in tokens)
    return voted_results
