"""Configuration module for miobot."""

from miobot.config.loader import get_config_path, load_config
from miobot.config.schema import Config

__all__ = ["Config", "load_config", "get_config_path"]
