"""Chat channels module with plugin architecture."""

from miobot.channels.base import BaseChannel
from miobot.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]
