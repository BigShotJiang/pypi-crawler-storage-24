"""CLI module for miobot."""
