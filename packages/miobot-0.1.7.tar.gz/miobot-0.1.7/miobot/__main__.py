"""
Entry point for running miobot as a module: python -m miobot
"""

from miobot.cli.commands import app

if __name__ == "__main__":
    app()
