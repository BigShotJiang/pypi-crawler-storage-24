"""Heartbeat service for periodic agent wake-ups."""

from miobot.heartbeat.service import HeartbeatService

__all__ = ["HeartbeatService"]
