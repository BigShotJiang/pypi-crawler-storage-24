"""
miobot - A lightweight AI agent framework
"""

__version__ = "0.1.7"
__logo__ = "👾"
