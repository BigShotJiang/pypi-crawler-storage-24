# 脚本

## 提交推送脚本

使用 `./scripts/cp` 替代手动 `git commit` 和 `git push`，自动更新 CHANGELOG。

### 使用方法

```bash
# 传统方式
git add -A
git commit -m "feat: 添加新功能"
git push

# 使用 cp 脚本（自动更新 CHANGELOG）
./scripts/cp "feat: 添加新功能"
```

### 功能

1. 暂存所有更改 (`git add -A`)
2. 使用您的信息创建提交
3. 更新 `docs/CHANGELOG.md`，包含：
   - 提交信息
   - 提交哈希
   - 时间戳
4. 将 CHANGELOG 更改合并到提交
5. 推送到远程

### Git Hook（可选）

也可以设置 pre-push hook：

```bash
cp scripts/git-hooks/pre-push .git/hooks/pre-push
chmod +x .git/hooks/pre-push
```

每次 `git push` 都会自动更新 CHANGELOG。

## 向量库脚本

### 固定入库到 `doc_knowledge`

```bash
python3 scripts/index_book_to_doc_knowledge.py /path/to/book.txt --title "书名"
```

说明：
- 此脚本强制写入 `doc_knowledge`
- 不会按书名创建 `book_xxx` collection

### 迁移历史 `book_xxx` 到 `doc_knowledge`

```bash
python3 scripts/migrate_collection_to_doc_knowledge.py --source book_juezhi
```

迁移后可选择删除旧 collection：

```bash
python3 scripts/migrate_collection_to_doc_knowledge.py --source book_juezhi --delete-source
```
