from __future__ import annotations
import inspect
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional


class HistoryEntry:
    __slots__ = ("value", "timestamp", "filename", "lineno", "function")

    def __init__(
        self,
        value: Any,
        timestamp: datetime,
        filename: str,
        lineno: int,
        function: str,
    ) -> None:
        self.value = value
        self.timestamp = timestamp
        self.filename = filename
        self.lineno = lineno
        self.function = function

    def __repr__(self) -> str:
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")
        return (
            f"HistoryEntry(value={self.value!r}, time={ts}, "
            f"at {self.filename}:{self.lineno} in {self.function})"
        )


class Chronicle:
    def __init__(self, max_history: int = 100) -> None:
        self.__dict__["_history"]: Dict[str, Deque[HistoryEntry]] = {}
        self.__dict__["_max_history"]: int = max_history
        self.__dict__["_lock"]: threading.Lock = threading.Lock()
        self.__dict__["_recording"]: bool = True

    def __setattr__(self, name: str, value: Any) -> None:
        self.__dict__[name] = value

        if name.startswith("_"):
            return

        if not self.__dict__.get("_recording", True):
            return

        frame = inspect.currentframe()
        caller = frame.f_back if frame else None
        if caller:
            filename: str = caller.f_code.co_filename
            lineno: int = caller.f_lineno
            function: str = caller.f_code.co_name
        else:
            filename, lineno, function = "<unknown>", 0, "<unknown>"

        entry = HistoryEntry(
            value=value,
            timestamp=datetime.now(timezone.utc),
            filename=filename,
            lineno=lineno,
            function=function,
        )

        with self.__dict__["_lock"]:
            if name not in self.__dict__["_history"]:
                self.__dict__["_history"][name] = deque(
                    maxlen=self.__dict__["_max_history"]
                )
            self.__dict__["_history"][name].append(entry)

    def get_history(self, attr_name: str) -> List[HistoryEntry]:
        with self.__dict__["_lock"]:
            history_deque = self.__dict__["_history"].get(attr_name)
            return list(history_deque) if history_deque else []

    def undo(self, attr_name: str) -> Any:
        with self.__dict__["_lock"]:
            hist = self.__dict__["_history"].get(attr_name)
            if not hist:
                raise KeyError(
                    f"No recorded history for attribute '{attr_name}'."
                )

            hist.pop()

            if hist:
                previous_value = hist[-1].value
                self.__dict__[attr_name] = previous_value
                return previous_value
            else:
                self.__dict__.pop(attr_name, None)
                del self.__dict__["_history"][attr_name]
                return None

    def audit(self) -> str:
        lines: List[str] = []
        border = "=" * 72
        lines.append(border)
        lines.append(
            f"  CHRONICLE AUDIT — {self.__class__.__name__} "
            f"(id={id(self):#x})"
        )
        lines.append(border)

        with self.__dict__["_lock"]:
            history = self.__dict__["_history"]
            if not history:
                lines.append("  (no attribute changes recorded)")
            else:
                for attr, entries in history.items():
                    lines.append(f"\n  Attribute: {attr!r}")
                    lines.append(f"  {'—' * 40}")
                    for idx, entry in enumerate(entries, start=1):
                        ts = entry.timestamp.strftime(
                            "%Y-%m-%d %H:%M:%S.%f"
                        )
                        lines.append(f"    [{idx}] value = {entry.value!r}")
                        lines.append(f"        time  = {ts} UTC")
                        lines.append(
                            f"        where = {entry.filename}:{entry.lineno}"
                            f" in {entry.function}()"
                        )

        lines.append(f"\n{border}")
        report = "\n".join(lines)
        print(report)
        return report

    def toggle_recording(self, enable: bool) -> None:
        self.__dict__["_recording"] = enable

    def clear_history(self, attr_name: Optional[str] = None) -> None:
        with self.__dict__["_lock"]:
            if attr_name is not None:
                self.__dict__["_history"].pop(attr_name, None)
            else:
                self.__dict__["_history"].clear()
