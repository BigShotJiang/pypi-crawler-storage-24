"""Bijoy — Object Observability for Python.

A lightweight library by Bijoy that automatically records the history
of every attribute change on your objects for debugging and auditing.

Quick start::

    from bijoy import Chronicle

    class Server(Chronicle):
        def __init__(self):
            super().__init__(max_history=50)
            self.status = "booting"

    srv = Server()
    srv.status = "ready"
    srv.audit()
"""

from bijoy.chronicle import Chronicle, HistoryEntry

__all__ = ["Chronicle", "HistoryEntry"]
__version__ = "1.0.1"
__author__ = "Bijoy"
