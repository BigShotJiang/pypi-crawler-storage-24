"""haeres — knowledge inheritance for AI agents.

Tasks execute and die. The knowledge they discover shouldn't die with them.
haeres is the mechanism of inheritance — how AI agent generations pass
knowledge forward through time.

Skills are the genome. Tasks are organisms. Agents are vessels.
haeres is heredity.

Usage:
    from haeres import post, read, clear, archive

    post("Found NAV discrepancy", sender="avantis-verify", to="terry", severity="action")
    msgs = read(to="terry")
    clear(msgs[0]["id"])
"""

from haeres.board import post, read, clear, clear_all, archive, archive_all, count

__all__ = ["post", "read", "clear", "clear_all", "archive", "archive_all", "count"]
__version__ = "0.1.0"
