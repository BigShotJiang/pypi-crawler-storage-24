# haeres

*Latin: heir, inheritor*

Knowledge inheritance for AI agents. DNA for LLMs.

```
pip install haeres
```

## The idea

Tasks execute and die. The knowledge they discover shouldn't die with them.

In biology, organisms are ephemeral but genes persist across generations. The same pattern applies to AI agents: each instance is temporary, but the knowledge it produces can outlive it — shaping how future instances think and act.

**haeres** is the mechanism of inheritance. A shared directory where agents leave knowledge for future agents to find. No server, no framework, no SDK. Just files.

| Biology | AI system |
|---|---|
| Genes | Skills (persistent knowledge) |
| Organisms | Tasks (executed, then gone) |
| Bodies | Agents (commodity instances) |
| Heredity | **haeres** |
| Natural selection | Human review |

## Usage

### Python

```python
from haeres import post, read, clear

# A task discovers something — leave it for the next generation
post("KIID shows 0.42% TER but Morningstar shows 0.45%",
     sender="avantis-verify", to="finance-tasks", severity="action")

# Next generation reads what predecessors learned
msgs = read(to="finance-tasks")

# Knowledge consumed — clear it
clear(msgs[0]["id"])
```

### CLI

```bash
haeres post "Found NAV discrepancy" --from avantis-verify --to terry -v action
haeres list --to terry
haeres clear 2026-03-20-1915-nav-discrepancy
haeres archive --all
```

### MCP

haeres includes an MCP server, making it available as native tools for any MCP-connected LLM:

```bash
haeres-mcp  # starts the MCP server
```

### Any agent, any platform

No SDK needed. Any agent that can read and write files can inherit:

```bash
cat > ~/notes/ACTA/2026-03-20-message.md << 'EOF'
---
from: my-skill
to: all
severity: info
ts: 2026-03-20T19:15+0800
---

Knowledge that should outlive this task.
EOF
```

## Design principles

- **Agents are commodity instances.** Every LLM invocation is interchangeable.
- **Skills are the identity.** Knowledge comes from what you load, not who you are.
- **Files are the communication layer.** Durable, cross-platform, survives reboots.
- **Async over sync.** Like the endocrine system, not the nervous system.

## Configuration

```bash
export ACTA_DIR=/path/to/shared/board  # default: ~/notes/ACTA
```

## License

MIT
