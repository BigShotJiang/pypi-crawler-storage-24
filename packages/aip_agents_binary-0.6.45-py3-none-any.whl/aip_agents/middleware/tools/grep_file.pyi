from aip_agents.middleware.backends.protocol import GrepMatch as GrepMatch
from aip_agents.middleware.backends.utils import ensure_absolute_path as ensure_absolute_path, format_grep_matches as format_grep_matches
from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

GREP_TOOL_DESCRIPTION: str

class GrepInput(BaseModel):
    """Input schema for grep tool."""
    path: str
    pattern: str
    max_matches: int

class GrepTool(BaseTool):
    """Tool for searching file contents across directories."""
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
