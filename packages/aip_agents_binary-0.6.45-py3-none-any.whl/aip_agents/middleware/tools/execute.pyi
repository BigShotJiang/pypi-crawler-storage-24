from _typeshed import Incomplete
from aip_agents.middleware.backends.protocol import BackendProtocol as BackendProtocol, ExecuteResult as ExecuteResult
from aip_agents.utils import get_logger as get_logger
from aip_agents.utils.artifacts import ArtifactTracker as ArtifactTracker
from aip_agents.utils.file_watchers import E2BFileWatcher as E2BFileWatcher, FileWatcherStrategy as FileWatcherStrategy, create_local_strategy as create_local_strategy
from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated

logger: Incomplete

class ExecuteInput(BaseModel):
    """Input schema for the execute tool.

    Attributes:
        command: The shell command to execute.
        timeout: Timeout in seconds (optional, defaults to 30).
    """
    command: str
    timeout: int

class ExecuteTool(BaseTool):
    """Tool for executing shell commands via backend with artifact tracking.

    This tool wraps backend command execution with proper timeout handling,
    output formatting, and artifact tracking for files created during execution.

    Attributes:
        name: Tool name ('execute').
        description: Tool description for LLM.
        args_schema: Input schema class.
        backend: BackendProtocol instance for execution.
        max_execute_timeout: Maximum allowed timeout in seconds.
    """
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[BackendProtocol, None]
    max_execute_timeout: int
