from _typeshed import Incomplete
from aip_agents.middleware.backends.protocol import BackendProtocol
from aip_agents.middleware.base import AgentMiddleware, ModelRequest
from aip_agents.skills.models import Skill
from pathlib import Path
from pydantic import BaseModel
from typing import Any, NotRequired, TypedDict

__all__ = ['SkillConfig', 'SkillMetadata', 'SkillsMiddleware']

class SkillConfig(BaseModel):
    '''Configuration for skills middleware setup.

    Attributes:
        skills (list[Skill | str] | None): Local skill objects or GitHub sources. Defaults to None.
        backend (BackendProtocol | None): Backend for staging/reading. Defaults to None (InMemoryBackend).
        sources (list[str] | None): Backend source roots to scan for skills. Defaults to ["/skills/"].
        destination_root (str): Backend root under which skills are staged. Defaults to "/skills".
        auto_read (bool): Whether to auto-load SKILL.md bodies into the system prompt. Defaults to False.
        auto_read_limit (int | None): Maximum number of skills to auto-load. Defaults to None (all).
        include_read_tool (bool): Whether to expose the read_file tool. Defaults to True.
        local_skill_root (str | Path): Local install root for GitHub skill sources. Defaults to ".agents/skills".
    '''
    skills: list[Skill | str] | None
    backend: Any | None
    sources: list[str] | None
    destination_root: str
    auto_read: bool
    auto_read_limit: int | None
    include_read_tool: bool
    local_skill_root: str | Path
    def create_backend(self, backend: BackendProtocol | None = None) -> BackendProtocol:
        """Create a backend instance for skills.

        Args:
            backend (BackendProtocol | None): Optional backend override. Defaults to None.

        Returns:
            BackendProtocol: Backend instance for SkillsMiddleware.
        """
    def create_middleware(self, *, backend: BackendProtocol | None = None) -> SkillsMiddleware:
        """Create SkillsMiddleware from this configuration.

        Args:
            backend (BackendProtocol | None): Optional backend override when none is configured. Defaults to None.

        Returns:
            SkillsMiddleware: Configured middleware instance.
        """
    model_config: Incomplete

class SkillMetadata(TypedDict):
    """Parsed metadata for a skill (from SKILL.md YAML frontmatter)."""
    name: str
    description: str
    path: str
    license: NotRequired[str | None]
    compatibility: NotRequired[str | None]
    metadata: NotRequired[dict[str, Any]]
    allowed_tools: NotRequired[list[str]]

class SkillsMiddleware(AgentMiddleware):
    """AIP middleware that exposes prompt-only skills via progressive disclosure."""
    tools: list[Any]
    system_prompt_additions: str | None
    def __init__(self, *, backend: BackendProtocol, skills: list[Skill | str] | None = None, sources: list[str] | None = None, destination_root: str = '/skills', auto_read: bool = False, auto_read_limit: int | None = None, include_read_tool: bool = True, local_skill_root: str | Path = '.agents/skills') -> None:
        '''Initialize SkillsMiddleware.

        Args:
            backend (BackendProtocol): Backend instance providing storage and file APIs.
            skills (list[Skill] | None, optional): Local skills to stage into backend. Defaults to None.
            sources (list[str] | None, optional): Backend source roots to scan for skills. Defaults to ["/skills/"].
            destination_root (str, optional): Backend root under which skills are staged. Defaults to "/skills".
            auto_read (bool, optional): Whether to auto-load SKILL.md bodies into the system prompt. Defaults to False.
            auto_read_limit (int | None, optional): Maximum number of skills to auto-load. Defaults to None (all).
            include_read_tool (bool, optional): Whether to expose the read_file tool. Defaults to True.
            local_skill_root (str | Path, optional): Local install root for GitHub skill sources. Defaults to
                ".agents/skills".

        Returns:
            None: This initializer returns None.
        '''
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Stage skills and load skills metadata into state.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Inject skills section into the model request system prompt.

        Args:
            request (ModelRequest): Model request to modify.
            state (dict[str, Any]): Agent state containing skills metadata.

        Returns:
            ModelRequest: Modified request.
        """
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op after_model hook.

        Args:
            state (dict[str, Any]): Agent state.

        Returns:
            dict[str, Any]: Empty updates.
        """
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async before_model hook.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async after_model hook.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
