import os
from aip_agents.skills.errors import SkillInstallError as SkillInstallError, SkillValidationError as SkillValidationError
from aip_agents.skills.validation import validate_skill_name as validate_skill_name
from dataclasses import dataclass
from pathlib import Path

class InvalidSkillException(Exception):
    """Fallback exception when gl-connectors-tools is unavailable."""
class SkillException(Exception):
    """Fallback exception when gl-connectors-tools is unavailable."""

@dataclass(frozen=True, slots=True)
class GitHubTreeSource:
    '''A GitHub "tree" URL normalized into components.'''
    owner: str
    repo: str
    ref: str
    subdir: str
    @property
    def skill_name(self) -> str:
        """Return the skill directory name (last segment of subdir).

        Returns:
            str: Skill directory name.
        """

def parse_github_tree_source(source: str) -> GitHubTreeSource:
    """Parse a GitHub tree URL into a normalized form.

    Args:
        source (str): A GitHub URL of the form:
            `https://github.com/<owner>/<repo>/tree/<ref>/<path>`.

    Returns:
        GitHubTreeSource: Parsed components.

    Raises:
        SkillInstallError: If the source is not a supported GitHub tree URL.
    """

class SkillInstaller:
    """Install skills into a canonical local destination root."""
    def __init__(self, *, token: str | None = None) -> None:
        """Initialize a SkillInstaller.

        Args:
            token (str | None, optional): GitHub token used for private repos. Defaults to
                `GITHUB_PERSONAL_ACCESS_TOKEN`, `GITHUB_TOKEN`, or `GH_TOKEN` from the environment.

        Returns:
            None: This initializer returns None.
        """
    async def install_github_tree(self, *, source: str, destination_root: str | os.PathLike[str]) -> Path:
        """Install a skill from a GitHub tree URL into the destination root.

        If the destination already contains a valid skill folder, this is a no-op and
        returns the existing path.

        Args:
            source (str): A GitHub tree URL pointing at a skill directory.
            destination_root (str | os.PathLike[str]): Root directory to install into.

        Returns:
            Path: The installed skill directory path.

        Raises:
            SkillInstallError: If installation fails.
            SkillValidationError: If the installed skill is invalid.
        """
