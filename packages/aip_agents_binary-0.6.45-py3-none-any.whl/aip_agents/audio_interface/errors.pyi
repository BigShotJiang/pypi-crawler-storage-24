class AudioInterfaceError(RuntimeError):
    """Base error for audio interface."""
class AudioSessionUnavailableError(AudioInterfaceError):
    """Provider deps are missing or incompatible."""
class AudioConfigError(AudioInterfaceError, ValueError):
    """Audio config is missing or invalid."""
