from aip_agents.schema.a2a import A2AStreamEventType as A2AStreamEventType
from collections.abc import Awaitable, Callable
from typing import Any

class AIPAudioAgentAdapter:
    """Adapter that turns transcript text into agent replies.

    This wrapper:
    - calls the agent's `arun(...)` method
    - injects a stable thread id via `configurable` for conversation persistence
    - optionally prints internal LangGraph step events when `AIP_AUDIO_DEBUG=1`
    """
    def __init__(self, agent: Any) -> None:
        """Create an adapter around an async-capable agent."""
    async def generate_reply(self, text: str, *, on_a2a_event: Callable[[dict[str, Any]], Awaitable[None]] | None = None, prefer_a2a_stream: bool = False, **kwargs: Any) -> str:
        """Generate an agent reply for a single user transcript.

        Args:
            text: Final transcript text.
            on_a2a_event: Optional async callback invoked for each A2A stream event.
            prefer_a2a_stream: When True, uses `arun_a2a_stream(...)` if available even
                when debug mode is disabled.
            **kwargs: Passed through to the underlying agent call.
        """
