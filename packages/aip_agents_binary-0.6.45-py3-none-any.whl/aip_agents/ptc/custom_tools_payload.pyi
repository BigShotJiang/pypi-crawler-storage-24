from _typeshed import Incomplete
from aip_agents.ptc.custom_tools import PTCCustomToolConfig as PTCCustomToolConfig, PTCToolDef as PTCToolDef
from aip_agents.ptc.naming import CustomToolRuntimeParamSpec as CustomToolRuntimeParamSpec, project_custom_tool_signature as project_custom_tool_signature, sanitize_function_name as sanitize_function_name
from aip_agents.ptc.payload import SandboxPayload as SandboxPayload
from aip_agents.ptc.template_utils import render_template as render_template
from aip_agents.utils.logger import get_logger as get_logger
from dataclasses import dataclass, field

logger: Incomplete

@dataclass
class CustomToolPayloadResult:
    """Result of custom tool payload generation.

    Attributes:
        payload: The sandbox payload with files to upload.
        tool_names: List of sanitized tool names available in sandbox.
    """
    payload: SandboxPayload
    tool_names: list[str] = field(default_factory=list)

def build_custom_tools_payload(config: PTCCustomToolConfig, tool_configs: dict[str, dict[str, object]] | None = None) -> CustomToolPayloadResult:
    """Build sandbox payload for custom LangChain tools.

    Args:
        config: Custom tool configuration with tool definitions.
        tool_configs: Optional per-tool config values to write to defaults.json.

    Returns:
        CustomToolPayloadResult with payload and available tool names.
    """
