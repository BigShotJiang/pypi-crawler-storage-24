# mcparmory-bamboohr-mcp

MCP server for BambooHR API.

Full version coming soon. See [mcparmory.com](https://mcparmory.com)
