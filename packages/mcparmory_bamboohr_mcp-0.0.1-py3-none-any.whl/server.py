"""MCP server for BambooHR API — placeholder."""

def main() -> None:
    print("mcparmory-bamboohr-mcp: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
