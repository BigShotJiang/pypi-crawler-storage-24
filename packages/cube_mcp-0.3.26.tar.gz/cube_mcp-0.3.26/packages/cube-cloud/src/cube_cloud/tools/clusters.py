"""Cube cluster tools: list, status, cluster_login (server-side via tbot)."""

from __future__ import annotations

import base64
import json
import logging

import yaml

from cube_cloud.teleport.kubeconfig import run_kubectl
from cube_cloud.teleport.tbot_manager import tbot

logger = logging.getLogger(__name__)


async def cube_status(cluster: str | None = None, profile: str = "admin") -> str:
    """Get the status of a Cube node."""
    if not tbot.is_ready:
        return "tbot credentials not ready. Server-side kubectl is not available yet."

    if not cluster:
        return "Error: cluster name is required. Use cube_list to see available clusters."

    output, rc = await run_kubectl(
        ["get", "nodes", "-o", "jsonpath={.items[0].metadata.name}"],
        cluster=cluster,
        profile=profile,
    )
    if rc != 0:
        return f"Failed to get node: {output}"

    node_name = output.strip()
    if not node_name:
        return "No nodes found. The Cube may not be running."

    output, rc = await run_kubectl(["describe", "node", node_name], cluster=cluster, profile=profile)
    if rc != 0:
        return f"Failed to describe node: {output}"

    return f"Cube Node Status ({cluster} / {node_name}):\n\n{output}"


async def cube_list(profile: str = "admin") -> str:
    """List available Cube clusters via dynamic tsh kube discovery."""
    if not tbot.is_ready:
        return "tbot credentials not ready. Server-side cluster listing is not available yet."

    clusters = await tbot.list_kube_clusters_tsh(profile=profile)
    if not clusters:
        return "No Cube clusters found. Teleport kube discovery may still be initializing."

    lines = ["Available Cubes:", "=" * 50]
    for c in clusters:
        lines.append(f"  {c}")

    lines.append("")
    lines.append("Use kubectl_exec with a cluster name to run commands.")
    return "\n".join(lines)


async def cube_cluster_login(cluster: str, profile: str = "admin") -> str:
    """Generate a self-contained kubeconfig for a cluster via tbot oneshot.

    Uses tbot kubernetes (v1) output to generate role-scoped kube certs,
    then extracts them into a standalone kubeconfig with embedded certs
    that the user can use locally with kubectl.
    """
    if not tbot.is_ready:
        return "Error: Cube credentials are initializing. Try again in a moment."

    if not cluster:
        return "Error: cluster name is required. Use cube_list to see available clusters."

    kc_path, err = await tbot.get_kube_kubeconfig(cluster, profile)
    if err:
        if "not found" in err.lower() or "not accessible" in err.lower():
            clusters = await tbot.list_kube_clusters_tsh(profile=profile)
            avail_str = ", ".join(clusters) if clusters else "none"
            return f"Error: Cluster '{cluster}' not found. Available: {avail_str}"
        return f"Error: Failed to generate credentials for '{cluster}': {err}"

    # Read the tbot-generated kubeconfig for cluster info
    with open(kc_path) as f:
        kc = yaml.safe_load(f)

    cluster_info = kc["clusters"][0]["cluster"]

    # Get fresh creds via tbot kube credentials exec plugin
    kube_dest = str(kc_path).rsplit("/kubeconfig.yaml", 1)[0]
    exec_info = {
        "apiVersion": "client.authentication.k8s.io/v1",
        "kind": "ExecCredential",
        "spec": {"cluster": {"server": cluster_info["server"]}},
    }
    if "certificate-authority-data" in cluster_info:
        exec_info["spec"]["cluster"]["certificate-authority-data"] = cluster_info["certificate-authority-data"]
    if "tls-server-name" in cluster_info:
        exec_info["spec"]["cluster"]["tls-server-name"] = cluster_info["tls-server-name"]

    env = tbot.tsh_env()
    env["KUBERNETES_EXEC_INFO"] = json.dumps(exec_info)

    import asyncio
    proc = await asyncio.create_subprocess_exec(
        "/usr/local/bin/tbot", "kube", "credentials", f"--destination-dir={kube_dest}",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    stdout_data, stderr_data = await asyncio.wait_for(proc.communicate(), timeout=15)

    if proc.returncode != 0:
        stderr_text = stderr_data.decode(errors="replace").strip()
        return f"Error: Failed to generate credentials for '{cluster}': {stderr_text[:200]}"

    try:
        exec_cred = json.loads(stdout_data)
    except json.JSONDecodeError:
        return f"Error: Failed to parse credentials for '{cluster}'. Contact admin."

    status = exec_cred.get("status", {})
    client_cert = status.get("clientCertificateData", "")
    client_key = status.get("clientKeyData", "")
    expires_at = status.get("expirationTimestamp", "")

    if not client_cert or not client_key:
        return f"Error: Empty credentials for '{cluster}'. Contact admin."

    # Build self-contained kubeconfig with embedded certs
    cluster_cfg: dict = {"server": cluster_info["server"]}
    if "certificate-authority-data" in cluster_info:
        cluster_cfg["certificate-authority-data"] = cluster_info["certificate-authority-data"]
    if "tls-server-name" in cluster_info:
        cluster_cfg["tls-server-name"] = cluster_info["tls-server-name"]

    cert_b64 = client_cert if not client_cert.startswith("-----BEGIN") else base64.b64encode(client_cert.encode()).decode()
    key_b64 = client_key if not client_key.startswith("-----BEGIN") else base64.b64encode(client_key.encode()).decode()

    kubeconfig_yaml = {
        "apiVersion": "v1",
        "kind": "Config",
        "clusters": [{"name": cluster, "cluster": cluster_cfg}],
        "users": [{
            "name": f"cube-mcp-{cluster}",
            "user": {
                "client-certificate-data": cert_b64,
                "client-key-data": key_b64,
            },
        }],
        "contexts": [{
            "name": cluster,
            "context": {"cluster": cluster, "user": f"cube-mcp-{cluster}"},
        }],
        "current-context": cluster,
    }

    result = {
        "kubeconfig": yaml.dump(kubeconfig_yaml, default_flow_style=False),
        "cluster": cluster,
        "expires_at": expires_at,
    }
    return json.dumps(result)
