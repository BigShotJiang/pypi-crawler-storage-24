"""tbot health monitoring, lifecycle management, and on-demand kube cert generation.

tbot runs as an ECS sidecar container and generates short-lived credentials
via the Teleport Machine ID protocol (IAM join method).

Outputs:
  - identity at {data_dir}/identity/ (for tsh commands)
  - on-demand kubernetes certs via tbot oneshot (per profile+cluster)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

TBOT_DATA_DIR = Path(os.environ.get("TBOT_DATA_DIR", "/tbot-data"))
TELEPORT_PROXY = os.environ.get("TELEPORT_PROXY", "edgescaleai.teleport.sh:443")
TBOT_JOIN_TOKEN = os.environ.get("TBOT_JOIN_TOKEN", "cube-mcp-bot-iam")
KUBE_CERT_TTL = os.environ.get("KUBE_CERT_TTL", "24h")
KUBE_CACHE_TTL = int(os.environ.get("KUBE_CACHE_TTL_SECONDS", "82800"))  # 23h
APP_TYPE_CACHE_TTL = int(os.environ.get("APP_TYPE_CACHE_TTL_SECONDS", "3600"))

# Profile names that don't match a Teleport role directly
PROFILE_ROLE_MAP: dict[str, str] = {
    "admin": "cube-mcp-bot",
    "esaiadmin": "cube-mcp-bot",
}


class TbotManager:
    """Monitor tbot sidecar health and credential availability."""

    def __init__(self, data_dir: Path = TBOT_DATA_DIR) -> None:
        self.data_dir = data_dir
        self.identity_dir = data_dir / "identity"
        self.identity_path = self.identity_dir / "identity"
        self.proxy = TELEPORT_PROXY
        self._kube_cache: dict[tuple[str, str], tuple[str, float]] = {}
        self._app_type_cache: dict[str, tuple[str, float]] = {}

    @property
    def is_ready(self) -> bool:
        """Check if tbot has generated a valid identity file."""
        return self.identity_path.exists() and self.identity_path.stat().st_size > 0

    async def wait_ready(self, timeout: float = 60) -> bool:
        """Wait for tbot to generate credentials. Returns True if ready."""
        elapsed = 0.0
        interval = 2.0
        while elapsed < timeout:
            if self.is_ready:
                logger.info("tbot identity ready at %s", self.identity_path)
                return True
            await asyncio.sleep(interval)
            elapsed += interval
        logger.warning("tbot credentials not ready after %.0fs", timeout)
        return False

    def get_identity_path(self, profile: str = "admin") -> Path:
        """Return the identity file path for a given profile.

        Tries per-role identity first, falls back to the shared identity.
        """
        role_identity = self.data_dir / "identity-roles" / profile / "identity"
        if role_identity.exists() and role_identity.stat().st_size > 0:
            return role_identity
        return self.identity_path

    def tsh_base_args(self, profile: str = "admin") -> list[str]:
        """Return base tsh args for identity-based auth, scoped to a role."""
        return [
            "tsh",
            "--proxy", self.proxy,
            "-i", str(self.get_identity_path(profile)),
            "--insecure",
        ]

    def tsh_env(self) -> dict[str, str]:
        """Return minimal environment for running tsh."""
        return {
            "PATH": "/usr/local/bin:/usr/bin:/bin",
            "HOME": "/tmp",
        }

    def tbot_env(self) -> dict[str, str]:
        """Return environment for running tbot oneshot.

        Includes AWS credential chain vars needed for IAM join method.
        """
        env = {
            "PATH": "/usr/local/bin:/usr/bin:/bin",
            "HOME": "/tmp",
        }
        # Pass through AWS credential chain for ECS task role (IAM join)
        for key in ("AWS_CONTAINER_CREDENTIALS_RELATIVE_URI",
                     "AWS_CONTAINER_CREDENTIALS_FULL_URI",
                     "AWS_CONTAINER_AUTHORIZATION_TOKEN",
                     "AWS_DEFAULT_REGION", "AWS_REGION",
                     "ECS_CONTAINER_METADATA_URI_V4"):
            val = os.environ.get(key)
            if val:
                env[key] = val
        return env

    async def list_kube_clusters_tsh(self, profile: str = "admin") -> list[str]:
        """Dynamically discover kube clusters via tsh kube ls."""
        cmd = self.tsh_base_args(profile) + ["kube", "ls", "--format=json"]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self.tsh_env(),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)

            if proc.returncode != 0:
                logger.warning("tsh kube ls failed: %s", stderr.decode())
                return []

            clusters = json.loads(stdout.decode())
            return [c["kube_cluster_name"] for c in clusters]
        except FileNotFoundError:
            logger.error("tsh not found in container")
            return []
        except asyncio.TimeoutError:
            logger.warning("tsh kube ls timed out")
            return []
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Failed to parse tsh kube ls output: %s", e)
            return []

    async def get_kube_kubeconfig(self, cluster: str, profile: str = "admin") -> tuple[str, str]:
        """Get a kubeconfig path for a kube cluster, using cache when possible.

        Runs tbot in oneshot mode to generate a kubernetes (v1) output with
        role-scoped certs. Results are cached per (profile, cluster) for ~23h.

        Returns (kubeconfig_path, error_message). On success error is empty.
        """
        cache_key = (profile, cluster)
        cached = self._kube_cache.get(cache_key)
        if cached:
            kc_path, expiry = cached
            if time.time() < expiry and Path(kc_path).exists():
                return kc_path, ""
            else:
                self._kube_cache.pop(cache_key, None)

        dest_dir = f"/tmp/tbot-kube/{profile}/{cluster}"
        os.makedirs(f"{dest_dir}/id", exist_ok=True)
        os.makedirs(f"{dest_dir}/kube", exist_ok=True)

        config = {
            "version": "v2",
            "proxy_server": self.proxy,
            "onboarding": {"join_method": "iam", "token": TBOT_JOIN_TOKEN},
            "storage": {"type": "memory"},
            "oneshot": True,
            "certificate_ttl": KUBE_CERT_TTL,
            "outputs": [
                {
                    "type": "identity",
                    "destination": {"type": "directory", "path": f"{dest_dir}/id"},
                },
                {
                    "type": "kubernetes",
                    "roles": [PROFILE_ROLE_MAP.get(profile, profile)],
                    "kubernetes_cluster": cluster,
                    "destination": {"type": "directory", "path": f"{dest_dir}/kube"},
                },
            ],
        }

        cfg_path = f"{dest_dir}/tbot.yaml"
        with open(cfg_path, "w") as f:
            yaml.dump(config, f)

        cmd = [
            "tbot", "start", "-c", cfg_path,
            f"--proxy-server={self.proxy}",
            f"--certificate-ttl={KUBE_CERT_TTL}",
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self.tbot_env(),
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        except asyncio.TimeoutError:
            return "", "tbot oneshot timed out"
        except FileNotFoundError:
            return "", "tbot not found in container"

        if proc.returncode != 0:
            err = stderr.decode(errors="replace").strip()
            if "not found" in err.lower():
                return "", f"cluster '{cluster}' not found or not accessible for profile '{profile}'"
            return "", err[-500:]

        kc_path = f"{dest_dir}/kube/kubeconfig.yaml"
        if not Path(kc_path).exists():
            return "", "tbot oneshot did not generate kubeconfig"

        self._kube_cache[cache_key] = (kc_path, time.time() + KUBE_CACHE_TTL)
        logger.info("Generated kube creds for %s/%s (cached %ds)", profile, cluster, KUBE_CACHE_TTL)
        return kc_path, ""

    async def get_app_type(self, app_name: str, profile: str = "admin") -> str:
        """Return app type ("TCP" or "HTTP") for an app, using a TTL cache.

        On cache miss, fetches all apps via ``tsh apps ls`` and batch-populates
        the cache to avoid N+1 calls.  Falls back to ``"HTTP"`` on any error.
        """
        cached = self._app_type_cache.get(app_name)
        if cached:
            app_type, expiry = cached
            if time.time() < expiry:
                return app_type
            self._app_type_cache.pop(app_name, None)

        if not self.is_ready:
            logger.debug("tbot not ready, defaulting app type to HTTP for %s", app_name)
            return "HTTP"

        try:
            await self._fetch_app_types(profile)
        except Exception as e:
            logger.warning("Failed to fetch app types: %s", e)
            return "HTTP"

        cached = self._app_type_cache.get(app_name)
        if cached:
            return cached[0]

        logger.debug("App %s not found in tsh apps ls, defaulting to HTTP", app_name)
        return "HTTP"

    async def _fetch_app_types(self, profile: str = "admin") -> None:
        """Run ``tsh apps ls --format=json`` and batch-populate the type cache."""
        cmd = self.tsh_base_args(profile) + ["apps", "ls", "--format=json"]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self.tsh_env(),
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)

        if proc.returncode != 0:
            raise RuntimeError(f"tsh apps ls failed: {stderr.decode()}")

        apps = json.loads(stdout.decode())
        expiry = time.time() + APP_TYPE_CACHE_TTL
        for app in apps:
            name = app.get("metadata", {}).get("name", "")
            uri = app.get("spec", {}).get("uri", "")
            app_type = "TCP" if uri.startswith("tcp://") else "HTTP"
            self._app_type_cache[name] = (app_type, expiry)

    def status(self) -> dict:
        """Return tbot status info for health checks."""
        return {
            "data_dir": str(self.data_dir),
            "ready": self.is_ready,
            "identity": self.is_ready,
        }


# Module-level singleton
tbot = TbotManager()
