"""kubectl execution via tbot oneshot (on-demand kube certs).

Uses tbot in oneshot mode to generate role-scoped kubernetes certs
for each (profile, cluster) pair. Certs are cached for ~23h.
"""

from __future__ import annotations

import asyncio
import logging
import shlex

from cube_cloud.teleport.tbot_manager import tbot

logger = logging.getLogger(__name__)

MAX_OUTPUT = 512 * 1024  # 512 KB


async def run_kubectl(
    args: list[str], cluster: str | None = None, profile: str = "admin", timeout: float = 60
) -> tuple[str, int]:
    """Run a kubectl command using a tbot-generated kubeconfig for the given cluster.

    Returns (output, return_code).
    """
    if not tbot.is_ready:
        return "tbot credentials not ready. kubectl is not available.", 1

    if not cluster:
        return "Error: cluster name is required.", 1

    logger.info("kubectl %s (cluster=%s)", " ".join(shlex.quote(a) for a in args), cluster)

    kc_path, err = await tbot.get_kube_kubeconfig(cluster, profile)
    if err:
        return f"Failed to get credentials for '{cluster}': {err}", 1

    try:
        cmd = ["kubectl", "--kubeconfig", kc_path] + args
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            env=tbot.tsh_env(),
        )

        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        output = stdout.decode("utf-8", errors="replace")

        if len(output) > MAX_OUTPUT:
            output = output[:MAX_OUTPUT] + "\n\n... (truncated)"

        return output, proc.returncode or 0

    except asyncio.TimeoutError:
        return f"kubectl command timed out after {timeout}s", 1
    except FileNotFoundError:
        return "kubectl not found in container.", 1
