"""Shared type definitions for the CLI."""

from typing import TypedDict


class InitResult(TypedDict):
    name: str
    agent: str
    created: list[str]
    updated: list[str]
    skipped: list[str]


class SkillsResult(TypedDict):
    available: dict[str, str]
    installed: dict[str, str]
    agent: str | None


class SkillAction(TypedDict):
    name: str
    action: str
    path: str
