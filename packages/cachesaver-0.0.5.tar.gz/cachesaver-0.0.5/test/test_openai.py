import sys
import pytest
import asyncio
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace

# ---------------------------------------------------------------------------
# Ensure `from openai import AsyncClient` works even with old openai package.
# We inject a mock AsyncClient into the openai module before importing our code.
# ---------------------------------------------------------------------------
import openai as _openai_mod
if not hasattr(_openai_mod, "AsyncClient"):
    _openai_mod.AsyncClient = MagicMock(name="AsyncClient")

from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.openai import OpenAIModel, AsyncOpenAI, OpenAI


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_chat_response(contents, model="gpt-4o", resp_id="chatcmpl_123"):
    """Build a mock ChatCompletion with one choice per content string."""
    choices = [
        SimpleNamespace(
            index=i,
            message=SimpleNamespace(role="assistant", content=c),
            finish_reason="stop",
        )
        for i, c in enumerate(contents)
    ]
    return SimpleNamespace(choices=choices, model=model, id=resp_id)


# ===================================================================
# OpenAIModel (core model) tests
# ===================================================================


class TestOpenAIModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()
        client.chat.completions.create = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.openai.AsyncClient",
            return_value=mock_client,
        ):
            m = OpenAIModel(api_key="sk-test")
        return m

    # --- basic single request ------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        mock_client.chat.completions.create.return_value = make_chat_response(
            ["Berlin"]
        )

        request = Request(
            args=(),
            kwargs={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Name a city."}],
            },
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].choices[0].message.content == "Berlin"
        mock_client.chat.completions.create.assert_awaited_once()

    # --- n > 1 ---------------------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_multiple_choices(self, model, mock_client):
        mock_client.chat.completions.create.return_value = make_chat_response(
            ["Paris", "Rome", "Tokyo"]
        )

        request = Request(
            args=(),
            kwargs={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Name a city."}],
            },
            n=3,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert len(response.data) == 3
        assert response.data[0].choices[0].message.content == "Paris"
        assert response.data[1].choices[0].message.content == "Rome"
        assert response.data[2].choices[0].message.content == "Tokyo"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_flattening_isolates_choices(self, model, mock_client):
        """Each flattened response should have exactly one choice."""
        mock_client.chat.completions.create.return_value = make_chat_response(
            ["A", "B"]
        )

        request = Request(
            args=(),
            kwargs={"model": "gpt-4o", "messages": []},
            n=2,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        for item in response.data:
            assert len(item.choices) == 1
        # Ensure the two objects are independent copies
        assert response.data[0] is not response.data[1]
        assert response.data[0].choices[0].message.content == "A"
        assert response.data[1].choices[0].message.content == "B"

    # --- kwargs forwarding ----------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_client):
        mock_client.chat.completions.create.return_value = make_chat_response(
            ["ok"]
        )

        request = Request(
            args=(),
            kwargs={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hi"}],
                "temperature": 0.5,
                "max_tokens": 100,
                "top_p": 0.9,
            },
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        call_kwargs = mock_client.chat.completions.create.call_args
        assert call_kwargs.kwargs["model"] == "gpt-4o"
        assert call_kwargs.kwargs["temperature"] == 0.5
        assert call_kwargs.kwargs["max_tokens"] == 100
        assert call_kwargs.kwargs["top_p"] == 0.9
        assert call_kwargs.kwargs["n"] == 1

    # --- client_kwargs forwarding ---------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_client_kwargs_forwarded(self):
        with patch("src.cachesaver.models.openai.AsyncClient") as mock_cls:
            OpenAIModel(api_key="sk-test", base_url="https://custom.api/v1")
            mock_cls.assert_called_once_with(
                api_key="sk-test",
                base_url="https://custom.api/v1",
            )

    # --- n is passed to the API -----------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_n_passed_to_api(self, model, mock_client):
        mock_client.chat.completions.create.return_value = make_chat_response(
            ["A", "B", "C"]
        )

        request = Request(
            args=(),
            kwargs={"model": "gpt-4o", "messages": []},
            n=3,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        call_kwargs = mock_client.chat.completions.create.call_args
        assert call_kwargs.kwargs["n"] == 3


# ===================================================================
# AsyncOpenAI (full wrapper) tests
# ===================================================================


class TestAsyncOpenAI:
    """Tests for the AsyncOpenAI drop-in wrapper including the caching pipeline."""

    # --- basic call via chat.completions.create -------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_chat_completions_create(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["Hello!"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            result = await w.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
            )

        assert hasattr(result, "choices")
        assert len(result.choices) == 1
        assert result.choices[0].message.content == "Hello!"

    # --- n > 1 merges choices via adapter ------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_n_greater_than_1(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["A", "B"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            result = await w.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Name a city."}],
                n=2,
            )

        assert len(result.choices) == 2
        assert result.choices[0].message.content == "A"
        assert result.choices[1].message.content == "B"

    # --- caching: same prompt in different namespace reuses cache --------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_caching_across_namespaces(self):
        """Cache reuse works across namespaces: second namespace gets the
        cached response without hitting the model again."""
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["cached answer"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="ns1", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            call_kwargs = dict(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hello"}],
            )

            result1 = await w.chat.completions.create(**call_kwargs, namespace="ns1")
            result2 = await w.chat.completions.create(**call_kwargs, namespace="ns2")

        # Model should only be called once; second namespace served from cache
        assert mock_client.chat.completions.create.await_count == 1
        assert result1.choices[0].message.content == "cached answer"
        assert result2.choices[0].message.content == "cached answer"

    # --- within same namespace, each call gets a fresh response ---------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_same_namespace_gets_fresh_responses(self):
        """Within the same namespace, identical prompts produce fresh (unique)
        responses — the cache tracks usage counts per namespace."""
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=[
                make_chat_response(["first"]),
                make_chat_response(["second"]),
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="same", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            call_kwargs = dict(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hello"}],
            )

            result1 = await w.chat.completions.create(**call_kwargs)
            result2 = await w.chat.completions.create(**call_kwargs)

        # Both calls hit the model (unique sampling within namespace)
        assert mock_client.chat.completions.create.await_count == 2
        assert result1.choices[0].message.content == "first"
        assert result2.choices[0].message.content == "second"

    # --- different prompts are not cached together ----------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_different_prompts_not_cached(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=[
                make_chat_response(["answer1"]),
                make_chat_response(["answer2"]),
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            r1 = await w.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Q1"}],
            )
            r2 = await w.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Q2"}],
            )

        assert mock_client.chat.completions.create.await_count == 2
        assert r1.choices[0].message.content == "answer1"
        assert r2.choices[0].message.content == "answer2"

    # --- concurrent requests --------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_concurrent_requests(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=[
                make_chat_response(["Berlin"]),
                make_chat_response(["Paris"]),
                make_chat_response(["Tokyo"]),
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test",
                    cachedir=tmpdir,
                    batch_size=3,
                    api_key="sk-test",
                )

            results = await asyncio.gather(
                w.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "City 1"}],
                ),
                w.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "City 2"}],
                ),
                w.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "City 3"}],
                ),
            )

        contents = [r.choices[0].message.content for r in results]
        assert len(contents) == 3
        # All three unique prompts should have hit the model
        assert mock_client.chat.completions.create.await_count == 3

    # --- per-call namespace ---------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_per_call_namespace(self):
        """Same prompt in different namespaces reuses cache across namespaces."""
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["answer"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="default",
                    cachedir=tmpdir,
                    batch_size=1,
                    api_key="sk-test",
                )

            call_kwargs = dict(
                model="gpt-4o",
                messages=[{"role": "user", "content": "hello"}],
            )

            r1 = await w.chat.completions.create(**call_kwargs, namespace="ns1")
            r2 = await w.chat.completions.create(**call_kwargs, namespace="ns2")

        # Same prompt cached once, reused for second namespace
        assert mock_client.chat.completions.create.await_count == 1
        assert r1.choices[0].message.content == "answer"
        assert r2.choices[0].message.content == "answer"

    # --- per-call request_id --------------------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_per_call_request_id(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["ok"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            await w.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                request_id="custom-id-42",
            )

        # Should work without error; request_id is consumed by wrapper,
        # not forwarded to the OpenAI client
        mock_client.chat.completions.create.assert_awaited_once()
        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        assert "request_id" not in call_kwargs

    # --- constructor forwards client_kwargs -----------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_constructor_forwards_client_kwargs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("src.cachesaver.models.openai.AsyncClient") as mock_cls:
                AsyncOpenAI(
                    namespace="test",
                    cachedir=tmpdir,
                    api_key="sk-test-key",
                    base_url="https://custom.openai.com/v1",
                    organization="org-123",
                )
                mock_cls.assert_called_once_with(
                    api_key="sk-test-key",
                    base_url="https://custom.openai.com/v1",
                    organization="org-123",
                )

    # --- alternative attribute chains work ------------------------------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_arbitrary_attr_chain(self):
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["ok"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            result = await w.foo.bar.baz(
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
            )

        assert result.choices[0].message.content == "ok"

    # --- metadata kwargs (stream, store) stripped from cache hash -------------

    @pytest.mark.asyncio(loop_scope="function")
    async def test_metadata_kwargs_dont_break_caching(self):
        """Metadata kwargs like `store` are excluded from the cache hash,
        so the same prompt with different metadata values shares a cache entry."""
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["answer"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                w = AsyncOpenAI(
                    namespace="test", cachedir=tmpdir, batch_size=1, api_key="sk-test",
                )

            base_kwargs = dict(
                model="gpt-4o",
                messages=[{"role": "user", "content": "test"}],
            )

            # Use different namespaces so the cache reuses across them
            r1 = await w.chat.completions.create(**base_kwargs, store=True, namespace="ns1")
            r2 = await w.chat.completions.create(**base_kwargs, store=False, namespace="ns2")

        # store is metadata — both calls resolve to the same cache entry
        assert mock_client.chat.completions.create.await_count == 1


# ===================================================================
# OpenAI (sync wrapper) tests
# ===================================================================


class TestSyncOpenAI:
    @pytest.mark.asyncio(loop_scope="function")
    async def test_sync_call(self):
        """Sync wrapper must be constructed inside a running event loop
        (because AsyncBatcher.__init__ calls asyncio.create_task).
        Once constructed, the sync call path uses nest_asyncio + asyncio.run."""
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=make_chat_response(["sync answer"])
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "src.cachesaver.models.openai.AsyncClient",
                return_value=mock_client,
            ):
                client = OpenAI(
                    namespace="test",
                    cachedir=tmpdir,
                    api_key="sk-test",
                )

            result = client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
            )

        assert result.choices[0].message.content == "sync answer"
