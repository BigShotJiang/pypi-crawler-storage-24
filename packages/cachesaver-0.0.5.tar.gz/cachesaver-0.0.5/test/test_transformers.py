import pytest
from unittest.mock import MagicMock, patch
from src.cachesaver.typedefs import Request, Batch, Response

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

pytestmark = pytest.mark.skipif(not HAS_TORCH, reason="torch not installed")

if HAS_TORCH:
    from src.cachesaver.models.transformers import (
        HFTransformersModel, AutoModelForCausalLM, make_hashable,
    )


class TestHFTransformersModel:
    @pytest.fixture
    def mock_hf_model(self):
        model = MagicMock()
        model.generate = MagicMock(
            return_value=torch.tensor([
                [1, 2, 3, 10, 11],
            ])
        )
        return model

    @pytest.fixture
    def model(self, mock_hf_model):
        with patch(
            "src.cachesaver.models.transformers.AutoModelClient"
        ) as mock_cls:
            mock_cls.from_pretrained.return_value = mock_hf_model
            m = HFTransformersModel("test-model", device_map="cpu")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_hf_model):
        mock_hf_model.generate.return_value = torch.tensor([[1, 2, 3, 10, 11]])

        request = Request(
            args=(),
            kwargs={"input_ids": torch.tensor([[1, 2, 3]])},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert torch.equal(response.data[0], torch.tensor([1, 2, 3, 10, 11]))
        mock_hf_model.generate.assert_called_once()

    @pytest.mark.asyncio(loop_scope="function")
    async def test_n_passed_as_num_return_sequences(self, model, mock_hf_model):
        mock_hf_model.generate.return_value = torch.tensor([
            [1, 2, 3, 10, 11],
            [1, 2, 3, 20, 21],
            [1, 2, 3, 30, 31],
        ])

        request = Request(
            args=(),
            kwargs={"input_ids": torch.tensor([[1, 2, 3]])},
            n=3,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert len(response.data) == 3
        call_kwargs = mock_hf_model.generate.call_args.kwargs
        assert call_kwargs["num_return_sequences"] == 3

    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_hf_model):
        mock_hf_model.generate.return_value = torch.tensor([[1, 2, 3, 10]])

        request = Request(
            args=(),
            kwargs={
                "input_ids": torch.tensor([[1, 2, 3]]),
                "max_new_tokens": 50,
                "temperature": 0.7,
                "do_sample": True,
            },
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        call_kwargs = mock_hf_model.generate.call_args.kwargs
        assert call_kwargs["max_new_tokens"] == 50
        assert call_kwargs["temperature"] == 0.7
        assert call_kwargs["do_sample"] is True

    @pytest.mark.asyncio(loop_scope="function")
    async def test_model_kwargs_forwarded_to_from_pretrained(self):
        with patch(
            "src.cachesaver.models.transformers.AutoModelClient"
        ) as mock_cls:
            mock_cls.from_pretrained.return_value = MagicMock()
            HFTransformersModel(
                "test-model",
                device_map="cuda",
                torch_dtype=torch.float16,
                trust_remote_code=True,
            )
            mock_cls.from_pretrained.assert_called_once_with(
                "test-model",
                device_map="cuda",
                torch_dtype=torch.float16,
                trust_remote_code=True,
            )

    @pytest.mark.asyncio(loop_scope="function")
    async def test_no_grad_context(self, model, mock_hf_model):
        """model.generate should be called inside torch.no_grad()."""
        mock_hf_model.generate.return_value = torch.tensor([[1, 2, 3]])

        request = Request(
            args=(),
            kwargs={"input_ids": torch.tensor([[1, 2, 3]])},
            n=1,
            namespace="test",
            request_id="1",
        )

        with patch("src.cachesaver.models.transformers.torch") as mock_torch:
            mock_torch.no_grad.return_value.__enter__ = MagicMock()
            mock_torch.no_grad.return_value.__exit__ = MagicMock()
            # Re-mock generate since we patched torch
            await model.request(request)

        mock_torch.no_grad.assert_called_once()


class TestAutoModelForCausalLM:
    @pytest.mark.asyncio(loop_scope="function")
    async def test_from_pretrained_forwards_params(self):
        with patch(
            "src.cachesaver.models.transformers.AutoModelClient"
        ) as mock_cls:
            mock_cls.from_pretrained.return_value = MagicMock()
            import tempfile
            with tempfile.TemporaryDirectory() as tmpdir:
                wrapper = AutoModelForCausalLM.from_pretrained(
                    "test-model",
                    namespace="custom-ns",
                    cachedir=tmpdir,
                    batch_size=4,
                    device_map="cpu",
                )
                assert wrapper.namespace == "custom-ns"
                assert wrapper.batch_size == 4
                assert wrapper.cachedir == tmpdir


class TestMakeHashable:
    def test_tensor_converted(self):
        t = torch.tensor([1, 2, 3])
        result = make_hashable(t)
        assert result["__tensor__"] is True
        assert result["data"] == [1, 2, 3]
        assert result["shape"] == (3,)

    def test_nested_dict_with_tensor(self):
        d = {"a": torch.tensor([1.0]), "b": "text"}
        result = make_hashable(d)
        assert result["a"]["__tensor__"] is True
        assert result["b"] == "text"

    def test_list_with_tensor(self):
        lst = [torch.tensor([1]), "hello"]
        result = make_hashable(lst)
        assert result[0]["__tensor__"] is True
        assert result[1] == "hello"

    def test_plain_values_unchanged(self):
        assert make_hashable(42) == 42
        assert make_hashable("text") == "text"
        assert make_hashable(None) is None
