import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.huggingface import HuggingFaceModel


class TestHuggingFaceModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()
        client.chat.completions.create = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.huggingface.HFClient",
            return_value=mock_client
        ):
            m = HuggingFaceModel(token="test-token")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        """n=1 should make a single call and return one flattened response."""
        mock_response = SimpleNamespace(
            choices=[SimpleNamespace(
                index=0,
                message=SimpleNamespace(role="assistant", content="Helsinki"),
            )],
            model="meta-llama/Meta-Llama-3-8B-Instruct",
            id="hf_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "meta-llama/Meta-Llama-3-8B-Instruct",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].choices[0].message.content == "Helsinki"
        mock_client.chat.completions.create.assert_called_once()

    @pytest.mark.asyncio(loop_scope="function")
    async def test_multiple_choices(self, model, mock_client):
        """n>1 should flatten all choices into individual responses."""
        mock_response = SimpleNamespace(
            choices=[
                SimpleNamespace(index=0, message=SimpleNamespace(role="assistant", content="Tokyo")),
                SimpleNamespace(index=1, message=SimpleNamespace(role="assistant", content="Oslo")),
            ],
            model="meta-llama/Meta-Llama-3-8B-Instruct",
            id="hf_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "meta-llama/Meta-Llama-3-8B-Instruct",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=2,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert len(response.data) == 2
        assert response.data[0].choices[0].message.content == "Tokyo"
        assert response.data[1].choices[0].message.content == "Oslo"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_client):
        """All kwargs should be forwarded to the SDK client."""
        mock_client.chat.completions.create.return_value = SimpleNamespace(
            choices=[SimpleNamespace(index=0, message=SimpleNamespace(content="x"))],
            model="test", id="1",
        )

        request = Request(
            args=(),
            kwargs={"model": "meta-llama/Meta-Llama-3-8B-Instruct",
                     "messages": [{"role": "user", "content": "Test"}],
                     "max_tokens": 100, "temperature": 0.7},
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        mock_client.chat.completions.create.assert_called_once_with(
            model="meta-llama/Meta-Llama-3-8B-Instruct",
            messages=[{"role": "user", "content": "Test"}],
            max_tokens=100,
            temperature=0.7,
            n=1,
        )
