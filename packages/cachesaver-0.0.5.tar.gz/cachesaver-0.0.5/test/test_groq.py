import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.groq import GroqModel


class TestGroqModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()
        client.chat.completions.create = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.groq.AsyncGroqClient",
            return_value=mock_client
        ):
            m = GroqModel(api_key="gsk-test-key")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        mock_response = SimpleNamespace(
            choices=[SimpleNamespace(
                index=0,
                message=SimpleNamespace(role="assistant", content="Mumbai"),
            )],
            model="llama-3.3-70b-versatile",
            id="groq_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "llama-3.3-70b-versatile",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].choices[0].message.content == "Mumbai"
        mock_client.chat.completions.create.assert_called_once()


    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_client):
        mock_client.chat.completions.create.return_value = SimpleNamespace(
            choices=[SimpleNamespace(index=0, message=SimpleNamespace(content="x"))],
            model="test", id="1",
        )

        request = Request(
            args=(),
            kwargs={"model": "llama-3.3-70b-versatile",
                     "messages": [{"role": "user", "content": "Test"}],
                     "temperature": 0.5, "max_tokens": 200},
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        mock_client.chat.completions.create.assert_called_once_with(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": "Test"}],
            temperature=0.5,
            max_tokens=200,
            n=1
        )
