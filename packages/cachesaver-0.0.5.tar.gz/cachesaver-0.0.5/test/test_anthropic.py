import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.anthropic import AnthropicModel


class TestAnthropicModel:
    @pytest.fixture
    def mock_client(self):
        client = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.anthropic.AsyncAnthropicClient",
            return_value=mock_client
        ):
            m = AnthropicModel(api_key="test-key")
        m.aclient = mock_client
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        """n=1 should make a single messages.create call."""
        mock_response = SimpleNamespace(
            id="msg_123",
            content=[SimpleNamespace(type="text", text="Hello!")],
            model="claude-sonnet-4-5-20250929",
            role="assistant",
            stop_reason="end_turn",
        )
        mock_client.messages.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "claude-sonnet-4-5-20250929", "max_tokens": 1024,
                     "messages": [{"role": "user", "content": "Hi"}]},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].content[0].text == "Hello!"
        mock_client.messages.create.assert_called_once()

    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_client):
        """All kwargs should be forwarded to the SDK client."""
        mock_client.messages.create.return_value = SimpleNamespace(
            id="msg_1", content=[], model="claude-sonnet-4-5-20250929",
            role="assistant", stop_reason="end_turn",
        )

        request = Request(
            args=(),
            kwargs={
                "model": "claude-sonnet-4-5-20250929",
                "max_tokens": 2048,
                "temperature": 0.5,
                "messages": [{"role": "user", "content": "Test"}],
            },
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        mock_client.messages.create.assert_called_once_with(
            model="claude-sonnet-4-5-20250929",
            max_tokens=2048,
            temperature=0.5,
            messages=[{"role": "user", "content": "Test"}],
        )
