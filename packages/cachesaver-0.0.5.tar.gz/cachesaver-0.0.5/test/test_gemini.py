import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.gemini import GeminiModel


class TestGeminiModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.aio = MagicMock()
        client.aio.models = MagicMock()
        client.aio.models.generate_content = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.gemini.genai.Client",
            return_value=mock_client
        ):
            m = GeminiModel(api_key="test-key")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        """n=1 should make a single generate_content call."""
        mock_response = SimpleNamespace(
            text="Hello from Gemini!",
            candidates=[SimpleNamespace(
                content=SimpleNamespace(parts=[SimpleNamespace(text="Hello from Gemini!")])
            )],
        )
        mock_client.aio.models.generate_content.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "gemini-2.0-flash", "contents": "Hi"},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].text == "Hello from Gemini!"
        mock_client.aio.models.generate_content.assert_called_once()

    @pytest.mark.asyncio(loop_scope="function")
    async def test_multiple_samples(self, model, mock_client):
        """n>1 should make one call with candidate_count=n and flatten candidates."""
        mock_response = SimpleNamespace(
            text="Response 0",
            candidates=[
                SimpleNamespace(content=SimpleNamespace(parts=[SimpleNamespace(text="Response 0")])),
                SimpleNamespace(content=SimpleNamespace(parts=[SimpleNamespace(text="Response 1")])),
                SimpleNamespace(content=SimpleNamespace(parts=[SimpleNamespace(text="Response 2")])),
            ],
        )
        mock_client.aio.models.generate_content.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "gemini-2.0-flash", "contents": "Hi"},
            n=3,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 3
        # Single API call with candidate_count=3
        mock_client.aio.models.generate_content.assert_called_once()
        # Each flattened response has exactly one candidate
        for resp in response.data:
            assert len(resp.candidates) == 1

    @pytest.mark.asyncio(loop_scope="function")
    async def test_kwargs_forwarded(self, model, mock_client):
        """All kwargs should be forwarded to the SDK client."""
        mock_client.aio.models.generate_content.return_value = SimpleNamespace(
            text="Test", candidates=[],
        )

        request = Request(
            args=(),
            kwargs={
                "model": "gemini-2.0-flash",
                "contents": "Test prompt",
            },
            n=1,
            namespace="test",
            request_id="1",
        )

        await model.request(request)

        call_kwargs = mock_client.aio.models.generate_content.call_args.kwargs
        assert call_kwargs["model"] == "gemini-2.0-flash"
        assert call_kwargs["contents"] == "Test prompt"
        # Model always injects a config with candidate_count
        assert call_kwargs["config"].candidate_count == 1
