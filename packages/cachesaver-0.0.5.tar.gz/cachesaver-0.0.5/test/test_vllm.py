import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.vllm import VLLMModel


class TestVLLMModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()
        client.chat.completions.create = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.vllm.AsyncClient",
            return_value=mock_client
        ):
            m = VLLMModel(base_url="http://localhost:8000/v1")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        mock_response = SimpleNamespace(
            choices=[SimpleNamespace(
                index=0,
                message=SimpleNamespace(role="assistant", content="Berlin"),
            )],
            model="meta-llama/Llama-3-8B",
            id="vllm_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "meta-llama/Llama-3-8B",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].choices[0].message.content == "Berlin"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_multiple_choices(self, model, mock_client):
        mock_response = SimpleNamespace(
            choices=[
                SimpleNamespace(index=0, message=SimpleNamespace(content="Paris")),
                SimpleNamespace(index=1, message=SimpleNamespace(content="Rome")),
            ],
            model="meta-llama/Llama-3-8B",
            id="vllm_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "meta-llama/Llama-3-8B",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=2,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert len(response.data) == 2
        assert response.data[0].choices[0].message.content == "Paris"
        assert response.data[1].choices[0].message.content == "Rome"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_default_api_key(self):
        """Should default api_key to 'EMPTY' when not provided."""
        with patch("src.cachesaver.models.vllm.AsyncClient") as mock_cls:
            VLLMModel(base_url="http://localhost:8000/v1")
            mock_cls.assert_called_once_with(
                base_url="http://localhost:8000/v1",
                api_key="EMPTY",
            )

    @pytest.mark.asyncio(loop_scope="function")
    async def test_custom_api_key(self):
        """Should use provided api_key when given."""
        with patch("src.cachesaver.models.vllm.AsyncClient") as mock_cls:
            VLLMModel(base_url="http://localhost:8000/v1", api_key="my-key")
            mock_cls.assert_called_once_with(
                base_url="http://localhost:8000/v1",
                api_key="my-key",
            )
