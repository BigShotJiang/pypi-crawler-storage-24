import pytest
import tempfile
from unittest.mock import AsyncMock, MagicMock
from types import SimpleNamespace
from diskcache import Cache
from src.cachesaver.typedefs import Request, Response, SingleRequestModel
from src.cachesaver.models.wrapper import (
    APIProxy, Wrapper, AsyncWrapper, SyncWrapper, Create, AsyncCreate,
    openai_chat_adapter, default_adapter,
)


class MockModel(SingleRequestModel):
    """Mock model that returns SimpleNamespace objects with a choices list."""

    def __init__(self):
        self.calls = []

    async def request(self, request: Request) -> Response:
        self.calls.append(request)
        responses = []
        for i in range(request.n):
            resp = SimpleNamespace(
                choices=[SimpleNamespace(index=i, text=f"response_{i}")],
                model="mock",
                id="mock_id"
            )
            responses.append(resp)
        return Response(data=responses)


class TestAPIProxy:
    def test_single_attr_chain(self):
        fn = MagicMock(return_value="result")
        proxy = APIProxy(fn)
        result = proxy.chat.completions.create("arg1", key="val")
        fn.assert_called_once_with("arg1", key="val")
        assert result == "result"

    def test_different_chains_same_function(self):
        fn = MagicMock(side_effect=["r1", "r2", "r3"])
        proxy = APIProxy(fn)

        r1 = proxy.chat.completions.create("a")
        r2 = proxy.messages.create("b")
        r3 = proxy.responses.create("c")

        assert r1 == "r1"
        assert r2 == "r2"
        assert r3 == "r3"
        assert fn.call_count == 3

    def test_direct_call(self):
        fn = MagicMock(return_value="direct")
        proxy = APIProxy(fn)
        result = proxy("arg")
        fn.assert_called_once_with("arg")
        assert result == "direct"

    def test_private_attr_raises(self):
        fn = MagicMock()
        proxy = APIProxy(fn)
        with pytest.raises(AttributeError):
            proxy._private

    def test_dunder_attr_raises(self):
        fn = MagicMock()
        proxy = APIProxy(fn)
        with pytest.raises(AttributeError):
            proxy.__something__


class TestResponseAdapters:
    def test_openai_chat_adapter_single(self):
        choice = SimpleNamespace(index=0, text="hello")
        resp = SimpleNamespace(choices=[choice], model="gpt-4", id="123")
        flattened = Response(data=[resp])
        result = openai_chat_adapter(flattened)
        assert len(result.choices) == 1
        assert result.choices[0].text == "hello"

    def test_openai_chat_adapter_multiple(self):
        resp1 = SimpleNamespace(
            choices=[SimpleNamespace(index=0, text="a")],
            model="gpt-4", id="123"
        )
        resp2 = SimpleNamespace(
            choices=[SimpleNamespace(index=1, text="b")],
            model="gpt-4", id="123"
        )
        flattened = Response(data=[resp1, resp2])
        result = openai_chat_adapter(flattened)
        assert len(result.choices) == 2
        assert result.choices[0].text == "a"
        assert result.choices[1].text == "b"

    def test_default_adapter_single(self):
        data = SimpleNamespace(text="hello")
        flattened = Response(data=[data])
        result = default_adapter(flattened)
        assert result is data

    def test_default_adapter_multiple(self):
        d1 = SimpleNamespace(text="a")
        d2 = SimpleNamespace(text="b")
        flattened = Response(data=[d1, d2])
        result = default_adapter(flattened)
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] is d1
        assert result[1] is d2


class TestCreate:
    @pytest.mark.asyncio(loop_scope="function")
    async def test_response_adapter_is_called(self):
        mock_api = AsyncMock()
        mock_api.request.return_value = Response(data=["raw_response"])

        custom_adapter = MagicMock(return_value="adapted")
        create = AsyncCreate(mock_api, "test_ns", response_adapter=custom_adapter)

        result = await create(model="gpt-4", messages=[])
        custom_adapter.assert_called_once()
        assert result == "adapted"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_default_adapter_used_when_none(self):
        mock_api = AsyncMock()
        mock_api.request.return_value = Response(data=["single_response"])

        create = AsyncCreate(mock_api, "test_ns")
        result = await create(model="gpt-4", messages=[])
        # default_adapter returns data[0] for single element
        assert result == "single_response"


class TestAsyncWrapperGetattr:
    @pytest.mark.asyncio(loop_scope="function")
    async def test_chat_completions_create(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model = MockModel()
            wrapper = AsyncWrapper(
                model=model,
                namespace="test",
                cachedir=tmpdir,
                response_adapter=openai_chat_adapter
            )
            result = await wrapper.chat.completions.create(
                model="mock", messages=[]
            )
            assert hasattr(result, 'choices')
            assert len(result.choices) == 1

    @pytest.mark.asyncio(loop_scope="function")
    async def test_messages_create(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model = MockModel()
            wrapper = AsyncWrapper(
                model=model,
                namespace="test",
                cachedir=tmpdir,
                response_adapter=openai_chat_adapter
            )
            result = await wrapper.messages.create(
                model="mock", messages=[]
            )
            assert hasattr(result, 'choices')

    @pytest.mark.asyncio(loop_scope="function")
    async def test_arbitrary_chain(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model = MockModel()
            wrapper = AsyncWrapper(
                model=model,
                namespace="test",
                cachedir=tmpdir,
                response_adapter=openai_chat_adapter
            )
            result = await wrapper.foo.bar.baz.qux(
                model="mock", messages=[]
            )
            assert hasattr(result, 'choices')

    @pytest.mark.asyncio(loop_scope="function")
    async def test_private_attr_raises(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model = MockModel()
            wrapper = AsyncWrapper(
                model=model,
                namespace="test",
                cachedir=tmpdir,
            )
            with pytest.raises(AttributeError):
                wrapper._nonexistent

    @pytest.mark.asyncio(loop_scope="function")
    async def test_real_attrs_resolve_normally(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model = MockModel()
            wrapper = AsyncWrapper(
                model=model,
                namespace="test",
                cachedir=tmpdir,
            )
            assert wrapper.namespace == "test"
            assert wrapper.batch_size == 1
            assert wrapper.model is model
