import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from types import SimpleNamespace
from src.cachesaver.typedefs import Request, Response
from src.cachesaver.models.openrouter import OpenRouterModel


class TestOpenRouterModel:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()
        client.chat.completions.create = AsyncMock()
        return client

    @pytest.fixture
    def model(self, mock_client):
        with patch(
            "src.cachesaver.models.openrouter.AsyncClient",
            return_value=mock_client
        ):
            m = OpenRouterModel(api_key="or-test-key")
        return m

    @pytest.mark.asyncio(loop_scope="function")
    async def test_single_request(self, model, mock_client):
        mock_response = SimpleNamespace(
            choices=[SimpleNamespace(
                index=0,
                message=SimpleNamespace(role="assistant", content="Seoul"),
            )],
            model="openai/gpt-4",
            id="or_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "openai/gpt-4",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=1,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert isinstance(response, Response)
        assert len(response.data) == 1
        assert response.data[0].choices[0].message.content == "Seoul"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_multiple_choices(self, model, mock_client):
        mock_response = SimpleNamespace(
            choices=[
                SimpleNamespace(index=0, message=SimpleNamespace(content="Lima")),
                SimpleNamespace(index=1, message=SimpleNamespace(content="Cairo")),
            ],
            model="openai/gpt-4",
            id="or_123",
        )
        mock_client.chat.completions.create.return_value = mock_response

        request = Request(
            args=(),
            kwargs={"model": "openai/gpt-4",
                     "messages": [{"role": "user", "content": "Name a city."}]},
            n=2,
            namespace="test",
            request_id="1",
        )

        response = await model.request(request)

        assert len(response.data) == 2
        assert response.data[0].choices[0].message.content == "Lima"
        assert response.data[1].choices[0].message.content == "Cairo"

    @pytest.mark.asyncio(loop_scope="function")
    async def test_default_base_url(self):
        """Should default base_url to openrouter.ai when not provided."""
        with patch("src.cachesaver.models.openrouter.AsyncClient") as mock_cls:
            OpenRouterModel(api_key="or-key")
            mock_cls.assert_called_once_with(
                api_key="or-key",
                base_url="https://openrouter.ai/api/v1",
            )

    @pytest.mark.asyncio(loop_scope="function")
    async def test_custom_base_url(self):
        """Should use provided base_url when given."""
        with patch("src.cachesaver.models.openrouter.AsyncClient") as mock_cls:
            OpenRouterModel(api_key="or-key", base_url="https://custom.api/v1")
            mock_cls.assert_called_once_with(
                api_key="or-key",
                base_url="https://custom.api/v1",
            )
