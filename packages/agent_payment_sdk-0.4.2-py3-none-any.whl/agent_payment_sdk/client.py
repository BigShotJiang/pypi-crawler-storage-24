"""Main SDK Client for Agent Payment Network"""

import requests
try:
    from .crypto import sign_eth_transfer, get_address_from_key
    WEB3_AVAILABLE = True
except ImportError:
    WEB3_AVAILABLE = False
from typing import Optional, Dict, Any, List
from decimal import Decimal


class AgentPaymentClient:
    """
    Client for interacting with Agent Payment Network API
    
    Example:
        >>> client = AgentPaymentClient(
        ...     api_key="your_api_key",
        ...     base_url="http://localhost:8002"
        ... )
        >>> payment = client.create_payment(
        ...     to_agent_id="agent_123",
        ...     amount=50.00,
        ...     currency="USD",
        ...     payment_method="stripe_card"
        ... )
        >>> print(payment["payment_id"])
    """
    
    def __init__(
        self, 
        api_key: Optional[str] = None,
        base_url: str = "https://agentpayment.network",
        timeout: int = 30,
        agent_private_key: Optional[str] = None
    ):
        """
        Initialize the Agent Payment Network client
        
        Args:
            api_key: Your API key (optional for testing)
            base_url: Base URL of the API (default: localhost)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.agent_private_key = agent_private_key
        self.session = requests.Session()
        
        if api_key:
            self.session.headers.update({
                "X-API-Key": api_key
            })
    
    def _request(
        self, 
        method: str, 
        endpoint: str, 
        **kwargs
    ) -> Dict[str, Any]:
        """Make HTTP request to API"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                timeout=self.timeout,
                **kwargs
            )
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.HTTPError as e:
            error_detail = "Unknown error"
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(e))
            except:
                error_detail = str(e)
            
            raise PaymentError(f"API Error: {error_detail}")
        
        except requests.exceptions.Timeout:
            raise NetworkError("Request timed out")
        
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error: {str(e)}")
    
    # Payment Operations
    
    def create_payment(
        self,
        from_agent_id: str,
        to_agent_id: str,
        amount: float,
        currency: str = "USD",
        payment_method: str = "auto",
        memo: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new payment
        
        Args:
            to_agent_id: Recipient agent ID
            amount: Payment amount
            currency: Currency code (USD, ETH, etc.)
            payment_method: Payment method (auto, crypto, stripe_card)
            memo: Optional payment memo
            
        Returns:
            Payment response with payment_id, status, and client_secret
            
        Example:
            >>> payment = client.create_payment(
            ...     to_agent_id="agent_456",
            ...     amount=100.00,
            ...     currency="USD",
            ...     payment_method="stripe_card",
            ...     memo="Monthly API usage"
            ... )
            >>> print(f"Payment ID: {payment['payment_id']}")
        """
        data = {
            "from_agent_id": from_agent_id,
                "to_agent_id": to_agent_id,
            "amount": amount,
            "currency": currency,
            "payment_method": payment_method,
            "memo": memo
        }
        
        return self._request(
            "POST",
            "/api/v1/payments/create",
            json=data
        )
    
    def get_payment(self, payment_id: str) -> Dict[str, Any]:
        """
        Get payment status by ID
        
        Args:
            payment_id: Payment ID
            
        Returns:
            Payment details including status
        """
        return self._request(
            "GET",
            f"/api/v1/payments/{payment_id}"
        )
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check API health and available payment methods
        
        Returns:
            Health status and configuration
        """
        return self._request(
            "GET",
            "/api/v1/payments/health"
        )
    
    # Payment Method Management
    
    def add_payment_method(
        self,
        agent_id: str,
        method_type: str,
        wallet_address: Optional[str] = None,
        stripe_payment_method_id: Optional[str] = None,
        is_default: bool = False
    ) -> Dict[str, Any]:
        """
        Add a new payment method
        
        Args:
            agent_id: Your agent ID
            method_type: Type (crypto_wallet, stripe_card, stripe_bank)
            wallet_address: Wallet address (for crypto)
            stripe_payment_method_id: Stripe payment method ID (for cards)
            is_default: Set as default payment method
            
        Returns:
            Payment method details
        """
        data = {
            "agent_id": agent_id,
            "method_type": method_type,
            "is_default": is_default
        }
        
        if wallet_address:
            data["wallet_address"] = wallet_address
        
        if stripe_payment_method_id:
            data["stripe_payment_method_id"] = stripe_payment_method_id
        
        return self._request(
            "POST",
            "/api/v1/payment-methods/add",
            json=data
        )
    
    def list_payment_methods(self, agent_id: str) -> List[Dict[str, Any]]:
        """
        List all payment methods for an agent
        
        Args:
            agent_id: Agent ID
            
        Returns:
            List of payment methods
        """
        return self._request(
            "GET",
            f"/api/v1/payment-methods/list/{agent_id}"
        )
    
    def delete_payment_method(self, method_id: str) -> Dict[str, Any]:
        """
        Delete a payment method
        
        Args:
            method_id: Payment method ID
            
        Returns:
            Success confirmation
        """
        return self._request(
            "DELETE",
            f"/api/v1/payment-methods/{method_id}"
        )



    def send_crypto_payment(
        self,
        from_agent_id: str,
        to_agent_id: str,
        amount_wei: int,
        to_wallet_address: str,
        gas_price: int,
        nonce: int,
        chain_id: int = 8453
    ) -> Dict[str, Any]:
        """
        Non-custodial crypto payment — signs transaction locally with agent private key.
        Platform never sees your private key. Transaction is signed on your machine,
        then broadcast to Base Mainnet via the platform.

        Args:
            from_agent_id: Your agent ID
            to_agent_id: Recipient agent ID
            amount_wei: Amount in wei to send
            to_wallet_address: Recipient wallet address
            gas_price: Gas price in wei (get from /payments/gas-price)
            nonce: Transaction nonce (get from /payments/nonce)
            chain_id: Chain ID (default: 8453 Base Mainnet)

        Returns:
            Transaction hash and confirmation

        Example:
            >>> client = AgentPaymentClient(
            ...     api_key="ap_live_xxx",
            ...     agent_private_key="0xabc..."
            ... )
            >>> result = client.send_crypto_payment(
            ...     from_agent_id="agent_a",
            ...     to_agent_id="agent_b",
            ...     amount_wei=1000000000000000,  # 0.001 ETH
            ...     to_wallet_address="0x...",
            ...     gas_price=1000000000,
            ...     nonce=5
            ... )
        """
        if not self.agent_private_key:
            raise PaymentError("agent_private_key is required for non-custodial crypto payments")
        if not WEB3_AVAILABLE:
            raise PaymentError("web3 is required. Install with: pip install agent-payment-sdk[crypto]")

        raw_tx = sign_eth_transfer(
            private_key=self.agent_private_key,
            to_address=to_wallet_address,
            amount_wei=amount_wei,
            nonce=nonce,
            gas_price=gas_price,
            chain_id=chain_id
        )

        return self._request("POST", "/api/v1/payments/broadcast", json={
            "from_agent_id": from_agent_id,
            "to_agent_id": to_agent_id,
            "raw_tx": raw_tx,
            "amount_wei": amount_wei
        })

    # Agent-to-Agent Billing

    def create_invoice(
        self,
        to_agent_id: str,
        amount: float,
        description: Optional[str] = None,
        payment_rail: str = "crypto",
        currency: str = "USD",
        expires_in_minutes: int = 60
    ) -> Dict[str, Any]:
        """
        Provider agent creates an invoice for a consumer agent.
        If the consumer has an auto-approval rule, payment is instant.

        Args:
            to_agent_id: Consumer agent ID to bill
            amount: Invoice amount
            description: Description of service rendered
            payment_rail: Payment rail to use (crypto, card, bank)
            currency: Currency code (default: USD)
            expires_in_minutes: Invoice expiry time (default: 60)

        Returns:
            Invoice response with status (paid if auto-approved, pending otherwise)

        Example:
            >>> invoice = client.create_invoice(
            ...     to_agent_id="consumer_agent_123",
            ...     amount=5.00,
            ...     description="API usage fee - 1000 requests",
            ...     payment_rail="crypto"
            ... )
            >>> print(invoice["status"])  # "paid" if auto-approved
        """
        return self._request("POST", "/api/v1/invoices", json={
            "to_agent_id": to_agent_id,
            "amount": amount,
            "currency": currency,
            "description": description,
            "payment_rail": payment_rail,
            "expires_in_minutes": expires_in_minutes
        })

    def approve_invoice(self, invoice_id: str) -> Dict[str, Any]:
        """
        Consumer agent manually approves and pays a pending invoice.

        Args:
            invoice_id: Invoice ID to approve

        Returns:
            Payment confirmation

        Example:
            >>> result = client.approve_invoice("inv_abc123")
            >>> print(result["status"])  # "paid"
        """
        return self._request("POST", f"/api/v1/invoices/{invoice_id}/pay")

    def list_invoices(
        self,
        agent_id: str,
        role: str = "all",
        limit: int = 20
    ) -> Dict[str, Any]:
        """
        List invoices for an agent.

        Args:
            agent_id: Agent ID
            role: Filter by role - "all", "sent" (as provider), "received" (as consumer)
            limit: Max number of invoices to return

        Returns:
            Dict with agent_id and list of invoices

        Example:
            >>> invoices = client.list_invoices("agent_123", role="sent")
            >>> for inv in invoices["invoices"]:
            ...     print(inv["status"], inv["amount"])
        """
        return self._request(
            "GET",
            "/api/v1/invoices",
            params={"role": role, "limit": limit}
        )

    def set_billing_rule(
        self,
        max_amount: float,
        preferred_rail: str = "crypto",
        approved_provider_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Set auto-approval billing rule for your agent (consumer side).
        Invoices matching this rule will be automatically approved and paid.

        Args:
            max_amount: Maximum invoice amount to auto-approve
            preferred_rail: Default payment rail (crypto, card, bank)
            approved_provider_id: Specific provider to approve (None = approve all)

        Returns:
            Billing rule confirmation

        Example:
            >>> rule = client.set_billing_rule(
            ...     max_amount=50.0,
            ...     preferred_rail="crypto",
            ...     approved_provider_id="provider_agent_456"
            ... )
            >>> print(rule["message"])
        """
        return self._request("POST", "/api/v1/billing-rules", json={
            "approved_provider_id": approved_provider_id,
            "max_amount": max_amount,
            "preferred_rail": preferred_rail
        })

    def get_billing_rules(self, agent_id: str) -> Dict[str, Any]:
        """
        Get active billing rules for an agent.

        Args:
            agent_id: Agent ID

        Returns:
            Dict with agent_id and list of active rules
        """
        return self._request("GET", f"/api/v1/billing-rules/{agent_id}")

# Exceptions


    def create_agent(self, agent_id, name, wallet_address):
        """Create a new agent and get an API key (save it - shown only once)"""
        return self._request("POST", "/api/v1/agents", json={
            "agent_id": agent_id,
            "name": name,
            "wallet_address": wallet_address
        })

    def get_agent(self, agent_id):
        """Get agent details by ID"""
        return self._request("GET", f"/api/v1/agents/{agent_id}")

    def delete_agent(self, agent_id):
        """Delete an agent and all associated API keys"""
        return self._request("DELETE", f"/api/v1/agents/{agent_id}")

    def rotate_api_key(self, agent_id):
        """Rotate API key - old key is immediately deactivated"""
        return self._request("POST", f"/api/v1/agents/{agent_id}/rotate-key")


class PaymentError(Exception):
    pass

class AuthenticationError(PaymentError):
    pass

class InvalidRequestError(PaymentError):
    pass

class NetworkError(PaymentError):
    pass
