#!/usr/bin/env python3
"""
Runtime Timeout Management

Runtimees are created with a timeout (default 300s / 5 minutes).
You can extend the timeout of a running runtime at any time to prevent
it from being automatically terminated.

The maximum allowed timeout is 43200 seconds (12 hours).

Usage:
    export GRAVIXLAYER_API_KEY="tg_api_key_xxxxx"
    python examples/runtimes/10_timeout_management.py
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from gravixlayer import GravixLayer

client = GravixLayer(
    api_key=os.environ["GRAVIXLAYER_API_KEY"],
    cloud=os.environ.get("GRAVIXLAYER_CLOUD", "azure"),
    region=os.environ.get("GRAVIXLAYER_REGION", "eastus2"),
)

TEMPLATE = os.environ.get("GRAVIXLAYER_TEMPLATE", "python-base-v1")

# ---------------------------------------------------------------------------
# Create a runtime with a short timeout
# ---------------------------------------------------------------------------
runtime = client.runtime.create(
    template=TEMPLATE,
    timeout=120,  # 2 minutes
)
sid = runtime.runtime_id

info = client.runtime.get(sid)
print(f"Runtime    : {sid}")
print(f"Timeout at : {info.timeout_at}")

# ---------------------------------------------------------------------------
# Extend the timeout while the runtime is running
# ---------------------------------------------------------------------------
response = client.runtime.set_timeout(sid, timeout=600)
print(f"\nExtended   : {response.message}")
print(f"New timeout: {response.timeout_at}")

# ---------------------------------------------------------------------------
# Verify by fetching runtime info again
# ---------------------------------------------------------------------------
info = client.runtime.get(sid)
print(f"Confirmed  : timeout_at={info.timeout_at}")

# ---------------------------------------------------------------------------
# Clean up
# ---------------------------------------------------------------------------
client.runtime.kill(sid)
print("\nRuntime terminated.")
