"""Tests for storage module."""
