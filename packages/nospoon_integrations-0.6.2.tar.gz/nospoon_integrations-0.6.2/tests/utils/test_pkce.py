"""Tests for PKCE utilities."""

import re

from nospoon_integrations.utils.pkce import generate_code_challenge, generate_code_verifier


class TestGenerateCodeVerifier:
    def test_default_length(self) -> None:
        verifier = generate_code_verifier()
        assert len(verifier) == 64

    def test_custom_length(self) -> None:
        verifier = generate_code_verifier(128)
        assert len(verifier) == 128

    def test_unreserved_characters_only(self) -> None:
        verifier = generate_code_verifier(128)
        assert re.match(r"^[A-Za-z0-9\-._~]+$", verifier)

    def test_unique_verifiers(self) -> None:
        v1 = generate_code_verifier()
        v2 = generate_code_verifier()
        assert v1 != v2


class TestGenerateCodeChallenge:
    def test_base64url_encoded(self) -> None:
        verifier = generate_code_verifier()
        challenge = generate_code_challenge(verifier)
        assert "+" not in challenge
        assert "/" not in challenge
        assert "=" not in challenge
        assert len(challenge) > 0

    def test_consistent_output(self) -> None:
        verifier = "test-verifier-string"
        c1 = generate_code_challenge(verifier)
        c2 = generate_code_challenge(verifier)
        assert c1 == c2

    def test_different_verifiers_different_challenges(self) -> None:
        c1 = generate_code_challenge("verifier-1")
        c2 = generate_code_challenge("verifier-2")
        assert c1 != c2
