"""Generate a tabular dataset from a natural language description."""

from symagedocs import Client

client = Client()  # reads SYMAGEDOCS_API_KEY from env

# Parse NL description into column schema
schema = client.tabular.parse("employee name, department, hire date, salary, city, state")
print(f"Parsed {len(schema.columns)} columns (via {schema.parser_type}):")
for col in schema.columns:
    print(f"  {col.name}: {col.type}")

# Generate 5,000 rows
job = client.tabular.generate(columns=schema.columns, quantity=5000, output_formats=["csv"])
print(f"\nJob created: {job.job_id} ({job.credits_required} credits)")

# Wait and download
client.tabular.wait(job.job_id)
client.tabular.download(job.job_id, "csv", "./employees.csv")
print("Downloaded to ./employees.csv")
