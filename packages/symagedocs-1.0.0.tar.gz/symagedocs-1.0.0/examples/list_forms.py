"""List all available forms and their credit costs."""

from symagedocs import Client

client = Client()  # reads SYMAGEDOCS_API_KEY from env

forms = client.forms.list()
print(f"Found {len(forms)} forms:\n")

for f in forms:
    print(f"  {f.id:<30} {f.name:<45} {f.credit_cost:>4} credits  ({f.field_count} fields)")
