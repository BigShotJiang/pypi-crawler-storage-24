"""Generate 100 W-2 documents and download as PDF + JSON."""

from symagedocs import Client

client = Client()  # reads SYMAGEDOCS_API_KEY from env

# Create generation job
job = client.generate.create(
    "irs_w2_2024",
    quantity=100,
    output_formats=["pdf_typed", "json"],
)
print(f"Job created: {job.job_id} ({job.credits_required} credits)")

# Wait for completion (shows progress bar if tqdm installed)
result = client.generate.wait(job.job_id)
print(f"Completed: {result.credits_charged} credits charged")

# Download
client.generate.download(job.job_id, "pdf_typed", "./w2_documents.zip")
client.generate.download(job.job_id, "json", "./w2_data.json")
print("Downloaded to ./w2_documents.zip and ./w2_data.json")
