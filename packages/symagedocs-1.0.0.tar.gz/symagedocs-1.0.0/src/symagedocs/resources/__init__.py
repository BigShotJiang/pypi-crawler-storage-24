"""Resource modules for each API endpoint group."""
