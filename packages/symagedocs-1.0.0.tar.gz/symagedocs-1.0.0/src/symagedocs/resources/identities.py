"""Raw identity generation resource."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .._base import async_request, sync_request
from .._config import ClientConfig


class IdentitiesResource:
    """Sync raw identity generation."""

    def __init__(self, client: httpx.Client, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    def generate(
        self,
        *,
        quantity: int = 1,
        config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Generate raw synthetic identities as JSON dicts."""
        body: Dict[str, Any] = {"quantity": quantity}
        if config:
            body["config"] = config
        if seed is not None:
            body["seed"] = seed
        data, _ = sync_request(self._client, self._config, "POST", "/api/v1/identities", json=body)
        return list(data)


class AsyncIdentitiesResource:
    """Async raw identity generation."""

    def __init__(self, client: httpx.AsyncClient, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    async def generate(
        self,
        *,
        quantity: int = 1,
        config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"quantity": quantity}
        if config:
            body["config"] = config
        if seed is not None:
            body["seed"] = seed
        data, _ = await async_request(
            self._client, self._config, "POST", "/api/v1/identities", json=body
        )
        return list(data)
