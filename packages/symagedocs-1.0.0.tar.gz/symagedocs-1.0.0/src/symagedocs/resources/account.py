"""Account resource."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .._base import async_request, sync_request
from .._config import ClientConfig
from .._types import Balance, Usage


class AccountResource:
    """Sync account operations."""

    def __init__(self, client: httpx.Client, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    def balance(self) -> Balance:
        """Get credit balance."""
        data, _ = sync_request(self._client, self._config, "GET", "/api/v1/account/balance")
        return Balance.model_validate(data)

    def usage(self, *, days: int = 30) -> Usage:
        """Get usage summary for the specified period."""
        data, _ = sync_request(
            self._client, self._config, "GET", "/api/v1/account/usage",
            params={"days": days},
        )
        return Usage.model_validate(data)


class AsyncAccountResource:
    """Async account operations."""

    def __init__(self, client: httpx.AsyncClient, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    async def balance(self) -> Balance:
        data, _ = await async_request(
            self._client, self._config, "GET", "/api/v1/account/balance"
        )
        return Balance.model_validate(data)

    async def usage(self, *, days: int = 30) -> Usage:
        data, _ = await async_request(
            self._client, self._config, "GET", "/api/v1/account/usage",
            params={"days": days},
        )
        return Usage.model_validate(data)
