"""Tabular data generation resource."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import httpx

from .._base import async_request, sync_request, sync_request_raw, async_request_raw
from .._config import ClientConfig
from .._errors import ConflictError
from .._types import TabularColumn, TabularJob, TabularSchema, TabularStatus


class TabularResource:
    """Sync tabular generation operations."""

    def __init__(self, client: httpx.Client, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    def parse(self, prompt: str) -> TabularSchema:
        """Parse a natural-language description into a column schema."""
        data, _ = sync_request(
            self._client, self._config, "POST", "/api/v1/tabular/parse",
            json={"prompt": prompt},
        )
        return TabularSchema.model_validate(data)

    def generate(
        self,
        *,
        columns: Union[List[Dict[str, Any]], List[TabularColumn]],
        quantity: int = 100,
        output_formats: Optional[List[str]] = None,
        seed: Optional[int] = None,
    ) -> TabularJob:
        """Create a tabular generation job."""
        col_dicts = [
            c.model_dump() if isinstance(c, TabularColumn) else c
            for c in columns
        ]
        body: Dict[str, Any] = {"columns": col_dicts, "quantity": quantity}
        if output_formats:
            body["output_formats"] = output_formats
        if seed is not None:
            body["seed"] = seed
        data, _ = sync_request(
            self._client, self._config, "POST", "/api/v1/tabular/generate", json=body,
        )
        return TabularJob.model_validate(data)

    def status(self, job_id: str) -> TabularStatus:
        """Get tabular job status and progress."""
        data, _ = sync_request(
            self._client, self._config, "GET", f"/api/v1/tabular/{job_id}/status",
        )
        return TabularStatus.model_validate(data)

    def download(self, job_id: str, format: str, path: str) -> Path:
        """Download tabular output to a file."""
        resp = sync_request_raw(
            self._client, self._config, "GET", f"/api/v1/tabular/{job_id}/download/{format}",
        )
        out = Path(path)
        out.write_bytes(resp.content)
        return out

    def wait(self, job_id: str, *, poll_interval: float = 2.0) -> TabularStatus:
        """Poll until tabular job is completed or failed."""
        try:
            from tqdm import tqdm
            has_tqdm = True
        except ImportError:
            has_tqdm = False

        pbar = None
        if has_tqdm:
            pbar = tqdm(total=100, unit="%", desc="Generating", leave=True)

        while True:
            s = self.status(job_id)
            if pbar is not None:
                pbar.n = int(s.percent)
                pbar.refresh()

            if s.status in ("completed", "failed"):
                if pbar is not None:
                    pbar.n = 100
                    pbar.refresh()
                    pbar.close()
                if s.status == "failed":
                    raise ConflictError(s.error or "Job failed", status_code=409, code="job_failed")
                return s
            time.sleep(poll_interval)


class AsyncTabularResource:
    """Async tabular generation operations."""

    def __init__(self, client: httpx.AsyncClient, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    async def parse(self, prompt: str) -> TabularSchema:
        data, _ = await async_request(
            self._client, self._config, "POST", "/api/v1/tabular/parse",
            json={"prompt": prompt},
        )
        return TabularSchema.model_validate(data)

    async def generate(
        self,
        *,
        columns: Union[List[Dict[str, Any]], List[TabularColumn]],
        quantity: int = 100,
        output_formats: Optional[List[str]] = None,
        seed: Optional[int] = None,
    ) -> TabularJob:
        col_dicts = [c.model_dump() if isinstance(c, TabularColumn) else c for c in columns]
        body: Dict[str, Any] = {"columns": col_dicts, "quantity": quantity}
        if output_formats:
            body["output_formats"] = output_formats
        if seed is not None:
            body["seed"] = seed
        data, _ = await async_request(
            self._client, self._config, "POST", "/api/v1/tabular/generate", json=body,
        )
        return TabularJob.model_validate(data)

    async def status(self, job_id: str) -> TabularStatus:
        data, _ = await async_request(
            self._client, self._config, "GET", f"/api/v1/tabular/{job_id}/status",
        )
        return TabularStatus.model_validate(data)

    async def download(self, job_id: str, format: str, path: str) -> Path:
        resp = await async_request_raw(
            self._client, self._config, "GET", f"/api/v1/tabular/{job_id}/download/{format}",
        )
        out = Path(path)
        out.write_bytes(resp.content)
        return out

    async def wait(self, job_id: str, *, poll_interval: float = 2.0) -> TabularStatus:
        import asyncio
        while True:
            s = await self.status(job_id)
            if s.status in ("completed", "failed"):
                if s.status == "failed":
                    raise ConflictError(s.error or "Job failed", status_code=409, code="job_failed")
                return s
            await asyncio.sleep(poll_interval)
