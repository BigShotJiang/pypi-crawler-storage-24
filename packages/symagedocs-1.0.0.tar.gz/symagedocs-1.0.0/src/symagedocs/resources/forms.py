"""Forms catalog resource."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .._base import async_request, sync_request
from .._config import ClientConfig
from .._types import Form, FormDetail


class FormsResource:
    """Sync forms catalog operations."""

    def __init__(self, client: httpx.Client, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    def list(self, *, category: Optional[str] = None) -> List[Form]:
        """List available forms, optionally filtered by category."""
        params: Optional[Dict[str, Any]] = None
        if category:
            params = {"category": category}
        data, _ = sync_request(self._client, self._config, "GET", "/api/v1/forms", params=params)
        return [Form.model_validate(f) for f in data]

    def get(self, form_id: str) -> FormDetail:
        """Get details for a specific form including field definitions."""
        data, _ = sync_request(self._client, self._config, "GET", f"/api/v1/forms/{form_id}")
        return FormDetail.model_validate(data)


class AsyncFormsResource:
    """Async forms catalog operations."""

    def __init__(self, client: httpx.AsyncClient, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    async def list(self, *, category: Optional[str] = None) -> List[Form]:
        """List available forms, optionally filtered by category."""
        params: Optional[Dict[str, Any]] = None
        if category:
            params = {"category": category}
        data, _ = await async_request(
            self._client, self._config, "GET", "/api/v1/forms", params=params
        )
        return [Form.model_validate(f) for f in data]

    async def get(self, form_id: str) -> FormDetail:
        """Get details for a specific form including field definitions."""
        data, _ = await async_request(
            self._client, self._config, "GET", f"/api/v1/forms/{form_id}"
        )
        return FormDetail.model_validate(data)
