"""Document generation resource."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

from .._base import async_request, sync_request, sync_request_raw, async_request_raw
from .._config import ClientConfig
from .._errors import ConflictError
from .._pagination import CursorPage
from .._types import CreateJobResult, Job, JobSummary


class GenerationResource:
    """Sync document generation operations."""

    def __init__(self, client: httpx.Client, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    def create(
        self,
        form_id: str,
        *,
        quantity: int = 1,
        output_formats: Optional[List[str]] = None,
        config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
    ) -> CreateJobResult:
        """Create an async generation job."""
        body: Dict[str, Any] = {"form_id": form_id, "quantity": quantity}
        if output_formats:
            body["output_formats"] = output_formats
        if config:
            body["config"] = config
        if seed is not None:
            body["seed"] = seed
        data, _ = sync_request(self._client, self._config, "POST", "/api/v1/generate", json=body)
        return CreateJobResult.model_validate(data)

    def list_jobs(
        self,
        *,
        limit: int = 50,
        cursor: Optional[str] = None,
        status: Optional[str] = None,
    ) -> CursorPage[JobSummary]:
        """List generation jobs with cursor-based pagination."""
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        data, meta = sync_request(self._client, self._config, "GET", "/api/v1/jobs", params=params)

        items = [JobSummary.model_validate(j) for j in data]
        has_more = meta.get("has_more", False)
        next_cursor = meta.get("next_cursor")

        def fetch_next() -> CursorPage[JobSummary]:
            return self.list_jobs(limit=limit, cursor=next_cursor, status=status)

        return CursorPage(
            data=items, has_more=has_more, next_cursor=next_cursor, _fetch_next=fetch_next,
        )

    def get_job(self, job_id: str) -> Job:
        """Get job status and details."""
        data, _ = sync_request(self._client, self._config, "GET", f"/api/v1/jobs/{job_id}")
        return Job.model_validate(data)

    def download(self, job_id: str, format: str, path: str) -> Path:
        """Download job output to a file. Returns the file path."""
        resp = sync_request_raw(
            self._client, self._config, "GET", f"/api/v1/jobs/{job_id}/download/{format}",
        )
        out = Path(path)
        out.write_bytes(resp.content)
        return out

    def wait(self, job_id: str, *, poll_interval: float = 3.0) -> Job:
        """Poll until job is completed or failed. Returns final status."""
        try:
            from tqdm import tqdm
            has_tqdm = True
        except ImportError:
            has_tqdm = False

        pbar = None
        if has_tqdm:
            pbar = tqdm(total=100, unit="%", desc="Generating", leave=True)

        while True:
            job = self.get_job(job_id)
            if pbar is not None:
                pbar.n = int(job.progress * 100)
                pbar.refresh()

            if job.status in ("completed", "failed"):
                if pbar is not None:
                    pbar.n = 100
                    pbar.refresh()
                    pbar.close()
                if job.status == "failed":
                    raise ConflictError(
                        job.error or "Job failed",
                        status_code=409,
                        code="job_failed",
                    )
                return job
            time.sleep(poll_interval)


class AsyncGenerationResource:
    """Async document generation operations."""

    def __init__(self, client: httpx.AsyncClient, config: ClientConfig) -> None:
        self._client = client
        self._config = config

    async def create(
        self,
        form_id: str,
        *,
        quantity: int = 1,
        output_formats: Optional[List[str]] = None,
        config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
    ) -> CreateJobResult:
        body: Dict[str, Any] = {"form_id": form_id, "quantity": quantity}
        if output_formats:
            body["output_formats"] = output_formats
        if config:
            body["config"] = config
        if seed is not None:
            body["seed"] = seed
        data, _ = await async_request(
            self._client, self._config, "POST", "/api/v1/generate", json=body
        )
        return CreateJobResult.model_validate(data)

    async def get_job(self, job_id: str) -> Job:
        data, _ = await async_request(
            self._client, self._config, "GET", f"/api/v1/jobs/{job_id}"
        )
        return Job.model_validate(data)

    async def list_jobs(
        self, *, limit: int = 50, cursor: Optional[str] = None, status: Optional[str] = None,
    ) -> CursorPage[JobSummary]:
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        data, meta = await async_request(
            self._client, self._config, "GET", "/api/v1/jobs", params=params
        )
        items = [JobSummary.model_validate(j) for j in data]
        return CursorPage(
            data=items,
            has_more=meta.get("has_more", False),
            next_cursor=meta.get("next_cursor"),
        )

    async def download(self, job_id: str, format: str, path: str) -> Path:
        resp = await async_request_raw(
            self._client, self._config, "GET", f"/api/v1/jobs/{job_id}/download/{format}",
        )
        out = Path(path)
        out.write_bytes(resp.content)
        return out

    async def wait(self, job_id: str, *, poll_interval: float = 3.0) -> Job:
        import asyncio
        while True:
            job = await self.get_job(job_id)
            if job.status in ("completed", "failed"):
                if job.status == "failed":
                    raise ConflictError(job.error or "Job failed", status_code=409, code="job_failed")
                return job
            await asyncio.sleep(poll_interval)
