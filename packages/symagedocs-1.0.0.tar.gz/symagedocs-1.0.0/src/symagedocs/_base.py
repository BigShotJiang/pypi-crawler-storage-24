"""Shared HTTP logic: auth headers, envelope parsing, retry."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from ._config import ClientConfig
from ._errors import RateLimitError, ServerError, raise_for_status

T = TypeVar("T")


def _auth_headers(config: ClientConfig) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {config.api_key}",
        "Content-Type": "application/json",
    }


def _parse_envelope(body: Dict[str, Any]) -> tuple[Any, Dict[str, Any]]:
    """Extract data and meta from response envelope."""
    data = body.get("data", body)
    meta = body.get("meta", {})
    return data, meta


# ── Sync helpers ─────────────────────────────────────────────


def sync_request(
    client: httpx.Client,
    config: ClientConfig,
    method: str,
    path: str,
    *,
    json: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
) -> tuple[Any, Dict[str, Any]]:
    """Make an HTTP request with retry and envelope parsing."""
    url = f"{config.base_url}{path}"
    headers = _auth_headers(config)
    last_exc: Optional[Exception] = None

    for attempt in range(config.max_retries + 1):
        try:
            resp = client.request(
                method, url, json=json, params=params, headers=headers,
            )
        except httpx.ConnectError as e:
            last_exc = e
            if attempt < config.max_retries:
                time.sleep(min(2 ** attempt, 30))
                continue
            raise ServerError(
                f"Cannot connect to {config.base_url}",
                status_code=0,
            ) from e

        if resp.status_code == 429 and attempt < config.max_retries:
            time.sleep(min(2 ** attempt, 30))
            continue
        if resp.status_code >= 500 and attempt < config.max_retries:
            time.sleep(min(2 ** attempt, 30))
            continue

        body = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
        raise_for_status(resp.status_code, body)
        return _parse_envelope(body)

    raise ServerError("Max retries exceeded", status_code=0)


def sync_request_raw(
    client: httpx.Client,
    config: ClientConfig,
    method: str,
    path: str,
    *,
    params: Optional[Dict[str, Any]] = None,
) -> httpx.Response:
    """Make a raw request (for downloads) with retry."""
    url = f"{config.base_url}{path}"
    headers = _auth_headers(config)

    for attempt in range(config.max_retries + 1):
        try:
            resp = client.request(method, url, params=params, headers=headers)
        except httpx.ConnectError as e:
            if attempt < config.max_retries:
                time.sleep(min(2 ** attempt, 30))
                continue
            raise ServerError(f"Cannot connect to {config.base_url}", status_code=0) from e

        if resp.status_code in (429, 500, 502, 503) and attempt < config.max_retries:
            time.sleep(min(2 ** attempt, 30))
            continue

        if resp.status_code >= 400:
            body = resp.json() if "application/json" in resp.headers.get("content-type", "") else {}
            raise_for_status(resp.status_code, body)

        return resp

    raise ServerError("Max retries exceeded", status_code=0)


# ── Async helpers ────────────────────────────────────────────

import asyncio


async def async_request(
    client: httpx.AsyncClient,
    config: ClientConfig,
    method: str,
    path: str,
    *,
    json: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
) -> tuple[Any, Dict[str, Any]]:
    """Async version of sync_request."""
    url = f"{config.base_url}{path}"
    headers = _auth_headers(config)

    for attempt in range(config.max_retries + 1):
        try:
            resp = await client.request(
                method, url, json=json, params=params, headers=headers,
            )
        except httpx.ConnectError as e:
            if attempt < config.max_retries:
                await asyncio.sleep(min(2 ** attempt, 30))
                continue
            raise ServerError(f"Cannot connect to {config.base_url}", status_code=0) from e

        if resp.status_code == 429 and attempt < config.max_retries:
            await asyncio.sleep(min(2 ** attempt, 30))
            continue
        if resp.status_code >= 500 and attempt < config.max_retries:
            await asyncio.sleep(min(2 ** attempt, 30))
            continue

        body = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
        raise_for_status(resp.status_code, body)
        return _parse_envelope(body)

    raise ServerError("Max retries exceeded", status_code=0)


async def async_request_raw(
    client: httpx.AsyncClient,
    config: ClientConfig,
    method: str,
    path: str,
    *,
    params: Optional[Dict[str, Any]] = None,
) -> httpx.Response:
    """Async version of sync_request_raw."""
    url = f"{config.base_url}{path}"
    headers = _auth_headers(config)

    for attempt in range(config.max_retries + 1):
        try:
            resp = await client.request(method, url, params=params, headers=headers)
        except httpx.ConnectError as e:
            if attempt < config.max_retries:
                await asyncio.sleep(min(2 ** attempt, 30))
                continue
            raise ServerError(f"Cannot connect to {config.base_url}", status_code=0) from e

        if resp.status_code in (429, 500, 502, 503) and attempt < config.max_retries:
            await asyncio.sleep(min(2 ** attempt, 30))
            continue

        if resp.status_code >= 400:
            body = resp.json() if "application/json" in resp.headers.get("content-type", "") else {}
            raise_for_status(resp.status_code, body)

        return resp

    raise ServerError("Max retries exceeded", status_code=0)
