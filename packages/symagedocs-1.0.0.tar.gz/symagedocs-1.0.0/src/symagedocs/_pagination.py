"""Cursor-based pagination."""

from __future__ import annotations

from typing import Any, Callable, Dict, Generic, Iterator, List, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class CursorPage(Generic[T]):
    """A single page of results with cursor pagination metadata."""

    def __init__(
        self,
        data: List[T],
        has_more: bool = False,
        next_cursor: Optional[str] = None,
        _fetch_next: Optional[Callable[[], "CursorPage[T]"]] = None,
    ) -> None:
        self.data = data
        self.has_more = has_more
        self.next_cursor = next_cursor
        self._fetch_next = _fetch_next

    def __iter__(self) -> Iterator[T]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    def next_page(self) -> "CursorPage[T]":
        """Fetch the next page of results."""
        if not self.has_more or self._fetch_next is None:
            return CursorPage(data=[])
        return self._fetch_next()

    def iter_all(self) -> Iterator[T]:
        """Iterate through all items across all pages."""
        page: CursorPage[T] = self
        while True:
            yield from page.data
            if not page.has_more:
                break
            page = page.next_page()
