"""Asynchronous SymageDocs client."""

from __future__ import annotations

from typing import Any

import httpx

from ._config import ClientConfig
from .resources.account import AsyncAccountResource
from .resources.forms import AsyncFormsResource
from .resources.generation import AsyncGenerationResource
from .resources.identities import AsyncIdentitiesResource
from .resources.tabular import AsyncTabularResource


class AsyncClient:
    """Asynchronous SymageDocs API client.

    Usage::

        from symagedocs import AsyncClient

        async with AsyncClient(api_key="sk_live_...") as client:
            forms = await client.forms.list()
    """

    def __init__(
        self,
        api_key: str = "",
        *,
        base_url: str = "",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.AsyncClient(timeout=timeout)

        self.forms = AsyncFormsResource(self._http, self._config)
        self.generate = AsyncGenerationResource(self._http, self._config)
        self.identities = AsyncIdentitiesResource(self._http, self._config)
        self.tabular = AsyncTabularResource(self._http, self._config)
        self.account = AsyncAccountResource(self._http, self._config)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def __repr__(self) -> str:
        return f"AsyncClient(base_url={self._config.base_url!r})"
