"""Pydantic models for all SymageDocs API response types."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


# ── Forms ────────────────────────────────────────────────────


class FormField(BaseModel):
    id: str
    label: str
    type: str
    page: int


class Form(BaseModel):
    id: str
    name: str
    category: str
    year: Optional[int] = None
    family: Optional[str] = None
    entity_type: str
    credit_cost: int
    field_count: int


class FormDetail(Form):
    version: Optional[str] = None
    page_count: Optional[int] = None
    fields: List[FormField] = []


# ── Generation Jobs ──────────────────────────────────────────


class Job(BaseModel):
    """Full job status returned by GET /jobs/{id}."""

    job_id: str
    status: str
    progress: float = 0.0
    form_id: str = ""
    form_name: str = ""
    quantity: int = 0
    output_formats: List[str] = []
    credits_required: int = 0
    credits_charged: int = 0
    seed: Optional[int] = None
    error: Optional[str] = None
    created_at: Optional[str] = None
    completed_at: Optional[str] = None


class JobSummary(BaseModel):
    """Job summary returned by GET /jobs (list)."""

    job_id: str
    form_id: str = ""
    form_name: str = ""
    quantity: int = 0
    status: str = ""
    output_formats: List[str] = []
    credits_charged: int = 0
    created_at: Optional[str] = None


class CreateJobResult(BaseModel):
    """Result of POST /generate."""

    job_id: str
    status: str
    credits_required: int = 0


# ── Account ──────────────────────────────────────────────────


class Balance(BaseModel):
    credits_used: int
    credits_allocated: int


class Usage(BaseModel):
    period_days: int
    total_jobs: int
    total_items_generated: int
    total_credits_used: int
    jobs_by_status: Dict[str, int] = {}


# ── Tabular ──────────────────────────────────────────────────


class TabularColumn(BaseModel):
    name: str
    type: str
    constraints: Dict[str, Any] = {}


class TabularSchema(BaseModel):
    """Result of POST /tabular/parse."""

    columns: List[TabularColumn]
    parser_type: str
    model: Optional[str] = None


class TabularJob(BaseModel):
    """Result of POST /tabular/generate."""

    job_id: str
    status: str
    credits_required: int = 0


class TabularStatus(BaseModel):
    """Result of GET /tabular/{id}/status."""

    job_id: str
    status: str
    rows_generated: int = 0
    total_rows: int = 0
    percent: float = 0.0
    estimated_seconds_remaining: Optional[float] = None
    error: Optional[str] = None


# ── Response Meta ────────────────────────────────────────────


class ResponseMeta(BaseModel):
    """Metadata from the response envelope."""

    request_id: Optional[str] = None
    count: Optional[int] = None
    has_more: Optional[bool] = None
    next_cursor: Optional[str] = None
    credits_charged: Optional[int] = None
