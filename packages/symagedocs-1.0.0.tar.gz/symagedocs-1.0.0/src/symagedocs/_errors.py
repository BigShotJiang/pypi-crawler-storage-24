"""Error hierarchy for the SymageDocs SDK."""

from __future__ import annotations

from typing import Optional


class SymageDocsError(Exception):
    """Base exception for all SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        code: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.message!r}, status_code={self.status_code})"


class AuthenticationError(SymageDocsError):
    """401 — API key is missing, invalid, or revoked."""


class PermissionDeniedError(SymageDocsError):
    """403 — API key lacks required scope."""


class NotFoundError(SymageDocsError):
    """404 — Resource not found."""


class RateLimitError(SymageDocsError):
    """429 — Rate limit exceeded."""


class InsufficientCreditsError(SymageDocsError):
    """402 — Not enough credits."""


class ConflictError(SymageDocsError):
    """409 — e.g., job not completed yet."""


class ValidationError(SymageDocsError):
    """400 — Invalid request parameters."""


class ServerError(SymageDocsError):
    """5xx — Server-side error."""


STATUS_TO_ERROR: dict[int, type[SymageDocsError]] = {
    400: ValidationError,
    401: AuthenticationError,
    402: InsufficientCreditsError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    429: RateLimitError,
}


def raise_for_status(status_code: int, body: object) -> None:
    """Raise the appropriate SDK error for an HTTP error response."""
    if 200 <= status_code < 300:
        return

    # Parse error body
    code: Optional[str] = None
    message = f"HTTP {status_code}"

    if isinstance(body, dict):
        detail = body.get("detail")
        if isinstance(detail, dict):
            code = detail.get("code")
            message = detail.get("message", message)
        elif isinstance(detail, str):
            message = detail

    error_cls = STATUS_TO_ERROR.get(status_code)
    if error_cls is None:
        if status_code >= 500:
            error_cls = ServerError
        else:
            error_cls = SymageDocsError

    raise error_cls(message, status_code=status_code, code=code)
