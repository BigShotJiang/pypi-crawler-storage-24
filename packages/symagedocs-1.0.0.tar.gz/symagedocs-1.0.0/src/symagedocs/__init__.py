"""SymageDocs Python SDK — generate synthetic documents, identities, and datasets.

Usage::

    from symagedocs import Client

    client = Client(api_key="sk_live_...")
    forms = client.forms.list()
"""

from ._async_client import AsyncClient
from ._client import Client
from ._errors import (
    AuthenticationError,
    ConflictError,
    InsufficientCreditsError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    SymageDocsError,
    ValidationError,
)
from ._types import (
    Balance,
    CreateJobResult,
    Form,
    FormDetail,
    FormField,
    Job,
    JobSummary,
    TabularColumn,
    TabularJob,
    TabularSchema,
    TabularStatus,
    Usage,
)

__all__ = [
    "Client",
    "AsyncClient",
    # Types
    "Balance",
    "CreateJobResult",
    "Form",
    "FormDetail",
    "FormField",
    "Job",
    "JobSummary",
    "TabularColumn",
    "TabularJob",
    "TabularSchema",
    "TabularStatus",
    "Usage",
    # Errors
    "SymageDocsError",
    "AuthenticationError",
    "ConflictError",
    "InsufficientCreditsError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
]

__version__ = "1.0.0"
