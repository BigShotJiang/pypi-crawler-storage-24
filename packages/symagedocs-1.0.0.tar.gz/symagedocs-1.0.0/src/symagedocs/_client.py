"""Synchronous SymageDocs client."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from ._config import ClientConfig
from .resources.account import AccountResource
from .resources.forms import FormsResource
from .resources.generation import GenerationResource
from .resources.identities import IdentitiesResource
from .resources.tabular import TabularResource


class Client:
    """Synchronous SymageDocs API client.

    Usage::

        from symagedocs import Client

        client = Client(api_key="sk_live_...")
        forms = client.forms.list()
    """

    def __init__(
        self,
        api_key: str = "",
        *,
        base_url: str = "",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.Client(timeout=timeout)

        self.forms = FormsResource(self._http, self._config)
        self.generate = GenerationResource(self._http, self._config)
        self.identities = IdentitiesResource(self._http, self._config)
        self.tabular = TabularResource(self._http, self._config)
        self.account = AccountResource(self._http, self._config)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Client(base_url={self._config.base_url!r})"
