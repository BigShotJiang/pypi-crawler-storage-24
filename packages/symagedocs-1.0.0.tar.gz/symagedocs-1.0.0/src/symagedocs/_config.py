"""Client configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


DEFAULT_BASE_URL = "https://symagedocs.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
ENV_API_KEY = "SYMAGEDOCS_API_KEY"
ENV_BASE_URL = "SYMAGEDOCS_BASE_URL"


@dataclass
class ClientConfig:
    """Configuration for the SymageDocs client."""

    api_key: str = ""
    base_url: str = ""
    timeout: float = DEFAULT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES

    def __post_init__(self) -> None:
        if not self.api_key:
            self.api_key = os.environ.get(ENV_API_KEY, "")
        if not self.api_key:
            raise ValueError(
                f"API key is required. Pass api_key= or set {ENV_API_KEY} environment variable."
            )
        if not self.base_url:
            self.base_url = os.environ.get(ENV_BASE_URL, DEFAULT_BASE_URL)
        self.base_url = self.base_url.rstrip("/")
