"""Tests for error handling and retry logic."""

import pytest
from pytest_httpx import HTTPXMock

from symagedocs import Client
from symagedocs._errors import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    raise_for_status,
)
from tests.conftest import API_KEY, BASE_URL


@pytest.fixture
def client():
    c = Client(api_key=API_KEY, base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


class TestRaiseForStatus:
    def test_200_does_not_raise(self):
        raise_for_status(200, {})

    def test_401_raises_authentication_error(self):
        with pytest.raises(AuthenticationError):
            raise_for_status(401, {"detail": "Invalid API key"})

    def test_404_raises_not_found(self):
        with pytest.raises(NotFoundError):
            raise_for_status(404, {"detail": {"code": "job_not_found", "message": "Not found", "status": 404}})

    def test_429_raises_rate_limit(self):
        with pytest.raises(RateLimitError):
            raise_for_status(429, {"detail": "Rate limit exceeded"})

    def test_500_raises_server_error(self):
        with pytest.raises(ServerError):
            raise_for_status(500, {"detail": "Internal error"})

    def test_400_raises_validation_error(self):
        with pytest.raises(ValidationError):
            raise_for_status(400, {"detail": {"code": "unknown_form", "message": "Unknown form", "status": 400}})

    def test_error_has_attributes(self):
        with pytest.raises(ValidationError) as exc_info:
            raise_for_status(400, {"detail": {"code": "unknown_form", "message": "Unknown form: x", "status": 400}})
        err = exc_info.value
        assert err.status_code == 400
        assert err.code == "unknown_form"
        assert "Unknown form: x" in err.message


class TestHttpErrors:
    def test_401_from_api(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(status_code=401, json={"detail": "Invalid API key"})
        with pytest.raises(AuthenticationError):
            client.forms.list()

    def test_404_from_api(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(
            status_code=404,
            json={"detail": {"code": "form_not_found", "message": "Form not found", "status": 404}},
        )
        with pytest.raises(NotFoundError):
            client.forms.get("nonexistent")


class TestRetry:
    def test_retries_on_429(self, httpx_mock: HTTPXMock):
        """Client retries 429 responses."""
        # max_retries=1: first attempt 429, second attempt success
        c = Client(api_key=API_KEY, base_url=BASE_URL, max_retries=1)
        httpx_mock.add_response(status_code=429, json={"detail": "Rate limited"})
        httpx_mock.add_response(json={"data": [], "meta": {"request_id": "x", "count": 0}})

        forms = c.forms.list()
        assert forms == []
        assert len(httpx_mock.get_requests()) == 2
        c.close()

    def test_retries_on_500(self, httpx_mock: HTTPXMock):
        """Client retries 500 responses."""
        c = Client(api_key=API_KEY, base_url=BASE_URL, max_retries=1)
        httpx_mock.add_response(status_code=500, json={"detail": "Server error"})
        httpx_mock.add_response(json={"data": [], "meta": {"request_id": "x", "count": 0}})

        forms = c.forms.list()
        assert forms == []
        assert len(httpx_mock.get_requests()) == 2
        c.close()

    def test_no_retry_on_400(self, httpx_mock: HTTPXMock):
        """Client does NOT retry 400 errors."""
        c = Client(api_key=API_KEY, base_url=BASE_URL, max_retries=2)
        httpx_mock.add_response(
            status_code=400,
            json={"detail": {"code": "bad_request", "message": "Bad", "status": 400}},
        )

        with pytest.raises(ValidationError):
            c.forms.list()
        assert len(httpx_mock.get_requests()) == 1
        c.close()
