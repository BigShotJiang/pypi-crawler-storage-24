"""Shared test fixtures."""

import pytest


API_KEY = "sk_live_test1234567890abcdef1234567890abcdef1234567890ab"
BASE_URL = "https://test.symagedocs.ai"


def envelope(data, **meta_extra):
    """Build a response envelope."""
    meta = {"request_id": "test-req-id", **meta_extra}
    return {"data": data, "meta": meta}
