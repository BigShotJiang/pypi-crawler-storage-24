"""Tests for the forms resource."""

import httpx
import pytest
from pytest_httpx import HTTPXMock

from symagedocs import Client, Form, FormDetail
from tests.conftest import API_KEY, BASE_URL, envelope


@pytest.fixture
def client():
    c = Client(api_key=API_KEY, base_url=BASE_URL)
    yield c
    c.close()


SAMPLE_FORM = {
    "id": "irs_w2_2024",
    "name": "W-2 Wage and Tax Statement",
    "category": "tax",
    "year": 2024,
    "family": "w2",
    "entity_type": "individual",
    "credit_cost": 20,
    "field_count": 20,
}


class TestListForms:
    def test_list_forms(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope([SAMPLE_FORM], count=1))

        forms = client.forms.list()
        assert len(forms) == 1
        assert isinstance(forms[0], Form)
        assert forms[0].id == "irs_w2_2024"
        assert forms[0].credit_cost == 20

    def test_list_forms_with_category(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope([SAMPLE_FORM], count=1))

        forms = client.forms.list(category="tax")
        assert len(forms) == 1
        req = httpx_mock.get_request()
        assert "category=tax" in str(req.url)

    def test_list_forms_sends_auth_header(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope([], count=0))

        client.forms.list()
        req = httpx_mock.get_request()
        assert req.headers["authorization"] == f"Bearer {API_KEY}"


class TestGetForm:
    def test_get_form(self, httpx_mock: HTTPXMock, client: Client):
        detail = {
            **SAMPLE_FORM,
            "version": "2024-01-15",
            "page_count": 1,
            "fields": [{"id": "ssn", "label": "SSN", "type": "ssn", "page": 1}],
        }
        httpx_mock.add_response(json=envelope(detail))

        form = client.forms.get("irs_w2_2024")
        assert isinstance(form, FormDetail)
        assert form.id == "irs_w2_2024"
        assert len(form.fields) == 1
        assert form.fields[0].id == "ssn"
