"""Tests for the account resource."""

import pytest
from pytest_httpx import HTTPXMock

from symagedocs import Client, Balance, Usage
from tests.conftest import API_KEY, BASE_URL, envelope


@pytest.fixture
def client():
    c = Client(api_key=API_KEY, base_url=BASE_URL)
    yield c
    c.close()


class TestBalance:
    def test_balance(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({"credits_used": 5000, "credits_allocated": 10000}))

        balance = client.account.balance()
        assert isinstance(balance, Balance)
        assert balance.credits_used == 5000
        assert balance.credits_allocated == 10000


class TestUsage:
    def test_usage(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({
            "period_days": 30,
            "total_jobs": 10,
            "total_items_generated": 500,
            "total_credits_used": 3000,
            "jobs_by_status": {"completed": 9, "failed": 1},
        }))

        usage = client.account.usage(days=30)
        assert isinstance(usage, Usage)
        assert usage.total_jobs == 10
        assert usage.jobs_by_status["completed"] == 9

    def test_usage_passes_days_param(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({
            "period_days": 7, "total_jobs": 0, "total_items_generated": 0,
            "total_credits_used": 0, "jobs_by_status": {},
        }))

        client.account.usage(days=7)
        req = httpx_mock.get_request()
        assert "days=7" in str(req.url)
