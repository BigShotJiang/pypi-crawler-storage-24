"""Tests for the tabular resource."""

import json

import pytest
from pytest_httpx import HTTPXMock

from symagedocs import Client, TabularColumn, TabularJob, TabularSchema, TabularStatus
from tests.conftest import API_KEY, BASE_URL, envelope


@pytest.fixture
def client():
    c = Client(api_key=API_KEY, base_url=BASE_URL)
    yield c
    c.close()


class TestTabularParse:
    def test_parse(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({
            "columns": [
                {"name": "first_name", "type": "text_first_name", "constraints": {}},
                {"name": "age", "type": "identity_age", "constraints": {}},
            ],
            "parser_type": "heuristic",
            "model": None,
        }, count=2))

        schema = client.tabular.parse("first name, age")
        assert isinstance(schema, TabularSchema)
        assert len(schema.columns) == 2
        assert schema.columns[0].name == "first_name"
        assert schema.parser_type == "heuristic"


class TestTabularGenerate:
    def test_generate(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            {"job_id": "t1", "status": "processing", "credits_required": 300},
            credits_charged=300,
        ))

        job = client.tabular.generate(
            columns=[{"name": "name", "type": "text_first_name", "constraints": {}}],
            quantity=100,
        )
        assert isinstance(job, TabularJob)
        assert job.job_id == "t1"
        assert job.credits_required == 300

    def test_generate_with_column_objects(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            {"job_id": "t2", "status": "processing", "credits_required": 30},
        ))

        cols = [TabularColumn(name="age", type="identity_age")]
        job = client.tabular.generate(columns=cols, quantity=10)
        assert job.job_id == "t2"

        req_body = json.loads(httpx_mock.get_request().content)
        assert req_body["columns"][0]["name"] == "age"


class TestTabularStatus:
    def test_status(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({
            "job_id": "t1",
            "status": "completed",
            "rows_generated": 100,
            "total_rows": 100,
            "percent": 100.0,
            "estimated_seconds_remaining": None,
            "error": None,
        }))

        status = client.tabular.status("t1")
        assert isinstance(status, TabularStatus)
        assert status.status == "completed"
        assert status.rows_generated == 100
