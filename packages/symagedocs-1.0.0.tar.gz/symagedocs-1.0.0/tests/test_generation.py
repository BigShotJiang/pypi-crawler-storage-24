"""Tests for the generation resource."""

import pytest
from pytest_httpx import HTTPXMock

from symagedocs import Client, CreateJobResult, Job, JobSummary
from tests.conftest import API_KEY, BASE_URL, envelope


@pytest.fixture
def client():
    c = Client(api_key=API_KEY, base_url=BASE_URL)
    yield c
    c.close()


class TestCreateJob:
    def test_create_job(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            {"job_id": "j1", "status": "pending", "credits_required": 200},
            credits_charged=200,
        ))

        result = client.generate.create("irs_w2_2024", quantity=10)
        assert isinstance(result, CreateJobResult)
        assert result.job_id == "j1"
        assert result.credits_required == 200

    def test_create_job_with_options(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            {"job_id": "j2", "status": "pending", "credits_required": 100},
        ))

        result = client.generate.create(
            "irs_w2_2024",
            quantity=5,
            output_formats=["pdf_typed", "json"],
            config={"states": ["CA"]},
            seed=42,
        )
        assert result.job_id == "j2"

        import json
        req_body = json.loads(httpx_mock.get_request().content)
        assert req_body["seed"] == 42
        assert req_body["output_formats"] == ["pdf_typed", "json"]
        assert req_body["config"] == {"states": ["CA"]}


class TestGetJob:
    def test_get_job(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope({
            "job_id": "j1",
            "status": "completed",
            "progress": 1.0,
            "form_id": "irs_w2_2024",
            "form_name": "W-2",
            "quantity": 10,
            "output_formats": ["pdf_typed"],
            "credits_required": 200,
            "credits_charged": 200,
            "seed": None,
            "error": None,
            "created_at": "2026-03-24T10:00:00Z",
            "completed_at": "2026-03-24T10:05:00Z",
        }))

        job = client.generate.get_job("j1")
        assert isinstance(job, Job)
        assert job.status == "completed"
        assert job.progress == 1.0


class TestListJobs:
    def test_list_jobs(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            [{"job_id": "j1", "form_id": "irs_w2_2024", "form_name": "W-2",
              "quantity": 10, "status": "completed", "output_formats": ["pdf_typed"],
              "credits_charged": 200, "created_at": "2026-03-24T10:00:00Z"}],
            count=1, has_more=False,
        ))

        page = client.generate.list_jobs()
        assert len(page) == 1
        assert isinstance(page.data[0], JobSummary)
        assert page.has_more is False

    def test_list_jobs_pagination(self, httpx_mock: HTTPXMock, client: Client):
        httpx_mock.add_response(json=envelope(
            [{"job_id": "j1", "form_id": "x", "form_name": "X",
              "quantity": 1, "status": "completed", "output_formats": [],
              "credits_charged": 0, "created_at": "2026-03-24T10:00:00Z"}],
            count=1, has_more=True, next_cursor="2026-03-24T09:00:00Z",
        ))

        page = client.generate.list_jobs(limit=1)
        assert page.has_more is True
        assert page.next_cursor == "2026-03-24T09:00:00Z"
