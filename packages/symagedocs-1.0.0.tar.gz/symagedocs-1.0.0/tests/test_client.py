"""Tests for client construction and configuration."""

import os

import pytest

from symagedocs import Client, AsyncClient
from symagedocs._config import ClientConfig


def test_client_requires_api_key():
    """Client raises if no API key is provided."""
    with pytest.raises(ValueError, match="API key is required"):
        Client()


def test_client_from_env(monkeypatch):
    """Client reads API key from environment."""
    monkeypatch.setenv("SYMAGEDOCS_API_KEY", "sk_live_envkey")
    client = Client()
    assert client._config.api_key == "sk_live_envkey"
    client.close()


def test_client_explicit_key_overrides_env(monkeypatch):
    """Explicit api_key takes precedence over env var."""
    monkeypatch.setenv("SYMAGEDOCS_API_KEY", "sk_live_envkey")
    client = Client(api_key="sk_live_explicit")
    assert client._config.api_key == "sk_live_explicit"
    client.close()


def test_client_default_base_url():
    """Default base URL is symagedocs.ai."""
    client = Client(api_key="sk_live_test")
    assert client._config.base_url == "https://symagedocs.ai"
    client.close()


def test_client_custom_base_url():
    """Custom base URL is stored correctly."""
    client = Client(api_key="sk_live_test", base_url="http://localhost:8000")
    assert client._config.base_url == "http://localhost:8000"
    client.close()


def test_client_base_url_strips_trailing_slash():
    client = Client(api_key="sk_live_test", base_url="http://localhost:8000/")
    assert client._config.base_url == "http://localhost:8000"
    client.close()


def test_client_has_resources():
    """Client exposes all resource groups."""
    client = Client(api_key="sk_live_test")
    assert hasattr(client, "forms")
    assert hasattr(client, "generate")
    assert hasattr(client, "identities")
    assert hasattr(client, "tabular")
    assert hasattr(client, "account")
    client.close()


def test_client_context_manager():
    """Client works as a context manager."""
    with Client(api_key="sk_live_test") as client:
        assert client._config.api_key == "sk_live_test"


def test_client_repr():
    client = Client(api_key="sk_live_test")
    assert "symagedocs.ai" in repr(client)
    client.close()
