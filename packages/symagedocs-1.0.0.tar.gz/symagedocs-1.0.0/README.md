# SymageDocs Python SDK

Generate synthetic documents, identities, and tabular datasets for testing, ML training, and compliance.

## Installation

```bash
pip install symagedocs
```

For progress bars during long jobs:

```bash
pip install symagedocs[progress]
```

## Quick Start

```python
from symagedocs import Client

client = Client(api_key="sk_live_...")

# List available forms
forms = client.forms.list()
for f in forms:
    print(f"{f.id}: {f.name} ({f.credit_cost} credits)")

# Generate 100 W-2 documents
job = client.generate.create(
    "irs_w2_2024",
    quantity=100,
    output_formats=["pdf_typed", "json"],
)
result = client.generate.wait(job.job_id)  # polls until complete
client.generate.download(job.job_id, "pdf_typed", "./w2_documents.zip")

# Generate tabular data from a description
schema = client.tabular.parse("name, age, SSN, city, state, annual income")
tab_job = client.tabular.generate(columns=schema.columns, quantity=5000)
client.tabular.wait(tab_job.job_id)
client.tabular.download(tab_job.job_id, "csv", "./dataset.csv")

# Check credit balance
balance = client.account.balance()
print(f"Credits used: {balance.credits_used}")
```

## Authentication

Get your API key at [symagedocs.ai/account?tab=api](https://symagedocs.ai/account?tab=api).

```python
# Pass directly
client = Client(api_key="sk_live_...")

# Or set environment variable
# export SYMAGEDOCS_API_KEY=sk_live_...
client = Client()  # reads from env
```

## Async Support

```python
from symagedocs import AsyncClient

async with AsyncClient(api_key="sk_live_...") as client:
    forms = await client.forms.list()
    job = await client.generate.create("irs_w2_2024", quantity=10)
    result = await client.generate.wait(job.job_id)
```

## Configuration

```python
client = Client(
    api_key="sk_live_...",
    base_url="https://symagedocs.ai",  # custom server
    timeout=60.0,                       # request timeout (seconds)
    max_retries=3,                      # retry on 429/5xx
)
```

## Error Handling

```python
from symagedocs import Client, AuthenticationError, RateLimitError, NotFoundError

try:
    forms = client.forms.list()
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Too many requests — SDK retries automatically")
except NotFoundError:
    print("Resource not found")
```

## Documentation

- [API Reference](https://symagedocs.ai/docs/api/)
- [Getting Started](https://symagedocs.ai/docs/api/getting-started.html)
- [Code Samples](https://symagedocs.ai/docs/api/code-samples.html)

## License

MIT
