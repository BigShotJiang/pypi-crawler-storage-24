## Requirements

- Python 3.12+
- uv for package management
- Pydantic for the data parts.

## Installation
```
pip install uv
uv sync
```

## Publish the Python Package to PyPI
- Increment the version of your package in the `__init__.py` file:
```
"""An amazing package!"""

__version__ = 'x.y.z'
```
- Publish
```
uv build && uv publish
```
