from logging import Logger
from typing import cast

from log_with_context import add_logging_context
from nameparser import HumanName
from pydantic import BaseModel, Field
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import Document

logger = Logger("pymultirole")


class NameParserParameters(ProcessorParameters):
    name_labels: list[str] = Field(
        None,
        description="Annotation labels whose text should be parsed as human names. "
        "Only annotations matching one of these labels will be processed.",
        json_schema_extra={"extra": "label"},
    )


class NameParserProcessor(ProcessorBase):
    __doc__ = (
        """Human name parser that extracts structured name components (title, first, middle, last, suffix, nickname) """
        """from annotated text spans using [Nameparser](https://github.com/derek73/python-nameparser).<br/>"""
        """The parsed components are added as properties to each matching annotation."""
    )

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        params: NameParserParameters = cast(NameParserParameters, parameters)
        try:
            for document in documents:
                with add_logging_context(docid=document.identifier):
                    if document.annotations:
                        for a in document.annotations:
                            if a.labelName in params.name_labels:
                                atext = a.text or document.text[a.start : a.end]
                                name = HumanName(atext)
                                props = a.properties or {}
                                props.update(name.as_dict())
                                a.properties = props
        except BaseException as err:
            raise err
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return NameParserParameters
