from pymultirole_plugins.v1.schema import Annotation, Document

from pyprocessors_nameparser.name_parser import NameParserParameters, NameParserProcessor


def test_model():
    model = NameParserProcessor.get_model()
    model_class = model.model_construct().__class__
    assert model_class == NameParserParameters


def test_nameparser():
    processor = NameParserProcessor()
    parameters = NameParserParameters(name_labels=["auteur"])
    doc = Document(
        text="Olivier Terrier",
        annotations=[Annotation(label="Auteur", labelName="auteur", start=0, end=15)],
    )
    docs = processor.process([doc], parameters)
    doc0 = docs[0]
    ot = doc0.annotations[0]
    assert len(ot.properties) > 0


def test_nameparser_no_annotations():
    processor = NameParserProcessor()
    parameters = NameParserParameters(name_labels=["auteur"])
    doc = Document(text="Some text without annotations")
    docs = processor.process([doc], parameters)
    assert len(docs) == 1
    assert docs[0].annotations is None or len(docs[0].annotations) == 0


def test_nameparser_non_matching_label():
    processor = NameParserProcessor()
    parameters = NameParserParameters(name_labels=["auteur"])
    doc = Document(
        text="Olivier Terrier",
        annotations=[Annotation(label="Location", labelName="location", start=0, end=15)],
    )
    docs = processor.process([doc], parameters)
    assert docs[0].annotations[0].properties is None or len(docs[0].annotations[0].properties) == 0


def test_nameparser_multiple_annotations():
    processor = NameParserProcessor()
    parameters = NameParserParameters(name_labels=["auteur"])
    doc = Document(
        text="Olivier Terrier and John Smith",
        annotations=[
            Annotation(label="Auteur", labelName="auteur", start=0, end=15),
            Annotation(label="Auteur", labelName="auteur", start=20, end=30),
        ],
    )
    docs = processor.process([doc], parameters)
    doc0 = docs[0]
    assert len(doc0.annotations) == 2
    assert len(doc0.annotations[0].properties) > 0
    assert len(doc0.annotations[1].properties) > 0


def test_nameparser_parsed_fields():
    processor = NameParserProcessor()
    parameters = NameParserParameters(name_labels=["auteur"])
    doc = Document(
        text="Dr. John A. Smith Jr.",
        annotations=[Annotation(label="Auteur", labelName="auteur", start=0, end=21)],
    )
    docs = processor.process([doc], parameters)
    props = docs[0].annotations[0].properties
    assert "title" in props
    assert "first" in props
    assert "last" in props
