from __future__ import annotations

import bisect
import decimal
import functools
import typing_extensions as t

import u

from ._utils import cached, join_symbols, parse_symbol
from .quantity import Quantity
from .capital_quantities import QUANTITY, DIV, MUL, Q2
from .maths import FloatOrDecimal, multiply, divide
from . import prefixes


__all__ = ["Unit"]


Q_co = t.TypeVar("Q_co", bound=QUANTITY, covariant=True)

UnitId = tuple[type[Quantity], FloatOrDecimal]

units_cache: t.MutableMapping[UnitId, Unit] = {}
units_by_symbol: t.MutableMapping[str, Unit] = {}


@functools.total_ordering
class Unit(t.Generic[Q_co]):
    """
    Represents a unit of measurement for a certain `Quantity`.

    To create your own unit, you must provide a `quantity`, a `symbol`, and a `multiplier`:

    ```
    seconds = Unit(Duration, "s", 1)
    minutes = Unit(Duration, "min", 60)
    ```

    To create units for compound quantities, it's recommended to use the `Unit` constructor like
    this:

    ```
    coulombs = Unit(seconds * amperes, "C")
    ```

    Changed in version 3.0: To maximize precision, the `multiplier` is now always converted to a
    `decimal.Decimal`.

    Added in version 3.0: The `systems` parameter and attribute. This emulates the concept of a
    "unit system", like "imperial" or "metric". Currently, unit systems are only used by
    `Quantity.__str__`, which tries to stay within the same unit system. (So for example,
    `u.meters(1523)` will be printed as "1.5 km" and not as "0.9 mi".)
    """

    quantity: t.Final[type[Quantity[Q_co]]]
    symbol: t.Final[str]
    multiplier: t.Final[decimal.Decimal]
    systems: t.Final[frozenset[str]]

    @t.overload
    def __init__(
        self,
        quantity: type[Quantity[Q_co]],
        symbol: str,
        multiplier: FloatOrDecimal,
        systems: t.Iterable[str] | None = None,
    ):
        pass

    @t.overload
    def __init__(
        self,
        unit: Unit[Q_co],
        /,
        symbol: str,
        systems: t.Iterable[str] = (),
    ):
        pass

    def __init__(  # type: ignore (redeclaration)
        self,
        quantity: type[Quantity[Q_co]] | Unit[Q_co],
        symbol: str,
        multiplier: FloatOrDecimal | None = None,
        systems: t.Iterable[str] = (),
    ):
        if isinstance(quantity, Unit):
            self.quantity = quantity.quantity
            self.multiplier = quantity.multiplier
            self.systems = quantity.systems
        else:
            self.quantity = quantity

            assert isinstance(multiplier, (int, float, decimal.Decimal))
            self.multiplier = decimal.Decimal(multiplier)
            self.systems = frozenset(systems)

        self.symbol = symbol

        unit_id = (self.quantity, self.multiplier)

        # If an `UnregisteredUnit` already existed, update its symbol. This is important because
        # that unit may exist in any number of our `@cached` functions. (For example, `1/s` is
        # created before `hertz`, and is permanently cached by `Unit.__truediv__`.)
        try:
            units_cache[unit_id].symbol = symbol
        except KeyError:
            pass

        units_cache[unit_id] = self

        if isinstance(self, UnregisteredUnit):
            return

        units_by_symbol[symbol] = self

        # Register this unit with the Quantity
        units = t.cast(list[Unit[Q_co]], self.quantity.units)

        bisect.insort(units, self, key=lambda unit: unit.multiplier)

    @staticmethod
    def _from_symbol(symbol: str) -> Unit:
        try:
            return units_by_symbol[symbol]
        except KeyError:
            pass

        # Check if it starts with a prefix
        prefix_length = min(1 + prefixes.max_prefix_length, len(symbol) - 1)

        while prefix_length > 0:
            prefix_symbol = symbol[:prefix_length]

            try:
                prefix = u.Prefix.from_symbol(prefix_symbol)
            except ValueError:
                pass
            else:
                unit_symbol = symbol[prefix_length:]
                try:
                    unit = units_by_symbol[unit_symbol]
                except KeyError:
                    pass
                else:
                    return prefix(unit)

            prefix_length -= 1

        raise ValueError(f"The symbol {symbol!r} doesn't correspond to a known Unit")

    @classmethod
    def parse(cls, symbol: str, /, quantity: type[Quantity[Q2]] = Quantity) -> Unit[Q2]:
        """
        Parses a string containing a unit of measurement. Compound units can be parsed too.

        Examples:

        ```python
        >>> Unit.parse("m")
        Unit(Quantity[DISTANCE], 'm', 1)
        >>> Unit.parse("m²")
        Unit(Quantity[DISTANCE²], 'm²', 1)
        >>> u.Unit.parse("m/s")
        Unit(Quantity[DISTANCE DURATION⁻¹], 'm/s', 1.0)
        ```

        Passing a `quantity` argument will check if the parsed unit is compatible with that
        quantity:

        ```python
        >>> u.Unit.parse("m", quantity=u.Duration)
        ValueError: 'm' is not a unit of Quantity[DURATION]
        ```
        """

        exponents = parse_symbol(symbol)

        unit: Unit

        # Try to start with a positive exponent
        try:
            sym = next(sym for sym, exponent in exponents.items() if exponent > 0)
        except StopIteration:
            unit = u.one
        else:
            unit = Unit._from_symbol(sym) ** exponents.pop(sym)

        for sym, exponent in exponents.items():
            if exponent > 0:
                unit *= Unit._from_symbol(sym) ** exponent
            elif exponent < 0:
                unit /= Unit._from_symbol(sym) ** -exponent

        if quantity is Quantity or unit.is_compatible_with(quantity):
            return unit

        raise ValueError(f"{symbol!r} is not a unit of {quantity}")

    @t.overload
    def is_compatible_with(self, unit: Unit, /) -> t.TypeGuard[Unit[Q_co]]: ...

    @t.overload
    def is_compatible_with(self, quantity: type[Quantity[Q2]], /) -> t.TypeGuard[Unit[Q2]]: ...

    def is_compatible_with(
        self,
        other: t.Union[Unit[Q2], type[Quantity[Q2]]],
        /,
    ) -> t.TypeGuard[Unit[Q2]]:
        if isinstance(other, Unit):
            return self.quantity.exponents == other.quantity.exponents
        else:
            return self.quantity.exponents == other.exponents

    @t.overload
    def __pow__(self, exponent: t.Literal[-1], /) -> Unit[DIV[u.ONE, Q_co]]: ...

    @t.overload
    def __pow__(self, exponent: t.Literal[0], /) -> Unit[u.ONE]: ...

    @t.overload
    def __pow__(self, exponent: t.Literal[1], /) -> t.Self: ...

    @t.overload
    def __pow__(self, exponent: t.Literal[2], /) -> Unit[MUL[Q_co, Q_co]]: ...

    @t.overload
    def __pow__(self, exponent: t.Literal[3], /) -> Unit[MUL[MUL[Q_co, Q_co], Q_co]]: ...

    @t.overload
    def __pow__(self, exponent: int, /) -> Unit: ...

    def __pow__(self, exponent: int) -> Unit:
        if exponent > 0:
            # Avoid use of `u.one` here because this code runs before the module is completely
            # initialized
            result = self

            for _ in range(exponent - 1):
                result *= self
        else:
            result = u.one

            for _ in range(-exponent):
                result /= self

        return result

    @cached
    def __mul__(self, other: Unit[Q2], /) -> Unit[MUL[Q_co, Q2]]:
        return lookup_unit(
            join_quantities(self.quantity, other.quantity, MUL),
            join_symbols(self.symbol, other.symbol, "*"),
            multiply(self.multiplier, other.multiplier, decimal.Decimal),
            combine_systems(self.systems, other.systems),
        )

    @cached
    def __truediv__(self, other: Unit[Q2], /) -> Unit[DIV[Q_co, Q2]]:
        def make_symbol():
            quantity = t.get_args(self.quantity)[0]
            try:
                quantity_name = quantity.__name__
            except AttributeError:
                # Bleh, old `typing` module
                quantity_name = quantity._name

            if quantity_name == "ONE" and "*" not in other.symbol and "/" not in other.symbol:
                if "*" in other.symbol or "/" in other.symbol:
                    symbol = f"({other.symbol})⁻¹"
                else:
                    symbol = other.symbol + "⁻¹"
            elif "*" in other.symbol or "(" in other.symbol:
                symbol = join_symbols(self.symbol, other.symbol, "/(") + ")"
            else:
                symbol = join_symbols(self.symbol, other.symbol, "/")

            return symbol

        return lookup_unit(
            join_quantities(self.quantity, other.quantity, DIV),
            make_symbol,
            divide(self.multiplier, other.multiplier, decimal.Decimal),
            combine_systems(self.systems, other.systems),
        )

    def __rmul__(self, value: FloatOrDecimal, /) -> Quantity[Q_co]:
        return Quantity(value, self)

    def __rtruediv__(self, value: t.Literal[1], /) -> Unit[DIV[u.ONE, Q_co]]:
        if value != 1:
            raise ValueError("Division by a number other than 1 is not supported")

        return u.one / self

    def __call__(self, value: FloatOrDecimal | Quantity[Q_co], /) -> Quantity[Q_co]:
        if isinstance(value, Quantity):
            return Quantity(value.to_number(self), self)
        else:
            return Quantity(value, self)

    def __hash__(self) -> int:
        return hash((self.quantity, self.multiplier))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, __class__):
            return NotImplemented

        return self.quantity == other.quantity and self.multiplier == other.multiplier

    def __le__(self, other: object) -> bool:
        if not isinstance(other, __class__):
            return NotImplemented

        if self.quantity != other.quantity:
            return False

        return self.multiplier < other.multiplier

    def __repr__(self) -> str:
        return f"Unit({self.quantity!r}, {self.symbol!r}, {self.multiplier!r})"

    def __str__(self) -> str:
        return self.symbol


class UnregisteredUnit(Unit):
    """
    Instances of this class won't have their `symbol` registered in the global lookup table.

    Do not instantiate this class directly. Instead, use the `lookup_unit` function. This will
    "normalize" the unit, such that `1/second` becomes `hertz`, for example.
    """


def lookup_unit(
    quantity: type[Quantity],
    symbol: str | t.Callable[[], str],
    multiplier: FloatOrDecimal,
    systems: t.Iterable[str] | None = None,
) -> Unit:
    unit_id: UnitId = (quantity, multiplier)

    try:
        return units_cache[unit_id]
    except KeyError:
        pass

    if not isinstance(symbol, str):
        symbol = symbol()

    return UnregisteredUnit(quantity, symbol, multiplier, systems)


def combine_systems(s1: t.Iterable[str], s2: t.Iterable[str]) -> frozenset[str]:
    s1 = frozenset(s1)
    s2 = frozenset(s2)

    if not s1:
        return s2
    if not s2:
        return s1

    intersection = s1 & s2
    if intersection:
        return intersection

    return s1 | s2


def join_quantities(q1: type[Quantity], q2: type[Quantity], joiner) -> type[Quantity]:
    [a] = t.get_args(q1)
    [b] = t.get_args(q2)

    return Quantity[joiner[a, b]]
