from setuptools import setup, find_packages

setup(
    name="roboinfra-sdk",
    version = "1.0.2",
    description = "Python SDK for RoboInfra URDF validation, Mesh Analyzer and 3D Model Converter robotics APIs",
    author="Ravindar J",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    keywords="robotics urdf api sdk mesh",
    classifiers = [
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Topic :: Scientific/Engineering"
    ]
)