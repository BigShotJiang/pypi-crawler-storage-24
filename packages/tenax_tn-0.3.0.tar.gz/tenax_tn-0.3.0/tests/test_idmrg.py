"""Tests for the iDMRG algorithm."""

import math

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from tenax.algorithms.idmrg import (
    _orthogonalize_unit_cell_dense,
    build_bulk_mpo_heisenberg,
    build_bulk_mpo_heisenberg_cylinder,
    build_bulk_mpo_heisenberg_symmetric,
    idmrg,
    iDMRGConfig,
    iDMRGResult,
)
from tenax.core.tensor import SymmetricTensor

# ---------------------------------------------------------------------------
# TestiDMRGConfig
# ---------------------------------------------------------------------------


class TestiDMRGConfig:
    def test_default_values(self):
        cfg = iDMRGConfig()
        assert cfg.max_bond_dim == 100
        assert cfg.max_iterations == 200
        assert cfg.convergence_tol == 1e-8
        assert cfg.lanczos_max_iter == 50
        assert cfg.lanczos_tol == 1e-12
        assert cfg.svd_trunc_err is None
        assert cfg.verbose is False

    def test_custom_values(self):
        cfg = iDMRGConfig(
            max_bond_dim=64,
            max_iterations=50,
            convergence_tol=1e-6,
            lanczos_max_iter=30,
            lanczos_tol=1e-10,
            svd_trunc_err=1e-8,
            verbose=True,
        )
        assert cfg.max_bond_dim == 64
        assert cfg.max_iterations == 50
        assert cfg.convergence_tol == 1e-6
        assert cfg.verbose is True


# ---------------------------------------------------------------------------
# TestBuildBulkMPO
# ---------------------------------------------------------------------------


class TestBuildBulkMPO:
    def test_shape(self):
        W = build_bulk_mpo_heisenberg()
        dense = W.todense()
        assert dense.shape == (5, 2, 2, 5)

    def test_labels(self):
        W = build_bulk_mpo_heisenberg()
        labels = W.labels()
        assert "w_l" in labels
        assert "w_r" in labels
        assert "mpo_top" in labels
        assert "mpo_bot" in labels

    def test_dtype_default(self):
        W = build_bulk_mpo_heisenberg()
        # Default is float64, but JAX truncates to float32 without x64 mode
        expected = jnp.float64 if jax.config.x64_enabled else jnp.float32
        assert W.todense().dtype == expected

    def test_dtype_explicit_float32(self):
        W = build_bulk_mpo_heisenberg(dtype=jnp.float32)
        assert W.todense().dtype == jnp.float32

    def test_produces_same_hamiltonian_as_build_mpo_heisenberg(self):
        """The bulk MPO should represent the same physical Hamiltonian.

        Rather than comparing W-matrix elements (which depend on internal
        ordering), we verify that an L=3 chain built from iDMRG bulk MPO
        produces the same ground state energy as build_mpo_heisenberg.
        """
        from tenax.algorithms.dmrg import (
            DMRGConfig,
            build_mpo_heisenberg,
            build_random_mps,
            dmrg,
        )

        Jz, Jxy, hz = 1.0, 1.0, 0.0
        L = 4

        mpo_ref = build_mpo_heisenberg(L=L, Jz=Jz, Jxy=Jxy, hz=hz)
        # Densify MPO to match DenseTensor MPS
        from tenax.core.tensor import DenseTensor
        from tenax.network.network import TensorNetwork as TN

        mpo_dense = TN()
        for nid in mpo_ref.node_ids():
            t = mpo_ref.get_tensor(nid)
            if not isinstance(t, DenseTensor):
                mpo_dense.add_node(nid, DenseTensor(t.todense(), t.indices))
            else:
                mpo_dense.add_node(nid, t)
        mps = build_random_mps(L, bond_dim=4, seed=0)
        config = DMRGConfig(max_bond_dim=8, num_sweeps=8, lanczos_max_iter=20)
        result = dmrg(mpo_dense, mps, config)

        # Energy should be close to exact L=4 Heisenberg ground state
        assert result.energy < -1.5, f"Energy {result.energy} too high"

    def test_invalid_d_raises(self):
        with pytest.raises(ValueError, match="only supports d=2"):
            build_bulk_mpo_heisenberg(d=3)


# ---------------------------------------------------------------------------
# TestiDMRGRun
# ---------------------------------------------------------------------------


class TestiDMRGRun:
    def test_runs_without_error(self):
        W = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=5, lanczos_max_iter=10)
        result = idmrg(W, cfg)
        assert isinstance(result, iDMRGResult)

    def test_energy_is_finite(self):
        W = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=10, lanczos_max_iter=10)
        result = idmrg(W, cfg)
        assert np.isfinite(result.energy_per_site), (
            f"Energy per site is not finite: {result.energy_per_site}"
        )

    def test_energy_per_site_negative(self):
        """The Heisenberg ground state energy per site should be negative."""
        W = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=16, max_iterations=30, lanczos_max_iter=20)
        result = idmrg(W, cfg)
        assert result.energy_per_site < 0, (
            f"Energy per site should be negative, got {result.energy_per_site}"
        )

    def test_energy_converges_toward_bethe_ansatz(self):
        """With moderate chi, e_0 should approach 1/4 - ln(2) ~ -0.4431."""
        e_exact = 0.25 - math.log(2)  # ~ -0.4431
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)
        cfg = iDMRGConfig(
            max_bond_dim=32,
            max_iterations=100,
            convergence_tol=1e-8,
            lanczos_max_iter=30,
            lanczos_tol=1e-14,
        )
        result = idmrg(W, cfg, dtype=jnp.float64)
        assert abs(result.energy_per_site - e_exact) < 0.01, (
            f"e/site = {result.energy_per_site:.6f} far from Bethe ansatz {e_exact:.6f}"
        )

    def test_energy_improves_with_bond_dim(self):
        """Larger bond dimension should give a lower (better) energy."""
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)

        cfg_small = iDMRGConfig(
            max_bond_dim=8,
            max_iterations=80,
            lanczos_max_iter=20,
        )
        cfg_large = iDMRGConfig(
            max_bond_dim=32,
            max_iterations=120,
            lanczos_max_iter=20,
        )
        res_small = idmrg(W, cfg_small, dtype=jnp.float64)
        res_large = idmrg(W, cfg_large, dtype=jnp.float64)

        assert res_large.energy_per_site <= res_small.energy_per_site + 1e-3, (
            f"chi=32 energy {res_large.energy_per_site:.6f} should be <= "
            f"chi=8 energy {res_small.energy_per_site:.6f}"
        )

    def test_singular_values_returned(self):
        W = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=10, lanczos_max_iter=10)
        result = idmrg(W, cfg)
        assert result.mps.singular_values[0] is not None
        assert len(result.mps.singular_values[0]) > 0
        assert jnp.all(result.mps.singular_values[0] >= 0)

    def test_convergence_flag(self):
        """With enough iterations and a generous tolerance, convergence should be True."""
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)
        cfg = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=200,
            convergence_tol=1e-4,
            lanczos_max_iter=30,
        )
        result = idmrg(W, cfg, dtype=jnp.float64)
        assert result.converged, (
            f"Expected convergence with tol=1e-4, "
            f"last energies: {result.energies_per_step[-5:]}"
        )

    def test_mps_tensors_shapes(self):
        """The returned MPS tensors should have valid shapes."""
        W = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=10, lanczos_max_iter=10)
        result = idmrg(W, cfg)
        A_L, A_R = result.mps.tensors
        # A_L: (chi_l, d, chi_c)  — 3D
        assert A_L.todense().ndim == 3
        # A_R: (chi_c, d, chi_r)  — 3D
        assert A_R.todense().ndim == 3
        # Centre bond should match
        assert A_L.todense().shape[2] == A_R.todense().shape[0]

    def test_energies_per_step_length(self):
        W = build_bulk_mpo_heisenberg()
        n_iter = 7
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=n_iter, lanczos_max_iter=10)
        result = idmrg(W, cfg)
        assert len(result.energies_per_step) <= n_iter
        assert len(result.energies_per_step) > 0


# ---------------------------------------------------------------------------
# TestBuildBulkMPOCylinder
# ---------------------------------------------------------------------------


class TestBuildBulkMPOCylinder:
    def test_shape_ly2(self):
        W = build_bulk_mpo_heisenberg_cylinder(Ly=2)
        dense = W.todense()
        # D_w = 3*2+2 = 8, d = 2^2 = 4
        assert dense.shape == (8, 4, 4, 8)

    def test_shape_ly4(self):
        W = build_bulk_mpo_heisenberg_cylinder(Ly=4)
        dense = W.todense()
        # D_w = 3*4+2 = 14, d = 2^4 = 16
        assert dense.shape == (14, 16, 16, 14)

    def test_labels(self):
        W = build_bulk_mpo_heisenberg_cylinder(Ly=2)
        labels = W.labels()
        assert "w_l" in labels
        assert "w_r" in labels
        assert "mpo_top" in labels
        assert "mpo_bot" in labels

    def test_invalid_ly_zero_raises(self):
        with pytest.raises(ValueError, match="Ly must be >= 1"):
            build_bulk_mpo_heisenberg_cylinder(Ly=0)

    def test_odd_ly_raises(self):
        """Odd Ly is incompatible with AFM order on the square lattice."""
        with pytest.raises(ValueError, match="Ly must be even"):
            build_bulk_mpo_heisenberg_cylinder(Ly=3)

    def test_h_ring_hermitian_ly2(self):
        """The within-ring Hamiltonian block should be Hermitian."""
        W = build_bulk_mpo_heisenberg_cylinder(Ly=2)
        dense = W.todense()
        D_w = dense.shape[0]
        # h_ring = W[D_w-1, :, :, 0]  (vacuum → done)
        h_ring = dense[D_w - 1, :, :, 0]
        np.testing.assert_allclose(
            np.array(h_ring),
            np.array(h_ring.T),
            atol=1e-12,
            err_msg="h_ring should be Hermitian (real symmetric)",
        )

    def test_h_ring_hermitian_ly4(self):
        """The within-ring Hamiltonian block should be Hermitian for Ly=4."""
        W = build_bulk_mpo_heisenberg_cylinder(Ly=4)
        dense = W.todense()
        D_w = dense.shape[0]
        h_ring = dense[D_w - 1, :, :, 0]
        np.testing.assert_allclose(
            np.array(h_ring),
            np.array(h_ring.T),
            atol=1e-12,
            err_msg="h_ring should be Hermitian (real symmetric)",
        )


class TestiDMRGCylinderRun:
    def test_ly2_runs_and_converges(self):
        """iDMRG with Ly=2 cylinder should run and give reasonable energy."""
        W = build_bulk_mpo_heisenberg_cylinder(Ly=2)
        cfg = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=50,
            convergence_tol=1e-4,
            lanczos_max_iter=30,
            lanczos_tol=1e-12,
        )
        result = idmrg(W, cfg, d=4)
        e_per_spin = result.energy_per_site / 2
        assert np.isfinite(e_per_spin)
        # The 2D Heisenberg energy per spin should be negative and
        # reasonable for a Ly=2 cylinder
        assert -1.0 < e_per_spin < -0.3, (
            f"Ly=2 e/spin = {e_per_spin:.6f} out of expected range"
        )


# ---------------------------------------------------------------------------
# Symmetric iDMRG
# ---------------------------------------------------------------------------


class TestBuildBulkMPOSymmetric:
    def test_returns_symmetric_tensor(self):
        W = build_bulk_mpo_heisenberg_symmetric()
        assert isinstance(W, SymmetricTensor)

    def test_shape_matches_dense(self):
        W_dense = build_bulk_mpo_heisenberg()
        W_sym = build_bulk_mpo_heisenberg_symmetric()
        # Same number of legs and same leg dimensions
        for i in range(4):
            assert len(W_sym.indices[i].charges) == W_dense.todense().shape[i]

    def test_data_matches_dense(self):
        """Symmetric MPO should have the same data as the dense version."""
        W_dense = build_bulk_mpo_heisenberg()
        W_sym = build_bulk_mpo_heisenberg_symmetric()
        np.testing.assert_allclose(W_sym.todense(), W_dense.todense(), atol=1e-14)

    def test_has_nontrivial_blocks(self):
        """Symmetric MPO should have multiple non-trivial charge sectors."""
        W = build_bulk_mpo_heisenberg_symmetric()
        assert W.n_blocks >= 8

    def test_custom_couplings(self):
        W = build_bulk_mpo_heisenberg_symmetric(Jz=2.0, Jxy=0.5, hz=0.1)
        assert isinstance(W, SymmetricTensor)
        W_dense = build_bulk_mpo_heisenberg(Jz=2.0, Jxy=0.5, hz=0.1)
        np.testing.assert_allclose(W.todense(), W_dense.todense(), atol=1e-14)


class TestiDMRGSymmetric:
    def test_symmetric_idmrg_runs(self):
        """Symmetric iDMRG should run without error."""
        W = build_bulk_mpo_heisenberg_symmetric()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=10)
        result = idmrg(W, cfg)
        assert isinstance(result, iDMRGResult)
        assert np.isfinite(result.energy_per_site)

    @pytest.mark.slow
    def test_symmetric_idmrg_energy_accuracy(self):
        """Symmetric iDMRG at chi=16 should match exact within 0.5%."""
        W = build_bulk_mpo_heisenberg_symmetric()
        cfg = iDMRGConfig(max_bond_dim=16, max_iterations=50)
        result = idmrg(W, cfg)
        exact_e = -0.4431471805
        rel_err = abs(result.energy_per_site - exact_e) / abs(exact_e)
        assert rel_err < 0.005, (
            f"Symmetric iDMRG e/site={result.energy_per_site:.8f} "
            f"vs exact {exact_e:.8f} (rel err={rel_err:.4f})"
        )

    def test_symmetric_matches_dense_energy(self):
        """Symmetric and dense iDMRG should give similar energies."""
        W_sym = build_bulk_mpo_heisenberg_symmetric()
        W_dense = build_bulk_mpo_heisenberg()
        cfg = iDMRGConfig(max_bond_dim=16, max_iterations=30)
        result_sym = idmrg(W_sym, cfg)
        result_dense = idmrg(W_dense, cfg)
        assert abs(result_sym.energy_per_site - result_dense.energy_per_site) < 0.002, (
            f"sym={result_sym.energy_per_site:.8f} vs "
            f"dense={result_dense.energy_per_site:.8f}"
        )

    def test_output_tensors_are_symmetric(self):
        """MPS tensors from symmetric iDMRG should be SymmetricTensors."""
        W = build_bulk_mpo_heisenberg_symmetric()
        cfg = iDMRGConfig(max_bond_dim=8, max_iterations=10)
        result = idmrg(W, cfg)
        for t in result.mps.tensors:
            assert isinstance(t, SymmetricTensor)


# ---------------------------------------------------------------------------
# Transfer matrix orthogonalization
# ---------------------------------------------------------------------------


class TestOrthogonalization:
    def test_orthogonalization_idempotent(self):
        """Running orthogonalization twice should give the same result."""
        # Create a random MPS-like state to orthogonalize
        rng = np.random.RandomState(42)
        chi, d = 8, 2
        # Start with a random (non-canonical) A_L and A_R
        A_L = rng.randn(chi, d, chi)
        A_R = rng.randn(chi, d, chi)
        s_vals = np.sort(np.abs(rng.randn(chi)))[::-1]
        s_vals = s_vals / np.linalg.norm(s_vals)

        # First orthogonalization
        A_L1, A_R1, s1 = _orthogonalize_unit_cell_dense(A_L, A_R, s_vals)
        # Second orthogonalization
        A_L2, A_R2, s2 = _orthogonalize_unit_cell_dense(A_L1, A_R1, s1)

        # After two passes, singular values should be nearly identical
        np.testing.assert_allclose(
            s1,
            s2,
            atol=1e-8,
            err_msg="Singular values changed after second orthogonalization",
        )

        # Check that T_L(I) = I after orthogonalization
        TL_I = np.zeros((chi, chi))
        for s in range(d):
            As = A_L1[:, s, :]
            TL_I += As.conj().T @ As
        np.testing.assert_allclose(
            TL_I,
            np.eye(chi),
            atol=1e-6,
            err_msg="T_L(I) != I after first orthogonalization",
        )

        # Check that T_R(I) = I after orthogonalization
        TR_I = np.zeros((chi, chi))
        for s in range(d):
            Bs = A_R1[:, s, :]
            TR_I += Bs @ Bs.conj().T
        np.testing.assert_allclose(
            TR_I,
            np.eye(chi),
            atol=1e-6,
            err_msg="T_R(I) != I after first orthogonalization",
        )

    def test_energy_unchanged_after_orthogonalization(self):
        """Orthogonalization shouldn't change the energy."""
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)

        # Run without orthogonalization
        cfg_no = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=40,
            lanczos_max_iter=20,
            orthogonalize_interval=0,
            convergence_tol=1e-8,
        )
        result_no = idmrg(W, cfg_no, dtype=jnp.float64)

        # Run with orthogonalization (applied at end only)
        cfg_yes = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=40,
            lanczos_max_iter=20,
            orthogonalize_interval=10,
            convergence_tol=1e-8,
        )
        result_yes = idmrg(W, cfg_yes, dtype=jnp.float64)

        # Energies should be the same since orthogonalization only
        # changes the gauge, not the physical state
        assert abs(result_no.energy_per_site - result_yes.energy_per_site) < 0.01, (
            f"Energy changed: without={result_no.energy_per_site:.8f}, "
            f"with={result_yes.energy_per_site:.8f}"
        )

    def test_left_canonical_after_orthogonalization(self):
        """After orthogonalization, A_L should satisfy T_L(I) = I."""
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)
        cfg = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=30,
            lanczos_max_iter=20,
            orthogonalize_interval=10,
        )
        result = idmrg(W, cfg, dtype=jnp.float64)
        A_L = np.array(result.mps.tensors[0].todense())
        chi = A_L.shape[2]
        d = A_L.shape[1]
        TL_I = np.zeros((chi, chi))
        for s in range(d):
            As = A_L[:, s, :]
            TL_I += As.conj().T @ As
        np.testing.assert_allclose(
            TL_I, np.eye(chi), atol=1e-6, err_msg="T_L(I) != I after orthogonalization"
        )


# ---------------------------------------------------------------------------
# 1-site iDMRG with DMRG3S
# ---------------------------------------------------------------------------


class TestiDMRG1Site:
    def test_1site_idmrg_runs(self):
        """1-site iDMRG with DMRG3S should run and give reasonable energy."""
        W = build_bulk_mpo_heisenberg()
        config = iDMRGConfig(
            max_bond_dim=16, max_iterations=50, two_site=False, verbose=False
        )
        result = idmrg(W, config, d=2)
        assert isinstance(result, iDMRGResult)
        assert np.isfinite(result.energy_per_site)
        assert result.energy_per_site < -0.40

    def test_1site_matches_2site_energy(self):
        """1-site with DMRG3S should give comparable energy to 2-site."""
        W = build_bulk_mpo_heisenberg(dtype=jnp.float64)

        cfg_2site = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=80,
            convergence_tol=1e-8,
            lanczos_max_iter=30,
            two_site=True,
        )
        cfg_1site = iDMRGConfig(
            max_bond_dim=16,
            max_iterations=80,
            convergence_tol=1e-8,
            lanczos_max_iter=30,
            two_site=False,
            mixing_factor=0.05,
        )
        res_2site = idmrg(W, cfg_2site, dtype=jnp.float64)
        res_1site = idmrg(W, cfg_1site, dtype=jnp.float64)

        # 1-site should be within 5% of 2-site energy
        assert abs(res_1site.energy_per_site - res_2site.energy_per_site) < 0.03, (
            f"1-site={res_1site.energy_per_site:.8f} vs "
            f"2-site={res_2site.energy_per_site:.8f}"
        )

    def test_1site_mps_shapes(self):
        """The returned MPS tensors should have valid shapes."""
        W = build_bulk_mpo_heisenberg()
        config = iDMRGConfig(
            max_bond_dim=8, max_iterations=20, two_site=False, verbose=False
        )
        result = idmrg(W, config)
        A_L, A_R = result.mps.tensors
        assert A_L.todense().ndim == 3
        assert A_R.todense().ndim == 3
        # Centre bond should match
        assert A_L.todense().shape[2] == A_R.todense().shape[0]

    def test_1site_config_mixing_factor(self):
        """iDMRGConfig should accept mixing_factor."""
        cfg = iDMRGConfig(mixing_factor=0.1)
        assert cfg.mixing_factor == 0.1

        # Default
        cfg2 = iDMRGConfig()
        assert cfg2.mixing_factor == 0.05
