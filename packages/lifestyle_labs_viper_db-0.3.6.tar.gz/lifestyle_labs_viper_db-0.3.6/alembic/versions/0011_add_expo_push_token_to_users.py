"""add_expo_push_token_to_users

Revision ID: 0011
Revises: 0010
Create Date: 2026-03-26

Adds expo_push_token column to users table for push notification delivery.
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0011"
down_revision: Union[str, None] = "0010"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("expo_push_token", sa.Text, nullable=True),
    )


def downgrade() -> None:
    op.drop_column("users", "expo_push_token")
