"""fix_handle_new_user_apple_social

Revision ID: 0007
Revises: 0006
Create Date: 2026-03-09

Rewrites handle_new_user() to:
- Remove the aggressive phone-based identity migration that was leaking
  conversations between separate OTP and email/password accounts.
- Preserve existing non-empty first_name/last_name/email on the ON CONFLICT
  path so Apple social sign-in (which has no name in raw_user_meta_data)
  doesn't overwrite previously-saved profile data with empty strings.
- Rebind the trigger to fire on INSERT (not UPDATE) so the public.users row
  is created immediately when the auth.users row is inserted.
"""

from typing import Sequence, Union

from alembic import op

revision: str = "0007"
down_revision: Union[str, None] = "0006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        CREATE OR REPLACE FUNCTION public.handle_new_user()
        RETURNS TRIGGER AS $$
        BEGIN
            INSERT INTO public.users (id, email, phone, first_name, last_name)
            VALUES (
                NEW.id,
                NEW.email,
                COALESCE(NEW.phone, NEW.raw_user_meta_data->>'phone', ''),
                COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
                COALESCE(NEW.raw_user_meta_data->>'last_name', '')
            )
            ON CONFLICT (id) DO UPDATE SET
                email = COALESCE(NULLIF(EXCLUDED.email, ''), users.email),
                phone = COALESCE(NULLIF(EXCLUDED.phone, ''), users.phone),
                first_name = COALESCE(NULLIF(EXCLUDED.first_name, ''), users.first_name),
                last_name = COALESCE(NULLIF(EXCLUDED.last_name, ''), users.last_name);
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql SECURITY DEFINER;

        DROP TRIGGER IF EXISTS on_auth_user_verified ON auth.users;

        CREATE TRIGGER on_auth_user_created
        AFTER INSERT ON auth.users
        FOR EACH ROW
        EXECUTE FUNCTION public.handle_new_user();
    """)


def downgrade() -> None:
    op.execute("""
        CREATE OR REPLACE FUNCTION public.handle_new_user()
        RETURNS TRIGGER AS $$
        DECLARE
            existing_user RECORD;
        BEGIN
            IF NEW.phone IS NOT NULL AND NEW.phone <> '' THEN
                SELECT * INTO existing_user
                FROM public.users
                WHERE phone = NEW.phone
                  AND id <> NEW.id
                LIMIT 1;

                IF FOUND THEN
                    UPDATE public.conversations SET user_id = NEW.id WHERE user_id = existing_user.id;
                    UPDATE public.bookings SET user_id = NEW.id WHERE user_id = existing_user.id;
                    DELETE FROM public.users WHERE id = existing_user.id;
                    INSERT INTO public.users (id, email, phone, first_name, last_name, preferences, created_at)
                    VALUES (
                        NEW.id,
                        COALESCE(NULLIF(NEW.email, ''), existing_user.email),
                        NEW.phone,
                        existing_user.first_name,
                        existing_user.last_name,
                        existing_user.preferences,
                        existing_user.created_at
                    );
                    RETURN NEW;
                END IF;
            END IF;

            INSERT INTO public.users (id, email, phone, first_name, last_name)
            VALUES (
                NEW.id,
                NEW.email,
                COALESCE(NEW.phone, NEW.raw_user_meta_data->>'phone', ''),
                COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
                COALESCE(NEW.raw_user_meta_data->>'last_name', '')
            )
            ON CONFLICT (id) DO UPDATE SET
                phone = COALESCE(NULLIF(EXCLUDED.phone, ''), users.phone),
                first_name = COALESCE(NULLIF(EXCLUDED.first_name, ''), users.first_name),
                last_name = COALESCE(NULLIF(EXCLUDED.last_name, ''), users.last_name);
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql SECURITY DEFINER;

        DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

        CREATE TRIGGER on_auth_user_verified
        AFTER UPDATE ON auth.users
        FOR EACH ROW
        EXECUTE FUNCTION public.handle_new_user();
    """)
