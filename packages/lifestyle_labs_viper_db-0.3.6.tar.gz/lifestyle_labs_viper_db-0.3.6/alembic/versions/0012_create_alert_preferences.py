"""create_alert_preferences

Revision ID: 0012
Revises: 0011
Create Date: 2026-03-26

Creates the alert_preferences table for user availability alerts.
Each row is a one-and-done alert with matched_slot_id tracking.
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0012"
down_revision: Union[str, None] = "0011"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "alert_preferences",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column(
            "user_id",
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("party_sizes", sa.ARRAY(sa.SmallInteger), nullable=False),
        sa.Column("dates", sa.ARRAY(sa.Date), nullable=False),
        sa.Column("time_start", sa.Time, nullable=False),
        sa.Column("time_end", sa.Time, nullable=False),
        sa.Column(
            "is_active",
            sa.Boolean,
            nullable=False,
            server_default=sa.text("true"),
        ),
        sa.Column(
            "matched_slot_id",
            sa.BigInteger,
            sa.ForeignKey("availability_slots.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "notified_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
    )
    op.create_index(
        "idx_alert_pref_user_active",
        "alert_preferences",
        ["user_id", "is_active"],
    )
    op.create_index(
        "idx_alert_pref_active_experience",
        "alert_preferences",
        ["experience_id", "is_active"],
        postgresql_where=sa.text("is_active = true"),
    )


def downgrade() -> None:
    op.drop_index("idx_alert_pref_active_experience", "alert_preferences")
    op.drop_index("idx_alert_pref_user_active", "alert_preferences")
    op.drop_table("alert_preferences")
