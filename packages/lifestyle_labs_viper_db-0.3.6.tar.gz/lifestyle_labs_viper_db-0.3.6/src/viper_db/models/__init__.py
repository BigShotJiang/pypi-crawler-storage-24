"""
SQLModel table definitions — the single source of truth for the database schema.

Import `Base` (or any table class) to get access to SQLModel.metadata,
which Alembic uses for autogenerate.
"""

from .alert_preference import AlertPreference
from .availability_slot import AvailabilitySlot
from .booking import Booking
from .conversation import Conversation
from .enums import BookingStatus, MessageRole
from .experience import Experience
from .experience_type import ExperienceType
from .feedback import Feedback
from .message import Message
from .neighborhood import Neighborhood
from .nightlife import Nightlife
from .restaurant import Restaurant
from .user import User
from .wellness import Wellness

__all__ = [
    "AlertPreference",
    "BookingStatus",
    "MessageRole",
    "ExperienceType",
    "Neighborhood",
    "User",
    "Experience",
    "Feedback",
    "Restaurant",
    "Nightlife",
    "Wellness",
    "Booking",
    "Conversation",
    "Message",
    "AvailabilitySlot",
]
