# Changelog v2

## 2026-03-24 — Neighborhood alias normalization for filter UI

### Problem

The `neighborhoods` table contains duplicate and overlapping entries from Resy ingestion:
- "Nolita" (id 1) and "NoLita" (id 38) — casing variant
- "SoHo / Greenwich Village" (id 33) — overlaps with "SoHo" (id 4) and "Greenwich Village" (id 7)
- "Midtown" (id 3), "Midtown East" (id 20), "Midtown West" (id 19), "Central Park South" (id 21), "Columbus Circle" (id 22), "Hell's Kitchen" (id 36), "Koreatown" (id 32) — all Midtown sub-areas

This resulted in 38 neighborhood options in the filter UI, many of which were redundant or confusingly similar.

### Changes

**dao/restaurants.py**

- Added `NEIGHBORHOOD_ALIASES` mapping that maps variant neighborhood names to canonical names (e.g., "NoLita" → "Nolita", "Midtown East" → "Midtown", "SoHo / Greenwich Village" → "SoHo").
- Added `_normalize_neighborhood(name)` helper that looks up a name in the alias map.
- Added `_expand_neighborhood_ids(selected_ids, all_neighborhoods)` helper that, given selected IDs, finds all other IDs sharing the same canonical name. Used when filtering so that selecting "Midtown" matches restaurants in all Midtown sub-neighborhoods.
- Updated `get_filter_options()` to group neighborhoods by canonical name, returning `{"ids": [...], "name": "..."}` instead of `{"id": ..., "name": "..."}`.
- Updated `get_filtered()` to expand selected neighborhood IDs via the alias map before querying.

**viper-api: api_schemas/restaurant.py**

- Changed `NeighborhoodOption.id: int` to `NeighborhoodOption.ids: list[int]` to support grouped neighborhoods.

**viper-api: routes/restaurants.py**

- Updated `get_filter_options` route to construct `NeighborhoodOption` with `ids` field.

**viper-mobile: types.gen.ts**

- Updated `NeighborhoodOption` type from `id: number` to `ids: Array<number>`.

**viper-mobile: FilterOverlay.tsx**

- Updated `toggleNeighborhood` to toggle all IDs in a group atomically.
- Updated chip rendering to check selection against all IDs in the group and key by name.

### Result

Neighborhoods condensed from 38 to 30 options. Key groupings:
- "Nolita" — ids [1, 38]
- "SoHo" — ids [4, 33]
- "Midtown" — ids [21, 22, 36, 32, 3, 20, 19]
