# Changelog v1

## 2026-03-24 — Restaurant filtering DAO methods and cuisine normalization

### Problem

The home screen had no way to filter the restaurant gallery by neighborhood or cuisine. The `RestaurantsDAO` only supported paginated listing (`get_paginated`) with no filter parameters.

Additionally, the `cuisine` column on the `restaurants` table contains raw Resy-ingested values with significant duplication and over-specificity (e.g., "Korean BBQ", "Korean Steakhouse", "Korean-American" as separate entries), resulting in 130+ distinct values that would be unusable in a filter UI.

### Changes

**dao/restaurants.py**

- Added `CUISINE_ALIASES` mapping (dict) that maps ~100 raw cuisine strings to 32 canonical categories (e.g., all Korean variants map to "Korean", all French variants map to "French").
- Added `_normalize_cuisine(raw)` helper that looks up a raw value in the alias map, falling back to the raw value if no alias exists.
- Added `_expand_cuisines(canonical_names)` helper that reverses the mapping — given canonical names, returns all raw values that map to them. Used when filtering so that selecting "Korean" matches restaurants tagged with "Korean BBQ", "Korean Steakhouse", etc.
- Added `get_filter_options()` method: queries the `neighborhoods` table directly for all neighborhoods, and uses `SELECT DISTINCT unnest(r.cuisine)` on active restaurants for cuisines, then normalizes and deduplicates via the alias map.
- Added `get_filtered(neighborhood_ids, cuisines)` method: returns all matching restaurants (no pagination) using `Experience.neighborhood_id.in_()` for neighborhoods and Postgres `&&` (array overlap) for cuisines, with cuisine expansion applied before the query.

### Nuances

- The `Restaurant.cuisine` column is defined with `sa_column=sa.Column(sa.ARRAY(sa.Text))`, which means SQLAlchemy/SQLModel's ORM attribute doesn't expose the `.overlap()` comparator. The workaround is `sa.literal_column("restaurants.cuisine").op("&&")(sa.cast(..., sa.ARRAY(sa.Text)))`.
- The curly right quote (U+2019) appears in some Resy-sourced cuisine strings (e.g., "chef's"). Alias keys must use the exact Unicode character to match.
- Unknown raw cuisines not in the alias map pass through as-is, so the system degrades gracefully when new values appear.
