"""PX4 Configuration package."""

__all__ = ["api"]


def __getattr__(name):
    if name == "__version__":
        from importlib.metadata import version, PackageNotFoundError

        try:
            return version("px4-configuration")
        except PackageNotFoundError:
            return "0.0.0"
    raise AttributeError(name)

