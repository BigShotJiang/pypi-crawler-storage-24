"""Configuration settings for the PX4 Configuration API."""

import os


def _get_package_version() -> str:
    """Read version from package metadata (pyproject.toml). Single source of truth."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("px4-configuration")
    except Exception:
        return "0.0.0"


class Settings:
    """Application settings with defaults."""

    # Default serial connection settings
    default_port: str = os.getenv("PX4_DEFAULT_PORT", "/dev/pixhawk")
    default_baudrate: int = int(os.getenv("PX4_DEFAULT_BAUDRATE", "2000000"))

    # API settings (version from pyproject.toml via package metadata)
    api_title: str = "PX4 Configuration API"
    api_version: str = _get_package_version()
    api_description: str = (
        "REST API for configuring PX4 flight controller from companion computer"
    )


settings = Settings()

