r"""
BeeMesh Hive State

In-memory coordinator state for the BeeMesh runtime.
This module tracks which bees are known to the hive, which task cells
are waiting to be assigned, and which results have already been stored.

State view:

             .-------------------.
            /   HIVE REGISTRY     \
           / workers | queue |     \
           \ results | ids   |     /
            '-------------------'
               /       |       \
              /        |        \
         [Bee-01]  <task cell>  [Bee-02]
              \        |        /
               \   <result>    /
                    [Bee-03]

Honeycomb mapping:
  - The hive center is the coordinator's in-memory state.
  - Bees register with the hive and pull available task cells.
  - Completed cells return as results and are stored by task ID.
"""

from collections import deque
from typing import Any, Deque, Dict, Optional



class HiveState:
    """
    Central runtime state of the BeeMesh coordinator (Hive).
    """

    def __init__(self):

        # worker_id -> metadata
        self.workers: Dict[str, Dict[str, Any]] = {}

        # worker_id -> active task count
        self.worker_active_tasks: Dict[str, int] = {}

        # pending tasks
        self.task_queue: Deque[Dict[str, Any]] = deque()

        # task_id -> result
        self.results: Dict[str, Any] = {}

        self.worker_counter: int = 0

    # -------------------------
    # Worker management
    # -------------------------

    def register_worker(
        self,
        hostname: str,
        cpu_cores: int = 1,
        ram_gb: float = 0.0,
        gpu: Optional[str] = None,
    ) -> str:

        self.worker_counter += 1
        worker_id = f"worker-{self.worker_counter}"

        self.workers[worker_id] = {
            "hostname": hostname,
            "cpu_cores": cpu_cores,
            "ram_gb": ram_gb,
            "gpu": gpu,
        }

        self.worker_active_tasks[worker_id] = 0

        print(
            f"[Hive] Registered {worker_id} "
            f"(CPU={cpu_cores}, RAM={ram_gb}GB, GPU={gpu})"
        )

        return worker_id

    # -------------------------
    # Task scheduling
    # -------------------------

    def get_task(self, worker_id: str) -> Optional[Dict[str, Any]]:

        if worker_id not in self.workers:
            return None

        worker = self.workers[worker_id]
        max_tasks = worker.get("cpu_cores", 1)

        active = self.worker_active_tasks.get(worker_id, 0)

        # worker already busy enough
        if active >= max_tasks:
            return None

        if not self.task_queue:
            return None

        task = self.task_queue.popleft()

        self.worker_active_tasks[worker_id] += 1

        return task

    def add_task(self, task: Dict[str, Any]) -> None:
        self.task_queue.append(task)

    # -------------------------
    # Result handling
    # -------------------------

    def store_result(self, worker_id: str, task_id: str, result: Any) -> None:

        self.results[task_id] = result

        if worker_id in self.worker_active_tasks:
            self.worker_active_tasks[worker_id] = max(
                0, self.worker_active_tasks[worker_id] - 1
            )
