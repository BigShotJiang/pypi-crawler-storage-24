"""
Write solver run analysis JSON for conventional and antifragile solves.

Each run (conventional or antifragile) can write one analysis file to
run_dir/results/analysis/analysis_<run_id>_<solve_type>.json with runtime summary,
solver settings summary, and optional solver_stats from the backend.
"""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.config.config_settings import ConfigSettings


def _solver_settings_summary_from_config(settings: ConfigSettings) -> dict[str, Any]:
    """Build short solver settings summary from ConfigSettings (no full config)."""
    summary: dict[str, Any] = {
        "solver": settings.solver,
        "model_export": settings.model_export,
    }
    opts = getattr(settings, "options", None) or {}
    if isinstance(opts, dict):
        # Normalize common option names
        if "mipgap" in opts:
            summary["mip_gap"] = float(opts["mipgap"]) if opts["mipgap"] is not None else None
        if "mip_gap" in opts:
            summary["mip_gap"] = float(opts["mip_gap"]) if opts["mip_gap"] is not None else None
        if "time_limit" in opts:
            summary["time_limit_s"] = float(opts["time_limit"]) if opts["time_limit"] is not None else None
        if "time_limit_s" in opts:
            summary["time_limit_s"] = float(opts["time_limit_s"]) if opts["time_limit_s"] is not None else None
        if "threads" in opts:
            summary["threads"] = int(opts["threads"]) if opts["threads"] is not None else None
    return summary


def _solver_settings_summary_from_config_optimization(config: ConfigOptimization) -> dict[str, Any]:
    """Extract solver settings summary from ConfigOptimization (pyomo.solver_settings)."""
    settings = config.pyomo.solver_settings
    return _solver_settings_summary_from_config(settings)


def _data_repo_path(run_dir: Path, run_id: str, solve_type: str) -> str:
    """Relative path to analysis file from data repo root (run_dir is typically .../runs/<run_id>)."""
    # If run_dir ends with run_id, assume structure .../runs/<run_id>
    try:
        if run_dir.name == run_id and "runs" in run_dir.parts:
            idx = list(run_dir.parts).index("runs")
            rel = Path(*run_dir.parts[idx:]) / "results" / "analysis" / f"analysis_{run_id}_{solve_type}.json"
            return rel.as_posix()
    except (ValueError, IndexError):
        pass
    return f"runs/{run_id}/results/analysis/analysis_{run_id}_{solve_type}.json"


def solver_stats_from_bundle(bundle: Any) -> dict[str, Any] | None:
    """
    Extract solver result statistics from a solve result bundle (e.g. linopy solve return).

    Uses solve_info when present; includes objective_value, status, wall_time_s, mip_gap_achieved
    if the backend exposes them. Returns None if bundle is None or has no solve_info.
    """
    if bundle is None:
        return None
    info = getattr(bundle, "solve_info", None)
    if info is None:
        return None
    stats: dict[str, Any] = {}
    if getattr(info, "objective_value", None) is not None:
        try:
            stats["objective_value"] = float(info.objective_value)
        except (TypeError, ValueError):
            pass
    if hasattr(info, "status") and info.status is not None:
        stats["status"] = str(info.status)
    if hasattr(info, "wall_time") and info.wall_time is not None:
        try:
            stats["wall_time_s"] = float(info.wall_time)
        except (TypeError, ValueError):
            pass
    if hasattr(info, "wall_time_s") and info.wall_time_s is not None:
        try:
            stats["wall_time_s"] = float(info.wall_time_s)
        except (TypeError, ValueError):
            pass
    if hasattr(info, "mip_gap_achieved") and info.mip_gap_achieved is not None:
        try:
            stats["mip_gap_achieved"] = float(info.mip_gap_achieved)
        except (TypeError, ValueError):
            pass
    return stats if stats else {"objective_value": getattr(info, "objective_value", None)}


def solver_stats_from_framework(fw: Any) -> dict[str, Any] | None:
    """
    Extract solver_stats from a conventional framework (Stochastic/Regret/Robust).

    For two-stage: uses fw._results_bundle. Otherwise uses first scenario's results_bundle.
    """
    bundle = getattr(fw, "_results_bundle", None)
    if bundle is not None:
        return solver_stats_from_bundle(bundle)
    scenarios = getattr(fw, "_scenarios", None)
    if scenarios is None:
        return None
    for name in getattr(scenarios, "names", lambda: [])():
        sc = scenarios.get_scenario(name)
        bundle = getattr(sc, "results_bundle", None)
        if bundle is not None:
            return solver_stats_from_bundle(bundle)
    return None


def write_solver_analysis(
    run_dir: Path,
    run_id: str,
    solve_type: str,
    runtime_s: float,
    *,
    config_name: str,
    variants: list[str],
    modules: dict[str, dict[str, float]] | None = None,
    solver_settings_summary: dict[str, Any] | None = None,
    solver_stats: dict[str, Any] | None = None,
    code_commit_sha: str | None = None,
) -> Path:
    """
    Write analysis_<run_id>_<solve_type>.json under run_dir/results/analysis/.

    solve_type: "conventional" or "antifragile".
    modules: only for conventional; keys e.g. "stochastic", "regret", "robust", value {"runtime_s": float}.
    solver_stats: for conventional, dict keyed by module name; for antifragile, single dict. Can be partial.
    """
    analysis_dir = run_dir / "results" / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    path = analysis_dir / f"analysis_{run_id}_{solve_type}.json"

    payload: dict[str, Any] = {
        "run_id": run_id,
        "timestamp_utc": datetime.now(tz=timezone.utc).isoformat(),
        "solve_type": solve_type,
        "runtime_s": round(runtime_s, 2),
        "config_name": config_name,
        "variants": variants,
        "solver_settings_summary": solver_settings_summary or {},
        "data_repo_path": _data_repo_path(run_dir, run_id, solve_type),
    }
    if modules is not None:
        payload["modules"] = modules
    if solver_stats is not None:
        payload["solver_stats"] = solver_stats
    if code_commit_sha is not None:
        payload["code_commit_sha"] = code_commit_sha

    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return path


def get_code_commit_sha() -> str | None:
    """Return eta-incerto repo HEAD commit sha, or None if not a git repo."""
    try:
        root = Path(__file__).resolve().parents[2]
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if out.returncode == 0 and out.stdout:
            return out.stdout.strip()
    except Exception:
        pass
    return None
