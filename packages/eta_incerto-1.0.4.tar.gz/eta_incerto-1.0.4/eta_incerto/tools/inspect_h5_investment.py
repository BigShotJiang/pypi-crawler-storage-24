"""
Inspect __expected__/investment and objective/cost KPIs in eta-incerto result H5 files.

Usage:
  python -m eta_incerto.tools.inspect_h5_investment [path_or_dir ...]

  If no path is given, reads paths from stdin (one per line).
  Paths can be .h5 files or directories (in which case all *.h5 under them are inspected).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import h5py


def _collect_h5_paths(paths: list[Path]) -> list[Path]:
    out: list[Path] = []
    for p in paths:
        resolved = p.resolve()
        if not resolved.exists():
            sys.stderr.write(f"Skip (missing): {resolved}\n")
            continue
        if resolved.is_file():
            if resolved.suffix.lower() in (".h5", ".hdf5"):
                out.append(resolved)
            else:
                sys.stderr.write(f"Skip (not H5): {resolved}\n")
        else:
            out.extend(sorted(resolved.rglob("*.h5")) + sorted(resolved.rglob("*.hdf5")))
    return out


def _read_scalar(ds: h5py.Dataset) -> float:
    v = ds[()]
    if hasattr(v, "shape") and v.shape == (1,):
        v = v[0]
    return float(v)


def _walk_group(group: h5py.Group, prefix: str, out: dict[str, float]) -> None:
    for key in group:
        path = f"{prefix}/{key}"
        obj = group[key]
        if isinstance(obj, h5py.Dataset):
            try:
                out[path] = _read_scalar(obj)
            except Exception:
                pass
        elif isinstance(obj, h5py.Group):
            _walk_group(obj, path, out)


def inspect_file(h5_path: Path) -> dict[str, dict[str, float]]:
    """Read __expected__/investment, objective, and costs sections. Returns dict section -> path -> value."""
    sections: dict[str, dict[str, float]] = {}
    with h5py.File(h5_path, "r") as f:
        base = "__expected__"
        if base not in f:
            return sections
        root = f[base]
        for sec in ("investment", "objective", "costs"):
            if sec not in root or not isinstance(root[sec], h5py.Group):
                continue
            sections[sec] = {}
            _walk_group(root[sec], sec, sections[sec])
    return sections


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect investment/objective/cost KPIs in H5 result files.")
    parser.add_argument(
        "paths",
        nargs="*",
        type=Path,
        help="H5 files or directories to scan (default: read paths from stdin)",
    )
    parser.add_argument("--brief", action="store_true", help="Only print file names and investment *_bought summary.")
    args = parser.parse_args()

    if args.paths:
        paths = _collect_h5_paths(args.paths)
    else:
        paths = []
        for line in sys.stdin:
            stripped = line.strip()
            if stripped:
                paths.extend(_collect_h5_paths([Path(stripped)]))
    if not paths:
        sys.stderr.write("No H5 paths to inspect.\n")
        sys.exit(1)

    for h5_path in paths:
        _report_file(h5_path, args.brief)


def _report_file(h5_path: Path, brief: bool) -> None:
    """Print inspection report for one H5 file."""
    sys.stdout.write(f"\n{'=' * 60}\n{h5_path}\n{'=' * 60}\n")
    try:
        data = inspect_file(h5_path)
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return
    if not data:
        sys.stdout.write("  (no __expected__ or empty)\n")
        return
    if brief:
        inv = data.get("investment", {})
        bought = {k: v for k, v in inv.items() if "bought" in k or "_bought" in k}
        for k, v in sorted(bought.items()):
            sys.stdout.write(f"  {k}: {v}\n")
        return
    for sec in ("investment", "objective", "costs"):
        if sec not in data:
            continue
        sys.stdout.write(f"\n  [{sec}]\n")
        for path, val in sorted(data[sec].items()):
            sys.stdout.write(f"    {path}: {val}\n")


if __name__ == "__main__":
    main()
