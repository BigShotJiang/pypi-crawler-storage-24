# eta_incerto/evaluation/robust_evaluation.py
from __future__ import annotations

import datetime as dt
import logging
from collections import defaultdict
from collections.abc import Iterator
from copy import deepcopy
from dataclasses import dataclass, field
from json import load
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import h5py
from eta_components.milp_component_library.custom_types import BasicSystem
from eta_components.milp_component_library.objectives import (
    Emissions,
    NetPresentValue,
    TotalAnnualizedCost,
)
from numpy import (
    allclose as np_allclose,
    array,
    asarray,
    isnan,
    ndarray,
    zeros,
)
from pydantic import BaseModel, ConfigDict, Field

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.config.config_scenario import SupplierData
from eta_incerto.envs.deterministic_evaluation import DeterministicEvaluator
from eta_incerto.envs.objective_aggregation import RobustAggregator
from eta_incerto.envs.robust import RobustFramework
from eta_incerto.envs.scenario import Scenario, ScenarioCollection
from eta_incerto.envs.stochastic import StochasticScenarioCollection
from eta_incerto.envs.stochastic_evaluation import bundle_slice_for_scenario, merge_scenario_data
from eta_incerto.envs.utils import (
    aggregate_over_all_indices,
    investment_capacity_metric_name,
    iter_investment_units,
    numeric_value,
    trader_scalar_or_year_da,
)
from eta_incerto.registry import get_system
from eta_incerto.util.h5_config import save_config_to_h5
from eta_incerto.util.variant_loader import load_variant_data

logger = logging.getLogger(__name__)


@dataclass
class _ExpectedAccumulators:
    prob_sum: float = 0.0
    total_emissions_t: float = 0.0
    capex: float = 0.0

    energy_wh: dict[str, float] = field(default_factory=dict)
    costs_eur: dict[str, float] = field(default_factory=dict)
    emissions_t_by_trader: dict[str, float] = field(default_factory=dict)

    invest_bought: dict[str, float] = field(default_factory=dict)
    invest_p_out_nom: dict[str, float] = field(default_factory=dict)
    invest_e_nom: dict[str, float] = field(default_factory=dict)
    invest_cost: dict[str, float] = field(default_factory=dict)

    def add_weighted(self, dct: dict[str, float], key: str, prob: float, val: float) -> None:
        dct[key] = dct.get(key, 0.0) + prob * val


class RobustEvaluator(BaseModel):
    """Solve a robust program and persist objectives + KPIs to HDF5."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: ConfigOptimization = Field(..., description="Optimization config from central config.json")
    scenarios: ScenarioCollection = Field(..., description="Scenarios with probabilities")
    h5_file_name: str
    variant_name: str | None = Field(
        None,
        description="Override variant for this run;\
        else use config.system.variant[0].",
    )

    # -----------------------
    # eta-components helpers
    # -----------------------

    def _iter_traders(self, system: BasicSystem) -> Iterator[tuple[str, Any]]:
        """Yield (name, unit) for all units that look like traders."""
        for unit in system.units:
            if all(hasattr(unit, attr) for attr in ("amount", "time_step_cost", "emissions")):
                yield unit.name, unit

    def _iter_investments(self, system: BasicSystem) -> Iterator[tuple[str, Any]]:
        """Yield (name, unit) for all units that look like dimensioning investments."""
        yield from iter_investment_units(system)

    def _total_investment_cost(self, system: BasicSystem, bundle: Any = None) -> float:
        """Total CAPEX. If bundle given (two-stage), read from bundle."""
        if bundle is not None and hasattr(bundle, "vars"):
            metrics = self._collect_investment_metrics(system, bundle)
            return sum(m["investment_cost"] for m in metrics.values())
        total = 0.0
        for _, inv_unit in self._iter_investments(system):
            try:
                total += float(numeric_value(inv_unit.onetime_cost))
            except Exception:
                total += float(numeric_value(inv_unit.model.investment_cost))
        return total

    # -----------------------
    # HDF5 helpers
    # -----------------------

    def _as_h5_str_array(self, values: list[str]) -> ndarray:
        dt_s = h5py.string_dtype(encoding="utf-8")
        return array(values, dtype=dt_s)

    def _write_topology(self, f: h5py.File, graph: dict[str, Any]) -> None:
        """graph = {'nodes': [str, ...], 'edges': [(str, str), ...]}"""
        topo = f.require_group("topology")

        for key in ("nodes", "edges"):
            if key in topo:
                del topo[key]

        nodes = list(graph.get("nodes", []))
        edges = list(graph.get("edges", []))

        topo.create_dataset("nodes", data=self._as_h5_str_array(nodes))

        if len(edges) == 0:
            topo.create_dataset("edges", data=array([], dtype=h5py.string_dtype("utf-8")).reshape(0, 2))
            return

        def _edge_uv(e):
            if isinstance(e, dict):
                return e["source"], e["target"]
            return e[0], e[1]

        flat = [_edge_uv(e) for e in edges]
        dt_s = h5py.string_dtype(encoding="utf-8")
        topo.create_dataset("edges", data=array(flat, dtype=dt_s))

    def _write_meta_time_tag(self, f: h5py.File, tz_name: str = "Europe/Berlin") -> str:
        tz = ZoneInfo(tz_name)
        now = dt.datetime.now(tz=tz)

        time_tag = now.strftime("%Y%m%d_%H%M%S_%z")
        generated_at = now.isoformat(timespec="seconds")

        meta = f.require_group("meta")
        for key in ("time_tag", "generated_at", "timezone"):
            if key in meta:
                del meta[key]

        meta.create_dataset("time_tag", data=time_tag)
        meta.create_dataset("generated_at", data=generated_at)
        meta.create_dataset("timezone", data=tz_name)
        return time_tag

    # -----------------------
    # Input scenario storage (YEARLY, DISCRETE)
    # -----------------------

    def _collapse_to_year_discrete(
        self,
        d: dict[tuple[int, int, int], float],
        *,
        mode: str = "assert_constant",  # "assert_constant" | "first"
        rtol: float = 0.0,
        atol: float = 0.0,
    ) -> dict[int, float]:
        """
        Collapse {(year, period, timestep): value} -> {year: value} WITHOUT averaging.

        mode="first":          take first encountered value per year
        mode="assert_constant": assert all values within a year are equal (within tol)
        """
        buckets: dict[int, list[float]] = defaultdict(list)
        for (y, _p, _t), v in d.items():
            buckets[int(y)].append(float(v))

        out: dict[int, float] = {}
        for y, vals in buckets.items():
            if not vals:
                continue

            if mode == "first":
                out[y] = vals[0]
                continue

            if mode == "assert_constant":
                v0 = vals[0]
                if not np_allclose(vals, v0, rtol=rtol, atol=atol):
                    raise ValueError(
                        f"Scenario input not discrete for year={y}: "
                        f"min={min(vals):.6g}, max={max(vals):.6g}, expected constant."
                    )
                out[y] = v0
                continue

            raise ValueError(f"Unknown mode={mode}")

        return out

    def _write_year_map(self, grp: h5py.Group, name: str, year_map: dict[int, float]) -> None:
        """
        Store {year: value} as:
          /<name>/year  (N,) int
          /<name>/value (N,) float
        """
        sub = grp.require_group(name)
        for k in ("year", "value"):
            if k in sub:
                del sub[k]

        if not year_map:
            sub.create_dataset("year", data=zeros((0,), dtype=int))
            sub.create_dataset("value", data=zeros((0,), dtype=float))
            return

        years = asarray(sorted(year_map.keys()), dtype=int)
        vals = asarray([year_map[int(y)] for y in years], dtype=float)

        sub.create_dataset("year", data=years)
        sub.create_dataset("value", data=vals)

    def _write_input_scenarios_yearly(self, f: h5py.File, scenarios: ScenarioCollection) -> None:
        """
        Writes yearly *input* scenario data (no period/timestep dims).

        Layout:
          /scenarios/<scenario_name>/probability
          /scenarios/<scenario_name>/carriers/<carrier>/unit_price/{year,value}
          /scenarios/<scenario_name>/carriers/<carrier>/emissions_per_unit/{year,value}
          /scenarios/<scenario_name>/carriers/<carrier>/aggregation
        """
        root = f.require_group("scenarios")
        # overwrite whole section
        for k in list(root.keys()):
            del root[k]

        for scen in scenarios:
            sg = root.create_group(scen.name)
            sg.create_dataset("probability", data=float(getattr(scen, "probability", 0.0)))

            carriers_grp = sg.require_group("carriers")
            energy = getattr(scen, "energy_scenario", None)
            if energy is None:
                continue

            items = energy.items() if isinstance(energy, dict) else [("default", energy)]

            for carrier, supplier in items:
                cg = carriers_grp.require_group(str(carrier))

                unit_price = getattr(supplier, "unit_price", None)
                emissions = getattr(supplier, "emissions_per_unit", None)

                up_year = self._collapse_to_year_discrete(dict(unit_price or {}), mode="assert_constant")
                em_year = self._collapse_to_year_discrete(dict(emissions or {}), mode="assert_constant")

                self._write_year_map(cg, "unit_price", up_year)
                self._write_year_map(cg, "emissions_per_unit", em_year)

                if "aggregation" in cg:
                    del cg["aggregation"]
                cg.create_dataset("aggregation", data="discrete_assert_constant")

    # -----------------------
    # Save results
    # -----------------------

    def _save_results(
        self,
        results: dict[str, dict[Any, Any]],
        h5_file_name: str,
        system: RobustFramework,
        scenarios: ScenarioCollection,
        expected_dispatch: tuple[BasicSystem, dict[str, SupplierData]] | None = None,
    ) -> None:
        """Save evaluation results + topology + input scenario data to a single HDF5 file."""
        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        hdf_path = out_dir / h5_file_name
        if hdf_path.exists():
            hdf_path.unlink()

        graph = system.graph_representation()

        with h5py.File(hdf_path, "w") as f:
            # meta + topology
            self._write_meta_time_tag(f, tz_name=getattr(self.config, "timezone", "Europe/Berlin"))
            self._write_topology(f, graph)

            # input scenario data (YEARLY)
            self._write_input_scenarios_yearly(f, scenarios)

            # metrics (per scenario)
            for scenario, metrics in results.items():
                grp = f.create_group(scenario)
                for (category, name), value in metrics.items():
                    cat_grp = grp.require_group(category)
                    if name in cat_grp:
                        del cat_grp[name]
                    cat_grp.create_dataset(name, data=value)

            # config
            config_dict = getattr(self.config, "to_dict", lambda: self.config.__dict__)()
            save_config_to_h5(f.create_group("config"), config_dict)

            if expected_dispatch is not None:
                exp_system, exp_energy = expected_dispatch

                exp_grp = f.require_group("__expected__")

                # store expected carrier inputs yearly (nice for debugging / plots)
                carriers_grp = exp_grp.require_group("carriers")
                for carrier, supplier in exp_energy.items():
                    cg = carriers_grp.require_group(str(carrier))
                    up_year = self._collapse_to_year_discrete(dict(supplier.unit_price), mode="assert_constant")
                    em_year = self._collapse_to_year_discrete(dict(supplier.emissions_per_unit), mode="assert_constant")
                    self._write_year_map(cg, "unit_price", up_year)
                    self._write_year_map(cg, "emissions_per_unit", em_year)

                # dump unit dispatch using deterministic evaluator's dumping logic
                dispatch_root = exp_grp.require_group("unit_dispatch")
                dispatch_root.attrs["kind"] = "deterministic_expected_inputs_fixed_investments"
                units_grp = dispatch_root.require_group("units")

                det = DeterministicEvaluator(
                    config=self.config, scenarios=ScenarioCollection(), h5_file_name="__noop__.h5"
                )
                first_bundle = getattr(system, "_results_bundle", None)
                if first_bundle is None:
                    for sc in scenarios:
                        b = getattr(sc, "results_bundle", None)
                        if b is not None and hasattr(b, "vars"):
                            first_bundle = b
                            break
                if first_bundle is not None:
                    for unit in exp_system.units:
                        det._dump_unit_from_bundle(units_grp, unit.name, first_bundle.vars)

        logger.info("Evaluation results for %d scenarios written to: %s", len(results), hdf_path)

    # -----------------------
    # Objective attachment + solve
    # -----------------------

    def _load_weights(self, series_file_name: str, system: BasicSystem) -> dict[int, float]:
        weights_path = self.config.paths.series_dir / series_file_name / "weights.json"
        if not weights_path.exists():
            raise FileNotFoundError(f"No weights.json found for series {series_file_name}")

        with weights_path.open() as f:
            raw = load(f)
        raw = {int(k): float(v) for k, v in raw.items()}

        n_time_steps = int(len(system.index.coords["time"]))
        step_length = float(getattr(system, "step_length", 1.0))
        scale = 8760.0 / (n_time_steps * step_length)
        weights = {}
        for y in system.years_set:
            for p, w in raw.items():
                weights[(y, p)] = w * scale
        return weights

    def _attach_objectives(self, scenarios: ScenarioCollection) -> None:
        objective_kind = self.config.pyomo.objective_kind
        for scen in scenarios:
            system: BasicSystem = scen.system
            weights = self._load_weights(scen.series_file_name, system)

            npv_obj = NetPresentValue(
                "npv_objective",
                {
                    "weights": weights,
                    "interest": self.config.pyomo.interest,
                    "emission_cost": self.config.pyomo.emission_cost,
                },
                system,
            )
            tac_obj = TotalAnnualizedCost(
                "tac_objective",
                {
                    "weights": weights,
                    "interest": self.config.pyomo.interest,
                    "emission_cost": self.config.pyomo.emission_cost,
                    "n_years": self.config.pyomo.horizon.n_years,
                },
                system,
            )
            emissions_obj = Emissions("emissions_objective", {"weights": weights}, system)

            if objective_kind == "npv":
                system.set_objective(npv_obj)
            elif objective_kind == "tac":
                system.set_objective(tac_obj)
            elif objective_kind == "emissions":
                system.set_objective(emissions_obj)
            else:
                raise ValueError(f"Unknown objective_kind: {objective_kind}")

    def _attach_objectives_two_stage_robust(
        self, system: BasicSystem, scenarios: StochasticScenarioCollection, scenario_names: list[str]
    ) -> None:
        """Attach RobustAggregator (wrapping NPV or TAC) to the single two-stage robust system."""
        first_name = scenario_names[0] if scenario_names else None
        series_file = getattr(scenarios.get_scenario(first_name), "series_file_name", "") if first_name else ""
        weights = self._load_weights(series_file, system)
        data = {
            "weights": weights,
            "interest": self.config.pyomo.interest,
            "emission_cost": self.config.pyomo.emission_cost,
            "sense": "minimize",
        }
        objective_kind = self.config.pyomo.objective_kind
        if objective_kind == "tac":
            data["n_years"] = self.config.pyomo.horizon.n_years
            base_obj = TotalAnnualizedCost("tac_base", data, system)
        else:
            base_obj = NetPresentValue("npv_base", data, system)
        robust_aggregator = RobustAggregator("minmax_objective", system, base_obj, data=data)
        system.set_objective(robust_aggregator)

    def _build_and_solve_two_stage(self, scenarios: StochasticScenarioCollection) -> RobustFramework:
        """Build one system with n_scenarios, RobustAggregator objective, one solve; return framework."""
        series_batch, scenario_data_batch, scenario_names = merge_scenario_data(scenarios)
        if not scenario_names:
            raise ValueError("Two-stage robust requires at least one scenario.")
        builder = self._instantiate_system_builder()
        system = builder.build_static_system(n_scenarios=len(scenario_names))
        system = builder.build_investment(system)
        system = builder.build_dynamic_system(system, series_batch, scenario_data_batch)
        self._attach_objectives_two_stage_robust(system, scenarios, scenario_names)
        fw = RobustFramework(scenarios=scenarios)
        fw.set_system(system)
        fw.build_model()
        model_export = self.config.pyomo.solver_settings.model_export
        model_export_dir = (
            Path(self.config.paths.results_dir) / "lp" / Path(self.h5_file_name).stem if model_export is True else None
        )
        fw.solve(
            solver_name=self.config.pyomo.solver_settings.solver,
            tee=self.config.pyomo.solver_settings.tee,
            options=self.config.pyomo.solver_settings.options,
            model_export=model_export,
            model_export_dir=model_export_dir,
            explicit_coordinate_names=True,
        )
        return fw

    def _build_and_solve_framework(self, scenarios: StochasticScenarioCollection) -> RobustFramework:
        use_two_stage = getattr(self.config.pyomo, "use_two_stage", False)
        if use_two_stage:
            return self._build_and_solve_two_stage(scenarios)
        fw = RobustFramework(scenarios=scenarios)
        fw.build_model()
        model_export = self.config.pyomo.solver_settings.model_export
        model_export_dir = (
            Path(self.config.paths.results_dir) / "lp" / Path(self.h5_file_name).stem if model_export is True else None
        )
        fw.solve(
            solver_name=self.config.pyomo.solver_settings.solver,
            tee=self.config.pyomo.solver_settings.tee,
            options=self.config.pyomo.solver_settings.options,
            model_export=model_export,
            model_export_dir=model_export_dir,
            explicit_coordinate_names=True,
        )
        return fw

    # -----------------------
    # Results collection
    # -----------------------

    def _make_safe_aggregator(self, system: BasicSystem):
        def _safe_agg(var, system=system) -> float:
            return float(aggregate_over_all_indices(var, system))

        return _safe_agg

    def _collect_trader_vals(
        self,
        system: BasicSystem,
        agg: Any = None,
        bundle: Any = None,
        *,
        scenario_index: int | None = None,
    ) -> dict[str, dict[str, float]]:
        """Collect trader Quantity/Costs/Emissions. If bundle given, read from bundle.vars (two-stage).
        When bundle is None but system.last_results exists (Linopy after solve), use last_results.vars
        so we aggregate solution values instead of symbolic variables (avoids LinearExpression in MILP).
        """
        trader_vals: dict[str, dict[str, float]] = {}
        bundle_or_results = bundle if bundle is not None else getattr(system, "last_results", None)
        if bundle_or_results is not None and hasattr(bundle_or_results, "vars"):
            step_length = float(getattr(system, "step_length", 1.0))
            vars_ds = bundle_or_results.vars
            for trader_name, trader in self._iter_traders(system):
                amount_var = f"{trader_name}__amount"
                if amount_var not in vars_ds:
                    continue
                amount_da = vars_ds[amount_var]
                qty_wh = float(aggregate_over_all_indices(amount_da, system)) * step_length
                unit_price = trader_scalar_or_year_da(
                    getattr(trader, "data", {}).get("unit_price"), amount_da, 0.0, scenario_index=scenario_index
                )
                cost_da = amount_da * unit_price
                costs = float(aggregate_over_all_indices(cost_da, system))
                epu = trader_scalar_or_year_da(
                    getattr(trader, "data", {}).get("emissions_per_unit"), amount_da, 0.0, scenario_index=scenario_index
                )
                em_da = amount_da * epu
                emissions = float(aggregate_over_all_indices(em_da, system))
                trader_vals[trader_name] = {"Quantity": qty_wh, "Costs": costs, "Emissions": emissions}
            return trader_vals
        if agg is None:
            return trader_vals
        step_length = float(getattr(system, "step_length", 1.0))
        for trader_name, trader in self._iter_traders(system):
            trader_vals[trader_name] = {
                "Quantity": agg(trader.amount) * step_length,  # W -> Wh
                "Costs": agg(trader.time_step_cost),  # €
                "Emissions": agg(trader.emissions),  # kg
            }
        return trader_vals

    def _build_scenario_results_dict(
        self,
        *,
        prob: float,
        objective_kind: str,
        scen_obj_value: float,
        capex: float,
        total_emissions_t: float,
    ) -> dict[Any, Any]:
        return {
            ("scenario", "probability"): prob,
            ("objective", objective_kind): scen_obj_value,
            ("objective", "capex"): capex,
            ("emissions", "total_t"): total_emissions_t,
        }

    def _write_traders_into_results(
        self, scen_results: dict[Any, Any], trader_vals: dict[str, dict[str, float]]
    ) -> None:
        for name, v in trader_vals.items():
            scen_results[("energy", f"{name}_wh")] = v["Quantity"]
            scen_results[("costs", f"{name}_eur")] = v["Costs"]
            scen_results[("emissions", f"{name}_t")] = v["Emissions"] * 1e-3

    def _accumulate_expected_traders(
        self, exp: _ExpectedAccumulators, trader_vals: dict[str, dict[str, float]], prob: float
    ) -> None:
        for name, v in trader_vals.items():
            exp.add_weighted(exp.energy_wh, name, prob, v["Quantity"])
            exp.add_weighted(exp.costs_eur, name, prob, v["Costs"])
            exp.add_weighted(exp.emissions_t_by_trader, name, prob, v["Emissions"] * 1e-3)

    def _iter_investments_from_bundle(self, system: BasicSystem, bundle: Any) -> Iterator[tuple[str, Any]]:
        """Yield (name, unit) for units that have investment-related variables in bundle.vars (Linopy)."""
        vars_ds = getattr(bundle, "vars", None)
        if vars_ds is None or not hasattr(vars_ds, "data_vars"):
            return
        inv_hints = (
            "is_bought",
            "inv_",
            "investment_cost",
            "onetime_cost",
            "p_out_nom",
            "e_nom",
            "p_heat_out_nom",
            "area",
        )
        for unit in system.units:
            prefix = f"{unit.name}__"
            for vname in vars_ds.data_vars:
                if vname.startswith(prefix) and any(h in vname for h in inv_hints):
                    yield unit.name, unit
                    break

    def _collect_investment_metrics(self, system: BasicSystem, bundle: Any = None) -> dict[str, dict[str, float]]:
        invest_metrics: dict[str, dict[str, float]] = {}
        if bundle is not None and hasattr(bundle, "vars"):
            det = DeterministicEvaluator(config=self.config, scenarios=ScenarioCollection(), h5_file_name="__noop__.h5")
            for inv_name, inv_unit in self._iter_investments_from_bundle(system, bundle):
                raw = det._read_investment_unit_from_bundle(inv_unit, bundle)
                invest_metrics[inv_name] = {
                    "bought": float(raw.get("bought", 0)),
                    "p_out_nom": float(raw.get("E_nom", 0)),
                    "E_nom": float(raw.get("E_nom", 0)),
                    "investment_cost": float(raw.get("investment_cost", 0)),
                    "_capacity_metric": investment_capacity_metric_name(inv_unit),
                }
                for k in ("p_out_nom_min", "p_out_nom_max", "E_nom_min", "E_nom_max"):
                    if k in raw:
                        invest_metrics[inv_name][k] = float(raw[k])
            return invest_metrics
        det = DeterministicEvaluator(config=self.config, scenarios=ScenarioCollection(), h5_file_name="__noop__.h5")
        for inv_name, inv_unit in self._iter_investments(system):
            raw = det._read_investment_unit(inv_unit, None)
            invest_metrics[inv_name] = {
                "bought": float(raw.get("bought", 0)),
                "p_out_nom": float(raw.get("p_out_nom", 0)),
                "E_nom": float(raw.get("E_nom", 0)),
                "investment_cost": float(raw.get("investment_cost", 0)),
                "_capacity_metric": investment_capacity_metric_name(inv_unit),
            }
            for k in ("p_out_nom_min", "p_out_nom_max", "E_nom_min", "E_nom_max"):
                if k in raw:
                    invest_metrics[inv_name][k] = float(raw[k])
        return invest_metrics

    def _write_investments_into_results(
        self, scen_results: dict[Any, Any], invest_metrics: dict[str, dict[str, float]]
    ) -> None:
        for inv_name, im in invest_metrics.items():
            scen_results[("investment", f"{inv_name}_bought")] = im["bought"]
            cap_metric = im.get("_capacity_metric", "p_out_nom")
            cap_val = im["E_nom"] if cap_metric == "E_nom" else im["p_out_nom"]
            scen_results[("investment", f"{inv_name}_{cap_metric}")] = cap_val
            scen_results[("investment", f"{inv_name}_investment_cost")] = im["investment_cost"]
            if cap_metric == "E_nom":
                if "E_nom_min" in im:
                    scen_results[("investment", f"{inv_name}_E_nom_min")] = im["E_nom_min"]
                if "E_nom_max" in im:
                    scen_results[("investment", f"{inv_name}_E_nom_max")] = im["E_nom_max"]
            else:
                if "p_out_nom_min" in im:
                    scen_results[("investment", f"{inv_name}_p_out_nom_min")] = im["p_out_nom_min"]
                if "p_out_nom_max" in im:
                    scen_results[("investment", f"{inv_name}_p_out_nom_max")] = im["p_out_nom_max"]

    def _accumulate_expected_investments(
        self, exp: _ExpectedAccumulators, invest_metrics: dict[str, dict[str, float]], prob: float
    ) -> None:
        for inv_name, im in invest_metrics.items():
            exp.add_weighted(exp.invest_bought, inv_name, prob, im["bought"])
            cap_metric = im.get("_capacity_metric", "p_out_nom")
            cap_val = im["E_nom"] if cap_metric == "E_nom" else im["p_out_nom"]
            if cap_metric == "E_nom":
                exp.add_weighted(exp.invest_e_nom, inv_name, prob, cap_val)
            else:
                exp.add_weighted(exp.invest_p_out_nom, inv_name, prob, cap_val)
            exp.add_weighted(exp.invest_cost, inv_name, prob, im["investment_cost"])

    def _finalize_expected(self, results: dict[str, dict[Any, Any]], exp: _ExpectedAccumulators) -> None:
        expected = results["__expected__"]
        n_years = self.config.pyomo.horizon.n_years
        annual_scale = 1.0 / n_years

        expected.update(
            {
                ("scenario", "probability_sum"): exp.prob_sum,
                ("emissions", "total_t"): exp.total_emissions_t * annual_scale,
                ("objective", "capex"): exp.capex,
            }
        )

        def _write_group(group: str, values: dict[str, float], *, suffix: str, scale: float, unit_suffix: str) -> None:
            for name, val in values.items():
                expected[(group, f"{name}{unit_suffix}{suffix}")] = val * scale

        def _write_invest_group(values: dict[str, float], *, metric_suffix: str, suffix: str, scale: float) -> None:
            for inv_name, val in values.items():
                expected[("investment", f"{inv_name}_{metric_suffix}{suffix}")] = val * scale

        norm = None
        if (not isnan(exp.prob_sum)) and exp.prob_sum not in (0.0, 1.0):
            norm = 1.0 / exp.prob_sum

        variants: list[tuple[str, float]] = [("", 1.0)]
        if norm is not None:
            variants.append(("_normalized", norm))

        for suffix, scale in variants:
            if suffix:
                expected[("emissions", f"total_t{suffix}")] = exp.total_emissions_t * scale * annual_scale
                expected[("objective", f"capex{suffix}")] = exp.capex * scale

            _write_group("energy", exp.energy_wh, suffix=suffix, scale=scale * annual_scale, unit_suffix="_wh")
            _write_group("costs", exp.costs_eur, suffix=suffix, scale=scale * annual_scale, unit_suffix="_eur")
            _write_group(
                "emissions", exp.emissions_t_by_trader, suffix=suffix, scale=scale * annual_scale, unit_suffix="_t"
            )

            _write_invest_group(exp.invest_bought, metric_suffix="bought", suffix=suffix, scale=scale)
            _write_invest_group(exp.invest_p_out_nom, metric_suffix="p_out_nom", suffix=suffix, scale=scale)
            _write_invest_group(exp.invest_e_nom, metric_suffix="E_nom", suffix=suffix, scale=scale)
            _write_invest_group(exp.invest_cost, metric_suffix="investment_cost", suffix=suffix, scale=scale)

    def _collect_results(self, scenarios: ScenarioCollection, fw: RobustFramework) -> dict[str, dict[Any, Any]]:
        results: dict[str, dict[Any, Any]] = {}

        objective_kind = self.config.pyomo.objective_kind
        exp = _ExpectedAccumulators()

        if getattr(fw, "_results_bundle", None) is not None and getattr(fw, "_system", None) is not None:
            system = fw._system
            bundle = fw._results_bundle
            scenario_names = list(scenarios.names())
            invest_metrics_once = self._collect_investment_metrics(system, bundle)
            capex_once = self._total_investment_cost(system, bundle)
            # Expected TAC = capex + sum_s(prob_s * operational_s) for comparability with stochastic/regret
            expected_tac = float(capex_once)
            for i, scen_name in enumerate(scenario_names):
                scen = scenarios.get_scenario(scen_name)
                prob = float(getattr(scen, "probability", 0.0))
                exp.prob_sum += prob
                sub_bundle = bundle_slice_for_scenario(bundle, i)
                trader_vals = self._collect_trader_vals(system, bundle=sub_bundle, scenario_index=i)
                total_emissions_t = sum(v["Emissions"] for v in trader_vals.values()) * 1e-3
                exp.total_emissions_t += prob * total_emissions_t
                exp.capex += prob * capex_once
                scen_obj_value = 0.0
                if hasattr(bundle, "vars") and "__obj_per_scenario" in getattr(bundle.vars, "data_vars", {}):
                    da = bundle.vars["__obj_per_scenario"]
                    if hasattr(da, "isel"):
                        scen_obj_value = float(da.isel(scenario=i).values)
                elif (
                    i == 0
                    and hasattr(bundle, "solve_info")
                    and getattr(bundle.solve_info, "objective_value", None) is not None
                ):
                    scen_obj_value = float(bundle.solve_info.objective_value)
                expected_tac += prob * scen_obj_value
                self._accumulate_expected_investments(exp, invest_metrics_once, prob)
                scen_results = self._build_scenario_results_dict(
                    prob=prob,
                    objective_kind=objective_kind,
                    scen_obj_value=scen_obj_value,
                    capex=capex_once,
                    total_emissions_t=total_emissions_t,
                )
                self._write_traders_into_results(scen_results, trader_vals)
                self._accumulate_expected_traders(exp, trader_vals, prob)
                self._write_investments_into_results(scen_results, invest_metrics_once)
                results[scen_name] = scen_results
            results["__expected__"] = {("objective", objective_kind): expected_tac}
            self._finalize_expected(results, exp)
            return results

        expected_tac = 0.0
        for scen in scenarios:
            scen_name = scen.name
            system: BasicSystem = scen.system
            prob = float(getattr(scen, "probability", 0.0))
            exp.prob_sum += prob

            agg = self._make_safe_aggregator(system)

            trader_vals = self._collect_trader_vals(system, agg=agg)
            total_emissions_t = sum(v["Emissions"] for v in trader_vals.values()) * 1e-3
            exp.total_emissions_t += prob * total_emissions_t

            # Linopy: objective value comes from solve result, not from system.objective (which is the objective object)
            last_results = getattr(system, "last_results", None)
            if (
                last_results is not None
                and hasattr(last_results, "solve_info")
                and getattr(last_results.solve_info, "objective_value", None) is not None
            ):
                scen_obj_value = float(last_results.solve_info.objective_value)
            else:
                scen_obj_value = float(numeric_value(system.objective))
            expected_tac += prob * scen_obj_value
            capex = self._total_investment_cost(system)
            exp.capex += prob * capex

            invest_metrics = self._collect_investment_metrics(system)
            self._accumulate_expected_investments(exp, invest_metrics, prob)

            scen_results = self._build_scenario_results_dict(
                prob=prob,
                objective_kind=objective_kind,
                scen_obj_value=scen_obj_value,
                capex=capex,
                total_emissions_t=total_emissions_t,
            )

            self._write_traders_into_results(scen_results, trader_vals)
            self._accumulate_expected_traders(exp, trader_vals, prob)

            self._write_investments_into_results(scen_results, invest_metrics)
            results[scen_name] = scen_results

        results["__expected__"] = {("objective", objective_kind): expected_tac}
        self._finalize_expected(results, exp)
        return results

    # -----------------------
    # Public API
    # -----------------------

    def evaluate_systems(
        self, scenarios: StochasticScenarioCollection | None = None
    ) -> tuple[dict[str, dict[Any, Any]], RobustFramework]:
        scenarios = self.scenarios if scenarios is None else scenarios
        use_two_stage = getattr(self.config.pyomo, "use_two_stage", False)
        if not use_two_stage:
            self._attach_objectives(scenarios)
        fw = self._build_and_solve_framework(scenarios)
        results = self._collect_results(scenarios, fw)

        expected_dispatch = self._solve_expected_dispatch(scenarios, fw)

        self._save_results(results, self.h5_file_name, fw, scenarios, expected_dispatch=expected_dispatch)
        return results, fw

    # -----------------------
    # Section for saving dispatch information for each unit
    # -----------------------

    def _probabilities(self, scenarios) -> dict[str, float]:
        probs = {sc.name: float(getattr(sc, "probability", 0.0)) for sc in scenarios}
        s = sum(probs.values())
        if s <= 0.0:
            # fallback: uniform if probabilities missing
            names = list(probs.keys())
            if not names:
                return {}
            u = 1.0 / len(names)
            return dict.fromkeys(names, u)
        return probs

    def _build_expected_energy_scenario(self, scenarios) -> dict[str, SupplierData]:
        """
        Build expected SupplierData per carrier:
          unit_price_exp[(y,p,t)] = sum_s prob_s * unit_price_s[(y,p,t)]   (prices are discrete-by-year anyway)
        We keep the *exact* index set of the first scenario as reference.
        """
        scenarios = list(scenarios)
        if not scenarios:
            return {}

        probs = self._probabilities(scenarios)
        ref_energy = getattr(scenarios[0], "energy_scenario", None)
        if not isinstance(ref_energy, dict) or not ref_energy:
            return {}

        out: dict[str, SupplierData] = {}

        for carrier, ref_supplier in ref_energy.items():
            ref_up = dict(getattr(ref_supplier, "unit_price", {}) or {})
            ref_em = dict(getattr(ref_supplier, "emissions_per_unit", {}) or {})

            # expected-by-year (using your existing discreteness logic)
            exp_up_year: dict[int, float] = {}
            exp_em_year: dict[int, float] = {}

            # accumulate weighted yearly values
            up_acc: dict[int, float] = defaultdict(float)
            em_acc: dict[int, float] = defaultdict(float)
            psum = 0.0

            for sc in scenarios:
                p = probs.get(sc.name, 0.0)
                psum += p

                energy = getattr(sc, "energy_scenario", None)
                if not isinstance(energy, dict) or carrier not in energy:
                    continue

                sup = energy[carrier]
                up_year = self._collapse_to_year_discrete(
                    dict(getattr(sup, "unit_price", {}) or {}), mode="assert_constant"
                )
                em_year = self._collapse_to_year_discrete(
                    dict(getattr(sup, "emissions_per_unit", {}) or {}), mode="assert_constant"
                )

                for y, v in up_year.items():
                    up_acc[int(y)] += p * float(v)
                for y, v in em_year.items():
                    em_acc[int(y)] += p * float(v)

            if psum <= 0.0:
                continue

            for y, v in up_acc.items():
                exp_up_year[int(y)] = v / psum
            for y, v in em_acc.items():
                exp_em_year[int(y)] = v / psum

            # materialize full index dict (keep ref keys)
            up_full: dict[tuple[int, int, int], float] = {}
            em_full: dict[tuple[int, int, int], float] = {}

            for y, p, t in ref_up:
                up_full[(int(y), int(p), int(t))] = float(exp_up_year[int(y)])
            for y, p, t in ref_em:
                em_full[(int(y), int(p), int(t))] = float(exp_em_year[int(y)])

            out[str(carrier)] = SupplierData(type=str(carrier), unit_price=up_full, emissions_per_unit=em_full)

        return out

    def _system_variant_name(self) -> str:
        if self.variant_name is not None:
            return self.variant_name
        name = getattr(self.config.system, "variant", None)
        if isinstance(name, (list, tuple)):
            if not name:
                raise ValueError("config.system.variant is empty.")
            return str(name[0])
        if not isinstance(name, str) or not name:
            raise ValueError("config.system.variant must be a non-empty string (or list with one entry).")
        return name

    def _instantiate_system_builder(self):
        variant = self._system_variant_name()
        system_cls, static_data_cls, investment_data_cls, _ = get_system(variant)

        if static_data_cls is not None and investment_data_cls is not None:
            static_data, investment_data, _ = load_variant_data(
                self.config, variant, static_data_cls, investment_data_cls, None
            )
        else:
            static_data = static_data_cls.load_default() if static_data_cls is not None else None
            investment_data = investment_data_cls.load_default() if investment_data_cls is not None else None

        # match both constructor styles seen in your codebase
        try:
            return system_cls(self.config, static_data, investment_data)
        except TypeError:
            return system_cls(config=self.config, static_data=static_data, investment_data=investment_data)

    def _build_expected_investment_system(
        self, *, series_data, expected_energy: dict[str, SupplierData]
    ) -> BasicSystem:
        builder = self._instantiate_system_builder()
        base_static = builder.build_static_system()

        sys_copy = deepcopy(base_static)
        dynamic_sys = builder.build_dynamic_system(sys_copy, series_data, expected_energy)

        baseline = deepcopy(dynamic_sys)
        return builder.build_investment(baseline)

    def _unit_by_name(self, system: BasicSystem, name: str):
        if hasattr(system, "get_unit"):
            try:
                return system.get_unit(name)
            except Exception:
                pass
        for u in system.units:
            if getattr(u, "name", None) == name:
                return u
        raise KeyError(f"Unit not found in expected system: {name}")

    def _fix_investments_from_solution(
        self,
        expected_system: BasicSystem,
        scenarios,
        fw: RobustFramework,
    ) -> None:
        """
        Fix p_out_nom from fw.root_solution() or from fw._results_bundle (two-stage).
        Fix y (and possible E_nom) from the first solved scenario or from bundle (two-stage).
        """
        scenarios = list(scenarios)
        if not scenarios:
            return

        det = DeterministicEvaluator(
            config=self.config,
            scenarios=ScenarioCollection(),
            h5_file_name="__noop__.h5",
        )
        ref_sys: BasicSystem = getattr(fw, "_system", None) or scenarios[0].system
        bundle = getattr(fw, "_results_bundle", None)

        p_out_nom_sol = self._extract_p_out_nom_solution(fw)
        inv_metrics = self._extract_investment_metrics(det, ref_sys, bundle=bundle)

        for inv_name, met in inv_metrics.items():
            u_exp = self._try_get_expected_unit(expected_system, inv_name)
            if u_exp is None:
                continue

            # 1) fix buy decision (y)
            y_val = self._round_if_near_int(float(met.get("bought", 0.0)))
            self._fix_if_possible(self._resolve_y_var(u_exp), y_val)

            # 2) fix p_out_nom
            if "p_out_nom" in met:
                nom = float(p_out_nom_sol.get(inv_name, met["p_out_nom"]))
                self._fix_if_possible(self._resolve_p_out_nom_var(u_exp), nom)

            # 3) fix E_nom
            if "E_nom" in met:
                self._fix_if_possible(self._resolve_e_nom_var(u_exp), float(met["E_nom"]))

    def _extract_p_out_nom_solution(self, fw: RobustFramework) -> dict[str, float]:
        """Return mapping {unit_name: p_out_nom} from fw.root_solution() or fw._results_bundle (two-stage)."""
        bundle = getattr(fw, "_results_bundle", None)
        if bundle is not None and hasattr(bundle, "vars"):
            out: dict[str, float] = {}
            for vname, da in bundle.vars.data_vars.items():
                if "__p_heat_out_nom" in vname or "__p_out_nom" in vname:
                    unit_name = vname.split("__", 1)[0]
                    try:
                        val = float(da.max().values) if hasattr(da, "max") else float(da.values.flatten()[0])
                    except Exception:
                        val = 0.0
                    out[unit_name] = val
            return out
        root = getattr(fw, "root_solution", None)
        if root is None:
            return {}
        sol = root()
        out: dict[str, float] = {}
        for k, v in sol.items():
            unit_name = str(k).split(".", 1)[0]
            out[unit_name] = float(v)
        return out

    def _extract_investment_metrics(
        self,
        det: DeterministicEvaluator,
        ref_sys: BasicSystem,
        *,
        bundle: Any = None,
    ) -> dict[str, dict[str, float]]:
        """Read investment metrics from the reference system or from bundle (two-stage)."""
        inv_metrics: dict[str, dict[str, float]] = {}
        for inv_name, inv_unit in det._iter_investments(ref_sys):
            if bundle is not None:
                raw = det._read_investment_unit_from_bundle(inv_unit, bundle)
                inv_metrics[inv_name] = {
                    "bought": float(raw.get("bought", 0)),
                    "p_out_nom": float(raw.get("E_nom", raw.get("p_out_nom", 0))),
                    "E_nom": float(raw.get("E_nom", 0)),
                }
            else:
                inv_metrics[inv_name] = det._read_investment_unit(inv_unit)
        return inv_metrics

    def _try_get_expected_unit(self, expected_system: BasicSystem, name: str):
        """Resolve expected unit; return None and warn if missing."""
        try:
            return self._unit_by_name(expected_system, name)
        except KeyError:
            logger.warning(
                "Expected-dispatch: investment unit %s not found in rebuilt expected system.",
                name,
            )
            return None

    @staticmethod
    def _round_if_near_int(x: float, tol: float = 1e-6) -> float:
        r = round(x)
        return float(r) if abs(x - r) < tol else x

    @staticmethod
    def _fix_if_possible(var, value: float) -> None:
        """Fix a Pyomo-like var if it exists and supports .fix()."""
        if var is not None and hasattr(var, "fix"):
            var.fix(value)

    @staticmethod
    def _resolve_y_var(u_exp):
        """Prefer wrapper attribute, else fall back to model.y."""
        if hasattr(u_exp, "is_bought"):
            return u_exp.is_bought
        model = getattr(u_exp, "model", None)
        return getattr(model, "y", None) if model is not None else None

    @staticmethod
    def _resolve_p_out_nom_var(u_exp):
        """Prefer wrapper _p_out_nom, else fall back to model.p_out_nom."""
        var = getattr(u_exp, "_p_out_nom", None)
        if var is not None:
            return var
        model = getattr(u_exp, "model", None)
        return getattr(model, "p_out_nom", None) if model is not None else None

    @staticmethod
    def _resolve_e_nom_var(u_exp):
        """Resolve model.E_nom if present."""
        model = getattr(u_exp, "model", None)
        return getattr(model, "E_nom", None) if model is not None else None

    def _solve_expected_dispatch(
        self, scenarios, fw: RobustFramework
    ) -> tuple[BasicSystem, dict[str, SupplierData]] | None:
        scenarios = list(scenarios)
        if not scenarios:
            return None

        expected_energy = self._build_expected_energy_scenario(scenarios)
        if not expected_energy:
            logger.warning("Expected-dispatch: could not build expected energy scenario (missing energy_scenario).")
            return None

        ref = scenarios[0]
        series_data = getattr(ref, "series", None)
        if series_data is None:
            logger.warning("Expected-dispatch: reference scenario has no 'series' attached.")
            return None

        expected_system = self._build_expected_investment_system(
            series_data=series_data, expected_energy=expected_energy
        )

        expected_scen = Scenario(
            name="__expected_dispatch__",
            system=expected_system,
            series=series_data,
            energy_scenario=expected_energy,
            series_file_name=getattr(ref, "series_file_name", ""),
        )

        self._attach_objectives(ScenarioCollection([expected_scen]))
        self._fix_investments_from_solution(expected_system, scenarios, fw)

        model_export = self.config.pyomo.solver_settings.model_export
        if model_export is True:
            lp_dir = Path(self.config.paths.results_dir) / "lp" / Path(self.h5_file_name).stem
            lp_dir.mkdir(parents=True, exist_ok=True)
            model_export_arg = lp_dir / "expected_dispatch.lp"
        else:
            model_export_arg = model_export
        expected_system.solve(
            solver=self.config.pyomo.solver_settings.solver,
            tee=self.config.pyomo.solver_settings.tee,
            options=self.config.pyomo.solver_settings.options,
            model_export=model_export_arg,
            explicit_coordinate_names=True,
        )

        return expected_system, expected_energy
