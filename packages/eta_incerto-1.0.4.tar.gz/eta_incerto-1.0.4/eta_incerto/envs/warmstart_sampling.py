from __future__ import annotations

import numpy as np
from pymoo.core.sampling import Sampling


class WarmStartSampling(Sampling):
    """
    Sampling that injects warm-start points and fills the rest via a base sampler (e.g., LHS).

    - warm_x: (k, n_var) or (n_var,)
    - base: any pymoo Sampling (e.g., LHS())
    """

    def __init__(self, warm_x: np.ndarray, base: Sampling):
        super().__init__()
        warm_x = np.asarray(warm_x, dtype=float)
        if warm_x.ndim == 1:
            warm_x = warm_x.reshape(1, -1)
        self.warm_x = warm_x
        self.base = base

    def _do(self, problem, n_samples, **kwargs):
        # base sampling
        base_pop = self.base.do(problem, n_samples, **kwargs)
        X = base_pop.get("X") if hasattr(base_pop, "get") else np.asarray(base_pop, dtype=float)  # noqa:N806

        # clip warm-start into bounds
        warm = np.clip(self.warm_x, problem.xl, problem.xu)

        # inject (overwrite first rows)
        k = min(len(warm), len(X))
        X[:k, :] = warm[:k, :]
        return X
