from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from numpy import asarray
from pymoo.core.problem import ElementwiseProblem

from eta_incerto.config.config import ConfigOptimization


@dataclass(frozen=True)
class AntifragileRuntime:
    config: ConfigOptimization
    eval_objectives: Callable[[np.ndarray], np.ndarray]


class AntifragileProblem(ElementwiseProblem):
    def __init__(self, rt: AntifragileRuntime, variant_name: str, parallelization=None):
        self.rt = rt
        cfg = rt.config
        pdef = cfg.pymoo.for_variant(variant_name)

        super().__init__(
            n_var=len(pdef.variable_names),
            n_obj=len(pdef.objective_names),
            n_constr=pdef.n_eq_constraints,
            xl=asarray(pdef.x_lower_bound, dtype=float),
            xu=asarray(pdef.x_upper_bound, dtype=float),
            elementwise=True,
            parallelization=parallelization,
        )

    def _evaluate(self, x, out, *args, **kwargs):
        out["F"] = self.rt.eval_objectives(asarray(x, dtype=float))
