from __future__ import annotations

from logging import getLogger
from pathlib import Path
from typing import Any

import h5py
import numpy as np
from chaospy import fit_regression, generate_expansion, generate_quadrature
from chaospy.distributions.baseclass import Distribution
from eta_components.milp_component_library.exceptions import InfeasibleProblemError
from joblib import Parallel, delayed
from numpy import asarray
from pydantic import BaseModel, ConfigDict, Field
from pymoo.optimize import minimize

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.envs.antifragile import AntifragileProblem, AntifragileRuntime
from eta_incerto.envs.model import Model
from eta_incerto.envs.surrogate_objectives import fit_surrogate, predict_surrogate
from eta_incerto.util.h5_config import save_config_to_h5
from eta_incerto.util.numba_stats import skew_moment, upr_from_y_weights
from eta_incerto.util.sampling_feasibility import (
    FeasibilityConstraint,
    RejectionSamplerWithStats,
    XiSampler,
)

log = getLogger(__name__)


class AntifragileEvaluator(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: ConfigOptimization = Field(..., description="Optimization config from central config.json")
    h5_file_name: str
    model_builder: Model = Field(..., description="Model to use for evaluation")
    distribution_data: Distribution = Field(..., description="Distribution of input parameters")
    variable_names: str | list[str]
    objective_names: str | list[str]
    variant_name: str

    normalize: bool = False
    obj_min: np.ndarray | None = None
    obj_max: np.ndarray | None = None

    problem: AntifragileProblem | None = None

    _xi_sampler: RejectionSamplerWithStats | None = None
    _xi_key: str = "xi"

    def model_post_init(self, __context: Any, /) -> None:
        pdef = self.config.pymoo.for_variant(self.variant_name)
        self.normalize = bool(pdef.normalize)
        self.obj_min = np.asarray(pdef.obj_min, dtype=float)
        self.obj_max = np.asarray(pdef.obj_max, dtype=float)

        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        dt_min = float(getattr(eval_cfg, "feasibility_dt_min", 1e-6))
        batch_size = int(getattr(eval_cfg, "feasibility_batch_size", 256))
        max_rounds = int(getattr(eval_cfg, "feasibility_max_rounds", 200))

        def _draw_fn(n: int, rng: np.random.Generator) -> dict[str, np.ndarray]:
            n = int(n)
            # deterministic seed taken from your Generator
            seed = int(rng.integers(0, 2**32 - 1, dtype=np.uint32))
            rule = self.config.evaluate.for_variant(self.variant_name).pce_rule

            s = self.distribution_data.sample(size=n, rule=rule, seed=seed)

            s = np.asarray(s, dtype=float)

            # Chaospy often returns shape (dim, n). Convert to (n, dim).
            if s.ndim == 1:
                # 1D distribution → shape (n,) or (1, n)
                s = s.reshape(n, 1) if s.shape[0] == n else s.reshape(-1, n).T
            else:
                # If last axis is n, move it to front: (..., n) -> (n, ...)
                if s.shape[-1] == n and s.shape[0] != n:
                    s = np.moveaxis(s, -1, 0)

                # If first axis is dim and second is n: (dim, n) -> (n, dim)
                if s.shape[0] != n and s.shape[1] == n:
                    s = s.T

                if s.shape[0] != n:
                    raise ValueError(f"Unexpected sample shape {s.shape} for n={n}")

                # flatten remaining dims to a feature dimension
                s = s.reshape(n, -1)

            return {self._xi_key: s}

        base = XiSampler(draw_fn=_draw_fn)
        constraint = FeasibilityConstraint(self.model_builder, dt_min=dt_min, xi_key=self._xi_key)

        self._xi_sampler = RejectionSamplerWithStats(
            base=base,
            constraint=constraint,
            max_rounds=max_rounds,
            batch_size=batch_size,
        )

        # Problem is built in evaluate_systems() after offline DOE and surrogate fit (offline-only flow).

    # ----------------------------
    # Feasibility metadata (persist to HDF5)
    # ----------------------------
    def _feasibility_metadata(self) -> dict[str, Any]:
        if self._xi_sampler is None:
            return {}

        n_drawn = int(getattr(self._xi_sampler, "n_drawn", 0))
        n_rejected = int(getattr(self._xi_sampler, "n_rejected", 0))
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        return {
            "n_drawn": n_drawn,
            "n_rejected": n_rejected,
            "rejection_rate": float(n_rejected / max(n_drawn, 1)),
            "dt_min": float(getattr(eval_cfg, "feasibility_dt_min", 1e-6)),
            "batch_size": int(getattr(eval_cfg, "feasibility_batch_size", 256)),
            "max_rounds": int(getattr(eval_cfg, "feasibility_max_rounds", 200)),
        }

    # ----------------------------
    # Core eval
    # ----------------------------
    def _simulate(self, x: np.ndarray, xi: np.ndarray) -> float:
        try:
            return float(self.model_builder.build_simulate_model(x, xi))
        except InfeasibleProblemError:
            # großer Wert = "schlecht" (weil du median etc. minimierst/transformierst)
            return float(self.config.pymoo.penalty)

    def _simulate_many(self, x: np.ndarray, xi_batch: np.ndarray, batch_size: int | None = None) -> np.ndarray:
        xi_batch = np.asarray(xi_batch, dtype=float)
        if xi_batch.ndim != 2:
            raise ValueError(f"Expected xi_batch with 2 dims, got shape {xi_batch.shape}.")

        n_rows = xi_batch.shape[0]
        if not batch_size or batch_size <= 0 or batch_size >= n_rows:
            return self._simulate_many_once(x, xi_batch)

        y = np.empty((n_rows,), dtype=float)
        for start in range(0, n_rows, batch_size):
            end = min(start + batch_size, n_rows)
            chunk = xi_batch[start:end]
            y_chunk = self._simulate_many_once(x, chunk)
            if y_chunk.shape[0] != chunk.shape[0]:
                raise ValueError(
                    f"Vectorized evaluation returned unexpected shape: {y_chunk.shape} for inputs {chunk.shape}."
                )
            y[start:end] = y_chunk
        return y

    def _simulate_many_once(self, x: np.ndarray, xi_batch: np.ndarray) -> np.ndarray:
        try:
            y = self.model_builder.build_simulate_model(x, xi_batch)
            y = np.asarray(y, dtype=float)
            if y.ndim == 0:
                y = np.full((xi_batch.shape[0],), float(y))
            return y
        except InfeasibleProblemError:
            return np.full((xi_batch.shape[0],), float(self.config.pymoo.penalty))

    def _draw_feasible_samples(self, n_samples: int) -> np.ndarray:
        """
        Returns samples shaped (n_dim, n_samples) for chaospy.fit_regression.
        """
        if self._xi_sampler is None:
            raise RuntimeError("Feasibility sampler not initialized.")

        rng = np.random.default_rng(self.config.pymoo.seed)
        X = self._xi_sampler.draw_many(rng, int(n_samples), key=self._xi_key)  # (n_samples, n_dim)# noqa: N806
        return np.asarray(X, dtype=float).T  # (n_dim, n_samples)

    def build_pce_surrogate(
        self,
        x: np.ndarray,
        distribution_data: Distribution,
        pce_rule: int,
        pce_order: int,
        n_jobs: int,
        backend: str,
        vectorized: bool,
        vectorized_batch_size: int | None,
    ):
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        overrides = {}
        if getattr(eval_cfg, "solver_mipgap_override", None) is not None:
            overrides["mipgap"] = float(eval_cfg.solver_mipgap_override)
        if getattr(eval_cfg, "solver_timelimit_override", None) is not None:
            overrides["timelimit"] = float(eval_cfg.solver_timelimit_override)
        self.model_builder._solver_options_override = overrides if overrides else None
        try:
            return self._build_pce_surrogate_impl(
                x=x,
                distribution_data=distribution_data,
                pce_rule=pce_rule,
                pce_order=pce_order,
                n_jobs=n_jobs,
                backend=backend,
                vectorized=vectorized,
                vectorized_batch_size=vectorized_batch_size,
            )
        finally:
            self.model_builder._solver_options_override = None

    def _build_pce_surrogate_impl(
        self,
        x: np.ndarray,
        distribution_data: Distribution,
        pce_rule: int,
        pce_order: int,
        n_jobs: int,
        backend: str,
        vectorized: bool,
        vectorized_batch_size: int | None,
    ):
        poly_exp = generate_expansion(order=pce_order, dist=distribution_data)
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        factor = int(getattr(eval_cfg, "pce_sample_factor", 4))
        n_samples = max(factor * len(poly_exp), 1)

        # IMPORTANT: draw feasible samples (conditional distribution)
        samples = self._draw_feasible_samples(n_samples)
        y_vals = None
        if vectorized:
            xi_batch = samples.T
            n_rows = xi_batch.shape[0]
            chunk_size = (
                vectorized_batch_size if vectorized_batch_size and 0 < vectorized_batch_size < n_rows else n_rows
            )
            n_chunks = max(1, (n_rows + chunk_size - 1) // chunk_size)
            use_parallel_chunks = n_chunks > 1 and n_jobs != 1
            try:
                if use_parallel_chunks:
                    chunks = [xi_batch[start : start + chunk_size] for start in range(0, n_rows, chunk_size)]
                    chunk_results = Parallel(n_jobs=n_jobs, backend=backend)(
                        delayed(self._simulate_many_once)(x, chunk) for chunk in chunks
                    )
                    y_vals = np.concatenate(chunk_results)
                else:
                    y_vals = self._simulate_many(x, xi_batch, batch_size=vectorized_batch_size)
            except Exception as exc:
                log.warning("Vectorized evaluation failed; falling back to scalar loop.", exc_info=exc)
                y_vals = None

        if y_vals is None:
            y_vals = Parallel(n_jobs=n_jobs, backend=backend)(
                delayed(self._simulate)(x, samples[:, i]) for i in range(samples.shape[1])
            )

        return fit_regression(poly_exp, samples, y_vals)

    def upr_from_distribution(
        self,
        pce_model,
        distribution_data: Distribution,
        omega: float,
        quad_order: int,
        quad_rule: str,
    ) -> float:
        if not hasattr(self, "_upr_quad_cache"):
            self._upr_quad_cache = {}
        key = (quad_order, quad_rule)
        if key not in self._upr_quad_cache:
            self._upr_quad_cache[key] = generate_quadrature(order=quad_order, dist=distribution_data, rule=quad_rule)
        nodes, weights = self._upr_quad_cache[key]
        y = asarray(pce_model(*nodes), dtype=float)
        return float(upr_from_y_weights(y, asarray(weights, dtype=float), omega))

    def evaluate_statistics(
        self,
        pce_model,
        distribution_data: Distribution,
        stat_n_mc: int,
        stat_omega: float,
        stat_rule: str,
        quad_order: int,
        quad_rule: str,
    ) -> np.ndarray:
        samples = distribution_data.sample(stat_n_mc, stat_rule)
        y = asarray(pce_model(*samples), dtype=float)

        med = float(np.median(y))
        skewness = float(skew_moment(y))
        upr = self.upr_from_distribution(pce_model, distribution_data, stat_omega, quad_order, quad_rule)
        return np.asarray([med, -skewness, -upr], dtype=float)

    def _evaluate_objectives(self, x: np.ndarray) -> np.ndarray:
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)

        pce_model = self.build_pce_surrogate(
            x=x,
            distribution_data=self.distribution_data,
            pce_rule=eval_cfg.pce_rule,
            pce_order=eval_cfg.pce_order,
            n_jobs=eval_cfg.n_jobs,
            backend=eval_cfg.backend,
            vectorized=bool(getattr(eval_cfg, "vectorized", False)),
            vectorized_batch_size=getattr(eval_cfg, "vectorized_batch_size", None),
        )

        stats = self.evaluate_statistics(
            pce_model=pce_model,
            distribution_data=self.distribution_data,
            stat_n_mc=eval_cfg.stat_n_mc,
            stat_omega=eval_cfg.stat_omega,
            stat_rule=eval_cfg.stat_rule,
            quad_order=eval_cfg.quad_order,
            quad_rule=eval_cfg.quad_rule,
        )

        if self.normalize:
            denom = self.obj_max - self.obj_min

            # If denom is a plain numpy array, use masking (no np.where => no numpoly dispatch)
            if isinstance(denom, np.ndarray):
                denom = denom.copy()
                denom[np.abs(denom) < 1e-12] = 1.0
            else:
                # denom might be scalar, list, numpoly polynomial, etc.
                # Convert to array if safe; otherwise just guard scalar case.
                try:
                    denom_arr = np.asarray(denom, dtype=float)
                    denom_arr[np.abs(denom_arr) < 1e-12] = 1.0
                    denom = denom_arr
                except Exception:
                    # last resort: scalar-ish
                    denom = 1.0 if abs(float(denom)) < 1e-12 else denom

            return (stats - self.obj_min) / denom

        return stats

    # ----------------------------
    # Offline DOE (PCE training with Gurobi)
    # ----------------------------
    def run_offline_doe(self, n_samples: int) -> tuple[np.ndarray, np.ndarray]:
        """
        Run design-space DOE: sample n_samples design points, evaluate each with
        _evaluate_objectives (PCE training via Gurobi + statistics).         Returns (x_doe, f_doe).
        """
        pdef = self.config.pymoo.for_variant(self.variant_name)
        n_obj = len(pdef.objective_names)

        # Minimal problem for sampling (bounds only; _evaluate not used by sampler)
        dummy_rt = AntifragileRuntime(config=self.config, eval_objectives=lambda x: np.zeros(n_obj))
        doe_problem = AntifragileProblem(dummy_rt, self.variant_name)
        sampling = self.config.algorithm.sampling_class()
        pop = sampling.do(doe_problem, n_samples)
        x_doe = np.asarray(pop.get("X"), dtype=float)

        f_doe = np.empty((x_doe.shape[0], n_obj), dtype=float)
        for i in range(x_doe.shape[0]):
            f_doe[i] = self._evaluate_objectives(x_doe[i])
            if (i + 1) % max(1, x_doe.shape[0] // 10) == 0 or i == x_doe.shape[0] - 1:
                log.info("Offline DOE: %d / %d design points evaluated.", i + 1, x_doe.shape[0])

        return x_doe, f_doe

    # ----------------------------
    # Optimization + persistence (surrogate-only loop)
    # ----------------------------
    def evaluate_systems(self):
        n_samples = self.config.antifragile.offline_n_design_points
        surrogate_kind = self.config.antifragile.surrogate_kind

        log.info("Offline phase: running DOE with n_samples=%d (Gurobi in this phase only).", n_samples)
        x_doe, f_doe = self.run_offline_doe(n_samples)

        log.info("Fitting surrogate (kind=%s) and starting NSGA-II (no Gurobi in loop).", surrogate_kind)
        surrogate = fit_surrogate(x_doe, f_doe, kind=surrogate_kind)

        pdef = self.config.pymoo.for_variant(self.variant_name)
        xl = asarray(pdef.x_lower_bound, dtype=float)
        xu = asarray(pdef.x_upper_bound, dtype=float)

        def surrogate_wrapper(x: np.ndarray) -> np.ndarray:
            f = predict_surrogate(surrogate, x, xl, xu)
            if self.normalize:
                denom = self.obj_max - self.obj_min
                if isinstance(denom, np.ndarray):
                    denom = denom.copy()
                    denom[np.abs(denom) < 1e-12] = 1.0
                else:
                    try:
                        denom = np.asarray(denom, dtype=float)
                        denom[np.abs(denom) < 1e-12] = 1.0
                    except Exception:
                        denom = 1.0 if abs(float(denom)) < 1e-12 else denom
                return (f - self.obj_min) / denom
            return f

        rt = AntifragileRuntime(config=self.config, eval_objectives=surrogate_wrapper)
        self.problem = AntifragileProblem(rt, self.variant_name)

        algorithm_cfg = self.config.algorithm
        termination = self.config.termination.termination_instance
        algorithm = algorithm_cfg.algorithm_class(
            pop_size=algorithm_cfg.pop_size,
            sampling=algorithm_cfg.sampling_class(),
            selection=algorithm_cfg.selection_class(),
            crossover=algorithm_cfg.crossover_class(),
            mutation=algorithm_cfg.mutation_class(),
        )

        res = minimize(
            problem=self.problem,
            algorithm=algorithm,
            termination=termination,
            seed=self.config.pymoo.seed,
            verbose=self.config.pymoo.verbose,
        )

        self._save_results(res.X, res.F, self.h5_file_name, x_doe=x_doe, f_doe=f_doe)
        return res

    def _get_config_dict(self) -> dict:
        """Return config as a plain dict for HDF5 serialization."""
        if hasattr(self.config, "to_dict"):
            return self.config.to_dict()
        if hasattr(self.config, "model_dump"):
            return self.config.model_dump()
        return dict(self.config.__dict__)

    def _write_doe_group(
        self,
        f: h5py.File,
        x_doe: np.ndarray | None,
        f_doe: np.ndarray | None,
        var_names: list[str],
        obj_names: list[str],
    ) -> None:
        """Write design_points/ group if both x_doe and f_doe are provided."""
        if x_doe is None or f_doe is None:
            return
        x_doe = x_doe.reshape(1, -1) if x_doe.ndim == 1 else x_doe
        f_doe = f_doe.reshape(1, -1) if f_doe.ndim == 1 else f_doe
        g_design = f.require_group("design_points")
        g_design.create_dataset("X", data=x_doe)
        g_design.create_dataset("F", data=f_doe)
        g_design.create_dataset("variable_names", data=np.asarray(var_names, dtype="S"))
        g_design.create_dataset("objective_names", data=np.asarray(obj_names, dtype="S"))

    def _save_results(
        self,
        x: np.ndarray,
        fvals: np.ndarray,
        h5_file_name: str,
        *,
        x_doe: np.ndarray | None = None,
        f_doe: np.ndarray | None = None,
    ) -> None:
        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        hdf_path = out_dir / h5_file_name
        if hdf_path.exists():
            hdf_path.unlink()

        var_names = [self.variable_names] if isinstance(self.variable_names, str) else list(self.variable_names)
        obj_names = [self.objective_names] if isinstance(self.objective_names, str) else list(self.objective_names)

        if x.ndim == 1:
            x = x.reshape(1, -1)
        if fvals.ndim == 1:
            fvals = fvals.reshape(1, -1)

        if len(var_names) != x.shape[1]:
            raise ValueError(f"Expected {x.shape[1]} variable names, got {len(var_names)}")
        if len(obj_names) != fvals.shape[1]:
            raise ValueError(f"Expected {fvals.shape[1]} objective names, got {len(obj_names)}")

        with h5py.File(hdf_path, "w") as f:
            meta_grp = f.require_group("meta")
            meta_grp.create_dataset("objective_transform", data=np.asarray([1.0, -1.0, -1.0]))
            meta_grp.attrs["variant"] = self.variant_name
            meta_grp.attrs["surrogate_kind"] = self.config.antifragile.surrogate_kind
            meta_grp.attrs["offline_n_design_points"] = self.config.antifragile.offline_n_design_points

            # persist rejection sampler stats (RejectionSamplerWithStats)
            feas = self._feasibility_metadata()
            if feas:
                g_feas = f.require_group("feasibility")
                for k, v in feas.items():
                    g_feas.create_dataset(str(k), data=v)

            g = f.require_group("pareto")
            g.create_dataset("X", data=x)
            g.create_dataset("F", data=fvals)
            g.create_dataset("variable_names", data=np.asarray(var_names, dtype="S"))
            g.create_dataset("objective_names", data=np.asarray(obj_names, dtype="S"))

            self._write_doe_group(f, x_doe, f_doe, var_names, obj_names)

            config_dict = self._get_config_dict()
            save_config_to_h5(f.require_group("config"), config_dict)

        log.info("Antifragile optimization stored: X %s, F %s -> %s", x.shape, fvals.shape, hdf_path)
