from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path
from typing import Any, Literal

import attrs
import eta_components.milp_component_library as mcl
import numpy as np
import xarray as xr

logger = logging.getLogger(__name__)


def unique_lp_path(directory: Path, basename: str) -> Path:
    """Return a non-existing LP file path in directory.

    On Windows, linopy deletes the target file before writing; if another process
    still holds the file handle (e.g. parallel run / open file), unlink fails.
    Using a unique filename avoids these collisions.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    base = directory / str(basename)
    if not base.exists():
        return base
    stem = base.stem
    suffix = base.suffix or ".lp"
    i = 1
    while True:
        cand = directory / f"{stem}_{i}{suffix}"
        if not cand.exists():
            return cand
        i += 1


@attrs.define(kw_only=True)
class SystemConfig:
    n_years: int
    n_periods: int
    n_time_steps: int
    step_length: int
    year_length: int
    start_path: str


def extend_to_years_index(data: dict, config: SystemConfig):
    for key, value in data.items():
        if isinstance(value, dict):
            value_temp = {}
            for key2, value2 in value.items():
                for year in np.arange(1, config.n_years * config.year_length + 1, config.year_length):
                    value_temp[(year, *key2)] = value2
            data[key] = value_temp
    return data


def replace_pfr_plr_bpts_with_linear_correlation(data: dict):
    for data_unit in data.values():
        if "pfr_plr_bpts" in data_unit:
            data_unit["pfr_plr_bpts"] = [[0, 0], [1, 1]]


def allow_simultaneous_charging_and_discharging_of_storages(data: dict):
    for name, data_unit in data.items():
        if "storage" in name:
            data_unit["allow_simultaneous_charging_and_discharging"] = True


def trader_scalar_or_year_da(  # noqa: PLR0911
    value: Any,
    amount_da: xr.DataArray,
    default: float = 0.0,
    *,
    scenario_index: int | None = None,
) -> float | xr.DataArray:
    """
    Convert trader unit_price or emissions_per_unit to a scalar or DataArray
    for multiplying amount_da.

    Handles: None, scalar, dict[year, float], and xr.DataArray.
    When value is an xr.DataArray with a 'scenario' dimension and amount_da does not
    have it (e.g. sliced bundle for one scenario), pass scenario_index to select
    the correct scenario slice; the result is aligned/broadcast to amount_da.
    """
    if value is None:
        return float(default)
    if isinstance(value, dict):
        year_coord = getattr(amount_da, "year", amount_da.coords.get("year"))
        if year_coord is None:
            return float(default)
        years = year_coord.values if hasattr(year_coord, "values") else list(year_coord)
        return xr.DataArray(
            [float(value.get(y, default)) for y in years],
            dims=["year"],
            coords={"year": years},
        )
    # Handle xr.DataArray (e.g. scenario-indexed unit_price from two-stage build_dynamic_system)
    if hasattr(value, "dims") and hasattr(value, "isel"):
        da = value
        # If amount_da has no scenario dim but da has one, slice to scenario_index
        if "scenario" in da.dims and "scenario" not in getattr(amount_da, "dims", ()):
            if scenario_index is None:
                return float(default)
            da = da.isel(scenario=scenario_index).drop_vars("scenario", errors="ignore")
        # Align to amount_da so amount_da * result is valid (result has amount_da's coords)
        try:
            aligned_da, _ = xr.align(da, amount_da, join="right")
            return aligned_da
        except Exception:
            return float(default)
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def iter_investment_units(system: mcl.custom_types.BasicSystem) -> Iterator[tuple[str, Any]]:
    """Yield (name, unit) for all units that look like dimensioning investments.

    Single source of truth so robust, stochastic, regret, and deterministic
    all discover the same set (including vars-based units like dimensioning heat pumps).
    """
    for unit in system.units:
        if all(hasattr(unit, attr) for attr in ("is_bought", "onetime_cost")) and any(
            hasattr(unit, a) for a in ("_p_out_nom", "_E_nom", "_e_nom")
        ):
            yield unit.name, unit
            continue
        if (
            hasattr(unit, "vars")
            and isinstance(unit.vars, dict)
            and (
                "e_nom" in unit.vars
                or "onetime_cost" in unit.vars
                or "p_out_nom" in unit.vars
                or "p_heat_out_nom" in unit.vars
                or "area" in unit.vars
            )
        ):
            yield unit.name, unit
            continue
        if not hasattr(unit, "model"):
            continue
        m = unit.model
        if not all(hasattr(m, a) for a in ("y", "investment_cost")):
            continue
        if any(hasattr(m, a) for a in ("p_out_nom", "P_out_nom", "E_nom", "e_nom", "E_nominal", "e_nominal")):
            yield unit.name, unit


def investment_capacity_metric_name(inv_unit: Any) -> Literal["E_nom", "p_out_nom"]:
    """Return the investment capacity key suffix for this unit: E_nom for storage, p_out_nom for power."""
    if hasattr(inv_unit, "vars") and isinstance(inv_unit.vars, dict) and "e_nom" in inv_unit.vars:
        return "E_nom"
    return "p_out_nom"


def numeric_value(x: Any) -> float:
    """Extract a single float from a scalar, DataArray, or object with .value/.values/.solution (Linopy)."""
    if x is None:
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if hasattr(x, "solution"):
        # Linopy variable after solve: value is in .solution (DataArray)
        return numeric_value(x.solution)
    if hasattr(x, "values"):
        v = x.values
        return float(v.flatten()[0]) if getattr(v, "size", 0) else 0.0
    if hasattr(x, "value"):
        return float(x.value)
    return float(x)


def aggregate_over_all_indices(var: xr.DataArray, system: mcl.custom_types.BasicSystem) -> float:
    """
    Aggregate a (year, period, time) DataArray over all indices to a single scalar,
    weighted by system.objective.weights (year, period).
    Linopy: expects xr.DataArray with dims (year, period, time).
    """
    weights = system.objective.weights
    if hasattr(var, "dims"):
        weighted = var * weights if "year" in var.dims and "period" in var.dims else var
        return numeric_value(weighted.sum())
    return 0.0


def aggregate_over_all_time_steps(
    var: xr.DataArray, year: int, period: int, system: mcl.custom_types.BasicSystem
) -> float:
    """
    Sum var over time steps for a given (year, period). No period weighting.
    Linopy: expects xr.DataArray with .sel().
    """
    if hasattr(var, "sel"):
        subset = var.sel(year=year, period=period)
        return numeric_value(subset.sum())
    return 0.0


def aggregate_for_years(var: xr.DataArray, system: mcl.custom_types.BasicSystem) -> dict[int, float]:
    """
    Aggregate var[year, period, time] per year, weighted by system.objective.weights.
    Returns {year: value} (weighted sum over periods and time per year).
    Linopy: expects xr.DataArray with .sel().
    """
    weights = system.objective.weights
    years_set = getattr(system, "years_set", [])
    if hasattr(var, "dims"):
        if "year" not in var.dims or "period" not in var.dims:
            return {}
        weighted = var * weights
        return {int(y): numeric_value(weighted.sel(year=y).sum()) for y in years_set}
    return {}


def check_plausibility_trader_cost(
    amount_da: xr.DataArray,
    unit_price: float | xr.DataArray,
    system: mcl.custom_types.BasicSystem,
    costs_by_year: dict[int, float],
    trader_name: str,
    *,
    ratio_tolerance: tuple[float, float] = (0.5, 2.0),
) -> dict[str, Any]:
    """
    Plausibility check: energy (SI) x price should match reported cost.

    Computes E_carrier (energy per year, same weighting as objective), then
    cost_expected = E_carrier x unit_price, and compares to costs_by_year.
    Returns dict with energy_by_year, cost_expected_by_year, ratios_by_year.
    Logs a warning if any ratio (reported / expected) is outside ratio_tolerance.
    """
    step_length = float(getattr(system, "step_length", 1.0))
    energy_da = amount_da.abs() * step_length
    energy_by_year = aggregate_for_years(energy_da, system)

    def price_for_year(y: int) -> float:
        if hasattr(unit_price, "sel") and "year" in getattr(unit_price, "dims", ()):
            try:
                return float(unit_price.sel(year=y).values)
            except Exception:
                return float(unit_price)
        return float(unit_price)

    cost_expected_by_year: dict[int, float] = {}
    ratios_by_year: dict[int, float] = {}
    for y, e in energy_by_year.items():
        p = price_for_year(y)
        cost_expected_by_year[y] = e * p
        reported = costs_by_year.get(y, 0.0)
        if cost_expected_by_year[y] != 0:
            ratios_by_year[y] = reported / cost_expected_by_year[y]
        else:
            ratios_by_year[y] = 1.0 if reported == 0 else float("inf")

    low, high = ratio_tolerance
    for y, ratio in ratios_by_year.items():
        if ratio < low or ratio > high:
            logger.warning(
                "Plausibility: %s year %s reported/expected cost ratio %.4g outside [%.2f, %.2f] "
                "(reported=%.4g, expected=%.4g, energy=%.4g).",
                trader_name,
                y,
                ratio,
                low,
                high,
                costs_by_year.get(y, 0),
                cost_expected_by_year.get(y, 0),
                energy_by_year.get(y, 0),
            )

    return {
        "energy_by_year": energy_by_year,
        "cost_expected_by_year": cost_expected_by_year,
        "ratios_by_year": ratios_by_year,
    }
