from __future__ import annotations

import abc
import logging
from abc import ABC
from typing import Any

from eta_incerto.envs.scenario import ScenarioCollection

logger = logging.getLogger(__name__)


class UncertaintyFramework(ABC):
    """Abstract base for uncertainty frameworks (Linopy-only)."""

    def __init__(self, scenarios: ScenarioCollection):
        self._scenarios: ScenarioCollection = scenarios
        self._first_stage_variables: dict[str, Any] = {}

    @abc.abstractmethod
    def build_model(self) -> None:
        """Build or prepare the model. Linopy: compat hooks only per scenario."""

    def solve(
        self,
        solver_name: str = "highs",
        tee: bool = False,
        options: dict | None = None,
        model_export: bool | str = False,
    ) -> Any:
        """Solve the framework. Override in subclasses (Deterministic/Stochastic use Linopy)."""
        raise NotImplementedError(
            "UncertaintyFramework.solve() is not implemented. "
            "Use DeterministicFramework or StochasticFramework (Linopy path)."
        )

    def _equate_investment_decisions_across_submodels(self, global_model: Any, scenarios_block: Any) -> None:
        """No-op: Linopy path uses per-scenario solve and populates _first_stage_variables from results."""
        return

    def _extract_first_stage_variables_from_submodels(self) -> dict:
        """No-op for Linopy-only: first-stage is populated from results_bundle in framework solve."""
        return {}

    def _get_first_stage_key_varname_from_bundle(self, bundle: Any) -> list[tuple[str, str]]:
        """Return list of (first_stage_key, backend_var_name) for design/first-stage vars.

        Includes vars like p_out_nom, p_heat_out_nom; excludes purely operational names
        (e.g. _nom_on, _on).
        """
        out: list[tuple[str, str]] = []
        if bundle is None or not hasattr(bundle, "vars"):
            return out
        ds = bundle.vars
        data_vars = getattr(ds, "data_vars", None)
        if data_vars is None:
            data_vars = ds
        if not hasattr(data_vars, "items"):
            return out
        for vname, _ in list(data_vars.items()):
            vname_lower = vname.lower()
            if "_nom_on" in vname_lower or vname_lower.endswith("_on"):
                continue
            if "__" not in vname or ("p_out_nom" not in vname_lower and "p_heat_out_nom" not in vname_lower):
                continue
            parts = vname.split("__")
            uname = parts[0]
            suffix = parts[1] if len(parts) > 1 else ""
            if "p_out_nom" in suffix.lower() or "p_heat_out_nom" in suffix.lower():
                key = f"{uname}.p_out_nom"
                out.append((key, vname))
        return out

    def _populate_first_stage_from_scenario(self, scenario_name: str) -> None:
        """Fill _first_stage_variables from the given scenario's results_bundle."""
        scenario = self._scenarios.get_scenario(scenario_name)
        bundle = getattr(scenario, "results_bundle", None)
        if bundle is None or not hasattr(bundle, "vars"):
            return
        v = getattr(bundle.vars, "data_vars", None) or getattr(bundle.vars, "variables", None)
        if v is None and hasattr(bundle.vars, "items"):
            v = bundle.vars
        if v is None or not hasattr(v, "items"):
            return
        for vname, da in v.items():
            vname_lower = vname.lower()
            if "__" not in vname or ("p_out_nom" not in vname_lower and "p_heat_out_nom" not in vname_lower):
                continue
            parts = vname.split("__")
            uname = parts[0]
            suffix = parts[1] if len(parts) > 1 else ""
            if "p_out_nom" in suffix.lower() or "p_heat_out_nom" in suffix.lower():
                key = f"{uname}.p_out_nom"
            else:
                continue
            try:
                val = (
                    float(da.sum().values)
                    if hasattr(da, "sum") and getattr(da, "size", 0)
                    else float(da.values.flatten()[0])
                )
            except Exception:
                val = 0.0
            self._first_stage_variables[key] = val

    def _check_all_submodels_have_same_first_stage_variables(self, submodel_first_stage_variables: dict) -> None:
        """Raise if the set of first-stage variable keys differs across scenarios."""
        if not submodel_first_stage_variables:
            return
        keys_per = {name: frozenset(vars_dict) for name, vars_dict in submodel_first_stage_variables.items()}
        ref = next(iter(keys_per.values()))
        for name, keys in keys_per.items():
            if keys != ref:
                raise ValueError(
                    f"First-stage variables must be the same in all scenarios; "
                    f"scenario {name} has keys {set(keys)} vs reference {set(ref)}."
                )

    def __name_of_first_scenario(self) -> str:
        return next(iter(self._scenarios.names()))

    def _create_global_first_stage_variables(self, global_model: Any, submodel_first_stage_variables: dict) -> dict:
        """No-op for Linopy-only."""
        return {}

    def _equate_global_first_stage_variables_to_submodel_first_stage_variables(  # noqa: B027
        self, scenarios_block: Any, global_first_stage_variables: dict, submodel_first_stage_variables: dict
    ) -> None:
        """No-op: equating is done inside _equate_investment_decisions_across_submodels."""
        pass

    def root_solution(self) -> dict[str, float]:
        """Return current values of first-stage variables (e.g. after solve)."""
        out: dict[str, float] = {}
        for k, v in self._first_stage_variables.items():
            if isinstance(v, (int, float)):
                out[k] = float(v)
            else:
                out[k] = 0.0
        return out

    def graph_representation(self) -> dict[str, list[tuple[str, str]]]:
        nodes = self._get_nodes()
        edges = self._get_edges()
        return {"nodes": nodes, "edges": edges}

    def _reference_system(self):
        first_name = next(iter(self._scenarios.names()))
        return self._scenarios.get_scenario(first_name).system

    @property
    def units(self):
        return self._reference_system().units

    @property
    def networks(self):
        return self._reference_system().networks

    @property
    def environments(self):
        return self._reference_system().environments

    def _get_nodes(self) -> list[str]:
        nodes = [unit.name for unit in self.units]
        nodes += [net.name for net in self.networks]
        nodes += [env.name for env in self.environments]
        return nodes

    def _get_edges(self) -> list[dict[str, str]]:
        edges: list[dict[str, str]] = []
        for net in self.networks:
            for unit, power in net._producers:
                edges.append(
                    {
                        "source": unit.name,
                        "target": net.name,
                        "kind": "producer",
                        "power": getattr(power, "local_name", getattr(power, "name", str(power))),
                    }
                )
            for unit, power in net._consumers:
                edges.append(
                    {
                        "source": net.name,
                        "target": unit.name,
                        "kind": "consumer",
                        "power": getattr(power, "local_name", getattr(power, "name", str(power))),
                    }
                )
            for unit, power in net._prosumers:
                pn = getattr(power, "local_name", getattr(power, "name", str(power)))
                edges.append({"source": unit.name, "target": net.name, "kind": "prosumer", "power": pn})
                edges.append({"source": net.name, "target": unit.name, "kind": "prosumer", "power": pn})
        env_by_id = {id(e): e for e in self.environments}
        env_by_name = {e.name: e for e in self.environments}
        for unit in self.units:
            for attr in dir(unit):
                if "env" not in attr.lower():
                    continue
                obj = getattr(unit, attr, None)
                if obj is None:
                    continue
                env = env_by_id.get(id(obj)) or env_by_name.get(getattr(obj, "name", None))
                if env is None:
                    continue
                edges.append(
                    {
                        "source": env.name,
                        "target": unit.name,
                        "kind": "environment",
                        "power": attr,
                    }
                )
        return edges
