from __future__ import annotations

from copy import deepcopy
from logging import INFO, basicConfig, getLogger
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING

from eta_incerto.analysis.sensitivity import run_std_target_sensitivity_from_config
from eta_incerto.config.config import ConfigOptimization
from eta_incerto.envs.antifragile_evaluation import AntifragileEvaluator
from eta_incerto.envs.deterministic_evaluation import DeterministicEvaluator
from eta_incerto.envs.pcetest import PceOrderTest
from eta_incerto.envs.pymoo_evaluation import PymooEvaluator
from eta_incerto.envs.regret_evaluation import RegretEvaluator
from eta_incerto.envs.robust_evaluation import RobustEvaluator
from eta_incerto.envs.scenario import Scenario, ScenarioCollection
from eta_incerto.envs.stochastic import StochasticScenario, StochasticScenarioCollection
from eta_incerto.envs.stochastic_evaluation import StochasticEvaluator
from eta_incerto.plotting.report import ReportPlotter
from eta_incerto.registry import get_system
from eta_incerto.tools.solver_analysis import solver_stats_from_framework
from eta_incerto.util.progress import ProgressPrinter
from eta_incerto.util.variant_loader import load_variant_data

if TYPE_CHECKING:
    import os

basicConfig(level=INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", force=True)

log = getLogger(__name__)


class EtaIncerto:
    """Orchestrator for the optimization."""

    def __init__(
        self,
        root_path: str | os.PathLike,
        config_name: str,
        relpath_config: str | os.PathLike = "config/",
    ) -> None:
        _root_path = root_path if isinstance(root_path, Path) else Path(root_path)
        __relpath_config_file = relpath_config if isinstance(relpath_config, Path) else Path(relpath_config)
        self.path_config_file = _root_path / __relpath_config_file / f"{config_name}"
        self.config: ConfigOptimization = ConfigOptimization.from_file(self.path_config_file, _root_path)
        self.scenarios = ScenarioCollection()
        self.invest_scenarios = ScenarioCollection()
        self.stochastic_scenarios = StochasticScenarioCollection()
        self.invest_stochastic_scenarios = StochasticScenarioCollection()

    # loading of data and configuration
    def load_system_series_scenario(self, system_name: str):
        """Load systems, series, energy scenarios for exactly one variant."""
        self.scenarios.clear()
        self.invest_scenarios.clear()
        self.stochastic_scenarios.clear()
        self.invest_stochastic_scenarios.clear()

        system_cls, static_data_cls, investment_data_cls, _ = get_system(system_name)
        static_data, investment_data, _ = load_variant_data(
            self.config, system_name, static_data_cls, investment_data_cls, None
        )
        system_builder = system_cls(self.config, static_data, investment_data)

        base_static_system = system_builder.build_static_system()

        total = len(self.config.series.series_file) * len(self.config.scenario.scenario_file)
        progress = ProgressPrinter(f"Loading scenarios for {system_name}", total)
        current = 0

        # ---- caches ----
        series_cache: dict[str, object] = {}  # series.file_name -> series_data
        scenario_cache: dict[tuple[str, str], object] = {}  # (series.file_name, scenario.name) -> scenario_data

        for series in self.config.series.series_file:
            dims = SimpleNamespace(
                n_years=self.config.pyomo.horizon.n_years,
                n_periods=self.config.pyomo.horizon.n_periods,
                n_time_steps=self.config.pyomo.horizon.n_time_steps,
                year_length=self.config.pyomo.horizon.year_length,
                step_length=series.step_length,
            )
            carrier_types = self.config.scenario.carrier_types

            # cache series_data (same for all scenarios for this series)
            if series.file_name not in series_cache:
                series_cache[series.file_name] = self.config.series.load_typical_day(
                    self.config,
                    dims,
                    series.file_name,
                )
            series_data = series_cache[series.file_name]

            for scenario in self.config.scenario.scenario_file:
                # cache scenario_data per (series, scenario) because dims depends on series.step_length
                sc_key = (series.file_name, scenario.name)
                if sc_key not in scenario_cache:
                    scenario_cache[sc_key] = scenario.load_supplier_data(dims, carrier_types)
                scenario_data = scenario_cache[sc_key]

                scenario_id = f"{system_name}_{series.file_name}_{scenario.name}"
                scenario_id_invest = f"{scenario_id}_invest"

                # Build dynamic system ONCE
                system_copy = deepcopy(base_static_system)
                dynamic_system = system_builder.build_dynamic_system(system_copy, series_data, scenario_data)

                # Build investment system by copying the dynamic system (cheaper than building dynamic twice)
                baseline_system = deepcopy(dynamic_system)
                investment_system = system_builder.build_investment(baseline_system)

                self.scenarios.set_scenario(
                    Scenario(
                        name=scenario_id,
                        system=dynamic_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                    )
                )

                self.invest_scenarios.set_scenario(
                    Scenario(
                        name=scenario_id_invest,
                        system=investment_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                    )
                )

                self.stochastic_scenarios.set_scenario(
                    StochasticScenario(
                        name=scenario_id,
                        system=dynamic_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                        probability=scenario.probability,
                    )
                )

                self.invest_stochastic_scenarios.set_scenario(
                    StochasticScenario(
                        name=scenario_id_invest,
                        system=investment_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                        probability=scenario.probability,
                    )
                )

                current += 1
                progress.update(current, f"{series.file_name}/{scenario.name}")

        progress.finish()
        log.info("Loaded scenarios for %s: %s", system_name, list(self.scenarios.names()))
        return self.scenarios, self.stochastic_scenarios, self.invest_scenarios, self.invest_stochastic_scenarios

    def load_stochastic_system_series_scenario(self, variant):
        """Load all systems, series, energy scenarios and store them in stochastic scenario collections."""
        stochastic_scenarios = StochasticScenarioCollection()
        invest_stochastic_scenarios = StochasticScenarioCollection()

        system_cls, static_data_cls, investment_data_cls, _ = get_system(variant)
        static_data, investment_data, _ = load_variant_data(
            self.config, variant, static_data_cls, investment_data_cls, None
        )
        system_builder = system_cls(self.config, static_data, investment_data)

        base_static_system = system_builder.build_static_system()

        total = len(self.config.series.series_file) * len(self.config.scenario.scenario_file)
        progress = ProgressPrinter(f"Loading stochastic scenarios for {variant}", total)
        current = 0

        # ---- caches ----
        series_cache: dict[str, object] = {}  # series.file_name -> series_data
        scenario_cache: dict[tuple[str, str], object] = {}  # (series.file_name, scenario.name) -> scenario_data

        for series in self.config.series.series_file:
            dims = SimpleNamespace(
                n_years=self.config.pyomo.horizon.n_years,
                n_periods=self.config.pyomo.horizon.n_periods,
                n_time_steps=self.config.pyomo.horizon.n_time_steps,
                year_length=self.config.pyomo.horizon.year_length,
                step_length=series.step_length,
            )
            carrier_types = self.config.scenario.carrier_types

            # cache series_data
            if series.file_name not in series_cache:
                series_cache[series.file_name] = self.config.series.load_typical_day(
                    self.config, dims, series.file_name
                )
            series_data = series_cache[series.file_name]

            for scenario in self.config.scenario.scenario_file:
                # cache scenario_data
                sc_key = (series.file_name, scenario.name)
                if sc_key not in scenario_cache:
                    scenario_cache[sc_key] = scenario.load_supplier_data(dims, carrier_types)
                scenario_data = scenario_cache[sc_key]

                scenario_id = f"{variant}_{series.file_name}_{scenario.name}"
                scenario_id_invest = f"{scenario_id}_invest"

                # Build dynamic system ONCE
                system_copy = deepcopy(base_static_system)
                dynamic_system = system_builder.build_dynamic_system(system_copy, series_data, scenario_data)

                # Build investment system by copying the dynamic system (cheaper than building dynamic twice)
                baseline_system = deepcopy(dynamic_system)
                investment_system = system_builder.build_investment(baseline_system)

                stochastic_scenarios.set_scenario(
                    StochasticScenario(
                        name=scenario_id,
                        system=dynamic_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                        probability=scenario.probability,
                    )
                )

                invest_stochastic_scenarios.set_scenario(
                    StochasticScenario(
                        name=scenario_id_invest,
                        system=investment_system,
                        series=series_data,
                        energy_scenario=scenario_data,
                        series_file_name=series.file_name,
                        probability=scenario.probability,
                    )
                )

                current += 1
                progress.update(current, f"{series.file_name}/{scenario.name}")

        progress.finish()
        log.info("Loaded stochastic scenarios for %s: %s", variant, list(stochastic_scenarios.names()))
        return stochastic_scenarios, invest_stochastic_scenarios

    def load_model_series_algorithm_termination(self, variant):
        """Loads the relevant component (different heat pump models) and the related distributions for the
        input parameters."""
        system_cls, static_data_cls, investment_data_cls, distribution_data_cls = get_system(variant)
        static_data, investment_data, distribution_data = load_variant_data(
            self.config, variant, static_data_cls, investment_data_cls, distribution_data_cls
        )
        model_builder = system_cls(config=self.config, investment_data=investment_data, static_data=static_data)

        demand_series = None
        for series in self.config.series.series_file:
            demand_series = self.config.series.load_series_df(self.config, series.file_name)

        log.info("Loaded model builder: %s", variant)
        return model_builder, demand_series, distribution_data

    def evaluate_pce_order(self, model_builder, distribution_data):
        """Evaluate for a variant model the PCE surrogate model quality (e.g. RMSE)."""
        surrogate_model_test = PceOrderTest(
            config=self.config,
            model_builder=model_builder,
            distribution_data=distribution_data,
            h5_file_name="pce_order_test.h5",
        )
        return surrogate_model_test.evaluate_systems()

    # deterministic invest optimization
    def evaluate_deterministic(
        self,
        scenarios: ScenarioCollection | None = None,
        h5_file_name: str | None = None,
    ):
        """Evaluate baseline scenarios.

        - If `scenarios` is provided: evaluate exactly those scenarios once.
        - Otherwise: follow the development behavior and evaluate per variant.
        """
        if scenarios is not None:
            _h5 = h5_file_name or "deterministic_operation.h5"
            evaluator = DeterministicEvaluator(config=self.config, scenarios=scenarios, h5_file_name=_h5)
            return evaluator.evaluate_systems()

        for variant in self.config.system.variant:
            _h5 = f"deterministic_operation_{variant}.h5"
            _scenarios, _, _, _ = self.load_system_series_scenario(variant)
            evaluator = DeterministicEvaluator(config=self.config, scenarios=_scenarios, h5_file_name=_h5)
            evaluator.evaluate_systems()
        return None

    def evaluate_operation_with_invest(
        self,
        invest_scenarios: ScenarioCollection | None = None,
        h5_file_name: str | None = None,
    ):
        """Attach to each built scenario the investment and evaluate.

        - If `invest_scenarios` is provided: evaluate exactly those scenarios once (old behavior).
        - Otherwise: follow the development behavior and evaluate per variant.
        """
        if invest_scenarios is not None:
            _h5 = h5_file_name or "determ_w_invest.h5"
            evaluator = DeterministicEvaluator(config=self.config, scenarios=invest_scenarios, h5_file_name=_h5)
            return evaluator.evaluate_systems()

        for variant in self.config.system.variant:
            _h5 = f"deterministic_operation_{variant}.h5"
            _, _, _invest_scenarios, _ = self.load_system_series_scenario(variant)
            evaluator = DeterministicEvaluator(config=self.config, scenarios=_invest_scenarios, h5_file_name=_h5)
            evaluator.evaluate_systems()
        return None

    # conventional invest under uncertainty optimization
    def stochastic_optimization(self) -> dict | None:
        """Attach to each built scenario the investment and stochastically evaluate.
        Returns solver_stats from the last variant's framework for run analysis."""
        last_stats = None
        for variant in self.config.system.variant:
            h5_file_name = f"stochastic_{variant}.h5"
            _, stochastic_invest_scenarios = self.load_stochastic_system_series_scenario(variant)
            evaluator = StochasticEvaluator(
                config=self.config,
                scenarios=stochastic_invest_scenarios,
                h5_file_name=h5_file_name,
                variant_name=variant,
            )
            _, fw = evaluator.evaluate_systems()
            last_stats = solver_stats_from_framework(fw)
        return last_stats

    def robust_optimization(self) -> dict | None:
        """Evaluate robust scenarios. Returns solver_stats from last variant for run analysis."""
        last_stats = None
        for variant in self.config.system.variant:
            h5_file_name = f"robust_{variant}.h5"
            _, stochastic_invest_scenarios = self.load_stochastic_system_series_scenario(variant)
            evaluator = RobustEvaluator(
                config=self.config,
                scenarios=stochastic_invest_scenarios,
                h5_file_name=h5_file_name,
            )
            _, fw = evaluator.evaluate_systems()
            last_stats = solver_stats_from_framework(fw)
        return last_stats

    def regret_optimization(self) -> dict | None:
        """Evaluate regret scenarios. Returns solver_stats from last variant for run analysis."""
        last_stats = None
        for variant in self.config.system.variant:
            h5_file_name = f"regret_{variant}.h5"
            _, stochastic_invest_scenarios = self.load_stochastic_system_series_scenario(variant)
            evaluator = RegretEvaluator(
                config=self.config,
                scenarios=stochastic_invest_scenarios,
                h5_file_name=h5_file_name,
                variant_name=variant,
            )
            _, fw = evaluator.evaluate_systems()
            last_stats = solver_stats_from_framework(fw)
        return last_stats

    def _load_single_invest_ref_scenario(self, system_name: str) -> Scenario:
        """Build exactly ONE investment scenario to use as antifragile reference (ref).

        This avoids constructing ALL scenario combinations (and the heavy deepcopy/build_* work)
        just to access invest_scenarios[0]. Build order matches full-load path: static -> dynamic -> investment.
        Picks the first entry of:
        - self.config.series.series_file
        - self.config.scenario.scenario_file
        """
        if not self.config.series.series_file:
            raise RuntimeError("No series configured (config.series.series_file is empty).")
        if not self.config.scenario.scenario_file:
            raise RuntimeError("No scenarios configured (config.scenario.scenario_file is empty).")

        series = self.config.series.series_file[0]
        scenario = self.config.scenario.scenario_file[0]

        system_cls, static_data_cls, investment_data_cls, _ = get_system(system_name)
        static_data, investment_data, _ = load_variant_data(
            self.config, system_name, static_data_cls, investment_data_cls, None
        )
        system_builder = system_cls(self.config, static_data, investment_data)

        base_static_system = system_builder.build_static_system()

        dims = SimpleNamespace(
            n_years=self.config.pyomo.horizon.n_years,
            n_periods=self.config.pyomo.horizon.n_periods,
            n_time_steps=self.config.pyomo.horizon.n_time_steps,
            year_length=self.config.pyomo.horizon.year_length,
            step_length=series.step_length,
        )
        carrier_types = self.config.scenario.carrier_types

        series_data = self.config.series.load_typical_day(self.config, dims, series.file_name)
        scenario_data = scenario.load_supplier_data(dims, carrier_types)

        # Same build order as full-load path: static -> dynamic -> investment
        system_copy = deepcopy(base_static_system)
        dynamic_system = system_builder.build_dynamic_system(system_copy, series_data, scenario_data)
        baseline_system = deepcopy(dynamic_system)
        investment_system = system_builder.build_investment(baseline_system)

        scenario_id = f"{system_name}_{series.file_name}_{scenario.name}_invest"

        return Scenario(
            name=scenario_id,
            system=investment_system,
            series=series_data,
            energy_scenario=scenario_data,
            series_file_name=series.file_name,
        )

    def antifragile_optimization(self):
        """Evaluate for each variant antifragile optimization.

        Offline-only flow: DOE with Gurobi (PCE training), then NSGA-II on surrogate.
        Config must include the "antifragile" section (offline_n_design_points, surrogate_kind).
        """
        if self.config.antifragile is None:
            raise ValueError(
                "Antifragile optimization requires config section 'antifragile' with "
                "offline_n_design_points and surrogate_kind. Add this section to your config."
            )
        for variant in self.config.system.variant:
            pdef = self.config.pymoo.for_variant(variant)
            if getattr(pdef, "mode", "invest") == "dispatch":
                continue

            h5_file_name = f"antifragile_{variant}.h5"

            model_builder, demand_series, distribution_data = self.load_model_series_algorithm_termination(variant)

            ref = self._load_single_invest_ref_scenario(variant)

            if hasattr(model_builder, "attach_inputs_from_scenario"):
                model_builder.attach_inputs_from_scenario(ref)
            else:
                model_builder.series_data = ref.series
                model_builder.scenario_data = ref.energy_scenario
                model_builder.series_file_name = getattr(ref, "series_file_name", "")

            evaluator = AntifragileEvaluator(
                config=self.config,
                variant_name=variant,
                model_builder=model_builder,
                demand_series=demand_series,
                distribution_data=distribution_data,
                h5_file_name=h5_file_name,
                variable_names=pdef.variable_names,
                objective_names=pdef.objective_names,
            )
            evaluator.evaluate_systems()

    def pymoo_pyomo_optimization(self):
        """Optimize a pyomo model with pymoo."""
        for variant in self.config.system.variant:
            pdef = self.config.pymoo.for_variant(variant)

            if getattr(pdef, "mode", "invest") == "dispatch":
                log.info("Skipping pymoo optimization for %s (dispatch-only: no pymoo variables).", variant)
                h5 = f"deterministic_operation_{variant}.h5"
                scenarios, _, _, _ = self.load_system_series_scenario(variant)
                DeterministicEvaluator(config=self.config, scenarios=scenarios, h5_file_name=h5).evaluate_systems()
                continue

            h5_file_name = f"pymoo_{variant}.h5"
            _, _, invest_scenarios, _ = self.load_system_series_scenario(variant)
            evaluator = PymooEvaluator(
                config=self.config,
                scenarios=invest_scenarios,
                h5_file_name=h5_file_name,
                variable_names=pdef.variable_names,
                objective_names=pdef.objective_names,
                x_lower_bound=pdef.x_lower_bound,
                x_upper_bound=pdef.x_upper_bound,
            )
            evaluator.evaluate_systems()

    def run_analysis(self) -> None:
        """Run optional analysis modules based on the configuration."""
        if not self.config.analysis.enabled:
            return

        if self.config.analysis.mode == "std_target":
            run_std_target_sensitivity_from_config(self.config)
            return

        raise ValueError(f"Unsupported analysis mode: {self.config.analysis.mode}")

    # plotting
    def plot_invest_summary(self):
        plotter = ReportPlotter(self.config)
        plotter.investment_summary()

    def plot_technical_summary(self):
        plotter = ReportPlotter(self.config)
        plotter.technical_summary()

    def plot_antifragile_summary(self):
        plotter = ReportPlotter(self.config)
        plotter.antifragile_summary()
