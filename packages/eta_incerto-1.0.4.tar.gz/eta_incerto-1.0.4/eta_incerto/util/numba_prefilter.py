import numpy as np
from numba import njit, prange


@njit(cache=True, fastmath=True, parallel=True)
def prefilter_margin_ok_variant_one(X, primary_side, dt_min):  # noqa: N803
    """
    X: (n, 2) with [T_CN, T_HNLT] or similar
    primary_side: (m,) constant array (e.g. cn_network["T_hot"] values)
    Returns ok mask (n,)
    """
    n = X.shape[0]
    ok = np.empty(n, dtype=np.bool_)
    for i in prange(n):
        secondary = X[i, 1]
        min_margin = 1e30
        for j in range(primary_side.shape[0]):
            m = secondary - primary_side[j] - dt_min
            min_margin = min(min_margin, m)
        ok[i] = min_margin > 0.0
    return ok


@njit(cache=True, fastmath=True, parallel=True)
def prefilter_margin_ok_variant_two(X, dt_min):  # noqa: N803
    """
    Example for 3D xi: (T_CN, T_HNLT, T_HNHT)
    Replace inequalities with your actual physical constraints.
    """
    n = X.shape[0]
    ok = np.empty(n, dtype=np.bool_)
    for i in prange(n):
        T_CN = X[i, 0]  # noqa: N806
        T_HNLT = X[i, 1]  # noqa: N806
        T_HNHT = X[i, 2]  # noqa: N806
        ok[i] = (dt_min < T_HNLT - T_CN) and (dt_min < T_HNHT - T_CN) and (dt_min < T_HNHT - T_HNLT)
    return ok
