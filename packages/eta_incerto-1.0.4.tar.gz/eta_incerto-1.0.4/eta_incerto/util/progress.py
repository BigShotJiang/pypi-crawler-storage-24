from __future__ import annotations

import logging
import re
import sys
import tempfile
import threading
import time
from collections.abc import Iterable
from pathlib import Path
from typing import TextIO

logger = logging.getLogger(__name__)


class ProgressPrinter:
    def __init__(
        self,
        label: str,
        total: int,
        *,
        stream: TextIO | None = None,
        log_every_percent: int = 5,
    ) -> None:
        self.label = label
        self.total = max(int(total), 0)
        self.stream = stream or sys.stdout
        self._start = time.perf_counter()
        self._last_len = 0
        self._last_log_percent = -1
        self._log_every_percent = max(int(log_every_percent), 1)
        self._use_tty = bool(getattr(self.stream, "isatty", lambda: False)())

    def update(self, current: int, item: str | None = None) -> None:
        if self.total <= 0:
            return

        current = min(max(int(current), 0), self.total)
        percent = int((current / self.total) * 100) if self.total else 100
        suffix = f" {item}" if item else ""

        if self._use_tty:
            bar_width = 28
            filled = int(bar_width * current / self.total)
            bar = "#" * filled + "-" * (bar_width - filled)
            msg = f"{self.label}: [{bar}] {current}/{self.total} ({percent}%)" + suffix
            self._write(msg)
        elif self._should_log(percent, current):
            logger.info(
                "%s: %d/%d (%d%%)%s",
                self.label,
                current,
                self.total,
                percent,
                suffix,
            )
            self._last_log_percent = percent

    def finish(self) -> None:
        if self.total <= 0:
            return

        elapsed = time.perf_counter() - self._start
        if self._use_tty:
            self._write(f"{self.label}: done in {elapsed:.1f}s.")
            self.stream.write("\n")
            self.stream.flush()
        else:
            logger.info("%s: done in %.1fs.", self.label, elapsed)

    def _should_log(self, percent: int, current: int) -> bool:
        if current in (1, self.total):
            return True
        if self._last_log_percent < 0:
            return True
        return percent - self._last_log_percent >= self._log_every_percent

    def _write(self, msg: str) -> None:
        pad = max(0, self._last_len - len(msg))
        self.stream.write("\r" + msg + (" " * pad))
        self.stream.flush()
        self._last_len = len(msg)


_GUROBI_GAP_RE = re.compile(r"gap\s+([0-9.+-eE]+)%", re.IGNORECASE)
_CPLEX_GAP_RE = re.compile(r"gap\s*=\s*([0-9.+-eE]+)%", re.IGNORECASE)


def _parse_gurobi_progress(lines: Iterable[str]) -> tuple[int | None, str | None]:
    for line in reversed(list(lines)):
        match = _GUROBI_GAP_RE.search(line)
        if match:
            gap = float(match.group(1))
            percent = max(1, min(99, int(round(100 - gap))))
            return percent, f"gap {gap:.1f}%"
        if "Optimal solution found" in line:
            return 99, "optimal"
    return None, None


def _parse_cplex_progress(lines: Iterable[str]) -> tuple[int | None, str | None]:
    for line in reversed(list(lines)):
        match = _CPLEX_GAP_RE.search(line)
        if match:
            gap = float(match.group(1))
            percent = max(1, min(99, int(round(100 - gap))))
            return percent, f"gap {gap:.1f}%"
        if "Optimal solution found" in line:
            return 99, "optimal"
    return None, None


def parse_solver_progress(solver_name: str, lines: Iterable[str]) -> tuple[int | None, str | None]:
    solver = solver_name.lower()
    if "gurobi" in solver:
        return _parse_gurobi_progress(lines)
    if "cplex" in solver:
        return _parse_cplex_progress(lines)
    return None, None


def _log_option_key_for_solver(solver_name: str) -> str | None:
    solver = solver_name.lower()
    if "gurobi" in solver:
        return "LogFile"
    if "cplex" in solver:
        return "logfile"
    if "glpk" in solver:
        return "log"
    return None


class SolverProgressMonitor:
    def __init__(
        self,
        label: str,
        solver_name: str,
        *,
        options: dict | None,
        tee: bool,
        stream: TextIO | None = None,
        poll_interval: float = 1.0,
    ) -> None:
        self._label = label
        self._solver_name = solver_name
        self._tee = tee
        self._options = dict(options or {})
        self._stream = stream
        self._poll_interval = max(poll_interval, 0.2)
        self._log_path: Path | None = None
        self._created_temp = False
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._printer = ProgressPrinter(label, 100, stream=stream)
        self._last_percent = 0

    def prepare_options(self) -> dict:
        if not self._tee:
            return dict(self._options)

        options = dict(self._options)
        key = _log_option_key_for_solver(self._solver_name)
        if key:
            existing = options.get(key)
            if existing:
                self._log_path = Path(str(existing))
            else:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".log") as tmp:
                    self._log_path = Path(tmp.name)
                options[key] = str(self._log_path)
                self._created_temp = True
        return options

    def start(self) -> None:
        if not self._tee or not self._log_path:
            return
        self._printer.update(1, "starting")
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._poll_log, name="solver-progress", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if not self._thread:
            return
        self._stop_event.set()
        self._thread.join(timeout=self._poll_interval * 2)
        self._printer.finish()
        if self._created_temp and self._log_path and self._log_path.exists():
            try:
                self._log_path.unlink()
            except OSError:
                logger.debug("Failed to remove solver log file: %s", self._log_path)

    def _poll_log(self) -> None:
        while not self._stop_event.is_set():
            try:
                lines = self._read_tail_lines(self._log_path, max_bytes=65536)
            except OSError:
                lines = []
            percent, status = parse_solver_progress(self._solver_name, lines)
            if percent is not None and percent != self._last_percent:
                self._last_percent = percent
                self._printer.update(percent, status)
            time.sleep(self._poll_interval)

    @staticmethod
    def _read_tail_lines(path: Path | None, max_bytes: int = 65536) -> list[str]:
        if path is None or not path.exists():
            return []
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            read_size = min(size, max_bytes)
            f.seek(-read_size, 2)
            data = f.read().decode(errors="ignore")
        return data.splitlines()
