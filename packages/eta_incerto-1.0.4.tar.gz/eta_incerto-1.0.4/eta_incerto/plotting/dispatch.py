from __future__ import annotations

# eta_incerto/plotting/dispatch.py
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext

# -----------------------------
# Public types (imported by report.py)
# -----------------------------


@dataclass(frozen=True, slots=True)
class TimeDims:
    n_years: int = 10
    n_periods: int = 7
    n_time_steps: int = 24


@dataclass(frozen=True, slots=True)
class FigureScale:
    w: float = 1.0
    h: float = 1.4


@dataclass(frozen=True, slots=True)
class DispatchOptions:
    title: str | None = None
    show_day_grid: bool = True
    show_component_prefix: bool = True


@dataclass(frozen=True, slots=True)
class HeatmapStyle:
    """Styling parameters for dispatch heatmaps."""

    cmap: str = "bwr"
    vmin: float | None = None
    vmax: float | None = None
    interpolation: str = "none"
    aspect: str = "auto"
    cbar_label: str = "W"
    show_xticks: bool = False
    xtick_count: int = 12


# -----------------------------
# Plotter
# -----------------------------


class DispatchPlotter:
    """
    Dispatch heatmap plotter.

    Expected HDF5 layout (one of these):
      A) <scenario>/unit_dispatch/units/<unit>/<component>/values (+ optional keys)
      B) scenarios/<scenario>/unit_dispatch/units/<unit>/<component>/values (+ optional keys)

    If the primary file doesn't contain dispatch, it can fall back to fallback_h5_path.

    Guarantees:
      - Centralized styling via ctx.style.rcparams
      - report.py compatibility: exposes .plot() -> Figure
      - Target layout:
          * only ONE representative year on the x-axis
          * no tight_layout() warnings (manual colorbar axis + subplots_adjust)
    """

    unit_dispatch_group: str = "unit_dispatch/units"

    def __init__(
        self,
        ctx: PlotContext,
        *,
        h5_path: str | Path,
        scenario: str | None = None,
        components: Sequence[str] | None = None,
        only_power_components_default: bool = True,
        time: TimeDims | None = None,
        options: DispatchOptions | None = None,
        scale: FigureScale | None = None,
        heatmap: HeatmapStyle | None = None,
        fallback_h5_path: str | Path | None = None,
    ) -> None:
        self.ctx = ctx

        self.h5_path = Path(h5_path)
        self.fallback_h5_path = Path(fallback_h5_path) if fallback_h5_path else None

        self.scenario = scenario
        self.components = list(components) if components is not None else None
        self.only_power_components_default = bool(only_power_components_default)

        self.time = time or TimeDims()
        self.options = options or DispatchOptions()
        self.scale = scale or FigureScale()
        self.heatmap = heatmap or HeatmapStyle()

    # -------------------------
    # Small HDF5 helpers
    # -------------------------

    @staticmethod
    def _is_group(obj: Any) -> bool:
        return isinstance(obj, h5py.Group)

    def _list_top_groups(self, path: Path) -> list[str]:
        with h5py.File(path, "r") as f:
            return [k for k in f if self._is_group(f[k])]

    def _candidate_scenarios(self, path: Path) -> list[str]:
        """
        Prefer explicit 'scenarios/<name>' if present, otherwise use top-level groups.
        IMPORTANT: do NOT exclude '__expected__' because dispatch may live there.
        """
        banned = {"config", "meta", "topology", "__meta__"}

        with h5py.File(path, "r") as f:
            if "scenarios" in f and self._is_group(f["scenarios"]):
                scen_grp = f["scenarios"]
                names = [k for k in scen_grp if self._is_group(scen_grp[k])]
                return sorted([n for n in names if n not in banned])

            top = [k for k in f if self._is_group(f[k])]
            return sorted([k for k in top if k not in banned and k != "scenarios"])

    def _scenario_prefix_candidates(self, scenario: str) -> list[str]:
        """
        Try:
        - "<scenario>"
        - "scenarios/<scenario>"
        PLUS: if dispatch is stored under __expected__, also allow that.
        """
        prefixes = [str(scenario), f"scenarios/{scenario}"]
        if "__expected__" not in prefixes:
            prefixes.append("__expected__")
        return prefixes

    def _find_dispatch_base(self, path: Path, scenario: str) -> str | None:
        """Return base path like "<prefix>/unit_dispatch/units" if exists."""
        with h5py.File(path, "r") as f:
            for prefix in self._scenario_prefix_candidates(scenario):
                base = f"{prefix}/{self.unit_dispatch_group}"
                if base in f:
                    return base
        return None

    def _ensure_dispatch_source(self) -> tuple[Path, str, str]:
        """
        Decide which file to use (primary or fallback), which scenario, and which base group.
        Returns: (active_path, scenario, base_group)
        """
        # 1) choose scenario
        scenario = self.scenario
        if scenario is None:
            cands = self._candidate_scenarios(self.h5_path)
            scenario = cands[0] if cands else None

        if scenario is None:
            raise ValueError(
                f"No scenarios found in {self.h5_path}. Top-level groups: {self._list_top_groups(self.h5_path)}"
            )

        # 2) try primary
        base = self._find_dispatch_base(self.h5_path, str(scenario))
        if base is not None:
            return self.h5_path, str(scenario), base

        # 3) fallback if provided
        if self.fallback_h5_path and self.fallback_h5_path.exists():
            fb_scenario = str(scenario)
            fb_base = self._find_dispatch_base(self.fallback_h5_path, fb_scenario)
            if fb_base is None:
                fb_cands = self._candidate_scenarios(self.fallback_h5_path)
                if fb_cands:
                    fb_scenario = fb_cands[0]
                    fb_base = self._find_dispatch_base(self.fallback_h5_path, fb_scenario)

            if fb_base is not None:
                return self.fallback_h5_path, fb_scenario, fb_base

        # 4) nothing found
        raise KeyError(
            "Dispatch group not found.\n"
            f"  Expected: <scenario>/{self.unit_dispatch_group} OR scenarios/<scenario>/{self.unit_dispatch_group}\n"
            f"  Primary file: {self.h5_path}\n"
            f"    scenarios detected: {self._candidate_scenarios(self.h5_path)}\n"
            f"  Fallback file: {self.fallback_h5_path if self.fallback_h5_path else '(none)'}\n"
        )

    # -------------------------
    # Data discovery / loading
    # -------------------------

    @staticmethod
    def _decode_bytes_array(arr: np.ndarray) -> list[str]:
        if getattr(arr.dtype, "kind", None) not in {"S", "O"}:
            return [str(x) for x in arr.tolist()]

        out: list[str] = []
        for item in arr:
            if isinstance(item, (bytes, np.bytes_)):
                out.append(item.decode("utf-8", errors="replace"))
            else:
                out.append(str(item))
        return out

    def list_components(self, active_path: Path, base: str, *, only_power: bool) -> list[str]:
        comps: set[str] = set()
        with h5py.File(active_path, "r") as f:
            if base not in f:
                return []
            units_group = f[base]
            for unit in units_group:
                ug = units_group[unit]
                if not self._is_group(ug):
                    continue
                for comp in ug:
                    comp_name = str(comp)
                    if only_power and not comp_name.startswith("p_"):
                        continue
                    comps.add(comp_name)
        return sorted(comps)

    def load_components_matrix(
        self,
        *,
        active_path: Path,
        base: str,
        components: Sequence[str],
        fill_missing: float = np.nan,
        row_order: Sequence[tuple[str, str]] | None = None,
    ) -> pd.DataFrame:
        with h5py.File(active_path, "r") as f:
            if base not in f:
                raise KeyError(f"'{base}' not found in file {active_path}.")

            units_group = f[base]
            units = sorted([u for u in units_group if self._is_group(units_group[u])])

            values_by_row: dict[tuple[str, str], np.ndarray] = {}
            index_keys: list[str] | None = None
            n_steps = 0

            for unit in units:
                ug = units_group[unit]
                for comp in components:
                    if comp not in ug:
                        continue
                    cg = ug[comp]
                    if not self._is_group(cg) or "values" not in cg:
                        continue

                    vals = np.asarray(cg["values"], dtype=float).reshape(-1)  # use values as stored in H5

                    if index_keys is None and "keys" in cg:
                        keys_arr = np.asarray(cg["keys"])
                        index_keys = self._decode_bytes_array(keys_arr)

                    values_by_row[(str(unit), str(comp))] = vals
                    n_steps = max(n_steps, len(vals))

        if not values_by_row:
            raise KeyError(f"No dispatch data found under '{base}' for components={list(components)}")

        if index_keys is None or len(index_keys) != n_steps:
            index_keys = [str(i) for i in range(n_steps)]

        rows = list(row_order) if row_order is not None else sorted(values_by_row, key=lambda x: (x[0], x[1]))

        mat = np.full((len(rows), n_steps), fill_missing, dtype=float)
        for i, rc in enumerate(rows):
            v = values_by_row[rc]
            if len(v) < n_steps:
                v = np.pad(v, (0, n_steps - len(v)), constant_values=np.nan)
            mat[i, :] = v[:n_steps]

        return pd.DataFrame(
            mat,
            index=pd.MultiIndex.from_tuples(rows, names=["unit", "component"]),
            columns=index_keys,
        )

    # -------------------------
    # Plot helpers
    # -------------------------

    @staticmethod
    def add_year_separators_and_labels(
        ax: Axes,
        *,
        n_years: int,
        n_periods: int,
        n_time_steps: int,
        show_day_grid: bool = True,
        day_grid_alpha: float = 0.18,
        year_line_width: float = 1.6,
        year_line_alpha: float = 0.7,
    ) -> None:
        steps_per_year = n_periods * n_time_steps
        total_steps = n_years * steps_per_year

        for y in range(1, n_years):
            x = y * steps_per_year - 0.5
            ax.axvline(x, linewidth=year_line_width, alpha=year_line_alpha)

        if show_day_grid:
            for x in range(n_time_steps, total_steps, n_time_steps):
                ax.axvline(x - 0.5, linewidth=0.6, alpha=day_grid_alpha)

        centers = np.array([y * steps_per_year + (steps_per_year - 1) / 2 for y in range(n_years)], dtype=float)
        ax.set_xticks(centers)
        ax.set_xticklabels([f"Y{y + 1}" for y in range(n_years)], fontsize=9)
        ax.set_xlabel("Representative year" if n_years == 1 else "Representative week per year (Y1..Yn)")

    def _resolve_vmin_vmax(self, data: np.ndarray, finite: np.ndarray) -> tuple[float, float]:
        vmin, vmax = self.heatmap.vmin, self.heatmap.vmax
        if vmin is None or vmax is None:
            max_abs = float(np.nanmax(np.abs(data[finite]))) if finite.any() else 1.0
            max_abs = max(max_abs, 1e-9)
            vmin = -max_abs if vmin is None else vmin
            vmax = +max_abs if vmax is None else vmax
        return float(vmin), float(vmax)

    # -------------------------
    # Public API (used by report.py)
    # -------------------------

    def plot(self) -> Figure:
        """ReportPlotter expects .plot() -> Figure."""
        active_path, scenario, base = self._ensure_dispatch_source()

        # choose components
        if self.components is None:
            comps = self.list_components(active_path, base, only_power=self.only_power_components_default)
            if not comps:
                raise ValueError(
                    f"No components found under '{base}' in {active_path} "
                    f"(only_power={self.only_power_components_default})."
                )
            components = comps
        else:
            components = list(self.components)

        combined = self.load_components_matrix(
            active_path=active_path,
            base=base,
            components=components,
        )

        # ---- TARGET DESIGN: only ONE representative year ----
        steps_per_year = int(self.time.n_periods) * int(self.time.n_time_steps)
        if combined.shape[1] > steps_per_year:
            combined = combined.iloc[:, :steps_per_year]

        data = combined.to_numpy(dtype=float)
        masked = np.ma.masked_invalid(data)
        finite = np.isfinite(data)
        if not finite.any():
            raise ValueError("No finite values to plot.")

        vmin, vmax = self._resolve_vmin_vmax(data, finite)

        # figure sizing
        fig_w = float(self.ctx.style.fig_w_in) * float(self.scale.w)
        fig_h = float(self.ctx.style.fig_h_in) * float(self.scale.h)

        # Centralized styling
        with plt.rc_context(self.ctx.style.rcparams):
            fig, ax = plt.subplots(figsize=(fig_w, fig_h), constrained_layout=False)

            im = ax.imshow(
                masked,
                cmap=self.heatmap.cmap,
                vmin=vmin,
                vmax=vmax,
                aspect=self.heatmap.aspect,
                interpolation=self.heatmap.interpolation,
            )
            im.cmap.set_bad(color="lightgray")

            # x-axis formatting (ONE year)
            ax.set_xticks([])
            self.add_year_separators_and_labels(
                ax,
                n_years=1,  # force target design
                n_periods=int(self.time.n_periods),
                n_time_steps=int(self.time.n_time_steps),
                show_day_grid=bool(self.options.show_day_grid),
            )

            # y-axis formatting
            idx = combined.index
            if self.options.show_component_prefix:
                ylabels = [f"{u} | {c}" for (u, c) in idx.to_list()]
                ax.set_ylabel("Unit | Component")
            else:
                ylabels = [f"{u}-{c}" for (u, c) in idx.to_list()]
                ax.set_ylabel("Unit-Component")

            ax.set_yticks(np.arange(len(ylabels)))
            ax.set_yticklabels(ylabels, fontsize=8)
            for label in ax.get_yticklabels():
                label.set_horizontalalignment("right")

            # title
            stem = active_path.stem
            title = self.options.title
            ax.set_title(str(title) if title else f"{stem} | {scenario} | dispatch")

            # ---- Deterministic layout (NO tight_layout warning) ----
            fig.subplots_adjust(
                left=0.32,  # space for "unit | component"
                right=0.92,  # reserve space for colorbar
                top=0.92,
                bottom=0.10,
            )

            # colorbar axis placed AFTER subplots_adjust
            ax_pos = ax.get_position().get_points().flatten()
            cax = fig.add_axes(
                [
                    0.93,
                    ax_pos[1] + 0.05,
                    0.012,
                    ax_pos[3] - ax_pos[1] - 0.10,
                ]
            )
            cbar = fig.colorbar(im, ax=ax, cax=cax)
            fmt = mticker.ScalarFormatter(useMathText=True)
            fmt.set_scientific(True)
            fmt.set_powerlimits((-1, 1))
            cbar.ax.yaxis.set_major_formatter(fmt)
            # Place scientific notation multiplier to the right of the colorbar, not above the unit label
            offset_text = cbar.ax.yaxis.get_offset_text()
            offset_text.set_ha("left")
            offset_text.set_position((1.12, 1.0))

            # label above bar
            pos = cax.get_position()
            fig.text(
                pos.x0 + pos.width / 2,
                pos.y1 + 0.01,
                self.heatmap.cbar_label,
                ha="center",
                va="bottom",
                rotation=90,
            )

            return fig
