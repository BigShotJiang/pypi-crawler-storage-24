# eta_incerto/plotting/doe.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext


@dataclass(frozen=True, slots=True)
class DoeFigureDefaults:
    ncols: int = 2
    w_scale: float = 1.0
    h_scale: float = 1.2


class DoePlotter(PlotterBase):
    """Design-point DOE scatter plotter + Sobol index visualizations.

    ReportPlotter-compatible:
      - does NOT save
      - returns matplotlib Figure(s)
      - resolves input file(s) from config.plots.design_doe

    Expected HDF5 layout (preferred):
      design_points/X
      design_points/F
      design_points/variable_names
      design_points/objective_names
    Backward compatibility: doe/... is also accepted.

    Optional Sobol layout:
      design_points/sobol/<metric>/S1 (or doe/sobol/...)

    Foundation rules:
      - no fig.suptitle(...) in plotters
      - no fig.tight_layout/subplots_adjust in plotters
      - figures finalized via PlotterBase.finalize_figure()
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)
        cfg = getattr(ctx.config.plots, "design_doe", None) or getattr(ctx.config.plots, "doe", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.doe (or config.plots.design_doe)")

        file_attr = getattr(cfg, "file", None)
        src = file_attr if file_attr is not None else cfg

        if isinstance(src, (str, Path)):
            self.h5_paths = [results_dir / str(src)]
        else:
            self.h5_paths = [results_dir / str(p) for p in list(src)]

        if not self.h5_paths:
            raise ValueError("config.plots.doe is empty")

        self._cfg = cfg
        self._cache: dict[Path, tuple[pd.DataFrame, list[str], list[str]]] = {}

    # -------------------------
    # Loading
    # -------------------------
    @staticmethod
    def _decode_names(arr: Any) -> list[str]:
        out: list[str] = []
        for n in np.asarray(arr):
            if isinstance(n, (bytes, np.bytes_)):
                out.append(n.decode("utf-8", errors="replace"))
            else:
                out.append(str(n))
        return out

    @staticmethod
    def _design_points_group(f: h5py.File) -> str:
        """Return HDF5 group name for design points: 'design_points' (preferred) or 'doe' (legacy)."""
        for name in ("design_points", "doe"):
            if name in f and "X" in f[name]:
                return name
        raise KeyError("Expected 'design_points' or 'doe' group with X, F, variable_names, objective_names")

    def _load_h5(self, h5_path: Path) -> tuple[pd.DataFrame, list[str], list[str]]:
        if h5_path in self._cache:
            return self._cache[h5_path]

        with h5py.File(h5_path, "r") as f:
            grp = self._design_points_group(f)
            doe_x = np.asarray(f[f"{grp}/X"], dtype=float)
            doe_f = np.asarray(f[f"{grp}/F"], dtype=float)

            var_names = self._decode_names(f[f"{grp}/variable_names"][:])
            obj_names = self._decode_names(f[f"{grp}/objective_names"][:])

        h5_df = pd.DataFrame(np.hstack([doe_x, doe_f]), columns=var_names + obj_names)
        self._cache[h5_path] = (h5_df, var_names, obj_names)
        return h5_df, var_names, obj_names

    # -------------------------
    # Tick helper (kept local; small + plot-specific)
    # -------------------------
    @staticmethod
    def _reduce_ticks(ax: plt.Axes, *, xdata: np.ndarray, ydata: np.ndarray) -> None:
        if xdata.size >= 2:
            xmin, xmax = float(np.nanmin(xdata)), float(np.nanmax(xdata))
            xmid = 0.5 * (xmin + xmax)
            ax.set_xticks([xmin, xmid, xmax])
        if ydata.size >= 2:
            ymin, ymax = float(np.nanmin(ydata)), float(np.nanmax(ydata))
            ymid = 0.5 * (ymin + ymax)
            ax.set_yticks([ymin, ymid, ymax])

    def _rc_context(self) -> dict[str, Any]:
        cfg = self._cfg
        extra_rc = dict(getattr(cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    # -------------------------
    # PlotID payload (stable)
    # -------------------------
    def _plotid_payload(self, *, h5_path: Path, kind: str, details: dict[str, Any]) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "doe",
            "kind": str(kind),  # "scatter" | "sobol"
            "h5_path": str(h5_path),
            "preset": getattr(self.ctx, "preset_name", None),
            "details": details,
        }

    # -------------------------
    # Public API
    # -------------------------
    def make_figure(self) -> Figure:
        """Return DOE scatter figure for the first configured DOE file."""
        return self.make_figures()[0]

    def make_figures(self) -> list[Figure]:
        cfg = self._cfg
        defaults = DoeFigureDefaults()

        subplots = getattr(cfg, "subplots", None)

        figs: list[Figure] = []
        for h5_path in self.h5_paths:
            df, _var_names, obj_names = self._load_h5(h5_path)

            if subplots:
                subplot_confs = list(subplots)
                nplots = max(int(getattr(c, "subplot", 0)) for c in subplot_confs) + 1
            else:
                # Fallback: plot all objective pairs
                pairs = [
                    (obj_names[i], obj_names[j]) for i in range(len(obj_names)) for j in range(i + 1, len(obj_names))
                ]
                subplot_confs = [
                    type(
                        "_Tmp",
                        (),
                        {
                            "x": x,
                            "y": y,
                            "subplot": k,
                            "xlabel": x,
                            "ylabel": y,
                            "title": None,
                            "color": None,
                            "color_label": None,
                        },
                    )
                    for k, (x, y) in enumerate(pairs)
                ]
                nplots = len(subplot_confs)

            ncols = int(getattr(cfg, "ncols", defaults.ncols))
            nrows = int(np.ceil(nplots / ncols)) if nplots else 1

            w_scale = float(getattr(cfg, "w_scale", defaults.w_scale))
            h_scale = float(getattr(cfg, "h_scale", defaults.h_scale))

            payload = self._plotid_payload(
                h5_path=h5_path,
                kind="scatter",
                details={
                    "nrows": nrows,
                    "ncols": ncols,
                    "w_scale": w_scale,
                    "h_scale": h_scale,
                    "subplots": [
                        {
                            "subplot": int(getattr(conf, "subplot", 0)),
                            "x": str(conf.x),
                            "y": str(conf.y),
                            "xlabel": getattr(conf, "xlabel", None),
                            "ylabel": getattr(conf, "ylabel", None),
                            "title": getattr(conf, "title", None),
                            "color": getattr(conf, "color", None),
                            "color_label": getattr(conf, "color_label", None),
                        }
                        for conf in subplot_confs
                    ],
                },
            )

            fig, axs = self.make_figure(
                nrows=nrows,
                ncols=ncols,
                plot_id_payload=payload,
                squeeze=False,
            )

            # scale relative to preset base size
            try:
                w, h = fig.get_size_inches()
                fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
            except Exception:
                pass

            axs_arr = np.atleast_1d(axs).reshape(-1)
            used_axes: set[int] = set()

            with plt.rc_context(self._rc_context()):
                for conf in subplot_confs:
                    x, y = str(conf.x), str(conf.y)
                    idx = int(getattr(conf, "subplot", 0))
                    if idx < 0 or idx >= len(axs_arr):
                        raise IndexError(
                            f"subplot index {idx} out of range for nrows={nrows}, ncols={ncols} (axes={len(axs_arr)})"
                        )

                    ax = axs_arr[idx]
                    used_axes.add(idx)

                    cvar = getattr(conf, "color", None)
                    if cvar and str(cvar) in df.columns:
                        cvar = str(cvar)
                        sc = ax.scatter(df[x], df[y], c=df[cvar], cmap="plasma", edgecolors="k", s=20)
                        fig.colorbar(sc, ax=ax, label=str(getattr(conf, "color_label", None) or cvar))
                    else:
                        ax.scatter(df[x], df[y], s=20, c="0.35", alpha=0.7)

                    # plot-specific tick reduction
                    self._reduce_ticks(ax, xdata=df[x].to_numpy(dtype=float), ydata=df[y].to_numpy(dtype=float))

                    # centralized axis formatting
                    xlabel = str(getattr(conf, "xlabel", None) or x)
                    ylabel = str(getattr(conf, "ylabel", None) or y)
                    title = getattr(conf, "title", None)

                    self.ctx.style.apply_axis_format(
                        ax,
                        title=str(title) if title else None,
                        xlabel=xlabel,
                        ylabel=ylabel,
                        grid=False,
                        tick_style=getattr(cfg, "tick_style", None),
                    )

            # remove unused axes
            for i, ax in enumerate(axs_arr):
                if i not in used_axes:
                    fig.delaxes(ax)

            figs.append(self.finalize_figure(fig, title=None, layout_policy="constrained"))

        return figs

    def make_sobol_figures(self) -> list[Figure]:
        """Return one figure per Sobol metric group (if available in the DOE file)."""
        cfg = self._cfg
        figs: list[Figure] = []

        dist_names = getattr(self.ctx.config, "dist_names", None)

        for h5_path in self.h5_paths:
            _, var_names, _ = self._load_h5(h5_path)
            var_labels = list(dist_names) if dist_names is not None else var_names

            with h5py.File(h5_path, "r") as f:
                grp = self._design_points_group(f)
                sobol_path = f"{grp}/sobol"
                if sobol_path not in f:
                    continue
                sobol_root = f[sobol_path]
                metrics = sorted(sobol_root.keys())

                for metric in metrics:
                    base = sobol_root[metric]
                    s1 = np.asarray(base["S1"][:], dtype=float)
                    st = np.asarray(base["ST"][:], dtype=float)
                    s2 = np.asarray(base["S2"][:], dtype=float)

                    w_scale = float(getattr(cfg, "w_scale", 1.0))
                    h_scale = float(getattr(cfg, "h_scale", 1.2))

                    payload = self._plotid_payload(
                        h5_path=h5_path,
                        kind="sobol",
                        details={
                            "metric": str(metric),
                            "w_scale": w_scale,
                            "h_scale": h_scale,
                            "vars": list(var_labels),
                        },
                    )

                    fig, axs = self.make_figure(
                        nrows=1,
                        ncols=2,
                        plot_id_payload=payload,
                        squeeze=False,
                    )

                    # scale relative to preset base size
                    try:
                        w, h = fig.get_size_inches()
                        fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
                    except Exception:
                        pass

                    axs_arr = np.atleast_1d(axs).reshape(-1)
                    if len(axs_arr) < 2:
                        raise RuntimeError("Expected 2 axes for Sobol figure (ncols=2).")

                    ax1, ax2 = axs_arr[0], axs_arr[1]

                    with plt.rc_context(self._rc_context()):
                        # left: S1/ST bars
                        x = np.arange(len(var_labels), dtype=float)
                        width = 0.35
                        ax1.bar(x - width / 2, s1, width, label="S1")
                        ax1.bar(x + width / 2, st, width, label="ST")
                        ax1.set_xticks(x)
                        ax1.set_xticklabels(var_labels, rotation=45, ha="right")
                        ax1.legend()

                        self.ctx.style.apply_axis_format(
                            ax1,
                            title=f"S1 / ST ({metric})",
                            xlabel=None,
                            ylabel="Sobol index",
                            grid=False,
                            tick_style=getattr(cfg, "tick_style", None),
                        )

                        # right: S2 heatmap (imshow only, no seaborn)
                        im = ax2.imshow(s2, aspect="auto")
                        ax2.set_xticks(np.arange(len(var_labels)))
                        ax2.set_yticks(np.arange(len(var_labels)))
                        ax2.set_xticklabels(var_labels, rotation=45, ha="right")
                        ax2.set_yticklabels(var_labels)

                        cbar = fig.colorbar(im, ax=ax2)
                        cbar.set_label("S2")

                        self.ctx.style.apply_axis_format(
                            ax2,
                            title=None,
                            xlabel=None,
                            ylabel=None,
                            grid=False,
                            tick_style=getattr(cfg, "tick_style", None),
                        )

                    fig_title = f"Sobol indices: {metric} ({h5_path.stem})"
                    figs.append(self.finalize_figure(fig, title=fig_title, layout_policy="constrained"))

        return figs
