from __future__ import annotations

# eta_incerto/plotting/table.py
from dataclasses import dataclass
from math import floor, log10
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint (given): 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0  # 6.319444...
_MAX_H_IN = 650.0 / 72.0  # 9.027777...

# Store payload on figure objects so the exporter can write it into meta.json
_PLOT_PAYLOAD_ATTR = "_eta_incerto_plot_payload"


def _set_plot_payload(fig: plt.Figure, payload: dict[str, Any]) -> None:
    try:
        setattr(fig, _PLOT_PAYLOAD_ATTR, payload)
    except Exception:
        pass


@dataclass(frozen=True)
class TableSpec:
    """
    Single point of configuration for table layout + scaling.

    IMPORTANT: This plotter must obey a hard size cap for reports:
      max = 455pt x 650pt.
    """

    # --- hard caps (benchmark) ---
    max_w_in: float = _MAX_W_IN
    max_h_in: float = _MAX_H_IN

    # --- geometry (inches) ---
    row_h_in: float = 0.28
    header_h_in: float = 0.45
    title_h_in: float = 0.28
    col_w_in: float = 1.05

    # --- minimum figure sizes (inches) ---
    min_w_in: float = 4.8
    min_h_in: float = 3.0

    # --- table positioning (axes coords) ---
    bbox: tuple[float, float, float, float] = (0.02, 0.05, 0.96, 0.88)

    # --- column width distribution inside bbox (relative) ---
    label_col_frac: float = 0.55

    # --- font scaling ---
    base_fontsize: float = 8.0
    min_fontsize: float = 5.0
    shrink_after_rows: int = 18
    shrink_after_cols: int = 6
    row_shrink_strength: float = 0.9
    col_shrink_strength: float = 0.9

    # --- additional fitting controls ---
    # allow the run columns to vary by content, without changing overall table width
    enable_variable_col_widths: bool = True
    # give header a bit more influence on width calculation
    header_weight: float = 1.2
    # clamp per-run column fractions so one column can't steal everything
    min_run_col_frac: float = 0.06
    max_run_col_frac: float = 0.18

    # optional: per-cell shrink if still overflowing
    enable_cell_font_shrink: bool = True
    cell_shrink_min_fontsize: float = 4.5

    # --- style ---
    title: str = "KPI Table"
    title_fontsize: float = 9.0
    # Vertical position of the table title (slightly closer than default,
    # but not too tight above the table).
    title_y: float = 0.86
    section_facecolor: tuple[float, float, float] = (0.95, 0.95, 0.95)
    header_linewidth: float = 1.0
    section_linewidth: float = 1.0


class TablePlotter(PlotterBase):
    """
    Config-driven KPI table.

    Reads:
      ctx.config.plots.invest_table = ["res_a.h5", "res_b.h5", ...]

    Assumes:
      - each name is a result file under config.paths.results_dir
      - expected values are scalar datasets below /__expected__/...

    Returns Figure(s). Does NOT save.
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)
        self._spec = TableSpec()

    @staticmethod
    def _unit_for_path(section: str, rel: str) -> tuple[float, str]:
        """Return (display_scale, unit_label). H5 is source of truth; no conversion in plotting."""
        # Use values as stored in H5 (scale 1.0). Unit from H5 when available; no brackets in labels.
        return (1.0, "")

    # ---------- IO ----------
    def _h5_path(self, res_name: str) -> Path:
        return Path(self.ctx.config.paths.results_dir) / res_name

    @staticmethod
    def _is_scalar(ds: h5py.Dataset) -> bool:
        shape = getattr(ds, "shape", None)
        return shape in ((), (1,))

    @staticmethod
    def _read_scalar(ds: h5py.Dataset) -> float:
        v = ds[()]
        if hasattr(v, "shape") and v.shape == (1,):
            v = v[0]
        return float(v)

    @staticmethod
    def _fmt(x: float, nd: int = 2, scale: float = 1.0) -> str:
        """
        Format numbers in LaTeX-like scientific notation so they are short
        and render with a superscript exponent in matplotlib, e.g.
        1.98 x 10^8 becomes ``$1.98 x 10^{8}$``.
        """
        v = float(x) * scale
        if v == 0.0:
            return "0"

        sign = "-" if v < 0 else ""
        av = abs(v)
        try:
            exp = int(floor(log10(av)))
        except ValueError:
            # Fallback for extremely small/invalid values
            return f"{v:.{nd}e}"

        mant = av / (10**exp)
        # Use mathtext so matplotlib renders the exponent as a superscript,
        # but keep a plain 'x' between mantissa and 10 (no \\cdot).
        return f"${sign}{mant:.{nd}f} x 10^{{{exp}}}$"

    def _display_name(self, res_name: str) -> str:
        s = res_name
        if s.endswith(".h5"):
            s = s[:-3]
        return (
            s.replace("deterministic_variant_one", "deterministic_v1")
            .replace("stochastic_variant_one", "stochastic_v1")
            .replace("regret_variant_one", "regret_v1")
            .replace("robust_variant_one", "robust_v1")
            .replace("deterministic_variant_two", "deterministic_v2")
            .replace("stochastic_variant_two", "stochastic_v2")
            .replace("regret_variant_two", "regret_v2")
            .replace("robust_variant_two", "robust_v2")
        )

    def _iter_scalar_datasets(self, f: h5py.File, base: str) -> list[tuple[str, h5py.Dataset]]:
        grp = f[base]
        out: list[tuple[str, h5py.Dataset]] = []

        def _walk(g: h5py.Group, prefix: str) -> None:
            for k, obj in g.items():
                if isinstance(obj, h5py.Dataset):
                    if self._is_scalar(obj):
                        out.append((f"{prefix}{k}", obj))
                elif isinstance(obj, h5py.Group):
                    _walk(obj, f"{prefix}{k}/")

        _walk(grp, "")
        out.sort(key=lambda x: x[0])
        return out

    def _build_rows(self, f_by_res: dict[str, h5py.File]) -> list[list[str]]:
        if not f_by_res:
            return []

        rows: list[list[str]] = []
        first_file = next(iter(f_by_res.values()))
        base = "__expected__"
        if base not in first_file:
            raise KeyError(f"Group '/{base}' not found in file '{first_file.filename}'")

        def add_section(name: str) -> None:
            rows.append([name, *([""] * len(f_by_res))])

        def fmt_value(f: h5py.File, path: str, scale: float = 1.0) -> str:
            # No decision available (path missing or not a scalar) -> dash.
            # Decision available but investment not done (value 0) -> "0".
            try:
                obj = f[path]
            except KeyError:
                return "—"
            if not isinstance(obj, h5py.Dataset) or not self._is_scalar(obj):
                return "—"
            try:
                val = self._read_scalar(obj)
            except Exception:
                return "—"
            if val == 0.0:
                return "0"
            return self._fmt(val, nd=2, scale=scale)

        # Exclude unit_dispatch section from table (handled by dispatch plotter).
        # Union sections and (per section) scalar paths across all files so all
        # investment components (and other rows) from any file are included.
        all_sections: set[str] = set()
        for f in f_by_res.values():
            if base not in f:
                continue
            for k in f[base]:
                sec_path = f"{base}/{k}"
                if isinstance(f[sec_path], h5py.Group):
                    all_sections.add(k)
        sections = sorted(all_sections)

        for sec in sections:
            if str(sec).strip().lower().replace(" ", "_") == "unit_dispatch":
                continue
            sec_path = f"{base}/{sec}"

            add_section(sec)

            # Union of all scalar dataset paths in this section across files.
            all_rel: set[str] = set()
            for f in f_by_res.values():
                if sec_path not in f or not isinstance(f[sec_path], h5py.Group):
                    continue
                for rel, _ in self._iter_scalar_datasets(f, sec_path):
                    all_rel.add(rel)
            for rel in sorted(all_rel):
                full_rel = f"{sec}/{rel}"
                scale, _ = self._unit_for_path(sec, rel)
                label = rel
                vals = [fmt_value(f, f"{base}/{full_rel}", scale) for f in f_by_res.values()]
                rows.append([label, *vals])

        return rows

    # ---------- sizing ----------
    def _max_body_rows_per_figure(self, has_title: bool = True) -> int:
        """Max body rows per figure so height stays within benchmark (455pt x 650pt)."""
        ts = self._spec
        title_h = ts.title_h_in if has_title else 0.0
        available = _MAX_H_IN - ts.header_h_in - title_h
        max_table_rows = max(1, int(available / ts.row_h_in))
        return max(0, max_table_rows - 1)

    def _section_boundaries(self, rows: list[list[str]], ncols: int) -> list[int]:
        """Return row indices that start a section (section header rows)."""
        indices: list[int] = [0]
        for r, row in enumerate(rows):
            if not row or r == 0:
                continue
            is_section = all((c >= len(row) or row[c] == "") for c in range(1, ncols))
            if is_section and row[0]:
                indices.append(r)
        return indices

    def _chunk_rows_by_max_height(self, rows: list[list[str]], ncols: int, max_body_rows: int) -> list[list[list[str]]]:
        """
        Split rows into chunks so each chunk has at most max_body_rows rows.
        Splits at section boundaries when possible so sections are not cut in the middle.
        """
        if max_body_rows <= 0 or not rows:
            return [rows] if rows else []
        boundaries = self._section_boundaries(rows, ncols)
        chunks: list[list[list[str]]] = []
        start = 0
        while start < len(rows):
            end_candidate = min(start + max_body_rows, len(rows))
            # Prefer to end at a section boundary so the next chunk starts with a section header
            end = end_candidate
            for b in boundaries:
                if start < b <= end_candidate:
                    end = b
                elif b > end_candidate:
                    break
            if end <= start:
                end = end_candidate
            chunk = rows[start:end]
            if chunk:
                chunks.append(chunk)
            start = end
        return chunks if chunks else [rows]

    def _desired_size_in(self, *, n_body_rows: int, ncols: int, has_title: bool) -> tuple[float, float]:
        ts = self._spec
        n_table_rows = n_body_rows + 1

        desired_h = ts.header_h_in + n_table_rows * ts.row_h_in + (ts.title_h_in if has_title else 0.0)
        desired_w = ncols * ts.col_w_in

        desired_h = min(ts.max_h_in, max(ts.min_h_in, desired_h))
        desired_w = min(ts.max_w_in, max(ts.min_w_in, desired_w))

        # hard clamp to benchmark
        desired_w = min(desired_w, _MAX_W_IN)
        desired_h = min(desired_h, _MAX_H_IN)

        return float(desired_w), float(desired_h)

    def _auto_fontsize(self, *, n_body_rows: int, ncols: int) -> float:
        ts = self._spec

        r = max(0, n_body_rows - ts.shrink_after_rows) / max(1.0, float(ts.shrink_after_rows))
        c = max(0, ncols - ts.shrink_after_cols) / max(1.0, float(ts.shrink_after_cols))

        fs = ts.base_fontsize / (1.0 + ts.row_shrink_strength * r + ts.col_shrink_strength * c)
        return max(ts.min_fontsize, float(fs))

    def _clamp_figsize(self, fig: plt.Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    # ---------- column width computation ----------
    def _compute_col_fracs(
        self,
        *,
        col_labels: list[str],
        rows: list[list[str]],
        label_col_frac: float,
    ) -> list[float]:
        """
        Compute per-column width fractions within the table bbox.

        Keeps overall width fixed: sum(fracs) == 1.0
        Column 0 uses label_col_frac, remaining width is distributed across data columns
        based on longest string in each column (header + body).
        """
        ts = self._spec
        ncols = len(col_labels)
        if ncols <= 1:
            return [1.0]

        label_frac = min(0.90, max(0.10, float(label_col_frac)))
        remain = 1.0 - label_frac
        if remain <= 0:
            return [1.0] + [0.0] * (ncols - 1)

        weights: list[float] = []
        for c in range(1, ncols):
            header_len = len(str(col_labels[c])) * float(ts.header_weight)
            body_len = 0.0
            for r in rows:
                if c < len(r):
                    body_len = max(body_len, float(len(str(r[c]))))
            w = max(1.0, header_len, body_len)
            weights.append(w)

        s = sum(weights) if weights else 1.0
        fracs_run = [remain * (w / s) for w in weights]

        minf = float(ts.min_run_col_frac)
        maxf = float(ts.max_run_col_frac)
        fracs_run = [min(max(f, minf), maxf) for f in fracs_run]

        s2 = sum(fracs_run) if fracs_run else 1.0
        if s2 > 0:
            fracs_run = [remain * (f / s2) for f in fracs_run]

        return [label_frac, *fracs_run]

    # ---------- styling ----------
    def _style_table(
        self,
        tbl: plt.Table,
        *,
        rows: list[list[str]],
        col_labels: list[str],
        label_col_frac_override: float | None = None,
    ) -> None:
        ts = self._spec
        ncols = len(col_labels)

        fs = self._auto_fontsize(n_body_rows=len(rows), ncols=ncols)
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(fs)

        # header styling
        for c in range(ncols):
            cell = tbl[0, c]
            cell.set_text_props(fontweight="bold")
            cell.set_linewidth(ts.header_linewidth)

        # section row styling
        for r in range(1, len(rows) + 1):
            is_section = all(rows[r - 1][c] == "" for c in range(1, ncols))
            if not is_section:
                continue
            for c in range(ncols):
                cell = tbl[r, c]
                cell.set_text_props(fontweight="bold")
                cell.set_facecolor(ts.section_facecolor)
                cell.set_linewidth(ts.section_linewidth)
                if c > 0:
                    cell.get_text().set_text("")

        # column widths inside bbox
        label_frac = label_col_frac_override if label_col_frac_override is not None else ts.label_col_frac
        if ts.enable_variable_col_widths and ncols > 2:
            fracs = self._compute_col_fracs(col_labels=col_labels, rows=rows, label_col_frac=float(label_frac))
            for (_r, c), cell in tbl.get_celld().items():
                if 0 <= c < len(fracs):
                    cell.set_width(fracs[c])
        else:
            label_frac = min(0.90, max(0.10, float(label_frac)))
            other_w = (1.0 - label_frac) / max(1, (ncols - 1))
            for (_r, c), cell in tbl.get_celld().items():
                cell.set_width(label_frac if c == 0 else other_w)

    def _shrink_overflowing_cells(self, tbl: plt.Table) -> None:
        """
        Optional last-resort: if some cell text still overflows, shrink its font size.
        Keeps overall table width unchanged.
        """
        ts = self._spec
        if not ts.enable_cell_font_shrink:
            return

        fig = tbl.axes.figure
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()

        min_fs = float(ts.cell_shrink_min_fontsize)

        for (_r, _c), cell in tbl.get_celld().items():
            txt = cell.get_text()
            if txt is None:
                continue
            s = txt.get_text()
            if not s:
                continue

            try:
                tb = txt.get_window_extent(renderer=renderer)
                cb = cell.get_window_extent(renderer=renderer)
            except Exception:
                continue

            if tb.width > 0.98 * cb.width:
                fs = float(txt.get_fontsize())
                for _ in range(8):
                    if fs <= min_fs:
                        break
                    fs = max(min_fs, fs * 0.9)
                    txt.set_fontsize(fs)
                    fig.canvas.draw()
                    tb2 = txt.get_window_extent(renderer=renderer)
                    if tb2.width <= 0.98 * cb.width:
                        break

    def _unify_fontsize_to_min(self, tbl: plt.Table) -> None:
        """
        For aesthetic consistency in the 'all runs' KPI table, find the
        smallest font size used in any cell (after per-cell shrinking)
        and apply that size (clamped to the per-cell minimum) to all cells.
        """
        ts = self._spec
        min_fs: float | None = None
        for (_r, _c), cell in tbl.get_celld().items():
            txt = cell.get_text()
            if txt is None:
                continue
            try:
                fs = float(txt.get_fontsize())
            except Exception:
                continue
            if min_fs is None or fs < min_fs:
                min_fs = fs

        if min_fs is None:
            return

        target_fs = min(min_fs, float(ts.cell_shrink_min_fontsize))

        for (_r, _c), cell in tbl.get_celld().items():
            txt = cell.get_text()
            if txt is None:
                continue
            try:
                txt.set_fontsize(target_fs)
            except Exception:
                continue

    # ---------- plotid ----------
    def _plotid_payload(self, *, mode: str, res_names: list[str], nrows: int, ncols: int) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "table",
            "mode": str(mode),  # "single" | "all_runs"
            "res_names": [str(r) for r in res_names],
            "nrows": int(nrows),
            "ncols": int(ncols),
            "title": str(self._spec.title),
            "bbox": tuple(float(x) for x in self._spec.bbox),
        }

    # ---------- figure title (force preset-consistent sizes) ----------
    def _apply_table_title(self, fig: plt.Figure, title: str | None) -> None:
        """
        Ensure KPI table titles obey the preset fonts.

        Matplotlib suptitles do not always match axes/title settings, and some styles
        don't propagate unless explicitly set. We derive sizes/weights from rcParams
        (set by ctx.style.rcparams), with a safe fallback to TableSpec defaults.
        """
        if not title:
            return

        ts = self._spec
        try:
            # Derive from axes.titlesize so table titles are in line
            # with subplot titles, but slightly smaller so they never
            # appear larger than scenario plot titles.
            axes_fs = plt.rcParams.get("axes.titlesize", ts.title_fontsize)
            fs = 0.8 * float(axes_fs)
            fw = plt.rcParams.get("figure.titleweight", "bold")
        except Exception:
            fs = ts.title_fontsize
            fw = "bold"

        try:
            fig.suptitle(str(title), y=float(ts.title_y), fontsize=fs, fontweight=fw)
        except Exception:
            pass

    # ---------- figure creation (legacy fallback safe) ----------
    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        pid = compute_plot_id(payload)

        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)

            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            return fig, ax

    # ---------- plotting ----------
    def plot_into(self, ax: plt.Axes, *, res_name: str) -> None:
        ts = self._spec
        ax.axis("off")

        f_by_res: dict[str, h5py.File] = {}
        tbl = None
        try:
            f_by_res[res_name] = h5py.File(self._h5_path(res_name), "r")

            rows = self._build_rows(f_by_res)
            col_labels = ["", self._display_name(res_name)]

            tbl = ax.table(
                cellText=rows,
                colLabels=col_labels,
                cellLoc="left",
                colLoc="center",
                loc="upper center",
                bbox=list(ts.bbox),
            )
        finally:
            for f in f_by_res.values():
                try:
                    f.close()
                except Exception:
                    pass

        if tbl is None:
            return

        self._style_table(tbl, rows=rows, col_labels=col_labels)
        self._shrink_overflowing_cells(tbl)

    def make_figure(self, *, res_name: str) -> plt.Figure:
        ts = self._spec

        # First pass: load rows to know geometry
        with h5py.File(self._h5_path(res_name), "r") as f:
            rows = self._build_rows({res_name: f})

        col_labels = ["", self._display_name(res_name)]
        payload = self._plotid_payload(mode="single", res_names=[res_name], nrows=len(rows), ncols=len(col_labels))

        fig, ax = self._make_figure_with_fallback(payload=payload)

        # Attach payload so ReportPlotter/export writes it into meta.json
        _set_plot_payload(
            fig,
            {
                "plotter": self.__class__.__qualname__,
                "plot_type": "table",
                "mode": "single",
                "res_name": str(res_name),
                "h5_path": Path(res_name).name,
            },
        )

        # Resize to geometry BUT clamp to benchmark
        w_in, h_in = self._desired_size_in(n_body_rows=len(rows), ncols=len(col_labels), has_title=bool(ts.title))
        fig.set_size_inches(w_in, h_in, forward=True)
        self._clamp_figsize(fig)

        fig_title = f"{ts.title}: {self._display_name(res_name)}" if ts.title else None

        # Apply plotting + title inside style rc_context so title uses preset rcParams
        with plt.rc_context(self.ctx.style.rcparams):
            self.plot_into(ax, res_name=res_name)
            fig = self.finalize_figure(fig, title=None, layout_policy="none")
            self._apply_table_title(fig, fig_title)

        self._clamp_figsize(fig)
        return fig

    def make_figure_all_runs(self) -> list[plt.Figure]:  # noqa: PLR0915
        ts = self._spec
        res_names = list(self.ctx.config.plots.invest_table)

        if not res_names:
            payload = self._plotid_payload(mode="all_runs", res_names=[], nrows=1, ncols=2)
            fig, ax = self._make_figure_with_fallback(payload=payload)
            ax.axis("off")
            fig.set_size_inches(min(6.0, _MAX_W_IN), min(3.0, _MAX_H_IN), forward=True)
            self._clamp_figsize(fig)

            _set_plot_payload(
                fig,
                {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "table",
                    "mode": "all_runs",
                    "res_names": [],
                    "h5_paths": [],
                },
            )

            fig_title = f"{ts.title}: All runs" if ts.title else None
            with plt.rc_context(self.ctx.style.rcparams):
                fig = self.finalize_figure(fig, title=None, layout_policy="none")
                self._apply_table_title(fig, fig_title)

            self._clamp_figsize(fig)
            return [fig]

        # First pass: open all files to build rows and know geometry
        f_by_res: dict[str, h5py.File] = {}
        try:
            for r in res_names:
                f_by_res[r] = h5py.File(self._h5_path(r), "r")
            rows = self._build_rows(f_by_res)
            col_labels = ["", *[self._display_name(r) for r in res_names]]
        finally:
            for f in f_by_res.values():
                try:
                    f.close()
                except Exception:
                    pass

        # Split rows into chunks so each figure stays within max height (455pt x 650pt).
        # Prefer section boundaries so we don't cut in the middle of a section.
        max_body_rows = self._max_body_rows_per_figure(has_title=bool(ts.title))
        row_chunks = self._chunk_rows_by_max_height(rows, len(col_labels), max_body_rows)

        def _make_all_runs_figure(rows_part: list[list[str]], part: int | None, total_parts: int) -> plt.Figure:
            n_body_rows = len(rows_part)
            payload = self._plotid_payload(
                mode="all_runs", res_names=res_names, nrows=n_body_rows, ncols=len(col_labels)
            )
            if part is not None:
                payload = dict(payload)
                payload["part"] = int(part)
                payload["total_parts"] = int(total_parts)

            fig, ax = self._make_figure_with_fallback(payload=payload)
            ax.axis("off")

            # Attach payload so ReportPlotter/export writes it into meta.json
            base_payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "table",
                "mode": "all_runs",
                "res_names": [str(r) for r in res_names],
                "h5_paths": [Path(r).name for r in res_names],
            }
            if part is not None:
                base_payload["part"] = int(part)
                base_payload["total_parts"] = int(total_parts)
            _set_plot_payload(fig, base_payload)

            # Resize to geometry BUT clamp to benchmark (original scaling and max size)
            w_in, h_in = self._desired_size_in(n_body_rows=n_body_rows, ncols=len(col_labels), has_title=bool(ts.title))
            fig.set_size_inches(w_in, h_in, forward=True)
            self._clamp_figsize(fig)

            if ts.title:
                if part is None or total_parts <= 1:
                    fig_title = f"{ts.title}: All runs"
                else:
                    fig_title = f"{ts.title}: All runs ({part}/{total_parts})"
            else:
                fig_title = None

            with plt.rc_context(self.ctx.style.rcparams):
                tbl = ax.table(
                    cellText=rows_part,
                    colLabels=col_labels,
                    cellLoc="left",
                    colLoc="center",
                    loc="upper center",
                    bbox=list(ts.bbox),
                )

                # For "all runs", label column smaller to free space for run columns
                self._style_table(
                    tbl,
                    rows=rows_part,
                    col_labels=col_labels,
                    label_col_frac_override=0.30,
                )
                # First shrink cells individually to satisfy width constraints,
                # then unify the font size across the table to the minimum used
                # so all entries share a common (small) text size.
                self._shrink_overflowing_cells(tbl)
                self._unify_fontsize_to_min(tbl)

                fig = self.finalize_figure(fig, title=None, layout_policy="none")
                self._apply_table_title(fig, fig_title)

            self._clamp_figsize(fig)
            return fig

        total_parts = len(row_chunks)
        if total_parts <= 1:
            return [_make_all_runs_figure(rows_part=rows, part=None, total_parts=1)]

        return [
            _make_all_runs_figure(rows_part=chunk, part=i + 1, total_parts=total_parts)
            for i, chunk in enumerate(row_chunks)
        ]

    def make_figures(self) -> list[plt.Figure]:
        figs: list[plt.Figure] = []
        figs.extend(self.make_figure_all_runs())
        for r in self.ctx.config.plots.invest_table:
            figs.append(self.make_figure(res_name=r))
        return figs


if __name__ == "__main__":
    pass
