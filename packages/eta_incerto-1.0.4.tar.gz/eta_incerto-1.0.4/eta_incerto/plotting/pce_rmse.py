# eta_incerto/plotting/pce_rmse.py
from __future__ import annotations

from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext
from eta_incerto.plotting.plot_id import compute_plot_id


class PceRmsePlotter(PlotterBase):
    """Plot RMSE vs design variable for different PCE orders.

    ReportPlotter-compatible:
      - does NOT save
      - returns a matplotlib Figure via make_figure()
      - resolves the input file from config.plots.pce_rmse (or config.plots.rmse)

    Foundation rules:
      - no fig.suptitle(...) in plotters (use finalize_figure(title=...))
      - no fig.tight_layout/subplots_adjust in plotters
      - figures finalized via PlotterBase.finalize_figure()
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        cfg = getattr(ctx.config.plots, "pce_rmse", None)
        if cfg is None:
            # backwards-friendly alias
            cfg = getattr(ctx.config.plots, "rmse", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.pce_rmse (or config.plots.rmse)")

        file_attr = getattr(cfg, "file", None)
        h5_file = file_attr if file_attr is not None else cfg
        if not isinstance(h5_file, (str, Path)):
            raise ValueError("config.plots.pce_rmse must be a filename or have a .file attribute.")

        self.h5_path = results_dir / str(h5_file)
        self._cfg = cfg  # store resolved cfg for make_figure()

        self.df, self.orders, self.order_labels = self._load_h5()

    @staticmethod
    def _decode_names(arr: Any) -> list[str]:
        out: list[str] = []
        for n in np.asarray(arr):
            if isinstance(n, (bytes, np.bytes_)):
                out.append(n.decode("utf-8", errors="replace"))
            else:
                out.append(str(n))
        return out

    def _load_h5(self) -> tuple[pd.DataFrame, list[int], list[str]]:
        with h5py.File(self.h5_path, "r") as f:
            design_x_range = np.asarray(f["rmse/design_var"][:], dtype=float)
            rmse_matrix = np.asarray(f["rmse/matrix"][:], dtype=float)
            orders = [int(x) for x in np.asarray(f["rmse/orders"][:]).tolist()]
            order_labels = self._decode_names(f["rmse/order_labels"][:])

        data: dict[str, Any] = {"design_var": design_x_range}
        for i, lbl in enumerate(order_labels):
            data[str(lbl)] = rmse_matrix[:, i]
        h5_df = pd.DataFrame(data)
        return h5_df, orders, [str(x) for x in order_labels]

    def make_figure(self) -> Figure:
        cfg = self._cfg

        # scales (old FigureSpec replacement)
        w_scale = float(getattr(cfg, "w_scale", 1.0))
        h_scale = float(getattr(cfg, "h_scale", 1.0))

        # PlotID payload (stable + deterministic)
        payload = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "pce_rmse",
            "h5_path": str(self.h5_path),
            "order_labels": list(self.order_labels),
            "w_scale": w_scale,
            "h_scale": h_scale,
        }
        plot_id = compute_plot_id(payload)

        # Create base figure via PlotterBase (single source of truth)
        try:
            fig, ax = self.make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
        except TypeError:
            # fallback if PlotterBase.make_figure signature doesn't accept plot_id_payload
            fig, ax = super().make_figure(nrows=1, ncols=1, squeeze=True)
            try:
                self.plot_id = plot_id
            except Exception:
                pass

        # Apply scaling relative to preset base size
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
        except Exception:
            pass

        # Optional per-plot rcparam overrides (overlay only for this figure)
        extra_rc = dict(getattr(cfg, "rcparams", {}) or {})
        if extra_rc:
            ctx_mgr = plt.rc_context({**self.ctx.style.rcparams, **extra_rc})
        else:
            ctx_mgr = plt.rc_context(self.ctx.style.rcparams)

        with ctx_mgr:
            for lbl in self.order_labels:
                ax.plot(self.df["design_var"], self.df[lbl], label=lbl)

            xlabel = str(getattr(cfg, "xlabel", "Design variable"))
            ylabel = str(getattr(cfg, "ylabel", "RMSE on design variable set"))
            fig_title = str(getattr(cfg, "title", "RMSE vs. design variable for different PCE orders"))
            legend_title = str(getattr(cfg, "legend_title", "PCE order"))

            # Optional units (if you add them later in config)
            x_unit = getattr(cfg, "x_unit", None)
            y_unit = getattr(cfg, "y_unit", None)

            # helpers (single source of truth for labels/spines/grid/ticks)
            # IMPORTANT: axis title stays None; figure title handled by finalize_figure().
            self.ctx.style.apply_axis_format(
                ax,
                xlabel=xlabel,
                ylabel=ylabel,
                x_unit=str(x_unit) if x_unit is not None else None,
                y_unit=str(y_unit) if y_unit is not None else None,
                title=None,
                grid=True,
                tick_style=getattr(cfg, "tick_style", None),
            )

            leg = ax.legend(title=legend_title)
            if leg:
                leg.get_frame().set_linewidth(0.0)

        # Centralized final layout + suptitle handling
        return super().finalize_figure(
            fig,
            title=fig_title,
            layout_policy="constrained",
        )
