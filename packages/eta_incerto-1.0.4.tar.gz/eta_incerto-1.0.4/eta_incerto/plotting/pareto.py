# eta_incerto/plotting/pareto.py
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint: 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0  # 6.319444...
_MAX_H_IN = 650.0 / 72.0  # 9.027777...


@dataclass(frozen=True, slots=True)
class ParetoFigureDefaults:
    w_scale: float = 1.0
    h_scale: float = 1.0
    alpha: float = 0.75
    s: float = 18.0


class ParetoPlotter(PlotterBase):
    """
    Pareto plotter.

    Reads:
      config.plots.pareto = ["file_a.h5", "file_b.h5", ...] or "file.h5"

    Expected HDF5 layout (best-effort):
      - tries common paths:
          /pareto/F
          /problem/objective_names
        fallback:
          /F, /objective_names

    Benchmark contract:
      - figure size must not exceed 455pt x 650pt
      - must work even if ctx has no .layout (legacy PlotContext)
      - does NOT save
      - returns matplotlib Figure(s)
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)
        cfg = getattr(ctx.config.plots, "pareto", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.pareto")

        items = [str(cfg)] if isinstance(cfg, (str, Path)) else [str(x) for x in list(cfg)]

        if not items:
            raise ValueError("config.plots.pareto is empty")

        self.h5_paths = [results_dir / it for it in items]
        self._cfg = cfg
        self._cache: dict[Path, tuple[pd.DataFrame, list[str]]] = {}

    # -------------------------
    # helpers
    # -------------------------

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        """
        Prefer PlotterBase.make_figure (new ctx.layout world). If ctx has no layout -> fallback.
        Always tags PlotID and clamps to benchmark.
        """
        pid = compute_plot_id(payload)

        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            self._clamp_figsize(fig)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)

            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, ax

    @staticmethod
    def _decode_names(arr: Any) -> list[str]:
        out: list[str] = []
        for n in np.asarray(arr):
            if isinstance(n, (bytes, np.bytes_)):
                out.append(n.decode("utf-8", errors="replace"))
            else:
                out.append(str(n))
        return out

    @staticmethod
    def _first_existing(h5f: h5py.File, candidates: Sequence[str]) -> str | None:
        for p in candidates:
            if p in h5f:
                return p
        return None

    def _load_h5(self, h5_path: Path) -> tuple[pd.DataFrame, list[str]]:
        if h5_path in self._cache:
            return self._cache[h5_path]

        with h5py.File(h5_path, "r") as f:
            f_path = self._first_existing(f, ["pareto/F", "pareto/f", "F", "f"])
            if not f_path:
                raise KeyError(f"Could not find Pareto objective array in {h5_path} (tried pareto/F, F).")

            f_values = np.asarray(f[f_path], dtype=float)
            if f_values.ndim == 1:
                f_values = f_values.reshape(-1, 1)

            names_path = self._first_existing(
                f,
                [
                    "problem/objective_names",
                    "objective_names",
                    "pareto/objective_names",
                ],
            )

            obj_names = (
                self._decode_names(f[names_path][:]) if names_path else [f"obj_{i}" for i in range(f_values.shape[1])]
            )

        if len(obj_names) != f_values.shape[1]:
            obj_names = [f"obj_{i}" for i in range(f_values.shape[1])]

        pareto_df = pd.DataFrame(f_values, columns=obj_names)
        self._cache[h5_path] = (pareto_df, obj_names)
        return pareto_df, obj_names

    def _rc_context(self) -> dict[str, Any]:
        extra_rc = dict(getattr(self._cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    # -------------------------
    # plotid
    # -------------------------
    def _plotid_payload(self, *, h5_path: Path, x: str, y: str, w_scale: float, h_scale: float) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "pareto",
            "h5_path": str(h5_path),
            "x": str(x),
            "y": str(y),
            "w_scale": float(w_scale),
            "h_scale": float(h_scale),
        }

    # -------------------------
    # public API
    # -------------------------

    def make_figure(self) -> Figure:
        figs = self.make_figures()
        return figs[0]

    def make_figures(self) -> list[Figure]:
        defaults = ParetoFigureDefaults()

        cfg = self._cfg
        w_scale = float(getattr(cfg, "w_scale", defaults.w_scale))
        h_scale = float(getattr(cfg, "h_scale", defaults.h_scale))
        alpha = float(getattr(cfg, "alpha", defaults.alpha))
        s = float(getattr(cfg, "s", defaults.s))

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            pareto_df, obj_names = self._load_h5(h5_path)

            if len(obj_names) < 2:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "pareto",
                    "h5_path": str(h5_path),
                }
                fig, ax = self._make_figure_with_fallback(payload=payload)
                ax.text(0.5, 0.5, "Pareto plot needs >= 2 objectives", ha="center", va="center")
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Pareto ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            x_name = str(getattr(cfg, "x", obj_names[0]))
            y_name = str(getattr(cfg, "y", obj_names[1]))
            if x_name not in pareto_df.columns:
                x_name = obj_names[0]
            if y_name not in pareto_df.columns:
                y_name = obj_names[1]

            payload = self._plotid_payload(
                h5_path=h5_path,
                x=x_name,
                y=y_name,
                w_scale=w_scale,
                h_scale=h_scale,
            )

            fig, ax = self._make_figure_with_fallback(payload=payload)

            # scale relative to preset base size, then clamp to benchmark
            try:
                w, h = fig.get_size_inches()
                fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
            except Exception:
                pass
            self._clamp_figsize(fig)

            with plt.rc_context(self._rc_context()):
                ax.scatter(pareto_df[x_name], pareto_df[y_name], s=s, alpha=alpha, c="0.35")

                self.ctx.style.apply_axis_format(
                    ax,
                    title=f"{h5_path.stem} | pareto",
                    xlabel=x_name,
                    ylabel=y_name,
                    grid=False,
                    tick_style=getattr(cfg, "tick_style", None),
                )

            fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
            self._clamp_figsize(fig)
            figs.append(fig)

        return figs


if __name__ == "__main__":
    pass
