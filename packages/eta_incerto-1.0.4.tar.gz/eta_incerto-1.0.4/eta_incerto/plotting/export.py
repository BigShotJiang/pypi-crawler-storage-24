# eta_incerto/plotting/export.py

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure

from eta_incerto.plotting.plot_id import get_plot_dir
from eta_incerto.plotting.style import PlotStyle, get_selected_preset_name, resolve_style

# -----------------------------
# Global max size (points) for all exported plots
# -----------------------------

MAX_FIG_W_PT = 650.0
MAX_FIG_H_PT = 455.0


def _fig_size_pt(fig: Figure) -> tuple[float, float]:
    w_in, h_in = fig.get_size_inches()
    return float(w_in * 72.0), float(h_in * 72.0)


def _enforce_max_fig_size(
    fig: Figure,
    *,
    max_w_pt: float = MAX_FIG_W_PT,
    max_h_pt: float = MAX_FIG_H_PT,
    mode: str = "scale",  # "scale" | "warn" | "error"
) -> dict[str, float]:
    """
    Enforce max figure size in points for ANY plot.

    mode:
      - "scale": shrink (never enlarges) to fit max size
      - "warn": do not change, only report (caller can log)
      - "error": raise if too large

    Returns a dict with:
      orig_w_pt, orig_h_pt, final_w_pt, final_h_pt, scale_applied
    """
    orig_w_pt, orig_h_pt = _fig_size_pt(fig)

    # Protect against degenerate figures
    if orig_w_pt <= 0 or orig_h_pt <= 0:
        return {
            "orig_w_pt": orig_w_pt,
            "orig_h_pt": orig_h_pt,
            "final_w_pt": orig_w_pt,
            "final_h_pt": orig_h_pt,
            "scale_applied": 1.0,
        }

    scale = min(max_w_pt / orig_w_pt, max_h_pt / orig_h_pt, 1.0)

    if scale < 1.0:
        if mode == "error":
            raise ValueError(
                f"Figure exceeds max size: {orig_w_pt:.1f}x{orig_h_pt:.1f} pt (max {max_w_pt:.1f}x{max_h_pt:.1f} pt)."
            )
        if mode == "scale":
            w_in, h_in = fig.get_size_inches()
            fig.set_size_inches(float(w_in * scale), float(h_in * scale), forward=True)
        # mode == "warn": no resize

    final_w_pt, final_h_pt = _fig_size_pt(fig)

    return {
        "orig_w_pt": orig_w_pt,
        "orig_h_pt": orig_h_pt,
        "final_w_pt": final_w_pt,
        "final_h_pt": final_h_pt,
        "scale_applied": float(scale),
    }


# -----------------------------
# Types / Results
# -----------------------------


@dataclass(frozen=True)
class ExportResult:
    plot_id: str
    preset_name: str
    out_dir: Path
    files: dict[str, Path]  # ext -> path
    meta_path: Path


FigureFactory = Callable[[PlotStyle], Figure]


# -----------------------------
# Helpers
# -----------------------------


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe_json(obj: Any) -> Any:
    """Best-effort JSON conversion so payloads/configs don't crash exporting."""
    try:
        json.dumps(obj, ensure_ascii=False)
        return obj
    except TypeError:
        return str(obj)


def _write_json(path: Path, data: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False),
        encoding="utf-8",
    )


def _strip(s: Any) -> str:
    if s is None:
        return ""
    return str(s).strip()


def _infer_unit_from_label(label: str) -> str | None:
    """
    Very small heuristic:
      - "Power [kW]" -> "kW"
      - "Power (kW)" -> "kW"
    """
    lab = _strip(label)
    if not lab:
        return None
    if "[" in lab and "]" in lab:
        inner = lab.split("[", 1)[1].rsplit("]", 1)[0].strip()
        return inner or None
    if "(" in lab and ")" in lab:
        inner = lab.split("(", 1)[1].rsplit(")", 1)[0].strip()
        return inner or None
    return None


def _looks_like_path(s: str) -> bool:
    """
    Heuristic: treat strings containing a path separator and a file suffix as paths.
    Works for Windows + POSIX.
    """
    if not isinstance(s, str):
        return False
    if ("/" not in s) and ("\\" not in s):
        return False
    # common suffixes in this project
    lower = s.lower()
    return any(
        lower.endswith(ext)
        for ext in (
            ".h5",
            ".hdf5",
            ".csv",
            ".json",
            ".yaml",
            ".yml",
            ".parquet",
            ".pickle",
            ".pkl",
            ".txt",
        )
    )


def _sanitize_payload_paths(obj: Any, *, parent_key: str | None = None) -> Any:
    """
    Recursively sanitize payload values so meta.json does not contain full absolute paths.

    Rule:
    - If a key looks like it denotes a path (e.g. 'h5_path', '*_path', 'path') and the
      value is a string, we replace it with Path(value).name
    - Additionally, if a string *looks like a path* (contains / or \\ and ends with a known suffix),
      we also replace it with the basename.
    """
    result: Any = obj

    if isinstance(obj, Mapping):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            ks = str(k)
            out[ks] = _sanitize_payload_paths(v, parent_key=ks)
        result = out

    elif isinstance(obj, (list, tuple)):
        result = [_sanitize_payload_paths(v, parent_key=parent_key) for v in obj]

    elif isinstance(obj, str):
        key = (parent_key or "").lower()
        key_is_pathy = key == "path" or key.endswith("_path") or key in {"h5_path", "csv_path", "file_path"}
        if key_is_pathy or _looks_like_path(obj):
            try:
                result = Path(obj).name
            except Exception:
                result = obj
        else:
            result = obj

    elif isinstance(obj, Path):
        result = obj.name

    return result


def _axes_to_dict(ax: Axes) -> dict[str, Any]:
    # Labels / title
    xlabel = _strip(ax.get_xlabel())
    ylabel = _strip(ax.get_ylabel())
    title = _strip(ax.get_title())

    # Scales and limits
    try:
        xscale = str(ax.get_xscale())
    except Exception:
        xscale = ""
    try:
        yscale = str(ax.get_yscale())
    except Exception:
        yscale = ""

    try:
        xlim = [float(ax.get_xlim()[0]), float(ax.get_xlim()[1])]
    except Exception:
        xlim = None
    try:
        ylim = [float(ax.get_ylim()[0]), float(ax.get_ylim()[1])]
    except Exception:
        ylim = None

    # Legend labels (if any)
    legend_labels: list[str] = []
    try:
        leg = ax.get_legend()
        if leg is not None:
            for t in leg.get_texts():
                txt = _strip(t.get_text())
                if txt and txt not in legend_labels:
                    legend_labels.append(txt)
    except Exception:
        pass

    # Line labels (useful even without legend)
    line_labels: list[str] = []
    try:
        for ln in ax.get_lines():
            lab = _strip(ln.get_label())
            # Matplotlib uses labels like "_child0" for unlabeled lines
            if lab and not lab.startswith("_") and lab not in line_labels:
                line_labels.append(lab)
    except Exception:
        pass

    return {
        "title": title or None,
        "x_axis": {
            "label": xlabel or None,
            "unit": _infer_unit_from_label(xlabel),
            "scale": xscale or None,
            "lim": xlim,
        },
        "y_axis": {
            "label": ylabel or None,
            "unit": _infer_unit_from_label(ylabel),
            "scale": yscale or None,
            "lim": ylim,
        },
        "legend_labels": legend_labels,
        "line_labels": line_labels,
    }


def _extract_figure_semantics(fig: Figure) -> dict[str, Any]:
    """
    Extract “columns/axis names/units”-adjacent metadata from matplotlib figure:
      - axes x/y labels, inferred units, scales, limits
      - legend and line labels
      - suptitle (if present)
    """
    suptitle = None
    try:
        st = fig._suptitle  # matplotlib internal
        if st is not None:
            suptitle = _strip(st.get_text()) or None
    except Exception:
        suptitle = None

    axes: list[dict[str, Any]] = []
    try:
        for ax in fig.get_axes():
            axes.append(_axes_to_dict(ax))
    except Exception:
        pass

    return {
        "suptitle": suptitle,
        "axes": axes,
    }


# -----------------------------
# Core: export one figure
# -----------------------------


def export_figure(  # noqa: PLR0913
    fig: Figure,
    *,
    plot_id: str,
    preset_name: str,
    out_root: str | Path,
    stem: str = "figure",
    style: PlotStyle | None = None,
    formats: Iterable[str] | None = None,
    dpi: int | None = None,
    metadata: Mapping[str, Any] | None = None,
    payload: Mapping[str, Any] | None = None,
    rcparams: Mapping[str, Any] | None = None,
    apply_style_rcparams: bool = True,
    close: bool = False,
    registry_file: str = "registry.jsonl",
) -> ExportResult:
    """
    Save a figure to:
      <out_root>/<plot_id>/<preset_name>/<stem>.<ext>

    Writes ONLY:
      - <stem>.meta.json   (contains metadata + payload + extracted figure semantics + size checks)

    Also appends:
      - <out_root>/<registry_file> as JSONL
    """
    out_root = Path(out_root)
    out_dir = get_plot_dir(out_root, plot_id, preset_name)

    # Resolve formats/dpi from style if not provided
    if formats is None:
        formats = ("pdf", "png") if style is None else style.export_formats

    if dpi is None:
        dpi = style.dpi if style is not None else int(fig.get_dpi())

    # Resolve save-time rcparams
    save_rcparams: Mapping[str, Any] | None = None
    if rcparams is not None:
        save_rcparams = rcparams
    elif apply_style_rcparams and style is not None:
        save_rcparams = style.rcparams

    # Enforce max figure size (points). Table figures use benchmark 455pt x 650pt.
    payload_dict = dict(payload) if payload else {}
    if payload_dict.get("plot_type") == "table":
        max_w_pt, max_h_pt = 455.0, 650.0
    else:
        max_w_pt, max_h_pt = MAX_FIG_W_PT, MAX_FIG_H_PT
    size_info = _enforce_max_fig_size(
        fig,
        max_w_pt=max_w_pt,
        max_h_pt=max_h_pt,
        mode="scale",
    )

    # ---- build meta (single file) ----
    meta: dict[str, Any] = {
        "plot_id": str(plot_id),
        "preset": str(preset_name),
        "stem": str(stem),
        "created_utc": _utc_now_iso(),
        "figure_size_pt": {
            "max_w_pt": float(max_w_pt),
            "max_h_pt": float(max_h_pt),
            **{k: float(v) for k, v in size_info.items()},
        },
    }

    if metadata:
        meta.update({k: _safe_json(v) for k, v in dict(metadata).items()})

    # Include payload inside meta.json
    if payload is not None:
        clean_payload = _sanitize_payload_paths(dict(payload))
        meta["payload"] = _safe_json(clean_payload)

    # Always include extracted figure semantics
    meta["figure"] = _extract_figure_semantics(fig)

    meta_path = out_dir / f"{stem}.meta.json"
    _write_json(meta_path, meta)

    files: dict[str, Path] = {}
    fmt_list = [str(f).lower().lstrip(".") for f in formats]

    save_ctx = plt.rc_context(dict(save_rcparams)) if save_rcparams else nullcontext()

    with save_ctx:
        for ext in fmt_list:
            path = out_dir / f"{stem}.{ext}"
            if ext == "png":
                fig.savefig(path, dpi=int(dpi))
            else:
                fig.savefig(path)
            files[ext] = path

    # append registry entry (jsonl) — also sanitized payload already in meta
    reg_path = out_root / registry_file
    entry = dict(meta)
    entry["files"] = {k: str(v) for k, v in files.items()}
    with reg_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + "\n")

    if close:
        plt.close(fig)

    return ExportResult(
        plot_id=str(plot_id),
        preset_name=str(preset_name),
        out_dir=out_dir,
        files=files,
        meta_path=meta_path,
    )


# -----------------------------
# Export variants from config
# -----------------------------


def export_variants_from_config(
    *,
    config: Any,
    plot_id: str,
    out_root: str | Path,
    stem: str,
    fig_factory: FigureFactory,
    presets: Iterable[str] | None = None,
    metadata: Mapping[str, Any] | None = None,
    payload: Mapping[str, Any] | None = None,
    registry_file: str = "registry.jsonl",
    close: bool = True,
) -> dict[str, ExportResult]:
    if presets is None:
        presets = [get_selected_preset_name(config)]

    out: dict[str, ExportResult] = {}
    for preset_name in presets:
        style = resolve_style(config, preset=str(preset_name))
        fig = fig_factory(style)

        meta = dict(metadata or {})
        meta.update(
            {
                "preset": str(preset_name),
                "export_formats": list(style.export_formats),
                "dpi": int(style.dpi),
                "mode": style.mode,
                "target": style.target,
            }
        )

        res = export_figure(
            fig,
            plot_id=str(plot_id),
            preset_name=str(preset_name),
            out_root=out_root,
            stem=stem,
            style=style,
            formats=None,
            dpi=None,
            metadata=meta,
            payload=payload,
            rcparams=None,
            apply_style_rcparams=True,
            close=close,
            registry_file=registry_file,
        )
        out[str(preset_name)] = res

    return out
