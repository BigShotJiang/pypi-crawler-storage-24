# eta_incerto/plotting/summary_template.py
from __future__ import annotations

from dataclasses import dataclass

import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext
from eta_incerto.plotting.plot_id import compute_plot_id

A4_W, A4_H = 8.27, 11.69


def _off(ax: plt.Axes) -> None:
    ax.set_axis_off()


@dataclass
class SummaryAxes2Topo:
    ax_title: plt.Axes
    ax_topo_wo: plt.Axes
    ax_topo_w: plt.Axes
    ax_perf: list[plt.Axes]  # [Energy, Costs, Emissions]
    ax_footer: plt.Axes


class SummaryTemplate(PlotterBase):
    """
    A4 summary-page template with a fixed GridSpec layout.

    This is intentionally a *layout helper* (not a report plotter by itself):
      - creates a single A4 figure with named axes slots
      - uses PlotterBase.make_figure() so rcParams + size caps are centralized
      - avoids direct plt.rcParams.update(...) and fig.subplots_adjust(...)
      - does not save

    Usage:
      tpl = SummaryTemplate(ctx)
      fig, axes = tpl.create_two_topologies(...)
      ... draw into axes ...
      fig = tpl.finalize(fig, title=None)
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

    def _plotid_payload(self, *, title: str, subtitle: str, footer_left: str, footer_right: str) -> dict:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "summary_template",
            "kind": "a4_two_topologies",
            "a4_w_in": float(A4_W),
            "a4_h_in": float(A4_H),
            # include texts (these affect the rendered figure)
            "title": str(title),
            "subtitle": str(subtitle),
            "footer_left": str(footer_left),
            "footer_right": str(footer_right),
        }

    def create_two_topologies(
        self,
        *,
        title: str,
        subtitle: str = "",
        footer_left: str = "",
        footer_right: str = "",
    ) -> tuple[plt.Figure, SummaryAxes2Topo]:
        # Use base backbone for figure creation.
        # We explicitly request A4 and disable constrained/tight at creation
        # because GridSpec + manual text blocks is a "custom layout" case.

        payload = self._plotid_payload(
            title=title,
            subtitle=subtitle,
            footer_left=footer_left,
            footer_right=footer_right,
        )
        _ = compute_plot_id(payload)

        # Create a 1x1 "base" figure and then force A4 size.
        # (Replaces old FigureSpec(fig_w_in/fig_h_in/max_w_in/max_h_in) logic)
        fig, _ax = super().make_figure(
            nrows=1,
            ncols=1,
            plot_id_payload=payload,
            squeeze=True,
        )

        # Force exact A4 size (portrait) for this template
        try:
            fig.set_size_inches(A4_W, A4_H, forward=True)
        except Exception:
            pass

        # header | topo row (2 columns) | performance row (3 columns) | footer
        gs = GridSpec(
            nrows=10,
            ncols=6,
            figure=fig,
            height_ratios=[0.9, 0.15, 3.0, 0.2, 2.2, 0.2, 0.1, 0.1, 0.1, 0.55],
            hspace=0.20,
            wspace=0.20,
        )

        ax_title = fig.add_subplot(gs[0, :])
        ax_topo_wo = fig.add_subplot(gs[2, 0:3])
        ax_topo_w = fig.add_subplot(gs[2, 3:6])

        ax_p1 = fig.add_subplot(gs[4, 0:2])
        ax_p2 = fig.add_subplot(gs[4, 2:4])
        ax_p3 = fig.add_subplot(gs[4, 4:6])

        ax_footer = fig.add_subplot(gs[-1, :])

        _off(ax_title)
        _off(ax_footer)

        header = title if not subtitle else f"{title}\n{subtitle}"
        ax_title.text(0.5, 0.55, header, ha="center", va="center", fontsize=16, fontweight="bold")

        ax_footer.text(0.01, 0.5, footer_left, ha="left", va="center", fontsize=9)
        ax_footer.text(0.99, 0.5, footer_right, ha="right", va="center", fontsize=9)

        axes = SummaryAxes2Topo(
            ax_title=ax_title,
            ax_topo_wo=ax_topo_wo,
            ax_topo_w=ax_topo_w,
            ax_perf=[ax_p1, ax_p2, ax_p3],
            ax_footer=ax_footer,
        )
        return fig, axes

    def finalize(self, fig: plt.Figure, *, title: str | None = None) -> plt.Figure:
        # For custom GridSpec templates, do NOT run tight/constrained; it can break spacing.
        return super().finalize_figure(fig, title=title, layout_policy="none")


def _make_a4_figure_agg(*, w_in: float, h_in: float) -> Figure:
    """
    Headless-safe figure factory for legacy fallback (no plt.figure / no GUI backend).
    """
    fig = Figure(figsize=(w_in, h_in))
    FigureCanvas(fig)  # attach a canvas so savefig works reliably
    return fig


# Backwards-compatible function API
def create_a4_template_two_topologies(
    title: str,
    subtitle: str = "",
    footer_left: str = "",
    footer_right: str = "",
    *,
    ctx: PlotContext | None = None,
) -> tuple[plt.Figure, SummaryAxes2Topo]:
    """
    Backwards-compatible convenience wrapper.

    If ctx is provided, uses centralized PlotStyle/rcParams via PlotterBase.
    If ctx is None, falls back to a minimal local rcParams snapshot (legacy behavior).
    """
    if ctx is None:
        # legacy fallback: keep behavior but minimal + non-invasive
        with plt.rc_context(
            {
                "font.size": 10,
                "axes.titlesize": 11,
                "axes.labelsize": 10,
                "legend.fontsize": 9,
                "xtick.labelsize": 9,
                "ytick.labelsize": 9,
                "axes.grid": True,
                "grid.alpha": 0.3,
                "pdf.fonttype": 42,
                "ps.fonttype": 42,
            }
        ):
            fig = _make_a4_figure_agg(w_in=A4_W, h_in=A4_H)

            gs = GridSpec(
                nrows=10,
                ncols=6,
                figure=fig,
                height_ratios=[0.9, 0.15, 3.0, 0.2, 2.2, 0.2, 0.1, 0.1, 0.1, 0.55],
                hspace=0.20,
                wspace=0.20,
            )

            ax_title = fig.add_subplot(gs[0, :])
            ax_topo_wo = fig.add_subplot(gs[2, 0:3])
            ax_topo_w = fig.add_subplot(gs[2, 3:6])

            ax_p1 = fig.add_subplot(gs[4, 0:2])
            ax_p2 = fig.add_subplot(gs[4, 2:4])
            ax_p3 = fig.add_subplot(gs[4, 4:6])

            ax_footer = fig.add_subplot(gs[-1, :])

            _off(ax_title)
            _off(ax_footer)

            header = title if not subtitle else f"{title}\n{subtitle}"
            ax_title.text(0.5, 0.55, header, ha="center", va="center", fontsize=16, fontweight="bold")

            ax_footer.text(0.01, 0.5, footer_left, ha="left", va="center", fontsize=9)
            ax_footer.text(0.99, 0.5, footer_right, ha="right", va="center", fontsize=9)

            axes = SummaryAxes2Topo(
                ax_title=ax_title,
                ax_topo_wo=ax_topo_wo,
                ax_topo_w=ax_topo_w,
                ax_perf=[ax_p1, ax_p2, ax_p3],
                ax_footer=ax_footer,
            )
            return fig, axes

    tpl = SummaryTemplate(ctx)
    return tpl.create_two_topologies(title=title, subtitle=subtitle, footer_left=footer_left, footer_right=footer_right)
