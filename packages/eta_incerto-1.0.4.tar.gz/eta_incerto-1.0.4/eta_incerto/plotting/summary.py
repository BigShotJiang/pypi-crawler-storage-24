# eta_incerto/plotting/summary.py
from __future__ import annotations

import matplotlib.pyplot as plt

"""
Legacy / developer scratch summary layout.

This module is intentionally NOT part of the PlotterBase style system.
It exists as a quick sandbox for GridSpec experiments.

If you want a production-ready summary-page layout, use:
  eta_incerto.plotting.summary_template (SummaryTemplate / create_a4_template_two_topologies)
and/or integrate that into ReportPlotter.

Rules for this file:
  - do not mutate global rcParams
  - do not hardcode saving paths for users
  - keep any demo code behind __main__
"""


A4_W, A4_H = 8.27, 11.69  # A4 portrait inches


def demo_gridspec_layout() -> plt.Figure:
    """Small demo figure to visualize a GridSpec layout."""
    fig = plt.figure(figsize=(A4_W, A4_H), constrained_layout=True)

    gs = fig.add_gridspec(3, 3)

    ax1 = fig.add_subplot(gs[0, :])
    ax1.set_title("gs[0, :]")

    ax2 = fig.add_subplot(gs[1, :-1])
    ax2.set_title("gs[1, :-1]")

    ax3 = fig.add_subplot(gs[1:, -1])
    ax3.set_title("gs[1:, -1]")

    ax4 = fig.add_subplot(gs[-1, 0])
    ax4.set_title("gs[-1, 0]")

    ax5 = fig.add_subplot(gs[-1, -2])
    ax5.set_title("gs[-1, -2]")

    return fig


if __name__ == "__main__":
    # Optional demo: write a PDF next to this file (no project-specific absolute paths).
    from pathlib import Path

    from matplotlib.backends.backend_pdf import PdfPages

    out_dir = Path.cwd() / "_summary_demo"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_pdf = out_dir / "summary_gridspec_demo.pdf"

    fig = demo_gridspec_layout()

    with PdfPages(out_pdf) as pdf:
        pdf.savefig(fig, bbox_inches="tight", pad_inches=0.1)

    plt.close(fig)
