# eta_incerto/plotting/context.py
from __future__ import annotations

from dataclasses import dataclass

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.plotting.style import PlotStyle, get_selected_preset_name, resolve_style


@dataclass(frozen=True)
class PlotContext:
    """
    LEGACY PlotContext.

    Many older plotters import:
        from eta_incerto.plotting.context import PlotContext

    Contract for legacy plotters:
      - ctx.config: ConfigOptimization
      - ctx.style: PlotStyle
    """

    config: ConfigOptimization
    style: PlotStyle

    @classmethod
    def build(cls, config: ConfigOptimization, *, preset: str | None = None) -> PlotContext:
        """
        Resolve PlotStyle once and return a legacy ctx.

        If preset is None, uses config.plotting.preset (fallback handled inside get_selected_preset_name/resolve_style).
        """
        preset_name = str(preset) if preset is not None else get_selected_preset_name(config)
        style = resolve_style(config, preset=preset_name)
        return cls(config=config, style=style)


# Optional explicit alias for readability in mixed code:
LegacyPlotContext = PlotContext
