# eta_incerto/plotting/series.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint (given): 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0  # 6.319444...
_MAX_H_IN = 650.0 / 72.0  # 9.027777...


@dataclass(frozen=True, slots=True)
class SeriesFigureDefaults:
    ncols: int = 1
    w_scale: float = 1.0
    h_scale: float = 1.0


class SeriesPlotter(PlotterBase):
    """Generic config-driven series plotter.

    ReportPlotter-compatible:
      - does NOT save
      - returns a matplotlib Figure via make_figure()
      - resolves HDF5 file from config.plots.series

    Expected config:
      config.plots.series.file = "results.h5"
      config.plots.series.subplots = [
        {"subplot": 0, "x": "/path/to/x", "y": "/path/to/y", "xlabel": "...", "ylabel": "...", "title": "..."},
        ...
      ]
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)
        cfg = getattr(ctx.config.plots, "series", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.series")

        file_attr = getattr(cfg, "file", None)
        h5_file = file_attr if file_attr is not None else cfg
        if not isinstance(h5_file, (str, Path)):
            raise ValueError("config.plots.series must be a filename or have a .file attribute.")

        self.h5_path = results_dir / str(h5_file)
        self._cfg = cfg

    @staticmethod
    def _read_1d(f: h5py.File, path: str) -> np.ndarray:
        if path not in f:
            raise KeyError(f"Dataset not found: '{path}'")
        arr = np.asarray(f[path])
        return arr.reshape(-1)

    def _plotid_payload(self) -> dict[str, Any]:
        """Stable PlotID payload for SeriesPlotter."""
        cfg = self._cfg
        subplots = list(getattr(cfg, "subplots", []))

        items: list[dict[str, str | int]] = []
        for s in subplots:
            items.append(
                {
                    "subplot": int(getattr(s, "subplot", 0)),
                    "x": str(s.x),
                    "y": str(s.y),
                }
            )

        items = sorted(items, key=lambda d: (int(d["subplot"]), str(d["x"]), str(d["y"])))

        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "series",
            "h5_path": str(self.h5_path),
            "subplots": items,
        }

    @staticmethod
    def _clamp_figsize(fig: Figure) -> None:
        """Clamp figure size to the benchmark limit in inches."""
        try:
            w, h = fig.get_size_inches()
            w2 = min(float(w), _MAX_W_IN)
            h2 = min(float(h), _MAX_H_IN)
            fig.set_size_inches(w2, h2, forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(
        self,
        *,
        nrows: int,
        ncols: int,
        payload: dict[str, Any],
        squeeze: bool,
    ):
        """
        Try PlotterBase.make_figure (new ctx.layout world).
        If ctx has no layout (legacy PlotContext), fall back to plt.subplots().
        """
        pid = compute_plot_id(payload)

        # Try "new base" path
        try:
            fig, axs = super().make_figure(
                nrows=nrows,
                ncols=ncols,
                plot_id_payload=payload,
                squeeze=squeeze,
            )
            return fig, axs
        except Exception:
            # Legacy fallback: size = style.fig_w_in/fig_h_in * grid
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w * max(1, ncols), _MAX_W_IN)
            fig_h = min(base_h * max(1, nrows), _MAX_H_IN)

            fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(fig_w, fig_h), squeeze=squeeze)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            return fig, axs

    def make_figure(self) -> Figure:
        cfg = self._cfg
        subplots = list(getattr(cfg, "subplots", []))
        if not subplots:
            raise ValueError("config.plots.series.subplots is empty (SeriesPlotter needs explicit dataset paths).")

        nplots = max(int(getattr(s, "subplot", 0)) for s in subplots) + 1
        ncols = int(getattr(cfg, "ncols", SeriesFigureDefaults.ncols))
        nrows = int(np.ceil(nplots / ncols))

        w_scale = float(getattr(cfg, "w_scale", SeriesFigureDefaults.w_scale))
        h_scale = float(getattr(cfg, "h_scale", SeriesFigureDefaults.h_scale))

        payload = self._plotid_payload()

        # Create figure (new ctx.layout OR legacy fallback)
        fig, axs = self._make_figure_with_fallback(nrows=nrows, ncols=ncols, payload=payload, squeeze=False)

        # Scale relative to preset base size
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
        except Exception:
            pass

        # Clamp to benchmark constraint
        self._clamp_figsize(fig)

        axs_arr = np.atleast_1d(axs).reshape(-1)
        used_axes: set[int] = set()

        # Plot-specific rcparams overlay (only for this figure)
        extra_rc = dict(getattr(cfg, "rcparams", {}) or {})
        if extra_rc:
            ctx_mgr = plt.rc_context({**self.ctx.style.rcparams, **extra_rc})
        else:
            ctx_mgr = plt.rc_context(self.ctx.style.rcparams)

        # Important: style cycling should be per-series, not per-subplot index
        series_i = 0

        with ctx_mgr, h5py.File(self.h5_path, "r") as f:
            for s in subplots:
                ax_idx = int(getattr(s, "subplot", 0))
                if ax_idx < 0 or ax_idx >= len(axs_arr):
                    raise IndexError(
                        f"subplot index {ax_idx} out of range for nrows={nrows}, ncols={ncols} (axes={len(axs_arr)})"
                    )

                ax = axs_arr[ax_idx]
                used_axes.add(ax_idx)

                x_path = str(s.x)
                y_path = str(s.y)

                x = self._read_1d(f, x_path)
                y = self._read_1d(f, y_path)

                label = getattr(s, "label", None)
                label_str = str(label) if label else None

                # Central BW/RGB styling policy
                # IMPORTANT FIX: PlotStyle.series_style() in your codebase does NOT accept label=...
                plot_kwargs = dict(self.ctx.style.series_style(series_i))
                series_i += 1

                if label_str:
                    ax.plot(x, y, label=label_str, **plot_kwargs)
                    self.ctx.style.apply_legend(ax)
                else:
                    ax.plot(x, y, **plot_kwargs)

                # Central formatting helpers
                xlabel = str(getattr(s, "xlabel", None) or x_path)
                ylabel = str(getattr(s, "ylabel", None) or y_path)
                title = getattr(s, "title", None)

                x_unit = getattr(s, "x_unit", None)
                y_unit = getattr(s, "y_unit", None)

                self.ctx.style.apply_axis_format(
                    ax,
                    xlabel=xlabel,
                    ylabel=ylabel,
                    x_unit=str(x_unit) if x_unit is not None else None,
                    y_unit=str(y_unit) if y_unit is not None else None,
                    title=str(title) if title else None,
                    grid=getattr(s, "grid", None),
                    tick_style=getattr(s, "tick_style", None),
                )

        # Remove unused axes
        for i, ax in enumerate(axs_arr):
            if i not in used_axes:
                fig.delaxes(ax)

        # Finalize layout (compatible with your base.py shim)
        layout_policy = str(getattr(cfg, "layout_policy", "constrained") or "constrained")
        fig_title = getattr(cfg, "title", None)

        fig = super().finalize_figure(
            fig,
            title=str(fig_title) if fig_title else None,
            layout_policy=layout_policy,
        )

        # Clamp again after finalize (tight_layout could expand slightly)
        self._clamp_figsize(fig)

        return fig
