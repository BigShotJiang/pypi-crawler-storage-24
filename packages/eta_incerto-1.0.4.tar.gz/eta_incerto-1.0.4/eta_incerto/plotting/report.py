# eta_incerto/plotting/report.py
"""Plotting orchestration class that loads different subclasses for plotting."""

from __future__ import annotations

import copy
import logging
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any, Callable

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.figure import Figure

from eta_incerto.config.config import ConfigOptimization

# --- Path resolving ---
from eta_incerto.plausibilization.loaders import get_typical_series_path

# --- New base context for migrated plotters ---
from eta_incerto.plotting.base import (
    LayoutSpec,
    PlotContext as NewPlotContext,
)

# --- Legacy plotters (still expect old PlotContext(config, style)) ---
from eta_incerto.plotting.comparison import ComparisonPlotter

# --- Old context module (kept for backward compatibility with un-migrated plotters) ---
from eta_incerto.plotting.context import PlotContext as LegacyPlotContext

# --- NEW/migrated plotters ---
from eta_incerto.plotting.dispatch import (
    DispatchOptions,
    DispatchPlotter,
    FigureScale,
    HeatmapStyle,
    TimeDims,
)
from eta_incerto.plotting.doe import DoePlotter

# --- NEW: enforce max fig size for summary PDFs too (summary path bypasses export_figure) ---
# --- Export & style ---
from eta_incerto.plotting.export import MAX_FIG_H_PT, MAX_FIG_W_PT, _enforce_max_fig_size, export_figure
from eta_incerto.plotting.pareto import ParetoPlotter
from eta_incerto.plotting.pce_rmse import PceRmsePlotter

# --- PlotID tools ---
from eta_incerto.plotting.plot_id import compute_plot_id, get_plot_id_from_figure, tag_matplotlib_figure
from eta_incerto.plotting.scenario import ScenarioPlotter
from eta_incerto.plotting.style import get_selected_preset_name, resolve_style
from eta_incerto.plotting.table import TablePlotter
from eta_incerto.plotting.topology import TopologyPlotter
from eta_incerto.plotting.typical_series import TypicalSeriesPlotter
from eta_incerto.util.data_paths import smart_resolve_path

logger = logging.getLogger(__name__)

# Store payload on figure objects so the exporter can write payload.json
_PLOT_PAYLOAD_ATTR = "_eta_incerto_plot_payload"


def _set_plot_payload(fig: Figure, payload: dict[str, Any]) -> None:
    try:
        setattr(fig, _PLOT_PAYLOAD_ATTR, payload)
    except Exception:
        # Non-fatal: export will still fall back to a minimal payload.
        pass


def _get_plot_payload(fig: Figure) -> dict[str, Any] | None:
    v = getattr(fig, _PLOT_PAYLOAD_ATTR, None)
    return v if isinstance(v, dict) else None


class ReportPlotter:
    """
    Orchestrates plotting and export.

    Supports:
      - NEW: presets via config.plotting (paper_rgb, paper_bw, slides_rgb, ...)
      - MIXED plotter world:
          * legacy plotters: receive LegacyPlotContext(config, style)
          * migrated plotters: receive NewPlotContext(style, layout, preset_name)
    """

    def __init__(self, config: ConfigOptimization):
        self.config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def investment_summary(self, *, presets: Sequence[str] | None = None) -> dict[str, Path]:
        return self._run_report("investment_summary", presets=presets)

    def technical_summary(self, *, presets: Sequence[str] | None = None) -> dict[str, Path]:
        return self._run_report("technical_summary", presets=presets)

    def environment_summary(self, *, presets: Sequence[str] | None = None) -> dict[str, Path]:
        return self._run_report("environment_summary", presets=presets)

    def antifragile_summary(self, *, presets: Sequence[str] | None = None) -> dict[str, Path]:
        return self._run_report("antifragile_summary", presets=presets)

    # ------------------------------------------------------------------
    # Internals: preset loop + plot orchestration
    # ------------------------------------------------------------------

    def _run_report(self, report_name: str, *, presets: Sequence[str] | None) -> dict[str, Path]:
        """
        Generate and export a report for one or more presets.

        If presets is None:
          -> exports only selected preset from config.plotting.preset (fallback "paper_rgb").
        """
        if presets is None:
            presets = [get_selected_preset_name(self.config)]

        out_paths: dict[str, Path] = {}

        import copy

        for preset_name in presets:
            style = resolve_style(self.config, preset=str(preset_name))

            # --- build a legacy-only config copy with normalized paths ---
            legacy_config = copy.copy(self.config)
            legacy_config.paths = copy.copy(self.config.paths)

            try:
                rr = Path(self.config.paths.results_dir)
                if (rr / "results").exists():
                    legacy_config.paths.results_dir = str((rr / "results").resolve())

                sr = Path(self.config.paths.series_dir)
                if (sr / "series").exists():
                    legacy_config.paths.series_dir = str((sr / "series").resolve())
            except Exception:
                # Non-fatal: legacy plotters may still fail, but we won't break exporting.
                pass

            # --- legacy ctx for non-migrated plotters (NO layout here!) ---
            legacy_ctx = LegacyPlotContext(config=legacy_config, style=style)

            # --- new ctx for migrated plotters ---
            layout = LayoutSpec(base_w_in=float(style.fig_w_in), base_h_in=float(style.fig_h_in))
            ctx = NewPlotContext(style=style, layout=layout, preset_name=str(preset_name))

            figs = self._make_figures_for_report(report_name, legacy_ctx=legacy_ctx, ctx=ctx)

            if not figs:
                logger.warning(
                    "No figures generated for report '%s' (preset=%s). Creating a fallback page.",
                    report_name,
                    preset_name,
                )
                figs = [self._fallback_page(ctx, report_name=report_name, preset_name=str(preset_name))]

            # IMPORTANT: export uses ORIGINAL self.config so output layout stays consistent.
            exported = self._export(
                figs,
                plot_name=report_name,
                preset_name=str(preset_name),
                style=style,
                make_summary_pdf=True,
            )
            out_paths.update(exported)

        return out_paths

    # ------------------------------------------------------------------
    # Small safety wrappers
    # ------------------------------------------------------------------

    def _safe_extend(self, figs: list[Figure], label: str, fn: Callable[[], list[Figure]]) -> None:
        try:
            out = fn()
            if out:
                figs.extend(out)
        except Exception as e:
            logger.warning("Skipping %s: %s", label, e)

    def _safe_append(self, figs: list[Figure], label: str, fn: Callable[[], Figure]) -> None:
        try:
            figs.append(fn())
        except Exception as e:
            logger.warning("Skipping %s: %s", label, e)

    # ------------------------------------------------------------------
    # Figure assembly per report
    # ------------------------------------------------------------------

    def _make_figures_for_report(
        self,
        report_name: str,
        *,
        legacy_ctx: LegacyPlotContext,
        ctx: NewPlotContext,
    ) -> list[Figure]:
        figs: list[Figure] = []

        # Legacy plotters (instantiate per preset so they pick up style changes)
        scenario = ScenarioPlotter(legacy_ctx)
        comparison = ComparisonPlotter(legacy_ctx)
        table = TablePlotter(legacy_ctx)

        doe = DoePlotter(legacy_ctx)
        pareto = ParetoPlotter(legacy_ctx)

        # PCE-RMSE is only needed for antifragile_summary; don't create it otherwise
        pce_rmse: PceRmsePlotter | None = None

        if report_name == "investment_summary":
            self._safe_extend(figs, "ScenarioPlotter.make_figures()", lambda: scenario.make_figures())
            self._safe_extend(figs, "TablePlotter.make_figures()", lambda: table.make_figures())
            self._safe_extend(figs, "ComparisonPlotter.make_figures()", lambda: comparison.make_figures(stacked=True))

        elif report_name == "technical_summary":
            # migrated plotters
            self._safe_extend(figs, "TopologyPlotter", lambda: self._make_topology_figures(ctx))
            self._safe_extend(figs, "DispatchPlotter", lambda: self._make_dispatch_figures(ctx))

            # TypicalSeriesPlotter is optional: only instantiate if file exists
            self._safe_extend(
                figs, "TypicalSeriesPlotter.make_figures()", lambda: self._maybe_make_typical_series(legacy_ctx)
            )

            if not figs:
                figs.append(self._fallback_page(ctx, report_name=report_name, preset_name=ctx.preset_name))

        elif report_name == "environment_summary":
            figs.append(self._fallback_page(ctx, report_name=report_name, preset_name=ctx.preset_name))

        elif report_name == "antifragile_summary":
            self._safe_extend(figs, "DoePlotter.make_figures()", lambda: doe.make_figures())
            self._safe_extend(figs, "DoePlotter.make_sobol_figures()", lambda: doe.make_sobol_figures())
            self._safe_extend(figs, "ParetoPlotter.make_figures()", lambda: pareto.make_figures())

            def _pce():
                nonlocal pce_rmse
                pce_rmse = PceRmsePlotter(legacy_ctx)
                return pce_rmse.make_figure()

            self._safe_append(figs, "PceRmsePlotter.make_figure()", _pce)

            if not figs:
                figs.append(self._fallback_page(ctx, report_name=report_name, preset_name=ctx.preset_name))

        else:
            raise ValueError(f"Unknown report name: {report_name!r}")

        return figs

    def _maybe_make_typical_series(self, legacy_ctx: LegacyPlotContext) -> list[Figure]:
        """
        Instantiate TypicalSeriesPlotter only if the HDF5 file exists.
        Log a single, informative warning if the file is referenced but missing.
        """
        cfg_raw = getattr(legacy_ctx.config.plots, "typical_series", None)
        if cfg_raw is None:
            return []

        series_dir = Path(legacy_ctx.config.paths.series_dir)
        file_attr = getattr(cfg_raw, "file", None)
        typical_folder = getattr(cfg_raw, "folder", None)

        # If not fully configured, silently skip (nothing to do)
        if typical_folder is None:
            return []

        h5_file = file_attr if file_attr is not None else cfg_raw
        if not isinstance(h5_file, (str, Path)):
            return []

        rel = Path(str(typical_folder)) / str(h5_file)
        h5_path = smart_resolve_path(series_dir, rel).resolve()

        if not h5_path.exists():
            # Fallback: use typical_series.h5 under config.series.series_file[0].file_name if it exists
            fallback_path = get_typical_series_path(legacy_ctx.config)
            if fallback_path is not None and fallback_path.exists():
                series_file = getattr(legacy_ctx.config.series, "series_file", [])
                if series_file:
                    folder_from_series = getattr(series_file[0], "file_name", None)
                    if folder_from_series:
                        try:
                            ts_cfg = legacy_ctx.config.plots.typical_series
                            legacy_plots_ts = legacy_ctx.config.plots.model_copy(
                                update={
                                    "typical_series": ts_cfg.model_copy(update={"folder": folder_from_series}),
                                }
                            )
                            legacy_config_ts = copy.copy(legacy_ctx.config)
                            legacy_config_ts.plots = legacy_plots_ts
                            ctx_ts = LegacyPlotContext(config=legacy_config_ts, style=legacy_ctx.style)
                            plotter = TypicalSeriesPlotter(ctx_ts)
                            return plotter.make_figures()
                        except Exception as e:
                            logger.warning("TypicalSeriesPlotter fallback failed: %s", e)
            logger.warning(
                "Skipping TypicalSeriesPlotter.make_figures(): %s (file does not exist). "
                "Set config.plots.typical_series.folder to the folder that contains typical_series.h5, "
                "or remove/disable config.plots.typical_series.",
                h5_path,
            )
            return []

        plotter = TypicalSeriesPlotter(legacy_ctx)
        return plotter.make_figures()

    # ------------------------------------------------------------------
    # Topology: map config -> new TopologyPlotter inputs
    # ------------------------------------------------------------------

    def _make_topology_figures(self, ctx: NewPlotContext) -> list[Figure]:
        cfg = getattr(self.config.plots, "topology", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.topology")

        items = [str(cfg)] if isinstance(cfg, (str, Path)) else [str(x) for x in list(cfg)]
        if not items:
            raise ValueError("config.plots.topology is empty")

        # results_dir might be run-root; H5 often under run-root/results/
        results_root = Path(self.config.paths.results_dir)
        h5_paths = [smart_resolve_path(results_root, it) for it in items]

        figs: list[Figure] = []
        for h5_path in h5_paths:
            plotter = TopologyPlotter(ctx, h5_path=h5_path, title="Topology")
            fig = plotter.plot()
            if _get_plot_payload(fig) is None:
                _set_plot_payload(
                    fig,
                    {
                        "plotter": plotter.__class__.__qualname__,
                        "plot_type": "topology",
                        "inputs": {"h5_path": str(h5_path)},
                    },
                )
            figs.append(fig)
        return figs

    # ------------------------------------------------------------------
    # Dispatch: map config -> new DispatchPlotter inputs
    # ------------------------------------------------------------------

    def _make_dispatch_figures(self, ctx: NewPlotContext) -> list[Figure]:
        cfg = getattr(self.config.plots, "dispatch", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.dispatch")

        # Normalize to list of files
        if isinstance(cfg, (str, Path)):
            items = [str(cfg)]
            opts: Any = {}
        elif isinstance(cfg, list):
            items = [str(x) for x in cfg]
            opts = {}
        else:
            h5_file = getattr(cfg, "file", None)
            if h5_file is None:
                raise ValueError("dispatch.file missing")
            items = [str(h5_file)]
            opts = cfg

        if not items:
            raise ValueError("config.plots.dispatch is empty")

        # results_dir might be run-root; H5 often under run-root/results/
        results_root = Path(self.config.paths.results_dir)
        h5_paths = [smart_resolve_path(results_root, it) for it in items]

        # ---- compute fallback typical_series.h5 (if configured) ----
        fallback_h5: Path | None = None
        ts_cfg = getattr(self.config.plots, "typical_series", None)
        if ts_cfg is not None:
            folder = getattr(ts_cfg, "folder", None)
            file_ = getattr(ts_cfg, "file", None)
            if folder and file_:
                series_root = Path(self.config.paths.series_dir)
                rel = Path(str(folder)) / str(file_)
                fallback_h5 = smart_resolve_path(series_root, rel).resolve()
        # -----------------------------------------------------------

        syscfg = self.config.system
        n_years = int(getattr(opts, "n_years", getattr(syscfg, "n_years", 10)))
        n_periods = int(getattr(opts, "n_periods", getattr(syscfg, "n_periods", 7)))
        n_time_steps = int(getattr(opts, "n_time_steps", getattr(syscfg, "n_time_steps", 24)))

        hm = getattr(opts, "heatmap", opts)
        heatmap = HeatmapStyle(
            cmap=str(getattr(hm, "cmap", "bwr")),
            vmin=getattr(hm, "vmin", None),
            vmax=getattr(hm, "vmax", None),
            interpolation=str(getattr(hm, "interpolation", "none")),
            aspect=str(getattr(hm, "aspect", "auto")),
            cbar_label=str(getattr(hm, "cbar_label", "W")),
            show_xticks=bool(getattr(hm, "show_xticks", False)),
            xtick_count=int(getattr(hm, "xtick_count", 12)),
        )

        figs: list[Figure] = []
        for h5_path in h5_paths:
            plotter = DispatchPlotter(
                ctx,
                h5_path=h5_path,
                scenario=getattr(opts, "scenario", None),
                components=getattr(opts, "components", None),
                only_power_components_default=bool(getattr(opts, "only_power", True)),
                time=TimeDims(
                    n_years=n_years,
                    n_periods=n_periods,
                    n_time_steps=n_time_steps,
                ),
                options=DispatchOptions(
                    title=getattr(opts, "title", None),
                    show_day_grid=bool(getattr(opts, "show_day_grid", True)),
                    show_component_prefix=bool(getattr(opts, "show_component_prefix", True)),
                ),
                scale=FigureScale(
                    w=float(getattr(opts, "w_scale", 1.0)),
                    h=float(getattr(opts, "h_scale", 1.4)),
                ),
                heatmap=heatmap,
                fallback_h5_path=fallback_h5,
            )
            fig = plotter.plot()
            if _get_plot_payload(fig) is None:
                _set_plot_payload(
                    fig,
                    {
                        "plotter": plotter.__class__.__qualname__,
                        "plot_type": "dispatch",
                        "inputs": {"h5_path": str(h5_path)},
                        "options": {
                            "scenario": getattr(opts, "scenario", None),
                            "components": getattr(opts, "components", None),
                            "time": {
                                "n_years": n_years,
                                "n_periods": n_periods,
                                "n_time_steps": n_time_steps,
                            },
                            "scale": {
                                "w": float(getattr(opts, "w_scale", 1.0)),
                                "h": float(getattr(opts, "h_scale", 1.4)),
                            },
                            "plot_opts": {
                                "title": getattr(opts, "title", None),
                                "show_day_grid": bool(getattr(opts, "show_day_grid", True)),
                                "show_component_prefix": bool(getattr(opts, "show_component_prefix", True)),
                            },
                            "fallback_h5_path": str(fallback_h5) if fallback_h5 is not None else None,
                        },
                    },
                )
            figs.append(fig)

        return figs

    # ------------------------------------------------------------------
    # Fallback page
    # ------------------------------------------------------------------

    def _fallback_page(self, ctx: NewPlotContext, *, report_name: str, preset_name: str) -> Figure:
        payload = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "fallback_page",
            "report": report_name,
            "preset": preset_name,
        }
        plot_id = compute_plot_id(payload)

        fig, ax = plt.subplots(figsize=(ctx.style.fig_w_in, ctx.style.fig_h_in))
        tag_matplotlib_figure(fig, plot_id, draw=False)
        _set_plot_payload(fig, payload)

        ax.axis("off")
        ax.text(
            0.02,
            0.92,
            f"Report: {report_name}\nPreset: {preset_name}",
            ha="left",
            va="top",
            fontsize=12,
            fontweight="bold",
        )
        ax.text(
            0.02,
            0.80,
            "No configured / available figures were generated for this report.\n"
            "This is not an error if required inputs are missing (e.g., typical_series.h5).\n\n"
            "Check:\n"
            "- config.plots.* entries\n"
            "- paths.results_dir / series_dir\n"
            "- availability of referenced HDF5 files\n",
            ha="left",
            va="top",
            fontsize=10,
        )
        return fig

    # ------------------------------------------------------------------
    # Export (PlotID routing + summary pdf)
    # ------------------------------------------------------------------

    def _export(
        self,
        figs: Iterable[Figure],
        *,
        plot_name: str,
        preset_name: str,
        style: Any,
        stem_prefix: str = "page",
        make_summary_pdf: bool = True,
        registry_file: str = "registry.jsonl",
    ) -> dict[str, Path]:
        figs_list = list(figs)
        if not figs_list:
            raise ValueError(f"No figures provided to export('{plot_name}').")

        results_dir = Path(self.config.paths.results_dir)
        plots_dir_cfg = Path(self.config.paths.plots_dir)
        plot_dir = (results_dir / plots_dir_cfg) if not plots_dir_cfg.is_absolute() else plots_dir_cfg
        plot_dir.mkdir(parents=True, exist_ok=True)

        bbox_inches = getattr(getattr(self.config, "plot_style", None), "bbox_inches", None)

        out_paths: dict[str, Path] = {}

        for i, fig in enumerate(figs_list, start=1):
            # 1) start from any payload already attached by plotters
            payload = _get_plot_payload(fig)

            # 2) ensure plot_id exists; compute from payload if possible
            plot_id = get_plot_id_from_figure(fig)
            if not plot_id:
                if payload is None:
                    payload = {}
                payload = dict(payload)
                payload.setdefault("report", plot_name)
                payload.setdefault("preset", preset_name)
                payload.setdefault("page", i)
                payload.setdefault("figure_label", getattr(fig, "get_label", lambda: "")())

                plot_id = compute_plot_id(payload)
                tag_matplotlib_figure(fig, plot_id, draw=False)
                _set_plot_payload(fig, payload)

            # 3) even if plot_id already existed, ensure we have at least a minimal payload
            if payload is None:
                payload = {
                    "report": plot_name,
                    "preset": preset_name,
                    "page": i,
                    "plot_id": str(plot_id),
                    "figure_label": getattr(fig, "get_label", lambda: "")(),
                }
                _set_plot_payload(fig, payload)

            stem = f"{stem_prefix}_{i:02d}_{plot_name}"

            res = export_figure(
                fig,
                plot_id=str(plot_id),
                preset_name=str(preset_name),
                out_root=plot_dir,
                stem=stem,
                style=style,
                formats=None,
                dpi=None,
                metadata={
                    "report": plot_name,
                    "page": i,
                    "bbox_inches": bbox_inches,
                },
                payload=payload,
                close=False,
                registry_file=registry_file,
            )

            for ext, path in res.files.items():
                out_paths[f"{preset_name}:{stem}.{ext}"] = path

        # --- SUMMARY PDF (IMPORTANT: enforce max size here too) ---
        # Table figures use benchmark 455pt x 650pt; other figures use MAX_FIG_*.
        if make_summary_pdf:
            summary_pdf = plot_dir / f"{plot_name}__{preset_name}.pdf"
            with PdfPages(summary_pdf) as pdf:
                for fig in figs_list:
                    payload = _get_plot_payload(fig)
                    if payload and payload.get("plot_type") == "table":
                        max_w_pt, max_h_pt = 455.0, 650.0
                    else:
                        max_w_pt, max_h_pt = MAX_FIG_W_PT, MAX_FIG_H_PT
                    _enforce_max_fig_size(
                        fig,
                        max_w_pt=max_w_pt,
                        max_h_pt=max_h_pt,
                        mode="scale",
                    )
                    pdf.savefig(fig, bbox_inches=bbox_inches)
            out_paths[f"{preset_name}:summary_pdf"] = summary_pdf

        for fig in figs_list:
            plt.close(fig)

        return out_paths


if __name__ == "__main__":
    pass
