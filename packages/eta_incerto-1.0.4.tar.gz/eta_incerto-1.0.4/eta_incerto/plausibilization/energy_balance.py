"""Energy balance check for no-storage systems: supply must match demand per timestep."""

from __future__ import annotations

from pathlib import Path

import xarray as xr

from eta_incerto.plausibilization.loaders import load_typical_series_demand, load_unit_dispatch_flat
from eta_incerto.plausibilization.result_types import FailureDetail
from eta_incerto.plausibilization.variant_mappings import (
    get_demand_series_for_variant,
    get_supply_vars_for_variant,
)


def _within_tolerance(expected: float, actual: float, atol: float, rtol: float) -> bool:
    diff = abs(expected - actual)
    if diff <= atol:
        return True
    scale = max(abs(expected), abs(actual), 1.0)
    return (diff / scale) <= rtol


def _demand_for_carrier(
    demand_arrays: dict[str, xr.DataArray],
    demand_series_names: list[str],
) -> xr.DataArray:
    """Sum demand series for a carrier; (period, step)."""
    out = None
    for name in demand_series_names:
        if name not in demand_arrays:
            continue
        da = demand_arrays[name]
        out = da.copy() if out is None else out + da
    if out is None:
        return xr.DataArray(0.0)
    return out


def _supply_for_carrier(
    dispatch: dict[str, xr.DataArray],
    supply_var_names: list[str],
    step_length: float = 1.0,
) -> xr.DataArray | None:
    """
    Sum supply vars for a carrier; return DataArray (year, period, time) in energy (e.g. Wh) if step_length set.
    Power vars are in W; supply is summed as-is (take abs for cooling if needed).
    """
    parts = []
    for vname in supply_var_names:
        if vname not in dispatch:
            continue
        da = dispatch[vname]
        # Cooling p_cool_out is typically negative (out of system); use abs for magnitude
        if "p_cool_out" in vname:
            da = da.abs()
        parts.append(da)
    if not parts:
        return None
    total = parts[0].copy()
    for da in parts[1:]:
        total = total + da
    if step_length != 1.0:
        total = total * step_length
    return total


def check_energy_balance_no_storage(
    typical_series_path: Path | str | None,
    scenario_grp,
    variant: str,
    *,
    result_file: str | None = None,
    scenario: str | None = None,
    atol: float = 1e-6,
    rtol: float = 1e-6,
    step_length: float = 1.0,
) -> list[FailureDetail]:
    """
    For each (year, period, time) and each carrier, compare total supply to demand.
    Demand comes from typical_series.h5 (period, step); supply from scenario unit_dispatch (year, period, time).
    Only applicable to no-storage variants (e.g. variant_zero).

    scenario_grp: h5py Group for one scenario (e.g. f["S1"]).
    Returns list of FailureDetail for each violation.
    """
    errors: list[FailureDetail] = []
    demand_series_map = get_demand_series_for_variant(variant)
    supply_vars_map = get_supply_vars_for_variant(variant)
    if not demand_series_map or not supply_vars_map:
        return errors

    if not typical_series_path or not Path(typical_series_path).exists():
        errors.append(
            FailureDetail(
                failure_type="energy_balance",
                message="typical_series.h5 not found; cannot run energy balance",
                result_file=result_file,
                scenario=scenario,
            )
        )
        return errors

    demand_arrays = load_typical_series_demand(
        Path(typical_series_path),
        list({s for names in demand_series_map.values() for s in names}),
    )
    dispatch = load_unit_dispatch_flat(scenario_grp)

    for carrier, demand_series_names in demand_series_map.items():
        supply_var_names = supply_vars_map.get(carrier, [])
        demand_da = _demand_for_carrier(demand_arrays, demand_series_names)
        supply_da = _supply_for_carrier(dispatch, supply_var_names, step_length=step_length)
        if supply_da is None:
            continue
        # Align: demand has (period, step), supply has (year, period, time)
        if "time" in supply_da.dims and "step" in demand_da.dims:
            supply_da = supply_da.rename({"time": "step"})
        years = supply_da.coords["year"].values if "year" in supply_da.coords else [1]
        for year in years:
            supply_slice = supply_da.sel(year=year)
            periods = supply_slice.coords["period"].values
            steps = supply_slice.coords["step"].values
            for period in periods:
                for step in steps:
                    try:
                        supply_val = float(supply_slice.sel(period=period, step=step).values)
                    except (KeyError, TypeError):
                        continue
                    try:
                        demand_val = float(demand_da.sel(period=period, step=step).values)
                    except (KeyError, TypeError):
                        demand_val = 0.0
                    if not _within_tolerance(demand_val, supply_val, atol, rtol):
                        errors.append(
                            FailureDetail(
                                failure_type="energy_balance",
                                message="Energy balance violation: supply != demand",
                                result_file=result_file,
                                scenario=scenario,
                                carrier=carrier,
                                timesteps=(int(year), int(period), int(step)),
                                expected=demand_val,
                                actual=supply_val,
                                abs_deviation=abs(demand_val - supply_val),
                                rel_deviation=abs(demand_val - supply_val) / max(abs(demand_val), abs(supply_val), 1.0),
                            )
                        )
    return errors
