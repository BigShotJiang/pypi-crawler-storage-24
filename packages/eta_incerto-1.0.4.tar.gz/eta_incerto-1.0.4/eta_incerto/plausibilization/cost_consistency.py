"""Cost consistency check: recalc expected costs from consumption x scenario prices vs reported."""

from __future__ import annotations

from eta_incerto.plausibilization.result_types import FailureDetail

# Heuristic: map trader name to scenario carrier for unit_price lookup.
TRADER_TO_CARRIER: dict[str, str] = {
    "gas_supplier": "gas",
    "electricity_supplier": "electricity",
    "electricity_feed_in": "electricity",
}


def _trader_carrier(trader_name: str) -> str | None:
    if trader_name in TRADER_TO_CARRIER:
        return TRADER_TO_CARRIER[trader_name]
    if "gas" in trader_name.lower():
        return "gas"
    if "electricity" in trader_name.lower():
        return "electricity"
    return None


def _within_tolerance(expected: float, actual: float, atol: float, rtol: float) -> bool:
    if atol < 0 or rtol < 0:
        return False
    diff = abs(expected - actual)
    if diff <= atol:
        return True
    scale = max(abs(expected), abs(actual), 1.0)
    return (diff / scale) <= rtol


def check_cost_consistency(
    traders_yearly: dict[str, dict[str, dict[int, float]]],
    unit_price_by_carrier_year: dict[str, dict[int, float]],
    *,
    result_file: str | None = None,
    scenario: str | None = None,
    atol: float = 1e-6,
    rtol: float = 1e-5,
) -> list[FailureDetail]:
    """
    Compare reported costs (traders_yearly) to expected costs (Quantity_kWh x unit_price).

    traders_yearly: from HDF5 technical/traders_yearly (trader -> Quantity_kWh_per_year, Costs_per_year).
    unit_price_by_carrier_year: carrier -> year -> unit_price from scenario CSV.

    Returns list of FailureDetail for each (trader, year) that fails the tolerance check.
    """
    errors: list[FailureDetail] = []
    for trader_name, data in traders_yearly.items():
        carrier = _trader_carrier(trader_name)
        if carrier is None or carrier not in unit_price_by_carrier_year:
            continue
        prices = unit_price_by_carrier_year[carrier]
        qty_by_year = data.get("Quantity_kWh_per_year") or {}
        costs_by_year = data.get("Costs_per_year") or {}
        for year, reported in costs_by_year.items():
            qty = qty_by_year.get(year, 0.0)
            price = prices.get(int(year), 0.0)
            expected = qty * price
            if not _within_tolerance(expected, reported, atol, rtol):
                diff = abs(expected - reported)
                rel = diff / max(abs(expected), abs(reported), 1.0)
                errors.append(
                    FailureDetail(
                        failure_type="cost_consistency",
                        message="Recalculated cost differs from reported cost",
                        result_file=result_file,
                        scenario=scenario,
                        trader=trader_name,
                        year=int(year),
                        expected=expected,
                        actual=reported,
                        abs_deviation=diff,
                        rel_deviation=rel,
                    )
                )
    return errors
