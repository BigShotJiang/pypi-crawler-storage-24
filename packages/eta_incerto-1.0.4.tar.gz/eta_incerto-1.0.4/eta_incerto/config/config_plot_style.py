from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

try:
    from typing import Literal
except Exception:  # pragma: no cover
    from typing_extensions import Literal


class ConfigPlotPreset(BaseModel):
    mode: Literal["rgb", "bw"] = "rgb"
    target: Literal["paper", "slides", "draft"] = "paper"

    fig_w_in: float = 6.0
    fig_h_in: float = 3.5
    dpi: int = 300

    rcparams: dict[str, Any] = Field(default_factory=dict)

    linestyles: tuple[Any, ...] = ()
    markers: tuple[str, ...] = ()
    palette: tuple[str, ...] = ()

    export_formats: tuple[str, ...] = ("pdf", "png")

    grid: bool = False
    grid_axis: str = "both"
    grid_alpha: float = 0.25

    hide_spines: tuple[str, ...] = ("top", "right")
    show_spines: tuple[str, ...] = ("bottom", "left")

    ylabel_rotation: float = 0.0
    ylabel_labelpad: float = 5.0
    ylabel_ha: str = "right"
    ylabel_va: str = "bottom"

    tick_style: Literal["plain", "sci", "auto"] = "plain"
    sci_limits: tuple[int, int] = (-3, 3)

    unit_separator: str = " in "


class ConfigPlotting(BaseModel):
    preset: str = "paper_rgb"
    presets: dict[str, ConfigPlotPreset] = Field(default_factory=dict)

    # optional global overrides
    fig_w_in: float | None = None
    fig_h_in: float | None = None
    dpi: int | None = None
    rcparams: dict[str, Any] = Field(default_factory=dict)

    linestyles: tuple[Any, ...] | None = None
    markers: tuple[str, ...] | None = None
    palette: tuple[str, ...] | None = None
    export_formats: tuple[str, ...] | None = None

    mode: Literal["rgb", "bw"] | None = None
    target: Literal["paper", "slides", "draft"] | None = None

    grid: bool | None = None
    grid_axis: str | None = None
    grid_alpha: float | None = None
    tick_style: Literal["plain", "sci", "auto"] | None = None


class ConfigPlotStyleLegacy(BaseModel):
    """
    Legacy 'plot_style' block (backwards compatible).
    Keep it optional in ConfigOptimization.
    """

    fig_w_in: float
    fig_h_in: float
    dpi: int
    rcparams: dict[str, Any] = Field(default_factory=dict)

    linestyles: tuple[Any, ...] = ()
    markers: tuple[str, ...] = ()

    bbox_inches: str = "tight"
