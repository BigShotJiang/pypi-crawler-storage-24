from __future__ import annotations

from copy import deepcopy
from logging import getLogger
from types import SimpleNamespace
from typing import TYPE_CHECKING, Literal

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from eta_incerto.envs.scenario import Scenario, ScenarioCollection
from eta_incerto.registry import get_system
from eta_incerto.util.variant_loader import load_variant_data

if TYPE_CHECKING:
    from typing import Any

log = getLogger(__name__)


def _as_1d_float_array(v: Any, *, name: str) -> np.ndarray:
    """Convert list/tuple/ndarray/scalar to 1D float ndarray (empty allowed)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        arr = np.asarray([v], dtype=float)
    elif isinstance(v, (list, tuple)):
        arr = np.asarray(v, dtype=float)
    elif isinstance(v, np.ndarray):
        arr = v.astype(float, copy=False)
    else:
        raise TypeError(f"Invalid type for {name}: {type(v)}")

    if arr.ndim != 1:
        raise ValueError(f"{name} must be 1D, got shape={arr.shape}")
    return arr


class ConfigPymooProblem(BaseModel):
    """
    One variant entry under `pymoo.problems.<variant_name>`.
    Mirrors your JSON schema strictly.
    """

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    mode: Literal["dispatch", "invest"] = Field(..., description="dispatch|invest")
    normalize: bool = Field(..., description="Whether to normalize objectives for this variant.")

    # design variables
    variable_names: list[str] = Field(..., description="Design variable names for this variant.")
    x_lower_bound: np.ndarray = Field(..., description="Lower bounds for variables (same order as variable_names).")
    x_upper_bound: np.ndarray = Field(..., description="Upper bounds for variables (same order as variable_names).")

    # objectives
    objective_names: list[str] = Field(..., description="Objective names for this variant.")
    obj_min: list[float] | None = Field(default=None, description="Objective minima (len == n_obj) if provided.")
    obj_max: list[float] | None = Field(default=None, description="Objective maxima (len == n_obj) if provided.")

    # constraints
    n_ieq_constraints: int = Field(..., ge=0)
    n_eq_constraints: int = Field(..., ge=0)

    @field_validator("x_lower_bound", "x_upper_bound", mode="before")
    @classmethod
    def _bounds_to_array(cls, v: Any, info):
        return _as_1d_float_array(v, name=info.field_name)

    @field_validator("obj_min", "obj_max", mode="before")
    @classmethod
    def _obj_bounds_to_float_list(cls, v: Any):
        if v is None:
            return None
        if not isinstance(v, list):
            raise TypeError("obj_min/obj_max must be a list if provided")
        return [float(x) for x in v]

    @model_validator(mode="after")
    def _validate_variant(self):
        n_obj = len(self.objective_names)
        n_var = len(self.variable_names)

        if n_obj <= 0:
            raise ValueError("objective_names must not be empty.")

        if self.mode == "dispatch":
            # dispatch-only variants must not define any design variables
            if n_var != 0:
                raise ValueError("dispatch mode requires variable_names to be empty.")
            if self.x_lower_bound.size != 0 or self.x_upper_bound.size != 0:
                raise ValueError("dispatch mode requires x_lower_bound/x_upper_bound to be empty.")
            # objective_names already checked above
            # obj_min/obj_max: allowed but must match if given
        else:
            # invest mode requires design variables
            if n_var <= 0:
                raise ValueError("invest mode requires variable_names to be non-empty.")
            if self.x_lower_bound.shape[0] != n_var:
                raise ValueError(
                    f"x_lower_bound length must match variable_names: {self.x_lower_bound.shape[0]} != {n_var}"
                )
            if self.x_upper_bound.shape[0] != n_var:
                raise ValueError(
                    f"x_upper_bound length must match variable_names: {self.x_upper_bound.shape[0]} != {n_var}"
                )
            if np.any(self.x_lower_bound < 0) or np.any(self.x_upper_bound < 0):
                raise ValueError("Bounds must be non-negative.")

        # Optional objective scaling bounds (if provided, must match n_obj)
        if self.obj_min is not None and len(self.obj_min) != n_obj:
            raise ValueError(f"obj_min length must match objective_names: {len(self.obj_min)} != {n_obj}")
        if self.obj_max is not None and len(self.obj_max) != n_obj:
            raise ValueError(f"obj_max length must match objective_names: {len(self.obj_max)} != {n_obj}")

        # If normalization is enabled for this variant, require both obj_min/obj_max.
        if self.normalize and (self.obj_min is None or self.obj_max is None):
            raise ValueError("normalize=true requires both obj_min and obj_max to be provided.")

        return self


class ConfigPymoo(BaseModel):
    """
    Top-level `pymoo` config section.

    Expected JSON:

      "pymoo": {
        "seed": 1,
        "save_history": true,
        "verbose": true,
        "penalty": 1e12,
        "vtype": "float",
        "normalize": false,
        "problems": { ... }
      }
    """

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    seed: int = Field(..., description="Random seed for pymoo.", ge=0)
    save_history: bool = Field(..., description="Whether pymoo should keep algorithm history.")
    verbose: bool = Field(..., description="Whether pymoo should print progress.")
    penalty: float = Field(..., description="Penalty objective for infeasible evaluations.", gt=0)

    vtype: type = Field(..., description="Variable type: 'int' or 'float' (or python type).")
    normalize: bool = Field(..., description="Global normalization flag (kept for backwards/central toggling).")

    problems: dict[str, ConfigPymooProblem] = Field(..., description="Per-variant pymoo problem definitions.")

    @field_validator("vtype", mode="before")
    @classmethod
    def _parse_vtype(cls, v: Any):
        type_map = {"int": int, "float": float}
        if isinstance(v, str):
            if v.lower() not in type_map:
                raise ValueError("pymoo.vtype must be 'int' or 'float'")
            return type_map[v.lower()]
        if v in (int, float):
            return v
        raise TypeError("pymoo.vtype must be 'int'/'float' or the python type int/float")

    @model_validator(mode="after")
    def _validate_top_level(self):
        if not self.problems:
            raise ValueError("pymoo.problems must contain at least one variant.")
        return self

    def for_variant(self, variant: str) -> ConfigPymooProblem:
        if variant not in self.problems:
            raise KeyError(f"Missing pymoo.problems entry for variant '{variant}'. Known: {list(self.problems)}")
        return self.problems[variant]

    def model_post_init(self, __context: Any, /) -> None:
        log.info("ConfigPymoo initialized with %d variant problem(s).", len(self.problems))


class ConfigProblem:
    """Adapter for loading system/series/scenario data; used by tests and config-driven flows."""

    @classmethod
    def load_system_series_scenario(cls, self_obj: Any) -> tuple[ScenarioCollection, ScenarioCollection, Any]:
        """Load scenarios and invest_scenarios for all systems in config.system.variant."""
        self_obj.scenarios.clear()
        self_obj.invest_scenarios.clear()
        config = self_obj.config
        distribution_data = None

        for system_name in config.system.variant:
            system_cls, static_data_cls, investment_data_cls, distribution_data_cls = get_system(system_name)
            static_data, investment_data, dist_data = load_variant_data(
                config, system_name, static_data_cls, investment_data_cls, distribution_data_cls
            )
            system_builder = system_cls(config, static_data, investment_data)
            base_static_system = system_builder.build_static_system()

            for series in config.series.series_file:
                for scenario in config.scenario.scenario_file:
                    dims = SimpleNamespace(
                        n_years=config.system.n_years,
                        n_periods=config.system.n_periods,
                        n_time_steps=config.system.n_time_steps,
                        year_length=config.system.year_length,
                        step_length=series.step_length,
                    )
                    series_data = config.series.load_typical_day(config, dims, series.file_name)
                    scenario_data = config.scenario.as_supplier_data(dims)

                    system_copy = deepcopy(base_static_system)
                    scenario_id = f"{system_name}_{series.file_name}_{scenario.name}"
                    dynamic_system = system_builder.build_dynamic_system(system_copy, series_data, scenario_data)
                    scenario_id_invest = f"{scenario_id}_invest"
                    investment_system = system_builder.build_investment(dynamic_system)

                    self_obj.scenarios.set_scenario(
                        Scenario(
                            name=scenario_id,
                            system=dynamic_system,
                            series=series_data,
                            energy_scenario=scenario_data,
                            series_file_name=series.file_name,
                        )
                    )
                    self_obj.invest_scenarios.set_scenario(
                        Scenario(
                            name=scenario_id_invest,
                            system=investment_system,
                            series=series_data,
                            energy_scenario=scenario_data,
                            series_file_name=series.file_name,
                        )
                    )

            if distribution_data_cls is not None:
                distribution_data = dist_data

        return self_obj.scenarios, self_obj.invest_scenarios, distribution_data
