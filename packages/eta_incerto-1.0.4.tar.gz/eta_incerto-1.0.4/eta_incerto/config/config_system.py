from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

if TYPE_CHECKING:
    pass

log = getLogger(__name__)


class ConfigSystem(BaseModel):
    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)
    variant: list[str]
