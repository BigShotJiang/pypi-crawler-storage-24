from __future__ import annotations

from pathlib import Path

from pandas import DataFrame, Series, read_csv
from pydantic import BaseModel, Field, field_validator, model_validator  # <- add Field, model_validator

Index = tuple[int, int, int]  # (year, period, timestep)


class SupplierData(BaseModel):
    type: str
    unit_price: dict[Index, float]
    emissions_per_unit: dict[Index, float]


class ScenarioFile(BaseModel):
    path: Path
    name: str
    probability: float | None = Field(default=None, ge=0.0)  # <- singular + scalar

    @field_validator("path")
    @classmethod
    def check_file_exists(cls, v: Path):
        if not v.exists():
            raise ValueError(f"Scenario file not found: {v}")
        return v

    def load_dataframe(self, **kwargs) -> DataFrame:
        """Load the csv file as a DataFrame."""
        return read_csv(self.path, on_bad_lines="warn", **kwargs)

    def load_supplier_data(self, dims, carrier_types: list[str]) -> dict[str, SupplierData]:
        """Convert fixed (two-row header) carrier_type CSV into SupplierData for all requested carriers."""
        df_supplier = self.load_dataframe(header=[0, 1]).set_index(("carrier_type", "year"))

        available = set(df_supplier.columns.get_level_values(0)) - {"carrier_type"}
        missing = set(carrier_types) - available
        if missing:
            raise KeyError(f"Missing carrier columns in {self.path.name}: {sorted(missing)}")

        out: dict[str, SupplierData] = {}
        default_series = Series(0.0, index=df_supplier.index)

        for c in carrier_types:
            if (c, "unit_price") in df_supplier.columns:
                unit_price_series = df_supplier[(c, "unit_price")].fillna(0.0)
            else:
                unit_price_series = default_series
            if (c, "emissions_per_unit") in df_supplier.columns:
                emission_series = df_supplier[(c, "emissions_per_unit")].fillna(0.0)
            else:
                emission_series = default_series

            unit_price: dict[Index, float] = {}
            emission: dict[Index, float] = {}

            for year in df_supplier.index:
                up = float(unit_price_series.loc[year])
                em = float(emission_series.loc[year])

                for period in range(1, dims.n_periods + 1):
                    for timestep in range(1, dims.n_time_steps + 1):
                        idx = (int(year), period, timestep)
                        unit_price[idx] = up
                        emission[idx] = em

            out[c] = SupplierData(type=c, unit_price=unit_price, emissions_per_unit=emission)

        return out


class ConfigScenario(BaseModel):
    carrier_types: list[str]
    scenario_file: list[ScenarioFile]
    data_repo_root: Path | None = None

    @model_validator(mode="before")
    @classmethod
    def resolve_paths_with_data_repo(cls, data: dict):
        data_repo_root = data.get("data_repo_root")
        if not data_repo_root:
            return data
        root_path = Path(data_repo_root)
        scenario_files = data.get("scenario_file", [])
        for entry in scenario_files:
            path_value = entry.get("path")
            if path_value is None:
                continue
            path = Path(path_value)
            if not path.is_absolute():
                entry["path"] = str(root_path / path)
        return data

    @model_validator(mode="after")
    def validate_probabilities(self):
        missing = [sf.name for sf in self.scenario_file if sf.probability is None]
        if missing:
            raise ValueError(f"Missing probability for scenarios: {missing}")

        total = sum(float(sf.probability) for sf in self.scenario_file)  # type: ignore[arg-type]
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"Probabilities must sum to 1.0, got {total}")

        return self

    def as_supplier_data(self, dims, carrier_types) -> dict[str, SupplierData]:
        """Load all scenario files as structured SupplierData objects"""
        return {sf.name: sf.load_supplier_data(dims, carrier_types) for sf in self.scenario_file}
