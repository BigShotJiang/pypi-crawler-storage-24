"""Configuration for uncertainty-space Design of Experiments (sampling over input/distribution space)."""

from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    pass


log = getLogger(__name__)


class ConfigUncertaintyDoe(BaseModel):
    """Uncertainty-space DOE: which uncertainty/input-parameter scenarios to sample."""

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    uncertainty_doe_n_samples: int = Field(
        ...,
        description="Number of samples in the uncertainty-space design of experiments.",
    )
    h5_filename: str
    method: str
    dist_names: str | list[str]
