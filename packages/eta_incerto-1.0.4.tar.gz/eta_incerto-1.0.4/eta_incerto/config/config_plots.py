from __future__ import annotations

from logging import getLogger
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

log = getLogger(__name__)


class ConfigTypicalSeries(BaseModel):
    model_config = ConfigDict(extra="forbid")  # keep strict schema

    folder: str | None = None
    file: str
    weights_file: str
    kind: Literal["weights", "periods", "overlay"] = "periods"
    key: list[str] | None = None
    ncols: int = 3
    where: Literal["pre", "post", "mid"] = "post"
    legend_mode: Literal["none", "first", "each"] = "first"
    show_weighted_mean: bool = False

    # overlay-only: list of {"key": "<series_name>", "column": "<col>", "label": "<legend>"}; key required
    specs: list[dict[str, Any]] | None = None

    # MathText supported
    # Example values may include Matplotlib MathText for subscripts/superscripts.
    display_names: dict[str, str] = Field(default_factory=dict)


class ConfigDispatchHeatmap(BaseModel):
    model_config = ConfigDict(extra="forbid")
    cmap: str = "bwr"
    vmin: float | None = None
    vmax: float | None = None
    interpolation: str = "none"
    aspect: str = "auto"
    cbar_label: str = "kW"


class ConfigDispatch(BaseModel):
    model_config = ConfigDict(extra="allow")  # allow extra keys

    file: str
    scenario: str | None = None
    components: list[str] | None = None

    n_years: int | None = None
    n_periods: int | None = None
    n_time_steps: int | None = None

    show_day_grid: bool = True
    heatmap: ConfigDispatchHeatmap = ConfigDispatchHeatmap()


class ConfigPlots(BaseModel):
    comparison: list[list[str, str]]
    invest_table: list[str]
    scenario: list[str]
    pareto: list[str]
    topology: list[str]
    dispatch: list[str] | ConfigDispatch | None = None
    typical_series: ConfigTypicalSeries | None = None
    design_doe: str | list[str]
    pce_rmse: str

    @model_validator(mode="before")
    @classmethod
    def accept_legacy_doe(cls, data: object) -> object:
        """Accept legacy key 'doe' when 'design_doe' is absent."""
        if isinstance(data, dict) and "doe" in data and "design_doe" not in data:
            data = {**data, "design_doe": data["doe"]}
        return data
