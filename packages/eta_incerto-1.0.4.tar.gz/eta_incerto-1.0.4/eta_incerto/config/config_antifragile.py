"""Configuration for offline DOE and surrogate in antifragile optimization."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ConfigAntifragile(BaseModel):
    """Offline design-point sampling and surrogate settings. Required for antifragile optimization."""

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    offline_n_design_points: int = Field(
        ...,
        gt=0,
        description="Number of design points in the offline phase (PCE training with Gurobi).",
    )
    surrogate_kind: str = Field(
        default="rbf",
        description="Surrogate model kind for x -> objectives (e.g. 'rbf').",
    )

    @model_validator(mode="before")
    @classmethod
    def accept_legacy_offline_doe_n_samples(cls, data: object) -> object:
        """Accept legacy key 'offline_doe_n_samples' when 'offline_n_design_points' is absent."""
        if isinstance(data, dict) and "offline_doe_n_samples" in data and "offline_n_design_points" not in data:
            data = {**data, "offline_n_design_points": data["offline_doe_n_samples"]}
        return data
