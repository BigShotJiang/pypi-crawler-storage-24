from __future__ import annotations

from logging import getLogger

from pydantic import BaseModel, ConfigDict, Field, RootModel

log = getLogger(__name__)


class ConfigEvaluateVariant(BaseModel):
    """
    Per-variant evaluation configuration, e.g.

    "evaluate": {
        "variant_one": {...},
        "variant_two": {...}
    }
    """

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    # parallelization
    n_jobs: int = -1
    backend: str = "loky"
    n_workers: int | None = Field(
        default=None,
        description="Optional process count for pymoo elementwise parallelization.",
    )
    vectorized: bool = Field(
        default=False,
        description="Use vectorized model evaluation for PCE training if supported (one build+solve per xi-batch).",
    )
    vectorized_batch_size: int | None = Field(
        default=None,
        description="When vectorized=True, cap batch size per vectorized build+solve (e.g. 64). None = full batch.",
    )

    # Optional solver overrides for PCE training (many MILP solves per evaluation)
    solver_mipgap_override: float | None = Field(
        default=None,
        description="Override mipgap for PCE training solves only (e.g. 0.08 to 0.10 for faster solves).",
    )
    solver_timelimit_override: float | None = Field(
        default=None,
        description="Per-solve time limit [s] for PCE training; hard instances may be suboptimal.",
    )

    # PCE / quadrature
    pce_order: int
    pce_rule: str
    pce_sample_factor: int = Field(
        default=4,
        ge=1,
        description="PCE training samples = max(pce_sample_factor * len(poly_exp), 1).\
            Lower = faster, coarser surrogate.",
    )
    quad_order: int
    quad_rule: str

    # statistics
    stat_n_mc: int
    stat_omega: float
    stat_rule: str

    # feasibility / rejection sampling controls
    feasibility_hot_idx: int
    feasibility_cold_idx: int
    feasibility_warm_idx: int | None = None  # only used for variants that need it
    feasibility_dt_min: float = Field(..., description="Minimum temperature difference [K].")
    feasibility_batch_size: int = 256
    feasibility_max_rounds: int = 200


class ConfigEvaluate(RootModel[dict[str, ConfigEvaluateVariant]]):
    """
    Root 'evaluate' section:
      evaluate: dict[str, ConfigEvaluateVariant]
    """

    def for_variant(self, variant: str) -> ConfigEvaluateVariant:
        try:
            return self.root[variant]
        except KeyError as e:
            raise KeyError(f"No evaluate config found for variant '{variant}'.") from e
