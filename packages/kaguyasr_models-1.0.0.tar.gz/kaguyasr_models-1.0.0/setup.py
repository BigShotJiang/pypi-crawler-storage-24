from setuptools import setup
from setuptools.command.install import install
import sys, os

class MODEL_BUILDER(install):
    def run(self):
        sys.path.insert(0, os.path.abspath('.'))
        import KaguyaSR_models.build
        KaguyaSR_models.build.main()
        super().run()

setup(
    name="KaguyaSR_models",
    version="1.0.0",
    description="KaguyaSR moonhalo models",
    author="Kiana Kaslana",
    author_email="anti-entropy-org@outlook.com",
    license="MIT",
    cmdclass={'install': MODEL_BUILDER},
)