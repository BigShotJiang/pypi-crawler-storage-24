import urllib.request
import os
import subprocess
import sys


def main():
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            check=True
        )
        compute_capability = result.stdout.strip()
        print(f"GPU Compute Capability: {compute_capability}")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("nvidia-smi is not available or failed to query compute capability.")
        sys.exit(1)

    os.system("where trtexec")
    cuda_major = compute_capability.replace(".", "")

    GPU_SM80plus = False

    build_mode = "ampere+" if GPU_SM80plus else "sameComputeCapability"

    def ensure_onnx_model(onnx_path: str):
        if os.path.exists(onnx_path):
            print(f"[✓] ONNX model exists: {onnx_path}")
            return
        filename = os.path.basename(onnx_path)
        url = f"https://cdn.anti-entropy.org.cn/mirrors/KaguyaSR_models/onnx/{filename}"
        print(f"Downloading {filename} from {url}")
        os.makedirs(os.path.dirname(onnx_path), exist_ok=True)
        
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"}
        )
        try:
            with urllib.request.urlopen(req) as response, open(onnx_path, 'wb') as out_file:
                out_file.write(response.read())
            print(f"Downloaded: {onnx_path}")
        except Exception as e:
            print(f"Failed to download {filename}: {e}")
            raise

    # FP16
    commonArgs = f"--fp16 --inputIOFormats=fp16:chw --outputIOFormats=fp16:chw --useCudaGraph --skipInference --hardwareCompatibilityLevel={build_mode} --minShapes=input:1x3x1x1"
    gfpganArgs = f"--inputIOFormats=fp32:chw --outputIOFormats=fp32:chw --useCudaGraph --skipInference --hardwareCompatibilityLevel={build_mode}"
    output_dir = f"trtoutput/MoonHalo_SM{cuda_major if not GPU_SM80plus else "80+"}"
    build_list =[
        # SMXX.X FP16 1080P
        f"trtexec --onnx=onnx/realesr-animevideov3.onnx --saveEngine={output_dir}/animevideov3_FP16.trt {commonArgs} --optShapes=input:1x3x1080x1920 --maxShapes=input:1x3x1080x1920",
        f"trtexec --onnx=onnx/realesr-general-x4v3.onnx --saveEngine={output_dir}/general-x4v3_FP16.trt {commonArgs} --optShapes=input:1x3x1080x1920 --maxShapes=input:1x3x1080x1920",

        # SMXX.X FP16 768P
        f"trtexec --onnx=onnx/RealESRGAN_x2plus.onnx --saveEngine={output_dir}/real-x2_FP16.trt {commonArgs} --optShapes=input:1x3x768x1366 --maxShapes=input:1x3x768x1366",

        # SMXX.X FP16 720P
        f"trtexec --onnx=onnx/RealESRGAN_x4plus.onnx --saveEngine={output_dir}/real-x4_FP16.trt {commonArgs} --optShapes=input:1x3x720x1280 --maxShapes=input:1x3x720x1280",

        # SMXX.X FP16 480x480
        f"trtexec --onnx=onnx/RealESRGAN_x8plus.onnx --saveEngine={output_dir}/real-x8_FP16.trt {commonArgs} --optShapes=input:1x3x480x480 --maxShapes=input:1x3x480x480",

        # SMXX.X FP16 720P
        f"trtexec --onnx=onnx/RealESRGAN_x4plus_anime_6B.onnx --saveEngine={output_dir}/anime-x4_FP16.trt {commonArgs} --optShapes=input:1x3x720x1280 --maxShapes=input:1x3x720x1280",

        # SMXX.X FP32 512x512
        f"trtexec --onnx=onnx/GFPGANv1.4.onnx --saveEngine={output_dir}/GFPGANv1.4.trt {gfpganArgs}",
        f"trtexec --onnx=onnx/parsing_parsenet.onnx --saveEngine={output_dir}/parsing_parsenet.trt {gfpganArgs}",

        # SMXX.X FP32 2150x2150
        f"trtexec --onnx=onnx/detection_Resnet50_Final.onnx --saveEngine={output_dir}/detection_Resnet50_Final.trt {gfpganArgs} --minShapes=input:1x3x1x1 --optShapes=input:1x3x2150x2150 --maxShapes=input:1x3x2150x2150",

    ]
    os.makedirs(output_dir, exist_ok=True)

    for cmd in build_list:
        parts = cmd.split()
        onnx_arg = next((part for part in parts if part.startswith("--onnx=")), None)
        if onnx_arg:
            onnx_path = onnx_arg.split("=", 1)[1]
            ensure_onnx_model(onnx_path)

    for cmd in build_list:
        os.system(cmd)