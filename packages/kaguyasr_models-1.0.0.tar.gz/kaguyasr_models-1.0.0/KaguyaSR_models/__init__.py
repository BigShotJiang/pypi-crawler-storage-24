import os

MODELDIR = os.path.dirname(os.path.abspath(__file__))