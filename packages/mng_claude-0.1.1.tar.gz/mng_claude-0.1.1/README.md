# mng-claude

This package has been renamed to [imbue-mngr-claude](https://pypi.org/project/imbue-mngr-claude/).

Install the new package:

```
pip install imbue-mngr-claude
```
