"""Phase 15 Case Study — How DSR Prevented a False Strategy Deployment.

Real scenario from Mnemox AI's TradeMemory Protocol (2026-03):
Grid search over 19,200 parameter combos produced "profitable" strategies
on BTCUSDT 1H data. DSR gate rejected ALL of them — correctly preventing
deployment of overfitted strategies.

This script reproduces the core finding:
- High M (trials) + low T (trades per window) = mathematically impossible to pass DSR
- LLM-guided search (M~30) has 640x lower statistical burden, but still fails
  when trade count is too low
"""

from deflated_sharpe import deflated_sharpe_ratio

# ── Scenario Setup ──────────────────────────────────────────────────
# 23 walk-forward periods, each 3 months IS + 3 months OOS
# ~30-50 trades per period (BTCUSDT 1H with single-hour entry)
# Grid search: 19,200 parameter combinations per period

NUM_PERIODS = 23
TRADES_PER_PERIOD = 40  # typical trade count in 3-month window

# Simulated observed Sharpe ratios (realistic range for BTCUSDT 1H)
# Some periods look great (SR > 1.0), mimicking what grid search finds
observed_srs = [
    0.20, 0.35, 0.55, 0.72, 0.48,
    0.91, 0.30, 0.65, 0.82, 1.05,
    0.40, 0.58, 0.95, 0.25, 0.70,
    1.15, 0.50, 0.38, 0.88, 0.62,
    0.45, 0.78, 1.10,
]

# ── Arm G: Grid Search (M=19,200) ──────────────────────────────────
print("=" * 70)
print("Phase 15 Case Study — DSR Prevented False Strategy Deployment")
print("=" * 70)
print()
print("─── Arm G: Grid Search (M=19,200 parameter combos) ───")
print(f"{'Period':>8} {'Obs SR':>8} {'DSR':>8} {'p-value':>10} {'Result':>8}")
print("-" * 50)

grid_m = 19200
grid_passes = 0

for i in range(NUM_PERIODS):
    sr = observed_srs[i]
    dsr, p = deflated_sharpe_ratio(sr, grid_m, TRADES_PER_PERIOD)
    passed = p < 0.05
    if passed:
        grid_passes += 1
    print(f"  P{i+1:02d}     {sr:>6.2f}   {dsr:>7.4f}   {p:>9.4f}   {'PASS' if passed else 'FAIL'}")

print("-" * 50)
print(f"  Grid result: {grid_passes}/{NUM_PERIODS} periods passed DSR gate")
print()

# ── Arm L: LLM Evolution (M~30 per round) ──────────────────────────
print("─── Arm L: LLM-Guided Search (M=30 per round, cumulative) ───")
print(f"{'Period':>8} {'Obs SR':>8} {'Cum M':>7} {'DSR':>8} {'p-value':>10} {'Result':>8}")
print("-" * 58)

llm_m_per_round = 30
llm_cumulative_m = 0
llm_passes = 0

for i in range(NUM_PERIODS):
    sr = observed_srs[i]
    llm_cumulative_m += llm_m_per_round  # M accumulates across periods
    dsr, p = deflated_sharpe_ratio(sr, llm_cumulative_m, TRADES_PER_PERIOD)
    passed = p < 0.05
    if passed:
        llm_passes += 1
    print(f"  P{i+1:02d}     {sr:>6.2f}   {llm_cumulative_m:>5d}   {dsr:>7.4f}   {p:>9.4f}   {'PASS' if passed else 'FAIL'}")

print("-" * 58)
print(f"  LLM result: {llm_passes}/{NUM_PERIODS} periods passed DSR gate")
print()

# ── Comparison ──────────────────────────────────────────────────────
print("─── Key Insight ───")
print()
print(f"  Grid (M=19,200):  {grid_passes}/{NUM_PERIODS} passed  — massive multiple-testing penalty")
print(f"  LLM  (M=30/rnd):  {llm_passes}/{NUM_PERIODS} passed  — 640x fewer trials, lower penalty")
print()

# Show the DSR threshold difference
_, p_grid = deflated_sharpe_ratio(1.0, grid_m, TRADES_PER_PERIOD)
_, p_llm = deflated_sharpe_ratio(1.0, llm_m_per_round, TRADES_PER_PERIOD)
print(f"  For SR=1.0, T={TRADES_PER_PERIOD}:")
print(f"    Grid p-value: {p_grid:.4f}  (need SR >> 1.0 to pass)")
print(f"    LLM  p-value: {p_llm:.4f}  (much lower bar, but T=40 still too few)")
print()

# ── Conclusion ──────────────────────────────────────────────────────
print("─── Conclusion ───")
print()
print("  1. DSR correctly blocked ALL grid search strategies — with M=19,200")
print("     and only 40 trades, even SR=1.15 is indistinguishable from luck.")
print()
print("  2. LLM search has a structurally lower bar (fewer trials to correct for),")
print("     but the real bottleneck is trade count (T=40), not search method.")
print()
print("  3. The fix isn't a better search algorithm — it's higher-frequency")
print("     strategies that produce enough trades per evaluation window.")
print()
print("  Without DSR, these overfitted strategies would have been deployed")
print("  to live trading, losing real money. DSR saved us from ourselves.")
