"""Quick Start — deflated-sharpe in 60 seconds."""

import random

from deflated_sharpe import (
    benjamini_hochberg,
    deflated_sharpe_ratio,
    min_backtest_length,
    RegimeDecayDetector,
    StrategyBaseline,
    TradeResult,
)

# ── 1. Deflated Sharpe Ratio ────────────────────────────────────────
print("=" * 60)
print("1. Deflated Sharpe Ratio (DSR)")
print("=" * 60)

observed_sr = 1.5
num_trials = 100  # strategies tested
num_obs = 252     # trading days

dsr, p = deflated_sharpe_ratio(observed_sr, num_trials, num_obs)
print(f"   Observed SR : {observed_sr}")
print(f"   Trials (M)  : {num_trials}")
print(f"   Observations: {num_obs}")
print(f"   DSR         : {dsr:.4f}")
print(f"   p-value     : {p:.4f}")
print(f"   Result      : {'SIGNIFICANT — real alpha after correction' if p < 0.05 else 'NOT significant — could be luck'}")
print()

# ── 2. Minimum Backtest Length ──────────────────────────────────────
print("=" * 60)
print("2. Minimum Backtest Length (MinBTL)")
print("=" * 60)

target_sr = 1.0
trials = 50

t = min_backtest_length(target_sr, trials)
print(f"   Target SR   : {target_sr}")
print(f"   Trials (M)  : {trials}")
print(f"   MinBTL      : {t} observations")
print(f"   → You need at least {t} data points for DSR > 0 at alpha=0.05")
print()

# ── 3. Benjamini-Hochberg FDR ──────────────────────────────────────
print("=" * 60)
print("3. Benjamini-Hochberg FDR Control")
print("=" * 60)

p_values = [0.001, 0.04, 0.03, 0.5, 0.01]
results = benjamini_hochberg(p_values)

print(f"   Raw p-values: {p_values}")
print(f"   After BH correction (alpha=0.05):")
for idx, pv, sig in results:
    status = "PASS" if sig else "FAIL"
    print(f"     Strategy {idx}: p={pv:.3f} → {status}")
n_pass = sum(1 for _, _, s in results if s)
print(f"   → {n_pass}/{len(p_values)} strategies survive FDR control")
print()

# ── 4. Regime Decay Detector ───────────────────────────────────────
print("=" * 60)
print("4. Regime Decay Detector (Triple Confirmation)")
print("=" * 60)

baseline = StrategyBaseline(
    win_rate=0.6,
    trade_count=100,
    max_drawdown_pct=15.0,
)
detector = RegimeDecayDetector(baseline=baseline)

# Feed 25 trades: first 10 wins, then 15 losses (regime decay)
random.seed(42)
for i in range(25):
    is_win = i < 10  # first 10 win, rest lose
    pnl = random.uniform(50, 150) if is_win else random.uniform(-200, -50)
    detector.add_trade(TradeResult(is_win=is_win, pnl=pnl))

result = detector.assess()
print(f"   Baseline    : WR={baseline.win_rate:.0%}, MDD={baseline.max_drawdown_pct}%")
print(f"   Live trades : {result.total_trades}")
print(f"   Signals fired: {result.signals_fired}/3")
for sig in result.signals:
    status = "FIRED" if sig.fired else "ok"
    print(f"     {sig.name}: {status} (value={sig.value:.3f}, threshold={sig.threshold:.3f})")
print(f"   Decay confirmed: {result.decay_confirmed}")
if result.reason:
    print(f"   Reason: {result.reason}")
print()

print("Done! See phase15_case_study.py for a real-world application.")
