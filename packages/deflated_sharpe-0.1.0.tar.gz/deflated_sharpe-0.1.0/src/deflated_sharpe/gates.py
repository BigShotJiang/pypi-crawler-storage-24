"""Statistical Gates — Deflated Sharpe Ratio + FDR control.

Three pure functions for multiple-testing correction in strategy evaluation:

1. deflated_sharpe_ratio() — Bailey & Lopez de Prado (2014)
2. min_backtest_length() — minimum observations needed
3. benjamini_hochberg() — FDR control for multiple strategies

References:
    Bailey, D. H., & Lopez de Prado, M. (2014).
    "The Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting,
     and Non-Normality." Journal of Portfolio Management.
"""

from __future__ import annotations

import math
from typing import List, Tuple

from ._math import _norm_cdf


def deflated_sharpe_ratio(
    observed_sr: float,
    num_trials: int,
    num_obs: int,
    skewness: float = 0.0,
    kurtosis: float = 3.0,
) -> Tuple[float, float]:
    """Compute the Deflated Sharpe Ratio (DSR).

    Adjusts the observed Sharpe ratio for the number of trials (strategies tested),
    accounting for non-normality of returns.

    Args:
        observed_sr: Observed (annualized) Sharpe ratio.
        num_trials: Number of independent strategies/trials tested (M).
        num_obs: Number of observations (T) in the backtest.
        skewness: Skewness of returns (0 for normal).
        kurtosis: Kurtosis of returns (3 for normal).

    Returns:
        (dsr, p_value): DSR value and associated p-value.
        DSR > 0 means the strategy likely has real alpha after accounting for trials.
        p_value < 0.05 means statistically significant.
    """
    if num_trials < 1 or num_obs < 2:
        return 0.0, 1.0

    if num_trials <= 1:
        sr_max = 0.0
    else:
        ln_m = math.log(num_trials)
        z = math.sqrt(2 * ln_m)
        e_z_max = z - (math.log(math.log(num_trials)) + math.log(4 * math.pi)) / (2 * z)
        sr_max = e_z_max * math.sqrt(1.0 / (num_obs - 1))

    sr = observed_sr
    se_sr = math.sqrt(
        max(
            (1 - skewness * sr + ((kurtosis - 1) / 4) * sr * sr) / (num_obs - 1),
            1e-12,
        )
    )

    dsr = (sr - sr_max) / se_sr

    p_value = 1.0 - _norm_cdf(dsr)

    return round(dsr, 6), round(p_value, 6)


def min_backtest_length(
    target_sr: float,
    num_trials: int,
    alpha: float = 0.05,
    skewness: float = 0.0,
    kurtosis: float = 3.0,
) -> int:
    """Compute minimum backtest length needed for a target Sharpe ratio.

    Given a target SR and number of trials, returns the minimum number of
    observations T such that DSR > 0 at significance level alpha.

    Args:
        target_sr: Target (annualized) Sharpe ratio (SR*).
        num_trials: Number of strategies tested (M).
        alpha: Significance level (default 0.05).
        skewness: Skewness of returns.
        kurtosis: Kurtosis of returns.

    Returns:
        Minimum number of observations needed (T).
    """
    if target_sr <= 0 or num_trials < 1:
        return 0

    lo, hi = 2, 100000

    dsr, p = deflated_sharpe_ratio(target_sr, num_trials, hi, skewness, kurtosis)
    if p >= alpha:
        return hi

    while lo < hi:
        mid = (lo + hi) // 2
        dsr, p = deflated_sharpe_ratio(target_sr, num_trials, mid, skewness, kurtosis)
        if p < alpha:
            hi = mid
        else:
            lo = mid + 1

    return lo


def benjamini_hochberg(
    p_values: List[float],
    alpha: float = 0.05,
) -> List[Tuple[int, float, bool]]:
    """Benjamini-Hochberg FDR correction for multiple testing.

    Args:
        p_values: List of p-values from multiple strategy tests.
        alpha: Target FDR level (default 0.05).

    Returns:
        List of (original_index, p_value, significant) tuples,
        sorted by original index.
    """
    if not p_values:
        return []

    m = len(p_values)

    indexed = sorted(enumerate(p_values), key=lambda x: x[1])

    significant = [False] * m
    max_significant_rank = -1

    for rank, (orig_idx, p) in enumerate(indexed):
        k = rank + 1
        threshold = (k / m) * alpha
        if p <= threshold:
            max_significant_rank = rank

    if max_significant_rank >= 0:
        for rank in range(max_significant_rank + 1):
            orig_idx = indexed[rank][0]
            significant[orig_idx] = True

    return [(i, p_values[i], significant[i]) for i in range(m)]
