"""deflated-sharpe: Statistical gates for quantitative strategy validation."""

__version__ = "0.1.0"

from .gates import deflated_sharpe_ratio, min_backtest_length, benjamini_hochberg
from .regime import (
    RegimeDecayDetector,
    StrategyBaseline,
    TradeResult,
    DecayAssessment,
    DecaySignal,
    RegimeDetectorConfig,
)

__all__ = [
    "deflated_sharpe_ratio",
    "min_backtest_length",
    "benjamini_hochberg",
    "RegimeDecayDetector",
    "StrategyBaseline",
    "TradeResult",
    "DecayAssessment",
    "DecaySignal",
    "RegimeDetectorConfig",
]
