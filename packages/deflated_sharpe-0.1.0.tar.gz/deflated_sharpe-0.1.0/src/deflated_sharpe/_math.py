"""Core math utilities for deflated-sharpe."""

from __future__ import annotations

import math


def _norm_cdf(x: float) -> float:
    """Standard normal CDF using the error function."""
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _mahalanobis(
    x: tuple[float, ...],
    mean: list[float],
    inv_cov: list[list[float]],
) -> float:
    """Compute Mahalanobis distance for a single observation."""
    dim = len(mean)
    diff = [x[j] - mean[j] for j in range(dim)]

    # d^2 = diff^T @ inv_cov @ diff
    d_sq = 0.0
    for i in range(dim):
        for j in range(dim):
            d_sq += diff[i] * inv_cov[i][j] * diff[j]

    return math.sqrt(max(d_sq, 0.0))


def _invert_3x3(m: list[list[float]]) -> list[list[float]] | None:
    """Invert a 3x3 matrix. Returns None if singular."""
    a, b, c = m[0]
    d, e, f = m[1]
    g, h, i = m[2]

    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        return None

    inv_det = 1.0 / det
    return [
        [
            (e * i - f * h) * inv_det,
            (c * h - b * i) * inv_det,
            (b * f - c * e) * inv_det,
        ],
        [
            (f * g - d * i) * inv_det,
            (a * i - c * g) * inv_det,
            (c * d - a * f) * inv_det,
        ],
        [
            (d * h - e * g) * inv_det,
            (b * g - a * h) * inv_det,
            (a * e - b * d) * inv_det,
        ],
    ]
