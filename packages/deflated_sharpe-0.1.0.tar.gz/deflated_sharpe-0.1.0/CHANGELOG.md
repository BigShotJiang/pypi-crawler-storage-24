# Changelog

## [0.1.0] - 2026-03-21

### Added
- Deflated Sharpe Ratio (DSR) — adjusts for multiple testing bias per Bailey & Lopez de Prado (2014)
- Minimum Backtest Length (MinBTL) — minimum trades needed for statistical significance
- Benjamini-Hochberg FDR correction — multi-strategy false discovery rate control
- Regime Decay Detector with triple-confirmation (Bayesian win rate + drawdown exceedance + Mahalanobis OOD)
- Paper verification tests against Bailey & Lopez de Prado 2014
- Phase 15 case study example
- Zero external dependencies
