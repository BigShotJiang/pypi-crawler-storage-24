# Tests for regime detection

from deflated_sharpe.regime import (
    DecayAssessment,
    RegimeDecayDetector,
    RegimeDetectorConfig,
    StrategyBaseline,
    TradeResult,
)


def _make_detector(min_trades: int = 20) -> RegimeDecayDetector:
    baseline = StrategyBaseline(win_rate=0.6, trade_count=100, max_drawdown_pct=15.0)
    config = RegimeDetectorConfig(min_trades=min_trades)
    return RegimeDecayDetector(baseline=baseline, config=config)


def test_all_wins_no_decay():
    det = _make_detector()
    for _ in range(20):
        det.add_trade(TradeResult(is_win=True, pnl=100.0))
    result = det.assess()
    assert not result.decay_confirmed


def test_all_losses_win_rate_decay():
    # Use weak prior (trade_count=20) so 20 losses overwhelm it
    baseline = StrategyBaseline(win_rate=0.6, trade_count=20, max_drawdown_pct=15.0)
    det = RegimeDecayDetector(baseline=baseline, config=RegimeDetectorConfig())
    for _ in range(20):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result = det.assess()
    wr_signal = [s for s in result.signals if s.name == "win_rate_decay"][0]
    assert wr_signal.fired


def test_drawdown_exceedance():
    det = _make_detector()
    # Start with some wins to build equity, then heavy losses to exceed 1.5x baseline MDD (22.5%)
    for _ in range(5):
        det.add_trade(TradeResult(is_win=True, pnl=100.0))
    # Now lose enough to create >22.5% drawdown from peak
    # Peak equity = 500. Need DD > 22.5% → loss > 112.5 from peak
    # 15 losing trades of -100 each = -1500, equity goes to -1000
    # DD = (500 - (-1000)) / 500 = 300% >> 22.5%
    # Also need dd_trade_count >= 10
    for _ in range(15):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result = det.assess()
    dd_signal = [s for s in result.signals if s.name == "drawdown_exceedance"][0]
    assert dd_signal.fired


def test_market_ood():
    det = _make_detector()
    # Fit baseline with tight cluster around (1.0, 0.0, 50.0)
    features = [(1.0 + i * 0.01, 0.0 + i * 0.01, 50.0 + i * 0.1) for i in range(50)]
    det.fit_market_baseline(features)
    # Add 20 trades with extreme features
    for _ in range(20):
        det.add_trade(
            TradeResult(
                is_win=True,
                pnl=100.0,
                atr_ratio=10.0,
                trend_12h_pct=5.0,
                atr_percentile=99.0,
            )
        )
    result = det.assess()
    ood_signal = [s for s in result.signals if s.name == "market_ood"][0]
    assert ood_signal.fired


def test_triple_confirmation_two_signals():
    # Weak prior so win_rate_decay fires alongside drawdown_exceedance
    baseline = StrategyBaseline(win_rate=0.6, trade_count=20, max_drawdown_pct=15.0)
    det = RegimeDecayDetector(baseline=baseline, config=RegimeDetectorConfig())
    for _ in range(5):
        det.add_trade(TradeResult(is_win=True, pnl=100.0))
    for _ in range(15):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result = det.assess()
    assert result.signals_fired >= 2
    assert result.decay_confirmed


def test_cooling_period():
    # Weak prior so decay triggers
    baseline = StrategyBaseline(win_rate=0.6, trade_count=20, max_drawdown_pct=15.0)
    det = RegimeDecayDetector(baseline=baseline, config=RegimeDetectorConfig())
    for _ in range(5):
        det.add_trade(TradeResult(is_win=True, pnl=100.0))
    for _ in range(15):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result = det.assess()
    assert result.decay_confirmed
    # Add 3 more trades (< cooling_period=5)
    for _ in range(3):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result2 = det.assess()
    assert result2.in_cooling
    assert not result2.decay_confirmed


def test_min_trades_insufficient():
    det = _make_detector(min_trades=20)
    for _ in range(10):
        det.add_trade(TradeResult(is_win=False, pnl=-100.0))
    result = det.assess()
    assert not result.decay_confirmed
    assert "Insufficient" in result.reason


def test_fit_market_baseline_too_few_features():
    det = _make_detector()
    # Only 2 features (< 3 required)
    det.fit_market_baseline([(1.0, 0.0, 50.0), (1.1, 0.1, 51.0)])
    # Add trades with features
    for _ in range(20):
        det.add_trade(
            TradeResult(
                is_win=True,
                pnl=100.0,
                atr_ratio=10.0,
                trend_12h_pct=5.0,
                atr_percentile=99.0,
            )
        )
    result = det.assess()
    ood_signal = [s for s in result.signals if s.name == "market_ood"][0]
    assert not ood_signal.fired
