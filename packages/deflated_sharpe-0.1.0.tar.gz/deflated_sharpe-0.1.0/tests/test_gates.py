"""Tests for deflated_sharpe.gates — DSR, MinBTL, BH-FDR."""

from __future__ import annotations

from deflated_sharpe.gates import (
    benjamini_hochberg,
    deflated_sharpe_ratio,
    min_backtest_length,
)


# ── DSR tests ──────────────────────────────────────────────────────────


class TestDeflatedSharpeRatio:
    def test_single_trial_no_penalty(self):
        """M=1: no multiple-testing penalty, sr_max should be 0."""
        dsr, p_value = deflated_sharpe_ratio(
            observed_sr=1.5, num_trials=1, num_obs=252
        )
        # With sr_max=0, DSR = sr / se_sr > 0 → p_value < 0.5
        assert dsr > 0
        assert p_value < 0.5

    def test_high_trials_heavy_penalty(self):
        """M=1000: massive penalty makes a weak SR insignificant."""
        dsr, p_value = deflated_sharpe_ratio(
            observed_sr=0.3, num_trials=1000, num_obs=50
        )
        # sr_max dominates with 1000 trials and only 50 obs → clearly insignificant
        assert p_value > 0.5

    def test_num_obs_below_2_returns_default(self):
        """T<2: not enough observations, return (0.0, 1.0)."""
        assert deflated_sharpe_ratio(1.0, 10, 0) == (0.0, 1.0)
        assert deflated_sharpe_ratio(1.0, 10, 1) == (0.0, 1.0)

    def test_negative_sharpe(self):
        """Negative observed SR should produce negative DSR."""
        dsr, p_value = deflated_sharpe_ratio(
            observed_sr=-1.0, num_trials=5, num_obs=100
        )
        assert dsr < 0
        assert p_value > 0.5

    def test_fat_tailed_returns_larger_se(self):
        """Skewness=-2, kurtosis=9: SE should be larger than normal case."""
        dsr_normal, _ = deflated_sharpe_ratio(
            observed_sr=0.4, num_trials=10, num_obs=60,
            skewness=0.0, kurtosis=3.0,
        )
        dsr_fat, _ = deflated_sharpe_ratio(
            observed_sr=0.4, num_trials=10, num_obs=60,
            skewness=-2.0, kurtosis=9.0,
        )
        # Fatter tails → larger SE → lower DSR (closer to or below zero)
        assert dsr_fat < dsr_normal

    def test_phase15_scenario_m19200_t40_fails(self):
        """Phase 15 reality check: M=19200, T=40 trades → must FAIL DSR gate.

        This reproduces the exact scenario from TradeMemory Phase 15 where
        grid search (19,200 combos) with only ~40 trades per 3-month window
        made it mathematically impossible to pass DSR.
        """
        dsr, p_value = deflated_sharpe_ratio(
            observed_sr=0.5, num_trials=19200, num_obs=40
        )
        assert p_value > 0.05, (
            f"M=19200, T=40 should FAIL DSR gate, got p={p_value}"
        )


# ── MinBTL tests ───────────────────────────────────────────────────────


class TestMinBacktestLength:
    def test_reasonable_positive_result(self):
        """target_sr=1.0, M=10 should return a reasonable positive integer."""
        t = min_backtest_length(target_sr=1.0, num_trials=10)
        assert isinstance(t, int)
        assert t > 0

    def test_target_sr_nonpositive_returns_zero(self):
        """target_sr <= 0 has no meaningful minimum length."""
        assert min_backtest_length(target_sr=0.0, num_trials=10) == 0
        assert min_backtest_length(target_sr=-1.0, num_trials=10) == 0

    def test_more_trials_needs_more_obs(self):
        """M=100 should require more observations than M=1."""
        t1 = min_backtest_length(target_sr=1.0, num_trials=1)
        t100 = min_backtest_length(target_sr=1.0, num_trials=100)
        assert t100 > t1


# ── BH-FDR tests ──────────────────────────────────────────────────────


class TestBenjaminiHochberg:
    def test_empty_list_returns_empty(self):
        """Empty input should return empty list."""
        assert benjamini_hochberg([]) == []

    def test_all_significant(self):
        """All p-values well below alpha → all significant."""
        result = benjamini_hochberg([0.001, 0.002, 0.005], alpha=0.05)
        assert len(result) == 3
        assert all(sig for _, _, sig in result)

    def test_none_significant(self):
        """All p-values above 0.5 → none significant at alpha=0.05."""
        result = benjamini_hochberg([0.6, 0.7, 0.8, 0.9], alpha=0.05)
        assert len(result) == 4
        assert not any(sig for _, _, sig in result)
