"""Paper verification tests — Bailey & Lopez de Prado (2014).

Numerical verification of the Deflated Sharpe Ratio formulas against
the original paper's mathematics. These tests are the trust anchor
for the entire library.

Reference:
    Bailey, D. H., & Lopez de Prado, M. (2014).
    "The Deflated Sharpe Ratio: Correcting for Selection Bias,
     Backtest Overfitting, and Non-Normality."
    Journal of Portfolio Management, 40(5), 94-107.
"""

from __future__ import annotations

import math

from deflated_sharpe.gates import (
    benjamini_hochberg,
    deflated_sharpe_ratio,
    min_backtest_length,
)


class TestGumbelApproximation:
    def test_gumbel_approximation(self):
        """Verify E[Z_max] Gumbel approximation and SR_max boundary.

        Formula (Eq. 2 in Bailey & LdP 2014):
            E[Z_max] = sqrt(2*ln(M)) - [ln(ln(M)) + ln(4*pi)] / [2*sqrt(2*ln(M))]
            SR_max = E[Z_max] * sqrt(1 / (T - 1))

        With M=100, T=1000:
            ln(100) = 4.60517
            z = sqrt(2 * 4.60517) = 3.03485
            E[Z_max] = 3.03485 - (1.52718 + 2.53103) / 6.06970 = 2.3663
            SR_max = 2.3663 * sqrt(1/999) = 0.07487

        When observed_sr == SR_max, DSR should be ~0 (null hypothesis boundary).
        """
        M, T = 100, 1000

        # Compute expected SR_max from Gumbel formula
        ln_m = math.log(M)
        z = math.sqrt(2 * ln_m)
        e_z_max = z - (math.log(math.log(M)) + math.log(4 * math.pi)) / (2 * z)
        sr_max = e_z_max * math.sqrt(1.0 / (T - 1))

        # Verify Gumbel intermediate values
        assert abs(e_z_max - 2.366) < 0.001, f"E[Z_max]={e_z_max}, expected ~2.366"
        assert abs(sr_max - 0.0749) < 0.001, f"SR_max={sr_max}, expected ~0.0749"

        # At the boundary (observed == expected max), DSR ≈ 0, p ≈ 0.5
        dsr, p_value = deflated_sharpe_ratio(sr_max, M, T)
        assert abs(dsr) < 0.1, (
            f"At SR_max boundary, DSR should be ~0, got {dsr}"
        )
        assert abs(p_value - 0.5) < 0.05, (
            f"At SR_max boundary, p should be ~0.5, got {p_value}"
        )


class TestSENonNormality:
    def test_se_non_normality(self):
        """Fat-tailed returns inflate SE(SR), making DSR harder to pass.

        Formula for SE(SR) (Eq. 3 in Bailey & LdP 2014):
            SE(SR) = sqrt([1 - skew*SR + ((kurt-1)/4)*SR^2] / (T-1))

        Normal case (skew=0, kurt=3): SE = sqrt((1 + 0.5*SR^2) / (T-1))
        Fat-tail (skew=-2, kurt=9): SE = sqrt((1 + 2*SR + 2*SR^2) / (T-1))

        Larger SE → lower DSR → higher p-value (harder to be significant).
        """
        sr, M, T = 1.0, 50, 252

        dsr_normal, _ = deflated_sharpe_ratio(sr, M, T, skewness=0.0, kurtosis=3.0)
        dsr_fat, _ = deflated_sharpe_ratio(sr, M, T, skewness=-2.0, kurtosis=9.0)

        assert dsr_fat < dsr_normal, (
            f"Fat-tailed returns should produce lower DSR (larger SE). "
            f"Normal DSR={dsr_normal}, Fat-tail DSR={dsr_fat}"
        )


class TestMinBTLRoundtrip:
    def test_min_btl_roundtrip(self):
        """MinBTL is the exact transition point for DSR significance.

        min_backtest_length(SR*, M) returns T_min such that:
            deflated_sharpe_ratio(SR*, M, T_min).p < 0.05  (passes)
            deflated_sharpe_ratio(SR*, M, T_min - 1).p >= 0.05  (fails)

        This verifies the binary search in min_backtest_length is consistent
        with deflated_sharpe_ratio.
        """
        target_sr, M = 1.0, 10
        t_min = min_backtest_length(target_sr, M)

        assert t_min > 2, f"T_min should be > 2, got {t_min}"

        # At T_min: should pass
        _, p_pass = deflated_sharpe_ratio(target_sr, M, t_min)
        assert p_pass < 0.05, (
            f"At T_min={t_min}, p should be < 0.05, got {p_pass}"
        )

        # At T_min - 1: should fail
        _, p_fail = deflated_sharpe_ratio(target_sr, M, max(t_min - 1, 2))
        assert p_fail >= 0.05, (
            f"At T_min-1={t_min - 1}, p should be >= 0.05, got {p_fail}"
        )


class TestBHFDRTextbook:
    def test_bh_fdr_textbook(self):
        """Textbook BH-FDR example with known outcome.

        Input p-values: [0.005, 0.01, 0.03, 0.04, 0.5], alpha=0.05

        Sorted with BH thresholds:
            k=1: p=0.005 <= (1/5)*0.05 = 0.01  pass
            k=2: p=0.01  <= (2/5)*0.05 = 0.02  pass
            k=3: p=0.03  <= (3/5)*0.05 = 0.03  pass
            k=4: p=0.04  <= (4/5)*0.05 = 0.04  pass
            k=5: p=0.50  <= (5/5)*0.05 = 0.05  fail

        BH step-up: largest k where p_k <= threshold is k=4.
        All strategies at rank 1..4 are significant.
        """
        p_values = [0.005, 0.01, 0.03, 0.04, 0.5]
        result = benjamini_hochberg(p_values, alpha=0.05)

        assert len(result) == 5

        # First 4 should be significant, last one not
        expected_sig = [True, True, True, True, False]
        actual_sig = [sig for _, _, sig in result]
        assert actual_sig == expected_sig, (
            f"Expected significance {expected_sig}, got {actual_sig}"
        )

        # Verify original p-values are preserved
        for i, (orig_idx, p, _) in enumerate(result):
            assert orig_idx == i
            assert p == p_values[i]


class TestDSRMonotonicity:
    def test_dsr_monotonicity(self):
        """More trials -> higher p-value (harder to be significant).

        Fixed SR=0.5, T=252. As M increases from 1 to 10000,
        SR_max increases -> DSR decreases -> p-value strictly increases.

        This is the core intuition: the more strategies you test,
        the higher the bar for statistical significance.
        """
        sr, T = 0.5, 252
        trial_counts = [1, 10, 100, 1000, 10000]
        dsr_values = []

        for m in trial_counts:
            dsr, _ = deflated_sharpe_ratio(sr, m, T)
            dsr_values.append(dsr)

        # DSR strictly decreasing as M increases (more penalty)
        for i in range(len(dsr_values) - 1):
            assert dsr_values[i] > dsr_values[i + 1], (
                f"DSR not monotonically decreasing: "
                f"M={trial_counts[i]} DSR={dsr_values[i]} <= "
                f"M={trial_counts[i + 1]} DSR={dsr_values[i + 1]}"
            )


class TestM1Identity:
    def test_m1_identity(self):
        """When M=1, SR_max=0 and DSR reduces to SR / SE(SR).

        With M=1, there is no multiple-testing correction (you only tested
        one strategy). The DSR becomes a simple t-statistic:

            DSR = SR / SE(SR)
            SE(SR) = sqrt([1 + ((kurt-1)/4)*SR^2] / (T-1))   [for skew=0]

        With SR=1.0, T=252, skew=0, kurt=3:
            SE = sqrt((1 + 0.5 * 1.0) / 251) = sqrt(1.5 / 251) = 0.07731
            DSR = 1.0 / 0.07731 = 12.936
        """
        dsr, p_value = deflated_sharpe_ratio(1.0, 1, 252)

        # Compute expected DSR analytically
        se = math.sqrt(1.5 / 251)  # (1 + 0.5*1^2) / (252-1)
        expected_dsr = 1.0 / se  # 12.936

        assert abs(dsr - expected_dsr) < 0.1, (
            f"M=1 DSR should be {expected_dsr:.4f}, got {dsr}"
        )
        # Highly significant — no multiple-testing penalty
        assert p_value < 0.001


class TestPaperCoreClaim:
    def test_paper_core_claim(self):
        """A modest SR becomes insignificant under heavy multiple testing.

        Bailey & LdP (2014) core insight: many published Sharpe ratios
        that appear significant in isolation become insignificant once
        you account for the number of strategies the researcher tried.

        SR=0.2 with M=200 trials and T=252 daily observations:
        The expected SR_max from 200 independent trials exceeds 0.2,
        making this observed SR statistically indistinguishable from
        selection bias. p > 0.05 -> cannot reject the null.
        """
        dsr, p_value = deflated_sharpe_ratio(
            observed_sr=0.2, num_trials=200, num_obs=252
        )
        assert p_value > 0.05, (
            f"SR=0.2 with M=200 trials should NOT be significant, "
            f"got p={p_value}"
        )
