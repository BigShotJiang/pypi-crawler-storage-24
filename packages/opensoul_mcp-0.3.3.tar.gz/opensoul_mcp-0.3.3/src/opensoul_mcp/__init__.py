"""OpenSoul MCP - Open Source Personality Profiling System."""

__version__ = "0.3.3"
