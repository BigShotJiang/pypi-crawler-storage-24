"""Project scanner."""
