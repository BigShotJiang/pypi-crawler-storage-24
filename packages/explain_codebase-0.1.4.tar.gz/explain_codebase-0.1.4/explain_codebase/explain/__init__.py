"""Explanation engine."""
