"""Analysis helpers."""
