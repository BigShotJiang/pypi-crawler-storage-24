"""Dependency graph helpers."""
