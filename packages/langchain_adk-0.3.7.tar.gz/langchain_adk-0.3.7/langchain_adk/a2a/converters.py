"""Converters between SDK Events and A2A streaming events."""

from __future__ import annotations

from collections.abc import AsyncIterator

from langchain_adk.a2a.types import (
    Artifact,
    TaskArtifactUpdateEvent,
    TaskState,
    TaskStatus,
    TaskStatusUpdateEvent,
    TextPart,
)
from langchain_adk.events.event import Event, EventType


async def events_to_a2a_stream(
    events: AsyncIterator[Event],
    *,
    task_id: str,
    context_id: str,
) -> AsyncIterator[TaskStatusUpdateEvent | TaskArtifactUpdateEvent]:
    """Convert SDK event stream into A2A-compliant streaming events.

    Yields TaskStatusUpdateEvent for status changes and
    TaskArtifactUpdateEvent for content (final answer, tool results).
    """
    async for event in events:
        if event.is_final_response():
            artifact = Artifact(
                parts=[TextPart(text=event.text)],
                name="answer",
            )
            yield TaskArtifactUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                artifact=artifact,
                last_chunk=True,
            )

        elif event.has_tool_calls:
            tc = event.tool_calls[0]
            yield TaskStatusUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                status=TaskStatus(
                    state=TaskState.working,
                    message=None,
                ),
                final=False,
                metadata={"tool_name": tc.tool_name, "tool_input": tc.args},
            )

        elif event.type == EventType.TOOL_RESPONSE:
            responses = event.content.tool_responses
            if responses:
                result_text = responses[0].result or (responses[0].error or "")
                tool_name = responses[0].tool_name
            else:
                result_text = event.text
                tool_name = "unknown"
            artifact = Artifact(
                parts=[TextPart(text=result_text)],
                name=f"tool_result:{tool_name}",
            )
            yield TaskArtifactUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                artifact=artifact,
                last_chunk=True,
            )
