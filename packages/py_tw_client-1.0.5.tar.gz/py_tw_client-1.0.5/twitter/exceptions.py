"""
This module defines a hierarchy of exceptions related to Twitter API errors.

The exceptions provided in this module allow for handling specific error cases that may arise when interacting with the Twitter API, including authentication issues, resource not found errors, rate limitExceeded errors, and general cursor-related exceptions.

Available exceptions:
- BaseTwitterException: A base class for all Twitter-related exceptions.
- NotCursorException: Raised when a cursor-related issue occurs.
- UnauthorizedError: Raised when authentication fails.
- NotFoundError: Raised when a requested resource cannot be found.
- RateLimitError: Raised when the Twitter API rate limit is exceeded.
"""


class BaseTwitterException(Exception):
    pass


class NotCursorException(BaseTwitterException):
    pass


class UnauthorizedError(BaseTwitterException):
    pass


class NotFoundError(BaseTwitterException):
    pass


class RateLimitError(BaseTwitterException):
    pass
