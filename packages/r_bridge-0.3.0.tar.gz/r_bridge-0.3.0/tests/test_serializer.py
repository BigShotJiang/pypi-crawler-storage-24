import math
import datetime
import numpy as np
import pandas as pd
import pytest
from r_bridge.serializer import serialize


# --- Basic scalars ---

def test_none():
    assert serialize(None) is None

def test_bool():
    assert serialize(True) is True
    assert serialize(False) is False

def test_int():
    result = serialize(42)
    assert result == {"__type__": "integer", "value": 42}

def test_float():
    assert serialize(3.14) == pytest.approx(3.14)

def test_float_nan():
    assert serialize(float("nan")) == {"__type__": "nan"}

def test_float_inf():
    assert serialize(float("inf")) == {"__type__": "inf", "sign": 1}
    assert serialize(float("-inf")) == {"__type__": "inf", "sign": -1}

def test_str():
    assert serialize("hello") == "hello"

def test_complex():
    assert serialize(1 + 2j) == {"__type__": "complex", "r": 1.0, "i": 2.0}


# --- Collections ---

def test_homogeneous_int_list():
    result = serialize([1, 2, 3])
    assert result == {"__type__": "integer_vector", "value": [1, 2, 3]}

def test_homogeneous_float_list():
    result = serialize([1.0, 2.0])
    assert result == {"__type__": "numeric_vector", "value": [1.0, 2.0]}

def test_homogeneous_str_list():
    result = serialize(["a", "b"])
    assert result == {"__type__": "character_vector", "value": ["a", "b"]}

def test_homogeneous_bool_list():
    result = serialize([True, False])
    assert result == {"__type__": "logical_vector", "value": [True, False]}

def test_heterogeneous_list():
    result = serialize([1, "a"])
    assert result == {"__type__": "list", "value": [{"__type__": "integer", "value": 1}, "a"]}

def test_empty_list():
    result = serialize([])
    assert result == {"__type__": "list", "value": []}

def test_dict():
    result = serialize({"a": 1, "b": "x"})
    assert result == {"__type__": "named_list", "value": {"a": {"__type__": "integer", "value": 1}, "b": "x"}}


# --- NumPy ---

def test_numpy_1d_float():
    arr = np.array([1.0, 2.0, 3.0])
    result = serialize(arr)
    assert result == {"__type__": "numeric_vector", "value": [1.0, 2.0, 3.0]}

def test_numpy_1d_int():
    arr = np.array([1, 2, 3], dtype=np.int32)
    result = serialize(arr)
    assert result == {"__type__": "integer_vector", "value": [1, 2, 3]}

def test_numpy_1d_bool():
    arr = np.array([True, False])
    result = serialize(arr)
    assert result == {"__type__": "logical_vector", "value": [True, False]}

def test_numpy_2d():
    arr = np.array([[1, 2], [3, 4]], dtype=np.float64)
    result = serialize(arr)
    assert result["__type__"] == "matrix"
    assert result["nrow"] == 2
    assert result["ncol"] == 2
    assert result["data"] == [1.0, 2.0, 3.0, 4.0]

def test_numpy_nan_in_array():
    arr = np.array([1.0, float("nan"), 3.0])
    result = serialize(arr)
    assert result["__type__"] == "numeric_vector"
    assert result["value"][1] == {"__type__": "nan"}


# --- Pandas ---

def test_dataframe():
    df = pd.DataFrame({"x": [1, 2], "y": [3.0, 4.0]})
    result = serialize(df)
    assert result["__type__"] == "dataframe"
    assert "x" in result["columns"]
    assert "y" in result["columns"]

def test_dataframe_with_na():
    df = pd.DataFrame({"x": pd.array([1, None], dtype=pd.Int64Dtype())})
    result = serialize(df)
    col = result["columns"]["x"]
    assert col["__type__"] == "integer_vector"
    assert col["value"][1] == {"__type__": "na", "na_type": "integer"}

def test_series_numeric():
    s = pd.Series([1.0, 2.0], name="v")
    result = serialize(s)
    assert result == {"__type__": "numeric_vector", "value": [1.0, 2.0]}

def test_categorical():
    s = pd.Categorical(["a", "b", "a"], categories=["a", "b"])
    result = serialize(s)
    assert result["__type__"] == "factor"
    assert result["levels"] == ["a", "b"]
    assert result["ordered"] is False


# --- Datetime ---

def test_datetime():
    dt = datetime.datetime(2026, 3, 21, 12, 0, 0)
    result = serialize(dt)
    assert result["__type__"] == "posixct"
    assert "2026-03-21" in result["iso8601"]

def test_date():
    d = datetime.date(2026, 3, 21)
    result = serialize(d)
    assert result == {"__type__": "date", "iso8601": "2026-03-21"}


# --- Unknown type ---

def test_unknown_type_raises():
    class Foo:
        pass
    with pytest.raises(TypeError):
        serialize(Foo())
