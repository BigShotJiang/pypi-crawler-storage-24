## [13.17.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.17.0...v13.17.1) (2026-03-13)


### Bug Fixes

* **release:** crates publish skips correctly when no new version ([dffa29c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/dffa29ca10e09dd79981962a9030ba44e5d09c80))

# [13.17.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.1...v13.17.0) (2026-03-13)


### Bug Fixes

* **cache:** per-threshold error isolation + configurable workers in multi-threshold fan-out ([e32ac14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e32ac1443decf88a81a3c0ac980cb14320116891))
* **checkpoint:** eliminate 4× redundant Vision downloads in multi-threshold network path ([91f8e17](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/91f8e17cfafb79c573cd273fd72f8590c0f899f2))
* **kintsugi:** add lightweight_mutation_projection_mode=drop for DELETE FROM ([ad43bd1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad43bd1e09119247509e8757b1d34b7d52f149e6))
* **kintsugi:** auto-delete stale left-straddling bars after _do_replace async race ([ad06650](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad06650705b3a1597c8c477c8d2f0e094f3397ad))
* **kintsugi:** reduce batch_days 3650→365 to prevent RSS memory pressure ([8d8c6cc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8d8c6ccf57b73bd85096d83491ff71720abb7c26))
* **kintsugi:** replace heavyweight ALTER TABLE DELETE with lightweight DELETE FROM ([c9cb5c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9cb5c5531a8b789fde0b8583ae6db15c6cc6a3b)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)
* **kintsugi:** split Vision exception handling to avoid false negative cache entries ([fa40c9d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fa40c9d85408b2c11510b6c00dc1f523c55921a2))
* **kintsugi:** T-7 Vision cutoff + remove batch-level Redis write lock ([28100f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/28100f9329e18a39398012d5b89c4e6e24e4a77e))
* **monit:** raise all memory thresholds to 70% of bigblack RAM ([7f11333](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7f11333a9c393eb7ba6d1804244a313616c062d6))
* **monit:** set kintsugi memory alert at 70% of bigblack RAM (42700 MB) ([4e4ae29](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4e4ae29d9f4c293794b97190af06d0d2f37ba7dc))
* **seeder:** 16→8 workers, raise MemoryMax 2G→6G ([191137f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/191137f8875c317c79af8e4eab68a518537ca9be))
* **seeder:** MEM-016v2 — per-day staging files + streaming merge ([0e64dbd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0e64dbd361d495af429f8385a0e303dbb9214273))
* **seeder:** MEM-017 sequential per-day streaming appends ([2f55034](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2f55034741429460f6de1fb1ebdc1052ae7345ad))
* **seeder:** MEM-018 bounded future submission — prevent DataFrame accumulation ([d941fb2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d941fb2f07947b3a40a09db5ea7d3732aea830ac))
* **seeder:** MEM-021 mimalloc + MEM-024 malloc_trim to eliminate glibc arena RSS plateau ([c416024](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c41602446f75cd6a8047501fb451e150510876f9)), closes [hi#water-mark](https://github.com-terrylica/hi/issues/water-mark)
* **seeder:** move state file /tmp → /var/tmp (monit PrivateTmp isolation) ([063c0f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/063c0f8fddd5e7b83921f1b523fdeef46631d910))
* **seeder:** raise MemoryMax to 2G (4 workers × 300-400MB polars DataFrames) ([14775f3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/14775f3d8f67e3e872c198ec697cf0f41a44341e))
* **seeder:** resilient staging merge — skip corrupt days instead of aborting month ([f8eb374](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8eb374150ef8baacdb31d42aba1286876f5cc81))
* **seeder:** use httpx for Vision downloads (add as dependency) ([df2ab4e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/df2ab4eb4e758a8b0977699047561d5d042a3ab2))
* **seeder:** use requests instead of httpx for Vision downloads (requests in venv) ([ea5bb40](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea5bb40fd74db51c4d1d468ab66a7ea34f411cbf))
* **storage:** convert us Int64 timestamps to ms in write_ticks ([bbb1545](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bbb154583c9c8effac87cdad588395a7dfec5213))
* **storage:** use diagonal_relaxed in lazy concat to tolerate schema drift (column_8) ([44d1c09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44d1c0978e6b86dbf5a262d94a3f10d126954a21))
* **systemd:** remove LimitNPROC=4096 from all service templates ([9bdb1e1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bdb1e119e6655007581091ae08ec64b9e1fc5a7)), closes [#107](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/107)


### Features

* **audit:** Task 9 cross-cutting synthesis - hardcoded values resolution strategy ([19e70d0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/19e70d0a65e2d1702c68eea2c2af297ea2dd6f98))
* **cache:** multi-threshold single-Parquet-read fast path + populate_range script ([9bf5dd2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bf5dd2d79646e253fd5fa41ac961d101a27c6d8))
* **docs:** add symbol registry implementation plan ([4454b0e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4454b0e8e8b238fc14e6d466eb5715e615f16c3e))
* implement quick-win fixes for symbol registry integration ([21a3d08](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/21a3d088f5861ad61a68e40c22256743a6e9df4c))
* **kintsugi:** add Parquet-first data source priority (local cache > Vision > REST) ([ffebf2e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ffebf2e2621b014673e5e916917d4339ea4fc15c))
* **seeder:** proactive Parquet tick cache seeder for bigblack (Issue [#270](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/270)) ([302717d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/302717d7c7f6305a7c669302a3e701f0dc0785bc))


### Performance Improvements

* **kintsugi:** increase batch_days from 60 to 3650 for single-pass gap closure ([e2db49e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e2db49e0b0e8f61c378b78aabfb37e1299836445))
* **kintsugi:** raise MAX_CONCURRENT_REPAIRS 8→24 based on empirical step-up profiling ([cd881ec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cd881eca23fd5d24bf5b8158db4aa8494f318066))
* reuse thread-local ClickHouse connection in fatal_cache_write ([9efa17d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9efa17d6770d2feebd417106111aa5507c70d1f7))
* **seeder:** MEM-016 month-level batch writes — eliminate O(N²) file scan accumulation ([7353c5f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7353c5f2567f55acaf6cd6c199218dfa9ad5849c))
* **storage:** MEM-015 anti-join dedup — avoid is_in deprecation path (+1954 MB) ([32aac52](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32aac52cf5fddf24b0fff45e633e0b17d2bdbac7))
* **storage:** MEM-015 column projection in write_ticks() — 95.7% memory reduction ([8b07931](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b0793133e72aa73eb9383b7910f7df6dbb4362e))
* **storage:** MEM-015 schema-normalize before sink_parquet to enable streaming engine ([ad3283e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad3283e29b950e0e0a2106e6ff16da1d877e81b6))
* **storage:** MEM-015 streaming sink_parquet — bounded memory for write_ticks() ([3e1cd78](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3e1cd780a4d9edd1bb97b81ccc643941370c82c4))
* **storage:** MEM-015 two-source scan_parquet streaming — write new rows to temp file first ([40f8588](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/40f8588ffcb6636fa34f16df1e110b407488aec0))

## [13.16.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.0...v13.16.1) (2026-03-12)


### Bug Fixes

* restore BTCUSDT thresholds [250,500,750,1000] — focus mode complete ([7e5c653](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7e5c65398069c4271d1977a742ccc1cf1f74064a))
* **stathera:** exclude first-bar artifacts from gap count + active repair visibility ([4facb9f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4facb9f074de649da6685fe7f5da5ac4fd861dee)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)

# [13.16.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.4...v13.16.0) (2026-03-12)


### Features

* dynamic Parquet parallelism + peak resource tracking in heartbeat ([79d9512](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/79d9512396d133a82f619e27f1ab8c61f84e9fd0))
* increase max_concurrent_parquet to 64, unleash full 5115-shard backfill ([f19311e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f19311e184a3b179b0d91098a3f4ce309963878f))


### Performance Improvements

* eliminate Redis lock serialization bottleneck in kintsugi ([8f2b7aa](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8f2b7aac198bcaaf70b8aa1126329e35d498a3bf))
* tune MAX_CONCURRENT_REPAIRS=13 (Vision download safe) ([f6ecee9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f6ecee930465b2c42b9ac0cd9de4487c520f53a8))

## [13.15.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.3...v13.15.4) (2026-03-12)


### Bug Fixes

* kintsugi override false-positive UNHEALTHY + persist parallelism settings ([ea14a97](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea14a97d75e565158d57be3b58f9527895331d6a))

## [13.15.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.2...v13.15.3) (2026-03-12)


### Bug Fixes

* resolve kintsugi connection pool exhaustion + schema.sql loading resilience ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295), [#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([d686a49](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d686a4906f0e04db496ac9d0dd64bc5b89c8524d))

## [13.15.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.1...v13.15.2) (2026-03-12)


### Bug Fixes

* **test:** update BTCUSDT threshold expectation to match registry focus mode ([3a20942](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3a20942b43c97ac3fae9018865308338f22a299a))

## [13.15.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.0...v13.15.1) (2026-03-12)


### Bug Fixes

* **test:** update KintsugiResult ariadne_used→had_anchor_tid ([d9cb378](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d9cb37819dbfc506c0f59272b9c7f2ad93e31caf))

# [13.15.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.14.0...v13.15.0) (2026-03-12)


### Bug Fixes

* **kintsugi:** cast incomplete bar column types to match Arrow schema ([0092d26](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0092d26a8f14c6ac8b28242d3f5e8f4a11760f46))
* **kintsugi:** CLI max_repairs falls through to KintsugiConfig env var when unset ([5372dbb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5372dbb0a3b580856bbc2a62aee26686ebcfff7a))
* **kintsugi:** normalize incomplete bar schema to match Arrow frames ([900adad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/900adadc1e6b62a8842f53a560ac0d4006ab81c8))
* **registry:** filter_pairs_by_registry checks thresholds, not just symbol enabled ([bd90565](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bd905652359847e4d16956723256bf1c16416acb))


### Features

* **registry+kintsugi:** symbols.toml as SSoT (BTCUSDT@250 only); day-start-fill invariant ([#265](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/265)) ([5d5624f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d5624f8b74470065e2edbee0d492f28919c7dbb))

# [13.14.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.13.0...v13.14.0) (2026-03-11)


### Bug Fixes

* **config:** remove unnecessary lambda in default_factory ([82f2ba5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/82f2ba5e276776b69533506f70e9ed378fd9a104))
* **data-source:** enforce spot-only policy, remove structural gap concept ([89921f5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/89921f5d24fb7a0fd6e7f078c91a6f04877b86fc)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264) [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)
* **monit:** remove kintsugi memory limit, revert workers to 4 ([5164126](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5164126bf819e4b43a1abf1a64331ff0b4da5470))
* restore _is_valid_parquet re-export removed by ruff auto-fix ([2c0f636](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c0f636da76ad02a73e98f7b5d81e1a95b5c47b7))
* **stathera:** day_boundary_exclusion time-gap check + symbol registry gating ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([0f35ce2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f35ce28addc66bc64600268b78806906003149d))
* **stathera:** remove day_boundary_exclusion — all tid_delta > 0 are gaps ([26fae60](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/26fae60130d03b8249589ab457d90ec484f7b034))


### Features

* **config:** centralize 60+ hardcoded constants into pydantic-settings ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2dcc2c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2dcc2c59d503dc0ed872c4e1fc825e4b3f1e89f4))
* **kintsugi:** outer shard parallelism via ThreadPoolExecutor ([fe8571f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fe8571f6ed3f78e7bb31a2134815dd03305a461b))
* **streaming:** Rust-native UTC midnight processor reset in LiveBarEngine ([47bf2c9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/47bf2c9f29d578d80e92f99aee29da8665a0749c)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)

# [13.13.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.12.0...v13.13.0) (2026-03-11)


### Features

* **kintsugi:** parallel day repairs within batch via ThreadPoolExecutor ([db710a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db710a7352fcde1101600b3de57ddf0dbd0592a6))

# [13.12.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.2...v13.12.0) (2026-03-11)


### Features

* **kintsugi:** multi-day batch processing per shard repair ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2340338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23403389334dc95b72a0bd79c9030d53223aac40))

## [13.11.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.1...v13.11.2) (2026-03-11)


### Bug Fixes

* improve sidecar_api log clarity — no more exc_info tracebacks for expected fallbacks ([9bb64c2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bb64c2feeb108a07dc03b72ee59ab66f86de318))
* invert cross_midnight health logic — healthy when kintsugi IS healing ([db591d3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db591d32d099e4eac30264e3303ebf10fe4bf8b5))
* pre-filter disabled symbols in sidecar gap-fill ([857659f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/857659fa75bf6f1b1e316c9b86b485c6eb9a84cd))

## [13.11.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.0...v13.11.1) (2026-03-11)


### Bug Fixes

* make symbol registry tests work with disabled symbols ([cb553d7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb553d79d51b0658403054980a8c82499cf5126b))

# [13.11.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.10.0...v13.11.0) (2026-03-11)


### Bug Fixes

* cross-midnight bars no longer clobber stathera_gaps health check ([5d05a14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d05a14a2b312ff410cb6ca06b006421ea553c09))
* day_boundary_exclusion() was hiding 172 real gaps from kintsugi ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([96c5c76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/96c5c76a55a3df638b8c61773c6b2e77ded9023c))
* enforce symbol registry enabled gate in kintsugi, backfill, detect_gaps ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([a83689a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a83689a75bafd09cc51bf58e1eb4da2834334edc))
* heartbeat Telegram respects symbol registry + reduce lock noise ([0512827](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/05128276cb95beba7c8c8c4ffaa916cb5278a6d1))


### Features

* adaptive sleep in kintsugi daemon — skip idle time when shards remain ([441e7c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/441e7c6c60057056f2077f5c6f2db7232460099f))

# [13.10.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.9.0...v13.10.0) (2026-03-11)


### Bug Fixes

* filter cross-midnight bars in streaming + dead-letter replay ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([ba02338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ba023386c8e46e26b9c133bedca48f7db2b082f8)), closes [hi#threshold](https://github.com-terrylica/hi/issues/threshold) [264/#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)


### Features

* add odb-telemetry skill for production monitoring and diagnostics ([264fed3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/264fed3a64fbfa13d5b5ccc0922b7880d473c366))

# [13.9.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.8.0...v13.9.0) (2026-03-11)


### Bug Fixes

* eliminate cross-midnight bar sources causing Sisyphean kintsugi cascade ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264), [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)) ([7bf3721](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7bf3721a521701b4fe37f4e1d1b41269e59462c6))


### Features

* **skill:** add auto-healing guards to odb-deploy-verification ([#261](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/261)) ([7469d31](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7469d31dd1036cb0b1011ce0385798d3bc7d73c2))

# [13.8.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.7.0...v13.8.0) (2026-03-10)


### Bug Fixes

* allow kintsugi to repair interior intra-day gaps ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([b26c343](https://github.com/terrylica/opendeviationbar-py/commit/b26c3433df3c7632a1f6baf7682e6a3c63d9fa27))
* **skill:** correct kintsugi_log column names in deploy verification ([df83aee](https://github.com/terrylica/opendeviationbar-py/commit/df83aeef6ce20bb4c08740d41f0ea14b9fc9d041))


### Features

* gap repair acceleration with Puck + Niffler (Issue [#257](https://github.com/terrylica/opendeviationbar-py/issues/257), [#158](https://github.com/terrylica/opendeviationbar-py/issues/158)) ([bf5b2e8](https://github.com/terrylica/opendeviationbar-py/commit/bf5b2e8b49316562fc8acdfa96dbab9b4bec5ac6))

# [13.7.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.6.6...v13.7.0) (2026-03-10)


### Bug Fixes

* prevent sidecar state loss on brief CH blips ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([bbb53b1](https://github.com/terrylica/opendeviationbar-py/commit/bbb53b14c87f178b043195bd190e837a02f94ac8)), closes [#198](https://github.com/terrylica/opendeviationbar-py/issues/198)


### Features

* add odb-deploy-verification skill (58-point checklist) ([848e46a](https://github.com/terrylica/opendeviationbar-py/commit/848e46afd1710c0b34934569284e45286564c47e))

## [13.6.6](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.5...v13.6.6) (2026-03-10)


### Bug Fixes

* resolve circular import in CLICKHOUSE_TRANSIENT_ERRORS ([25368b9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/25368b914c05ea484d2dfdfc64d3c79ffe42e1df))

## [13.6.5](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.4...v13.6.5) (2026-03-10)


### Bug Fixes

* sync workspace dep versions in semantic-release prepareCmd ([6998d47](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6998d470eab55810463322ecb4e8685335683440))

## [13.6.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.3...v13.6.4) (2026-03-10)


### Bug Fixes

* wire internal crate deps to workspace SSoT via inheritance ([c46d8bd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c46d8bd327044e9ac70fee3c7a01e8117ecfba1f))

## [13.6.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.2...v13.6.3) (2026-03-10)


### Bug Fixes

* add take_gap_event_watcher mock to all sidecar watchdog tests ([32580cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32580cdea482f69d1a000a22d9bedd616bee6000))

## [13.6.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.1...v13.6.2) (2026-03-10)


### Bug Fixes

* mock take_gap_event_watcher in watchdog test to prevent JSON serialization error ([a89d488](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a89d4882c72864d9f70a40d1daffd99905ae8fcc))

## [13.6.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.0...v13.6.1) (2026-03-10)


### Bug Fixes

* test default watchdog timeout (600s, not 300s) ([cb47d6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb47d6c9ebb2f37b6784c85d3946709a2073790e))

# [13.6.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.1...v13.6.0) (2026-03-10)


### Bug Fixes

* **#257 phase 0a:** rate limiter CAS loop, fetch_max, Spot weight=4 for aggTrades ([abac1f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/abac1f8dc7abaa9d64f804a6acc25fd4fe4c0492)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#259:** critical row-index bug in kintsugi, dangling forex test imports ([c9972a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9972a5cdca5204a958e1cbe61de55380ba6ec76)), closes [#259](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/259)
* **heartbeat+kintsugi:** day-boundary gap classification, today-guard sentinel, human-readable Telegram ([1294131](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/12941312b36e2aca9d3e10c311c87969e9849898))
* pre-release formatting and config test fixes ([95ff444](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/95ff444b62f03e8fa47a09f6356786fb68ee2d37))
* use loguru instead of warnings.warn for invalid TELEGRAM_LOG_LEVEL ([5b25f8e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5b25f8e554b13a7571cb6e087300912abe4de0fa))
* validate FLUSH_THRESHOLD env var + add bounded flush tests ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([a06e086](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a06e08649f5a082046be3dc8732e97f8c86eccf2))


### Features

* **#257 phase 1:** SSE gap_detected event broadcast in sidecar ([acb0d0d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/acb0d0d787d07fa08248080c52ac83aafd02b5e6)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phase 2a:** parallel aggTrades fetcher with JoinSet+Semaphore ([78bb30d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/78bb30dd9776db370dcdd611a79c3f8d79ddb9fb)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1-2a:** gap detection submodule (event, command, detector) ([f8404a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8404a7f65778ade75f1fb7bc3d42f522deabf29)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1,2c:** PyO3 gap bindings (PyGapEventWatcher, fill_gap) ([7080d2a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7080d2ad808af2f7223da132e97e21ab849d6b71)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 2-2c:** live engine gap detection + command channel fill_gap() ([b4f9041](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b4f9041c8d0de1728a01a00ee72876b9c8cd4951)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* bounded ClickHouse INSERT — flush every 10K bars during day processing ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([44f4f54](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44f4f54cb1a8ad99db71705d20b853c6ddfa97c6)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.5.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.0...v13.5.1) (2026-03-09)


### Bug Fixes

* **release:** fetch and reconcile with remote in preflight ([04aedeb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04aedeb7ea8284c482914bb21813353b11da4c5b))

# [13.5.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.4.0...v13.5.0) (2026-03-09)


### Features

* add ClickHouse password auth support ([#201](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/201)) ([8a70953](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a70953ddff20f8b2e52bef5493f3d283debbd42))
* add OPENDEVIATIONBAR_TELEGRAM_LOG_LEVEL env var ([#243](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/243)) ([9595fa4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9595fa433b6c7663a284fca3bea2f48c98e7aa22))
* **monit:** detailed Telegram health reports with UUID and LOUD failure alerts ([87e20e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87e20e0e9e16de4b127a3675c88deede6bfd4509))

# [13.4.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.3.0...v13.4.0) (2026-03-09)


### Bug Fixes

* **clickhouse:** crash-safe replace with overlapping DELETE predicate ([9b343b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9b343b493c808623953eb46fb6f4340e98194c20))
* **kintsugi:** cap day-recompute to one day per pass in day-mode Ouroboros ([be30451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/be304519217e81e39e61c9a4cf86826f6b0c639f))
* **vision:** cache ALL failures in Redis negative cache, not just 404s ([51d2d84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51d2d847c4db37a938103d9b6e8f9e1e7b6d2a67))


### Features

* **heartbeat:** deterministic hotfix detection via mtime comparison ([31984ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31984aedb606e41eb0c6d40291541449ce17bce9))
* **kintsugi:** Vision-first data source priority for day-recompute ([d4eaae0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4eaae01e42788030ae7cb27e09bf0767872e973))

# [13.3.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.2.0...v13.3.0) (2026-03-09)


### Features

* **issue-256:** add write-time registry gate to ClickHouse layer ([969af12](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/969af12f4c367981eecbd140f834e12faa6d4445))
* **monitoring:** add delta tracking to heartbeat for repair progress visibility ([3457e89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457e89ebc33f98efb98f125fc8fea7a202a85c0))
