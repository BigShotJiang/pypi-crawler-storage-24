CMD = """\
input_fa={input.fasta}
if [[ "{input.fasta}" == *.gz ]]; then
    input_fa=$(echo {input.fasta} | sed 's/\\.gz$//')
    gunzip -c {input.fasta} > $input_fa
fi
addl_opts=""
if [ -n "{input.pfam_hits}" ]; then addl_opts="$addl_opts --retain_pfam_hits {input.pfam_hits}"; fi
if [ -n "{input.blastp_hits}" ]; then addl_opts="$addl_opts --retain_blastp_hits {input.blastp_hits}"; fi
TransDecoder.Predict -t $input_fa $addl_opts {params.options} > {log} 2>&1
"""
