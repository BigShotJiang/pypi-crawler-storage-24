CMD = """\
output_dir=$(dirname {output.pep})
rm -rf $output_dir
input_fa={input.fasta}
if [[ "{input.fasta}" == *.gz ]]; then
    input_fa=$(echo {input.fasta} | sed 's/\\.gz$//')
    gunzip -c {input.fasta} > $input_fa
fi
gtm_opt=""
if [ -n "{input.gene_trans_map}" ]; then gtm_opt="--gene_trans_map {input.gene_trans_map}"; fi
TransDecoder.LongOrfs -t $input_fa -O $output_dir $gtm_opt {params.options} > {log} 2>&1
"""
