CMD = """\
options="{params.options}"
if [ -n "{output.csv}" ]; then options="$options -csvStats {output.csv}"; fi
snpEff ann \
    -dataDir {params.datadir} \
    -v \
    $options \
    {params.genome_name} \
    {input.vcf} \
    > {output.vcf} 2>{log}
"""
