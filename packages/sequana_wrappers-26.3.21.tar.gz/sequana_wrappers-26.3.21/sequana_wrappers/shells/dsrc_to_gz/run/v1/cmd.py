CMD = """\
dsrc d -s -t{threads} {params.options} {input} | pigz -p {threads} > {output} > {log} 2>&1
pigz -p {threads} --test {output} >> {log} 2>&1
rm -f {input}
"""
