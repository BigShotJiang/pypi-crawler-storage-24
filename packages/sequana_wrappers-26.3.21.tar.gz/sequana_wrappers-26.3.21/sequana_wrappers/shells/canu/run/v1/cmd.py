CMD = """\
output_dir=$(dirname {output})
filename=$(basename {output})
prefix=$(echo $filename | sed 's/\\.contigs\\.fasta//')
rm -f $output_dir/canu{params.step}.done $output_dir/canu{params.step}.failed
canu {params.step} \
    -p $prefix \
    -d $output_dir \
    genomeSize={params.genome_size} \
    maxThreads={threads} \
    useGrid=false \
    {params.options} \
    -{params.preset} {input} > {log} 2>&1
"""
