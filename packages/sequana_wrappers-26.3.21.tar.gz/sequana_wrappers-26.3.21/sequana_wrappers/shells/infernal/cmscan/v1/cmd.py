CMD = """\
profile=$(echo {input.profile} | sed 's/\\.i1[mifp]$//')
out_cmd=""
if [ -n "{output.outfile}" ]; then out_cmd="$out_cmd -o {output.outfile}"; fi
if [ -n "{output.tblout}" ]; then out_cmd="$out_cmd --tblout {output.tblout}"; fi
if [ -n "{params.score_threshold}" ]; then
    thresh="-T {params.score_threshold}"
else
    thresh="-E {params.evalue_threshold}"
fi
cmscan $out_cmd $thresh {params.extra} \
    --cpu {threads} $profile {input.fasta} 2> {log}
"""
