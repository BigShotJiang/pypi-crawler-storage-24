CMD = """\
cmpress -F {input.cm} > {log} 2>&1
"""
