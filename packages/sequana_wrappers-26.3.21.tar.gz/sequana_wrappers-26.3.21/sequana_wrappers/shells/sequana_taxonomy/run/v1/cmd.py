CMD = """\
outdir=$(echo {output.html} | cut -d'/' -f1)
cmd="sequana_taxonomy --input-file1 {input.fastq1}"
nfiles=$(echo {input} | wc -w)
if [ $nfiles -gt 1 ]; then
    cmd="$cmd --input-file2 {input.fastq2}"
fi
$cmd \
    --thread {threads} \
    --databases {params.databases} \
    --output-directory $outdir \
    --level {params.level} \
    {params.options} > {log} 2>&1
touch {output.unclassified}
"""
