CMD = """\
right_opt=""
if [ -n "{input.right}" ]; then
    input_cmd="--left {input.left} --right {input.right}"
else
    input_cmd="--single {input.left}"
fi
align_and_estimate_abundance.pl \
    --seqType fq \
    $input_cmd \
    --transcripts {input.fasta} \
    --est_method {params.est_method} \
    --trinity_mode \
    --SS_lib_type {params.lib_type} \
    --thread_count {threads} \
    --output_dir {output.outdir} \
    --prep_reference > {log} 2>&1
"""
