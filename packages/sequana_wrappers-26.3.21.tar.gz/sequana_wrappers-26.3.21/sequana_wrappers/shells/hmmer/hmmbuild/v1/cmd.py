CMD = """\
hmmbuild {params.options} --cpu {threads} {output.hmm} {input.msa} > {log} 2>&1
"""
