CMD = """\
profile=$(echo {input.profile} | sed 's/\\.h3[mifp]$//')
out_cmd=""
if [ -n "{output.outfile}" ]; then out_cmd="$out_cmd -o {output.outfile}"; fi
if [ -n "{output.tblout}" ]; then out_cmd="$out_cmd --tblout {output.tblout}"; fi
if [ -n "{output.domtblout}" ]; then out_cmd="$out_cmd --domtblout {output.domtblout}"; fi
if [ -n "{params.score_threshold}" ]; then
    thresh="-T {params.score_threshold}"
else
    thresh="-E {params.evalue_threshold}"
fi
hmmscan $out_cmd $thresh --cpu {threads} {params.extra} \
    $profile {input.fasta} 2> {log}
"""
