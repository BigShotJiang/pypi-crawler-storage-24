CMD = """\
pbunzip2 -p{threads} --test {input} > {log} 2>&1
pbunzip2 -p{threads} {input} | pigz -p {threads} > {output} 2>> {log}
pigz -p {threads} --test {output} >> {log} 2>&1
rm -f {input}
"""
