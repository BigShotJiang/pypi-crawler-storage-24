CMD = """\
polypolish {params.options} {input.assembly} {input.alignments} 1>{output.fasta} 2>{log}
"""
