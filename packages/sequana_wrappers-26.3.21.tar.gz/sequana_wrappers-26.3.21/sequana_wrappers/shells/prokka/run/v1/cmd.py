CMD = """\
outdir=$(dirname {output.gff})
prefix=$(basename {output.gff} .gff)
prokka --force {params.options} \
    --cpus {threads} \
    --outdir $outdir \
    --prefix $prefix \
    {input.assembly} > {log} 2>&1
"""
