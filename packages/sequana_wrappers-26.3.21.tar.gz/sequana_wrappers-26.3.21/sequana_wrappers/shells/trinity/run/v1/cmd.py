CMD = """\
outdir=$(dirname {output.fasta})
max_memory="10G"
if [ "{resources.mem_gb}" != "" ] && [ "{resources.mem_gb}" != "0" ]; then
    max_memory="{resources.mem_gb}G"
fi
R1={params.left}
seqtype="fq"
if [[ "$R1" == *.fa ]] || [[ "$R1" == *.fasta ]]; then seqtype="fa"; fi
right_opt=""
if [ -n "{params.right}" ]; then
    right_opt="--right {params.right}"
    input_cmd="--left {params.left} $right_opt"
else
    input_cmd="--single {params.left}"
fi
Trinity $input_cmd \
    --CPU {threads} \
    --max_memory $max_memory \
    --seqType $seqtype \
    --output $outdir \
    {params.options} > {log} 2>&1
new_fasta=$(dirname $outdir)/$(basename $outdir).Trinity.fasta
if [ -f $new_fasta ]; then
    mv $new_fasta $outdir/Trinity.fasta
    mv $(dirname $outdir)/$(basename $outdir).Trinity.fasta.gene_trans_map $outdir/Trinity.fasta.gene_trans_map
fi
"""
