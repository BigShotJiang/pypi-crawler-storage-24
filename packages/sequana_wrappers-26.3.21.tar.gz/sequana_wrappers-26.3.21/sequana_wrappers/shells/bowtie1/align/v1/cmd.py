CMD = """\
prefix=$(echo "{input.index}" | sed 's/\\.1\\.ebwt$//')
if [ $(echo "{input.fastq}" | wc -w) -eq 2 ]; then
    reads="-1 $(echo {input.fastq} | cut -d' ' -f1) -2 $(echo {input.fastq} | cut -d' ' -f2)"
else
    reads="{input.fastq}"
fi
(bowtie -S {params.options} -p {threads} -x $prefix $reads \
 | samtools view -Sbh - > {output.bam}) > {log} 2>&1
samtools sort -@ {threads} -o {output.sorted} {output.bam} >> {log} 2>&1
samtools index {output.sorted} >> {log} 2>&1
"""
