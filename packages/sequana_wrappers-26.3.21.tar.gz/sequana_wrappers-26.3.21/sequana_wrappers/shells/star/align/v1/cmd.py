CMD = """\
genomeDir=$(dirname {input.index})
suffix="_Aligned.sortedByCoord.out.bam"
prefix=$(echo {output.bam} | sed "s/$suffix//")
annotation_opt=""
if [ -n "{input.annotation}" ]; then
    annotation_opt="--sjdbGTFfile {input.annotation} --sjdbOverhang {params.sjdbOverhang}"
    if [[ "{input.annotation}" == *.gff ]] || [[ "{input.annotation}" == *.gff3 ]]; then
        annotation_opt="$annotation_opt --sjdbGTFtagExonParentTranscript Parent"
    fi
fi
STAR --genomeDir $genomeDir \
    --twopassMode Basic \
    --twopass1readsN -1 \
    --readFilesIn {input.fastq} \
    --runThreadN {threads} \
    --genomeLoad NoSharedMemory \
    --outSAMtype {params.outSAMtype} \
    --readFilesCommand {params.readFilesCommand} \
    --outFileNamePrefix ${{prefix}}_ \
    $annotation_opt \
    {params.options} > {log} 2>&1
"""
