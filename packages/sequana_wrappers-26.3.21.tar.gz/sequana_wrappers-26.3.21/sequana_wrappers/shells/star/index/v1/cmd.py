CMD = """\
wkdir=$(dirname {output.done})
mkdir -p $wkdir
annotation_opt=""
if [ -n "{input.annotation}" ]; then
    annotation_opt="--sjdbGTFfile {input.annotation} --sjdbOverhang {params.sjdbOverhang}"
    if [[ "{input.annotation}" == *.gff ]] || [[ "{input.annotation}" == *.gff3 ]]; then
        annotation_opt="$annotation_opt --sjdbGTFtagExonParentTranscript Parent"
    fi
fi
STAR --runMode genomeGenerate \
    --genomeFastaFiles {input.fasta} \
    --genomeDir $wkdir \
    --runThreadN {threads} \
    --genomeSAindexNbases {params.genomeSAindexNbases} \
    $annotation_opt \
    {params.options} > {log} 2>&1
touch {output.done}
"""
