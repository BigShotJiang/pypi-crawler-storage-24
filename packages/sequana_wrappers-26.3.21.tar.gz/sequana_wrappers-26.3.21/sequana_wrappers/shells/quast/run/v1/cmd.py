CMD = """\
nfiles=$(echo {input.fastq} | wc -w)
if [ $nfiles -eq 2 ]; then
    R1=$(echo {input.fastq} | cut -d' ' -f1)
    R2=$(echo {input.fastq} | cut -d' ' -f2)
    input_fastq="-1 $R1 -2 $R2"
else
    input_fastq="--{params.preset} {input.fastq}"
fi
ref_opt=""
if [ -n "{params.reference}" ]; then ref_opt="-r {params.reference}"; fi
outdir=$(dirname {output.report})
quast.py {params.options} \
    -t {threads} \
    $ref_opt \
    {input.assembly} \
    $input_fastq \
    --output-dir $outdir > {log} 2>&1
touch {output.report}
"""
