CMD = """\
nfiles=$(echo {input.sample} | wc -w)
if [ $nfiles -eq 1 ]; then
    reads="--in1 {input.sample}"
    trimmed="--out1 {output.trimmed}"
else
    R1=$(echo {input.sample} | cut -d' ' -f1)
    R2=$(echo {input.sample} | cut -d' ' -f2)
    reads="--in1 $R1 --in2 $R2"
    T1=$(echo {output.trimmed} | cut -d' ' -f1)
    T2=$(echo {output.trimmed} | cut -d' ' -f2)
    trimmed="--out1 $T1 --out2 $T2"
fi
fastp --thread {threads} {params.options} {params.adapters} \
    $reads $trimmed \
    --json {output.json} \
    --html {output.html} > {log} 2>&1
"""
