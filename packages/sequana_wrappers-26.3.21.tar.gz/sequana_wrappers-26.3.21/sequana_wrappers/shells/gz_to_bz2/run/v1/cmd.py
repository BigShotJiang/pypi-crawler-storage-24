CMD = """\
pigz -p {threads} --test {input} > {log} 2>&1
pigz -d -c -p {threads} {input} | pbzip2 -p{threads} > {output} 2>> {log}
pbzip2 {output} -p{threads} --test >> {log} 2>&1
rm -f {input}
"""
