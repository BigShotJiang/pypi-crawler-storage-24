CMD = """\
graph={params.tmp_graph_name}
nfiles=$(echo {input.fastq} | wc -w)
if [ $nfiles -eq 2 ]; then
    prefix=$(basename {output.fastq[0]} | sed 's/_R1.*//' | sed 's/\\.fastq.*//')
    R1=$(echo {input.fastq} | cut -d' ' -f1)
    R2=$(echo {input.fastq} | cut -d' ' -f2)
    if [[ $R1 == *.gz ]]; then
        unpigz -p {threads} -fk $R1 && R1_unzip=$(echo $R1 | sed 's/\\.gz$//')
        unpigz -p {threads} -fk $R2 && R2_unzip=$(echo $R2 | sed 's/\\.gz$//')
        interleave-reads.py $R1_unzip $R2_unzip --output $prefix.pe > {log} 2>&1
        rm -f $R1_unzip $R2_unzip
    else
        interleave-reads.py $R1 $R2 --output $prefix.pe > {log} 2>&1
    fi
    normalize-by-median.py --paired --ksize {params.ksize} --cutoff {params.cutoff} \
        -M {params.m} {params.options} --savegraph $graph $prefix.pe \
        --output $prefix.pe.keep >> {log} 2>&1
    filter-abund.py --threads {threads} -V $graph $prefix.pe.keep \
        --output $prefix.pe.filter >> {log} 2>&1
    extract-paired-reads.py $prefix.pe.filter \
        --output-paired $prefix.pe \
        --output-single $prefix.orphans >> {log} 2>&1
    split-paired-reads.py $prefix.pe \
        -1 {output.fastq[0]} -2 {output.fastq[1]} >> {log} 2>&1
    rm -f $prefix.pe $prefix.pe.filter $prefix.pe.keep $prefix.orphans $graph
else
    prefix=$(basename {output.fastq} | sed 's/\\.fastq.*//')
    normalize-by-median.py --ksize {params.ksize} --cutoff {params.cutoff} \
        -M {params.m} {params.options} --savegraph $graph {input.fastq} \
        --output $prefix.se.keep > {log} 2>&1
    filter-abund.py --threads {threads} -V $graph \
        $prefix.se.keep --output $prefix.se.filter >> {log} 2>&1
    mv $prefix.se.filter {output.fastq}
    rm -f $prefix.se.keep $graph
fi
"""
