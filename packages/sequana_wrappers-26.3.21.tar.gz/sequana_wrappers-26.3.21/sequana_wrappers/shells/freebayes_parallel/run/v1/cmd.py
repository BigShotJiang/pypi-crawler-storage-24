CMD = """\
freebayes-parallel \
    <(fasta_generate_regions.py {input.ref}.fai {params.chunk}) \
    {threads} {params.options} --ploidy {params.ploidy} \
    -f {input.ref} -v {output.vcf} {input.bam} > {log} 2>&1 || echo ''
"""
