CMD = """\
outdir=$(dirname {output.fasta})
if [ "{params.long_reads}" = "True" ]; then
    input_file="-l {input.fastq[0]}"
elif [ $(echo {input.fastq} | wc -w) -eq 2 ]; then
    R1=$(echo {input.fastq} | cut -d' ' -f1)
    R2=$(echo {input.fastq} | cut -d' ' -f2)
    input_file="-1 $R1 -2 $R2"
else
    input_file="-s {input.fastq}"
fi
unicycler --mode {params.mode} \
    --threads {threads} \
    $input_file \
    -o $outdir \
    {params.options} > {log} 2>&1
cp $outdir/assembly.fasta {output.fasta}
"""
