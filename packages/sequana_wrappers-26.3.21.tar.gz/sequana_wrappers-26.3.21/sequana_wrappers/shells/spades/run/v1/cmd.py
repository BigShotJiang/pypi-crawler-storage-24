CMD = """\
nfiles=$(echo {input.fastq} | wc -w)
if [ $nfiles -eq 2 ]; then
    R1=$(echo {input.fastq} | cut -d' ' -f1)
    R2=$(echo {input.fastq} | cut -d' ' -f2)
    input_file="-1 $R1 -2 $R2"
else
    input_file="-s {input.fastq}"
fi
preset_opt=""
if [ -n "{params.preset}" ]; then preset_opt="--{params.preset}"; fi
outdir=$(dirname {output.scaffolds})
spades.py $preset_opt \
    -k {params.k} \
    --memory {params.memory} \
    --threads {threads} \
    $input_file \
    -o $outdir \
    {params.options} > {log} 2>&1
cp $outdir/contigs.fasta {output.contigs}
cp $outdir/scaffolds.fasta {output.scaffolds}
"""
