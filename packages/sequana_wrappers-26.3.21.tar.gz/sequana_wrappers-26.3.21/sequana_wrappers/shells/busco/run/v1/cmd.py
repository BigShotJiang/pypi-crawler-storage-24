CMD = """\
out=$(basename {output.outdir})
out_dirname=$(dirname {output.outdir})
download_opt=""
if [ -n "{params.download_path}" ]; then
    download_opt="--download_path {params.download_path}"
fi
busco --in {input} --out $out --force \
    --out_path $out_dirname \
    --cpu {threads} \
    --mode {params.mode} \
    --lineage {params.lineage} \
    $download_opt \
    {params.options} > {log} 2>&1
"""
