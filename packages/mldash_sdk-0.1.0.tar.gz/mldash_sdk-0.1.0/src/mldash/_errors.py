class MLDashError(Exception):
    """Base exception for mldash."""


class MLDashValidationError(MLDashError):
    """Raised when input validation fails."""


class MLDashAuthError(MLDashError):
    """Raised when authentication fails (bad API key, expired, etc.)."""


class MLDashUploadError(MLDashError):
    """Raised when the upload to ML-Dash fails (network, server error, etc.)."""
