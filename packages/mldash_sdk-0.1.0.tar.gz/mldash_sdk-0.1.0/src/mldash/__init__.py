"""mldash — Export trained ML models to ML-Dash."""

import getpass
import os
import shutil
import tempfile

from ._bundle import build_metadata, create_bundle
from ._credentials import clear as _clear_credentials
from ._credentials import get as _get_credential
from ._credentials import load as _load_credentials
from ._credentials import store as _store_credentials
from ._detect import detect_all
from ._errors import MLDashAuthError, MLDashError, MLDashUploadError, MLDashValidationError
from ._serialize import serialize_artifacts
from ._upload import upload_bundle
from ._validate import validate_all, validate_api_key, validate_url
from ._version import __version__

__all__ = [
    'login', 'logout', 'init', 'export', 'save', 'whoami',
    'MLDashError', 'MLDashValidationError', 'MLDashAuthError', 'MLDashUploadError',
    '__version__',
]

# Session-level state set via init()
_session = {
    'url': None,
    'api_key': None,
    'project': None,
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def login(url=None, api_key=None):
    """Authenticate with ML-Dash and store credentials locally.

    Run this once per machine. Credentials are saved to
    ~/.config/mldash/credentials so future export() calls don't need
    url or api_key.

    If url or api_key are not provided, prompts interactively.

    >>> import mldash
    >>> mldash.login()  # prompts for URL and API key
    >>> mldash.export(model=model, name="My Model")
    """
    # Resolve URL
    if not url:
        url = os.environ.get('MLDASH_URL') or _colab_secret('MLDASH_URL')
    if not url:
        existing_url = _get_credential('url')
        default_hint = f' [{existing_url}]' if existing_url else ''
        try:
            url = input(f'ML-Dash URL{default_hint}: ').strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not url and existing_url:
            url = existing_url
    if not url:
        raise MLDashValidationError("URL is required.")
    validate_url(url)

    # Resolve API key
    if not api_key:
        api_key = os.environ.get('MLDASH_API_KEY') or _colab_secret('MLDASH_API_KEY')
    if not api_key:
        print(f'Get your API key from: {url.rstrip("/")}/developers/keys')
        try:
            api_key = getpass.getpass('API Key: ')
        except (EOFError, KeyboardInterrupt):
            print()
            return
    if not api_key:
        raise MLDashValidationError("API key is required.")
    validate_api_key(api_key)

    # Verify credentials against the server
    _verify_credentials(url, api_key)

    # Store to disk
    _store_credentials(url=url, api_key=api_key)

    # Also set session state so current notebook session works immediately
    _session['url'] = url
    _session['api_key'] = api_key

    print(f'Authenticated with {url}')
    print(f'Credentials saved to ~/.config/mldash/credentials')


def logout():
    """Remove stored credentials."""
    _clear_credentials()
    _session['url'] = None
    _session['api_key'] = None
    _session['project'] = None
    print('Logged out. Credentials removed.')


def init(project=None, url=None):
    """Set the active project for this session.

    Call this at the top of a notebook to associate all subsequent
    export() calls with a specific ML-Dash project.

    >>> mldash.init(project="churn-analysis")
    >>> mldash.export(model=model, name="RF v2")  # goes to churn-analysis project
    """
    if url is not None:
        _session['url'] = url
    if project is not None:
        _session['project'] = project
        # Also persist project to credentials so it's the default next time
        _store_credentials(project=project)
    if project:
        print(f'Project set to: {project}')


def whoami():
    """Show current authentication status.

    Returns a dict with url, api_key_prefix, and project, or None
    if not authenticated.
    """
    creds = _load_credentials()
    url = _session.get('url') or creds.get('url')
    api_key = _session.get('api_key') or creds.get('api_key')
    project = _session.get('project') or creds.get('project')

    if not url and not api_key:
        print('Not logged in. Run mldash.login() to authenticate.')
        return None

    prefix = api_key[:10] + '...' if api_key and len(api_key) > 10 else api_key
    info = {
        'url': url,
        'api_key_prefix': prefix,
        'project': project,
    }
    print(f'URL:     {url or "(not set)"}')
    print(f'API Key: {prefix or "(not set)"}')
    print(f'Project: {project or "(not set)"}')
    return info


def export(
    model,
    name,
    url=None,
    api_key=None,
    *,
    scaler=None,
    encoder=None,
    label_map=None,
    description='',
    task_type=None,
    framework=None,
    features=None,
    target=None,
    project_id=None,
):
    """Bundle a trained model and upload it to ML-Dash.

    After calling login() and init(), you typically only need:

        mldash.export(model=model, name="My Model")

    Args:
        model: A fitted model object with a predict() method.
        name: Display name for the model on ML-Dash.
        url: ML-Dash server URL. Resolved automatically from login().
        api_key: API key. Resolved automatically from login().
        scaler: Optional fitted scaler (must have transform()).
        encoder: Optional fitted encoder (must have transform()).
        label_map: Optional dict mapping label indices to names.
        description: Optional model description.
        task_type: 'classification' or 'regression'. Auto-detected if omitted.
        framework: ML framework name. Auto-detected if omitted.
        features: Dict of {column_name: type} where type is 'numeric',
            'categorical', or 'text'.
        target: Dict with a single {column_name: type} entry.
        project_id: ML-Dash project ID. Resolved from init() if not provided.

    Returns:
        dict with keys: model_id, model_name, model_slug, url, auto_detected.

    Raises:
        MLDashValidationError: Invalid inputs.
        MLDashAuthError: Authentication failure.
        MLDashUploadError: Server/network error.
    """
    # Validate inputs
    validate_all(
        model, name, scaler=scaler, encoder=encoder, label_map=label_map,
        task_type=task_type, framework=framework, features=features, target=target,
    )

    # Resolve url, api_key, project from the fallback chain
    url = _resolve_url(url)
    api_key = _resolve_api_key(api_key)
    validate_url(url)
    validate_api_key(api_key)

    if project_id is None:
        project_id = _resolve_project()

    # Auto-detect metadata
    detected = detect_all(model, task_type=task_type, framework=framework)

    # Build, bundle, upload
    tmpdir = tempfile.mkdtemp(prefix='mldash_')
    try:
        artifact_paths = serialize_artifacts(tmpdir, model, scaler, encoder, label_map)
        metadata = build_metadata(name, description, detected, features, target,
                                  scaler, encoder, label_map)
        zip_path = create_bundle(tmpdir, artifact_paths, metadata)

        response = upload_bundle(
            zip_path, url, api_key, name,
            description=description,
            task_type=detected.get('task_type', ''),
            framework=detected.get('framework', ''),
            project_id=project_id,
        )
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    # Format return value
    model_data = response.get('model', {})
    result = {
        'model_id': model_data.get('id'),
        'model_name': model_data.get('name'),
        'model_slug': model_data.get('slug'),
        'url': url,
        'auto_detected': response.get('auto_detected', {}),
    }

    print(f'Exported "{name}" to {url} (id={result["model_id"]})')
    return result


def save(
    model,
    name,
    path='./model.zip',
    *,
    scaler=None,
    encoder=None,
    label_map=None,
    description='',
    task_type=None,
    framework=None,
    features=None,
    target=None,
):
    """Bundle a trained model to a local ZIP file (offline mode).

    Same as export() but writes to disk instead of uploading.

    Args:
        model: A fitted model object with a predict() method.
        name: Display name for the model.
        path: Output ZIP file path. Defaults to './model.zip'.
        (remaining args same as export)

    Returns:
        str: Path to the created ZIP file.

    Raises:
        MLDashValidationError: Invalid inputs.
    """
    validate_all(
        model, name, scaler=scaler, encoder=encoder, label_map=label_map,
        task_type=task_type, framework=framework, features=features, target=target,
    )

    detected = detect_all(model, task_type=task_type, framework=framework)

    tmpdir = tempfile.mkdtemp(prefix='mldash_')
    try:
        artifact_paths = serialize_artifacts(tmpdir, model, scaler, encoder, label_map)
        metadata = build_metadata(name, description, detected, features, target,
                                  scaler, encoder, label_map)
        zip_path = create_bundle(tmpdir, artifact_paths, metadata)

        # Copy to final destination
        dest = os.path.abspath(path)
        shutil.copy2(zip_path, dest)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    return dest


# ---------------------------------------------------------------------------
# Credential resolution (fallback chains)
# ---------------------------------------------------------------------------

def _resolve_url(explicit):
    """Resolve ML-Dash URL: explicit > session > stored > env > Colab."""
    if explicit:
        return explicit
    if _session['url']:
        return _session['url']
    stored = _get_credential('url')
    if stored:
        return stored
    env = os.environ.get('MLDASH_URL')
    if env:
        return env
    colab = _colab_secret('MLDASH_URL')
    if colab:
        return colab
    raise MLDashValidationError(
        "Not logged in. Run mldash.login() first, or pass url= explicitly."
    )


def _resolve_api_key(explicit):
    """Resolve API key: explicit > session > stored > env > Colab > prompt."""
    if explicit:
        return explicit
    if _session['api_key']:
        return _session['api_key']
    stored = _get_credential('api_key')
    if stored:
        return stored
    env = os.environ.get('MLDASH_API_KEY')
    if env:
        return env
    colab = _colab_secret('MLDASH_API_KEY')
    if colab:
        return colab
    raise MLDashValidationError(
        "Not logged in. Run mldash.login() first, or pass api_key= explicitly."
    )


def _resolve_project():
    """Resolve project: session > stored > None."""
    if _session['project']:
        return _session['project']
    return _get_credential('project')


def _colab_secret(name):
    """Try to read a value from Google Colab Secrets. Returns None on failure."""
    try:
        from google.colab import userdata
        return userdata.get(name)
    except Exception:
        return None


def _verify_credentials(url, api_key):
    """Quick check that the URL and API key are valid.

    Makes a lightweight request to the server. Raises on auth failure.
    """
    import requests

    # Try the models list endpoint — a GET that requires auth
    endpoint = url.rstrip('/') + '/api/models/'
    headers = {'X-API-Key': api_key}
    try:
        resp = requests.get(endpoint, headers=headers, timeout=10)
    except requests.ConnectionError:
        raise MLDashUploadError(
            f"Could not connect to ML-Dash at {url}. Is the server running?"
        )
    except requests.RequestException as exc:
        raise MLDashUploadError(f"Connection failed: {exc}")

    if resp.status_code == 401:
        raise MLDashAuthError("Invalid API key.")
    if resp.status_code == 403:
        raise MLDashAuthError("API key is not authorized.")
    # Any 2xx or other status is fine — we just needed to verify auth
