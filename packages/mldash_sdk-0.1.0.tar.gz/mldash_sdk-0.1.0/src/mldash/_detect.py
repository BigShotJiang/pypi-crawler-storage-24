def detect_task_type(model):
    """Detect classification vs regression from the model object."""
    # Try sklearn mixin check
    try:
        from sklearn.base import ClassifierMixin, RegressorMixin
        if isinstance(model, ClassifierMixin):
            return 'classification'
        if isinstance(model, RegressorMixin):
            return 'regression'
    except ImportError:
        pass

    # Fallback: check class name heuristics
    cls_name = type(model).__name__.lower()
    classifier_keywords = ('classifier', 'logistic', 'svc', 'sgd', 'nb', 'bayes')
    regressor_keywords = ('regressor', 'regression', 'svr', 'lasso', 'ridge', 'elasticnet')
    if any(kw in cls_name for kw in classifier_keywords):
        return 'classification'
    if any(kw in cls_name for kw in regressor_keywords):
        return 'regression'

    # Check for classes_ attribute (classifiers have this)
    if hasattr(model, 'classes_'):
        return 'classification'

    return None


def detect_framework(model):
    """Detect the ML framework from the model's module path."""
    module = getattr(type(model), '__module__', '') or ''
    for name in ('sklearn', 'xgboost', 'lightgbm', 'catboost', 'tensorflow', 'torch'):
        if name in module:
            if name == 'torch':
                return 'pytorch'
            return name
    return None


def detect_hyperparameters(model):
    """Extract hyperparameters via get_params() if available."""
    if hasattr(model, 'get_params'):
        try:
            params = model.get_params()
            # Ensure all values are JSON-serializable
            return {k: _make_serializable(v) for k, v in params.items()}
        except Exception:
            pass
    return {}


def detect_class_labels(model):
    """Extract class labels from classifier models."""
    if hasattr(model, 'classes_'):
        try:
            return [str(c) for c in model.classes_]
        except Exception:
            pass
    return None


def detect_n_features(model):
    """Extract feature count from fitted model."""
    if hasattr(model, 'n_features_in_'):
        try:
            return int(model.n_features_in_)
        except Exception:
            pass
    return None


def detect_feature_names(model):
    """Extract feature names if available (sklearn 1.0+)."""
    if hasattr(model, 'feature_names_in_'):
        try:
            return list(model.feature_names_in_)
        except Exception:
            pass
    return None


def detect_model_class(model):
    """Return the model class name (e.g. 'RandomForestClassifier')."""
    return type(model).__name__


def detect_all(model, task_type=None, framework=None):
    """Run all auto-detection and return a metadata dict.

    User-provided values take precedence over auto-detected ones.
    """
    return {
        'task_type': task_type or detect_task_type(model),
        'framework': framework or detect_framework(model),
        'model_class': detect_model_class(model),
        'hyperparameters': detect_hyperparameters(model),
        'class_labels': detect_class_labels(model),
        'n_features': detect_n_features(model),
        'feature_names': detect_feature_names(model),
    }


def _make_serializable(value):
    """Convert numpy/non-standard types to JSON-serializable Python types."""
    if value is None:
        return None
    try:
        import numpy as np
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.bool_):
            return bool(value)
    except ImportError:
        pass
    if isinstance(value, (int, float, str, bool)):
        return value
    if isinstance(value, dict):
        return {k: _make_serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_make_serializable(v) for v in value]
    # Fallback: convert to string
    return str(value)
