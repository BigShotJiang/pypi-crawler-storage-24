# mldash

Export trained ML models from notebooks to [ML-Dash](https://github.com/mrocha/ml-dash).

## Install

```bash
pip install mldash
```

## Quick Start

```python
import mldash

# One-time login (saved to ~/.config/mldash/credentials)
mldash.login()

# Set active project for this notebook
mldash.init(project="churn-analysis")

# Train your model
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Export — just model + name, everything else is resolved
mldash.export(model=model, name="Churn Predictor")
```

## Authentication

### `mldash.login()` — One-time setup

Run once per machine. You'll be prompted for your ML-Dash URL and API key:

```
>>> mldash.login()
ML-Dash URL: http://localhost:8000
Get your API key from: http://localhost:8000/developers/keys
API Key: ········
Authenticated with http://localhost:8000
Credentials saved to ~/.config/mldash/credentials
```

Credentials are stored locally at `~/.config/mldash/credentials` (chmod 600) and reused automatically.

You can also pass values directly (useful for CI or scripting):
```python
mldash.login(url="http://localhost:8000", api_key="mlda_xxx")
```

### `mldash.logout()`

```python
mldash.logout()  # removes stored credentials
```

### `mldash.whoami()`

```python
mldash.whoami()
# URL:     http://localhost:8000
# API Key: mlda_abcde...
# Project: churn-analysis
```

### Alternative auth methods

These work without calling `login()`:

**Environment variables:**
```bash
export MLDASH_URL=http://localhost:8000
export MLDASH_API_KEY=mlda_your_key_here
```

**Google Colab Secrets:**

Add `MLDASH_URL` and `MLDASH_API_KEY` to your Colab Secrets (key icon in sidebar).

## Project Association

### `mldash.init()` — Set active project

```python
mldash.init(project="churn-analysis")

# All exports now go to "churn-analysis"
mldash.export(model=model1, name="Logistic v1")
mldash.export(model=model2, name="XGBoost v1")
```

The project is saved to credentials, so it persists across sessions.
Override per-export with `project_id=`:

```python
mldash.export(model=model, name="Experiment", project_id="other-project")
```

## Usage

### Export with artifacts

```python
mldash.export(
    model=model,
    name="Sales Predictor",
    scaler=scaler,              # StandardScaler, MinMaxScaler, etc.
    encoder=encoder,            # OneHotEncoder, LabelEncoder, etc.
    label_map={"0": "no", "1": "yes"},
    features={"age": "numeric", "dept": "categorical", "review": "text"},
    target={"churn": "categorical"},
)
```

### Save to local ZIP (offline)

```python
mldash.save(
    model=model,
    name="My Model",
    path="./my_model.zip",
)
# Upload the ZIP manually via the ML-Dash web UI
```

### Auto-detection

The package auto-detects:
- **task_type** — classification or regression (from sklearn mixins)
- **framework** — sklearn, xgboost, lightgbm, etc. (from module path)
- **hyperparameters** — via `model.get_params()`
- **model_class** — e.g., `RandomForestClassifier`
- **n_features** — from `model.n_features_in_`
- **class_labels** — from `model.classes_`

## Typical Notebook Workflow

```python
# Cell 1: Setup (run once)
import mldash
mldash.login()
mldash.init(project="mas-648-final")

# Cell 2-N: Train models...
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

# Cell N+1: Export
mldash.export(model=model, name="RF 100 trees")
```

## Errors

```python
from mldash import MLDashValidationError, MLDashAuthError, MLDashUploadError

try:
    mldash.export(model=model, name="Test")
except MLDashValidationError as e:
    print(f"Invalid input: {e}")
except MLDashAuthError as e:
    print(f"Auth failed: {e}")
except MLDashUploadError as e:
    print(f"Upload failed: {e}")
```
