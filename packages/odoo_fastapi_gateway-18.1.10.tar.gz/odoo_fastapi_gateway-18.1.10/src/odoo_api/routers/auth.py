# -*- coding:utf-8 -*-

from fastapi import APIRouter

from odoo_api.dependencies.auth import authenticate
from odoo_api.dependencies.token import Token, AuthenticationBody
from odoo_api.exceptions import UnauthorizedException

router = APIRouter(tags=["Authentication"])


@router.post('/api/login', response_model=Token, summary="Login", description="Authenticate with Odoo credentials and receive a JWT access token.")
async def login(info: AuthenticationBody):
    token = await authenticate(info.db, info.username, info.password)
    if not token:
        raise UnauthorizedException(message="Incorrect login information")
    return {"access_token": token, "token_type": "bearer"}
