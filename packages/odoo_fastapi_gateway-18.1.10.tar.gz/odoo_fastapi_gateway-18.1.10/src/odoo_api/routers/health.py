from fastapi import APIRouter

router = APIRouter(tags=["Health"])


@router.get("/api/health", summary="Health check", description="Returns the health status of the API server.")
async def health():
    return {"status": "ok"}
