from odoo_api.routers.auth import router as auth_router
from odoo_api.routers.health import router as health_router
from odoo_api.routers.models import router as models_router


def get_routers():
    return [health_router, auth_router, models_router]
