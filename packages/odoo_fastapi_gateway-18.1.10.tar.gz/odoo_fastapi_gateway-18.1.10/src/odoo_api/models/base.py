# -*- coding:utf-8 -*-

from pydantic import BaseModel

from odoo_api.core.config import get_settings


class APIBaseModel(BaseModel):
    @classmethod
    def settings(cls):
        return get_settings()
