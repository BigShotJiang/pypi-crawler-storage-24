# -*- coding:utf-8 -*-

from fastapi import FastAPI, status
from fastapi.responses import JSONResponse


class APIException(Exception):
    def __init__(self, message: str):
        self.message = message


class UnauthorizedException(Exception):
    def __init__(self, message: str):
        self.message = message


class DecryptionError(Exception):
    def __init__(self, message: str):
        self.message = message


def register_exception_handlers(app: FastAPI):
    @app.exception_handler(APIException)
    async def handle_api_error(request, exc):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"message": exc.message, "data": None, "code": 0}
        )

    @app.exception_handler(UnauthorizedException)
    async def handle_auth_error(request, exc):
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"message": exc.message, "data": None, "code": 0}
        )
