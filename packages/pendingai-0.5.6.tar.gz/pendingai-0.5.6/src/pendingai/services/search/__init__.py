#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from pendingai.services.search.search_databases import SearchDatabaseInterface
from pendingai.services.search.searches import SearchInterface
from pendingai.services.service import PendingAiService


class SearchService(PendingAiService):
    """
    Interface for the Pending AI Search service.

    Manage and execute long-running search operations against large-scale chemical
    databases. It includes standard utilities for handling resource metadata, and
    tracking the status of submitted searches through a basic polling lifecycle.
    """

    search_databases: SearchDatabaseInterface
    searches: SearchInterface
