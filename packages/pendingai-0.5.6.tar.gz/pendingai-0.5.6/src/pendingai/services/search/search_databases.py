#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from typing import Any, Dict, Optional

from pydantic import AwareDatetime
from typing_extensions import NotRequired, TypedDict, Unpack

from pendingai.api.models import ApiResource, ApiResourceList
from pendingai.api_resources.interfaces import ResourceInterface
from pendingai.requestor.response import Response


class SearchDatabase(ApiResource):
    name: str
    version: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: AwareDatetime
    updated_at: AwareDatetime


class PaginationParams(TypedDict):
    limit: int
    starting_after: NotRequired[str]
    ending_before: NotRequired[str]


class SearchDatabaseInterface(ResourceInterface):
    """Search database resource interface."""

    def create(self, name: str):
        raise NotImplementedError

    def list(
        self, **request: Unpack[PaginationParams]
    ) -> ApiResourceList[SearchDatabase]:
        response: Response = self._requestor.get("/search/v1/databases", params=request)
        return ApiResourceList[SearchDatabase].from_response(response)

    def retrieve(self, id: str) -> SearchDatabase:
        response: Response = self._requestor.get(f"/search/v1/databases/{id}")
        return SearchDatabase.from_response(response)

    def update(self, id: str):
        raise NotImplementedError

    def delete(self, id: str):
        raise NotImplementedError
