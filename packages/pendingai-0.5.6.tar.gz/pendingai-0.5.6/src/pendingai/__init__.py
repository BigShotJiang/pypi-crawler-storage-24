#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import enum
import logging
import warnings

from pendingai.client import PendingAiClient  # noqa: F401

logging.getLogger("pysmiles").setLevel(logging.CRITICAL)
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysmiles")


@enum.unique
class Environment(str, enum.Enum):
    """
    Deployment environment used for building client connection strings,
    authentication flows for the device or refresh tokens, and controls
    cached state data between different environments
    """

    DEV = "dev"
    STAGING = "stage"
    DEFAULT = "default"
