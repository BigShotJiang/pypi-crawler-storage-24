#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from .generator import app as generator_app  # noqa: F401
from .retrosynthesis import app as retrosynthesis_app  # noqa: F401
from .search import search_app  # noqa: F401
from .synth import synth_app  # noqa: F401
