#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from typer import Argument, BadParameter, Typer

from pendingai.cli.console import Console
from pendingai.cli.context import PendingAiContext

synth_app: Typer = Typer(
    name="synth",
    short_help="Run retrosynthesis on a target molecule given as a SMILES string.",
)

console: Console = Console(highlight=False)


# region Commands


@synth_app.callback(invoke_without_command=True)
def main(
    ctx: PendingAiContext,
    smiles: str = Argument(..., help="SMILES string to run retrosynthesis on."),
):
    from pysmiles import read_smiles

    try:
        read_smiles(smiles)
    except Exception:
        raise BadParameter(f"Invalid SMILES string: {smiles}")
    try:
        console.print(
            ctx.obj["client"]
            ._base_requestor.post(
                "/synth/v1/treesearch",
                json={
                    "search_smiles": smiles,
                    "early_exit_first_solution": True,
                    "max_seconds": 4.0,
                    "max_depth": 6,
                    "root_expansion_top_k": 500,
                    "expansion_top_k": 250,
                    "expansion_batch_size": 64,
                    "path_distance_weight": 0.30,
                    "applicability_gte": 5,
                    "mask_trivial_solution": True,
                    "mask_large_bblocks": True,
                    "mask_bblocks_mw_gte": None,
                    "mask_usd_pricing_gte": 10000.0,
                    "ships_to": "US",
                    "mask_lead_times_gte": None,
                    "max_results": 1,
                    "sort_by_cost": True,
                },
            )
            .json(),
            highlight=True,
        )
    except Exception:
        console.print("[red]Error: Unable to handle the request for the target SMILES.")


# endregion
