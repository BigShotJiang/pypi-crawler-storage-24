import datetime
from typing import Any
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.session_user import SessionUser
from ..types import UNSET
from ..types import Unset


T = TypeVar("T", bound="AuthGetSessionResponse200")


@_attrs_define
class AuthGetSessionResponse200:
    """AuthGetSessionResponse200 model

    Attributes:
        expires (datetime.datetime):
        user (SessionUser):
        sudo (Union[Unset, bool]):  Default: False.
    """

    expires: datetime.datetime
    user: "SessionUser"
    sudo: Union[Unset, bool] = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        expires = self.expires.isoformat()
        user = self.user.to_dict()
        sudo = self.sudo

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "expires": expires,
                "user": user,
            }
        )
        if sudo is not UNSET:
            field_dict["sudo"] = sudo

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`AuthGetSessionResponse200` from a dict"""
        d = src_dict.copy()
        expires = isoparse(d.pop("expires"))

        user = SessionUser.from_dict(d.pop("user"))

        sudo = d.pop("sudo", UNSET)

        auth_get_session_response_200 = cls(
            expires=expires,
            user=user,
            sudo=sudo,
        )

        return auth_get_session_response_200
