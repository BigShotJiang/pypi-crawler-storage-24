import datetime
from typing import Any
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.task_def import TaskDef
from ..types import UNSET
from ..types import Unset


T = TypeVar("T", bound="TaskQueueEntry")


@_attrs_define
class TaskQueueEntry:
    """TaskQueueEntry model

    Attributes:
        submitted_on (datetime.datetime):
        task (TaskDef):
        claimed (Union[Unset, str]):
        claimed_on (Union[Unset, datetime.datetime]):
        timeout_on (Union[Unset, datetime.datetime]):
    """

    submitted_on: datetime.datetime
    task: "TaskDef"
    claimed: Union[Unset, str] = UNSET
    claimed_on: Union[Unset, datetime.datetime] = UNSET
    timeout_on: Union[Unset, datetime.datetime] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        submitted_on = self.submitted_on.isoformat()
        task = self.task.to_dict()
        claimed = self.claimed
        claimed_on: Union[Unset, str] = UNSET
        if not isinstance(self.claimed_on, Unset):
            claimed_on = self.claimed_on.isoformat()
        timeout_on: Union[Unset, str] = UNSET
        if not isinstance(self.timeout_on, Unset):
            timeout_on = self.timeout_on.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "submitted_on": submitted_on,
                "task": task,
            }
        )
        if claimed is not UNSET:
            field_dict["claimed"] = claimed
        if claimed_on is not UNSET:
            field_dict["claimed_on"] = claimed_on
        if timeout_on is not UNSET:
            field_dict["timeout_on"] = timeout_on

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`TaskQueueEntry` from a dict"""
        d = src_dict.copy()
        submitted_on = isoparse(d.pop("submitted_on"))

        task = TaskDef.from_dict(d.pop("task"))

        claimed = d.pop("claimed", UNSET)

        _claimed_on = d.pop("claimed_on", UNSET)
        claimed_on: Union[Unset, datetime.datetime]
        if isinstance(_claimed_on, Unset):
            claimed_on = UNSET
        else:
            claimed_on = isoparse(_claimed_on)

        _timeout_on = d.pop("timeout_on", UNSET)
        timeout_on: Union[Unset, datetime.datetime]
        if isinstance(_timeout_on, Unset):
            timeout_on = UNSET
        else:
            timeout_on = isoparse(_timeout_on)

        task_queue_entry = cls(
            submitted_on=submitted_on,
            task=task,
            claimed=claimed,
            claimed_on=claimed_on,
            timeout_on=timeout_on,
        )

        return task_queue_entry
