"""
Tests for CLI functionality.
"""

import unittest
import os
import sys
import json
import tempfile
from unittest.mock import patch, MagicMock

# Add project root to path for imports
project_root = os.path.join(os.path.dirname(__file__), '..')
sys.path.insert(0, project_root)

from src.cli import load_leads_from_file


class TestLoadLeadsFromFile(unittest.TestCase):
    """Test file loading functionality."""

    def test_load_json_file(self):
        """Test loading leads from JSON file."""
        leads_data = [
            {'company': 'Company A', 'email': 'a@test.com'},
            {'company': 'Company B', 'email': 'b@test.com'}
        ]

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(leads_data, f)
            f.flush()

            try:
                leads = load_leads_from_file(f.name)
                self.assertEqual(len(leads), 2)
                self.assertEqual(leads[0]['company'], 'Company A')
            finally:
                os.unlink(f.name)

    def test_load_csv_file(self):
        """Test loading leads from CSV file."""
        csv_content = "company,email,country\nCompany A,a@test.com,GB\nCompany B,b@test.com,DE"

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            f.flush()

            try:
                leads = load_leads_from_file(f.name)
                self.assertEqual(len(leads), 2)
                self.assertEqual(leads[0]['company'], 'Company A')
                self.assertEqual(leads[0]['country'], 'GB')
            finally:
                os.unlink(f.name)

    def test_file_not_found(self):
        """Test error handling for missing file."""
        with self.assertRaises(FileNotFoundError):
            load_leads_from_file('nonexistent.json')

    def test_unsupported_format(self):
        """Test error handling for unsupported format."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write('some content')
            f.flush()

            try:
                with self.assertRaises(ValueError) as context:
                    load_leads_from_file(f.name)
                self.assertIn('Unsupported file format', str(context.exception))
            finally:
                os.unlink(f.name)

    def test_invalid_json_not_a_list(self):
        """Test error handling when JSON is not a list."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({'company': 'Test'}, f)  # Dict, not list
            f.flush()

            try:
                with self.assertRaises(ValueError) as context:
                    load_leads_from_file(f.name)
                self.assertIn('must contain a list', str(context.exception))
            finally:
                os.unlink(f.name)

    def test_invalid_json_syntax(self):
        """Test error handling for invalid JSON."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('not valid json')
            f.flush()

            try:
                with self.assertRaises(json.JSONDecodeError):
                    load_leads_from_file(f.name)
            finally:
                os.unlink(f.name)


if __name__ == '__main__':
    unittest.main()