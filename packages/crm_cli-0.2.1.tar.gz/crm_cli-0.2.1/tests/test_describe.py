"""Tests for the describe client."""

import unittest
from unittest.mock import Mock, patch

from src.describe import DescribeClient, FieldDefinition, ObjectDescription


class TestDescribeClient(unittest.TestCase):
    """Test the DescribeClient."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_token_manager = Mock()
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": "test_corp_id",
            "currentOpenUserId": "test_user"
        }
        self.client = DescribeClient(self.mock_token_manager)

    def test_describe_object_success(self):
        """Test describing an object successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "describe": {
                    "label": "Leads",
                    "fields": {
                        "field_IT92M__c": {
                            "label": "国家",
                            "type": "select_one",
                            "options": [
                                {"value": "kaYz89Lwq", "label": "Germany"},
                                {"value": "xYz123Abc", "label": "France"}
                            ]
                        }
                    }
                }
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.describe_object("LeadsObj")

        self.assertIsInstance(result, ObjectDescription)
        self.assertEqual(result.api_name, "LeadsObj")
        self.assertEqual(result.label, "Leads")
        self.assertIn("field_IT92M__c", result.fields)

        field = result.fields["field_IT92M__c"]
        self.assertEqual(field.label, "国家")
        self.assertEqual(len(field.options), 2)
        self.assertEqual(field.options[0].value, "kaYz89Lwq")
        self.assertEqual(field.options[0].label, "Germany")

    def test_describe_object_not_found(self):
        """Test describing a non-existent object."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 1001,
            "errorMessage": "Object not found"
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.describe_object("NonExistentObj")

        self.assertIsNone(result)

    def test_describe_field(self):
        """Test describing a specific field."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "describe": {
                    "label": "Leads",
                    "fields": {
                        "field_IT92M__c": {
                            "label": "国家",
                            "type": "select_one",
                            "options": [
                                {"value": "kaYz89Lwq", "label": "Germany"}
                            ]
                        }
                    }
                }
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.describe_field("LeadsObj", "field_IT92M__c")

        self.assertIsInstance(result, FieldDefinition)
        self.assertEqual(result.api_name, "field_IT92M__c")
        self.assertEqual(result.label, "国家")

    def test_describe_field_not_found(self):
        """Test describing a non-existent field."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "describe": {
                    "label": "Leads",
                    "fields": {}
                }
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.describe_field("LeadsObj", "nonexistent")

        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()
