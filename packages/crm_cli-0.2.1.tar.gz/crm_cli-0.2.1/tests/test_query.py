import unittest
from unittest.mock import Mock, patch
from src.query import LeadQueryClient, QueryResult


class TestLeadQueryClient(unittest.TestCase):
    def setUp(self):
        self.mock_token_manager = Mock()
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": "test_corp_id",
            "currentOpenUserId": "test_user_id"
        }
        self.client = LeadQueryClient(self.mock_token_manager)

    def test_query_by_email_success(self):
        """Test querying lead by email."""
        mock_response = Mock()
        # The findOne API returns the data nested in objectData
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "objectData": {
                    "_id": "69ad3d697b29ec0007111128",
                    "company": "Metro Deutschland GmbH",  # Use 'company' not 'name'
                    "name": "Mohammed",  # Contact name
                    "email": "mohammed.khalil@yahoo.de",
                    "field_IT92M__c": "DE",
                    "field_e2eon__c": "商超"
                }
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.query_by_email("mohammed.khalil@yahoo.de")

        self.assertIsInstance(result, QueryResult)
        self.assertEqual(result.lead_id, "69ad3d697b29ec0007111128")
        self.assertEqual(result.company, "Metro Deutschland GmbH")
        self.assertEqual(result.email, "mohammed.khalil@yahoo.de")

    def test_query_not_found(self):
        """Test when lead is not found."""
        mock_response = Mock()
        # When not found, the API returns an errorCode != 0
        mock_response.json.return_value = {
            "errorCode": 1001,
            "errorMessage": "Data not found"
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.query_by_email("notfound@example.com")

        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()
