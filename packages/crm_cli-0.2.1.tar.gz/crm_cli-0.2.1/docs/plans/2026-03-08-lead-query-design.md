# Lead Query Feature Design

**Date:** 2026-03-08
**Author:** Claude
**Status:** Approved

## Problem Statement

The CRM CLI currently only supports creating leads. Users cannot:
1. Query leads by email, ID, or company name
2. Debug field value issues (e.g., "选项已删除" for dropdown fields)
3. Verify lead data after insertion

## Root Cause: Field Value Mismatch

The "选项已删除" error occurs because FXiaoke CRM stores dropdown values as **internal option IDs**, not display text:

| Field | Value Sent | Stored As | Displayed As |
|-------|-----------|-------------|--------------|
| Country | `"DE"` | `"DE"` (text) | 选项已删除 |
| Secondary Source | `"LinkedIn"` | `"1Lk5T92e1"` | LinkedIn |

The query feature must show **both** raw stored values and display values to help debug these mismatches.

## Design

### CLI Interface

```bash
# Query by email
crm query --email mohammed.khalil@yahoo.de

# Query by CRM ID
crm query --id 69ad3d697b29ec0007111128

# Query by company name (exact match)
crm query --company "Metro Deutschland GmbH"

# List recent leads
crm query --recent 10
```

### Output Format

```
┌─────────────────────────────────────────────────────────────┐
│ Lead Query Result                                           │
├─────────────────────────────────────────────────────────────┤
│ CRM ID:         69ad3d697b29ec0007111128                    │
│ Created:        2026-03-08 14:32:05                         │
├─────────────────────────────────────────────────────────────┤
│ Company:        Metro Deutschland GmbH                      │
│ Email:          mohammed.khalil@yahoo.de                      │
│ Phone:          +49...                                        │
│ Website:        https://www.metro.de                          │
├─────────────────────────────────────────────────────────────┤
│ ⚠ Fields with Issues:                                         │
│                                                               │
│ Country:        [选项已删除]                                  │
│   ├─ Stored:    "DE"                                          │
│   └─ Expected:  Option ID like "kaYz89Lwq"                    │
│                                                               │
│ Primary Industry: [选项已删除]                                  │
│   ├─ Stored:    "商超"                                        │
│   └─ Expected:  Option ID like "..."                          │
├─────────────────────────────────────────────────────────────┤
│ ✓ Valid Fields:                                               │
│                                                               │
│ Region:         欧洲 (field_g60ab__c = 1dKGudtaC)              │
│ Pool:           欧洲线索公海池                                  │
│ Follow Status:  S1-待跟进                                     │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### API Endpoint

```python
POST https://open.fxiaoke.com/cgi/crm/v2/data/query

{
  "corpAccessToken": "...",
  "corpId": "...",
  "currentOpenUserId": "...",
  "apiName": "LeadsObj",
  "searchQuery": {
    "offset": 0,
    "limit": 10,
    "filters": [
      {
        "field_name": "email",
        "field_values": ["mohammed.khalil@yahoo.de"],
        "operator": "EQ"
      }
    ]
  }
}
```

### Response Handling

The query returns raw field values. To show display labels:
1. Call `crm/v2/object/describe` to get field metadata including option mappings
2. Map raw values to display labels where options exist
3. Flag mismatches (stored value not in option list)

## Implementation Plan

### Phase 1: Basic Query
- Query by email, ID, company name
- Show raw field values
- Help debug field value issues

### Phase 2: Enhanced Display
- Call object describe to get option mappings
- Show display labels alongside raw values
- Highlight problematic fields

## Success Criteria

1. Can query leads by email, ID, and company name
2. Output clearly shows field values and identifies "选项已删除" issues
3. Helps user understand the difference between stored values and display labels
4. Performance: Query completes in < 3 seconds

## Open Questions

1. Should we cache the object describe metadata to avoid repeated API calls?
2. Should we add export capability (JSON/CSV output)?
3. Should we support advanced filters (date range, pool, owner)?
