# CRM Describe Command Design

**Date:** 2026-03-08
**Status:** Ready for implementation

## Overview

Add a `crm describe` command that calls FXiaoke's Object Describe API to discover field metadata and option values dynamically. This solves the "选项已删除" problem by revealing the correct option IDs.

## Problem Statement

When inserting leads, text values like "DE" (country) or "商超" (industry) cause fields to show "选项已删除" in CRM. The CRM expects option IDs like "kaYz89Lwq" instead.

## Solution

Use the Object Describe API (`crm/v2/object/describe`) to fetch field definitions including all valid option IDs and their display labels.

## CLI Interface

```bash
# Describe all fields for LeadsObj
crm describe --object LeadsObj

# Describe specific field
crm describe --object LeadsObj --field field_IT92M__c

# Output as JSON for scripting
crm describe --object LeadsObj --format json

# Save to file
crm describe --object LeadsObj --output field-options.json
```

## Output Format

### Table Format (default)

```
================================================================================
  Object: LeadsObj
================================================================================

Field: field_IT92M__c (国家 / Country)
Type: select_one
================================================================================
  Option ID          | Display Label
  -------------------|------------------
  kaYz89Lwq          | Germany
  xYz123Abc          | France
  def456Ghi          | China
  ...

Field: field_e2eon__c (一级行业 / Primary Industry)
Type: select_one
================================================================================
  Option ID          | Display Label
  -------------------|------------------
  abcDef123          | Retail (商超)
  ghiJkl456          | Manufacturing
  mnoPqr789          | Technology
  ...
```

### JSON Format (`--format json`)

```json
{
  "object": "LeadsObj",
  "fields": {
    "field_IT92M__c": {
      "label": "国家",
      "label_en": "Country",
      "type": "select_one",
      "options": {
        "kaYz89Lwq": "Germany",
        "xYz123Abc": "France"
      }
    }
  }
}
```

## API Integration

### Endpoint

```
POST https://open.fxiaoke.com/cgi/crm/v2/object/describe
```

### Request

```json
{
  "corpAccessToken": "...",
  "corpId": "...",
  "currentOpenUserId": "...",
  "apiName": "LeadsObj"
}
```

### Response Structure

```json
{
  "errorCode": 0,
  "data": {
    "describe": {
      "fields": {
        "field_IT92M__c": {
          "label": "国家",
          "type": "select_one",
          "options": [
            {"value": "kaYz89Lwq", "label": "Germany"},
            {"value": "xYz123Abc", "label": "France"}
          ]
        }
      }
    }
  }
}
```

## Implementation Components

### 1. DescribeClient (`src/describe.py`)

- `describe_object(api_name)` - Fetch all fields for an object
- `describe_field(api_name, field_name)` - Fetch specific field details
- Parse and normalize API response

### 2. Output Formatters (`src/formatters.py` - extend)

- `format_describe_table(data)` - Human-readable table format
- `format_describe_json(data)` - Machine-readable JSON
- Support filtering by field name

### 3. CLI Integration (`src/cli.py` - extend)

- Add `describe` subparser with arguments
- Implement `cmd_describe()` function
- Wire up to formatters

## Usage Workflow

### Discovering Correct Values

```bash
# 1. Describe the Country field
crm describe --object LeadsObj --field field_IT92M__c

# 2. Find Germany option ID (let's say it's "kaYz89Lwq")

# 3. Update lead JSON to use option ID instead of "DE"
{
  "country": "kaYz89Lwq"  # Instead of "DE"
}

# 4. Sync the lead
crm sync lead.json
```

## Benefits

1. **Solves immediate problem**: Discover option IDs to fix "选项已删除"
2. **Self-documenting**: Field definitions include labels and types
3. **Scriptable**: JSON output enables automation
4. **Cacheable**: Field definitions can be cached locally

## Future Enhancements

1. **Cache**: Save field definitions to `~/.crm_field_cache.json`
2. **Validation**: Pre-validate lead JSON against field types
3. **Suggest**: Recommend option IDs based on partial text match
