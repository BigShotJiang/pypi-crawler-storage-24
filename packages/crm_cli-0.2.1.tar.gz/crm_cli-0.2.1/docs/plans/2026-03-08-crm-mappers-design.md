# CRM Mappers Design

**Date:** 2026-03-08
**Status:** Approved
**Implementation:** Pending

## Overview

Extend `crm-cli` with mapper commands that convert human-readable values (country names, industry names, lead sources) to FXiaoke CRM option IDs.

## Problem Statement

Currently, mapping countries/industries/sources to CRM option IDs requires:
1. Running `crm describe` manually
2. Parsing JSON output to find the right option ID
3. Risk of typos or stale data

This is error-prone and slow. A dedicated command makes this reliable and fast.

## Solution

Add subcommands to existing `crm-cli`:
- `crm map-country <input>` - Map country to option ID
- `crm map-industry <input>` - Map industry to option ID
- `crm map-source <input>` - Map lead source to option ID
- `crm cache-refresh` - Refresh the options cache
- `crm cache-status` - Show cache status

## Data Flow

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Skill/CLI  │────▶│  crm-cli    │────▶│  FXiaoke   │
│  needs ID    │     │  map-xxx     │     │   API      │
└──────────────┘     │              │     └──────────────┘
                     │
                     ▼
              ┌──────────────────┐
              │  Local Cache    │
              │  ~/.cache/       │
              │  crm-helpers/    │
              └──────────────────┘
```

## Cache Strategy

- **Location:** `~/.cache/crm-helpers/options.json`
- **TTL:** 30 days
- **Auto-refresh:** On first `map-*` call if cache expired

### Cache File Structure

```json
{
  "fetched_at": "2026-03-08T10:00:00",
  "fields": {
    "field_IT92M__c": {
      "name": "Country",
      "options": [
        {"id": "KsekHd2m8", "value": "Germany"},
        {"id": "Ab3cdEf4g5", "value": "France"}
      ]
    },
    "field_e2eon__c": {
      "name": "Industry",
      "options": [
        {"id": "11jjHrls3", "value": "Retail"},
        {"id": "Hh5ijKl6m7", "value": "Fitness"}
      ]
    },
    "field_NtXsK__c": {
      "name": "Source",
      "options": [
        {"id": "6A7SBTmqi", "value": "Facebook"},
        {"id": "1Lk5T92e1", "value": "LinkedIn"}
      ]
    }
  }
}
```

## Command Specifications

### `crm map-country <input>`

**Purpose:** Convert country name/code to CRM option ID

**Input:** Country name or code (e.g., "Germany", "DE", "deutschland")

**Output:** CRM option ID (e.g., `KsekHd2m8`)

**Examples:**
```bash
$ crm map-country DE
KsekHd2m8

$ crm map-country Germany
KsekHd2m8

$ crm map-country deutschland
KsekHd2m8
```

**Exit Codes:**
- 0: Success
- 1: Country not found

---

### `crm map-industry <input>`

**Purpose:** Convert industry name to CRM option ID

**Input:** Industry name (e.g., "retail", "fitness", "wholesale")

**Output:** CRM option ID

**Examples:**
```bash
$ crm map-industry retail
11jjHrls3
```

---

### `crm map-source <input>`

**Purpose:** Convert lead source to CRM option ID

**Input:** Lead source (e.g., "facebook", "linkedin", "website")

**Output:** CRM option ID

**Examples:**
```bash
$ crm map-source facebook
6A7SBTmqi
```

---

### `crm cache-refresh`

**Purpose:** Fetch field options from CRM API and update local cache

**Output:** Success message with timestamp

**Example:**
```bash
$ crm cache-refresh
Cache refreshed: ~/.cache/crm-helpers/options.json
Fields cached: country, industry, source
```

---

### `crm cache-status`

**Purpose:** Show cache age and expiration status

**Output:** Cache location, fetch date, expiry date, days remaining

**Example:**
```bash
$ crm cache-status
Cache: ~/.cache/crm-helpers/options.json
Fetched: 2026-03-08 10:00:00
Expires: 2026-04-07 10:00:00
Status: valid (22 days remaining)
```

## Implementation Details

### File Structure

```
crm-cli/
├── src/
│   └── crm_cli/
│       ├── __init__.py
│       ├── cli.py          # existing
│       ├── api.py           # existing
│       ├── mappers.py      # NEW - map commands
│       └── cache.py         # NEW - cache management
├── tests/
│   └── test_mappers.py
└── pyproject.toml
```

### Key Functions

**cache.py:**
- `get_cache_path()` - Return cache file path
- `load_cache()` - Load cache, return None if expired/missing
- `save_cache(data)` - Save cache with timestamp
- `refresh_cache()` - Call API and save

**mappers.py:**
- `normalize_country(input)` - Normalize to lowercase, handle common aliases
- `find_option_id(field_id, value)` - Look up option ID in cache
- `map_country(input)` - Main entry point for country mapping
- `map_industry(input)` - Main entry point for industry mapping
- `map_source(input)` - Main entry point for source mapping

### Error Handling

| Error | Behavior |
|-------|----------|
| Country/industry/source not found | Exit 1, print error to stderr |
| Cache expired | Auto-refresh, then retry |
| API auth failed | Exit 2, print auth error |
| Network timeout | Exit 3, print timeout error |

### Dependencies

- No new dependencies required
- Uses existing `crm-cli` authentication and API client

## Success Criteria

1. `crm map-country DE` returns correct option ID
2. `crm map-industry retail` returns correct option ID
3. `crm map-source facebook` returns correct option ID
4. Cache persists for 30 days
5. Auto-refresh works when cache expires
6. Exit codes indicate success/failure correctly

## Out of Scope

- Email automation (future enhancement)
- Batch processing (future enhancement)
- Custom field mapping (use `crm describe` directly)
