# Lead Query Feature Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a `crm query` command to search and display lead details from FXiaoke CRM, helping debug field value issues like "选项已删除".

**Architecture:** Create a `LeadQueryClient` class that wraps the FXiaoke `crm/v2/data/query` API, a formatter module for table output, and integrate as a new CLI subcommand. Keep it simple: one query method per filter type, no caching, minimal dependencies.

**Tech Stack:** Python 3.12, requests, existing TokenManager for auth, existing test infrastructure (unittest).

---

## Prerequisites

- FXiaoke API credentials in environment (CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE)
- At least one test lead in CRM (e.g., mohammed.khalil@yahoo.de)

## Testing Approach

- Use existing lead `mohammed.khalil@yahoo.de` for integration tests
- Mock API responses for unit tests
- Manual test: `crm query --email mohammed.khalil@yahoo.de`

---

## Task 1: Create LeadQueryClient Module

**Files:**
- Create: `src/query.py`
- Test: `tests/test_query.py`

**Step 1: Write the failing test**

Create `tests/test_query.py`:

```python
import unittest
from unittest.mock import Mock, patch
from src.query import LeadQueryClient, QueryResult


class TestLeadQueryClient(unittest.TestCase):
    def setUp(self):
        self.mock_token_manager = Mock()
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": "test_corp_id"
        }
        self.client = LeadQueryClient(self.mock_token_manager)

    def test_query_by_email_success(self):
        """Test querying lead by email."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "dataList": [
                    {
                        "_id": "69ad3d697b29ec0007111128",
                        "name": "Metro Deutschland GmbH",
                        "email": "mohammed.khalil@yahoo.de",
                        "field_IT92M__c": "DE",
                        "field_e2eon__c": "商超"
                    }
                ]
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.query_by_email("mohammed.khalil@yahoo.de")

        self.assertIsInstance(result, QueryResult)
        self.assertEqual(result.lead_id, "69ad3d697b29ec0007111128")
        self.assertEqual(result.company, "Metro Deutschland GmbH")
        self.assertEqual(result.email, "mohammed.khalil@yahoo.de")

    def test_query_not_found(self):
        """Test when lead is not found."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "errorCode": 0,
            "data": {
                "dataList": []
            }
        }
        mock_response.status_code = 200

        with patch('requests.post', return_value=mock_response):
            result = self.client.query_by_email("notfound@example.com")

        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()
```

**Step 2: Run test to verify it fails**

```bash
uv run python -m pytest tests/test_query.py -v
```

Expected: FAIL with import errors (LeadQueryClient doesn't exist yet)

**Step 3: Write minimal implementation**

Create `src/query.py`:

```python
"""
Lead query client for FXiaoke CRM.
Provides methods to query leads by email, ID, or company name.
"""

import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any

import requests

from .fxiaoke_auth import TokenManager

logger = logging.getLogger('lead_query')

QUERY_ENDPOINT = "https://open.fxiaoke.com/cgi/crm/v2/data/query"


@dataclass
class QueryResult:
    """Result of a lead query."""
    lead_id: str
    company: str
    email: Optional[str]
    phone: Optional[str]
    country: Optional[str]
    raw_data: Dict[str, Any]  # All fields from API


class LeadQueryClient:
    """Client for querying leads from FXiaoke CRM."""

    def __init__(self, token_manager: TokenManager):
        """
        Initialize query client.

        Args:
            token_manager: TokenManager instance for authentication
        """
        self.token_manager = token_manager
        self.session = token_manager.session

    def query_by_email(self, email: str) -> Optional[QueryResult]:
        """
        Query lead by email address.

        Args:
            email: Email address to search for

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("email", email)

    def query_by_id(self, lead_id: str) -> Optional[QueryResult]:
        """
        Query lead by CRM ID.

        Args:
            lead_id: CRM lead ID (e.g., "69ad3d697b29ec0007111128")

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("_id", lead_id)

    def query_by_company(self, company_name: str) -> Optional[QueryResult]:
        """
        Query lead by company name (exact match).

        Args:
            company_name: Company name to search for

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("name", company_name)

    def _query_with_filter(self, field: str, value: str) -> Optional[QueryResult]:
        """
        Execute query with a single filter.

        Args:
            field: Field name to filter on
            value: Value to match

        Returns:
            QueryResult if found, None otherwise
        """
        auth = self.token_manager.get_auth_headers()
        if not auth:
            logger.error("Authentication failed - no valid token")
            return None

        payload = {
            "corpAccessToken": auth["corpAccessToken"],
            "corpId": auth["corpId"],
            "currentOpenUserId": auth.get("currentOpenUserId", ""),
            "apiName": "LeadsObj",
            "searchQuery": {
                "offset": 0,
                "limit": 10,
                "filters": [
                    {
                        "field_name": field,
                        "field_values": [value],
                        "operator": "EQ"
                    }
                ]
            }
        }

        try:
            response = self.session.post(
                QUERY_ENDPOINT,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()

            if data.get("errorCode") != 0:
                logger.error(f"Query failed: {data.get('errorMessage')}")
                return None

            results = data.get("data", {}).get("dataList", [])
            if not results:
                return None

            return self._parse_lead_data(results[0])

        except requests.exceptions.RequestException as e:
            logger.error(f"Query request failed: {e}")
            return None

    def _parse_lead_data(self, data: Dict[str, Any]) -> QueryResult:
        """
        Parse API response data into QueryResult.

        Args:
            data: Raw lead data from API

        Returns:
            QueryResult with parsed fields
        """
        return QueryResult(
            lead_id=data.get("_id", ""),
            company=data.get("name", ""),
            email=data.get("email") or data.get("field_xxx__c"),  # Check standard + custom
            phone=data.get("field_S737R__c"),  # Contact phone field
            country=data.get("field_IT92M__c"),  # Country field
            raw_data=data  # Keep all data for detailed display
        )
```

**Step 4: Run tests to verify they pass**

```bash
uv run python -m pytest tests/test_query.py -v
```

Expected: All tests PASS

**Step 5: Commit**

```bash
git add tests/test_query.py src/query.py
git commit -m "feat: add LeadQueryClient for querying CRM leads

- Add LeadQueryClient class with query_by_email, query_by_id, query_by_company
- Add QueryResult dataclass for structured results
- Add comprehensive unit tests with mocked API responses
- Follows existing pattern from crm.py and fxiaoke_auth.py"
```

---

## Task 2: Create Output Formatter Module

**Files:**
- Create: `src/formatters.py`
- Test: `tests/test_formatters.py`

**Step 1: Write the failing test**

Create `tests/test_formatters.py`:

```python
import unittest
from io import StringIO
from unittest.mock import patch

from src.formatters import format_lead_table
from src.query import QueryResult


class TestFormatters(unittest.TestCase):
    def setUp(self):
        self.sample_lead = QueryResult(
            lead_id="69ad3d697b29ec0007111128",
            company="Metro Deutschland GmbH",
            email="mohammed.khalil@yahoo.de",
            phone="+49123456789",
            country="DE",
            raw_data={
                "_id": "69ad3d697b29ec0007111128",
                "name": "Metro Deutschland GmbH",
                "email": "mohammed.khalil@yahoo.de",
                "field_IT92M__c": "DE",
                "field_e2eon__c": "商超",
                "field_g60ab__c": "1dKGudtaC",
            }
        )

    def test_format_lead_table_basic(self):
        """Test basic table formatting."""
        with patch('sys.stdout', new=StringIO()) as fake_out:
            format_lead_table(self.sample_lead)
            output = fake_out.getvalue()

        # Check that key information is in output
        self.assertIn("69ad3d697b29ec0007111128", output)
        self.assertIn("Metro Deutschland GmbH", output)
        self.assertIn("mohammed.khalil@yahoo.de", output)

    def test_format_lead_table_shows_warnings(self):
        """Test that fields with issues are flagged."""
        with patch('sys.stdout', new=StringIO()) as fake_out:
            format_lead_table(self.sample_lead)
            output = fake_out.getvalue()

        # Should show the raw values that cause "选项已删除"
        self.assertIn("DE", output)
        self.assertIn("商超", output)


if __name__ == '__main__':
    unittest.main()
```

**Step 2: Run test to verify it fails**

```bash
uv run python -m pytest tests/test_formatters.py -v
```

Expected: FAIL with import errors (format_lead_table doesn't exist)

**Step 3: Write minimal implementation**

Create `src/formatters.py`:

```python
"""
Output formatters for displaying lead query results.
"""

from typing import Dict, Any
from src.query import QueryResult


def format_lead_table(result: QueryResult) -> None:
    """
    Format and print lead details in a table-like format.

    Shows key lead information and highlights potential issues
    like fields showing "选项已删除".

    Args:
        result: QueryResult with lead data
    """
    raw = result.raw_data

    # Header
    print("=" * 65)
    print(f"  Lead Query Result")
    print("=" * 65)
    print()

    # Basic Info Section
    print("  Basic Information")
    print("  " + "-" * 61)
    print(f"  CRM ID:        {result.lead_id}")
    print(f"  Company:       {result.company}")
    if result.email:
        print(f"  Email:         {result.email}")
    if result.phone:
        print(f"  Phone:         {result.phone}")
    print()

    # Address/Region Section
    print("  Region & Address")
    print("  " + "-" * 61)

    # Country field - show warning if it looks like a code not option ID
    country = raw.get("field_IT92M__c", "")
    if country:
        if len(country) <= 3 and country.isalpha():
            # Likely a country code like "DE" - will show as 选项已删除
            print(f"  Country:       {country}  [⚠ May show as 选项已删除]")
        else:
            print(f"  Country:       {country}")

    # Region (区域) - shows as option ID
    region = raw.get("field_g60ab__c", "")
    if region:
        region_display = {"1dKGudtaC": "欧洲", "5yF9DohVi": "亚洲"}.get(region, region)
        print(f"  Region:        {region_display}")

    print()

    # Industry Section (if present)
    primary_ind = raw.get("field_e2eon__c", "")
    secondary_ind = raw.get("field_e1Gqm__c", "")

    if primary_ind or secondary_ind:
        print("  Industry Classification")
        print("  " + "-" * 61)

        if primary_ind:
            # Check if it looks like text rather than option ID
            if len(primary_ind) > 10:
                print(f"  Primary:       {primary_ind}")
            else:
                print(f"  Primary:       {primary_ind}  [⚠ May show as 选项已删除]")

        if secondary_ind:
            if len(secondary_ind) > 10:
                print(f"  Secondary:     {secondary_ind}")
            else:
                print(f"  Secondary:     {secondary_ind}  [⚠ May show as 选项已删除]")

        print()

    # Source Section
    print("  Source Information")
    print("  " + "-" * 61)

    secondary_source = raw.get("field_NtXsK__c", "")
    if secondary_source:
        # Map known option IDs to display names
        source_map = {
            "1Lk5T92e1": "LinkedIn",
            "6A7SBTmqi": "Facebook",
            "15i2w2eom": "Google",
            "20NkwyqL0": "Yahoo"
        }
        display = source_map.get(secondary_source, secondary_source)
        print(f"  Secondary:     {display}")

    print()

    # Raw Data Summary (optional - for debugging)
    print("  " + "=" * 61)
    print("  Tip: Use raw_data for full field inspection")
    print("  " + "=" * 61)
    print()
```

**Step 4: Run tests to verify they pass**

```bash
uv run python -m pytest tests/test_formatters.py -v
```

Expected: All tests PASS

**Step 5: Commit**

```bash
git add tests/test_formatters.py src/formatters.py
git commit -m "feat: add output formatter for lead query results

- Add format_lead_table() to display lead details in readable format
- Highlight fields that may show 选项已删除 (option deleted)
- Show both raw values and mapped display values
- Include unit tests for formatting functions"
```

---

## Task 3: Add CLI Query Command

**Files:**
- Modify: `src/cli.py`

**Step 1: Add query command to CLI**

Add the following to `src/cli.py` after the lookup command:

```python
def cmd_query(args):
    """Query leads in CRM."""
    from .query import LeadQueryClient
    from .formatters import format_lead_table
    import requests

    # Check credentials
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    # Initialize token manager
    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    # Create query client
    query_client = LeadQueryClient(token_manager)

    # Determine query type
    result = None
    query_desc = ""

    try:
        if args.email:
            query_desc = f"email '{args.email}'"
            print(f"Querying lead by {query_desc}...\n")
            result = query_client.query_by_email(args.email)
        elif args.id:
            query_desc = f"ID '{args.id}'"
            print(f"Querying lead by {query_desc}...\n")
            result = query_client.query_by_id(args.id)
        elif args.company:
            query_desc = f"company '{args.company}'"
            print(f"Querying lead by {query_desc}...\n")
            result = query_client.query_by_company(args.company)
        elif args.recent:
            print(f"Querying {args.recent} most recent leads...\n")
            # TODO: Implement recent leads query
            print("Recent leads query not yet implemented")
            sys.exit(0)
        else:
            print("Please specify a query filter:")
            print("  --email <address>")
            print("  --id <lead_id>")
            print("  --company <name>")
            print("  --recent <n>")
            sys.exit(1)

        if result:
            format_lead_table(result)
        else:
            print(f"✗ No lead found with {query_desc}")
            sys.exit(1)

    except requests.exceptions.RequestException as e:
        print_error('REQUEST_ERROR', f"Query failed: {e}")
        sys.exit(1)
```

**Step 2: Add query parser to main()**

Add the query subparser in the `main()` function, after the lookup parser:

```python
# query command
query_parser = subparsers.add_parser('query', help='Query leads in CRM')
query_parser.add_argument('--email', help='Query by email address')
query_parser.add_argument('--id', help='Query by CRM lead ID')
query_parser.add_argument('--company', help='Query by company name')
query_parser.add_argument('--recent', type=int, help='List N most recent leads')
query_parser.set_defaults(func=cmd_query)
```

**Step 3: Update imports if needed**

Ensure the imports at the top of `cli.py` include what we need (they should already be there from existing code).

**Step 4: Run a quick syntax check**

```bash
uv run python -c "from src import cli; print('CLI imports OK')"
```

Expected: No errors

**Step 5: Test the help command**

```bash
uv run crm query --help
```

Expected: Shows help text for query command with all options

**Step 6: Commit**

```bash
git add src/cli.py
git commit -m "feat: add query command to CLI

- Add cmd_query() function to handle lead queries
- Support query by email, ID, company name, and recent leads
- Integrate with LeadQueryClient and format_lead_table
- Add query subparser with --email, --id, --company, --recent options"
```

---

## Task 4: Integration Testing

**Files:**
- None to modify

**Step 1: Test querying existing lead**

Run the actual query against your existing test lead:

```bash
uv run crm query --email mohammed.khalil@yahoo.de
```

Expected output:
- Shows lead details table
- Displays country as "DE" with ⚠ warning
- Shows primary industry as "商超" with ⚠ warning

**Step 2: Test query by ID**

```bash
uv run crm query --id 69ad3d697b29ec0007111128
```

Expected: Same output as email query

**Step 3: Test not found case**

```bash
uv run crm query --email nonexistent@example.com
```

Expected: "✗ No lead found with email 'nonexistent@example.com'"

**Step 4: Run all unit tests**

```bash
uv run python -m pytest tests/ -v
```

Expected: All tests pass (existing + new)

**Step 5: Commit test results**

```bash
git add .
git commit -m "test: verify lead query feature works end-to-end

- Test query by email, ID for existing lead
- Verify not found handling
- All unit tests passing"
```

---

## Summary

After completing all tasks, the CRM CLI will have:

1. **New `crm query` command** with options:
   - `--email <address>` - Query by email
   - `--id <lead_id>` - Query by CRM ID
   - `--company <name>` - Query by company
   - `--recent <n>` - List recent leads

2. **Visual output** showing:
   - Lead details in a formatted table
   - Warnings for fields that may show "选项已删除"
   - Both raw stored values and expected formats

3. **Full test coverage** with unit tests and integration verification

## Usage Example

```bash
# Query by email
$ uv run crm query --email mohammed.khalil@yahoo.de

===============================================================
  Lead Query Result
===============================================================

  Basic Information
  -------------------------------------------------------------
  CRM ID:        69ad3d697b29ec0007111128
  Company:       Metro Deutschland GmbH
  Email:         mohammed.khalil@yahoo.de

  ...

  ⚠ Fields with Issues:
  Country:       DE  [⚠ May show as 选项已删除]
  Primary Industry: 商超  [⚠ May show as 选项已删除]
```
