# CRM Mappers Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add mapper commands to crm-cli for production-ready lead processing

**Architecture:** Extend existing `crm-cli` package at `~/projects/crm-cli/` with new commands that cache and map field values

**Tech Stack:** Python 3.10+, hatchling, Existing crm-cli codebase

---

## Task 1: Create cache module

**Files:**
- Create: `~/projects/crm-cli/src/cache.py`

**Step 1: Write the cache module**

Create `~/projects/crm-cli/src/cache.py`:

```python
"""
Options cache for CRM field mappings.
Caches describe results to avoid repeated API calls.
"""
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any

logger = logging.getLogger('cache')

# Cache settings
CACHE_DIR = Path.home() / ".cache" / "crm-helpers"
CACHE_FILE = CACHE_DIR / "options.json"
CACHE_TTL_DAYS = 30


def get_cache_path() -> Path:
    """Return cache file path."""
    return CACHE_FILE


def load_cache() -> Optional[Dict[str, Any]]:
    """
    Load cache from disk.

    Returns:
        Cache dict if valid and not expired, None otherwise
    """
    if not CACHE_FILE.exists():
        return None

    try:
        with open(CACHE_FILE, 'r') as f:
            data = json.load(f)

        # Check expiration
        fetched_at = datetime.fromisoformat(data.get("fetched_at", ""))
        expires_at = fetched_at + timedelta(days=CACHE_TTL_DAYS)

        if datetime.now() > expires_at:
            logger.info("Cache expired")
            return None

        return data
    except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Cache corrupted: {e}")
            return None


def save_cache(data: Dict[str, Any]) -> None:
    """
    Save cache to disk with timestamp.

    Args:
        data: Cache data to save
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    data["fetched_at"] = datetime.now().isoformat()

    with open(CACHE_FILE, 'w') as f:
        json.dump(data, f, indent=2)

    logger.info(f"Cache saved to {CACHE_FILE}")


def get_cache_age() -> Optional[timedelta]:
    """
    Get age of current cache.

    Returns:
        timedelta if cache exists, None otherwise
    """
    if not CACHE_FILE.exists():
        return None

    try:
        with open(CACHE_FILE, 'r') as f:
            data = json.load(f)
        fetched_at = datetime.fromisoformat(data.get("fetched_at", ""))
        return datetime.now() - fetched_at
    except (json.JSONDecodeError, ValueError):
        return None
```

**Step 2: Verify cache module works**

```bash
cd ~/projects/crm-cli
python3 -c "from src.cache import get_cache_path; print(get_cache_path())"
# Expected: /Users/<you>/.cache/crm-helpers/options.json
```

---

## Task 2: Create mappers module

**Files:**
- Create: `~/projects/crm-cli/src/mappers.py`

**Step 1: Write the mappers module**

Create `~/projects/crm-cli/src/mappers.py`:

```python
"""
Field value mappers for CRM.
Maps human-readable values to CRM option IDs.
"""
import logging
import sys
from typing import Optional

from .describe import DescribeClient
from .cache import load_cache, save_cache
from .fxiaoke_auth import TokenManager

logger = logging.getLogger('mappers')

# Field IDs in CRM (these are the actual API field names)
FIELD_COUNTRY = "field_IT92M__c"  # 国家 (Country)
FIELD_INDUSTRY = "field_e2eon__c"  # 行业 (Industry)
FIELD_SOURCE = "field_NtXsK__c"  # 线索来源 (Lead Source)


def normalize_input(value: str) -> str:
    """
    Normalize input for matching.
    Lowercase, strip whitespace, handle common variations.
    """
    if not value:
        return ""
    return value.lower().strip()


def find_option_id(cache: dict, field_id: str, input_value: str) -> Optional[str]:
    """
    Find option ID in cached field options.

    Args:
        cache: Cache dict with 'fields' key
        field_id: CRM field API name
        input_value: Human-readable value to match

    Returns:
        Option ID if found, None otherwise
    """
    if not cache or "fields" not in cache:
        return None

    field_data = cache["fields"].get(field_id, {})
    options = field_data.get("options", [])

    normalized_input = normalize_input(input_value)

    for opt in options:
        label = opt.get("label", "")
        value = opt.get("value", "")

        # Match against label (normalized)
        if normalize_input(label) == normalized_input:
            return value

        # Also check if input is already an option ID
        if value == input_value:
            return value

    return None


class FieldMapper:
    """Maps human-readable values to CRM option IDs."""

    def __init__(self, token_manager: TokenManager):
        self.token_manager = token_manager
        self._cache: Optional[dict] = None

    def _ensure_cache(self) -> dict:
        """Load cache, refresh if needed."""
        if self._cache is None:
            self._cache = load_cache()

        if self._cache is None:
            # Refresh cache from API
            self._cache = self._refresh_cache()

        return self._cache or {}

    def _refresh_cache(self) -> Optional[dict]:
        """Fetch fresh options from CRM API."""
        describe_client = DescribeClient(self.token_manager)
        obj_desc = describe_client.describe_object("LeadsObj")

        if not obj_desc:
            logger.error("Failed to describe LeadsObj")
            return None

        # Build cache structure
        cache_data = {"fields": {}}

        for field_id in [FIELD_COUNTRY, FIELD_INDUSTRY, FIELD_SOURCE]:
            field_def = obj_desc.fields.get(field_id)
            if field_def:
                cache_data["fields"][field_id] = {
                    "name": field_def.label,
                    "options": [
                        {"value": opt.value, "label": opt.label}
                        for opt in field_def.options
                    ]
                }

        save_cache(cache_data)
        return cache_data

    def map_country(self, input_value: str) -> Optional[str]:
        """Map country name/code to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_COUNTRY, input_value)

    def map_industry(self, input_value: str) -> Optional[str]:
        """Map industry name to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_INDUSTRY, input_value)

    def map_source(self, input_value: str) -> Optional[str]:
        """Map lead source to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_SOURCE, input_value)
```

**Step 2: Verify mappers module imports**

```bash
cd ~/projects/crm-cli
python3 -c "from src.mappers import FieldMapper, normalize_input; print('OK')"
# Expected: OK
```

---

## Task 3: Add CLI commands

**Files:**
- Modify: `~/projects/crm-cli/src/cli.py`

**Step 1: Add imports at top of cli.py**

Add after line 20 (after existing imports):

```python
from .mappers import FieldMapper
from .cache import get_cache_path, get_cache_age
```

**Step 2: Add map-country command**

Add after the describe_parser section (around line 214):

```python
    # map-country command
    map_country_parser = subparsers.add_parser('map-country', help='Map country name to CRM option ID')
    map_country_parser.add_argument('country', help='Country name or code (e.g., "Germany", "DE", "deutschland")')
    map_country_parser.set_defaults(func=cmd_map_country)

    # map-industry command
    map_industry_parser = subparsers.add_parser('map-industry', help='Map industry name to CRM option ID')
    map_industry_parser.add_argument('industry', help='Industry name (e.g., "retail", "fitness")')
    map_industry_parser.set_defaults(func=cmd_map_industry)

    # map-source command
    map_source_parser = subparsers.add_parser('map-source', help='Map lead source to CRM option ID')
    map_source_parser.add_argument('source', help='Lead source (e.g., "facebook", "linkedin")')
    map_source_parser.set_defaults(func=cmd_map_source)

    # cache-refresh command
    cache_refresh_parser = subparsers.add_parser('cache-refresh', help='Refresh the options cache from CRM API')
    cache_refresh_parser.set_defaults(func=cmd_cache_refresh)

    # cache-status command
    cache_status_parser = subparsers.add_parser('cache-status', help='Show cache status and age')
    cache_status_parser.set_defaults(func=cmd_cache_status)
```

**Step 3: Add command functions**

Add before `if __name__ == '__main__':` (around line 527):

```python
def cmd_map_country(args):
    """Map country name to CRM option ID."""
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    mapper = FieldMapper(token_manager)
    option_id = mapper.map_country(args.country)

    if option_id:
        print(option_id)
    else:
        print(f"Country '{args.country}' not found in CRM options", file=sys.stderr)
        sys.exit(1)


def cmd_map_industry(args):
    """Map industry name to CRM option ID."""
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    mapper = FieldMapper(token_manager)
    option_id = mapper.map_industry(args.industry)

    if option_id:
        print(option_id)
    else:
        print(f"Industry '{args.industry}' not found in CRM options", file=sys.stderr)
        sys.exit(1)


def cmd_map_source(args):
    """Map lead source to CRM option ID."""
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    mapper = FieldMapper(token_manager)
    option_id = mapper.map_source(args.source)

    if option_id:
        print(option_id)
    else:
        print(f"Source '{args.source}' not found in CRM options", file=sys.stderr)
        sys.exit(1)


def cmd_cache_refresh(args):
    """Refresh the options cache."""
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    mapper = FieldMapper(token_manager)
    mapper._refresh_cache()

    print(f"✓ Cache refreshed: {get_cache_path()}")


def cmd_cache_status(args):
    """Show cache status."""
    cache_path = get_cache_path()

    if not cache_path.exists():
        print("Cache: not found")
        print(f"Path: {cache_path}")
        return

    age = get_cache_age()
    if age:
        days = age.days
        remaining = 30 - days
        status = "valid" if remaining > 0 else "expired"
        print(f"Cache: {cache_path}")
        print(f"Age: {days} days")
        print(f"Expires in: {remaining} days ({status})")
    else:
        print(f"Cache: {cache_path}")
        print("Status: corrupted or invalid")
```

**Step 4: Update help text**

Find the help print section (around line 221-225) and add:

```python
        print("  crm map-country <name>  - Map country to option ID")
        print("  crm map-industry <name> - Map industry to option ID")
        print("  crm map-source <name>  - Map source to option ID")
        print("  crm cache-refresh     - Refresh options cache")
        print("  crm cache-status      - Show cache status")
```

---

## Task 4: Test the implementation

**Step 1: Test cache-status (should show no cache)**

```bash
cd ~/projects/crm-cli
crm cache-status
# Expected: Cache: not found
```

**Step 2: Test cache-refresh**

```bash
crm cache-refresh
# Expected: ✓ Cache refreshed: /Users/<you>/.cache/crm-helpers/options.json
```

**Step 3: Test cache-status again**

```bash
crm cache-status
# Expected:
# Cache: /Users/<you>/.cache/crm-helpers/options.json
# Age: 0 days
# Expires in: 30 days (valid)
```

**Step 4: Test map-country**

```bash
crm map-country DE
# Expected: <option_id> (e.g., KsekHd2m8)

crm map-country Germany
# Expected: <same option_id>

crm map-country "not a country"
# Expected: exit code 1, error message
```

**Step 5: Test map-industry**

```bash
crm map-industry retail
# Expected: <option_id>
```

**Step 6: Test map-source**

```bash
crm map-source facebook
# Expected: <option_id>
```

---

## Task 5: Update crm-cli version and reinstall

**Files:**
- Modify: `~/projects/crm-cli/pyproject.toml`

**Step 1: Bump version**

```toml
version = "0.2.0"  # Changed from "0.1.11"
```

**Step 2: Reinstall the tool**

```bash
cd ~/projects/crm-cli
uv tool install . --force
```

**Step 3: Verify new commands work**

```bash
crm --help
# Should show new map-* and cache-* commands
```

---

## Task 6: Update documentation in virtual-salesperson

**Files:**
- Modify: `/Users/thaddeus/projects/the virtual sales person/docs/ARCHITECTURE.md`

**Step 1: Update CLI tools reference**

Update the crm-cli section to include new commands:

```markdown
### crm-cli

Sync leads to FXiaoke CRM and Also includes field value mappers.

```bash
# Installation
uv tool install crm-cli

# Mapper commands (NEW)
crm map-country DE              # → KsekHd2m8
crm map-country Germany        # → KsekHd2m8
crm map-industry retail        # → <option_id>
crm map-source facebook       # → 6A7SBTmqi

# Cache management (NEW)
crm cache-refresh             # Refresh options cache
crm cache-status              # Show cache age/validity

# Existing commands
crm sync /tmp/crm_lead.json --owner FSUID_xxx
crm describe --object LeadsObj
crm query --email test@example.com
```
```

---

## Verification Checklist

After all tasks complete, verify:

- [ ] `crm map-country DE` returns an option ID (not empty)
- [ ] `crm map-country Germany` returns same ID as above
- [ ] `crm map-industry retail` returns an option ID
- [ ] `crm map-source facebook` returns an option ID
- [ ] `crm cache-status` shows valid cache with remaining days
- [ ] Cache file exists at `~/.cache/crm-helpers/options.json`
- [ ] `crm --help` shows all new commands
- [ ] ARCHITECTURE.md updated with new commands

---

## Commit Message

```
feat: add field mappers and options cache to crm-cli

- Add map-country, map-industry, map-source commands
- Add cache-refresh and cache-status commands
- Cache stored at ~/.cache/crm-helpers/options.json (30-day TTL)
- Auto-refresh when cache expired

Closes #<issue_number>
```
