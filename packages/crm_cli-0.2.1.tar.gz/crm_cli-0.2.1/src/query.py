"""
Lead query client for FXiaoke CRM.
Provides methods to query leads by email, ID, or company name.
"""

import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any

import requests

from .fxiaoke_auth import TokenManager

logger = logging.getLogger('lead_query')

QUERY_ENDPOINT = "https://open.fxiaoke.com/cgi/crm/custom/v2/data/findOne"


@dataclass
class QueryResult:
    """Result of a lead query."""
    lead_id: str
    company: str
    email: Optional[str]
    phone: Optional[str]
    country: Optional[str]
    raw_data: Dict[str, Any]  # All fields from API


class LeadQueryClient:
    """Client for querying leads from FXiaoke CRM."""

    def __init__(self, token_manager: TokenManager):
        """
        Initialize query client.

        Args:
            token_manager: TokenManager instance for authentication
        """
        self.token_manager = token_manager
        self.session = token_manager.session

    def query_by_email(self, email: str) -> Optional[QueryResult]:
        """
        Query lead by email address.

        Args:
            email: Email address to search for

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("email", email)

    def query_by_id(self, lead_id: str) -> Optional[QueryResult]:
        """
        Query lead by CRM ID.

        Args:
            lead_id: CRM lead ID (e.g., "69ad3d697b29ec0007111128")

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("_id", lead_id)

    def query_by_company(self, company_name: str) -> Optional[QueryResult]:
        """
        Query lead by company name (exact match).

        Args:
            company_name: Company name to search for

        Returns:
            QueryResult if found, None otherwise
        """
        return self._query_with_filter("name", company_name)

    def _query_with_filter(self, field: str, value: str) -> Optional[QueryResult]:
        """
        Execute query with a single filter.

        Args:
            field: Field name to filter on
            value: Value to match

        Returns:
            QueryResult if found, None otherwise
        """
        auth = self.token_manager.get_auth_headers()
        if not auth:
            logger.error("Authentication failed - no valid token")
            return None

        payload = {
            "corpAccessToken": auth["corpAccessToken"],
            "corpId": auth["corpId"],
            "currentOpenUserId": auth.get("currentOpenUserId", ""),
            "data": {
                "dataObjectApiName": "LeadsObj",
                "search_query_info": {
                    "offset": 0,
                    "limit": 10,
                    "filters": [
                        {
                            "field_name": field,
                            "field_values": [value],
                            "operator": "EQ"
                        }
                    ]
                },
                "field_projection": []
            }
        }

        try:
            response = requests.post(
                QUERY_ENDPOINT,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()

            if data.get("errorCode") != 0:
                logger.error(f"Query failed: {data.get('errorMessage')}")
                return None

            # The findOne API returns data in objectData field
            result_data = data.get("data", {})
            if not result_data:
                return None

            # The actual lead data is nested in objectData
            object_data = result_data.get("objectData", {})
            if not object_data:
                return None

            return self._parse_lead_data(object_data)

        except requests.exceptions.RequestException as e:
            logger.error(f"Query request failed: {e}")
            return None

    def _parse_lead_data(self, data: Dict[str, Any]) -> QueryResult:
        """
        Parse API response data into QueryResult.

        Args:
            data: Raw lead data from API

        Returns:
            QueryResult with parsed fields
        """
        return QueryResult(
            lead_id=data.get("_id", ""),
            company=data.get("company", ""),  # Company name (not 'name' which is contact name)
            email=data.get("email") or data.get("field_xxx__c"),  # Check standard + custom
            phone=data.get("field_S737R__c"),  # Contact phone field
            country=data.get("field_IT92M__c"),  # Country field
            raw_data=data  # Keep all data for detailed display
        )
