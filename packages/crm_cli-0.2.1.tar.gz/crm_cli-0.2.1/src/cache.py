"""
Options cache for CRM field mappings.
Caches describe results to avoid repeated API calls.
"""
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any

logger = logging.getLogger('cache')

# Cache settings
CACHE_DIR = Path.home() / ".cache" / "crm-helpers"
CACHE_FILE = CACHE_DIR / "options.json"
CACHE_TTL_DAYS = 30


def get_cache_path() -> Path:
    """Return cache file path."""
    return CACHE_FILE


def load_cache() -> Optional[Dict[str, Any]]:
    """
    Load cache from disk.

    Returns:
        Cache dict if valid and not expired, None otherwise
    """
    if not CACHE_FILE.exists():
        return None

    try:
        with open(CACHE_FILE, 'r') as f:
            data = json.load(f)

        # Check expiration
        fetched_at = datetime.fromisoformat(data.get("fetched_at", ""))
        expires_at = fetched_at + timedelta(days=CACHE_TTL_DAYS)

        if datetime.now() > expires_at:
            logger.info("Cache expired")
            return None

        return data
    except (json.JSONDecodeError, ValueError) as e:
        logger.warning(f"Cache corrupted: {e}")
        return None


def save_cache(data: Dict[str, Any]) -> None:
    """
    Save cache to disk with timestamp.

    Args:
        data: Cache data to save
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    data["fetched_at"] = datetime.now().isoformat()

    with open(CACHE_FILE, 'w') as f:
        json.dump(data, f, indent=2)

    logger.info(f"Cache saved to {CACHE_FILE}")


def get_cache_age() -> Optional[timedelta]:
    """
    Get age of current cache.

    Returns:
        timedelta if cache exists, None otherwise
    """
    if not CACHE_FILE.exists():
        return None

    try:
        with open(CACHE_FILE, 'r') as f:
            data = json.load(f)
        fetched_at = datetime.fromisoformat(data.get("fetched_at", ""))
        return datetime.now() - fetched_at
    except (json.JSONDecodeError, ValueError):
        return None
