"""
Output formatters for displaying lead query results and field descriptions.
"""

from typing import Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .query import QueryResult
    from .describe import ObjectDescription, FieldDefinition, FieldOption


def format_lead_table(result: "QueryResult") -> None:
    """
    Format and print lead details in a table-like format.

    Shows key lead information and highlights potential issues
    like fields showing "选项已删除".

    Args:
        result: QueryResult with lead data
    """
    raw = result.raw_data

    # Header
    print("=" * 65)
    print("  Lead Query Result")
    print("=" * 65)
    print()

    # Basic Info Section
    print("  Basic Information")
    print("  " + "-" * 61)
    print(f"  CRM ID:        {result.lead_id}")
    print(f"  Company:       {result.company}")
    if result.email:
        print(f"  Email:         {result.email}")
    if result.phone:
        print(f"  Phone:         {result.phone}")
    print()

    # Address/Region Section
    print("  Region & Address")
    print("  " + "-" * 61)

    # Country field - show warning if it looks like a code not option ID
    country = raw.get("field_IT92M__c", "")
    if country:
        if len(country) <= 3 and country.isalpha():
            # Likely a country code like "DE" - will show as 选项已删除
            print(f"  Country:       {country}  [⚠ May show as 选项已删除]")
        else:
            print(f"  Country:       {country}")

    # Region (区域) - shows as option ID
    region = raw.get("field_g60ab__c", "")
    if region:
        region_display = {"1dKGudtaC": "欧洲", "5yF9DohVi": "亚洲"}.get(region, region)
        print(f"  Region:        {region_display}")

    print()

    # Industry Section (if present)
    primary_ind = raw.get("field_e2eon__c", "")
    secondary_ind = raw.get("field_e1Gqm__c", "")

    if primary_ind or secondary_ind:
        print("  Industry Classification")
        print("  " + "-" * 61)

        if primary_ind:
            # Check if it looks like text rather than option ID
            if len(primary_ind) > 10:
                print(f"  Primary:       {primary_ind}")
            else:
                print(f"  Primary:       {primary_ind}  [⚠ May show as 选项已删除]")

        if secondary_ind:
            if len(secondary_ind) > 10:
                print(f"  Secondary:     {secondary_ind}")
            else:
                print(f"  Secondary:     {secondary_ind}  [⚠ May show as 选项已删除]")

        print()

    # Source Section
    print("  Source Information")
    print("  " + "-" * 61)

    secondary_source = raw.get("field_NtXsK__c", "")
    if secondary_source:
        # Map known option IDs to display names
        source_map = {
            "1Lk5T92e1": "LinkedIn",
            "6A7SBTmqi": "Facebook",
            "15i2w2eom": "Google",
            "20NkwyqL0": "Yahoo"
        }
        display = source_map.get(secondary_source, secondary_source)
        print(f"  Secondary:     {display}")

    print()

    # Raw Data Summary (optional - for debugging)
    print("  " + "=" * 61)
    print("  Tip: Use raw_data for full field inspection")
    print("  " + "=" * 61)
    print()


def format_describe_output(object_name: str, fields: dict, single_field: bool = False) -> None:
    """
    Format and print field description output.

    Args:
        object_name: Name of the CRM object
        fields: Dictionary of field definitions
        single_field: Whether showing a single field or all fields
    """
    from src.describe import FieldDefinition  # Local import to avoid circular dependency

    if single_field:
        # Single field output
        field = next(iter(fields.values()))
        print("=" * 80)
        print(f"  Field: {field.api_name}")
        print(f"  Label: {field.label}")
        if field.label_en:
            print(f"  Label (EN): {field.label_en}")
        print(f"  Type: {field.field_type}")
        print("=" * 80)
        print()

        if field.options:
            print("  Available Options:")
            print("  " + "-" * 76)
            print(f"  {'Option ID':<20} | {'Display Label':<50}")
            print("  " + "-" * 76)
            for opt in field.options:
                print(f"  {opt.value:<20} | {opt.label:<50}")
            print("  " + "-" * 76)
        else:
            print("  No options available for this field type.")
        print()
    else:
        # All fields output
        print("=" * 80)
        print(f"  Object: {object_name}")
        print(f"  Total Fields: {len(fields)}")
        print("=" * 80)
        print()

        for field_name, field in fields.items():
            print(f"Field: {field.api_name}")
            print(f"  Label: {field.label}")
            print(f"  Type: {field.field_type}")

            if field.options:
                print(f"  Options ({len(field.options)}):")
                # Show first 5 options
                for opt in field.options[:5]:
                    print(f"    {opt.value}: {opt.label}")
                if len(field.options) > 5:
                    print(f"    ... and {len(field.options) - 5} more")
            print()

    print("=" * 80)
    print("  Tip: Use --format json for machine-readable output")
    print("=" * 80)
    print()
