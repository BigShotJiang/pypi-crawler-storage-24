"""
Field value mappers for CRM.
Maps human-readable values to CRM option IDs.
"""
import logging
import sys
from typing import Optional, Dict, Any

from .describe import DescribeClient
from .cache import load_cache, save_cache
from .fxiaoke_auth import TokenManager

logger = logging.getLogger('mappers')

# Field IDs in CRM (these are the actual API field names)
FIELD_COUNTRY = "field_IT92M__c"  # 国家 (Country)
FIELD_INDUSTRY = "field_e2eon__c"  # 行业 (Industry)
FIELD_SOURCE = "field_NtXsK__c"  # 线索来源 (Lead Source)

# Country aliases: maps English names and codes to Chinese names used in CRM
COUNTRY_ALIASES = {
    # Country codes
    "de": "德国",
    "us": "美国",
    "uk": "英国",
    "gb": "英国",
    "cn": "中国",
    "jp": "日本",
    "kr": "韩国",
    "fr": "法国",
    "it": "意大利",
    "es": "西班牙",
    "au": "澳大利亚",
    "ca": "加拿大",
    "sg": "新加坡",
    "my": "马来西亚",
    "th": "泰国",
    "vn": "越南",
    "in": "印度",
    "br": "巴西",
    "mx": "墨西哥",
    "ae": "阿联酋",
    "sa": "沙特阿拉伯",
    "ru": "俄罗斯",
    "nl": "荷兰",
    "be": "比利时",
    "ch": "瑞士",
    "at": "奥地利",
    "se": "瑞典",
    "no": "挪威",
    "dk": "丹麦",
    "fi": "芬兰",
    "pl": "波兰",
    "cz": "捷克",
    "pt": "葡萄牙",
    "gr": "希腊",
    "tr": "土耳其",
    "id": "印度尼西亚",
    "ph": "菲律宾",
    "tw": "中国台湾",
    "hk": "中国香港",
    "mo": "中国澳门",
    "nz": "新西兰",
    "za": "南非",
    "eg": "埃及",
    "ng": "尼日利亚",
    "ke": "肯尼亚",
    "il": "以色列",
    "ir": "伊朗",
    "iq": "伊拉克",
    "pk": "巴基斯坦",
    "bd": "孟加拉",
    "ua": "乌克兰",
    "ro": "罗马尼亚",
    "hu": "匈牙利",
    "ie": "爱尔兰",
    "sk": "斯洛伐克",
    "bg": "保加利亚",
    "hr": "克罗地亚",
    "si": "斯洛文尼亚",
    "rs": "塞尔维亚",
    "lt": "立陶宛",
    "lv": "拉脱维亚",
    "ee": "爱沙尼亚",
    "co": "哥伦比亚",
    "ar": "阿根廷",
    "cl": "智利",
    "pe": "秘鲁",
    "ve": "委内瑞拉",
    "cl": "哥伦比亚",
    # English names
    "germany": "德国",
    "united states": "美国",
    "usa": "美国",
    "america": "美国",
    "united kingdom": "英国",
    "great britain": "英国",
    "britain": "英国",
    "england": "英国",
    "china": "中国",
    "japan": "日本",
    "korea": "韩国",
    "south korea": "韩国",
    "france": "法国",
    "italy": "意大利",
    "spain": "西班牙",
    "australia": "澳大利亚",
    "canada": "加拿大",
    "singapore": "新加坡",
    "malaysia": "马来西亚",
    "thailand": "泰国",
    "vietnam": "越南",
    "india": "印度",
    "brazil": "巴西",
    "mexico": "墨西哥",
    "united arab emirates": "阿联酋",
    "saudi arabia": "沙特阿拉伯",
    "russia": "俄罗斯",
    "netherlands": "荷兰",
    "belgium": "比利时",
    "switzerland": "瑞士",
    "austria": "奥地利",
    "sweden": "瑞典",
    "norway": "挪威",
    "denmark": "丹麦",
    "finland": "芬兰",
    "poland": "波兰",
    "portugal": "葡萄牙",
    "greece": "希腊",
    "turkey": "土耳其",
    "indonesia": "印度尼西亚",
    "philippines": "菲律宾",
    "taiwan": "中国台湾",
    "hong kong": "中国香港",
    "macau": "中国澳门",
    "new zealand": "新西兰",
    "south africa": "南非",
    "egypt": "埃及",
    "nigeria": "尼日利亚",
    "kenya": "肯尼亚",
    "israel": "以色列",
    "iran": "伊朗",
    "iraq": "伊拉克",
    "pakistan": "巴基斯坦",
    "bangladesh": "孟加拉",
    "ukraine": "乌克兰",
    "romania": "罗马尼亚",
    "hungary": "匈牙利",
    "ireland": "爱尔兰",
    "czech": "捷克",
    "czech republic": "捷克",
    "croatia": "克罗地亚",
    "serbia": "塞尔维亚",
    "colombia": "哥伦比亚",
    "argentina": "阿根廷",
    "chile": "智利",
    "peru": "秘鲁",
    "deutschland": "德国",  # German name
}

# Industry aliases: maps English names to Chinese names used in CRM
INDUSTRY_ALIASES = {
    "retail": "商超",
    "supermarket": "商超",
    "restaurant": "餐饮",
    "food service": "餐饮",
    "hospitality": "酒店",
    "hotel": "酒店",
    "medical": "医疗",
    "healthcare": "医疗",
    "cleaning": "清洁",
    "logistics": "工厂物流",
    "warehouse": "工厂物流",
    "it": "IT信息技术",
    "technology": "IT信息技术",
    "finance": "金融",
    "trading": "贸易商/批发/零售",
    "wholesale": "贸易商/批发/零售",
    "robot": "机器人",
    "robot manufacturer": "机器人生产商",
    "robot distributor": "机器人代理商",
}

# Source aliases: maps English names to Chinese names used in CRM
SOURCE_ALIASES = {
    "google": "Google",
    "linkedin": "Linkedin",
    "facebook": "Facebook",
    "email": "Email",
    "website": "官网",
    "official website": "官网",
    "yahoo": "Yahoo",
    "market search": "市场部检索",
    "referral": "公司内部转介绍",
    "internal referral": "公司内部转介绍",
    "friend referral": "朋友介绍/代理商介绍",
    "other": "其他",
    "phone": "电话拜访",
    "cold call": "电话拜访",
    "webinar": "webinar",
    "alibaba": "阿里国际站",
    "email marketing": "邮件自营销售",
    "telemarketing": "电话营销",
    "social media": "社媒",
    "exhibition": "展会商机",
    "agent registration": "代理商备案",
}


def normalize_input(value: str) -> str:
    """
    Normalize input for matching.
    Lowercase, strip whitespace, handle common variations.
    """
    if not value:
        return ""
    return value.lower().strip()


def find_option_id(cache: dict, field_id: str, input_value: str, aliases: Optional[dict] = None) -> Optional[str]:
    """
    Find option ID in cached field options.

    Args:
        cache: Cache dict with 'fields' key
        field_id: CRM field API name
        input_value: Human-readable value to match
        aliases: Optional dict mapping normalized input to CRM label

    Returns:
        Option ID if found, None otherwise
    """
    if not cache or "fields" not in cache:
        return None

    field_data = cache["fields"].get(field_id, {})
    options = field_data.get("options", [])

    normalized_input = normalize_input(input_value)

    # Check aliases first (maps English to Chinese)
    if aliases:
        mapped_value = aliases.get(normalized_input)
        if mapped_value:
            # Now search for the Chinese label
            for opt in options:
                if opt.get("label") == mapped_value:
                    return opt.get("value")

    for opt in options:
        label = opt.get("label", "")
        value = opt.get("value", "")

        # Match against label (normalized)
        if normalize_input(label) == normalized_input:
            return value

        # Also check if input is already an option ID
        if value == input_value:
            return value

    return None


class FieldMapper:
    """Maps human-readable values to CRM option IDs."""

    def __init__(self, token_manager: TokenManager):
        self.token_manager = token_manager
        self._cache: Optional[dict] = None

    def _ensure_cache(self) -> dict:
        """Load cache, refresh if needed."""
        if self._cache is None:
            self._cache = load_cache()

        if self._cache is None:
            # Refresh cache from API
            self._cache = self._refresh_cache()

        return self._cache or {}

    def _refresh_cache(self) -> Optional[dict]:
        """Fetch fresh options from CRM API."""
        describe_client = DescribeClient(self.token_manager)
        obj_desc = describe_client.describe_object("LeadsObj")

        if not obj_desc:
            logger.error("Failed to describe LeadsObj")
            return None

        # Build cache structure
        cache_data = {"fields": {}}

        for field_id in [FIELD_COUNTRY, FIELD_INDUSTRY, FIELD_SOURCE]:
            field_def = obj_desc.fields.get(field_id)
            if field_def:
                cache_data["fields"][field_id] = {
                    "name": field_def.label,
                    "options": [
                        {"value": opt.value, "label": opt.label}
                        for opt in field_def.options
                    ]
                }

        save_cache(cache_data)
        return cache_data

    def map_country(self, input_value: str) -> Optional[str]:
        """Map country name/code to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_COUNTRY, input_value, COUNTRY_ALIASES)

    def map_industry(self, input_value: str) -> Optional[str]:
        """Map industry name to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_INDUSTRY, input_value, INDUSTRY_ALIASES)

    def map_source(self, input_value: str) -> Optional[str]:
        """Map lead source to CRM option ID."""
        cache = self._ensure_cache()
        return find_option_id(cache, FIELD_SOURCE, input_value, SOURCE_ALIASES)
