"""
Field description client for FXiaoke CRM.
Provides methods to discover field metadata and option values.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List

import requests

from .fxiaoke_auth import TokenManager

logger = logging.getLogger('describe_client')

DESCRIBE_ENDPOINT = "https://open.fxiaoke.com/cgi/crm/v2/object/describe"


@dataclass
class FieldOption:
    """A single option for a select field."""
    value: str  # The option ID (e.g., "kaYz89Lwq")
    label: str  # The display label (e.g., "Germany")


@dataclass
class FieldDefinition:
    """Definition of a CRM field."""
    api_name: str  # Field API name (e.g., "field_IT92M__c")
    label: str  # Display label (e.g., "国家")
    label_en: Optional[str] = None  # English label if available
    field_type: str = ""  # select_one, text, email, etc.
    options: List[FieldOption] = field(default_factory=list)  # For select fields


@dataclass
class ObjectDescription:
    """Description of a CRM object including all fields."""
    api_name: str  # Object API name (e.g., "LeadsObj")
    label: str  # Object display label
    fields: Dict[str, FieldDefinition] = field(default_factory=dict)


class DescribeClient:
    """Client for discovering CRM field metadata."""

    def __init__(self, token_manager: TokenManager):
        """
        Initialize describe client.

        Args:
            token_manager: TokenManager instance for authentication
        """
        self.token_manager = token_manager

    def describe_object(self, api_name: str) -> Optional[ObjectDescription]:
        """
        Describe a CRM object and all its fields.

        Args:
            api_name: Object API name (e.g., "LeadsObj")

        Returns:
            ObjectDescription if successful, None otherwise
        """
        auth = self.token_manager.get_auth_headers()
        if not auth:
            logger.error("Authentication failed - no valid token")
            return None

        payload = {
            "corpAccessToken": auth["corpAccessToken"],
            "corpId": auth["corpId"],
            "currentOpenUserId": auth.get("currentOpenUserId", ""),
            "apiName": api_name
        }

        try:
            response = requests.post(
                DESCRIBE_ENDPOINT,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()

            if data.get("errorCode") != 0:
                logger.error(f"Describe failed: {data.get('errorMessage')}")
                return None

            return self._parse_object_description(api_name, data)

        except requests.exceptions.RequestException as e:
            logger.error(f"Describe request failed: {e}")
            return None

    def describe_field(self, api_name: str, field_name: str) -> Optional[FieldDefinition]:
        """
        Describe a specific field.

        Args:
            api_name: Object API name (e.g., "LeadsObj")
            field_name: Field API name (e.g., "field_IT92M__c")

        Returns:
            FieldDefinition if found, None otherwise
        """
        obj_desc = self.describe_object(api_name)
        if not obj_desc:
            return None

        return obj_desc.fields.get(field_name)

    def _parse_object_description(self, api_name: str, data: Dict[str, Any]) -> ObjectDescription:
        """
        Parse API response into ObjectDescription.

        Args:
            api_name: Object API name
            data: Raw API response

        Returns:
            Parsed ObjectDescription
        """
        describe = data.get("data", {}).get("describe", {})
        obj_label = describe.get("label", api_name)

        obj_desc = ObjectDescription(
            api_name=api_name,
            label=obj_label
        )

        # Parse fields
        fields = describe.get("fields", {})
        for field_api_name, field_info in fields.items():
            field_def = self._parse_field_definition(field_api_name, field_info)
            obj_desc.fields[field_api_name] = field_def

        return obj_desc

    def _parse_field_definition(self, api_name: str, info: Dict[str, Any]) -> FieldDefinition:
        """
        Parse field info into FieldDefinition.

        Args:
            api_name: Field API name
            info: Raw field info from API

        Returns:
            Parsed FieldDefinition
        """
        field_def = FieldDefinition(
            api_name=api_name,
            label=info.get("label", api_name),
            field_type=info.get("type", "unknown")
        )

        # Parse options for select fields
        if "options" in info:
            for opt in info["options"]:
                option = FieldOption(
                    value=opt.get("value", ""),
                    label=opt.get("label", "")
                )
                field_def.options.append(option)

        return field_def
