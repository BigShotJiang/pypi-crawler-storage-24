#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用对象描述接口获取字段选项值
"""

import requests
import json
from auth import get_access_token, get_current_open_user_id


def get_object_describe():
    """获取线索对象的描述信息，包括字段选项"""
    token_result = get_access_token()
    if not token_result:
        print("获取token失败")
        return None
    
    corp_access_token = token_result.get('corpAccessToken')
    corp_id = token_result.get('corpId')
    current_open_user_id = get_current_open_user_id()
    
    url = "https://open.fxiaoke.com/cgi/crm/v2/object/describe"
    
    data = {
        "corpAccessToken": corp_access_token,
        "currentOpenUserId": current_open_user_id,
        "corpId": corp_id,
        "data": {
            "apiName": "LeadsObj",
            "includeDetail": True
        }
    }
    
    response = requests.post(url, json=data)
    result = response.json()
    
    if result.get("errorCode") != 0:
        print(f"查询失败: {result.get('errorMessage')}")
        return None
    
    return result


def extract_field_options(result, target_field_name):
    """从对象描述中提取指定字段的选项值"""
    if not result or "data" not in result:
        return None
    
    describe = result.get("data", {}).get("describe", {})
    fields = describe.get("fields", {})
    
    field = fields.get(target_field_name)
    if not field:
        return None
    
    options = field.get("options", [])
    if not options:
        return None
    
    return {
        "field_api_name": target_field_name,
        "field_label": field.get("label", ""),
        "field_type": field.get("type", ""),
        "options": [
            {
                "label": opt.get("label", ""),
                "value": opt.get("value", ""),
            }
            for opt in options
        ]
    }


def print_field_options(field_info):
    """打印字段选项信息"""
    if not field_info:
        print("未找到字段或字段无选项")
        return
    
    print(f"\n{'='*80}")
    print(f"字段: {field_info['field_label']} ({field_info['field_api_name']})")
    print(f"类型: {field_info['field_type']}")
    print(f"{'='*80}")
    print(f"\n选项值列表 (共 {len(field_info['options'])} 个):")
    print(f"{'-'*80}")
    print(f"{'选项标签':<40} {'选项值(code)':<30}")
    print(f"{'-'*80}")
    
    for opt in field_info['options']:
        print(f"{opt['label']:<40} {opt['value']:<30}")


def main():
    """主函数"""
    print("正在调用对象描述接口...")
    result = get_object_describe()
    
    if not result:
        return
    
    # 要查询的字段列表
    fields_to_query = [
        ("field_NtXsK__c", "二级来源"),
        ("source", "一级来源"),
        ("field_g60ab__c", "区域"),
        ("field_IT92M__c", "国家"),
        ("field_7dDlL__c", "跟进状态"),
        ("leads_stage", "线索阶段"),
        ("field_e2eon__c", "一级行业"),
        ("field_e1Gqm__c", "二级行业"),
        ("leads_pool_id", "线索池"),
    ]
    
    all_results = {}
    
    for field_api_name, field_label in fields_to_query:
        field_info = extract_field_options(result, field_api_name)
        if field_info:
            print_field_options(field_info)
            all_results[field_api_name] = field_info
        else:
            print(f"\n未找到字段或字段无选项: {field_api_name} ({field_label})")
    
    # 保存到文件
    output_file = "field_options.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n\n所有字段选项已保存到: {output_file}")


if __name__ == "__main__":
    main()
