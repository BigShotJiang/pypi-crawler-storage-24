from .main import XGoogleDriveReader as gdr
from ...tools.logger import Logger as logger
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
import sys

class XGoogleService:

    def __init__(self, dataStorage: dict = None, readOptions: dict = None, schema: StructType = None,
                 sparkSession: SparkSession = None,
                 debug: bool = False):
        self.dataStorage = dataStorage
        self.readOptions = readOptions
        self.schema = schema
        # Initialize Spark session
        self.spark = sparkSession
        self.debug = debug

    def processRequest(self):
        """
        Process the request to get data from Google Sheets.
        
        Returns:
            pyspark.sql.DataFrame: Spark DataFrame if available, otherwise None.
        """
        dataStorage = self.dataStorage
        readOptions = self.readOptions or {}
        file_path = dataStorage.get("file_path", "") or readOptions.get("file_path", "")
        sheet_name = dataStorage.get("sheet_name", None) or readOptions.get("sheet_name", None)
        range_name = dataStorage.get("range_name") or readOptions.get("range_name")
        auth_file_path = dataStorage.get("auth_file_path", None) or readOptions.get("auth_file_path", None)
        rename_source = dataStorage.get("rename_source", False) or readOptions.get("rename_source", False)
        new_name = dataStorage.get("new_name", None) or readOptions.get("new_name", None)
        initial_timeout = dataStorage.get("initial_timeout", 10) or readOptions.get("initial_timeout", 10)
        max_timeout = dataStorage.get("max_timeout", 300) or readOptions.get("max_timeout", 300)
        local_path = dataStorage.get("local_path", "downloaded_file") or readOptions.get("local_path", "downloaded_file")
        fill_empty_cells = dataStorage.get("fill_empty_cells", False) or readOptions.get("fill_empty_cells", False)
        fill_merged_cells = dataStorage.get("fill_merged_cells", False) or readOptions.get("fill_merged_cells", False)
        output_sheet_name = dataStorage.get("output_sheet_name", None) or readOptions.get("output_sheet_name", None)

        # Initialize Google Drive Reader
        if auth_file_path:
            reader = gdr(auth_file_path)
        else:
            reader = gdr()  # Use default auth file path

        # Authenticate
        if reader.authenticate():
            if dataStorage.get("format").upper().endswith("SHEETS"):
                print(f'[Line 49] GoogleService[processRequest]: Google Sheets executing sheet reading.')
                print(f'[Line 50] GoogleService[processRequest]: file_path={file_path}')
                pandas_df = reader.read_sheet(
                    file_path=file_path,
                    sheet_name=sheet_name,
                    range_name=range_name
                )
                if self.debug:
                    print(f'[Line 57] GoogleService[processRequest]: Sheet read into Pandas DataFrame with shape: {pandas_df.shape if pandas_df is not None else "None"}')
                    print(f'[Line 58] GoogleService[processRequest]: Converting Pandas DataFrame to Spark DataFrame.')
                    print(f'[Line 59] GoogleService[processRequest]: First 5 rows of Pandas DataFrame: {pandas_df.head(5) if pandas_df is not None else "None"}')
                if pandas_df is not None:
                    # Convert pandas DataFrame to Spark DataFrame
                    try:
                        if pandas_df.empty:
                            logger().log('GoogleService[processRequest]: Pandas DataFrame is empty.', level='warning')
                            if self.schema and len(self.schema.fields) > 0:
                                return self.spark.createDataFrame([], self.schema)
                            elif len(pandas_df.columns) > 0:
                                schema = StructType([StructField(str(c), StringType(), True) for c in pandas_df.columns])
                                return self.spark.createDataFrame([], schema)
                            else:
                                return self.spark.createDataFrame([], StructType([]))

                        # Align Pandas DataFrame columns with Schema if provided
                        if self.schema and len(self.schema.fields) > 0:
                            schema_cols = [field.name for field in self.schema.fields]
                            # Add missing columns with None
                            for col in schema_cols:
                                if col not in pandas_df.columns:
                                    pandas_df[col] = None
                            # Reorder columns to match schema and drop extra columns
                            pandas_df = pandas_df[schema_cols]

                        schema_arg = self.schema
                        if schema_arg is not None and len(schema_arg.fields) == 0:
                            schema_arg = None

                        spark_df = self.spark.createDataFrame(
                            pandas_df,
                            schema=schema_arg
                        )

                        if self.debug:
                            print(f'[Line 93] GoogleService[processRequest]: Spark DataFrame created with schema: {spark_df.schema}')
                            print(f'[Line 94] GoogleService[processRequest]: Spark DataFrame row count: {spark_df.count()}')
                            logger().log(f'GoogleService[processRequest]: Spark DataFrame created with schema: {spark_df.schema}', level='debug')
                            # logger().log(f'GoogleService[processRequest]: Spark DataFrame row count: {spark_df.count()}', level='debug')
                            # Log sample data from pandas before conversion to avoid pandas dependency on executors
                            if len(pandas_df) > 0:
                                print(f'[Line 99] GoogleService[processRequest]: Sample data (first 5 rows):\n{pandas_df.head(5).to_string()}')
                                logger().log(f'GoogleService[processRequest]: Sample data (first 5 rows):\n{pandas_df.head(5).to_string()}', level='debug')
                        return spark_df
                    except Exception as e:
                        print(f'[Line 103] GoogleService[processRequest]: Failed to convert to Spark DataFrame: {str(e)}')
                        logger().log(f'GoogleService[processRequest]: Failed to convert to Spark DataFrame: {str(e)}', level='error')
                        return None
                else:
                    print('[Line 107] GoogleService[processRequest]: No data found in the specified sheet.')
                    logger().log('GoogleService[processRequest]: No data found in the specified sheet.', level='warning')
                    return None
            elif dataStorage.get("format").upper().endswith("FILE"):
                # Implement Google Drive File Download format handling if needed
                print(f'[Line 112] GoogleService[processRequest]: Google Drive File Download executing download.')
                print(f'[Line 113] GoogleService[processRequest]: file_path={file_path}')
                print(f'[Line 114] GoogleService[processRequest]: local_path={readOptions.get("local_path", "downloaded_file")}')
                reader.download_file(
                    file_path=file_path,
                    local_path=readOptions.get("local_path", "downloaded_file"),
                    mime_type=readOptions.get("mime_type", None)
                )
            elif dataStorage.get("format").upper().endswith("EXPORT"):
                # Implement Google Drive File Download format handling if needed
                print(f'[Line 122] GoogleService[processRequest]: Google Drive File Download executing download.')
                print(f'[Line 123] GoogleService[processRequest]: file_path={file_path}')
                print(f'[Line 124] GoogleService[processRequest]: local_path={local_path}')
                print(f'[Line 125] GoogleService[processRequest]: range_name={range_name}')
                print(f'[Line 126] GoogleService[processRequest]: initial_timeout={initial_timeout}')
                print(f'[Line 127] GoogleService[processRequest]: max_timeout={max_timeout}')
                print(f'[Line 128] GoogleService[processRequest]: fill_empty_cells={fill_empty_cells}')
                print(f'[Line 129] GoogleService[processRequest]: fill_merged_cells={fill_merged_cells}')
                print(f'[Line 130] GoogleService[processRequest]: output_sheet_name={output_sheet_name}')
                reader.export_sheet_to_excel(
                    file_path=file_path,
                    local_path=readOptions.get("local_path", "downloaded_file"),
                    mime_type=readOptions.get("mime_type", 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                    sheet_name=sheet_name,
                    range_name=range_name,
                    initial_timeout=initial_timeout,
                    max_timeout=max_timeout,
                    fill_empty_cells=fill_empty_cells,
                    fill_merged_cells=fill_merged_cells,
                    output_sheet_name=output_sheet_name
                )
            else:
                logger().log('GoogleService[processRequest]: Unsupported format specified.', level='error')
                return None
            # Rename file if required
            if rename_source and new_name:
                success = reader.rename_file(
                    file_path=file_path,
                    new_name=new_name
                )
                if success:
                    logger().log(f'GoogleService[processRequest]: File renamed successfully to {new_name}.', level='info')
                else:
                    logger().log('GoogleService[processRequest]: File renaming failed.', level='error')
        else:
            logger().log('GoogleService[processRequest]: Authentication failed.', level='error')
            return None

    def renameFile(self) -> bool:
        """
        Rename a file in Google Drive.
        
        Returns:
            bool: True if renaming was successful, otherwise False.
        """
        dataStorage = self.dataStorage
        file_path = dataStorage.get("file_path")
        new_name = dataStorage.get("new_name")
        auth_file_path = dataStorage.get("auth_file_path", None)

        # Initialize Google Drive Reader
        if auth_file_path:
            reader = gdr(auth_file_path)
        else:
            reader = gdr()  # Use default auth file path

        # Authenticate
        if reader.authenticate():
            success = reader.rename_file(
                file_path=file_path,
                new_name=new_name
            )
            if success:
                logger().log(f'GoogleService[renameFile]: File renamed successfully to {new_name}.', level='info')
            else:
                logger().log('GoogleService[renameFile]: File renaming failed.', level='error')
            return success
        else:
            logger().log('GoogleService[renameFile]: Authentication failed.', level='error')
            return False

