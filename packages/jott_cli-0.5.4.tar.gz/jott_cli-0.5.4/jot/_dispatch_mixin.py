"""Dispatch mixin — mode-specific key dispatch for App."""

import time

from jot.core.constants import (
    MODE_QUICK_ADD, MODE_COMMAND, MODE_MULTISELECT,
    MODE_FUZZY_SEARCH, MODE_ALL_CATEGORIES,
)
from jot.ui.input import get_key
from jot.ui.styles import RESET, CYAN


class DispatchMixin:
    """Mode-specific key dispatch methods for App."""

    def _dispatch_quick_add(self, key, tasks_to_display):
        """Handle a keypress in QUICK_ADD mode."""
        st = self.state

        if key == '\r' or key == '\n':
            self._quick_add_enter()
            return

        if key == '\x1b':
            st.mode = MODE_COMMAND
            st.input_buffer = ""
            return

        if key == '\x7f':
            st.input_buffer = st.input_buffer[:-1]
            return

        if key == '\x03':  # Ctrl+C
            self._handle_switch_category()
            return

        if key == 'Z':
            self._handle_switch_project()
            return

        if key == 'L':
            should_toggle, new_mode = (
                self.command_handler.toggle_all_categories_view(st.mode))
            if should_toggle:
                st.mode = new_mode
            st.input_buffer = ""
            return

        if key == '=':
            self.task_manager.sort_by_priority()
            st.input_buffer = ""
            return

        method_name = self._QUICK_ADD_SIMPLE.get(key)
        if method_name:
            getattr(self.command_handler, method_name)()
            st.input_buffer = ""
            return

        if self._handle_toggle(key):
            return

        if key == 'V':
            st.mode = MODE_MULTISELECT
            st.selected_tasks.clear()
            st.input_buffer = ""
            return

        if key == '\x06':  # Ctrl+F
            st.mode = MODE_FUZZY_SEARCH
            st.search_buffer = ""
            st.filtered_tasks = []
            st.input_buffer = ""
            return

        if key == '\t':
            self._handle_tab_cycle()
            return

        if self._handle_navigation(key, tasks_to_display):
            return

        if key == '.':
            self._handle_dot_chord()
            return

        if len(key) == 1 and key.isprintable():
            st.input_buffer += key

    def _quick_add_enter(self):
        """Handle Enter key in quick-add mode."""
        st = self.state
        if st.input_buffer.strip():
            result = self.task_manager.add_task(st.input_buffer.strip())
            if isinstance(result, dict):
                if result.get('action') == 'broadcast':
                    self._confirm_broadcast(result)
                elif result.get('action') == 'route':
                    self._execute_route(result)
            st.input_buffer = ""
        else:
            tally_count = self.task_manager.increment_tally()
            if tally_count:
                print(f"\n{CYAN}\u2713 Tally: \u00d7{tally_count}{RESET}")
                time.sleep(0.3)

    def _confirm_broadcast(self, info):
        """Prompt user before broadcasting task to all projects."""
        from jot.ui.input import restore_terminal
        projects = (self.task_manager.keyword_handler
                    .project_registry.list_projects())
        n = len(projects)
        print(f"\n\u26a0  Broadcast \"{info['task_text']}\" "
              f"to {n} projects? (y/N): ", end='', flush=True)
        restore_terminal()
        if input().strip().lower() == 'y':
            count = self.task_manager._route_to_project(
                info['task_text'], info['project_name'],
                info['priority'], info['status'],
                info['labels'], info['effort'])
            print(f"{CYAN}\u2713 Added to {count} projects{RESET}")
        else:
            print("Cancelled")
        time.sleep(0.5)

    def _execute_route(self, info):
        """Route task to a single project with feedback."""
        count = self.task_manager._route_to_project(
            info['task_text'], info['project_name'],
            info['priority'], info['status'],
            info['labels'], info['effort'])
        if count:
            print(f"\n{CYAN}\u2713 Routed to "
                  f"{info['project_name']}{RESET}")
            time.sleep(0.5)

    def _dispatch_command(self, key, tasks_to_display):
        """Handle a keypress in COMMAND mode."""
        st = self.state

        if key == 'a':
            st.mode = MODE_QUICK_ADD
            st.input_buffer = ""
            return

        if self._handle_navigation(key, tasks_to_display):
            return

        if key == '\r' or key == '\n':
            tally_count = self.task_manager.increment_tally()
            if tally_count:
                print(f"\n{CYAN}\u2713 Tally: \u00d7{tally_count}{RESET}")
                time.sleep(0.3)
            return

        if key in ('A', 'O', 'Y'):
            self._handle_toggle(key)
            return

        if key:
            st.running = self.command_handler.handle(key)

    def _dispatch_multiselect(self, key, tasks_to_display):
        """Handle a keypress in MULTISELECT mode."""
        st = self.state

        if key == '\x1b':
            st.mode = MODE_QUICK_ADD
            st.selected_tasks.clear()
            return

        if key == ' ':
            current_task = self.task_manager.get_current_task()
            if current_task:
                task_id = current_task['id']
                if task_id in st.selected_tasks:
                    st.selected_tasks.remove(task_id)
                else:
                    st.selected_tasks.add(task_id)
            return

        if key == 'A':
            for task in self.task_manager.tasks:
                st.selected_tasks.add(task['id'])
            return

        if key == 'N':
            st.selected_tasks.clear()
            return

        filtered = (
            tasks_to_display
            if st.show_today_only or st.collapsed_parents
            else None)

        if key == 'UP':
            self.task_manager.set_prev_current(filtered)
            return
        if key == 'DOWN':
            self.task_manager.set_next_current(filtered)
            return

        if key == 'SHIFT_UP':
            self.task_manager.set_prev_current(filtered)
            current_task = self.task_manager.get_current_task()
            if current_task:
                st.selected_tasks.add(current_task['id'])
            return
        if key == 'SHIFT_DOWN':
            self.task_manager.set_next_current(filtered)
            current_task = self.task_manager.get_current_task()
            if current_task:
                st.selected_tasks.add(current_task['id'])
            return

        if key == 'B':
            self._multiselect_bulk_action()
            return

    def _multiselect_bulk_action(self):
        """Process bulk action menu in multiselect mode."""
        st = self.state
        if not st.selected_tasks:
            return

        action = self.command_handler.bulk_actions_menu(st.selected_tasks)
        action_map = {
            'priority': self.command_handler.bulk_set_priority,
            'status': self.command_handler.bulk_set_status,
            'delete': self.command_handler.bulk_delete,
            'archive': self.command_handler.bulk_archive,
        }
        handler = action_map.get(action)
        if handler:
            handler(st.selected_tasks)
            st.selected_tasks.clear()

    def _dispatch_fuzzy_search(self, key):
        """Handle a keypress in FUZZY_SEARCH mode."""
        st = self.state

        if key == '\x1b':
            st.mode = MODE_QUICK_ADD
            st.search_buffer = ""
            st.match_positions = {}
            return

        if key == '\r' or key == '\n':
            current_task = self.task_manager.get_current_task()
            if current_task:
                st.mode = MODE_QUICK_ADD
                st.search_buffer = ""
                st.match_positions = {}
            return

        if key == '\x7f':
            if st.search_buffer:
                st.search_buffer = st.search_buffer[:-1]
            return

        if key == '\x01':  # Ctrl+A
            st.include_archived_in_search = (
                not st.include_archived_in_search)
            return

        if key in ('UP', 'DOWN'):
            self._fuzzy_navigate(key)
            return

        if len(key) == 1 and key.isprintable():
            st.search_buffer += key

    def _fuzzy_navigate(self, key):
        """Navigate within fuzzy search filtered results."""
        st = self.state
        if not st.filtered_tasks:
            return

        current_task = self.task_manager.get_current_task()
        if not current_task:
            return

        current_id = current_task['id']
        filtered_ids = [t[0]['id'] for t in st.filtered_tasks]
        if current_id not in filtered_ids:
            return

        idx = filtered_ids.index(current_id)
        if key == 'UP' and idx > 0:
            self.task_manager.set_current(
                st.filtered_tasks[idx - 1][0]['id'])
        elif key == 'DOWN' and idx < len(st.filtered_tasks) - 1:
            self.task_manager.set_current(
                st.filtered_tasks[idx + 1][0]['id'])

    def _handle_dot_chord(self):
        """Handle '.' leader key — wait for second key to form chord."""
        st = self.state
        second = get_key(timeout=0.5)
        if second == 's':
            self._toggle_collapse()
            st.input_buffer = ""
            return
        if second == 'c':
            self.command_handler.copy_to_clipboard()
            st.input_buffer = ""
            return
        if second == '?':
            st.show_shortcuts = not st.show_shortcuts
            st.input_buffer = ""
            return
        if second == 'i':
            self.command_handler.import_from_gcal()
            st.input_buffer = ""
            return
        if second == 'g':
            self.command_handler.web_search()
            st.input_buffer = ""
            return
        # Not a chord — treat '.' as normal input
        st.input_buffer += '.'
        if second and second != '.':
            st.input_buffer += second

    def _toggle_collapse(self):
        """Toggle collapse state for current task's parent group."""
        task = self.task_manager.get_current_task()
        if not task:
            return

        tasks = self.task_manager.get_tasks()
        collapsed = self.state.collapsed_parents

        # Check if current task is a parent (has descendants)
        has_children = any(
            f'parent:{task["id"]}' in t.get('labels', [])
            for t in tasks
        )

        if has_children:
            target_id = task['id']
        else:
            # Check if it's a child — toggle its parent
            target_id = None
            for label in task.get('labels', []):
                if label.startswith('parent:'):
                    pid = label.split(':', 1)[1]
                    try:
                        target_id = int(pid)
                    except ValueError:
                        target_id = pid
                    break

        if target_id is None:
            return

        # Count descendants for feedback
        children_of = {}
        for t in tasks:
            for label in t.get('labels', []):
                if label.startswith('parent:'):
                    pid = label.split(':', 1)[1]
                    try:
                        pid = int(pid)
                    except ValueError:
                        pass
                    children_of.setdefault(pid, []).append(t['id'])
                    break

        count = 0
        stack = list(children_of.get(target_id, []))
        seen = set()
        while stack:
            cid = stack.pop()
            if cid not in seen:
                seen.add(cid)
                count += 1
                stack.extend(children_of.get(cid, []))

        if target_id in collapsed:
            collapsed.discard(target_id)
            print(f"\n{CYAN}▼ Expanded {count} subtask"
                  f"{'s' if count != 1 else ''}{RESET}")
        else:
            collapsed.add(target_id)
            print(f"\n{CYAN}▶ Collapsed {count} subtask"
                  f"{'s' if count != 1 else ''}{RESET}")
        time.sleep(0.3)

    def _dispatch_all_categories(self, key, tasks_to_display):
        """Handle a keypress in ALL_CATEGORIES mode."""
        st = self.state

        if key == '\x1b' or key == 'L':
            st.mode = MODE_QUICK_ADD
            return

        filtered = (
            tasks_to_display
            if st.show_today_only or st.collapsed_parents
            else None)
        if key == 'UP':
            self.task_manager.set_prev_current(filtered)
        elif key == 'DOWN':
            self.task_manager.set_next_current(filtered)
