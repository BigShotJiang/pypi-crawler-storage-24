"""Main application loop for jot — extracted from jot.py

Provides the App class that owns the interactive event loop and
dispatches key events through mode-specific dispatch tables.
"""

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from jot.core.constants import (
    MODE_QUICK_ADD, MODE_COMMAND, MODE_ALL_CATEGORIES,
)
from jot.ui import display_all_categories_view, display_tasks
from jot.ui.input import get_key
from jot.utils.date_utils import (
    get_today_day_name, sort_tasks_by_day, filter_today_tasks,
)
from jot.utils.text_utils import fuzzy_match
from jot._dispatch_mixin import DispatchMixin
from jot._app_navigation_mixin import AppNavigationMixin
from jot.ui.rendering import buffered_output


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

@dataclass
class AppState:
    """All mutable state for the main event loop."""

    mode: str = MODE_QUICK_ADD
    input_buffer: str = ""
    show_archived: bool = False
    sort_by_day: bool = False
    show_today_only: bool = False
    include_archived_in_search: bool = True
    show_shortcuts: bool = False
    show_notes_inline: bool = False
    running: bool = True
    selected_tasks: set = field(default_factory=set)
    search_buffer: str = ""
    filtered_tasks: list = field(default_factory=list)
    archived_task_ids: set = field(default_factory=set)
    match_positions: dict = field(default_factory=dict)
    collapsed_parents: set = field(default_factory=set)


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

class App(DispatchMixin, AppNavigationMixin):
    """Interactive event loop for the jot TUI."""

    _QUICK_ADD_SIMPLE = {
        'M': 'move_task_to_project',
        '\x0b': 'copy_task_to_project',        # Ctrl+K
        '\x14': 'transfer_task_to_category',       # Ctrl+T
        '\x13': 'sync_subtasks',                # Ctrl+S
        '\x04': 'delete_current',              # Ctrl+D
        'W': 'assign_day',
        'P': 'set_priority',
        'H': 'set_priority_high',
        'X': 'set_status',
        'G': 'export_to_gcal',
        'E': 'trigger_keyword_action',
        'N': 'edit_task_notes',
        '\x15': 'open_url',                     # Ctrl+U
        '(': 'ultrathink_task',
        ')': 'execute_analysis_task',
        '$': 'suggest_task',
        'J': 'set_agent_task',
        'B': 'start_priority_timer',
        '!': 'fix_duplicate_ids_interactive',
        '@': 'read_tasks_aloud',
        '#': 'reauthenticate_google_calendar',
        '\x12': 'register_current_project',     # Ctrl+R
        '*': 'toggle_highlight',
        '~': 'quick_highlight',
        '\x0c': 'assign_parent',                # Ctrl+L
    }

    def __init__(self, task_manager, command_handler, registry,
                 target_dir, project_name):
        self.task_manager = task_manager
        self.command_handler = command_handler
        self.registry = registry
        self.target_dir = target_dir
        self.project_name = project_name

        self.state = AppState()
        self._needs_render = True
        self._last_mtime = (
            os.path.getmtime(task_manager.storage_file)
            if task_manager.storage_file.exists() else 0)

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self):
        """Run the main interactive loop until the user quits."""
        try:
            self._event_loop()
        finally:
            sys.stdout.write('\033[?25h')
            sys.stdout.flush()

    def _event_loop(self):
        """Inner event loop — separated so run() can wrap with
        try/finally."""
        while self.state.running:
            if self._needs_render:
                tasks_to_display = self._prepare_tasks()
                self._render(tasks_to_display)
                self._needs_render = False
            else:
                tasks_to_display = self._prepare_tasks()

            try:
                key = get_key()

                if self._handle_auto_refresh(key):
                    continue
                if self._handle_paste(key):
                    continue

                # Any real key press triggers a render
                self._needs_render = True

                # Global handlers (any mode)
                if key == '\x05':                   # Ctrl+E
                    self.command_handler.edit_current()
                    self.state.input_buffer = ""
                    continue
                if key == '\x18':                   # Ctrl+X
                    print("\n\nGoodbye!")
                    self.state.running = False
                    continue

                # Mode dispatch
                mode = self.state.mode
                if mode == MODE_QUICK_ADD:
                    self._dispatch_quick_add(key, tasks_to_display)
                elif mode == 'multiselect':
                    self._dispatch_multiselect(key, tasks_to_display)
                elif mode == 'fuzzy_search':
                    self._dispatch_fuzzy_search(key)
                elif mode == MODE_ALL_CATEGORIES:
                    self._dispatch_all_categories(key, tasks_to_display)
                else:
                    self._dispatch_command(key, tasks_to_display)

            except (KeyboardInterrupt, EOFError):
                print("\n\nGoodbye!")
                break

    # ------------------------------------------------------------------
    # Task preparation & filtering
    # ------------------------------------------------------------------

    def _prepare_tasks(self):
        """Fetch, filter, and sort the task list for display."""
        tasks = self.task_manager.get_tasks()

        # Stash full list before collapse filtering so display can
        # compute correct descendant counts for collapsed parents.
        self._all_tasks = tasks

        if self.state.collapsed_parents:
            tasks = self._filter_collapsed(tasks)
        if self.state.show_today_only:
            today = get_today_day_name()
            tasks = filter_today_tasks(tasks, today)
        if self.state.sort_by_day:
            tasks = sort_tasks_by_day(tasks)

        return self._get_filtered_tasks(tasks)

    def _filter_collapsed(self, tasks):
        """Remove descendants of collapsed parents from the task list."""
        # Build parent→children map
        children_of = {}
        for task in tasks:
            for label in task.get('labels', []):
                if label.startswith('parent:'):
                    pid = label.split(':', 1)[1]
                    try:
                        pid = int(pid)
                    except ValueError:
                        pass
                    children_of.setdefault(pid, []).append(task['id'])
                    break

        # Collect all descendants of collapsed parents (BFS)
        hidden = set()
        for root_id in self.state.collapsed_parents:
            stack = list(children_of.get(root_id, []))
            while stack:
                cid = stack.pop()
                if cid not in hidden:
                    hidden.add(cid)
                    stack.extend(children_of.get(cid, []))

        return [t for t in tasks if t['id'] not in hidden]

    def _get_filtered_tasks(self, tasks_to_display):
        """Apply fuzzy-search filtering when in FUZZY_SEARCH mode."""
        st = self.state

        if st.mode == 'fuzzy_search' and st.search_buffer:
            st.filtered_tasks = []
            st.archived_task_ids = set()

            for task in tasks_to_display:
                is_match, score, positions = fuzzy_match(
                    st.search_buffer, task.get('text', ''))
                if is_match:
                    st.filtered_tasks.append((task, score, positions))

            if st.include_archived_in_search:
                for task in self.task_manager.archived:
                    is_match, score, positions = fuzzy_match(
                        st.search_buffer, task.get('text', ''))
                    if is_match:
                        st.filtered_tasks.append((task, score, positions))
                        st.archived_task_ids.add(task['id'])

            st.filtered_tasks.sort(key=lambda x: x[1], reverse=True)
            tasks_to_display = [t[0] for t in st.filtered_tasks]
            st.match_positions = {
                t[0]['id']: t[2] for t in st.filtered_tasks
            }

            if st.filtered_tasks:
                current = self.task_manager.get_current_task()
                filtered_ids = {t[0]['id'] for t in st.filtered_tasks}
                if not current or current['id'] not in filtered_ids:
                    self.task_manager.set_current(
                        st.filtered_tasks[0][0]['id'])

        elif st.mode == 'fuzzy_search':
            st.archived_task_ids = set()
            st.match_positions = {}

        return tasks_to_display

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _render(self, tasks_to_display):
        """Clear screen and draw the current view."""
        with buffered_output():
            sys.stdout.write('\033[?25l\033[H\033[J')
            st = self.state

            if st.mode == MODE_ALL_CATEGORIES:
                self._render_all_categories()
            else:
                all_tasks = (
                    self._all_tasks
                    if st.collapsed_parents else None)
                display_tasks(
                    tasks_to_display, st.mode, st.input_buffer,
                    self.project_name,
                    category=self.task_manager.category,
                    is_global=self.task_manager.is_global,
                    show_archived=st.show_archived,
                    archived_tasks=self.task_manager.archived,
                    selected_tasks=st.selected_tasks,
                    search_buffer=st.search_buffer,
                    archived_task_ids=st.archived_task_ids,
                    include_archived_in_search=st.include_archived_in_search,
                    show_shortcuts=st.show_shortcuts,
                    show_notes_inline=st.show_notes_inline,
                    match_positions=st.match_positions,
                    collapsed_parents=st.collapsed_parents,
                    all_tasks=all_tasks,
                )

            sys.stdout.write('\033[?25h')

    def _render_all_categories(self):
        """Delegate ALL_CATEGORIES rendering to the display module."""
        st = self.state
        project_dir = (
            self.task_manager.project_dir
            if not self.task_manager.is_global else Path.cwd())
        all_cat_data = self.command_handler.collect_all_category_tasks(
            project_dir, show_archived=st.show_archived)
        display_all_categories_view(
            all_cat_data, project_dir, show_archived=st.show_archived)

    # ------------------------------------------------------------------
    # Auto-refresh & paste
    # ------------------------------------------------------------------

    def _handle_auto_refresh(self, key):
        """Detect external file changes on timeout."""
        if key is not None:
            return False

        if self.task_manager.storage_file.exists():
            current_mtime = os.path.getmtime(
                self.task_manager.storage_file)
            if current_mtime != self._last_mtime:
                self.task_manager._load_tasks()
                self._last_mtime = current_mtime
                self._needs_render = True
        return True

    def _handle_paste(self, key):
        """Handle bracketed-paste events."""
        if not (isinstance(key, tuple) and key[0] == 'PASTE'):
            return False

        pasted_text = key[1]
        if self.state.mode == MODE_QUICK_ADD:
            pasted_text = pasted_text.replace('\r', '').replace('\n', '')
            self.state.input_buffer += pasted_text
        self._needs_render = True
        return True
