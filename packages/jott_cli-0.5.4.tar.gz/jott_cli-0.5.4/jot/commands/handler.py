"""Command handler for interactive jot UI — facade over domain mixins."""

from jot.commands._core_mixin import CoreMixin
from jot.commands._metadata_mixin import MetadataMixin
from jot.commands._transfer_mixin import TransferMixin
from jot.commands._bulk_mixin import BulkMixin
from jot.commands._gcal_mixin import GcalMixin
from jot.commands._ai_analysis_mixin import AiAnalysisMixin
from jot.commands._ai_suggest_mixin import AiSuggestMixin
from jot.commands._notes_mixin import NotesMixin
from jot.commands._web_clipboard_mixin import WebClipboardMixin
from jot.commands._audio_timer_mixin import AudioTimerMixin
from jot.commands._context_mixin import ContextMixin


class CommandHandler(
    CoreMixin,
    MetadataMixin,
    TransferMixin,
    BulkMixin,
    GcalMixin,
    AiAnalysisMixin,
    AiSuggestMixin,
    NotesMixin,
    WebClipboardMixin,
    AudioTimerMixin,
    ContextMixin,
):
    """Extensible command system — composed from domain-specific mixins."""

    def __init__(self, task_manager, registry=None):
        self.task_manager = task_manager
        self.registry = registry
        self.commands = {
            'a': self.add_task,
            'c': self.set_current,
            'd': self.delete_task,
            '\x04': self.delete_current,   # Ctrl+D
            'e': self.edit_task,
            'E': self.edit_current,
            'M': self.move_task_to_project,
            'r': self.refresh,
            'q': self.quit,
            'h': self.help,
        }

    def handle(self, command):
        """Handle a command"""
        # Check for exact match first (for case-sensitive commands like 'E')
        handler = self.commands.get(command)
        if not handler:
            # Fall back to lowercase
            handler = self.commands.get(command.lower())

        if handler:
            return handler()
        else:
            print(f"\nUnknown command: {command}. Press 'h' for help.")
            return True
