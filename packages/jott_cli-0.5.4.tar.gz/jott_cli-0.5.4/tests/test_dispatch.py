#!/usr/bin/env python3
"""Tests for jot/app.py dispatch tables and App class structure."""

import inspect

from jot.app import App, AppState
from jot.commands import CommandHandler
from jot.core.constants import (
    MODE_QUICK_ADD, MODE_COMMAND, MODE_MULTISELECT,
    MODE_FUZZY_SEARCH, MODE_ALL_CATEGORIES,
)


class TestAppState:
    """Verify AppState dataclass defaults."""

    def test_default_mode(self):
        state = AppState()
        assert state.mode == MODE_QUICK_ADD

    def test_default_input_buffer(self):
        assert AppState().input_buffer == ""

    def test_default_running(self):
        assert AppState().running is True

    def test_default_toggles(self):
        state = AppState()
        assert state.show_archived is False
        assert state.sort_by_day is False
        assert state.show_today_only is False
        assert state.include_archived_in_search is True
        assert state.show_shortcuts is False
        assert state.show_notes_inline is False

    def test_default_collections(self):
        state = AppState()
        assert state.selected_tasks == set()
        assert state.filtered_tasks == []
        assert state.archived_task_ids == set()

    def test_collections_are_independent(self):
        """Each instance should have its own set/list, not shared."""
        a = AppState()
        b = AppState()
        a.selected_tasks.add(1)
        assert 1 not in b.selected_tasks


class TestQuickAddDispatchTable:
    """Validate _QUICK_ADD_SIMPLE maps to real CommandHandler methods."""

    def test_all_entries_map_to_handler_methods(self):
        for key, method_name in App._QUICK_ADD_SIMPLE.items():
            assert hasattr(CommandHandler, method_name), (
                f"Key {key!r} maps to '{method_name}' which does not "
                f"exist on CommandHandler"
            )

    def test_all_methods_are_callable(self):
        for key, method_name in App._QUICK_ADD_SIMPLE.items():
            attr = getattr(CommandHandler, method_name)
            assert callable(attr), (
                f"Key {key!r} maps to '{method_name}' which is not callable"
            )

    def test_no_duplicate_keys(self):
        keys = list(App._QUICK_ADD_SIMPLE.keys())
        assert len(keys) == len(set(keys)), "Duplicate keys in dispatch table"

    def test_no_duplicate_method_names(self):
        methods = list(App._QUICK_ADD_SIMPLE.values())
        assert len(methods) == len(set(methods)), (
            "Duplicate method names in dispatch table"
        )

    def test_table_is_not_empty(self):
        assert len(App._QUICK_ADD_SIMPLE) >= 20, (
            "Dispatch table should have at least 20 entries"
        )

    def test_critical_keys_present(self):
        """Verify that the most important shortcuts are wired up."""
        critical = {
            '\x04': 'delete_current',  # Ctrl+D
            'W': 'assign_day',
            'P': 'set_priority',
            'X': 'set_status',
            'M': 'move_task_to_project',
            'N': 'edit_task_notes',
            '\x14': 'transfer_task_to_category',  # Ctrl+T
        }
        for key, expected_method in critical.items():
            assert App._QUICK_ADD_SIMPLE.get(key) == expected_method, (
                f"Key {key!r} should map to '{expected_method}'"
            )


class TestAppDispatcherStructure:
    """Verify that per-mode dispatch methods exist and have correct arity."""

    def test_mode_dispatchers_exist(self):
        expected = [
            '_dispatch_quick_add',
            '_dispatch_command',
            '_dispatch_multiselect',
            '_dispatch_fuzzy_search',
            '_dispatch_all_categories',
        ]
        for name in expected:
            assert hasattr(App, name), f"Missing dispatcher: {name}"
            assert callable(getattr(App, name))

    def test_shared_helpers_exist(self):
        helpers = [
            '_handle_navigation',
            '_handle_toggle',
            '_handle_auto_refresh',
            '_handle_paste',
            '_reload_task_manager',
            '_handle_switch_category',
            '_handle_switch_project',
            '_handle_tab_cycle',
        ]
        for name in helpers:
            assert hasattr(App, name), f"Missing helper: {name}"

    def test_run_method_exists(self):
        assert hasattr(App, 'run')
        assert callable(App.run)


class TestDisplayFunctionExport:
    """Verify display_all_categories_view is properly exported."""

    def test_importable_from_display(self):
        from jot.ui.display import display_all_categories_view
        assert callable(display_all_categories_view)

    def test_importable_from_ui_package(self):
        from jot.ui import display_all_categories_view
        assert callable(display_all_categories_view)

    def test_signature(self):
        from jot.ui.display import display_all_categories_view
        sig = inspect.signature(display_all_categories_view)
        params = list(sig.parameters.keys())
        assert 'all_cat_data' in params
        assert 'project_dir' in params
        assert 'show_archived' in params
