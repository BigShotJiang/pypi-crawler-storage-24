from pathlib import Path
from typing import List

import aidge_core
from aidge_core.export_utils import data_conversion, generate_file, generate_input_file
from aidge_export_cpp import CPP_ROOT


def generate_main_cpp(
    export_folder: str,
    graph_view: aidge_core.GraphView,
    inputs_tensor: List[aidge_core.Tensor] = None,
    labels: aidge_core.Tensor = None,
    main_name: str = "main.cpp",
    main_template_path: Path = CPP_ROOT / "templates" / "main.jinja",
) -> None:
    """
    Generate a C++ file to manage the forward pass of a model using the given graph structure.

    This function extracts details from the :py:class:`aidge_core.graph_view` object, including input and output node names, data types,
    and tensor sizes. It uses this data to populate a C++ file template (`main.jinja`), creating a file (`main.cpp`)
    that call the `model_forward` function, which handles data flow and processing for the exported model.

    This function also generate files containing input tensor if they have been set.

    :param export_folder: Path to the folder where the generated C++ file (`main.cpp`) will be saved.
    :type export_folder: str
    :param graph_view: An instance of :py:class:`aidge_core.graph_view`, providing access to nodes and
                       ordered input/output data within the computational graph.
    :type graph_view: aidge_core.graph_view
    :param inputs_tensor: argument to provide external tensors to use in the main function
                          By default, the input of the given graph will be exported.
    :type inputs_tensor: List[aidge_core.Tensor]
    :param labels: Argument to provide labels tensor to generate and use in the main function.
    :type labels: aidge_core.Tensor
    :raises RuntimeError: If there is an inconsistency in the output arguments (names, data types, sizes),
                          indicating an internal bug in the graph representation.
    """
    outputs_name: list[str] = []
    outputs_dtype: list[str] = []
    outputs_size: list[int] = []
    inputs_name: list[str] = []
    gv_inputs: list[tuple[aidge_core.Node, int]] = graph_view.get_ordered_inputs()
    gv_outputs: list[tuple[aidge_core.Node, int]] = graph_view.get_ordered_outputs()

    inputs_tensor_id = 0

    # Generate input file(s)
    for in_node, in_idx in gv_inputs:
        in_node_input, in_node_input_idx = in_node.input(in_idx)
        in_name = (
            f"{in_node.name()}_input_{in_idx}"
            if in_node_input is None
            else f"{in_node_input.name()}_output_{in_node_input_idx}"
        )

        # Ignore optional inputs
        if in_node.get_operator().is_optional_input(in_idx):
            continue

        # If inputs_tensor is not defined, take the inputs of the graph
        if inputs_tensor is None:
            input_tensor = in_node.get_operator().get_input(in_idx)

        else:
            input_tensor = inputs_tensor[inputs_tensor_id]
            inputs_tensor_id += 1

        # Generate the input
        ## For the forward call in the main file
        inputs_name.append(in_name)

        ## Generate the input file
        generate_input_file(
            export_folder=str(Path(export_folder) / "data"),
            array_name=in_name,
            tensor=input_tensor,
        )

    # Generate labels file
    if labels is not None:
        generate_input_file(
            export_folder=str(Path(export_folder) / "data"),
            array_name="labels",
            tensor=labels,
        )

    for out_node, out_id in gv_outputs:
        outputs_name.append(f"{out_node.name()}_output_{out_id}")
        out_tensor = out_node.get_operator().get_output(out_id)
        outputs_dtype.append(data_conversion.aidge2c(out_tensor.dtype))
        outputs_size.append(out_tensor.size)

    if len(outputs_name) != len(outputs_dtype) or len(outputs_name) != len(
        outputs_size
    ):
        raise RuntimeError(
            "FATAL: Output args list does not have the same length this is an internal bug."
        )

    generate_file(
        str(Path(export_folder) / main_name),
        str(main_template_path),
        func_name="model_forward",
        inputs_name=inputs_name,
        outputs_name=outputs_name,
        outputs_dtype=outputs_dtype,
        outputs_size=outputs_size,
        labels=(labels is not None),
    )
