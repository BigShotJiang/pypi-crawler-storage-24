import aidge_core
from aidge_export_arm_cortexm import ARM_CORTEXM_ROOT
from aidge_export_arm_cortexm.export_registry import ExportLibAidgeARM
from aidge_export_cpp.operators.ConvDw import *


@ExportLibAidgeARM.register(
    "ConvDepthWise2D",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.any),
        ],
        [  # Output specifications
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nhwc)
        ],
    ),
)
class ArmConvDw(ConvDw):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Replace the CPP macs.hpp file with the ARM optimized one
        ## Remove the macs.hpp file related to the CPP Export
        for i, kernel in enumerate(self.kernels_to_copy):
            if "macs.hpp" in str(kernel["src_path"]):
                self.kernels_to_copy.pop(i)
                break

        ## Add the macs.hpp file related to the Arm Export instead
        self.add_kernel_to_copy(
            ARM_CORTEXM_ROOT / "_Aidge_Arm" / "static" / "macs.hpp",
            "include/utils/cpp",
            fwd_include=False,
        )


@ExportLibAidgeARM.register_metaop(
    ["PaddedConvDepthWise2D", "PadConvDw"],
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
)
class ArmPadConvDw(PadConvDw, ArmConvDw):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibAidgeARM.register_metaop(
    "ConvDwAct", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class ArmConvDwAct(ConvDwAct, ArmConvDw):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibAidgeARM.register_metaop(
    "PadConvDwAct", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class ArmPadConvDwAct(ArmPadConvDw, ArmConvDwAct):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
