"""
Tests for preview session management and new backend models.

Covers:
- PreviewManager CRUD (start, get, list, stop, refresh, health, detect, cleanup)
- Preview model serialization / deserialization
- Schedule / Channel / Automation models (missing-model backfill)
- Lifecycle preset: agent_workspace
"""

import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, Any

from fleeks_sdk.previews import PreviewManager
from fleeks_sdk.models import (
    # Preview models
    PreviewStatus,
    PreviewFramework,
    PreviewSession,
    PreviewSessionList,
    PreviewHealth,
    PreviewDetectResult,
    # Schedule models
    ScheduleType,
    DaemonStatus,
    ProjectType,
    Schedule,
    ScheduleList,
    ScheduleStartResult,
    DaemonStatusInfo,
    DaemonLogs,
    QuotaMetric,
    QuotaCounter,
    QuotaUsage,
    # Sub-agent models
    SubAgentResult,
    SubAgentUsage,
    # Channel models
    ChannelType,
    ChannelTypeInfo,
    Channel,
    ChannelList,
    AuthFlowResult,
    # Automation models
    TriggerType,
    Automation,
    AutomationList,
    AutomationTestResult,
)
from fleeks_sdk.lifecycle import LifecycleConfig, IdleAction
from fleeks_sdk.exceptions import FleeksResourceNotFoundError, FleeksAPIError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_mock_client() -> MagicMock:
    """Build a mock FleeksClient with an async _make_request."""
    client = MagicMock()
    client._make_request = AsyncMock()
    return client


def _session_dict(**overrides: Any) -> Dict[str, Any]:
    """Factory for a valid PreviewSession response dict."""
    base: Dict[str, Any] = {
        "session_id": "prev_abc123",
        "project_id": 42,
        "status": "running",
        "preview_url": "https://preview-42.fleeks.dev",
        "port": 3000,
        "framework": "react_vite",
        "created_at": "2026-03-10T00:00:00Z",
        "started_at": "2026-03-10T00:00:01Z",
        "container_id": "ctr_xyz",
        "websocket_url": "wss://preview-42.fleeks.dev/ws",
        "auto_detected": True,
    }
    base.update(overrides)
    return base


# ============================================================================
# PREVIEW ENUM TESTS
# ============================================================================

class TestPreviewEnums:
    def test_preview_status_values(self) -> None:
        assert PreviewStatus.RUNNING.value == "running"
        assert PreviewStatus.STOPPED.value == "stopped"
        assert PreviewStatus.FAILED.value == "failed"
        assert PreviewStatus.UNHEALTHY.value == "unhealthy"

    def test_preview_framework_values(self) -> None:
        assert PreviewFramework.REACT_VITE.value == "react_vite"
        assert PreviewFramework.NEXTJS.value == "nextjs"
        assert PreviewFramework.FASTAPI.value == "fastapi"
        assert PreviewFramework.DJANGO.value == "django"
        assert PreviewFramework.STATIC.value == "static"


# ============================================================================
# PREVIEW MODEL TESTS
# ============================================================================

class TestPreviewSession:
    def test_from_dict_full(self) -> None:
        data = _session_dict()
        session = PreviewSession.from_dict(data)
        assert session.session_id == "prev_abc123"
        assert session.project_id == 42
        assert session.status == "running"
        assert session.preview_url == "https://preview-42.fleeks.dev"
        assert session.port == 3000
        assert session.framework == "react_vite"
        assert session.auto_detected is True
        assert session.container_id == "ctr_xyz"

    def test_from_dict_minimal(self) -> None:
        data = {
            "session_id": "prev_min",
            "project_id": 1,
            "created_at": "2026-03-10T00:00:00Z",
        }
        session = PreviewSession.from_dict(data)
        assert session.session_id == "prev_min"
        assert session.status == "starting"
        assert session.port == 3000
        assert session.framework == "custom"
        assert session.auto_detected is False

    def test_is_running(self) -> None:
        running = PreviewSession.from_dict(_session_dict(status="running"))
        stopped = PreviewSession.from_dict(_session_dict(status="stopped"))
        assert running.is_running is True
        assert stopped.is_running is False

    def test_is_healthy(self) -> None:
        running = PreviewSession.from_dict(_session_dict(status="running"))
        failed = PreviewSession.from_dict(_session_dict(status="failed"))
        assert running.is_healthy is True
        assert failed.is_healthy is False


class TestPreviewSessionList:
    def test_from_dict(self) -> None:
        data = {
            "sessions": [_session_dict(), _session_dict(session_id="prev_two")],
            "total": 2,
            "project_id": 42,
        }
        lst = PreviewSessionList.from_dict(data)
        assert lst.total == 2
        assert len(lst.sessions) == 2
        assert lst.project_id == 42

    def test_from_dict_empty(self) -> None:
        lst = PreviewSessionList.from_dict({"project_id": 1})
        assert lst.total == 0
        assert lst.sessions == []


class TestPreviewHealth:
    def test_from_dict(self) -> None:
        data = {
            "session_id": "prev_abc",
            "healthy": True,
            "status_code": 200,
            "response_time_ms": 42.5,
            "checked_at": "2026-03-10T12:00:00Z",
        }
        h = PreviewHealth.from_dict(data)
        assert h.healthy is True
        assert h.status_code == 200
        assert h.response_time_ms == 42.5

    def test_unhealthy(self) -> None:
        h = PreviewHealth.from_dict({"healthy": False, "error": "Connection refused"})
        assert h.healthy is False
        assert h.error == "Connection refused"


class TestPreviewDetectResult:
    def test_from_dict(self) -> None:
        data = {
            "project_id": 42,
            "detected_framework": "react_vite",
            "confidence": 0.95,
            "suggested_port": 5173,
            "suggested_command": "npm run dev",
            "config_files_found": ["package.json", "vite.config.ts"],
        }
        det = PreviewDetectResult.from_dict(data)
        assert det.detected_framework == "react_vite"
        assert det.confidence == 0.95
        assert det.suggested_port == 5173
        assert len(det.config_files_found) == 2


# ============================================================================
# PREVIEW MANAGER TESTS
# ============================================================================

class TestPreviewManager:
    def setup_method(self) -> None:
        self.mock_client = _make_mock_client()
        self.mgr = PreviewManager(self.mock_client)

    @pytest.mark.asyncio
    async def test_start(self) -> None:
        self.mock_client._make_request.return_value = _session_dict()
        session = await self.mgr.start(project_id=42, framework="react_vite", port=5173)
        assert session.session_id == "prev_abc123"
        self.mock_client._make_request.assert_awaited_once()
        call_args = self.mock_client._make_request.call_args
        assert call_args[0][0] == "POST"
        assert "42" in call_args[0][1]

    @pytest.mark.asyncio
    async def test_get(self) -> None:
        self.mock_client._make_request.return_value = _session_dict()
        session = await self.mgr.get("prev_abc123")
        assert session.preview_url == "https://preview-42.fleeks.dev"

    @pytest.mark.asyncio
    async def test_get_not_found(self) -> None:
        self.mock_client._make_request.side_effect = FleeksAPIError(
            "Not found", status_code=404
        )
        with pytest.raises(FleeksResourceNotFoundError):
            await self.mgr.get("prev_nonexistent")

    @pytest.mark.asyncio
    async def test_list(self) -> None:
        self.mock_client._make_request.return_value = {
            "sessions": [_session_dict()],
            "total": 1,
            "project_id": 42,
        }
        result = await self.mgr.list(42, status="running")
        assert result.total == 1
        assert result.sessions[0].session_id == "prev_abc123"

    @pytest.mark.asyncio
    async def test_stop(self) -> None:
        self.mock_client._make_request.return_value = {"status": "stopped"}
        result = await self.mgr.stop("prev_abc123")
        assert result["status"] == "stopped"

    @pytest.mark.asyncio
    async def test_stop_not_found(self) -> None:
        self.mock_client._make_request.side_effect = FleeksAPIError(
            "Not found", status_code=404
        )
        with pytest.raises(FleeksResourceNotFoundError):
            await self.mgr.stop("prev_ghost")

    @pytest.mark.asyncio
    async def test_refresh(self) -> None:
        self.mock_client._make_request.return_value = _session_dict(
            status="running", started_at="2026-03-10T12:00:00Z"
        )
        session = await self.mgr.refresh("prev_abc123")
        assert session.is_running is True

    @pytest.mark.asyncio
    async def test_health(self) -> None:
        self.mock_client._make_request.return_value = {
            "session_id": "prev_abc123",
            "healthy": True,
            "status_code": 200,
            "response_time_ms": 30.0,
            "checked_at": "2026-03-10T12:00:00Z",
        }
        h = await self.mgr.health("prev_abc123")
        assert h.healthy is True

    @pytest.mark.asyncio
    async def test_detect(self) -> None:
        self.mock_client._make_request.return_value = {
            "project_id": 42,
            "detected_framework": "nextjs",
            "confidence": 0.88,
            "suggested_port": 3000,
            "suggested_command": "npm run dev",
            "config_files_found": ["next.config.js"],
        }
        det = await self.mgr.detect(42)
        assert det.detected_framework == "nextjs"
        assert det.confidence == 0.88

    @pytest.mark.asyncio
    async def test_cleanup_force(self) -> None:
        """Force cleanup stops all sessions."""
        self.mock_client._make_request.side_effect = [
            # list call
            {
                "sessions": [
                    _session_dict(session_id="s1", status="running"),
                    _session_dict(session_id="s2", status="stopped"),
                ],
                "total": 2,
                "project_id": 42,
            },
            # stop s1
            {"status": "stopped"},
            # s2 is already stopped — no stop call
        ]
        result = await self.mgr.cleanup(42, force=True)
        assert result["stopped_count"] == 2
        assert "s1" in result["session_ids"]
        assert "s2" in result["session_ids"]


# ============================================================================
# SCHEDULE MODEL TESTS
# ============================================================================

class TestScheduleModels:
    def test_schedule_type_enum(self) -> None:
        assert ScheduleType.ALWAYS_ON.value == "always_on"
        assert ScheduleType.CRON.value == "cron"

    def test_daemon_status_enum(self) -> None:
        assert DaemonStatus.RUNNING.value == "running"
        assert DaemonStatus.PROVISIONING.value == "provisioning"
        assert DaemonStatus.CRASHED.value == "crashed"

    def test_project_type_agent_workspace(self) -> None:
        assert ProjectType.AGENT_WORKSPACE.value == "agent_workspace"

    def test_schedule_from_dict(self) -> None:
        data = {
            "schedule_id": "sched_abc",
            "name": "PR Bot",
            "schedule_type": "always_on",
            "status": "active",
            "agent_type": "code",
            "created_at": "2026-03-10T00:00:00Z",
            "updated_at": "2026-03-10T00:00:00Z",
            "project_id": 42,
            "tags": ["ci"],
        }
        sched = Schedule.from_dict(data)
        assert sched.schedule_id == "sched_abc"
        assert sched.project_id == 42
        assert sched.tags == ["ci"]

    def test_schedule_list_from_dict(self) -> None:
        data = {
            "schedules": [
                {
                    "schedule_id": "s1",
                    "name": "A",
                    "created_at": "2026-01-01T00:00:00Z",
                }
            ],
            "total": 1,
            "limit": 50,
            "offset": 0,
        }
        lst = ScheduleList.from_dict(data)
        assert lst.total == 1
        assert lst.schedules[0].name == "A"

    def test_schedule_start_result(self) -> None:
        data = {
            "schedule_id": "sched_abc",
            "daemon_id": "daemon_xyz",
            "status": "provisioning",
            "message": "Provisioning workspace",
            "project_id": 42,
            "workspace_url": "https://ws.fleeks.dev/42",
        }
        result = ScheduleStartResult.from_dict(data)
        assert result.project_id == 42
        assert result.workspace_url is not None

    def test_daemon_status_info_new_fields(self) -> None:
        """project_id and user_id — backend 2026-03-10 update."""
        data = {
            "schedule_id": "sched_abc",
            "daemon_id": "d_1",
            "status": "running",
            "uptime_seconds": 3661,
            "cpu_percent": 12.5,
            "memory_mb": 512.0,
            "restart_count": 0,
            "project_id": 42,
            "user_id": 7,
        }
        info = DaemonStatusInfo.from_dict(data)
        assert info.project_id == 42
        assert info.user_id == 7
        assert info.is_running is True
        assert info.uptime_display == "1h 1m 1s"

    def test_daemon_logs(self) -> None:
        data = {
            "schedule_id": "s",
            "daemon_id": "d",
            "lines": ["line1", "line2"],
            "total_lines": 2,
        }
        logs = DaemonLogs.from_dict(data)
        assert len(logs.lines) == 2

    def test_quota_usage(self) -> None:
        data = {
            "agent_hours": {"used": 80.0, "limit": 100.0},
            "schedules": {"current": 3, "max_allowed": 10},
            "concurrent_daemons": {"current": 1, "max_allowed": 5},
            "billing_period_start": "2026-03-01",
            "billing_period_end": "2026-03-31",
            "tier": "pro",
        }
        q = QuotaUsage.from_dict(data)
        assert q.is_warning is True
        assert q.is_exceeded is False
        assert q.agent_hours.remaining == 20.0
        assert q.agent_hours.percent_used == 80.0


# ============================================================================
# SUB-AGENT MODEL TESTS
# ============================================================================

class TestSubAgentModels:
    def test_sub_agent_usage(self) -> None:
        data = {"input_tokens": 100, "output_tokens": 200, "total_tokens": 300, "model": "claude-sonnet-4-20250514"}
        usage = SubAgentUsage.from_dict(data)
        assert usage.total_tokens == 300

    def test_sub_agent_result(self) -> None:
        data = {
            "sub_agent_id": "sa_1",
            "parent_agent_id": "a_parent",
            "status": "completed",
            "result": "Done",
            "usage": {"input_tokens": 10, "output_tokens": 20, "total_tokens": 30},
            "execution_time_ms": 1234.5,
        }
        result = SubAgentResult.from_dict(data)
        assert result.sub_agent_id == "sa_1"
        assert result.usage.total_tokens == 30


# ============================================================================
# CHANNEL MODEL TESTS
# ============================================================================

class TestChannelModels:
    def test_channel_type_enum(self) -> None:
        assert ChannelType.SLACK.value == "slack"
        assert ChannelType.DISCORD.value == "discord"

    def test_channel_from_dict(self) -> None:
        data = {
            "channel_id": "ch_1",
            "schedule_id": "sched_abc",
            "channel_type": "slack",
            "name": "general",
            "status": "active",
            "created_at": "2026-03-10T00:00:00Z",
        }
        ch = Channel.from_dict(data)
        assert ch.channel_id == "ch_1"

    def test_channel_list(self) -> None:
        data = {
            "channels": [
                {
                    "channel_id": "ch_1",
                    "schedule_id": "s",
                    "channel_type": "slack",
                    "created_at": "2026-03-10T00:00:00Z",
                }
            ],
            "total": 1,
        }
        lst = ChannelList.from_dict(data)
        assert lst.total == 1

    def test_auth_flow_result(self) -> None:
        data = {"channel_id": "ch_1", "auth_url": "https://oauth.slack.com/..."}
        r = AuthFlowResult.from_dict(data)
        assert r.auth_url.startswith("https://")


# ============================================================================
# AUTOMATION MODEL TESTS
# ============================================================================

class TestAutomationModels:
    def test_trigger_type_enum(self) -> None:
        assert TriggerType.GITHUB_PR.value == "github_pr"
        assert TriggerType.WEBHOOK.value == "webhook"

    def test_automation_from_dict(self) -> None:
        data = {
            "automation_id": "auto_1",
            "schedule_id": "sched_abc",
            "name": "PR Review",
            "trigger_type": "github_pr",
            "status": "active",
            "created_at": "2026-03-10T00:00:00Z",
        }
        auto = Automation.from_dict(data)
        assert auto.automation_id == "auto_1"
        assert auto.trigger_type == "github_pr"

    def test_automation_list(self) -> None:
        data = {
            "automations": [
                {
                    "automation_id": "a1",
                    "schedule_id": "s",
                    "name": "x",
                    "created_at": "2026-03-10T00:00:00Z",
                }
            ],
            "total": 1,
        }
        lst = AutomationList.from_dict(data)
        assert lst.total == 1

    def test_automation_test_result(self) -> None:
        data = {
            "automation_id": "a1",
            "success": True,
            "trigger_type": "webhook",
            "message": "OK",
            "agent_id": "agent_1",
        }
        r = AutomationTestResult.from_dict(data)
        assert r.success is True
        assert r.agent_id == "agent_1"


# ============================================================================
# LIFECYCLE PRESET TESTS
# ============================================================================

class TestLifecyclePresets:
    def test_agent_workspace_preset(self) -> None:
        config = LifecycleConfig.agent_workspace()
        assert config.idle_timeout_minutes == 240
        assert config.idle_action == IdleAction.KEEP_ALIVE
        assert config.max_duration_hours is None
        assert config.auto_wake is True
        assert config.keep_alive_on_preview is True
        assert config.heartbeat_interval_seconds == 120

    def test_agent_workspace_to_dict(self) -> None:
        d = LifecycleConfig.agent_workspace().to_dict()
        assert d["idle_action"] == "keep_alive"
        assert d["idle_timeout_minutes"] == 240


# ============================================================================
# VERSION TEST UPDATE
# ============================================================================

class TestVersion:
    def test_version(self) -> None:
        import fleeks_sdk
        assert fleeks_sdk.__version__ == "0.5.0"
