# dataloader.py

import torch
import struct
from pathlib import Path
from torch.utils.data import Dataset, DataLoader, IterableDataset
from .c_tokenizers import BaseTokenizer
from .colors import C, _section, _info, _ok, _bar


# ─── config ───────────────────────────────────────────────────────────────────

class DataConfig:
    def __init__(
        self,
        seq_len:     int   = 512,
        batch_size:  int   = 16,
        shuffle:     bool  = True,
        num_workers: int   = 0,
        split:       float = 0.9,
        streaming:   bool  = False,
    ):
        self.seq_len     = seq_len
        self.batch_size  = batch_size
        self.shuffle     = shuffle
        self.num_workers = num_workers
        self.split       = split
        self.streaming   = streaming


# ─── dataset ──────────────────────────────────────────────────────────────────

class TokenDataset(Dataset):
    def __init__(self, tokens: torch.Tensor, seq_len: int):
        self.tokens  = tokens
        self.seq_len = seq_len

    def __len__(self):
        # last valid idx needs tokens[idx+seq_len] to exist for y,
        # so max idx = len - seq_len - 1, giving len - seq_len - 1 samples
        return max(0, len(self.tokens) - self.seq_len - 1)

    def __getitem__(self, idx):
        x = self.tokens[idx:     idx + self.seq_len]
        y = self.tokens[idx + 1: idx + self.seq_len + 1]
        return x, y


class StreamingDataset(IterableDataset):
    def __init__(self, paths: list[str], tokenizer: BaseTokenizer, seq_len: int):
        self.paths     = paths
        self.tokenizer = tokenizer
        self.seq_len   = seq_len

    def __iter__(self):
        buf = []
        for path in self.paths:
            with open(path, encoding="utf-8", errors="replace") as f:
                for line in f:
                    buf.extend(self.tokenizer.encode(line))
                    while len(buf) >= self.seq_len + 1:
                        chunk = buf[:self.seq_len + 1]
                        buf   = buf[self.seq_len + 1:]
                        yield (
                            torch.tensor(chunk[:-1], dtype=torch.long),
                            torch.tensor(chunk[1:],  dtype=torch.long),
                        )


# ─── tokenize + split ─────────────────────────────────────────────────────────

def _tokenize(texts: list[str], tokenizer: BaseTokenizer) -> torch.Tensor:
    ids = []
    for i, text in enumerate(texts):
        print(f"\r  {C.DIM}tokenizing{C.RESET}  {_bar(i+1, len(texts))}  {C.DIM}{i+1}/{len(texts)}{C.RESET}", end="", flush=True)
        ids.extend(tokenizer.encode(text))
    print()
    return torch.tensor(ids, dtype=torch.long)


def _split(tokens: torch.Tensor, cfg: DataConfig) -> tuple[TokenDataset, TokenDataset]:
    n        = len(tokens)
    split_at = int(n * cfg.split)
    train_ds = TokenDataset(tokens[:split_at], cfg.seq_len)
    val_ds   = TokenDataset(tokens[split_at:], cfg.seq_len)

    if len(val_ds) == 0:
        print(f"  {C.YELLOW}⚠  val set empty — using last 10% of train{C.RESET}")
        split_at = int(split_at * 0.9)
        train_ds = TokenDataset(tokens[:split_at], cfg.seq_len)
        val_ds   = TokenDataset(tokens[split_at:], cfg.seq_len)

    return train_ds, val_ds


def _loaders(train_ds, val_ds, cfg, shuffle=None) -> tuple[DataLoader, DataLoader]:
    s = cfg.shuffle if shuffle is None else shuffle
    train_dl = DataLoader(train_ds, batch_size=cfg.batch_size, shuffle=s,     num_workers=cfg.num_workers)
    val_dl   = DataLoader(val_ds,   batch_size=cfg.batch_size, shuffle=False,  num_workers=cfg.num_workers)
    print(f"  {C.DIM}train{C.RESET}  {C.WHITE}{len(train_ds):>10,}{C.RESET} samples  {C.DIM}│{C.RESET}  {C.YELLOW}{len(train_dl):,}{C.RESET} batches")
    print(f"  {C.DIM}val  {C.RESET}  {C.WHITE}{len(val_ds):>10,}{C.RESET} samples  {C.DIM}│{C.RESET}  {C.YELLOW}{len(val_dl):,}{C.RESET} batches\n")
    return train_dl, val_dl


# ─── binary ───────────────────────────────────────────────────────────────────

def save_binary(tokens: list[int], path: str):
    # FIX: assert token IDs fit in uint16 — vocabs over 65535 silently corrupt
    max_id = max(tokens) if tokens else 0
    assert max_id < 65536, (
        f"Token ID {max_id} exceeds uint16 range (65535). "
        "Use a smaller vocabulary or switch to int32 storage."
    )
    Path(path).write_bytes(struct.pack(f"{len(tokens)}H", *tokens))
    print(f"  {C.GREEN}✓{C.RESET}  saved {C.CYAN}{len(tokens):,}{C.RESET} tokens → {C.DIM}{path}{C.RESET}")


def load_binary(path: str) -> torch.Tensor:
    raw = Path(path).read_bytes()
    ids = struct.unpack(f"{len(raw)//2}H", raw)
    tok = torch.tensor(ids, dtype=torch.long)
    print(f"  {C.GREEN}✓{C.RESET}  loaded {C.CYAN}{len(tok):,}{C.RESET} tokens ← {C.DIM}{path}{C.RESET}")
    return tok


# ─── public API ───────────────────────────────────────────────────────────────

def from_binary(path: str, cfg: DataConfig) -> tuple[DataLoader, DataLoader]:
    _section("💾 Binary dataset")
    _info("path", path)
    tokens           = load_binary(path)
    train_ds, val_ds = _split(tokens, cfg)
    return _loaders(train_ds, val_ds, cfg)


def from_files(paths: list[str], tokenizer: BaseTokenizer, cfg: DataConfig) -> tuple[DataLoader, DataLoader]:
    _section("📂 File dataset")
    for p in paths: _info("file", p)

    if cfg.streaming:
        _info("mode", "streaming")
        split_at = max(1, int(len(paths) * cfg.split))
        train_paths = paths[:split_at]
        val_paths   = paths[split_at:]

        # FIX: when only 1 file exists, warn clearly instead of silently
        # using the training file as validation data
        if not val_paths:
            print(f"  {C.YELLOW}⚠  only {len(paths)} file(s) — val set will overlap with train. "
                  f"Provide more files or use in-memory mode for a proper split.{C.RESET}")
            val_paths = train_paths[-1:]

        train_ds = StreamingDataset(train_paths, tokenizer, cfg.seq_len)
        val_ds   = StreamingDataset(val_paths,   tokenizer, cfg.seq_len)
        return _loaders(train_ds, val_ds, cfg, shuffle=False)

    _info("mode", "in-memory")
    texts            = [Path(p).read_text(encoding="utf-8", errors="replace") for p in paths]
    tokens           = _tokenize(texts, tokenizer)
    train_ds, val_ds = _split(tokens, cfg)
    return _loaders(train_ds, val_ds, cfg)


def from_hf(dataset_name: str, tokenizer: BaseTokenizer, cfg: DataConfig,
            split: str = "train", text_col: str = "text") -> tuple[DataLoader, DataLoader]:
    _section("🤗 HuggingFace dataset")
    _info("dataset", dataset_name)
    _info("split", split)
    _info("streaming", str(cfg.streaming))

    from datasets import load_dataset
    ds = load_dataset(dataset_name, split=split, streaming=cfg.streaming)

    if cfg.streaming:
        def _make_gen(source_ds):
            def _gen():
                buf = []
                for row in source_ds:
                    buf.extend(tokenizer.encode(row[text_col]))
                    while len(buf) >= cfg.seq_len + 1:
                        chunk = buf[:cfg.seq_len + 1]
                        buf   = buf[cfg.seq_len + 1:]
                        yield (
                            torch.tensor(chunk[:-1], dtype=torch.long),
                            torch.tensor(chunk[1:],  dtype=torch.long),
                        )
            return _gen

        class _HFStream(IterableDataset):
            def __init__(self, gen_fn): self._gen_fn = gen_fn
            def __iter__(self): return self._gen_fn()

        # FIX: two independent load_dataset calls so train and val have
        # separate underlying iterators — sharing one iterator caused val
        # to consume the first N rows and train to start from row N+1.
        val_n        = max(1, int(cfg.batch_size * 20))
        train_ds_raw = load_dataset(dataset_name, split=split, streaming=True)
        val_ds_raw   = load_dataset(dataset_name, split=split, streaming=True)
        print(f"  {C.YELLOW}⚠  HF streaming: val shard = first {val_n} rows. "
              f"Use in-memory mode for an exact split.{C.RESET}")
        train_ds = _HFStream(_make_gen(train_ds_raw.skip(val_n)))
        val_ds   = _HFStream(_make_gen(val_ds_raw.take(val_n)))

        train_dl = DataLoader(train_ds, batch_size=cfg.batch_size, num_workers=cfg.num_workers)
        val_dl   = DataLoader(val_ds,   batch_size=cfg.batch_size, num_workers=cfg.num_workers)
        _ok("streaming dataloaders ready")
        return train_dl, val_dl

    print(f"  {C.YELLOW}⏳ downloading...{C.RESET}", flush=True)
    texts            = [row[text_col] for row in ds]
    _ok(f"downloaded {len(texts):,} documents")
    tokens           = _tokenize(texts, tokenizer)
    train_ds, val_ds = _split(tokens, cfg)
    return _loaders(train_ds, val_ds, cfg)


def from_strings(texts: list[str], tokenizer: BaseTokenizer, cfg: DataConfig) -> tuple[DataLoader, DataLoader]:
    _section("📝 String dataset")
    _info("documents", str(len(texts)))
    tokens           = _tokenize(texts, tokenizer)
    train_ds, val_ds = _split(tokens, cfg)
    return _loaders(train_ds, val_ds, cfg)
