# model.py

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Literal

from .attention            import MultiHeadAttention, GroupedQueryAttention, \
                                  MultiQueryAttention, FlashAttention, MLAttention
from .feed_forward         import FFN, SwiGLU, MoE
from .normalization        import LayerNorm, RMSNorm
from .positional_encodings import SinusoidalPE, LearnedPE, RoPE, ALiBi
from .block                import TransformerBlock


# ─── config ───────────────────────────────────────────────────────────────────

@dataclass
class TransformerConfig:
    # core
    vocab_size: int   = 32000
    dim:        int   = 512
    n_layers:   int   = 8
    n_heads:    int   = 8
    max_seq:    int   = 2048

    # attention
    attn:       Literal["mha", "gqa", "mqa", "flash", "mla"] = "gqa"
    n_kv_heads: int   = 4        # gqa only
    latent_dim: int   = 64       # mla only

    # ffn
    ffn:        Literal["ffn", "swiglu", "moe"] = "swiglu"
    hidden_dim: int   = None     # defaults to dim * 4
    n_experts:  int   = 8        # moe only
    top_k:      int   = 2        # moe only
    moe_aux_weight: float = 0.01

    # normalization
    norm:       Literal["rmsnorm", "layernorm"] = "rmsnorm"
    eps:        float = 1e-6

    # positional encoding
    pos_enc:    Literal["rope", "sinusoidal", "learned", "alibi", "none"] = "rope"

    # regularisation
    dropout:    float = 0.0

    # output
    tie_weights: bool = True

    def __post_init__(self):
        if self.hidden_dim is None:
            self.hidden_dim = self.dim * 4

    @property
    def head_dim(self) -> int:
        return self.dim // self.n_heads


# ─── registry ─────────────────────────────────────────────────────────────────

def _build_norm(cfg: TransformerConfig) -> nn.Module:
    match cfg.norm:
        case "rmsnorm":   return RMSNorm(cfg.dim, cfg.eps)
        case "layernorm": return LayerNorm(cfg.dim, cfg.eps)
        case _:           raise ValueError(f"unknown norm: {cfg.norm!r}")


def _build_ffn(cfg: TransformerConfig) -> nn.Module:
    match cfg.ffn:
        case "ffn":    return FFN(cfg.dim, cfg.hidden_dim)
        case "swiglu": return SwiGLU(cfg.dim, cfg.hidden_dim)
        case "moe":    return MoE(cfg.dim, cfg.hidden_dim, cfg.n_experts,
                                   cfg.top_k, cfg.moe_aux_weight)
        case _:        raise ValueError(f"unknown ffn: {cfg.ffn!r}")


def _build_attn(cfg: TransformerConfig, pos_enc) -> nn.Module:
    """
    pos_enc is passed in so each attention module can call rope.rotate(q, k)
    when pos_enc="rope", or ignore it for stream-based / ALiBi encodings.
    Only RoPE instances are meaningful here; all others are passed as None.
    """
    rope = pos_enc if isinstance(pos_enc, RoPE) else None
    match cfg.attn:
        case "mha":   return MultiHeadAttention(cfg.dim, cfg.n_heads, rope)
        case "gqa":   return GroupedQueryAttention(cfg.dim, cfg.n_heads,
                                                    cfg.n_kv_heads, rope)
        case "mqa":   return MultiQueryAttention(cfg.dim, cfg.n_heads, rope)
        case "flash": return FlashAttention(cfg.dim, cfg.n_heads, rope)
        case "mla":   return MLAttention(cfg.dim, cfg.n_heads,
                                          cfg.latent_dim, rope)
        case _:       raise ValueError(f"unknown attn: {cfg.attn!r}")


def _build_pos_enc(cfg: TransformerConfig):
    """
    Stream encodings  (SinusoidalPE, LearnedPE) — applied to x before blocks.
    Attention encodings (RoPE, ALiBi)            — applied inside attention.
    Returns None when pos_enc="none".
    """
    match cfg.pos_enc:
        case "rope":       return RoPE(cfg.head_dim, cfg.max_seq)
        case "sinusoidal": return SinusoidalPE(cfg.dim, cfg.max_seq)
        case "learned":    return LearnedPE(cfg.dim, cfg.max_seq)
        case "alibi":      return ALiBi(cfg.n_heads)
        case "none":       return None
        case _:            raise ValueError(f"unknown pos_enc: {cfg.pos_enc!r}")


# ─── model ────────────────────────────────────────────────────────────────────

class Transformer(nn.Module):
    def __init__(self, cfg: TransformerConfig):
        super().__init__()
        self.cfg      = cfg
        self.embed    = nn.Embedding(cfg.vocab_size, cfg.dim)
        self.emb_drop = nn.Dropout(cfg.dropout)

        # build positional encoding once — shared reference passed into attention
        self.pos_enc  = _build_pos_enc(cfg)

        self.blocks = nn.ModuleList([
            TransformerBlock(
                dim     = cfg.dim,
                n_heads = cfg.n_heads,
                hidden  = cfg.hidden_dim,
                norm    = _build_norm(cfg),
                attn    = _build_attn(cfg, self.pos_enc),
                ffn     = _build_ffn(cfg),
                dropout = cfg.dropout,
            )
            for _ in range(cfg.n_layers)
        ])
        self.norm = _build_norm(cfg)
        self.head = nn.Linear(cfg.dim, cfg.vocab_size, bias=False)

        if cfg.tie_weights:
            self.head.weight = self.embed.weight

    def forward(self, tokens: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Returns (logits, aux_loss).
        aux_loss is non-zero only for MoE FFN — add it to your training loss:
            loss = ce_loss + aux_loss
        For non-MoE models aux_loss is 0.0 and has no effect.
        """
        x = self.emb_drop(self.embed(tokens))

        # stream encodings: modify x once before all blocks
        if isinstance(self.pos_enc, (SinusoidalPE, LearnedPE)):
            x = self.pos_enc(x)

        # ALiBi: compute the additive bias once and pass as mask to every block
        # RoPE: applied inside each attention module via rope.rotate(q, k) — no x change
        # none: nothing to do
        mask = None
        if isinstance(self.pos_enc, ALiBi):
            mask = self.pos_enc.get_bias(tokens.shape[1], tokens.device)

        aux_loss = torch.tensor(0.0, device=tokens.device)
        for block in self.blocks:
            x, block_aux = block(x, mask=mask)
            aux_loss = aux_loss + block_aux

        return self.head(self.norm(x)), aux_loss

    @torch.no_grad()
    def generate(
        self,
        tokens:      torch.Tensor,
        max_new:     int   = 10,
        temperature: float = 1.0,
        top_k:       int   = 50,
    ) -> torch.Tensor:
        """
        Auto-regressive generation with top-k sampling.
        top_k=1  → greedy decoding.
        top_k=0  → full-vocab softmax (not recommended).
        """
        for _ in range(max_new):
            context     = tokens[:, -self.cfg.max_seq:]
            logits, _   = self.forward(context)
            logits      = logits[:, -1, :] / max(temperature, 1e-8)
            if top_k > 0:
                k      = min(top_k, logits.size(-1))
                thresh = logits.topk(k, dim=-1).values[:, -1, None]
                logits = logits.masked_fill(logits < thresh, float('-inf'))
            probs  = F.softmax(logits, dim=-1)
            tokens = torch.cat([tokens, torch.multinomial(probs, 1)], dim=-1)
        return tokens

    def n_params(self) -> str:
        n = sum(p.numel() for p in self.parameters())
        return f"{n/1e6:.2f}M" if n < 1e9 else f"{n/1e9:.2f}B"

    def state_dict_for_save(self) -> dict:
        """
        Use instead of state_dict() when tie_weights=True.
        Removes head.weight so load re-applies the tie instead of
        breaking it into two independent tensors.
        """
        sd = self.state_dict()
        if self.cfg.tie_weights:
            sd.pop("head.weight", None)
        return sd

    def load_state_dict_with_tie(self, sd: dict, strict: bool = True):
        """Companion to state_dict_for_save(). Re-applies weight tying after load."""
        missing, unexpected = super().load_state_dict(sd, strict=False)
        expected_missing    = ["head.weight"] if self.cfg.tie_weights else []
        real_missing        = [k for k in missing if k not in expected_missing]
        if strict and (real_missing or unexpected):
            raise RuntimeError(
                f"Missing keys: {real_missing}  Unexpected keys: {unexpected}"
            )
        if self.cfg.tie_weights:
            self.head.weight = self.embed.weight
