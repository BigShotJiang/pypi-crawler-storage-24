"""Integration tests for Markitai."""
