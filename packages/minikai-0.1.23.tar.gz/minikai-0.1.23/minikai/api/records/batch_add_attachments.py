from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.batch_add_attachments_body import BatchAddAttachmentsBody
from ...models.batch_attachment_result import BatchAttachmentResult
from ...models.http_validation_problem_details import HttpValidationProblemDetails
from typing import cast



def _get_kwargs(
    *,
    body: BatchAddAttachmentsBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Records/batch/attachments",
    }

    _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    if response.status_code == 202:
        response_202 = BatchAttachmentResult.from_dict(response.json())



        return response_202

    if response.status_code == 400:
        response_400 = HttpValidationProblemDetails.from_dict(response.json())



        return response_400

    if response.status_code == 422:
        response_422 = BatchAttachmentResult.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BatchAddAttachmentsBody,

) -> Response[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    """ 
    Args:
        body (BatchAddAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[BatchAttachmentResult, HttpValidationProblemDetails]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BatchAddAttachmentsBody,

) -> Optional[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    """ 
    Args:
        body (BatchAddAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[BatchAttachmentResult, HttpValidationProblemDetails]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BatchAddAttachmentsBody,

) -> Response[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    """ 
    Args:
        body (BatchAddAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[BatchAttachmentResult, HttpValidationProblemDetails]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BatchAddAttachmentsBody,

) -> Optional[Union[BatchAttachmentResult, HttpValidationProblemDetails]]:
    """ 
    Args:
        body (BatchAddAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[BatchAttachmentResult, HttpValidationProblemDetails]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
