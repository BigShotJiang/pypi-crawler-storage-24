from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.cursor_paginated_list_of_record_dto import CursorPaginatedListOfRecordDto
from ...models.record_state import check_record_state
from ...models.record_state import RecordState
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from typing import Union
from uuid import UUID
import datetime



def _get_kwargs(
    *,
    mini_id: str,
    record_ids: Union[Unset, list[UUID]] = UNSET,
    external_uris: Union[Unset, list[str]] = UNSET,
    session_id: Union[Unset, UUID] = UNSET,
    record_id: Union[Unset, UUID] = UNSET,
    before_cursor: Union[Unset, UUID] = UNSET,
    after_cursor: Union[Unset, UUID] = UNSET,
    limit_before: Union[Unset, Any] = UNSET,
    limit_after: Union[Unset, Any] = UNSET,
    labels: Union[Unset, list[str]] = UNSET,
    states: Union[Unset, list[RecordState]] = UNSET,
    start_date: Union[Unset, datetime.datetime] = UNSET,
    end_date: Union[Unset, datetime.datetime] = UNSET,
    created_by: Union[Unset, list[str]] = UNSET,
    updated_by: Union[Unset, list[str]] = UNSET,
    sort_descending: Union[Unset, bool] = True,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["miniId"] = mini_id

    json_record_ids: Union[Unset, list[str]] = UNSET
    if not isinstance(record_ids, Unset):
        json_record_ids = []
        for record_ids_item_data in record_ids:
            record_ids_item = str(record_ids_item_data)
            json_record_ids.append(record_ids_item)


    params["recordIds"] = json_record_ids

    json_external_uris: Union[Unset, list[str]] = UNSET
    if not isinstance(external_uris, Unset):
        json_external_uris = external_uris


    params["externalUris"] = json_external_uris

    json_session_id: Union[Unset, str] = UNSET
    if not isinstance(session_id, Unset):
        json_session_id = str(session_id)
    params["sessionId"] = json_session_id

    json_record_id: Union[Unset, str] = UNSET
    if not isinstance(record_id, Unset):
        json_record_id = str(record_id)
    params["recordId"] = json_record_id

    json_before_cursor: Union[Unset, str] = UNSET
    if not isinstance(before_cursor, Unset):
        json_before_cursor = str(before_cursor)
    params["beforeCursor"] = json_before_cursor

    json_after_cursor: Union[Unset, str] = UNSET
    if not isinstance(after_cursor, Unset):
        json_after_cursor = str(after_cursor)
    params["afterCursor"] = json_after_cursor

    params["limitBefore"] = limit_before

    params["limitAfter"] = limit_after

    json_labels: Union[Unset, list[str]] = UNSET
    if not isinstance(labels, Unset):
        json_labels = labels


    params["labels"] = json_labels

    json_states: Union[Unset, list[str]] = UNSET
    if not isinstance(states, Unset):
        json_states = []
        for states_item_data in states:
            states_item: str = states_item_data
            json_states.append(states_item)


    params["states"] = json_states

    json_start_date: Union[Unset, str] = UNSET
    if not isinstance(start_date, Unset):
        json_start_date = start_date.isoformat()
    params["startDate"] = json_start_date

    json_end_date: Union[Unset, str] = UNSET
    if not isinstance(end_date, Unset):
        json_end_date = end_date.isoformat()
    params["endDate"] = json_end_date

    json_created_by: Union[Unset, list[str]] = UNSET
    if not isinstance(created_by, Unset):
        json_created_by = created_by


    params["createdBy"] = json_created_by

    json_updated_by: Union[Unset, list[str]] = UNSET
    if not isinstance(updated_by, Unset):
        json_updated_by = updated_by


    params["updatedBy"] = json_updated_by

    params["sortDescending"] = sort_descending


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/Records",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[CursorPaginatedListOfRecordDto]:
    if response.status_code == 200:
        response_200 = CursorPaginatedListOfRecordDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[CursorPaginatedListOfRecordDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    record_ids: Union[Unset, list[UUID]] = UNSET,
    external_uris: Union[Unset, list[str]] = UNSET,
    session_id: Union[Unset, UUID] = UNSET,
    record_id: Union[Unset, UUID] = UNSET,
    before_cursor: Union[Unset, UUID] = UNSET,
    after_cursor: Union[Unset, UUID] = UNSET,
    limit_before: Union[Unset, Any] = UNSET,
    limit_after: Union[Unset, Any] = UNSET,
    labels: Union[Unset, list[str]] = UNSET,
    states: Union[Unset, list[RecordState]] = UNSET,
    start_date: Union[Unset, datetime.datetime] = UNSET,
    end_date: Union[Unset, datetime.datetime] = UNSET,
    created_by: Union[Unset, list[str]] = UNSET,
    updated_by: Union[Unset, list[str]] = UNSET,
    sort_descending: Union[Unset, bool] = True,

) -> Response[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (Union[Unset, list[UUID]]):
        external_uris (Union[Unset, list[str]]):
        session_id (Union[Unset, UUID]):
        record_id (Union[Unset, UUID]):
        before_cursor (Union[Unset, UUID]):
        after_cursor (Union[Unset, UUID]):
        limit_before (Union[Unset, Any]):
        limit_after (Union[Unset, Any]):
        labels (Union[Unset, list[str]]):
        states (Union[Unset, list[RecordState]]):
        start_date (Union[Unset, datetime.datetime]):
        end_date (Union[Unset, datetime.datetime]):
        created_by (Union[Unset, list[str]]):
        updated_by (Union[Unset, list[str]]):
        sort_descending (Union[Unset, bool]):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordDto]
     """


    kwargs = _get_kwargs(
        mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    record_ids: Union[Unset, list[UUID]] = UNSET,
    external_uris: Union[Unset, list[str]] = UNSET,
    session_id: Union[Unset, UUID] = UNSET,
    record_id: Union[Unset, UUID] = UNSET,
    before_cursor: Union[Unset, UUID] = UNSET,
    after_cursor: Union[Unset, UUID] = UNSET,
    limit_before: Union[Unset, Any] = UNSET,
    limit_after: Union[Unset, Any] = UNSET,
    labels: Union[Unset, list[str]] = UNSET,
    states: Union[Unset, list[RecordState]] = UNSET,
    start_date: Union[Unset, datetime.datetime] = UNSET,
    end_date: Union[Unset, datetime.datetime] = UNSET,
    created_by: Union[Unset, list[str]] = UNSET,
    updated_by: Union[Unset, list[str]] = UNSET,
    sort_descending: Union[Unset, bool] = True,

) -> Optional[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (Union[Unset, list[UUID]]):
        external_uris (Union[Unset, list[str]]):
        session_id (Union[Unset, UUID]):
        record_id (Union[Unset, UUID]):
        before_cursor (Union[Unset, UUID]):
        after_cursor (Union[Unset, UUID]):
        limit_before (Union[Unset, Any]):
        limit_after (Union[Unset, Any]):
        labels (Union[Unset, list[str]]):
        states (Union[Unset, list[RecordState]]):
        start_date (Union[Unset, datetime.datetime]):
        end_date (Union[Unset, datetime.datetime]):
        created_by (Union[Unset, list[str]]):
        updated_by (Union[Unset, list[str]]):
        sort_descending (Union[Unset, bool]):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordDto
     """


    return sync_detailed(
        client=client,
mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    record_ids: Union[Unset, list[UUID]] = UNSET,
    external_uris: Union[Unset, list[str]] = UNSET,
    session_id: Union[Unset, UUID] = UNSET,
    record_id: Union[Unset, UUID] = UNSET,
    before_cursor: Union[Unset, UUID] = UNSET,
    after_cursor: Union[Unset, UUID] = UNSET,
    limit_before: Union[Unset, Any] = UNSET,
    limit_after: Union[Unset, Any] = UNSET,
    labels: Union[Unset, list[str]] = UNSET,
    states: Union[Unset, list[RecordState]] = UNSET,
    start_date: Union[Unset, datetime.datetime] = UNSET,
    end_date: Union[Unset, datetime.datetime] = UNSET,
    created_by: Union[Unset, list[str]] = UNSET,
    updated_by: Union[Unset, list[str]] = UNSET,
    sort_descending: Union[Unset, bool] = True,

) -> Response[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (Union[Unset, list[UUID]]):
        external_uris (Union[Unset, list[str]]):
        session_id (Union[Unset, UUID]):
        record_id (Union[Unset, UUID]):
        before_cursor (Union[Unset, UUID]):
        after_cursor (Union[Unset, UUID]):
        limit_before (Union[Unset, Any]):
        limit_after (Union[Unset, Any]):
        labels (Union[Unset, list[str]]):
        states (Union[Unset, list[RecordState]]):
        start_date (Union[Unset, datetime.datetime]):
        end_date (Union[Unset, datetime.datetime]):
        created_by (Union[Unset, list[str]]):
        updated_by (Union[Unset, list[str]]):
        sort_descending (Union[Unset, bool]):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordDto]
     """


    kwargs = _get_kwargs(
        mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    record_ids: Union[Unset, list[UUID]] = UNSET,
    external_uris: Union[Unset, list[str]] = UNSET,
    session_id: Union[Unset, UUID] = UNSET,
    record_id: Union[Unset, UUID] = UNSET,
    before_cursor: Union[Unset, UUID] = UNSET,
    after_cursor: Union[Unset, UUID] = UNSET,
    limit_before: Union[Unset, Any] = UNSET,
    limit_after: Union[Unset, Any] = UNSET,
    labels: Union[Unset, list[str]] = UNSET,
    states: Union[Unset, list[RecordState]] = UNSET,
    start_date: Union[Unset, datetime.datetime] = UNSET,
    end_date: Union[Unset, datetime.datetime] = UNSET,
    created_by: Union[Unset, list[str]] = UNSET,
    updated_by: Union[Unset, list[str]] = UNSET,
    sort_descending: Union[Unset, bool] = True,

) -> Optional[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (Union[Unset, list[UUID]]):
        external_uris (Union[Unset, list[str]]):
        session_id (Union[Unset, UUID]):
        record_id (Union[Unset, UUID]):
        before_cursor (Union[Unset, UUID]):
        after_cursor (Union[Unset, UUID]):
        limit_before (Union[Unset, Any]):
        limit_after (Union[Unset, Any]):
        labels (Union[Unset, list[str]]):
        states (Union[Unset, list[RecordState]]):
        start_date (Union[Unset, datetime.datetime]):
        end_date (Union[Unset, datetime.datetime]):
        created_by (Union[Unset, list[str]]):
        updated_by (Union[Unset, list[str]]):
        sort_descending (Union[Unset, bool]):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordDto
     """


    return (await asyncio_detailed(
        client=client,
mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )).parsed
