from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.cursor_paginated_list_of_record_version_dto import CursorPaginatedListOfRecordVersionDto
from ...types import UNSET, Unset
from typing import cast
from typing import Union
from uuid import UUID



def _get_kwargs(
    record_id: UUID,
    *,
    mini_id: str,
    limit: Union[Unset, Any] = 20,
    after_cursor: Union[Unset, str] = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["miniId"] = mini_id

    params["limit"] = limit

    params["afterCursor"] = after_cursor


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/Records/{record_id}/versions".format(record_id=record_id,),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[CursorPaginatedListOfRecordVersionDto]:
    if response.status_code == 200:
        response_200 = CursorPaginatedListOfRecordVersionDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[CursorPaginatedListOfRecordVersionDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    record_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    limit: Union[Unset, Any] = 20,
    after_cursor: Union[Unset, str] = UNSET,

) -> Response[CursorPaginatedListOfRecordVersionDto]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):
        limit (Union[Unset, Any]):  Default: 20.
        after_cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordVersionDto]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
mini_id=mini_id,
limit=limit,
after_cursor=after_cursor,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    record_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    limit: Union[Unset, Any] = 20,
    after_cursor: Union[Unset, str] = UNSET,

) -> Optional[CursorPaginatedListOfRecordVersionDto]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):
        limit (Union[Unset, Any]):  Default: 20.
        after_cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordVersionDto
     """


    return sync_detailed(
        record_id=record_id,
client=client,
mini_id=mini_id,
limit=limit,
after_cursor=after_cursor,

    ).parsed

async def asyncio_detailed(
    record_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    limit: Union[Unset, Any] = 20,
    after_cursor: Union[Unset, str] = UNSET,

) -> Response[CursorPaginatedListOfRecordVersionDto]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):
        limit (Union[Unset, Any]):  Default: 20.
        after_cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordVersionDto]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
mini_id=mini_id,
limit=limit,
after_cursor=after_cursor,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    record_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    mini_id: str,
    limit: Union[Unset, Any] = 20,
    after_cursor: Union[Unset, str] = UNSET,

) -> Optional[CursorPaginatedListOfRecordVersionDto]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):
        limit (Union[Unset, Any]):  Default: 20.
        after_cursor (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordVersionDto
     """


    return (await asyncio_detailed(
        record_id=record_id,
client=client,
mini_id=mini_id,
limit=limit,
after_cursor=after_cursor,

    )).parsed
