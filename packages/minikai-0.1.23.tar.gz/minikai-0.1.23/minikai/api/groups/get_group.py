from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.group_dto import GroupDto
from typing import cast
from uuid import UUID



def _get_kwargs(
    group_id: UUID,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/Groups/{group_id}".format(group_id=group_id,),
    }


    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, GroupDto]]:
    if response.status_code == 200:
        response_200 = GroupDto.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, GroupDto]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    group_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Response[Union[Any, GroupDto]]:
    """ 
    Args:
        group_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, GroupDto]]
     """


    kwargs = _get_kwargs(
        group_id=group_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    group_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Optional[Union[Any, GroupDto]]:
    """ 
    Args:
        group_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, GroupDto]
     """


    return sync_detailed(
        group_id=group_id,
client=client,

    ).parsed

async def asyncio_detailed(
    group_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Response[Union[Any, GroupDto]]:
    """ 
    Args:
        group_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, GroupDto]]
     """


    kwargs = _get_kwargs(
        group_id=group_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    group_id: UUID,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Optional[Union[Any, GroupDto]]:
    """ 
    Args:
        group_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, GroupDto]
     """


    return (await asyncio_detailed(
        group_id=group_id,
client=client,

    )).parsed
