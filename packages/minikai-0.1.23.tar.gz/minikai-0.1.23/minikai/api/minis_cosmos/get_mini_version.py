from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.mini_version_dto import MiniVersionDto
from typing import cast



def _get_kwargs(
    id: str,
    version_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/MinisCosmos/{id}/versions/{version_id}".format(id=id,version_id=version_id,),
    }


    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, MiniVersionDto]]:
    if response.status_code == 200:
        response_200 = MiniVersionDto.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, MiniVersionDto]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    version_id: str,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Response[Union[Any, MiniVersionDto]]:
    """ 
    Args:
        id (str):
        version_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, MiniVersionDto]]
     """


    kwargs = _get_kwargs(
        id=id,
version_id=version_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    version_id: str,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Optional[Union[Any, MiniVersionDto]]:
    """ 
    Args:
        id (str):
        version_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, MiniVersionDto]
     """


    return sync_detailed(
        id=id,
version_id=version_id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: str,
    version_id: str,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Response[Union[Any, MiniVersionDto]]:
    """ 
    Args:
        id (str):
        version_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, MiniVersionDto]]
     """


    kwargs = _get_kwargs(
        id=id,
version_id=version_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    version_id: str,
    *,
    client: Union[AuthenticatedClient, Client],

) -> Optional[Union[Any, MiniVersionDto]]:
    """ 
    Args:
        id (str):
        version_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, MiniVersionDto]
     """


    return (await asyncio_detailed(
        id=id,
version_id=version_id,
client=client,

    )).parsed
