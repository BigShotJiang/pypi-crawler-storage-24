from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast, Union
from typing import Union






T = TypeVar("T", bound="UserToMiniDto")



@_attrs_define
class UserToMiniDto:
    """ 
        Attributes:
            user_id (str):
            mini_name (str):
            mini_id (Union[Unset, Any]):
            mini_description (Union[None, Unset, str]):
     """

    user_id: str
    mini_name: str
    mini_id: Union[Unset, Any] = UNSET
    mini_description: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        mini_name = self.mini_name

        mini_id = self.mini_id

        mini_description: Union[None, Unset, str]
        if isinstance(self.mini_description, Unset):
            mini_description = UNSET
        else:
            mini_description = self.mini_description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "userId": user_id,
            "miniName": mini_name,
        })
        if mini_id is not UNSET:
            field_dict["miniId"] = mini_id
        if mini_description is not UNSET:
            field_dict["miniDescription"] = mini_description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId")

        mini_name = d.pop("miniName")

        mini_id = d.pop("miniId", UNSET)

        def _parse_mini_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        mini_description = _parse_mini_description(d.pop("miniDescription", UNSET))


        user_to_mini_dto = cls(
            user_id=user_id,
            mini_name=mini_name,
            mini_id=mini_id,
            mini_description=mini_description,
        )


        user_to_mini_dto.additional_properties = d
        return user_to_mini_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
