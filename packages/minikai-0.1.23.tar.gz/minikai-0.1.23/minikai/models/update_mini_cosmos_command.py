from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import cast, Union
from typing import Union






T = TypeVar("T", bound="UpdateMiniCosmosCommand")



@_attrs_define
class UpdateMiniCosmosCommand:
    """ 
        Attributes:
            id (str):
            name (str):
            profile_picture_url (Union[Unset, str]):
            profile (Union[Unset, Any]):
            external_uri (Union[Unset, str]):
            labels (Union[None, Unset, list[str]]):
            e_tag (Union[None, Unset, str]):
     """

    id: str
    name: str
    profile_picture_url: Union[Unset, str] = UNSET
    profile: Union[Unset, Any] = UNSET
    external_uri: Union[Unset, str] = UNSET
    labels: Union[None, Unset, list[str]] = UNSET
    e_tag: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        profile_picture_url = self.profile_picture_url

        profile = self.profile

        external_uri = self.external_uri

        labels: Union[None, Unset, list[str]]
        if isinstance(self.labels, Unset):
            labels = UNSET
        elif isinstance(self.labels, list):
            labels = self.labels


        else:
            labels = self.labels

        e_tag: Union[None, Unset, str]
        if isinstance(self.e_tag, Unset):
            e_tag = UNSET
        else:
            e_tag = self.e_tag


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
        })
        if profile_picture_url is not UNSET:
            field_dict["profilePictureUrl"] = profile_picture_url
        if profile is not UNSET:
            field_dict["profile"] = profile
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels
        if e_tag is not UNSET:
            field_dict["eTag"] = e_tag

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        profile_picture_url = d.pop("profilePictureUrl", UNSET)

        profile = d.pop("profile", UNSET)

        external_uri = d.pop("externalUri", UNSET)

        def _parse_labels(data: object) -> Union[None, Unset, list[str]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                labels_type_0 = cast(list[str], data)

                return labels_type_0
            except: # noqa: E722
                pass
            return cast(Union[None, Unset, list[str]], data)

        labels = _parse_labels(d.pop("labels", UNSET))


        def _parse_e_tag(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        e_tag = _parse_e_tag(d.pop("eTag", UNSET))


        update_mini_cosmos_command = cls(
            id=id,
            name=name,
            profile_picture_url=profile_picture_url,
            profile=profile,
            external_uri=external_uri,
            labels=labels,
            e_tag=e_tag,
        )


        update_mini_cosmos_command.additional_properties = d
        return update_mini_cosmos_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
