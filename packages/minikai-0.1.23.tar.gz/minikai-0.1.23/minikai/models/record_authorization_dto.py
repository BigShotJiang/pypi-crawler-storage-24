from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Union






T = TypeVar("T", bound="RecordAuthorizationDto")



@_attrs_define
class RecordAuthorizationDto:
    """ 
        Attributes:
            users (Union[Unset, list[str]]):
            minis (Union[Unset, list[str]]):
            organizations (Union[Unset, list[str]]):
            sessions (Union[Unset, list[str]]):
     """

    users: Union[Unset, list[str]] = UNSET
    minis: Union[Unset, list[str]] = UNSET
    organizations: Union[Unset, list[str]] = UNSET
    sessions: Union[Unset, list[str]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        users: Union[Unset, list[str]] = UNSET
        if not isinstance(self.users, Unset):
            users = self.users



        minis: Union[Unset, list[str]] = UNSET
        if not isinstance(self.minis, Unset):
            minis = self.minis



        organizations: Union[Unset, list[str]] = UNSET
        if not isinstance(self.organizations, Unset):
            organizations = self.organizations



        sessions: Union[Unset, list[str]] = UNSET
        if not isinstance(self.sessions, Unset):
            sessions = self.sessions




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if users is not UNSET:
            field_dict["users"] = users
        if minis is not UNSET:
            field_dict["minis"] = minis
        if organizations is not UNSET:
            field_dict["organizations"] = organizations
        if sessions is not UNSET:
            field_dict["sessions"] = sessions

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        users = cast(list[str], d.pop("users", UNSET))


        minis = cast(list[str], d.pop("minis", UNSET))


        organizations = cast(list[str], d.pop("organizations", UNSET))


        sessions = cast(list[str], d.pop("sessions", UNSET))


        record_authorization_dto = cls(
            users=users,
            minis=minis,
            organizations=organizations,
            sessions=sessions,
        )


        record_authorization_dto.additional_properties = d
        return record_authorization_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
