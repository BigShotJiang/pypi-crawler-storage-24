from typing import (
    Union, List, Dict, Tuple, Optional, Callable, Any, Literal,
)
import copy
import numpy as np 
import pandas as pd 
import lightgbm as lgb 
import xgboost as xgb 
import catboost as cb 

from sklearn.model_selection import StratifiedKFold, KFold
from sklearn.metrics import roc_auc_score, mean_squared_error
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import FunctionTransformer, OrdinalEncoder

# Type aliases 
ModelKey = Literal['lgb', 'xgb', 'cb']
PredictionType = Literal['classification', 'regression']

def cv_score_predict(
    X: pd.DataFrame,
    y: Union[pd.Series, np.ndarray],
    X_test: Optional[pd.DataFrame] = None,
    pred_type: PredictionType = None,
    unbalanced_target: bool = False,
    processor: Optional[Union[BaseEstimator, TransformerMixin]] = None,
    models: Union[List[ModelKey], ModelKey] = ('lgb', 'xgb', 'cb'),
    params_dict: Optional[Dict[str, dict]] = None,
    scoring_dict: Optional[Dict[str, Callable]] = None,
    decision_threshold: float = 0.5,
    n_splits: int = 5,
    random_state: Union[int, List[int]] = 42,
    early_stopping_rounds: int = 50,
    verbose: int = 2,
    return_trained: bool = False,
    predict_proba: bool = True,
    return_raw_test_preds: bool = False, 
    cv_splitter: Optional[Any] = None,
    cv_groups: Optional[Union[pd.Series, np.ndarray]] = None,
) -> Tuple[pd.DataFrame, Optional[pd.DataFrame], Optional[List[Tuple[Any, Any]]]]:
    """
    Cross-validate gradient boosting estimators with robust categorical handling.
    
    Automatically applies categorical preprocessing AFTER the user-provided `processor`:
      1. Detects object/string/categorical columns in processor output
      2. Applies OrdinalEncoder with explicit unseen-category handling:
         - Unseen categories → encoded as -1
         - Missing values → encoded as -1
         - Training data guaranteed to contain -1 via `encoded_missing_value=-1`
      3. Converts encoded integers to pandas 'category' dtype for native booster support
    
    This pattern ensures compatibility across all supported libraries:
      • XGBoost: Satisfies strict requirement that all test categories exist in training
      • LightGBM: Extracts integer codes from category dtype (handles -1 as missing)
      • CatBoost: Accepts integer-encoded categoricals via explicit `cat_features`
    
    Estimators are trained with early stopping on each fold's validation set. Final test
    predictions (when `X_test` is provided) are produced by the early-stopped estimators
    from each fold and averaged across folds for each (model, seed) combination.

    Parameters
    ----------
    X : pd.DataFrame
        Training features.
    y : pd.Series or np.ndarray
        Target values.
    X_test : pd.DataFrame or None, optional
        Final test set to predict. If None, no test predictions are produced.
    pred_type : str
        Either 'classification' or 'regression'.
    unbalanced_target : bool, default False
        If True, adds scale_pos_weight estimator parameter (calculated per fold).
        Ignored for regression.
    processor : object or None, optional
        Preprocessing pipeline with `fit_transform` and `transform` methods.
        Applied BEFORE categorical conversion. If None, features pass through unchanged.
    models : list or str, default ('lgb', 'xgb', 'cb')
        Model keys to train. Supported values: 'lgb', 'xgb', 'cb'.
    params_dict : dict or None, optional
        Mapping `model_name -> dict` of model parameters. 
        If None, n_estimators=10000 is used to allow space for early stopping.
    scoring_dict : dict or None, optional
        Mapping `metric_name -> callable(y_true, y_pred_or_proba)`. If None,
        defaults are provided (classification: ROC AUC; regression: RMSE).
    decision_threshold : float, default 0.5
        Threshold to convert probabilities to class labels for threshold-based metrics.
    n_splits : int, default 5
        Number of CV folds. Ignored if `cv_splitter` is provided.
    random_state : int or list of ints, default 42
        Single seed or list of seeds to repeat CV. Results are averaged across seeds.
    early_stopping_rounds : int, default 50
        Default early stopping rounds used when model params do not override it.
    verbose : int, default 2
        2 prints detailed per-fold/per-model scores,
        1 prints only final averaged scores,
        0 prints nothing.
    return_trained : bool, default False
        If True, return the list of trained estimator instances (one per model
        per fold per seed) and the final fitted preprocessing pipeline. 
        If False (default), trained estimators are not accumulated and the final 
        preprocessing pipeline is not fitted and None is returned in that positions.
    predict_proba : bool, default True
        For classification: if True return probabilities; if False return binary
        labels using `decision_threshold`. Ignored for regression.
    return_raw_test_preds : bool, default False
        Controls test prediction structure:
        - If True: returns raw per-fold predictions with one column per 
          (model, fold, seed) — columns named like 'lgb_seed_42_fold_0'.
        - If False (default): averages predictions across folds for each 
          (model, seed) combination, returning one column per (model, seed) 
          that matches the OOF DataFrame's column structure and order.
    cv_splitter : object, optional
        A pre-configured CV splitter instance (e.g., PurgedKFold, TimeSeriesSplit).
        If provided, this overrides `n_splits` and automatic splitter selection logic.
        The splitter must implement a `split(X, y, [groups])` method.
        If `random_state` is a list, this splitter will be cloned for each seed.
    cv_groups : pd.Series or np.ndarray, optional
        Group labels for CV splitting. Must be provided if `cv_splitter` requires groups.
        If `cv_splitter` is None, this must also be None (internal group splitters removed).
        Length must match `X` and `y`.

    Returns
    -------
    oof_preds_df : pd.DataFrame
        OOF predictions. Shape: (n_samples, N), where N = n_models × n_seeds.
        Columns named like 'lgb_seed_42'.
    test_preds_df : pd.DataFrame or None
        Test predictions. If `X_test` is None, returns None.
        - If `return_raw_test_preds=True`: shape (len(X_test), N_raw) with 
          N_raw = n_models × n_folds × n_seeds, columns named like 
          'lgb_seed_42_fold_0'.
        - If `return_raw_test_preds=False` (default): shape (len(X_test), N) 
          with N = n_models × n_seeds, columns named like 'lgb_seed_42', 
          matching the OOF DataFrame column structure and order.
    trained_pipelines : list of (processor, model) tuples or None
        If return_trained=True, list of (fold_processor, model) for each model/fold/seed.
    """
    # Input Validation
    if pred_type not in ('classification', 'regression'):
        raise ValueError("pred_type must be 'classification' or 'regression'")

    if models is None:
        raise ValueError("`models` cannot be None.")
    
    if isinstance(models, str):
        models = [models]
    allowed = {'lgb', 'xgb', 'cb'}
    for m in models:
        if m not in allowed:
            raise ValueError(f"Unsupported model '{m}'. Allowed: {allowed}")

    if isinstance(random_state, int):
        random_states = [random_state]
    else:
        random_states = list(random_state)

    if X_test is not None and len(X_test) == 0:
        raise ValueError("`X_test` must not be empty if provided.")
    
    if len(X) != len(y):
        raise ValueError("`X` and `y` must have the same number of samples.")
    
    if cv_splitter is None and cv_groups is not None:
        raise ValueError(
            "`cv_groups` is provided but `cv_splitter` is None. "
            "Please provide a custom `cv_splitter` (e.g., GroupKFold) to use `cv_groups`."
        )

    # Ensure y as pd.Series for consistent indexing with iloc
    y = y if isinstance(y, pd.Series) else pd.Series(y)

    # Initialize OOF: one column per (model, seed) 
    oof_col_names = [f"{m}_seed_{seed}" for seed in random_states for m in models]
    oof_preds_df = pd.DataFrame(index=X.index, columns=oof_col_names, dtype=np.float64)
    oof_preds_df[:] = np.nan  

    # Initialize test preds: Dynamic column creation handled in loop
    test_preds_df = None
    if X_test is not None:
        test_preds_df = pd.DataFrame(index=X_test.index, dtype=np.float64)

    # Default scoring
    if scoring_dict is None:
        if pred_type == 'classification':
            scoring_dict = {'roc_auc': roc_auc_score}
        else:
            scoring_dict = {
                'rmse': lambda y_true, y_pred: float(np.sqrt(mean_squared_error(y_true, y_pred)))
                }

    # Default parameters
    if params_dict is None:
        params_dict = {m: {} for m in models}
    else:
        for m in models:
            params_dict.setdefault(m, {})

    # Setup base processor (identity if None)
    if processor is None:
        base_processor = FunctionTransformer(lambda X: X.copy(), validate=False)
    elif not hasattr(processor, 'fit_transform') or not hasattr(processor, 'transform'):
        raise TypeError("`processor` must have `fit_transform` and `transform` methods.")
    else:
        base_processor = processor

    # Store (processor, model) tuples if requested
    trained_pipelines: List[Tuple[Any, Any]] = [] if return_trained else None

    # CV results storage (for printing only)
    cv_results = {
        'stacked': {name: [] for name in scoring_dict.keys()},
        'per_model': {m: {name: [] for name in scoring_dict.keys()} for m in models},
    }
    # Helper for controlled printing
    def _print(msg, level=2):
        if verbose >= level:
            print(msg)

    # Main loop across random states
    for seed in random_states:
        _print(f'\n=== Random State {seed} ===', level=2)
        
        # Determine splitter
        if cv_splitter is not None:
            # Use custom splitter
            splitter = copy.deepcopy(cv_splitter)
            
            # Try to set random state if the splitter supports it
            if hasattr(splitter, 'random_state'):
                splitter.random_state = seed
            
            # Warn if n_splits attribute exists but differs from function arg
            if hasattr(splitter, 'n_splits') and splitter.n_splits != n_splits:
                _print(f"Warning: splitter.n_splits ({splitter.n_splits}) differs from function arg n_splits ({n_splits}). Using splitter's value.", level=1)
            
            split_args = (X, y)
            split_kwargs = {}
            if cv_groups is not None:
                split_kwargs['groups'] = cv_groups
        else:
            # Regular CV (standard sklearn splitters)
            if pred_type == 'classification':
                splitter = StratifiedKFold(
                    n_splits=n_splits, 
                    shuffle=True, 
                    random_state=seed
                )
            else:
                splitter = KFold(
                    n_splits=n_splits, 
                    shuffle=True, 
                    random_state=seed
                )
            split_args = (X, y)
            split_kwargs = {}

        # Per-seed storage for reporting 
        seed_model_scores = {m: {name: [] for name in scoring_dict.keys()} for m in models}
        seed_stack_scores = {metric_name: [] for metric_name in scoring_dict.keys()}
        
        for fold, (train_idx, val_idx) in enumerate(splitter.split(*split_args, **split_kwargs)):
            _print(f'\nFold {fold + 1}', level=2)

            X_train, X_val = X.iloc[train_idx].copy(), X.iloc[val_idx].copy()
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

            # Always wrap processor to handle categoricals post-transformation
            fold_processor = _CatWrapper(copy.deepcopy(base_processor))

            # Apply processor to current fold
            X_train = fold_processor.fit_transform(X_train, y_train)
            X_val = fold_processor.transform(X_val)
            X_test_proc = fold_processor.transform(X_test) if X_test is not None else None
            
            # Get categorical columns for model params 
            cat_cols = getattr(fold_processor, 'cat_cols_', [])

            # Update model params for categorical handling
            local_params_dict = {}
            for m in models:
                p = params_dict[m].copy()
                if cat_cols:
                    # lgb handles categories automatically via pandas categorical dtype
                    if m == 'xgb':
                        p['enable_categorical'] = True
                    elif m == 'cb':
                        p['cat_features'] = cat_cols
                
                # Handle unbalanced target
                if unbalanced_target and pred_type == 'classification':
                    pos_weight = y_train.eq(0).sum() / y_train.eq(1).sum()
                    p['scale_pos_weight'] = pos_weight

                # Update parameters
                local_params_dict[m] = p

            fold_val_preds_list = []

            for model_name in models:
                p = local_params_dict[model_name]

                # Train model
                if model_name == 'lgb':
                    ModelClass = lgb.LGBMClassifier if pred_type == 'classification' else lgb.LGBMRegressor
                    # Set a high default to allow early stopping to determine optimal rounds
                    if not p:
                        p.setdefault('n_estimators', 10000)
                    p.setdefault('verbosity', -1)
                    model = ModelClass(**p)
                    model.fit(
                        X_train, y_train,
                        eval_set=[(X_val, y_val)],
                        callbacks=[lgb.early_stopping(early_stopping_rounds, verbose=False)]
                    )
                elif model_name in ['xgb', 'cb']:
                    p.setdefault('early_stopping_rounds', early_stopping_rounds)
                   
                    if model_name == 'xgb': 
                        ModelClass = xgb.XGBClassifier if pred_type == 'classification' else xgb.XGBRegressor
                        if not p:
                            p.setdefault('n_estimators', 10000) 
                    else:
                        ModelClass = cb.CatBoostClassifier if pred_type == 'classification' else cb.CatBoostRegressor
                        if not p:
                            p.setdefault('iterations', 10000)

                    model = ModelClass(**p) 
                    model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)


                # Store the (fitted fold_processor, trained fold model) tuple if requested
                if return_trained:
                    trained_pipelines.append((fold_processor, model))

                # Predictions              
                if pred_type == 'classification':
                    # Prefer predict_proba; if user requested binary output at top-level,
                    # we still compute probabilities here and convert later if needed
                    val_preds = model.predict_proba(X_val)[:, 1]
                    test_fold_preds = model.predict_proba(X_test_proc)[:, 1] if X_test_proc is not None else None
                    
                else:  # regression
                    val_preds = model.predict(X_val)
                    test_fold_preds = model.predict(X_test_proc) if X_test_proc is not None else None

                # Clip classification probabilities to [0,1] 
                if pred_type == 'classification':
                    val_preds = np.clip(val_preds, 0.0, 1.0)
                    if test_fold_preds is not None:
                        test_fold_preds = np.clip(test_fold_preds, 0.0, 1.0)
                
                # OOF predictions: accumulate into (model, seed) column
                oof_col = f"{model_name}_seed_{seed}"
                val_index_labels = X.iloc[val_idx].index
                oof_preds_df.loc[val_index_labels, oof_col] = val_preds

                # Test predictions: accumulate into (model, seed, fold) column
                if X_test is not None:
                    test_col = f"{model_name}_seed_{seed}_fold_{fold}"
                    test_preds_df[test_col] = test_fold_preds

                # Scoring
                fold_val_preds_list.append(val_preds)

                # Score individual model on this fold
                if pred_type == 'classification':
                    val_binary = (val_preds >= decision_threshold).astype(int)

                    for metric_name, scoring_fn in scoring_dict.items():
                        name_l = metric_name.lower()

                        if any(k in name_l for k in ('roc', 'auc', 'logloss', 'log_loss')):
                            score = scoring_fn(y_val, val_preds)
                        else:
                            score = scoring_fn(y_val, val_binary)

                        cv_results['per_model'][model_name][metric_name].append(score)
                        seed_model_scores[model_name][metric_name].append(score)
                        _print(f'  {model_name.upper()} {metric_name}: {score:.5f}', level=2)
                else:
                    for metric_name, scoring_fn in scoring_dict.items():
                        score = scoring_fn(y_val, val_preds)
                        cv_results['per_model'][model_name][metric_name].append(score)
                        seed_model_scores[model_name][metric_name].append(score)
                        _print(f'  {model_name.upper()} {metric_name}: {score:.5f}', level=2)

            # Stacked scoring (mean of models on this fold)
            fold_val_preds = np.mean(np.vstack(fold_val_preds_list), axis=0)

            if pred_type == 'classification':
                fold_val_binary = (fold_val_preds >= decision_threshold).astype(int)

                for metric_name, scoring_fn in scoring_dict.items():
                    name_l = metric_name.lower()

                    if any(k in name_l for k in ('roc', 'auc', 'logloss', 'log_loss')):
                        stacked_score = scoring_fn(y_val, fold_val_preds)
                    else:
                        stacked_score = scoring_fn(y_val, fold_val_binary)

                    cv_results['stacked'][metric_name].append(stacked_score)
                    seed_stack_scores[metric_name].append(stacked_score)
                    _print(f'  Stacked {metric_name}: {stacked_score:.5f}', level=2)
            else:
                for metric_name, scoring_fn in scoring_dict.items():
                    stacked_score = scoring_fn(y_val, fold_val_preds)
                    cv_results['stacked'][metric_name].append(stacked_score)
                    seed_stack_scores[metric_name].append(stacked_score)
                    _print(f'  Stacked {metric_name}: {stacked_score:.5f}', level=2)

        # --- End of folds for this seed ---
        
        # Print per-seed summary
        if verbose >= 2:          
            _print(f'\nSeed {seed} mean scores:', level=2)
            for model_name in models:
                for metric_name, vals in seed_model_scores[model_name].items():
                    mean_val = float(np.mean(vals)) if vals else float('nan')
                    _print(f'  {model_name.upper()} {metric_name}: {mean_val:.5f}', level=2)

            # Stacked average scores
            for metric_name, score in {k: float(np.mean(v)) for k, v in seed_stack_scores.items()}.items():
                _print(f'  Stacked {metric_name}: {score:.5f}', level=2)

    # --- End of seeds ---

    # Final summary
    if verbose >= 1:
        print('\n' + '=' * 30)
        print('=== CV Results Summary ===\n')
        print('Mean CV Scores per Model:')
        for model_name in models:
            print(f'\n--- {model_name.upper()} ---')
            for metric_name, scores in cv_results['per_model'][model_name].items():
                print(f'  {metric_name}: {np.mean(scores):.5f}')
  
        print('\nMean Stacked CV Scores:')
        for metric_name, scores in cv_results['stacked'].items():
            print(f'  {metric_name}: {np.mean(scores):.5f}')

    # Transform test predictions to match OOF structure if requested
    if X_test is not None and not return_raw_test_preds:
        # Build averaged test predictions DataFrame matching OOF structure
        averaged_test_preds = pd.DataFrame(index=X_test.index, columns=oof_col_names, dtype=np.float64)
        for seed in random_states:
            for model_name in models:
                oof_col = f"{model_name}_seed_{seed}"
                # Find all fold columns for this (model, seed) dynamically
                fold_cols = [c for c in test_preds_df.columns if c.startswith(f"{model_name}_seed_{seed}_fold_")]
                # Average across folds (preserves probability space before thresholding)
                if fold_cols:
                    averaged_test_preds[oof_col] = test_preds_df[fold_cols].mean(axis=1)
                else:
                    averaged_test_preds[oof_col] = np.nan
        test_preds_df = averaged_test_preds

    # Apply final thresholding if needed (only for classification)
    if pred_type == 'classification' and not predict_proba:
        oof_preds_df = (oof_preds_df >= decision_threshold).astype(int)
        if test_preds_df is not None:
            test_preds_df = (test_preds_df >= decision_threshold).astype(int)

    return oof_preds_df, test_preds_df, trained_pipelines

class _CatWrapper(BaseEstimator, TransformerMixin):
    """
    Wraps a base processor and ensures robust categorical handling for gradient boosters.
    
    After applying `base_processor.fit_transform()`, detects columns with object/string/
    categorical dtypes and applies OrdinalEncoder with explicit unseen-category handling.    
    Final output converts encoded integers to pandas 'category' dtype. 
    
    Attributes
    ----------
    cat_cols_ : List[str]
        Column names detected as categorical-like after base_processor transformation.
    oe_ : OrdinalEncoder or None
        Fitted encoder for categorical columns, or None if no categoricals detected.
    """
    def __init__(self, base_processor):
        self.base_processor = base_processor

    def fit(self, X, y=None):
        X_proc = self.base_processor.fit_transform(X, y)
        if isinstance(X_proc, pd.DataFrame):
            self.cat_cols_ = [
                col for col, dtype in X_proc.dtypes.items()
                if pd.api.types.is_object_dtype(dtype)
                or pd.api.types.is_string_dtype(dtype)
                or isinstance(dtype, pd.CategoricalDtype)
            ]
            if self.cat_cols_:
                self.oe_ = OrdinalEncoder(
                    dtype=np.int32,
                    handle_unknown='use_encoded_value',
                    unknown_value=-1,
                    encoded_missing_value=-1,
                ).set_output(transform='pandas')
                self.oe_.fit(X_proc[self.cat_cols_])
            else:
                self.oe_ = None
        else:
            self.cat_cols_ = []
            self.oe_ = None

        return self

    def transform(self, X):
        X_proc = self.base_processor.transform(X)
        if isinstance(X_proc, pd.DataFrame) and self.cat_cols_ and self.oe_ is not None:
            X_proc = X_proc.copy()
            X_proc[self.cat_cols_] = self.oe_.transform(X_proc[self.cat_cols_]).astype('category')

        return X_proc