"""Leanvox Python SDK — Official client for the Leanvox TTS API."""

from .client import AsyncLeanvox, Leanvox
from .errors import (
    AuthenticationError,
    InsufficientBalanceError,
    InvalidRequestError,
    LeanvoxError,
    NotFoundError,
    RateLimitError,
    ServerError,
    StreamingFormatError,
)
from .types import (
    AccountBalance,
    AccountUsage,
    FileExtractResult,
    GenerateResult,
    Generation,
    GenerationList,
    Job,
    SpeakersData,
    SummaryData,
    TranscribeResult,
    TranscribeUsage,
    TranscriptData,
    TranscriptSegment,
    Voice,
    VoiceDesign,
    VoiceOverResult,
    VoiceList,
)

__version__ = "0.4.0"

__all__ = [
    "Leanvox",
    "AsyncLeanvox",
    "LeanvoxError",
    "InvalidRequestError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "StreamingFormatError",
    "GenerateResult",
    "Voice",
    "VoiceList",
    "VoiceDesign",
    "VoiceOverResult",
    "Job",
    "FileExtractResult",
    "Generation",
    "GenerationList",
    "AccountBalance",
    "AccountUsage",
]
