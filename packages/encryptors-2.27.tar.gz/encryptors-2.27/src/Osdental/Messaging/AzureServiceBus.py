import json
from typing import Dict, Any
from azure.servicebus import ServiceBusMessage
from azure.servicebus.aio import ServiceBusClient
from azure.identity.aio import DefaultAzureCredential

class ServiceBusService:

    def __init__(self, namespace: str, queue_name: str):

        self.namespace = namespace
        self.queue_name = queue_name

        self.credential = DefaultAzureCredential()

        self.client = ServiceBusClient(
            fully_qualified_namespace=self.namespace,
            credential=self.credential
        )

        self.sender = None

    async def start(self):
        self.sender = self.client.get_queue_sender(queue_name=self.queue_name)
        await self.sender.__aenter__()

    async def send_message(self, message: Dict[str, Any] | str):

        data = json.dumps(message) if isinstance(message, dict) else message

        msg = ServiceBusMessage(data)

        await self.sender.send_messages(msg)

    async def close(self):

        if self.sender:
            await self.sender.__aexit__(None, None, None)

        await self.client.close()
        await self.credential.close()