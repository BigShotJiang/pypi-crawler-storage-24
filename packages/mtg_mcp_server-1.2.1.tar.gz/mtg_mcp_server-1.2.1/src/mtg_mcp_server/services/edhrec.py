"""EDHREC API client for commander staples and card synergy data.

EDHREC has no official public API. This client uses undocumented internal JSON
endpoints that may break without notice. All access is behind a feature flag
(MTG_MCP_ENABLE_EDHREC) and should fail gracefully.
"""

from __future__ import annotations

import re
import unicodedata
from typing import TYPE_CHECKING

from cachetools import TTLCache

from mtg_mcp_server.services.base import DEFAULT_USER_AGENT, BaseClient, ServiceError
from mtg_mcp_server.services.cache import _method_key, async_cached
from mtg_mcp_server.types import EDHRECCard, EDHRECCardList, EDHRECCommanderData

# Pre-compiled regexes for URL slug generation (_slugify).
# EDHREC slugs are lowercase-hyphenated with no punctuation.
_RE_SPECIAL_CHARS = re.compile(r"[,.'\"!?:;()]+")
_RE_WHITESPACE = re.compile(r"\s+")
_RE_MULTI_HYPHEN = re.compile(r"-+")


def _normalize_name(name: str) -> str:
    """Normalize a card name for matching: lowercase, strip diacritics, front face only."""
    # Strip DFC back-face suffix ("Pinnacle Monk // Mystic Peak" → "Pinnacle Monk")
    if " // " in name:
        name = name.split(" // ")[0]
    # Strip diacritics ("Glóin" → "Gloin")
    nfkd = unicodedata.normalize("NFD", name)
    name = "".join(c for c in nfkd if unicodedata.category(c) != "Mn")
    return name.lower()


if TYPE_CHECKING:
    # httpx.Response.json() returns Any; we alias for clarity in parsing helpers.
    from typing import Any as JSONData


class EDHRECError(ServiceError):
    """EDHREC API error."""


class CommanderNotFoundError(EDHRECError):
    """Commander was not found on EDHREC."""


class EDHRECClient(BaseClient):
    """Async client for EDHREC's internal JSON endpoints.

    These endpoints are undocumented and fragile. Use defensive parsing
    with ``.get()`` chains and default to empty values when fields are missing.

    Args:
        base_url: EDHREC JSON endpoint base URL.
        rate_limit_rps: Max requests per second (0.5 = 1 req per 2 sec).
        user_agent: User-Agent header value.
    """

    # Aggressive 24h cache — EDHREC data updates daily and endpoints are fragile.
    _commander_cache: TTLCache = TTLCache(maxsize=100, ttl=86400)  # 24h
    _synergy_cache: TTLCache = TTLCache(maxsize=200, ttl=86400)  # 24h

    def __init__(
        self,
        base_url: str = "https://json.edhrec.com",
        rate_limit_rps: float = 0.5,
        user_agent: str = DEFAULT_USER_AGENT,
    ) -> None:
        super().__init__(
            base_url=base_url,
            rate_limit_rps=rate_limit_rps,
            user_agent=user_agent,
        )

    def _slugify(self, name: str) -> str:
        """Convert a card name to an EDHREC URL slug.

        Lowercase, replace spaces with hyphens, remove commas, apostrophes,
        periods, and other special characters. Collapse multiple hyphens.
        """
        slug = name.lower()
        slug = _RE_SPECIAL_CHARS.sub("", slug)
        slug = _RE_WHITESPACE.sub("-", slug)
        slug = _RE_MULTI_HYPHEN.sub("-", slug)
        return slug.strip("-")

    @async_cached(_commander_cache, key=_method_key)
    async def commander_top_cards(
        self, commander_name: str, category: str | None = None
    ) -> EDHRECCommanderData:
        """Get top cards for a commander with synergy and inclusion data.

        Args:
            commander_name: The commander's full name (e.g. "Muldrotha, the Gravetide").
            category: Optional category filter (e.g. "creatures", "enchantments").
                      Matches against the cardlist tag field.

        Returns:
            EDHRECCommanderData with parsed cardlists.

        Raises:
            CommanderNotFoundError: If the commander page doesn't exist.
            EDHRECError: On other API errors.
        """
        slug = self._slugify(commander_name)
        try:
            response = await self._get(f"/pages/commanders/{slug}.json")
        except ServiceError as exc:
            if exc.status_code in (404, 403):
                raise CommanderNotFoundError(
                    f"Commander not found on EDHREC: '{slug}'", status_code=exc.status_code
                ) from exc
            raise EDHRECError(exc.message, status_code=exc.status_code) from exc

        data = response.json()
        return self._parse_commander_data(data, commander_name, category)

    @async_cached(_synergy_cache, key=_method_key)
    async def card_synergy(self, card_name: str, commander_name: str) -> EDHRECCard | None:
        """Get synergy data for a specific card with a commander.

        Fetches the commander page and searches all cardlists for the card.

        Args:
            card_name: The card to look up.
            commander_name: The commander to check synergy against.

        Returns:
            EDHRECCard if the card is found, None otherwise.

        Raises:
            CommanderNotFoundError: If the commander page doesn't exist.
            EDHRECError: On other API errors.
        """
        result = await self.commander_top_cards(commander_name)
        needle = _normalize_name(card_name)
        for cardlist in result.cardlists:
            for card in cardlist.cardviews:
                if _normalize_name(card.name) == needle:
                    return card
        return None

    def _parse_commander_data(
        self,
        data: JSONData,
        commander_name: str,
        category: str | None = None,
    ) -> EDHRECCommanderData:
        """Defensively parse a commander page JSON response.

        The response has a deeply nested structure::

            {
              "header": "Muldrotha, the Gravetide (Commander)",
              "num_decks_avg": 19741,
              "container": {
                "json_dict": {
                  "cardlists": [
                    {"header": "Creatures", "tag": "creatures",
                     "cardviews": [{"name": ..., "synergy": ..., ...}]}
                  ]
                }
              }
            }

        Every level uses ``isinstance`` checks and ``.get()`` with defaults
        because this undocumented API can change field shapes without notice.

        Args:
            data: Raw JSON response (expected dict, but guarded against other types).
            commander_name: Fallback name if the response header is missing.
            category: Optional tag filter (e.g. ``"creatures"``).

        Returns:
            Parsed commander data with categorized cardlists.
        """
        if not isinstance(data, dict):
            return EDHRECCommanderData(commander_name=commander_name)

        # Extract header — fall back to provided commander name
        raw_header = data.get("header", commander_name)
        header = str(raw_header) if raw_header is not None else commander_name
        if header.endswith(" (Commander)"):
            header = header[: -len(" (Commander)")]

        raw_total = data.get("num_decks_avg", 0)
        total_decks = int(raw_total) if isinstance(raw_total, (int, float)) else 0

        # Navigate: data -> container -> json_dict -> cardlists
        container = data.get("container")
        json_dict = container.get("json_dict") if isinstance(container, dict) else None
        raw_cardlists = json_dict.get("cardlists", []) if isinstance(json_dict, dict) else []
        if not isinstance(raw_cardlists, list):
            raw_cardlists = []

        cardlists: list[EDHRECCardList] = []
        for raw_cl in raw_cardlists:
            if not isinstance(raw_cl, dict):
                continue
            tag = str(raw_cl.get("tag", ""))
            cl_header = str(raw_cl.get("header", ""))
            raw_views = raw_cl.get("cardviews", [])
            if not isinstance(raw_views, list):
                raw_views = []

            cards: list[EDHRECCard] = []
            for raw_card in raw_views:
                if not isinstance(raw_card, dict):
                    continue
                # Use `or 0.0` / `or 0` to coerce None from JSON to numeric defaults.
                # The API returns ``inclusion`` as a raw deck count (same as
                # ``num_decks``), not a percentage.  Compute the percentage
                # from ``num_decks / potential_decks * 100`` at parse time so
                # downstream consumers can use ``inclusion`` directly as 0-100.
                num = int(raw_card.get("num_decks", 0) or 0)
                pot = int(raw_card.get("potential_decks", 0) or 0)
                pct = round(num / pot * 100) if pot > 0 else 0
                cards.append(
                    EDHRECCard(
                        name=str(raw_card.get("name", "")),
                        sanitized=str(raw_card.get("sanitized", "")),
                        synergy=float(raw_card.get("synergy", 0.0) or 0.0),
                        inclusion=pct,
                        num_decks=num,
                        potential_decks=pot,
                        label=str(raw_card.get("label", "")),
                    )
                )

            cardlists.append(EDHRECCardList(header=cl_header, tag=tag, cardviews=cards))

        if category is not None:
            category_lower = category.lower()
            # Exact match first; fall back to substring (e.g. "artifacts"
            # matches "utilityartifacts" and "manaartifacts").
            exact = [cl for cl in cardlists if cl.tag.lower() == category_lower]
            cardlists = (
                exact if exact else [cl for cl in cardlists if category_lower in cl.tag.lower()]
            )

        return EDHRECCommanderData(
            commander_name=header,
            cardlists=cardlists,
            total_decks=total_decks,
        )
