"""Blob storage backends."""
