import pytest

from makegis.dag.sql import analyze_sql_content
from makegis.dag.sql import DBO


def test_simple():
    sql = """
    create table new.table as
    select * from raw.dataset;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("new", "table", "relation")}
    assert r.dependencies == {DBO("raw", "dataset", "relation")}


def test_trickier():
    sql = """
    --create table not.new_table as select * from raw.fake;
    create table new.table as
        select * from raw.dataset;

    create temp table tmp_tbl
        as select * from raw.thing;

    create temporary table tmp_tbl_orary
        as select * from raw.thing;

    begin;

    create view view_commit as select * from new.table;
    create view view_commit_but_dropped_later as select * from new.table;

    commit;

    begin;

    create view view_rollback as select * from still_a_dep;

    rollback;

    drop view view_commit_but_dropped_later;
    """
    r = analyze_sql_content(sql)
    assert r.created == {
        DBO("new", "table", "relation"),
        DBO("", "view_commit", "relation"),
    }
    assert r.dependencies == {
        DBO("raw", "dataset", "relation"),
        DBO("raw", "thing", "relation"),
        DBO("", "still_a_dep", "relation"),
    }


def test_with_cte():
    sql = """
    create table new.table as
        with some_dep as (
            select * from raw.dep
        )
        select * from some_dep;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("new", "table", "relation")}
    assert r.dependencies == {DBO("raw", "dep", "relation")}


def test_view_from_existing_dependency():
    sql = """
    create view new.view as
        with some_dep as (
            select * from raw.dep
        )
        select * from some_dep;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("new", "view", "relation")}
    assert r.dependencies == {DBO("raw", "dep", "relation")}


def test_create_function():
    sql = """
    create or replace function sch.foo(_id integer)
    returns table(
        id integer
    ) as
    $$
        select _id + 1
    $$
    language sql
    immutable;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("sch", "foo", "function")}
    assert r.dependencies == set()


def test_create_index():
    sql = """
    -- index creation has no impact
    create index on some_table using gist(geom);
    """
    r = analyze_sql_content(sql)
    assert r.created == set()
    assert r.dependencies == set()


def test_alter_owned_table():
    sql = """
    create table foo as
        select *
        from dep;
    alter table foo add primary key(id);
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "foo", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_alter_existing_table_raises_error():
    sql = """
    alter table foo add primary key(id);
    """
    with pytest.raises(NotImplementedError):
        r = analyze_sql_content(sql)


def test_analyze_table():
    sql = "analyze some.table;"
    r = analyze_sql_content(sql)
    assert r.dependencies == {DBO("some", "table", "relation")}


def test_update_owned_table():
    sql = """
    create table foo as
        select *
        from dep;
    update foo set col = 0
    from other_dep
    where other_dep.id = foo.id;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "foo", "relation")}
    assert r.dependencies == {
        DBO("", "dep", "relation"),
        DBO("", "other_dep", "relation"),
    }


def test_update_existing_table_raises_error():
    sql = """
    update table foo set col = 0;
    """
    with pytest.raises(NotImplementedError):
        r = analyze_sql_content(sql)


def test_drop_then_create():
    sql = """
    drop table foo;
    create table foo as
        select *
        from dep;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "foo", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_drop_then_create_commit():
    sql = """
    begin;
    drop table foo;
    create table foo as
        select *
        from dep;
    commit;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "foo", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_drop_then_create_rollback():
    sql = """
    begin;
    drop table foo;
    create table foo as
        select *
        from dep;
    rollback;
    """
    r = analyze_sql_content(sql)
    assert r.created == set()
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_recursive_function():
    sql = """
    create or replace function sch.recursive_foo(_id integer)
    returns table(
        id integer
    ) as
    $$
    with recursive traverse(id, fid) as (
        select _id, rch.fid
        from raw.dep d
        where d.id = _id
        union
        select d.id, d.fid
        from raw.dep d
        join traverse on traverse.fid = d.nextfid
    )
    select id
    from traverse
    $$
    language sql
    immutable;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("sch", "recursive_foo", "function")}
    assert r.dependencies == {DBO("raw", "dep", "relation")}


def test_create_then_insert():
    sql = """
    create table sch.tbl (
        id integer primary key,
        name text not null
    );

    insert into sch.tbl (id, name)
    select fid
        , title
    from dep;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("sch", "tbl", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_builtin_count_function():
    """
    Reproduce bug where count(*) is parsed as a user defined function.
    """
    sql = """
    create view some_view as
        select id
            , count(id) as ids
            , count(*) as stars
        from dep
        group by 1;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "some_view", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}


def test_postgis_functions():
    """
    Postgis functions should not be listed as dependencies.
    """
    sql = """
    create view some_view as
        select id
            , sum(public.st_area(geom)) as area
            , st_union(geom) as geom
        from dep
        group by 1;
    """
    r = analyze_sql_content(sql)
    assert r.created == {DBO("", "some_view", "relation")}
    assert r.dependencies == {DBO("", "dep", "relation")}
