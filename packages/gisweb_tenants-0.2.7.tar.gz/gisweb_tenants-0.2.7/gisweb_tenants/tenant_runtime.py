# tenant_oidc.py

# Questa classe:

# estende TenantContextConfig
# aggiunge TenantRuntimeConfigService
# espone getter runtime per tenant:
# get_oidc()
# get_email()
# get_pagopa()
# get_protocollo()


from .models import KeycloakAdminConfig
from .tenant_context import TenantContextConfig
from .service import TenantRuntimeConfigService


class TenantRuntimeConfig(TenantContextConfig):
    def __init__(
        self,
        tenants_source: str,
        *,
        settings=None,
        tenant_header: str = "X-Tenant",
        user_id_header: str = "X-UserId",
        request_id_header: str = "X-Request-Id",
        default_tenant: str | None = None,
        default_user_id: str | None = None,
        allowed_tenants: set[str] | None = None,
        strict_whitelist: bool = False,
    ):
        super().__init__(
            tenants_source=tenants_source,
            tenant_header=tenant_header,
            user_id_header=user_id_header,
            request_id_header=request_id_header,
            default_tenant=default_tenant,
            default_user_id=default_user_id,
            allowed_tenants=allowed_tenants,
            strict_whitelist=strict_whitelist,
        )

        self.runtime = TenantRuntimeConfigService(self.service, settings)

    # -------------------------
    # RUNTIME CONFIG
    # -------------------------

    def get_oidc(self, tenant: str):
        return self.runtime.get_oidc(tenant)
    
    def get_keycloak_admin(self, tenant: str):
        return self.runtime.get_keycloak_admin(tenant)

    def get_email(self, tenant: str):
        return self.runtime.get_email(tenant)

    def get_pagopa(self, tenant: str):
        return self.runtime.get_pagopa(tenant)

    def get_protocollo(self, tenant: str):
        return self.runtime.get_protocollo(tenant)