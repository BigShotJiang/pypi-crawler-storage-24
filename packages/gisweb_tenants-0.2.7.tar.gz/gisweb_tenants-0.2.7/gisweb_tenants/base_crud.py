from __future__ import annotations

from typing import Any, Generic, TypeVar, TYPE_CHECKING

from pydantic import BaseModel
from sqlalchemy import delete as sa_delete
from sqlalchemy import exists, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.inspection import inspect

if TYPE_CHECKING:
    from gisweb_tenants.tenant_db import TenantDbConfig


ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class MissingDbError(RuntimeError):
    pass


class CRUDBase(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    def __init__(
        self,
        model: type[ModelType],
        *,
        config: TenantDbConfig | None = None,
    ):
        self.model = model
        self.config = config

    # -------------------------
    # DB
    # -------------------------

    def _db(self, db: AsyncSession | None = None) -> AsyncSession:
        if db is not None:
            return db

        if self.config is None:
            raise MissingDbError(f"No active DB for {self.model.__name__}")

        return self.config.current_db()

    # -------------------------
    # USER (audit)
    # -------------------------

    def _current_user_id(self) -> str | None:
        if self.config is None:
            return None
        return self.config.current_user_id()

    def _apply_create_audit(self, obj: ModelType) -> None:
        user_id = self._current_user_id()
        if not user_id:
            return

        if hasattr(obj, "created_by") and not getattr(obj, "created_by", None):
            setattr(obj, "created_by", user_id)

        if hasattr(obj, "updated_by"):
            setattr(obj, "updated_by", user_id)

    def _apply_update_audit(self, obj: ModelType) -> None:
        user_id = self._current_user_id()
        if user_id and hasattr(obj, "updated_by"):
            setattr(obj, "updated_by", user_id)

    # -------------------------
    # DATA
    # -------------------------

    def _to_dict(self, obj_in: BaseModel | dict[str, Any]) -> dict[str, Any]:
        if isinstance(obj_in, BaseModel):
            return obj_in.model_dump(exclude_unset=True)
        return obj_in

    # -------------------------
    # PK
    # -------------------------

    @property
    def pk_column(self):
        mapper = inspect(self.model)
        pk = mapper.primary_key

        if len(pk) != 1:
            raise ValueError(f"{self.model.__name__}: only single-column PK supported")

        return pk[0]

    # -------------------------
    # GET
    # -------------------------

    async def get(
        self,
        id: Any,
        *,
        db: AsyncSession | None = None,
    ) -> ModelType | None:
        db = self._db(db)
        return await db.get(self.model, id)

    async def get_multi(
        self,
        *,
        offset: int = 0,
        limit: int = 100,
        query: T | Select[T] | None = None,
        db: AsyncSession | None = None,
    ) -> list[ModelType]:
        db = self._db(db)
        
        if query is None:
            query = select(self.model).offset(offset).limit(limit)
        result = await db.execute(query)
        return list(result.scalars().all())

    async def count(
        self,
        *,
        db: AsyncSession | None = None,
    ) -> int:
        db = self._db(db)

        stmt = select(func.count()).select_from(self.model)
        result = await db.execute(stmt)
        return int(result.scalar_one())

    async def exists(
        self,
        id: Any,
        *,
        db: AsyncSession | None = None,
    ) -> bool:
        db = self._db(db)

        stmt = select(exists().where(self.pk_column == id))
        result = await db.execute(stmt)
        return bool(result.scalar())

    # -------------------------
    # CREATE
    # -------------------------

    async def create(
        self,
        *,
        obj_in: CreateSchemaType | dict[str, Any],
        db: AsyncSession | None = None,
        commit: bool = True,
        refresh: bool = True,
    ) -> ModelType:
        db = self._db(db)
        data = self._to_dict(obj_in)

        db_obj = self.model(**data)

        self._apply_create_audit(db_obj)
        db.add(db_obj)

        if commit:
            await db.commit()
            if refresh:
                await db.refresh(db_obj)
        else:
            await db.flush()

        return db_obj

    # -------------------------
    # UPDATE
    # -------------------------

    async def update(
        self,
        *,
        db_obj: ModelType,
        obj_in: UpdateSchemaType | dict[str, Any],
        db: AsyncSession | None = None,
        commit: bool = True,
        refresh: bool = True,
    ) -> ModelType:
        db = self._db(db)
        data = self._to_dict(obj_in)

        for key, value in data.items():
            setattr(db_obj, key, value)

        self._apply_update_audit(db_obj)

        if commit:
            await db.commit()
            if refresh:
                await db.refresh(db_obj)
        else:
            await db.flush()

        return db_obj

    # -------------------------
    # DELETE
    # -------------------------

    async def delete(
        self,
        *,
        id: Any,
        db: AsyncSession | None = None,
        commit: bool = True,
    ) -> ModelType | None:
        db = self._db(db)

        db_obj = await db.get(self.model, id)
        if db_obj is None:
            return None

        await db.delete(db_obj)

        if commit:
            await db.commit()
        else:
            await db.flush()

        return db_obj

    async def delete_where(
        self,
        *,
        where,
        db: AsyncSession | None = None,
        commit: bool = True,
    ) -> int:
        db = self._db(db)

        stmt = sa_delete(self.model).where(where)
        result = await db.execute(stmt)

        if commit:
            await db.commit()
        else:
            await db.flush()

        return int(result.rowcount or 0)