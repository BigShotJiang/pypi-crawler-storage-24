"""Synkro enterprise client — main entry point."""

from __future__ import annotations

import re
import uuid
from typing import Any

from synkro.enterprise._http import AsyncBaseHTTPClient, BaseHTTPClient
from synkro.enterprise.resources.integrations import AsyncIntegrations, Integrations
from synkro.enterprise.resources.policies import AsyncPolicies, Policies
from synkro.enterprise.resources.projects import AsyncProjects, Projects
from synkro.enterprise.types import Policy, Project

DEFAULT_BASE_URL = "https://api.synkro.sh"
SYNKRO_GATEWAY_URL = "https://gateway.synkro.sh"


class Synkro:
    """Synkro enterprise client (synchronous).

    Args:
        api_key: API key (sk-synkro-xxx).
        project: Project name — auto-creates or fetches the project.
        provider: Default provider for the project (e.g. ``"google"``, ``"openai"``).
        tap: Enable trace forwarding — ``"langsmith"``, ``"langfuse"``, or ``"all"``.
            When set, automatically intercepts traces from the specified platform
            and forwards them to Synkro. Defaults to ``None`` (disabled).
        gateway_url: Gateway base URL (e.g. ``http://localhost:8787``).
            Defaults to ``https://gateway.synkro.sh``.
        base_url: CRUD server URL. Defaults to https://api.synkro.sh.
        timeout: Request timeout in seconds.

    Example — minimal setup::

        synkro = Synkro(api_key="sk-synkro-xxx", project="My Agent")
        llm = synkro.langchain("gemini-2.5-flash", provider="google", api_key=GEMINI_KEY)

    Example — with LangSmith trace tap::

        synkro = Synkro(api_key="sk-synkro-xxx", project="My Agent", tap="langsmith")

    Example — with gateway routing::

        client = Synkro(
            api_key="sk-synkro-xxx",
            gateway_url="http://localhost:8787",
        )
        resp = client.chat.completions.create(
            model="gpt-4o", api_key=OPENAI_KEY, messages=[...],
            user_id="u1", conversation_id="conv-1",
        )
        resp.synkro.blocked  # True/False
    """

    projects: Projects
    policies: Policies
    integrations: Integrations

    def __init__(
        self,
        api_key: str,
        *,
        project: str | None = None,
        provider: str | None = None,
        tap: str | None = None,
        gateway_url: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._gateway_base = (gateway_url or SYNKRO_GATEWAY_URL).rstrip("/")
        # Strip any /v1/p/... suffix to get clean base
        self._gateway_base = re.sub(r"/v1/p/.*$", "", self._gateway_base)
        self._timeout = timeout
        self._http = BaseHTTPClient(base_url=base_url, api_key=api_key, timeout=timeout)
        self.projects = Projects(self._http)
        self.policies = Policies(self._http)
        self.integrations = Integrations(self._http)

        # Auto-resolve project if name provided
        self._project: Project | None = None
        if project:
            self._project = self._resolve_project(project, provider)

        # Enable trace tap if requested
        if tap:
            from synkro.enterprise.trace_tap import init as _tap_init
            _tap_init(api_key=api_key, project=project, tap=tap)

        # Gateway client (only when gateway_url provided and project resolved)
        gw_url = gateway_url
        if not gw_url and self._project:
            gw_url = f"{self._gateway_base}/v1/p/{self._project.slug}"
        if gw_url:
            # If gw_url doesn't have /v1/p/ path and we have a project, append it
            if "/v1/p/" not in gw_url and self._project:
                gw_url = f"{self._gateway_base}/v1/p/{self._project.slug}"

            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "openai is required for gateway_url support. "
                    "Install it with: pip install openai"
                )

            from synkro.enterprise.openai_wrapper import SynkroClient

            oai_kwargs: dict = {
                "base_url": gw_url,
                "api_key": "x",
                "default_headers": {"x-synkro-api-key": api_key},
            }
            if timeout != 30.0:
                oai_kwargs["timeout"] = timeout

            self._universal = SynkroClient(OpenAI(**oai_kwargs))
            self.chat = self._universal.chat

    @property
    def project(self) -> Project:
        """The resolved project. Raises if no project was set."""
        if self._project is None:
            raise ValueError("No project set. Pass project='...' to the Synkro constructor.")
        return self._project

    def _resolve_project(self, name: str, provider: str | None = None) -> Project:
        """Find existing project by name or create it."""
        existing = self.projects.list()
        proj = next((p for p in existing if p.name == name), None)
        if proj:
            return proj
        return self.projects.create(name=name, provider=provider)

    def policy(
        self,
        name: str,
        *,
        text: str | None = None,
        mode: str = "audit",
    ) -> Policy:
        """Get or create a policy for the current project (idempotent).

        Args:
            name: Policy name.
            text: Policy text — used only when creating a new policy.
            mode: Default rule mode (``"audit"`` or ``"blocking"``). Applied on creation.

        Returns:
            The existing or newly created Policy.
        """
        proj = self.project
        existing = self.policies.list(proj.id)
        pol = next((p for p in existing if p.is_active and p.name == name), None)
        if pol:
            return pol

        if text is None:
            raise ValueError(f"Policy '{name}' not found and no text provided to create it.")

        result = self.policies.create(proj.id, text=text, name=name)
        if mode and result.rules:
            rule_updates = [{"rule_id": r["rule_id"], "mode": mode} for r in result.rules]
            self.policies.update(proj.id, result.policy_id, rule_updates=rule_updates)

        # Re-fetch full policy
        policies = self.policies.list(proj.id)
        return next(p for p in policies if p.id == result.policy_id)

    def langchain(
        self,
        model: str,
        *,
        provider: str | None = None,
        api_key: str | None = None,
        conversation_id: str | None = None,
        **kwargs: Any,
    ):
        """Create a LangChain ``ChatOpenAI`` pre-configured to route through the Synkro gateway.

        Args:
            model: Model name (e.g. ``"gemini-2.5-flash"``, ``"gpt-4o"``).
            provider: Provider hint for the gateway (e.g. ``"google"``, ``"openai"``).
            api_key: The *provider's* API key.
            conversation_id: Conversation ID for guard tracking. Auto-generated if omitted.
            **kwargs: Extra kwargs passed to ``ChatOpenAI()``.

        Returns:
            A ``ChatOpenAI`` instance routed through the Synkro gateway.

        Example::

            synkro = Synkro(api_key="sk-synkro-xxx", project="My Agent")
            llm = synkro.langchain("gemini-2.5-flash", provider="google", api_key=GEMINI_KEY)
            llm.invoke("Hello")
        """
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(
                "langchain-openai is required for synkro.langchain(). "
                "Install it with: pip install langchain-openai"
            )

        proj = self.project
        gateway_url = f"{self._gateway_base}/v1/p/{proj.slug}"
        conv_id = conversation_id or str(uuid.uuid4())

        headers: dict[str, str] = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-conversation-id": conv_id,
        }
        if provider:
            headers["x-synkro-provider"] = provider

        # Merge any extra default_headers from kwargs (e.g. x-synkro-user-id)
        extra_headers = kwargs.pop("default_headers", None)
        if extra_headers:
            headers.update(extra_headers)

        lc_kwargs: dict[str, Any] = {
            "model": model,
            "base_url": gateway_url,
            "api_key": api_key or "x",
            "default_headers": headers,
            **kwargs,
        }

        return ChatOpenAI(**lc_kwargs)

    def litellm_kwargs(
        self,
        model: str,
        *,
        provider: str | None = None,
        api_key: str | None = None,
        conversation_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return kwargs for ``litellm.completion()`` pre-configured to route through the Synkro gateway.

        Args:
            model: Model name (e.g. ``"gemini-2.5-flash"``, ``"gpt-4o"``).
            provider: Provider hint for the gateway (e.g. ``"google"``, ``"openai"``).
            api_key: The *provider's* API key.
            conversation_id: Conversation ID for guard tracking. Auto-generated if omitted.
            **kwargs: Extra kwargs merged into the result (e.g. ``extra_body``).

        Returns:
            A dict of kwargs to spread into ``litellm.completion(**kwargs)``.

        Example::

            synkro = Synkro(api_key="sk-synkro-xxx", project="My Agent")
            kw = synkro.litellm_kwargs("gemini-2.5-flash", provider="google", api_key=GEMINI_KEY)
            response = litellm.completion(messages=[...], **kw)
        """
        proj = self.project
        gateway_url = f"{self._gateway_base}/v1/p/{proj.slug}"
        conv_id = conversation_id or str(uuid.uuid4())

        headers: dict[str, str] = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-conversation-id": conv_id,
        }
        if provider:
            headers["x-synkro-provider"] = provider

        # Merge any extra headers from kwargs
        extra_headers = kwargs.pop("extra_headers", None)
        if extra_headers:
            headers.update(extra_headers)

        result: dict[str, Any] = {
            "model": f"openai/{model}",
            "api_base": gateway_url,
            "api_key": api_key or "x",
            "extra_headers": headers,
            **kwargs,
        }

        return result

    def openai_client(
        self,
        project: str,
        upstream: str,
        api_key: str,
        *,
        timeout: float | None = None,
    ):
        """Create a drop-in OpenAI replacement with ``.synkro`` on responses.

        Works with any OpenAI-compatible endpoint (OpenAI, MindsDB, Ollama, etc.).
        Pass ``user_id`` and ``conversation_id`` per-call on ``.create()``.

        Args:
            project: Project slug.
            upstream: Upstream provider base URL (e.g. "https://api.openai.com/v1").
            api_key: The *provider's* API key.
            timeout: Request timeout in seconds (passed to OpenAI client).

        Returns:
            SynkroOpenAI instance.
        """
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError(
                "openai is required for synkro.openai_client(). "
                "Install it with: pip install openai"
            )

        from synkro.enterprise.openai_wrapper import SynkroOpenAI

        base_url = SYNKRO_GATEWAY_URL + "/v1/p/" + project
        headers = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-upstream": upstream,
        }

        kwargs: dict = {
            "base_url": base_url,
            "api_key": api_key,
            "default_headers": headers,
        }
        if timeout is not None:
            kwargs["timeout"] = timeout

        return SynkroOpenAI(OpenAI(**kwargs))

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Synkro:
        return self

    def __exit__(self, *args) -> None:
        self.close()


class AsyncSynkro:
    """Synkro enterprise client (asynchronous).

    Args:
        api_key: API key (sk-synkro-xxx).
        project: Project name for trace tap context.
        tap: Enable trace forwarding — ``"langsmith"``, ``"langfuse"``, or ``"all"``.
        gateway_url: Gateway URL for LLM proxying.
        base_url: CRUD server URL. Defaults to https://api.synkro.sh.
        timeout: Request timeout in seconds.

    Example::

        client = AsyncSynkro(
            api_key="sk-synkro-xxx",
            project="My Agent",
            tap="langfuse",
            gateway_url="http://localhost:8787/v1/p/proj_xxx",
        )
        resp = await client.chat.completions.create(
            model="gpt-4o", api_key=OPENAI_KEY, messages=[...],
            user_id="u1", conversation_id="conv-1",
        )
    """

    projects: AsyncProjects
    policies: AsyncPolicies
    integrations: AsyncIntegrations

    def __init__(
        self,
        api_key: str,
        *,
        project: str | None = None,
        tap: str | None = None,
        gateway_url: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._http = AsyncBaseHTTPClient(base_url=base_url, api_key=api_key, timeout=timeout)
        self.projects = AsyncProjects(self._http)
        self.policies = AsyncPolicies(self._http)
        self.integrations = AsyncIntegrations(self._http)

        # Enable trace tap if requested
        if tap:
            from synkro.enterprise.trace_tap import init as _tap_init
            _tap_init(api_key=api_key, project=project, tap=tap)

        if gateway_url:
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise ImportError(
                    "openai is required for gateway_url support. "
                    "Install it with: pip install openai"
                )

            from synkro.enterprise.openai_wrapper import AsyncSynkroClient

            oai_kwargs: dict = {
                "base_url": gateway_url,
                "api_key": "x",
                "default_headers": {"x-synkro-api-key": api_key},
            }
            if timeout != 30.0:
                oai_kwargs["timeout"] = timeout

            self._universal = AsyncSynkroClient(AsyncOpenAI(**oai_kwargs))
            self.chat = self._universal.chat

    def openai_client(
        self,
        project: str,
        upstream: str,
        api_key: str,
        *,
        timeout: float | None = None,
    ):
        """Create an async drop-in OpenAI replacement with ``.synkro`` on responses.

        Works with any OpenAI-compatible endpoint (OpenAI, MindsDB, Ollama, etc.).
        Pass ``user_id`` and ``conversation_id`` per-call on ``.create()``.

        Args:
            project: Project slug.
            upstream: Upstream provider base URL (e.g. "https://api.openai.com/v1").
            api_key: The *provider's* API key.
            timeout: Request timeout in seconds (passed to AsyncOpenAI client).

        Returns:
            AsyncSynkroOpenAI instance.
        """
        try:
            from openai import AsyncOpenAI
        except ImportError:
            raise ImportError(
                "openai is required for synkro.openai_client(). "
                "Install it with: pip install openai"
            )

        from synkro.enterprise.openai_wrapper import AsyncSynkroOpenAI

        base_url = SYNKRO_GATEWAY_URL + "/v1/p/" + project
        headers = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-upstream": upstream,
        }

        kwargs: dict = {
            "base_url": base_url,
            "api_key": api_key,
            "default_headers": headers,
        }
        if timeout is not None:
            kwargs["timeout"] = timeout

        return AsyncSynkroOpenAI(AsyncOpenAI(**kwargs))

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> AsyncSynkro:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
