#!/usr/bin/env python3
"""MCP Server for NetNam Odoo — exposes smart query tools for Claude."""

import json
import os
import sys
import urllib.request
import urllib.error

from mcp.server.fastmcp import FastMCP

# Configuration from environment
ODOO_URL = os.environ.get("ODOO_URL", "http://localhost:8069")
ODOO_DB = os.environ.get("ODOO_DB", "testninja")
ODOO_API_KEY = os.environ.get("ODOO_API_KEY", "")
ODOO_USER = os.environ.get("ODOO_USER", "admin")

mcp = FastMCP(
    "NetNam Odoo",
    instructions="Query NetNam Odoo data with smart filtering and aggregation for charts and reports",
)


def _mcp_request(endpoint: str, method: str = "GET", body: dict = None) -> dict:
    """Make HTTP request to Odoo MCP endpoints."""
    url = f"{ODOO_URL}{endpoint}"
    headers = {
        "X-API-Key": ODOO_API_KEY,
        "X-Odoo-Database": ODOO_DB,
        "Content-Type": "application/json",
    }
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        try:
            return json.loads(error_body)
        except json.JSONDecodeError:
            return {"success": False, "error": {"message": f"HTTP {e.code}: {error_body[:200]}"}}
    except Exception as e:
        return {"success": False, "error": {"message": str(e)}}


@mcp.tool()
def query_data(
    model: str,
    domain: list = None,
    groupby: list = None,
    fields: list = None,
    orderby: str = "",
    limit: int = 100,
    offset: int = 0,
) -> str:
    """Query Odoo data with filtering and aggregation. Best for charts and reports.

    Args:
        model: Odoo model name. Available models:
            - netnam.revenue.line: Revenue data (fields: user_id, actual_amount, plan_amount, fiscal_year[fy24/fy25], quarter[q1-q4], loai_doanh_thu, nhom_dv, department_id, vung_mien)
            - netnam.revenue.plan: Revenue plans
            - netnam.service.contract: Service contracts
            - netnam.customer.visit: Customer visit logs
            - netnam.ets.deal: ETS deals
            - netnam.sla.policy: SLA policies
            - help.ticket: Helpdesk tickets (fields: department_id, ticket_type, sla_state, priority, create_date, vung_mien, root_cause)
            - netnam.ticket.escalation: Ticket escalation history
            - hr.employee: Employees
            - crm.lead: CRM leads/opportunities
            - res.partner: Contacts/Customers
            - res.users: Users
        domain: Odoo domain filter, e.g. [["fiscal_year", "=", "fy25"], ["department_id", "!=", false]]
        groupby: Fields to group by for aggregation. When set, returns aggregated data via read_group.
            For date fields, append :month, :quarter, :year, e.g. ["create_date:month"]
        fields: Fields to return. For groupby queries, use "field:agg" format, e.g. ["actual_amount:sum", "id:count"]
        orderby: Sort order, e.g. "actual_amount desc"
        limit: Max records (default 100, max 500)
        offset: Skip N records for pagination

    Returns:
        JSON with aggregated or raw data ready for chart rendering.

    Examples:
        Top 5 salespeople by revenue:
            model="netnam.revenue.line", domain=[["fiscal_year","=","fy25"]], groupby=["user_id"], fields=["actual_amount:sum"], orderby="actual_amount desc", limit=5

        Monthly ticket count:
            model="help.ticket", domain=[], groupby=["create_date:month"], fields=["id:count"], limit=12

        Revenue by quarter and department:
            model="netnam.revenue.line", domain=[["fiscal_year","=","fy25"]], groupby=["quarter","department_id"], fields=["actual_amount:sum"]
    """
    result = _mcp_request("/mcp/query", method="POST", body={
        "model": model,
        "domain": domain or [],
        "groupby": groupby or [],
        "fields": fields or [],
        "orderby": orderby,
        "limit": limit,
        "offset": offset,
    })

    if not result.get("success"):
        return json.dumps({"error": result.get("error", {}).get("message", "Unknown error")})

    return json.dumps(result["data"], ensure_ascii=False, indent=2)


@mcp.tool()
def list_models() -> str:
    """List all Odoo models available for MCP queries."""
    result = _mcp_request("/mcp/models")
    if not result.get("success"):
        return json.dumps({"error": result.get("error", {}).get("message", "Unknown error")})
    return json.dumps(result["data"], ensure_ascii=False, indent=2)


@mcp.tool()
def get_model_fields(model: str) -> str:
    """Get field definitions for an Odoo model. Useful to understand what data is available before querying.

    Args:
        model: Odoo model name, e.g. "netnam.revenue.line"

    Returns:
        Field names, types, and descriptions.
    """
    import xmlrpc.client
    try:
        common = xmlrpc.client.ServerProxy(f"{ODOO_URL}/mcp/xmlrpc/common")
        uid = common.authenticate(ODOO_DB, ODOO_USER, ODOO_API_KEY, {})
        if not uid:
            return json.dumps({"error": "Authentication failed"})

        obj = xmlrpc.client.ServerProxy(f"{ODOO_URL}/mcp/xmlrpc/object")
        fields = obj.execute_kw(
            ODOO_DB, uid, ODOO_API_KEY,
            model, "fields_get", [],
            {"attributes": ["string", "type", "selection", "relation", "help"]}
        )

        # Filter to useful fields only
        result = {}
        skip_types = {"binary", "html", "reference"}
        for name, info in sorted(fields.items()):
            if info["type"] in skip_types:
                continue
            if name.startswith("__"):
                continue
            entry = {"type": info["type"], "label": info.get("string", "")}
            if info.get("selection"):
                entry["options"] = info["selection"]
            if info.get("relation"):
                entry["relation"] = info["relation"]
            result[name] = entry

        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def search_records(
    model: str,
    domain: list = None,
    fields: list = None,
    orderby: str = "",
    limit: int = 20,
    offset: int = 0,
) -> str:
    """Search and read individual records from Odoo. Use query_data with groupby for aggregated reports.

    Args:
        model: Odoo model name
        domain: Filter conditions, e.g. [["name", "ilike", "NetNam"]]
        fields: List of field names to return. Empty = all fields.
        orderby: Sort order, e.g. "create_date desc"
        limit: Max records (default 20, max 500)
        offset: Pagination offset

    Returns:
        List of matching records.
    """
    result = _mcp_request("/mcp/query", method="POST", body={
        "model": model,
        "domain": domain or [],
        "groupby": [],
        "fields": fields or [],
        "orderby": orderby,
        "limit": limit,
        "offset": offset,
    })

    if not result.get("success"):
        return json.dumps({"error": result.get("error", {}).get("message", "Unknown error")})

    return json.dumps(result["data"], ensure_ascii=False, indent=2)


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
