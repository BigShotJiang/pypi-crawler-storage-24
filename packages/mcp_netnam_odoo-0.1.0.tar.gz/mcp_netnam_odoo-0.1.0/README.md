# mcp-netnam-odoo

MCP server for querying Odoo ERP with smart aggregation — designed for AI assistants to generate charts and reports.

## Features

- **query_data** — Aggregate data with domain filters, groupby, and sorting (uses `read_group`)
- **search_records** — Search individual records with filters
- **list_models** — List available models
- **get_model_fields** — Inspect model field definitions

## Requirements

- Odoo 16+ with the `mcp_server` module installed
- API key generated in Odoo (Settings > Users > API Keys)

## Installation

```bash
pip install mcp-netnam-odoo
```

## Configuration

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "netnam": {
      "command": "mcp-netnam-odoo",
      "env": {
        "ODOO_URL": "http://your-odoo-server:8069",
        "ODOO_DB": "your_database",
        "ODOO_API_KEY": "your_api_key",
        "ODOO_USER": "your_login"
      }
    }
  }
}
```

### Claude Code

Add to `.mcp.json` in your project:

```json
{
  "mcpServers": {
    "netnam": {
      "command": "mcp-netnam-odoo",
      "env": {
        "ODOO_URL": "http://your-odoo-server:8069",
        "ODOO_DB": "your_database",
        "ODOO_API_KEY": "your_api_key",
        "ODOO_USER": "your_login"
      }
    }
  }
}
```

## Example queries

- "Top 5 salespeople by revenue this fiscal year"
- "Monthly ticket count as a bar chart"
- "Revenue breakdown by department and quarter"
