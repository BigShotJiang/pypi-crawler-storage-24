# agentable

Official Python package for Agentable.

## Status

`agentable` is currently a bootstrap release.

This package is published as the official Python entry for Agentable on PyPI.
It is intentionally minimal at this stage.

Future releases are expected to distribute the official Agentable CLI and related binaries.

## Installation

```bash
pip install agentable
```

## Usage

```bash
agentable
agentable --version
python -m agentable
```

## Notes

- This is the official `agentable` package on PyPI.
- This package is currently minimal by design.
- Source code for Agentable is not published at this time.

## Links

- Homepage: https://agentable.ai
- Documentation: https://agentable.ai/docs
- Support: https://agentable.ai/support

## License

Proprietary.
