import argparse

from agentable import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentable",
        description="Official Python package for Agentable.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main() -> int:
    parser = build_parser()
    parser.parse_args()

    print("Agentable")
    print(f"Version: {__version__}")
    print("Status: bootstrap release")
    print("This is the official Agentable package on PyPI.")
    print("Future releases will distribute the official Agentable CLI and related binaries.")
    return 0
