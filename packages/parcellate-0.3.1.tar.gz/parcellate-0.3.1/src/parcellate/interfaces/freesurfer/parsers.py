"""Parsers for FreeSurfer statistics files.

FreeSurfer produces two distinct ``.stats`` file formats:

- **mri_segstats** output: space-separated rows, headers in ``# ColHeaders``
  comment line. Used for volumetric atlases (aseg, wmparc, custom volume).
- **mris_anatomical_stats** output: space-separated rows, headers in
  ``# ColHeaders`` comment line. Used for surface atlases (aparc, custom
  annot/gcs).

Both formats share the same comment-header convention but differ in the
column names and data types present.
"""

from __future__ import annotations

import io
import logging
from pathlib import Path

import pandas as pd

from parcellate.interfaces.freesurfer.models import FreeSurferStatsType

LOGGER = logging.getLogger(__name__)

# Standardised column name mappings for mri_segstats output.
_SEGSTATS_COLUMN_MAP: dict[str, str] = {
    "Index": "region_index",
    "SegId": "segment_id",
    "NVoxels": "n_voxels",
    "Volume_mm3": "volume_mm3",
    "StructName": "region_name",
    "Mean": "intensity_mean",
    "StdDev": "intensity_std",
    "Min": "intensity_min",
    "Max": "intensity_max",
    "Range": "intensity_range",
}

# Standardised column name mappings for mris_anatomical_stats output.
_ANATSTAT_COLUMN_MAP: dict[str, str] = {
    "StructName": "region_name",
    "NumVert": "n_vertices",
    "SurfArea": "surface_area_mm2",
    "GrayVol": "gray_matter_volume_mm3",
    "ThickAvg": "thickness_mean",
    "ThickStd": "thickness_std",
    "MeanCurv": "mean_curvature",
    "GausCurv": "gaussian_curvature",
    "FoldInd": "folding_index",
    "CurvInd": "curvature_index",
}


def _read_stats_lines(stats_path: Path) -> tuple[list[str], list[str]]:
    """Return (comment_lines, data_lines) from a FreeSurfer .stats file.

    Parameters
    ----------
    stats_path:
        Path to the ``.stats`` file.

    Returns
    -------
    tuple[list[str], list[str]]
        Comment lines (including ``#``) and data lines (non-comment, non-empty).
    """
    text = stats_path.read_text()
    comment_lines: list[str] = []
    data_lines: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            comment_lines.append(stripped)
        elif stripped:
            data_lines.append(stripped)
    return comment_lines, data_lines


def _parse_col_headers(comment_lines: list[str]) -> list[str] | None:
    """Extract column names from the ``# ColHeaders`` comment line.

    Parameters
    ----------
    comment_lines:
        All comment lines from the ``.stats`` file.

    Returns
    -------
    list[str] | None
        Column names in order, or ``None`` if no ``ColHeaders`` line is found.
    """
    for line in comment_lines:
        if "ColHeaders" in line:
            # Format: "# ColHeaders  col1 col2 col3 ..."
            parts = line.split()
            # Drop "#" and "ColHeaders"
            idx = parts.index("ColHeaders")
            return parts[idx + 1 :]
    return None


def parse_segstats(stats_path: Path) -> pd.DataFrame:
    """Parse a ``mri_segstats`` output file into a standardised DataFrame.

    The returned DataFrame contains a subset of columns from the raw file,
    renamed to the standardised names in :data:`_SEGSTATS_COLUMN_MAP`. Any
    raw columns not in the map are preserved under their original names.

    Parameters
    ----------
    stats_path:
        Path to the ``mri_segstats`` ``.stats`` file.

    Returns
    -------
    pd.DataFrame
        One row per brain segment with standardised column names.

    Raises
    ------
    ValueError
        If no ``# ColHeaders`` line is found in the file.
    """
    comment_lines, data_lines = _read_stats_lines(stats_path)
    columns = _parse_col_headers(comment_lines)
    if columns is None:
        raise ValueError(f"No '# ColHeaders' line found in {stats_path}")  # noqa: TRY003

    text_block = "\n".join(data_lines)
    df = pd.read_csv(io.StringIO(text_block), sep=r"\s+", header=None, names=columns)
    df = df.rename(columns={k: v for k, v in _SEGSTATS_COLUMN_MAP.items() if k in df.columns})
    return df


def parse_anatomical_stats(stats_path: Path) -> pd.DataFrame:
    """Parse a ``mris_anatomical_stats`` output file into a standardised DataFrame.

    The returned DataFrame contains a subset of columns from the raw file,
    renamed to the standardised names in :data:`_ANATSTAT_COLUMN_MAP`. Any
    raw columns not in the map are preserved under their original names.

    Parameters
    ----------
    stats_path:
        Path to the ``mris_anatomical_stats`` ``.stats`` file.

    Returns
    -------
    pd.DataFrame
        One row per cortical region with standardised column names.

    Raises
    ------
    ValueError
        If no ``# ColHeaders`` line is found in the file.
    """
    comment_lines, data_lines = _read_stats_lines(stats_path)
    columns = _parse_col_headers(comment_lines)
    if columns is None:
        raise ValueError(f"No '# ColHeaders' line found in {stats_path}")  # noqa: TRY003

    text_block = "\n".join(data_lines)
    df = pd.read_csv(io.StringIO(text_block), sep=r"\s+", header=None, names=columns)
    df = df.rename(columns={k: v for k, v in _ANATSTAT_COLUMN_MAP.items() if k in df.columns})
    return df


def parse_stats_file(stats_path: Path, stats_type: FreeSurferStatsType) -> pd.DataFrame:
    """Dispatch to the appropriate parser based on stats type.

    Parameters
    ----------
    stats_path:
        Path to the ``.stats`` file to parse.
    stats_type:
        Whether this is a surface or volume stats file.

    Returns
    -------
    pd.DataFrame
        Parsed statistics.
    """
    if stats_type == FreeSurferStatsType.VOLUME:
        return parse_segstats(stats_path)
    return parse_anatomical_stats(stats_path)


def extract_stats_metadata(stats_path: Path) -> dict[str, str]:
    """Extract provenance metadata from comment headers of a ``.stats`` file.

    Looks for ``# key value`` pairs such as::

        # subjectname  sub-01
        # CreationTime 2024-01-01T12:00:00
        # BuildStamp   freesurfer-linux-ubuntu22_x86_64-7.4.1
        # SUBJECTS_DIR /path/to/subjects

    Parameters
    ----------
    stats_path:
        Path to the ``.stats`` file.

    Returns
    -------
    dict[str, str]
        Mapping of metadata key → value extracted from comment lines.
    """
    comment_lines, _ = _read_stats_lines(stats_path)
    metadata: dict[str, str] = {}
    for line in comment_lines:
        parts = line.lstrip("#").split(None, 1)
        if len(parts) == 2:
            key, value = parts
            key = key.strip()
            value = value.strip()
            if key and value and key != "ColHeaders":
                metadata[key] = value
    return metadata
