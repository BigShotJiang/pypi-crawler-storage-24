"""FreeSurfer parcellation interface for parcellate.

This package provides a native FreeSurfer interface that shells out to
FreeSurfer commands (``mri_segstats``, ``mris_anatomical_stats``) to extract
regional brain statistics from FreeSurfer ``recon-all`` outputs.

Supported atlas types
---------------------
- ``builtin_surface`` — built-in FreeSurfer surface parcellations (aparc,
  aparc.a2009s, aparc.DKTatlas).
- ``builtin_volume`` — built-in volumetric segmentations (aseg, aparc+aseg,
  wmparc).

Example usage::

    from parcellate.interfaces.freesurfer.freesurfer import load_config, run_parcellations
"""

from parcellate.interfaces.freesurfer.freesurfer import load_config, run_parcellations
from parcellate.interfaces.freesurfer.models import (
    FreeSurferAtlasDefinition,
    FreeSurferAtlasType,
    FreeSurferConfig,
    FreeSurferOverlay,
    FreeSurferParcellationOutput,
    FreeSurferStatsType,
    FreeSurferSubjectData,
)

__all__ = [
    "FreeSurferAtlasDefinition",
    "FreeSurferAtlasType",
    "FreeSurferConfig",
    "FreeSurferOverlay",
    "FreeSurferParcellationOutput",
    "FreeSurferStatsType",
    "FreeSurferSubjectData",
    "load_config",
    "run_parcellations",
]
