"""Discover and validate FreeSurfer recon-all outputs.

This module handles:

- Verifying the FreeSurfer environment (executables, FREESURFER_HOME).
- Discovering subject directories from a ``SUBJECTS_DIR``-like root.
- Validating minimum required files for each subject.
- Ensuring ``fsaverage`` is available for custom ``.annot`` atlases.
- Assembling :class:`~parcellate.interfaces.freesurfer.models.FreeSurferSubjectData`
  objects from config + filesystem.
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

from parcellate.interfaces.freesurfer.models import (
    FreeSurferConfig,
    FreeSurferSubjectData,
    SubjectContext,
)

LOGGER = logging.getLogger(__name__)

#: Minimum files that must exist for a subject to be considered valid.
_REQUIRED_FILES: list[str] = [
    "mri/brain.mgz",
    "surf/lh.white",
    "surf/rh.white",
    "label/lh.aparc.annot",
]

#: FreeSurfer executables that must be on PATH (or under FREESURFER_HOME/bin).
_REQUIRED_EXECUTABLES: list[str] = [
    "mri_segstats",
    "mris_anatomical_stats",
]


def validate_freesurfer_env(config: FreeSurferConfig) -> Path:
    """Verify that FreeSurfer is installed and the environment is usable.

    Checks that ``FREESURFER_HOME`` is set (via ``config.freesurfer_home`` or
    the ``$FREESURFER_HOME`` environment variable) and that key executables
    are present.

    Parameters
    ----------
    config:
        FreeSurfer parcellation configuration.

    Returns
    -------
    Path
        Resolved path to ``FREESURFER_HOME``.

    Raises
    ------
    EnvironmentError
        If ``FREESURFER_HOME`` cannot be determined or required executables
        are missing.
    """
    fs_home: Path | None = config.freesurfer_home
    if fs_home is None:
        env_val = os.environ.get("FREESURFER_HOME")
        if env_val:
            fs_home = Path(env_val)
    if fs_home is None:
        raise OSError(  # noqa: TRY003
            "FreeSurfer home directory not found. Set $FREESURFER_HOME or specify 'freesurfer_home' in the config."
        )
    fs_home = fs_home.expanduser().resolve()
    if not fs_home.is_dir():
        raise OSError(f"FREESURFER_HOME does not exist or is not a directory: {fs_home}")  # noqa: TRY003

    missing: list[str] = []
    for exe in _REQUIRED_EXECUTABLES:
        # Check PATH first, then $FREESURFER_HOME/bin.
        if shutil.which(exe) is None and not (fs_home / "bin" / exe).is_file():
            missing.append(exe)
    if missing:
        raise OSError(f"Required FreeSurfer executables not found on PATH or in {fs_home}/bin: " + ", ".join(missing))

    LOGGER.debug("FreeSurfer home validated: %s", fs_home)
    return fs_home


def validate_subject(subjects_dir: Path, subject_id: str) -> bool:
    """Check whether a subject directory has the minimum required files.

    Parameters
    ----------
    subjects_dir:
        Root directory containing per-subject FreeSurfer outputs.
    subject_id:
        Subject identifier (e.g. ``"sub-01"``).

    Returns
    -------
    bool
        ``True`` if all required files exist; ``False`` otherwise (with
        warnings logged for each missing file).
    """
    subject_dir = subjects_dir / subject_id
    valid = True
    for rel_path in _REQUIRED_FILES:
        fpath = subject_dir / rel_path
        if not fpath.exists():
            LOGGER.warning("Missing required file for %s: %s", subject_id, fpath)
            valid = False
    return valid


def _discover_subjects(subjects_dir: Path, filter_subjects: list[str] | None = None) -> list[str]:
    """Discover subject directories under ``subjects_dir``.

    Accepts both BIDS-style (``sub-*``) and plain FreeSurfer-style directories
    (any directory containing ``mri/brain.mgz``).

    Parameters
    ----------
    subjects_dir:
        Root directory to search in.
    filter_subjects:
        If provided, only return subjects matching these identifiers.

    Returns
    -------
    list[str]
        Sorted list of discovered subject identifiers.
    """
    found: list[str] = []
    if not subjects_dir.is_dir():
        LOGGER.warning("subjects_dir does not exist: %s", subjects_dir)
        return found

    for candidate in sorted(subjects_dir.iterdir()):
        if not candidate.is_dir():
            continue
        name = candidate.name
        # Skip fsaverage and other FreeSurfer template subjects.
        if name in {"fsaverage", "fsaverage5", "fsaverage6", "cvs_avg35_inMNI152"}:
            continue
        # Accept BIDS-style (sub-*) or any directory containing mri/brain.mgz.
        if (name.startswith("sub-") or (candidate / "mri" / "brain.mgz").exists()) and (
            filter_subjects is None or name in filter_subjects
        ):
            found.append(name)

    LOGGER.debug("Discovered %d subject(s) in %s", len(found), subjects_dir)
    return found


def load_freesurfer_inputs(config: FreeSurferConfig) -> list[FreeSurferSubjectData]:
    """Discover and validate FreeSurfer subject data from a config.

    This is the primary entry point for the loader. It:

    1. Resolves ``subjects_dir`` (defaulting to ``config.input_root``).
    2. Validates the FreeSurfer environment.
    3. Discovers subject directories.
    4. Validates each subject.
    5. Assembles :class:`~parcellate.interfaces.freesurfer.models.FreeSurferSubjectData`
       for each valid subject.

    Parameters
    ----------
    config:
        FreeSurfer parcellation configuration.

    Returns
    -------
    list[FreeSurferSubjectData]
        One entry per valid subject/session.
    """
    subjects_dir = config.subjects_dir or config.input_root
    subjects_dir = subjects_dir.expanduser().resolve()

    validate_freesurfer_env(config)

    subject_ids = _discover_subjects(subjects_dir, filter_subjects=config.subjects)
    if not subject_ids:
        LOGGER.warning("No subjects found in %s", subjects_dir)
        return []

    inputs: list[FreeSurferSubjectData] = []
    for subject_id in subject_ids:
        if not validate_subject(subjects_dir, subject_id):
            LOGGER.warning("Skipping invalid subject: %s", subject_id)
            continue

        # Determine session: FreeSurfer directories are typically flat
        # (no per-session subdirectory). We store the session from config if
        # only one session is specified, otherwise leave it None.
        session_id: str | None = None
        if config.sessions and len(config.sessions) == 1:
            session_id = config.sessions[0]

        # Strip 'sub-' prefix if present: SubjectContext.subject_id should be
        # the bare BIDS label (e.g. "CLMC10"), not the directory name.
        bids_subject_id = subject_id.removeprefix("sub-")
        context = SubjectContext(subject_id=bids_subject_id, session_id=session_id)
        subject_dir = subjects_dir / subject_id

        inputs.append(
            FreeSurferSubjectData(
                context=context,
                subject_dir=subject_dir,
                atlases=list(config.fs_atlases),
                overlays=list(config.overlays),
            )
        )
        LOGGER.debug("Loaded subject: %s", subject_id)

    LOGGER.info("Loaded %d valid FreeSurfer subject(s)", len(inputs))
    return inputs
