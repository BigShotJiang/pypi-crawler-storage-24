"""Execute FreeSurfer parcellation commands via subprocess.

All FreeSurfer commands are run as list-form subprocess calls (no
``shell=True``) with a configurable timeout. The module exposes one workflow
function per atlas type plus a top-level dispatcher that processes all atlases
for a given subject.

Command reference
-----------------
- ``mris_anatomical_stats``: surface-based parcellation statistics.
- ``mri_segstats``: volume-based segmentation statistics.
"""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

from parcellate.interfaces.freesurfer.models import (
    BUILTIN_VOLUME_ATLASES,
    FreeSurferAtlasDefinition,
    FreeSurferConfig,
    FreeSurferOverlay,
    FreeSurferParcellationOutput,
    FreeSurferStatsType,
    FreeSurferSubjectData,
)
from parcellate.interfaces.freesurfer.parsers import parse_stats_file
from parcellate.interfaces.models import SubjectContext

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_env(config: FreeSurferConfig) -> dict[str, str]:
    """Build the subprocess environment with FreeSurfer variables set.

    Parameters
    ----------
    config:
        FreeSurfer configuration containing ``subjects_dir`` and
        ``freesurfer_home``.

    Returns
    -------
    dict[str, str]
        A copy of the current environment with ``SUBJECTS_DIR`` and
        ``FREESURFER_HOME`` set.
    """
    env = os.environ.copy()
    subjects_dir = config.subjects_dir or config.input_root
    env["SUBJECTS_DIR"] = str(subjects_dir.expanduser().resolve())
    if config.freesurfer_home is not None:
        env["FREESURFER_HOME"] = str(config.freesurfer_home.expanduser().resolve())
    # Ensure FreeSurfer bin is on PATH.
    fs_home = env.get("FREESURFER_HOME", "")
    if fs_home:
        bin_dir = str(Path(fs_home) / "bin")
        path = env.get("PATH", "")
        if bin_dir not in path.split(os.pathsep):
            env["PATH"] = bin_dir + os.pathsep + path
    return env


def _run_command(
    cmd: list[str],
    env: dict[str, str],
    timeout: int,
) -> subprocess.CompletedProcess[str]:
    """Run a FreeSurfer command and raise on failure.

    Parameters
    ----------
    cmd:
        Command and arguments as a list (never ``shell=True``).
    env:
        Environment variables for the subprocess.
    timeout:
        Maximum seconds to wait for the command to finish.

    Returns
    -------
    subprocess.CompletedProcess[str]
        The completed process object.

    Raises
    ------
    RuntimeError
        If the command exits with a non-zero return code.
    subprocess.TimeoutExpired
        If the command does not complete within ``timeout`` seconds.
    """
    LOGGER.debug("Running: %s", " ".join(cmd))
    result = subprocess.run(  # noqa: S603
        cmd,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        raise RuntimeError(  # noqa: TRY003
            f"FreeSurfer command failed (exit {result.returncode}):\n"
            f"  cmd: {' '.join(cmd)}\n"
            f"  stderr: {result.stderr.strip()}"
        )
    return result


# ---------------------------------------------------------------------------
# Surface atlas workflows
# ---------------------------------------------------------------------------


def run_builtin_surface(
    subject_id: str,
    atlas_name: str,
    hemi: str,
    config: FreeSurferConfig,
    overlay: FreeSurferOverlay | None = None,
) -> tuple[Path, str]:
    """Run ``mris_anatomical_stats`` for a built-in surface atlas.

    Parameters
    ----------
    subject_id:
        FreeSurfer subject identifier.
    atlas_name:
        Built-in atlas name (e.g. ``"aparc"``, ``"aparc.a2009s"``).
    hemi:
        Hemisphere to process (``"lh"`` or ``"rh"``).
    config:
        FreeSurfer configuration.
    overlay:
        Optional overlay to extract statistics from. When provided,
        ``-t {overlay.path}`` is appended to the command.

    Returns
    -------
    tuple[Path, str]
        Path to the generated ``.stats`` file and the command string.
    """
    subjects_dir = config.subjects_dir or config.input_root
    subjects_dir = subjects_dir.expanduser().resolve()
    stats_file = subjects_dir / subject_id / "stats" / f"{hemi}.{atlas_name}.stats"

    cmd = ["mris_anatomical_stats", "-a", atlas_name, "-b", "-f", str(stats_file)]
    if overlay is not None:
        cmd += ["-t", str(overlay.path)]
    cmd += [subject_id, hemi]

    env = _build_env(config)
    _run_command(cmd, env=env, timeout=config.command_timeout)
    return stats_file, " ".join(cmd)


# ---------------------------------------------------------------------------
# Volume atlas workflows
# ---------------------------------------------------------------------------


def run_builtin_volume(
    subject_id: str,
    atlas_name: str,
    config: FreeSurferConfig,
    overlay: FreeSurferOverlay | None = None,
) -> tuple[Path, str]:
    """Run ``mri_segstats`` for a built-in volumetric atlas.

    Parameters
    ----------
    subject_id:
        FreeSurfer subject identifier.
    atlas_name:
        Built-in atlas name (e.g. ``"aseg"``, ``"aparc+aseg"``).
    config:
        FreeSurfer configuration.
    overlay:
        Optional overlay (e.g. an fMRI map). When omitted, ``mri_segstats``
        uses the default intensity image (``mri/brain.mgz``).

    Returns
    -------
    tuple[Path, str]
        Path to the generated ``.stats`` file and the command string.
    """
    subjects_dir = config.subjects_dir or config.input_root
    subjects_dir = subjects_dir.expanduser().resolve()
    subject_dir = subjects_dir / subject_id

    seg_file = BUILTIN_VOLUME_ATLASES.get(atlas_name, f"{atlas_name}.mgz")
    seg_path = subject_dir / "mri" / seg_file
    stats_file = subject_dir / "stats" / f"{atlas_name}.stats"

    cmd = [
        "mri_segstats",
        "--seg",
        str(seg_path),
        "--subject",
        subject_id,
        "--excludeid",
        "0",
        "--sum",
        str(stats_file),
    ]
    if overlay is not None:
        cmd += ["--i", str(overlay.path)]
    else:
        # Use the normalised brain as default intensity image.
        brain_path = subject_dir / "mri" / "brain.mgz"
        cmd += ["--i", str(brain_path)]

    env = _build_env(config)
    _run_command(cmd, env=env, timeout=config.command_timeout)
    return stats_file, " ".join(cmd)


# ---------------------------------------------------------------------------
# Top-level dispatcher
# ---------------------------------------------------------------------------


def run_parcellation_for_subject(
    subject_data: FreeSurferSubjectData,
    config: FreeSurferConfig,
) -> list[FreeSurferParcellationOutput]:
    """Run all configured atlas parcellations for a single subject.

    Iterates over every atlas in ``subject_data.atlases`` and dispatches to
    the appropriate workflow. Surface atlases are looped over hemispheres;
    volume atlases run once. When overlays are configured, each combination
    of (atlas x hemisphere x overlay) is run independently.

    Parameters
    ----------
    subject_data:
        Discovered subject data (directory, atlases, overlays).
    config:
        FreeSurfer configuration (hemispheres, timeout, etc.).

    Returns
    -------
    list[FreeSurferParcellationOutput]
        All parcellation results for this subject.
    """
    # Use the actual FreeSurfer directory name (e.g. "sub-CLMC10_ses-01")
    # for commands and path construction; context holds the BIDS label.
    fs_subject_id = subject_data.subject_dir.name
    context = subject_data.context
    outputs: list[FreeSurferParcellationOutput] = []

    # Build overlay list: None means "no overlay" (default stats).
    overlays: list[FreeSurferOverlay | None] = [None]
    if subject_data.overlays:
        overlays = list(subject_data.overlays)

    for atlas in subject_data.atlases:
        for overlay in overlays:
            try:
                _run_atlas(fs_subject_id, atlas, overlay, config, outputs, context)
            except Exception:
                LOGGER.exception(
                    "Failed parcellation for %s | atlas=%s | overlay=%s",
                    fs_subject_id,
                    atlas.name,
                    overlay.name if overlay else "none",
                )

    return outputs


def _run_atlas(
    subject_id: str,
    atlas: FreeSurferAtlasDefinition,
    overlay: FreeSurferOverlay | None,
    config: FreeSurferConfig,
    outputs: list[FreeSurferParcellationOutput],
    context: SubjectContext,
) -> None:
    """Dispatch a single atlas run and append results to ``outputs``.

    Internal helper used by :func:`run_parcellation_for_subject`.
    ``subject_id`` is the FreeSurfer directory name (used for commands and
    path construction); ``context`` carries the BIDS-compliant identifiers
    stored in the output objects.
    """
    if atlas.stats_type == FreeSurferStatsType.SURFACE:
        for hemi in config.hemispheres:
            stats_file, cmd = _dispatch_surface(subject_id, atlas, hemi, config, overlay)
            df = parse_stats_file(stats_file, atlas.stats_type)
            outputs.append(
                FreeSurferParcellationOutput(
                    context=context,
                    atlas=atlas,
                    hemisphere=hemi,
                    overlay=overlay,
                    stats_table=df,
                    stats_file=stats_file,
                    command=cmd,
                )
            )
    else:
        stats_file, cmd = _dispatch_volume(subject_id, atlas, config, overlay)
        df = parse_stats_file(stats_file, atlas.stats_type)
        outputs.append(
            FreeSurferParcellationOutput(
                context=context,
                atlas=atlas,
                hemisphere=None,
                overlay=overlay,
                stats_table=df,
                stats_file=stats_file,
                command=cmd,
            )
        )


def _dispatch_surface(
    subject_id: str,
    atlas: FreeSurferAtlasDefinition,
    hemi: str,
    config: FreeSurferConfig,
    overlay: FreeSurferOverlay | None,
) -> tuple[Path, str]:
    """Dispatch to the correct surface workflow for a given atlas type."""
    return run_builtin_surface(subject_id, atlas.name, hemi, config, overlay)


def _dispatch_volume(
    subject_id: str,
    atlas: FreeSurferAtlasDefinition,
    config: FreeSurferConfig,
    overlay: FreeSurferOverlay | None,
) -> tuple[Path, str]:
    """Dispatch to the correct volume workflow for a given atlas type."""
    return run_builtin_volume(subject_id, atlas.name, config, overlay)
