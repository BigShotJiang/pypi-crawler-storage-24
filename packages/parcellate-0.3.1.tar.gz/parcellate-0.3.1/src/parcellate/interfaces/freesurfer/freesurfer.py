"""Main orchestrator for the FreeSurfer parcellation interface.

This module provides:

- :func:`load_config` — parse TOML configuration into a
  :class:`~parcellate.interfaces.freesurfer.models.FreeSurferConfig`.
- :func:`run_parcellations` — orchestrate the full workflow (load inputs,
  run per-subject parcellation, write outputs).
- Helper functions for building output paths and writing TSV + JSON outputs.

CLI usage (BIDS App)::

    parcellate /path/to/freesurfer_subjects /path/to/output participant \\
        --pipeline freesurfer --config freesurfer_config.toml

Legacy usage (deprecated)::

    parcellate freesurfer freesurfer_config.toml
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

from parcellate.interfaces.freesurfer.loader import load_freesurfer_inputs, validate_freesurfer_env
from parcellate.interfaces.freesurfer.models import (
    FreeSurferAtlasDefinition,
    FreeSurferAtlasType,
    FreeSurferConfig,
    FreeSurferOverlay,
    FreeSurferParcellationOutput,
    FreeSurferSubjectData,
)
from parcellate.interfaces.freesurfer.runner import run_parcellation_for_subject
from parcellate.interfaces.shared import run_parallel_workflow
from parcellate.interfaces.utils import _as_list, _parse_log_level

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------


def _parse_fs_atlases(atlas_configs: list[dict[str, object]]) -> list[FreeSurferAtlasDefinition]:
    """Parse a list of atlas config dicts into FreeSurferAtlasDefinition objects.

    Each dict must have ``name`` and ``type`` keys. For custom atlas types
    (``custom_annot``, ``custom_gcs``, ``custom_volume``) a ``path`` key is
    required. Optionally, ``color_lut`` and ``space`` may be set.

    Parameters
    ----------
    atlas_configs:
        List of raw atlas configuration dictionaries from the TOML file.

    Returns
    -------
    list[FreeSurferAtlasDefinition]
        Validated atlas definitions.

    Raises
    ------
    ValueError
        If required fields are missing or the ``type`` is unrecognised.
    """
    atlases: list[FreeSurferAtlasDefinition] = []
    for cfg in atlas_configs:
        name = cfg.get("name")
        type_str = cfg.get("type")
        if not name or not type_str:
            LOGGER.warning("Skipping atlas with missing 'name' or 'type': %s", cfg)
            continue
        try:
            atlas_type = FreeSurferAtlasType(type_str)
        except ValueError as exc:
            raise ValueError(  # noqa: TRY003
                f"Unknown atlas type '{type_str}' for atlas '{name}'. "
                f"Valid types: {[t.value for t in FreeSurferAtlasType]}"
            ) from exc

        atlases.append(
            FreeSurferAtlasDefinition(
                name=str(name),
                atlas_type=atlas_type,
            )
        )
    return atlases


def _parse_overlays(overlay_configs: list[dict[str, object]]) -> list[FreeSurferOverlay]:
    """Parse overlay configuration dicts into :class:`FreeSurferOverlay` objects.

    Parameters
    ----------
    overlay_configs:
        List of raw overlay configuration dictionaries.

    Returns
    -------
    list[FreeSurferOverlay]
        Validated overlay definitions.
    """
    overlays: list[FreeSurferOverlay] = []
    for cfg in overlay_configs:
        name = cfg.get("name")
        path_str = cfg.get("path")
        overlay_type = cfg.get("type", "volume")
        if not name or not path_str:
            LOGGER.warning("Skipping overlay with missing 'name' or 'path': %s", cfg)
            continue
        overlays.append(
            FreeSurferOverlay(
                name=str(name),
                path=Path(str(path_str)).expanduser().resolve(),
                overlay_type=str(overlay_type),
                hemisphere=str(cfg["hemisphere"]) if cfg.get("hemisphere") else None,
            )
        )
    return overlays


def load_config(args: argparse.Namespace) -> FreeSurferConfig:
    """Parse a TOML configuration file and override with CLI arguments.

    Supports all keys defined by :class:`~parcellate.interfaces.freesurfer.models.FreeSurferConfig`.
    CLI arguments override the corresponding TOML values when both are
    provided.

    Parameters
    ----------
    args:
        Parsed CLI arguments. Expected attributes: ``config``, ``input_root``,
        ``output_dir``, ``subjects``, ``sessions``, ``force``, ``log_level``,
        ``n_jobs``, ``n_procs``.

    Returns
    -------
    FreeSurferConfig
        Fully initialised configuration object.
    """
    data: dict[str, object] = {}
    if args.config:
        with args.config.open("rb") as f:
            data = tomllib.load(f)

    input_root_str = args.input_root or data.get("input_root", ".")
    input_root = Path(str(input_root_str)).expanduser().resolve()

    output_dir_str = args.output_dir or data.get("output_dir", input_root / "parcellations")
    output_dir = Path(str(output_dir_str)).expanduser().resolve()

    subjects = args.subjects or _as_list(data.get("subjects"))
    sessions = args.sessions or _as_list(data.get("sessions"))
    force = args.force or bool(data.get("force", False))
    log_level = _parse_log_level(getattr(args, "log_level", None) or data.get("log_level"))
    n_jobs = int(getattr(args, "n_jobs", None) or int(str(data.get("n_jobs", 1))))
    n_procs = int(getattr(args, "n_procs", None) or int(str(data.get("n_procs", 1))))

    # FreeSurfer-specific
    subjects_dir_str = data.get("subjects_dir")
    subjects_dir: Path | None = Path(str(subjects_dir_str)).expanduser().resolve() if subjects_dir_str else None

    fs_home_str = data.get("freesurfer_home") or os.environ.get("FREESURFER_HOME")
    freesurfer_home: Path | None = Path(str(fs_home_str)).expanduser().resolve() if fs_home_str else None

    raw_hemispheres = data.get("hemispheres", ["lh", "rh"])
    hemispheres: list[str] = [str(h) for h in (raw_hemispheres if isinstance(raw_hemispheres, list) else ["lh", "rh"])]
    command_timeout = int(str(data.get("command_timeout", 600)))

    raw_atlases = data.get("atlases", [])
    atlas_configs: list[dict[str, object]] = list(raw_atlases) if isinstance(raw_atlases, list) else []
    fs_atlases = _parse_fs_atlases(atlas_configs)

    raw_overlays = data.get("overlays", [])
    overlay_configs: list[dict[str, object]] = list(raw_overlays) if isinstance(raw_overlays, list) else []
    overlays = _parse_overlays(overlay_configs)

    return FreeSurferConfig(
        input_root=input_root,
        output_dir=output_dir,
        subjects=subjects,
        sessions=sessions,
        force=force,
        log_level=log_level,
        n_jobs=n_jobs,
        n_procs=n_procs,
        subjects_dir=subjects_dir,
        freesurfer_home=freesurfer_home,
        fs_atlases=fs_atlases,
        hemispheres=hemispheres,
        overlays=overlays,
        command_timeout=command_timeout,
    )


# ---------------------------------------------------------------------------
# Output path construction
# ---------------------------------------------------------------------------


def _build_output_path(
    result: FreeSurferParcellationOutput,
    destination: Path,
) -> Path:
    """Construct the BIDS-derivative output path for a FreeSurfer result.

    Output convention::

        {destination}/freesurfer/sub-{id}/[ses-{id}/]anat/atlas-{name}/
            sub-{id}[_ses-{id}]_atlas-{name}[_hemi-{lh|rh}][_desc-{overlay}]_space-freesurfer_parc.tsv

    Parameters
    ----------
    result:
        The parcellation output to write.
    destination:
        Root output directory.

    Returns
    -------
    Path
        Full path to the output TSV file (not yet created).
    """
    ctx = result.context
    base = destination / "freesurfer" / f"sub-{ctx.subject_id}"
    if ctx.session_id:
        base = base / f"ses-{ctx.session_id}"
    base = base / "anat" / f"atlas-{result.atlas.name}"

    entities: list[str] = [ctx.label]
    entities.append(f"atlas-{result.atlas.name}")
    if result.hemisphere:
        entities.append(f"hemi-{result.hemisphere}")
    entities.append("space-freesurfer")
    if result.overlay is not None:
        entities.append(f"desc-{result.overlay.name}")

    filename = "_".join(entities) + "_parc.tsv"
    return base / filename


# ---------------------------------------------------------------------------
# Output writing
# ---------------------------------------------------------------------------


def _write_fs_output(result: FreeSurferParcellationOutput, config: FreeSurferConfig) -> Path:
    """Write a FreeSurfer parcellation result to TSV + JSON sidecar.

    Parameters
    ----------
    result:
        Parcellation output to write.
    config:
        FreeSurfer configuration (used for provenance metadata).

    Returns
    -------
    Path
        Path to the written TSV file.
    """
    out_path = _build_output_path(result, config.output_dir)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    result.stats_table.to_csv(out_path, sep="\t", index=False)
    LOGGER.debug("Wrote FreeSurfer parcellation to %s", out_path)

    # --- JSON sidecar ---
    try:
        from importlib.metadata import version as pkg_version

        software_version = pkg_version("parcellate")
    except Exception:
        software_version = "unknown"

    subjects_dir = config.subjects_dir or config.input_root
    from parcellate.interfaces.freesurfer.parsers import extract_stats_metadata

    fs_metadata = extract_stats_metadata(result.stats_file)

    sidecar: dict = {
        "subjects_dir": str(subjects_dir),
        "subject_id": result.context.subject_id,
        "session_id": result.context.session_id,
        "atlas_name": result.atlas.name,
        "atlas_type": result.atlas.atlas_type.value,
        "hemisphere": result.hemisphere,
        "stats_file": str(result.stats_file),
        "freesurfer_command": result.command,
        "overlay": result.overlay.name if result.overlay else None,
        "overlay_path": str(result.overlay.path) if result.overlay else None,
        "freesurfer_version": fs_metadata.get("BuildStamp", "unknown"),
        "software_version": software_version,
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
    }

    json_path = out_path.with_suffix(".json")
    json_path.write_text(json.dumps(sidecar, indent=2) + "\n")
    LOGGER.debug("Wrote FreeSurfer sidecar to %s", json_path)
    return out_path


# ---------------------------------------------------------------------------
# Per-subject orchestration
# ---------------------------------------------------------------------------


def _run_recon(
    subject_data: FreeSurferSubjectData,
    config: FreeSurferConfig,
) -> list[Path]:
    """Run and write parcellations for a single FreeSurfer subject.

    This function is the unit of work submitted to :func:`run_parallel_workflow`.
    It:

    1. Calls :func:`~parcellate.interfaces.freesurfer.runner.run_parcellation_for_subject`.
    2. For each result, checks whether the output file already exists (skips
       when ``config.force`` is ``False``).
    3. Writes new outputs via :func:`_write_fs_output`.

    Parameters
    ----------
    subject_data:
        Input data for a single subject.
    config:
        FreeSurfer configuration.

    Returns
    -------
    list[Path]
        Paths to all written output files for this subject.
    """
    outputs: list[Path] = []
    results = run_parcellation_for_subject(subject_data, config)

    for result in results:
        out_path = _build_output_path(result, config.output_dir)
        if not config.force and out_path.exists():
            LOGGER.info("Reusing existing output: %s", out_path)
            outputs.append(out_path)
            continue
        outputs.append(_write_fs_output(result, config))

    return outputs


# ---------------------------------------------------------------------------
# Top-level entry point
# ---------------------------------------------------------------------------


def run_parcellations(config: FreeSurferConfig) -> list[Path]:
    """Execute the full FreeSurfer parcellation workflow.

    1. Configures logging.
    2. Validates the FreeSurfer environment.
    3. Loads subject inputs via :func:`~parcellate.interfaces.freesurfer.loader.load_freesurfer_inputs`.
    4. Dispatches per-subject processing via
       :func:`~parcellate.interfaces.shared.run_parallel_workflow`.

    Parameters
    ----------
    config:
        Fully initialised FreeSurfer configuration.

    Returns
    -------
    list[Path]
        All output paths produced across all subjects.
    """
    logging.basicConfig(level=config.log_level, format="%(asctime)s [%(levelname)s] %(message)s")
    LOGGER.info("Starting FreeSurfer parcellation workflow")

    validate_freesurfer_env(config)

    inputs = load_freesurfer_inputs(config)
    if not inputs:
        LOGGER.warning("No valid FreeSurfer subjects found. Nothing to do.")
        return []

    from typing import cast

    return cast(
        list[Path],
        run_parallel_workflow(
            config=config,
            recon_inputs=inputs,
            run_recon_fn=_run_recon,
            pipeline_name="FreeSurfer",
        ),
    )


# ---------------------------------------------------------------------------
# Legacy CLI entry point
# ---------------------------------------------------------------------------


def add_cli_args(parser: argparse.ArgumentParser) -> None:
    """Add FreeSurfer-specific CLI arguments to a parser.

    Parameters
    ----------
    parser:
        The argument parser to augment.
    """
    parser.add_argument("--input-root", type=Path, help="Root SUBJECTS_DIR.")
    parser.add_argument("--output-dir", type=Path, help="Output directory.")
    parser.add_argument("--subjects", nargs="+", help="Subject identifiers to process.")
    parser.add_argument("--sessions", nargs="+", help="Session identifiers (optional).")
    parser.add_argument("--force", action="store_true", help="Overwrite existing outputs.")
    parser.add_argument("--log-level", default="INFO", help="Logging verbosity.")
    parser.add_argument("--n-jobs", type=int, help="Parallel jobs within subject.")
    parser.add_argument("--n-procs", type=int, help="Parallel processes across subjects.")
    parser.add_argument("--config", type=Path, help="Path to TOML config file.")


def main(argv: list[str] | None = None) -> int:
    """Legacy CLI entry point for ``parcellate freesurfer config.toml``."""
    parser = argparse.ArgumentParser(description="Run FreeSurfer parcellations.")
    add_cli_args(parser)
    args = parser.parse_args(argv)
    config = load_config(args)
    try:
        run_parcellations(config)
    except Exception:
        LOGGER.exception("FreeSurfer parcellation workflow failed")
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
