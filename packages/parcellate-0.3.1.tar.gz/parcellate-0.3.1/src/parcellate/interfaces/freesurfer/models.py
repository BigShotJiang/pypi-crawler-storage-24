"""Data models for the FreeSurfer parcellation interface.

This module defines the enums, dataclasses, and configuration objects used
throughout the FreeSurfer interface. FreeSurfer uses its own statistics tools
(mri_segstats, mris_anatomical_stats) rather than NIfTI-based parcellation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import pandas as pd

from parcellate.interfaces.models import ParcellationConfig, SubjectContext


class FreeSurferAtlasType(str, Enum):
    """Type of FreeSurfer atlas, determining which workflow commands to run.

    Attributes
    ----------
    BUILTIN_SURFACE:
        Standard FreeSurfer surface parcellations (aparc, aparc.a2009s,
        aparc.DKTatlas). Run with ``mris_anatomical_stats``.
    BUILTIN_VOLUME:
        Standard FreeSurfer volumetric segmentations (aseg, aparc+aseg,
        wmparc). Run with ``mri_segstats``.
    """

    BUILTIN_SURFACE = "builtin_surface"
    BUILTIN_VOLUME = "builtin_volume"


class FreeSurferStatsType(str, Enum):
    """Which FreeSurfer statistics command to invoke.

    Attributes
    ----------
    SURFACE:
        Use ``mris_anatomical_stats`` (surface-based parcellations).
    VOLUME:
        Use ``mri_segstats`` (volumetric parcellations).
    """

    SURFACE = "surface"
    VOLUME = "volume"


#: Built-in surface parcellations: atlas name → annotation file stem.
BUILTIN_SURFACE_ATLASES: dict[str, str] = {
    "aparc": "aparc",
    "aparc.a2009s": "aparc.a2009s",
    "aparc.DKTatlas": "aparc.DKTatlas",
}

#: Built-in volumetric segmentations: atlas name → MGZ filename.
BUILTIN_VOLUME_ATLASES: dict[str, str] = {
    "aseg": "aseg.mgz",
    "aparc+aseg": "aparc+aseg.mgz",
    "wmparc": "wmparc.mgz",
}

#: Default stats type for each atlas type.
_ATLAS_TYPE_TO_STATS_TYPE: dict[FreeSurferAtlasType, FreeSurferStatsType] = {
    FreeSurferAtlasType.BUILTIN_SURFACE: FreeSurferStatsType.SURFACE,
    FreeSurferAtlasType.BUILTIN_VOLUME: FreeSurferStatsType.VOLUME,
}


@dataclass(frozen=True)
class FreeSurferAtlasDefinition:
    """Description of a built-in FreeSurfer atlas.

    Parameters
    ----------
    name:
        Short identifier used in output filenames (e.g. ``"aparc"``,
        ``"aparc.a2009s"``).
    atlas_type:
        Enum value indicating whether this is a surface or volume atlas.
    stats_type:
        Which statistics command to invoke. Auto-determined from
        ``atlas_type`` when not specified explicitly.
    """

    name: str
    atlas_type: FreeSurferAtlasType
    stats_type: FreeSurferStatsType = FreeSurferStatsType.SURFACE

    def __post_init__(self) -> None:
        object.__setattr__(self, "stats_type", _ATLAS_TYPE_TO_STATS_TYPE[self.atlas_type])


@dataclass(frozen=True)
class FreeSurferOverlay:
    """An overlay map to extract regional statistics from.

    When an overlay is supplied, ``mris_anatomical_stats`` or ``mri_segstats``
    will compute statistics of the overlay values within each parcel rather
    than the default morphometric statistics.

    Parameters
    ----------
    name:
        Short identifier used in output filenames (e.g. ``"fmri_contrast"``).
    path:
        Path to the overlay file (``.mgz``, ``.mgh``, ``.nii.gz``).
    overlay_type:
        ``"surface"`` or ``"volume"``.
    hemisphere:
        For surface overlays, the hemisphere (``"lh"`` or ``"rh"``). ``None``
        for volume overlays or bilateral surface overlays.
    """

    name: str
    path: Path
    overlay_type: str
    hemisphere: str | None = None


@dataclass(frozen=True)
class FreeSurferSubjectData:
    """All input data discovered for a single FreeSurfer subject.

    Parameters
    ----------
    context:
        Subject and optional session identifiers.
    subject_dir:
        Full path to the subject's FreeSurfer output directory.
    atlases:
        Atlas definitions to parcellate for this subject.
    overlays:
        Optional overlay maps to extract values from.
    """

    context: SubjectContext
    subject_dir: Path
    atlases: list[FreeSurferAtlasDefinition]
    overlays: list[FreeSurferOverlay] = field(default_factory=list)


@dataclass
class FreeSurferConfig(ParcellationConfig):
    """Configuration for the FreeSurfer parcellation workflow.

    Extends :class:`~parcellate.interfaces.models.ParcellationConfig` with
    FreeSurfer-specific fields.

    Parameters
    ----------
    subjects_dir:
        Path to the FreeSurfer ``SUBJECTS_DIR``. Defaults to ``input_root``
        when not set.
    freesurfer_home:
        Path to ``FREESURFER_HOME``. Auto-detected from the environment when
        not set.
    fs_atlases:
        List of :class:`FreeSurferAtlasDefinition` objects to parcellate.
    hemispheres:
        Which hemispheres to process for surface atlases.
    overlays:
        Optional overlay maps to extract statistics from.
    command_timeout:
        Subprocess timeout in seconds for each FreeSurfer command.
    """

    subjects_dir: Path | None = None
    freesurfer_home: Path | None = None
    fs_atlases: list[FreeSurferAtlasDefinition] = field(default_factory=list)
    hemispheres: list[str] = field(default_factory=lambda: ["lh", "rh"])
    overlays: list[FreeSurferOverlay] = field(default_factory=list)
    command_timeout: int = 600


@dataclass(frozen=True)
class FreeSurferParcellationOutput:
    """Result of one FreeSurfer parcellation run.

    Parameters
    ----------
    context:
        Subject and session identifiers.
    atlas:
        The atlas definition that was applied.
    hemisphere:
        ``"lh"`` or ``"rh"`` for surface atlases; ``None`` for volumetric.
    overlay:
        The overlay used to extract statistics, if any.
    stats_table:
        Parsed statistics as a :class:`~pandas.DataFrame`.
    stats_file:
        Path to the original FreeSurfer ``.stats`` file.
    command:
        The FreeSurfer command string that produced the output (for
        provenance).
    """

    context: SubjectContext
    atlas: FreeSurferAtlasDefinition
    hemisphere: str | None
    overlay: FreeSurferOverlay | None
    stats_table: pd.DataFrame
    stats_file: Path
    command: str


LOGGER = logging.getLogger(__name__)
