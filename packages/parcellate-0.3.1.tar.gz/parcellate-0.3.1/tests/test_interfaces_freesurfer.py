"""Tests for the FreeSurfer parcellation interface.

Covers:
- Data model construction and enum values
- Stats file parsers (segstats and anatomical stats)
- Loader utilities (subject discovery, validation, env checks)
- Runner command construction (via subprocess mocking)
- Config loading from TOML
- Output path construction
"""

from __future__ import annotations

import argparse
import json
import textwrap
from pathlib import Path
from subprocess import CompletedProcess
from unittest.mock import patch

import pandas as pd
import pytest

from parcellate.interfaces.freesurfer.freesurfer import (
    _build_output_path,
    _parse_fs_atlases,
    _parse_overlays,
    _write_fs_output,
    load_config,
)
from parcellate.interfaces.freesurfer.loader import (
    _discover_subjects,
    validate_freesurfer_env,
    validate_subject,
)
from parcellate.interfaces.freesurfer.models import (
    BUILTIN_SURFACE_ATLASES,
    BUILTIN_VOLUME_ATLASES,
    FreeSurferAtlasDefinition,
    FreeSurferAtlasType,
    FreeSurferConfig,
    FreeSurferOverlay,
    FreeSurferParcellationOutput,
    FreeSurferStatsType,
    FreeSurferSubjectData,
)
from parcellate.interfaces.freesurfer.parsers import (
    extract_stats_metadata,
    parse_anatomical_stats,
    parse_segstats,
    parse_stats_file,
)
from parcellate.interfaces.freesurfer.runner import (
    _build_env,
    run_builtin_surface,
    run_builtin_volume,
    run_parcellation_for_subject,
)
from parcellate.interfaces.models import SubjectContext

# ---------------------------------------------------------------------------
# Fixtures - sample .stats file content
# ---------------------------------------------------------------------------

SEGSTATS_CONTENT = textwrap.dedent("""\
    # Title Segmentation Statistics
    # subjectname sub-01
    # CreationTime 2024-01-15T10:30:00
    # BuildStamp freesurfer-linux-ubuntu22_x86_64-7.4.1
    # SUBJECTS_DIR /subjects
    # ColHeaders  Index SegId NVoxels Volume_mm3 StructName Mean StdDev Min Max Range
    1 2 4536 4536.0 Left-Cerebral-White-Matter 97.4 5.1 40.2 110.0 69.8
    2 3 2109 2109.0 Left-Cerebral-Cortex 74.2 8.3 20.1 105.3 85.2
    3 4 189 189.0 Left-Lateral-Ventricle 37.8 9.1 15.2 70.0 54.8
""")

ANATSTAT_CONTENT = textwrap.dedent("""\
    # Title Anatomical Statistics
    # subjectname sub-01
    # hemi lh
    # CreationTime 2024-01-15T10:30:00
    # BuildStamp freesurfer-linux-ubuntu22_x86_64-7.4.1
    # ColHeaders StructName NumVert SurfArea GrayVol ThickAvg ThickStd MeanCurv GausCurv FoldInd CurvInd
    bankssts 1501 988 2714 2.547 0.408 0.104 0.021 19 1.7
    caudalanteriorcingulate 1095 648 1816 2.561 0.487 0.127 0.022 20 2.0
    caudalmiddlefrontal 3254 2070 5960 2.608 0.467 0.085 0.016 30 3.0
""")


@pytest.fixture()
def segstats_file(tmp_path: Path) -> Path:
    """Write a sample mri_segstats output file."""
    p = tmp_path / "aseg.stats"
    p.write_text(SEGSTATS_CONTENT)
    return p


@pytest.fixture()
def anatstat_file(tmp_path: Path) -> Path:
    """Write a sample mris_anatomical_stats output file."""
    p = tmp_path / "lh.aparc.stats"
    p.write_text(ANATSTAT_CONTENT)
    return p


@pytest.fixture()
def subject_dir(tmp_path: Path) -> Path:
    """Create a minimal valid FreeSurfer subject directory."""
    s = tmp_path / "sub-01"
    for rel in ["mri/brain.mgz", "surf/lh.white", "surf/rh.white", "label/lh.aparc.annot"]:
        p = s / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.touch()
    (s / "stats").mkdir(exist_ok=True)
    (s / "label").mkdir(exist_ok=True)
    return tmp_path  # Return the subjects_dir, not the subject


@pytest.fixture()
def fs_config(tmp_path: Path) -> FreeSurferConfig:
    """Return a minimal FreeSurferConfig pointed at tmp_path."""
    return FreeSurferConfig(
        input_root=tmp_path,
        output_dir=tmp_path / "output",
        subjects_dir=tmp_path,
        freesurfer_home=Path("/usr/local/freesurfer"),
        fs_atlases=[
            FreeSurferAtlasDefinition(name="aparc", atlas_type=FreeSurferAtlasType.BUILTIN_SURFACE),
        ],
        hemispheres=["lh", "rh"],
        command_timeout=60,
    )


# ---------------------------------------------------------------------------
# Model tests
# ---------------------------------------------------------------------------


class TestFreeSurferAtlasType:
    def test_enum_values(self) -> None:
        assert FreeSurferAtlasType.BUILTIN_SURFACE.value == "builtin_surface"
        assert FreeSurferAtlasType.BUILTIN_VOLUME.value == "builtin_volume"

    def test_is_str_enum(self) -> None:
        assert FreeSurferAtlasType("builtin_surface") == FreeSurferAtlasType.BUILTIN_SURFACE


class TestFreeSurferStatsType:
    def test_enum_values(self) -> None:
        assert FreeSurferStatsType.SURFACE.value == "surface"
        assert FreeSurferStatsType.VOLUME.value == "volume"


class TestFreeSurferAtlasDefinition:
    def test_stats_type_auto_derived_surface(self) -> None:
        atlas = FreeSurferAtlasDefinition(name="aparc", atlas_type=FreeSurferAtlasType.BUILTIN_SURFACE)
        assert atlas.stats_type == FreeSurferStatsType.SURFACE

    def test_stats_type_auto_derived_volume(self) -> None:
        atlas = FreeSurferAtlasDefinition(name="aseg", atlas_type=FreeSurferAtlasType.BUILTIN_VOLUME)
        assert atlas.stats_type == FreeSurferStatsType.VOLUME

    def test_frozen_dataclass(self) -> None:
        atlas = FreeSurferAtlasDefinition(name="aparc", atlas_type=FreeSurferAtlasType.BUILTIN_SURFACE)
        with pytest.raises(AttributeError):
            atlas.name = "other"  # type: ignore[misc]

    def test_builtin_constants(self) -> None:
        assert "aparc" in BUILTIN_SURFACE_ATLASES
        assert "aparc.a2009s" in BUILTIN_SURFACE_ATLASES
        assert "aparc.DKTatlas" in BUILTIN_SURFACE_ATLASES
        assert "aseg" in BUILTIN_VOLUME_ATLASES
        assert "aparc+aseg" in BUILTIN_VOLUME_ATLASES
        assert "wmparc" in BUILTIN_VOLUME_ATLASES


class TestSubjectContext:
    def test_label_with_session(self) -> None:
        ctx = SubjectContext(subject_id="01", session_id="02")
        assert ctx.label == "sub-01_ses-02"

    def test_label_without_session(self) -> None:
        ctx = SubjectContext(subject_id="01")
        assert ctx.label == "sub-01"


class TestFreeSurferConfig:
    def test_defaults(self, tmp_path: Path) -> None:
        cfg = FreeSurferConfig(input_root=tmp_path, output_dir=tmp_path / "out")
        assert cfg.hemispheres == ["lh", "rh"]
        assert cfg.command_timeout == 600
        assert cfg.fs_atlases == []
        assert cfg.overlays == []


# ---------------------------------------------------------------------------
# Parser tests
# ---------------------------------------------------------------------------


class TestParseSegstats:
    def test_basic_parsing(self, segstats_file: Path) -> None:
        df = parse_segstats(segstats_file)
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 3
        assert "region_name" in df.columns
        assert "volume_mm3" in df.columns
        assert "n_voxels" in df.columns

    def test_region_names(self, segstats_file: Path) -> None:
        df = parse_segstats(segstats_file)
        names = df["region_name"].tolist()
        assert "Left-Cerebral-White-Matter" in names
        assert "Left-Cerebral-Cortex" in names

    def test_numeric_columns(self, segstats_file: Path) -> None:
        df = parse_segstats(segstats_file)
        assert df["volume_mm3"].dtype in (float, "float64")

    def test_missing_col_headers_raises(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.stats"
        bad_file.write_text("# some comment\n1 2 3\n")
        with pytest.raises(ValueError, match="ColHeaders"):
            parse_segstats(bad_file)


class TestParseAnatomicalStats:
    def test_basic_parsing(self, anatstat_file: Path) -> None:
        df = parse_anatomical_stats(anatstat_file)
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 3
        assert "region_name" in df.columns
        assert "thickness_mean" in df.columns
        assert "surface_area_mm2" in df.columns

    def test_region_names(self, anatstat_file: Path) -> None:
        df = parse_anatomical_stats(anatstat_file)
        names = df["region_name"].tolist()
        assert "bankssts" in names
        assert "caudalmiddlefrontal" in names

    def test_missing_col_headers_raises(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.stats"
        bad_file.write_text("no header here\n")
        with pytest.raises(ValueError, match="ColHeaders"):
            parse_anatomical_stats(bad_file)


class TestParseStatsFile:
    def test_dispatches_to_segstats(self, segstats_file: Path) -> None:
        df = parse_stats_file(segstats_file, FreeSurferStatsType.VOLUME)
        assert "region_name" in df.columns

    def test_dispatches_to_anatstat(self, anatstat_file: Path) -> None:
        df = parse_stats_file(anatstat_file, FreeSurferStatsType.SURFACE)
        assert "region_name" in df.columns


class TestExtractStatsMetadata:
    def test_extracts_subject(self, segstats_file: Path) -> None:
        meta = extract_stats_metadata(segstats_file)
        assert meta.get("subjectname") == "sub-01"

    def test_extracts_build_stamp(self, segstats_file: Path) -> None:
        meta = extract_stats_metadata(segstats_file)
        assert "BuildStamp" in meta
        assert "7.4.1" in meta["BuildStamp"]

    def test_no_col_headers_in_metadata(self, segstats_file: Path) -> None:
        meta = extract_stats_metadata(segstats_file)
        assert "ColHeaders" not in meta


# ---------------------------------------------------------------------------
# Loader tests
# ---------------------------------------------------------------------------


class TestDiscoverSubjects:
    def test_finds_bids_subjects(self, tmp_path: Path) -> None:
        for name in ["sub-01", "sub-02", "sub-03"]:
            (tmp_path / name / "mri").mkdir(parents=True)
            (tmp_path / name / "mri" / "brain.mgz").touch()
        found = _discover_subjects(tmp_path)
        assert set(found) == {"sub-01", "sub-02", "sub-03"}

    def test_excludes_fsaverage(self, tmp_path: Path) -> None:
        for name in ["sub-01", "fsaverage"]:
            (tmp_path / name / "mri").mkdir(parents=True)
            (tmp_path / name / "mri" / "brain.mgz").touch()
        found = _discover_subjects(tmp_path)
        assert "fsaverage" not in found

    def test_filter_subjects(self, tmp_path: Path) -> None:
        for name in ["sub-01", "sub-02"]:
            (tmp_path / name / "mri").mkdir(parents=True)
            (tmp_path / name / "mri" / "brain.mgz").touch()
        found = _discover_subjects(tmp_path, filter_subjects=["sub-01"])
        assert found == ["sub-01"]

    def test_nonexistent_dir_returns_empty(self, tmp_path: Path) -> None:
        found = _discover_subjects(tmp_path / "nonexistent")
        assert found == []

    def test_plain_freesurfer_subject(self, tmp_path: Path) -> None:
        """A directory without sub- prefix but with mri/brain.mgz is accepted."""
        (tmp_path / "bert" / "mri").mkdir(parents=True)
        (tmp_path / "bert" / "mri" / "brain.mgz").touch()
        found = _discover_subjects(tmp_path)
        assert "bert" in found


class TestValidateSubject:
    def test_valid_subject(self, subject_dir: Path) -> None:
        assert validate_subject(subject_dir, "sub-01") is True

    def test_missing_file(self, subject_dir: Path) -> None:
        # Remove one required file
        (subject_dir / "sub-01" / "surf" / "lh.white").unlink()
        assert validate_subject(subject_dir, "sub-01") is False

    def test_nonexistent_subject(self, tmp_path: Path) -> None:
        assert validate_subject(tmp_path, "sub-99") is False


class TestValidateFreeSurferEnv:
    def test_raises_when_no_fs_home(self, fs_config: FreeSurferConfig, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FREESURFER_HOME", raising=False)
        cfg = FreeSurferConfig(
            input_root=fs_config.input_root,
            output_dir=fs_config.output_dir,
            freesurfer_home=None,
        )
        with pytest.raises(OSError, match="FREESURFER_HOME"):
            validate_freesurfer_env(cfg)

    def test_raises_when_fs_home_does_not_exist(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FREESURFER_HOME", raising=False)
        cfg = FreeSurferConfig(
            input_root=tmp_path,
            output_dir=tmp_path / "out",
            freesurfer_home=tmp_path / "nonexistent_fs",
        )
        with pytest.raises(OSError, match="does not exist"):
            validate_freesurfer_env(cfg)

    def test_accepts_env_var(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        # Create a fake FS home with all required executables.
        fs_home = tmp_path / "fs"
        bin_dir = fs_home / "bin"
        bin_dir.mkdir(parents=True)
        for exe in ["mri_segstats", "mris_anatomical_stats", "mri_surf2surf", "mri_vol2vol", "mris_ca_label"]:
            (bin_dir / exe).touch()
        monkeypatch.setenv("FREESURFER_HOME", str(fs_home))
        cfg = FreeSurferConfig(input_root=tmp_path, output_dir=tmp_path / "out", freesurfer_home=None)
        result = validate_freesurfer_env(cfg)
        assert result == fs_home

    def test_raises_when_executables_missing(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FREESURFER_HOME", raising=False)
        # Create FS home directory but no bin executables.
        fs_home = tmp_path / "fs_empty"
        fs_home.mkdir()
        cfg = FreeSurferConfig(
            input_root=tmp_path,
            output_dir=tmp_path / "out",
            freesurfer_home=fs_home,
        )
        with patch("shutil.which", return_value=None), pytest.raises(OSError, match="executables not found"):
            validate_freesurfer_env(cfg)


# ---------------------------------------------------------------------------
# Runner tests
# ---------------------------------------------------------------------------


class TestBuildEnv:
    def test_sets_subjects_dir(self, fs_config: FreeSurferConfig) -> None:
        env = _build_env(fs_config)
        assert env["SUBJECTS_DIR"] == str(fs_config.subjects_dir)

    def test_sets_freesurfer_home(self, fs_config: FreeSurferConfig) -> None:
        env = _build_env(fs_config)
        assert env["FREESURFER_HOME"] == str(fs_config.freesurfer_home)


def _mock_completed(returncode: int = 0) -> CompletedProcess[str]:
    return CompletedProcess(args=[], returncode=returncode, stdout="", stderr="")


class TestRunBuiltinSurface:
    def test_correct_command(self, tmp_path: Path, fs_config: FreeSurferConfig) -> None:
        (tmp_path / "sub-01" / "stats").mkdir(parents=True, exist_ok=True)
        (tmp_path / "sub-01" / "stats" / "lh.aparc.stats").touch()

        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed()
            _stats_file, _cmd = run_builtin_surface("sub-01", "aparc", "lh", fs_config)

        args = mock_run.call_args[0][0]
        assert args[0] == "mris_anatomical_stats"
        assert "-a" in args
        assert "aparc" in args
        assert "-b" in args
        assert "-f" in args
        assert "sub-01" in args
        assert "lh" in args

    def test_overlay_appended(self, tmp_path: Path, fs_config: FreeSurferConfig) -> None:
        (tmp_path / "sub-01" / "stats").mkdir(parents=True, exist_ok=True)
        (tmp_path / "sub-01" / "stats" / "lh.aparc.stats").touch()
        overlay = FreeSurferOverlay(name="mymap", path=Path("/maps/mymap.mgz"), overlay_type="surface")

        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed()
            _, _cmd = run_builtin_surface("sub-01", "aparc", "lh", fs_config, overlay=overlay)

        args = mock_run.call_args[0][0]
        assert "-t" in args
        assert str(overlay.path) in args

    def test_raises_on_nonzero_exit(self, tmp_path: Path, fs_config: FreeSurferConfig) -> None:
        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed(returncode=1)
            with pytest.raises(RuntimeError, match="failed"):
                run_builtin_surface("sub-01", "aparc", "lh", fs_config)


class TestRunBuiltinVolume:
    def test_correct_command(self, tmp_path: Path, fs_config: FreeSurferConfig) -> None:
        subject_dir = tmp_path / "sub-01"
        (subject_dir / "mri").mkdir(parents=True)
        (subject_dir / "mri" / "aseg.mgz").touch()
        (subject_dir / "mri" / "brain.mgz").touch()
        (subject_dir / "stats").mkdir()
        (subject_dir / "stats" / "aseg.stats").touch()

        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed()
            _, _cmd = run_builtin_volume("sub-01", "aseg", fs_config)

        args = mock_run.call_args[0][0]
        assert "mri_segstats" in args
        assert "--seg" in args
        assert "--excludeid" in args
        assert "0" in args


class TestRunParcellationForSubject:
    def test_iterates_hemispheres(self, tmp_path: Path, fs_config: FreeSurferConfig, anatstat_file: Path) -> None:
        """Two outputs expected for a surface atlas (one per hemisphere)."""
        subject_dir = tmp_path / "sub-01"
        (subject_dir / "stats").mkdir(parents=True, exist_ok=True)
        # Point both hemisphere stats to the same fixture file.
        for hemi in ["lh", "rh"]:
            (subject_dir / "stats" / f"{hemi}.aparc.stats").write_text(anatstat_file.read_text())

        subject_data = FreeSurferSubjectData(
            context=SubjectContext(subject_id="sub-01"),
            subject_dir=subject_dir,
            atlases=[FreeSurferAtlasDefinition(name="aparc", atlas_type=FreeSurferAtlasType.BUILTIN_SURFACE)],
        )

        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed()
            outputs = run_parcellation_for_subject(subject_data, fs_config)

        assert len(outputs) == 2
        hemis = {o.hemisphere for o in outputs}
        assert hemis == {"lh", "rh"}

    def test_volume_atlas_no_hemisphere(self, tmp_path: Path, fs_config: FreeSurferConfig, segstats_file: Path) -> None:
        subject_dir = tmp_path / "sub-01"
        (subject_dir / "mri").mkdir(parents=True)
        (subject_dir / "mri" / "aseg.mgz").touch()
        (subject_dir / "mri" / "brain.mgz").touch()
        (subject_dir / "stats").mkdir()
        (subject_dir / "stats" / "aseg.stats").write_text(segstats_file.read_text())

        cfg = FreeSurferConfig(
            input_root=tmp_path,
            output_dir=tmp_path / "out",
            subjects_dir=tmp_path,
            freesurfer_home=Path("/usr/local/freesurfer"),
            fs_atlases=[FreeSurferAtlasDefinition(name="aseg", atlas_type=FreeSurferAtlasType.BUILTIN_VOLUME)],
        )
        subject_data = FreeSurferSubjectData(
            context=SubjectContext(subject_id="sub-01"),
            subject_dir=subject_dir,
            atlases=[FreeSurferAtlasDefinition(name="aseg", atlas_type=FreeSurferAtlasType.BUILTIN_VOLUME)],
        )

        with patch("parcellate.interfaces.freesurfer.runner.subprocess.run") as mock_run:
            mock_run.return_value = _mock_completed()
            outputs = run_parcellation_for_subject(subject_data, cfg)

        assert len(outputs) == 1
        assert outputs[0].hemisphere is None


# ---------------------------------------------------------------------------
# Config loading tests
# ---------------------------------------------------------------------------


class TestParseFsAtlases:
    def test_builtin_surface(self) -> None:
        atlases = _parse_fs_atlases([{"name": "aparc", "type": "builtin_surface"}])
        assert len(atlases) == 1
        assert atlases[0].atlas_type == FreeSurferAtlasType.BUILTIN_SURFACE

    def test_custom_type_raises(self) -> None:
        for custom_type in ("custom_annot", "custom_gcs", "custom_volume"):
            with pytest.raises(ValueError, match="Unknown atlas type"):
                _parse_fs_atlases([{"name": "myatlas", "type": custom_type}])

    def test_unknown_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown atlas type"):
            _parse_fs_atlases([{"name": "foo", "type": "invalid_type"}])

    def test_missing_name_skipped(self) -> None:
        atlases = _parse_fs_atlases([{"type": "builtin_surface"}])
        assert atlases == []


class TestParseOverlays:
    def test_basic_overlay(self, tmp_path: Path) -> None:
        overlay_path = tmp_path / "zstat.mgz"
        overlay_path.touch()
        overlays = _parse_overlays([{"name": "contrast", "path": str(overlay_path), "type": "surface"}])
        assert len(overlays) == 1
        assert overlays[0].name == "contrast"
        assert overlays[0].overlay_type == "surface"

    def test_missing_name_skipped(self, tmp_path: Path) -> None:
        overlays = _parse_overlays([{"path": "/some/path.mgz", "type": "volume"}])
        assert overlays == []


class TestLoadConfig:
    def test_from_toml(self, tmp_path: Path) -> None:
        toml_content = textwrap.dedent("""\
            input_root = "{input}"
            output_dir = "{output}"
            subjects = ["sub-01"]
            hemispheres = ["lh", "rh"]
            command_timeout = 300

            [[atlases]]
            name = "aparc"
            type = "builtin_surface"
        """).format(input=tmp_path, output=tmp_path / "out")

        config_file = tmp_path / "config.toml"
        config_file.write_text(toml_content)

        args = argparse.Namespace(
            config=config_file,
            input_root=None,
            output_dir=None,
            subjects=None,
            sessions=None,
            force=False,
            log_level="INFO",
            n_jobs=None,
            n_procs=None,
        )
        cfg = load_config(args)
        assert cfg.subjects == ["sub-01"]
        assert cfg.command_timeout == 300
        assert len(cfg.fs_atlases) == 1
        assert cfg.fs_atlases[0].name == "aparc"
        assert cfg.hemispheres == ["lh", "rh"]


# ---------------------------------------------------------------------------
# Output path tests
# ---------------------------------------------------------------------------


class TestBuildOutputPath:
    def _make_result(
        self,
        subject_id: str = "01",
        session_id: str | None = None,
        atlas_name: str = "aparc",
        atlas_type: FreeSurferAtlasType = FreeSurferAtlasType.BUILTIN_SURFACE,
        hemisphere: str | None = "lh",
        overlay: FreeSurferOverlay | None = None,
        stats_file: Path | None = None,
    ) -> FreeSurferParcellationOutput:
        return FreeSurferParcellationOutput(
            context=SubjectContext(subject_id=subject_id, session_id=session_id),
            atlas=FreeSurferAtlasDefinition(name=atlas_name, atlas_type=atlas_type),
            hemisphere=hemisphere,
            overlay=overlay,
            stats_table=pd.DataFrame(),
            stats_file=stats_file or Path("placeholder.stats"),
            command="mris_anatomical_stats ...",
        )

    def test_surface_with_hemisphere(self, tmp_path: Path) -> None:
        result = self._make_result()
        path = _build_output_path(result, tmp_path)
        assert "hemi-lh" in path.name
        assert "atlas-aparc" in path.name
        assert "space-freesurfer" in path.name
        assert path.name.endswith("_parc.tsv")

    def test_surface_with_session(self, tmp_path: Path) -> None:
        result = self._make_result(session_id="01")
        path = _build_output_path(result, tmp_path)
        assert "ses-01" in str(path)
        assert "sub-01_ses-01" in path.name

    def test_volume_no_hemisphere(self, tmp_path: Path) -> None:
        result = self._make_result(
            atlas_type=FreeSurferAtlasType.BUILTIN_VOLUME,
            atlas_name="aseg",
            hemisphere=None,
        )
        path = _build_output_path(result, tmp_path)
        assert "hemi-" not in path.name

    def test_with_overlay(self, tmp_path: Path) -> None:
        overlay = FreeSurferOverlay(name="fmri", path=tmp_path / "z.mgz", overlay_type="volume")
        result = self._make_result(overlay=overlay)
        path = _build_output_path(result, tmp_path)
        assert "desc-fmri" in path.name

    def test_output_under_freesurfer_subdir(self, tmp_path: Path) -> None:
        result = self._make_result()
        path = _build_output_path(result, tmp_path)
        assert path.parts[-5] == "freesurfer"


# ---------------------------------------------------------------------------
# Write output tests
# ---------------------------------------------------------------------------


class TestWriteFsOutput:
    def _make_result(
        self,
        tmp_path: Path,
        atlas_type: FreeSurferAtlasType = FreeSurferAtlasType.BUILTIN_SURFACE,
        atlas_name: str = "aparc",
        hemisphere: str | None = "lh",
    ) -> FreeSurferParcellationOutput:
        # Create a real stats file so extract_stats_metadata can read it.
        stats_file = tmp_path / "lh.aparc.stats"
        stats_file.write_text(ANATSTAT_CONTENT)
        return FreeSurferParcellationOutput(
            context=SubjectContext(subject_id="01"),
            atlas=FreeSurferAtlasDefinition(name=atlas_name, atlas_type=atlas_type),
            hemisphere=hemisphere,
            overlay=None,
            stats_table=pd.DataFrame({"region_name": ["bankssts"], "thickness_mean": [2.547]}),
            stats_file=stats_file,
            command="mris_anatomical_stats ...",
        )

    def test_writes_tsv(self, tmp_path: Path) -> None:
        cfg = FreeSurferConfig(input_root=tmp_path, output_dir=tmp_path / "out")
        result = self._make_result(tmp_path)
        out = _write_fs_output(result, cfg)
        assert out.exists()
        df = pd.read_csv(out, sep="\t")
        assert "region_name" in df.columns

    def test_writes_json_sidecar(self, tmp_path: Path) -> None:
        cfg = FreeSurferConfig(input_root=tmp_path, output_dir=tmp_path / "out")
        result = self._make_result(tmp_path)
        out = _write_fs_output(result, cfg)
        json_path = out.with_suffix(".json")
        assert json_path.exists()
        sidecar = json.loads(json_path.read_text())
        assert sidecar["atlas_name"] == "aparc"
        assert sidecar["hemisphere"] == "lh"
        assert sidecar["overlay"] is None

    def test_json_sidecar_fields(self, tmp_path: Path) -> None:
        cfg = FreeSurferConfig(input_root=tmp_path, output_dir=tmp_path / "out")
        result = self._make_result(tmp_path)
        out = _write_fs_output(result, cfg)
        sidecar = json.loads(out.with_suffix(".json").read_text())
        for key in ["atlas_type", "subject_id", "freesurfer_command", "timestamp", "software_version"]:
            assert key in sidecar


# ---------------------------------------------------------------------------
# CLI integration tests
# ---------------------------------------------------------------------------


class TestCliIntegration:
    def test_freesurfer_in_pipeline_choices(self) -> None:
        from parcellate.cli import _build_bids_parser

        parser = _build_bids_parser()
        # Get pipeline choices.
        for action in parser._actions:
            if hasattr(action, "choices") and action.choices and "freesurfer" in action.choices:
                return
        pytest.fail("'freesurfer' not found in --pipeline choices")

    def test_freesurfer_in_legacy_subcommands(self) -> None:
        from parcellate.cli import _LEGACY_SUBCOMMANDS

        assert "freesurfer" in _LEGACY_SUBCOMMANDS

    def test_bids_app_routes_to_freesurfer(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        called: list[bool] = []

        def fake_run(config: object) -> list:
            called.append(True)
            return []

        monkeypatch.setattr(
            "parcellate.interfaces.freesurfer.freesurfer.run_parcellations",
            fake_run,
        )
        # Also patch load_config to avoid needing a real TOML file.
        monkeypatch.setattr(
            "parcellate.interfaces.freesurfer.freesurfer.load_config",
            lambda args: FreeSurferConfig(
                input_root=tmp_path,
                output_dir=tmp_path / "out",
            ),
        )

        from parcellate.cli import main as cli_main

        # We need to patch the import inside _run_bids_app.
        with patch("parcellate.interfaces.freesurfer.freesurfer.run_parcellations", fake_run):
            ret = cli_main([str(tmp_path), str(tmp_path / "out"), "participant", "--pipeline", "freesurfer"])
        assert ret == 0
