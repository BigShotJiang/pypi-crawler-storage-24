# FreeSurfer Interface — Example Configs

This directory contains example TOML configuration files for the `freesurfer`
parcellation pipeline.

## Prerequisites

1. **FreeSurfer installed** and `$FREESURFER_HOME` set in your environment.
2. **`recon-all` completed** for each subject. The `SUBJECTS_DIR` should
   contain one subdirectory per subject, each with `mri/`, `surf/`, `label/`
   and `stats/` subdirectories.
3. **`fsaverage` available** in your `SUBJECTS_DIR` (required for custom `.annot`
   atlases). The interface will auto-symlink it from `$FREESURFER_HOME/subjects/`
   if it is missing.

## Quick Start

```bash
# Source your FreeSurfer setup
source /usr/local/freesurfer/SetUpFreeSurfer.sh

# Built-in surface parcellations (aparc, aparc.a2009s)
parcellate /path/to/subjects /path/to/output participant \
    --pipeline freesurfer \
    --config examples/freesurfer/builtin_surface.toml

# Built-in volumetric segmentations (aseg, aparc+aseg)
parcellate /path/to/subjects /path/to/output participant \
    --pipeline freesurfer \
    --config examples/freesurfer/builtin_volume.toml
```

## Config Files

| File | Description |
|---|---|
| `builtin_surface.toml` | aparc, aparc.a2009s, aparc.DKTatlas — `mris_anatomical_stats` |
| `builtin_volume.toml` | aseg, aparc+aseg, wmparc — `mri_segstats` |
| `custom_atlases.toml` | Custom `.annot`, `.gcs`, and volumetric atlases |
| `with_overlay.toml` | Extract overlay statistics (fMRI, PET, DTI) |

## Output Structure

Outputs follow BIDS-derivative conventions under `{output_dir}/freesurfer/`:

```
freesurfer/
└── sub-01/
    └── anat/
        ├── atlas-aparc/
        │   ├── sub-01_atlas-aparc_hemi-lh_space-freesurfer_parc.tsv
        │   ├── sub-01_atlas-aparc_hemi-lh_space-freesurfer_parc.json
        │   ├── sub-01_atlas-aparc_hemi-rh_space-freesurfer_parc.tsv
        │   └── sub-01_atlas-aparc_hemi-rh_space-freesurfer_parc.json
        └── atlas-aseg/
            ├── sub-01_atlas-aseg_space-freesurfer_parc.tsv
            └── sub-01_atlas-aseg_space-freesurfer_parc.json
```

Each TSV contains one row per brain region with standardised column names:

**Surface atlases (`mris_anatomical_stats`)**:
- `region_name`, `n_vertices`, `surface_area_mm2`, `gray_matter_volume_mm3`
- `thickness_mean`, `thickness_std`, `mean_curvature`, `gaussian_curvature`
- `folding_index`, `curvature_index`

**Volume atlases (`mri_segstats`)**:
- `region_name`, `region_index`, `segment_id`
- `n_voxels`, `volume_mm3`
- `intensity_mean`, `intensity_std`, `intensity_min`, `intensity_max`, `intensity_range`

Each JSON sidecar records full provenance: FreeSurfer version, command used,
subjects directory, atlas type, and timestamp.

## Testing with Real Data

### 1. Verify environment

```bash
parcellate /path/to/subjects /tmp/test_output participant \
    --pipeline freesurfer \
    --config examples/freesurfer/builtin_surface.toml \
    --log-level DEBUG \
    --subjects sub-01   # process a single subject first
```

### 2. Check output

```python
import pandas as pd

df = pd.read_csv(
    "/tmp/test_output/freesurfer/sub-01/anat/atlas-aparc/"
    "sub-01_atlas-aparc_hemi-lh_space-freesurfer_parc.tsv",
    sep="\t",
)
print(df[["region_name", "thickness_mean", "surface_area_mm2"]].head())
```

### 3. Inspect sidecar

```bash
cat /tmp/test_output/freesurfer/sub-01/anat/atlas-aparc/sub-01_atlas-aparc_hemi-lh_space-freesurfer_parc.json
```

### 4. Custom atlas (Schaefer 400)

Download the Schaefer 2018 annotations:

```bash
# From the CBIG repository
wget https://raw.githubusercontent.com/ThomasYeoLab/CBIG/master/stable_projects/\
brain_parcellation/Schaefer2018_LocalGlobal/Parcellations/FreeSurfer5.3/\
fsaverage/label/lh.Schaefer2018_400Parcels_7Networks_order.annot \
-O /path/to/atlases/lh.Schaefer2018_400Parcels_7Networks_order.annot

wget https://raw.githubusercontent.com/ThomasYeoLab/CBIG/master/stable_projects/\
brain_parcellation/Schaefer2018_LocalGlobal/Parcellations/FreeSurfer5.3/\
fsaverage/label/rh.Schaefer2018_400Parcels_7Networks_order.annot \
-O /path/to/atlases/rh.Schaefer2018_400Parcels_7Networks_order.annot
```

Then update `custom_atlases.toml` with the downloaded path and run:

```bash
parcellate /path/to/subjects /path/to/output participant \
    --pipeline freesurfer \
    --config examples/freesurfer/custom_atlases.toml
```

## Fixture Stats Files for Unit Tests

The test suite in `tests/test_interfaces_freesurfer.py` uses inline fixture
strings that replicate the format of real FreeSurfer `.stats` files. To test
parsers against your own data:

```python
from parcellate.interfaces.freesurfer.parsers import parse_anatomical_stats, parse_segstats

# Surface stats
df = parse_anatomical_stats(Path("/path/to/lh.aparc.stats"))
print(df.head())

# Volume stats
df = parse_segstats(Path("/path/to/aseg.stats"))
print(df.head())
```

Real `.stats` files are located under `{SUBJECTS_DIR}/{subject}/stats/`:
- `lh.aparc.stats`, `rh.aparc.stats` — Desikan–Killiany surface stats
- `aseg.stats` — subcortical segmentation stats
- `aparc+aseg.stats` — combined stats
