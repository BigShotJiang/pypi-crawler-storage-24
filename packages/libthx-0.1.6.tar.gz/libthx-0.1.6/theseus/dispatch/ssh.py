"""
ssh utilities for remote dispatch
"""

import subprocess
import shlex
import re
import time
import threading
import socket
import os
from pathlib import Path
from dataclasses import dataclass

from loguru import logger

# Per-host adaptive rate limiting with exponential backoff
_host_last_call: dict[str, float] = {}
_host_interval: dict[str, float] = {}  # current interval per host
_host_lock = threading.Lock()

_MIN_INTERVAL = 0.5  # minimum interval between calls
_MAX_INTERVAL = 10.0  # maximum interval (cap for backoff)
_BACKOFF_FACTOR = 2.0  # multiply interval by this on failure
_RECOVERY_FACTOR = 0.8  # multiply interval by this on success
_MAX_RETRIES = 5  # max retries for transient connection errors


def _is_transient_error(stderr: str) -> bool:
    """Check if an error is a transient connection error."""
    transient_patterns = [
        "connection reset",
        "connection closed",
        "kex_exchange",
        "connection refused",
        "connection timed out",
        "no route to host",
    ]
    stderr_lower = stderr.lower()
    return any(pattern in stderr_lower for pattern in transient_patterns)


def _rate_limit(host: str) -> None:
    """Wait if needed to avoid overwhelming the SSH server."""
    with _host_lock:
        now = time.time()
        last_call = _host_last_call.get(host, 0)
        interval = _host_interval.get(host, _MIN_INTERVAL)
        elapsed = now - last_call
        if elapsed < interval:
            wait_time = interval - elapsed
            logger.debug(f"SSH | rate limiting: waiting {wait_time:.2f}s for {host}")
            time.sleep(wait_time)
        _host_last_call[host] = time.time()


def _backoff(host: str) -> None:
    """Increase rate limit interval for a host after a failure."""
    with _host_lock:
        current = _host_interval.get(host, _MIN_INTERVAL)
        new_interval = min(current * _BACKOFF_FACTOR, _MAX_INTERVAL)
        _host_interval[host] = new_interval
        logger.debug(f"SSH | backoff for {host}: interval now {new_interval:.2f}s")


def _recover(host: str) -> None:
    """Decrease rate limit interval for a host after success."""
    with _host_lock:
        current = _host_interval.get(host, _MIN_INTERVAL)
        new_interval = max(current * _RECOVERY_FACTOR, _MIN_INTERVAL)
        _host_interval[host] = new_interval


def _shell_quote(s: str) -> str:
    """Quote a string for safe shell execution."""
    return shlex.quote(s)


@dataclass
class RunResult:
    """Result of a remote command execution"""

    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


@dataclass
class TunnelResult:
    """Result of starting an SSH local port forward."""

    returncode: int
    pid: int | None
    command: list[str]
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and self.pid is not None


def hosts() -> list[str]:
    """Parse ~/.ssh/config to list accessible hosts.

    Returns a list of host names/aliases defined in the SSH config.
    Excludes wildcard patterns and special entries.
    """
    config_path = Path.home() / ".ssh" / "config"

    if not config_path.exists():
        logger.debug("SSH | no ~/.ssh/config found")
        return []

    hosts_list: list[str] = []
    content = config_path.read_text()

    # Match "Host" lines, handling multiple hosts per line
    host_pattern = re.compile(r"^\s*Host\s+(.+?)\s*$", re.MULTILINE | re.IGNORECASE)

    for match in host_pattern.finditer(content):
        # Split on whitespace to handle "Host foo bar baz"
        entries = match.group(1).split()
        for entry in entries:
            # Skip wildcards and special patterns
            if "*" in entry or "?" in entry or "!" in entry:
                continue
            hosts_list.append(entry)

    logger.debug(f"SSH | found {len(hosts_list)} hosts in ssh config")
    return hosts_list


def run(cmd: str | list[str], host: str, timeout: float | None = None) -> RunResult:
    """Execute a command remotely on a host via SSH.

    Runs in a login shell to ensure environment variables are loaded.
    Retries on transient connection errors with exponential backoff.

    Args:
        cmd: Command to execute (string or list of args)
        host: SSH host (name, alias, or user@host)
        timeout: Optional timeout in seconds

    Returns:
        RunResult with returncode, stdout, and stderr
    """
    if isinstance(cmd, list):
        cmd = " ".join(cmd)

    # Wrap in login shell to get full environment (bashrc, profile, etc.)
    # Using $SHELL -l -c ensures we use the user's default shell (bash, zsh, etc.)
    wrapped_cmd = f"$SHELL -l -c {_shell_quote(cmd)}"
    ssh_cmd = ["ssh", "-o", "BatchMode=yes", host, wrapped_cmd]

    # Truncate cmd for logging if too long
    cmd_preview = cmd[:80] + "..." if len(cmd) > 80 else cmd

    last_result = None
    for attempt in range(_MAX_RETRIES):
        # Rate limit to avoid overwhelming SSH server
        _rate_limit(host)

        logger.debug(f"SSH | running on {host}: {cmd_preview}")

        try:
            result = subprocess.run(
                ssh_cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            last_result = RunResult(
                returncode=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
            )

            if result.returncode == 0:
                _recover(host)
                return last_result

            # Check if it's a transient error worth retrying
            if _is_transient_error(result.stderr) and attempt < _MAX_RETRIES - 1:
                logger.warning(
                    f"SSH | transient error on {host} (attempt {attempt + 1}/{_MAX_RETRIES}), backing off..."
                )
                _backoff(host)
                continue

            # Non-transient error or last attempt
            if result.returncode != 0:
                logger.debug(
                    f"SSH | command failed (rc={result.returncode}): {result.stderr[:200] if result.stderr else 'no stderr'}"
                )
            return last_result

        except subprocess.TimeoutExpired as e:
            logger.warning(f"SSH | command timed out after {timeout}s on {host}")
            last_result = RunResult(
                returncode=-1,
                stdout=e.stdout or ""
                if isinstance(e.stdout, str)
                else (e.stdout.decode() if e.stdout else ""),
                stderr=f"Command timed out after {timeout}s",
            )
            if attempt < _MAX_RETRIES - 1:
                _backoff(host)
                continue
            return last_result

    return last_result or RunResult(
        returncode=-1, stdout="", stderr="max retries exceeded"
    )


def run_many(
    cmd: str | list[str], hosts: list[str], timeout: float | None = None
) -> dict[str, RunResult]:
    """Execute a command on multiple hosts in parallel.

    Args:
        cmd: Command to execute
        hosts: List of SSH hosts
        timeout: Optional timeout in seconds per host

    Returns:
        Dict mapping host -> RunResult
    """
    import concurrent.futures

    logger.debug(f"SSH | running command on {len(hosts)} hosts in parallel")
    results: dict[str, RunResult] = {}

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(hosts)) as executor:
        future_to_host = {
            executor.submit(run, cmd, host, timeout): host for host in hosts
        }
        for future in concurrent.futures.as_completed(future_to_host):
            host = future_to_host[future]
            try:
                results[host] = future.result()
            except Exception as e:
                logger.warning(f"SSH | exception running on {host}: {e}")
                results[host] = RunResult(returncode=-1, stdout="", stderr=str(e))

    success_count = sum(1 for r in results.values() if r.ok)
    logger.debug(f"SSH | run_many completed: {success_count}/{len(hosts)} succeeded")
    return results


def copy_to(
    local_path: str | Path, host: str, remote_path: str, timeout: float | None = None
) -> RunResult:
    """Copy a local file/directory to a remote host via scp.

    Args:
        local_path: Local file or directory path
        host: SSH host
        remote_path: Destination path on remote host
        timeout: Optional timeout in seconds

    Returns:
        RunResult with returncode, stdout, and stderr
    """
    # Rate limit to avoid overwhelming SSH server
    _rate_limit(host)

    local_path = Path(local_path)
    logger.debug(f"SSH | copying {local_path} to {host}:{remote_path}")
    scp_cmd = ["scp", "-o", "BatchMode=yes"]

    if local_path.is_dir():
        scp_cmd.append("-r")

    scp_cmd.extend([str(local_path), f"{host}:{remote_path}"])

    try:
        result = subprocess.run(
            scp_cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            logger.debug("SSH | copy_to succeeded")
        else:
            logger.warning(f"SSH | copy_to failed: {result.stderr}")
        return RunResult(
            returncode=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )
    except subprocess.TimeoutExpired:
        logger.warning(f"SSH | scp timed out after {timeout}s")
        return RunResult(
            returncode=-1,
            stdout="",
            stderr=f"SCP timed out after {timeout}s",
        )


def copy_from(
    host: str, remote_path: str, local_path: str | Path, timeout: float | None = None
) -> RunResult:
    """Copy a remote file/directory to local via scp.

    Args:
        host: SSH host
        remote_path: Source path on remote host
        local_path: Local destination path
        timeout: Optional timeout in seconds

    Returns:
        RunResult with returncode, stdout, and stderr
    """
    # Rate limit to avoid overwhelming SSH server
    _rate_limit(host)

    logger.debug(f"SSH | copying {host}:{remote_path} to {local_path}")
    scp_cmd = [
        "scp",
        "-o",
        "BatchMode=yes",
        "-r",
        f"{host}:{remote_path}",
        str(local_path),
    ]

    try:
        result = subprocess.run(
            scp_cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return RunResult(
            returncode=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )
    except subprocess.TimeoutExpired:
        logger.warning(f"SSH | scp timed out after {timeout}s")
        return RunResult(
            returncode=-1,
            stdout="",
            stderr=f"SCP timed out after {timeout}s",
        )


def is_reachable(host: str, timeout: float = 5.0) -> bool:
    """Check if a host is reachable via SSH.

    Args:
        host: SSH host to check
        timeout: Connection timeout in seconds

    Returns:
        True if host is reachable
    """
    logger.debug(f"SSH | checking if {host} is reachable")
    result = run("echo ok", host, timeout=timeout)
    reachable = result.ok and "ok" in result.stdout
    logger.debug(f"SSH | {host} reachable={reachable}")
    return reachable


def forward_port(host: str, local_port: int, remote_port: int) -> TunnelResult:
    """Start a background SSH tunnel forwarding local_port -> remote localhost:remote_port.

    Args:
        host: SSH host (name, alias, or user@host)
        local_port: Local port to bind
        remote_port: Remote port on localhost to forward to

    Returns:
        TunnelResult with PID on success
    """
    if local_port <= 0 or remote_port <= 0:
        return TunnelResult(
            returncode=-1,
            pid=None,
            command=[],
            stderr="local_port and remote_port must be positive integers",
        )

    # Fail fast if the requested local port is already occupied.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", local_port))
        except OSError as e:
            return TunnelResult(
                returncode=-1,
                pid=None,
                command=[],
                stderr=f"local port {local_port} is already in use: {e}",
            )

    def _listener_pids(port: int) -> set[int]:
        result = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return set()
        pids: set[int] = set()
        for line in result.stdout.splitlines():
            line = line.strip()
            if line.isdigit():
                pids.add(int(line))
        return pids

    cmd = [
        "ssh",
        "-N",
        "-o",
        "BatchMode=yes",
        "-o",
        "ExitOnForwardFailure=yes",
        "-o",
        "ServerAliveInterval=30",
        "-o",
        "ServerAliveCountMax=3",
        "-L",
        f"{local_port}:localhost:{remote_port}",
        host,
    ]
    logger.debug(
        f"SSH | forwarding local port {local_port} -> {host}:localhost:{remote_port}"
    )
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
    except Exception as e:
        return TunnelResult(
            returncode=-1,
            pid=None,
            command=cmd,
            stderr=str(e),
        )

    # Validate tunnel is actually established locally, not just spawned.
    wait_seconds = float(os.environ.get("THESEUS_SSH_TUNNEL_WAIT_SECONDS", "12.0"))
    wait_seconds = max(3.0, wait_seconds)
    deadline = time.time() + wait_seconds
    sleep_s = 0.05
    while time.time() < deadline:
        rc = proc.poll()
        if rc is not None:
            stderr = ""
            if proc.stderr is not None:
                stderr = proc.stderr.read() or ""
            return TunnelResult(
                returncode=rc,
                pid=None,
                command=cmd,
                stderr=stderr.strip(),
            )

        # Ensure the listener belongs to this ssh process, not a different one.
        listeners = _listener_pids(local_port)
        if proc.pid in listeners:
            return TunnelResult(returncode=0, pid=proc.pid, command=cmd, stderr="")
        time.sleep(sleep_s)
        sleep_s = min(sleep_s * 1.5, 0.75)

    # Tunnel process is alive but local listener did not appear.
    try:
        proc.terminate()
    except Exception:
        pass
    stderr = ""
    if proc.stderr is not None:
        try:
            stderr = proc.stderr.read() or ""
        except Exception:
            stderr = ""
    return TunnelResult(
        returncode=-1,
        pid=None,
        command=cmd,
        stderr=stderr.strip()
        or f"ssh tunnel did not open local listener in time ({wait_seconds:.1f}s)",
    )
