"""
SARIF Report Generator for CodeSecure.

SS-006: SARIF 2.1.0 compliant output for IDE integration.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from codesecure.reports.generator import BaseReportGenerator, ReportGenerator, ReportMetadata
from codesecure.scanners.base import Finding, FindingSeverity
from codesecure.scanners.engine import ScanResult
from codesecure.common.logging import get_logger


logger = get_logger(__name__)


class SARIFReportGenerator(BaseReportGenerator):
    """
    SS-006: SARIF 2.1.0 report generator for IDE integration.
    
    Produces SARIF output compatible with:
    - VS Code SARIF Viewer
    - GitHub Code Scanning
    - Azure DevOps
    - Other SARIF-compliant tools
    """
    
    format_name = "sarif"
    file_extension = ".sarif"
    
    # SARIF schema version
    SARIF_VERSION = "2.1.0"
    SCHEMA_URI = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
    
    # Severity to SARIF level mapping
    SEVERITY_TO_LEVEL = {
        "critical": "error",
        "high": "error",
        "medium": "warning",
        "low": "note",
        "info": "note",
    }
    
    def generate(
        self,
        result: ScanResult,
        output_path: Path,
        metadata: Optional[ReportMetadata] = None,
    ) -> Path:
        """Generate SARIF report."""
        output_path = self._prepare_output_path(output_path)
        metadata = metadata or ReportMetadata()
        
        sarif = self._build_sarif(result, metadata)
        
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(sarif, f, indent=2, default=str)
        
        return output_path
    
    def _build_sarif(self, result: ScanResult, metadata: ReportMetadata) -> Dict[str, Any]:
        """Build SARIF 2.1.0 compliant structure."""
        # Group findings by scanner for tool runs
        findings_by_scanner: Dict[str, List[Finding]] = {}
        for finding in result.findings:
            if finding.scanner not in findings_by_scanner:
                findings_by_scanner[finding.scanner] = []
            findings_by_scanner[finding.scanner].append(finding)
        
        runs = []
        for scanner_name, findings in findings_by_scanner.items():
            runs.append(self._build_run(scanner_name, findings, metadata))
        
        # If no findings, create an empty run for CodeSecure
        if not runs:
            runs.append({
                "tool": {
                    "driver": {
                        "name": "CodeSecure",
                        "version": metadata.tool_version,
                        "informationUri": "https://github.com/codesecure",
                    }
                },
                "results": [],
            })
        
        return {
            "$schema": self.SCHEMA_URI,
            "version": self.SARIF_VERSION,
            "runs": runs,
        }
    
    def _build_run(
        self,
        scanner_name: str,
        findings: List[Finding],
        metadata: ReportMetadata,
    ) -> Dict[str, Any]:
        """Build a SARIF run for a scanner."""
        # Collect unique rules
        rules = {}
        for finding in findings:
            rule_id = finding.id[:12]  # Use truncated ID as rule ID
            if rule_id not in rules:
                rules[rule_id] = self._build_rule(finding)
        
        return {
            "tool": {
                "driver": {
                    "name": scanner_name,
                    "version": metadata.tool_version,
                    "rules": list(rules.values()),
                }
            },
            "results": [self._build_result(f) for f in findings],
            "invocations": [{
                "executionSuccessful": True,
                "endTimeUtc": metadata.generated_at.isoformat() + "Z",
                "properties": {
                    "jobId": metadata.job_id
                }
            }],
        }
    
    def _build_rule(self, finding: Finding) -> Dict[str, Any]:
        """Build a SARIF rule definition."""
        rule = {
            "id": finding.id[:12],
            "name": finding.title,
            "shortDescription": {
                "text": finding.title,
            },
            "fullDescription": {
                "text": finding.description or finding.title,
            },
            "defaultConfiguration": {
                "level": self.SEVERITY_TO_LEVEL.get(
                    finding.severity.value if hasattr(finding.severity, 'value') else finding.severity, 
                    "warning"
                ),
            },
        }
        
        # Add CWE relationships
        if finding.cwe_ids:
            rule["relationships"] = [
                {
                    "target": {
                        "id": cwe,
                        "guid": None,
                        "toolComponent": {"name": "CWE"},
                    },
                    "kinds": ["superset"],
                }
                for cwe in finding.cwe_ids
            ]
        
        return rule
    
    def _build_result(self, finding: Finding) -> Dict[str, Any]:
        """Build a SARIF result from a finding."""
        result = {
            "ruleId": finding.id[:12],
            "level": self.SEVERITY_TO_LEVEL.get(
                finding.severity.value if hasattr(finding.severity, 'value') else finding.severity, 
                "warning"
            ),
            "message": {
                "text": finding.description or finding.title,
            },
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding.file_path.replace("\\", "/"),
                        },
                        "region": {
                            "startLine": max(1, finding.line_start),
                            "endLine": max(1, finding.line_end or finding.line_start),
                        },
                    }
                }
            ],
        }
        
        # Add code snippet if available
        if finding.code_snippet:
            result["locations"][0]["physicalLocation"]["region"]["snippet"] = {
                "text": finding.code_snippet,
            }
        
        # Add fingerprint for deduplication
        result["fingerprints"] = {
            "primaryLocationLineHash": finding.id,
        }
        
        # Add AI enhancements to properties
        if hasattr(finding, "detailed_description"):
            result["properties"] = {
                "detailedDescription": finding.detailed_description,
                "attackScenario": finding.attack_scenario,
                "businessImpact": finding.business_impact,
                "exploitability": finding.exploitability,
                "remediationCode": finding.remediation_code,
                "implementationSteps": finding.implementation_steps,
                "googleCloudRecommendation": getattr(finding, "google_cloud_recommendation", ""),
                "googleCloudDocLinks": getattr(finding, "google_cloud_doc_links", []),
                "rollbackProcedure": getattr(finding, "rollback_procedure", ""),
                "awsRecommendation": getattr(finding, "aws_recommendation", ""),
                "awsWellArchitectedPillar": getattr(finding, "aws_well_architected_pillar", ""),
                "awsDocLinks": getattr(finding, "aws_doc_links", []),
                "codeSnippetBefore": getattr(finding, "code_snippet_before", ""),
                "falsePositiveConfidence": getattr(finding, "false_positive_confidence", 0.0),
                "isFalsePositive": getattr(finding, "is_false_positive", False),
                "testCases": getattr(finding, "test_cases", []),
                "owaspCategory": getattr(finding, "owasp_category", ""),
                "mitreAttackId": getattr(finding, "mitre_attack_id", ""),
                "nistControls": getattr(finding, "nist_controls", []),
            }
        
        return result


# Register with ReportGenerator
ReportGenerator.register(SARIFReportGenerator)
