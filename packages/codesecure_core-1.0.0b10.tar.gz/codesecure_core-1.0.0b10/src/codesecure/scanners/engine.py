"""
Scanner Engine Orchestrator for CodeSecure.

SS-001: Orchestrates security tool execution
SS-002: Support local and container mode
"""

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Type

from codesecure.scanners.base import (
    BaseScanner,
    Finding,
    ScanMode,
    ScannerResult,
)
from codesecure.scanners.bandit import BanditScanner
from codesecure.scanners.semgrep import SemgrepScanner
from codesecure.scanners.checkov import CheckovScanner
from codesecure.scanners.detect_secrets import DetectSecretsScanner
from codesecure.scanners.npm_audit import NpmAuditScanner
from codesecure.scanners.grype import GrypeScanner
from codesecure.scanners.syft import SyftScanner
from codesecure.scanners.pip_audit import PipAuditScanner
from codesecure.scanners.pip_licenses import PipLicensesScanner
from codesecure.common.logging import get_logger


from codesecure.common.logging import get_logger
from codesecure.common.models import ScanResult
from codesecure.common.cloud_provider import CloudProvider

logger = get_logger(__name__)


class ScannerEngine:
    """
    SS-001: Orchestrates security tool execution.
    SS-002: Support local and container mode.
    
    Usage:
        engine = ScannerEngine()
        result = await engine.run_scan(
            path=Path("/project"),
            scanners=["bandit", "semgrep"],
            mode=ScanMode.LOCAL
        )
    """
    
    # Registry of available scanners
    SCANNERS: Dict[str, Type[BaseScanner]] = {
        "bandit": BanditScanner,
        "semgrep": SemgrepScanner,
        "checkov": CheckovScanner,
        "detect-secrets": DetectSecretsScanner,
        "npm-audit": NpmAuditScanner,
        "grype": GrypeScanner,
        "syft": SyftScanner,
        "pip-audit": PipAuditScanner,
        "pip-licenses": PipLicensesScanner,
    }
    
    def __init__(self):
        """Initialize the scanner engine."""
        self.logger = logger
    
    def get_available_scanners(self, mode: ScanMode = None) -> List[str]:
        """
        Get list of available scanners, optionally filtered by mode.
        
        Args:
            mode: Optional mode to filter by
            
        Returns:
            List of scanner names
        """
        if mode is None:
            return list(self.SCANNERS.keys())
        
        available = []
        for name, scanner_cls in self.SCANNERS.items():
            if mode in scanner_cls.supported_modes:
                available.append(name)
        return available
    
    async def run_scan_with_progress(
        self,
        path: Path,
        job_id: str,
        scanners: Optional[List[str]] = None,
        mode: ScanMode = ScanMode.LOCAL,
        timeout: int = 600,
        progress_callback: Optional[callable] = None,
        cloud_provider: CloudProvider = CloudProvider.NONE,
    ) -> ScanResult:
        """
        Run security scans with progress updates - SS-007.
        
        Args:
            path: Target path to scan
            job_id: Associated job ID
            scanners: List of scanners to run
            mode: Execution mode
            timeout: Timeout per scanner
            progress_callback: Callback(percentage, status_text)
            
        Returns:
            ScanResult with merged and validated findings
        """
        import time
        from codesecure.scanners.data_merger import get_data_merger
        from codesecure.common.performance import PerformanceManager
        
        start_time = time.time()
        started_at = datetime.now(timezone.utc)

        # Dynamic Performance Analysis
        perf_config = PerformanceManager.analyze_repository(path)
        scanned_files = perf_config.file_count
        
        # Only override timeout if using default (600 or 480 from CLI), 
        # allowing PerformanceManager to set the strict PRD-compliant limit.
        if timeout in [480, 600]:
            timeout = perf_config.timeout_seconds
        
        # Default to all available scanners
        if scanners is None:
            scanners = self.get_available_scanners(mode)
            
        # Optimization: Skip workspace-level scanners for single file scans
        if path.is_file():
            workspace_scanners = {"pip-audit", "pip-licenses", "npm-audit", "grype", "syft"}
            original_count = len(scanners)
            scanners = [s for s in scanners if s not in workspace_scanners]
            if len(scanners) < original_count:
                self.logger.info(f"Single file scan detected. Skipping workspace-level scanners: {workspace_scanners & set(scanners if isinstance(scanners, list) else [])}")
        
        # Initial progress
        if progress_callback:
            await progress_callback(0, f"Initializing {len(scanners)} scanners (timeout: {timeout}s)...")
            
        # Instantiate scanners
        scanner_instances = []
        errors = []
        
        if scanners:
            self.logger.info("Initializing scanners: %s", scanners)
            
        for scanner_name in scanners:
            if scanner_name not in self.SCANNERS:
                self.logger.warning(f"Unknown scanner: {scanner_name}")
                errors.append(f"Unknown scanner: {scanner_name}")
                continue
                
            scanner_cls = self.SCANNERS[scanner_name]
            if mode not in scanner_cls.supported_modes:
                self.logger.warning(f"Scanner {scanner_name} not supported in {mode.value} mode")
                errors.append(f"Scanner {scanner_name} not supported in {mode.value} mode")
                continue
                
            try:
                scanner = scanner_cls(mode=mode)
                if scanner.is_available():
                    self.logger.info(f"Scanner {scanner_name} is available and active")
                    scanner_instances.append(scanner)
                else:
                    self.logger.info(f"Scanner {scanner_name} is not available on this system, skipping.")
            except Exception as e:
                self.logger.error(f"Failed to init {scanner_name}: {e}")
                errors.append(f"Failed to init {scanner_name}: {e}")
        
        if not scanner_instances:
            self.logger.error("No valid scanners available for this scan")
            return ScanResult(
                job_id=job_id,
                success=False,
                errors=errors or ["No valid scanners available"],
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
            )
            
        # Run scanners in parallel
        if progress_callback:
            await progress_callback(10, f"Running {len(scanner_instances)} tools in parallel...")
            
        total_scanners = len(scanner_instances)
        completed_scanners = 0
        scanner_results = {}
        
        async def run_wrapper(scanner, idx):
            nonlocal completed_scanners
            try:
                self.logger.info(f"Starting {scanner.name} on {path}")
                # Apply scanner-specific multiplier if available
                scanner_timeout = int(timeout * getattr(scanner, "timeout_multiplier", 1.0))
                result = await scanner.run(path, timeout=scanner_timeout)
                self.logger.info(f"Completed {scanner.name} with {len(result.findings)} findings")
                
                # Update progress
                completed_scanners += 1
                completion_pct = 10 + (completed_scanners / total_scanners * 60)  # 10% to 70%
                if progress_callback:
                    await progress_callback(
                        completion_pct, 
                        f"Completed {scanner.name} ({completed_scanners}/{total_scanners})"
                    )
                return (scanner.name, result)
            except Exception as e:
                self.logger.error(f"Scanner {scanner.name} execution failed: {e}")
                completed_scanners += 1
                return (scanner.name, e)

        # Execute parallel tasks
        tasks = [run_wrapper(s, i) for i, s in enumerate(scanner_instances)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        for name, result in results:
            if isinstance(result, Exception):
                errors.append(f"{name}: {str(result)}")
                scanner_results[name] = ScannerResult(scanner_name=name, success=False, error=str(result))
            else:
                scanner_results[name] = result
                if result.success:
                    self.logger.info(f"Adding {len(result.findings)} findings from {name}")
                else:
                    self.logger.warning(f"Scanner {name} failed: {result.error}")
                    errors.append(f"{name}: {result.error}")
        
        # Merge and Deduplicate
        if progress_callback:
            await progress_callback(75, "Merging and deduplicating findings...")
            
        merger = get_data_merger()
        
        from codesecure.common.models import Finding as ModelFinding

        # Group by scanner for merger
        findings_map = {}
        for name, result in scanner_results.items():
            if result.success:
                findings_map[name] = [
                    ModelFinding(
                        id=f.id,
                        scanner=f.scanner,
                        title=f.title,
                        description=f.description,
                        severity=f.severity.value,
                        file_path=f.file_path,
                        line_start=f.line_start,
                        line_end=f.line_end,
                        code_snippet=f.code_snippet,
                        cwe_ids=f.cwe_ids,
                        owasp_category=f.owasp_category,
                        mitre_attack_id=f.mitre_attack_id or None,
                        nist_controls=f.nist_controls,
                    ) for f in result.findings
                ]
        
        self.logger.info(f"Merging findings from {list(findings_map.keys())}")
        merged_findings = merger.merge_findings(findings_map)
        self.logger.info(f"Total merged findings: {len(merged_findings)}")
        
        # Apply Framework Mapping [SS-014]
        try:
            from codesecure.scanners.framework_mapper import get_framework_mapper
            mapper = get_framework_mapper()
            merged_findings = mapper.map_findings(merged_findings)
        except Exception as e:
            self.logger.error(f"Framework mapping failed: {e}")
            errors.append(f"Framework mapping failed: {str(e)}")
        
        # AI Enrichment [G-002]
        if cloud_provider != CloudProvider.NONE:
            if progress_callback:
                await progress_callback(80, f"Enriching findings with {cloud_provider.value} AI...")
                
            # Populate missing snippets from filesystem before sending to AI
            # This is critical for tools like detect-secrets or checkov that might miss snippets.
            for finding in merged_findings:
                if not finding.code_snippet and finding.file_path:
                    try:
                        # Normalize finding path and target path
                        f_path = finding.file_path.replace("\\", "/")
                        if f_path.startswith("./"):
                            f_path = f_path[2:]
                        
                        filepath = path / f_path if not Path(f_path).is_absolute() else Path(f_path)
                        filepath = filepath.resolve()
                        
                        if filepath.exists() and filepath.is_file():
                            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                                lines = f.readlines()
                                if 1 <= finding.line_start <= len(lines):
                                    finding.code_snippet = lines[finding.line_start-1].strip()
                    except Exception as e:
                        self.logger.debug(f"Failed to auto-populate snippet for {finding.file_path}: {e}")

            try:
                from codesecure.ai_providers.manager import get_ai_manager
                ai_manager = get_ai_manager(cloud_provider)
                
                # Enrich findings using AI manager
                self.logger.info(f"Sending {len(merged_findings)} findings for AI enrichment")
                enriched = await ai_manager.enrich_findings(merged_findings)
                merged_findings = enriched
                self.logger.info(f"AI enrichment complete, got {len(merged_findings)} findings back")
                
            except ImportError:
                self.logger.warning("AI Providers module not found, skipping enrichment.")
            except Exception as e:
                self.logger.error(f"AI Enrichment failed: {e}")
                errors.append(f"AI Enrichment failed: {str(e)}")
        
        # Finalization
        execution_time = time.time() - start_time
        
        if progress_callback:
            await progress_callback(90, "Finalizing results...")
        
        any_success = any(r.success for r in scanner_results.values() if isinstance(r, ScannerResult))
        
        return ScanResult(
            job_id=job_id,
            success=any_success,
            findings=merged_findings,
            scanner_results={name: r.__dict__ if hasattr(r, '__dict__') else r for name, r in scanner_results.items()},
            scanners_run=list(scanner_results.keys()),
            errors=errors,
            duration_seconds=execution_time,
            scanned_files=scanned_files,
            started_at=started_at,
            completed_at=datetime.now(timezone.utc)
        )

    # run_scan legacy method removed - use run_scan_with_progress via JobManager


# Singleton instance
_scanner_engine: Optional[ScannerEngine] = None


def get_scanner_engine() -> ScannerEngine:
    """Get the global ScannerEngine singleton."""
    global _scanner_engine
    if _scanner_engine is None:
        _scanner_engine = ScannerEngine()
    return _scanner_engine
