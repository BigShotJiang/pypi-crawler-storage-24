"""
Configuration settings for CodeSecure.

This module contains all configuration constants and settings.
"""

from pathlib import Path
from typing import Optional
import os


# Job Management Configuration - PERF-007, PERF-008
MAX_CONCURRENT_JOBS: int = 25  # PERF-007: Maximum concurrent jobs
JOB_TTL_HOURS: int = 24  # PERF-008: Job TTL for cleanup (hours)

# Storage Paths
CODESECURE_HOME: Path = Path.home() / ".codesecure"
JOBS_STORAGE_PATH: Path = CODESECURE_HOME / "jobs"
SCANS_STORAGE_PATH: Path = CODESECURE_HOME / "scans"
REPORTS_STORAGE_PATH: Path = CODESECURE_HOME / "reports"
THREAT_MODELS_STORAGE_PATH: Path = CODESECURE_HOME / "threat_models"
LOGS_STORAGE_PATH: Path = CODESECURE_HOME / "logs"
CONFIG_FILE_PATH: Path = CODESECURE_HOME / "config.yaml"
TERMS_ACCEPTANCE_FILE: Path = CODESECURE_HOME / ".terms_accepted"

# Scanner Timeouts (seconds)
SCANNER_TIMEOUT: int = 480  # 8 minutes per scanner
AI_BATCH_TIMEOUT: int = 600  # 10 minutes per AI batch

# AI Configuration
AI_BATCH_SIZE: int = 10  # Findings per AI batch
FALSE_POSITIVE_THRESHOLD: float = 0.90  # 90% confidence for FP detection
AI_MAX_CONCURRENT_BATCHES: int = 3  # PERF-009: Max concurrent AI batches

# Performance Targets - From TDD Section 10 & PRD Section 4.2
SMALL_REPO_TIMEOUT: int = 300  # 5 minutes
MEDIUM_REPO_TIMEOUT: int = 600  # 10 minutes
LARGE_REPO_TIMEOUT: int = 1200  # 20 minutes
THREAT_MODEL_TIMEOUT: int = 900  # PERF-004: 10-15 minutes

# Logging Configuration - REL-003, REL-004
LOG_RETENTION_DAYS: int = 30
LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
AUDIT_LOG_FORMAT: str = '{"timestamp": "%(asctime)s", "event": "%(message)s", "level": "%(levelname)s"}'


def ensure_storage_dirs() -> None:
    """Create all required storage directories if they don't exist."""
    dirs = [
        CODESECURE_HOME,
        JOBS_STORAGE_PATH,
        SCANS_STORAGE_PATH,
        REPORTS_STORAGE_PATH,
        THREAT_MODELS_STORAGE_PATH,
        LOGS_STORAGE_PATH,
    ]
    for dir_path in dirs:
        dir_path.mkdir(parents=True, exist_ok=True)


def get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    """Get environment variable with optional default."""
    return os.environ.get(key, default)


# Cloud Provider Defaults
DEFAULT_CLOUD_PROVIDER: str = get_env("CODESECURE_CLOUD_PROVIDER", "none")


def is_terms_accepted() -> bool:
    """Check if the user has accepted the beta terms."""
    return TERMS_ACCEPTANCE_FILE.exists()


def accept_terms() -> None:
    """Mark the beta terms as accepted."""
    ensure_storage_dirs()
    TERMS_ACCEPTANCE_FILE.touch()
