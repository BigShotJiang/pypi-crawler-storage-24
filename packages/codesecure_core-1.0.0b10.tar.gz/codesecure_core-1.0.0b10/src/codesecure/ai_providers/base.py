from abc import ABC, abstractmethod
from typing import List, Any, Optional, AsyncIterator, Dict
from dataclasses import dataclass
from enum import Enum

from codesecure.common.models import Finding, EnhancedFinding
from codesecure.common.logging import get_logger

logger = get_logger(__name__)

class AIProviderType(str, Enum):
    GOOGLE = "google"
    AWS = "aws"
    AZURE = "azure"
    OPENAI = "openai"

class AIProviderStatus(str, Enum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"
    ERROR = "error"

class PromptBuilder(ABC):
    """Abstract base class for building AI prompts."""
    @abstractmethod
    def build_batch_prompt(self, findings: List[Finding], app_context: Optional[Dict[str, Any]] = None) -> str:
        pass

class CLIExecutor(ABC):
    """Abstract base class for executing CLI commands."""
    @abstractmethod
    async def execute(self, prompt: str) -> str:
        """Execute the CLI command with the given prompt and return output."""
        pass

    @staticmethod
    def clean_output(text: str) -> str:
        """Remove ANSI escape sequences and SGR codes from text."""
        import re
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

class MarkdownParser(ABC):
    """Abstract base class for parsing markdown responses."""
    @abstractmethod
    def parse(self, markdown: str, original_findings: List[Finding]) -> List[EnhancedFinding]:
        pass

@dataclass
class AIAnalysisResult:
    """Raw result from AI analysis"""
    content: str
    metadata: Dict[str, Any]

class BaseAIProvider(ABC):
    """Base class for AI providers integration."""
    
    PROVIDER_TYPE: AIProviderType
    
    @property
    @abstractmethod
    def is_available(self) -> bool:
        pass
        
    @abstractmethod
    async def check_availability(self) -> tuple[AIProviderStatus, str]:
        pass
        
    @abstractmethod
    async def analyze_findings_batch(
        self, 
        findings: List[Finding], 
        code_contexts: Dict[str, str],
        batch_size: int = 5,
        app_context: Optional[Dict[str, Any]] = None
    ) -> List[Any]: # Returns raw analysis objects/dicts
        pass

    @abstractmethod
    def enhance_finding(self, finding: Finding, analysis: Any) -> EnhancedFinding:
        pass
        
    @abstractmethod
    async def generate_stride_analysis(self, repo_path: Any, category: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def test_connection(self) -> tuple[AIProviderStatus, str]:
        """Perform a minimal AI request to verify connectivity and quota."""
        pass
