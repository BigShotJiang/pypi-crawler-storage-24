"""
AI Provider Manager for CodeSecure.

Orchestrates AI provider selection, fallback, and finding enrichment.

Implements:
- G-001, G-002: Cloud provider selection
- SS-003, SS-004: AI-powered code review
- SS-010, SS-011: False positive detection (>90%)
"""

import asyncio
from typing import Any, Dict, List, Optional, Tuple

from codesecure.ai_providers.base import (
    AIAnalysisResult,
    AIProviderStatus,
    AIProviderType,
    BaseAIProvider,
)
from codesecure.ai_providers.google_cli import get_gemini_wrapper
from codesecure.ai_providers.kiro_cli import get_kiro_wrapper
from codesecure.ai_providers.azure_cli import get_azure_wrapper
from codesecure.ai_providers.openai_provider import get_openai_wrapper
from codesecure.ai_providers.anthropic_provider import get_anthropic_wrapper
from codesecure.common.logging import get_logger, audit_logger
from codesecure.common.models import CloudProvider, Finding, EnhancedFinding
from codesecure.common.config import AI_BATCH_SIZE, FALSE_POSITIVE_THRESHOLD


logger = get_logger(__name__)


class AIProviderManager:
    """
    Manages AI provider selection, fallback, and finding enrichment.
    
    G-001: Allow user to choose between different cloud providers
    G-002: Use appropriate AI capabilities based on chosen provider
    
    Features:
    - Automatic provider selection based on cloud provider
    - Fallback between providers on failure
    - Batch processing for efficiency
    - False positive filtering at >90% confidence
    """
    
    def __init__(
        self,
        cloud_provider: CloudProvider = CloudProvider.NONE,
        ai_provider_override: Optional[str] = None,
        api_key_override: Optional[str] = None,
        batch_size: int = AI_BATCH_SIZE,
        fp_threshold: float = FALSE_POSITIVE_THRESHOLD,
    ):
        """
        Initialize AI Provider Manager.
        
        Args:
            cloud_provider: Selected cloud provider
            batch_size: Number of findings per AI batch
            fp_threshold: False positive confidence threshold (0-1)
        """
        self.cloud_provider = cloud_provider
        self.ai_provider_override = ai_provider_override
        self.api_key_override = api_key_override
        self.batch_size = batch_size
        self.fp_threshold = fp_threshold * 100  # Convert to percentage
        
        # Initialize providers
        self._gemini = get_gemini_wrapper()
        self._kiro = get_kiro_wrapper()
        self._azure = get_azure_wrapper()
        self._openai = get_openai_wrapper()
        self._anthropic = get_anthropic_wrapper()
        
        # Primary provider based on cloud selection
        self._primary_provider: Optional[BaseAIProvider] = None
        self._fallback_provider: Optional[BaseAIProvider] = None
        
        self._configure_providers()
    
    def _configure_providers(self) -> None:
        """Configure primary and fallback providers based on cloud selection."""
        # Reset providers
        self._primary_provider = None
        self._fallback_provider = None
        
        # Explicit override handling (for IDE/CLI direct configuration)
        if self.ai_provider_override:
            override = self.ai_provider_override.lower()
            if override == "google":
                self._primary_provider = self._gemini
            elif override == "openai":
                self._primary_provider = self._openai
                if self.api_key_override:
                    self._openai.set_api_key(self.api_key_override)
            elif override == "anthropic":
                self._primary_provider = self._anthropic
                if self.api_key_override:
                    self._anthropic.set_api_key(self.api_key_override)
            elif override == "aws":
                self._primary_provider = self._kiro
            elif override == "azure":
                self._primary_provider = self._azure
                
        else:
            # Fallback to cloud environment implicit logic
            if self.cloud_provider == CloudProvider.GOOGLE:
                self._primary_provider = self._gemini
            elif self.cloud_provider == CloudProvider.AWS:
                self._primary_provider = self._kiro
            elif self.cloud_provider == CloudProvider.AZURE:
                self._primary_provider = self._azure
            elif self.cloud_provider == CloudProvider.OPENAI:
                self._primary_provider = self._openai
            
        if self._primary_provider:
             logger.info(
                "AI provider configured: %s",
                self._primary_provider.PROVIDER_TYPE.value
            )
    
    async def check_providers(self) -> Dict[str, Any]:
        """
        Check availability of all AI providers.
        
        Returns:
            Dictionary with provider status information
        """
        results = {}
        
        # Check Gemini
        gemini_status, gemini_msg = await self._gemini.check_availability()
        if gemini_status == AIProviderStatus.AVAILABLE:
             # Deep check connectivity and quota
             gemini_status, gemini_msg = await self._gemini.test_connection()
             
        results["gemini"] = {
            "status": gemini_status.value,
            "message": gemini_msg,
            "is_primary": self._primary_provider == self._gemini,
        }
        
        # Check Kiro
        kiro_status, kiro_msg = await self._kiro.check_availability()
        if kiro_status == AIProviderStatus.AVAILABLE:
             # Deep check connectivity and quota
             kiro_status, kiro_msg = await self._kiro.test_connection()
             
        results["kiro"] = {
            "status": kiro_status.value,
            "message": kiro_msg,
            "is_primary": self._primary_provider == self._kiro,
        }
        
        # Check Azure
        azure_status, azure_msg = await self._azure.check_availability()
        if azure_status == AIProviderStatus.AVAILABLE:
             azure_status, azure_msg = await self._azure.test_connection()
             
        results["azure"] = {
            "status": azure_status.value,
            "message": azure_msg,
            "is_primary": self._primary_provider == self._azure,
        }

        # Check OpenAI
        openai_status, openai_msg = await self._openai.check_availability()
        if openai_status == AIProviderStatus.AVAILABLE:
             openai_status, openai_msg = await self._openai.test_connection()

        results["openai"] = {
            "status": openai_status.value,
            "message": openai_msg,
            "is_primary": self._primary_provider == self._openai,
        }

        # Check Anthropic
        anthropic_status, anthropic_msg = await self._anthropic.check_availability()
        if anthropic_status == AIProviderStatus.AVAILABLE:
             anthropic_status, anthropic_msg = await self._anthropic.test_connection()

        results["anthropic"] = {
            "status": anthropic_status.value,
            "message": anthropic_msg,
            "is_primary": self._primary_provider == self._anthropic,
        }
        
        # Overall status
        results["has_available_provider"] = any(
            s == AIProviderStatus.AVAILABLE for s in [
                gemini_status, kiro_status, azure_status, openai_status, anthropic_status
            ]
        )
        
        return results
    
    async def enrich_findings(
        self,
        findings: List[Finding],
        code_contexts: Optional[Dict[str, str]] = None,
        app_context: Optional[Dict[str, Any]] = None,
        is_workspace_scan: bool = False,
    ) -> List[EnhancedFinding]:
        """
        Enrich findings with AI-generated analysis with resilience.
        
        SS-003, SS-004: AI-powered code review
        SS-010, SS-011: False positive detection
        PERF-009: Concurrent batch processing
        
        Args:
            findings: List of findings to enrich
            code_contexts: Optional dict of finding_id -> code_context
            is_workspace_scan: True if triggered from a heavy workspace review
            
        Returns:
            List of EnhancedFinding with AI enhancements
        """
        from codesecure.common.config import AI_MAX_CONCURRENT_BATCHES

        if not self._primary_provider:
            logger.warning("No AI provider configured, returning unenriched findings")
            return [self._finding_to_enhanced(f) for f in findings]
        
        # Pre-check connectivity and quota before starting (PERF-009)
        status, msg = await self._primary_provider.test_connection()
        if status != AIProviderStatus.AVAILABLE:
             logger.error("AI Provider Connection Failed: %s", msg)
             # Return findings with error message set
             return [self._finding_to_enhanced(f, error_message=msg) for f in findings]
        
        code_contexts = code_contexts or {}
        semaphore = asyncio.Semaphore(AI_MAX_CONCURRENT_BATCHES) # PERF-009
        
        # Prepare batches
        batches = [findings[i : i + self.batch_size] for i in range(0, len(findings), self.batch_size)]
        
        logger.info("Enriching %d findings in %d batches (max concurrent: %d)", 
                   len(findings), len(batches), AI_MAX_CONCURRENT_BATCHES)

        async def _process_batch_with_limit(batch: List[Finding]) -> List[EnhancedFinding]:
            """Process a single batch with concurrency control."""
            async with semaphore:
                return await self._process_batch(
                    batch, 
                    code_contexts=code_contexts, 
                    app_context=app_context,
                    is_workspace_scan=is_workspace_scan
                )

        # Execute concurrent batches
        tasks = [_process_batch_with_limit(batch) for batch in batches]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate results
        all_enhanced = []
        for res in results:
            if isinstance(res, list):
                all_enhanced.extend(res)
            else:
                logger.error("Batch failed with unhandled exception: %s", res)
        
        # Filter False Positives > 90%
        final_findings, fps = await self.filter_false_positives(all_enhanced)
        
        logger.info(
            "Enriched %d findings with AI analysis (Filtered %d FPs)",
            len(final_findings), len(fps)
        )
        
        return final_findings

    async def _process_batch(
        self, 
        batch: List[Finding],
        code_contexts: Dict[str, str],
        app_context: Optional[Dict[str, Any]] = None,
        is_workspace_scan: bool = False,
    ) -> List[EnhancedFinding]:
        """Process a single batch of findings with fallback logic."""
        batch_enhanced = []
        batch_error = None
        
        # Try primary provider
        try:
            if self._primary_provider.is_available:
                batch_enhanced = await self._primary_provider.analyze_findings_batch(
                    batch,
                    code_contexts=code_contexts,
                    batch_size=len(batch),
                    app_context=app_context,
                    is_workspace_scan=is_workspace_scan
                )
            else:
                status, msg = await self._primary_provider.check_availability()
                batch_error = f"Primary AI Provider Unavailable: {msg}"
        except Exception as e:
            logger.exception("Primary provider failed for batch: %s", e)
            batch_error = str(e)
            
        # If primary failed, we no longer fallback automatically
        if batch_error:
            logger.warning("AI analysis failed for batch: %s", batch_error)

        # Combine results for this batch
        batch_results = []
        enriched_ids = {f.id for f in batch_enhanced}
        
        for finding in batch:
            if finding.id in enriched_ids:
                # Successfully enriched
                for ef in batch_enhanced:
                    if ef.id == finding.id:
                        batch_results.append(ef)
                        break
            else:
                # Failed to enrich - use professional error message
                user_message = self._map_error_to_user_message(batch_error)
                batch_results.append(self._finding_to_enhanced(finding, error_message=user_message))
                
        return batch_results

    def _map_error_to_user_message(self, error: Optional[str]) -> str:
        """Map internal system errors to user-friendly messages."""
        if not error:
            return "AI Analysis Failed: Service Temporarily Unavailable"
            
        err_lower = error.lower()
        
        # Prioritize service/quota errors
        if any(kw in err_lower for kw in ["quota", "rate limit", "429", "too many requests"]):
            return "AI Analysis Failed: Quota Exceeded (429)"
        elif "timed out" in err_lower or "deadline" in err_lower:
            return "AI Analysis Failed: Service Timeout"
            
        # Distinguish between missing tool and incompatible tool
        if any(kw in err_lower for kw in ["file not found", "no such file", "command not found", "winerror 2"]):
            return "AI Analysis Failed: AI Tool Not Installed or Path Error"
            
        # If it failed but the command was likely found, check for arg errors (incompatibility)
        if any(kw in err_lower for kw in ["argument", "invalid option", "not recognized", "unknown option"]):
            return "AI Analysis Failed: Incompatible AI Tool Version or Flags"
            
        if "api_key" in err_lower or "authentication" in err_lower or "unauthorized" in err_lower:
            return "AI Analysis Failed: Configuration Error (Missing/Invalid API Key)"
        elif "markdown" in err_lower or "parse" in err_lower:
            return "AI Analysis Failed: Parsing Error (Unexpected AI Response)"
            
        return f"AI Analysis Failed: {error[:50]}..." if error else "AI Analysis Failed: Service Unavailable"
    
    async def filter_false_positives(
        self,
        findings: List[EnhancedFinding],
    ) -> Tuple[List[EnhancedFinding], List[EnhancedFinding]]:
        """
        Filter findings based on false positive confidence.
        
        SS-010, SS-011: >90% FP detection confidence
        
        Args:
            findings: List of enhanced findings to filter
            
        Returns:
            Tuple of (valid_findings, false_positives)
        """
        valid = []
        false_positives = []
        
        for finding in findings:
            # Check if FP confidence is high
            fp_conf_percent = finding.false_positive_confidence * 100 if finding.false_positive_confidence <= 1.0 else finding.false_positive_confidence

            if finding.is_false_positive and fp_conf_percent > self.fp_threshold:
                false_positives.append(finding)
                logger.debug(
                    "Finding %s marked as FP (confidence: %.1f%%)",
                    finding.id, fp_conf_percent
                )
            else:
                valid.append(finding)
        
        logger.info(
            "FP filtering: %d valid, %d false positives (threshold: %.1f%%)",
            len(valid), len(false_positives), self.fp_threshold
        )
        
        return (valid, false_positives)
    
    async def generate_stride_threats(
        self,
        repository_path: str,
        categories: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Generate STRIDE threat analysis for repository.
        
        TM-001, TM-002: STRIDE threat models
        TM-005: Parallel STRIDE category execution
        
        Args:
            repository_path: Path to the repository
            categories: STRIDE categories to analyze (default: all)
            
        Returns:
            Dictionary with STRIDE analysis results
        """
        from pathlib import Path
        
        if categories is None:
            categories = [
                "spoofing",
                "tampering",
                "repudiation",
                "information_disclosure",
                "denial_of_service",
                "elevation_of_privilege",
            ]
        
        if not self._primary_provider:
            logger.warning("No AI provider available for STRIDE analysis")
            return {"error": "No AI provider available", "categories": {}}
        
        repo_path = Path(repository_path)
        
        # TM-005: Run categories in parallel
        tasks = [
            self._primary_provider.generate_stride_analysis(repo_path, category)
            for category in categories
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        stride_results = {}
        for category, result in zip(categories, results):
            if isinstance(result, Exception):
                logger.error("STRIDE analysis failed for %s: %s", category, result)
                stride_results[category] = {"error": str(result), "threats": []}
            else:
                stride_results[category] = result
        
        # Count total threats
        total_threats = sum(
            len(r.get("threats", []))
            for r in stride_results.values()
            if isinstance(r, dict)
        )
        
        logger.info(
            "STRIDE analysis completed: %d categories, %d total threats",
            len(categories), total_threats
        )
        
        return {
            "repository_path": str(repository_path),
            "categories": stride_results,
            "total_threats": total_threats,
            "provider": self._primary_provider.PROVIDER_TYPE.value,
        }
    
    def _finding_to_enhanced(self, finding: Finding, error_message: str = "") -> EnhancedFinding:
        """Convert a Finding to EnhancedFinding without AI enrichment."""
        return EnhancedFinding(
            id=finding.id,
            scanner=finding.scanner,
            severity=finding.severity,
            title=finding.title,
            description=finding.description,
            file_path=finding.file_path,
            line_start=finding.line_start,
            line_end=finding.line_end,
            code_snippet=finding.code_snippet,
            code_snippet_before=finding.code_snippet,  # Requirement: code_snippet (before)
            cwe_ids=finding.cwe_ids,
            owasp_category=finding.owasp_category,
            mitre_attack_id=finding.mitre_attack_id,
            nist_controls=finding.nist_controls,
            # Initialize other AI fields with defaults to ensure they are present in JSON
            detailed_description=error_message if error_message else "",
            attack_scenario="",
            business_impact="",
            exploitability="unknown",
            remediation_code=f"# {error_message}" if error_message else "",
            remediation_guidance=error_message if error_message else "",
            implementation_steps=[],
            rollback_procedure="",
            google_cloud_recommendation="",
            google_cloud_doc_links=[],
        )


# Singleton instance
_ai_manager: Optional[AIProviderManager] = None


def get_ai_manager(
    cloud_provider: CloudProvider = CloudProvider.NONE,
    ai_provider_override: Optional[str] = None,
    api_key_override: Optional[str] = None
) -> AIProviderManager:
    """
    Get the AI Provider Manager singleton.
    
    Args:
        cloud_provider: Cloud provider to configure
        ai_provider_override: Optional direct string override ("google", "openai", "anthropic")
        api_key_override: Optional API key material to pass to the provider
        
    Returns:
        AIProviderManager instance
    """
    global _ai_manager
    if (
        _ai_manager is None or 
        _ai_manager.cloud_provider != cloud_provider or 
        _ai_manager.ai_provider_override != ai_provider_override or
        _ai_manager.api_key_override != api_key_override
    ):
        _ai_manager = AIProviderManager(
            cloud_provider=cloud_provider,
            ai_provider_override=ai_provider_override,
            api_key_override=api_key_override
        )
    return _ai_manager
