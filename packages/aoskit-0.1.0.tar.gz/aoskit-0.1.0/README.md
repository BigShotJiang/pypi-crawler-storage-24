# aoskit

The reference SDK for building Agentic Operating Systems (AOS).

## Install

```bash
pip install aoskit
```

## Quick Start

```python
from aoskit import AOS, AOSConfig

wiz = AOS(AOSConfig(name="wiz", domain="ad-intelligence", version="1.0.0"))
```

## Learn More

- [GitHub](https://github.com/XYANDZ-iO/aoskit)
- [aoskit.dev](https://aoskit.dev)
- [xyandz.io](https://xyandz.io)
