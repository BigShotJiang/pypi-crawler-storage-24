"""Agent — PARA cycle (Plan → Act → Recover → Audit)"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import time

@dataclass
class AuditLog:
    agent_name: str
    duration_ms: float
    total_cost: float
    timestamp: float
    success: bool

class Agent:
    def __init__(self, name: str, config: dict):
        self.name = name
        self.description = config.get("description", "")
        self.tools = config.get("tools", [])
        self._plan_fn = config.get("plan")
        self._act_fn = config.get("act")
        self._recover_fn = config.get("recover")

    async def run(self, context: dict) -> AuditLog:
        start = time.time()
        success = True
        try:
            plan = await self._plan_fn(context) if self._plan_fn else {}
            result = await self._act_fn(plan) if self._act_fn else {}
        except Exception as e:
            if self._recover_fn:
                await self._recover_fn(e, context)
            success = False
        
        return AuditLog(
            agent_name=self.name,
            duration_ms=(time.time() - start) * 1000,
            total_cost=0.0,
            timestamp=time.time(),
            success=success,
        )
