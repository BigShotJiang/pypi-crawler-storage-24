"""AOS — Agentic Operating System runtime"""
from dataclasses import dataclass, field
from typing import Dict, Optional, Any

@dataclass
class AOSConfig:
    name: str
    domain: str
    version: str

class AOS:
    """Core kernel that manages agents, tools, memory, and observability."""
    
    def __init__(self, config: AOSConfig):
        self.name = config.name
        self.domain = config.domain
        self.version = config.version
        self._agents: Dict[str, Any] = {}
        self._tools: Dict[str, Any] = {}
        self._running = False

    def agent(self, name: str, config: dict) -> "AOS":
        from .agent import Agent
        self._agents[name] = Agent(name, config)
        return self

    def tool(self, config: dict) -> "AOS":
        from .tool import Tool
        self._tools[config["name"]] = Tool(config)
        return self

    def observe(self, fid: Any) -> "AOS":
        print(f"[{self.name}] FID observability connected")
        return self

    def identity(self, pid: Any) -> "AOS":
        print(f"[{self.name}] PID identity connected")
        return self

    async def start(self):
        self._running = True
        print(f"[{self.name}] AOS v{self.version} started — domain: {self.domain}")
        print(f"[{self.name}] {len(self._agents)} agents, {len(self._tools)} tools registered")

    async def stop(self):
        self._running = False
        print(f"[{self.name}] AOS stopped")
