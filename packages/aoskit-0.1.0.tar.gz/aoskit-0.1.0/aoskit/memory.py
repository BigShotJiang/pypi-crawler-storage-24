"""Memory — Agent memory and context persistence"""
from typing import List, Optional
from dataclasses import dataclass

@dataclass
class MemoryResult:
    content: str
    score: float
    source: str
    timestamp: float

class Memory:
    def __init__(self, backend: str = "sqlite", **kwargs):
        self.backend = backend

    async def store(self, key: str, content: str, metadata: dict = None):
        pass

    async def retrieve(self, query: str, limit: int = 10) -> List[MemoryResult]:
        return []

    async def forget(self, key: str):
        pass
