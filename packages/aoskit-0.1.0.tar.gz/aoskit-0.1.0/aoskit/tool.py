"""Tool — MCP-compatible tool wrapper"""

class Tool:
    def __init__(self, config: dict):
        self.name = config["name"]
        self.description = config.get("description", "")
        self.input_schema = config.get("input_schema", {})
        self._handler = config.get("handler")

    async def execute(self, input_data: dict):
        if self._handler:
            return await self._handler(input_data)

    def to_mcp(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": {"type": "object", "properties": self.input_schema},
        }
