"""SKILL.md parser and directory scanner for agentskills.io packages."""

from __future__ import annotations

import logging
import re
from pathlib import Path

import yaml

from pulsebot.skills.agentskills.models import (
    OpenClawMetadata,
    SkillContent,
    SkillMetadata,
    SkillRequirements,
    SkillSource,
)

logger = logging.getLogger(__name__)

# Regex for YAML frontmatter extraction
FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n(.*)", re.DOTALL)

# agentskills.io name validation: lowercase, digits, hyphens
NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")

# Valid frontmatter fields per agentskills.io spec
VALID_FIELDS = {
    "name", "description", "license", "compatibility", "metadata", "allowed-tools",
    # OpenClaw top-level extensions
    "version", "homepage", "user-invocable", "disable-model-invocation",
    "command-dispatch", "command-tool", "command-arg-mode",
}

OPENCLAW_METADATA_ALIASES = ("openclaw", "clawdbot", "clawdis", "moltbot")


def _parse_openclaw_metadata(metadata: dict) -> OpenClawMetadata | None:
    """Extract OpenClaw metadata from any known alias key in the metadata block."""
    if not isinstance(metadata, dict):
        return None
    raw = None
    for alias in OPENCLAW_METADATA_ALIASES:
        if alias in metadata:
            raw = metadata[alias]
            break
    if raw is None:
        return None
    if not isinstance(raw, dict):
        return None

    req_raw = raw.get("requires", {}) or {}
    requires = SkillRequirements(
        env=req_raw.get("env") or [],
        bins=req_raw.get("bins") or [],
        any_bins=req_raw.get("anyBins") or req_raw.get("anyOf") or [],
        configs=req_raw.get("config") or req_raw.get("configs") or [],
    )
    return OpenClawMetadata(
        requires=requires,
        primary_env=raw.get("primaryEnv"),
        always=raw.get("always", False),
        emoji=raw.get("emoji"),
        homepage=raw.get("homepage"),
        os=raw.get("os", []),
        skill_key=raw.get("skillKey"),
    )


def parse_frontmatter(skill_md_path: Path) -> tuple[dict, str]:
    """Parse SKILL.md into (frontmatter_dict, body_markdown)."""
    content = skill_md_path.read_text(encoding="utf-8")
    match = FRONTMATTER_RE.match(content)
    if not match:
        raise ValueError(f"No valid YAML frontmatter in {skill_md_path}")
    frontmatter = yaml.safe_load(match.group(1))
    body = match.group(2).strip()
    return frontmatter, body


def validate_metadata(fm: dict, dir_name: str) -> list[str]:
    """Validate frontmatter against agentskills.io spec. Returns list of errors."""
    errors = []

    for key in fm:
        if key not in VALID_FIELDS:
            logger.debug("Unknown frontmatter field in '%s': %s", dir_name, key)

    name = fm.get("name")
    if not name:
        errors.append("Missing required field: name")

    desc = fm.get("description")
    if not desc:
        errors.append("Missing required field: description")
    elif len(desc) > 1024:
        errors.append("description exceeds 1024 characters")

    return errors


def _resolve_skill_name(fm: dict, dir_name: str) -> str:
    """Return the canonical skill name to use for a skill package.

    Prefers the frontmatter ``name`` when it is a valid slug; otherwise falls
    back to the directory name (which is always a valid slug when installed by
    ``pulsebot skill install``).
    """
    name = str(fm.get("name", "")).strip()
    if name and NAME_RE.match(name) and len(name) <= 64:
        return name
    # Frontmatter name is display-only (e.g. "Polymarket") — use dir slug
    return dir_name


def load_skill_metadata(skill_dir: Path) -> SkillMetadata | None:
    """Load only metadata from a skill package (Tier 1 - cheap)."""
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return None

    try:
        fm, _ = parse_frontmatter(skill_md)
        errors = validate_metadata(fm, skill_dir.name)
        if errors:
            logger.warning("Skill '%s' has validation errors: %s", skill_dir.name, errors)
            return None

        raw_metadata = fm.get("metadata", {}) or {}
        openclaw = _parse_openclaw_metadata(raw_metadata)
        skill_name = _resolve_skill_name(fm, skill_dir.name)

        return SkillMetadata(
            name=skill_name,
            description=fm["description"],
            source=SkillSource.EXTERNAL,
            path=skill_dir,
            license=fm.get("license"),
            compatibility=fm.get("compatibility"),
            metadata=raw_metadata,
            allowed_tools=fm.get("allowed-tools"),
            version=fm.get("version"),
            openclaw=openclaw,
        )
    except Exception as e:
        logger.warning("Failed to load skill metadata from %s: %s", skill_dir, e)
        return None


def load_skill_content(meta: SkillMetadata) -> SkillContent:
    """Load full skill content on demand (Tier 2 - expensive)."""
    if meta.path is None:
        raise ValueError("Cannot load content for skill without path")

    skill_md = meta.path / "SKILL.md"
    _, body = parse_frontmatter(skill_md)

    scripts: dict[str, str] = {}
    scripts_dir = meta.path / "scripts"
    if scripts_dir.exists():
        for f in scripts_dir.iterdir():
            if f.is_file():
                scripts[f.name] = f.read_text(encoding="utf-8")

    references: dict[str, str] = {}
    refs_dir = meta.path / "references"
    if refs_dir.exists():
        for f in refs_dir.iterdir():
            if f.is_file():
                references[f.name] = f.read_text(encoding="utf-8")

    return SkillContent(
        metadata=meta,
        instructions=body,
        scripts=scripts,
        references=references,
    )


def discover_skills(skill_dirs: list[str]) -> list[SkillMetadata]:
    """Scan configured directories for agentskills.io packages.

    Directories are scanned in order; first occurrence of a skill name wins.
    """
    skills: list[SkillMetadata] = []
    seen_names: set[str] = set()

    for dir_path in skill_dirs:
        base = Path(dir_path)
        if not base.exists():
            logger.debug("Skill directory does not exist: %s", base)
            continue
        for child in sorted(base.iterdir()):
            if child.is_dir() and (child / "SKILL.md").exists():
                meta = load_skill_metadata(child)
                if meta and meta.name not in seen_names:
                    skills.append(meta)
                    seen_names.add(meta.name)

    return skills
