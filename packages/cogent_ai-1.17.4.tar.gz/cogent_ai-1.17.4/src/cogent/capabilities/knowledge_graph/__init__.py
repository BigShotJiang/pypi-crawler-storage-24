"""
KnowledgeGraph capability for persistent entity/relationship memory.

This module provides a knowledge graph capability with multiple storage backends:
- In-memory graph (uses networkx if available)
- SQLite database for persistence and large graphs
- JSON file for simple persistence with auto-save

Example:
    ```python
    from cogent.capabilities import KnowledgeGraph

    # In-memory (default)
    kg = KnowledgeGraph()

    # SQLite for persistence
    kg = KnowledgeGraph(backend="sqlite", path="knowledge.db")

    # Or load from file (auto-detects backend)
    kg = KnowledgeGraph.from_file("knowledge.db")
    ```
"""

from cogent.capabilities.knowledge_graph.backends import (
    GraphBackend,
    InMemoryGraph,
    JSONFileGraph,
    SQLiteGraph,
    _HAS_SQLITE,
)
from cogent.capabilities.knowledge_graph.capability import KnowledgeGraph
from cogent.capabilities.knowledge_graph.models import Entity, Relationship

_base_all = [
    # Main capability
    "KnowledgeGraph",
    # Models
    "Entity",
    "Relationship",
    # Backends
    "GraphBackend",
    "InMemoryGraph",
    "JSONFileGraph",
]

if _HAS_SQLITE:
    _base_all.append("SQLiteGraph")

__all__ = _base_all
