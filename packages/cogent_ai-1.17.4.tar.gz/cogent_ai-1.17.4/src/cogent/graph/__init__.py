"""Knowledge Graph module for Cogent.

This module provides a clean, modern API for building and querying knowledge graphs.
"""

from cogent.graph import visualization
from cogent.graph.engines import Engine, NativeEngine
from cogent.graph.graph import Graph
from cogent.graph.models import Entity, Relationship
from cogent.graph.query import QueryPattern, QueryResult, match, parse_pattern
from cogent.graph.storage import FileStorage, MemoryStorage, Storage
from cogent.graph.storage import _has_sqlalchemy

if _has_sqlalchemy:
    from cogent.graph.storage import SQLStorage

_base_all = [
    "Graph",
    "Entity",
    "Relationship",
    "Engine",
    "NativeEngine",
    "Storage",
    "MemoryStorage",
    "FileStorage",
    "QueryPattern",
    "QueryResult",
    "parse_pattern",
    "match",
    "visualization",
]

if _has_sqlalchemy:
    _base_all.append("SQLStorage")

# Conditionally import NetworkXEngine
try:
    from cogent.graph.engines import NetworkXEngine

    __all__ = [*_base_all, "NetworkXEngine"]
except ImportError:
    __all__ = _base_all
