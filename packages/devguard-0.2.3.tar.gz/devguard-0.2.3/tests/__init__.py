"""Tests for devguard."""
