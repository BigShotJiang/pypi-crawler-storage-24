from dataclasses import dataclass, field
from typing import Optional, List, Any, Dict

@dataclass
class ContextParams:
    timezone: str = "UTC"
    locale: str = "en_US"
    target_currency: Optional[str] = None
    transliterate: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}

@dataclass
class AddressOutput:
    street: Optional[str] = None
    house_number: Optional[str] = None
    floor_unit: Optional[str] = None
    postal_code: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    type: Optional[str] = None
    address_latin: Optional[str] = None
    error: Optional[str] = None

@dataclass
class NameOutput:
    title: Optional[str] = None
    first: Optional[str] = None
    middle: Optional[str] = None
    last: Optional[str] = None
    suffix: Optional[str] = None
    nickname: Optional[str] = None
    gender: Optional[str] = None
    confidence: Optional[str] = None
    name_latin: Optional[str] = None

@dataclass
class MoneyOutput:
    float_value: Optional[float] = None
    currency: Optional[str] = None
    currency_symbol: Optional[str] = None
    clean_string: Optional[str] = None
    conversion_required: Optional[bool] = None
    error: Optional[str] = None

@dataclass
class BatchResponse:
    task_id: str
    status: str
    results: Optional[List[Any]] = None
    error: Optional[str] = None
