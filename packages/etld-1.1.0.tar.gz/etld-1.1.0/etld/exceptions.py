class ETLDBaseException(Exception):
    """Base exception for ETL-D SDK"""
    pass

class ETLDAuthenticationError(ETLDBaseException):
    """Raised when API key is invalid or missing"""
    pass

class ETLDRateLimitError(ETLDBaseException):
    """Raised when API rate limit is exceeded"""
    pass

class ETLDProcessingError(ETLDBaseException):
    """Raised when there is an error processing the request"""
    pass

class PaymentRequiredError(ETLDBaseException):
    """Raised when credits are exhausted (HTTP 402)"""
    def __init__(self, message: str, checkout_url: str, recovery_hint: str):
        super().__init__(message)
        self.checkout_url = checkout_url
        self.recovery_hint = recovery_hint

class ETLDValidationError(ETLDBaseException):
    """Raised when request validation fails"""
    pass
