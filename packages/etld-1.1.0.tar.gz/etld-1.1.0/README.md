# ETL-D SDK: The Agentic Data & Finance Middleware
Stop wasting LLM context windows and tokens on basic data parsing and complex financial logic. ETL-D is a stateless, deterministic middleware designed specifically for AI Agents, No-Code automation (n8n, Make), and high-performance integrations. We handle chaotic global data and B2B financial pipelines using algorithmic parsing with an LLM-Routing Fallback to guarantee 100% accuracy and perfect JSON schemas.

🚀 The Arsenal (Available Endpoints)
ETL-D goes far beyond basic string manipulation. Your AI agents gain instant access to:

- **B2B Parsing**: Transform raw Norma 43 (N43) bank statements and complex nested XMLs into flat, queryable JSONs.
- **Financial Operations**: Generate SEPA Direct Debit (PAIN.008) XMLs, fetch historical Forex rates, and autonomously map messy transactions to GAAP/PGC accounting codes.
- **Data Engineering Magic**: Generate E-commerce Cartesian product variants, normalize physical measurement units, and intelligently split chaotic contact strings.
- **Core Enrichment**: E.164 phone validation, ISO 8601 relative date parsing (timezone-aware), and global address structuring with LLM-fallback for complex regions (e.g., UAE, Japan).

🤖 The Agentic Workflow (Autonomous Billing)
ETL-D V1.0+ introduces features strictly designed for autonomous systems that handle their own billing lifecycles.

### 1. Zero-Touch Agent Provisioning
If your AI agent is booting up for the first time and lacks an API key, it can provision one programmatically. No emails, no logins.

```python
import etld
from etld.client import EtlDClient

client = EtlDClient(api_key="BOOTSTRAP") # Key not needed for provisioning

# Provision a new session
provision = client.create_provisioning_session()
print(f"Pay here: {provision['checkout_url']}")

# Poll for the key
status = client.poll_provisioning_status(provision['poll_id'])
if status['status'] == 'ready':
    print(f"Your API Key: {status['api_key']}")
```

### 2. Handling 402 Payment Required
When an agent exhausts its credits, the API returns a HTTP 402. The SDK intercepts this and raises a `PaymentRequiredError` containing a `checkout_url`. The agent can autonomously navigate to the URL, pay for a top-up, and resume execution.

```python
from etld.exceptions import PaymentRequiredError

try:
    client.enrich_date("next Tuesday")
except PaymentRequiredError as e:
    print(f"Credits exhausted. Top up at: {e.checkout_url}")
    # Agent can now wait, or notify human, or even use a headless browser to pay!
```

⚡ Async Batch Processing
Process 10,000+ records without blocking your server. Queue the batch, and the SDK automatically polls the background worker until the job is done.

```python
task_id = client.enrich_batch("date", ["next Tuesday", "27/10/2023"])
results = client.wait_for_batch(task_id)
print(results)
```

## Installation
```bash
pip install etld
```
