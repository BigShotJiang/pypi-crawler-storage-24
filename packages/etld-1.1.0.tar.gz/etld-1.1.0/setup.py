from setuptools import setup, find_packages

setup(
    name="etld",
    version="1.1.0",
    author="ETL-D Team",
    author_email="hello@etl-d.net",
    description="Official Python SDK for the ETL-D API - Stateless Data Middleware for AI Agents.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/pablixnieto2/enrichermagic",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
