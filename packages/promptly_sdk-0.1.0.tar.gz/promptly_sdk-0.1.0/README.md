# promptly-ai

Official Python SDK for [Promptly](https://getpromptly.in) - LLM cost optimization proxy.

## Install

```bash
pip install promptly-ai
```

## Quick Start

```python
from promptly import Promptly

client = Promptly(api_key="sk-promptly-...")

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}]
)

print(response.choices[0].message.content)
```

## Streaming

```python
stream = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Write a poem."}],
    stream=True,
)

for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")
```

## Access Promptly Metadata

```python
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}]
)

meta = response.promptly_metadata
print(f"Saved: ${meta['savings']}")
print(f"Routed to: {meta['routed_model']}")
print(f"Cache hit: {meta['cache_hit']}")
```

## Wrap Existing Client

Already using the OpenAI SDK? Wrap it in one line:

```python
import openai
from promptly import wrap

client = wrap(openai.OpenAI(api_key="sk-your-openai-key"))
# All calls now go through Promptly
```

## Configuration

```python
client = Promptly(
    api_key="sk-promptly-...",
    base_url="https://api.getpromptly.in/v1",  # default
    timeout=30,                                  # seconds
    max_retries=2,                               # auto-retry on failure
)
```

## Requirements

- Python 3.8+
- `openai` >= 1.0.0
