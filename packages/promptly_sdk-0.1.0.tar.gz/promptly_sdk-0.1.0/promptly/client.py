"""
Promptly client - a thin wrapper around the OpenAI SDK that points
all requests to the Promptly proxy.
"""

from __future__ import annotations

from openai import OpenAI


_DEFAULT_BASE_URL = "https://api.getpromptly.in/v1"


class Promptly(OpenAI):
    """
    Drop-in OpenAI client that routes through Promptly.

    Usage::

        from promptly import Promptly

        client = Promptly(api_key="sk-promptly-...")
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float | None = None,
        max_retries: int = 2,
        **kwargs,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            **kwargs,
        )


def wrap(client: OpenAI, api_key: str | None = None) -> OpenAI:
    """
    Wrap an existing OpenAI client to route through Promptly.

    Usage::

        import openai
        from promptly import wrap

        client = wrap(openai.OpenAI(api_key="sk-openai-..."), api_key="sk-promptly-...")
    """
    client.base_url = _DEFAULT_BASE_URL  # type: ignore[assignment]
    if api_key:
        client.api_key = api_key
    return client
