from __future__ import annotations

from typing import Any, Callable

from donkit.llm import FunctionDefinition, Tool


class AgentTool:
    def __init__(
        self,
        name: str,
        description: str,
        parameters: dict[str, Any],
        handler: Callable[[dict[str, Any]], str],
        is_async: bool = False,
    ) -> None:
        self.name = name
        self.description = description
        self.parameters = parameters
        self.handler = handler
        self.is_async = is_async

    def to_tool_spec(self) -> Tool:
        return Tool(
            function=FunctionDefinition(
                name=self.name, description=self.description, parameters=self.parameters
            )
        )
