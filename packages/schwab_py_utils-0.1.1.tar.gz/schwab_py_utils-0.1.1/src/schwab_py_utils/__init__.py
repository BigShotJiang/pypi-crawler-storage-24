"""
schwab-py-utils: Quality-of-life utilities for schwab-py.

Example usage:
    from schwab_py_utils import get_client, get_price_history, normalize_ticker, Client, AsyncClient

    client = get_client()
    df = get_price_history(client, "AAPL", interval=5)
"""

from schwab.client import AsyncClient, Client

from ._types import (
    EquityTickerClassStyle,
    SchwabPriceHistoryInterval,
    SchwabPriceHistoryIntervalStr,
    Ticker,
    TickerNormalized,
    TickerUpperCase,
)
from .client import (
    SchwabClientMethod,
    SchwabPyGetClientMethod,
    get_client,
    get_schwab_client,
)
from .price_history import (
    get_price_history,
    get_price_history_from_schwab,
    get_price_history_from_schwab_non_df,
    get_price_history_raw,
    price_history_to_df,
)
from .ticker import (
    DEFAULT_DOLLAR_PREFIX_TICKERS,
    add_dollar_prefix_tickers,
    dollar_prefix_tickers,
    normalize_ticker,
)

__all__ = [
    # Client
    "Client",
    "AsyncClient",
    "get_client",
    "get_schwab_client",
    "SchwabClientMethod",
    "SchwabPyGetClientMethod",
    # Price history
    "get_price_history",
    "get_price_history_from_schwab",
    "get_price_history_raw",
    "get_price_history_from_schwab_non_df",
    "price_history_to_df",
    # Ticker
    "normalize_ticker",
    "add_dollar_prefix_tickers",
    "dollar_prefix_tickers",
    "DEFAULT_DOLLAR_PREFIX_TICKERS",
    # Types
    "Ticker",
    "TickerUpperCase",
    "TickerNormalized",
    "EquityTickerClassStyle",
    "SchwabPriceHistoryInterval",
    "SchwabPriceHistoryIntervalStr",
]
