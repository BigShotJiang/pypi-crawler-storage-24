from typing import Literal

Ticker = str
TickerUpperCase = str
TickerNormalized = str
EquityTickerClassStyle = Literal[".", "/"]

SchwabPriceHistoryInterval = Literal[1, 5, 10, 15, 30, "d", "w"]
SchwabPriceHistoryIntervalStr = Literal["1", "5", "10", "15", "30", "d", "w"]
