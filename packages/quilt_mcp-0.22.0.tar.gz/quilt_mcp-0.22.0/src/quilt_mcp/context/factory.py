"""RequestContextFactory for request-scoped service creation."""

from __future__ import annotations

from typing import Literal, Optional

from quilt_mcp.context.exceptions import ServiceInitializationError
from quilt_mcp.context.utils import generate_request_id, resolve_user_id_from_auth
from quilt_mcp.context.request_context import RequestContext
from quilt_mcp.context.runtime_context import get_runtime_auth
from quilt_mcp.services.auth_service import AuthService
from quilt_mcp.config import get_mode_config
from quilt_mcp.services.iam_auth_service import IAMAuthService
from quilt_mcp.services.jwt_auth_service import JWTAuthService
from quilt_mcp.services.permissions_service import PermissionDiscoveryService
from quilt_mcp.services.workflow_service import WorkflowService
from quilt_mcp.storage.file_storage import FileBasedWorkflowStorage


class RequestContextFactory:
    """Factory for creating request-scoped contexts and services."""

    def __init__(self, mode: str = "auto") -> None:
        mode_config = get_mode_config()
        if mode == "auto":
            self.mode: Literal["single-user", "multiuser"] = "multiuser" if mode_config.is_multiuser else "single-user"
        else:
            # Validate that mode is one of the expected values
            if mode not in ("single-user", "multiuser"):
                raise ValueError(f"Invalid mode: {mode}. Must be 'single-user' or 'multiuser'")
            self.mode = mode  # type: ignore[assignment]
        self._is_multiuser = self.mode == "multiuser"

    def create_context(
        self,
        *,
        request_id: Optional[str] = None,
    ) -> RequestContext:
        auth_state = get_runtime_auth()
        user_id = resolve_user_id_from_auth(auth_state)
        resolved_request_id = generate_request_id(request_id)

        try:
            auth_service = self._create_auth_service()
        except Exception as exc:
            raise ServiceInitializationError("AuthService", str(exc)) from exc

        try:
            permission_service = self._create_permission_service(auth_service)
        except Exception as exc:
            raise ServiceInitializationError("PermissionService", str(exc)) from exc

        try:
            workflow_service = self._create_workflow_service()
        except Exception as exc:
            raise ServiceInitializationError("WorkflowService", str(exc)) from exc

        user_id = user_id or auth_service.get_user_identity().get("user_id")

        return RequestContext(
            request_id=resolved_request_id,
            user_id=user_id,
            auth_service=auth_service,
            permission_service=permission_service,
            workflow_service=workflow_service,
        )

    def _create_auth_service(self) -> AuthService:
        mode_config = get_mode_config()
        runtime_auth = get_runtime_auth()

        if runtime_auth and runtime_auth.access_token:
            return JWTAuthService()  # type: ignore[return-value]

        if mode_config.requires_jwt:
            # In stdio/local test workflows there may be no request-scoped runtime JWT.
            # JWTAuthService can still resolve credentials from discovery sources.
            return JWTAuthService()  # type: ignore[return-value]

        return IAMAuthService()  # type: ignore[return-value]

    def _create_permission_service(self, auth_service: AuthService) -> PermissionDiscoveryService:
        return PermissionDiscoveryService(auth_service)

    def _create_workflow_service(self) -> Optional[WorkflowService]:
        if self._is_multiuser:
            return None
        storage = FileBasedWorkflowStorage()
        return WorkflowService(storage=storage)
