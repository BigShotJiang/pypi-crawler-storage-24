"""Platform GraphQL backend implementation.

This module provides a concrete implementation of QuiltOps backed by the
Platform GraphQL API and JWT authentication claims.
"""

from __future__ import annotations

import json
import logging
import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, cast

import boto3

from quilt_mcp.ops.quilt_ops import QuiltOps
from quilt_mcp.ops.tabulator_mixin import TabulatorMixin
from quilt_mcp.ops.admin_ops import AdminOps
from quilt_mcp.ops.exceptions import AuthenticationError, BackendError, ValidationError, NotFoundError
from quilt_mcp.domain import (
    Package_Info,
    Content_Info,
    Bucket_Info,
    Auth_Status,
    Catalog_Config,
)
from quilt_mcp.domain.package_builder import PackageBuilder, PackageEntry
from quilt_mcp.services.browsing_session_client import BrowsingSessionClient
from quilt_mcp.services.jwt_auth_service import JWTAuthService
from quilt_mcp.utils.common import (
    graphql_endpoint,
    normalize_url,
    get_dns_name_from_url,
    resolve_registry_url,
    _runtime_boto3_session,
)
from quilt_mcp.backends.platform_graphql_client import PlatformGraphQLClient
from quilt_mcp.backends.graphql_queries import (
    DELETE_REVISION_MUTATION,
    GET_PACKAGE_QUERY,
    PACKAGE_CONSTRUCT_MUTATION,
    PACKAGE_REVISIONS_FOR_DELETE_QUERY,
)
from quilt_mcp.utils.helpers import extract_bucket_from_registry

logger = logging.getLogger(__name__)


@dataclass
class DeletionResult:
    """Structured result for package deletion attempts."""

    success: bool
    method: str
    revision_count: int = 0
    error: str | None = None


class Platform_Backend(TabulatorMixin, QuiltOps):
    """Platform GraphQL backend implementation."""

    def __init__(self) -> None:
        self._access_token = self._load_access_token()

        # Admin operations (lazy loaded)
        self._admin_ops: Optional[AdminOps] = None

        self._catalog_url = os.getenv("QUILT_CATALOG_URL")
        if not self._catalog_url:
            raise AuthenticationError("Platform backend requires QUILT_CATALOG_URL environment variable.")
        try:
            self._registry_url = resolve_registry_url(catalog_url=self._catalog_url)
        except Exception as exc:
            raise AuthenticationError(f"Failed to resolve registry URL from catalog config: {exc}") from exc
        if not self._registry_url:
            raise AuthenticationError("Platform backend could not resolve registry URL from QUILT_CATALOG_URL.")

        self._graphql_endpoint = os.getenv("QUILT_GRAPHQL_ENDPOINT")
        if not self._graphql_endpoint and self._registry_url:
            self._graphql_endpoint = graphql_endpoint(self._registry_url)

        if not self._graphql_endpoint:
            raise AuthenticationError(
                "GraphQL endpoint not configured. Set QUILT_GRAPHQL_ENDPOINT or fix QUILT_CATALOG_URL config."
            )

        import requests

        self._requests = requests
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._access_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )
        self._graphql_client = PlatformGraphQLClient(
            session=self._session,
            endpoint=self._graphql_endpoint,
            auth_header=f"Bearer {self._access_token}",
        )

        ttl_seconds = int(os.getenv("QUILT_BROWSING_SESSION_TTL", "180"))
        self._browse_client = BrowsingSessionClient(
            catalog_url=self._catalog_url,
            graphql_endpoint=self._graphql_endpoint,
            access_token=self._access_token,
            session=self._session,
            ttl_seconds=ttl_seconds,
        )

        logger.info("Platform_Backend initialized")

    # ---------------------------------------------------------------------
    # GraphQL auth + endpoint helpers
    # ---------------------------------------------------------------------

    def get_graphql_endpoint(self) -> str:
        if not self._graphql_endpoint:
            raise AuthenticationError("GraphQL endpoint not configured")
        return self._graphql_endpoint

    def get_graphql_auth_headers(self) -> Dict[str, str]:
        if not self._access_token:
            raise AuthenticationError("Missing JWT access token for GraphQL authentication")
        return {"Authorization": f"Bearer {self._access_token}"}

    def execute_graphql_query(
        self,
        query: str,
        variables: Optional[Dict[str, Any]] = None,
        registry: Optional[str] = None,
    ) -> Dict[str, Any]:
        try:
            result = self._graphql_client.execute(query=query, variables=variables)

            if "errors" in result:
                error_messages = [err.get("message", str(err)) for err in result.get("errors", [])]
                raise BackendError(f"GraphQL query failed: {'; '.join(error_messages)}")

            return result
        except self._requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            if status in {401, 403}:
                raise AuthenticationError("GraphQL query not authorized") from exc
            error_text = exc.response.text if exc.response is not None else str(exc)
            raise BackendError(f"GraphQL query failed: {error_text}") from exc
        except BackendError:
            raise
        except Exception as exc:
            raise BackendError(f"GraphQL query failed: {exc}") from exc

    # ---------------------------------------------------------------------
    # Auth + catalog
    # ---------------------------------------------------------------------

    def _backend_get_auth_status(self) -> Auth_Status:
        """Backend primitive: Get basic authentication status.

        Returns Auth_Status with basic fields only (is_authenticated, logged_in_url,
        catalog_name, registry_url=None). Catalog config enrichment (region,
        tabulator_data_catalog) is handled by QuiltOps Template Method.

        Returns:
            Auth_Status object with basic authentication fields only

        Raises:
            AuthenticationError: When authentication credentials are invalid
            BackendError: When the backend operation fails to retrieve auth status
        """
        try:
            query = """
            query AuthStatus {
              me {
                name
                email
                isAdmin
              }
            }
            """
            result = self.execute_graphql_query(query)
            me = result.get("data", {}).get("me")
            is_authenticated = bool(me)

            catalog_url = self._catalog_url
            catalog_name = get_dns_name_from_url(catalog_url) if catalog_url else None

            # Return basic Auth_Status (no catalog config enrichment)
            # QuiltOps Template Method will enrich with region, tabulator_data_catalog, and registry_url
            return Auth_Status(
                is_authenticated=is_authenticated,
                logged_in_url=catalog_url,
                catalog_name=catalog_name,
                registry_url=None,  # Will be enriched by Template Method
            )
        except AuthenticationError:
            raise
        except Exception as exc:
            raise BackendError(f"Failed to get authentication status: {exc}") from exc

    # HIGH-LEVEL METHOD REMOVED - Now implemented in QuiltOps base class
    # get_catalog_config() is now a concrete method in QuiltOps that calls:
    # - _backend_get_catalog_config() primitive
    # - _transform_catalog_config() transformation (in QuiltOps base)

    def configure_catalog(self, catalog_url: str) -> None:
        raise ValidationError(
            "Platform backend uses static configuration. Set QUILT_CATALOG_URL environment variable instead."
        )

    def get_registry_url(self) -> Optional[str]:
        return self._registry_url

    # ---------------------------------------------------------------------
    # Read operations
    # ---------------------------------------------------------------------

    # HIGH-LEVEL METHOD REMOVED - Now implemented in QuiltOps base class
    # list_buckets() is now a concrete method in QuiltOps that calls:
    # - _backend_list_buckets() primitive (which returns Bucket_Info objects directly)

    # HIGH-LEVEL METHOD REMOVED - Now implemented in QuiltOps base class
    # search_packages() is now a concrete method in QuiltOps that calls:
    # - _backend_search_packages() primitive
    # - _transform_search_result_to_package_info() primitive

    def get_package_info(self, package_name: str, registry: str) -> Package_Info:
        try:
            bucket = self._extract_bucket_from_registry(registry)
            gql = """
            query PackageInfo($bucket: String!, $name: String!) {
              package(bucket: $bucket, name: $name) {
                bucket
                name
                modified
                revision(hashOrTag: "latest") {
                  hash
                  message
                  userMeta
                }
              }
            }
            """
            result = self.execute_graphql_query(gql, variables={"bucket": bucket, "name": package_name})
            package_data = result.get("data", {}).get("package")
            if not package_data:
                raise NotFoundError(f"Package not found: {package_name}")

            return self._transform_package_details(package_data, registry)
        except NotFoundError:
            raise
        except Exception as exc:
            raise BackendError(
                f"Platform backend get_package_info failed: {exc}",
                context={"package_name": package_name, "registry": registry},
            ) from exc

    def browse_content(self, package_name: str, registry: str, path: str = "") -> List[Content_Info]:
        try:
            bucket = self._extract_bucket_from_registry(registry)
            gql = """
            query BrowseContent($bucket: String!, $name: String!, $path: String!) {
              package(bucket: $bucket, name: $name) {
                revision(hashOrTag: "latest") {
                  dir(path: $path) {
                    path
                    children {
                      __typename
                      ... on PackageFile { path size physicalKey }
                      ... on PackageDir { path }
                    }
                  }
                  file(path: $path) {
                    path
                    size
                    physicalKey
                  }
                }
              }
            }
            """
            result = self.execute_graphql_query(
                gql,
                variables={"bucket": bucket, "name": package_name, "path": path or ""},
            )
            revision = result.get("data", {}).get("package", {}).get("revision")
            if not revision:
                raise NotFoundError(f"Package not found: {package_name}")

            dir_info = revision.get("dir")
            file_info = revision.get("file")

            if dir_info:
                children = dir_info.get("children", [])
                return [self._transform_content_entry(entry) for entry in children]

            if file_info:
                return [self._transform_content_entry({"__typename": "PackageFile", **file_info})]

            raise NotFoundError(f"Path not found in package: {path}")
        except NotFoundError:
            raise
        except Exception as exc:
            raise BackendError(
                f"Platform backend browse_content failed: {exc}",
                context={"package_name": package_name, "registry": registry, "path": path},
            ) from exc

    # HIGH-LEVEL METHOD REMOVED - Now implemented in QuiltOps base class
    # diff_packages() is now a concrete method in QuiltOps that calls:
    # - _backend_get_package() primitive (twice)
    # - _backend_diff_packages() primitive

    # ---------------------------------------------------------------------
    # Content URLs
    # ---------------------------------------------------------------------

    # HIGH-LEVEL METHOD REMOVED - Now implemented in QuiltOps base class
    # get_content_url() is now a concrete method in QuiltOps that calls:
    # - _backend_get_file_url() primitive

    # ---------------------------------------------------------------------
    # Write operations (quilt3 Package)
    # ---------------------------------------------------------------------

    def get_aws_client(self, service_name: str, region: Optional[str] = None) -> Any:
        runtime_session = _runtime_boto3_session()
        if runtime_session is not None:
            return runtime_session.client(service_name, region_name=region)

        try:
            jwt_session = JWTAuthService().get_boto3_session()
            return jwt_session.client(service_name, region_name=region)
        except Exception:
            pass

        return boto3.client(service_name, region_name=region)

    def get_boto3_client(self, service_name: str, region: Optional[str] = None) -> Any:
        """Backward-compatible alias for get_aws_client()."""
        return self.get_aws_client(service_name=service_name, region=region)

    # HIGH-LEVEL METHODS REMOVED - Now implemented in QuiltOps base class
    # create_package_revision() is now a concrete method in QuiltOps that calls:
    # - _backend_create_empty_package() primitive
    # - _backend_add_file_to_package() primitive
    # - _backend_set_package_metadata() primitive
    # - _backend_push_package() primitive

    def _try_s3_fallback_delete(self, bucket_name: str, package_name: str) -> DeletionResult:
        """Fallback deletion path by removing package pointer files from S3."""
        prefix = f".quilt/named_packages/{package_name}/"
        s3_client = self.get_aws_client("s3")
        pointer_keys: list[str] = []
        continuation_token: Optional[str] = None

        while True:
            params: Dict[str, Any] = {"Bucket": bucket_name, "Prefix": prefix, "MaxKeys": 1000}
            if continuation_token:
                params["ContinuationToken"] = continuation_token
            response = s3_client.list_objects_v2(**params)
            for item in response.get("Contents", []):
                key = item.get("Key", "")
                if key and not key.endswith("/"):
                    pointer_keys.append(key)
            if not response.get("IsTruncated"):
                break
            continuation_token = response.get("NextContinuationToken")

        if not pointer_keys:
            return DeletionResult(success=False, method="s3-pointer", error="No pointer files found")

        had_delete_errors = False
        for i in range(0, len(pointer_keys), 1000):
            batch = pointer_keys[i : i + 1000]
            delete_response = s3_client.delete_objects(
                Bucket=bucket_name,
                Delete={"Objects": [{"Key": key} for key in batch], "Quiet": True},
            )
            if delete_response.get("Errors"):
                had_delete_errors = True
                logger.error(
                    "Pointer delete batch had errors",
                    extra={
                        "bucket": bucket_name,
                        "package_name": package_name,
                        "errors": delete_response["Errors"],
                    },
                )

        return DeletionResult(
            success=not had_delete_errors,
            method="s3-pointer",
            revision_count=len(pointer_keys),
            error=None if not had_delete_errors else "S3 pointer delete returned errors",
        )

    def _try_graphql_delete(self, bucket_name: str, package_name: str) -> DeletionResult:
        """Delete all package revisions via GraphQL packageRevisionDelete."""
        revision_hashes: list[str] = []
        page_num = 1
        per_page = 100
        total_revisions: Optional[int] = None
        while True:
            result = self.execute_graphql_query(
                PACKAGE_REVISIONS_FOR_DELETE_QUERY,
                variables={"bucket": bucket_name, "name": package_name, "page": page_num, "perPage": per_page},
            )
            package_payload = result.get("data", {}).get("package")
            if not package_payload:
                break
            revisions = package_payload.get("revisions", {})
            if total_revisions is None:
                total_revisions = revisions.get("total", 0)
            page_entries = revisions.get("page", []) or []
            if not page_entries:
                break
            for entry in page_entries:
                hash_value = entry.get("hash")
                if hash_value:
                    revision_hashes.append(hash_value)
            if total_revisions is not None and len(revision_hashes) >= total_revisions:
                break
            page_num += 1

        if not revision_hashes:
            return DeletionResult(success=False, method="graphql", error="No package revisions found")

        had_failure = False
        for hash_or_tag in sorted(set(revision_hashes), reverse=True):
            try:
                result = self.execute_graphql_query(
                    DELETE_REVISION_MUTATION,
                    variables={"bucket": bucket_name, "name": package_name, "hash": hash_or_tag},
                )
                payload = result.get("data", {}).get("packageRevisionDelete", {})
                if payload.get("__typename") != "PackageRevisionDeleteSuccess":
                    had_failure = True
                    logger.error(
                        "Package revision delete returned non-success",
                        extra={
                            "bucket": bucket_name,
                            "package_name": package_name,
                            "hash": hash_or_tag,
                            "typename": payload.get("__typename"),
                            "message": payload.get("message"),
                        },
                    )
            except Exception as exc:
                had_failure = True
                logger.error(
                    "Package revision delete failed",
                    extra={
                        "bucket": bucket_name,
                        "package_name": package_name,
                        "hash": hash_or_tag,
                        "error": str(exc),
                    },
                )

        return DeletionResult(
            success=not had_failure,
            method="graphql",
            revision_count=len(set(revision_hashes)),
            error=None if not had_failure else "GraphQL revision deletion had failures",
        )

    def delete_package(self, bucket: str, name: str) -> bool:
        """Delete all known package revisions.

        Prefer fast pointer deletion and fall back to GraphQL revision deletion.
        """
        try:
            bucket_name = self._extract_bucket_from_registry(bucket)

            try:
                pointer_result = self._try_s3_fallback_delete(bucket_name, name)
                if pointer_result.success:
                    return True
            except Exception as exc:
                logger.warning(
                    "Fast S3 pointer delete path failed, falling back to GraphQL delete",
                    extra={"bucket": bucket_name, "package_name": name, "error": str(exc)},
                )

            graphql_result = self._try_graphql_delete(bucket_name, name)
            if not graphql_result.success and graphql_result.error:
                logger.warning(
                    "GraphQL package delete returned non-success",
                    extra={
                        "bucket": bucket_name,
                        "package_name": name,
                        "error": graphql_result.error,
                        "revision_count": graphql_result.revision_count,
                    },
                )
            return graphql_result.success
        except Exception as exc:
            logger.error(
                "Failed to enumerate package revisions for deletion",
                extra={"bucket": bucket, "package_name": name, "error": str(exc)},
            )
            return False

    # ---------------------------------------------------------------------
    # Admin operations
    # ---------------------------------------------------------------------

    @property
    def admin(self) -> AdminOps:
        """Get admin operations interface.

        Returns:
            AdminOps instance for performing admin operations
        """
        if self._admin_ops is None:
            # Import here to avoid circular dependency
            from quilt_mcp.backends.platform_admin_ops import Platform_Admin_Ops

            self._admin_ops = Platform_Admin_Ops(self)
        return self._admin_ops

    # =========================================================================
    # Backend Primitives (Template Method Pattern)
    # =========================================================================
    # These methods implement the abstract backend primitives defined in QuiltOps.
    # They wrap GraphQL operations without adding validation or transformation logic.

    def _backend_create_empty_package(self) -> PackageBuilder:
        """Create a new empty package representation (backend primitive).

        Returns:
            PackageBuilder with empty entries list
        """
        return {"entries": []}

    def _backend_add_file_to_package(self, package: PackageBuilder, logical_key: str, s3_uri: str) -> None:
        """Add a file reference to package representation (backend primitive).

        Args:
            package: PackageBuilder being constructed
            logical_key: Logical path within package
            s3_uri: S3 URI of file to add
        """
        package["entries"].append(
            {
                "logicalKey": logical_key,
                "physicalKey": s3_uri,
            }
        )

    def _backend_set_package_metadata(self, package: PackageBuilder, metadata: Dict[str, Any]) -> None:
        """Set metadata on package representation (backend primitive).

        Args:
            package: PackageBuilder being constructed
            metadata: Metadata dictionary
        """
        package["metadata"] = metadata

    def _backend_push_package(
        self, package: PackageBuilder, package_name: str, registry: str, message: str, copy: bool
    ) -> str:
        """Push package via GraphQL packageConstruct mutation (backend primitive).

        Args:
            package: PackageBuilder to push
            package_name: Full package name
            registry: Registry S3 URL
            message: Commit message
            copy: If True, promote package to copy objects

        Returns:
            Top hash of pushed package (empty string if push fails)
        """
        bucket = self._extract_bucket_from_registry(registry)

        # Build GraphQL packageConstruct mutation
        # Note: Error types (PackagePushInvalidInputFailure, PackagePushComputeFailure)
        # are not available in current GraphQL schema, so we rely on general error handling
        variables = {
            "params": {
                "bucket": bucket,
                "name": package_name,
                "message": message,
                "userMeta": package.get("metadata", {}),
                "workflow": None,
            },
            "src": {"entries": package["entries"]},
        }

        result = self.execute_graphql_query(PACKAGE_CONSTRUCT_MUTATION, variables=variables)
        package_construct = result.get("data", {}).get("packageConstruct", {})
        typename = package_construct.get("__typename")

        if typename == "PackagePushSuccess":
            revision = package_construct.get("revision", {})
            top_hash: str = str(revision.get("hash", ""))

            # If copy=True, promote the package to copy objects to registry
            if copy:
                promoted_hash = self._promote_package(
                    bucket, package_name, top_hash, message, package.get("metadata", {})
                )
                return str(promoted_hash)

            return top_hash
        elif typename == "PackagePushInvalidInputFailure":
            # Handle validation errors
            errors = package_construct.get("errors", [])
            error_msg = "; ".join(f"{e.get('path', 'unknown')}: {e.get('message', 'unknown')}" for e in errors)
            raise ValidationError(f"Invalid package input: {error_msg}")
        elif typename == "PackagePushComputeFailure":
            # Handle compute failures
            message_text = package_construct.get("message", "Unknown compute failure")
            raise BackendError(f"Package creation compute failure: {message_text}")
        else:
            # Handle any other non-success response
            raise BackendError(f"Package creation failed with response type: {typename}")

    def _backend_get_package(self, package_name: str, registry: str, top_hash: Optional[str] = None) -> Any:
        """Retrieve package via GraphQL query (backend primitive).

        Args:
            package_name: Full package name
            registry: Registry S3 URL
            top_hash: Optional specific version hash

        Returns:
            Package data structure with contentsFlatMap

        Raises:
            NotFoundError: If package not found
        """
        bucket = self._extract_bucket_from_registry(registry)

        variables = {
            "bucket": bucket,
            "name": package_name,
            "hash": top_hash or "latest",
        }

        result = self.execute_graphql_query(GET_PACKAGE_QUERY, variables=variables)
        package_data = result.get("data", {}).get("package")

        if not package_data:
            raise NotFoundError(f"Package not found: {package_name}")

        return package_data

    def _backend_get_package_entries(self, package: Any) -> Dict[str, PackageEntry]:
        """Get all entries from package data (backend primitive).

        Args:
            package: Package data structure from GraphQL

        Returns:
            Dict mapping logical_key to PackageEntry with normalized types
        """
        contents_flat_map = package.get("revision", {}).get("contentsFlatMap", {})
        entries: Dict[str, PackageEntry] = {}

        for logical_key, entry_data in contents_flat_map.items():
            if isinstance(entry_data, dict):
                entries[logical_key] = PackageEntry(
                    logicalKey=logical_key,
                    physicalKey=entry_data.get("physicalKey", ""),
                    size=entry_data.get("size"),
                    hash=entry_data.get("hash"),
                    meta=entry_data.get("meta"),
                )

        return entries

    def _backend_get_package_metadata(self, package: Any) -> Dict[str, Any]:
        """Get metadata from package data (backend primitive).

        Args:
            package: Package data structure from GraphQL

        Returns:
            Package metadata dictionary (empty dict if no metadata)
        """
        result: Dict[str, Any] = package.get("revision", {}).get("userMeta", {})
        return result

    def _backend_search_packages(self, query: str, registry: str) -> List[Dict[str, Any]]:
        """Execute GraphQL package search (backend primitive).

        Args:
            query: Search query string
            registry: Registry S3 URL

        Returns:
            List of package data dictionaries (not domain objects)
        """
        bucket = self._extract_bucket_from_registry(registry)

        gql = """
        query SearchPackages($buckets: [String!], $searchString: String) {
          searchPackages(buckets: $buckets, searchString: $searchString) {
            __typename
            ... on PackagesSearchResultSet {
              firstPage(size: 1000, order: NEWEST) {
                hits {
                  name
                  bucket
                  hash
                  modified
                  comment
                  meta
                }
              }
            }
            ... on EmptySearchResultSet {
              _
            }
            ... on InvalidInput {
              errors { path message name context }
            }
            ... on OperationError {
              message
              name
              context
            }
          }
        }
        """

        result = self.execute_graphql_query(gql, variables={"buckets": [bucket], "searchString": query})
        search_result = result.get("data", {}).get("searchPackages", {})
        typename = search_result.get("__typename")

        # Handle both old and new API response types
        if typename == "PackageSearchResults":
            # New API format
            hits = search_result.get("hits", [])
        elif typename == "PackagesSearchResultSet":
            # Old API format (with pagination)
            hits = search_result.get("firstPage", {}).get("hits", [])
        elif typename == "EmptySearchResultSet":
            # Empty results
            return []
        elif typename == "InvalidInput":
            errors = search_result.get("errors", [])
            raise ValidationError(f"Search invalid input: {errors}")
        elif typename == "OperationError":
            message = search_result.get("message", "Search failed")
            raise Exception(f"Search operation error: {message}")
        else:
            raise Exception(f"Unexpected search response type: {typename}")

        # Return raw hits (not transformed to domain objects)
        return [
            {
                "name": hit.get("name", ""),
                "bucket": hit.get("bucket", bucket),
                "top_hash": hit.get("hash", ""),
                "modified": hit.get("modified"),
                "comment": hit.get("comment"),
                "meta": hit.get("meta"),
                "registry": registry,
            }
            for hit in hits
        ]

    # _backend_diff_packages inherited from base class (uses _backend_get_package_entries)

    def _backend_browse_package_content(self, package: Any, path: str) -> List[Dict[str, Any]]:
        """List contents of package at path via GraphQL (backend primitive).

        Args:
            package: Package data structure from GraphQL (must include name and bucket)
            path: Path within package to browse

        Returns:
            List of content entry dictionaries (not domain objects)
        """
        # Extract package info from package data
        package_name = package.get("name", "")
        bucket = package.get("bucket", "")

        gql = """
        query BrowseContent($bucket: String!, $name: String!, $path: String!) {
          package(bucket: $bucket, name: $name) {
            revision(hashOrTag: "latest") {
              dir(path: $path) {
                path
                children {
                  __typename
                  ... on PackageFile { path size physicalKey }
                  ... on PackageDir { path }
                }
              }
              file(path: $path) {
                path
                size
                physicalKey
              }
            }
          }
        }
        """

        result = self.execute_graphql_query(
            gql, variables={"bucket": bucket, "name": package_name, "path": path or ""}
        )
        revision = result.get("data", {}).get("package", {}).get("revision")

        if not revision:
            raise NotFoundError(f"Package not found: {package_name}")

        dir_info = revision.get("dir")
        file_info = revision.get("file")

        if dir_info:
            children = dir_info.get("children", [])
            return [
                {
                    "path": entry.get("path", ""),
                    "size": entry.get("size"),
                    "type": "directory" if entry.get("__typename") == "PackageDir" else "file",
                }
                for entry in children
            ]

        if file_info:
            return [
                {
                    "path": file_info.get("path", ""),
                    "size": file_info.get("size"),
                    "type": "file",
                }
            ]

        raise NotFoundError(f"Path not found in package: {path}")

    def _backend_get_file_url(
        self, package_name: str, registry: str, path: str, top_hash: Optional[str] = None
    ) -> str:
        """Generate download URL via browsing session (backend primitive).

        Args:
            package_name: Full package name
            registry: Registry S3 URL
            path: Path to file within package
            top_hash: Optional specific version hash

        Returns:
            Presigned URL for file download
        """
        bucket = self._extract_bucket_from_registry(registry)

        # Get revision hash if not provided
        if not top_hash:
            gql = """
            query GetRevisionHash($bucket: String!, $name: String!) {
              package(bucket: $bucket, name: $name) {
                revision(hashOrTag: "latest") {
                  hash
                }
              }
            }
            """
            result = self.execute_graphql_query(gql, variables={"bucket": bucket, "name": package_name})
            top_hash = result.get("data", {}).get("package", {}).get("revision", {}).get("hash")

        if not top_hash:
            raise Exception("Missing revision hash for browsing session")

        scope = f"s3://{bucket}#package={package_name}&hash={top_hash}"
        return self._browse_client.get_presigned_url(scope=scope, path=path)

    def _backend_get_session_info(self) -> Dict[str, Any]:
        """Get Platform session information (backend primitive).

        Returns:
            Dict with session info
        """
        return {
            "is_authenticated": bool(self._access_token),
            "catalog_url": self._catalog_url,
            "registry_url": self._registry_url,
        }

    # _backend_get_catalog_config inherited from base class (standard HTTP GET)

    def _backend_list_buckets(self) -> List[Bucket_Info]:
        """List S3 buckets via GraphQL (backend primitive).

        Returns:
            List of Bucket_Info domain objects
        """
        from quilt_mcp.domain import Bucket_Info

        gql = """
        query ListBuckets {
          bucketConfigs {
            name
          }
        }
        """

        result = self.execute_graphql_query(gql)
        bucket_configs = result.get("data", {}).get("bucketConfigs", [])

        buckets = []
        for bucket in bucket_configs:
            if bucket.get("name"):
                bucket_info = Bucket_Info(
                    name=bucket["name"],
                    region="unknown",  # GraphQL doesn't return region in bucketConfigs
                    access_level="unknown",  # Would require additional queries
                    created_date=None,  # Not available in GraphQL bucketConfigs
                )
                buckets.append(bucket_info)

        return buckets

    def _backend_get_boto3_session(self) -> Any:
        """Get boto3 session (backend primitive).

        Raises:
            AuthenticationError: Platform backend doesn't support boto3 access
        """
        raise AuthenticationError("AWS client access is not available in Platform backend.")

    def _transform_search_result_to_package_info(self, result: Dict[str, Any], registry: str) -> Package_Info:
        """Transform GraphQL search result to Package_Info (backend primitive).

        Args:
            result: Backend-specific search result dictionary
            registry: Registry URL for context

        Returns:
            Package_Info domain object
        """
        return self._transform_search_hit(result, registry)

    def _transform_content_entry_to_content_info(self, entry: Dict[str, Any]) -> Content_Info:
        """Transform GraphQL content entry to Content_Info (backend primitive).

        Args:
            entry: Backend-specific content entry dictionary

        Returns:
            Content_Info domain object
        """
        return self._transform_content_entry(entry)

    # ---------------------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------------------

    def _load_access_token(self) -> str:
        from quilt_mcp.auth.jwt_discovery import JWTDiscovery

        return JWTDiscovery.discover_or_raise()

    # TRANSFORMATION METHOD REMOVED - Now in QuiltOps base class
    # _transform_catalog_config() is now a concrete method in QuiltOps base class

    def _transform_search_hit(self, hit: Dict[str, Any], registry: str) -> Package_Info:
        name = hit.get("name") or ""
        bucket = hit.get("bucket") or self._extract_bucket_from_registry(registry)
        # Handle both GraphQL response format ("hash") and primitive format ("top_hash")
        top_hash = hit.get("top_hash") or hit.get("hash") or ""
        modified = self._normalize_package_datetime(hit.get("modified"))

        meta = self._parse_meta(hit.get("meta"))
        description = self._extract_description(meta, hit.get("comment"))
        tags = self._extract_tags_from_meta(meta)

        return Package_Info(
            name=name,
            description=description,
            tags=tags,
            modified_date=modified,
            registry=registry,
            bucket=bucket,
            top_hash=top_hash,
        )

    def _transform_package_details(self, package_data: Dict[str, Any], registry: str) -> Package_Info:
        revision = package_data.get("revision") or {}
        meta = self._parse_meta(revision.get("userMeta"))
        description = self._extract_description(meta, revision.get("message"))
        tags = self._extract_tags_from_meta(meta)
        modified = self._normalize_package_datetime(package_data.get("modified"))

        return Package_Info(
            name=package_data.get("name", ""),
            description=description,
            tags=tags,
            modified_date=modified,
            registry=registry,
            bucket=package_data.get("bucket", self._extract_bucket_from_registry(registry)),
            top_hash=revision.get("hash", ""),
        )

    def _transform_content_entry(self, entry: Dict[str, Any]) -> Content_Info:
        typename = entry.get("__typename") or "PackageFile"
        path = entry.get("path") or ""
        size = self._normalize_size(entry.get("size"))
        meta = entry.get("meta")
        if typename == "PackageDir":
            content_type = "directory"
        else:
            content_type = "file"

        return Content_Info(
            path=path,
            size=size,
            type=content_type,
            modified_date=None,
            download_url=None,
            meta=meta,  # Entry-level metadata
        )

    def _normalize_package_datetime(self, datetime_value: Any) -> str:
        if datetime_value is None:
            return "None"
        if hasattr(datetime_value, "isoformat"):
            return str(datetime_value.isoformat())
        return str(datetime_value)

    def _normalize_size(self, size: Any) -> Optional[int]:
        if size is None:
            return None
        try:
            return int(size)
        except (ValueError, TypeError):
            return None

    def _extract_description(self, meta: Optional[Dict[str, Any]], fallback: Optional[str]) -> Optional[str]:
        if isinstance(meta, dict):
            desc = meta.get("description")
            if desc is not None:
                return str(desc)
        return str(fallback) if fallback else None

    def _extract_tags_from_meta(self, meta: Optional[Dict[str, Any]]) -> List[str]:
        if not isinstance(meta, dict):
            return []
        tags = meta.get("tags") or meta.get("keywords") or []
        if isinstance(tags, list):
            return [str(tag) for tag in tags if tag is not None]
        if isinstance(tags, str):
            return [tags]
        return []

    def _parse_meta(self, meta: Any) -> Optional[Dict[str, Any]]:
        if meta is None:
            return None
        if isinstance(meta, dict):
            return meta
        if isinstance(meta, str):
            try:
                parsed = json.loads(meta)
                return parsed if isinstance(parsed, dict) else None
            except json.JSONDecodeError:
                return None
        return None

    def _extract_bucket_from_registry(self, registry: str) -> str:
        return extract_bucket_from_registry(registry)

    def _promote_package(self, bucket: str, name: str, hash: str, message: str, user_meta: Dict) -> str:
        """
        Promote (copy) a package to the registry bucket using packagePromote mutation.
        Returns the new package hash after promotion.
        """
        mutation = """
        mutation PackagePromote($params: PackagePushParams!, $src: PackagePromoteSource!) {
          packagePromote(params: $params, src: $src) {
            __typename
            ... on PackagePushSuccess {
              revision { hash }
            }
            ... on InvalidInput {
              errors { path message name }
            }
            ... on OperationError {
              message
              name
            }
          }
        }
        """

        variables = {
            "params": {
                "bucket": bucket,
                "name": name,
                "message": message,
                "userMeta": user_meta,
                "workflow": None,
            },
            "src": {
                "bucket": bucket,
                "name": name,
                "hash": hash,
            },
        }

        result = self.execute_graphql_query(mutation, variables=variables)
        package_promote = result.get("data", {}).get("packagePromote", {})
        typename = package_promote.get("__typename")

        if typename == "PackagePushSuccess":
            revision = package_promote.get("revision", {})
            promoted_hash = cast(str, revision.get("hash", ""))
            return promoted_hash
        elif typename == "InvalidInput":
            errors = package_promote.get("errors", [])
            error_messages = [f"{err.get('path', 'unknown')}: {err.get('message', 'invalid input')}" for err in errors]
            raise ValidationError(f"Package promotion invalid input: {'; '.join(error_messages)}")
        elif typename == "OperationError":
            message_text = package_promote.get("message", "Package promotion failed")
            raise BackendError(f"Package promotion error: {message_text}")
        else:
            raise BackendError(f"Unexpected packagePromote response type: {typename}")

    # =========================================================================
    # TRANSFORMATION METHODS REMOVED - Now in QuiltOps base class
    # =========================================================================
    # The following methods have been removed as they are now in QuiltOps base class:
    #
    # - _extract_logical_key()    -> Now in QuiltOps._extract_logical_key()
    # - _build_catalog_url()      -> Now in QuiltOps._build_catalog_url()
