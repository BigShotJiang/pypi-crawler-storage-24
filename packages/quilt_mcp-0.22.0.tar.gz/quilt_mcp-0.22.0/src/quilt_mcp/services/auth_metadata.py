"""Shared helpers for authentication-oriented resources.

These functions were originally implemented as MCP tools but are read-only in
practice.  Consolidating them here lets resources consume the logic directly
while other call sites (e.g. onboarding flows) can reuse the same helpers
without routing through ``quilt_mcp.tools``.
"""

from __future__ import annotations

import os
import tempfile
from typing import Any, Dict
from urllib.parse import urlparse

try:
    from quilt_mcp.ops.factory import QuiltOpsFactory
except ModuleNotFoundError:  # pragma: no cover - optional dependency
    # Provide a stub so tests can patch QuiltOpsFactory without requiring quilt3.
    class QuiltOpsFactory:  # type: ignore[no-redef]
        def __init__(self, *args: object, **kwargs: object) -> None:
            raise ModuleNotFoundError("quilt3 is required for QuiltOpsFactory")

        def create(self, *args: object, **kwargs: object) -> None:
            raise ModuleNotFoundError("quilt3 is required for QuiltOpsFactory")


from quilt_mcp.utils.common import get_dns_name_from_url as _extract_catalog_name_from_url


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_bucket_from_registry(registry: str) -> str:
    """Normalize registry URIs to bare bucket names."""
    if registry.startswith("s3://"):
        return registry[5:].split("/", 1)[0]
    return registry


def _get_catalog_info() -> Dict[str, Any]:
    """Return catalog configuration details by delegating to QuiltOps."""
    factory = QuiltOpsFactory()
    quilt_ops = factory.create()
    auth_status = quilt_ops.get_auth_status()

    # Transform Auth_Status to the expected dictionary format
    return {
        "catalog_name": auth_status.catalog_name or "unknown",
        "navigator_url": auth_status.logged_in_url,  # navigator_url is legacy alias for logged_in_url
        "registry_url": auth_status.registry_url,
        "is_authenticated": auth_status.is_authenticated,
        "logged_in_url": auth_status.logged_in_url,
        "region": getattr(auth_status, 'region', None),
        "tabulator_data_catalog": getattr(auth_status, 'tabulator_data_catalog', None),
    }


def _get_catalog_host_from_config() -> str | None:
    """Detect the catalog hostname from current Quilt configuration."""
    try:
        factory = QuiltOpsFactory()
        quilt_ops = factory.create()
        auth_status = quilt_ops.get_auth_status()

        if auth_status.logged_in_url:
            parsed = urlparse(auth_status.logged_in_url)
            hostname = parsed.hostname
            return hostname if hostname else None
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Public helpers consumed by resources and higher-level workflows
# ---------------------------------------------------------------------------


def catalog_info() -> Dict[str, Any]:
    """Summarize catalog configuration for discovery and troubleshooting."""
    try:
        from quilt_mcp.config import get_mode_config

        mode_config = get_mode_config()
        info = _get_catalog_info()

        # Determine detection method
        if info["logged_in_url"]:
            detection_method = "authentication"
        elif info["navigator_url"]:
            detection_method = "navigator_config"
        elif info["registry_url"]:
            detection_method = "registry_config"
        else:
            detection_method = "unknown"

        result: Dict[str, Any] = {
            "catalog_name": info["catalog_name"],
            "is_authenticated": info["is_authenticated"],
            "detection_method": detection_method,
            "status": "success",
            "deployment_mode": mode_config.deployment_mode.value,
            "deployment": {
                "mode": mode_config.deployment_mode.value,
                "backend": mode_config.backend_name,
                "transport": mode_config.default_transport,
                "multiuser": mode_config.is_multiuser,
            },
        }

        if info["navigator_url"]:
            result["navigator_url"] = info["navigator_url"]
        if info["registry_url"]:
            result["registry_url"] = info["registry_url"]
        if info["logged_in_url"]:
            result["logged_in_url"] = info["logged_in_url"]
        if info["region"]:
            result["region"] = info["region"]
        if info["tabulator_data_catalog"]:
            result["tabulator_data_catalog"] = info["tabulator_data_catalog"]

        result["message"] = (
            f"Connected to catalog: {info['catalog_name']}"
            if info["is_authenticated"]
            else f"Configured for catalog: {info['catalog_name']} (not authenticated)"
        )

        # Integrate search backend status for discovery
        try:
            from quilt_mcp.search.utils import get_search_backend_status

            backend_status = get_search_backend_status()
            result["search_backend_status"] = backend_status
        except Exception as backend_exc:
            # Don't fail catalog_info if backend status check fails
            result["search_backend_status"] = {
                "available": False,
                "backend": None,
                "capabilities": [],
                "status": "error",
                "error": f"Failed to get backend status: {backend_exc}",
            }

        return result

    except Exception as exc:
        return {
            "status": "error",
            "error": f"Failed to get catalog info: {exc}",
            "catalog_name": "unknown",
            "detection_method": "error",
            "deployment_mode": "unknown",
        }


def auth_status() -> Dict[str, Any]:
    """Audit Quilt authentication status and suggest next actions."""
    try:
        factory = QuiltOpsFactory()
        quilt_ops = factory.create()
        auth_status_obj = quilt_ops.get_auth_status()

        if auth_status_obj.logged_in_url:
            registry_bucket = None
            try:
                if auth_status_obj.registry_url:
                    registry_bucket = _extract_bucket_from_registry(auth_status_obj.registry_url)
            except Exception:
                pass

            try:
                user_info = {
                    "username": "current_user",
                    "email": "user@example.com",
                }
            except Exception:
                user_info = {"username": "unknown", "email": "unknown"}

            return {
                "status": "authenticated",
                "catalog_url": auth_status_obj.logged_in_url,
                "catalog_name": auth_status_obj.catalog_name or "unknown",
                "registry_bucket": registry_bucket,
                "write_permissions": "unknown",
                "user_info": user_info,
                "suggested_actions": [
                    "Try listing packages with: packages_list()",
                    "Test bucket permissions with: bucket_access_check(bucket_name)",
                    "Discover your writable buckets with: aws_permissions_discover()",
                    "Create your first package with: package_create_from_s3()",
                ],
                "message": f"Successfully authenticated to {auth_status_obj.catalog_name or 'Quilt catalog'}",
                "search_available": True,
                "next_steps": {
                    "immediate": "Try: aws_permissions_discover() to see your bucket access",
                    "package_creation": "Try: package_create_from_s3() to create your first package",
                    "exploration": "Try: packages_list() to browse existing packages",
                },
            }

        setup_instructions = [
            "1. Configure catalog: quilt3 config https://open.quiltdata.com",
            "2. Login: quilt3 login",
            "3. Follow the browser authentication flow",
            "4. Verify with: auth_status()",
        ]

        return {
            "status": "not_authenticated",
            "catalog_name": auth_status_obj.catalog_name or "none",
            "message": "Not logged in to Quilt catalog",
            "search_available": False,
            "setup_instructions": setup_instructions,
            "quick_setup": {
                "description": "Get started quickly with Quilt",
                "steps": [
                    {"step": 1, "action": "Configure catalog", "command": "quilt3 config https://open.quiltdata.com"},
                    {"step": 2, "action": "Login", "command": "quilt3 login"},
                    {"step": 3, "action": "Verify", "command": "auth_status()"},
                ],
            },
            "help": {
                "documentation": "https://docs.quiltdata.com/",
                "support": "For help, visit Quilt documentation or contact support",
            },
        }

    except Exception as exc:
        return {
            "status": "error",
            "error": f"Failed to check authentication: {exc}",
            "catalog_name": "unknown",
            "troubleshooting": {
                "common_issues": [
                    "AWS credentials not configured",
                    "Quilt not installed properly",
                    "Network connectivity issues",
                ],
                "suggested_fixes": [
                    "Check AWS credentials with: aws sts get-caller-identity",
                    "Reinstall quilt3: pip install --upgrade quilt3",
                    "Check network connectivity",
                ],
            },
            "setup_instructions": [
                "1. Configure catalog: quilt3 config https://open.quiltdata.com",
                "2. Login: quilt3 login",
            ],
        }


def filesystem_status() -> Dict[str, Any]:
    """Probe filesystem access for Quilt tooling."""
    result: Dict[str, Any] = {
        "home_directory": os.path.expanduser("~"),
        "temp_directory": tempfile.gettempdir(),
        "current_directory": os.getcwd(),
    }

    try:
        test_file = os.path.join(result["home_directory"], ".quilt_test_write")
        with open(test_file, "w", encoding="utf-8") as handle:
            handle.write("test")
        os.remove(test_file)
        result["home_writable"] = True
    except Exception as exc:
        result["home_writable"] = False
        result["home_write_error"] = str(exc)

    try:
        with tempfile.NamedTemporaryFile(delete=True) as tmp:
            tmp.write(b"test")
        result["temp_writable"] = True
    except Exception as exc:
        result["temp_writable"] = False
        result["temp_write_error"] = str(exc)

    if result.get("home_writable"):
        result.update(
            status="full_access",
            message="Full filesystem access available - all Quilt tools should work",
            tools_available=[
                # Authentication & Configuration
                "auth_status",
                "catalog_configure",
                "catalog_info",
                "catalog_uri",
                "catalog_url",
                "filesystem_status",
                # Package Management (Read)
                "package_browse",
                "package_diff",
                "packages_list",
                # Package Management (Write)
                "package_create",
                "package_create_from_s3",
                "package_delete",
                "package_update",
                # Bucket Operations (Read)
                "bucket_object_fetch",
                "bucket_object_info",
                "bucket_object_link",
                "bucket_object_text",
                "bucket_objects_list",
                # Bucket Operations (Write)
                "bucket_objects_put",
                # Permissions & Discovery
                "bucket_recommendations_get",
                "check_bucket_access",
                "discover_permissions",
                "get_resource",
                # Search & Query
                "search_catalog",
                "search_explain",
                "search_suggest",
                # Athena & Glue
                "athena_databases_list",
                "athena_query_execute",
                "athena_query_history",
                "athena_query_validate",
                "athena_table_schema",
                "athena_tables_list",
                "athena_workgroups_list",
                # Tabulator
                "list_tabulator_buckets",
                "list_tabulator_tables",
                "tabulator_bucket_query",
                "tabulator_buckets_list",
                "tabulator_table_create",
                "tabulator_table_delete",
                "tabulator_table_rename",
                "tabulator_tables_list",
                # Visualization & Summary
                "create_data_visualization",
                "create_quilt_summary_files",
                "generate_package_visualizations",
                "generate_quilt_summarize_json",
                # Workflows
                "workflow_add_step",
                "workflow_create",
                "workflow_get_status",
                "workflow_list_all",
                "workflow_template_apply",
                "workflow_update_step",
                # Admin (if permissions allow)
                "admin_roles_list",
                "admin_sso_config_get",
                "admin_sso_config_remove",
                "admin_sso_config_set",
                "admin_tabulator_open_query_get",
                "admin_tabulator_open_query_set",
                "admin_user_add_roles",
                "admin_user_create",
                "admin_user_delete",
                "admin_user_get",
                "admin_user_remove_roles",
                "admin_user_reset_password",
                "admin_user_set_active",
                "admin_user_set_admin",
                "admin_user_set_email",
                "admin_user_set_role",
                "admin_users_list",
            ],
        )
    elif result.get("temp_writable"):
        result.update(
            status="limited_access",
            message="Limited filesystem access - Quilt tools may work with proper configuration",
            tools_available=[
                # Authentication & Configuration
                "auth_status",
                "catalog_configure",
                "catalog_info",
                "catalog_uri",
                "catalog_url",
                "filesystem_status",
                # Package Management (Read only)
                "package_browse",
                "package_diff",
                "packages_list",
                # Bucket Operations (Read only)
                "bucket_object_fetch",
                "bucket_object_info",
                "bucket_object_link",
                "bucket_object_text",
                "bucket_objects_list",
                # Permissions & Discovery
                "bucket_recommendations_get",
                "check_bucket_access",
                "discover_permissions",
                "get_resource",
                # Search & Query
                "search_catalog",
                "search_explain",
                "search_suggest",
                # Athena & Glue (Read only)
                "athena_databases_list",
                "athena_query_execute",
                "athena_query_history",
                "athena_query_validate",
                "athena_table_schema",
                "athena_tables_list",
                "athena_workgroups_list",
                # Tabulator (Read only)
                "list_tabulator_buckets",
                "list_tabulator_tables",
                "tabulator_bucket_query",
                "tabulator_buckets_list",
                "tabulator_tables_list",
            ],
        )
    else:
        result.update(
            status="read_only",
            message="Read-only filesystem access - limited Quilt functionality available",
            tools_available=[
                # Authentication & Configuration (Read only)
                "auth_status",
                "catalog_info",
                "catalog_uri",
                "catalog_url",
                "filesystem_status",
                # Package Management (Browse only)
                "package_browse",
                "package_diff",
                "packages_list",
                # Bucket Operations (Read only)
                "bucket_object_info",
                "bucket_object_link",
                "bucket_object_text",
                "bucket_objects_list",
                # Permissions & Discovery (Read only)
                "bucket_recommendations_get",
                "check_bucket_access",
                "get_resource",
                # Search & Query (Read only)
                "search_catalog",
                "search_explain",
                "search_suggest",
                # Athena & Glue (Read only)
                "athena_databases_list",
                "athena_query_history",
                "athena_table_schema",
                "athena_tables_list",
                "athena_workgroups_list",
                # Tabulator (Read only)
                "list_tabulator_buckets",
                "list_tabulator_tables",
                "tabulator_buckets_list",
                "tabulator_tables_list",
            ],
        )

    return result


def configure_catalog(catalog_url: str) -> Dict[str, Any]:
    """Configure the Quilt catalog URL.

    Args:
        catalog_url: Full catalog URL or friendly name (demo, sandbox, open).

    Returns:
        Dict containing configuration result with status, catalog_url, and next steps.
    """
    try:
        # Common catalog mappings
        catalog_mappings = {
            "demo": "https://demo.quiltdata.com",
            "sandbox": "https://sandbox.quiltdata.com",
            "open": "https://open.quiltdata.com",
            "example": "https://open.quiltdata.com",
        }

        # Determine target URL
        original_input = catalog_url
        if catalog_url.lower() in catalog_mappings:
            catalog_url = catalog_mappings[catalog_url.lower()]
            friendly_name = original_input.lower()
        elif catalog_url.startswith(("http://", "https://")):
            friendly_name = _extract_catalog_name_from_url(catalog_url)
        elif not catalog_url.startswith(("http://", "https://")):
            # Try to construct URL
            catalog_url = f"https://{catalog_url}"
            friendly_name = original_input
        else:
            friendly_name = _extract_catalog_name_from_url(catalog_url)

        # Configure the catalog
        factory = QuiltOpsFactory()
        quilt_ops = factory.create()
        quilt_ops.configure_catalog(catalog_url)

        # Verify configuration
        auth_status_obj = quilt_ops.get_auth_status()
        configured_url = auth_status_obj.logged_in_url

        return {
            "status": "success",
            "catalog_url": catalog_url,
            "configured_url": configured_url,
            "message": f"Successfully configured catalog: {friendly_name}",
            "next_steps": [
                "Login with: quilt3 login",
                "Verify with: auth_status()",
                "Start exploring with: packages_list()",
            ],
            "help": {
                "login_command": "quilt3 login",
                "verify_command": "auth_status()",
                "documentation": "https://docs.quiltdata.com/",
            },
        }

    except Exception as exc:
        # Platform backend is configured via environment and does not support runtime
        # catalog mutation. Treat matching catalog requests as a successful no-op.
        if "Platform backend uses static configuration" in str(exc):
            configured_url = os.getenv("QUILT_CATALOG_URL")
            if configured_url and configured_url.rstrip("/") == catalog_url.rstrip("/"):
                return {
                    "status": "success",
                    "catalog_url": catalog_url,
                    "configured_url": configured_url,
                    "message": "Catalog already configured via platform environment",
                    "next_steps": [
                        "Verify with: auth_status()",
                        "Start exploring with: packages_list()",
                    ],
                    "help": {
                        "verify_command": "auth_status()",
                        "documentation": "https://docs.quiltdata.com/",
                    },
                }
        return {
            "status": "error",
            "error": f"Failed to configure catalog: {exc}",
            "catalog_url": catalog_url,
            "available_catalogs": list(catalog_mappings.keys()) if "catalog_mappings" in locals() else [],
            "troubleshooting": {
                "common_issues": [
                    "Invalid catalog URL",
                    "Network connectivity problems",
                    "Quilt configuration file permissions",
                ],
                "suggested_fixes": [
                    "Verify the catalog URL is correct and accessible",
                    "Check network connectivity",
                    "Ensure write permissions to Quilt config directory",
                    "Use one of the available catalog names: demo, sandbox, open",
                ],
            },
        }


__all__ = [
    "auth_status",
    "catalog_info",
    "configure_catalog",
    "filesystem_status",
    "_extract_catalog_name_from_url",
    "_extract_bucket_from_registry",
    "_get_catalog_info",
    "_get_catalog_host_from_config",
]
