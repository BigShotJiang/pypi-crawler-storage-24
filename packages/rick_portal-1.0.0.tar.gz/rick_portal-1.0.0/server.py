import os
import shutil
import socket
import tempfile
import time
import threading
import urllib.parse
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from waitress import serve

# --- CONFIGURATION ---
# Mobile uploads go straight to Downloads
UPLOAD_FOLDER = os.path.join(os.path.expanduser('~'), 'Downloads')

# PC-to-mobile share folder: hidden in temp, auto-cleaned after 24h
SHARE_FOLDER = os.path.join(tempfile.gettempdir(), '.rick-portal')
os.makedirs(SHARE_FOLDER, exist_ok=True)

FILE_MAX_AGE = 24 * 60 * 60  # 24 hours in seconds

# 100 GB Limit for large video transfers
MAX_SIZE = 100 * 1024 * 1024 * 1024 

app = Flask(__name__)

# --- FRONTEND ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RICK Portal</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0a0a0a;
            color: #e0e0e0;
            min-height: 100vh;
            padding: 1.5rem;
        }

        h1 {
            font-size: 1.4rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            color: #fff;
            text-align: center;
            padding: 1.5rem 0;
        }

        .section { margin-bottom: 2rem; }

        .label {
            font-size: 0.75rem;
            font-weight: 600;
            color: #555;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 0.75rem;
        }

        /* UPLOAD */
        .upload-btn {
            display: block;
            width: 100%;
            padding: 1rem;
            border: 1px dashed #333;
            border-radius: 12px;
            background: #111;
            color: #888;
            font-size: 0.95rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .upload-btn:active { background: #1a1a1a; border-color: #555; }

        .progress-wrap {
            margin-top: 0.75rem;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            overflow: hidden;
            display: none;
        }

        .progress-bar {
            width: 0%;
            height: 100%;
            background: #fff;
            transition: width 0.2s;
        }

        #status {
            text-align: center;
            font-size: 0.8rem;
            margin-top: 0.5rem;
            color: #666;
            min-height: 18px;
        }

        /* DIVIDER */
        .divider {
            border: none;
            border-top: 1px solid #1a1a1a;
            margin: 0.5rem 0;
        }

        /* FILES */
        .file-list { list-style: none; }

        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid #141414;
        }

        .file-item:last-child { border-bottom: none; }

        .file-name {
            font-size: 0.9rem;
            color: #ccc;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            flex: 1;
            margin-right: 1rem;
        }

        .btn-dl {
            flex-shrink: 0;
            padding: 0.35rem 0.9rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: #000;
            background: #fff;
            border: none;
            border-radius: 20px;
            text-decoration: none;
            transition: opacity 0.2s;
        }

        .btn-dl:active { opacity: 0.7; }

        .empty {
            color: #333;
            padding: 1.5rem 0;
            font-size: 0.85rem;
            text-align: center;
        }

        .refresh {
            display: block;
            margin: 1.25rem auto 0;
            padding: 0.5rem 1.2rem;
            font-size: 0.8rem;
            font-weight: 600;
            color: #555;
            background: none;
            border: 1px solid #222;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .refresh:active { color: #fff; border-color: #444; }
    </style>
</head>
<body>

<h1>RICK PORTAL</h1>

<div class="section">
    <div class="label">Send to PC</div>
    <div class="upload-btn" onclick="document.getElementById('fileInput').click()">
        Tap to select files
        <input type="file" id="fileInput" multiple style="display:none">
    </div>
    <div class="progress-wrap" id="progressContainer">
        <div class="progress-bar" id="progressBar"></div>
    </div>
    <div id="status"></div>
</div>

<hr class="divider">

<div class="section">
    <div class="label">Files from PC{% if files %} &middot; {{ files|length }}{% endif %}</div>
    {% if files %}
        <ul class="file-list">
        {% for file in files %}
            <li class="file-item">
                <span class="file-name">{{ file }}</span>
                <a href="/download/{{ file }}" class="btn-dl" download>Save</a>
            </li>
        {% endfor %}
        </ul>
    {% else %}
        <p class="empty">No files shared yet</p>
    {% endif %}
    <button class="refresh" onclick="location.reload()">Refresh</button>
</div>

<script>
    const fileInput = document.getElementById('fileInput');
    const status = document.getElementById('status');
    const progressBar = document.getElementById('progressBar');
    const progressContainer = document.getElementById('progressContainer');

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length === 0) return;
        uploadFile(fileInput.files[0]);
    });

    function uploadFile(file) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/upload', true);
        const fd = new FormData();
        fd.append('file', file);

        progressContainer.style.display = 'block';
        status.innerText = file.name;
        status.style.color = '#888';

        xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
                progressBar.style.width = (e.loaded / e.total * 100) + '%';
            }
        };

        xhr.onload = () => {
            if (xhr.status === 200) {
                status.innerText = 'Sent';
                status.style.color = '#4ade80';
                progressBar.style.width = '100%';
                setTimeout(() => {
                    progressContainer.style.display = 'none';
                    progressBar.style.width = '0%';
                    status.innerText = '';
                }, 2000);
            } else {
                status.innerText = 'Failed';
                status.style.color = '#f87171';
            }
        };

        xhr.onerror = () => {
            status.innerText = 'Network error';
            status.style.color = '#f87171';
        };

        xhr.send(fd);
    }
</script>
</body>
</html>
"""

# --- ROUTES ---

@app.route('/')
def index():
    # List files in the share folder (PC-to-mobile)
    try:
        files = os.listdir(SHARE_FOLDER)
        files = [f for f in files if not f.startswith('.')]
    except Exception:
        files = []
    return render_template_string(HTML_TEMPLATE, files=files)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No name"}), 400

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)
    return jsonify({"message": "success"}), 200

@app.route('/download/<path:filename>')
def download_file(filename):
    # This enables the phone to download files from the PC
    # Decode URL (handles spaces and special characters in filenames)
    filename = urllib.parse.unquote(filename)
    return send_from_directory(SHARE_FOLDER, filename, as_attachment=True)

# --- NETWORK UTILS ---
def get_ip_list():
    ip_list = []
    # Method 1: Hostname
    try:
        hostname = socket.gethostname()
        for ip in socket.gethostbyname_ex(hostname)[2]:
            if not ip.startswith("127."):
                ip_list.append(ip)
    except: pass
    
    # Method 2: Socket Connection (Most reliable)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
        if ip not in ip_list:
            ip_list.append(ip)
    except: pass
    finally: s.close()
    return ip_list

def cleanup_old_files():
    """Delete files in the share folder older than 24 hours."""
    while True:
        try:
            now = time.time()
            for name in os.listdir(SHARE_FOLDER):
                path = os.path.join(SHARE_FOLDER, name)
                if os.path.isfile(path) and now - os.path.getmtime(path) > FILE_MAX_AGE:
                    os.remove(path)
                    print(f"  🗑️ Auto-deleted (24h expired): {name}")
                elif os.path.isdir(path) and now - os.path.getmtime(path) > FILE_MAX_AGE:
                    shutil.rmtree(path)
                    print(f"  🗑️ Auto-deleted folder (24h expired): {name}")
        except Exception:
            pass
        time.sleep(3600)  # Check every hour

def stdin_listener():
    """Listen for file paths dropped/pasted into the terminal and copy them to the shared folder."""
    while True:
        try:
            line = input()
        except EOFError:
            break
        path = line.strip().strip('"').strip("'")
        if not path:
            continue
        if not os.path.exists(path):
            print(f"  ❌ Not found: {path}")
            continue
        if os.path.isdir(path):
            dest = os.path.join(SHARE_FOLDER, os.path.basename(path))
            shutil.copytree(path, dest, dirs_exist_ok=True)
            print(f"  ✅ Copied folder: {os.path.basename(path)}")
        else:
            shutil.copy2(path, SHARE_FOLDER)
            print(f"  ✅ Copied: {os.path.basename(path)}")

def main():
    ips = get_ip_list()
    port = 5000

    print(f"\n  RICK Portal")
    print(f"  -----------")
    for ip in ips:
        print(f"  http://{ip}:{port}")
    print(f"\n  Drop a file here to share it with mobile\n")

    threading.Thread(target=cleanup_old_files, daemon=True).start()
    threading.Thread(target=stdin_listener, daemon=True).start()

    serve(app, host='0.0.0.0', port=port, threads=6, max_request_body_size=MAX_SIZE)

if __name__ == '__main__':
    main()