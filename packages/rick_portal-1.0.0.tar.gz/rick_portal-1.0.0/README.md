# RICK Portal

Transfer files between your PC and mobile over local WiFi. No apps, no cables, no cloud.

## Install

```
pip install rick-portal
```

## Usage

```
rick-portal
```

Open the printed URL on your mobile browser. That's it.

- **Mobile to PC** — tap "Send to PC" to upload files (saved to your Downloads folder)
- **PC to Mobile** — drag a file into the terminal to share it, then tap "Save" on mobile
- Shared files auto-delete after 24 hours

## Features

- Works on any PC (Windows, Mac, Linux)
- No sign-up, no internet required — runs on your local network
- Supports files up to 100 GB
- Clean, dark mobile UI
- One command to start, one command to install
