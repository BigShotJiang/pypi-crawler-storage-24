from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import remove_none_values


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["read_user"]),
    requires_secrets=[
        "SALESFORCE_ORG_SUBDOMAIN",
        "SALESFORCE_MAX_CONCURRENT_REQUESTS",
    ],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: Context,
) -> Annotated[
    dict[str, Any],
    "Current user profile and Salesforce organization information.",
]:
    """
    Get information about the currently authenticated Salesforce user.

    This is typically the first tool called to establish user context.
    Returns the user's profile details and organization information.
    """
    sf_client = SalesforceClient(context=context)

    user_id = await sf_client.get_current_user_id()

    user_record = await sf_client.get(f"sobjects/User/{user_id}")

    result: dict[str, Any] = {
        "user_id": user_record.get("Id"),
        "name": user_record.get("Name"),
        "first_name": user_record.get("FirstName"),
        "last_name": user_record.get("LastName"),
        "email": user_record.get("Email"),
        "username": user_record.get("Username"),
        "alias": user_record.get("Alias"),
        "title": user_record.get("Title"),
        "department": user_record.get("Department"),
        "company_name": user_record.get("CompanyName"),
        "division": user_record.get("Division"),
        "phone": user_record.get("Phone"),
        "mobile_phone": user_record.get("MobilePhone"),
        "city": user_record.get("City"),
        "state": user_record.get("State"),
        "country": user_record.get("Country"),
        "postal_code": user_record.get("PostalCode"),
        "time_zone": user_record.get("TimeZoneSidKey"),
        "locale": user_record.get("LocaleSidKey"),
        "language": user_record.get("LanguageLocaleKey"),
        "is_active": user_record.get("IsActive"),
        "profile_photo_url": user_record.get("SmallPhotoUrl"),
        "role_id": user_record.get("UserRoleId"),
        "profile_id": user_record.get("ProfileId"),
        "currency": user_record.get("CurrencyIsoCode"),
        "org_subdomain": sf_client.org_subdomain,
    }

    return remove_none_values(result)
