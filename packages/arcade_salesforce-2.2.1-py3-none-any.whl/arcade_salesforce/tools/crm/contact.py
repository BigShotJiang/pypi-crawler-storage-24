import asyncio
from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.exceptions import SalesforceToolExecutionError
from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import (
    build_dynamic_soql,
    clamp_pagination,
    paginated_response,
    sanitize_soql_like_argument,
    validate_salesforce_id,
)


# TODO: Add support for referencing an account by keywords (name, website, etc). We can use the
# get_account_data_by_keywords tool to search for accounts. If more than one is returned, we can
# raise a RetryableToolError providing the matches for the user to choose.
@tool(
    requires_auth=OAuth2(
        id="salesforce",
        scopes=["write_contact"],
    ),
    requires_secrets=[
        "SALESFORCE_ORG_SUBDOMAIN",
        "SALESFORCE_MAX_CONCURRENT_REQUESTS",
    ],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_contact(
    context: Context,
    account_id: Annotated[str, "The ID of the account to create the contact for."],
    last_name: Annotated[str, "The last name of the contact."],
    first_name: Annotated[str | None, "The first name of the contact."] = None,
    email: Annotated[str | None, "The email of the contact."] = None,
    phone: Annotated[str | None, "The phone number of the contact."] = None,
    mobile_phone: Annotated[str | None, "The mobile phone number of the contact."] = None,
    title: Annotated[
        str | None,
        "The title of the contact. E.g. 'CEO', 'Sales Director', 'CTO', etc.",
    ] = None,
    department: Annotated[
        str | None,
        "The department of the contact. E.g. 'Marketing', 'Sales', 'IT', etc.",
    ] = None,
    description: Annotated[str | None, "The description of the contact."] = None,
) -> Annotated[
    dict,
    "The created contact.",
]:
    """Creates a contact in Salesforce."""
    if not last_name:
        raise ToolExecutionError("Last name is required by Salesforce to create a contact.")
    validate_salesforce_id(account_id, "account_id", search_hint="GetAccountDataByKeywords")
    client = SalesforceClient(context)
    contact = await client.create_contact(
        account_id=account_id,
        first_name=first_name,
        last_name=last_name,
        email=email,
        phone=phone,
        mobile_phone=mobile_phone,
        title=title,
        department=department,
        description=description,
    )

    if not contact.get("success"):
        raise SalesforceToolExecutionError(
            message="Failed to create contact",
            errors=contact.get("errors", []),
            status_code=422,
        )

    return {"success": True, "contactId": contact.get("id")}


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["read_contact"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_contacts(
    context: Context,
    query: Annotated[
        str | None,
        "Keyword search against contact name, email, title, and account name.",
    ] = None,
    account_id: Annotated[str | None, "Only return contacts belonging to this Account."] = None,
    title: Annotated[str | None, "Filter by job title (partial match)."] = None,
    limit: Annotated[int, "Maximum results to return (1-50). Defaults to 20."] = 20,
    page: Annotated[int, "Page number for pagination. Defaults to 1 (first page)."] = 1,
) -> Annotated[dict, "Paginated list of contacts matching the search criteria."]:
    """Searches for contacts in Salesforce with optional filters.

    At least one filter (query, account_id, or title) must be provided.
    Use this to find people at specific accounts or with specific roles.
    """
    if not query and not account_id and not title:
        raise ToolExecutionError(
            "At least one filter must be provided: query, account_id, or title."
        )

    client = SalesforceClient(context)
    pp = clamp_pagination(limit, page)

    where: list[str] = []

    if account_id:
        safe_account_id = validate_salesforce_id(
            account_id, "account_id", search_hint="GetAccountDataByKeywords"
        )
        where.append(f"AccountId = '{safe_account_id}'")

    if query:
        kw = sanitize_soql_like_argument(query)
        where.append(
            f"(Name LIKE '%{kw}%' OR Email LIKE '%{kw}%' "
            f"OR Title LIKE '%{kw}%' OR Account.Name LIKE '%{kw}%')"
        )

    if title:
        t = sanitize_soql_like_argument(title)
        where.append(f"Title LIKE '%{t}%'")

    select = (
        "Id, Name, FirstName, LastName, Title, Email, Phone, MobilePhone, "
        "Department, AccountId, Account.Name"
    )

    count_soql = build_dynamic_soql(
        select="COUNT()",
        from_obj="Contact",
        where_clauses=where,
    )
    data_soql = build_dynamic_soql(
        select=select,
        from_obj="Contact",
        where_clauses=where,
        order_by="LastName ASC, FirstName ASC",
        limit=pp.limit,
        offset=pp.offset,
    )

    count_result, data_result = await asyncio.gather(
        client.query(count_soql),
        client.query(data_soql),
    )

    total_count = count_result["totalSize"]
    records = data_result["records"]

    contacts = []
    for rec in records:
        account = rec.get("Account") or {}
        contacts.append({
            "contact_id": rec["Id"],
            "name": rec.get("Name"),
            "first_name": rec.get("FirstName"),
            "last_name": rec.get("LastName"),
            "title": rec.get("Title"),
            "email": rec.get("Email"),
            "phone": rec.get("Phone"),
            "mobile_phone": rec.get("MobilePhone"),
            "department": rec.get("Department"),
            "account_id": rec.get("AccountId"),
            "account_name": account.get("Name"),
        })

    return paginated_response(total_count, pp, "contacts", contacts)
