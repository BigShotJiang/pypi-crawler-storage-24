import asyncio
from datetime import date
from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.exceptions import SalesforceToolExecutionError
from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import (
    build_dynamic_soql,
    build_validation_error,
    clamp_pagination,
    paginated_response,
    remove_none_values,
    sanitize_soql_string_literal,
    validate_salesforce_id,
    validate_soql_date,
)

VALID_PRIORITIES = ["High", "Normal", "Low"]


async def _validate_task_status(client: SalesforceClient, status: str) -> None:
    """Validate *status* against the org's Task Status picklist (graceful on describe failure)."""
    try:
        valid_statuses = await client.describe_picklist("Task", "Status")
    except SalesforceToolExecutionError:
        valid_statuses = []
    if valid_statuses and status not in valid_statuses:
        raise ToolExecutionError(build_validation_error("status", status, valid_statuses))


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_task"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_task(
    context: Context,
    subject: Annotated[str, "Short description of the task."],
    due_date: Annotated[
        str | None,
        "When the task is due, in ISO format (YYYY-MM-DD).",
    ] = None,
    priority: Annotated[
        str | None,
        "Task priority. Allowed values: High, Normal, Low.",
    ] = "Normal",
    status: Annotated[
        str | None,
        "Initial task status. Valid values are org-specific. Defaults to the org's default.",
    ] = None,
    description: Annotated[str | None, "Detailed notes or context for the task."] = None,
    account_or_opportunity_id: Annotated[
        str | None,
        "Salesforce ID of the Account or Opportunity this task is related to.",
    ] = None,
    contact_or_lead_id: Annotated[
        str | None,
        "Salesforce ID of the Contact or Lead this task is about.",
    ] = None,
    owner_user_id: Annotated[
        str | None,
        "Salesforce User ID to assign this task to. Defaults to the current user.",
    ] = None,
) -> Annotated[dict, "The created task ID."]:
    """Creates a task (follow-up, reminder, to-do) in Salesforce.

    Use this for future actions like reminders, follow-ups, or to-do items.
    For logging a completed phone call, use LogACall instead.
    """
    if priority and priority not in VALID_PRIORITIES:
        raise ToolExecutionError(build_validation_error("priority", priority, VALID_PRIORITIES))

    if due_date:
        validate_soql_date(due_date)

    client = SalesforceClient(context)

    if status:
        await _validate_task_status(client, status)

    data = remove_none_values({
        "Subject": subject,
        "ActivityDate": due_date,
        "Priority": priority,
        "Status": status,
        "Description": description,
        "WhatId": account_or_opportunity_id,
        "WhoId": contact_or_lead_id,
        "OwnerId": owner_user_id,
    })

    result = await client.create_record("Task", data)

    if not result.get("success"):
        raise SalesforceToolExecutionError(
            message="Failed to create task",
            errors=result.get("errors", []),
            status_code=422,
        )

    return {"success": True, "task_id": result["id"]}


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["read_task"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_my_tasks(
    context: Context,
    status: Annotated[str | None, "Filter by task status. Values are org-specific."] = None,
    due_date_from: Annotated[
        str | None, "Only return tasks due on or after this date (YYYY-MM-DD)."
    ] = None,
    due_date_to: Annotated[
        str | None, "Only return tasks due on or before this date (YYYY-MM-DD)."
    ] = None,
    overdue_only: Annotated[
        bool,
        "If true, only return tasks that are past due and not yet completed. Defaults to False.",
    ] = False,
    account_or_opportunity_id: Annotated[
        str | None, "Only return tasks linked to this Account or Opportunity."
    ] = None,
    limit: Annotated[int, "Maximum results to return (1-50). Defaults to 20."] = 20,
    page: Annotated[int, "Page number for pagination. Defaults to 1 (first page)."] = 1,
) -> Annotated[dict, "Paginated list of your tasks."]:
    """Lists tasks assigned to you in Salesforce with optional filters.

    Excludes call logs and email activities — only shows actionable tasks.
    Use overdue_only=true to see just tasks past their due date.
    """
    client = SalesforceClient(context)
    pp = clamp_pagination(limit, page)

    user_id = await client.get_current_user_id()

    if status:
        await _validate_task_status(client, status)

    where: list[str] = [
        f"OwnerId = '{user_id}'",
        "TaskSubtype != 'Call'",
        "TaskSubtype != 'Email'",
    ]

    if status:
        where.append(f"Status = '{sanitize_soql_string_literal(status)}'")

    if due_date_from:
        where.append(f"ActivityDate >= {validate_soql_date(due_date_from)}")

    if due_date_to:
        where.append(f"ActivityDate <= {validate_soql_date(due_date_to)}")

    if overdue_only:
        where.append("ActivityDate < TODAY")
        where.append("IsClosed = false")

    if account_or_opportunity_id:
        safe_what_id = validate_salesforce_id(
            account_or_opportunity_id,
            "account_or_opportunity_id",
            search_hint="GetAccountDataByKeywords or SearchOpportunities",
        )
        where.append(f"WhatId = '{safe_what_id}'")

    select = (
        "Id, Subject, ActivityDate, Priority, Status, "
        "WhatId, What.Name, What.Type, WhoId, Who.Name, Who.Type, Owner.Name"
    )

    count_soql = build_dynamic_soql(
        select="COUNT()",
        from_obj="Task",
        where_clauses=where,
    )
    data_soql = build_dynamic_soql(
        select=select,
        from_obj="Task",
        where_clauses=where,
        order_by="ActivityDate ASC NULLS LAST, Priority DESC",
        limit=pp.limit,
        offset=pp.offset,
    )

    count_result, data_result = await asyncio.gather(
        client.query(count_soql),
        client.query(data_soql),
    )

    total_count = count_result["totalSize"]
    records = data_result["records"]

    tasks = []
    for rec in records:
        what = rec.get("What") or {}
        who = rec.get("Who") or {}
        owner = rec.get("Owner") or {}

        task_data: dict[str, Any] = {
            "task_id": rec["Id"],
            "subject": rec.get("Subject"),
            "due_date": rec.get("ActivityDate"),
            "priority": rec.get("Priority"),
            "status": rec.get("Status"),
            "owner_name": owner.get("Name"),
        }

        if what.get("Name"):
            task_data["related_to"] = {
                "id": rec.get("WhatId"),
                "name": what.get("Name"),
                "type": what.get("Type"),
            }

        if who.get("Name"):
            task_data["who"] = {
                "id": rec.get("WhoId"),
                "name": who.get("Name"),
                "type": who.get("Type"),
            }

        tasks.append(task_data)

    return paginated_response(total_count, pp, "tasks", tasks)


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_task"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_task(
    context: Context,
    task_id: Annotated[str, "The Salesforce ID of the task to update."],
    status: Annotated[str | None, "New task status. Valid values are org-specific."] = None,
    due_date: Annotated[str | None, "New due date (YYYY-MM-DD)."] = None,
    priority: Annotated[str | None, "New priority. Allowed values: High, Normal, Low."] = None,
    subject: Annotated[str | None, "Updated task subject."] = None,
    description: Annotated[str | None, "Updated description."] = None,
) -> Annotated[dict, "Update result."]:
    """Updates fields on an existing task. Only provided fields are changed.

    Use status='Completed' to mark a task as done.
    """
    validate_salesforce_id(task_id, "task_id", search_hint="ListMyTasks")

    client = SalesforceClient(context)

    field_map = {
        "Status": status,
        "ActivityDate": due_date,
        "Priority": priority,
        "Subject": subject,
        "Description": description,
    }
    data = remove_none_values(field_map)

    if not data:
        raise ToolExecutionError("At least one field must be provided to update.")

    if due_date:
        validate_soql_date(due_date)

    if priority and priority not in VALID_PRIORITIES:
        raise ToolExecutionError(build_validation_error("priority", priority, VALID_PRIORITIES))

    if status:
        await _validate_task_status(client, status)

    await client.update_record("Task", task_id, data)

    return {"success": True, "task_id": task_id}


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_task"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def log_a_call(
    context: Context,
    subject: Annotated[str, "Short description of the call."],
    description: Annotated[str | None, "Call notes, summary, or key takeaways."] = None,
    duration_minutes: Annotated[int | None, "How long the call lasted, in minutes."] = None,
    account_or_opportunity_id: Annotated[
        str | None,
        "Salesforce ID of the Account or Opportunity this call was about.",
    ] = None,
    contact_or_lead_id: Annotated[
        str | None,
        "Salesforce ID of the Contact or Lead who was on the call.",
    ] = None,
    call_result: Annotated[str | None, "The outcome of the call."] = None,
) -> Annotated[dict, "The logged call activity ID."]:
    """Logs a completed phone call as an activity in Salesforce.

    Use this to record calls that already happened. For future follow-up actions,
    use CreateTask instead.
    """
    if duration_minutes is not None and duration_minutes < 0:
        raise ToolExecutionError("duration_minutes cannot be negative.")

    client = SalesforceClient(context)

    data: dict[str, Any] = {
        "Subject": subject,
        "TaskSubtype": "Call",
        "Status": "Completed",
        "ActivityDate": date.today().isoformat(),
    }

    if description is not None:
        data["Description"] = description
    if duration_minutes is not None:
        data["CallDurationInSeconds"] = duration_minutes * 60
    if account_or_opportunity_id is not None:
        data["WhatId"] = account_or_opportunity_id
    if contact_or_lead_id is not None:
        data["WhoId"] = contact_or_lead_id
    if call_result is not None:
        data["CallDisposition"] = call_result

    result = await client.create_record("Task", data)

    if not result.get("success"):
        raise SalesforceToolExecutionError(
            message="Failed to log call",
            errors=result.get("errors", []),
            status_code=422,
        )

    return {"success": True, "task_id": result["id"]}
