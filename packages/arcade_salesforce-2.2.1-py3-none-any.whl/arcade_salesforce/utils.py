import os
import re
import string
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date as date_type
from typing import Any, cast

from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import ToolExecutionError

from arcade_salesforce.constants import ASSOCIATION_REFERENCE_FIELDS, GLOBALLY_IGNORED_FIELDS
from arcade_salesforce.enums import SalesforceObject


@dataclass(frozen=True, slots=True)
class PageParams:
    """Clamped pagination parameters ready for SOQL LIMIT/OFFSET."""

    limit: int
    page: int
    offset: int


def clamp_pagination(limit: int, page: int, *, max_limit: int = 50) -> PageParams:
    """Clamp limit and page to valid ranges and compute offset."""
    limit = max(1, min(limit, max_limit))
    page = max(1, page)
    return PageParams(limit=limit, page=page, offset=(page - 1) * limit)


def paginated_response(
    total_count: int, page_params: PageParams, items_key: str, items: list
) -> dict[str, Any]:
    """Build a standardised paginated response envelope."""
    has_more = (page_params.offset + page_params.limit) < total_count
    return {
        "total_count": total_count,
        "has_more": has_more,
        "next_page": page_params.page + 1 if has_more else None,
        items_key: items,
    }


def remove_fields_globally_ignored(clean_func: Callable[[dict], dict]) -> Callable[[dict], dict]:
    """Remove fields that are irrelevant for our tools' responses.

    The main purpose of cleaning and removing unnecessary fields from data is to make our
    responses more concise and save on LLM tokens/context window.
    """

    def global_cleaner(data: dict) -> dict:
        cleaned_data = {}
        for key, value in data.items():
            if key in GLOBALLY_IGNORED_FIELDS or value is None:
                continue

            if isinstance(value, dict):
                cleaned_data[key] = global_cleaner(value)

            elif isinstance(value, list | tuple | set):
                cleaned_items = []
                for item in value:
                    if isinstance(item, dict):
                        cleaned_items.append(global_cleaner(item))
                    else:
                        cleaned_items.append(item)
                cleaned_data[key] = cleaned_items  # type: ignore[assignment]
            else:
                cleaned_data[key] = value
        return cleaned_data

    def wrapper(data: dict) -> dict:
        return global_cleaner(clean_func(data))

    return wrapper


def clean_object_data(data: dict) -> dict:
    """Clean Salesforce object dictionary based on the object type."""

    obj_type = data["attributes"]["type"]
    if obj_type == SalesforceObject.ACCOUNT.value:
        return clean_account_data(data)
    elif obj_type == SalesforceObject.CONTACT.value:
        return clean_contact_data(data)
    elif obj_type == SalesforceObject.LEAD.value:
        return clean_lead_data(data)
    elif obj_type == SalesforceObject.NOTE.value:
        return clean_note_data(data)
    elif obj_type == SalesforceObject.TASK.value:
        return clean_task_data(data)
    elif obj_type == SalesforceObject.USER.value:
        return clean_user_data(data)
    raise ValueError(f"Unknown object type: '{obj_type}' in object: {data}")


@remove_fields_globally_ignored
def clean_account_data(data: dict) -> dict:
    data["AccountType"] = data["Type"]
    del data["Type"]
    data["ObjectType"] = SalesforceObject.ACCOUNT.value
    ignore_fields = [
        "BillingCity",
        "BillingCountry",
        "BillingCountryCode",
        "BillingPostalCode",
        "BillingState",
        "BillingStateCode",
        "BillingStreet",
        "LastActivityDate",
        "ShippingCity",
        "ShippingCountry",
        "ShippingCountryCode",
        "ShippingPostalCode",
        "ShippingState",
        "ShippingStateCode",
        "ShippingStreet",
    ]
    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


@remove_fields_globally_ignored
def clean_contact_data(data: dict) -> dict:
    data["ObjectType"] = SalesforceObject.CONTACT.value
    ignore_fields = ["IsEmailBounced", "IsPriorityRecord"]
    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


@remove_fields_globally_ignored
def clean_lead_data(data: dict) -> dict:
    data["ObjectType"] = SalesforceObject.LEAD.value
    return data


@remove_fields_globally_ignored
def clean_opportunity_data(data: dict) -> dict:
    data["ObjectType"] = SalesforceObject.OPPORTUNITY.value
    amount = data.get("Amount")
    probability = data.get("Probability")
    expected_revenue = data.get("ExpectedRevenue")
    if amount is not None or probability is not None or expected_revenue is not None:
        data["Amount"] = {
            "Value": amount,
            "ClosingProbability": probability
            if not isinstance(probability, int | float)
            else probability / 100,
            "ExpectedRevenue": expected_revenue,
        }
    data.pop("Probability", None)
    data.pop("ExpectedRevenue", None)
    return data


@remove_fields_globally_ignored
def clean_note_data(data: dict) -> dict:
    data["ObjectType"] = SalesforceObject.NOTE.value
    return data


@remove_fields_globally_ignored
def clean_task_data(data: dict) -> dict:
    task_subtype = data.get("TaskSubtype", SalesforceObject.TASK.value)
    data["ObjectType"] = task_subtype
    who_id = data.get("WhoId")
    if who_id is not None:
        data["AssociatedToWhom"] = who_id
    ignore_fields = [
        "IsArchived",
        "IsClosed",
        "IsDeleted",
        "IsHighPriority",
        "IsRecurrence",
        "IsReminderSet",
        "TaskSubtype",
        "WhoId",
    ]

    if data["ObjectType"] == SalesforceObject.EMAIL.value:
        desc = data.get("Description", "")
        if desc:
            data["Email"] = format_email(desc)
        for field in (
            "ActivityDate",
            "CompletedDateTime",
            "Description",
            "Subject",
            "OwnerId",
            "Priority",
            "Status",
        ):
            data.pop(field, None)

    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


@remove_fields_globally_ignored
def clean_user_data(data: dict) -> dict:
    data["ObjectType"] = SalesforceObject.USER.value
    ignore_fields = [
        "attributes",
        "CleanStatus",
        "LastReferencedDate",
        "LastViewedDate",
        "SystemModstamp",
    ]
    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


def get_ids_referenced(*data_objects: dict) -> set[str]:
    """Build a set of IDs referenced in a list of dictionaries.

    Args:
        data_objects: The list of dictionaries to search for referenced IDs.

    Returns:
        The set of IDs referenced in the dictionaries.
    """
    referenced_ids = set()
    for data in data_objects:
        for field in ASSOCIATION_REFERENCE_FIELDS:
            if field in data:
                referenced_ids.add(data[field])
    return referenced_ids


def expand_associations(data: dict, objects_by_id: dict) -> dict:
    """Expand a Salesforce object referenced by ID with metadata about the object.

    Args:
        data: The dictionary to expand.
        objects_by_id: The dictionary of objects metadata by ID.

    Returns:
        The expanded dictionary.
    """
    for field in ASSOCIATION_REFERENCE_FIELDS:
        if field not in data:
            continue

        associated_object = objects_by_id.get(data[field])

        if isinstance(associated_object, dict):
            del data[field]
            data[field.rstrip("Id")] = simplified_object_data(associated_object)

    return data


def simplified_object_data(data: dict) -> dict:
    return {
        "Id": data["Id"],
        "Name": data["Name"],
        "ObjectType": get_object_type(data),
    }


def get_object_type(data: dict) -> str:
    obj_type = data.get("ObjectType") or data["attributes"]["type"]
    return cast(str, obj_type)


def build_soql_query(query: str, **kwargs: Any) -> str:
    """Build a SOQL query with sanitized arguments.

    Args:
        query: The SOQL query to build.
        **kwargs: The arguments to sanitize and format into the query.

    Returns:
        The SOQL query with the arguments formatted.
    """
    return query.format(**{key: sanitize_soql_argument(value) for key, value in kwargs.items()})


def sanitize_soql_argument(value: Any) -> str:
    """Sanitize an argument for a SOQL query.

    The goal is to prevent SQL injection, since Salesforce does not support parameterized queries.
    This function will only accept ASCII letters and digits in the value.

    Args:
        value: The value to sanitize.

    Returns:
        The sanitized value.
    """
    allowed_chars = string.ascii_letters + string.digits
    if not isinstance(value, str):
        value = str(value)
    return "".join([char for char in value if char in allowed_chars])


def sanitize_soql_id(value: Any) -> str:
    """Sanitize a Salesforce record ID for use in SOQL queries.

    Salesforce IDs are always 15- or 18-character alphanumeric strings, so only
    ASCII letters and digits are allowed. This is equivalent to sanitize_soql_argument
    but named explicitly for clarity at call sites.
    """
    if not isinstance(value, str):
        value = str(value)
    return "".join(char for char in value if char in string.ascii_letters + string.digits)


def sanitize_soql_string_literal(value: Any) -> str:
    """Sanitize a string value for SOQL equality/comparison filters.

    Preserves spaces, hyphens, and common characters found in picklist values
    and names. Single quotes are escaped by doubling per SOQL convention.
    Use this for values that appear inside single-quoted SOQL strings, e.g.
    ``StageName = '{sanitize_soql_string_literal(stage)}'``.
    """
    if not isinstance(value, str):
        value = str(value)
    allowed = string.ascii_letters + string.digits + " -_./&(),':"
    sanitized = "".join(char for char in value if char in allowed)
    return sanitized.replace("'", "''")


_ISO_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


def validate_soql_date(value: str) -> str:
    """Validate and return an ISO-format date (YYYY-MM-DD) for unquoted SOQL date literals.

    Checks both the format and calendar validity (rejects dates like 2026-13-40).
    Raises ToolExecutionError if the format or date is invalid.
    """
    if not isinstance(value, str):
        value = str(value)
    if not _ISO_DATE_RE.fullmatch(value):
        raise ToolExecutionError(
            f"Invalid date format '{value}'. Expected ISO format: YYYY-MM-DD "
            f"(e.g. '2026-03-15')."
        )
    try:
        date_type.fromisoformat(value)
    except ValueError:
        raise ToolExecutionError(
            f"Invalid date '{value}': not a valid calendar date. "
            f"Expected a real date in YYYY-MM-DD format (e.g. '2026-03-15')."
        )
    return value


_SALESFORCE_ID_RE = re.compile(r"^[a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?$")


def validate_salesforce_id(value: str, field_name: str, search_hint: str | None = None) -> str:
    """Validate that a value looks like a Salesforce record ID (15 or 18 alphanumeric chars).

    Raises ToolExecutionError with an actionable message if the shape is invalid.
    Still runs sanitize_soql_id on valid-shaped IDs for injection safety.
    """
    if not isinstance(value, str):
        value = str(value)
    if not _SALESFORCE_ID_RE.fullmatch(value):
        hint = f" Use the {search_hint} tool to look up the correct ID." if search_hint else ""
        raise ToolExecutionError(
            f"'{field_name}' must be a valid Salesforce ID "
            f"(15 or 18 alphanumeric characters). "
            f"Received: '{value}'.{hint}"
        )
    return sanitize_soql_id(value)


def _levenshtein_distance(s1: str, s2: str) -> int:
    """Compute the Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)

    prev_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            insert = prev_row[j + 1] + 1
            delete = curr_row[j] + 1
            replace = prev_row[j] + (0 if c1 == c2 else 1)
            curr_row.append(min(insert, delete, replace))
        prev_row = curr_row
    return prev_row[-1]


def rank_suggestions(
    invalid_value: str,
    valid_values: list[str],
    *,
    max_suggestions: int = 3,
    threshold: float = 0.4,
) -> list[tuple[str, float]]:
    """Rank valid values by similarity to an invalid input using normalized Levenshtein distance.

    Returns up to `max_suggestions` values above `threshold`, sorted by descending similarity.
    If none meet the threshold, returns the top `max_suggestions` overall.
    """
    if not valid_values:
        return []

    normalized_input = invalid_value.strip().lower()
    scored: list[tuple[str, float]] = []
    for candidate in valid_values:
        normalized_candidate = candidate.strip().lower()
        max_len = max(len(normalized_input), len(normalized_candidate))
        if max_len == 0:
            score = 1.0
        else:
            score = 1.0 - _levenshtein_distance(normalized_input, normalized_candidate) / max_len
        scored.append((candidate, round(score, 2)))

    scored.sort(key=lambda x: x[1], reverse=True)

    above_threshold = [(v, s) for v, s in scored if s >= threshold]
    if above_threshold:
        return above_threshold[:max_suggestions]
    return scored[:max_suggestions]


def build_validation_error(
    field_label: str,
    invalid_value: str,
    valid_values: list[str],
) -> str:
    """Build a standardized validation error message with ranked suggestions."""
    suggestions = rank_suggestions(invalid_value, valid_values)
    parts = [f"Invalid {field_label} '{invalid_value}'."]

    if suggestions:
        suggestion_strs = [f"'{v}' ({s})" for v, s in suggestions]
        parts.append(f"Did you mean: {', '.join(suggestion_strs)}?")

    parts.append(f"Valid values for this org: {', '.join(valid_values)}")

    return " ".join(parts)


def _extract_header(description: str, header: str, *, multiline: bool = False) -> str | None:
    """Extract the value after ``header`` from a Salesforce email description.

    Returns ``None`` when *header* is not present in the text, avoiding the
    ``IndexError`` that ``str.split(header)[1]`` would raise.
    """
    parts = description.split(header, maxsplit=1)
    if len(parts) < 2:
        return None
    tail = parts[1]
    if multiline:
        return tail.strip()
    return tail.split("\n", maxsplit=1)[0].strip()


def format_email(description: str) -> dict:
    """Turns a Salesforce email description string into a more readable dictionary.

    Not all Salesforce orgs use the standard email header format.  When headers
    are missing the function now returns whatever fields it *can* parse instead
    of raising ``IndexError``.
    """
    headers = {
        "To": "To:",
        "CC": "CC:",
        "BCC": "BCC:",
        "Attachment": "Attachment:",
        "Subject": "Subject:",
    }

    email: dict[str, str] = {}
    for key, marker in headers.items():
        value = _extract_header(description, marker)
        if value is not None:
            email[key] = value

    body = _extract_header(description, "Body:\n", multiline=True)
    if body is not None:
        email["Body"] = body

    if email.get("Attachment") in (None, "--none--"):
        email.pop("Attachment", None)

    return email


def remove_none_values(data: dict) -> dict:
    """Remove None values from a dictionary.

    Args:
        data: The dictionary to clean.

    Returns:
        The cleaned dictionary.
    """
    return {k: v for k, v in data.items() if v is not None}


def sanitize_soql_like_argument(value: Any) -> str:
    """Sanitize an argument for a SOQL LIKE clause.

    More permissive than sanitize_soql_id -- allows spaces, @, ., -, _, and
    single quotes which are common in names, emails, and company names.
    Single quotes are escaped (doubled) per SOQL convention to prevent injection.

    SOQL LIKE wildcards (% and _) are not in the allowed set to prevent wildcard
    injection. Callers add LIKE wildcards (%) around the result themselves.

    Args:
        value: The value to sanitize.

    Returns:
        The sanitized value.
    """
    allowed_chars = string.ascii_letters + string.digits + " @._-'"
    if not isinstance(value, str):
        value = str(value)
    sanitized = "".join(char for char in value if char in allowed_chars)
    return sanitized.replace("'", "''")


def build_dynamic_soql(
    select: str,
    from_obj: str,
    where_clauses: list[str] | None = None,
    order_by: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """Build a SOQL query from dynamic components.

    Args:
        select: The SELECT field list (e.g. "Id, Name, Amount").
        from_obj: The FROM object name (e.g. "Opportunity").
        where_clauses: Optional list of WHERE condition strings to AND together.
        order_by: Optional ORDER BY clause (e.g. "CloseDate ASC").
        limit: Optional LIMIT value.
        offset: Optional OFFSET value.

    Returns:
        The complete SOQL query string.
    """
    parts = [f"SELECT {select} FROM {from_obj}"]  # noqa: S608
    if where_clauses:
        parts.append("WHERE " + " AND ".join(where_clauses))
    if order_by:
        parts.append(f"ORDER BY {order_by}")
    if limit is not None:
        parts.append(f"LIMIT {int(limit)}")
    if offset is not None and offset > 0:
        parts.append(f"OFFSET {int(offset)}")
    return " ".join(parts)


@remove_fields_globally_ignored
def clean_contact_role_data(data: dict) -> dict:
    data["ObjectType"] = "OpportunityContactRole"
    ignore_fields = ["OpportunityId"]
    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


@remove_fields_globally_ignored
def clean_line_item_data(data: dict) -> dict:
    data["ObjectType"] = "OpportunityLineItem"
    ignore_fields = ["OpportunityId"]
    return {k: v for k, v in data.items() if v is not None and k not in ignore_fields}


def get_subdomain(context: Context) -> str:
    try:
        return context.get_secret("SALESFORCE_ORG_SUBDOMAIN")
    except ValueError:
        if "SALESFORCE_ORG_SUBDOMAIN" in os.environ:
            return os.environ["SALESFORCE_ORG_SUBDOMAIN"]
        message = "Missing Salesforce subdomain."
        developer_message = (
            "The Salesforce toolkit requires a 'SALESFORCE_ORG_SUBDOMAIN' secret to be set. "
            "Please refer to the Arcade documentation to learn where you can get your Salesforce "
            "Org Subdomain and how to set it up as a secret for the toolkit to work: "
            "https://docs.arcade.dev"
        )
        raise ToolExecutionError(message=message, developer_message=developer_message)
