from typing import Any

from arcade_mcp_server.exceptions import UpstreamError


class SalesforceToolExecutionError(UpstreamError):
    """Upstream Salesforce API error.

    Extends ``UpstreamError`` so the Arcade runtime can classify and route
    upstream failures correctly (retryability, error kind, etc.).
    """

    def __init__(
        self,
        errors: list[str],
        message: str = "Failed to execute Salesforce tool",
        *,
        status_code: int,
        error_details: list[dict[str, Any]] | None = None,
    ):
        self.errors = errors
        self.error_details = error_details or []
        exc_message = f"{message}. Errors: {errors}"
        super().__init__(
            exc_message,
            developer_message=exc_message,
            status_code=status_code,
        )


class ResourceNotFoundError(SalesforceToolExecutionError):
    def __init__(
        self,
        errors: list[str],
        *,
        error_details: list[dict[str, Any]] | None = None,
    ):
        super().__init__(
            message="Resource not found",
            errors=errors,
            status_code=404,
            error_details=error_details,
        )


class BadRequestError(SalesforceToolExecutionError):
    def __init__(
        self,
        errors: list[str],
        *,
        error_details: list[dict[str, Any]] | None = None,
    ):
        super().__init__(
            message="Bad request",
            errors=errors,
            status_code=400,
            error_details=error_details,
        )
