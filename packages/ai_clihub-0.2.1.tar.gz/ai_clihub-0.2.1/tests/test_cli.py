from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENV = {
    **os.environ,
    "PYTHONPATH": str(ROOT / "src"),
}


def run_cli(*args: str, cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "clihub", *args],
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


class CLIHubTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.project = Path(self.temp_dir.name)
        self.home = self.project / "home"
        self.home.mkdir(parents=True, exist_ok=True)
        self.env = {
            **ENV,
            "HOME": str(self.home),
        }

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_inspect_and_register_raw_command(self) -> None:
        inspection = run_cli("inspect", "python3 -m http.server", "--json", cwd=self.project, env=self.env)
        self.assertEqual(inspection.returncode, 0, inspection.stderr)
        inspection_payload = json.loads(inspection.stdout)
        self.assertTrue(inspection_payload["installed"])
        self.assertEqual(inspection_payload["entrypoint"], "python3")
        self.assertIn("usage", inspection_payload["usage_lines"][0].lower())

        registered = run_cli(
            "register",
            "python3 -m http.server",
            "--id",
            "http-server",
            "--summary",
            "Serve a local directory over HTTP.",
            "--tag",
            "web",
            "--capability",
            "http.serve",
            "--json",
            cwd=self.project,
            env=self.env,
        )
        self.assertEqual(registered.returncode, 0, registered.stderr)
        registered_payload = json.loads(registered.stdout)
        self.assertEqual(registered_payload["tool_id"], "http-server")
        self.assertFalse((self.project / ".clihub").exists())
        self.assertTrue((self.home / ".clihub" / "tools" / "http-server.json").exists())

        listing = run_cli("list", "--json", cwd=self.project, env=self.env)
        self.assertEqual(listing.returncode, 0, listing.stderr)
        listing_payload = json.loads(listing.stdout)
        self.assertEqual(listing_payload["count"], 1)
        self.assertEqual(listing_payload["items"][0]["id"], "http-server")
        self.assertEqual(listing_payload["items"][0]["command"], "python3 -m http.server")

        shown = run_cli("show", "http-server", "--json", cwd=self.project, env=self.env)
        self.assertEqual(shown.returncode, 0, shown.stderr)
        shown_payload = json.loads(shown.stdout)
        self.assertEqual(shown_payload["summary"], "Serve a local directory over HTTP.")
        self.assertEqual(shown_payload["inspection"]["entrypoint"], "python3")

    def test_resolve_and_exec_dry_run(self) -> None:
        run_cli(
            "register",
            "python3 -m http.server",
            "--id",
            "http-server",
            "--summary",
            "Serve a local directory over HTTP.",
            "--tag",
            "web",
            "--capability",
            "http.serve",
            cwd=self.project,
            env=self.env,
        )
        resolve_result = run_cli("resolve", "serve files over http", "--json", cwd=self.project, env=self.env)
        self.assertEqual(resolve_result.returncode, 0, resolve_result.stderr)
        resolved = json.loads(resolve_result.stdout)
        self.assertEqual(resolved["count"], 1)
        self.assertEqual(resolved["items"][0]["id"], "http-server")
        self.assertIn("summary", resolved["items"][0]["matched_fields"])

        dry_exec = run_cli(
            "exec",
            "http-server",
            "--dry-run",
            "--json",
            "--",
            "--directory",
            "/tmp",
            cwd=self.project,
            env=self.env,
        )
        self.assertEqual(dry_exec.returncode, 0, dry_exec.stderr)
        exec_payload = json.loads(dry_exec.stdout)
        self.assertEqual(exec_payload["command"][:3], ["python3", "-m", "http.server"])
        self.assertEqual(exec_payload["command"][-2:], ["--directory", "/tmp"])

    def test_scenario_registration_and_run(self) -> None:
        scenario_file = self.project / "hello.json"
        scenario_file.write_text(
            json.dumps(
                {
                    "id": "say-hello",
                    "description": "Print a greeting.",
                    "defaults": {"name": "world"},
                    "steps": [
                        {
                            "id": "hello",
                            "command": ["python3", "-c", "print('hello ${name}')"],
                        }
                    ],
                }
            ),
            encoding="utf-8",
        )
        register = run_cli(
            "scenario",
            "register",
            "--file",
            str(scenario_file),
            "--json",
            cwd=self.project,
            env=self.env,
        )
        self.assertEqual(register.returncode, 0, register.stderr)

        listing = run_cli("list", "--kind", "all", "--json", cwd=self.project, env=self.env)
        self.assertEqual(listing.returncode, 0, listing.stderr)
        items = json.loads(listing.stdout)["items"]
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["kind"], "scenario")
        self.assertEqual(items[0]["id"], "say-hello")

        validation = run_cli("scenario", "validate", "say-hello", "--json", cwd=self.project, env=self.env)
        self.assertEqual(validation.returncode, 0, validation.stderr)
        self.assertTrue(json.loads(validation.stdout)["valid"])

        execution = run_cli(
            "scenario",
            "run",
            "say-hello",
            "--set",
            "name=codex",
            "--json",
            cwd=self.project,
            env=self.env,
        )
        self.assertEqual(execution.returncode, 0, execution.stderr)
        results = json.loads(execution.stdout)
        self.assertEqual(results["exit_code"], 0)
        self.assertIn("hello codex", results["results"][0]["stdout"])


if __name__ == "__main__":
    unittest.main()
