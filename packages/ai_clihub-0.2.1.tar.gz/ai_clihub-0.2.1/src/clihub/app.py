from __future__ import annotations

import argparse
import copy
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from string import Template
from typing import Any

from . import __version__

SCHEMA_VERSION = 2
RISK_LEVELS = ("low", "medium", "high")
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
TOKEN_RE = re.compile(r"[a-z0-9_.-]+|[\u4e00-\u9fff]+", re.IGNORECASE)
SECTION_PREFIXES = (
    "usage",
    "options",
    "commands",
    "examples",
    "arguments",
    "positional arguments",
    "optional arguments",
    "flags",
    "subcommands",
)
STOPWORDS = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "by",
    "for",
    "from",
    "in",
    "into",
    "is",
    "it",
    "of",
    "on",
    "or",
    "that",
    "the",
    "this",
    "to",
    "tool",
    "with",
}
HELP_SUFFIXES = [["--help"], ["-h"], ["help"]]
VERSION_SUFFIXES = [["--version"], ["version"], ["-V"], ["-v"]]


class CLIHubError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def slugify(value: str) -> str:
    cleaned = []
    for char in value.lower():
        if char.isalnum():
            cleaned.append(char)
        elif char in ("-", "_", "."):
            cleaned.append("-")
        elif char.isspace():
            cleaned.append("-")
    result = "".join(cleaned).strip("-")
    while "--" in result:
        result = result.replace("--", "-")
    if not result:
        raise CLIHubError("Unable to derive a valid id from an empty value.")
    return result


def strip_ansi(text: str) -> str:
    return ANSI_RE.sub("", text)


def tokenize(text: str) -> list[str]:
    tokens = [match.group(0).lower() for match in TOKEN_RE.finditer(text or "")]
    return [token for token in tokens if token and token not in STOPWORDS]


def parse_key_values(values: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in values:
        if "=" not in item:
            raise CLIHubError(f"Expected KEY=VALUE, got: {item}")
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise CLIHubError(f"Missing key in assignment: {item}")
        result[key] = value
    return result


def render_template(value: Any, variables: dict[str, Any]) -> Any:
    if isinstance(value, str):
        return Template(value).safe_substitute(variables)
    if isinstance(value, list):
        return [render_template(item, variables) for item in value]
    if isinstance(value, dict):
        return {key: render_template(item, variables) for key, item in value.items()}
    return value


def read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CLIHubError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise CLIHubError(f"Invalid JSON in {path}: {exc}") from exc


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def pretty_print(data: Any) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def load_manifest_file(path: str | None) -> dict[str, Any]:
    if not path:
        raise CLIHubError("A manifest file path is required.")
    manifest = read_json(Path(path))
    if not isinstance(manifest, dict):
        raise CLIHubError("Manifest file must contain a JSON object.")
    return manifest


def normalize_text_block(text: str, limit: int = 12000) -> str:
    cleaned = strip_ansi(text or "").strip()
    return cleaned[:limit]


def resolve_executable(entrypoint: str) -> str | None:
    expanded = os.path.expanduser(entrypoint)
    if os.sep in expanded or expanded.startswith("."):
        path = Path(expanded)
        return str(path.resolve()) if path.exists() else None
    return shutil.which(entrypoint)


def run_command(
    command: str | list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
    capture_output: bool = True,
    timeout: int = 5,
) -> subprocess.CompletedProcess[str]:
    args = shlex.split(command) if isinstance(command, str) else list(command)
    try:
        return subprocess.run(
            args,
            check=False,
            text=True,
            capture_output=capture_output,
            cwd=cwd,
            env={**os.environ, **(env or {})},
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise CLIHubError(f"Command not found: {args[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise CLIHubError(f"Command timed out: {shlex.join(args)}") from exc


def probe_variants(base_command: str, suffixes: list[list[str]]) -> dict[str, Any]:
    base_tokens = shlex.split(base_command)
    attempts: list[dict[str, Any]] = []
    best: dict[str, Any] | None = None
    best_score = -1
    for suffix in suffixes:
        full_command = base_tokens + suffix
        try:
            result = run_command(full_command)
            stdout = normalize_text_block(result.stdout or "")
            stderr = normalize_text_block(result.stderr or "")
            output = stdout or stderr
            attempt = {
                "command": shlex.join(full_command),
                "args": full_command,
                "exit_code": result.returncode,
                "stdout": stdout,
                "stderr": stderr,
            }
            score = (100 if result.returncode == 0 else 50 if output else 0) + min(len(output), 1000)
            if output and score > best_score:
                best = attempt
                best_score = score
        except CLIHubError as exc:
            attempt = {
                "command": shlex.join(full_command),
                "args": full_command,
                "exit_code": None,
                "stdout": "",
                "stderr": str(exc),
            }
        attempts.append(attempt)
    return {"selected": best, "attempts": attempts}


def extract_usage_lines(help_text: str, command: str) -> list[str]:
    usage_lines: list[str] = []
    entrypoint = shlex.split(command)[0]
    for raw_line in help_text.splitlines():
        line = raw_line.strip()
        lower = line.lower()
        if not line:
            continue
        if lower.startswith("usage"):
            usage_lines.append(line)
        elif lower.startswith(entrypoint.lower()) and len(line.split()) > 1:
            usage_lines.append(line)
        if len(usage_lines) >= 5:
            break
    return usage_lines


def guess_summary(help_text: str, command: str) -> str:
    entrypoint = shlex.split(command)[0]
    for raw_line in help_text.splitlines():
        line = raw_line.strip()
        lower = line.lower().rstrip(":")
        if not line:
            continue
        if len(line) < 4 or len(line) > 160:
            continue
        if lower == entrypoint.lower() or lower == command.lower():
            continue
        if line.startswith("-"):
            continue
        if line.startswith("[") or line.startswith("<") or line.startswith("("):
            continue
        if any(lower.startswith(prefix) for prefix in SECTION_PREFIXES):
            continue
        if re.fullmatch(r"[-_= ]+", line):
            continue
        return line
    usage_lines = extract_usage_lines(help_text, command)
    if usage_lines:
        return usage_lines[0]
    return f"CLI command registered from '{command}'."


def infer_keywords(command: str, summary: str, help_text: str) -> list[str]:
    candidates = tokenize(command) + tokenize(summary)
    help_lines = [line.strip() for line in help_text.splitlines()[:20] if line.strip()]
    for line in help_lines:
        candidates.extend(tokenize(line))
    unique: list[str] = []
    seen: set[str] = set()
    for token in candidates:
        if token in seen:
            continue
        seen.add(token)
        unique.append(token)
    return unique[:40]


def inspect_command(command: str) -> dict[str, Any]:
    tokens = shlex.split(command)
    if not tokens:
        raise CLIHubError("Command must not be empty.")
    entrypoint = tokens[0]
    resolved_path = resolve_executable(entrypoint)
    installed = resolved_path is not None
    help_probe = probe_variants(command, HELP_SUFFIXES) if installed else {"selected": None, "attempts": []}
    version_probe = probe_variants(command, VERSION_SUFFIXES) if installed else {"selected": None, "attempts": []}
    help_text = ""
    if help_probe.get("selected"):
        selected = help_probe["selected"]
        help_text = selected.get("stdout") or selected.get("stderr") or ""
    summary_guess = guess_summary(help_text, command)
    usage_lines = extract_usage_lines(help_text, command)
    return {
        "command": command,
        "entrypoint": entrypoint,
        "base_tokens": tokens,
        "installed": installed,
        "resolved_path": resolved_path,
        "help": help_probe,
        "version": version_probe,
        "summary_guess": summary_guess,
        "usage_lines": usage_lines,
        "keywords": infer_keywords(command, summary_guess, help_text),
    }


def tool_defaults(tool_id: str, command: str, summary: str, inspection: dict[str, Any], **extra: Any) -> dict[str, Any]:
    now = utc_now()
    data = {
        "kind": "tool",
        "schema_version": SCHEMA_VERSION,
        "id": tool_id,
        "name": extra.pop("name", tool_id),
        "command": command,
        "entrypoint": inspection["entrypoint"],
        "summary": summary,
        "tags": extra.pop("tags", []),
        "capabilities": extra.pop("capabilities", []),
        "keywords": extra.pop("keywords", []),
        "examples": extra.pop("examples", inspection.get("usage_lines", [])[:3]),
        "risk_level": extra.pop("risk_level", "low"),
        "inspection": inspection,
        "registered_at": extra.pop("registered_at", now),
        "updated_at": now,
    }
    data.update(extra)
    return data


def scenario_defaults(scenario_id: str, description: str, **extra: Any) -> dict[str, Any]:
    now = utc_now()
    data = {
        "kind": "scenario",
        "schema_version": SCHEMA_VERSION,
        "id": scenario_id,
        "name": extra.pop("name", scenario_id),
        "description": description,
        "defaults": extra.pop("defaults", {}),
        "inputs": extra.pop("inputs", []),
        "examples": extra.pop("examples", []),
        "preconditions": extra.pop("preconditions", []),
        "risk_level": extra.pop("risk_level", "medium"),
        "steps": extra.pop("steps", []),
        "registered_at": extra.pop("registered_at", now),
        "updated_at": now,
    }
    data.update(extra)
    return data


def validate_tool(tool: dict[str, Any]) -> dict[str, Any]:
    if not tool.get("id"):
        raise CLIHubError("Tool is missing required field 'id'.")
    if not tool.get("command"):
        raise CLIHubError(f"Tool {tool['id']} is missing required field 'command'.")
    summary = tool.get("summary") or tool.get("description")
    if not summary:
        raise CLIHubError(f"Tool {tool['id']} is missing required field 'summary'.")
    if tool.get("risk_level", "low") not in RISK_LEVELS:
        raise CLIHubError(f"Invalid risk_level for tool {tool['id']}.")
    tool["id"] = slugify(str(tool["id"]))
    tool.setdefault("kind", "tool")
    tool.setdefault("schema_version", SCHEMA_VERSION)
    tool.setdefault("name", tool["id"])
    tool.setdefault("entrypoint", shlex.split(tool["command"])[0])
    tool["summary"] = summary
    tool.setdefault("tags", [])
    tool.setdefault("capabilities", [])
    tool.setdefault("examples", [])
    tool.setdefault("inspection", {})
    keyword_source = tool.get("keywords") or []
    keyword_source.extend(tokenize(tool["id"]))
    keyword_source.extend(tokenize(tool["command"]))
    keyword_source.extend(tokenize(tool["summary"]))
    for tag in tool["tags"]:
        keyword_source.extend(tokenize(tag))
    for capability in tool["capabilities"]:
        keyword_source.extend(tokenize(capability))
    unique_keywords: list[str] = []
    seen: set[str] = set()
    for keyword in keyword_source:
        if keyword in seen:
            continue
        seen.add(keyword)
        unique_keywords.append(keyword)
    tool["keywords"] = unique_keywords[:60]
    tool.setdefault("registered_at", utc_now())
    tool["updated_at"] = utc_now()
    return tool


def validate_scenario(scenario: dict[str, Any]) -> dict[str, Any]:
    if not scenario.get("id"):
        raise CLIHubError("Scenario is missing required field 'id'.")
    if not scenario.get("description"):
        raise CLIHubError(f"Scenario {scenario['id']} is missing required field 'description'.")
    if scenario.get("risk_level", "medium") not in RISK_LEVELS:
        raise CLIHubError(f"Invalid risk_level for scenario {scenario['id']}.")
    steps = scenario.get("steps", [])
    if not isinstance(steps, list) or not steps:
        raise CLIHubError(f"Scenario {scenario['id']} must define at least one step.")
    for index, step in enumerate(steps, start=1):
        if not isinstance(step, dict):
            raise CLIHubError(f"Scenario {scenario['id']} step {index} must be an object.")
        if not step.get("tool") and not step.get("command"):
            raise CLIHubError(
                f"Scenario {scenario['id']} step {index} must define either 'tool' or 'command'."
            )
        step.setdefault("id", f"step-{index}")
        step.setdefault("args", [])
        step.setdefault("env", {})
        step.setdefault("continue_on_error", False)
    scenario["id"] = slugify(str(scenario["id"]))
    scenario.setdefault("kind", "scenario")
    scenario.setdefault("schema_version", SCHEMA_VERSION)
    scenario.setdefault("name", scenario["id"])
    scenario.setdefault("defaults", {})
    scenario.setdefault("inputs", [])
    scenario.setdefault("examples", [])
    scenario.setdefault("preconditions", [])
    scenario.setdefault("registered_at", utc_now())
    scenario["updated_at"] = utc_now()
    return scenario


@dataclass
class HubContext:
    cwd: Path
    local_root: Path | None
    global_root: Path

    @classmethod
    def discover(cls, cwd: Path | None = None) -> "HubContext":
        current = (cwd or Path.cwd()).resolve()
        return cls(
            cwd=current,
            local_root=find_local_hub(current),
            global_root=Path.home() / ".clihub",
        )


def find_local_hub(start: Path) -> Path | None:
    probe = start if start.is_dir() else start.parent
    for current in [probe, *probe.parents]:
        candidate = current / ".clihub"
        if candidate.is_dir():
            return candidate
    return None


def ensure_hub_layout(root: Path, *, name: str | None = None, inherit_global: bool = True) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "tools").mkdir(parents=True, exist_ok=True)
    (root / "scenarios").mkdir(parents=True, exist_ok=True)
    config_path = root / "hub.json"
    if not config_path.exists():
        write_json(
            config_path,
            {
                "kind": "hub",
                "schema_version": SCHEMA_VERSION,
                "name": name or root.parent.name,
                "inherit_global": inherit_global,
                "created_at": utc_now(),
            },
        )


class Registry:
    def __init__(self, context: HubContext) -> None:
        self.context = context
        ensure_hub_layout(self.context.global_root, name="global", inherit_global=False)

    def ensure_root(self, scope: str) -> Path:
        if scope == "global":
            root = self.context.global_root
            ensure_hub_layout(root, name="global", inherit_global=False)
            return root
        if scope != "local":
            raise CLIHubError(f"Unsupported scope: {scope}")
        if self.context.local_root is None:
            raise CLIHubError("No local .clihub found. Run 'clihub init' first.")
        ensure_hub_layout(self.context.local_root)
        return self.context.local_root

    def hub_config(self, root: Path) -> dict[str, Any]:
        path = root / "hub.json"
        if not path.exists():
            ensure_hub_layout(root)
        return read_json(path)

    def collection_path(self, root: Path, kind: str, item_id: str) -> Path:
        directory = "tools" if kind == "tool" else "scenarios"
        return root / directory / f"{slugify(item_id)}.json"

    def write_manifest(self, kind: str, data: dict[str, Any], scope: str, force: bool = False) -> Path:
        root = self.ensure_root(scope)
        target = self.collection_path(root, kind, data["id"])
        if target.exists() and not force:
            raise CLIHubError(f"{kind.title()} '{data['id']}' already exists in {scope} scope.")
        write_json(target, data)
        return target

    def remove_manifest(self, kind: str, item_id: str, scope: str) -> Path:
        root = self.ensure_root(scope)
        target = self.collection_path(root, kind, item_id)
        if not target.exists():
            raise CLIHubError(f"{kind.title()} '{item_id}' was not found in {scope} scope.")
        target.unlink()
        return target

    def load_collection(self, kind: str, scope: str) -> list[dict[str, Any]]:
        roots: list[tuple[str, Path]] = []
        inherit_global = True
        if self.context.local_root is not None:
            inherit_global = self.hub_config(self.context.local_root).get("inherit_global", True)
        if scope in ("local", "all") and self.context.local_root is not None:
            roots.append(("local", self.context.local_root))
        if scope in ("global", "all") and (scope == "global" or inherit_global or self.context.local_root is None):
            roots.append(("global", self.context.global_root))
        merged: dict[str, dict[str, Any]] = {}
        directory_name = "tools" if kind == "tool" else "scenarios"
        for scope_name, root in reversed(roots):
            directory = root / directory_name
            if not directory.exists():
                continue
            for path in sorted(directory.glob("*.json")):
                item = read_json(path)
                item["_scope"] = scope_name
                item["_path"] = str(path)
                merged[item["id"]] = item
        return sorted(merged.values(), key=lambda item: item["id"])

    def get_manifest(self, kind: str, item_id: str, scope: str = "all") -> dict[str, Any]:
        item_id = slugify(item_id)
        for item in self.load_collection(kind, scope):
            if item["id"] == item_id:
                return item
        raise CLIHubError(f"{kind.title()} '{item_id}' was not found.")

    def find_tool_by_command(self, command: str, scope: str) -> dict[str, Any] | None:
        for tool in self.load_collection("tool", scope):
            if tool.get("command") == command:
                return tool
        return None


def compact_tool(tool: dict[str, Any]) -> dict[str, Any]:
    inspection = tool.get("inspection", {})
    return {
        "kind": "tool",
        "id": tool["id"],
        "name": tool.get("name", tool["id"]),
        "command": tool.get("command"),
        "summary": tool.get("summary") or tool.get("description"),
        "tags": tool.get("tags", []),
        "capabilities": tool.get("capabilities", []),
        "scope": tool.get("_scope"),
        "installed": inspection.get("installed"),
        "resolved_path": inspection.get("resolved_path"),
        "updated_at": tool.get("updated_at"),
    }


def compact_scenario(scenario: dict[str, Any]) -> dict[str, Any]:
    return {
        "kind": "scenario",
        "id": scenario["id"],
        "name": scenario.get("name", scenario["id"]),
        "description": scenario.get("description"),
        "step_count": len(scenario.get("steps", [])),
        "scope": scenario.get("_scope"),
        "updated_at": scenario.get("updated_at"),
    }


def print_tool(tool: dict[str, Any]) -> None:
    inspection = tool.get("inspection", {})
    print(f"{tool['id']} [{tool.get('_scope', 'unknown')}]")
    print(f"command: {tool['command']}")
    print(f"summary: {tool.get('summary', '')}")
    if tool.get("tags"):
        print(f"tags: {', '.join(tool['tags'])}")
    if tool.get("capabilities"):
        print(f"capabilities: {', '.join(tool['capabilities'])}")
    if inspection:
        print(f"installed: {'yes' if inspection.get('installed') else 'no'}")
        if inspection.get("resolved_path"):
            print(f"path: {inspection['resolved_path']}")
        if inspection.get("usage_lines"):
            print("usage:")
            for line in inspection["usage_lines"][:3]:
                print(f"  {line}")


def print_scenario(scenario: dict[str, Any]) -> None:
    print(f"{scenario['id']} [{scenario.get('_scope', 'unknown')}]")
    print(scenario.get("description", ""))
    for step in scenario.get("steps", []):
        if step.get("tool"):
            print(f"- {step['id']}: tool={step['tool']} args={step.get('args', [])}")
        else:
            print(f"- {step['id']}: command={step.get('command')}")


def print_compact_items(items: list[dict[str, Any]]) -> None:
    if not items:
        print("No items found.")
        return
    for item in items:
        summary = item.get("summary") or item.get("description") or ""
        print(f"{item['kind']} {item['id']} [{item.get('scope', 'unknown')}]")
        print(f"  {summary}")


def parse_inputs(values: list[str]) -> list[dict[str, str]]:
    inputs: list[dict[str, str]] = []
    for item in values:
        name, _, description = item.partition(":")
        name = name.strip()
        if not name:
            raise CLIHubError(f"Scenario input must start with a name: {item}")
        payload = {"name": name}
        if description.strip():
            payload["description"] = description.strip()
        inputs.append(payload)
    return inputs


def parse_steps(values: list[str]) -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = []
    for raw in values:
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise CLIHubError(f"Scenario step must be valid JSON: {raw}") from exc
        if not isinstance(payload, dict):
            raise CLIHubError(f"Scenario step must decode to an object: {raw}")
        steps.append(payload)
    return steps


def build_scenario_from_args(args: argparse.Namespace) -> dict[str, Any]:
    if args.file:
        manifest = load_manifest_file(args.file)
    else:
        if not args.id or not args.description:
            raise CLIHubError("scenario register requires --id and --description unless --file is used.")
        manifest = scenario_defaults(
            scenario_id=args.id,
            description=args.description,
            name=args.name or args.id,
            defaults=parse_key_values(args.defaults or []),
            inputs=parse_inputs(args.inputs or []),
            examples=args.examples or [],
            preconditions=args.preconditions or [],
            risk_level=args.risk_level or "medium",
            steps=parse_steps(args.steps or []),
        )
    if args.id:
        manifest["id"] = args.id
    if args.name:
        manifest["name"] = args.name
    if args.description:
        manifest["description"] = args.description
    if args.defaults:
        manifest["defaults"] = parse_key_values(args.defaults)
    if args.inputs:
        manifest["inputs"] = parse_inputs(args.inputs)
    if args.examples:
        manifest["examples"] = args.examples
    if args.preconditions:
        manifest["preconditions"] = args.preconditions
    if args.risk_level:
        manifest["risk_level"] = args.risk_level
    if args.steps:
        manifest["steps"] = parse_steps(args.steps)
    return validate_scenario(manifest)


def resolve_tool_for_exec(registry: Registry, tool_id: str) -> dict[str, Any]:
    return registry.get_manifest("tool", tool_id, "all")


def resolve_step_command(registry: Registry, step: dict[str, Any], variables: dict[str, Any]) -> list[str]:
    if step.get("tool"):
        tool = resolve_tool_for_exec(registry, step["tool"])
        base = shlex.split(render_template(tool["command"], variables))
        args = render_template(step.get("args", []), variables)
        if isinstance(args, str):
            args = shlex.split(args)
        return base + [str(item) for item in args]
    command = render_template(step["command"], variables)
    if isinstance(command, str):
        return shlex.split(command)
    return [str(item) for item in command]


def render_scenario_plan(registry: Registry, scenario: dict[str, Any], variables: dict[str, Any]) -> list[dict[str, Any]]:
    plan: list[dict[str, Any]] = []
    for step in scenario["steps"]:
        command = resolve_step_command(registry, step, variables)
        plan.append(
            {
                "id": step["id"],
                "tool": step.get("tool"),
                "command": command,
                "env": render_template(step.get("env", {}), variables),
                "cwd": render_template(step.get("cwd"), variables) if step.get("cwd") else None,
                "continue_on_error": step.get("continue_on_error", False),
            }
        )
    return plan


def execute_plan(plan: list[dict[str, Any]], *, stream_output: bool = True) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for step in plan:
        result = run_command(step["command"], env=step.get("env"), cwd=step.get("cwd"))
        payload = {
            "id": step["id"],
            "command": step["command"],
            "exit_code": result.returncode,
            "stdout": result.stdout or "",
            "stderr": result.stderr or "",
        }
        results.append(payload)
        if stream_output and result.stdout:
            print(result.stdout, end="")
        if stream_output and result.stderr:
            print(result.stderr, end="", file=sys.stderr)
        if result.returncode != 0 and not step.get("continue_on_error", False):
            break
    return results


def find_item_for_show(registry: Registry, item_id: str, kind: str, scope: str) -> tuple[str, dict[str, Any]]:
    if kind in ("tool", "scenario"):
        return kind, registry.get_manifest(kind, item_id, scope)
    found: list[tuple[str, dict[str, Any]]] = []
    for candidate_kind in ("tool", "scenario"):
        try:
            found.append((candidate_kind, registry.get_manifest(candidate_kind, item_id, scope)))
        except CLIHubError:
            continue
    if not found:
        raise CLIHubError(f"No tool or scenario found with id '{slugify(item_id)}'.")
    if len(found) > 1:
        raise CLIHubError(f"Id '{slugify(item_id)}' exists for both tool and scenario. Use --kind.")
    return found[0]


def text_fields_for_match(kind: str, item: dict[str, Any]) -> dict[str, str]:
    if kind == "tool":
        inspection = item.get("inspection", {})
        selected_help = inspection.get("help", {}).get("selected") or {}
        return {
            "id": item.get("id", ""),
            "name": item.get("name", ""),
            "command": item.get("command", ""),
            "summary": item.get("summary") or item.get("description", ""),
            "tags": " ".join(item.get("tags", [])),
            "capabilities": " ".join(item.get("capabilities", [])),
            "keywords": " ".join(item.get("keywords", [])),
            "usage": " ".join(inspection.get("usage_lines", [])),
            "help": (selected_help.get("stdout") or selected_help.get("stderr") or "")[:4000],
        }
    return {
        "id": item.get("id", ""),
        "name": item.get("name", ""),
        "description": item.get("description", ""),
        "examples": " ".join(item.get("examples", [])),
        "inputs": " ".join(input_item.get("name", "") for input_item in item.get("inputs", [])),
    }


def score_match(query: str, kind: str, item: dict[str, Any]) -> dict[str, Any] | None:
    query_lower = query.lower().strip()
    query_tokens = tokenize(query)
    fields = text_fields_for_match(kind, item)
    field_weights = {
        "id": 120,
        "name": 100,
        "command": 100,
        "summary": 90,
        "description": 90,
        "tags": 70,
        "capabilities": 70,
        "keywords": 60,
        "usage": 50,
        "examples": 40,
        "inputs": 30,
        "help": 20,
    }
    score = 0
    matched_fields: list[str] = []
    if query_lower == item.get("id", "").lower():
        score += 500
        matched_fields.append("id")
    if query_lower == item.get("command", "").lower():
        score += 400
        matched_fields.append("command")
    for field, text in fields.items():
        value = (text or "").lower()
        if not value:
            continue
        weight = field_weights.get(field, 10)
        field_matched = False
        if query_lower and query_lower in value:
            score += weight * 3
            field_matched = True
        for token in query_tokens:
            if len(token) < 2:
                continue
            if token in value:
                score += weight
                field_matched = True
        if field_matched and field not in matched_fields:
            matched_fields.append(field)
    if score <= 0:
        return None
    return {"score": score, "matched_fields": matched_fields}


def resolve_items(registry: Registry, query: str, kind: str, scope: str, limit: int) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    kinds = ["tool", "scenario"] if kind == "all" else [kind]
    for candidate_kind in kinds:
        for item in registry.load_collection(candidate_kind, scope):
            match = score_match(query, candidate_kind, item)
            if not match:
                continue
            compact = compact_tool(item) if candidate_kind == "tool" else compact_scenario(item)
            compact["score"] = match["score"]
            compact["matched_fields"] = match["matched_fields"]
            results.append(compact)
    results.sort(key=lambda item: (-item["score"], item["kind"], item["id"]))
    return results[:limit]


def build_tool_record(args: argparse.Namespace) -> dict[str, Any]:
    inspection = inspect_command(args.command)
    if not inspection["installed"]:
        raise CLIHubError(f"Command '{args.command}' is not available on PATH.")
    tool_id = args.id or slugify(args.command)
    summary = args.summary or inspection["summary_guess"]
    return validate_tool(
        tool_defaults(
            tool_id=tool_id,
            command=args.command,
            summary=summary,
            inspection=inspection,
            name=args.name or tool_id,
            tags=args.tags or [],
            capabilities=args.capabilities or [],
            risk_level=args.risk_level or "low",
            keywords=inspection["keywords"],
        )
    )


def refresh_tool_manifest(tool: dict[str, Any]) -> dict[str, Any]:
    refreshed = copy.deepcopy(tool)
    inspection = inspect_command(tool["command"])
    refreshed["inspection"] = inspection
    if refreshed.get("summary", "").startswith("CLI command registered from '"):
        refreshed["summary"] = inspection["summary_guess"]
    refreshed["examples"] = inspection.get("usage_lines", [])[:3] or refreshed.get("examples", [])
    return validate_tool(refreshed)


def add_common_json_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON.")


def handle_init(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    if args.scope == "global":
        root = context.global_root
        ensure_hub_layout(root, name=args.name or "global", inherit_global=False)
    else:
        target_root = Path(args.path).resolve() if args.path else context.cwd
        root = target_root / ".clihub"
        ensure_hub_layout(root, name=args.name, inherit_global=not args.no_global)
    payload = {"status": "ok", "scope": args.scope, "root": str(root), "schema_version": SCHEMA_VERSION}
    if args.json:
        pretty_print(payload)
    else:
        print(f"Initialized CLI Hub at {root}")
    return 0


def handle_inspect(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    inspection = inspect_command(args.command)
    if args.json:
        pretty_print(inspection)
    else:
        print(f"command: {inspection['command']}")
        print(f"installed: {'yes' if inspection['installed'] else 'no'}")
        if inspection.get("resolved_path"):
            print(f"path: {inspection['resolved_path']}")
        print(f"summary guess: {inspection['summary_guess']}")
        for line in inspection.get("usage_lines", [])[:3]:
            print(f"usage: {line}")
    return 0


def handle_register(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    existing = registry.find_tool_by_command(args.command, args.scope)
    if existing and not args.force:
        raise CLIHubError(
            f"Command '{args.command}' is already registered as '{existing['id']}'. Use --force to overwrite."
        )
    tool = build_tool_record(args)
    if existing and args.force:
        tool["registered_at"] = existing.get("registered_at", tool["registered_at"])
    path = registry.write_manifest("tool", tool, args.scope, force=args.force)
    payload = {
        "status": "ok",
        "tool_id": tool["id"],
        "command": tool["command"],
        "summary": tool["summary"],
        "path": str(path),
    }
    if args.json:
        pretty_print(payload)
    else:
        print(f"Registered tool '{tool['id']}'")
        print(f"command: {tool['command']}")
        print(f"summary: {tool['summary']}")
    return 0


def handle_unregister(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    path = registry.remove_manifest(args.kind, args.id, args.scope)
    payload = {"status": "ok", "kind": args.kind, "id": slugify(args.id), "path": str(path)}
    if args.json:
        pretty_print(payload)
    else:
        print(f"Removed {args.kind} '{slugify(args.id)}'")
    return 0


def handle_list(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    items: list[dict[str, Any]] = []
    if args.kind in ("tool", "all"):
        items.extend(compact_tool(item) for item in registry.load_collection("tool", args.scope))
    if args.kind in ("scenario", "all"):
        items.extend(compact_scenario(item) for item in registry.load_collection("scenario", args.scope))
    items.sort(key=lambda item: (item["kind"], item["id"]))
    if args.json:
        pretty_print({"items": items, "count": len(items)})
    else:
        print_compact_items(items)
    return 0


def handle_show(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    kind, item = find_item_for_show(registry, args.id, args.kind, args.scope)
    if args.json:
        pretty_print(item)
    else:
        if kind == "tool":
            print_tool(item)
        else:
            print_scenario(item)
    return 0


def handle_resolve(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    results = resolve_items(registry, args.query, args.kind, args.scope, args.limit)
    if args.json:
        pretty_print({"items": results, "count": len(results), "query": args.query})
    else:
        print_compact_items(results)
    return 0


def handle_doctor(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    tool = registry.get_manifest("tool", args.id, args.scope)
    inspection = inspect_command(tool["command"])
    payload = {
        "tool_id": tool["id"],
        "command": tool["command"],
        "installed": inspection["installed"],
        "resolved_path": inspection["resolved_path"],
        "summary_guess": inspection["summary_guess"],
        "usage_lines": inspection["usage_lines"],
        "help": inspection["help"],
        "version": inspection["version"],
    }
    if args.json:
        pretty_print(payload)
    else:
        print(f"tool: {tool['id']}")
        print(f"installed: {'yes' if inspection['installed'] else 'no'}")
        if inspection["resolved_path"]:
            print(f"path: {inspection['resolved_path']}")
        print(f"summary guess: {inspection['summary_guess']}")
    return 0


def handle_refresh(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    tool = registry.get_manifest("tool", args.id, args.scope)
    refreshed = refresh_tool_manifest(tool)
    target = Path(tool["_path"])
    refreshed.pop("_path", None)
    refreshed.pop("_scope", None)
    write_json(target, refreshed)
    payload = {
        "status": "ok",
        "tool_id": refreshed["id"],
        "command": refreshed["command"],
        "summary": refreshed["summary"],
        "path": str(target),
    }
    if args.json:
        pretty_print(payload)
    else:
        print(f"Refreshed tool '{refreshed['id']}'")
    return 0


def handle_exec(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    tool = resolve_tool_for_exec(registry, args.id)
    passthrough = list(args.args or [])
    if passthrough and passthrough[0] == "--":
        passthrough = passthrough[1:]
    command = shlex.split(tool["command"]) + passthrough
    if args.dry_run:
        payload = {"tool_id": tool["id"], "command": command}
        if args.json:
            pretty_print(payload)
        else:
            print(shlex.join(command))
        return 0
    result = run_command(command)
    if args.json:
        pretty_print(
            {
                "tool_id": tool["id"],
                "command": command,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
    else:
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
    return result.returncode


def handle_manifest(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    payload = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "scope": args.scope,
        "tools": registry.load_collection("tool", args.scope),
        "scenarios": registry.load_collection("scenario", args.scope),
    }
    pretty_print(payload)
    return 0


def handle_scenario_register(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    scenario = build_scenario_from_args(args)
    path = registry.write_manifest("scenario", scenario, args.scope, force=args.force)
    payload = {"status": "ok", "scenario_id": scenario["id"], "path": str(path)}
    if args.json:
        pretty_print(payload)
    else:
        print(f"Registered scenario '{scenario['id']}'")
    return 0


def handle_scenario_list(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    items = [compact_scenario(item) for item in registry.load_collection("scenario", args.scope)]
    if args.json:
        pretty_print({"items": items, "count": len(items)})
    else:
        print_compact_items(items)
    return 0


def handle_scenario_show(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    scenario = registry.get_manifest("scenario", args.id, args.scope)
    if args.json:
        pretty_print(scenario)
    else:
        print_scenario(scenario)
    return 0


def handle_scenario_unregister(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    path = registry.remove_manifest("scenario", args.id, args.scope)
    payload = {"status": "ok", "scenario_id": slugify(args.id), "path": str(path)}
    if args.json:
        pretty_print(payload)
    else:
        print(f"Removed scenario '{slugify(args.id)}'")
    return 0


def handle_scenario_validate(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    scenario = registry.get_manifest("scenario", args.id, args.scope)
    problems: list[str] = []
    for step in scenario["steps"]:
        if step.get("tool"):
            try:
                resolve_tool_for_exec(registry, step["tool"])
            except CLIHubError as exc:
                problems.append(f"{step['id']}: {exc}")
        elif step.get("command"):
            command = step["command"]
            executable = shlex.split(command)[0] if isinstance(command, str) else str(command[0])
            if resolve_executable(executable) is None:
                problems.append(f"{step['id']}: command not found: {executable}")
    payload = {"scenario_id": scenario["id"], "valid": not problems, "problems": problems}
    if args.json:
        pretty_print(payload)
    else:
        if problems:
            print(f"Scenario '{scenario['id']}' is invalid:")
            for problem in problems:
                print(f"- {problem}")
        else:
            print(f"Scenario '{scenario['id']}' is valid.")
    return 0 if not problems else 1


def handle_scenario_run(args: argparse.Namespace, context: HubContext, registry: Registry) -> int:
    scenario = registry.get_manifest("scenario", args.id, args.scope)
    variables = dict(scenario.get("defaults", {}))
    variables.update(parse_key_values(args.sets or []))
    plan = render_scenario_plan(registry, scenario, variables)
    if args.dry_run:
        payload = {"scenario_id": scenario["id"], "variables": variables, "plan": plan}
        if args.json:
            pretty_print(payload)
        else:
            for step in plan:
                print(f"{step['id']}: {shlex.join(step['command'])}")
        return 0
    results = execute_plan(plan, stream_output=not args.json)
    exit_code = results[-1]["exit_code"] if results else 0
    if args.json:
        pretty_print({"scenario_id": scenario["id"], "results": results, "exit_code": exit_code})
    return exit_code


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="clihub",
        description="CLI Hub: an AI-first registry for local command-line tools and reusable scenarios.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Initialize the global or local CLI Hub registry.")
    init_parser.add_argument("path", nargs="?", help="Project directory to initialize when --scope=local.")
    init_parser.add_argument("--name", help="Optional hub name.")
    init_parser.add_argument("--scope", choices=("global", "local"), default="global")
    init_parser.add_argument("--no-global", action="store_true", help="Do not inherit global tools.")
    add_common_json_flag(init_parser)
    init_parser.set_defaults(handler=handle_init)

    inspect_parser = subparsers.add_parser("inspect", help="Inspect a raw CLI command before registration.")
    inspect_parser.add_argument("command", help="Raw command or base invocation to inspect.")
    add_common_json_flag(inspect_parser)
    inspect_parser.set_defaults(handler=handle_inspect)

    register_parser = subparsers.add_parser("register", help="Auto-register a raw CLI command for AI use.")
    register_parser.add_argument("command", help="Raw command or base invocation to register.")
    register_parser.add_argument("--id", help="Override the generated tool id.")
    register_parser.add_argument("--name", help="Display name.")
    register_parser.add_argument("--summary", help="Override the summary inferred from help output.")
    register_parser.add_argument("--tag", dest="tags", action="append", default=[], help="Tool tag.")
    register_parser.add_argument(
        "--capability", dest="capabilities", action="append", default=[], help="Capability label."
    )
    register_parser.add_argument("--risk-level", choices=RISK_LEVELS, help="Side-effect risk level.")
    register_parser.add_argument("--scope", choices=("local", "global"), default="global")
    register_parser.add_argument("--force", action="store_true", help="Overwrite an existing registration.")
    add_common_json_flag(register_parser)
    register_parser.set_defaults(handler=handle_register)

    unregister_parser = subparsers.add_parser("unregister", help="Remove a registered tool or scenario.")
    unregister_parser.add_argument("id", help="Registered id.")
    unregister_parser.add_argument("--kind", choices=("tool", "scenario"), default="tool")
    unregister_parser.add_argument("--scope", choices=("local", "global"), default="global")
    add_common_json_flag(unregister_parser)
    unregister_parser.set_defaults(handler=handle_unregister)

    list_parser = subparsers.add_parser("list", help="List what AI can currently discover in CLI Hub.")
    list_parser.add_argument("--kind", choices=("tool", "scenario", "all"), default="tool")
    list_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(list_parser)
    list_parser.set_defaults(handler=handle_list)

    show_parser = subparsers.add_parser("show", help="Show the full stored record for a tool or scenario.")
    show_parser.add_argument("id", help="Registered id.")
    show_parser.add_argument("--kind", choices=("auto", "tool", "scenario"), default="auto")
    show_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(show_parser)
    show_parser.set_defaults(handler=handle_show)

    resolve_parser = subparsers.add_parser("resolve", help="Find the best registered match for a user intent.")
    resolve_parser.add_argument("query", help="Intent or task description.")
    resolve_parser.add_argument("--kind", choices=("tool", "scenario", "all"), default="tool")
    resolve_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    resolve_parser.add_argument("--limit", type=int, default=10, help="Maximum number of matches.")
    add_common_json_flag(resolve_parser)
    resolve_parser.set_defaults(handler=handle_resolve)

    doctor_parser = subparsers.add_parser("doctor", help="Live-check a registered tool without rewriting it.")
    doctor_parser.add_argument("id", help="Registered tool id.")
    doctor_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(doctor_parser)
    doctor_parser.set_defaults(handler=handle_doctor)

    refresh_parser = subparsers.add_parser("refresh", help="Re-inspect a registered tool and update its record.")
    refresh_parser.add_argument("id", help="Registered tool id.")
    refresh_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(refresh_parser)
    refresh_parser.set_defaults(handler=handle_refresh)

    exec_parser = subparsers.add_parser("exec", help="Execute a registered tool with extra arguments.")
    exec_parser.add_argument("id", help="Registered tool id.")
    exec_parser.add_argument("--dry-run", action="store_true", help="Print the final command only.")
    add_common_json_flag(exec_parser)
    exec_parser.set_defaults(handler=handle_exec)

    manifest_parser = subparsers.add_parser("manifest", help="Export the full registry as JSON.")
    manifest_parser.add_argument("--scope", choices=("local", "global", "all"), default="global")
    manifest_parser.set_defaults(handler=handle_manifest)

    scenario_parser = subparsers.add_parser("scenario", help="Manage reusable multi-step scenarios.")
    scenario_subparsers = scenario_parser.add_subparsers(dest="scenario_command", required=True)

    scenario_register = scenario_subparsers.add_parser("register", help="Register a scenario.")
    scenario_register.add_argument("--file", help="Path to a JSON scenario manifest.")
    scenario_register.add_argument("--id", help="Scenario id.")
    scenario_register.add_argument("--name", help="Display name.")
    scenario_register.add_argument("--description", help="Scenario description.")
    scenario_register.add_argument("--default", dest="defaults", action="append", default=[], help="KEY=VALUE.")
    scenario_register.add_argument("--input", dest="inputs", action="append", default=[], help="name:description.")
    scenario_register.add_argument("--example", dest="examples", action="append", default=[], help="Example usage.")
    scenario_register.add_argument(
        "--precondition", dest="preconditions", action="append", default=[], help="Scenario precondition."
    )
    scenario_register.add_argument("--step", dest="steps", action="append", default=[], help="Step JSON object.")
    scenario_register.add_argument("--risk-level", choices=RISK_LEVELS, help="Scenario risk level.")
    scenario_register.add_argument("--scope", choices=("local", "global"), default="global")
    scenario_register.add_argument("--force", action="store_true", help="Overwrite an existing scenario.")
    add_common_json_flag(scenario_register)
    scenario_register.set_defaults(handler=handle_scenario_register)

    scenario_list = scenario_subparsers.add_parser("list", help="List scenarios.")
    scenario_list.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(scenario_list)
    scenario_list.set_defaults(handler=handle_scenario_list)

    scenario_show = scenario_subparsers.add_parser("show", help="Show scenario details.")
    scenario_show.add_argument("id", help="Scenario id.")
    scenario_show.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(scenario_show)
    scenario_show.set_defaults(handler=handle_scenario_show)

    scenario_unregister = scenario_subparsers.add_parser("unregister", help="Remove a scenario.")
    scenario_unregister.add_argument("id", help="Scenario id.")
    scenario_unregister.add_argument("--scope", choices=("local", "global"), default="global")
    add_common_json_flag(scenario_unregister)
    scenario_unregister.set_defaults(handler=handle_scenario_unregister)

    scenario_validate = scenario_subparsers.add_parser("validate", help="Validate scenario references.")
    scenario_validate.add_argument("id", help="Scenario id.")
    scenario_validate.add_argument("--scope", choices=("local", "global", "all"), default="global")
    add_common_json_flag(scenario_validate)
    scenario_validate.set_defaults(handler=handle_scenario_validate)

    scenario_run = scenario_subparsers.add_parser("run", help="Run a scenario.")
    scenario_run.add_argument("id", help="Scenario id.")
    scenario_run.add_argument("--scope", choices=("local", "global", "all"), default="global")
    scenario_run.add_argument("--set", dest="sets", action="append", default=[], help="KEY=VALUE runtime value.")
    scenario_run.add_argument("--dry-run", action="store_true", help="Render commands without executing.")
    add_common_json_flag(scenario_run)
    scenario_run.set_defaults(handler=handle_scenario_run)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args, unknown = parser.parse_known_args(argv)
    if getattr(args, "command", None) == "exec":
        args.args = unknown
    elif unknown:
        parser.error(f"unrecognized arguments: {' '.join(unknown)}")
    context = HubContext.discover()
    registry = Registry(context)
    try:
        return args.handler(args, context, registry)
    except CLIHubError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
