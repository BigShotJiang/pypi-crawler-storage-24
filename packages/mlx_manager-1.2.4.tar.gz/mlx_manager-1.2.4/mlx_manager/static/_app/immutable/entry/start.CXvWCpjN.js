import{l as o,a as r}from"../chunks/BL1kFfBZ.js";export{o as load_css,r as start};
