"""
Kodara — Memory Layer for AI Development.

Architecture-aware context engine that converts a codebase into
queryable structured memory, reducing LLM context from ~900k to ~20k tokens.
"""

__version__ = "0.2.0"
