"""Authentication commands: login, logout, status, me."""

from __future__ import annotations

import json
import logging

import click
from rich.panel import Panel

from ._common import console, handle_command, structured_output_options

logger = logging.getLogger(__name__)


@click.command()
@click.option("--cookie-source", default=None, help="指定瀏覽器 (chrome/firefox/edge/brave/arc/safari)")
@click.option("--cookie-file", default=None, type=click.Path(exists=True), help="從 Cookie 檔案匯入 (JSON 或 Netscape 格式)")
def login(cookie_source: str | None, cookie_file: str | None) -> None:
    """透過瀏覽器 Cookie 登入 104 人力銀行"""
    from ..auth import (
        extract_browser_credential,
        load_cookie_file,
        verify_credential,
    )

    cred = None

    # Option 1: Manual cookie file import
    if cookie_file:
        cred = load_cookie_file(cookie_file)
        if not cred:
            console.print("[red]無法從檔案中讀取有效的 Cookie[/red]")
            raise SystemExit(1)
        console.print(f"[green]已從檔案匯入 {len(cred.cookies)} 個 Cookie[/green]")

    # Option 2: Extract from browser
    if not cred:
        if cookie_source:
            console.print(f"[dim]正在從 {cookie_source} 提取 Cookie...[/dim]")
        else:
            console.print("[dim]正在從瀏覽器提取 Cookie...[/dim]")

        cred = extract_browser_credential(cookie_source=cookie_source)
        if not cred:
            console.print(
                "[yellow]未找到瀏覽器 Cookie。[/yellow]\n"
                "請先在瀏覽器中登入 [bold]https://www.104.com.tw[/bold]，然後重新執行此指令。\n"
                "或使用 [bold]job104 login --cookie-file <path>[/bold] 手動匯入。"
            )
            raise SystemExit(1)

    # Verify the credential
    console.print("[dim]正在驗證登入狀態...[/dim]")
    authenticated, message = verify_credential(cred)
    if authenticated:
        console.print(f"[green]登入成功！[/green] ({len(cred.cookies)} cookies)")
    else:
        console.print(f"[yellow]Cookie 已儲存 ({len(cred.cookies)} cookies)，但驗證未通過[/yellow]")
        if message:
            console.print(f"[dim]{message}[/dim]")
        console.print("[dim]部分功能（如搜尋）不需要登入仍可使用[/dim]")


@click.command()
def logout() -> None:
    """清除已儲存的登入憑證"""
    from ..auth import clear_credential

    clear_credential()
    console.print("[green]已登出[/green]")


@click.command()
@structured_output_options
def status(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """檢查目前登入狀態"""
    from ..auth import get_credential, verify_credential

    cred = get_credential()
    if cred:
        authenticated, message = verify_credential(cred)
        cookie_names = sorted(cred.cookies.keys())
        data = {
            "authenticated": authenticated,
            "credential_present": True,
            "cookie_count": len(cred.cookies),
            "cookies": cookie_names,
        }
        if message:
            data["reason"] = message

        if as_json:
            click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        elif as_yaml:
            try:
                import yaml

                click.echo(yaml.dump(data, allow_unicode=True, default_flow_style=False))
            except ImportError:
                click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            n = len(cred.cookies)
            keys = ", ".join(cookie_names[:5])
            extra = f" (+{n - 5} more)" if n > 5 else ""
            if authenticated:
                console.print(f"[green]已登入[/green] ({n} cookies)")
                console.print(f"  [dim]{keys}{extra}[/dim]")
            else:
                console.print(f"[yellow]本地存在憑證，但登入態可能無效[/yellow] ({n} cookies)")
                console.print(f"  [dim]{keys}{extra}[/dim]")
                if message:
                    console.print(f"  [dim]{message}[/dim]")
    else:
        data = {"authenticated": False, "credential_present": False}
        if as_json:
            click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        elif as_yaml:
            try:
                import yaml

                click.echo(yaml.dump(data, allow_unicode=True, default_flow_style=False))
            except ImportError:
                click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            console.print("[yellow]未登入[/yellow]，使用 [bold]job104 login[/bold] 登入")


@click.command()
@structured_output_options
def me(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看個人資料"""
    from ..auth import get_credential

    cred = get_credential()
    if not cred:
        console.print("[red]未登入，請先使用 [bold]job104 login[/bold] 登入[/red]")
        raise SystemExit(1)

    def _action(client):
        return client.get_profile()

    def _render(info: dict) -> None:
        source = info.get("_source", "")

        if source == "none":
            console.print("[green]已登入[/green]（個人資料 API 暫不可用）")
            return

        if source == "applied_fallback":
            raw = info.get("_raw", {})
            records = raw.get("data", [])
            lines = ["[green]已登入[/green]"]
            if records:
                lines.append(f"近期應徵: {len(records)} 筆")
                first = records[0]
                if first.get("applyDate"):
                    lines.append(f"最近應徵: {first['applyDate']}")
            panel = Panel("\n".join(lines), title="帳號狀態", border_style="cyan")
            console.print(panel)
            return

        # Normal profile rendering
        name = info.get("name", info.get("userName", "-"))
        email = info.get("email", "-")
        phone = info.get("phone", "-")

        lines = [f"[bold]{name}[/bold]"]
        if email and email != "-":
            lines.append(f"信箱: {email}")
        if phone and phone != "-":
            lines.append(f"電話: {phone}")
        if info.get("education"):
            lines.append(f"學歷: {info['education']}")
        if info.get("jobTitle"):
            lines.append(f"目前職稱: {info['jobTitle']}")

        panel = Panel(
            "\n".join(lines),
            title="個人資料",
            border_style="cyan",
        )
        console.print(panel)

    handle_command(
        action=_action,
        render=_render,
        as_json=as_json,
        as_yaml=as_yaml,
        as_md=as_md,
        credential=cred,
    )
