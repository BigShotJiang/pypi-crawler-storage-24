"""CLI entry point for job104 CLI.

Usage:
    job104 search <keyword> [--area A] [--exp E] [--edu D]
    job104 detail <jobNo>
    job104 show <index>
    job104 export <keyword> [-n N] [-o FILE]
    job104 areas
    job104 login [--cookie-source BROWSER] [--cookie-file PATH]
    job104 logout
    job104 status [--json]
    job104 me [--json]
    job104 resume-edit <section> [--add|--update|--delete] [--data JSON]
    job104 resume-fill --from <file> [--strategy replace|merge]
    job104 resume-fields [--section <name>] --json
    job104 resume-autocomplete <type> <query>
"""

from __future__ import annotations

import logging

import click

from . import __version__
from .commands import auth, personal, resume_edit, search


@click.group()
@click.version_option(version=__version__, prog_name="job104")
@click.option("-v", "--verbose", is_flag=True, help="啟用詳細日誌 (顯示請求 URL、時間)")
@click.pass_context
def cli(ctx: click.Context, verbose: bool) -> None:
    """job104 CLI — 在終端機搜尋 104 人力銀行職缺"""
    ctx.ensure_object(dict)
    if verbose:
        logging.basicConfig(level=logging.INFO, format="%(name)s %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)


# -- Search & Browse commands ------------------------------------------------

cli.add_command(search.search)
cli.add_command(search.detail)
cli.add_command(search.show)
cli.add_command(search.export)
cli.add_command(search.company)
cli.add_command(search.categories)
cli.add_command(search.industries)
cli.add_command(search.areas)
cli.add_command(search.suggest)

# -- Auth commands -----------------------------------------------------------

cli.add_command(auth.login)
cli.add_command(auth.logout)
cli.add_command(auth.status)
cli.add_command(auth.me)

# -- Personal center commands ------------------------------------------------

cli.add_command(personal.applied)
cli.add_command(personal.saved)
cli.add_command(personal.interviews)
cli.add_command(personal.resume)
cli.add_command(personal.resume_show)
cli.add_command(personal.viewers)
cli.add_command(personal.follows)
cli.add_command(personal.history)
cli.add_command(personal.recommend)

# -- Resume edit commands ----------------------------------------------------

cli.add_command(resume_edit.resume_edit)
cli.add_command(resume_edit.resume_fill)
cli.add_command(resume_edit.resume_fields)
cli.add_command(resume_edit.resume_autocomplete)


if __name__ == "__main__":
    cli()
