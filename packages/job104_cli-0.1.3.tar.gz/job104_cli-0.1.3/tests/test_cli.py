"""Tests for job104 CLI."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from job104_cli.cli import cli
from job104_cli.client import Job104Client, resolve_area
from job104_cli.constants import (
    AREA_CODES,
    EDU_CODES,
    EXP_CODES,
    INDCAT_CODES,
    JOB_TYPE_CODES,
    JOBCAT_CODES,
    MATCH_MODE_CODES,
    SCHEDULE_CODES,
)
from job104_cli.exceptions import (
    CloudflareBlockError,
    Job104ApiError,
    RateLimitError,
    error_code_for_exception,
)
from job104_cli.index_cache import get_job_by_index, save_index
from job104_cli.models import Job


# -- CLI help tests ----------------------------------------------------------


class TestCLIHelp:
    """Verify all commands respond to --help."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    @pytest.mark.parametrize(
        "args",
        [
            ["--help"],
            ["--version"],
            ["search", "--help"],
            ["detail", "--help"],
            ["show", "--help"],
            ["export", "--help"],
            ["areas", "--help"],
            ["categories", "--help"],
            ["industries", "--help"],
            ["suggest", "--help"],
        ],
    )
    def test_help_exits_cleanly(self, runner: CliRunner, args: list[str]) -> None:
        result = runner.invoke(cli, args)
        assert result.exit_code == 0, f"Failed for {args}: {result.output}"

    def test_version_shows_version(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["--version"])
        assert "job104" in result.output
        assert "0.1.0" in result.output


# -- Area resolution tests ---------------------------------------------------


class TestAreaResolution:
    def test_resolve_known_city(self) -> None:
        assert resolve_area("台北市") == "6001001000"

    def test_resolve_code_passthrough(self) -> None:
        assert resolve_area("6001001000") == "6001001000"

    def test_resolve_unknown_returns_empty(self) -> None:
        assert resolve_area("不存在的地方") == ""

    def test_all_areas_have_strings(self) -> None:
        for name, code in AREA_CODES.items():
            assert isinstance(name, str)
            assert isinstance(code, str)


# -- Exception tests ---------------------------------------------------------


class TestExceptions:
    def test_error_code_mapping(self) -> None:
        assert error_code_for_exception(RateLimitError()) == "rate_limited"
        assert error_code_for_exception(Job104ApiError("test")) == "api_error"
        assert error_code_for_exception(ValueError("test")) == "unknown_error"

    def test_api_error_attributes(self) -> None:
        exc = Job104ApiError("test error", code=42, response={"key": "val"})
        assert str(exc) == "test error"
        assert exc.code == 42
        assert exc.response == {"key": "val"}


# -- Constants tests ---------------------------------------------------------


class TestConstants:
    def test_exp_codes_have_expected_keys(self) -> None:
        assert "不限" in EXP_CODES
        assert "3-5年" in EXP_CODES

    def test_edu_codes_have_expected_keys(self) -> None:
        assert "不限" in EDU_CODES
        assert "碩士" in EDU_CODES

    def test_area_codes_include_major_cities(self) -> None:
        for city in ["台北市", "新北市", "台中市", "高雄市", "台南市"]:
            assert city in AREA_CODES, f"Missing city: {city}"

    def test_jobcat_codes_cover_all_main_categories(self) -> None:
        l0_count = sum(1 for c in JOBCAT_CODES.values() if c.endswith("000000"))
        assert l0_count == 18, f"Expected 18 L0 categories, got {l0_count}"
        assert len(JOBCAT_CODES) >= 100, f"Expected 100+ entries, got {len(JOBCAT_CODES)}"

    def test_jobcat_codes_include_non_it_categories(self) -> None:
        for name in ["醫療／保健服務類", "財會／金融專業類", "學術／教育／輔導類", "餐飲／旅遊／美容美髮類"]:
            assert name in JOBCAT_CODES, f"Missing job category: {name}"

    def test_indcat_codes_cover_all_main_industries(self) -> None:
        l0_count = sum(1 for c in INDCAT_CODES.values() if c.endswith("000000"))
        assert l0_count == 16, f"Expected 16 L0 industries, got {l0_count}"
        assert len(INDCAT_CODES) >= 80, f"Expected 80+ entries, got {len(INDCAT_CODES)}"

    def test_indcat_codes_include_key_industries(self) -> None:
        for name in ["半導體業", "金融機構及其相關業", "醫療服務業", "教育服務業"]:
            assert name in INDCAT_CODES, f"Missing industry: {name}"


# -- Index cache tests -------------------------------------------------------


class TestIndexCache:
    def test_save_and_retrieve(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.index_cache.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.index_cache.INDEX_CACHE_FILE", tmp_path / "index_cache.json")

        jobs = [
            {"jobNo": "abc123", "jobName": "Test Job 1", "custName": "Co 1", "salaryLow": 50000, "salaryHigh": 70000},
            {"jobNo": "def456", "jobName": "Test Job 2", "custName": "Co 2", "salaryLow": 60000, "salaryHigh": 90000},
        ]
        save_index(jobs, source="test")

        result = get_job_by_index(1)
        assert result is not None
        assert result["jobNo"] == "abc123"

        result = get_job_by_index(2)
        assert result is not None
        assert result["jobNo"] == "def456"

    def test_out_of_range_returns_none(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.index_cache.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.index_cache.INDEX_CACHE_FILE", tmp_path / "index_cache.json")

        jobs = [{"jobNo": "abc123", "jobName": "Test", "link": {"job": "https://www.104.com.tw/job/abc123"}}]
        save_index(jobs, source="test")

        assert get_job_by_index(0) is None
        assert get_job_by_index(5) is None

    def test_extract_job_id_from_link(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.index_cache.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.index_cache.INDEX_CACHE_FILE", tmp_path / "index_cache.json")

        jobs = [{"link": {"job": "//www.104.com.tw/job/xyz789"}, "jobName": "Link Job"}]
        save_index(jobs, source="test")

        result = get_job_by_index(1)
        assert result is not None
        assert result["jobId"] == "xyz789"


# -- Client tests ------------------------------------------------------------


class TestClient:
    def test_client_context_manager(self) -> None:
        with Job104Client() as client:
            assert client._http is not None
        assert client._http is None

    def test_client_without_context_raises(self) -> None:
        client = Job104Client()
        with pytest.raises(RuntimeError, match="not initialized"):
            _ = client.client


# -- Search command integration (mocked) -------------------------------------


class TestSearchCommand:
    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_json_output(self, runner: CliRunner) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '{"data":[],"metadata":{"pagination":{"total":0,"lastPage":0}}}'
        mock_response.json.return_value = {
            "data": [],
            "metadata": {"pagination": {"total": 0, "lastPage": 0, "currentPage": 1, "count": 0}},
        }
        mock_response.cookies = {}

        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response  # For CF warmup
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_areas_command(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["areas"])
        assert result.exit_code == 0

    def test_categories_command(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["categories"])
        assert result.exit_code == 0

    def test_categories_all_flag(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["categories", "--all"])
        assert result.exit_code == 0

    def test_industries_command(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["industries"])
        assert result.exit_code == 0

    def test_industries_all_flag(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["industries", "--all"])
        assert result.exit_code == 0

    def test_search_with_indcat(self, runner: CliRunner) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '{"data":[],"metadata":{"pagination":{"total":0,"lastPage":0}}}'
        mock_response.json.return_value = {
            "data": [],
            "metadata": {"pagination": {"total": 0, "lastPage": 0, "currentPage": 1, "count": 0}},
        }
        mock_response.cookies = {}

        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "護理師", "--indcat", "醫療服務業", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_search_with_raw_code(self, runner: CliRunner) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '{"data":[],"metadata":{"pagination":{"total":0,"lastPage":0}}}'
        mock_response.json.return_value = {
            "data": [],
            "metadata": {"pagination": {"total": 0, "lastPage": 0, "currentPage": 1, "count": 0}},
        }
        mock_response.cookies = {}

        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--jobcat", "2007001020", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_company_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["company", "--help"])
        assert result.exit_code == 0


# -- Job model tests ---------------------------------------------------------


class TestJobModel:
    def test_from_search_result_new_format(self) -> None:
        raw = {
            "jobNo": 15077397,
            "jobName": "Senior AI Engineer",
            "link": {"job": "https://www.104.com.tw/job/8z5sl", "cust": "https://www.104.com.tw/company/xyz"},
            "custName": "Google_美商科高國際有限公司",
            "custNo": "xyz",
            "coIndustryDesc": "網際網路相關業",
            "salaryLow": 80000,
            "salaryHigh": 150000,
            "optionEdu": [4, 5],
            "optionExp": "3年以上",
            "tags": {"s1": {"desc": "Python"}, "s2": {"desc": "AI"}},
            "jobAddrNoDesc": "台北市信義區",
            "appearDate": "2026/03/14",
            "description": "We are looking for...",
        }
        job = Job.from_search_result(raw)
        assert job.job_no == "15077397"
        assert job.job_id == "8z5sl"
        assert job.salary_desc == "80,000 ~ 150,000"
        assert job.edu_desc == "大學/碩士"
        assert job.tags == ["Python", "AI"]
        assert job.industry == "網際網路相關業"

    def test_from_search_result_no_salary(self) -> None:
        raw = {"jobNo": "123", "jobName": "Test", "salaryLow": 0, "salaryHigh": 0}
        job = Job.from_search_result(raw)
        assert job.salary_desc == "面議"

    def test_from_search_result_legacy_tags(self) -> None:
        raw = {"jobNo": "123", "tags": ["Python", "Django"]}
        job = Job.from_search_result(raw)
        assert job.tags == ["Python", "Django"]

    def test_to_dict_roundtrip(self) -> None:
        raw = {
            "jobNo": 999,
            "jobName": "Test",
            "link": {"job": "https://www.104.com.tw/job/abc"},
            "salaryLow": 50000,
            "salaryHigh": 70000,
            "optionEdu": [4],
            "tags": {"s1": {"desc": "Go"}},
        }
        job = Job.from_search_result(raw)
        d = job.to_dict()
        assert d["jobId"] == "abc"
        assert d["salary"] == "50,000 ~ 70,000"
        assert d["tags"] == ["Go"]


# -- CloudflareBlockError test -----------------------------------------------


class TestCloudflareBlockError:
    def test_error_code(self) -> None:
        assert error_code_for_exception(CloudflareBlockError()) == "cloudflare_blocked"


# -- New filter constants tests ----------------------------------------------


class TestNewFilterConstants:
    def test_match_mode_codes(self) -> None:
        assert "僅標題" in MATCH_MODE_CODES
        assert "標題+描述" in MATCH_MODE_CODES
        assert "廣泛" in MATCH_MODE_CODES
        assert MATCH_MODE_CODES["僅標題"] == "1"
        assert MATCH_MODE_CODES["標題+描述"] == "7"

    def test_job_type_codes(self) -> None:
        assert "全職" in JOB_TYPE_CODES
        assert "兼職" in JOB_TYPE_CODES
        assert "高階" in JOB_TYPE_CODES
        assert "派遣" in JOB_TYPE_CODES
        assert JOB_TYPE_CODES["全職"] == "1"

    def test_schedule_codes(self) -> None:
        assert "日班" in SCHEDULE_CODES
        assert "夜班" in SCHEDULE_CODES
        assert "假日班" in SCHEDULE_CODES
        assert "大夜班" in SCHEDULE_CODES

    def test_schedule_comma_separated(self) -> None:
        """Verify comma-separated format for schedule codes (API rejects bitmask)."""
        codes = [SCHEDULE_CODES[s] for s in ("日班", "夜班")]
        assert ",".join(codes) == "1,2"

        all_codes = ",".join(SCHEDULE_CODES.values())
        assert all_codes == "1,2,4,8"


# -- District area codes tests ----------------------------------------------


class TestDistrictAreaCodes:
    def test_taipei_districts(self) -> None:
        assert "台北市大安區" in AREA_CODES
        assert "台北市內湖區" in AREA_CODES
        assert "台北市信義區" in AREA_CODES

    def test_new_taipei_districts(self) -> None:
        assert "新北市板橋區" in AREA_CODES
        assert "新北市中和區" in AREA_CODES

    def test_taichung_districts(self) -> None:
        assert "台中市西屯區" in AREA_CODES

    def test_kaohsiung_districts(self) -> None:
        assert "高雄市前鎮區" in AREA_CODES

    def test_district_code_format(self) -> None:
        """District codes should be more specific than city codes."""
        city_code = AREA_CODES["台北市"]
        district_code = AREA_CODES["台北市大安區"]
        assert city_code.startswith("600100")
        assert district_code.startswith("600100")
        assert city_code != district_code


# -- resolve_area warning test -----------------------------------------------


class TestResolveAreaWarning:
    def test_unknown_area_warns(self, capsys) -> None:
        result = resolve_area("不存在的地方")
        assert result == ""
        captured = capsys.readouterr()
        assert "找不到地區" in captured.err

    def test_known_area_no_warning(self, capsys) -> None:
        result = resolve_area("台北市")
        assert result == "6001001000"
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_district_resolves(self) -> None:
        result = resolve_area("台北市大安區")
        assert result != ""


# -- Job model new fields tests ----------------------------------------------


class TestJobModelNewFields:
    def test_new_fields_from_search_result(self) -> None:
        raw = {
            "jobNo": "123",
            "jobName": "Test",
            "applyCnt": 10,
            "remoteWorkType": 2,
            "employeeCount": 500,
        }
        job = Job.from_search_result(raw)
        assert job.apply_cnt == 10
        assert job.remote_work_type == 2
        assert job.employee_count == 500

    def test_new_fields_in_to_dict(self) -> None:
        raw = {
            "jobNo": "123",
            "applyCnt": 5,
            "remoteWorkType": 1,
            "employeeCount": 200,
        }
        job = Job.from_search_result(raw)
        d = job.to_dict()
        assert d["applyCnt"] == 5
        assert d["remoteWorkType"] == 1
        assert d["employeeCount"] == 200

    def test_new_fields_default_zero(self) -> None:
        raw = {"jobNo": "123"}
        job = Job.from_search_result(raw)
        assert job.apply_cnt == 0
        assert job.remote_work_type == 0
        assert job.employee_count == 0


# -- Search with new filters (mocked) ---------------------------------------


class TestSearchNewFilters:
    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def _mock_empty_response(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '{"data":[],"metadata":{"pagination":{"total":0,"lastPage":0}}}'
        mock_response.json.return_value = {
            "data": [],
            "metadata": {"pagination": {"total": 0, "lastPage": 0, "currentPage": 1, "count": 0}},
        }
        mock_response.cookies = {}
        return mock_response

    def test_search_with_job_type(self, runner: CliRunner) -> None:
        mock_response = self._mock_empty_response()
        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--job-type", "全職", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_search_with_match_mode(self, runner: CliRunner) -> None:
        mock_response = self._mock_empty_response()
        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--match-mode", "僅標題", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_search_with_salary_strict(self, runner: CliRunner) -> None:
        mock_response = self._mock_empty_response()
        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--salary-strict", "--exclude-negotiable", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_search_with_schedule(self, runner: CliRunner) -> None:
        mock_response = self._mock_empty_response()
        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--schedule", "日班", "--schedule", "夜班", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_search_with_exclude_kw(self, runner: CliRunner) -> None:
        mock_response = self._mock_empty_response()
        with patch.object(Job104Client, "_build_client") as mock_build:
            mock_http = MagicMock()
            mock_http.request.return_value = mock_response
            mock_http.cookies = MagicMock()
            mock_http.get.return_value = mock_response
            mock_build.return_value = mock_http

            result = runner.invoke(cli, ["search", "Python", "--exclude-kw", "管理", "--exclude-kw", "行政", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_suggest_help(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["suggest", "--help"])
        assert result.exit_code == 0
        assert "關鍵字自動完成" in result.output
