"""Tests for records commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.commands.records import _parse_cli_value

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.records.SyncVirtualDojoClient"


class TestParseCliValue:
    def test_true(self):
        assert _parse_cli_value("true") is True
        assert _parse_cli_value("True") is True

    def test_false(self):
        assert _parse_cli_value("false") is False

    def test_null(self):
        assert _parse_cli_value("null") is None
        assert _parse_cli_value("none") is None
        assert _parse_cli_value("") is None

    def test_int(self):
        assert _parse_cli_value("42") == 42

    def test_float(self):
        assert _parse_cli_value("3.14") == 3.14

    def test_json_object(self):
        assert _parse_cli_value('{"a": 1}') == {"a": 1}

    def test_json_array(self):
        assert _parse_cli_value("[1, 2]") == [1, 2]

    def test_invalid_json(self):
        assert _parse_cli_value("{bad}") == "{bad}"

    def test_string(self):
        assert _parse_cli_value("hello") == "hello"


class TestListRecords:
    @patch(MOCK_CLIENT)
    def test_list_success(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "records": [{"id": "1", "name": "Test"}],
            "total_count": 1,
        }
        result = runner.invoke(app, ["records", "list", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_with_filter(self, mock_cls):
        mock_cls.return_value.get.return_value = {"records": [], "total_count": 0}
        result = runner.invoke(
            app, ["records", "list", "accounts", "--filter", "status=active"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_with_sort(self, mock_cls):
        mock_cls.return_value.get.return_value = {"records": [], "total_count": 0}
        result = runner.invoke(
            app, ["records", "list", "accounts", "--sort", "name", "--desc"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_with_columns(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "records": [{"id": "1", "name": "Test"}],
            "total_count": 1,
        }
        result = runner.invoke(
            app, ["records", "list", "accounts", "--columns", "id,name"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_json_format(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "records": [{"id": "1"}],
            "total_count": 1,
        }
        result = runner.invoke(app, ["records", "list", "accounts", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_as_raw_list(self, mock_cls):
        mock_cls.return_value.get.return_value = [{"id": "1"}]
        result = runner.invoke(app, ["records", "list", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_error_with_message(self, mock_cls):
        err = MagicMock()
        err.message = "Not found"
        err.hint = "Check name"
        mock_cls.return_value.get.side_effect = err
        runner.invoke(app, ["records", "list", "accounts"])

    @patch(MOCK_CLIENT)
    def test_list_error_generic(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["records", "list", "accounts"])
        assert result.exit_code != 0


class TestGetRecord:
    @patch(MOCK_CLIENT)
    def test_get_success(self, mock_cls):
        mock_cls.return_value.get.return_value = {"id": "1", "name": "Test"}
        result = runner.invoke(app, ["records", "get", "accounts", "acc-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_get_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"id": "1"}
        result = runner.invoke(
            app, ["records", "get", "accounts", "acc-1", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_get_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["records", "get", "accounts", "acc-1"])
        assert result.exit_code != 0


class TestCreateRecord:
    @patch(MOCK_CLIENT)
    def test_create_with_data(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "new-1"}
        result = runner.invoke(
            app,
            ["records", "create", "accounts", "--data", '{"name": "Acme"}'],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_create_with_set(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "new-1"}
        result = runner.invoke(
            app,
            [
                "records",
                "create",
                "accounts",
                "--set",
                "name=Acme",
                "--set",
                "status=active",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_create_with_file(self, mock_cls, tmp_path):
        f = tmp_path / "data.json"
        f.write_text('{"name": "Test"}')
        mock_cls.return_value.post.return_value = {"id": "new-1"}
        result = runner.invoke(app, ["records", "create", "accounts", "--file", str(f)])
        assert result.exit_code == 0

    def test_create_no_data(self):
        result = runner.invoke(app, ["records", "create", "accounts"])
        assert result.exit_code != 0

    def test_create_invalid_json(self):
        result = runner.invoke(
            app, ["records", "create", "accounts", "--data", "{bad}"]
        )
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_create_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app, ["records", "create", "accounts", "--data", '{"name": "X"}']
        )
        assert result.exit_code != 0


class TestUpdateRecord:
    @patch(MOCK_CLIENT)
    def test_update_with_set(self, mock_cls):
        mock_cls.return_value.put.return_value = {"id": "1", "status": "active"}
        result = runner.invoke(
            app, ["records", "update", "accounts", "acc-1", "--set", "status=active"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_update_with_data(self, mock_cls):
        mock_cls.return_value.put.return_value = {"id": "1"}
        result = runner.invoke(
            app,
            [
                "records",
                "update",
                "accounts",
                "acc-1",
                "--data",
                '{"status": "active"}',
            ],
        )
        assert result.exit_code == 0

    def test_update_no_data(self):
        result = runner.invoke(app, ["records", "update", "accounts", "acc-1"])
        assert result.exit_code != 0

    def test_update_invalid_json(self):
        result = runner.invoke(
            app, ["records", "update", "accounts", "acc-1", "--data", "{bad}"]
        )
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_update_error(self, mock_cls):
        mock_cls.return_value.put.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app, ["records", "update", "accounts", "acc-1", "--set", "x=y"]
        )
        assert result.exit_code != 0


class TestDeleteRecord:
    @patch(MOCK_CLIENT)
    def test_delete_force(self, mock_cls):
        result = runner.invoke(
            app, ["records", "delete", "accounts", "acc-1", "--force"]
        )
        assert result.exit_code == 0

    def test_delete_abort(self):
        runner.invoke(app, ["records", "delete", "accounts", "acc-1"], input="n\n")

    @patch(MOCK_CLIENT)
    def test_delete_error(self, mock_cls):
        mock_cls.return_value.delete.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app, ["records", "delete", "accounts", "acc-1", "--force"]
        )
        assert result.exit_code != 0


class TestCountRecords:
    @patch(MOCK_CLIENT)
    def test_count_success(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_count": 42}
        result = runner.invoke(app, ["records", "count", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_count_with_filter(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_count": 5}
        result = runner.invoke(
            app, ["records", "count", "accounts", "--filter", "status=active"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_count_list_result(self, mock_cls):
        mock_cls.return_value.get.return_value = [1, 2, 3]
        result = runner.invoke(app, ["records", "count", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_count_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["records", "count", "accounts"])
        assert result.exit_code != 0


class TestErrorWithMessage:
    """Test hasattr(e, 'message') error branches for all record commands."""

    @patch(MOCK_CLIENT)
    def test_list_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Unauthorized"
        err.hint = "Login"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["records", "list", "accounts"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_get_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Not found"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["records", "get", "accounts", "acc-1"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_create_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Validation error"
        err.hint = "Check fields"
        mock_cls.return_value.post.side_effect = err
        result = runner.invoke(
            app, ["records", "create", "accounts", "--data", '{"name": "X"}']
        )
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_update_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Not found"
        err.hint = None
        mock_cls.return_value.put.side_effect = err
        result = runner.invoke(
            app, ["records", "update", "accounts", "acc-1", "--set", "x=y"]
        )
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_delete_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Forbidden"
        err.hint = None
        mock_cls.return_value.delete.side_effect = err
        result = runner.invoke(
            app, ["records", "delete", "accounts", "acc-1", "--force"]
        )
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_count_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["records", "count", "accounts"])
        assert result.exit_code != 0


class TestDeleteConfirm:
    @patch(MOCK_CLIENT)
    def test_delete_confirm_yes(self, mock_cls):
        mock_cls.return_value.delete.return_value = {}
        result = runner.invoke(
            app, ["records", "delete", "accounts", "acc-1"], input="y\n"
        )
        assert result.exit_code == 0
