"""Tests for files commands."""

from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.commands.files import _get_file_icon

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.files.SyncVirtualDojoClient"


class TestGetFileIcon:
    def test_folder(self):
        assert _get_file_icon({"is_folder": True}) == "\U0001f4c1"

    def test_image(self):
        assert _get_file_icon({"mime_type": "image/png"}) == "\U0001f5bc\ufe0f"

    def test_video(self):
        assert _get_file_icon({"mime_type": "video/mp4"}) == "\U0001f3ac"

    def test_audio(self):
        assert _get_file_icon({"mime_type": "audio/mp3"}) == "\U0001f3b5"

    def test_text(self):
        assert _get_file_icon({"mime_type": "text/plain"}) == "\U0001f4dd"

    def test_pdf(self):
        assert _get_file_icon({"mime_type": "application/pdf"}) == "\U0001f4d5"

    def test_spreadsheet(self):
        assert _get_file_icon({"mime_type": "application/spreadsheet"}) == "\U0001f4ca"

    def test_excel(self):
        assert _get_file_icon({"mime_type": "application/excel"}) == "\U0001f4ca"

    def test_document(self):
        assert _get_file_icon({"mime_type": "application/document"}) == "\U0001f4c4"

    def test_word(self):
        assert _get_file_icon({"mime_type": "application/word"}) == "\U0001f4c4"

    def test_zip(self):
        assert _get_file_icon({"mime_type": "application/zip"}) == "\U0001f4e6"

    def test_archive(self):
        assert _get_file_icon({"mime_type": "application/archive"}) == "\U0001f4e6"

    def test_compressed(self):
        assert _get_file_icon({"mime_type": "application/compressed"}) == "\U0001f4e6"

    def test_unknown(self):
        assert _get_file_icon({"mime_type": "application/octet-stream"}) == "\U0001f4c4"

    def test_no_mime(self):
        assert _get_file_icon({}) == "\U0001f4c4"


class TestListFiles:
    @patch(MOCK_CLIENT)
    def test_list_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "items": [
                {
                    "id": "file-1234567890abcdef",
                    "name": "report.pdf",
                    "mime_type": "application/pdf",
                    "size": 1024,
                    "has_embeddings": True,
                    "updated_at": "2024-01-01",
                    "is_folder": False,
                }
            ],
            "total": 1,
        }
        result = runner.invoke(app, ["files", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_full_ids(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "items": [{"id": "file-1234567890abcdef", "name": "x"}],
            "total": 1,
        }
        result = runner.invoke(app, ["files", "list", "--full-ids"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": [], "total": 0}
        result = runner.invoke(app, ["files", "list", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_json_raw(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": [], "total": 0}
        result = runner.invoke(app, ["files", "list", "--format", "json", "--raw"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": [], "total": 0}
        result = runner.invoke(app, ["files", "list", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": [], "total": 0}
        result = runner.invoke(app, ["files", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_with_filters(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": [], "total": 0}
        result = runner.invoke(
            app,
            [
                "files",
                "list",
                "--folder",
                "f1",
                "--type",
                "image",
                "--classification-status",
                "classified",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_folder_item(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "items": [{"id": "f1", "name": "folder", "is_folder": True}],
            "total": 1,
        }
        result = runner.invoke(app, ["files", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "list"])
        assert result.exit_code != 0


class TestFileInfo:
    @patch(MOCK_CLIENT)
    def test_info_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "id": "file-1",
            "name": "report.pdf",
            "mime_type": "application/pdf",
            "size": 2048,
            "created_at": "2024-01-01",
            "is_public": True,
            "has_embeddings": False,
        }
        result = runner.invoke(app, ["files", "info", "file-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_info_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"id": "file-1"}
        result = runner.invoke(app, ["files", "info", "file-1", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_info_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"id": "file-1"}
        result = runner.invoke(app, ["files", "info", "file-1", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_info_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "info", "file-1"])
        assert result.exit_code != 0


class TestUploadFile:
    @patch(MOCK_CLIENT)
    def test_upload_single(self, mock_cls, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        mock_cls.return_value.upload.return_value = {"id": "file-1"}
        result = runner.invoke(app, ["files", "upload", str(f)])
        assert result.exit_code == 0

    def test_upload_not_found(self):
        result = runner.invoke(app, ["files", "upload", "/nonexistent/file.txt"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_upload_dir_no_recursive(self, mock_cls, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        result = runner.invoke(app, ["files", "upload", str(d)])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_upload_dir_recursive(self, mock_cls, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        (d / "a.txt").write_text("a")
        (d / "b.txt").write_text("b")
        mock_cls.return_value.upload.return_value = {"id": "file-1"}
        result = runner.invoke(app, ["files", "upload", str(d), "--recursive"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_upload_dir_empty(self, mock_cls, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        result = runner.invoke(app, ["files", "upload", str(d), "--recursive"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_upload_dir_partial_failure(self, mock_cls, tmp_path):
        d = tmp_path / "dir"
        d.mkdir()
        (d / "a.txt").write_text("a")
        (d / "b.txt").write_text("b")
        mock_cls.return_value.upload.side_effect = [
            {"id": "file-1"},
            RuntimeError("fail"),
        ]
        result = runner.invoke(app, ["files", "upload", str(d), "--recursive"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_upload_error(self, mock_cls, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        mock_cls.return_value.upload.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "upload", str(f)])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_upload_with_options(self, mock_cls, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        mock_cls.return_value.upload.return_value = {"id": "file-1"}
        result = runner.invoke(
            app, ["files", "upload", str(f), "--folder", "f1", "--no-embeddings"]
        )
        assert result.exit_code == 0


class TestDownloadFile:
    @patch(MOCK_CLIENT)
    def test_download_default(self, mock_cls, tmp_path):
        mock_cls.return_value.get.return_value = {
            "name": "report.pdf",
            "size": 1024,
        }
        mock_cls.return_value.download.return_value = 1024
        result = runner.invoke(
            app,
            ["files", "download", "file-1", "--output", str(tmp_path / "report.pdf")],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_download_to_dir(self, mock_cls, tmp_path):
        mock_cls.return_value.get.return_value = {
            "name": "report.pdf",
            "size": 1024,
        }
        mock_cls.return_value.download.return_value = 1024
        result = runner.invoke(
            app,
            ["files", "download", "file-1", "--output", str(tmp_path) + "/"],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_download_info_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "download", "file-1"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_download_error(self, mock_cls, tmp_path):
        mock_cls.return_value.get.return_value = {"name": "x.txt", "size": 100}
        mock_cls.return_value.download.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app,
            ["files", "download", "file-1", "--output", str(tmp_path / "x.txt")],
        )
        assert result.exit_code != 0


class TestDeleteFile:
    @patch(MOCK_CLIENT)
    def test_delete_force(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "name": "test.pdf",
            "is_folder": False,
        }
        mock_cls.return_value.delete.return_value = {}
        result = runner.invoke(app, ["files", "delete", "file-1", "--force"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_delete_folder(self, mock_cls):
        mock_cls.return_value.get.return_value = {"name": "folder", "is_folder": True}
        mock_cls.return_value.delete.return_value = {}
        result = runner.invoke(app, ["files", "delete", "f1", "--force"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_delete_abort(self, mock_cls):
        mock_cls.return_value.get.return_value = {"name": "test.pdf"}
        runner.invoke(app, ["files", "delete", "file-1"], input="n\n")

    @patch(MOCK_CLIENT)
    def test_delete_info_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "delete", "file-1", "--force"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_delete_error(self, mock_cls):
        mock_cls.return_value.get.return_value = {"name": "test.pdf"}
        mock_cls.return_value.delete.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "delete", "file-1", "--force"])
        assert result.exit_code != 0


class TestMkdir:
    @patch(MOCK_CLIENT)
    def test_mkdir(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "folder-1"}
        result = runner.invoke(app, ["files", "mkdir", "New Folder"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_mkdir_with_parent(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "folder-1"}
        result = runner.invoke(app, ["files", "mkdir", "Sub", "--parent", "parent-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_mkdir_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "mkdir", "New"])
        assert result.exit_code != 0


class TestMoveFile:
    @patch(MOCK_CLIENT)
    def test_move(self, mock_cls):
        mock_cls.return_value.put.return_value = {}
        result = runner.invoke(app, ["files", "move", "file-1", "--to", "folder-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_move_error(self, mock_cls):
        mock_cls.return_value.put.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "move", "file-1", "--to", "folder-1"])
        assert result.exit_code != 0


class TestRenameFile:
    @patch(MOCK_CLIENT)
    def test_rename(self, mock_cls):
        mock_cls.return_value.put.return_value = {}
        result = runner.invoke(
            app, ["files", "rename", "file-1", "--name", "new-name.pdf"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_rename_error(self, mock_cls):
        mock_cls.return_value.put.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "rename", "file-1", "--name", "new.pdf"])
        assert result.exit_code != 0


class TestCopyFile:
    @patch(MOCK_CLIENT)
    def test_copy_to_folder(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "copy-1"}
        result = runner.invoke(app, ["files", "copy", "file-1", "--to", "folder-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_copy_with_name(self, mock_cls):
        mock_cls.return_value.post.return_value = {"id": "copy-1"}
        result = runner.invoke(app, ["files", "copy", "file-1", "--name", "copy.pdf"])
        assert result.exit_code == 0

    def test_copy_no_options(self):
        result = runner.invoke(app, ["files", "copy", "file-1"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_copy_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "copy", "file-1", "--to", "folder-1"])
        assert result.exit_code != 0


class TestShareFiles:
    def test_share_stub(self):
        result = runner.invoke(app, ["files", "share", "file-1", "--public"])
        assert result.exit_code == 0

    def test_unshare_stub(self):
        result = runner.invoke(app, ["files", "unshare", "file-1"])
        assert result.exit_code == 0

    def test_shares_stub(self):
        result = runner.invoke(app, ["files", "shares", "file-1"])
        assert result.exit_code == 0


class TestLinkFile:
    @patch(MOCK_CLIENT)
    def test_link(self, mock_cls):
        mock_cls.return_value.post.return_value = {}
        result = runner.invoke(
            app,
            ["files", "link", "file-1", "--object", "accounts", "--record", "acc-1"],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_link_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app,
            ["files", "link", "file-1", "--object", "accounts", "--record", "acc-1"],
        )
        assert result.exit_code != 0


class TestUnlinkFile:
    @patch(MOCK_CLIENT)
    def test_unlink(self, mock_cls):
        mock_cls.return_value.delete.return_value = {}
        result = runner.invoke(app, ["files", "unlink", "file-1", "--link", "link-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_unlink_error(self, mock_cls):
        mock_cls.return_value.delete.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "unlink", "file-1", "--link", "link-1"])
        assert result.exit_code != 0


class TestListLinks:
    @patch(MOCK_CLIENT)
    def test_links_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "links": [
                {
                    "id": "link-1",
                    "object_api_name": "accounts",
                    "record_id": "acc-1",
                    "created_at": "2024-01-01",
                }
            ]
        }
        result = runner.invoke(app, ["files", "links", "file-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_links_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"links": []}
        result = runner.invoke(app, ["files", "links", "file-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_links_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"links": []}
        result = runner.invoke(app, ["files", "links", "file-1", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_links_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"links": []}
        result = runner.invoke(app, ["files", "links", "file-1", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_links_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "links", "file-1"])
        assert result.exit_code != 0


class TestSearchFiles:
    @patch(MOCK_CLIENT)
    def test_search_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "items": [
                {
                    "id": "file-1234567890abcdef",
                    "name": "report.pdf",
                    "mime_type": "application/pdf",
                    "size": 1024,
                }
            ]
        }
        result = runner.invoke(app, ["files", "search", "report"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_full_ids(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "items": [{"id": "file-1234567890abcdef", "name": "x"}]
        }
        result = runner.invoke(app, ["files", "search", "x", "--full-ids"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": []}
        result = runner.invoke(app, ["files", "search", "test", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_json_raw(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": []}
        result = runner.invoke(
            app, ["files", "search", "test", "--format", "json", "--raw"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": []}
        result = runner.invoke(app, ["files", "search", "test", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": []}
        result = runner.invoke(app, ["files", "search", "nothing"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_with_filters(self, mock_cls):
        mock_cls.return_value.get.return_value = {"items": []}
        result = runner.invoke(
            app,
            [
                "files",
                "search",
                "report",
                "--type",
                "document",
                "--created-after",
                "2024-01-01",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "search", "test"])
        assert result.exit_code != 0


class TestStorageInfo:
    @patch(MOCK_CLIENT)
    def test_storage_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "used_bytes": 1024 * 1024,
            "total_bytes": 1024 * 1024 * 100,
            "file_count": 50,
            "folder_count": 5,
        }
        result = runner.invoke(app, ["files", "storage"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_storage_high_usage(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "used_bytes": 95 * 1024 * 1024,
            "total_bytes": 100 * 1024 * 1024,
            "file_count": 500,
            "folder_count": 50,
        }
        result = runner.invoke(app, ["files", "storage"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_storage_zero_total(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "used_bytes": 0,
            "total_bytes": 0,
            "file_count": 0,
            "folder_count": 0,
        }
        result = runner.invoke(app, ["files", "storage"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_storage_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(app, ["files", "storage", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_storage_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(app, ["files", "storage", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_storage_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "storage"])
        assert result.exit_code != 0


class TestComplianceStats:
    @patch(MOCK_CLIENT)
    def test_stats_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "statistics": {
                "classification_enabled": True,
                "batch_interval_minutes": 30,
                "by_classification_level": {
                    "unclassified": 100,
                    "cui_basic": 5,
                    "itar": 1,
                },
                "by_status": {
                    "classified": 90,
                    "pending_classification": 10,
                    "failed": 1,
                },
                "by_document_type": {f"type{i}": i for i in range(15)},
                "files_with_cui_markings": 3,
            }
        }
        result = runner.invoke(app, ["files", "compliance", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_disabled(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "statistics": {"classification_enabled": False}
        }
        result = runner.invoke(app, ["files", "compliance", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(
            app, ["files", "compliance", "stats", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(
            app, ["files", "compliance", "stats", "--format", "yaml"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "compliance", "stats"])
        assert result.exit_code != 0


class TestComplianceAudit:
    @patch(MOCK_CLIENT)
    def test_audit_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "entries": [
                {
                    "created_at": "2024-01-01T00:00:00",
                    "action": "classified",
                    "document_id": "doc-1234567890abcdef",
                    "classification_level": "cui_basic",
                    "user_id": "user-1234567890abcdef",
                }
            ]
        }
        result = runner.invoke(app, ["files", "compliance", "audit"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_audit_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"entries": []}
        result = runner.invoke(app, ["files", "compliance", "audit"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_audit_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"entries": []}
        result = runner.invoke(
            app, ["files", "compliance", "audit", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_audit_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"entries": []}
        result = runner.invoke(
            app, ["files", "compliance", "audit", "--format", "yaml"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_audit_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "compliance", "audit"])
        assert result.exit_code != 0


class TestCompliancePending:
    @patch(MOCK_CLIENT)
    def test_pending(self, mock_cls):
        mock_cls.return_value.get.return_value = {"count": 5}
        result = runner.invoke(app, ["files", "compliance", "pending"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_pending_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "compliance", "pending"])
        assert result.exit_code != 0


class TestComplianceClassify:
    @patch(MOCK_CLIENT)
    def test_classify(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "classification_level": "cui_basic",
            "document_type": "contract",
            "has_cui_markings": True,
        }
        result = runner.invoke(app, ["files", "compliance", "classify", "file-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_classify_minimal(self, mock_cls):
        mock_cls.return_value.post.return_value = {}
        result = runner.invoke(app, ["files", "compliance", "classify", "file-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_classify_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["files", "compliance", "classify", "file-1"])
        assert result.exit_code != 0


class TestComplianceReclassify:
    @patch(MOCK_CLIENT)
    def test_reclassify_force(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "classification_level": "unclassified"
        }
        result = runner.invoke(
            app, ["files", "compliance", "reclassify", "file-1", "--force"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_reclassify_abort(self, mock_cls):
        runner.invoke(app, ["files", "compliance", "reclassify", "file-1"], input="n\n")

    @patch(MOCK_CLIENT)
    def test_reclassify_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(
            app, ["files", "compliance", "reclassify", "file-1", "--force"]
        )
        assert result.exit_code != 0
