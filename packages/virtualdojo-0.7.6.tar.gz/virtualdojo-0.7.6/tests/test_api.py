"""Tests for the api command group."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.commands.api import _parse_json_data, _validate_path

runner = CliRunner()


# ---------------------------------------------------------------------------
# Help output tests
# ---------------------------------------------------------------------------


def test_api_help():
    """Test api subcommand help."""
    result = runner.invoke(app, ["api", "--help"])
    assert result.exit_code == 0
    assert "get" in result.stdout
    assert "post" in result.stdout
    assert "put" in result.stdout
    assert "patch" in result.stdout
    assert "delete" in result.stdout


def test_api_get_help():
    """Test api get help shows path argument."""
    result = runner.invoke(app, ["api", "get", "--help"])
    assert result.exit_code == 0
    assert "PATH" in result.stdout


# ---------------------------------------------------------------------------
# _validate_path unit tests
# ---------------------------------------------------------------------------


def test_validate_path_normal():
    """Relative path with leading slash passes through."""
    assert _validate_path("/api/v1/health") == "/api/v1/health"


def test_validate_path_adds_leading_slash():
    """Path without leading slash gets one added."""
    assert _validate_path("api/v1/health") == "/api/v1/health"


def test_validate_path_with_query_string():
    """Query strings are preserved."""
    p = "/ai/token-usage/by-user?start_date=2026-02-01&end_date=2026-02-27"
    assert _validate_path(p) == p


def test_validate_path_rejects_absolute_http():
    """Absolute http URL is rejected."""
    import click
    import pytest

    with pytest.raises(click.exceptions.Exit):
        _validate_path("http://evil.com/steal")


def test_validate_path_rejects_absolute_https():
    """Absolute https URL is rejected."""
    import click
    import pytest

    with pytest.raises(click.exceptions.Exit):
        _validate_path("https://evil.com/steal")


# ---------------------------------------------------------------------------
# _parse_json_data unit tests
# ---------------------------------------------------------------------------


def test_parse_json_data_none():
    """None input returns None."""
    assert _parse_json_data(None) is None


def test_parse_json_data_valid():
    """Valid JSON object is parsed."""
    assert _parse_json_data('{"key": "value"}') == {"key": "value"}


def test_parse_json_data_invalid():
    """Invalid JSON raises Exit."""
    import click
    import pytest

    with pytest.raises(click.exceptions.Exit):
        _parse_json_data("not json")


def test_parse_json_data_non_object():
    """JSON array raises Exit."""
    import click
    import pytest

    with pytest.raises(click.exceptions.Exit):
        _parse_json_data("[1, 2, 3]")


# ---------------------------------------------------------------------------
# Command integration tests (mocked client)
# ---------------------------------------------------------------------------

MOCK_RESPONSE = {"status": "ok", "data": [1, 2, 3]}


def _mock_client(**method_returns):
    """Create a mock SyncVirtualDojoClient with given method return values."""
    mock = MagicMock()
    for method, retval in method_returns.items():
        getattr(mock, method).return_value = retval
    return mock


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_success(mock_cls):
    """GET request succeeds and prints JSON."""
    mock_cls.return_value = _mock_client(get=MOCK_RESPONSE)
    result = runner.invoke(app, ["api", "get", "/api/v1/health"])
    assert result.exit_code == 0
    assert '"status": "ok"' in result.stdout
    mock_cls.return_value.get.assert_called_once_with("/api/v1/health")


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_with_query_string(mock_cls):
    """GET request preserves query string in path."""
    mock_cls.return_value = _mock_client(get=MOCK_RESPONSE)
    path = "/ai/token-usage/by-user?start_date=2026-02-01&end_date=2026-02-27"
    result = runner.invoke(app, ["api", "get", path])
    assert result.exit_code == 0
    mock_cls.return_value.get.assert_called_once_with(path)


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_success(mock_cls):
    """POST request sends JSON body."""
    mock_cls.return_value = _mock_client(post=MOCK_RESPONSE)
    result = runner.invoke(
        app, ["api", "post", "/api/v1/endpoint", "-d", '{"name": "test"}']
    )
    assert result.exit_code == 0
    assert '"status": "ok"' in result.stdout
    mock_cls.return_value.post.assert_called_once_with(
        "/api/v1/endpoint", {"name": "test"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_no_body(mock_cls):
    """POST request without --data sends None body."""
    mock_cls.return_value = _mock_client(post=MOCK_RESPONSE)
    result = runner.invoke(app, ["api", "post", "/api/v1/endpoint"])
    assert result.exit_code == 0
    mock_cls.return_value.post.assert_called_once_with("/api/v1/endpoint")


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_put_success(mock_cls):
    """PUT request sends JSON body."""
    mock_cls.return_value = _mock_client(put=MOCK_RESPONSE)
    result = runner.invoke(
        app, ["api", "put", "/api/v1/endpoint/123", "-d", '{"name": "updated"}']
    )
    assert result.exit_code == 0
    mock_cls.return_value.put.assert_called_once_with(
        "/api/v1/endpoint/123", {"name": "updated"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_patch_success(mock_cls):
    """PATCH request sends JSON body."""
    mock_cls.return_value = _mock_client(patch=MOCK_RESPONSE)
    result = runner.invoke(
        app, ["api", "patch", "/api/v1/endpoint/123", "-d", '{"status": "active"}']
    )
    assert result.exit_code == 0
    mock_cls.return_value.patch.assert_called_once_with(
        "/api/v1/endpoint/123", {"status": "active"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_delete_success(mock_cls):
    """DELETE request succeeds."""
    mock_cls.return_value = _mock_client(delete=MOCK_RESPONSE)
    result = runner.invoke(app, ["api", "delete", "/api/v1/endpoint/123"])
    assert result.exit_code == 0
    mock_cls.return_value.delete.assert_called_once_with("/api/v1/endpoint/123")


# ---------------------------------------------------------------------------
# SSRF protection via CLI invocation
# ---------------------------------------------------------------------------


def test_api_get_rejects_absolute_url():
    """GET with absolute URL is rejected before any client call."""
    result = runner.invoke(app, ["api", "get", "https://evil.com/steal"])
    assert result.exit_code == 1
    assert "Absolute URLs are not allowed" in result.stdout


def test_api_post_rejects_absolute_url():
    """POST with absolute URL is rejected."""
    result = runner.invoke(app, ["api", "post", "http://evil.com/steal"])
    assert result.exit_code == 1
    assert "Absolute URLs are not allowed" in result.stdout


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_error_with_message(mock_cls):
    """Error with .message attribute is displayed."""
    exc = Exception("something broke")
    exc.message = "API returned 500"
    exc.hint = "Try again later"
    mock_cls.return_value.get.side_effect = exc
    result = runner.invoke(app, ["api", "get", "/api/v1/health"])
    assert result.exit_code == 1
    assert "API returned 500" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_error_without_message(mock_cls):
    """Generic exception falls back to str()."""
    mock_cls.return_value.get.side_effect = RuntimeError("connection refused")
    result = runner.invoke(app, ["api", "get", "/api/v1/health"])
    assert result.exit_code == 1
    assert "connection refused" in result.stdout


def test_api_post_invalid_json():
    """POST with invalid JSON in --data fails."""
    result = runner.invoke(app, ["api", "post", "/api/v1/endpoint", "-d", "not-json"])
    assert result.exit_code == 1
    assert "Invalid JSON" in result.stdout


def test_api_post_json_array():
    """POST with JSON array in --data fails."""
    result = runner.invoke(app, ["api", "post", "/api/v1/endpoint", "-d", "[1,2,3]"])
    assert result.exit_code == 1
    assert "must be an object" in result.stdout


# ---------------------------------------------------------------------------
# Profile passthrough
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_with_profile(mock_cls):
    """--profile flag is forwarded to the client."""
    mock_cls.return_value = _mock_client(get=MOCK_RESPONSE)
    result = runner.invoke(app, ["api", "get", "/health", "-p", "staging"])
    assert result.exit_code == 0
    mock_cls.assert_called_once_with("staging")


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_error_with_message(mock_cls):
    """POST error with .message attribute is displayed."""
    exc = Exception("post broke")
    exc.message = "POST failed"
    exc.hint = "Check payload"
    mock_cls.return_value.post.side_effect = exc
    result = runner.invoke(app, ["api", "post", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "POST failed" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_error_without_message(mock_cls):
    """POST generic error falls back to str()."""
    mock_cls.return_value.post.side_effect = RuntimeError("post failed")
    result = runner.invoke(app, ["api", "post", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "post failed" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_put_error(mock_cls):
    """PUT error path with .message is exercised."""
    exc = Exception("put broke")
    exc.message = "PUT failed"
    exc.hint = None
    mock_cls.return_value.put.side_effect = exc
    result = runner.invoke(app, ["api", "put", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "PUT failed" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_put_error_generic(mock_cls):
    """PUT generic error falls back to str()."""
    mock_cls.return_value.put.side_effect = RuntimeError("put failed")
    result = runner.invoke(app, ["api", "put", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "put failed" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_patch_error(mock_cls):
    """PATCH error path with .message is exercised."""
    exc = Exception("patch broke")
    exc.message = "Server error"
    exc.hint = None
    mock_cls.return_value.patch.side_effect = exc
    result = runner.invoke(app, ["api", "patch", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "Server error" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_patch_error_generic(mock_cls):
    """PATCH generic error falls back to str()."""
    mock_cls.return_value.patch.side_effect = RuntimeError("patch failed")
    result = runner.invoke(app, ["api", "patch", "/api/v1/x", "-d", '{"a": 1}'])
    assert result.exit_code == 1
    assert "patch failed" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_delete_error(mock_cls):
    """DELETE error with .message is exercised."""
    exc = Exception("del broke")
    exc.message = "Not found"
    exc.hint = None
    mock_cls.return_value.delete.side_effect = exc
    result = runner.invoke(app, ["api", "delete", "/api/v1/x"])
    assert result.exit_code == 1
    assert "Not found" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_delete_error_generic(mock_cls):
    """DELETE generic error falls back to str()."""
    mock_cls.return_value.delete.side_effect = RuntimeError("delete failed")
    result = runner.invoke(app, ["api", "delete", "/api/v1/x"])
    assert result.exit_code == 1
    assert "delete failed" in result.stdout


# ---------------------------------------------------------------------------
# --raw flag tests
# ---------------------------------------------------------------------------

MOCK_RAW_RESPONSE = (200, {"content-type": "application/json"}, '{"status": "ok"}')
MOCK_RAW_HTML = (200, {"content-type": "text/html"}, "<html><body>Hello</body></html>")


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_raw_json(mock_cls):
    """GET --raw prints status and raw body for JSON responses."""
    mock_cls.return_value.raw_request.return_value = MOCK_RAW_RESPONSE
    result = runner.invoke(app, ["api", "get", "--raw", "/api/v1/health"])
    assert result.exit_code == 0
    assert '{"status": "ok"}' in result.stdout
    mock_cls.return_value.raw_request.assert_called_once_with(
        "GET", "/api/v1/health", data=None
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_raw_html(mock_cls):
    """GET --raw prints HTML body without JSON parsing errors."""
    mock_cls.return_value.raw_request.return_value = MOCK_RAW_HTML
    result = runner.invoke(app, ["api", "get", "--raw", "/admin/"])
    assert result.exit_code == 0
    assert "<html>" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_raw_short_flag(mock_cls):
    """-r is a short alias for --raw."""
    mock_cls.return_value.raw_request.return_value = MOCK_RAW_RESPONSE
    result = runner.invoke(app, ["api", "get", "-r", "/api/v1/health"])
    assert result.exit_code == 0
    assert '{"status": "ok"}' in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_raw(mock_cls):
    """POST --raw sends body and returns raw response."""
    mock_cls.return_value.raw_request.return_value = (
        201,
        {"content-type": "application/json"},
        '{"id": 1}',
    )
    result = runner.invoke(
        app,
        ["api", "post", "--raw", "/api/v1/endpoint", "-d", '{"name": "test"}'],
    )
    assert result.exit_code == 0
    assert '{"id": 1}' in result.stdout
    mock_cls.return_value.raw_request.assert_called_once_with(
        "POST", "/api/v1/endpoint", data={"name": "test"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_delete_raw(mock_cls):
    """DELETE --raw returns raw response."""
    mock_cls.return_value.raw_request.return_value = (
        204,
        {"content-type": "text/plain"},
        "",
    )
    result = runner.invoke(app, ["api", "delete", "--raw", "/api/v1/x/123"])
    assert result.exit_code == 0
    mock_cls.return_value.raw_request.assert_called_once_with(
        "DELETE", "/api/v1/x/123", data=None
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_delete_with_body(mock_cls):
    """DELETE with --data sends JSON body."""
    mock_cls.return_value = _mock_client(delete=MOCK_RESPONSE)
    result = runner.invoke(
        app, ["api", "delete", "/api/v1/bulk", "-d", '{"ids": [1, 2]}']
    )
    assert result.exit_code == 0
    mock_cls.return_value.delete.assert_called_once_with(
        "/api/v1/bulk", {"ids": [1, 2]}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_put_raw(mock_cls):
    """PUT --raw sends body and returns raw response."""
    mock_cls.return_value.raw_request.return_value = (
        200,
        {"content-type": "application/json"},
        '{"updated": true}',
    )
    result = runner.invoke(
        app,
        ["api", "put", "--raw", "/api/v1/endpoint/1", "-d", '{"name": "new"}'],
    )
    assert result.exit_code == 0
    assert '{"updated": true}' in result.stdout
    mock_cls.return_value.raw_request.assert_called_once_with(
        "PUT", "/api/v1/endpoint/1", data={"name": "new"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_patch_raw(mock_cls):
    """PATCH --raw sends body and returns raw response."""
    mock_cls.return_value.raw_request.return_value = (
        200,
        {"content-type": "application/json"},
        '{"patched": true}',
    )
    result = runner.invoke(
        app,
        ["api", "patch", "--raw", "/api/v1/endpoint/1", "-d", '{"status": "done"}'],
    )
    assert result.exit_code == 0
    assert '{"patched": true}' in result.stdout
    mock_cls.return_value.raw_request.assert_called_once_with(
        "PATCH", "/api/v1/endpoint/1", data={"status": "done"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_raw_error_handling(mock_cls):
    """--raw still handles connection errors properly."""
    mock_cls.return_value.raw_request.side_effect = RuntimeError("connection refused")
    result = runner.invoke(app, ["api", "get", "--raw", "/api/v1/health"])
    assert result.exit_code == 1
    assert "connection refused" in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_raw_error_with_message(mock_cls):
    """--raw error with .message attribute is displayed."""
    exc = Exception("raw broke")
    exc.message = "Server error"
    exc.hint = "Check server"
    mock_cls.return_value.raw_request.side_effect = exc
    result = runner.invoke(app, ["api", "get", "--raw", "/api/v1/health"])
    assert result.exit_code == 1
    assert "Server error" in result.stdout


# ---------------------------------------------------------------------------
# --verbose flag tests
# ---------------------------------------------------------------------------

MOCK_VERBOSE_RESPONSE = {
    "request_method": "GET",
    "request_url": "https://app.virtualdojo.com/api/v1/health",
    "request_headers": {
        "authorization": "Bearer tok1234...",
        "x-tenant-id": "test-tenant",
        "content-type": "application/json",
        "x-request-id": "abc123",
    },
    "request_body": None,
    "status_code": 200,
    "response_headers": {
        "content-type": "application/json",
        "x-request-id": "abc123",
    },
    "response_body": '{"status": "healthy"}',
    "elapsed_ms": 42.5,
}


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_verbose(mock_cls):
    """GET --verbose prints request/response details."""
    mock_cls.return_value.verbose_request.return_value = MOCK_VERBOSE_RESPONSE
    result = runner.invoke(app, ["api", "get", "--verbose", "/api/v1/health"])
    assert result.exit_code == 0
    assert '{"status": "healthy"}' in result.stdout
    mock_cls.return_value.verbose_request.assert_called_once_with(
        "GET", "/api/v1/health", data=None
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_verbose_short_flag(mock_cls):
    """-v is a short alias for --verbose."""
    mock_cls.return_value.verbose_request.return_value = MOCK_VERBOSE_RESPONSE
    result = runner.invoke(app, ["api", "get", "-v", "/api/v1/health"])
    assert result.exit_code == 0
    assert '{"status": "healthy"}' in result.stdout


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_post_verbose(mock_cls):
    """POST --verbose sends body and shows verbose output."""
    verbose_resp = {
        **MOCK_VERBOSE_RESPONSE,
        "request_method": "POST",
        "request_body": {"name": "test"},
        "status_code": 201,
    }
    mock_cls.return_value.verbose_request.return_value = verbose_resp
    result = runner.invoke(
        app,
        ["api", "post", "-v", "/api/v1/endpoint", "-d", '{"name": "test"}'],
    )
    assert result.exit_code == 0
    mock_cls.return_value.verbose_request.assert_called_once_with(
        "POST", "/api/v1/endpoint", data={"name": "test"}
    )


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_verbose_error_handling(mock_cls):
    """--verbose still handles connection errors properly."""
    mock_cls.return_value.verbose_request.side_effect = RuntimeError("refused")
    result = runner.invoke(app, ["api", "get", "-v", "/api/v1/health"])
    assert result.exit_code == 1
    assert "refused" in result.stdout


# ---------------------------------------------------------------------------
# Timing output tests
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.api.SyncVirtualDojoClient")
def test_api_get_shows_timing(mock_cls):
    """Normal GET prints elapsed time to stderr."""
    mock_cls.return_value.get.return_value = MOCK_RESPONSE
    result = runner.invoke(app, ["api", "get", "/api/v1/health"])
    assert result.exit_code == 0
    assert '"status": "ok"' in result.stdout
