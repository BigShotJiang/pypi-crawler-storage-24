"""Tests for AI chat commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from virtualdojo.cli import app

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.ai.SyncVirtualDojoClient"


class TestChat:
    @patch(MOCK_CLIENT)
    def test_single_message(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "response": "Hello!",
            "conversation_id": "conv-1",
            "metadata": {},
        }
        result = runner.invoke(app, ["ai", "chat", "Hello"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_single_message_with_conversation(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "response": "Hello!",
            "conversation_id": "conv-1",
            "metadata": {},
        }
        result = runner.invoke(app, ["ai", "chat", "Hello", "--conversation", "conv-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_single_message_with_citations(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "response": "Answer",
            "conversation_id": "conv-1",
            "metadata": {
                "citations": [
                    {"file_title": "doc.pdf", "relevance": 0.95},
                ]
            },
        }
        result = runner.invoke(app, ["ai", "chat", "Question"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_chat_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["ai", "chat", "Hello"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_chat_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Unauthorized"
        err.hint = "Login"
        mock_cls.return_value.post.side_effect = err
        result = runner.invoke(app, ["ai", "chat", "Hello"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_interactive_eof(self, mock_cls):
        """Interactive mode exits on empty input (EOF)."""
        result = runner.invoke(app, ["ai", "chat"], input="")
        assert result.exit_code == 0


class TestConversations:
    @patch(MOCK_CLIENT)
    def test_list_conversations(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {
                "id": "conv-1234567890",
                "title": "Test convo",
                "message_count": 5,
                "last_activity_at": "2024-01-01T00:00:00",
            }
        ]
        result = runner.invoke(app, ["ai", "conversations"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_conversations_dict(self, mock_cls):
        mock_cls.return_value.get.return_value = {"data": []}
        result = runner.invoke(app, ["ai", "conversations"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_conversations_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["ai", "conversations"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_conversations_with_limit(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["ai", "conversations", "--limit", "10"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_conversations_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["ai", "conversations"])
        assert result.exit_code != 0


class TestHistory:
    @patch(MOCK_CLIENT)
    def test_history_success(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"sender_type": "user", "message_text": "Hi", "sent_at": "2024-01-01"},
            {"sender_type": "ai", "message_text": "Hello", "sent_at": "2024-01-01"},
        ]
        result = runner.invoke(app, ["ai", "history", "conv-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_dict_response(self, mock_cls):
        mock_cls.return_value.get.return_value = {"data": []}
        result = runner.invoke(app, ["ai", "history", "conv-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["ai", "history", "conv-1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_with_limit(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["ai", "history", "conv-1", "--limit", "10"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["ai", "history", "conv-1"])
        assert result.exit_code != 0


class TestInteractiveChat:
    @patch(MOCK_CLIENT)
    def test_interactive_empty_input_skipped(self, mock_cls):
        """Empty input lines are skipped."""
        mock_cls.return_value.post.return_value = {
            "response": "Hi",
            "conversation_id": "c1",
            "metadata": {},
        }
        # Send empty line then a real message then EOF
        result = runner.invoke(app, ["ai", "chat"], input="\nhello\n")
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_interactive_keyboard_interrupt_once(self, mock_cls):
        """Single Ctrl+C shows 'press again' message."""
        # We can simulate this by patching input to raise KeyboardInterrupt
        with patch("builtins.input") as mock_input:
            mock_input.side_effect = [KeyboardInterrupt, KeyboardInterrupt]
            result = runner.invoke(app, ["ai", "chat"])
            assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_interactive_auth_error(self, mock_cls):
        """Auth errors exit the chat."""
        from virtualdojo.exceptions import AuthenticationError

        mock_cls.return_value.post.side_effect = AuthenticationError(
            message="Expired", hint="Login again"
        )
        result = runner.invoke(app, ["ai", "chat"], input="hello\n")
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_interactive_generic_error_with_message(self, mock_cls):
        """Generic error with message attribute doesn't exit chat."""
        err = RuntimeError()
        err.message = "Server error"
        err.hint = "Try later"

        call_count = 0

        def _post_side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise err
            return {"response": "ok", "conversation_id": "c1", "metadata": {}}

        mock_cls.return_value.post.side_effect = _post_side_effect
        # First message triggers error, then EOF
        result = runner.invoke(app, ["ai", "chat"], input="hello\n")
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_interactive_generic_error_no_message(self, mock_cls):
        """Generic error without message attribute."""
        call_count = 0

        def _post_side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("something broke")
            return {"response": "ok", "conversation_id": "c1", "metadata": {}}

        mock_cls.return_value.post.side_effect = _post_side_effect
        result = runner.invoke(app, ["ai", "chat"], input="hello\n")
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_conversations_error_with_message(self, mock_cls):
        """Conversations error with .message attribute."""
        err = RuntimeError()
        err.message = "Unauthorized"
        err.hint = "Login"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["ai", "conversations"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_history_error_with_message(self, mock_cls):
        """History error with .message attribute."""
        err = RuntimeError()
        err.message = "Not found"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["ai", "history", "conv-1"])
        assert result.exit_code != 0


class TestSendMessage:
    def test_send_message_no_conversation_id(self):
        """Test _send_message without spinner."""
        from virtualdojo.commands.ai import _send_message

        mock_client = MagicMock()
        mock_client.post.return_value = {
            "response": "Hi",
            "conversation_id": None,
            "metadata": {},
        }
        result = _send_message(mock_client, "hello", show_conversation_id=False)
        assert result is None

    def test_send_message_with_spinner(self):
        from virtualdojo.commands.ai import _send_message

        mock_client = MagicMock()
        mock_client.post.return_value = {
            "response": "Hi",
            "conversation_id": "c1",
            "metadata": {},
        }
        result = _send_message(mock_client, "hello", show_spinner=True)
        assert result == "c1"
