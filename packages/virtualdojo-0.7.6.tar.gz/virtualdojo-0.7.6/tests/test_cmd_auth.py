"""Tests for auth commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.commands.auth import (
    _warn_insecure_connection,
    resolve_server_url,
)

runner = CliRunner()


class TestResolveServerUrl:
    def test_none_returns_default(self):
        result = resolve_server_url(None)
        assert "virtualdojo.com" in result

    def test_local_shortcut(self):
        result = resolve_server_url("local", warn_http=False)
        assert result == "http://localhost"

    def test_dev_shortcut(self):
        result = resolve_server_url("dev", warn_http=False)
        assert "dev" in result

    def test_production_shortcut(self):
        result = resolve_server_url("production", warn_http=False)
        assert "app.virtualdojo.com" in result

    def test_localhost_prefix(self):
        result = resolve_server_url("localhost:9000", warn_http=False)
        assert result == "http://localhost:9000"

    def test_127_prefix(self):
        result = resolve_server_url("127.0.0.1:8000", warn_http=False)
        assert result == "http://127.0.0.1:8000"

    def test_bare_domain_gets_https(self):
        result = resolve_server_url("example.com")
        assert result == "https://example.com"

    def test_explicit_http_warns(self):
        with patch("virtualdojo.commands.auth._warn_insecure_connection") as mock_warn:
            resolve_server_url("http://example.com", warn_http=True)
            mock_warn.assert_called_once()

    def test_explicit_http_localhost_no_warn(self):
        with patch("virtualdojo.commands.auth._warn_insecure_connection") as mock_warn:
            resolve_server_url("http://localhost:8000", warn_http=True)
            mock_warn.assert_not_called()

    def test_explicit_https_passthrough(self):
        result = resolve_server_url("https://custom.example.com")
        assert result == "https://custom.example.com"

    def test_local_shortcut_warns(self):
        with patch("virtualdojo.commands.auth._warn_insecure_connection") as mock_warn:
            resolve_server_url("local", warn_http=True)
            mock_warn.assert_called_once()

    def test_localhost_warns(self):
        with patch("virtualdojo.commands.auth._warn_insecure_connection") as mock_warn:
            resolve_server_url("localhost:8000", warn_http=True)
            mock_warn.assert_called_once()


class TestWarnInsecureConnection:
    def test_prints_warning(self):
        # Should not raise
        _warn_insecure_connection("http://example.com")


class TestLoginCommand:
    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_with_password_success(self, mock_cm, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        # May succeed or fail depending on prompt handling

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_login_with_password_401(self, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_login_with_password_500(self, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Server error"}
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_login_connect_error(self, mock_client_class):
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = httpx.ConnectError("refused")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_login_timeout(self, mock_client_class):
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = httpx.TimeoutException("timeout")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        assert result.exit_code != 0

    def test_login_local_shortcut(self):
        with patch("virtualdojo.commands.auth.httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_class.return_value = mock_client

            runner.invoke(
                app,
                ["login", "--local", "--email", "a@b.com"],
                input="password123\n",
            )

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_with_api_key(self, mock_cm, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--api-key",
                "sk-123",
            ],
        )

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_login_api_key_401(self, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--api-key",
                "sk-bad",
            ],
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_multi_tenant_single(self, mock_cm, mock_client_class):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
            "multiple_tenants": False,
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
            input="password123\n",
        )


class TestLoginEnvVarsAndFlows:
    """Tests for env var handling, tenant detection, and API key login flows."""

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_uses_env_server(self, mock_cm, mock_client_class):
        """Line 164: default server message when no server arg."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
            "multiple_tenants": False,
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            ["auth", "login", "--email", "a@b.com"],
            input="password123\n",
        )
        assert "default server" in result.output.lower() or result.exit_code == 0

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_prompts_email_and_password(
        self, mock_cm, mock_client_class, mock_prompt
    ):
        """Lines 177-178: prompts for email and password when not provided."""
        mock_prompt.ask.side_effect = ["user@test.com", "secret"]
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
            "multiple_tenants": False,
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com"],
        )
        assert mock_prompt.ask.call_count >= 2

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_api_key_prompts_tenant(
        self, mock_cm, mock_client_class, mock_prompt
    ):
        """Line 172: prompts for tenant when using api key without --tenant."""
        mock_prompt.ask.return_value = "my-tenant"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--api-key", "sk-123"],
        )
        mock_prompt.ask.assert_called_once_with("Tenant ID or subdomain")

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_api_key_env_var(self, mock_cm, mock_client_class):
        """Line 257: API key from env var."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "tenant": {"tenant_id": "t1", "tenant_name": "Test"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        with patch.dict(
            "os.environ", {"VIRTUALDOJO_API_KEY": "sk-env", "VIRTUALDOJO_TENANT": "t1"}
        ):
            runner.invoke(
                app,
                ["auth", "login", "--server", "https://test.com"],
            )

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_login_password_tenant_same_id_name(self, mock_cm, mock_client_class):
        """Line 257: tenant_id == tenant_name shows only tenant_id."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
            "tenant": {"tenant_id": "same", "tenant_name": "same"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "same",
                "--email",
                "a@b.com",
            ],
            input="password123\n",
        )
        assert result.exit_code == 0


class TestApiKeyLoginFlow:
    """Tests for lines 299-337 and 473-522: API key login edge cases."""

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_api_key_login_non_200(self, mock_client_class):
        """Lines 473-475: API key validation non-200 response."""
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.json.return_value = {"detail": "Forbidden"}
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--api-key",
                "sk-bad",
            ],
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_api_key_login_same_tenant_id_name(self, mock_cm, mock_client_class):
        """Line 515: tenant_id == tenant_name in API key login."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "tenant": {"tenant_id": "sameid", "tenant_name": "sameid"},
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "sameid",
                "--api-key",
                "sk-123",
            ],
        )
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_api_key_login_connect_error(self, mock_client_class):
        """Lines 518-519: ConnectError during API key login."""
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = httpx.ConnectError("refused")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--api-key",
                "sk-123",
            ],
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_api_key_login_timeout(self, mock_client_class):
        """Lines 521-522: TimeoutException during API key login."""
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = httpx.TimeoutException("timeout")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "auth",
                "login",
                "--server",
                "https://test.com",
                "--tenant",
                "t1",
                "--api-key",
                "sk-123",
            ],
        )
        assert result.exit_code != 0


class TestMultiTenantFlow:
    """Tests for lines 299-337, 379-383, 395-445: multi-tenant selection."""

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_multi_tenant_non_200(self, mock_client_class):
        """Lines 299-301: non-200 from multi-tenant endpoint."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"detail": "Internal error"}
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_multi_tenant_selection(self, mock_cm, mock_client_class, mock_prompt):
        """Lines 306-344: user selects from multiple tenants."""
        multi_response = MagicMock()
        multi_response.status_code = 200
        multi_response.json.return_value = {
            "multiple_tenants": True,
            "user_id": "u1",
            "available_tenants": [
                {
                    "tenant_id": "t1",
                    "tenant_name": "Alpha",
                    "subdomain": "alpha",
                    "user_role": "admin",
                },
                {
                    "tenant_id": "t2",
                    "tenant_name": "Beta",
                    "subdomain": "beta",
                    "user_role": "member",
                },
            ],
        }
        select_response = MagicMock()
        select_response.status_code = 200
        select_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = [multi_response, select_response]
        mock_client_class.return_value = mock_client

        mock_prompt.ask.side_effect = ["password123", "1"]

        runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
        )

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_multi_tenant_invalid_then_valid_choice(
        self, mock_cm, mock_client_class, mock_prompt
    ):
        """Lines 330-334: invalid selection then valid selection."""
        multi_response = MagicMock()
        multi_response.status_code = 200
        multi_response.json.return_value = {
            "multiple_tenants": True,
            "user_id": "u1",
            "available_tenants": [
                {
                    "tenant_id": "t1",
                    "tenant_name": "Alpha",
                    "subdomain": "alpha",
                    "user_role": "admin",
                },
            ],
        }
        select_response = MagicMock()
        select_response.status_code = 200
        select_response.json.return_value = {
            "access_token": "tok",
            "expires_in": 1800,
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = [multi_response, select_response]
        mock_client_class.return_value = mock_client

        # First "abc" (ValueError), then "5" (out of range), then "1" (valid)
        mock_prompt.ask.side_effect = ["password123", "abc", "5", "1"]

        runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
        )

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_multi_tenant_connect_error(self, mock_client_class):
        """Lines 379-380: ConnectError in multi-tenant flow."""
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = httpx.ConnectError("refused")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_multi_tenant_timeout(self, mock_client_class):
        """Lines 382-383: TimeoutException in multi-tenant flow."""
        import httpx

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = httpx.TimeoutException("timeout")
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
            input="password123\n",
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_select_tenant_non_200(self, mock_client_class, mock_prompt):
        """Lines 408-411: select-tenant returns non-200."""
        multi_response = MagicMock()
        multi_response.status_code = 200
        multi_response.json.return_value = {
            "multiple_tenants": True,
            "user_id": "u1",
            "available_tenants": [
                {
                    "tenant_id": "t1",
                    "tenant_name": "Alpha",
                    "subdomain": "alpha",
                    "user_role": "admin",
                },
            ],
        }
        select_response = MagicMock()
        select_response.status_code = 400
        select_response.json.return_value = {"detail": "Bad request"}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = [multi_response, select_response]
        mock_client_class.return_value = mock_client

        mock_prompt.ask.side_effect = ["password123", "1"]

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_select_tenant_connect_error(self, mock_client_class, mock_prompt):
        """Lines 440-442: ConnectError during select-tenant."""
        import httpx

        multi_response = MagicMock()
        multi_response.status_code = 200
        multi_response.json.return_value = {
            "multiple_tenants": True,
            "user_id": "u1",
            "available_tenants": [
                {
                    "tenant_id": "t1",
                    "tenant_name": "Alpha",
                    "subdomain": "alpha",
                    "user_role": "admin",
                },
            ],
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = [multi_response, httpx.ConnectError("refused")]
        mock_client_class.return_value = mock_client

        mock_prompt.ask.side_effect = ["password123", "1"]

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
        )
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.Prompt")
    @patch("virtualdojo.commands.auth.httpx.Client")
    def test_select_tenant_timeout(self, mock_client_class, mock_prompt):
        """Lines 443-445: TimeoutException during select-tenant."""
        import httpx

        multi_response = MagicMock()
        multi_response.status_code = 200
        multi_response.json.return_value = {
            "multiple_tenants": True,
            "user_id": "u1",
            "available_tenants": [
                {
                    "tenant_id": "t1",
                    "tenant_name": "Alpha",
                    "subdomain": "alpha",
                    "user_role": "admin",
                },
            ],
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.side_effect = [
            multi_response,
            httpx.TimeoutException("timeout"),
        ]
        mock_client_class.return_value = mock_client

        mock_prompt.ask.side_effect = ["password123", "1"]

        result = runner.invoke(
            app,
            ["auth", "login", "--server", "https://test.com", "--email", "a@b.com"],
        )
        assert result.exit_code != 0


class TestWhoamiErrorPaths:
    """Tests for lines 593, 598, 607: whoami and api-key error paths."""

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_whoami_with_token_type(self, mock_cm, mock_client_class):
        """Line 593: credentials with token_type displayed."""
        from virtualdojo.config import Credentials, Profile

        mock_client = MagicMock()
        mock_client.get.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "full_name": "Test",
        }
        mock_client_class.return_value = mock_client
        mock_cm.get_profile.return_value = Profile(
            name="default", server="https://test.com", tenant="t1"
        )
        mock_cm.get_credentials.return_value = Credentials(
            profile_name="default", token="tok", token_type="api_key"
        )

        result = runner.invoke(app, ["auth", "whoami"])
        assert result.exit_code == 0
        assert "api_key" in result.output

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_whoami_error_with_message_attr(self, mock_client_class):
        """Line 598: exception with .message and .hint attributes."""
        exc = Exception("base")
        exc.message = "Custom error message"
        exc.hint = "Try this hint"
        mock_client_class.side_effect = exc

        result = runner.invoke(app, ["auth", "whoami"])
        assert result.exit_code != 0


class TestApiKeyCrudErrorPaths:
    """Tests for lines 653, 691-696, 708-718: API key CRUD error paths."""

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_error_with_message(self, mock_client_class):
        """Line 653: list keys error with .message attribute."""
        exc = Exception("base")
        exc.message = "Auth required"
        exc.hint = "Login first"
        mock_client = MagicMock()
        mock_client.get.side_effect = exc
        mock_client_class.return_value = mock_client

        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_create_api_key_error_with_message(self, mock_client_class):
        """Lines 691-696: create key error with .message attribute."""
        exc = Exception("base")
        exc.message = "Forbidden"
        exc.hint = "Need admin role"
        mock_client = MagicMock()
        mock_client.post.side_effect = exc
        mock_client_class.return_value = mock_client

        result = runner.invoke(app, ["auth", "api-key", "create", "--name", "test"])
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_create_api_key_generic_error(self, mock_client_class):
        """Lines 694-695: create key with generic error (no .message)."""
        mock_client = MagicMock()
        mock_client.post.side_effect = RuntimeError("generic fail")
        mock_client_class.return_value = mock_client

        result = runner.invoke(app, ["auth", "api-key", "create", "--name", "test"])
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_revoke_api_key_error_with_message(self, mock_client_class):
        """Lines 708-718: revoke key error with .message attribute."""
        exc = Exception("base")
        exc.message = "Not found"
        exc.hint = "Check key ID"
        mock_client = MagicMock()
        mock_client.delete.side_effect = exc
        mock_client_class.return_value = mock_client

        result = runner.invoke(app, ["auth", "api-key", "revoke", "key-123", "--force"])
        assert result.exit_code != 0


class TestLogoutCommand:
    @patch("virtualdojo.commands.auth.config_manager")
    def test_logout_default(self, mock_cm):
        mock_cm.config.default_profile = "default"
        runner.invoke(app, ["logout"])
        mock_cm.remove_credentials.assert_called_once_with("default")

    @patch("virtualdojo.commands.auth.config_manager")
    def test_logout_specific_profile(self, mock_cm):
        runner.invoke(app, ["logout", "--profile", "dev"])
        mock_cm.remove_credentials.assert_called_once_with("dev")

    @patch("virtualdojo.commands.auth.config_manager")
    def test_logout_all(self, mock_cm):
        from virtualdojo.config import Profile

        mock_cm.list_profiles.return_value = [
            Profile(name="a", server="s", tenant="t"),
            Profile(name="b", server="s", tenant="t"),
        ]
        runner.invoke(app, ["auth", "logout", "--all"])
        assert mock_cm.remove_credentials.call_count == 2

    @patch("virtualdojo.commands.auth.config_manager")
    def test_logout_no_profile(self, mock_cm):
        mock_cm.config.default_profile = None
        result = runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0


class TestWhoamiCommand:
    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    @patch("virtualdojo.commands.auth.config_manager")
    def test_whoami_success(self, mock_cm, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.return_value = {
            "email": "a@b.com",
            "id": "u1",
            "full_name": "Test User",
        }
        mock_client_class.return_value = mock_client

        from virtualdojo.config import Credentials, Profile

        mock_cm.get_profile.return_value = Profile(
            name="default", server="https://test.com", tenant="t1"
        )
        mock_cm.get_credentials.return_value = Credentials(
            profile_name="default", token="tok", token_type="jwt"
        )

        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_whoami_error_with_message(self, mock_client_class):
        err = MagicMock()
        err.message = "Not logged in"
        err.hint = "Run vdojo login"
        mock_client_class.side_effect = err.message
        mock_client_class.return_value.get.side_effect = Exception("test")

        runner.invoke(app, ["auth", "whoami"])

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_whoami_generic_error(self, mock_client_class):
        mock_client_class.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["auth", "whoami"])
        assert result.exit_code != 0


class TestApiKeyCommands:
    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_success(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.return_value = {
            "data": [
                {
                    "id": "key-123-456-789",
                    "name": "test",
                    "created_at": "2024-01-01T00:00:00",
                    "expires_at": "2024-12-31T00:00:00",
                }
            ]
        }
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_empty(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.return_value = {"data": []}
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_as_list(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.return_value = [
            {"id": "key-123-456-789", "name": "test", "created_at": "2024-01-01"}
        ]
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_no_expires(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.return_value = [
            {
                "id": "key-123-456-789",
                "name": "test",
                "created_at": None,
                "expires_at": None,
            }
        ]
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_list_api_keys_error(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.get.side_effect = Exception("fail")
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "list"])
        assert result.exit_code != 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_create_api_key(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.post.return_value = {
            "key": "sk-abc123",
            "name": "test",
            "id": "k1",
        }
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "create", "--name", "test"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_create_api_key_with_expiry(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.post.return_value = {"api_key": "sk-abc", "name": "ci", "id": "k1"}
        mock_client_class.return_value = mock_client
        result = runner.invoke(
            app, ["auth", "api-key", "create", "--name", "ci", "--expires", "90"]
        )
        assert result.exit_code == 0

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_create_api_key_error(self, mock_client_class):
        mock_client = MagicMock()
        err = MagicMock()
        err.message = "forbidden"
        err.hint = "no permission"
        mock_client.post.side_effect = err
        mock_client_class.return_value = mock_client
        runner.invoke(app, ["auth", "api-key", "create", "--name", "test"])

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_revoke_api_key(self, mock_client_class):
        mock_client = MagicMock()
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "revoke", "key-123", "--force"])
        assert result.exit_code == 0

    def test_revoke_api_key_abort(self):
        runner.invoke(app, ["auth", "api-key", "revoke", "key-123"], input="n\n")

    @patch("virtualdojo.commands.auth.SyncVirtualDojoClient")
    def test_revoke_api_key_error(self, mock_client_class):
        mock_client = MagicMock()
        mock_client.delete.side_effect = RuntimeError("fail")
        mock_client_class.return_value = mock_client
        result = runner.invoke(app, ["auth", "api-key", "revoke", "key-123", "--force"])
        assert result.exit_code != 0
