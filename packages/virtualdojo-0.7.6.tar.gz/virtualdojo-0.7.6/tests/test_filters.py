"""Tests for filter parsing utilities."""

import json

from virtualdojo.utils.filters import (
    FILTER_OPERATORS,
    _parse_value,
    _split_filter_pairs,
    build_filter_help,
    parse_filters,
)


class TestParseFilters:
    def test_json_passthrough(self):
        result = parse_filters('{"status": "active"}')
        assert json.loads(result) == {"status": "active"}

    def test_invalid_json_falls_through(self):
        result = parse_filters("{bad json")
        assert json.loads(result) == {}

    def test_simple_equality(self):
        result = parse_filters("status=active")
        assert json.loads(result) == {"status": "active"}

    def test_multiple_pairs(self):
        result = parse_filters("status=active,tier=enterprise")
        data = json.loads(result)
        assert data["status"] == "active"
        assert data["tier"] == "enterprise"

    def test_numeric_value(self):
        result = parse_filters("amount_gte=10000")
        assert json.loads(result)["amount_gte"] == 10000

    def test_float_value(self):
        result = parse_filters("rate=3.14")
        assert json.loads(result)["rate"] == 3.14

    def test_boolean_values(self):
        result = parse_filters("active=true,archived=false")
        data = json.loads(result)
        assert data["active"] is True
        assert data["archived"] is False

    def test_null_value(self):
        result = parse_filters("status=null")
        assert json.loads(result)["status"] is None

    def test_none_value(self):
        result = parse_filters("status=none")
        assert json.loads(result)["status"] is None

    def test_quoted_value_double(self):
        result = parse_filters('name="Acme Corp"')
        assert json.loads(result)["name"] == "Acme Corp"

    def test_quoted_value_single(self):
        result = parse_filters("name='Acme Corp'")
        assert json.loads(result)["name"] == "Acme Corp"

    def test_in_operator_pipe(self):
        result = parse_filters("status_in=active|pending")
        data = json.loads(result)
        assert data["status_in"] == ["active", "pending"]

    def test_in_operator_comma_quoted(self):
        result = parse_filters('status_in="active,pending"')
        data = json.loads(result)
        assert data["status_in"] == ["active", "pending"]

    def test_not_in_operator(self):
        result = parse_filters("status_not_in=closed|lost")
        data = json.loads(result)
        assert data["status_not_in"] == ["closed", "lost"]

    def test_in_operator_single_numeric(self):
        result = parse_filters("id_in=42")
        data = json.loads(result)
        assert data["id_in"] == [42]

    def test_no_equals(self):
        result = parse_filters("invalid_filter")
        assert json.loads(result) == {}

    def test_empty_string(self):
        result = parse_filters("")
        assert json.loads(result) == {}

    def test_whitespace_handling(self):
        result = parse_filters("  status = active  ")
        assert json.loads(result)["status"] == "active"


class TestSplitFilterPairs:
    def test_simple_split(self):
        assert _split_filter_pairs("a=1,b=2") == ["a=1", "b=2"]

    def test_quoted_comma(self):
        assert _split_filter_pairs('a="1,2",b=3') == ['a="1,2"', "b=3"]

    def test_single_quoted_comma(self):
        assert _split_filter_pairs("a='1,2',b=3") == ["a='1,2'", "b=3"]

    def test_empty(self):
        assert _split_filter_pairs("") == []

    def test_single(self):
        assert _split_filter_pairs("a=1") == ["a=1"]


class TestParseValue:
    def test_true(self):
        assert _parse_value("true") is True
        assert _parse_value("True") is True

    def test_false(self):
        assert _parse_value("false") is False

    def test_null(self):
        assert _parse_value("null") is None
        assert _parse_value("none") is None

    def test_int(self):
        assert _parse_value("42") == 42
        assert _parse_value("-5") == -5

    def test_float(self):
        assert _parse_value("3.14") == 3.14
        assert _parse_value("-1.5") == -1.5

    def test_string(self):
        assert _parse_value("hello") == "hello"


class TestBuildFilterHelp:
    def test_returns_string(self):
        result = build_filter_help()
        assert isinstance(result, str)
        assert "Filter Syntax" in result


class TestFilterOperators:
    def test_operators_defined(self):
        assert "" in FILTER_OPERATORS
        assert "_ne" in FILTER_OPERATORS
        assert "_in" in FILTER_OPERATORS
        assert "_contains" in FILTER_OPERATORS
