"""Tests for schema commands."""

from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.schema.SyncVirtualDojoClient"


class TestListObjects:
    @patch(MOCK_CLIENT)
    def test_objects_list(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"api_name": "accounts", "label": "Accounts"},
        ]
        result = runner.invoke(app, ["schema", "objects"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_objects_dict_response(self, mock_cls):
        mock_cls.return_value.get.return_value = {"objects": [{"api_name": "accounts"}]}
        result = runner.invoke(app, ["schema", "objects"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_objects_filter_standard(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"api_name": "accounts"},
            {"api_name": "projects_co"},
        ]
        result = runner.invoke(app, ["schema", "objects", "--type", "standard"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_objects_filter_custom(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"api_name": "accounts"},
            {"api_name": "projects_co"},
        ]
        result = runner.invoke(app, ["schema", "objects", "--type", "custom"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_objects_json(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["schema", "objects", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_objects_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["schema", "objects"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_objects_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Not found"
        err.hint = "Check name"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["schema", "objects"])
        assert result.exit_code != 0


class TestDescribeObject:
    @patch(MOCK_CLIENT)
    def test_describe_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {"name": {"field_name": "name", "display_type": "string"}}
        }
        result = runner.invoke(app, ["schema", "describe", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_describe_custom_object(self, mock_cls):
        mock_cls.return_value.get.return_value = {"fields": []}
        result = runner.invoke(app, ["schema", "describe", "projects_co"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_describe_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"fields": {}}
        result = runner.invoke(
            app, ["schema", "describe", "accounts", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_describe_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"fields": {}}
        result = runner.invoke(
            app, ["schema", "describe", "accounts", "--format", "yaml"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_describe_fields_list(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": [{"field_name": "name", "display_type": "string"}]
        }
        result = runner.invoke(app, ["schema", "describe", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_describe_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["schema", "describe", "accounts"])
        assert result.exit_code != 0


class TestListFields:
    @patch(MOCK_CLIENT)
    def test_fields_success(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "name": {
                    "field_name": "name",
                    "display_type": "string",
                    "is_nullable": True,
                },
                "email": {
                    "field_name": "email",
                    "display_type": "string",
                    "is_nullable": False,
                },
            }
        }
        result = runner.invoke(app, ["schema", "fields", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_fields_required_only(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "name": {"field_name": "name", "is_nullable": False},
                "email": {"field_name": "email", "is_nullable": True},
            }
        }
        result = runner.invoke(app, ["schema", "fields", "accounts", "--required"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_fields_filter_type(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "name": {"field_name": "name", "display_type": "string"},
                "age": {"field_name": "age", "display_type": "number"},
            }
        }
        result = runner.invoke(
            app, ["schema", "fields", "accounts", "--type", "string"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_fields_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"fields": {}}
        result = runner.invoke(
            app, ["schema", "fields", "accounts", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_fields_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["schema", "fields", "accounts"])
        assert result.exit_code != 0


class TestPicklists:
    @patch(MOCK_CLIENT)
    def test_picklists_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": [
                        {"value": "open", "label": "Open", "is_active": True},
                        {"value": "closed", "label": "Closed", "is_active": False},
                    ],
                }
            }
        }
        result = runner.invoke(app, ["schema", "picklists", "opportunities"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_string_values(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": ["open", "closed"],
                }
            }
        }
        result = runner.invoke(app, ["schema", "picklists", "opportunities"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_no_values(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": [],
                }
            }
        }
        result = runner.invoke(app, ["schema", "picklists", "opportunities"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_filter_field(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": [{"value": "open", "label": "Open"}],
                },
                "status": {
                    "field_name": "status",
                    "display_type": "picklist",
                    "choices": [{"value": "active"}],
                },
            }
        }
        result = runner.invoke(
            app, ["schema", "picklists", "accounts", "--field", "stage"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_none_found(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {"name": {"field_name": "name", "display_type": "string"}}
        }
        result = runner.invoke(app, ["schema", "picklists", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": [],
                }
            }
        }
        result = runner.invoke(
            app, ["schema", "picklists", "accounts", "--format", "json"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "fields": {
                "stage": {
                    "field_name": "stage",
                    "display_type": "picklist",
                    "choices": [],
                }
            }
        }
        result = runner.invoke(
            app, ["schema", "picklists", "accounts", "--format", "yaml"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_picklists_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["schema", "picklists", "accounts"])
        assert result.exit_code != 0


class TestErrorWithMessage:
    @patch(MOCK_CLIENT)
    def test_objects_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = "hint"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["schema", "objects"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_describe_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["schema", "describe", "accounts"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_fields_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["schema", "fields", "accounts"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_picklists_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["schema", "picklists", "accounts"])
        assert result.exit_code != 0
