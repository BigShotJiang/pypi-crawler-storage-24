"""Tests for CLI main entry point and top-level commands."""

import os
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from virtualdojo.cli import app, run

runner = CliRunner()


class TestVersionCallback:
    def test_version_flag(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "version" in result.output.lower()


class TestMainCallback:
    def test_no_args_shows_help(self):
        result = runner.invoke(app, [])
        # no_args_is_help=True means exit 0 with help text
        assert "Usage" in result.output or result.exit_code == 0

    @patch("virtualdojo.cli.get_update_message")
    def test_update_check(self, mock_update):
        mock_update.return_value = "Update available: 99.0.0"
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0

    @patch("virtualdojo.cli.get_update_message")
    def test_update_check_none(self, mock_update):
        mock_update.return_value = None
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0

    @patch("virtualdojo.cli.get_update_message")
    def test_no_update_check_flag(self, mock_update):
        result = runner.invoke(app, ["--no-update-check", "--version"])
        assert result.exit_code == 0
        mock_update.assert_not_called()

    @patch.dict(os.environ, {"VIRTUALDOJO_NO_UPDATE_CHECK": "1"})
    @patch("virtualdojo.cli.get_update_message")
    def test_no_update_check_env(self, mock_update):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        mock_update.assert_not_called()


class TestLoginShortcut:
    @patch("virtualdojo.cli.auth")
    def test_login(self, mock_auth):
        mock_auth.login = lambda **kwargs: None
        result = runner.invoke(app, ["login", "--local"], input="a@b.com\npass\n")
        assert result.exit_code == 0


class TestLogoutShortcut:
    @patch("virtualdojo.cli.auth")
    def test_logout(self, mock_auth):
        mock_auth.logout = lambda **kwargs: None
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0


class TestWhoamiShortcut:
    @patch("virtualdojo.cli.auth")
    def test_whoami(self, mock_auth):
        mock_auth.whoami = lambda **kwargs: None
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0


class TestRunFunction:
    @patch("virtualdojo.cli.app")
    def test_run_success(self, mock_app):
        mock_app.return_value = None
        run()

    @patch("virtualdojo.cli.app")
    def test_run_virtualdojo_error(self, mock_app):
        from click.exceptions import Exit

        from virtualdojo.exceptions import VirtualDojoError

        mock_app.side_effect = VirtualDojoError("test error", hint="try again")
        with pytest.raises((SystemExit, Exit)):
            run()

    @patch("virtualdojo.cli.app")
    def test_run_virtualdojo_error_no_hint(self, mock_app):
        from click.exceptions import Exit

        from virtualdojo.exceptions import VirtualDojoError

        mock_app.side_effect = VirtualDojoError("test error")
        with pytest.raises((SystemExit, Exit)):
            run()

    @patch("virtualdojo.cli.app")
    def test_run_keyboard_interrupt(self, mock_app):
        from click.exceptions import Exit

        mock_app.side_effect = KeyboardInterrupt
        with pytest.raises((SystemExit, Exit)):
            run()


class TestVersionCallbackDirect:
    def test_version_callback_function(self):
        """Test the version_callback function directly."""
        from click.exceptions import Exit

        from virtualdojo.cli import version_callback

        with pytest.raises(Exit):
            version_callback(True)

    def test_version_callback_false(self):
        """Test version_callback with False does nothing."""
        from virtualdojo.cli import version_callback

        version_callback(False)


class TestUpdateCheckPrinted:
    @patch("virtualdojo.cli.get_update_message")
    def test_update_message_printed(self, mock_update):
        """When update is available, message is printed."""
        mock_update.return_value = "Update available: 99.0.0"
        runner.invoke(app, ["config", "show"])
        mock_update.assert_called_once()


class TestMainModule:
    def test_main_module_importable(self):
        """Test __main__.py can be imported."""
        import importlib

        mod = importlib.import_module("virtualdojo.__main__")
        assert hasattr(mod, "app")
