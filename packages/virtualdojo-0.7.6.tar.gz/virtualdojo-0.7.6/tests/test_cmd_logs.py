"""Tests for logs commands."""

from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.logs.SyncVirtualDojoClient"


class TestListLogs:
    @patch(MOCK_CLIENT)
    def test_list_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "created_at": "2024-01-01T00:00:00",
                    "log_level": "error",
                    "component": "RecordList",
                    "message": "Something failed" + "x" * 60,
                }
            ],
            "total": 1,
        }
        result = runner.invoke(app, ["logs", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": [], "total": 0}
        result = runner.invoke(app, ["logs", "list", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": [], "total": 0}
        result = runner.invoke(app, ["logs", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_with_filters(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": [], "total": 0}
        result = runner.invoke(
            app,
            [
                "logs",
                "list",
                "--level",
                "error",
                "--component",
                "Auth",
                "--source",
                "backend",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_all_levels(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "log_level": "error",
                    "message": "e",
                    "component": "A",
                    "created_at": "",
                },
                {
                    "log_level": "warning",
                    "message": "w",
                    "component": "B",
                    "created_at": "",
                },
                {
                    "log_level": "info",
                    "message": "i",
                    "component": "C",
                    "created_at": "",
                },
                {
                    "log_level": "debug",
                    "message": "d",
                    "component": "D",
                    "created_at": "",
                },
                {
                    "log_level": "custom",
                    "message": "c",
                    "component": "E",
                    "created_at": "",
                },
            ],
            "total": 5,
        }
        result = runner.invoke(app, ["logs", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "list"])
        assert result.exit_code != 0


class TestSearchLogs:
    @patch(MOCK_CLIENT)
    def test_search_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "created_at": "2024-01-01",
                    "log_level": "error",
                    "component": "Auth",
                    "message": "Failed login" + "x" * 60,
                }
            ]
        }
        result = runner.invoke(app, ["logs", "search", "failed"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": []}
        result = runner.invoke(app, ["logs", "search", "test", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": []}
        result = runner.invoke(app, ["logs", "search", "nothing"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_list_response(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["logs", "search", "test"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_with_filters(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": []}
        result = runner.invoke(
            app,
            [
                "logs",
                "search",
                "error",
                "--level",
                "error",
                "--component",
                "Auth",
                "--start",
                "2024-01-01",
                "--end",
                "2024-12-31",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_search_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "search", "test"])
        assert result.exit_code != 0


class TestLogStats:
    @patch(MOCK_CLIENT)
    def test_stats_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "total_logs": 1000,
            "logs_by_level": {"error": 10, "info": 900, "warning": 90},
            "logs_by_component": {"Auth": 500, "Records": 300},
            "logs_by_source": {"backend": 800, "frontend": 200},
        }
        result = runner.invoke(app, ["logs", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_logs": 0}
        result = runner.invoke(app, ["logs", "stats", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_minimal(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_logs": 0}
        result = runner.invoke(app, ["logs", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "stats"])
        assert result.exit_code != 0


class TestTailLogs:
    @patch("virtualdojo.commands.logs.time")
    @patch(MOCK_CLIENT)
    def test_tail_follow_interrupt(self, mock_cls, mock_time):
        """Test tail with follow - keyboard interrupt after first poll."""
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "id": "1",
                    "created_at": "2024-01-01",
                    "log_level": "info",
                    "component": "Auth",
                    "message": "msg",
                }
            ]
        }
        mock_time.sleep.side_effect = KeyboardInterrupt
        result = runner.invoke(app, ["logs", "tail"])
        assert result.exit_code == 0

    @patch("virtualdojo.commands.logs.time")
    @patch(MOCK_CLIENT)
    def test_tail_with_filters(self, mock_cls, mock_time):
        mock_cls.return_value.get.return_value = {"logs": []}
        mock_time.sleep.side_effect = KeyboardInterrupt
        result = runner.invoke(
            app,
            ["logs", "tail", "--level", "error", "--component", "Auth"],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_tail_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "tail"])
        assert result.exit_code != 0


class TestComponents:
    @patch(MOCK_CLIENT)
    def test_list_components(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"component": "Auth", "is_enabled": True, "log_count_24h": 100},
            {"component": "Records", "is_enabled": False, "log_count_24h": 0},
        ]
        result = runner.invoke(app, ["logs", "components"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_components_dict(self, mock_cls):
        mock_cls.return_value.get.return_value = {"data": []}
        result = runner.invoke(app, ["logs", "components"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_components_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = []
        result = runner.invoke(app, ["logs", "components"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_components_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "components"])
        assert result.exit_code != 0


class TestEnableDebug:
    @patch(MOCK_CLIENT)
    def test_enable(self, mock_cls):
        mock_cls.return_value.post.return_value = {"expires_at": "2024-01-01T01:00:00"}
        result = runner.invoke(app, ["logs", "enable"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_enable_hours(self, mock_cls):
        mock_cls.return_value.post.return_value = {"expires_at": "2024-01-01T02:00:00"}
        result = runner.invoke(app, ["logs", "enable", "--hours", "2"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_enable_invalid_hours(self, mock_cls):
        result = runner.invoke(app, ["logs", "enable", "--hours", "5"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_enable_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "enable"])
        assert result.exit_code != 0


class TestDisableDebug:
    @patch(MOCK_CLIENT)
    def test_disable(self, mock_cls):
        mock_cls.return_value.post.return_value = {}
        result = runner.invoke(app, ["logs", "disable"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_disable_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "disable"])
        assert result.exit_code != 0


class TestDebugStatus:
    @patch(MOCK_CLIENT)
    def test_status_enabled(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "is_enabled": True,
            "expires_at": "2024-01-01T01:00:00",
            "enabled_by": "admin",
            "enabled_at": "2024-01-01T00:00:00",
        }
        result = runner.invoke(app, ["logs", "status"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_status_disabled(self, mock_cls):
        mock_cls.return_value.get.return_value = {"is_enabled": False}
        result = runner.invoke(app, ["logs", "status"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_status_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"is_enabled": True}
        result = runner.invoke(app, ["logs", "status", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_status_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "status"])
        assert result.exit_code != 0


class TestSystemLogs:
    @patch(MOCK_CLIENT)
    def test_system_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "timestamp": "2024-01-01",
                    "level": "error",
                    "component": "DB",
                    "message": "Connection lost" + "x" * 60,
                }
            ],
            "total": 1,
        }
        result = runner.invoke(app, ["logs", "system"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_system_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": []}
        result = runner.invoke(app, ["logs", "system", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_system_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": []}
        result = runner.invoke(app, ["logs", "system"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_system_list_response(self, mock_cls):
        mock_cls.return_value.get.return_value = [
            {"log_level": "info", "message": "test", "component": "A", "created_at": ""}
        ]
        result = runner.invoke(app, ["logs", "system"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_system_with_level(self, mock_cls):
        mock_cls.return_value.get.return_value = {"logs": [], "total": 0}
        result = runner.invoke(app, ["logs", "system", "--level", "error"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_system_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "system"])
        assert result.exit_code != 0


class TestAnalytics:
    @patch(MOCK_CLIENT)
    def test_analytics_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "total_logs": 500,
            "error_patterns": [{"message": "Connection error", "count": 10}],
            "top_users": [{"user_email": "a@b.com", "log_count": 100}],
            "hourly_trends": [
                {"hour": "00:00", "count": 50},
                {"hour": "01:00", "count": 30},
                {"hour": "02:00", "count": 20},
                {"hour": "03:00", "count": 10},
                {"hour": "04:00", "count": 5},
                {"hour": "05:00", "count": 2},
                {"hour": "06:00", "count": 100},
            ],
        }
        result = runner.invoke(app, ["logs", "analytics"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_analytics_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_logs": 0}
        result = runner.invoke(app, ["logs", "analytics", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_analytics_minimal(self, mock_cls):
        mock_cls.return_value.get.return_value = {"total_logs": 0}
        result = runner.invoke(app, ["logs", "analytics"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_analytics_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["logs", "analytics"])
        assert result.exit_code != 0


class TestErrorWithMessage:
    """Test hasattr(e, 'message') branches across all log commands."""

    @patch(MOCK_CLIENT)
    def test_list_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Unauthorized"
        err.hint = "Login"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "list"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_search_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Bad query"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "search", "test"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_stats_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "stats"])
        assert result.exit_code != 0

    @patch("virtualdojo.commands.logs.time")
    @patch(MOCK_CLIENT)
    def test_tail_error_with_message(self, mock_cls, mock_time):
        err = RuntimeError()
        err.message = "Error"
        err.hint = "try again"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "tail"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_components_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "components"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_enable_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.post.side_effect = err
        result = runner.invoke(app, ["logs", "enable"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_disable_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.post.side_effect = err
        result = runner.invoke(app, ["logs", "disable"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_status_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "status"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_system_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "system"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_analytics_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = None
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["logs", "analytics"])
        assert result.exit_code != 0


class TestTailNoFollow:
    @patch(MOCK_CLIENT)
    def test_tail_no_follow(self, mock_cls):
        """Call tail_logs directly with follow=False to cover the break path."""
        mock_cls.return_value.get.return_value = {
            "logs": [
                {
                    "id": "1",
                    "created_at": "2024-01-01",
                    "log_level": "info",
                    "component": "Auth",
                    "message": "msg",
                }
            ]
        }
        from virtualdojo.commands.logs import tail_logs

        # Call the function directly with follow=False
        tail_logs(follow=False)
