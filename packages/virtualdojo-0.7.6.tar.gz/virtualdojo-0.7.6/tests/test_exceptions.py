"""Tests for exceptions module."""

from virtualdojo.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    NetworkError,
    NotLoggedInError,
    ProfileNotFoundError,
    TokenExpiredError,
    TokenRefreshedError,
    ValidationError,
    VirtualDojoError,
)


class TestVirtualDojoError:
    def test_basic(self):
        e = VirtualDojoError("msg")
        assert e.message == "msg"
        assert e.hint is None
        assert str(e) == "msg"

    def test_with_hint(self):
        e = VirtualDojoError("msg", hint="try this")
        assert e.hint == "try this"


class TestAuthenticationError:
    def test_is_virtualdojo_error(self):
        e = AuthenticationError("auth failed")
        assert isinstance(e, VirtualDojoError)
        assert e.message == "auth failed"


class TestTokenExpiredError:
    def test_defaults(self):
        e = TokenExpiredError()
        assert "expired" in e.message
        assert "login" in e.hint


class TestTokenRefreshedError:
    def test_is_virtualdojo_error(self):
        e = TokenRefreshedError("refreshed")
        assert isinstance(e, VirtualDojoError)


class TestConfigurationError:
    def test_is_virtualdojo_error(self):
        e = ConfigurationError("bad config")
        assert isinstance(e, VirtualDojoError)


class TestNotLoggedInError:
    def test_defaults(self):
        e = NotLoggedInError()
        assert "not logged in" in e.message
        assert "login" in e.hint


class TestProfileNotFoundError:
    def test_with_name(self):
        e = ProfileNotFoundError("myprofile")
        assert "myprofile" in e.message
        assert "profile list" in e.hint


class TestAPIError:
    def test_with_known_status(self):
        e = APIError(401, "Unauthorized")
        assert e.status_code == 401
        assert e.detail == "Unauthorized"
        assert "401" in e.message
        assert e.hint is not None

    def test_all_known_statuses(self):
        for code in [400, 401, 403, 404, 429, 500]:
            e = APIError(code, "test")
            assert e.hint is not None

    def test_unknown_status(self):
        e = APIError(418, "I'm a teapot")
        assert e.hint is None


class TestNetworkError:
    def test_basic(self):
        e = NetworkError("connection refused")
        assert "connection refused" in e.message
        assert "internet" in e.hint.lower() or "connection" in e.hint.lower()


class TestValidationError:
    def test_is_virtualdojo_error(self):
        e = ValidationError("bad input")
        assert isinstance(e, VirtualDojoError)
