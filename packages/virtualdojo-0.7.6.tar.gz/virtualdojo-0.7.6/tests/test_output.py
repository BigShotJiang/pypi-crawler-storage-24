"""Tests for output utilities."""

import json

from virtualdojo.utils.output import (
    format_duration,
    format_size,
    print_error,
    print_fields,
    print_info,
    print_json,
    print_objects,
    print_panel,
    print_raw_json,
    print_record,
    print_records,
    print_success,
    print_warning,
    print_yaml,
)


class TestPrintFunctions:
    def test_print_success(self, capsys):
        print_success("done")

    def test_print_error_no_hint(self, capsys):
        print_error("fail")

    def test_print_error_with_hint(self, capsys):
        print_error("fail", hint="try again")

    def test_print_warning(self, capsys):
        print_warning("careful")

    def test_print_info(self, capsys):
        print_info("note")

    def test_print_json(self, capsys):
        print_json({"key": "val"})

    def test_print_raw_json(self, capsys):
        print_raw_json({"key": "val"})
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["key"] == "val"

    def test_print_yaml(self, capsys):
        print_yaml({"key": "val"})

    def test_print_panel(self, capsys):
        print_panel("content", "title")
        print_panel("content", "title", style="red")


class TestPrintRecord:
    def test_json_format(self, capsys):
        print_record({"id": "1", "name": "test"}, format="json")

    def test_yaml_format(self, capsys):
        print_record({"id": "1", "name": "test"}, format="yaml")

    def test_table_format(self, capsys):
        print_record(
            {
                "id": "1",
                "name": "test",
                "active": True,
                "inactive": False,
                "empty": None,
                "nested": {"a": "b", "c": "d"},
                "items": [1, 2, 3],
                "long_nested": {f"key{i}": f"value{i}" for i in range(50)},
            },
            format="table",
        )


class TestPrintRecords:
    def test_empty(self, capsys):
        print_records([])

    def test_json_format(self, capsys):
        print_records([{"id": "1"}], format="json")

    def test_yaml_format(self, capsys):
        print_records([{"id": "1"}], format="yaml")

    def test_table_with_columns(self, capsys):
        print_records(
            [{"id": "1", "name": "test", "status": "active"}],
            columns=["id", "name"],
        )

    def test_table_auto_columns(self, capsys):
        print_records(
            [
                {
                    "id": "1",
                    "name": "test",
                    "email": "a@b.com",
                    "status": "active",
                    "created_at": "2024-01-01",
                    "updated_at": "2024-01-02",
                    "extra1": "v1",
                    "extra2": "v2",
                    "extra3": "v3",
                    "extra4": "v4",
                }
            ]
        )

    def test_table_value_types(self, capsys):
        print_records(
            [
                {
                    "id": "1",
                    "active": True,
                    "inactive": False,
                    "empty": None,
                    "nested": {"a": "b"},
                    "items": [1, 2],
                    "long_value": "x" * 50,
                }
            ]
        )

    def test_table_with_title(self, capsys):
        print_records([{"id": "1"}], title="Test Records")


class TestPrintObjects:
    def test_json_format(self, capsys):
        print_objects([{"api_name": "accounts"}], format="json")

    def test_yaml_format(self, capsys):
        print_objects([{"api_name": "accounts"}], format="yaml")

    def test_table_standard(self, capsys):
        print_objects(
            [
                {
                    "api_name": "accounts",
                    "label": "Accounts",
                    "is_custom": False,
                    "fields_count": 10,
                }
            ]
        )

    def test_table_custom(self, capsys):
        print_objects(
            [{"api_name": "projects_co", "label": "Projects", "field_count": 5}]
        )

    def test_table_name_fallback(self, capsys):
        print_objects([{"name": "test"}])


class TestPrintFields:
    def test_json_format(self, capsys):
        print_fields([{"field_name": "name"}], format="json")

    def test_yaml_format(self, capsys):
        print_fields([{"field_name": "name"}], format="yaml")

    def test_table_format(self, capsys):
        print_fields(
            [
                {
                    "field_name": "name",
                    "display_type": "string",
                    "is_nullable": True,
                },
                {
                    "api_name": "email",
                    "field_type": "string",
                    "is_nullable": False,
                },
                {"name": "id", "type": "uuid"},
            ]
        )


class TestFormatSize:
    def test_bytes(self):
        assert "B" in format_size(500)

    def test_kb(self):
        assert "KB" in format_size(2048)

    def test_mb(self):
        assert "MB" in format_size(2 * 1024 * 1024)

    def test_gb(self):
        assert "GB" in format_size(2 * 1024**3)

    def test_tb(self):
        assert "TB" in format_size(2 * 1024**4)


class TestFormatDuration:
    def test_milliseconds(self):
        assert "ms" in format_duration(0.5)

    def test_seconds(self):
        assert "s" in format_duration(30)

    def test_minutes(self):
        result = format_duration(125)
        assert "m" in result
        assert "s" in result
