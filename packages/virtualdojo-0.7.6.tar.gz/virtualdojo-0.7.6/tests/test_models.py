"""Tests for pydantic models."""

from virtualdojo.models import PaginatedResponse, Record, TokenResponse, UserInfo
from virtualdojo.models.auth import APIKeyInfo, APIKeyResponse
from virtualdojo.models.records import FieldDefinition, ObjectDefinition, ObjectSchema


class TestTokenResponse:
    def test_minimal(self):
        t = TokenResponse(access_token="abc")
        assert t.access_token == "abc"
        assert t.token_type == "bearer"
        assert t.expires_in == 1800
        assert t.refresh_token is None

    def test_full(self):
        t = TokenResponse(
            access_token="abc",
            token_type="custom",
            expires_in=3600,
            refresh_token="ref",
        )
        assert t.refresh_token == "ref"
        assert t.expires_in == 3600


class TestUserInfo:
    def test_minimal(self):
        u = UserInfo(id="u1", email="a@b.com", tenant_id="t1")
        assert u.id == "u1"
        assert u.full_name is None
        assert u.is_active is True
        assert u.profile_id is None

    def test_full(self):
        u = UserInfo(
            id="u1",
            email="a@b.com",
            full_name="Test",
            is_active=False,
            tenant_id="t1",
            profile_id="p1",
        )
        assert u.full_name == "Test"
        assert u.is_active is False


class TestAPIKeyResponse:
    def test_minimal(self):
        k = APIKeyResponse(id="k1", name="test", key="sk-123", created_at="2024-01-01")
        assert k.expires_at is None

    def test_full(self):
        k = APIKeyResponse(
            id="k1",
            name="test",
            key="sk-123",
            created_at="2024-01-01",
            expires_at="2024-12-31",
        )
        assert k.expires_at == "2024-12-31"


class TestAPIKeyInfo:
    def test_defaults(self):
        k = APIKeyInfo(id="k1", name="test", created_at="2024-01-01")
        assert k.is_active is True
        assert k.expires_at is None


class TestRecord:
    def test_minimal(self):
        r = Record(id="r1")
        assert r.tenant_id is None
        assert r.is_deleted is False

    def test_extra_fields(self):
        r = Record(id="r1", custom_field="val")
        assert r.custom_field == "val"


class TestPaginatedResponse:
    def test_basic(self):
        p = PaginatedResponse(data=[{"id": "1"}], total=1)
        assert len(p.data) == 1
        assert p.skip == 0
        assert p.limit == 100


class TestObjectDefinition:
    def test_defaults(self):
        o = ObjectDefinition(api_name="accounts", label="Accounts")
        assert o.plural_label is None
        assert o.is_custom is False
        assert o.field_count is None


class TestFieldDefinition:
    def test_defaults(self):
        f = FieldDefinition(api_name="name", label="Name", field_type="string")
        assert f.is_required is False
        assert f.is_unique is False
        assert f.max_length is None
        assert f.default_value is None
        assert f.help_text is None
        assert f.picklist_values is None


class TestObjectSchema:
    def test_basic(self):
        obj = ObjectDefinition(api_name="accounts", label="Accounts")
        field = FieldDefinition(api_name="name", label="Name", field_type="string")
        schema = ObjectSchema(object=obj, fields=[field])
        assert len(schema.fields) == 1
