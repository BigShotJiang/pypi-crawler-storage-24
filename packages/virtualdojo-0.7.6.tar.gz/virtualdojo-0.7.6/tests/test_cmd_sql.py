"""Tests for SQL commands."""

from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.sql.SyncVirtualDojoClient"


class TestSqlQuery:
    @patch(MOCK_CLIENT)
    def test_select_table(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "SELECT",
            "rows": [{"id": "1", "name": "Test"}],
            "columns": ["id", "name"],
            "row_count": 1,
            "execution_time_ms": 15,
        }
        result = runner.invoke(app, ["sql", "query", "SELECT * FROM accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_select_no_rows(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "SELECT",
            "rows": [],
            "columns": [],
            "row_count": 0,
            "execution_time_ms": 5,
        }
        result = runner.invoke(app, ["sql", "query", "SELECT * FROM empty"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_select_with_null_values(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "SELECT",
            "rows": [{"id": "1", "email": None}],
            "columns": ["id", "email"],
            "row_count": 1,
            "execution_time_ms": 10,
        }
        result = runner.invoke(app, ["sql", "query", "SELECT * FROM accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_write_operation(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "UPDATE",
            "rows": [],
            "columns": [],
            "row_count": 5,
            "execution_time_ms": 20,
        }
        result = runner.invoke(
            app, ["sql", "query", "UPDATE accounts SET status='active'", "--confirm"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_insert_operation(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "INSERT",
            "row_count": 1,
            "execution_time_ms": 10,
        }
        result = runner.invoke(
            app,
            [
                "sql",
                "query",
                "INSERT INTO tasks (name) VALUES ('test')",
                "--confirm",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_delete_operation(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "DELETE",
            "row_count": 3,
            "execution_time_ms": 0,
        }
        result = runner.invoke(
            app,
            ["sql", "query", "DELETE FROM tasks WHERE done=true", "--confirm"],
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_dry_run(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "estimated_rows": 100,
            "operation": "SELECT",
        }
        result = runner.invoke(
            app, ["sql", "query", "SELECT * FROM accounts", "--dry-run"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_dry_run_minimal(self, mock_cls):
        mock_cls.return_value.post.return_value = {"success": True}
        result = runner.invoke(
            app, ["sql", "query", "SELECT * FROM accounts", "--dry-run"]
        )
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_json_format(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "SELECT",
            "rows": [],
            "columns": [],
            "row_count": 0,
            "execution_time_ms": 0,
        }
        result = runner.invoke(app, ["sql", "query", "SELECT 1", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_yaml_format(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": True,
            "operation": "SELECT",
            "rows": [],
            "columns": [],
            "row_count": 0,
            "execution_time_ms": 0,
        }
        result = runner.invoke(app, ["sql", "query", "SELECT 1", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_query_failure(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "success": False,
            "error": "Syntax error",
            "error_type": "syntax",
            "suggestions": ["Check your SQL"],
        }
        result = runner.invoke(app, ["sql", "query", "INVALID SQL"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_query_failure_minimal(self, mock_cls):
        mock_cls.return_value.post.return_value = {"success": False}
        result = runner.invoke(app, ["sql", "query", "BAD"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_query_exception(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["sql", "query", "SELECT 1"])
        assert result.exit_code != 0


class TestSqlValidate:
    @patch(MOCK_CLIENT)
    def test_valid_query(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "valid": True,
            "operation": "SELECT",
            "estimated_rows": 100,
            "warnings": ["Performance warning"],
            "suggestions": ["Add index"],
        }
        result = runner.invoke(app, ["sql", "validate", "SELECT * FROM accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_valid_minimal(self, mock_cls):
        mock_cls.return_value.post.return_value = {"valid": True}
        result = runner.invoke(app, ["sql", "validate", "SELECT 1"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_invalid_query(self, mock_cls):
        mock_cls.return_value.post.return_value = {
            "valid": False,
            "error": "Syntax error",
        }
        result = runner.invoke(app, ["sql", "validate", "BAD SQL"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_validate_error(self, mock_cls):
        mock_cls.return_value.post.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["sql", "validate", "SELECT 1"])
        assert result.exit_code != 0


class TestSqlSchema:
    @patch(MOCK_CLIENT)
    def test_list_objects(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": True,
            "objects": {
                "accounts": {"label": "Accounts", "type": "standard", "fields": [1, 2]},
                "projects_co": {"label": "Projects", "fields": [1]},
            },
        }
        result = runner.invoke(app, ["sql", "schema"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_objects_list_format(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": True,
            "objects": [
                {"name": "accounts", "label": "Accounts", "fields": [1, 2]},
            ],
        }
        result = runner.invoke(app, ["sql", "schema"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_list_objects_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"success": True, "objects": {}}
        result = runner.invoke(app, ["sql", "schema"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_object_fields(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": True,
            "object": {
                "label": "Accounts",
                "fields": [
                    {"name": "id", "label": "ID", "type": "uuid", "required": True},
                    {
                        "name": "name",
                        "label": "Name",
                        "type": "string",
                        "required": False,
                    },
                ],
            },
        }
        result = runner.invoke(app, ["sql", "schema", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_object_fields_no_object_key(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": True,
            "fields": [{"name": "id", "label": "ID", "type": "uuid"}],
        }
        result = runner.invoke(app, ["sql", "schema", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_object_fields_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": True,
            "object": {"fields": []},
        }
        result = runner.invoke(app, ["sql", "schema", "accounts"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_schema_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"success": True, "objects": {}}
        result = runner.invoke(app, ["sql", "schema", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_schema_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"success": True, "objects": {}}
        result = runner.invoke(app, ["sql", "schema", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_schema_failure(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "success": False,
            "error": "Not found",
        }
        result = runner.invoke(app, ["sql", "schema", "missing"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_schema_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["sql", "schema"])
        assert result.exit_code != 0


class TestSqlHistory:
    @patch(MOCK_CLIENT)
    def test_history_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "queries": [
                {
                    "operation": "SELECT",
                    "query": "SELECT * FROM accounts",
                    "executed_at": "2024-01-01",
                    "row_count": 10,
                    "execution_time_ms": 15,
                    "success": True,
                },
                {
                    "operation": "DELETE",
                    "query": "DELETE FROM tasks WHERE status='done' AND archived=true AND old=true",
                    "executed_at": "2024-01-01",
                    "row_count": 5,
                    "execution_time_ms": 20,
                    "success": False,
                },
            ]
        }
        result = runner.invoke(app, ["sql", "history"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {"queries": []}
        result = runner.invoke(app, ["sql", "history", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {"queries": []}
        result = runner.invoke(app, ["sql", "history", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_empty(self, mock_cls):
        mock_cls.return_value.get.return_value = {"queries": []}
        result = runner.invoke(app, ["sql", "history"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_with_operation(self, mock_cls):
        mock_cls.return_value.get.return_value = {"queries": []}
        result = runner.invoke(app, ["sql", "history", "--operation", "SELECT"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_history_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["sql", "history"])
        assert result.exit_code != 0


class TestSqlStats:
    @patch(MOCK_CLIENT)
    def test_stats_table(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "operations": {
                "SELECT": {
                    "count": 100,
                    "avg_execution_time_ms": 15.5,
                    "success_rate": 99.0,
                },
                "INSERT": {
                    "count": 10,
                    "avg_execution_time_ms": 20.0,
                    "success_rate": 80.0,
                },
                "DELETE": {
                    "count": 5,
                    "avg_execution_time_ms": 10.0,
                    "success_rate": 70.0,
                },
            },
            "performance": {
                "total_queries": 115,
                "avg_execution_time_ms": 15.0,
                "total_rows": 5000,
            },
            "rate_limit": {
                "SELECT": {"remaining": 900, "limit": 1000},
                "INSERT": {"remaining": 50, "limit": 100},
                "DELETE": {"remaining": 5, "limit": 100},
            },
        }
        result = runner.invoke(app, ["sql", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_json(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(app, ["sql", "stats", "--format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_yaml(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(app, ["sql", "stats", "--format", "yaml"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_minimal(self, mock_cls):
        mock_cls.return_value.get.return_value = {}
        result = runner.invoke(app, ["sql", "stats"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_stats_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["sql", "stats"])
        assert result.exit_code != 0
