"""Tests for system commands."""

from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app

runner = CliRunner()

MOCK_CLIENT = "virtualdojo.commands.system.SyncVirtualDojoClient"


class TestHealthCheck:
    @patch(MOCK_CLIENT)
    def test_healthy(self, mock_cls):
        mock_cls.return_value.get.return_value = {"status": "healthy"}
        result = runner.invoke(app, ["system", "health"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_unhealthy(self, mock_cls):
        mock_cls.return_value.get.return_value = {"status": "degraded"}
        result = runner.invoke(app, ["system", "health"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_verbose(self, mock_cls):
        mock_cls.return_value.get.side_effect = [
            {"status": "healthy", "uptime": "10h"},
            {
                "status": "healthy",
                "database": "pg",
                "connection_pool": {"size": 10, "checked_out": 2},
            },
        ]
        result = runner.invoke(app, ["system", "health", "--verbose"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_verbose_db_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = [
            {"status": "healthy"},
            RuntimeError("db error"),
        ]
        result = runner.invoke(app, ["system", "health", "--verbose"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_health_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["system", "health"])
        assert result.exit_code != 0


class TestSystemInfo:
    @patch(MOCK_CLIENT)
    def test_info_success(self, mock_cls):
        mock_cls.return_value.get.return_value = {
            "status": "healthy",
            "version": "1.0.0",
            "environment": "production",
            "uptime": "10h",
        }
        result = runner.invoke(app, ["system", "info"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_info_minimal(self, mock_cls):
        mock_cls.return_value.get.return_value = {"status": "healthy"}
        result = runner.invoke(app, ["system", "info"])
        assert result.exit_code == 0

    @patch(MOCK_CLIENT)
    def test_info_error(self, mock_cls):
        mock_cls.return_value.get.side_effect = RuntimeError("fail")
        result = runner.invoke(app, ["system", "info"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_info_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Unauthorized"
        err.hint = "Login first"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["system", "info"])
        assert result.exit_code != 0


class TestHealthErrorBranches:
    @patch(MOCK_CLIENT)
    def test_health_error_with_message(self, mock_cls):
        err = RuntimeError()
        err.message = "Error"
        err.hint = "hint"
        mock_cls.return_value.get.side_effect = err
        result = runner.invoke(app, ["system", "health"])
        assert result.exit_code != 0

    @patch(MOCK_CLIENT)
    def test_health_verbose_db_error(self, mock_cls):
        """Verbose health check where DB health fails."""
        mock_cls.return_value.get.side_effect = [
            {"status": "healthy", "version": "1.0"},
            Exception("db unreachable"),
        ]
        result = runner.invoke(app, ["system", "health", "--verbose"])
        assert result.exit_code == 0
