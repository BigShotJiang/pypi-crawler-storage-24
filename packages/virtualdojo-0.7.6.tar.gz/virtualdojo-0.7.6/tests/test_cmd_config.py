"""Tests for config commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.config import Config, Profile

runner = CliRunner()

MOCK_CM = "virtualdojo.commands.config.config_manager"


class TestShowConfig:
    @patch(MOCK_CM)
    @patch("virtualdojo.commands.config.get_config_file")
    @patch("virtualdojo.commands.config.get_config_dir")
    def test_show_with_profiles(self, mock_dir, mock_file, mock_cm):
        mock_dir.return_value = "/tmp/cfg"
        mock_file.return_value = "/tmp/cfg/config.toml"
        config = Config(
            default_profile="test",
            profiles={"test": Profile(name="test", server="https://x.com", tenant="t")},
        )
        mock_cm.config = config
        mock_cm.has_credentials.return_value = True
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    @patch("virtualdojo.commands.config.get_config_file")
    @patch("virtualdojo.commands.config.get_config_dir")
    def test_show_no_profiles(self, mock_dir, mock_file, mock_cm):
        mock_dir.return_value = "/tmp/cfg"
        mock_file.return_value = "/tmp/cfg/config.toml"
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0


class TestGetSetting:
    @patch(MOCK_CM)
    def test_get_default_profile(self, mock_cm):
        mock_cm.config = Config(default_profile="test")
        result = runner.invoke(app, ["config", "get", "default_profile"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_get_default_profile_none(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "get", "default_profile"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_get_output_format(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "get", "output_format"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_get_default_limit(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "get", "default_limit"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_get_unknown(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "get", "unknown_key"])
        assert result.exit_code != 0


class TestSetSetting:
    @patch(MOCK_CM)
    def test_set_default_profile(self, mock_cm):
        mock_cm.config = Config(
            profiles={"test": Profile(name="test", server="s", tenant="t")}
        )
        mock_cm.save_config = MagicMock()
        result = runner.invoke(app, ["config", "set", "default_profile", "test"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_set_default_profile_not_found(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "set", "default_profile", "missing"])
        assert result.exit_code != 0

    @patch(MOCK_CM)
    def test_set_output_format(self, mock_cm):
        mock_cm.config = Config()
        mock_cm.save_config = MagicMock()
        result = runner.invoke(app, ["config", "set", "output_format", "json"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_set_output_format_invalid(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "set", "output_format", "xml"])
        assert result.exit_code != 0

    @patch(MOCK_CM)
    def test_set_default_limit(self, mock_cm):
        mock_cm.config = Config()
        mock_cm.save_config = MagicMock()
        result = runner.invoke(app, ["config", "set", "default_limit", "50"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_set_default_limit_invalid(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "set", "default_limit", "abc"])
        assert result.exit_code != 0

    @patch(MOCK_CM)
    def test_set_unknown(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "set", "unknown_key", "val"])
        assert result.exit_code != 0


class TestProfileList:
    @patch(MOCK_CM)
    def test_list_profiles(self, mock_cm):
        mock_cm.list_profiles.return_value = [
            Profile(name="test", server="https://x.com", tenant="t"),
        ]
        mock_cm.config = Config(default_profile="test")
        mock_cm.has_credentials.return_value = True
        result = runner.invoke(app, ["config", "profile", "list"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_list_profiles_empty(self, mock_cm):
        mock_cm.list_profiles.return_value = []
        result = runner.invoke(app, ["config", "profile", "list"])
        assert result.exit_code == 0


class TestProfileAdd:
    @patch(MOCK_CM)
    def test_add_profile(self, mock_cm):
        mock_cm.config = Config()
        mock_cm.add_profile = MagicMock()
        result = runner.invoke(
            app,
            [
                "config",
                "profile",
                "add",
                "test",
                "--server",
                "https://x.com",
                "--tenant",
                "t1",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_add_profile_default(self, mock_cm):
        mock_cm.config = Config()
        mock_cm.add_profile = MagicMock()
        result = runner.invoke(
            app,
            [
                "config",
                "profile",
                "add",
                "test",
                "--server",
                "https://x.com",
                "--tenant",
                "t1",
                "--default",
            ],
        )
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_add_profile_exists(self, mock_cm):
        mock_cm.config = Config(
            profiles={"test": Profile(name="test", server="s", tenant="t")}
        )
        mock_cm.add_profile = MagicMock()
        result = runner.invoke(
            app,
            [
                "config",
                "profile",
                "add",
                "test",
                "--server",
                "https://x.com",
                "--tenant",
                "t1",
            ],
        )
        assert result.exit_code == 0


class TestProfileRemove:
    @patch(MOCK_CM)
    def test_remove_force(self, mock_cm):
        mock_cm.config = Config(
            profiles={"test": Profile(name="test", server="s", tenant="t")}
        )
        mock_cm.remove_profile = MagicMock()
        result = runner.invoke(app, ["config", "profile", "remove", "test", "--force"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_remove_not_found(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(
            app, ["config", "profile", "remove", "missing", "--force"]
        )
        assert result.exit_code != 0

    @patch(MOCK_CM)
    def test_remove_abort(self, mock_cm):
        mock_cm.config = Config(
            profiles={"test": Profile(name="test", server="s", tenant="t")}
        )
        runner.invoke(app, ["config", "profile", "remove", "test"], input="n\n")


class TestProfileUse:
    @patch(MOCK_CM)
    def test_use_profile(self, mock_cm):
        mock_cm.config = Config(
            profiles={"test": Profile(name="test", server="s", tenant="t")}
        )
        mock_cm.set_default_profile = MagicMock()
        result = runner.invoke(app, ["config", "profile", "use", "test"])
        assert result.exit_code == 0

    @patch(MOCK_CM)
    def test_use_profile_not_found(self, mock_cm):
        mock_cm.config = Config()
        result = runner.invoke(app, ["config", "profile", "use", "missing"])
        assert result.exit_code != 0
