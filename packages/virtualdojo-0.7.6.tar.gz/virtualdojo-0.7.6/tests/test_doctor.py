"""Tests for the doctor command."""

import time
from unittest.mock import patch

from typer.testing import CliRunner

from virtualdojo.cli import app
from virtualdojo.config import Credentials, Profile
from virtualdojo.exceptions import NetworkError, ProfileNotFoundError

runner = CliRunner()


def _mock_profile():
    return Profile(name="default", server="https://app.virtualdojo.com", tenant="t1")


def _mock_creds(**kwargs):
    defaults = {
        "profile_name": "default",
        "token": "tok123",
        "token_type": "jwt",
        "expires_at": time.time() + 3600,
    }
    defaults.update(kwargs)
    return Credentials(**defaults)


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_all_ok(mock_profile, mock_creds, mock_client_cls):
    """Doctor passes when everything is healthy."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {"content-type": "application/json", "x-request-id": "abc123"},
        '{"status": "healthy", "version": "1.2.3"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "All checks passed" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_shows_profile_info(mock_profile, mock_creds, mock_client_cls):
    """Doctor displays profile, server, and tenant."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {"content-type": "application/json"},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert "default" in result.stdout
    assert "app.virtualdojo.com" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_server_version(mock_profile, mock_creds, mock_client_cls):
    """Doctor shows server version from health response."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {"content-type": "application/json"},
        '{"status": "healthy", "version": "2.0.0"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert "2.0.0" in result.stdout


# ---------------------------------------------------------------------------
# Profile failures
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_no_profile(mock_profile):
    """Doctor fails gracefully when no profile exists."""
    mock_profile.side_effect = ProfileNotFoundError("default")
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "not found" in result.stdout


# ---------------------------------------------------------------------------
# Auth failures
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_not_logged_in(mock_profile, mock_creds, mock_client_cls):
    """Doctor reports when not logged in."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = None
    # Still need connectivity check to not crash
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "Not logged in" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_token_expired(mock_profile, mock_creds, mock_client_cls):
    """Doctor reports expired token."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds(expires_at=time.time() - 60)
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "Expired" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_token_expiring_soon(mock_profile, mock_creds, mock_client_cls):
    """Doctor warns when token is expiring soon (<5 min)."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds(expires_at=time.time() + 120)
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor"])
    # Token expiring soon is a warning, not a failure
    assert result.exit_code == 0
    assert "Expires in" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_api_key_no_expiry(mock_profile, mock_creds, mock_client_cls):
    """Doctor shows API key with no expiry."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds(token_type="api_key", expires_at=None)
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "API key" in result.stdout


# ---------------------------------------------------------------------------
# Connectivity failures
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_connectivity_failure(mock_profile, mock_creds, mock_client_cls):
    """Doctor reports connectivity failure."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.side_effect = NetworkError(
        "Could not connect"
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "Could not connect" in result.stdout


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_server_error(mock_profile, mock_creds, mock_client_cls):
    """Doctor reports non-200 health check."""
    mock_profile.return_value = _mock_profile()
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.return_value = (
        503,
        {},
        "Service Unavailable",
    )
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "503" in result.stdout


# ---------------------------------------------------------------------------
# Profile flag passthrough
# ---------------------------------------------------------------------------


@patch("virtualdojo.commands.doctor.SyncVirtualDojoClient")
@patch("virtualdojo.commands.doctor.get_current_credentials")
@patch("virtualdojo.commands.doctor.get_current_profile")
def test_doctor_with_profile(mock_profile, mock_creds, mock_client_cls):
    """--profile flag is forwarded."""
    mock_profile.return_value = Profile(
        name="staging", server="https://staging.virtualdojo.com", tenant="s1"
    )
    mock_creds.return_value = _mock_creds()
    mock_client_cls.return_value.raw_request.return_value = (
        200,
        {},
        '{"status": "healthy"}',
    )
    result = runner.invoke(app, ["doctor", "-p", "staging"])
    assert result.exit_code == 0
    mock_profile.assert_called_once_with("staging")
