"""Tests for version check utility."""

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

from virtualdojo.utils.version_check import (
    _fetch_latest_version,
    _parse_version,
    _read_cache,
    _write_cache,
    check_for_updates,
    get_update_message,
)


class TestParseVersion:
    def test_simple(self):
        assert _parse_version("1.2.3") == (1, 2, 3)

    def test_prerelease_alpha(self):
        assert _parse_version("1.0.0a1") == (1, 0, 0)

    def test_prerelease_beta(self):
        assert _parse_version("1.0.0b2") == (1, 0, 0)

    def test_prerelease_rc(self):
        assert _parse_version("1.0.0rc1") == (1, 0, 0)

    def test_invalid(self):
        assert _parse_version("invalid") == (0, 0, 0)


class TestReadWriteCache:
    def test_write_and_read(self, tmp_path):
        with patch(
            "virtualdojo.utils.version_check._get_cache_path",
            return_value=tmp_path / "cache.json",
        ):
            _write_cache("1.0.0")
            result = _read_cache()
            assert result is not None
            assert result["latest_version"] == "1.0.0"

    def test_read_no_cache(self, tmp_path):
        with patch(
            "virtualdojo.utils.version_check._get_cache_path",
            return_value=tmp_path / "nonexistent.json",
        ):
            assert _read_cache() is None

    def test_read_expired_cache(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        # Write cache with old timestamp
        with open(cache_file, "w") as f:
            json.dump(
                {"latest_version": "1.0.0", "checked_at": time.time() - 100000}, f
            )
        with patch(
            "virtualdojo.utils.version_check._get_cache_path",
            return_value=cache_file,
        ):
            assert _read_cache() is None

    def test_read_corrupt_cache(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        cache_file.write_text("not json")
        with patch(
            "virtualdojo.utils.version_check._get_cache_path",
            return_value=cache_file,
        ):
            assert _read_cache() is None

    def test_write_cache_failure(self, tmp_path):
        with patch(
            "virtualdojo.utils.version_check._get_cache_path",
            return_value=Path("/nonexistent/dir/cache.json"),
        ):
            # Should not raise
            _write_cache("1.0.0")


class TestFetchLatestVersion:
    def test_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"info": {"version": "2.0.0"}}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response

        with patch(
            "virtualdojo.utils.version_check.httpx.Client", return_value=mock_client
        ):
            assert _fetch_latest_version() == "2.0.0"

    def test_non_200(self):
        mock_response = MagicMock()
        mock_response.status_code = 404

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response

        with patch(
            "virtualdojo.utils.version_check.httpx.Client", return_value=mock_client
        ):
            assert _fetch_latest_version() is None

    def test_network_error(self):
        with patch(
            "virtualdojo.utils.version_check.httpx.Client",
            side_effect=Exception("network error"),
        ):
            assert _fetch_latest_version() is None


class TestCheckForUpdates:
    def test_update_available_from_cache(self):
        with patch(
            "virtualdojo.utils.version_check._read_cache",
            return_value={"latest_version": "99.0.0"},
        ):
            result = check_for_updates()
            assert result is not None
            assert result[1] == "99.0.0"

    def test_no_update(self):
        with patch(
            "virtualdojo.utils.version_check._read_cache",
            return_value={"latest_version": "0.0.1"},
        ):
            assert check_for_updates() is None

    def test_fetch_when_no_cache(self):
        with (
            patch("virtualdojo.utils.version_check._read_cache", return_value=None),
            patch(
                "virtualdojo.utils.version_check._fetch_latest_version",
                return_value="99.0.0",
            ),
            patch("virtualdojo.utils.version_check._write_cache"),
        ):
            result = check_for_updates()
            assert result is not None

    def test_fetch_fails(self):
        with (
            patch("virtualdojo.utils.version_check._read_cache", return_value=None),
            patch(
                "virtualdojo.utils.version_check._fetch_latest_version",
                return_value=None,
            ),
        ):
            assert check_for_updates() is None


class TestGetUpdateMessage:
    def test_update_available(self):
        with patch(
            "virtualdojo.utils.version_check.check_for_updates",
            return_value=("0.1.0", "2.0.0"),
        ):
            msg = get_update_message()
            assert msg is not None
            assert "2.0.0" in msg

    def test_no_update(self):
        with patch(
            "virtualdojo.utils.version_check.check_for_updates",
            return_value=None,
        ):
            assert get_update_message() is None
