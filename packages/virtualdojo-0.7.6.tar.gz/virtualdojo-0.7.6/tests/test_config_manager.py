"""Tests for config management."""

from unittest.mock import MagicMock, patch

import pytest

from virtualdojo.config import (
    Config,
    ConfigManager,
    Credentials,
    Profile,
    get_config_dir,
    get_config_file,
    get_credentials_file,
    get_current_credentials,
    get_current_profile,
)
from virtualdojo.exceptions import ConfigurationError, ProfileNotFoundError


class TestHelpers:
    def test_get_config_dir(self, tmp_path):
        with patch(
            "virtualdojo.config.platformdirs.user_config_dir",
            return_value=str(tmp_path / "cfg"),
        ):
            result = get_config_dir()
            assert result.exists()

    def test_get_config_file(self, tmp_path):
        with patch("virtualdojo.config.get_config_dir", return_value=tmp_path):
            assert get_config_file() == tmp_path / "config.toml"

    def test_get_credentials_file(self, tmp_path):
        with patch("virtualdojo.config.get_config_dir", return_value=tmp_path):
            assert get_credentials_file() == tmp_path / "credentials.toml"


class TestModels:
    def test_profile(self):
        p = Profile(name="test", server="https://example.com", tenant="t1")
        assert p.default_limit == 100
        assert p.output_format == "table"

    def test_credentials(self):
        c = Credentials(profile_name="test")
        assert c.token_type == "jwt"
        assert c.token is None

    def test_config(self):
        c = Config()
        assert c.default_profile is None
        assert c.profiles == {}


class TestConfigManager:
    def _make_manager(self, tmp_path):
        """Create a ConfigManager with temp paths."""
        cm = ConfigManager()
        cm._config = Config()
        return cm

    def test_config_property_loads(self, tmp_path):
        cm = ConfigManager()
        with patch.object(cm, "_load_config") as mock_load:
            mock_load.side_effect = lambda: setattr(cm, "_config", Config())
            _ = cm.config
            mock_load.assert_called_once()

    def test_config_property_cached(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        # Should not call _load_config again
        _ = cm.config
        assert cm._config is not None

    def test_load_config_no_file(self, tmp_path):
        cm = ConfigManager()
        with patch(
            "virtualdojo.config.get_config_file",
            return_value=tmp_path / "nonexistent.toml",
        ):
            cm._load_config()
            assert cm._config is not None
            assert cm._config.profiles == {}

    def test_load_config_with_file(self, tmp_path):
        import tomli_w

        config_file = tmp_path / "config.toml"
        data = {
            "default_profile": "test",
            "output_format": "json",
            "default_limit": 50,
            "profiles": {"test": {"server": "https://example.com", "tenant": "t1"}},
        }
        with open(config_file, "wb") as f:
            tomli_w.dump(data, f)

        cm = ConfigManager()
        with patch("virtualdojo.config.get_config_file", return_value=config_file):
            cm._load_config()
            assert cm._config.default_profile == "test"
            assert "test" in cm._config.profiles
            assert cm._config.profiles["test"].server == "https://example.com"

    def test_save_config(self, tmp_path):
        config_file = tmp_path / "config.toml"
        cm = ConfigManager()
        cm._config = Config(
            default_profile="test",
            profiles={
                "test": Profile(name="test", server="https://example.com", tenant="t1")
            },
        )
        with patch("virtualdojo.config.get_config_file", return_value=config_file):
            cm.save_config()
            assert config_file.exists()

    def test_get_profile_default(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["default"] = Profile(
            name="default", server="https://example.com", tenant="t1"
        )
        cm._config.default_profile = "default"
        assert cm.get_profile().name == "default"

    def test_get_profile_by_name(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["test"] = Profile(
            name="test", server="https://example.com", tenant="t1"
        )
        assert cm.get_profile("test").name == "test"

    def test_get_profile_no_default(self, tmp_path):
        cm = self._make_manager(tmp_path)
        with pytest.raises(ConfigurationError):
            cm.get_profile()

    def test_get_profile_not_found(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.default_profile = "nonexistent"
        with pytest.raises(ProfileNotFoundError):
            cm.get_profile()

    def test_add_profile(self, tmp_path):
        cm = self._make_manager(tmp_path)
        with patch.object(cm, "save_config"):
            p = Profile(name="new", server="https://example.com", tenant="t1")
            cm.add_profile(p)
            assert "new" in cm._config.profiles
            assert cm._config.default_profile == "new"

    def test_add_profile_set_default(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.default_profile = "existing"
        with patch.object(cm, "save_config"):
            p = Profile(name="new", server="https://example.com", tenant="t1")
            cm.add_profile(p, set_default=True)
            assert cm._config.default_profile == "new"

    def test_add_profile_keeps_default(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.default_profile = "existing"
        cm._config.profiles["existing"] = Profile(
            name="existing", server="https://example.com", tenant="t1"
        )
        with patch.object(cm, "save_config"):
            p = Profile(name="new", server="https://example.com", tenant="t1")
            cm.add_profile(p, set_default=False)
            assert cm._config.default_profile == "existing"

    def test_remove_profile(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["test"] = Profile(
            name="test", server="https://example.com", tenant="t1"
        )
        cm._config.default_profile = "test"
        with patch.object(cm, "save_config"), patch.object(cm, "remove_credentials"):
            cm.remove_profile("test")
            assert "test" not in cm._config.profiles
            assert cm._config.default_profile is None

    def test_remove_profile_switches_default(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["a"] = Profile(
            name="a", server="https://example.com", tenant="t1"
        )
        cm._config.profiles["b"] = Profile(
            name="b", server="https://example.com", tenant="t1"
        )
        cm._config.default_profile = "a"
        with patch.object(cm, "save_config"), patch.object(cm, "remove_credentials"):
            cm.remove_profile("a")
            assert cm._config.default_profile == "b"

    def test_remove_profile_not_found(self, tmp_path):
        cm = self._make_manager(tmp_path)
        with pytest.raises(ProfileNotFoundError):
            cm.remove_profile("nonexistent")

    def test_set_default_profile(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["test"] = Profile(
            name="test", server="https://example.com", tenant="t1"
        )
        with patch.object(cm, "save_config"):
            cm.set_default_profile("test")
            assert cm._config.default_profile == "test"

    def test_set_default_profile_not_found(self, tmp_path):
        cm = self._make_manager(tmp_path)
        with pytest.raises(ProfileNotFoundError):
            cm.set_default_profile("nonexistent")

    def test_list_profiles(self, tmp_path):
        cm = self._make_manager(tmp_path)
        cm._config.profiles["a"] = Profile(name="a", server="s", tenant="t")
        cm._config.profiles["b"] = Profile(name="b", server="s", tenant="t")
        assert len(cm.list_profiles()) == 2


class TestCredentials:
    def test_save_and_get_credentials(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        creds_file = tmp_path / "credentials.toml"

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
        ):
            # Keyring available
            mock_keyring.set_password = MagicMock()
            mock_keyring.get_password = MagicMock(return_value="token123")

            creds = Credentials(
                profile_name="test",
                token="token123",
                refresh_token="refresh123",
                user_email="a@b.com",
                user_id="u1",
                expires_at=9999999999.0,
            )
            cm.save_credentials(creds)

            # Reset to force reload
            cm._credentials = {}
            result = cm.get_credentials("test")
            assert result is not None

    def test_get_credentials_empty(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        with patch(
            "virtualdojo.config.get_credentials_file",
            return_value=tmp_path / "nonexistent.toml",
        ):
            result = cm.get_credentials("test")
            assert result is None

    def test_has_credentials(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        cm._credentials = {
            "test": Credentials(profile_name="test", token="tok"),
            "empty": Credentials(profile_name="empty"),
        }
        assert cm.has_credentials("test") is True
        assert cm.has_credentials("empty") is False
        assert cm.has_credentials("nonexistent") is False

    def test_remove_credentials(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        cm._credentials = {"test": Credentials(profile_name="test", token="tok")}
        creds_file = tmp_path / "credentials.toml"

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
        ):
            mock_keyring.delete_password = MagicMock()
            mock_keyring.set_password = MagicMock()
            mock_keyring.get_password = MagicMock(return_value=None)
            cm.remove_credentials("test")
            assert "test" not in cm._credentials

    def test_remove_credentials_nonexistent(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        cm._credentials = {}
        creds_file = tmp_path / "credentials.toml"
        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring"),
        ):
            cm.remove_credentials("nonexistent")

    def test_save_credentials_no_keyring(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        creds_file = tmp_path / "credentials.toml"

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
        ):
            mock_keyring.set_password = MagicMock(side_effect=Exception("no keyring"))
            mock_keyring.get_password = MagicMock(side_effect=Exception("no keyring"))

            creds = Credentials(
                profile_name="test",
                token="token123",
                refresh_token="refresh123",
            )
            cm.save_credentials(creds)
            assert creds_file.exists()

    def test_load_credentials_with_keyring(self, tmp_path):
        import tomli_w

        creds_file = tmp_path / "credentials.toml"
        data = {
            "credentials": {
                "test": {
                    "token_type": "jwt",
                    "uses_keyring": True,
                    "user_email": "a@b.com",
                }
            }
        }
        with open(creds_file, "wb") as f:
            tomli_w.dump(data, f)

        cm = ConfigManager()
        cm._config = Config()

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
        ):
            mock_keyring.get_password = MagicMock(
                side_effect=lambda svc, key: "token123" if "token" in key else None
            )
            cm._load_credentials()
            assert "test" in cm._credentials
            assert cm._credentials["test"].token == "token123"

    def test_load_credentials_keyring_error(self, tmp_path):
        import tomli_w

        creds_file = tmp_path / "credentials.toml"
        data = {
            "credentials": {
                "test": {
                    "token_type": "jwt",
                    "uses_keyring": True,
                }
            }
        }
        with open(creds_file, "wb") as f:
            tomli_w.dump(data, f)

        cm = ConfigManager()
        cm._config = Config()

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
        ):
            mock_keyring.get_password = MagicMock(side_effect=Exception("locked"))
            cm._load_credentials()
            assert "test" in cm._credentials

    def test_save_credentials_os_open_fallback(self, tmp_path):
        cm = ConfigManager()
        cm._config = Config()
        creds_file = tmp_path / "credentials.toml"

        with (
            patch("virtualdojo.config.get_credentials_file", return_value=creds_file),
            patch("virtualdojo.config.keyring") as mock_keyring,
            patch("os.open", side_effect=OSError("mock")),
        ):
            mock_keyring.set_password = MagicMock(side_effect=Exception("no keyring"))
            mock_keyring.get_password = MagicMock(side_effect=Exception("no keyring"))

            creds = Credentials(profile_name="test", token="tok")
            cm.save_credentials(creds)
            assert creds_file.exists()


class TestGlobalHelpers:
    def test_get_current_profile(self):
        with patch("virtualdojo.config.config_manager") as mock_cm:
            mock_cm.get_profile.return_value = Profile(
                name="test", server="s", tenant="t"
            )
            result = get_current_profile("test")
            assert result.name == "test"

    def test_get_current_credentials(self):
        with patch("virtualdojo.config.config_manager") as mock_cm:
            mock_cm.get_profile.return_value = Profile(
                name="test", server="s", tenant="t"
            )
            mock_cm.get_credentials.return_value = Credentials(
                profile_name="test", token="tok"
            )
            result = get_current_credentials("test")
            assert result.token == "tok"
