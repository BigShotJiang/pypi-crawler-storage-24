"""Diagnostic command for VirtualDojo CLI."""

import time

import typer

from .. import __version__
from ..client import SyncVirtualDojoClient
from ..config import get_config_dir, get_current_credentials, get_current_profile
from ..exceptions import VirtualDojoError
from ..utils.output import console


def doctor(profile: str | None = None) -> None:
    """Run all-in-one diagnostics: config, auth, connectivity, server version."""
    console.print(
        f"\n[bold cyan]VirtualDojo Doctor[/bold cyan]  (CLI v{__version__})\n"
    )
    all_ok = True

    # --- 1. Config ---
    config_dir = get_config_dir()
    console.print(f"  Config dir: {config_dir}")
    try:
        prof = get_current_profile(profile)
        console.print(f"  [green]✓[/green] Profile: {prof.name}")
        console.print(f"  [green]✓[/green] Server:  {prof.server}")
        console.print(f"  [green]✓[/green] Tenant:  {prof.tenant}")
    except VirtualDojoError as e:
        console.print(f"  [red]✗[/red] Profile: {e.message}")
        if e.hint:
            console.print(f"    [dim]{e.hint}[/dim]")
        all_ok = False
        # Can't continue without a profile
        _print_summary(all_ok)
        return

    # --- 2. Auth ---
    try:
        creds = get_current_credentials(prof.name)
        if creds is None or creds.token is None:
            console.print("  [red]✗[/red] Auth: Not logged in")
            console.print("    [dim]Run 'vdojo login' to authenticate.[/dim]")
            all_ok = False
        else:
            console.print(f"  [green]✓[/green] Auth: {creds.token_type or 'token'}")
            # Check token expiry
            if creds.expires_at is not None:
                remaining = creds.expires_at - time.time()
                if remaining <= 0:
                    console.print("  [red]✗[/red] Token: Expired")
                    console.print("    [dim]Run 'vdojo login' to refresh.[/dim]")
                    all_ok = False
                elif remaining < 300:
                    mins = int(remaining / 60)
                    console.print(f"  [yellow]![/yellow] Token: Expires in {mins}m")
                else:
                    mins = int(remaining / 60)
                    console.print(
                        f"  [green]✓[/green] Token: Valid ({mins}m remaining)"
                    )
            else:
                console.print("  [green]✓[/green] Token: No expiry (API key)")
    except VirtualDojoError as e:
        console.print(f"  [red]✗[/red] Auth: {e.message}")
        all_ok = False

    # --- 3. Connectivity ---

    try:
        client = SyncVirtualDojoClient(profile)
        start = time.monotonic()
        status_code, headers, body = client.raw_request("GET", "/health")
        elapsed = (time.monotonic() - start) * 1000

        if status_code == 200:
            console.print(f"  [green]✓[/green] Connectivity: OK ({elapsed:.0f}ms)")
        else:
            console.print(
                f"  [yellow]![/yellow] Connectivity: HTTP {status_code} ({elapsed:.0f}ms)"
            )
            all_ok = False

        # Parse server version from health response
        try:
            import json

            health = json.loads(body)
            server_version = health.get("version", "unknown")
            console.print(f"  [green]✓[/green] Server version: {server_version}")
        except Exception:
            console.print("  [dim]-[/dim] Server version: unknown")

        # Check request ID support
        req_id = headers.get("x-request-id")
        if req_id:
            console.print("  [green]✓[/green] Request tracing: supported")
        else:
            console.print("  [dim]-[/dim] Request tracing: not returned by server")

    except VirtualDojoError as e:
        console.print(f"  [red]✗[/red] Connectivity: {e.message}")
        if e.hint:
            console.print(f"    [dim]{e.hint}[/dim]")
        all_ok = False

    _print_summary(all_ok)


def _print_summary(all_ok: bool) -> None:
    """Print the final summary line."""
    if all_ok:
        console.print("\n  [bold green]All checks passed.[/bold green]\n")
    else:
        console.print(
            "\n  [bold yellow]Some checks failed. See above for details.[/bold yellow]\n"
        )
        raise typer.Exit(1)
