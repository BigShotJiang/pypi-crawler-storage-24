"""Generic API command for VirtualDojo CLI."""

import json
import sys
import time
from urllib.parse import urlparse

import typer

from ..client import SyncVirtualDojoClient
from ..utils.output import print_error, print_raw_json

app = typer.Typer(help="Make raw API requests", no_args_is_help=True)


def _validate_path(path: str) -> str:
    """Validate that the path is relative and safe (no SSRF)."""
    parsed = urlparse(path)
    if parsed.scheme or parsed.netloc:
        print_error(
            "Absolute URLs are not allowed. Use a relative path like /api/v1/...",
            hint="The request is always sent to your configured server.",
        )
        raise typer.Exit(1)
    # Ensure leading slash
    if not path.startswith("/"):
        path = "/" + path
    return path


def _parse_json_data(data: str | None) -> dict | None:
    """Parse a JSON string into a dict."""
    if data is None:
        return None
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON data: {e}")
        raise typer.Exit(1) from None
    if not isinstance(parsed, dict):
        print_error("JSON data must be an object (not an array or scalar).")
        raise typer.Exit(1)
    return parsed


def _print_raw_response(status_code: int, headers: dict[str, str], body: str) -> None:
    """Print raw HTTP response details.

    Status line and content-type go to stderr so stdout stays pipeable.
    """
    content_type = headers.get("content-type", "unknown")
    print(f"HTTP {status_code}  {content_type}", file=sys.stderr)
    print(body)


def _print_verbose(info: dict) -> None:
    """Print verbose request/response details to stderr."""
    err = sys.stderr

    # Request
    print(f"> {info['request_method']} {info['request_url']}", file=err)
    for key, value in info.get("request_headers", {}).items():
        print(f"> {key}: {value}", file=err)
    if info.get("request_body"):
        print(f"> Body: {json.dumps(info['request_body'])}", file=err)
    print(">", file=err)

    # Response
    print(f"< HTTP {info['status_code']}", file=err)
    for key, value in info.get("response_headers", {}).items():
        print(f"< {key}: {value}", file=err)
    print(f"< Elapsed: {info['elapsed_ms']}ms", file=err)
    print("<", file=err)

    # Body to stdout
    print(info.get("response_body", ""))


def _do_request(
    method: str,
    path: str,
    *,
    profile: str | None = None,
    body: dict | None = None,
    raw: bool = False,
    verbose: bool = False,
) -> None:
    """Execute an API request with shared error handling."""
    path = _validate_path(path)
    try:
        client = SyncVirtualDojoClient(profile)
        if verbose:
            info = client.verbose_request(method, path, data=body)
            _print_verbose(info)
        elif raw:
            status_code, headers, body_text = client.raw_request(
                method, path, data=body
            )
            _print_raw_response(status_code, headers, body_text)
        else:
            start = time.monotonic()
            result = (
                getattr(client, method.lower())(path)
                if body is None
                else getattr(client, method.lower())(path, body)
            )
            elapsed = (time.monotonic() - start) * 1000
            print_raw_json(result)
            sys.stdout.flush()
            print(f"Elapsed: {elapsed:.0f}ms", file=sys.stderr)
    except Exception as e:
        if hasattr(e, "message"):
            print_error(e.message, getattr(e, "hint", None))
        else:
            print_error(str(e))
        raise typer.Exit(1) from None


@app.command("get")
def api_get(
    path: str = typer.Argument(help="API path, e.g. /api/v1/health"),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Print raw response without JSON parsing"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show request/response headers and timing"
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a GET request to the VirtualDojo API.

    Query parameters can be included in the path.

    Examples:
        vdojo api get /api/v1/health
        vdojo api get --raw /admin/tenant-administration/
        vdojo api get -v /api/v1/health
    """
    _do_request("GET", path, profile=profile, raw=raw, verbose=verbose)


@app.command("post")
def api_post(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Print raw response without JSON parsing"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show request/response headers and timing"
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a POST request to the VirtualDojo API.

    Examples:
        vdojo api post /api/v1/some-endpoint -d '{"name": "test"}'
    """
    body = _parse_json_data(data)
    _do_request("POST", path, profile=profile, body=body, raw=raw, verbose=verbose)


@app.command("put")
def api_put(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Print raw response without JSON parsing"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show request/response headers and timing"
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a PUT request to the VirtualDojo API.

    Examples:
        vdojo api put /api/v1/some-endpoint/123 -d '{"name": "updated"}'
    """
    body = _parse_json_data(data)
    _do_request("PUT", path, profile=profile, body=body, raw=raw, verbose=verbose)


@app.command("patch")
def api_patch(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help='JSON body, e.g. \'{"key": "value"}\''
    ),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Print raw response without JSON parsing"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show request/response headers and timing"
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a PATCH request to the VirtualDojo API.

    Examples:
        vdojo api patch /api/v1/some-endpoint/123 -d '{"status": "active"}'
    """
    body = _parse_json_data(data)
    _do_request("PATCH", path, profile=profile, body=body, raw=raw, verbose=verbose)


@app.command("delete")
def api_delete(
    path: str = typer.Argument(help="API path"),
    data: str | None = typer.Option(
        None, "--data", "-d", help="JSON body, e.g. '{\"ids\": [1, 2, 3]}'"
    ),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Print raw response without JSON parsing"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show request/response headers and timing"
    ),
    profile: str | None = typer.Option(None, "--profile", "-p"),
) -> None:
    """Make a DELETE request to the VirtualDojo API.

    Examples:
        vdojo api delete /api/v1/some-endpoint/123
        vdojo api delete /api/v1/bulk-delete -d '{"ids": [1, 2, 3]}'
    """
    body = _parse_json_data(data)
    _do_request("DELETE", path, profile=profile, body=body, raw=raw, verbose=verbose)
