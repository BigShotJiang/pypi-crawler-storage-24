"""VirtualDojo CLI - Command-line interface for VirtualDojo CRM."""

__version__ = "0.7.6"
__app_name__ = "virtualdojo-cli"

# Default server URL - change this for your deployment
DEFAULT_SERVER_URL = "https://app.virtualdojo.com"

# Common development URLs (for reference)
DEV_URLS = {
    "local": "http://localhost",
    "docker": "http://localhost",
    "dev": "https://dev.virtualdojo.com",
    "development": "https://dev.virtualdojo.com",
    "production": "https://app.virtualdojo.com",
}
