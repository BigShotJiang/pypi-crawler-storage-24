::: textual_timepiece.constants
