# noqa: D100

from __future__ import annotations

__name__ = "textual-timepiece"
__description__ = "Various time related widgets & functionality for Textual."
__url__ = "https://github.com/ddkasa/textual-timepiece"
__author__ = "David Kasakaitis"
__author_email__ = "davidkasakaitis@proton.me"
__version__ = "0.7.0"
__license__ = "MIT"
