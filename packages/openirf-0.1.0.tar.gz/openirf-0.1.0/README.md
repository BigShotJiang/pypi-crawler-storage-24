![OpenIRF Logo](https://gitlab.com/openirf/gitlab-profile/-/raw/main/logo_small.png)

# OpenIRF: An Open-Source Package for Impulse Response Function Estimation

![coverage](https://gitlab.com/OliverZobel/openirf/badges/main/coverage.svg)
[![OpenIRF Build Status](https://app.readthedocs.org/projects/openirf/badge/)](https://openirf.readthedocs.io/)

A collection of tools for the time domain analysis of mechanical systems.

## Installation

To install OpenIRF through pip, use the following command:

`pip install openirf`
