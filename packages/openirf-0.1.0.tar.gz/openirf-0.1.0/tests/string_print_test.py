# Tests for formatted string printing of OpenIRF objects
# Covered functions:
# - NumericalIRF.__str__()
# - NumericalIRF.__repr__()
# - ExperimentalIRF.__str__()
# - ExperimentalIRF.__repr__()

import openirf
import numpy as np
import pytest

# Test Variables
M_test = np.array([[4, 2], [2, 4]])
K_test = np.array([[2, -1], [-1, 2]])
C_test = np.array([[1, -0.5], [-0.5, 1]])
y_test_vec = np.array([[[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]], [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]]])
f_test_vec = np.array(
    [
        [[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]],
        [[2, 3, 2, 0, 0, 0], [-2, -3, -2, 0, 0, 0]],
    ]
)
t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])


def test_printout_of_numerical_IRF_class():
    IRF_ob = openirf.NumericalIRF()  # Create OpenIRF object instance
    assert IRF_ob.__str__() == "==== OpenIRF Numerical IRF Object Summary ====\nM:     None\nC:     None\nK:     None", (
        "Numerical IRF string print has unexpected form/content."
    )
    IRF_ob.add_MCK(M=M_test, K=K_test, C=C_test)
    assert IRF_ob.__str__() == "==== OpenIRF Numerical IRF Object Summary ====\nM:     (2, 2)\nC:     (2, 2)\nK:     (2, 2)", (
        "Numerical IRF string print has unexpected form/content."
    )
    assert IRF_ob.__repr__() == "==== OpenIRF Numerical IRF Object Summary ====\nM:     (2, 2)\nC:     (2, 2)\nK:     (2, 2)", (
        "Numerical IRF string print has unexpected form/content."
    )


def test_printout_of_experimental_IRF_class():
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    assert IRF_ob.__str__() == "==== OpenIRF Experimental IRF Object Summary ====\nt_vec: None\ny_vec: None\nf_vec: None", (
        "Numerical IRF string print has unexpected form/content."
    )
    IRF_ob.add_time_series(y_vec=y_test_vec, f_vec=f_test_vec, t_vec=t_test_vec)
    assert IRF_ob.__str__() == "==== OpenIRF Experimental IRF Object Summary ====\nt_vec: (6,)\ny_vec: (2, 2, 6)\nf_vec: (2, 2, 6)"
    assert IRF_ob.__repr__() == "==== OpenIRF Experimental IRF Object Summary ====\nt_vec: (6,)\ny_vec: (2, 2, 6)\nf_vec: (2, 2, 6)"
