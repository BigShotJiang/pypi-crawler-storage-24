# Tests for importing times series into OpenIRF
# Covered functions:
# - _convert_to_1d_array
# - _convert_to_3d_array
# - add_time_series
# - __init__ (where applicable to time series import)

import openirf
import numpy as np
import pytest


def test_1d_array_shaping():
    # Input: 1D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    test_vec = np.array([1, 2, 3, 4, 5, 6])
    assert IRF_ob._convert_to_3d_array(test_vec).shape == (1, 1, 6), "Time series import: Shaping of 1D array failed."
    assert np.array_equal(IRF_ob._convert_to_3d_array(test_vec), np.array([[[1, 2, 3, 4, 5, 6]]]))


def test_2d_array_shaping():
    # Input: 2D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    test_vec = np.array([[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]])
    assert IRF_ob._convert_to_3d_array(test_vec).shape == (1, 2, 6), "Time series import: Shaping of 2D array failed."
    assert np.array_equal(
        IRF_ob._convert_to_3d_array(test_vec),
        np.array([[[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]]]),
    )


def test_3d_array_shaping():
    # Input: 2D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    test_vec = np.array(
        [
            [[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]],
            [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]],
        ]
    )
    assert IRF_ob._convert_to_3d_array(test_vec).shape == (2, 2, 6), "Time series import: Shaping of 3D array failed."
    assert np.array_equal(
        IRF_ob._convert_to_3d_array(test_vec),
        np.array(
            [
                [[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]],
                [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]],
            ]
        ),
    )


def test_4d_array_rejection():
    # Input: 4D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    test_vec = np.ones([1, 2, 3, 4])
    with pytest.raises(Exception) as exc_info:
        IRF_ob._convert_to_3d_array(test_vec)
    assert exc_info.value.args[0] == "Expected 1D, 2D, or 3D array. Got 4D."
    assert exc_info.type.__name__ == "ValueError"


def test_time_vector_import():
    # Test import of true 1D array
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    IRF_ob = openirf.ExperimentalIRF(t_vec=t_test_vec)  # Create OpenIRF object instance and assign t_vec
    assert IRF_ob.t_vec.shape == (6,)

    # Test import of true 1D array with 2 dimensions
    t_test_vec = np.array([[0, 0.1, 0.2, 0.3, 0.4, 0.5]])
    IRF_ob = openirf.ExperimentalIRF(t_vec=t_test_vec)  # Create OpenIRF object instance and assign t_vec
    assert IRF_ob.t_vec.shape == (6,)

    # Test import of 2D array being rejected
    t_test_vec = np.array([[0, 0.1, 0.2, 0.3, 0.4, 0.5], [0, 0.1, 0.2, 0.3, 0.4, 0.5]])
    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.ExperimentalIRF(t_vec=t_test_vec)  # Create OpenIRF object instance and assign t_vec
    assert exc_info.value.args[0] == "Expected 1D array. Got 2D."
    assert exc_info.type.__name__ == "ValueError"


def test_1d_time_series_import():
    # Input: 1D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec)
    assert IRF_ob.y_vec.shape == (1, 1, 6), "Time series import: Shaping of 1D array 'y_vec' failed."
    assert np.array_equal(IRF_ob.y_vec, np.array([[[1, 2, 3, 4, 5, 6]]])), "Time series import: Shaping of 1D array 'y_vec' changed values within array."
    assert IRF_ob.f_vec.shape == (1, 1, 6), "Time series import: Shaping of 1D array 'f_vec' failed."
    assert np.array_equal(IRF_ob.f_vec, np.array([[[1, 2, 1, 0, 0, 0]]])), "Time series import: Shaping of 1D array 'f_vec' changed values within array."


def test_2d_time_series_import():
    # Input: 1D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array([[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]])
    f_test_vec = np.array([[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec)
    assert IRF_ob.y_vec.shape == (1, 2, 6), "Time series import: Shaping of 1D array 'y_vec' failed."
    assert np.array_equal(IRF_ob.y_vec, np.array([[[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]]])), (
        "Time series import: Shaping of 2D array 'y_vec' changed values within array."
    )
    assert IRF_ob.f_vec.shape == (1, 2, 6), "Time series import: Shaping of 1D array 'f_vec' failed."
    assert np.array_equal(IRF_ob.f_vec, np.array([[[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]]])), (
        "Time series import: Shaping of 2D array 'f_vec' changed values within array."
    )


def test_3d_time_series_import():
    # Input: 1D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array(
        [
            [[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]],
            [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]],
        ]
    )
    f_test_vec = np.array(
        [
            [[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]],
            [[2, 3, 2, 0, 0, 0], [-2, -3, -2, 0, 0, 0]],
        ]
    )
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec)
    assert IRF_ob.y_vec.shape == (2, 2, 6), "Time series import: Shaping of 1D array 'y_vec' failed."
    assert np.array_equal(
        IRF_ob.y_vec,
        np.array(
            [
                [[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]],
                [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]],
            ]
        ),
    ), "Time series import: Shaping of 3D array 'y_vec' changed values within array."
    assert IRF_ob.f_vec.shape == (2, 2, 6), "Time series import: Shaping of 1D array 'f_vec' failed."
    assert np.array_equal(
        IRF_ob.f_vec,
        np.array(
            [
                [[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]],
                [[2, 3, 2, 0, 0, 0], [-2, -3, -2, 0, 0, 0]],
            ]
        ),
    ), "Time series import: Shaping of 3D array 'f_vec' changed values within array."


def test_data_rejection_with_different_time_vectors():
    # Time vector with correct shape but wrong data
    t_test_vec1 = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])
    IRF_ob = openirf.ExperimentalIRF(t_vec=t_test_vec1)  # Create OpenIRF object instance with first time vector

    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])
    t_test_vec2 = np.array([0, 0.01, 0.02, 0.03, 0.04, 0.05])

    with pytest.raises(Exception) as exc_info:
        IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec2)
    assert exc_info.value.args[0] == "Provided t_vec does not match stored t_vec."
    assert exc_info.type.__name__ == "Exception"

    # Time vector with incorrect shape
    t_test_vec1 = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
    IRF_ob = openirf.ExperimentalIRF(t_vec=t_test_vec1)  # Create OpenIRF object instance with first time vector

    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])
    t_test_vec2 = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    with pytest.raises(Exception) as exc_info:
        IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec2)
    assert exc_info.value.args[0] == "Provided t_vec does not match stored t_vec."
    assert exc_info.type.__name__ == "Exception"


def test_data_rejection_with_different_lengths_during_instantiation():
    # Data added during class instance creation - f_vec shaped incorrectly
    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.ExperimentalIRF(y_vec=y_test_vec, f_vec=f_test_vec, t_vec=t_test_vec)
    assert exc_info.value.args[0] == "Provided f_vec does not match length of stored t_vec."
    assert exc_info.type.__name__ == "Exception"

    # Data added during class instance creation - y_vec shaped incorrectly
    y_test_vec = np.array([1, 2, 3, 4, 5, 6, 7])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.ExperimentalIRF(y_vec=y_test_vec, f_vec=f_test_vec, t_vec=t_test_vec)
    assert exc_info.value.args[0] == "Provided y_vec does not match length of stored t_vec."
    assert exc_info.type.__name__ == "Exception"


def test_data_rejection_with_different_lengths_after_instantiation():
    # Data added after class instance creation - f_vec shaped incorrectly
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    with pytest.raises(Exception) as exc_info:
        IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec)
    assert exc_info.value.args[0] == "Provided f_vec does not match length of stored t_vec."
    assert exc_info.type.__name__ == "Exception"

    # Data added after class instance creation - y_vec shaped incorrectly
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array([1, 2, 3, 4, 5, 6, 7])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    with pytest.raises(Exception) as exc_info:
        IRF_ob.add_time_series(y_test_vec, f_test_vec, t_vec=t_test_vec)
    assert exc_info.value.args[0] == "Provided y_vec does not match length of stored t_vec."
    assert exc_info.type.__name__ == "Exception"


def test_correct_appending_of_1D_time_series():
    # Input: 1D arrays
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec1 = np.array([1, 2, 3, 4, 5, 6])
    y_test_vec2 = np.array([6, 5, 4, 3, 2, 1])
    y_test_vec3 = np.array([2, 3, 4, 5, 6, 7])
    y_test_vec4 = np.array([7, 6, 5, 4, 3, 2])
    f_test_vec1 = np.array([1, 2, 1, 0, 0, 0])
    f_test_vec2 = np.array([-1, -2, -1, 0, 0, 0])
    f_test_vec3 = np.array([2, 3, 2, 0, 0, 0])
    f_test_vec4 = np.array([-2, -3, -2, 0, 0, 0])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    IRF_ob.add_time_series(y_test_vec1, f_test_vec1, t_vec=t_test_vec)
    IRF_ob.add_time_series(y_test_vec2, f_test_vec2)
    IRF_ob.add_time_series(y_test_vec3, f_test_vec3, t_vec=t_test_vec)
    IRF_ob.add_time_series(y_test_vec4, f_test_vec4)

    assert IRF_ob.y_vec.shape == (4, 1, 6), "Time series import: Appending 1D arrays to 'y_vec' failed."
    assert np.array_equal(
        IRF_ob.y_vec,
        np.array(
            [
                [[1, 2, 3, 4, 5, 6]],
                [[6, 5, 4, 3, 2, 1]],
                [[2, 3, 4, 5, 6, 7]],
                [[7, 6, 5, 4, 3, 2]],
            ]
        ),
    ), "Time series import: Appending 1D arrays to 'y_vec' changed values within array."
    assert IRF_ob.f_vec.shape == (4, 1, 6), "Time series import: Appending 1D arrays to 'f_vec' failed."
    assert np.array_equal(
        IRF_ob.f_vec,
        np.array(
            [
                [[1, 2, 1, 0, 0, 0]],
                [[-1, -2, -1, 0, 0, 0]],
                [[2, 3, 2, 0, 0, 0]],
                [[-2, -3, -2, 0, 0, 0]],
            ]
        ),
    ), "Time series import: Appending 1D arrays to 'f_vec' changed values within array."


def test_correct_appending_of_2D_time_series():
    # Input: 2D arrays
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec1 = np.array([[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]])
    y_test_vec2 = np.array([[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]])
    f_test_vec1 = np.array([[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]])
    f_test_vec2 = np.array([[2, 3, 2, 0, 0, 0], [-2, -3, -2, 0, 0, 0]])
    t_test_vec = np.array([0, 0.1, 0.2, 0.3, 0.4, 0.5])

    IRF_ob.add_time_series(y_test_vec1, f_test_vec1, t_vec=t_test_vec)
    IRF_ob.add_time_series(y_test_vec2, f_test_vec2)

    # Input: 2D arrays
    assert IRF_ob.y_vec.shape == (2, 2, 6), "Time series import: Shaping of 1D array 'y_vec' failed."
    assert np.array_equal(
        IRF_ob.y_vec,
        np.array(
            [
                [[1, 2, 3, 4, 5, 6], [6, 5, 4, 3, 2, 1]],
                [[2, 3, 4, 5, 6, 7], [7, 6, 5, 4, 3, 2]],
            ]
        ),
    ), "Time series import: Shaping of 3D array 'y_vec' changed values within array."
    assert IRF_ob.f_vec.shape == (2, 2, 6), "Time series import: Shaping of 1D array 'f_vec' failed."
    assert np.array_equal(
        IRF_ob.f_vec,
        np.array(
            [
                [[1, 2, 1, 0, 0, 0], [-1, -2, -1, 0, 0, 0]],
                [[2, 3, 2, 0, 0, 0], [-2, -3, -2, 0, 0, 0]],
            ]
        ),
    ), "Time series import: Shaping of 3D array 'f_vec' changed values within array."


def test_rejection_of_data_without_time_vector_during_instantiation():
    # Input: 1D array
    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])

    with pytest.raises(Exception) as exc_info:
        IRF_ob = openirf.ExperimentalIRF(y_vec=y_test_vec, f_vec=f_test_vec)  # Create OpenIRF object instance
    assert exc_info.value.args[0] == "No t_vec provided for data."
    assert exc_info.type.__name__ == "Exception"


def test_rejection_of_data_without_time_vector_after_instantiation():
    # Input: 1D array
    IRF_ob = openirf.ExperimentalIRF()  # Create OpenIRF object instance
    y_test_vec = np.array([1, 2, 3, 4, 5, 6])
    f_test_vec = np.array([1, 2, 1, 0, 0, 0])

    with pytest.raises(Exception) as exc_info:
        IRF_ob.add_time_series(y_test_vec, f_test_vec)
    assert exc_info.value.args[0] == "No t_vec provided for data."
    assert exc_info.type.__name__ == "Exception"
