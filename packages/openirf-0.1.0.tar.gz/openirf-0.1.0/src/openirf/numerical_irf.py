import numpy as np
from .utils import *
from tqdm import tqdm


class NumericalIRF:
    """
    OpenIRF Numerical IRF Class
    ---------------------------

    Stores numerical model (M,C,K) for IRF calculation.

    Constraints
    -----------
    - All matrices must have the same size
    - M & K matrices must be added simultaneously
    - Adding a C matrix is optional

    Attributes
    ----------
    :param M: Mass matrix of numerical model.
    :type M: ndarray
    :param C: Damping matrix of numerical model.
    :type C: ndarray
    :param K: Stiffness matrix of numerical model.
    :type K: ndarray
    :param t_vec: Time vector corresponding to calculated IRFs.
    :type t_vec: ndarray
    :param H_d: Displacement IRF matrix.
    :type H_d: ndarray
    :param H_v: Velocity IRF matrix.
    :type H_v: ndarray
    :param H_a: Acceleration IRF matrix.
    :type H_a: ndarray

    """

    # Declare parameters as attributes
    M = np.empty((0, 0))
    C = np.empty((0, 0))
    K = np.empty((0, 0))
    t_vec = np.empty(0)
    H_d = np.empty((0, 0))
    H_v = np.empty((0, 0))
    H_a = np.empty((0, 0))

    def __init__(self, M=np.empty((0, 0)), C=np.empty((0, 0)), K=np.empty((0, 0))):
        # Initialize NumericalIRF class with provided data
        if M.size == 0 and K.size != 0:
            raise Exception("No mass matrix M was provided.")
        elif K.size == 0 and M.size != 0:
            raise Exception("No stiffness matrix K was provided.")
        elif M.size == 0 and K.size == 0 and C.size != 0:
            raise Exception("No mass matrix M and stiffness matrix K was provided.")
        else:
            if C.size == 0:
                self.add_MCK(M, K)
            else:
                self.add_MCK(M, K, C=C)

    def __str__(self):
        # Prints an formatted object summary of the OpenIRF NumericalIRF object
        def print_array(arr):
            if arr is None or arr.size == 0:
                return "None"
            else:
                return str(arr.shape)

        return f"==== OpenIRF Numerical IRF Object Summary ====\nM:     {print_array(self.M)}\nC:     {print_array(self.C)}\nK:     {print_array(self.K)}"

    def __repr__(self):
        # Return the same output as __str__ for IPython outputs
        return self.__str__()

    def add_MCK(self, M, K, C=None):
        """
        Add MCK matrices
        ----------------
        This method allows to add MCK matrices to the class istance.

        Constraints
        -----------
        - All matrices must have the same size
        - M & K matrices must be added simultaneously
        - Adding a C matrix is optional

        Parameters
        ----------
        :param M: Mass matrix of numerical model.
        :type M: ndarray, optional
        :param C: Damping matrix of numerical model.
        :type C: ndarray, optional
        :param K: Stiffness matrix of numerical model.
        :type K: ndarray, optional

        """
        # Check mass matrix
        if M.ndim != 2:
            raise Exception("Provided mass matrix M is not a 2D matrix.")
        if M.shape[0] != M.shape[1]:
            raise Exception("Provided mass matrix M is not a square matrix.")

        # Check stiffness matrix
        if K.ndim != 2:
            raise Exception("Provided stiffness matrix K is not a 2D matrix.")
        if K.shape[0] != K.shape[1]:
            raise Exception("Provided stiffness matrix K is not a square matrix.")

        # Check damping matrix
        if C is not None:
            if C.ndim != 2:
                raise Exception("Provided damping matrix C is not a 2D matrix.")
            if C.shape[0] != C.shape[1]:
                raise Exception("Provided damping matrix C is not a square matrix.")

        # Check consistant shape
        if M.shape != K.shape:
            raise Exception("Provided mass matrix M and stiffness matrix K have different size.")
        if C is not None:
            if M.shape != C.shape:
                raise Exception("Provided damping matrix C does not match the size of the mass matrix M and stiffness matrix K.")

        # Assign matrices after passing all checks
        self.M = M
        self.K = K
        if C is not None:
            self.C = C
        else:
            C = np.zeros_like(M)

    def calculate_IRF(self, t_step, t_len, dof_list=None, ic_type="shifted_force"):
        """
        Calculates a numerical IRF matrix
        ---------------------------------

        Numerically calculates an IRF matrix using Newmark time integration with the specified discrete time step size (t_step) for the specified length (t_len). The IRF matrix contains the degrees of freedom specified in dof_list. The initial condition type used for the calculation can be specified with ic_type.

        Supported initial condition types
        ---------------------------------
        - ``shifted_force`` (default): The Dirac impulse is applied as a force on the second time step.
        - ``initial_force``: The Dirac impulse is applied as a force on the first time step.
        - ``initial_velocity``: The Dirac impulse is applied as an initial system velocity.

        Parameters
        ----------
        :param t_step: Discrete time step size (in seconds).
        :type t_step: float
        :param t_len: Length of calculated IRFs (in seconds).
        :type t_len: float
        :param dof_list: List of dofs for which IRFs should be calculated.
        :type dof_list: ndarray, optional
        :param ic_type: Initial condition type used for IRF calculation.
        :type ic_type: string

        """

        # Generate and store time vector
        self.t_vec = np.arange(0, t_len + 2 * t_step, t_step)

        # Build dof_list if none provided
        if dof_list is None:
            dof_list = np.arange(0, len(self.M))

        # Preallocate IRF matrices
        H_d = np.zeros((len(dof_list), len(dof_list), len(self.t_vec)))
        H_v = np.zeros((len(dof_list), len(dof_list), len(self.t_vec)))
        H_a = np.zeros((len(dof_list), len(dof_list), len(self.t_vec)))

        # Loop over all requested dofs
        for dof in tqdm(range(0, len(dof_list))):
            # Determine initial conditions and force vector
            f_vec = np.zeros((len(self.t_vec), len(self.M)))
            q0 = np.zeros(len(self.M))
            dq0 = np.zeros(len(self.M))

            # Calculate appropiate Dirac initial condition
            if ic_type == "shifted_force":
                f_vec[1, dof_list[dof]] = 1 / t_step
            elif ic_type == "initial_force":
                f_vec[0, dof_list[dof]] = 2 / t_step
            elif ic_type == "initial_velocity":
                dq0 = np.linalg.inv(self.M)[dof_list[dof]]
            else:
                raise Exception("Unimplemented.")

            # Perform Newmark time integration
            q, dq, ddq = newmark_integration(self.M, self.C, self.K, f_vec, self.t_vec, q0, dq0)

            # Sort results in output matrix
            H_d[dof] = q[:, dof_list].T
            H_v[dof] = dq[:, dof_list].T
            H_a[dof] = ddq[:, dof_list].T

        # Trim t_vec, shift IRFs, and store in class instance
        self.t_vec = self.t_vec[:-1]

        if ic_type == "shifted_force":
            self.H_d = H_d[:, :, 1:]
            self.H_v = H_v[:, :, 1:]
            self.H_a = H_a[:, :, 1:]
        else:
            self.H_d = H_d[:, :, :-1]
            self.H_v = H_v[:, :, :-1]
            self.H_a = H_a[:, :, :-1]
