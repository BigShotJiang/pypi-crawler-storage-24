from splent_framework.seeders.BaseSeeder import BaseSeeder


class ProfileSeeder(BaseSeeder):

    def run(self):

        data = [
            # Create any Model object you want to make seed
        ]

        self.seed(data)
