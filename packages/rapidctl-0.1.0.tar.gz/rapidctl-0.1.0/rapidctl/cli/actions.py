import rapidctl.cli.tasks
from typing import List, Optional
from functools import cmp_to_key

def find_container(podman_session, container):
    """
    Find a container image locally utilizing caching.
    
    Args:
        podman_session: Authenticated PodmanCLI instance.
        container (str): The container image name to find.
        
    Returns:
        Optional[str]: The container ID if found locally, else None.
    """
    image = rapidctl.cli.tasks.local_search(podman_session, container)

    return image 

def pull_container(podman_session, container):
    """
    Pull a container image from its registry.
    
    Args:
        podman_session: Authenticated PodmanCLI instance.
        container (str): The container image name to pull.
        
    Returns:
        The pulled image object from podman library.
    """
    image = podman_session.pull_image(container)

    return image

def list_local_versions(podman_session, repo: str) -> List[str]:
    """Action to list all local versions for a repo, sorted from newest to oldest."""
    tags = rapidctl.cli.tasks.get_local_image_tags(podman_session, repo)
    
    # Sort tags using the VersionParser via task compare_versions
    sorted_tags = sorted(
        tags, 
        key=cmp_to_key(rapidctl.cli.tasks.compare_versions),
        reverse=True
    )
    
    return sorted_tags


def find_newer_version(podman_session, repo: str, current_version: str) -> Optional[str]:
    """Action to find the newest available local version that is newer than current."""
    all_versions = list_local_versions(podman_session, repo)
    
    if not all_versions:
        return None
        
    newest = all_versions[0]
    
    # Compare with current
    if rapidctl.cli.tasks.compare_versions(newest, current_version) > 0:
        return newest
        
    return None


def ensure_version(podman_session, repo: str, version: str):
    """Action to ensure a specific version exists locally, pulling if necessary."""
    full_image_ref = f"{repo}:{version}"
    
    image_id = find_container(podman_session, full_image_ref)
    
    if not image_id:
        print(f"Version {version} not found locally. Pulling...")
        image = pull_container(podman_session, full_image_ref)
        if isinstance(image, dict):
            return image.get("Id")
        return image.short_id if hasattr(image, "short_id") else None
        
    return image_id


def apply_latest_available(podman_session, repo: str, current_version: str) -> str:
    """
    Action to find the latest local version, update baseline_version,
    and persist the choice to disk.
    
    Returns the version that was applied.
    """
    newer = find_newer_version(podman_session, repo, current_version)
    
    if newer:
        # Persist the choice to disk so it's sticky across executions
        rapidctl.cli.tasks.write_version_state(repo, newer)
        return newer
        
    return current_version


def authenticate_to_registry(podman_session, image_name: str):
    """
    Action to prompt user for credentials and log in to the registry.
    Extracts registry from image name if possible.
    """
    import getpass
    from urllib.parse import urlparse
    
    # Extract registry from image name
    import rapidctl.cli.tasks as tasks
    registry = tasks.extract_registry(image_name)
            
    print(f"\n--- Registry Authentication Required for {registry} ---")
    username = input(f"Username: ")
    password = getpass.getpass(f"Password: ")
    
    try:
        rapidctl.cli.tasks.registry_login(podman_session, registry, username, password)
        print("✓ Login successful")
        return True
    except Exception as e:
        print(f"✗ Login failed: {e}")
        return False


def run_container_command(podman_session, image_name: str, command_path: str, args: List[str]):
    """
    Action to execute a command within a container.
    Constructs the full path to the executable and runs it.
    """
    import os
    
    if not args:
        print("No command provided to execute.")
        return

    # Subcommand is the first argument
    sub_command = args[0]
    
    # Construct full path to the command inside the container
    full_command_path = os.path.join(command_path, sub_command)
    
    # Combine with remaining arguments
    full_command = [full_command_path] + args[1:]
    
    # Run the container and stream output locally
    output_stream = podman_session.run_container(image_name, full_command, stream=True)
    for line in output_stream:
        if isinstance(line, bytes):
            print(line.decode('utf-8'), end='')
        else:
            print(line, end='')


def get_container_subcommands(podman_session, image_name: str, command_path: str) -> dict:
    """
    Action to discover available subcommands and their descriptions.
    Tries to read commands.json from the parent directory of command_path,
    falling back to listing files.
    """
    import os
    import json
    
    base_path = os.path.dirname(command_path.rstrip('/'))
    json_path = os.path.join(base_path, "commands.json")
    
    try:
        output = rapidctl.cli.tasks.run_command_capture(
            podman_session,
            image_name,
            ["cat", json_path]
        )
        if output:
            metadata = json.loads("\n".join(output))
            result = {}
            for cmd, info in metadata.items():
                result[cmd] = info.get("summary", "")
            return result
    except Exception:
        pass # Fallback to ls -1
        
    try:
        commands = rapidctl.cli.tasks.run_command_capture(
            podman_session, 
            image_name, 
            ["ls", "-1", command_path]
        )
        return {cmd: "" for cmd in sorted(commands) if cmd}
    except Exception as e:
        print(f"Warning: Could not discover subcommands in container: {e}")
        return {}

def display_available_commands(podman_session, container_version, command_path, header: str) -> None:
    """Action to discover and print available commands for a container."""
    from rapidctl.cli.tasks import format_command_list
    
    available_cmds = get_container_subcommands(podman_session, container_version, command_path)
    print(header)
    if available_cmds:
        print(format_command_list(available_cmds))
    else:
        print("  No subcommands found.")
    return available_cmds
