"""Xenia — Biologically Grounded Affective Dynamics (BGAD).

A coupled ODE system for human psychobiology simulation.
Full package in development.
"""
__version__ = "0.0.1"
