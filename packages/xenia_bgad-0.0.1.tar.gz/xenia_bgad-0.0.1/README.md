# Xenia — Biologically Grounded Affective Dynamics (BGAD)

Coupled ODE system modeling human psychobiology from neurochemistry to behavior.

**Status: In development. Full package coming soon.**

Paper forthcoming.
