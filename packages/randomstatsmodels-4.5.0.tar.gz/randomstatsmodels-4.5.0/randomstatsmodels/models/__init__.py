from .fourier import FourierForecaster, AutoFourier
from .hybrid import HybridForecastNet, AutoHybridForecaster
from .meld import MELDForecaster, AutoMELD
from .knn import KNNForecaster, AutoKNN
from .palf import PALF, AutoPALF
from .neo import NEOForecaster, AutoNEO
from .theta_ar import AutoThetaAR
from .polymath import PolymathForecaster, AutoPolymath
from .naive import NaiveForecaster, AutoNaive
from .holt_winters import HoltWintersForecaster, AutoHoltWinters
from .ssa import SSAForecaster, AutoSSA
from .local_linear import LocalLinearForecaster, AutoLocalLinear
from .ensemble import EnsembleForecaster, AutoEnsemble
from .rift import RIFTForecaster, AutoRIFT
from .fracdiff import FracDiffForecaster, AutoFracDiff
from .spectral_gradient import SpectralGradientForecaster, AutoSpectralGradient
from .greens_kernel import GreensKernelForecaster, AutoGreensKernel
from .pde_field import PDEFieldForecaster, AutoPDEField
from .variational_path import VariationalPathForecaster, AutoVariationalPath
from .koopman import KoopmanForecaster, AutoKoopman
from .ensemble_advanced import (
    StackedForecaster, AutoStacked,
    BaggedForecaster, AutoBagged,
    DynamicEnsemble, AutoDynamic,
)

# Apply speed parameter to every Auto* class
from ..presets import _add_speed as _s
for _cls in [AutoFourier, AutoHybridForecaster, AutoMELD, AutoKNN, AutoPALF,
             AutoNEO, AutoThetaAR, AutoPolymath, AutoNaive, AutoHoltWinters,
             AutoSSA, AutoLocalLinear, AutoEnsemble, AutoRIFT,
             AutoFracDiff, AutoSpectralGradient, AutoGreensKernel,
             AutoPDEField, AutoVariationalPath, AutoKoopman,
             AutoStacked, AutoBagged, AutoDynamic]:
    _s(_cls)
del _s, _cls

__all__ = [
    "HybridForecastNet",
    "AutoHybridForecaster",
    "MELDForecaster",
    "AutoMELD",
    "KNNForecaster",
    "AutoKNN",
    "PALF",
    "AutoPALF",
    "NEOForecaster",
    "AutoNEO",
    "AutoThetaAR",
    "PolymathForecaster",
    "AutoPolymath",
    "FourierForecaster",
    "AutoFourier",
    "NaiveForecaster",
    "AutoNaive",
    "HoltWintersForecaster",
    "AutoHoltWinters",
    "SSAForecaster",
    "AutoSSA",
    "LocalLinearForecaster",
    "AutoLocalLinear",
    "EnsembleForecaster",
    "AutoEnsemble",
    "RIFTForecaster",
    "AutoRIFT",
    "FracDiffForecaster",
    "AutoFracDiff",
    "SpectralGradientForecaster",
    "AutoSpectralGradient",
    "GreensKernelForecaster",
    "AutoGreensKernel",
    "PDEFieldForecaster",
    "AutoPDEField",
    "VariationalPathForecaster",
    "AutoVariationalPath",
    "KoopmanForecaster",
    "AutoKoopman",
    "StackedForecaster",
    "AutoStacked",
    "BaggedForecaster",
    "AutoBagged",
    "DynamicEnsemble",
    "AutoDynamic",
]
