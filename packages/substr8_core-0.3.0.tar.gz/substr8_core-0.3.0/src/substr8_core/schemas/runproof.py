"""RunProof v2.1 Schema

Cryptographically verifiable receipt for agent execution.

Schema version: runproof/v2.1

Changes from v2:
- Expanded Issuer (object with name, version, runtime)
- Added Claims section (policy, model, environment, compliance)
- Added Lineage section (parent, root, depth for chainable proofs)
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal, Union

from pydantic import BaseModel, Field


class RunStatus(str, Enum):
    """Run completion status."""
    COMPLETED = "completed"
    FAILED = "failed"
    INTERRUPTED = "interrupted"


class TriggerType(str, Enum):
    """What triggered the run."""
    USER_PROMPT = "user_prompt"
    API = "api"
    SCHEDULE = "schedule"
    EVENT = "event"


class RedactionMode(str, Enum):
    """How sensitive data is handled."""
    HASHED = "hashed"
    PARTIAL = "partial"
    EMBEDDED = "embedded"


class EventType(str, Enum):
    """Canonical event types."""
    RUN_STARTED = "run_started"
    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"
    RUN_CANCELLED = "run_cancelled"
    NODE_STARTED = "node_started"
    NODE_COMPLETED = "node_completed"
    NODE_FAILED = "node_failed"
    DECISION_MADE = "decision_made"
    TOOL_CALL_STARTED = "tool_call_started"
    TOOL_CALL_COMPLETED = "tool_call_completed"
    TOOL_CALL_FAILED = "tool_call_failed"
    DELEGATION_STARTED = "delegation_started"
    DELEGATION_COMPLETED = "delegation_completed"
    DELEGATION_FAILED = "delegation_failed"
    MEMORY_READ = "memory_read"
    MEMORY_WRITE = "memory_write"
    STATE_TRANSITION = "state_transition"
    CAPABILITY_CHECK = "capability_check"
    POLICY_ALLOW = "policy_allow"
    POLICY_DENY = "policy_deny"
    ARTIFACT_EMITTED = "artifact_emitted"
    PAYMENT_AUTHORIZED = "payment_authorized"
    PAYMENT_SETTLED = "payment_settled"
    PAYMENT_FAILED = "payment_failed"
    ERROR = "error"
    RETRY = "retry"
    HUMAN_REVIEW_REQUESTED = "human_review_requested"
    HUMAN_REVIEW_COMPLETED = "human_review_completed"
    CUSTOM = "custom"


class SignatureAlgorithm(str, Enum):
    """Supported signature algorithms."""
    ED25519 = "ed25519"
    ECDSA_P256 = "ecdsa-p256"


# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────


class RunProofHeader(BaseModel):
    """Run metadata and identification."""
    
    proof_id: str = Field(..., description="Unique proof artifact identifier")
    run_id: str = Field(..., description="Execution identifier")
    tenant_id: str | None = Field(None, description="Multi-tenant isolation")
    agent_id: str = Field(..., description="Agent identifier (e.g., claims/orchestrator)")
    agent_version_hash: str | None = Field(None, description="SHA256 hash of agent definition")
    runtime: str = Field(..., description="Execution environment (langgraph, openclaw, etc.)")
    runtime_version: str | None = Field(None, description="Runtime version for reproducibility")
    started_at: datetime = Field(..., description="Run start timestamp")
    ended_at: datetime | None = Field(None, description="Run end timestamp")
    status: RunStatus = Field(..., description="Run completion status")
    parent_run_id: str | None = Field(None, description="Parent run for delegation/retry")
    session_id: str | None = Field(None, description="Conversation context")
    workflow_id: str | None = Field(None, description="Job-level chain")


# ─────────────────────────────────────────────────────────────────────────────
# Identity (v2.1: Expanded Issuer)
# ─────────────────────────────────────────────────────────────────────────────


class Issuer(BaseModel):
    """
    Issuer metadata (v2.1).
    
    Provides rich information about what generated the proof.
    """
    
    name: str = Field(..., description="SDK/tool name (e.g., 'substr8')")
    version: str = Field(..., description="SDK version (semver)")
    runtime: str = Field(..., description="Execution framework (langgraph, crewai, etc.)")
    runtime_version: str | None = Field(None, description="Framework version")


# Type alias for backward compatibility with v2 (string) and v2.1 (object)
IssuerType = Union[str, Issuer]


class Signer(BaseModel):
    """Proof signer identity."""
    
    key_id: str = Field(..., description="Signing key identifier")
    public_key: str = Field(..., description="Public key (prefixed with algorithm)")
    issuer: IssuerType = Field(..., description="Key issuer - string (v2) or Issuer object (v2.1)")


class Policy(BaseModel):
    """Governance policy reference."""
    
    capability_profile_id: str | None = Field(None, description="ACC capability profile")
    policy_hash: str | None = Field(None, description="SHA256 hash of policy document")


class Identity(BaseModel):
    """Signer and policy information."""
    
    signer: Signer
    policy: Policy | None = None


# ─────────────────────────────────────────────────────────────────────────────
# Claims (v2.1: NEW)
# ─────────────────────────────────────────────────────────────────────────────


class Claims(BaseModel):
    """
    Contextual claims about the execution (v2.1).
    
    Claims are assertions by the issuer - they are NOT cryptographically 
    verified by the proof itself. External systems may verify claims against
    their own records.
    
    Claims are included in proof_hash, so tampering is detectable.
    """
    
    policy: str | None = Field(None, description="Policy name/ID that governed execution")
    model: str | None = Field(None, description="LLM model used")
    environment: str | None = Field(None, description="Execution environment (dev/staging/prod)")
    compliance: list[str] = Field(default_factory=list, description="Compliance tags (gdpr-safe, hipaa, etc.)")
    intent_hash: str | None = Field(None, description="Hash of original intent (for Intent primitive)")
    custom: dict[str, Any] = Field(default_factory=dict, description="Arbitrary key-value metadata")


# ─────────────────────────────────────────────────────────────────────────────
# Lineage (v2.1: NEW)
# ─────────────────────────────────────────────────────────────────────────────


class Lineage(BaseModel):
    """
    Proof lineage for chainable workflows (v2.1).
    
    Enables cryptographic relationships between proofs for multi-step
    workflows and delegation chains.
    """
    
    parent: str | None = Field(None, description="SHA256 hash of parent RunProof")
    root: str | None = Field(None, description="SHA256 hash of workflow root RunProof")
    depth: int = Field(1, ge=1, description="Steps from root (1 = is root)")
    workflow_id: str | None = Field(None, description="Workflow identifier for grouping")


# ─────────────────────────────────────────────────────────────────────────────
# Context
# ─────────────────────────────────────────────────────────────────────────────


class ModelInfo(BaseModel):
    """LLM model information."""
    
    provider: str = Field(..., description="Model provider (anthropic, openai, etc.)")
    model_id: str = Field(..., description="Model identifier")


class Context(BaseModel):
    """Execution context."""
    
    trigger_type: TriggerType = Field(..., description="What triggered the run")
    input_hash: str = Field(..., description="SHA256 hash of input (privacy-safe)")
    input_redaction_mode: RedactionMode = Field(
        RedactionMode.HASHED, description="How input is stored"
    )
    model: ModelInfo | None = None
    tools_available: list[str] = Field(default_factory=list, description="Available tool names")


# ─────────────────────────────────────────────────────────────────────────────
# Trace
# ─────────────────────────────────────────────────────────────────────────────


class TraceEntry(BaseModel):
    """Single event in the execution trace."""
    
    seq: int = Field(..., ge=1, description="Sequence number (1-indexed)")
    event_id: str = Field(..., description="Unique event identifier")
    type: EventType = Field(..., description="Event type")
    timestamp: datetime = Field(..., description="Event timestamp")
    prev_hash: str | None = Field(None, description="Hash of previous entry (chain)")
    payload_hash: str | None = Field(None, description="SHA256 hash of payload")
    payload_ref: str | None = Field(None, description="External payload reference")
    payload: dict[str, Any] | None = Field(None, description="Event payload (if embedded)")
    entry_hash: str = Field(..., description="SHA256 hash of this entry")


# ─────────────────────────────────────────────────────────────────────────────
# Outputs
# ─────────────────────────────────────────────────────────────────────────────


class Artifact(BaseModel):
    """Output artifact reference."""
    
    artifact_id: str
    artifact_type: Literal["file", "json", "report"]
    artifact_hash: str
    uri: str | None = None


class Outputs(BaseModel):
    """Run outputs."""
    
    result_hash: str = Field(..., description="SHA256 hash of final output")
    result_redaction_mode: RedactionMode = Field(
        RedactionMode.HASHED, description="How output is stored"
    )
    artifacts: list[Artifact] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# Commitments
# ─────────────────────────────────────────────────────────────────────────────


class Signature(BaseModel):
    """Cryptographic signature."""
    
    algorithm: SignatureAlgorithm = Field(SignatureAlgorithm.ED25519)
    value: str = Field(..., description="Base64-encoded signature")


class Commitments(BaseModel):
    """Cryptographic commitments."""
    
    event_root: str = Field(..., description="Merkle root of trace entries")
    proof_hash: str = Field(..., description="SHA256 of canonical proof envelope")
    signature: Signature


# ─────────────────────────────────────────────────────────────────────────────
# Anchors
# ─────────────────────────────────────────────────────────────────────────────


class Anchors(BaseModel):
    """External anchoring references."""
    
    registry_id: str | None = Field(None, description="Registry entry ID")
    registry_anchor_hash: str | None = Field(None, description="Registry anchor hash")
    transparency_log_entry: str | None = Field(None, description="Transparency log reference")


# ─────────────────────────────────────────────────────────────────────────────
# Metadata
# ─────────────────────────────────────────────────────────────────────────────


class Metadata(BaseModel):
    """Additional metadata."""
    
    tags: list[str] = Field(default_factory=list)
    custom: dict[str, Any] = Field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# RunProof (Top-level)
# ─────────────────────────────────────────────────────────────────────────────


# Schema versions supported
SchemaVersion = Literal["runproof/v2", "runproof/v2.1"]


class RunProof(BaseModel):
    """
    RunProof v2.1 - Cryptographically verifiable receipt for agent execution.
    
    Proves that a specific agent/runtime identity produced a specific ordered
    execution trace and outputs under a specific policy context, and that the
    artifact has not been altered since signing.
    
    v2.1 adds:
    - Expanded issuer metadata (name, version, runtime)
    - Claims section for enterprise context
    - Lineage section for chainable workflows
    """
    
    schema_version: SchemaVersion = Field(
        "runproof/v2.1", description="Schema version"
    )
    header: RunProofHeader
    identity: Identity
    claims: Claims | None = Field(None, description="Contextual claims (v2.1)")
    lineage: Lineage | None = Field(None, description="Proof lineage (v2.1)")
    context: Context
    trace: list[TraceEntry] = Field(default_factory=list)
    outputs: Outputs
    commitments: Commitments
    anchors: Anchors = Field(default_factory=Anchors)
    metadata: Metadata = Field(default_factory=Metadata)
    
    model_config = {
        "json_schema_extra": {
            "title": "RunProof",
            "description": "Cryptographically verifiable receipt for agent execution",
            "$id": "https://substr8labs.com/schemas/runproof/v2.1"
        }
    }


# ─────────────────────────────────────────────────────────────────────────────
# Helper functions
# ─────────────────────────────────────────────────────────────────────────────


def normalize_issuer(issuer: IssuerType) -> Issuer:
    """
    Convert v2 string issuer to v2.1 Issuer object.
    
    Args:
        issuer: String (v2) or Issuer object (v2.1)
        
    Returns:
        Issuer object
    """
    if isinstance(issuer, str):
        # Parse v2 format: "substr8-langgraph" or just "substr8"
        parts = issuer.split("-", 1)
        return Issuer(
            name=parts[0] if len(parts) > 0 else "unknown",
            version="unknown",
            runtime=parts[1] if len(parts) > 1 else issuer,
        )
    return issuer


def is_v2_proof(proof: RunProof) -> bool:
    """Check if proof is v2 format."""
    return proof.schema_version == "runproof/v2"


def is_v21_proof(proof: RunProof) -> bool:
    """Check if proof is v2.1 format."""
    return proof.schema_version == "runproof/v2.1"
