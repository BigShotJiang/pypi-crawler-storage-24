"""
Substr8 Core - Schemas and utilities for RunProof system.

Schema version: runproof/v2
"""

__version__ = "0.2.0"

from .schemas import (
    # RunProof
    RunProof,
    RunProofHeader,
    TraceEntry,
    EventType,
    RunStatus,
    TriggerType,
    RedactionMode,
    SignatureAlgorithm,
    Signer,
    Policy,
    Identity,
    Context,
    ModelInfo,
    Outputs,
    Artifact,
    Commitments,
    Signature,
    Anchors,
    Metadata,
    # RunState
    RunState,
    LifecycleStatus,
    ChildRunRef,
    HumanReviewState,
    HumanReviewStatus,
    RetryState,
    ValidationState,
    SettlementState,
    SettlementStatus,
    Checkpoint,
)

from .crypto import (
    # Hashing
    sha256_hex,
    sha256_str,
    sha256_json,
    canonical_json,
    compute_entry_hash,
    compute_merkle_root,
    verify_hash_chain,
    # Signing
    KeyPair,
    verify_signature,
    verify_signature_str,
    # Verification
    verify_runproof,
    VerificationResult,
    CheckResult,
)

__all__ = [
    # Version
    "__version__",
    # RunProof schemas
    "RunProof",
    "RunProofHeader",
    "TraceEntry",
    "EventType",
    "RunStatus",
    "TriggerType",
    "RedactionMode",
    "SignatureAlgorithm",
    "Signer",
    "Policy",
    "Identity",
    "Context",
    "ModelInfo",
    "Outputs",
    "Artifact",
    "Commitments",
    "Signature",
    "Anchors",
    "Metadata",
    # RunState schemas
    "RunState",
    "LifecycleStatus",
    "ChildRunRef",
    "HumanReviewState",
    "HumanReviewStatus",
    "RetryState",
    "ValidationState",
    "SettlementState",
    "SettlementStatus",
    "Checkpoint",
    # Hashing
    "sha256_hex",
    "sha256_str",
    "sha256_json",
    "canonical_json",
    "compute_entry_hash",
    "compute_merkle_root",
    "verify_hash_chain",
    # Signing
    "KeyPair",
    "verify_signature",
    "verify_signature_str",
    # Verification
    "verify_runproof",
    "VerificationResult",
    "CheckResult",
]
