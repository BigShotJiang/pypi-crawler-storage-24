"""Cryptographic signing utilities for RunProof."""

from __future__ import annotations

import base64
from dataclasses import dataclass

from nacl.signing import SigningKey, VerifyKey
from nacl.exceptions import CryptoError


@dataclass
class KeyPair:
    """Ed25519 key pair."""
    
    signing_key: SigningKey
    verify_key: VerifyKey
    key_id: str
    
    @classmethod
    def generate(cls, key_id: str) -> "KeyPair":
        """Generate a new Ed25519 key pair."""
        signing_key = SigningKey.generate()
        verify_key = signing_key.verify_key
        return cls(signing_key=signing_key, verify_key=verify_key, key_id=key_id)
    
    @classmethod
    def from_seed(cls, seed: bytes, key_id: str) -> "KeyPair":
        """Create key pair from 32-byte seed."""
        signing_key = SigningKey(seed)
        verify_key = signing_key.verify_key
        return cls(signing_key=signing_key, verify_key=verify_key, key_id=key_id)
    
    @property
    def public_key_hex(self) -> str:
        """Get public key as hex string with ed25519: prefix."""
        return f"ed25519:{self.verify_key.encode().hex()}"
    
    def sign(self, data: bytes) -> str:
        """Sign data and return base64-encoded signature."""
        signed = self.signing_key.sign(data)
        # signed.signature is just the signature, not the message
        return base64.b64encode(signed.signature).decode("ascii")
    
    def sign_str(self, text: str) -> str:
        """Sign a string."""
        return self.sign(text.encode("utf-8"))


def verify_signature(
    public_key: str,
    signature_b64: str,
    data: bytes,
) -> bool:
    """
    Verify an Ed25519 signature.
    
    Args:
        public_key: Public key with "ed25519:" prefix
        signature_b64: Base64-encoded signature
        data: Original data that was signed
    
    Returns:
        True if signature is valid, False otherwise
    """
    try:
        # Parse public key
        if public_key.startswith("ed25519:"):
            key_hex = public_key[8:]
        else:
            key_hex = public_key
        
        key_bytes = bytes.fromhex(key_hex)
        verify_key = VerifyKey(key_bytes)
        
        # Decode signature
        signature = base64.b64decode(signature_b64)
        
        # Verify
        verify_key.verify(data, signature)
        return True
        
    except (CryptoError, ValueError, Exception):
        return False


def verify_signature_str(
    public_key: str,
    signature_b64: str,
    text: str,
) -> bool:
    """Verify signature of a string."""
    return verify_signature(public_key, signature_b64, text.encode("utf-8"))
