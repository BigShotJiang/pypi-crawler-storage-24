"""Substr8 Cryptographic Utilities."""

from .hashing import (
    sha256_hex,
    sha256_str,
    sha256_json,
    canonical_json,
    compute_entry_hash,
    compute_merkle_root,
    verify_hash_chain,
)

from .signing import (
    KeyPair,
    verify_signature,
    verify_signature_str,
)

from .verify import (
    verify_runproof,
    VerificationResult,
    CheckResult,
)

__all__ = [
    # Hashing
    "sha256_hex",
    "sha256_str",
    "sha256_json",
    "canonical_json",
    "compute_entry_hash",
    "compute_merkle_root",
    "verify_hash_chain",
    # Signing
    "KeyPair",
    "verify_signature",
    "verify_signature_str",
    # Verification
    "verify_runproof",
    "VerificationResult",
    "CheckResult",
]
