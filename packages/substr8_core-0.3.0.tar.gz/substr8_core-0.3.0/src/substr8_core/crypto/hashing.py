"""Cryptographic hashing utilities for RunProof."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def sha256_hex(data: bytes) -> str:
    """Compute SHA256 hash and return as hex string with prefix."""
    digest = hashlib.sha256(data).hexdigest()
    return f"sha256:{digest}"


def sha256_str(text: str) -> str:
    """Hash a string using SHA256."""
    return sha256_hex(text.encode("utf-8"))


def sha256_json(obj: Any) -> str:
    """Hash a JSON-serializable object using canonical serialization."""
    canonical = canonical_json(obj)
    return sha256_str(canonical)


def canonical_json(obj: Any) -> str:
    """
    Produce canonical JSON for deterministic hashing.
    
    Rules:
    - Keys sorted alphabetically
    - No extra whitespace
    - UTF-8 encoding
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def compute_entry_hash(
    seq: int,
    event_type: str,
    timestamp: str,
    prev_hash: str | None,
    payload_hash: str | None,
) -> str:
    """
    Compute the entry hash for a trace entry.
    
    entry_hash = SHA256(seq || type || timestamp || prev_hash || payload_hash)
    """
    components = [
        str(seq),
        event_type,
        timestamp,
        prev_hash or "",
        payload_hash or "",
    ]
    data = "|".join(components)
    return sha256_str(data)


def compute_merkle_root(entry_hashes: list[str]) -> str:
    """
    Compute Merkle root from a list of entry hashes.
    
    Empty list returns hash of empty string.
    Single entry returns that entry.
    Multiple entries are paired and hashed up the tree.
    """
    if not entry_hashes:
        return sha256_str("")
    
    if len(entry_hashes) == 1:
        return entry_hashes[0]
    
    # Build tree level by level
    current_level = entry_hashes[:]
    
    while len(current_level) > 1:
        next_level = []
        
        for i in range(0, len(current_level), 2):
            left = current_level[i]
            # If odd number of elements, duplicate the last one
            right = current_level[i + 1] if i + 1 < len(current_level) else left
            combined = sha256_str(left + right)
            next_level.append(combined)
        
        current_level = next_level
    
    return current_level[0]


def verify_hash_chain(entries: list[dict]) -> tuple[bool, list[str]]:
    """
    Verify the hash chain of trace entries.
    
    Returns (valid, errors).
    """
    errors = []
    
    if not entries:
        return True, []
    
    for i, entry in enumerate(entries):
        # Check sequence
        expected_seq = i + 1
        if entry.get("seq") != expected_seq:
            errors.append(f"Entry {i}: expected seq {expected_seq}, got {entry.get('seq')}")
        
        # Check prev_hash links to previous entry
        if i > 0:
            prev_entry = entries[i - 1]
            expected_prev = prev_entry.get("entry_hash")
            actual_prev = entry.get("prev_hash")
            if actual_prev != expected_prev:
                errors.append(f"Entry {i}: prev_hash mismatch")
        
        # Recompute entry_hash
        computed = compute_entry_hash(
            seq=entry.get("seq", 0),
            event_type=entry.get("type", ""),
            timestamp=entry.get("timestamp", ""),
            prev_hash=entry.get("prev_hash"),
            payload_hash=entry.get("payload_hash"),
        )
        
        if computed != entry.get("entry_hash"):
            errors.append(f"Entry {i}: entry_hash mismatch (computed {computed[:20]}...)")
    
    return len(errors) == 0, errors
