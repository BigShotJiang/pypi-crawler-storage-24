# substr8-core

Core schemas and utilities for the Substr8 RunProof system.

## Installation

```bash
pip install substr8-core
```

## Usage

### RunProof Schema

```python
from substr8_core.schemas import RunProof, RunProofHeader, TraceEntry

# Create a RunProof
proof = RunProof(
    schema_version="runproof/v2",
    header=RunProofHeader(
        proof_id="proof_abc123",
        run_id="run_xyz789",
        agent_id="claims/orchestrator",
        runtime="langgraph",
        started_at="2026-03-09T10:00:00Z",
        status="completed"
    ),
    # ... rest of proof
)

# Serialize
proof_json = proof.model_dump_json()

# Validate
proof = RunProof.model_validate_json(proof_json)
```

### RunState Schema

```python
from substr8_core.schemas import RunState, LifecycleStatus

# Create run state
state = RunState(
    run_id="run_xyz789",
    agent_id="claims/orchestrator",
    lifecycle_status=LifecycleStatus.RUNNING,
    current_node="validate_output",
    step_index=5
)

# Update state
state.lifecycle_status = LifecycleStatus.COMPLETED
```

### Verification

```python
from substr8_core.crypto import verify_proof

result = verify_proof(proof)
print(result.valid)  # True/False
print(result.checks)  # Detailed check results
```

## Schema Version

This package implements RunProof schema version `runproof/v2`.

## License

MIT © 2026 Substr8 Labs
