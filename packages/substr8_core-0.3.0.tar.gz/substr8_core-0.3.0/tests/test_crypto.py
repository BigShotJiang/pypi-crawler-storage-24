"""Tests for Substr8 crypto utilities."""

import pytest

from substr8_core import (
    sha256_str,
    sha256_json,
    compute_entry_hash,
    compute_merkle_root,
    verify_hash_chain,
    KeyPair,
    verify_signature_str,
)


def test_sha256_str():
    """Test SHA256 string hashing."""
    result = sha256_str("hello")
    assert result.startswith("sha256:")
    assert len(result) == 7 + 64  # prefix + hex


def test_sha256_json():
    """Test SHA256 JSON hashing is deterministic."""
    obj1 = {"b": 2, "a": 1}
    obj2 = {"a": 1, "b": 2}
    
    # Should be same despite different key order
    assert sha256_json(obj1) == sha256_json(obj2)


def test_compute_entry_hash():
    """Test entry hash computation."""
    hash1 = compute_entry_hash(
        seq=1,
        event_type="run_started",
        timestamp="2026-03-09T10:00:00Z",
        prev_hash=None,
        payload_hash="sha256:abc",
    )
    
    assert hash1.startswith("sha256:")
    
    # Different inputs should give different hash
    hash2 = compute_entry_hash(
        seq=2,
        event_type="run_started",
        timestamp="2026-03-09T10:00:00Z",
        prev_hash=hash1,
        payload_hash="sha256:abc",
    )
    
    assert hash1 != hash2


def test_compute_merkle_root_empty():
    """Test Merkle root of empty list."""
    root = compute_merkle_root([])
    assert root.startswith("sha256:")


def test_compute_merkle_root_single():
    """Test Merkle root of single entry."""
    entry = "sha256:abc123"
    root = compute_merkle_root([entry])
    assert root == entry


def test_compute_merkle_root_multiple():
    """Test Merkle root of multiple entries."""
    entries = [
        "sha256:a1",
        "sha256:b2",
        "sha256:c3",
        "sha256:d4",
    ]
    root = compute_merkle_root(entries)
    assert root.startswith("sha256:")
    
    # Should be deterministic
    assert compute_merkle_root(entries) == root


def test_verify_hash_chain_valid():
    """Test valid hash chain verification."""
    entry1_hash = compute_entry_hash(1, "start", "2026-03-09T10:00:00Z", None, "sha256:p1")
    entry2_hash = compute_entry_hash(2, "work", "2026-03-09T10:00:01Z", entry1_hash, "sha256:p2")
    
    entries = [
        {
            "seq": 1,
            "type": "start",
            "timestamp": "2026-03-09T10:00:00Z",
            "prev_hash": None,
            "payload_hash": "sha256:p1",
            "entry_hash": entry1_hash,
        },
        {
            "seq": 2,
            "type": "work",
            "timestamp": "2026-03-09T10:00:01Z",
            "prev_hash": entry1_hash,
            "payload_hash": "sha256:p2",
            "entry_hash": entry2_hash,
        },
    ]
    
    valid, errors = verify_hash_chain(entries)
    assert valid
    assert len(errors) == 0


def test_verify_hash_chain_broken():
    """Test broken hash chain detection."""
    entries = [
        {
            "seq": 1,
            "type": "start",
            "timestamp": "2026-03-09T10:00:00Z",
            "prev_hash": None,
            "payload_hash": "sha256:p1",
            "entry_hash": "sha256:wrong",  # Intentionally wrong
        },
    ]
    
    valid, errors = verify_hash_chain(entries)
    assert not valid
    assert len(errors) > 0


def test_keypair_generate():
    """Test key pair generation."""
    kp = KeyPair.generate("test_key")
    
    assert kp.key_id == "test_key"
    assert kp.public_key_hex.startswith("ed25519:")


def test_sign_and_verify():
    """Test signing and verification."""
    kp = KeyPair.generate("test_key")
    
    message = "hello world"
    signature = kp.sign_str(message)
    
    # Should verify
    assert verify_signature_str(kp.public_key_hex, signature, message)
    
    # Should fail with wrong message
    assert not verify_signature_str(kp.public_key_hex, signature, "wrong message")
