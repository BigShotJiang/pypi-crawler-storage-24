"""Substr8 Core Tests."""
