"""Tests for Substr8 Core schemas."""

import pytest
from datetime import datetime

from substr8_core import (
    RunProof,
    RunProofHeader,
    RunState,
    LifecycleStatus,
    EventType,
    RunStatus,
    TriggerType,
    TraceEntry,
    Identity,
    Signer,
    Context,
    Outputs,
    Commitments,
    Signature,
)


def test_runproof_header():
    """Test RunProofHeader creation."""
    header = RunProofHeader(
        proof_id="proof_abc123",
        run_id="run_xyz789",
        agent_id="claims/orchestrator",
        runtime="langgraph",
        started_at=datetime.utcnow(),
        status=RunStatus.COMPLETED,
    )
    
    assert header.proof_id == "proof_abc123"
    assert header.agent_id == "claims/orchestrator"
    assert header.status == RunStatus.COMPLETED


def test_trace_entry():
    """Test TraceEntry creation."""
    entry = TraceEntry(
        seq=1,
        event_id="evt_001",
        type=EventType.RUN_STARTED,
        timestamp=datetime.utcnow(),
        entry_hash="sha256:abc123",
    )
    
    assert entry.seq == 1
    assert entry.type == EventType.RUN_STARTED


def test_runproof_minimal():
    """Test minimal RunProof creation."""
    proof = RunProof(
        header=RunProofHeader(
            proof_id="proof_test",
            run_id="run_test",
            agent_id="test/agent",
            runtime="test",
            started_at=datetime.utcnow(),
            status=RunStatus.COMPLETED,
        ),
        identity=Identity(
            signer=Signer(
                key_id="test_key",
                public_key="ed25519:abc123",
                issuer="test",
            )
        ),
        context=Context(
            trigger_type=TriggerType.API,
            input_hash="sha256:input123",
        ),
        outputs=Outputs(
            result_hash="sha256:output456",
        ),
        commitments=Commitments(
            event_root="sha256:root789",
            proof_hash="sha256:proof000",
            signature=Signature(value="base64sig"),
        ),
    )
    
    assert proof.schema_version == "runproof/v2.1"  # v2.1 is now default
    assert proof.header.agent_id == "test/agent"


def test_runstate_lifecycle():
    """Test RunState lifecycle helpers."""
    state = RunState(
        run_id="run_test",
        agent_id="test/agent",
        lifecycle_status=LifecycleStatus.RUNNING,
    )
    
    assert not state.is_terminal
    assert not state.is_waiting
    
    state.lifecycle_status = LifecycleStatus.WAITING_FOR_HUMAN
    assert state.is_waiting
    
    state.lifecycle_status = LifecycleStatus.COMPLETED
    assert state.is_terminal


def test_runstate_retry():
    """Test RunState retry helpers."""
    state = RunState(
        run_id="run_test",
        agent_id="test/agent",
    )
    
    assert state.retry.can_retry
    assert state.retry.count == 0
    
    state.retry.count = 3
    assert not state.retry.can_retry


def test_runproof_serialization():
    """Test RunProof JSON serialization."""
    proof = RunProof(
        header=RunProofHeader(
            proof_id="proof_test",
            run_id="run_test",
            agent_id="test/agent",
            runtime="test",
            started_at=datetime(2026, 3, 9, 10, 0, 0),
            status=RunStatus.COMPLETED,
        ),
        identity=Identity(
            signer=Signer(
                key_id="test_key",
                public_key="ed25519:abc123",
                issuer="test",
            )
        ),
        context=Context(
            trigger_type=TriggerType.API,
            input_hash="sha256:input123",
        ),
        outputs=Outputs(
            result_hash="sha256:output456",
        ),
        commitments=Commitments(
            event_root="sha256:root789",
            proof_hash="sha256:proof000",
            signature=Signature(value="base64sig"),
        ),
    )
    
    # Serialize
    json_str = proof.model_dump_json()
    assert "runproof/v2.1" in json_str  # v2.1 is now default
    
    # Deserialize
    proof2 = RunProof.model_validate_json(json_str)
    assert proof2.header.proof_id == proof.header.proof_id


# ─────────────────────────────────────────────────────────────────────────────
# v2.1 Feature Tests
# ─────────────────────────────────────────────────────────────────────────────

from substr8_core.schemas.runproof import Claims, Lineage, Issuer, normalize_issuer


def test_issuer_object():
    """Test v2.1 Issuer object."""
    issuer = Issuer(
        name="substr8",
        version="1.7.2",
        runtime="langgraph",
        runtime_version="0.2.99",
    )
    
    assert issuer.name == "substr8"
    assert issuer.version == "1.7.2"
    assert issuer.runtime == "langgraph"


def test_normalize_issuer_from_string():
    """Test converting v2 string issuer to v2.1 object."""
    # Format: "name-runtime"
    issuer = normalize_issuer("substr8-langgraph")
    assert issuer.name == "substr8"
    assert issuer.runtime == "langgraph"
    
    # Simple string
    issuer2 = normalize_issuer("test")
    assert issuer2.name == "test"
    assert issuer2.runtime == "test"


def test_claims():
    """Test v2.1 Claims section."""
    claims = Claims(
        policy="trading-agent-policy-v3",
        model="gpt-4.1",
        environment="prod-us-east",
        compliance=["sox-compliant", "pci-dss"],
        custom={"trader_id": "T-4521"},
    )
    
    assert claims.policy == "trading-agent-policy-v3"
    assert "sox-compliant" in claims.compliance
    assert claims.custom["trader_id"] == "T-4521"


def test_lineage():
    """Test v2.1 Lineage section for chainable proofs."""
    lineage = Lineage(
        parent="sha256:abc123",
        root="sha256:def456",
        depth=3,
        workflow_id="wf_content_pipeline_001",
    )
    
    assert lineage.parent == "sha256:abc123"
    assert lineage.depth == 3


def test_runproof_with_v21_features():
    """Test RunProof with all v2.1 features."""
    from datetime import datetime, UTC
    
    proof = RunProof(
        header=RunProofHeader(
            proof_id="proof_v21_test",
            run_id="run_v21_test",
            agent_id="test/agent",
            runtime="langgraph",
            started_at=datetime.now(UTC),
            status=RunStatus.COMPLETED,
        ),
        identity=Identity(
            signer=Signer(
                key_id="test_key",
                public_key="ed25519:abc123",
                issuer=Issuer(
                    name="substr8",
                    version="1.7.2",
                    runtime="langgraph",
                ),
            )
        ),
        claims=Claims(
            policy="test-policy",
            model="claude-3.5-sonnet",
            environment="test",
        ),
        lineage=Lineage(
            parent=None,  # This is the root
            root=None,
            depth=1,
        ),
        context=Context(
            trigger_type=TriggerType.API,
            input_hash="sha256:input123",
        ),
        outputs=Outputs(
            result_hash="sha256:output456",
        ),
        commitments=Commitments(
            event_root="sha256:root789",
            proof_hash="sha256:proof000",
            signature=Signature(value="base64sig"),
        ),
    )
    
    assert proof.schema_version == "runproof/v2.1"
    assert proof.claims is not None
    assert proof.claims.model == "claude-3.5-sonnet"
    assert proof.lineage is not None
    assert proof.lineage.depth == 1
    
    # Check issuer is object
    assert isinstance(proof.identity.signer.issuer, Issuer)
    assert proof.identity.signer.issuer.name == "substr8"
