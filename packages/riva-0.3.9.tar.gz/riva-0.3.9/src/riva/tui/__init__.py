"""TUI dashboard modules."""
