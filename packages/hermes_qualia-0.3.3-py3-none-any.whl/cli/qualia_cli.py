"""Qualia CLI — command-line interface for Hermes Qualia."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import click


DEFAULT_QUALIA_REPO = Path("~/projects/hermes-qualia").expanduser()
DEFAULT_HERMES_HOME = Path(
    os.environ.get("QUALIA_HERMES_HOME")
    or os.environ.get("HERMES_HOME")
    or "~/.hermes"
).expanduser()
DEFAULT_HOOK_DEST = DEFAULT_HERMES_HOME / "hooks" / "qualia-autosync"


def get_qualia_repo() -> Path:
    repo = Path(os.environ.get("QUALIA_REPO", str(DEFAULT_QUALIA_REPO)))
    return repo.expanduser()


def _ledger() -> "SoulLedger":
    """Create SoulLedger with correct repo_dir from env."""
    from core.ledger import SoulLedger
    return SoulLedger(repo_dir=str(get_qualia_repo()))


# =============================================================================
# CLI group
# =============================================================================

@click.group()
def cli():
    """Hermes Qualia — Soul Ledger CLI."""
    pass


# =============================================================================
# Status & Observe
# =============================================================================

@cli.command()
def status():
    """Show current Qualia status."""
    from core.ledger import SoulLedger

    ledger = _ledger()
    last = ledger._last_manifest

    if last:
        click.echo(f"Last snap:  {last.snap_id[:12]}")
        click.echo(f"Trigger:    {last.trigger}")
        click.echo(f"Timestamp:  {last.timestamp}")
        click.echo(f"Files:      {list(last.files.keys())}")
        click.echo(f"Drift:      {last.drift_score:.4f}")
    else:
        click.echo("No manifests yet. Run 'qualia observe' first.")


@cli.command()
@click.option("--trigger", default="cli:manual", help="Trigger label")
def observe(trigger):
    """Capture current soul state. Does NOT commit to git."""
    from core.ledger import SoulLedger

    ledger = _ledger()
    result = ledger.observe(trigger=trigger)

    if result["changed"]:
        click.echo(f"Changed: {result['files']}")
        click.echo(f"Snap:    {result['snap_id'][:12]}")
        click.echo(f"Drift:   {result['drift_score']:.4f}")
        click.echo(f"Manifest: {result.get('manifest_path', 'N/A')}")
    else:
        click.echo("No change detected.")


# =============================================================================
# Review
# =============================================================================

@cli.command()
@click.option("--preset", default="narrador", help="Commentary preset")
@click.option("--force", is_flag=True, help="Commit even if nothing changed")
@click.option("--no-push", is_flag=True, help="Skip auto-push to remote")
def review(preset, force, no_push):
    """Run daily review: aggregate manifests + commentary + git commit."""
    from core.ledger import SoulLedger
    from historian.review import Historian
    from historian.session_context import SessionContext

    ledger = _ledger()
    historian = Historian(ledger, preset=preset)
    result = historian.review(force=force)

    if result.get("changed"):
        click.echo(f"Committed: {result.get('commit', 'N/A')}")
        click.echo(f"Files:     {result['files']}")
        click.echo(f"Drift:     {result.get('drift_score', 0):.4f}")
        push_res = result.get("push")
        if push_res:
            if push_res.success:
                click.echo(f"Push:      {push_res.message}")
            else:
                click.echo(f"Push:      FAILED — {push_res.message}", err=True)
        elif no_push:
            click.echo("Push:      skipped (--no-push)")
        if result.get("commentary"):
            preview = result["commentary"][:200].replace("\n", " ")
            click.echo(f"Preview:   {preview}...")
    else:
        click.echo(f"No changes ({result.get('reason', 'unknown')}).")


# =============================================================================
# Log
# =============================================================================

@cli.command()
@click.option("--limit", default=10, help="Number of commits to show")
def log(limit):
    """Show history of soul evolution commits."""
    repo = get_qualia_repo()
    result = subprocess.run(
        ["git", "-C", str(repo), "log", f"-{limit}", "--format=%H|%s|%ai"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        click.echo("Error reading git log", err=True)
        return

    for line in result.stdout.strip().split("\n"):
        if not line:
            continue
        parts = line.split("|")
        if len(parts) >= 3:
            sha = parts[0][:12]
            date = parts[2][:10]
            msg = "|".join(parts[1:]).strip()
            click.echo(f"{sha}  {date}  {msg}")


# =============================================================================
# Restore
# =============================================================================

@cli.command()
@click.argument("target")
@click.option("--dry-run", is_flag=True, help="Show what would be restored")
def restore(target, dry_run):
    """Restore soul/ to a previous snap_id or date.

    TARGET can be:
      - Full or short snap_id (e.g., abc123def456 or abc123def)
      - Date YYYY-MM-DD (most recent snap before that date)
    """
    from core.ledger import SoulLedger
    from historian.review import Historian

    repo = get_qualia_repo()
    ledger = SoulLedger(repo_dir=str(repo))

    # Determine target commit
    commit = _resolve_target(target, repo)
    if not commit:
        click.echo(f"Could not resolve target: {target}", err=True)
        sys.exit(1)

    if dry_run:
        click.echo(f"[dry-run] Would restore soul/ from: {commit}")
        return

    # Backup before restore
    backup_dir = ledger._create_backup()
    click.echo(f"Backup: {backup_dir}")

    # Restore
    from core.git_ops import GitOps
    git_ops = GitOps(repo_dir=str(repo), soul_dir=str(repo / "soul"))
    result = git_ops.restore(commit)

    if result.success:
        click.echo(f"Restored soul/ from {commit[:12]}")
    else:
        click.echo(f"Restore failed: {result.message}", err=True)


def _resolve_target(target: str, repo: Path) -> str:
    """Resolve target (snap_id or date) to git commit hash."""
    # Try as snap_id (full or short)
    result = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--verify", "--short", target],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()

    # Try as date — find most recent commit before date
    result = subprocess.run(
        [
            "git", "-C", str(repo), "log",
            "--format=%H",
            f"--before={target}T23:59:59",
            "-1",
        ],
        capture_output=True, text=True,
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()

    return ""


# =============================================================================
# Config
# =============================================================================

@cli.command()
def config():
    """Show Qualia configuration."""
    from core.config import QualiaConfig

    cfg = QualiaConfig.load()
    click.echo(f"repo_dir:       {cfg.repo_dir}")
    click.echo(f"hermes_home:    {cfg.hermes_home}")
    click.echo(f"poll_interval:  {cfg.poll_interval}s")
    click.echo(f"lock_timeout:   {cfg.lock_timeout}s")
    click.echo(f"drift_threshold:{cfg.drift_threshold}")


@cli.command()
@click.option("--set", "key_value", nargs=2, type=str, help="key value to set")
def config_set(key_value):
    """Set a Qualia config value."""
    # For now just show the value that would be set
    if key_value:
        click.echo(f"Would set: {key_value[0]} = {key_value[1]}")
    else:
        click.echo("Usage: qualia config --set <key> <value>")


# =============================================================================
# Poll watcher
# =============================================================================

@cli.command()
def poll_start():
    """Start the background poll watcher."""
    from observer.poll_watcher import PollWatcher
    from core.ledger import SoulLedger

    ledger = _ledger()
    watcher = PollWatcher(ledger)
    watcher.start()
    click.echo("Poll watcher started. PID will end when this process exits.")


@cli.command()
def poll_stop():
    """Stop the background poll watcher."""
    click.echo("Poll watcher stopping is not yet implemented.")
    click.echo("Kill the PollWatcher process manually.")


@cli.command()
def poll_status():
    """Check poll watcher status."""
    click.echo("Poll watcher status: use process management (ps/top)")


# =============================================================================
# Install
# =============================================================================

@cli.command()
@click.option("--repo-url", default="git@github.com:maelrx/hermes-qualia.git", help="Git repo to clone")
@click.option("--path", default="~/.hermes/qualia", help="Where to install Qualia")
@click.option("--model", help="Model to use for commentary (e.g. MiniMax-M2.7, gpt-4o)")
@click.option("--provider", help="Provider (minimax, openai, openrouter)")
@click.option("--api-key", help="API key for the model")
@click.option("--base-url", help="API base URL")
@click.option("--force", is_flag=True, help="Overwrite existing installation")
def install(repo_url, path, model, provider, api_key, base_url, force):
    """One-command install: clone repo, detect Hermes config, setup hook."""
    install_path = Path(path).expanduser()
    hermes_home = Path(os.environ.get("HERMES_HOME", "~/.hermes")).expanduser()

    click.echo("=== Qualia Installer ===")

    # 1. Clone or update repo
    if install_path.exists() and not force:
        click.echo(f"Already installed at {install_path}. Use --force to reinstall.")
    else:
        if install_path.exists():
            shutil.rmtree(install_path)
        click.echo(f"Cloning {repo_url}...")
        result = subprocess.run(
            ["git", "clone", repo_url, str(install_path)],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            click.echo(f"Clone failed: {result.stderr}", err=True)
            sys.exit(1)
        click.echo(f"Cloned to {install_path}")

    # 2. Install Python deps
    click.echo("Installing Python dependencies...")
    result = subprocess.run(
        ["pip3", "install", "--quiet", "click"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        click.echo(f"pip install click failed: {result.stderr}", err=True)

    # 3. Setup directories
    manifests_dir = install_path / "manifests"
    soul_dir = install_path / "soul"
    backups_dir = install_path / "backups"
    for d in [manifests_dir, soul_dir, backups_dir]:
        d.mkdir(parents=True, exist_ok=True)
    click.echo(f"Directories: manifests/, soul/, backups/")

    # 4. Register hook
    hook_src_handler = install_path / "observer" / "hook_handler.py"
    hook_src_yaml = install_path / "observer" / "hook_template" / "HOOK.yaml"
    hook_dst = hermes_home / "hooks" / "qualia-autosync"

    hook_dst.mkdir(parents=True, exist_ok=True)
    if hook_src_handler.exists():
        shutil.copy2(hook_src_handler, hook_dst / "handler.py")
    if hook_src_yaml.exists():
        shutil.copy2(hook_src_yaml, hook_dst / "HOOK.yaml")
    click.echo(f"Hook installed: {hook_dst}")

    # 5. Detect Hermes config and configure commentary model
    detected = _detect_hermes_model(hermes_home)

    if not model:
        click.echo("")
        click.echo("=== Commentary Model ===")
        hermes_model = detected.get("default_model", "unknown")
        hermes_provider = detected.get("provider", "unknown")
        click.echo(f"Detected Hermes: {hermes_model} ({hermes_provider})")
        click.echo("")
        click.echo("Select model for Qualia commentary:")
        click.echo("  1) Use Hermes default model (recommended)")
        click.echo("  2) MiniMax-M2.7 (if Hermes has MiniMax key)")
        click.echo("  3) Custom (enter manually)")
        choice = click.prompt("Choice", type=int, default=1)

        if choice == 1:
            model = hermes_model
            provider = hermes_provider
            base_url = detected.get("base_url", "")
            # Prefer the key that matches the provider (avoid 402 from OpenRouter without credits)
            openrouter_key = detected.get("openrouter_key", "")
            minimax_key = detected.get("minimax_key", "")
            if openrouter_key and hermes_provider == "openrouter":
                api_key = openrouter_key
            elif minimax_key:
                api_key = minimax_key
            elif openrouter_key:
                api_key = openrouter_key
            else:
                api_key = ""
        elif choice == 2:
            model = "MiniMax-M2.7"
            provider = "minimax"
            base_url = "https://api.minimax.io/anthropic/v1"
            api_key = detected.get("minimax_key", "")
        else:
            model = click.prompt("Model name (e.g. gpt-4o, claude-3-5-sonnet)")
            provider = click.prompt("Provider (minimax/openai/openrouter)")
            base_url = click.prompt("Base URL (leave empty for default)")
            api_key = click.prompt("API Key", hide_input=True)

    # 6. Write QUALIA config to hermes .env
    env_file = hermes_home / ".env"
    env_content = env_file.read_text() if env_file.exists() else ""

    config_lines = f"\n# Qualia — Commentary Model\n"
    config_lines += f"QUALIA_MODEL={model}\n"
    config_lines += f"QUALIA_PROVIDER={provider}\n"
    if base_url:
        config_lines += f"QUALIA_API_BASE={base_url}\n"
    if api_key:
        config_lines += f"QUALIA_API_KEY={api_key}\n"

    if "QUALIA_MODEL" not in env_content:
        env_content += config_lines
        env_file.write_text(env_content)
        click.echo(f"Model configured: {provider}/{model}")
    else:
        click.echo("Qualia model already configured in .env")

    # 7. Summary
    click.echo("")
    click.echo("=== Installed ===")
    click.echo(f"  Repo:     {install_path}")
    click.echo(f"  Hook:     {hook_dst}")
    click.echo(f"  Model:    {provider}/{model}")
    click.echo("")
    click.echo("Next: restart Hermes gateway, then:")
    click.echo(f"  export QUALIA_REPO={install_path}")
    click.echo(f"  qualia status")


def _detect_hermes_model(hermes_home: Path) -> dict:
    """Read Hermes config to detect model and API keys.

    Priority: .env LLM_MODEL > config.yaml model > defaults.
    This ensures we pick Hermes' actual active model, not an alternate provider.
    """
    result = {
        "default_model": "MiniMax-M2.7",
        "provider": "minimax",
        "base_url": "https://api.minimax.io/anthropic/v1",
        "minimax_key": "",
        "openrouter_key": "",
    }

    # Read .env first — this has the active LLM_MODEL and API keys
    env_file = hermes_home / ".env"
    if env_file.exists():
        env_text = env_file.read_text()
        for line in env_text.splitlines():
            if line.startswith("LLM_MODEL="):
                val = line.split("=", 1)[1].strip()
                if val:
                    result["default_model"] = val
            elif line.startswith("MINIMAX_API_KEY="):
                val = line.split("=", 1)[1].strip()
                if val:
                    result["minimax_key"] = val
            elif line.startswith("OPENROUTER_API_KEY="):
                val = line.split("=", 1)[1].strip()
                if val:
                    result["openrouter_key"] = val

    # Read config.yaml — has provider/base_url, but don't override model if .env already has it
    config_file = hermes_home / "config.yaml"
    if config_file.exists():
        import yaml
        try:
            config = yaml.safe_load(config_file.read_text())
            model_cfg = config.get("model", {})
            cfg_base_url = model_cfg.get("base_url", "")
            cfg_provider = model_cfg.get("provider", "")
            cfg_model = model_cfg.get("default", "")

            # Detect provider from base_url if not obvious
            if cfg_base_url:
                if "minimax.io" in cfg_base_url or "minimaxi" in cfg_base_url:
                    result["provider"] = "minimax"
                    result["base_url"] = cfg_base_url.rstrip("/") + "/v1"
                elif "openrouter" in cfg_base_url:
                    result["provider"] = "openrouter"
                    result["base_url"] = cfg_base_url.rstrip("/") + "/v1"
                else:
                    if cfg_provider:
                        result["provider"] = cfg_provider
                    if cfg_base_url:
                        result["base_url"] = cfg_base_url.rstrip("/") + "/v1"

            # default_model: prefer .env LLM_MODEL, fallback to config.yaml
            if not result["default_model"] or result["default_model"] == "MiniMax-M2.7":
                if cfg_model:
                    result["default_model"] = cfg_model
        except Exception:
            pass

    return result


# =============================================================================
# Hook management
# =============================================================================

@cli.command()
@click.option("--dry-run", is_flag=True, help="Show what would be installed")
def install_hook(dry_run):
    """Install the Qualia hook into ~/.hermes/hooks/qualia-autosync/."""
    repo = get_qualia_repo()
    hook_src = repo / "observer" / "hook_template"
    hook_dst = DEFAULT_HOOK_DEST

    if not hook_src.exists():
        click.echo(f"Error: hook template not found at {hook_src}", err=True)
        sys.exit(1)

    if dry_run:
        click.echo(f"[dry-run] Would copy {hook_src}/* -> {hook_dst}/")
        return

    hook_dst.mkdir(parents=True, exist_ok=True)

    src_yaml = hook_src / "HOOK.yaml"
    if src_yaml.exists():
        shutil.copy2(src_yaml, hook_dst / "HOOK.yaml")

    handler_src = repo / "observer" / "hook_handler.py"
    if handler_src.exists():
        shutil.copy2(handler_src, hook_dst / "handler.py")

    click.echo(f"Installed hook at {hook_dst}")


@cli.command()
def uninstall_hook():
    """Remove the Qualia hook from ~/.hermes/hooks/."""
    hook_dst = DEFAULT_HOOK_DEST
    if hook_dst.exists():
        shutil.rmtree(hook_dst)
        click.echo(f"Removed {hook_dst}")
    else:
        click.echo("Hook not installed.")


# =============================================================================
# Health
# =============================================================================

@cli.command()
def health():
    """Check Qualia hook health status."""
    from observer.health import HookHealth

    health = HookHealth()
    result = health.check()

    click.echo(f"Qualia Hook Health — {result['checked_at']}")
    click.echo("")
    for check in result["checks"]:
        icon = {"ok": "✅", "degraded": "⚠️", "broken": "❌"}.get(check["status"], "?")
        click.echo(f"  {icon} {check['name']}: {check['message']}")
    click.echo("")
    click.echo(result["summary"])


# =============================================================================
# Purge
# =============================================================================

@cli.command()
@click.option("--confirm", is_flag=True, help="Actually delete. Without this, runs dry-run.")
def purge(confirm):
    """Delete all manifests and backups. DANGER. Git history preserved."""
    repo = get_qualia_repo()
    manifests = repo / "manifests"
    backups = repo / "backups"

    if not confirm:
        click.echo("[dry-run] Would delete:")
        if manifests.exists():
            click.echo(f"  {manifests}/* ({len(list(manifests.glob('*.json')))} files)")
        if backups.exists():
            click.echo(f"  {backups}/* ({len(list(backups.glob('*')))} files)")
        click.echo("Run with --confirm to actually delete.")
        return

    if manifests.exists():
        for f in manifests.glob("*.json"):
            f.unlink()
        click.echo(f"Deleted {manifests}/*.json")

    if backups.exists():
        shutil.rmtree(backups)
        backups.mkdir()
        click.echo(f"Reset {backups}/")


# =============================================================================
# Main
# =============================================================================

if __name__ == "__main__":
    cli()
