"""Hook health monitoring — checks if Qualia hook is installed and healthy."""

from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_HERMES_HOME = Path(
    os.environ.get("QUALIA_HERMES_HOME")
    or os.environ.get("HERMES_HOME")
    or "~/.hermes"
).expanduser()
HOOK_DIR = DEFAULT_HERMES_HOME / "hooks" / "qualia-autosync"
GATEWAY_PID_FILE = DEFAULT_HERMES_HOME / "gateway.pid"


class HookHealth:
    """
    Check health status of the Qualia hook installation.

    Usage:
        health = HookHealth()
        status = health.check()  # returns dict
    """

    def check(self) -> dict:
        """
        Run all health checks and return a status report.

        Returns:
            dict with keys:
                - status: "healthy" | "degraded" | "broken"
                - checks: list of individual check results
                - summary: human-readable string
        """
        checks = [
            self._check_hook_installed(),
            self._check_hook_yaml(),
            self._check_handler_exists(),
            self._check_gateway_running(),
        ]

        statuses = [c["status"] for c in checks]
        if "broken" in statuses:
            overall = "broken"
        elif "degraded" in statuses:
            overall = "degraded"
        else:
            overall = "healthy"

        return {
            "status": overall,
            "checks": checks,
            "summary": self._summarize(checks, overall),
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    def _check_hook_installed(self) -> dict:
        """Check if hook directory exists."""
        installed = HOOK_DIR.exists() and HOOK_DIR.is_dir()
        return {
            "name": "hook_directory",
            "status": "ok" if installed else "broken",
            "message": f"{HOOK_DIR}" if installed else "Hook dir not found",
        }

    def _check_hook_yaml(self) -> dict:
        """Check if HOOK.yaml exists and is valid."""
        yaml_path = HOOK_DIR / "HOOK.yaml"
        if not yaml_path.exists():
            return {
                "name": "hook_yaml",
                "status": "broken",
                "message": "HOOK.yaml not found",
            }

        try:
            import yaml
            with open(yaml_path) as f:
                data = yaml.safe_load(f)

            if not data:
                return {
                    "name": "hook_yaml",
                    "status": "degraded",
                    "message": "HOOK.yaml is empty",
                }

            required = ["name", "events"]
            missing = [k for k in required if k not in data]
            if missing:
                return {
                    "name": "hook_yaml",
                    "status": "degraded",
                    "message": f"Missing fields: {missing}",
                }

            return {
                "name": "hook_yaml",
                "status": "ok",
                "message": f"Hook: {data.get('name', 'unknown')} v{data.get('version', '?')}",
            }
        except ImportError:
            return {
                "name": "hook_yaml",
                "status": "degraded",
                "message": "pyyaml not installed — can't validate",
            }
        except Exception as e:
            return {
                "name": "hook_yaml",
                "status": "broken",
                "message": f"Error: {e}",
            }

    def _check_handler_exists(self) -> dict:
        """Check if handler.py exists."""
        handler = HOOK_DIR / "handler.py"
        if not handler.exists():
            return {
                "name": "handler_exists",
                "status": "broken",
                "message": "handler.py not found",
            }
        return {
            "name": "handler_exists",
            "status": "ok",
            "message": f"handler.py ({handler.stat().st_size} bytes)",
        }

    def _check_gateway_running(self) -> dict:
        """Check if Hermes gateway process is running."""
        # Check pid file
        if GATEWAY_PID_FILE.exists():
            try:
                pid = int(GATEWAY_PID_FILE.read_text().strip())
                # Check if process exists
                result = subprocess.run(
                    ["ps", "-p", str(pid), "-o", "pid="],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    return {
                        "name": "gateway",
                        "status": "ok",
                        "message": f"Gateway PID {pid}",
                    }
                else:
                    return {
                        "name": "gateway",
                        "status": "degraded",
                        "message": f"Stale PID file (pid={pid})",
                    }
            except (ValueError, OSError):
                pass

        # Check for any hermes-gateway process
        result = subprocess.run(
            ["pgrep", "-f", "hermes-gateway"],
            capture_output=True, text=True,
        )
        if result.stdout.strip():
            return {
                "name": "gateway",
                "status": "ok",
                "message": f"Gateway running (pgrep found)",
            }

        return {
            "name": "gateway",
            "status": "degraded",
            "message": "Gateway not detected (hook won't fire without it)",
        }

    def _summarize(self, checks: list, overall: str) -> str:
        """Build human-readable summary."""
        ok = sum(1 for c in checks if c["status"] == "ok")
        degraded = sum(1 for c in checks if c["status"] == "degraded")
        broken = sum(1 for c in checks if c["status"] == "broken")

        emoji = {"healthy": "✅", "degraded": "⚠️", "broken": "❌"}[overall]
        parts = [f"{emoji} {overall.upper()}"]
        if ok:
            parts.append(f"{ok} ok")
        if degraded:
            parts.append(f"{degraded} degraded")
        if broken:
            parts.append(f"{broken} broken")

        return " | ".join(parts)
