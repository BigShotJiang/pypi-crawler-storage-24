"""PollWatcher — background daemon for observing soul state.

Watches tracked files for changes using inotify (Linux) or polling fallback.
Used primarily for CLI sessions (gateway has hooks) and SOUL.md changes.

Runs as a background thread. Continuously monitors until stop() is called.
"""

from __future__ import annotations

import hashlib
import threading
import time
from pathlib import Path
from typing import Optional

# Optional inotify support
try:
    import inotify.adapters
    INOTIFY_AVAILABLE = True
except ImportError:
    INOTIFY_AVAILABLE = False


class PollWatcher:
    """
    Background watcher for Hermes soul state changes.

    Uses inotify on Linux for real-time detection.
    Falls back to polling every POLL_INTERVAL seconds.

    Thread-safe: runs in background daemon thread.

    Args:
        ledger: SoulLedger instance to use for observe()
        poll_interval: Seconds between polling checks (default 60)
    """

    POLL_INTERVAL = 60  # seconds

    def __init__(self, ledger, poll_interval: int = POLL_INTERVAL):
        self.ledger = ledger
        self.poll_interval = poll_interval
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.last_hashes: dict[str, str] = {}

    # -------------------------------------------------------------------------
    # Hashing
    # -------------------------------------------------------------------------

    def _hash_file(self, path: Path) -> str:
        """SHA-256 hex of file content."""
        if not path.exists():
            return ""
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def _initial_hash(self):
        """Populate last_hashes with current state."""
        for name, path in self.ledger._tracked_files.items():
            self.last_hashes[name] = self._hash_file(path)

    def _check_changes(self) -> bool:
        """Return True if any tracked file changed since last check."""
        changed = False
        for name, path in self.ledger._tracked_files.items():
            current_hash = self._hash_file(path)
            if self.last_hashes.get(name) != current_hash:
                self.last_hashes[name] = current_hash
                changed = True
        return changed

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    def start(self):
        """Start watcher in background daemon thread."""
        self._initial_hash()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="PollWatcher")
        self._thread.start()

    def stop(self):
        """Stop the watcher thread."""
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    # -------------------------------------------------------------------------
    # Main loop
    # -------------------------------------------------------------------------

    def _run(self):
        """Main loop: inotify + polling fallback."""
        if INOTIFY_AVAILABLE:
            self._run_inotify()
        else:
            self._run_polling()

    def _run_inotify(self):
        """Use inotify for real-time file change detection."""
        # Build inotify watches for each tracked file directory
        dirs_to_watch = set()
        for path in self.ledger._tracked_files.values():
            dirs_to_watch.add(path.parent)

        i = inotify.adapters.Inotify()
        for d in dirs_to_watch:
            if d.exists():
                i.add_watch(str(d))

        try:
            for event in i.event_gen(timeout=1000):
                if self._stop.is_set():
                    break
                if event is None:
                    continue
                # File changed — check and observe
                if self._check_changes():
                    self._on_change()
        finally:
            i.close()

    def _run_polling(self):
        """Fallback: poll every poll_interval seconds."""
        while not self._stop.is_set():
            if self._check_changes():
                self._on_change()
            self._stop.wait(self.poll_interval)

    def _on_change(self):
        """Called when a change is detected. Runs observe()."""
        try:
            result = self.ledger.observe(trigger="poll:detected")
            if result.get("changed"):
                files = ",".join(result.get("files", [])) or "no-change"
                print(f"[qualia poll] obs: {files}", flush=True)
            else:
                print(f"[qualia poll] obs: no-change", flush=True)
        except Exception as e:
            print(f"[qualia poll] error: {e}", flush=True)
