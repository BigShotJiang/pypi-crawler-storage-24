"""Hook handler for Hermes gateway events.

Receives events from Hermes gateway hook system.
Runs observe() — generates manifest, does NOT commit.

Install via: qualia install-hook
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

# Add qualia repo to path
QUALIA_REPO = os.environ.get("QUALIA_REPO", "~/projects/hermes-qualia")
_QUALIA_REPO = Path(QUALIA_REPO).expanduser()
if _QUALIA_REPO.exists() and str(_QUALIA_REPO) not in sys.path:
    sys.path.insert(0, str(_QUALIA_REPO))


def handle(event_type: str, context: dict) -> dict:
    """
    Handle a gateway event by running observe().

    This function is called by the Hermes hook system when
    agent:end, session:end, or session:reset events fire.

    It runs observe() which:
    - Computes current soul state
    - If changed: generates manifest JSON, syncs soul/ mirror
    - Does NOT commit (historian does that on cron)

    Args:
        event_type: The event name (e.g., "agent:end", "session:end")
        context: Dict with session_id and other event metadata

    Returns:
        dict with keys: changed (bool), files (list), snap_id (str)
    """
    try:
        from core.ledger import SoulLedger

        ledger = SoulLedger(repo_dir=str(_QUALIA_REPO))

        result = ledger.observe(
            trigger=f"gateway:{event_type}",
            session_id=context.get("session_id"),
        )

        files = result.get("files", [])
        label = ",".join(files) if files else "no-change"
        print(f"[qualia] obs: {label}", flush=True)

        return result

    except Exception as e:
        print(f"[qualia] error: {e}", flush=True)
        # Never raises — hook error must not block gateway
        return {"changed": False, "files": [], "snap_id": "", "error": str(e)}
