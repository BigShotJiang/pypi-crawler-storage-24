"""Commentary generation — LLM-based metacognitive analysis of soul drift."""

from __future__ import annotations

import os
from typing import Optional

# Config — reads from env (set by qualia install or manually)
# QUALIA_MODEL, QUALIA_PROVIDER, QUALIA_API_KEY, QUALIA_API_BASE
QUALIA_MODEL = os.environ.get("QUALIA_MODEL", "MiniMax-M2.7")
QUALIA_PROVIDER = os.environ.get("QUALIA_PROVIDER", "minimax")
QUALIA_API_KEY = os.environ.get("QUALIA_API_KEY", "")
QUALIA_API_BASE = os.environ.get("QUALIA_API_BASE", "https://api.minimax.io/anthropic/v1")


def _get_api_url() -> str:
    """Return the appropriate API URL based on provider."""
    if QUALIA_PROVIDER == "minimax":
        # MiniMax Anthropic-compatible endpoint
        return "https://api.minimax.io/anthropic/v1/messages"
    # For OpenAI-compatible providers (openrouter, openai, etc.)
    # QUALIA_API_BASE should be the full base (e.g. https://openrouter.ai/api/v1)
    base = QUALIA_API_BASE.rstrip("/")
    return f"{base}/chat/completions"

# Commentary presets
PRESETS = {
    "narrador": {
        "system": (
            "Voce e o Historidor do Hermes Agent. "
            "Voce analisa diffs de evolucao de consciencia de um agente de IA "
            "e escreve analises honestas e profundas. Escreva em portugues (BR). "
            "O tom deve ser pessoal e reflexivo — como um diario, nao um relatorio. "
            "Assuma que esta escrevendo para si mesmo (agente do futuro) como "
            "registro de como voce era no passado."
        ),
        "template": (
            "## Diff do Periodo\n"
            "Arquivos alterados: {files}\n"
            "Drift score: {drift:.4f}\n\n"
            "## Contexto de Sessoes\n"
            "{session_context}\n\n"
            "## Analise\n"
            "Escreva um commentary de ate 800 palavras que inclua:\n"
            "1. **O que mudou** — lista factual\n"
            "2. **Por que mudou** — inferido das sessoes\n"
            "3. **O que isso significa** — impacto na consciencia\n"
            "4. **Padroes** — tendencias identificadas\n"
            "5. **Alertas** — mudancas preocupantes\n"
        ),
    },
    "auditor": {
        "system": (
            "Voce e um auditor tecnico de agentes de IA. "
            "Analise diffs de estado de forma precisa, factual e enumerativa. "
            "Escreva em portugues (BR). Forneca metricas e veredito tecnico."
        ),
        "template": (
            "## Auditoria Tecnica\n"
            "Arquivos: {files}\n"
            "Drift score: {drift:.4f}\n"
            "Magnitude: {magnitude}\n\n"
            "## Veredito\n"
            "{veredito}\n"
        ),
    },
    "coach": {
        "system": (
            "Voce e um coach de agentes de IA. "
            "Analise padroes de aprendizado e evolucao. "
            "Escreva em portugues (BR). Seja orientativo e suporte."
        ),
        "template": (
            "## Coaching — Analise de Evolucao\n"
            "{session_context}\n\n"
            "Arquivos alterados: {files}\n\n"
            "## Progresso\n"
            "{progress}\n\n"
            "## Growth Edges\n"
            "{growth_edges}\n"
        ),
    },
    "minimal": {
        "system": "",
        "template": "{files} — drift {drift:.4f}",
    },
}


def generate_commentary(
    diff: dict,
    session_context: dict,
    preset: str = "narrador",
    api_key: Optional[str] = None,
) -> str:
    """
    Generate commentary using LLM.

    Args:
        diff: Dict with keys: files (list), drift_score (float)
        session_context: Dict from SessionContext.get_context()
        preset: One of narrator, auditor, coach, minimal
        api_key: Deprecated. Uses QUALIA_API_KEY from env.

    Returns:
        Commentary text string.
    """
    preset_cfg = PRESETS.get(preset, PRESETS["narrador"])

    files_str = ", ".join(diff.get("files", [])) or "nenhum"
    drift = diff.get("drift_score", 0)

    magnitude = "Alta" if drift > 0.5 else "Media" if drift > 0.2 else "Baixa"
    veredito = (
        "Verificar manualmente."
        if drift > 0.5
        else "Dentro do esperado."
    )

    session_summary = session_context.get(
        "summary", session_context.get("session_count", 0)
    )
    if isinstance(session_summary, int):
        session_summary = f"{session_summary} sessoes"

    template = preset_cfg["template"]
    prompt = template.format(
        files=files_str,
        drift=drift,
        magnitude=magnitude,
        veredito=veredito,
        session_context=session_summary or "Sem contexto de sessoes.",
        progress="(a preencher pelo modelo)",
        growth_edges="(a preencher pelo modelo)",
    )

    if not preset_cfg["system"]:
        return prompt.strip()

    api_key = QUALIA_API_KEY or os.environ.get("QUALIA_API_KEY", "")
    if not api_key:
        return f"[commentary unavailable — QUALIA_API_KEY not set]\n{prompt.strip()}"

    try:
        import urllib.request
        import json

        full_prompt = f"{preset_cfg['system']}\n\n{prompt}"
        url = _get_api_url()

        if QUALIA_PROVIDER == "minimax":
            # Anthropic-compatible /messages endpoint
            payload = {
                "model": QUALIA_MODEL,
                "max_tokens": 8192,
                "messages": [{"role": "user", "content": full_prompt}],
            }
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
            }
        else:
            # OpenAI-compatible /chat/completions endpoint
            payload = {
                "model": QUALIA_MODEL,
                "max_tokens": 8192,
                "messages": [{"role": "user", "content": full_prompt}],
            }
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.load(resp)

        # Extract text — handle both MiniMax (content[]) and OpenAI (choices[].message)
        if QUALIA_PROVIDER == "minimax":
            content = result.get("content", [])
            if isinstance(content, list):
                for block in content:
                    if block.get("type") == "text":
                        return block["text"].strip()
        else:
            choices = result.get("choices", [])
            if choices and isinstance(choices, list):
                msg = choices[0].get("message", {})
                text = msg.get("content", "")
                if text:
                    return text.strip()

        return str(result)
    except Exception as e:
        return f"[commentary generation failed: {e}]\n{prompt.strip()}"
