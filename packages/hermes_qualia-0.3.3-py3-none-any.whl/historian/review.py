"""Historian — periodic review of soul evolution with commentary and git commit."""

from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from core.ledger import SoulLedger
from core.git_ops import GitOps
from historian.session_context import SessionContext
from historian.commentary import generate_commentary, PRESETS


class Historian:
    """
    Aggregate manifests and produce a historical commit with commentary.

    Usage:
        ledger = SoulLedger()
        historian = Historian(ledger)
        result = historian.review()
    """

    def __init__(
        self,
        ledger: SoulLedger,
        preset: str = "narrador",
        session_context: Optional[SessionContext] = None,
    ):
        self.ledger = ledger
        self.preset = preset
        self.session_context = session_context or SessionContext()

    # -------------------------------------------------------------------------
    # Review — main entry point
    # -------------------------------------------------------------------------

    def review(self, force: bool = False) -> dict:
        """
        Perform a review of all unreviewed manifests.

        If any tracked files changed since last review:
        1. Aggregate diffs from manifests
        2. Get session context from state.db
        3. Generate commentary (LLM or fallback)
        4. Sync soul/ mirror to current state
        5. git add soul/ + git commit
        6. Mark last review timestamp

        Args:
            force: If True, always commit even if nothing changed.

        Returns:
            dict with keys: changed (bool), files (list), commentary (str),
                           commit (str or None), drift_score (float)
        """
        manifests = self._get_unreviewed_manifests()
        aggregated = self._aggregate_diffs(manifests)

        if not aggregated["files"] and not force:
            return {"changed": False, "reason": "no new manifests"}

        # Get session context
        start_ts = manifests[0].stat().st_mtime if manifests else None
        end_ts = manifests[-1].stat().st_mtime if manifests else None
        ctx = {}
        if start_ts and end_ts:
            ctx = self.session_context.get_context(start_ts, end_ts)

        # Generate commentary
        commentary = generate_commentary(
            diff=aggregated,
            session_context=ctx,
            preset=self.preset,
        )

        # Sync soul/ mirror
        self.ledger._sync_soul_files(list(self.ledger._tracked_files.keys()))

        # Git add soul/
        self._git_add()

        # Git commit
        snap_id = self.ledger.snap()["snap_id"]
        commit_sha = self._git_commit(
            commentary=commentary,
            files=aggregated["files"],
            snap_id=snap_id,
            drift_score=aggregated.get("drift_score", 0),
            session_count=ctx.get("session_count", 0),
        )

        # Mark reviewed
        self._mark_reviewed()

        # Auto-push to remote if configured and not disabled
        push_result = None
        auto_push = os.environ.get("QUALIA_AUTO_PUSH", "true").lower() != "false"
        if auto_push:
            git_ops = GitOps(repo_dir=str(self.ledger.repo_dir), soul_dir=str(self.ledger.soul_dir))
            if git_ops.has_remote():
                push_result = git_ops.push()

        return {
            "changed": True,
            "files": aggregated["files"],
            "commentary": commentary,
            "commit": commit_sha,
            "drift_score": aggregated.get("drift_score", 0),
            "push": push_result,
        }

    # -------------------------------------------------------------------------
    # Manifest aggregation
    # -------------------------------------------------------------------------

    def _get_unreviewed_manifests(self) -> list:
        """Return manifest files since last review."""
        marker = self.ledger.manifests_dir / ".last_review"
        last_ts = float(marker.read_text()) if marker.exists() else 0

        manifests = sorted(self.ledger.manifests_dir.glob("*.json"))
        return [m for m in manifests if m.stat().st_mtime > last_ts]

    def _aggregate_diffs(self, manifests: list) -> dict:
        """Aggregate all file changes from manifests."""
        import json

        all_files = {}
        drift_scores = []

        for m_path in manifests:
            data = json.loads(m_path.read_text())
            for fname, fdata in (data.get("files") or {}).items():
                if fdata.get("changed"):
                    all_files[fname] = fdata
            drift_scores.append(data.get("drift_score", 0))

        avg_drift = sum(drift_scores) / len(drift_scores) if drift_scores else 0

        return {
            "files": list(all_files.keys()),
            "files_detail": all_files,
            "drift_score": avg_drift,
        }

    # -------------------------------------------------------------------------
    # Git operations
    # -------------------------------------------------------------------------

    def _git_add(self):
        """Stage soul/ and manifests/ for commit."""
        subprocess.run(
            ["git", "-C", str(self.ledger.repo_dir), "add", "soul/", "manifests/"],
            check=False,
        )

    def _git_commit(
        self,
        commentary: str,
        files: list,
        snap_id: str,
        drift_score: float,
        session_count: int,
    ) -> Optional[str]:
        """Create git commit with commentary and metadata footer."""
        msg_lines = [commentary, "\n---\n"]
        msg_lines.append(f"snap_id:    {snap_id}\n")
        msg_lines.append(f"preset:     {self.preset}\n")
        msg_lines.append(f"drift:      {drift_score:.4f}\n")
        msg_lines.append(f"files:      {', '.join(files)}\n")
        msg_lines.append(f"sessions:   {session_count}\n")

        full_msg = "".join(msg_lines)

        result = subprocess.run(
            ["git", "-C", str(self.ledger.repo_dir), "commit", "-m", full_msg],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            sha = result.stdout.strip()
            return sha
        return None

    def _mark_reviewed(self):
        """Mark current timestamp as last review."""
        marker = self.ledger.manifests_dir / ".last_review"
        marker.write_text(str(datetime.now(timezone.utc).timestamp()))
