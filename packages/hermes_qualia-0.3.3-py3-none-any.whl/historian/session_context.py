"""SessionContext — read Hermes state.db for session history."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class SessionContext:
    """
    Read Hermes state.db to provide session context for commentary.

    Uses direct SQLite queries — no LLM calls, fast, free.
    Historian injects this context into the commentary prompt.

    Args:
        db_path: Path to Hermes state.db. Defaults to ~/.hermes/state.db.
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        if db_path is None:
            db_path = Path("~/.hermes/state.db").expanduser()
        self.db_path = Path(db_path)

    def get_context(self, start_ts: float, end_ts: float) -> dict:
        """
        Get aggregated session context for a time period.

        Args:
            start_ts: Unix timestamp (start of period)
            end_ts: Unix timestamp (end of period)

        Returns:
            dict with keys:
                - sessions: list of session summaries
                - session_count: int
                - message_count: int
                - summary: human-readable string
        """
        if not self.db_path.exists():
            return {
                "sessions": [],
                "session_count": 0,
                "message_count": 0,
                "summary": "state.db not found",
            }

        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
        except sqlite3.OperationalError:
            return {
                "sessions": [],
                "session_count": 0,
                "message_count": 0,
                "summary": "state.db locked or unavailable",
            }

        try:
            rows = conn.execute("""
                SELECT s.id, s.started_at, s.source, s.title,
                       COUNT(m.id) as msg_count
                FROM sessions s
                LEFT JOIN messages m ON m.session_id = s.id
                WHERE s.started_at >= ? AND s.started_at <= ?
                GROUP BY s.id
                ORDER BY s.started_at DESC
                LIMIT 20
            """, (start_ts, end_ts)).fetchall()
        except sqlite3.OperationalError:
            return {
                "sessions": [],
                "session_count": 0,
                "message_count": 0,
                "summary": "query failed",
            }

        sessions = []
        for r in rows:
            sessions.append({
                "id": r["id"],
                "started_at": datetime.fromtimestamp(r["started_at"], tz=timezone.utc).isoformat()
                    if r["started_at"] else None,
                "source": r["source"] or "unknown",
                "title": r["title"] or "(no title)",
                "message_count": r["msg_count"],
            })

        total_messages = sum(s["message_count"] for s in sessions)

        conn.close()

        return {
            "sessions": sessions,
            "session_count": len(sessions),
            "message_count": total_messages,
            "summary": self._summarize(sessions, total_messages),
        }

    def get_session_messages(self, session_id: str, limit: int = 10) -> str:
        """Get last N messages from a session as readable text."""
        if not self.db_path.exists():
            return ""

        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
        except sqlite3.OperationalError:
            return ""

        try:
            rows = conn.execute("""
                SELECT role, content FROM messages
                WHERE session_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (session_id, limit)).fetchall()
        except sqlite3.OperationalError:
            return ""

        conn.close()

        lines = []
        for r in reversed(list(rows)):
            if r["content"]:
                snippet = r["content"][:200].replace("\n", " ")
                lines.append(f"[{r['role']}]: {snippet}")
        return "\n".join(lines)

    def _summarize(self, sessions: list, total_messages: int) -> str:
        if not sessions:
            return "Nenhuma sessao registrada neste periodo."
        sources = set(s["source"] for s in sessions)
        titles = [s["title"] for s in sessions if s["title"] and s["title"] != "(no title)"]
        source_str = ", ".join(sorted(sources))
        title_str = ", ".join(titles[:3])
        result = f"{len(sessions)} sessoes ({source_str}), {total_messages} mensagens."
        if title_str:
            result += f" Topicos: {title_str}"
        return result
