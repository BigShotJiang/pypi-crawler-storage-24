"""GitOps — Git operations for Qualia ledger.

Handles soul/ directory commits and restore operations.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class GitOpsResult:
    """Result of a git operation."""

    success: bool
    message: str
    output: str = ""


class GitOps:
    """Git operations handler for Qualia soul/ mirror.

    Provides methods for committing changes to the soul/ mirror
    and restoring previous states.
    """

    def __init__(self, repo_dir: Path, soul_dir: Path):
        """Initialize GitOps handler.

        Args:
            repo_dir: Path to the git repository root.
            soul_dir: Path to the soul/ directory to track.
        """
        self.repo_dir = Path(repo_dir)
        self.soul_dir = Path(soul_dir)

    def is_repo(self) -> bool:
        """Check if repo_dir is a valid git repository.

        Returns:
            True if repo_dir is a git repository.
        """
        result = subprocess.run(
            ["git", "-C", str(self.repo_dir), "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
        )
        return result.returncode == 0 and result.stdout.strip() == "true"

    def add_soul(self) -> GitOpsResult:
        """Stage all files in soul/ directory for commit.

        Returns:
            GitOpsResult with success status and output.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_dir), "add", str(self.soul_dir)],
                capture_output=True,
                text=True,
            )
            return GitOpsResult(
                success=result.returncode == 0,
                message="Added soul/ to staging" if result.returncode == 0 else result.stderr,
                output=result.stdout,
            )
        except Exception as e:
            return GitOpsResult(success=False, message=str(e))

    def commit(
        self,
        message: str,
        snap_id: Optional[str] = None,
    ) -> GitOpsResult:
        """Create a git commit with the soul/ changes.

        Args:
            message: Commit message.
            snap_id: Optional snap ID to include in commit message.

        Returns:
            GitOpsResult with success status and details.
        """
        full_message = message
        if snap_id:
            full_message = f"{message}\n\nSnap: {snap_id}"

        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_dir), "commit", "-m", full_message],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return GitOpsResult(
                    success=True,
                    message="Commit created",
                    output=result.stdout,
                )
            else:
                return GitOpsResult(
                    success=False,
                    message=result.stderr or "Commit failed",
                    output=result.stdout,
                )
        except Exception as e:
            return GitOpsResult(success=False, message=str(e))

    def get_last_commit(self, max_count: int = 1) -> Optional[str]:
        """Get the last commit hash(es).

        Args:
            max_count: Number of commits to retrieve.

        Returns:
            Commit hash string, or None if no commits exist.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_dir), "log", f"-{max_count}", "--format=%H"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0 and result.stdout.strip():
                commits = result.stdout.strip().split("\n")
                return commits[0] if commits else None
        except Exception:
            pass
        return None

    def restore(self, commit_hash: str, file_path: Optional[str] = None) -> GitOpsResult:
        """Restore soul/ files from a previous commit.

        Args:
            commit_hash: Git commit hash to restore from.
            file_path: Optional specific file to restore. If None, restores all soul/ files.

        Returns:
            GitOpsResult with success status and details.
        """
        target = file_path if file_path else str(self.soul_dir)
        try:
            result = subprocess.run(
                [
                    "git", "-C", str(self.repo_dir),
                    "checkout", commit_hash, "--", target
                ],
                capture_output=True,
                text=True,
            )
            return GitOpsResult(
                success=result.returncode == 0,
                message="Restored" if result.returncode == 0 else result.stderr,
                output=result.stdout,
            )
        except Exception as e:
            return GitOpsResult(success=False, message=str(e))

    def get_soul_files_at_commit(self, commit_hash: str) -> list[str]:
        """Get list of soul/ files at a specific commit.

        Args:
            commit_hash: Git commit hash.

        Returns:
            List of file paths in soul/ at that commit.
        """
        try:
            result = subprocess.run(
                [
                    "git", "-C", str(self.repo_dir),
                    "ls-tree", "-r", "--name-only", commit_hash, str(self.soul_dir)
                ],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return [line.strip() for line in result.stdout.strip().split("\n") if line.strip()]
        except Exception:
            pass
        return []

    def push(self, remote: str = "origin", branch: str = "main") -> GitOpsResult:
        """Push commits to remote repository.

        Args:
            remote: Remote name (default: origin)
            branch: Branch to push (default: main)

        Returns:
            GitOpsResult with success status and output.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_dir), "push", remote, branch],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                return GitOpsResult(
                    success=True,
                    message=f"Pushed to {remote}/{branch}",
                    output=result.stdout,
                )
            else:
                return GitOpsResult(
                    success=False,
                    message=result.stderr or "Push failed",
                    output=result.stdout,
                )
        except subprocess.TimeoutExpired:
            return GitOpsResult(success=False, message="Push timed out")
        except Exception as e:
            return GitOpsResult(success=False, message=str(e))

    def has_remote(self) -> bool:
        """Check if repository has a remote configured."""
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_dir), "remote", "-v"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0 and bool(result.stdout.strip())
        except Exception:
            return False
