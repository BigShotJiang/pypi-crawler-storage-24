"""SoulLedger — Core deterministic ledger for Hermes Qualia.

Tracks soul state via SHA-256 hashes of tracked files.
Generates append-only manifests on change detection.
Syncs soul/ mirror for git diff.
"""

from __future__ import annotations

import fcntl
import os
import hashlib
import json
import shutil
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


@dataclass
class Manifest:
    """Single observation event — records soul state at a point in time."""

    version: str = "1.0"
    snap_id: str = ""
    timestamp: str = ""
    trigger: str = ""
    session_id: Optional[str] = None
    files: dict = field(default_factory=dict)
    drift_score: float = 0.0

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, raw: str) -> "Manifest":
        return cls(**json.loads(raw))


class SoulLedger:
    """
    Deterministic ledger for Hermes Agent soul state.

    Tracks: SOUL.md, MEMORY.md, USER.md, skills/*.md
    Generates snap_id = SHA-256 of all tracked file contents.
    Creates manifests only when state actually changes.
    Syncs soul/ mirror for git-based diff.

    Usage:
        ledger = SoulLedger(repo_dir="/path/to/hermes-qualia")
        snap = ledger.snap()
        result = ledger.observe(trigger="gateway:agent:end")

    Args:
        repo_dir: Path to the hermes-qualia repo (contains soul/, manifests/).
        hermes_home: Path to Hermes home directory. Defaults to ~/.hermes.
    """

    DEFAULT_TRACKED_FILES: dict[str, str] = {
        "SOUL.md": "SOUL.md",
        "MEMORY.md": "memories/MEMORY.md",
        "USER.md": "memories/USER.md",
    }
    DEFAULT_TRACKED_DIRS: dict[str, str] = {
        "skills": "skills",
    }

    def __init__(
        self,
        repo_dir: str | Path = ".",
        hermes_home: str | Path | None = None,
    ):
        self.repo_dir = Path(repo_dir).expanduser().resolve()
        self.manifests_dir = self.repo_dir / "manifests"
        self.soul_dir = self.repo_dir / "soul"
        self.manifests_dir.mkdir(parents=True, exist_ok=True)
        self.soul_dir.mkdir(parents=True, exist_ok=True)

        # Hermes home: resolve from env first, then fall back to ~/.hermes.
        if hermes_home is None:
            hermes_home = Path(
                os.environ.get("QUALIA_HERMES_HOME")
                or os.environ.get("HERMES_HOME")
                or "~/.hermes"
            ).expanduser()
        else:
            hermes_home = Path(hermes_home).expanduser()
        self.hermes_home = hermes_home

        # Build tracked paths relative to hermes_home
        self._tracked_files: dict[str, Path] = {}
        for name, rel in self.DEFAULT_TRACKED_FILES.items():
            self._tracked_files[name] = self.hermes_home / rel

        self._tracked_dirs: dict[str, Path] = {}
        for name, rel in self.DEFAULT_TRACKED_DIRS.items():
            self._tracked_dirs[name] = self.hermes_home / rel

        self._last_manifest: Optional[Manifest] = self._load_last_manifest()

    # -------------------------------------------------------------------------
    # Hashing
    # -------------------------------------------------------------------------

    def _hash_file(self, path: Path) -> str:
        """SHA-256 hex of file contents. Empty string if file missing."""
        if not path.exists():
            return ""
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def _hash_dir(self, dir_path: Path) -> str:
        """SHA-256 hex of concatenated .md file contents in a directory."""
        if not dir_path.exists():
            return ""
        files = sorted(dir_path.glob("**/*.md"))
        content = b"".join(f.read_bytes() for f in files)
        return hashlib.sha256(content).hexdigest()

    # -------------------------------------------------------------------------
    # Snap — deterministic hash of current state
    # -------------------------------------------------------------------------

    def snap(self) -> dict:
        """
        Calculate current snap_id = SHA-256 of all tracked files.

        Deterministic: same content → same snap_id.
        Independent of timestamps or file order.

        Returns:
            dict with keys: snap_id (str), files (dict), dirs (dict)
        """
        files_hashes = {}
        for name, path in self._tracked_files.items():
            files_hashes[name] = self._hash_file(path)

        dir_hashes = {}
        for name, path in self._tracked_dirs.items():
            dir_hashes[name] = self._hash_dir(path)

        all_hashes = json.dumps(files_hashes | dir_hashes, sort_keys=True)
        snap_id = hashlib.sha256(all_hashes.encode()).hexdigest()

        return {"snap_id": snap_id, "files": files_hashes, "dirs": dir_hashes}

    # -------------------------------------------------------------------------
    # Observe — detect change, create manifest
    # -------------------------------------------------------------------------

    def observe(self, trigger: str, session_id: Optional[str] = None) -> dict:
        """
        Observe current soul state, compare with last manifest.

        If state changed (snap_id differs): generate manifest JSON, sync soul/.
        If state unchanged: return {changed: False}. No manifest created.

        Args:
            trigger: What triggered this observation (e.g. "gateway:agent:end")
            session_id: Optional session ID for context

        Returns:
            dict with keys: changed (bool), files (list), snap_id (str),
                           manifest_path (str or None), drift_score (float)
        """
        current = self.snap()

        # No previous manifest — first run, always record
        if self._last_manifest is None:
            return self._create_manifest(current, trigger, session_id)

        # Compare snap_ids
        if current["snap_id"] == self._last_manifest.snap_id:
            return {"changed": False, "files": [], "snap_id": current["snap_id"]}

        # State changed — generate manifest
        return self._create_manifest(current, trigger, session_id)

    def _create_manifest(
        self, current: dict, trigger: str, session_id: Optional[str]
    ) -> dict:
        """Generate and persist manifest, sync soul/ mirror."""
        files_diff = {}
        changed_files = []

        for name, path in self._tracked_files.items():
            h_before = ""
            if self._last_manifest and self._last_manifest.files:
                h_before = self._last_manifest.files.get(name, {}).get("hash_after", "")
            h_after = current["files"][name]
            size = 0
            if path.exists():
                size = path.stat().st_size
            if h_before != h_after:
                files_diff[name] = {
                    "hash_before": h_before,
                    "hash_after": h_after,
                    "changed": True,
                    "size_delta": size,
                }
                changed_files.append(name)

        for name, path in self._tracked_dirs.items():
            h_before = ""
            if self._last_manifest and self._last_manifest.files:
                h_before = self._last_manifest.files.get(name, {}).get("hash_after", "")
            h_after = current["dirs"][name]
            if h_before != h_after:
                files_diff[name] = {
                    "hash_before": h_before,
                    "hash_after": h_after,
                    "changed": True,
                }
                changed_files.append(name)

        # Drift score
        total = sum(
            p.stat().st_size
            for p in self._tracked_files.values()
            if p.exists()
        )
        changed_size = sum(files_diff.get(f, {}).get("size_delta", 0) for f in changed_files)
        drift = changed_size / total if total > 0 else 0.0

        manifest = Manifest(
            snap_id=current["snap_id"],
            timestamp=datetime.now(timezone.utc).isoformat(),
            trigger=trigger,
            session_id=session_id,
            files=files_diff,
            drift_score=round(drift, 4),
        )

        # Save manifest (append-only)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        mpath = self.manifests_dir / f"{ts}_{current['snap_id'][:12]}.json"
        mpath.write_text(manifest.to_json())

        # Sync soul/ mirror
        self._sync_soul_files(changed_files)

        # Create local backup of soul state (append-only, local only)
        self._create_backup()

        self._last_manifest = manifest

        return {
            "changed": True,
            "files": changed_files,
            "snap_id": current["snap_id"],
            "manifest_path": str(mpath),
            "drift_score": drift,
        }

    def _sync_soul_files(self, changed_files: list):
        """Copy changed tracked files to soul/ mirror."""
        for name in changed_files:
            if name in self._tracked_files:
                src = self._tracked_files[name]
                dst = self.soul_dir / name
                if src.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(src.read_bytes())

    # -------------------------------------------------------------------------
    # Lock — prevent concurrent write conflicts
    # -------------------------------------------------------------------------

    @staticmethod
    def _acquire_lock(lock_path: Path, timeout: float = 10.0) -> bool:
        """Acquire an exclusive lock file using fcntl.flock.

        Creates the lock file if it doesn't exist.
        Releases automatically when the context manager exits.

        Args:
            lock_path: Path to the lock file.
            timeout: Max seconds to wait for lock.

        Returns:
            bool: True if acquired, False if timed out.
        """
        lock_path = Path(lock_path)
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_fd = lock_path.open("w")
        start = time.monotonic()
        while True:
            try:
                fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            except BlockingIOError:
                if time.monotonic() - start >= timeout:
                    lock_fd.close()
                    return False
                time.sleep(0.05)

    # -------------------------------------------------------------------------
    # Persistence helpers
    # -------------------------------------------------------------------------

    def _create_backup(self) -> Path:
        """Create a timestamped backup of current soul/ state.

        Backup is saved to backups/<YYYYMMDD>_<snap_id[:12]>/.
        This is a LOCAL backup (not git-tracked).

        Returns:
            Path to the backup directory created (or existing if already present).
        """
        snap = self.snap()
        ts = datetime.now(timezone.utc).strftime("%Y%m%d")
        backup_name = f"{ts}_{snap['snap_id'][:12]}"
        backup_dir = self.repo_dir / "backups" / backup_name

        if backup_dir.exists():
            # Already backed up this exact state today — skip
            return backup_dir

        backup_dir.mkdir(parents=True, exist_ok=True)

        # Copy current soul/ contents
        if self.soul_dir.exists():
            for item in self.soul_dir.iterdir():
                dst = backup_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dst)

        return backup_dir

    def _load_last_manifest(self) -> Optional[Manifest]:
        """Load most recent manifest from manifests/ directory."""
        manifests = sorted(self.manifests_dir.glob("*.json"), reverse=True)
        if manifests:
            return Manifest.from_json(manifests[0].read_text())
        return None
