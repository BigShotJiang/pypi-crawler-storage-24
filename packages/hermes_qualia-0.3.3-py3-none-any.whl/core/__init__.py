"""Qualia core package."""
