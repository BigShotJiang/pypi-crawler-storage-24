"""QualiaConfig — Settings loader for Qualia.

Loads configuration from qualia.yaml with environment variable overrides.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


@dataclass
class QualiaConfig:
    """Configuration holder for Qualia settings.

    Attributes:
        repo_dir: Path to the Hermes repository to track.
        soul_dir: Path to the soul/ mirror directory.
        manifests_dir: Path to store manifest JSON files.
        backups_dir: Path to store pre-restore backups.
        hermes_home: Path to Hermes home directory.
        drift_threshold: Drift score threshold for change detection.
        poll_interval: Polling interval in seconds.
        lock_timeout: Lock acquisition timeout in seconds.
    """

    repo_dir: Path = Path("./hermes-repo")
    soul_dir: Path = Path("./soul")
    manifests_dir: Path = Path("./manifests")
    backups_dir: Path = Path("./backups")
    hermes_home: Path = field(default_factory=lambda: Path(os.environ.get("QUALIA_HERMES_HOME") or os.environ.get("HERMES_HOME") or "~/.hermes").expanduser())
    drift_threshold: float = 0.0
    poll_interval: int = 30
    lock_timeout: int = 10

    _loaded: bool = field(default=False, repr=False)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> QualiaConfig:
        """Load configuration from YAML file with environment overrides.

        Args:
            config_path: Path to qualia.yaml. Defaults to ./qualia.yaml.

        Returns:
            QualiaConfig instance with loaded settings.
        """
        if config_path is None:
            config_path = Path("qualia.yaml")

        config = cls()

        if config_path.exists():
            with open(config_path) as f:
                data = yaml.safe_load(f) or {}
            cls._apply_dict(config, data)

        cls._apply_env_overrides(config)
        config._loaded = True
        return config

    @staticmethod
    def _apply_dict(config: QualiaConfig, data: dict) -> None:
        """Apply dictionary values to config attributes."""
        for key, value in data.items():
            if hasattr(config, key):
                attr_value = getattr(config, key)
                if isinstance(attr_value, Path):
                    setattr(config, key, Path(value))
                else:
                    setattr(config, key, value)

    @staticmethod
    def _apply_env_overrides(config: QualiaConfig) -> None:
        """Apply environment variable overrides."""
        env_mappings = {
            "QUALIA_REPO_DIR": "repo_dir",
            "QUALIA_SOUL_DIR": "soul_dir",
            "QUALIA_MANIFESTS_DIR": "manifests_dir",
            "QUALIA_BACKUPS_DIR": "backups_dir",
            "QUALIA_HERMES_HOME": "hermes_home",
            "QUALIA_DRIFT_THRESHOLD": "drift_threshold",
            "QUALIA_POLL_INTERVAL": "poll_interval",
            "QUALIA_LOCK_TIMEOUT": "lock_timeout",
        }
        for env_var, attr_name in env_mappings.items():
            if env_var in os.environ:
                value = os.environ[env_var]
                attr_value = getattr(config, attr_name)
                if isinstance(attr_value, Path):
                    setattr(config, attr_name, Path(value))
                elif isinstance(attr_value, float):
                    setattr(config, attr_name, float(value))
                elif isinstance(attr_value, int):
                    setattr(config, attr_name, int(value))
                else:
                    setattr(config, attr_name, value)

    def ensure_dirs(self) -> None:
        """Create required directories if they don't exist."""
        for dir_path in [self.soul_dir, self.manifests_dir, self.backups_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
