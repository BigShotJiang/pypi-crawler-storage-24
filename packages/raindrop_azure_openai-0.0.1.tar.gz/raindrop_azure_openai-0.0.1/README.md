# raindrop-azure-openai

Raindrop integration for Azure OpenAI (Python). Automatically captures `chat.completions.create()` calls by wrapping the AzureOpenAI client.

## Installation

```bash
pip install raindrop-azure-openai openai
```

## Usage

```python
from raindrop_azure_openai import create_raindrop_azure_openai
from openai import AzureOpenAI

raindrop = create_raindrop_azure_openai(
    api_key="rk_...",
    user_id="user-123",
)

client = AzureOpenAI(
    azure_endpoint="https://your-resource.openai.azure.com",
    api_key="...",
    api_version="2024-10-21",
)
wrapped = raindrop["wrap"](client)

response = wrapped.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello!"}],
)

raindrop["shutdown"]()
```

## What gets captured

- **Chat completions**: input messages, output text, model, token usage
- **Errors**: tracked and re-raised to caller

## Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `api_key` | `str` | required | Raindrop API key |
| `user_id` | `str` | `None` | Associate all events with a user |
| `convo_id` | `str` | `None` | Group events into a conversation |

## Testing

```bash
cd packages/azure-openai-python
pip install -e .
python -m pytest tests/ -v
```
