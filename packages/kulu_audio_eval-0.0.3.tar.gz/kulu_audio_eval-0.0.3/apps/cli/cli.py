"""CLI entry point using Click."""

from __future__ import annotations

import csv
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import click

from cli.utils.log_config import configure_logging
from cli.utils.table_log import print_table

AUDIO_EXTENSIONS = (".oga", ".wav", ".mp3", ".m4a", ".flac")


def _print_evaluation_summary(output_dir: Path) -> None:
    """Print evaluation_summary.csv as a Rich table (same as config table)."""
    summary_path = output_dir / "evaluation_summary.csv"
    if not summary_path.is_file():
        return
    try:
        with open(summary_path, encoding="utf-8") as f:
            reader = csv.reader(f)
            rows = list(reader)
    except (OSError, csv.Error):
        return
    if len(rows) < 2:
        return
    # Data rows: (metric, value) pairs; ensure both strings for print_table
    table_rows: list[tuple[str, str]] = []
    for row in rows[1:]:
        if len(row) >= 2:
            table_rows.append((row[0], str(row[1])))
        elif len(row) == 1:
            table_rows.append((row[0], ""))
    if not table_rows:
        return
    click.echo("", err=True)
    click.echo("Summary (%s)" % output_dir, err=True)
    print_table(table_rows, left_header="Metric", right_header="Value")
    click.echo("", err=True)


def _print_output_log(output_dir: Path) -> None:
    """Log main output file paths (summary, per-turn, latency plots)."""
    base = str(output_dir)
    click.echo("", err=True)
    click.echo("1. Summary: %s/evaluation_summary.csv" % base, err=True)
    click.echo("2. Per Turn: %s/agent_transcript.csv" % base, err=True)
    click.echo("3. Latency Plots:", err=True)
    click.echo("   %s/latency_plot.png" % base, err=True)
    click.echo("   %s/latency_per_turn.png" % base, err=True)


@click.group()
def cli() -> None:
    """Voice agent audio evaluation tool."""


def _run_one(
    audio_path: Path,
    output_base: Path,
    log_prefix: str | None = None,
    config_overrides: dict | None = None,
) -> tuple[Path, None] | tuple[Path, BaseException]:
    """Run pipeline on one audio file. Returns (audio_path, None) or (audio_path, error)."""
    from cli.core.pipeline import run

    output_dir = output_base / audio_path.stem
    try:
        run(
            str(audio_path),
            str(output_dir),
            log_prefix=log_prefix,
            config_overrides=config_overrides,
        )
        return (audio_path, None)
    except Exception as e:
        return (audio_path, e)


@cli.command()
@click.argument(
    "audio",
    type=click.Path(exists=True),
    required=False,
    metavar="[AUDIO]",
)
@click.option(
    "-o",
    "--output",
    type=click.Path(),
    default=None,
    help="Output directory (default: out/<audio-name>). Single-file only.",
)
@click.option(
    "-j",
    "--max-workers",
    type=int,
    default=4,
    help="When no AUDIO given: max parallel (non-blocking) workers for multiple files in in/ (default: 4). Ignored for single-file mode.",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Show DEBUG logs (e.g. Processing audio, VAD filter, language detection).",
)
@click.option(
    "--elevenlabs-key",
    "elevenlabs_api_key",
    default=None,
    envvar="ELEVENLABS_API_KEY",
    help="ElevenLabs API key for STT/diarization (overrides .env).",
)
@click.option(
    "--gemini-key",
    "gemini_api_key",
    default=None,
    envvar="GEMINI_API_KEY",
    help="Gemini API key for failure inference and translation (overrides .env).",
)
def evaluate(
    audio: str | None,
    output: str | None,
    max_workers: int,
    verbose: bool,
    elevenlabs_api_key: str | None,
    gemini_api_key: str | None,
) -> None:
    """Run pipeline on one audio file, or on all files in in/ if AUDIO omitted. Batch mode (no AUDIO) runs files in parallel (non-blocking); single-file mode is sequential."""
    configure_logging(verbose=verbose)

    config_overrides: dict | None = None
    if elevenlabs_api_key or gemini_api_key:
        config_overrides = {}
        if elevenlabs_api_key:
            config_overrides["ELEVENLABS_API_KEY"] = elevenlabs_api_key
        if gemini_api_key:
            config_overrides["GEMINI_API_KEY"] = gemini_api_key

    if audio is not None:
        from cli.core.pipeline import run

        audio_path = Path(audio)
        if output is None:
            output_dir = Path("out") / audio_path.stem
        else:
            output_dir = Path(output)
        try:
            run(str(audio_path), str(output_dir), config_overrides=config_overrides)
            _print_evaluation_summary(output_dir)
            _print_output_log(output_dir)
        except KeyboardInterrupt:
            print("\nPipeline interrupted.", file=sys.stderr)
            sys.exit(130)
        return

    # No AUDIO: run on all files in in/
    base = Path("in")
    if not base.is_dir():
        click.echo(f"Input directory {base} not found.", err=True)
        sys.exit(1)
    audios = sorted(
        f
        for f in base.iterdir()
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS
    )
    if not audios:
        click.echo(f"No audio files found in {base}.", err=True)
        sys.exit(1)

    output_base = Path("out")
    failed: list[tuple[Path, BaseException]] = []
    # Parallel (non-blocking): multiple audio files run concurrently; each run() is sequential inside.
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_run_one, p, output_base, p.name, config_overrides): p for p in audios
        }
        for future in as_completed(futures):
            path, err = future.result()
            if err is not None:
                failed.append((path, err))
                click.echo(f"Failed {path}: {err}", err=True)
            else:
                click.echo(f"Done {path}")
                out_dir = output_base / path.stem
                _print_evaluation_summary(out_dir)
                _print_output_log(out_dir)

    if failed:
        click.echo(f"\n{len(failed)} of {len(audios)} failed.", err=True)
        sys.exit(1)
