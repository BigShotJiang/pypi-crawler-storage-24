"""Turn annotation: map speaker IDs to agent/user, merge segments, assign turns."""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


def _speaker_to_agent_user(segments: list[dict]) -> None:
    """Map speaker IDs to agent/user (first-appearing = agent). In-place."""
    if not segments:
        return
    order: list[str] = []
    for seg in segments:
        spk = seg.get("speaker")
        if spk and spk not in order:
            order.append(spk)
    if len(order) < 2:
        for seg in segments:
            seg["speaker"] = "agent"
        return
    agent_id, user_id = order[0], order[1]
    for seg in segments:
        seg["speaker"] = "agent" if seg.get("speaker") == agent_id else "user"


def _merge_consecutive_same_speaker(
    segments: list[dict],
    min_duration_s: float = 3.0,
    audio_duration_s: float | None = None,
) -> list[dict]:
    """Merge consecutive same-speaker segments to avoid tiny chunks.

    First pass: merge all consecutive same-speaker segments into one
    (concatenate text, extend time range).

    Second pass: any segment still shorter than min_duration_s gets merged
    into its nearest same-speaker neighbor.

    Pass 3: pad remaining short segments to min_duration_s, then clamp
    start/end to [0, audio_duration_s] so exported chunks never extend
    past the file (which would otherwise produce short boundary chunks).

    Args:
        segments: Sorted list of segments with speaker labels.
        min_duration_s: Minimum segment duration in seconds.
        audio_duration_s: If set, clamp segment times so chunks do not
            extend past the end of the audio (avoids short boundary chunks).

    Returns:
        Merged segments list.
    """
    if not segments:
        return segments

    # Pass 1: merge consecutive same-speaker segments
    merged: list[dict] = [dict(segments[0])]
    for seg in segments[1:]:
        prev = merged[-1]
        if seg["speaker"] == prev["speaker"]:
            prev["end"] = max(prev["end"], seg["end"])
            prev["text"] = prev["text"] + " " + seg["text"]
        else:
            merged.append(dict(seg))

    # Pass 2: absorb segments shorter than min_duration_s into a
    # same-speaker neighbor (prefer the previous neighbor, then next).
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(merged):
            seg = merged[i]
            dur = seg["end"] - seg["start"]
            if dur >= min_duration_s or len(merged) <= 1:
                i += 1
                continue

            # Try to merge with previous same-speaker segment
            if i > 0 and merged[i - 1]["speaker"] == seg["speaker"]:
                merged[i - 1]["end"] = max(merged[i - 1]["end"], seg["end"])
                merged[i - 1]["text"] = merged[i - 1]["text"] + " " + seg["text"]
                merged.pop(i)
                changed = True
                continue

            # Try to merge with next same-speaker segment
            if i < len(merged) - 1 and merged[i + 1]["speaker"] == seg["speaker"]:
                merged[i + 1]["start"] = min(merged[i + 1]["start"], seg["start"])
                merged[i + 1]["text"] = seg["text"] + " " + merged[i + 1]["text"]
                merged.pop(i)
                changed = True
                continue

            i += 1

    # Pass 3: pad any remaining short segments by extending their time
    # boundaries symmetrically so the audio chunk reaches min_duration_s.
    # Clamp to [0, audio_duration_s] so we never export past end of file
    # (which would make export_chunk clamp and produce short boundary chunks).
    for seg in merged:
        dur = seg["end"] - seg["start"]
        if dur < min_duration_s:
            deficit = min_duration_s - dur
            seg["start"] = max(0.0, seg["start"] - deficit / 2)
            seg["end"] = seg["end"] + deficit / 2
        if audio_duration_s is not None:
            seg["start"] = max(0.0, min(seg["start"], audio_duration_s))
            seg["end"] = max(seg["start"], min(seg["end"], audio_duration_s))
            if seg["end"] - seg["start"] < min_duration_s:
                log.debug(
                    "Segment at boundary remains shorter than min (%.1fs): "
                    "%.2f–%.2fs (duration %.2fs)",
                    min_duration_s,
                    seg["start"],
                    seg["end"],
                    seg["end"] - seg["start"],
                )

    log.debug(
        "Merged segments: %d -> %d (min_duration=%.1fs)",
        len(segments),
        len(merged),
        min_duration_s,
    )
    return merged


def _assign_turns(segments: list[dict]) -> list[dict]:
    """Assign sequential turn numbers.

    Turn increments when current speaker is agent and previous was user.
    """
    if not segments:
        return segments

    turn = 1
    segments[0]["turn"] = turn
    prev_speaker = segments[0]["speaker"]

    for seg in segments[1:]:
        if seg["speaker"] == "agent" and prev_speaker == "user":
            turn += 1
        seg["turn"] = turn
        prev_speaker = seg["speaker"]

    return segments
