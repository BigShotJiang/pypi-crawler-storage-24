"""Anomaly detection: cutout detection and failed response detection.

Cutout detection analyses audio segments for energy dropouts (cutouts) that
occur at the start, middle, or end of a speech segment.  Failed response
detection identifies turns where the agent failed to respond.

Both stages append structured events to per-segment metadata columns
(``cutouts`` and ``failed_response`` arrays).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from abc import ABC, abstractmethod

import numpy as np

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cutout detection
# ---------------------------------------------------------------------------

# Default parameters (configurable via config dict / CUTOUT_SILENT_THRESHOLD_DB, CUTOUT_THRESHOLD_MS env)
_DEFAULTS: dict[str, float] = {
    "frame_length_ms": 128.0,
    "hop_length_ms": 32.0,
    "cutout_silent_threshold_db": -40.0,
    "cutout_threshold_ms": 1000.0,  # min duration (ms) for cutout_mid
    "min_cutout_ms": 300.0,
    "max_cutout_ms": 30000.0,  # Raised from 3000 to capture barge-in gaps (can be 8+ seconds)
    "collar_ms": 150.0,
    "pre_post_confirm_ms": 200.0,  # Raised from 100ms: natural fade before a hard cut needs a wider look-back window
    # Slope detection: dB drop per hop that indicates a digital cut
    "slope_threshold_db": 15.0,
    # Zero-run: minimum consecutive near-zero samples to confirm digital cut
    "zero_run_min_samples": 80,
    # Absolute sample value treated as "zero" for zero-run detection
    "zero_abs_threshold": 1e-4,
    # Speech confirmation: energy must be above this dB to count as speech
    # (prevents noise-floor dropouts from being flagged as cutouts)
    "speech_confirm_db": -20.0,
}


def _compute_rms_frames(
    audio: np.ndarray,
    sample_rate: int,
    frame_length_ms: float,
    hop_length_ms: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute frame-level RMS energy (linear).

    Returns:
        rms: Array of RMS values per frame.
        frame_times_ms: Centre time of each frame in milliseconds.
    """
    frame_len = int(sample_rate * frame_length_ms / 1000.0)
    hop_len = int(sample_rate * hop_length_ms / 1000.0)
    if frame_len == 0 or hop_len == 0 or len(audio) < frame_len:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    n_frames = 1 + (len(audio) - frame_len) // hop_len
    rms = np.empty(n_frames, dtype=np.float64)
    for i in range(n_frames):
        start = i * hop_len
        frame = audio[start : start + frame_len]
        rms[i] = np.sqrt(np.mean(frame.astype(np.float64) ** 2))

    frame_times_ms = (
        np.arange(n_frames, dtype=np.float64) * hop_length_ms + frame_length_ms / 2.0
    )
    return rms, frame_times_ms


def _rms_to_db(rms: np.ndarray, ref_rms: float) -> np.ndarray:
    """Convert RMS to dB relative to a reference RMS level."""
    ref = max(ref_rms, 1e-10)
    out: np.ndarray = 20.0 * np.log10(np.maximum(rms, 1e-10) / ref)
    return out


def _compute_global_ref_rms(
    audio: np.ndarray,
    sample_rate: int,
    frame_length_ms: float,
    hop_length_ms: float,
) -> float:
    """Compute a robust global RMS reference (95th percentile) for the full audio."""
    rms, _ = _compute_rms_frames(audio, sample_rate, frame_length_ms, hop_length_ms)
    if len(rms) == 0:
        return 1e-10
    return max(float(np.percentile(rms, 95)), 1e-10)


def _rms_at_time(
    audio: np.ndarray,
    sample_rate: int,
    time_s: float,
    window_ms: float,
) -> float:
    """Compute RMS over a window centered at time_s (seconds). Returns 0 if out of range."""
    window_samples = max(1, int(sample_rate * window_ms / 1000.0))
    center = int(time_s * sample_rate)
    start = center - window_samples // 2
    end = start + window_samples
    if start < 0 or end > len(audio):
        return 0.0
    frame = audio[start:end].astype(np.float64)
    return float(np.sqrt(np.mean(frame**2)))


def _detect_cutout_words_in_segment(
    seg: dict,
    words: list[dict],
    audio_data: np.ndarray,
    sample_rate: int,
    config: dict,
    ref_rms: float,
) -> list[dict]:
    """Detect cutout_word events from STT words whose text ends with '-' (cut-off).

    STT often marks truncated/cut-off words with a trailing hyphen (e.g. \"Dokład-\",
    \"trzym-\"). We scan words overlapping the segment and emit a cutout only when
    the word's text ends with '-'. Timestamps use word.start and word.end.

    Returns list of cutout dicts: {\"type\": \"cutout_word\", \"start_ms\", \"end_ms\"}.
    """
    seg_start_s = seg["start"]
    seg_end_s = seg["end"]
    cutouts: list[dict] = []
    for w in words:
        if (w.get("type") or "") != "word":
            continue
        text = (w.get("text") or "").strip()
        if not text.endswith("-"):
            continue
        try:
            start_s = float(w.get("start", 0))
            end_s = float(w.get("end", 0))
        except (TypeError, ValueError):
            continue
        if start_s >= seg_end_s or end_s <= seg_start_s:
            continue
        cutouts.append(
            {
                "type": "cutout_word",
                "start_ms": round(start_s * 1000.0, 1),
                "end_ms": round(end_s * 1000.0, 1),
            }
        )
    return cutouts


def _find_low_energy_runs(
    energy_db: np.ndarray,
    frame_times_ms: np.ndarray,
    threshold_db: float,
    min_cutout_ms: float,
    max_cutout_ms: float,
    hop_length_ms: float,
) -> list[tuple[float, float, int, int]]:
    """Find continuous runs where energy_db < threshold_db.

    Returns list of (start_ms, end_ms, start_frame_idx, end_frame_idx)
    relative to chunk start.
    """
    below = energy_db < threshold_db
    runs: list[tuple[float, float, int, int]] = []
    in_run = False
    run_start_idx = 0

    for i in range(len(below)):
        if below[i] and not in_run:
            in_run = True
            run_start_idx = i
        elif not below[i] and in_run:
            in_run = False
            start_ms = frame_times_ms[run_start_idx] - hop_length_ms / 2.0
            end_ms = frame_times_ms[i - 1] + hop_length_ms / 2.0
            dur = end_ms - start_ms
            if min_cutout_ms <= dur <= max_cutout_ms:
                runs.append((max(0.0, start_ms), end_ms, run_start_idx, i - 1))

    # Handle run that extends to end of audio
    if in_run:
        start_ms = frame_times_ms[run_start_idx] - hop_length_ms / 2.0
        end_ms = frame_times_ms[-1] + hop_length_ms / 2.0
        dur = end_ms - start_ms
        if min_cutout_ms <= dur <= max_cutout_ms:
            runs.append((max(0.0, start_ms), end_ms, run_start_idx, len(energy_db) - 1))

    return runs


def _has_speech_energy(
    energy_db: np.ndarray,
    frame_times_ms: np.ndarray,
    region_start_ms: float,
    region_end_ms: float,
    threshold_db: float,
) -> bool:
    """Check if there is non-cutout energy (>= threshold) within a region."""
    mask = (frame_times_ms >= region_start_ms) & (frame_times_ms <= region_end_ms)
    if not np.any(mask):
        return False
    return bool(np.any(energy_db[mask] >= threshold_db))


# ---- Slope (derivative) detection ----


def _has_sharp_onset_slope(
    energy_db: np.ndarray,
    run_start_idx: int,
    slope_threshold_db: float,
    speech_confirm_db: float,
) -> bool:
    """Check if the cutout onset has a sharp negative slope (digital cut).

    Looks at the frame just before the low-energy run and the first frame
    of the run.  A large negative delta means abrupt drop.

    Also requires that the pre-run frame is at speech level
    (``>= speech_confirm_db``).  A slope from already-faded audio (e.g.
    -30 dB → -47 dB) is a natural trail-off, not a digital cut.
    """
    if run_start_idx < 1:
        return False
    pre_energy = energy_db[run_start_idx - 1]
    if pre_energy < speech_confirm_db:
        return False
    delta = energy_db[run_start_idx] - pre_energy
    return bool(delta < -slope_threshold_db)


def _has_sharp_offset_slope(
    energy_db: np.ndarray,
    run_end_idx: int,
    slope_threshold_db: float,
) -> bool:
    """Check if the cutout offset has a sharp positive slope (digital recovery).

    Looks at the last frame of the low-energy run and the frame just after.
    A large positive delta means abrupt recovery from silence.
    """
    if run_end_idx >= len(energy_db) - 1:
        return False
    delta = energy_db[run_end_idx + 1] - energy_db[run_end_idx]
    return bool(delta > slope_threshold_db)


# ---- Zero-sample run detection ----


def _has_zero_run(
    audio_chunk: np.ndarray,
    sample_rate: int,
    local_start_ms: float,
    local_end_ms: float,
    zero_run_min_samples: int,
    zero_abs_threshold: float,
) -> bool:
    """Check if there is a run of consecutive near-zero samples in a region.

    This detects hard digital truncation (samples literally go to zero).
    """
    start_sample = max(0, int(local_start_ms * sample_rate / 1000.0))
    end_sample = min(len(audio_chunk), int(local_end_ms * sample_rate / 1000.0))
    if end_sample - start_sample < zero_run_min_samples:
        return False

    region = np.abs(audio_chunk[start_sample:end_sample].astype(np.float64))
    is_zero = region < zero_abs_threshold

    # Find longest consecutive zero run
    max_run = 0
    current_run = 0
    for z in is_zero:
        if z:
            current_run += 1
            if current_run > max_run:
                max_run = current_run
        else:
            current_run = 0

    return max_run >= zero_run_min_samples


# ---- Classification ----


def _classify_cutout(
    cutout_start_ms: float,
    cutout_end_ms: float,
    seg_start_ms: float,
    seg_end_ms: float,
    collar_ms: float,
    pre_post_confirm_ms: float,
    energy_db: np.ndarray,
    frame_times_ms: np.ndarray,
    speech_confirm_db: float,
    *,
    has_slope: bool,
    has_zero_run: bool,
) -> str | None:
    """Classify a cutout interval; only cutout_mid is reported for now.

    Returns None if the cutout should be discarded (including boundary
    cutout_start / cutout_end, which are not reported).

    - **cutout_mid** (interior): speech before AND after, plus digital cut
      evidence (slope OR zero-run). Boundary cutouts are not returned.

    Uses ``speech_confirm_db`` (higher than the cutout threshold) to verify
    that the energy adjacent to the dropout is actual speech.
    """
    seg_dur_ms = seg_end_ms - seg_start_ms
    in_start_collar = cutout_start_ms < collar_ms
    in_end_collar = cutout_end_ms > seg_dur_ms - collar_ms

    if in_start_collar and in_end_collar:
        return None

    # Discard boundary cutouts (cutout_start / cutout_end not reported for now)
    if in_start_collar or in_end_collar:
        return None

    # Check speech before and after the cutout
    pre_start = max(0.0, cutout_start_ms - pre_post_confirm_ms)
    pre_end = cutout_start_ms
    post_start = cutout_end_ms
    post_end = cutout_end_ms + pre_post_confirm_ms

    has_pre = _has_speech_energy(
        energy_db, frame_times_ms, pre_start, pre_end, speech_confirm_db
    )
    has_post = _has_speech_energy(
        energy_db, frame_times_ms, post_start, post_end, speech_confirm_db
    )

    # Interior (cutout_mid): speech before AND after, plus digital cut
    # evidence (slope OR zero-run) to distinguish real dropouts from
    # natural inter-sentence pauses.
    is_digital = has_slope or has_zero_run
    if has_pre and has_post and is_digital:
        return "cutout_mid"
    return None


def detect_cutouts_in_segment(
    audio_chunk: np.ndarray,
    sample_rate: int,
    seg_start_s: float,
    seg_end_s: float,
    config: dict,
    ref_rms: float | None = None,
) -> list[dict]:
    """Detect cutout intervals within a single speech segment.

    Args:
        audio_chunk: Audio data for this segment.
        sample_rate: Sample rate in Hz.
        seg_start_s: Segment start time in seconds (absolute).
        seg_end_s: Segment end time in seconds (absolute).
        config: Detection parameters (see _DEFAULTS).
        ref_rms: Global RMS reference level. If None, computed per-segment.

    Returns:
        List of cutout dicts: {"type", "start_ms", "end_ms"}.
    """
    frame_length_ms = float(config.get("frame_length_ms", _DEFAULTS["frame_length_ms"]))
    hop_length_ms = float(config.get("hop_length_ms", _DEFAULTS["hop_length_ms"]))
    threshold_db = float(
        config.get(
            "cutout_silent_threshold_db", _DEFAULTS["cutout_silent_threshold_db"]
        )
    )
    cutout_threshold_ms = float(
        config.get("cutout_threshold_ms", _DEFAULTS["cutout_threshold_ms"])
    )
    min_cutout_ms = float(config.get("min_cutout_ms", _DEFAULTS["min_cutout_ms"]))
    max_cutout_ms = float(config.get("max_cutout_ms", _DEFAULTS["max_cutout_ms"]))
    collar_ms = float(config.get("collar_ms", _DEFAULTS["collar_ms"]))
    pre_post_confirm_ms = float(
        config.get("pre_post_confirm_ms", _DEFAULTS["pre_post_confirm_ms"])
    )
    slope_threshold_db = float(
        config.get("slope_threshold_db", _DEFAULTS["slope_threshold_db"])
    )
    zero_run_min_samples = int(
        config.get("zero_run_min_samples", _DEFAULTS["zero_run_min_samples"])
    )
    zero_abs_threshold = float(
        config.get("zero_abs_threshold", _DEFAULTS["zero_abs_threshold"])
    )
    speech_confirm_db = float(
        config.get("speech_confirm_db", _DEFAULTS["speech_confirm_db"])
    )

    if len(audio_chunk) == 0:
        return []

    rms, frame_times_ms = _compute_rms_frames(
        audio_chunk, sample_rate, frame_length_ms, hop_length_ms
    )
    if len(rms) == 0:
        return []

    # Use global ref if provided, else per-segment 95th percentile
    if ref_rms is None:
        ref_rms = max(float(np.percentile(rms, 95)), 1e-10)
    energy_db = _rms_to_db(rms, ref_rms)

    seg_start_ms = seg_start_s * 1000.0
    seg_end_ms = seg_end_s * 1000.0

    # Find low-energy runs (times relative to chunk start)
    runs = _find_low_energy_runs(
        energy_db,
        frame_times_ms,
        threshold_db,
        min_cutout_ms,
        max_cutout_ms,
        hop_length_ms,
    )

    cutouts: list[dict] = []
    for run_start_local, run_end_local, run_si, run_ei in runs:
        # Check for digital cut evidence (slope and zero-run separately)
        slope = _has_sharp_onset_slope(
            energy_db, run_si, slope_threshold_db, speech_confirm_db
        )
        zero_run = _has_zero_run(
            audio_chunk,
            sample_rate,
            run_start_local,
            run_end_local,
            zero_run_min_samples,
            zero_abs_threshold,
        )

        cutout_type = _classify_cutout(
            run_start_local,
            run_end_local,
            seg_start_ms,
            seg_end_ms,
            collar_ms,
            pre_post_confirm_ms,
            energy_db,
            frame_times_ms,
            speech_confirm_db,
            has_slope=slope,
            has_zero_run=zero_run,
        )
        if cutout_type is not None:
            run_dur_ms = run_end_local - run_start_local
            if cutout_type == "cutout_mid" and run_dur_ms < cutout_threshold_ms:
                continue
            cutouts.append(
                {
                    "type": cutout_type,
                    "start_ms": round(seg_start_ms + run_start_local, 1),
                    "end_ms": round(seg_start_ms + run_end_local, 1),
                }
            )

    cutouts.sort(key=lambda c: c["start_ms"])
    return cutouts


def detect_end_speech_in_chunk(
    audio_chunk: np.ndarray,
    sample_rate: int,
    config: dict,
    ref_rms: float | None = None,
) -> float | None:
    """Detect the end-of-speech timestamp within an audio chunk.

    Uses the same energy-based logic as cutout detection (CUTOUT_SILENT_THRESHOLD_DB):
    frames below the threshold (dB relative to reference RMS) are considered silent.
    Scans from the end of the chunk backwards and returns the end time (ms) of the
    last frame that is above the silence threshold.

    Reference RMS is always computed per-chunk (95th percentile of this chunk's
    frame RMS) so that "speech" vs "silent" is relative to this chunk's level.
    This ensures every chunk gets a reliable end-of-speech value; using a global
    ref would make quieter chunks appear all-silent and yield None.

    Args:
        audio_chunk: Audio data for one segment (mono, float).
        sample_rate: Sample rate in Hz.
        config: Detection parameters (uses frame_length_ms, hop_length_ms,
                cutout_silent_threshold_db from _DEFAULTS).
        ref_rms: Unused (per-chunk ref is always used); kept for API compatibility.

    Returns:
        End-of-speech time in milliseconds relative to chunk start,
        or None if no frames are above threshold (e.g. empty or silent chunk).
    """
    frame_length_ms = float(config.get("frame_length_ms", _DEFAULTS["frame_length_ms"]))
    hop_length_ms = float(config.get("hop_length_ms", _DEFAULTS["hop_length_ms"]))
    threshold_db = float(
        config.get(
            "cutout_silent_threshold_db", _DEFAULTS["cutout_silent_threshold_db"]
        )
    )

    if len(audio_chunk) == 0:
        return None

    rms, frame_times_ms = _compute_rms_frames(
        audio_chunk, sample_rate, frame_length_ms, hop_length_ms
    )
    if len(rms) == 0:
        return None

    # Per-chunk reference so "speech" vs "silent" is relative to this chunk's level
    chunk_ref_rms = max(float(np.percentile(rms, 95)), 1e-10)
    energy_db = _rms_to_db(rms, chunk_ref_rms)

    # Scan backwards to find last frame above silence threshold
    for i in range(len(energy_db) - 1, -1, -1):
        if energy_db[i] >= threshold_db:
            return float(frame_times_ms[i] + hop_length_ms / 2.0)

    return None


# ---------------------------------------------------------------------------
# Failed response detection
# ---------------------------------------------------------------------------


class FailureEvent:
    """A single detected failed response."""

    def __init__(
        self,
        type: str,
        timestamp: float,
        turn_number: int,
        reason: str = "",
    ) -> None:
        self.type = type
        self.timestamp = timestamp
        self.turn_number = turn_number
        self.reason = reason

    def to_dict(self) -> dict:
        d: dict = {
            "type": self.type,
            "timestamp": round(self.timestamp, 3),
            "turn_number": self.turn_number,
        }
        if self.reason:
            d["reason"] = self.reason
        return d


class FailureDetector(ABC):
    """Interface for failed response detection methods."""

    @abstractmethod
    def detect(self, turn: dict, config: dict) -> list[FailureEvent]: ...


class EmptyResponseDetector(FailureDetector):
    """Detect turns where the agent started but produced no valid output."""

    def detect(self, turn: dict, config: dict) -> list[FailureEvent]:
        agent_start = turn.get("agent_start")
        agent_text = turn.get("agent_text", "")

        if agent_start is None:
            return []

        if not agent_text or not agent_text.strip():
            return [
                FailureEvent(
                    type="agent_response_empty",
                    timestamp=agent_start,
                    turn_number=turn["turn_number"],
                    reason="agent produced no text/transcript",
                )
            ]

        return []


# ---------------------------------------------------------------------------
# Pipeline-level orchestration
# ---------------------------------------------------------------------------


def detect_cutouts(
    audio_data: np.ndarray,
    sample_rate: int,
    segments: list[dict],
    config: dict,
    words_json_path: Path | None = None,
) -> list[dict]:
    """Run cutout detection on all segments.

    Mutates each segment in-place by adding ``cutouts`` and ``y_pred_cutouts``
    keys (list of dicts with type/start_ms/end_ms).
    Returns the flat list of all cutout events as dicts.

    If words_json_path is set (e.g. STT cache with \"words\" array), also
    detects cutout_word events at word boundaries where energy is below
    threshold, using word.start and word.end for timestamps.

    Args:
        audio_data: Full audio array (mono, float32).
        sample_rate: Sample rate in Hz.
        segments: Pipeline segments with start/end in seconds.
        config: Detection config dict.
        words_json_path: Optional path to JSON with top-level \"words\" array
                         (each item: start, end, type \"word\"|\"spacing\").
    """
    frame_length_ms = float(config.get("frame_length_ms", _DEFAULTS["frame_length_ms"]))
    hop_length_ms = float(config.get("hop_length_ms", _DEFAULTS["hop_length_ms"]))

    # Honour CUTOUT_SILENT_THRESHOLD_DB and CUTOUT_THRESHOLD_MS from config (set via .env / EvalConfig)
    cutout_config = dict(config)
    if (
        "CUTOUT_SILENT_THRESHOLD_DB" in config
        and "cutout_silent_threshold_db" not in config
    ):
        cutout_config["cutout_silent_threshold_db"] = float(
            config["CUTOUT_SILENT_THRESHOLD_DB"]
        )
    if "CUTOUT_THRESHOLD_MS" in config and "cutout_threshold_ms" not in config:
        cutout_config["cutout_threshold_ms"] = float(config["CUTOUT_THRESHOLD_MS"])

    # Compute global RMS reference from the full audio for stable thresholding
    ref_rms = _compute_global_ref_rms(
        audio_data, sample_rate, frame_length_ms, hop_length_ms
    )
    log.debug("Global RMS reference: %.6f", ref_rms)

    words: list[dict] = []
    if words_json_path is not None and words_json_path.is_file():
        try:
            data = json.loads(words_json_path.read_text(encoding="utf-8"))
            words = data.get("words") or []
        except (OSError, json.JSONDecodeError) as e:
            log.warning("Could not load words for cutout_word: %s", e)

    all_cutouts: list[dict] = []

    for seg in segments:
        start_sample = int(seg["start"] * sample_rate)
        end_sample = int(seg["end"] * sample_rate)
        start_sample = max(0, start_sample)
        end_sample = min(len(audio_data), end_sample)
        chunk = audio_data[start_sample:end_sample]

        try:
            seg_cutouts = detect_cutouts_in_segment(
                chunk, sample_rate, seg["start"], seg["end"], cutout_config, ref_rms
            )
        except Exception:
            log.exception(
                "Cutout detection failed on segment %s",
                seg.get("segment_id"),
            )
            seg_cutouts = []

        enable_transcription = bool(config.get("ENABLE_CUTOUT_BY_TRANSCRIPTION", False))
        if words and enable_transcription:
            word_cutouts = _detect_cutout_words_in_segment(
                seg, words, audio_data, sample_rate, cutout_config, ref_rms
            )
            seg_cutouts = seg_cutouts + word_cutouts
            seg_cutouts.sort(key=lambda c: c["start_ms"])

        seg["cutouts"] = seg_cutouts
        seg["y_pred_cutouts"] = seg_cutouts
        all_cutouts.extend(seg_cutouts)

        # End-of-speech detection (last frame above silence threshold)
        end_speech_local_ms = detect_end_speech_in_chunk(
            chunk, sample_rate, cutout_config, ref_rms
        )
        if end_speech_local_ms is not None:
            seg["end_speech_s"] = seg["start"] + end_speech_local_ms / 1000.0
        else:
            seg["end_speech_s"] = None

    all_cutouts.sort(key=lambda c: c["start_ms"])
    log.debug(
        "Cutout detection: %d events across %d segments",
        len(all_cutouts),
        len(segments),
    )
    return all_cutouts


def _build_turns(segments: list[dict]) -> list[dict]:
    """Build turn-level summaries from segments for failure detection.

    Groups segments by turn number and extracts user_end / agent_start
    timestamps and agent text.
    """
    turns_map: dict[int, dict] = {}
    for seg in segments:
        turn_num = seg.get("turn")
        if turn_num is None:
            continue
        if turn_num not in turns_map:
            turns_map[turn_num] = {
                "turn_number": turn_num,
                "user_end": None,
                "agent_start": None,
                "agent_text": "",
            }
        t = turns_map[turn_num]
        if seg["speaker"] == "user":
            end = seg["end"]
            if t["user_end"] is None or end > t["user_end"]:
                t["user_end"] = end
        elif seg["speaker"] == "agent":
            start = seg["start"]
            if t["agent_start"] is None or start < t["agent_start"]:
                t["agent_start"] = start
            text = seg.get("text", "")
            if text:
                t["agent_text"] = (t["agent_text"] + " " + text).strip()

    return [turns_map[k] for k in sorted(turns_map)]


def detect_failed_responses(
    segments: list[dict],
    config: dict,
) -> list[dict]:
    """Run failed response detection on all turns.

    Mutates segments in-place by adding ``failed_response`` key to agent
    segments of affected turns. Returns the flat list of all failure events.

    Args:
        segments: Pipeline segments with speaker, turn, start/end, text.
        config: Config dict (unused for current detectors).
    """
    detectors: list[FailureDetector] = [
        EmptyResponseDetector(),
    ]
    detection_config: dict = {}

    turns = _build_turns(segments)
    all_failures: list[dict] = []
    failure_by_turn: dict[int, list[dict]] = {}

    for turn in turns:
        turn_failures: list[dict] = []
        for detector in detectors:
            try:
                events = detector.detect(turn, detection_config)
                for ev in events:
                    turn_failures.append(ev.to_dict())
            except Exception:
                log.exception(
                    "Failure detector %s failed on turn %s",
                    type(detector).__name__,
                    turn["turn_number"],
                )

        if turn_failures:
            failure_by_turn[turn["turn_number"]] = turn_failures
            all_failures.extend(turn_failures)

    # Attach to segments
    for seg in segments:
        turn_num = seg.get("turn")
        if turn_num in failure_by_turn:
            seg.setdefault("failed_response", []).extend(failure_by_turn[turn_num])
        else:
            seg.setdefault("failed_response", [])

    all_failures.sort(key=lambda f: f["timestamp"])
    log.debug(
        "Failed response detection: %d events across %d turns",
        len(all_failures),
        len(turns),
    )
    return all_failures
