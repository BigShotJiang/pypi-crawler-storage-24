"""Voice agent audio evaluation tool."""

from cli.core.pipeline import run

__all__ = ["run"]
