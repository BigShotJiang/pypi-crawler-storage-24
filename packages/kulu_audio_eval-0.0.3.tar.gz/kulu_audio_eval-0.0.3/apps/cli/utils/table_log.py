"""Reusable Rich table logging to stderr (e.g. config and params tables)."""

from __future__ import annotations

import sys
from typing import Iterable

from rich.align import Align
from rich.console import Console
from rich.table import Table

__all__ = ["print_table"]

# Style used for all tables
_TABLE_STYLE = "green"
_BORDER_STYLE = "green"
_HEADER_STYLE = "green bold"
_VALUE_STYLE = "cyan"


def print_table(
    rows: Iterable[tuple[str, str]],
    *,
    left_header: str = "Parameter",
    right_header: str = "Value",
) -> None:
    """Print a two-column table to stderr, center-aligned, green styling.

    Args:
        rows: Sequence of (left_cell, right_cell) pairs.
        left_header: Header for the first column.
        right_header: Header for the second column.
    """
    table = Table(style=_TABLE_STYLE, border_style=_BORDER_STYLE)
    table.add_column(left_header, style=_HEADER_STYLE)
    table.add_column(right_header, style=_VALUE_STYLE)
    for left, right in rows:
        table.add_row(left, right)
    Console(file=sys.stderr).print(Align(table, align="center"))
