"""Audio loading and chunk export utilities."""

from __future__ import annotations

import csv

import numpy as np
import soundfile as sf
import librosa


def load_audio(audio_path: str, target_sr: int = 16000) -> dict:
    """Load audio file, convert to mono, resample to target_sr.

    Returns:
        Dict with keys: audio (np.ndarray), sample_rate (int), duration (float seconds).
    """
    audio, sr = sf.read(audio_path, dtype="float32")

    # Convert to mono if stereo
    if audio.ndim > 1:
        audio = audio.mean(axis=1)

    # Resample if needed
    if sr != target_sr:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=target_sr)
        sr = target_sr

    duration = len(audio) / sr
    return {"audio": audio, "sample_rate": sr, "duration": duration}


def load_audio_stereo(audio_path: str, target_sr: int = 16000) -> dict:
    """Load audio preserving stereo channels (ch0=agent, ch1=user), resampled to target_sr.

    If the source is mono, both channels are identical (same data duplicated).

    Returns:
        Dict with keys: audio (np.ndarray shape [samples, 2]), sample_rate (int), duration (float).
    """
    audio, sr = sf.read(audio_path, dtype="float32")

    if audio.ndim == 1:
        # Mono source — duplicate into two identical channels
        audio = np.stack([audio, audio], axis=1)
    elif audio.shape[1] > 2:
        audio = audio[:, :2]

    if sr != target_sr:
        ch0 = librosa.resample(audio[:, 0], orig_sr=sr, target_sr=target_sr)
        ch1 = librosa.resample(audio[:, 1], orig_sr=sr, target_sr=target_sr)
        audio = np.stack([ch0, ch1], axis=1)
        sr = target_sr

    duration = audio.shape[0] / sr
    return {"audio": audio, "sample_rate": sr, "duration": duration}


def export_chunk(
    audio: np.ndarray,
    sample_rate: int,
    start_s: float,
    end_s: float,
    output_path: str,
) -> None:
    """Export a time-slice of audio to a WAV file.

    Args:
        audio: Full audio array — mono (samples,) or stereo (samples, 2), float32.
        sample_rate: Sample rate in Hz.
        start_s: Start time in seconds.
        end_s: End time in seconds.
        output_path: Path for the output WAV file.
    """
    n_samples = audio.shape[0]
    start_sample = max(0, int(start_s * sample_rate))
    end_sample = min(n_samples, int(end_s * sample_rate))
    chunk = audio[start_sample:end_sample]
    sf.write(output_path, chunk, sample_rate)


def export_chunk_audio_csv(
    audio: np.ndarray,
    sample_rate: int,
    start_s: float,
    end_s: float,
    output_path: str,
) -> None:
    """Export raw audio samples and timestamps for a chunk as CSV.

    Columns: timestamp_ms, amplitude, agent_amplitude, user_amplitude.
    Per-channel samples are ch0=agent, ch1=user. ``amplitude`` is (agent+user)/2,
    matching ``load_audio`` mono mix so legacy two-column consumers still work.

    Args:
        audio: Full audio array — mono (samples,) or stereo (samples, 2), float32.
        sample_rate: Sample rate in Hz.
        start_s: Start time in seconds.
        end_s: End time in seconds.
        output_path: Path for the output CSV file.
    """
    start_sample = max(0, int(start_s * sample_rate))
    end_sample = min(audio.shape[0], int(end_s * sample_rate))
    if audio.ndim == 1:
        agent = audio[start_sample:end_sample]
        user = agent
    else:
        agent = audio[start_sample:end_sample, 0]
        user = audio[start_sample:end_sample, 1]

    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["timestamp_ms", "amplitude", "agent_amplitude", "user_amplitude"]
        )
        for i in range(agent.shape[0]):
            timestamp_ms = (start_sample + i) / sample_rate * 1000.0
            a0 = float(agent[i])
            a1 = float(user[i])
            mix = 0.5 * (a0 + a1)
            writer.writerow(
                [
                    f"{timestamp_ms:.4f}",
                    f"{mix:.6f}",
                    f"{a0:.6f}",
                    f"{a1:.6f}",
                ]
            )
