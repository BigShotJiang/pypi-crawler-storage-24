"""Pipeline utils: duration formatting, stage labels."""

from __future__ import annotations

# Defaults
DEFAULT_OUTPUT_DIR = "out"

# Pipeline stage names (1-based). No separate "Model init" or "Transcribe";
# ElevenLabs does transcribe+diarize in one step.
STAGES = (
    "Load",
    "STT",
    "Annotate",
    "Chunks",
    "Anomaly",
    "Latency",
    "Translate",
    "Export transcript",
    "Timeline",
    "Visualize",
    "Evaluation",
)


def _format_duration(seconds: float) -> str:
    """Format seconds as MM:SS or HH:MM:SS."""
    m, s = divmod(int(round(seconds)), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def _format_pipeline_duration(seconds: float) -> str:
    """Format pipeline duration for summary: 19s or 1:23."""
    if seconds < 60:
        return f"{int(round(seconds))}s"
    return _format_duration(seconds)


def _stage(stage_num: int, msg: str) -> str:
    """Prefix message with pipeline stage [n/N] StageName stage: msg."""
    n, total = stage_num, len(STAGES)
    return f"[{n}/{total}] {STAGES[n - 1]} stage: {msg}"
